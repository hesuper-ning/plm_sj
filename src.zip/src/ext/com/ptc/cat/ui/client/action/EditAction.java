package ext.com.ptc.cat.ui.client.action;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.ptc.cat.ui.client.action.ActionDefinition;
import com.ptc.cat.ui.client.action.JCAAction;
import org.apache.log4j.Logger;

import com.extjs.gxt.ui.client.mvc.Dispatcher;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.ptc.cat.entity.client.ChangeAccumulator;
import com.ptc.cat.entity.client.ConstraintDescriptorManager;
import com.ptc.cat.entity.client.EntityCore;
import com.ptc.cat.entity.client.Flags;
import com.ptc.cat.entity.client.Identifier;
import com.ptc.cat.entity.client.attribute.Attribute;
import com.ptc.cat.entity.client.attribute.ModelLoader;
import com.ptc.cat.entity.client.change.StructureModelUpdate;
import com.ptc.cat.entity.client.descriptor.TypeDescriptor;
import com.ptc.cat.entity.client.structure.SimpleMasteredStructureModel;
import com.ptc.cat.entity.client.structure.StructureModel;
import com.ptc.cat.gxt.client.AbstractEntryPoint;
import com.ptc.cat.gxt.client.GSEEvents;
import com.ptc.cat.gxt.client.GXTMessages;
import com.ptc.cat.gxt.client.controller.TreeController;
import com.ptc.cat.gxt.client.model.BaseTreeModel;
import com.ptc.cat.gxt.client.model.ModelsByIdentifiersMap;
import com.ptc.cat.gxt.client.util.Util;
import com.ptc.cat.gxt.client.view.TreeView;
import com.ptc.cat.gxt.client.widget.MessageDialog;
import com.ptc.cat.ops.client.OperationResult;
import com.ptc.cat.ops.client.OpsCore;
import com.ptc.cat.ops.client.internal.CheckoutOperation;
import com.ptc.cat.ui.client.internal.action.DefaultActionDefinition;

import wt.log4j.LogR;
import wt.util.WTMessage;

/**
 * @Author: lcd
 * @Date: 2023/7/24 15:36
 * @Description:
 */
public class EditAction extends JCAAction {

    private static final Logger log = LogR.getLogger(com.ptc.cat.ui.client.action.EditAction.class.getName());

    private boolean doPostProcessingAlreadyRun = false;

    public EditAction(ActionDefinition definition) {
        super(definition);
    }

    @Override
    public void run(final AsyncCallback<OperationResult> call_back) {

        doPostProcessingAlreadyRun = false;

        StructureModel model = getAffectedStructureModels().get(0);
        if (!model.isFlagEnabled(Flags.F_CHECKEDOUT_COPY ) && !model.isFlagEnabled(Flags.F_WORKING_COPY)) {
            Set<StructureModel> model_set = new HashSet<StructureModel>();
            model_set.add(model);
            final CheckoutOperation checkout_operation = getCheckoutOperation(model.getContext(), model_set);
            OpsCore.getInstance().getOperationManager().commitNow(
                    checkout_operation,
                    new AsyncCallback<OperationResult>() {
                        @Override
                        public void onFailure(Throwable caught) {
                            Dispatcher.forwardEvent(GSEEvents.ActionCompleted);
                            log.error("EditAction: failed to checkout parent object.", caught);
                            MessageDialog.showErrorMessage(checkout_operation.getFailedLabel(), caught.getLocalizedMessage());
                        }

                        @Override
                        public void onSuccess(OperationResult result) {
                            // This would revalidate the toolbar so that even if the user cancels the add
                            // action later, the toolbar will still be valid
                            Dispatcher.forwardEvent(GSEEvents.ActionCompleted);
                            run(call_back);
                        }
                    }
            );
        } else {
            super.run(call_back);
        }
    }

    protected CheckoutOperation getCheckoutOperation(EntityCore context, Set<StructureModel> model_set)
    {
        return new CheckoutOperation(context, model_set);
    }

    @Override
    protected void populateActionDefinition(ActionDefinition action_definition) {
        DefaultActionDefinition actionDefinition = (DefaultActionDefinition) action_definition;

        String actionName="editGWT";
        String formProcessorClass="ext.plm.processor.part.CtPartEditProcessor";

        actionDefinition.setFormProcessorClass(formProcessorClass);
        actionDefinition.setName(actionName);
    }

    @Override
    protected JSONObject populateAdditionalParams(JSONObject result) {
        JSONString jsonOID = new JSONString(super.getSelectedModelOid());
        result.put("oid", jsonOID);
        return result;
    }

    // Overridden to support cell selections
    @Override
    protected StructureModel populateSelectedModel() {
        List<StructureModel> models = getAffectedStructureModels();
        if (models != null && !models.isEmpty()) {
            return models.get(0);
        }
        return null;
    }

    @Override
    protected void doPostProcessing(StructureModel selected_model,
                                    @SuppressWarnings("unused") List<Identifier> added_identifier_list) {

        if (doPostProcessingAlreadyRun) {
            return;
        }
        else {
            doPostProcessingAlreadyRun = true;
        }

        String type = null;
        try {
            String type_name = selected_model.getChildIdentifier().getTypeName();
            if (type_name != null) {
                TypeDescriptor info = ConstraintDescriptorManager.getTypeDescriptor(type_name);
                type = info.getDisplay();
            }
        }
        catch (Exception e){
            log.error("EditCommonAtributesAction: could not set the object type.", e);
            type = null;
        }
        LoadAttributesCallback loadAttributesCallback = type == null ? null : new LoadAttributesCallback(type);

        List<StructureModel> affectedStructureModels = getAffectedRowStructureModels();

        StructureModel selectedModel = affectedStructureModels.get(0);

        List<Attribute> attributes = ModelLoader.getRegisteredAttributes(selectedModel);

        StructureModel rootStructureModel = null;
        if(getView() instanceof TreeView && ((TreeView) getView()).getController() instanceof TreeController) {
            TreeController tree_controller = (TreeController) ((TreeView) getView()).getController();
            rootStructureModel = tree_controller.getRoot().getStructure();
        }
        if (selectedModel instanceof SimpleMasteredStructureModel && rootStructureModel != null && selectedModel.equals(rootStructureModel)) {
            // We are dealing with the root of the tree
            loadAttributesCallback.setRefreshRoot(true);
        }

        @SuppressWarnings("unchecked")
        ModelsByIdentifiersMap<BaseTreeModel> modelMap = getContext().getModelsByIdentifierMap(getView());

        LinkedList<BaseTreeModel> affectedModels = modelMap.getModelsContainingIdentifier(selectedModel.getChildIdentifier());

        // It's possible that more than 1 StructureModel was affected by the update made by the Edit dialog.
        // Clear out the checkout flags for each affected model and add each affected model to the structureModelsAffected
        // list so that they get reloaded.
        List<StructureModel> structureModelsAffected = new ArrayList<StructureModel>();
        for (BaseTreeModel affectedModel : affectedModels) {
            StructureModel affectedStructureModel = affectedModel.getStructure();
            affectedStructureModel.disableFlags(Flags.F_WORKING_COPY);
            affectedStructureModel.disableFlags(Flags.F_CHECKEDOUT_COPY);
            affectedStructureModel.disableFlags(Flags.F_CHECKEDOUT_TO_ME);
            structureModelsAffected.add(affectedStructureModel);
        }

        ModelLoader.loadModel(structureModelsAffected, attributes, loadAttributesCallback, selectedModel.getContext(), true, true, true, false);
    }

    /**
     *
     * Set status message after editing the object common attributes.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false <BR>
     * <BR>
     * <B>Extendable: </B>false
     */
    private class LoadAttributesCallback  implements AsyncCallback<List<StructureModel>>{
        String type;
        boolean refreshRoot = false;

        public LoadAttributesCallback(String type) {
            this.type = type;
        }

        public void setRefreshRoot(boolean refreshRoot) {
            this.refreshRoot = refreshRoot;
        }

        @Override
        public void onFailure(Throwable caught) {
            log.error("Edit Common Attributes Action failed.", caught);

            forceRefresh();

            // This would revalidate the toolbar so that even if the user cancels the add
            // action later, the toolbar will still be valid
            Dispatcher.forwardEvent(GSEEvents.ActionCompleted);

            Util.setErrorStatus(WTMessage.getLocalizedMessage(AbstractEntryPoint.GXT_RESOURCES,
                    GXTMessages.ObjectUpdatedFailed, new String[] { type } ));

            MessageDialog.showErrorMessage(caught);
        }

        @Override
        public void onSuccess(List<StructureModel> result) {

            forceRefresh();

            // This would revalidate the toolbar so that even if the user cancels the add
            // action later, the toolbar will still be valid
            Dispatcher.forwardEvent(GSEEvents.ActionCompleted);

            // Set status
            Util.setCompleteStatus(WTMessage.getLocalizedMessage(AbstractEntryPoint.GXT_RESOURCES,
                    GXTMessages.ObjectUpdated, new String[] { type } ));
        }

        private void forceRefresh() {
            // Force refresh the selected models
            StructureModel model = null;
            List<StructureModel> affectedModels = getAffectedRowStructureModels();
            if (affectedModels != null && affectedModels.size() > 0) {
                model = affectedModels.get(0);
            }

            if (model == null) {
                return;
            }

            ChangeAccumulator changeAccumulator = new ChangeAccumulator(LoadAttributesCallback.class.getName(), model.getContext());
            model.getContext().pushChangeAccumulator(changeAccumulator);
            changeAccumulator.pushChange(new StructureModelUpdate(model, model.getChildIdentifier()));
            model.getContext().popChangeAccumulator();

            if (refreshRoot) {
                EntityCore context = model.getContext();
                String rootStringId = context.getRootIdentifier().getStringIdentifer();
                if (!rootStringId.startsWith("OR:") && !rootStringId.startsWith("VR:")) {
                    rootStringId = "OR:" + rootStringId;
                }
                infoPageRefreshTop(rootStringId);
            }
        }
    }
}
