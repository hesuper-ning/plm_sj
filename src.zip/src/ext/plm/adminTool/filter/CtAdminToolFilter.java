package ext.plm.adminTool.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.plm.util.CtUserUtil;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.org.WTPrincipal;

/**
 * 管理员工具过滤器
 *
 * @Author liangzh
 * @DATE 2022/3/21 15:45
 */
public class CtAdminToolFilter extends DefaultSimpleValidationFilter {

    public CtAdminToolFilter() {
    }


    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria) {
        UIValidationStatus uivalidationstatus = UIValidationStatus.DISABLED;
        try {
            WTPrincipal currentUser = CtUserUtil.getCurrentUser();
            WTContainerRef siteContainerRef = WTContainerHelper.service.getExchangeRef();
            if (siteContainerRef != null && WTContainerHelper.service.isAdministrator(siteContainerRef, currentUser)) {
                uivalidationstatus = UIValidationStatus.ENABLED;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return uivalidationstatus;
    }
}
