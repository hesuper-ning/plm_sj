package ext.plm.adminTool.configCenter.mapper;

import ext.plm.adminTool.configCenter.bo.CtMultiAttributeConfigBO;
import ext.plm.adminTool.configCenter.bo.CtStringDefinitionBO;
import ext.plm.adminTool.configCenter.bo.CtStringValueBO;
import org.apache.ibatis.annotations.*;

import java.util.HashMap;
import java.util.List;

/**
 * 多属性配置mapper组件
 * @author liangzh
 */
@Mapper
public interface CtMultiAttributeConfigMapper {

    /**
     * 通过菜单ids查询多属性配置
     * @param menuIdList
     * @return
     */
    @Select("<script>" +
                "SELECT * FROM ZMultiAttributeConfig WHERE configMenuId IN "+
                "<foreach collection='list' index='index' item='item'  open='(' separator=',' close=')'>" +
                    "#{item}"+
                "</foreach>"+
            "</script>")
    List<CtMultiAttributeConfigBO> getMultiAttributeByMenuIds(List<String> menuIdList);

    /**
     * 通过对象ids 批量删除StringValue
     * @param object_idList
     */
    @Delete("<script>" +
                "DELETE FROM ZStringValue WHERE objectId IN "+
                "<foreach collection='list' index='index' item='item'  open='(' separator=',' close=')'>" +
                    "#{item}"+
                "</foreach>"+
            "</script>")
    void batchDeleteStringValueByObjectIds(List<String> object_idList);

    /**
     * 通过菜单ids 批量删除StringDefinition
     * @param menuIdList
     */
    @Delete("<script>" +
                "DELETE FROM ZStringDefinition WHERE configMenuId IN "+
                "<foreach collection='list' index='index' item='item'  open='(' separator=',' close=')'>" +
                    "#{item}"+
                "</foreach>"+
            "</script>")
    void batchDeleteStringDefinitionByMenuIds(List<String> menuIdList);

    /**
     * 通过菜单id查询多属性配置
     * @param menuId
     * @return
     */
    @Select("SELECT * FROM ZMultiAttributeConfig WHERE configMenuId = #{configMenuId}")
    List<CtMultiAttributeConfigBO> getMultiAttributeByMenuId(@Param("configMenuId") String menuId);

    /**
     * 通过对象id查询多属性配置
     * @param objectId
     * @return
     */
    @Select("SELECT ZStringDefinition.innerName,ZStringValue.ZStringValue " +
            "FROM ZMultiAttributeConfig,ZStringDefinition,ZStringValue " +
            "WHERE ZMultiAttributeConfig.id=ZStringValue.objectId " +
            "AND ZStringValue.strDefinitionId=ZStringDefinition.id " +
            "AND ZStringValue.objectId=#{objectId}")
    List<HashMap<String, String>> getMultiAttributeByObjectId(@Param("objectId") String objectId);

    /**
     * 新增多属性配置
     * @param multiAttributeConfig
     */
    @Insert("INSERT INTO ZMultiAttributeConfig " +
            "(" +
                "id," +
                "configMenuId," +
                "createUserId," +
                "modifiedUserId," +
                "createTime," +
                "modifiedTime" +
            ") VALUES (" +
                "#{id}," +
                "#{configMenuId}," +
                "#{createUserId}," +
                "#{modifiedUserId}," +
                "#{createTime}," +
                "#{modifiedTime}" +
            ")")
    void createMultiAttributeConfig(CtMultiAttributeConfigBO multiAttributeConfig);

    /**
     * 新增多属性配置 属性
     * @param stringValue
     */
    @Insert("INSERT INTO ZStringValue " +
            "(" +
                "id," +
                "objectId," +
                "strDefinitionId," +
                "stringValue," +
                "createUserId," +
                "modifiedUserId," +
                "createTime," +
                "modifiedTime" +
            ") VALUES (" +
                "#{id}," +
                "#{objectId}," +
                "#{strDefinitionId}," +
                "#{stringValue}," +
                "#{createUserId}," +
                "#{modifiedUserId}," +
                "#{createTime}," +
                "#{modifiedTime}" +
            ")")
    void createStringValue(CtStringValueBO stringValue);

    /**
     * 更新多属性配置
     * @param stringValue
     */
    @Update("UPDATE ZStringValue SET " +
            "stringValue=#{stringValue}," +
            "modifiedUserId=#{modifiedUserId}," +
            "modifiedTime=#{modifiedTime} " +
            "WHERE objectId=#{objectId} " +
            "AND strDefinitionId=#{strDefinitionId}")
    void updateMultiAttributeConfig(CtStringValueBO stringValue);

    /**
     * 批量删除多属性配置
     * @param ids
     */
    @Delete("<script>" +
                "DELETE FROM ZMultiAttributeConfig WHERE id IN "+
                "<foreach collection='list' index='index' item='item'  open='(' separator=',' close=')'>" +
                    "#{item}"+
                "</foreach>"+
            "</script>")
    void batchDeleteMultiAttributeConfigByIds(List<String> ids);

    /**
     * 通过菜单Id查询多属性配置key
     * @param menuId
     * @return
     */
    @Select("SELECT * FROM ZStringDefinition WHERE configMenuId=#{menuId}")
    List<CtStringDefinitionBO> getStringDefinitionByMenuId(@Param("menuId") String menuId);

    /**
     * 通过内部名称获取StringDefinition
     * @param innerName
     * @return
     */
    @Select("SELECT * FROM ZStringDefinition WHERE innerName=#{innerName}")
    CtStringDefinitionBO getStringDefinitionByInnerName(String innerName);

    /**
     * 新增stringDefinition
     * @param stringDefinition
     */
    @Insert("INSERT INTO ZStringDefinition " +
            "(" +
                "id," +
                "configMenuId," +
                "innerName," +
                "displayName," +
                "createUserId," +
                "modifiedUserId," +
                "createTime," +
                "modifiedTime" +
            ") VALUES (" +
                "#{id}," +
                "#{configMenuId}," +
                "#{innerName}," +
                "#{displayName}," +
                "#{createUserId}," +
                "#{modifiedUserId}," +
                "#{createTime}," +
                "#{modifiedTime}" +
            ")")
    void createStringDefinition(CtStringDefinitionBO stringDefinition);

    /**
     * 更新stringDefinition
     * @param stringDefinition
     */
    @Update("UPDATE ZStringDefinition SET " +
            "innerName=#{innerName}," +
            "displayName=#{displayName}," +
            "modifiedUserId=#{modifiedUserId}," +
            "modifiedTime=#{modifiedTime} " +
            "WHERE id=#{id} ")
    void updateStringDefinition(CtStringDefinitionBO stringDefinition);

    /**
     * 通过StrDefIds批量删除stringValue
     * @param strDefIds
     */
    @Delete("<script>" +
                "DELETE FROM ZStringValue WHERE strDefinitionId IN "+
                "<foreach collection='list' index='index' item='item'  open='(' separator=',' close=')'>" +
                    "#{item}"+
                "</foreach>"+
            "</script>")
    void batchDeleteStringValueByStrDefIds(List<String> strDefIds);

    /**
     * 通过id批量删除StringDefinition
     * @param idList
     */
    @Delete("<script>" +
                "DELETE FROM ZStringDefinition WHERE id IN "+
                "<foreach collection='list' index='index' item='item'  open='(' separator=',' close=')'>" +
                    "#{item}"+
                "</foreach>"+
            "</script>")
    void batchDeleteStringDefinitionByIds(List<String> idList);

    /**
     * 获取对象指定属性值
     * @param object_id
     * @param strDefinitionId
     * @return
     */
    @Select("SELECT ZStringValue.stringValue " +
            "FROM ZMultiAttributeConfig,ZStringDefinition,ZStringValue " +
            "WHERE ZMultiAttributeConfig.id=ZStringValue.object_id " +
            "AND ZStringValue.strDefinitionId=ZStringDefinition.id " +
            "AND ZStringValue.objectId=#{objectId} " +
            "AND ZStringDefinition.id=#{strDefinitionId}")
    String getStringValueByObjectIdAndDefId(@Param("objectId") String object_id, @Param("strDefinitionId") String strDefinitionId);

    /**
     * 通过菜单id查询多属性配置
     * @param menuInnerName
     * @return
     */
    @Select("SELECT ZMultiAttributeConfig.* FROM ZMultiAttributeConfig,ZConfigMenu " +
            "WHERE ZMultiAttributeConfig.configMenuId = ZConfigMenu.id " +
            "AND ZConfigMenu.innerName=#{innerName}")
    List<CtMultiAttributeConfigBO> getMultiAttributeByMenuInnerName(@Param("innerName") String menuInnerName);
}
