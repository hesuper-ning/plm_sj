package ext.plm.adminTool.configCenter.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.adminTool.configCenter.bo.CtConfigMenuBO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 配置中心菜单mapper
 * @author liangzh
 */
@Mapper
public interface CtConfigMenuMapper extends BaseMapper<CtConfigMenuBO> {

}
