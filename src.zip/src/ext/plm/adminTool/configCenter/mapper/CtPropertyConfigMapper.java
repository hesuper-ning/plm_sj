package ext.plm.adminTool.configCenter.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.adminTool.configCenter.bo.CtPropertyConfigBO;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * property配置mapper组件
 * @author liangzh
 */
@Mapper
public interface CtPropertyConfigMapper extends BaseMapper<CtPropertyConfigBO> {

    /**
     * 通过菜单内部名称查询property配置
     * @param menuInnerName
     * @return
     */
    @Select("SELECT ZPropertyConfig.* FROM ZConfigMenu,ZPropertyConfig " +
            "WHERE ZPropertyConfig.configMenuId = ZConfigMenu.id " +
            "AND ZConfigMenu.innerName=#{innerName}")
    List<CtPropertyConfigBO> getPropertyConfigByMenuInnerName(@Param("innerName") String menuInnerName);
}
