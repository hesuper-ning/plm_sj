package ext.plm.adminTool.configCenter;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.adminTool.configCenter.bo.*;
import ext.plm.adminTool.configCenter.dao.CtConfigMenuDAO;
import ext.plm.adminTool.configCenter.dao.CtMultiAttributeConfigDAO;
import ext.plm.adminTool.configCenter.dao.CtPropertyConfigDAO;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import wt.util.WTProperties;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 配置中心service组件实现类
 * @author liangzh
 */
@Service
public class CtConfigCenterServiceImpl implements CtConfigCenterService {

    /**
     * 配置中心菜单DAO组件
     */
    @Autowired
    private CtConfigMenuDAO ctConfigMenuDAO;

    /**
     * property配置DAO组件
     */
    @Autowired
    private CtPropertyConfigDAO ctPropertyConfigDAO;

    /**
     * 多属性配置DAO组件
     */
    @Autowired
    private CtMultiAttributeConfigDAO ctMultiAttributeConfigDAO;

    /**
     * 查询配置中心菜单
     * @return
     */
    @Override
    public List<CtConfigMenuBO> getConfigCenterMenu() throws Exception{
        List<CtConfigMenuBO> configMenuList = ctConfigMenuDAO.getAllConfigCenterMenu();
        if(CollectionUtils.isEmpty(configMenuList)){
            configMenuList = initDefaultConfigMenu();
        }

        List<CtConfigMenuBO> resultList = new ArrayList<>();
        for (CtConfigMenuBO menu:configMenuList){
            if (StringUtils.isNotBlank(menu.getParentId())){
                continue;
            }
            menu.setLeaf(false);
            buildMenuTree(menu,configMenuList);
            resultList.add(menu);
        }
        return resultList;
    }

    /**
     * 新增配置中心菜单
     * @param configMenu
     * @return
     */
    @Override
    public String createConfigCenterMenu(CtConfigMenuBO configMenu) throws Exception{
        checkConfigMenu(configMenu);
        return ctConfigMenuDAO.createConfigCenterMenu(configMenu);
    }

    /**
     * 更新配置中心菜单
     * @param configMenu
     */
    @Override
    public void updateConfigCenterMenu(CtConfigMenuBO configMenu) {
        ctConfigMenuDAO.updateConfigCenterMenu(configMenu);
    }

    /**
     * 批量删除更新配置中心菜单
     * @param idList
     */
    @Transactional
    @Override
    public void batchDeleteConfigCenterMenu(List<String> idList) throws Exception{
        //1.删除菜单
        ctConfigMenuDAO.batchDeleteConfigCenterMenu(idList);
        //2.删除property配置
        ctPropertyConfigDAO.batchDeletePropertyConfigByMenuIds(idList);
        //3.删除多属性值配置
        ctMultiAttributeConfigDAO.batchDeleteStringDefinitionByMenuIds(idList);
        List<CtMultiAttributeConfigBO> multiAttributeConfigList = ctMultiAttributeConfigDAO.getMultiAttributeByMenuIds(idList);
        if (CollectionUtils.isNotEmpty(multiAttributeConfigList)){

            List<String> objIds = multiAttributeConfigList.stream().map(e -> e.getId()).collect(Collectors.toList());
            ctMultiAttributeConfigDAO.batchDeleteStringValueByObjectIds(objIds);
        }
    }

    /**
     * 通过菜单Id查询property配置
     * @param menuId
     * @return
     */
    @Override
    public List<CtPropertyConfigBO> getPropertyConfigByMenuId(String menuId) {
        return ctPropertyConfigDAO.getPropertyConfigByMenuId(menuId);
    }

    /**
     * 通过菜单内部名称查询property配置
     * @param menuInnerName
     * @return
     */
    @Override
    public List<CtPropertyConfigBO> getPropertyConfigByMenuInnerName(String menuInnerName) {
        return ctPropertyConfigDAO.getPropertyConfigByMenuInnerName(menuInnerName);
    }

    /**
     * 新增property配置
     * @param propertyConfig
     * @return
     */
    @Override
    public String createPropertyConfig(CtPropertyConfigBO propertyConfig) throws Exception{
        checkPropertyConfig(propertyConfig);
        return ctPropertyConfigDAO.createPropertyConfig(propertyConfig);
    }

    /**
     * 更新property配置
     * @param propertyConfig
     */
    @Override
    public void updatePropertyConfig(CtPropertyConfigBO propertyConfig) throws Exception{
        checkPropertyConfig(propertyConfig);
        ctPropertyConfigDAO.updatePropertyConfig(propertyConfig);
    }

    /**
     * 批量删除property配置
     * @param idList
     */
    @Override
    public void batchDeletePropertyConfig(List<String> idList) {
        ctPropertyConfigDAO.batchDeletePropertyConfig(idList);
    }

    /**
     * 通过菜单Id查询多属性配置
     * @param menuId
     * @return
     */
    @Override
    public List<HashMap<String, String>> getMultiAttributeConfigByMenuId(String menuId) {
        List<CtMultiAttributeConfigBO> multiAttributeConfigList = ctMultiAttributeConfigDAO.getMultiAttributeByMenuId(menuId);

        return createMultiAttributeList(multiAttributeConfigList);
    }

    /**
     * 通过菜单Id查询多属性配置
     * @param menuInnerName
     * @return
     */
    @Override
    public List<HashMap<String, String>> getMultiAttributeConfigByMenuInnerName(String menuInnerName) {
        List<CtMultiAttributeConfigBO> multiAttributeConfigList = ctMultiAttributeConfigDAO.getMultiAttributeByMenuInnerName(menuInnerName);

        return createMultiAttributeList(multiAttributeConfigList);
    }

    /**
     * 新增多属性配置
     * @param multiAttributeConfigParam
     * @return
     */
    @Transactional
    @Override
    public String saveMultiAttributeConfig(CtMultiAttributeConfigQuery multiAttributeConfigParam) throws Exception{
       String strValue = ctMultiAttributeConfigDAO.getStringValueByObjectIdAndDefId(multiAttributeConfigParam.getId(),multiAttributeConfigParam.getStrDefinitionId());

       if (StringUtils.isBlank(multiAttributeConfigParam.getId()) || StringUtils.isBlank(strValue)){
           return createMultiAttributeConfig(multiAttributeConfigParam);
       }else {
           return updateMultiAttributeConfig(multiAttributeConfigParam);
       }
    }

    /**
     * 批量删除多属性配置
     * @param objIds
     */
    @Transactional
    @Override
    public void batchDeleteMultiAttributeConfig(List<String> objIds) {
        ctMultiAttributeConfigDAO.batchDeleteMultiAttributeConfigByIds(objIds);
        ctMultiAttributeConfigDAO.batchDeleteStringValueByObjectIds(objIds);
    }

    /**
     * 通过菜单Id查询多属性配置key
     * @param menuId
     * @return
     */
    @Override
    public List<CtStringDefinitionBO> getStringDefinitionByMenuId(String menuId) {
        return ctMultiAttributeConfigDAO.getStringDefinitionByMenuId(menuId);
    }

    /**
     *批量保存多属性配置key
     * @param stringDefinitionList
     */
    @Transactional
    @Override
    public void batchSaveStringDefinition(List<CtStringDefinitionBO> stringDefinitionList) throws Exception {
        if(CollectionUtils.isEmpty(stringDefinitionList)){
            return;
        }
        checkStringDefinition(stringDefinitionList);

        //获取原菜单配置属性
        List<CtStringDefinitionBO> orgStringDefinitionList = ctMultiAttributeConfigDAO.getStringDefinitionByMenuId(stringDefinitionList.get(0).getConfigMenuId());
        //获取出需要删除的属性配置
        orgStringDefinitionList.removeAll(stringDefinitionList);

        List<String> idList = orgStringDefinitionList.stream().map(e -> e.getId()).collect(Collectors.toList());
        batchDeleteStringDefinition(idList);

        for (CtStringDefinitionBO stringDefinition:stringDefinitionList){
            if (StringUtils.isBlank(stringDefinition.getId())){
                createStringDefinition(stringDefinition);
            }else {
                updateStringDefinition(stringDefinition);
            }
        }
    }

    /**
     * 校验stringDefinition创建
     * @param stringDefinitionList
     */
    private void checkStringDefinition(List<CtStringDefinitionBO> stringDefinitionList) throws Exception{
        HashSet<String> innerNameSet = new HashSet<>();

        String errorMsg="";
        for (CtStringDefinitionBO stringDefinition:stringDefinitionList){
            String innerName = stringDefinition.getInnerName();
            if (innerNameSet.contains(innerName)){
                errorMsg="属性："+innerName+"，已经存在！";
                continue;
            }
            innerNameSet.add(innerName);
            CtStringDefinitionBO orgStringDefinition=ctMultiAttributeConfigDAO.getStringDefinitionByInnerName(stringDefinition.getInnerName());
            if (orgStringDefinition!=null && !orgStringDefinition.getId().equals(stringDefinition.getId())){
                errorMsg="属性："+innerName+"，已经存在！";
            }
        }

        if (StringUtils.isNotBlank(errorMsg)){
            throw new Exception(errorMsg);
        }
    }


    /**
     * 构建树形菜单
     * @param rootMenu
     * @param configMenuList
     */
    private void buildMenuTree(CtConfigMenuBO rootMenu, List<CtConfigMenuBO> configMenuList){
        for (CtConfigMenuBO menu:configMenuList){
            if (rootMenu.getId().equals(menu.getParentId())){
                rootMenu.getChildren().add(menu);
                buildMenuTree(menu,configMenuList);
            }
        }
    }

    /**
     * 校验property配置
     * @param propertyConfig
     * @throws Exception
     */
    private void checkPropertyConfig(CtPropertyConfigBO propertyConfig) throws Exception{
        CtPropertyConfigBO orgPropertyConfig = ctPropertyConfigDAO.getPropertyConfigByKey(propertyConfig.getPropertyKey(),propertyConfig.getConfigMenuId());
        if (orgPropertyConfig!=null && !orgPropertyConfig.getId().equals(propertyConfig.getId())){
            throw new Exception("key值："+propertyConfig.getPropertyKey()+"，已经存在！");
        }
    }

    /**
     * 校验菜单配置
     * @param configMenu
     * @throws Exception
     */
    private void checkConfigMenu(CtConfigMenuBO configMenu) throws Exception {
        CtConfigMenuBO orgConfigMenu=ctConfigMenuDAO.getConfigCenterMenuByInnerName(configMenu.getInnerName());
        if (orgConfigMenu!=null && !orgConfigMenu.getId().equals(configMenu.getId())){
            throw new Exception("内部名称："+orgConfigMenu.getInnerName()+"，已经存在！");
        }
    }

    /**
     * 初始化默认菜单
     * @return
     */
    @Transactional
    private List<CtConfigMenuBO> initDefaultConfigMenu() throws Exception{
        List<CtConfigMenuBO> configMenuList = new ArrayList<>();
        List<CtPropertyConfigBO> propertyConfigList = new ArrayList<>();

        WTProperties wtProperties = WTProperties.getLocalProperties();
        String filePath = wtProperties.getProperty("wt.home") +"/codebase/ext/plm/adminTool/config/defaultConfigMenu.json";

        File file = new File(filePath);
        FileReader fileReader = new FileReader(file);
        Reader reader = new InputStreamReader(new FileInputStream(file),"utf-8");
        int ch = 0;
        StringBuffer sb = new StringBuffer();
        while ((ch = reader.read()) != -1) {
            sb.append((char) ch);
        }
        fileReader.close();
        reader.close();
        String jsonStr = sb.toString();
        JSONObject jsonObject = JSONObject.parseObject(jsonStr);
        JSONObject propertyConfigJson = jsonObject.getJSONObject("propertyConfig");
        JSONObject multiAttributeConfigJson = jsonObject.getJSONObject("multiAttributeConfig");

        // 单属性配置菜单
        CtConfigMenuBO propertyConfig = JSONObject.toJavaObject(propertyConfigJson, CtConfigMenuBO.class);
        String propertyConfigId = CtFormatUtil.getUUID();
        propertyConfig.setId(propertyConfigId);
        supplementAttribute(propertyConfig);

        configMenuList.add(propertyConfig);

        // 多属性配置菜单
        CtConfigMenuBO multiAttributeConfig = JSONObject.toJavaObject(multiAttributeConfigJson, CtConfigMenuBO.class);
        String multiAttributeConfigId = CtFormatUtil.getUUID();
        multiAttributeConfig.setId(multiAttributeConfigId);
        supplementAttribute(multiAttributeConfig);

        configMenuList.add(multiAttributeConfig);

        long userId = CtUserUtil.getCurrentUser().getPersistInfo().getObjectIdentifier().getId();

        // 单属性配置菜单子阶
        JSONArray items = propertyConfigJson.getJSONArray("items");
        for (int i=0;i<items.size();i++){
            JSONObject object = items.getJSONObject(i);
            CtConfigMenuBO ctConfigMenuBO = JSONObject.toJavaObject(object, CtConfigMenuBO.class);

            String uuid = CtFormatUtil.getUUID();
            ctConfigMenuBO.setParentId(propertyConfigId);
            ctConfigMenuBO.setId(uuid);
            supplementAttribute(ctConfigMenuBO);

            JSONArray jsonArray = object.getJSONArray("items");
            if (jsonArray!=null){
                for (int y=0;y<jsonArray.size();y++){
                    JSONObject json = jsonArray.getJSONObject(y);
                    CtPropertyConfigBO propertyConfigBO = JSONObject.toJavaObject(json, CtPropertyConfigBO.class);
                    propertyConfigBO.setConfigMenuId(uuid);
                    propertyConfigBO.setCreateTime(new Date());
                    propertyConfigBO.setModifiedTime(new Date());
                    propertyConfigBO.setCreateUserId(userId);
                    propertyConfigBO.setModifiedUserId(userId);

                    propertyConfigList.add(propertyConfigBO);
                }
            }

            configMenuList.add(ctConfigMenuBO);
        }

        // 不同数据库批量写入方法不同 做兼容处理单个写入
        for (CtConfigMenuBO ctConfigMenuBO:configMenuList){
            ctConfigMenuDAO.createConfigCenterMenu(ctConfigMenuBO);
        }

        for (CtPropertyConfigBO propertyConfigBO:propertyConfigList){
            ctPropertyConfigDAO.createPropertyConfig(propertyConfigBO);
        }

        return configMenuList;
    }

    /**
     * 补充属性
     * @param configMenu
     * @throws Exception
     */
    private void supplementAttribute(CtConfigMenuBO configMenu) throws Exception{
        long userId = CtUserUtil.getCurrentUser().getPersistInfo().getObjectIdentifier().getId();

        configMenu.setCreateTime(new Date());
        configMenu.setModifiedTime(new Date());
        configMenu.setCreateUserId(userId);
        configMenu.setModifiedUserId(userId);
    }

    /**
     * 新增多属性配置key
     * @param stringDefinition
     * @return
     */
    private String createStringDefinition(CtStringDefinitionBO stringDefinition) throws Exception {
        Long userId = CtUserUtil.getCurrentUser().getPersistInfo().getObjectIdentifier().getId();

        String uuid = CtFormatUtil.getUUID();
        stringDefinition.setId(uuid);
        stringDefinition.setCreateTime(new Date());
        stringDefinition.setModifiedTime(new Date());
        stringDefinition.setCreateUserId(userId);
        stringDefinition.setModifiedUserId(userId);

        ctMultiAttributeConfigDAO.createStringDefinition(stringDefinition);

        return uuid;
    }

    /**
     * 更新多属性配置key
     * @param stringDefinition
     * @throws Exception
     */
    private void updateStringDefinition(CtStringDefinitionBO stringDefinition) throws Exception {
        Long userId = CtUserUtil.getCurrentUser().getPersistInfo().getObjectIdentifier().getId();

        stringDefinition.setModifiedTime(new Date());
        stringDefinition.setModifiedUserId(userId);

        ctMultiAttributeConfigDAO.updateStringDefinition(stringDefinition);
    }

    /**
     * 批量删除多属性配置key
     * @param idList
     */
    private void batchDeleteStringDefinition(List<String> idList) {
        ctMultiAttributeConfigDAO.batchDeleteStringValueByStrDefIds(idList);
        ctMultiAttributeConfigDAO.batchDeleteStringDefinitionByIds(idList);
    }

    /**
     * 创建多属性配置
     * @param multiAttributeConfigParam
     * @throws Exception
     */
    private String createMultiAttributeConfig(CtMultiAttributeConfigQuery multiAttributeConfigParam) throws Exception{
        String objectId = multiAttributeConfigParam.getId();

        Long userId = CtUserUtil.getCurrentUser().getPersistInfo().getObjectIdentifier().getId();
        if (StringUtils.isBlank(objectId)){
            objectId = CtFormatUtil.getUUID();

            CtMultiAttributeConfigBO multiAttributeConfig = new CtMultiAttributeConfigBO();
            multiAttributeConfig.setId(objectId);
            multiAttributeConfig.setConfigMenuId(multiAttributeConfigParam.getConfigMenuId());
            multiAttributeConfig.setCreateTime(new Date());
            multiAttributeConfig.setModifiedTime(new Date());
            multiAttributeConfig.setCreateUserId(userId);
            multiAttributeConfig.setModifiedUserId(userId);

            ctMultiAttributeConfigDAO.createMultiAttributeConfig(multiAttributeConfig);
        }

        CtStringValueBO stringValue = new CtStringValueBO();
        stringValue.setId(CtFormatUtil.getUUID());
        stringValue.setObjectId(objectId);
        stringValue.setStrDefinitionId(multiAttributeConfigParam.getStrDefinitionId());
        stringValue.setStringValue(multiAttributeConfigParam.getValue());
        stringValue.setCreateTime(new Date());
        stringValue.setModifiedTime(new Date());
        stringValue.setCreateUserId(userId);
        stringValue.setModifiedUserId(userId);

        ctMultiAttributeConfigDAO.createStringValue(stringValue);

        return objectId;
    }

    /**
     * 更新多属性配置
     * @param multiAttributeConfigParam
     * @return
     */
    private String updateMultiAttributeConfig(CtMultiAttributeConfigQuery multiAttributeConfigParam) throws Exception{
        Long userId = CtUserUtil.getCurrentUser().getPersistInfo().getObjectIdentifier().getId();

        CtStringValueBO stringValue = new CtStringValueBO();
        stringValue.setObjectId(multiAttributeConfigParam.getId());
        stringValue.setStrDefinitionId(multiAttributeConfigParam.getStrDefinitionId());
        stringValue.setStringValue(multiAttributeConfigParam.getValue());
        stringValue.setModifiedTime(new Date());
        stringValue.setCreateUserId(userId);
        stringValue.setModifiedUserId(userId);

        ctMultiAttributeConfigDAO.updateMultiAttributeConfig(stringValue);

        return multiAttributeConfigParam.getId();
    }

    /**
     * 创建多属性
     * @param multiAttributeConfigList
     * @return
     */
    private List<HashMap<String, String>> createMultiAttributeList(List<CtMultiAttributeConfigBO> multiAttributeConfigList){
        List<HashMap<String, String>> resultList = new ArrayList<>();
        for (CtMultiAttributeConfigBO multiAttributeConfig:multiAttributeConfigList){
            List<HashMap<String,String>> attributeList =  ctMultiAttributeConfigDAO.getMultiAttributeByObjectId(multiAttributeConfig.getId());

            HashMap<String, String> map = new HashMap<>();
            map.put("id",multiAttributeConfig.getId());

            for (HashMap<String,String> attMap:attributeList){
                map.put(attMap.get("innerName"),attMap.get("stringValue"));
            }

            resultList.add(map);
        }

       return resultList;
    }
}
