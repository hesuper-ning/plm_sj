package ext.plm.adminTool.configCenter.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldStrategy;
import ext.plm.common.CtAbstractBO;

/**
 * property配置Bo
 * @author liangzh
 */
@TableName("ZPropertyConfig")
public class CtPropertyConfigBO extends CtAbstractBO {

    /**
     * 配置菜单ID
     */
    @TableField(value = "configMenuId" , strategy  = FieldStrategy.IGNORED)
    private String configMenuId;

    /**
     * key
     */
    @TableField(value = "propertyKey", strategy  = FieldStrategy.IGNORED)
    private String propertyKey;

    /**
     * value
     */
    @TableField(value = "propertyValue", strategy  = FieldStrategy.IGNORED)
    private String propertyValue;

    /**
     * 分隔符
     */
    @TableField(value = "splitChart", strategy  = FieldStrategy.IGNORED)
    private String splitChart;

    /**
     * 备注
     */
    @TableField(value = "remark", strategy  = FieldStrategy.IGNORED)
    private String remark;

    public String getConfigMenuId() {
        return configMenuId;
    }

    public void setConfigMenuId(String configMenuId) {
        this.configMenuId = configMenuId;
    }

    public String getPropertyKey() {
        return propertyKey;
    }

    public void setPropertyKey(String propertyKey) {
        this.propertyKey = propertyKey;
    }

    public String getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }

    public String getSplitChart() {
        return splitChart;
    }

    public void setSplitChart(String splitChart) {
        this.splitChart = splitChart;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "CtPropertyConfigBO{" +
                "configMenuId='" + configMenuId + '\'' +
                ", propertyKey='" + propertyKey + '\'' +
                ", propertyValue='" + propertyValue + '\'' +
                ", splitChart='" + splitChart + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }
}
