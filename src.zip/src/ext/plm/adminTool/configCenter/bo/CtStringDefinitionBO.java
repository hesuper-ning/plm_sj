package ext.plm.adminTool.configCenter.bo;

import ext.plm.common.CtAbstractBO;

/**
 * String类型配置定义BO
 * @author liangzh
 */
public class CtStringDefinitionBO extends CtAbstractBO {

    /**
     * 配置菜单ID
     */
    private String configMenuId;

    /**
     * 内部名称
     */
    private String innerName;

    /**
     * 显示名称
     */
    private String displayName;

    public String getConfigMenuId() {
        return configMenuId;
    }

    public void setConfigMenuId(String configMenuId) {
        this.configMenuId = configMenuId;
    }

    public String getInnerName() {
        return innerName;
    }

    public void setInnerName(String innerName) {
        this.innerName = innerName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return "CtStringDefinitionBo{" +
                "configMenuId='" + configMenuId + '\'' +
                ", innerName='" + innerName + '\'' +
                ", displayName='" + displayName + '\'' +
                '}';
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((configMenuId == null) ? 0 : configMenuId.hashCode());
        result = prime * result + ((innerName == null) ? 0 : innerName.hashCode());
        result = prime * result + ((displayName == null) ? 0 : displayName.hashCode());

        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        }

        if (obj == null){
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }
        CtStringDefinitionBO other = (CtStringDefinitionBO) obj;

        if (configMenuId == null) {
            if (other.configMenuId != null) {
                return false;
            }
        } else if (!configMenuId.equals(other.configMenuId)) {
            return false;
        }

        if (innerName == null) {
            if (other.innerName != null) {
                return false;
            }
        } else if (!innerName.equals(other.innerName)) {
            return false;
        }

        if (displayName == null) {
            if (other.displayName != null) {
                return false;
            }
        } else if (!displayName.equals(other.displayName)) {
            return false;
        }

        return true;
    }
}
