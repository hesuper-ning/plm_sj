package ext.plm.adminTool.configCenter.bo;

/**
 * 多属性配置param
 * @author liangzh
 */
public class CtMultiAttributeConfigQuery {

    private String id;

    private String strDefinitionId;

    private String value;

    private String configMenuId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStrDefinitionId() {
        return strDefinitionId;
    }

    public void setStrDefinitionId(String strDefinitionId) {
        this.strDefinitionId = strDefinitionId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getConfigMenuId() {
        return configMenuId;
    }

    public void setConfigMenuId(String configMenuId) {
        this.configMenuId = configMenuId;
    }
}
