package ext.plm.adminTool.configCenter.bo;

import ext.plm.common.CtAbstractBO;

/**
 * 多属性配置BO对象
 * @author liangzh
 */
public class CtMultiAttributeConfigBO extends CtAbstractBO {

    /**
     * 配置菜单ID
     */
    private String configMenuId;

    public String getConfigMenuId() {
        return configMenuId;
    }

    public void setConfigMenuId(String configMenuId) {
        this.configMenuId = configMenuId;
    }
}
