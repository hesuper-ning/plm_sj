package ext.plm.adminTool.configCenter.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldStrategy;
import com.fasterxml.jackson.annotation.JsonProperty;
import ext.plm.common.CtAbstractBO;

import java.util.ArrayList;
import java.util.List;

/**
 * 配置中心菜单BO
 * @author liangzh
 */
@TableName("ZConfigMenu")
public class CtConfigMenuBO extends CtAbstractBO {

    /**
     * 父节点id
     */
    @TableField(value = "parentId", strategy  = FieldStrategy.IGNORED)
    private String parentId;

    /**
     * 菜单内部名称
     */
    @TableField(value = "innerName", strategy  = FieldStrategy.IGNORED)
    private String innerName;

    /**
     * 菜单显示名称
     */
    @JsonProperty(value = "text")
    @TableField(value = "displayName", strategy  = FieldStrategy.IGNORED)
    private String displayName;

    /**
     * 0为单属性配置，1为多属性配置 菜单
     */
    @TableField(value = "multiAttributeStatus")
    private Integer multiAttributeStatus;

    /**
     * 非数据库字段
     */
    @TableField(exist = false)
    private boolean leaf=true;

    /**
     * 非数据库字段
     */
    @TableField(exist = false)
    private boolean expanded=true;

    /**
     * 子集
     */
    @TableField(exist = false)
    private List<CtConfigMenuBO> children=new ArrayList<>();

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getInnerName() {
        return innerName;
    }

    public void setInnerName(String innerName) {
        this.innerName = innerName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public List<CtConfigMenuBO> getChildren() {
        return children;
    }

    public void setChildren(List<CtConfigMenuBO> children) {
        this.children = children;
    }

    public boolean isLeaf() {
        return leaf;
    }

    public void setLeaf(boolean leaf) {
        this.leaf = leaf;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    public Integer getMultiAttributeStatus() {
        return multiAttributeStatus;
    }

    public void setMultiAttributeStatus(Integer multiAttributeStatus) {
        this.multiAttributeStatus = multiAttributeStatus;
    }

    @Override
    public String toString() {
        return "CtConfigMenuBo{" +
                "parentId='" + parentId + '\'' +
                ", innerName='" + innerName + '\'' +
                ", displayName='" + displayName + '\'' +
                ", multiAttributeStatus=" + multiAttributeStatus +
                ", leaf=" + leaf +
                ", expanded=" + expanded +
                ", children=" + children +
                '}';
    }
}
