package ext.plm.adminTool.configCenter.bo;

import ext.plm.common.CtAbstractBO;

/**
 * String类型值定义BO
 * @author liangzh
 */
public class CtStringValueBO extends CtAbstractBO {

    /**
     * 多属性配置id
     */
    private String objectId;

    /**
     * StringDefinitionID
     */
    private String strDefinitionId;

    /**
     * 字符串值
     */
    private String stringValue;

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getStrDefinitionId() {
        return strDefinitionId;
    }

    public void setStrDefinitionId(String strDefinitionId) {
        this.strDefinitionId = strDefinitionId;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }
}
