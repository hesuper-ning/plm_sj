package ext.plm.adminTool.configCenter;

import ext.plm.adminTool.configCenter.bo.CtConfigMenuBO;
import ext.plm.adminTool.configCenter.bo.CtMultiAttributeConfigQuery;
import ext.plm.adminTool.configCenter.bo.CtPropertyConfigBO;
import ext.plm.adminTool.configCenter.bo.CtStringDefinitionBO;
import ext.plm.common.CtResApiResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 配置中心controller组件
 *
 * @author liangzh
 */
@RestController
@RequestMapping("/adminTool/configCenter")
public class CtConfigCenterController {

    /**
     * 配置中心service组件
     */
    @Autowired
    private CtConfigCenterService ctConfigCenterService;

    /**
     * 查询配置中心菜单
     *
     * @return
     */
    @GetMapping(value = "/menu", produces = "application/json; charset=UTF-8")
    public CtResApiResult getConfigCenterMenu() {
        try {
            return CtResApiResult.successTree(ctConfigCenterService.getConfigCenterMenu());
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 新增配置中心菜单
     *
     * @param configMenu
     * @return
     */
    @PostMapping(value = "/menu", produces = "application/json; charset=UTF-8")
    public CtResApiResult createConfigCenterMenu(@RequestBody CtConfigMenuBO configMenu) {
        try {
            return CtResApiResult.success(ctConfigCenterService.createConfigCenterMenu(configMenu));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 更新配置中心菜单
     *
     * @param configMenu
     * @return
     */
    @PutMapping(value = "/menu", produces = "application/json; charset=UTF-8")
    public CtResApiResult updateConfigCenterMenu(@RequestBody CtConfigMenuBO configMenu) {
        try {
            ctConfigCenterService.updateConfigCenterMenu(configMenu);
            return CtResApiResult.success();
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 批量删除更新配置中心菜单
     *
     * @param idList
     * @return
     */
    @DeleteMapping(value = "/menu/batch", produces = "application/json; charset=UTF-8")
    public CtResApiResult batchDeleteConfigCenterMenu(@RequestBody List<String> idList) {
        try {
            ctConfigCenterService.batchDeleteConfigCenterMenu(idList);
            return CtResApiResult.success();
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }


    /**
     * 通过菜单Id查询property配置
     *
     * @param menuId
     * @return
     */
    @GetMapping(value = "/property", produces = "application/json; charset=UTF-8")
    public CtResApiResult getPropertyConfigByMenuId(@RequestParam("menuId") String menuId) {
        try {
            return CtResApiResult.success(ctConfigCenterService.getPropertyConfigByMenuId(menuId));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 新增property配置
     *
     * @param propertyConfig
     * @return
     */
    @PostMapping(value = "/property", produces = "application/json; charset=UTF-8")
    public CtResApiResult createPropertyConfig(@RequestBody CtPropertyConfigBO propertyConfig) {
        try {
            return CtResApiResult.success(ctConfigCenterService.createPropertyConfig(propertyConfig));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 更新property配置
     *
     * @param propertyConfig
     * @return
     */
    @PutMapping(value = "/property", produces = "application/json; charset=UTF-8")
    public CtResApiResult updatePropertyConfig(@RequestBody CtPropertyConfigBO propertyConfig) {
        try {
            ctConfigCenterService.updatePropertyConfig(propertyConfig);
            return CtResApiResult.success();
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 批量删除property配置
     *
     * @return
     */
    @DeleteMapping(value = "/property/batch", produces = "application/json; charset=UTF-8")
    public CtResApiResult batchDeletePropertyConfig(@RequestBody List<String> idList) {
        try {
            ctConfigCenterService.batchDeletePropertyConfig(idList);
            return CtResApiResult.success();
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }


    /**
     * 通过菜单Id查询多属性配置
     *
     * @param menuId
     * @return
     */
    @GetMapping(value = "/multiAttribute", produces = "application/json; charset=UTF-8")
    public CtResApiResult getMultiAttributeConfigByMenuId(@RequestParam("menuId") String menuId) {
        try {
            return CtResApiResult.success(ctConfigCenterService.getMultiAttributeConfigByMenuId(menuId));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 保存多属性配置
     *
     * @param multiAttributeConfigParam
     * @return
     */
    @PostMapping(value = "/multiAttribute", produces = "application/json; charset=UTF-8")
    public CtResApiResult saveMultiAttributeConfig(@RequestBody CtMultiAttributeConfigQuery multiAttributeConfigParam) {
        try {
            return CtResApiResult.success(ctConfigCenterService.saveMultiAttributeConfig(multiAttributeConfigParam));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 批量删除多属性配置
     *
     * @return
     */
    @DeleteMapping(value = "/multiAttribute/batch", produces = "application/json; charset=UTF-8")
    public CtResApiResult batchDeleteMultiAttributeConfig(@RequestBody List<String> idList) {
        try {
            ctConfigCenterService.batchDeleteMultiAttributeConfig(idList);
            return CtResApiResult.success();
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }


    /**
     * 通过菜单Id查询多属性配置key
     *
     * @param menuId
     * @return
     */
    @GetMapping(value = "/stringDefinition", produces = "application/json; charset=UTF-8")
    public CtResApiResult getStringDefinitionByMenuId(@RequestParam("menuId") String menuId) {
        try {
            return CtResApiResult.success(ctConfigCenterService.getStringDefinitionByMenuId(menuId));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 批量保存多属性配置key
     *
     * @param stringDefinitionList
     * @return
     */
    @PostMapping(value = "/stringDefinition/batch", produces = "application/json; charset=UTF-8")
    public CtResApiResult batchSaveStringDefinition(@RequestBody List<CtStringDefinitionBO> stringDefinitionList) {
        try {
            ctConfigCenterService.batchSaveStringDefinition(stringDefinitionList);
            return CtResApiResult.success();
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }
}
