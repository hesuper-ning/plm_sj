package ext.plm.adminTool.configCenter;

import ext.plm.adminTool.configCenter.bo.CtConfigMenuBO;
import ext.plm.adminTool.configCenter.bo.CtMultiAttributeConfigQuery;
import ext.plm.adminTool.configCenter.bo.CtPropertyConfigBO;
import ext.plm.adminTool.configCenter.bo.CtStringDefinitionBO;

import java.util.HashMap;
import java.util.List;

/**
 * 配置中心service组件接口
 * @author liangzh
 */
public interface CtConfigCenterService {

    /**
     * 查询配置中心菜单
     * @return
     */
    List<CtConfigMenuBO> getConfigCenterMenu() throws Exception;

    /**
     * 新增配置中心菜单
     * @param configMenu
     * @return
     */
    String createConfigCenterMenu(CtConfigMenuBO configMenu) throws Exception;

    /**
     * 更新配置中心菜单
     * @param configMenu
     */
    void updateConfigCenterMenu(CtConfigMenuBO configMenu);

    /**
     * 批量删除更新配置中心菜单
     * @param idList
     */
    void batchDeleteConfigCenterMenu(List<String> idList) throws Exception;

    /**
     * 通过菜单Id查询property配置
     * @param menuId
     * @return
     */
    List<CtPropertyConfigBO> getPropertyConfigByMenuId(String menuId);

    /**
     * 通过菜单内部名称查询property配置
     * @param menuInnerName
     * @return
     */
    List<CtPropertyConfigBO> getPropertyConfigByMenuInnerName(String menuInnerName);

    /**
     * 新增property配置
     * @param propertyConfig
     * @return
     */
    String createPropertyConfig(CtPropertyConfigBO propertyConfig) throws Exception;

    /**
     * 更新property配置
     * @param propertyConfig
     */
    void updatePropertyConfig(CtPropertyConfigBO propertyConfig) throws Exception;

    /**
     * 批量删除property配置
     * @param idList
     */
    void batchDeletePropertyConfig(List<String> idList);

    /**
     * 通过菜单Id查询多属性配置
     * @param menuId
     * @return
     */
    List<HashMap<String,String>> getMultiAttributeConfigByMenuId(String menuId);

    /**
     * 通过菜单内部名称查询多属性配置
     * @param menuInnerName
     * @return
     */
    List<HashMap<String,String>> getMultiAttributeConfigByMenuInnerName(String menuInnerName);

    /**
     * 新增多属性配置
     * @param multiAttributeConfigParam
     * @return
     */
    String saveMultiAttributeConfig(CtMultiAttributeConfigQuery multiAttributeConfigParam) throws Exception;

    /**
     * 批量删除多属性配置
     * @param idList
     */
    void batchDeleteMultiAttributeConfig(List<String> idList);

    /**
     * 通过菜单Id查询多属性配置key
     * @param menuId
     * @return
     */
    List<CtStringDefinitionBO> getStringDefinitionByMenuId(String menuId);

    /**
     * 批量保存多属性配置key
     * @param stringDefinitionList
     */
    void batchSaveStringDefinition(List<CtStringDefinitionBO> stringDefinitionList) throws Exception;


}
