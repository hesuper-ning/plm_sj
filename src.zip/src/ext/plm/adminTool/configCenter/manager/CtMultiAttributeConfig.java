package ext.plm.adminTool.configCenter.manager;

import ext.plm.adminTool.configCenter.CtConfigCenterService;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;

/**
 * 多属性配置
 * @author liangzh
 */
public class CtMultiAttributeConfig {

    private List<HashMap<String,String>> list;

    private HashMap<String,HashMap<String,String>> attributesMap;

    public CtMultiAttributeConfig(CtConfigCenterService ctConfigCenterService, String menuInnerName){
       this.list = ctConfigCenterService.getMultiAttributeConfigByMenuInnerName(menuInnerName);
    }

    public CtMultiAttributeConfig(CtConfigCenterService ctConfigCenterService, String menuInnerName,String key){
        this.list = ctConfigCenterService.getMultiAttributeConfigByMenuInnerName(menuInnerName);
        attributesMap=new HashMap<>();
        if (StringUtils.isNotBlank(key)){
            for (HashMap<String,String> hashMap:list){
                String val = hashMap.get(key);
                if (StringUtils.isBlank(val)){
                    continue;
                }
                attributesMap.put(val,hashMap);
            }
        }
    }

    public List<HashMap<String, String>> getList() {
        return list;
    }

    /**
     * 通过定义的key值获取属性
     * @param keyVal
     * @return
     */
    public HashMap<String,String> getAttributesByKeyVal(String keyVal){
        if (attributesMap!=null){
            return attributesMap.get(keyVal);
        }
        return null;
    }

    /**
     * 通过定义的key值，属性key获取配置值
     * @param keyVal
     * @param attrKey
     * @return
     */
    public String getAttributeValByKey(String keyVal,String attrKey){
        HashMap<String, String> attributes = getAttributesByKeyVal(keyVal);
        if (attributes!=null){
            return attributes.get(attrKey);
        }

        return null;
    }
}
