package ext.plm.adminTool.configCenter.manager;

import ext.plm.adminTool.configCenter.CtConfigCenterService;
import ext.plm.adminTool.configCenter.bo.CtPropertyConfigBO;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

/**
 * property配置
 * @author liangzh
 */
public class CtPropertyConfig {

    private HashMap<String, CtPropertyConfigBO> map=new HashMap<>();

    public CtPropertyConfig(CtConfigCenterService ctConfigCenterService,String menuInnerName){

        List<CtPropertyConfigBO> propertyConfigList =  ctConfigCenterService.getPropertyConfigByMenuInnerName(menuInnerName);
        for (CtPropertyConfigBO propertyConfig:propertyConfigList){
            map.put(propertyConfig.getPropertyKey(),propertyConfig);
        }
    }

    /**
     * 获取key的集合
     * @return
     */
    public Set<String> getKeySet(){
        return map.keySet();
    }

    /**
     * 获取单值
     * @param key
     * @return
     */
    public String getValue(String key){
        if (map.get(key)!=null){
            return map.get(key).getPropertyValue();
        }
        return null;
    }

    /**
     * 获取备注
     * @param key
     * @return
     */
    public String getRemark(String key){
        if (map.get(key)!=null){
            return map.get(key).getRemark();
        }
        return null;
    }

    /**
     * 获取多值集合
     * @param key
     * @return
     */
    public List<String> getValues(String key){
        CtPropertyConfigBO propertyConfig = map.get(key);
        if (propertyConfig !=null ){
            String splitChart = propertyConfig.getSplitChart();
            if (StringUtils.isNotBlank(splitChart) && StringUtils.isNotBlank(propertyConfig.getPropertyValue())){
                return Arrays.asList(propertyConfig.getPropertyValue().split(splitChart));
            }
        }
        return null;
    }
}
