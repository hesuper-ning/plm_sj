package ext.plm.adminTool.configCenter.manager;

import ext.plm.adminTool.configCenter.CtConfigCenterService;
import ext.plm.bean.CtBeanFactory;

/**
 * 配置中心管理
 * @author liangzh
 */
public class CtConfigCenterManager {

     private volatile static CtConfigCenterManager instance;

     public static CtConfigCenterManager getInstance(){
         if (instance==null){
             synchronized (CtConfigCenterManager.class){
                 if (instance==null){
                    instance=new CtConfigCenterManager();
                 }
             }
         }

         return instance;
     }

     private CtConfigCenterService ctConfigCenterService;

     private CtConfigCenterManager(){
         this.ctConfigCenterService= CtBeanFactory.newCtBeanFactory().getBean(CtConfigCenterService.class);
     }

    /**
     * 加载单值配置
     * @param menuInnerName
     * @return
     */
     public CtPropertyConfig loadProperty(String menuInnerName){
         return new CtPropertyConfig(ctConfigCenterService,menuInnerName);
     }

    /**
     * 加载多属性配置
     * @param menuInnerName
     * @return
     */
    public CtMultiAttributeConfig loadMultiAttribute(String menuInnerName){
         return new CtMultiAttributeConfig(ctConfigCenterService,menuInnerName);
    }

    /**
     * 加载多属性配置
     * @param menuInnerName
     * @param key
     * @return
     */
    public CtMultiAttributeConfig loadMultiAttribute(String menuInnerName,String key){
        return new CtMultiAttributeConfig(ctConfigCenterService,menuInnerName,key);
    }
}
