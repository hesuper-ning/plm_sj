package ext.plm.adminTool.configCenter.dao;

import ext.plm.adminTool.configCenter.bo.CtConfigMenuBO;
import ext.plm.adminTool.configCenter.mapper.CtConfigMenuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * 配置中心DAO组件
 *
 * @author liangzh
 */
@Repository
public class CtConfigMenuDAOImpl implements CtConfigMenuDAO {

    /**
     * 配置中心mapper组件
     */
    @Autowired
    private CtConfigMenuMapper ctConfigMenuMapper;

    /**
     * 查询所有配置中心菜单
     *
     * @return
     */
    @Override
    public List<CtConfigMenuBO> getAllConfigCenterMenu() {
        return ctConfigMenuMapper.selectList(null);
    }

    /**
     * 新增配置中心菜单
     *
     * @param configMenu
     * @return
     */
    @Override
    public String createConfigCenterMenu(CtConfigMenuBO configMenu) {
        ctConfigMenuMapper.insert(configMenu);
        return configMenu.getId();
    }

    /**
     * 更新配置中心菜单
     *
     * @param configMenu
     */
    @Override
    public void updateConfigCenterMenu(CtConfigMenuBO configMenu) {
        configMenu.setModifiedTime(new Date());
        ctConfigMenuMapper.updateById(configMenu);
    }

    /**
     * 批量删除更新配置中心菜单
     *
     * @param idList
     */
    @Override
    public void batchDeleteConfigCenterMenu(List<String> idList) {
        ctConfigMenuMapper.deleteBatchIds(idList);
    }

    /**
     * 通过内部名称查询配置中心菜单
     *
     * @param innerName
     * @return
     */
    @Override
    public CtConfigMenuBO getConfigCenterMenuByInnerName(String innerName) {
        CtConfigMenuBO menuBO = new CtConfigMenuBO();
        menuBO.setInnerName(innerName);
        return ctConfigMenuMapper.selectOne(menuBO);
    }
}
