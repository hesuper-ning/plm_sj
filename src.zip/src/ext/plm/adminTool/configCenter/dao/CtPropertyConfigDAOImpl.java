package ext.plm.adminTool.configCenter.dao;

import com.baomidou.mybatisplus.mapper.Condition;
import com.baomidou.mybatisplus.mapper.Wrapper;
import ext.plm.adminTool.configCenter.bo.CtPropertyConfigBO;
import ext.plm.adminTool.configCenter.mapper.CtPropertyConfigMapper;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * property配置DAO组件
 *
 * @author liangzh
 */
@Repository
public class CtPropertyConfigDAOImpl implements CtPropertyConfigDAO {

    /**
     * property配置mapper组件
     */
    @Resource
    private CtPropertyConfigMapper ctPropertyConfigMapper;

    /**
     * 通过菜单id 批量删除property配置
     *
     * @param menuIdList
     */
    @Override
    public void batchDeletePropertyConfigByMenuIds(List<String> menuIdList) {
        Wrapper<CtPropertyConfigBO> wrapper = Condition.wrapper();
        wrapper.in("configMenuId", menuIdList);
        ctPropertyConfigMapper.delete(wrapper);
    }

    /**
     * 通过菜单Id查询property配置
     *
     * @param menuId
     * @return
     */
    @Override
    public List<CtPropertyConfigBO> getPropertyConfigByMenuId(String menuId) {
        Wrapper<CtPropertyConfigBO> wrapper = Condition.wrapper();
        wrapper.eq("configMenuId", menuId);
        return ctPropertyConfigMapper.selectList(wrapper);
    }

    /**
     * 新增property配置
     *
     * @param propertyConfig
     * @return
     */
    @Override
    public String createPropertyConfig(CtPropertyConfigBO propertyConfig) {
        ctPropertyConfigMapper.insert(propertyConfig);
        return propertyConfig.getId();
    }

    /**
     * 更新property配置
     *
     * @param propertyConfig
     */
    @Override
    public void updatePropertyConfig(CtPropertyConfigBO propertyConfig) {
        propertyConfig.setModifiedTime(new Date());
        ctPropertyConfigMapper.updateById(propertyConfig);
    }

    /**
     * 批量删除property配置
     *
     * @param idList
     */
    @Override
    public void batchDeletePropertyConfig(List<String> idList) {
        ctPropertyConfigMapper.deleteBatchIds(idList);
    }

    /**
     * 通过key查询property配置
     *
     * @param propertyKey
     * @param configMenuId
     * @return
     */
    @Override
    public CtPropertyConfigBO getPropertyConfigByKey(String propertyKey, String configMenuId) {
        Wrapper<CtPropertyConfigBO> wrapper = Condition.wrapper();
        CtPropertyConfigBO configBO = new CtPropertyConfigBO();
        configBO.setConfigMenuId(configMenuId);
        configBO.setPropertyKey(propertyKey);
        return ctPropertyConfigMapper.selectOne(configBO);
    }

    /**
     * 通过菜单内部名称查询property配置
     *
     * @param menuInnerName
     * @return
     */
    @Override
    public List<CtPropertyConfigBO> getPropertyConfigByMenuInnerName(String menuInnerName) {
        return ctPropertyConfigMapper.getPropertyConfigByMenuInnerName(menuInnerName);
    }
}
