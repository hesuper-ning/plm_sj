package ext.plm.adminTool.configCenter.dao;

import ext.plm.adminTool.configCenter.bo.CtConfigMenuBO;

import java.util.List;

/**
 * 配置中心菜单DAO组件接口
 * @author liangzh
 */
public interface CtConfigMenuDAO {

    /**
     * 查询所有配置中心菜单
     * @return
     */
    List<CtConfigMenuBO> getAllConfigCenterMenu();

    /**
     * 新增配置中心菜单
     * @param configMenu
     * @return
     */
    String createConfigCenterMenu(CtConfigMenuBO configMenu);

    /**
     * 更新配置中心菜单
     * @param configMenu
     */
    void updateConfigCenterMenu(CtConfigMenuBO configMenu);

    /**
     * 批量删除更新配置中心菜单
     * @param idList
     */
    void batchDeleteConfigCenterMenu(List<String> idList);

    /**
     * 通过内部名称获取菜单
     * @param innerName
     * @return
     */
    CtConfigMenuBO getConfigCenterMenuByInnerName(String innerName);
}
