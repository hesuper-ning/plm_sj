package ext.plm.adminTool.configCenter.dao;

import ext.plm.adminTool.configCenter.bo.CtMultiAttributeConfigBO;
import ext.plm.adminTool.configCenter.bo.CtStringDefinitionBO;
import ext.plm.adminTool.configCenter.bo.CtStringValueBO;
import ext.plm.adminTool.configCenter.mapper.CtMultiAttributeConfigMapper;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * 多属性配置DAO组件
 * @author liangzh
 */
@Repository
public class CtMultiAttributeConfigDAOImpl implements CtMultiAttributeConfigDAO {

    /**
     * 多属性配置mapper组件
     */
    @Resource
    private CtMultiAttributeConfigMapper ctMultiAttributeConfigMapper;

    /**
     * 通过菜单ids查询多属性配置
     * @param menuIdList
     * @return
     */
    @Override
    public List<CtMultiAttributeConfigBO> getMultiAttributeByMenuIds(List<String> menuIdList) {
        if (CollectionUtils.isNotEmpty(menuIdList)){
            return ctMultiAttributeConfigMapper.getMultiAttributeByMenuIds(menuIdList);
        }
        return null;
    }

    /**
     * 通过菜单strDefIds 批量删除StringValue
     * @param strDefIds
     */
    @Override
    public void batchDeleteStringValueByObjectIds(List<String> strDefIds) {
        if (CollectionUtils.isNotEmpty(strDefIds)){
            ctMultiAttributeConfigMapper.batchDeleteStringValueByObjectIds(strDefIds);
        }
    }

    /**
     * 通过菜单ids删除StringDefinition
     * @param menuIdList
     */
    @Override
    public void batchDeleteStringDefinitionByMenuIds(List<String> menuIdList) {
        if (CollectionUtils.isNotEmpty(menuIdList)){
            ctMultiAttributeConfigMapper.batchDeleteStringDefinitionByMenuIds(menuIdList);
        }
    }

    /**
     * 通过菜单id查询多属性配置
     * @param menuId
     * @return
     */
    @Override
    public List<CtMultiAttributeConfigBO> getMultiAttributeByMenuId(String menuId) {
        return ctMultiAttributeConfigMapper.getMultiAttributeByMenuId(menuId);
    }

    /**
     * 通过菜单内部名称查询多属性配置
     * @param menuInnerName
     * @return
     */
    @Override
    public List<CtMultiAttributeConfigBO> getMultiAttributeByMenuInnerName(String menuInnerName) {
        return ctMultiAttributeConfigMapper.getMultiAttributeByMenuInnerName(menuInnerName);
    }

    /**
     * 通过对象id查询多属性配置
     * @param objectId
     * @return
     */
    @Override
    public List<HashMap<String, String>> getMultiAttributeByObjectId(String objectId) {
        return ctMultiAttributeConfigMapper.getMultiAttributeByObjectId(objectId);
    }

    /**
     * 新增多属性配置
     * @param multiAttributeConfig
     * @return
     */
    @Override
    public String createMultiAttributeConfig(CtMultiAttributeConfigBO multiAttributeConfig) {
        ctMultiAttributeConfigMapper.createMultiAttributeConfig(multiAttributeConfig);
        return multiAttributeConfig.getId();
    }

    /**
     * 新增多属性配置 属性
     * @param stringValue
     */
    @Override
    public void createStringValue(CtStringValueBO stringValue) {
        ctMultiAttributeConfigMapper.createStringValue(stringValue);
    }

    /**
     * 更新多属性配置
     * @param stringValue
     */
    @Override
    public void updateMultiAttributeConfig(CtStringValueBO stringValue) {
        stringValue.setModifiedTime(new Date());
        ctMultiAttributeConfigMapper.updateMultiAttributeConfig(stringValue);
    }

    /**
     * 批量删除多属性配置
     * @param objIds
     */
    @Override
    public void batchDeleteMultiAttributeConfigByIds(List<String> objIds) {
        if (CollectionUtils.isNotEmpty(objIds)){
            ctMultiAttributeConfigMapper.batchDeleteMultiAttributeConfigByIds(objIds);
        }
    }

    /**
     * 通过菜单Id查询多属性配置key
     * @param menuId
     * @return
     */
    @Override
    public List<CtStringDefinitionBO> getStringDefinitionByMenuId(String menuId) {
        return ctMultiAttributeConfigMapper.getStringDefinitionByMenuId(menuId);
    }

    /**
     * 通过内部名称获取StringDefinition
     * @param innerName
     * @return
     */
    @Override
    public CtStringDefinitionBO getStringDefinitionByInnerName(String innerName) {
        return ctMultiAttributeConfigMapper.getStringDefinitionByInnerName(innerName);
    }

    /**
     * 新增stringDefinition
     * @param stringDefinition
     */
    @Override
    public void createStringDefinition(CtStringDefinitionBO stringDefinition) {
        ctMultiAttributeConfigMapper.createStringDefinition(stringDefinition);
    }

    /**
     * 更新stringDefinition
     * @param stringDefinition
     */
    @Override
    public void updateStringDefinition(CtStringDefinitionBO stringDefinition) {
        stringDefinition.setModifiedTime(new Date());
        ctMultiAttributeConfigMapper.updateStringDefinition(stringDefinition);
    }

    /**
     * 通过StrDefIds批量删除stringValue
     * @param strDefIds
     */
    @Override
    public void batchDeleteStringValueByStrDefIds(List<String> strDefIds) {
        if (CollectionUtils.isNotEmpty(strDefIds)){
            ctMultiAttributeConfigMapper.batchDeleteStringValueByStrDefIds(strDefIds);
        }
    }

    /**
     * 通过id批量删除StringDefinition
     * @param idList
     */
    @Override
    public void batchDeleteStringDefinitionByIds(List<String> idList) {
        if (CollectionUtils.isNotEmpty(idList)){
            ctMultiAttributeConfigMapper.batchDeleteStringDefinitionByIds(idList);
        }
    }

    /**
     * 获取对象指定属性值
     * @param objectId
     * @param strDefinitionId
     * @return
     */
    @Override
    public String getStringValueByObjectIdAndDefId(String objectId, String strDefinitionId) {
        return ctMultiAttributeConfigMapper.getStringValueByObjectIdAndDefId(objectId,strDefinitionId);
    }
}
