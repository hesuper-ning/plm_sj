package ext.plm.adminTool.configCenter.dao;

import ext.plm.adminTool.configCenter.bo.CtPropertyConfigBO;

import java.util.List;

/**
 * property配置DAO组件接口
 * @author liangzh
 */
public interface CtPropertyConfigDAO {

    /**
     * 通过菜单id 批量删除property配置
     * @param menuIdList
     */
    void batchDeletePropertyConfigByMenuIds(List<String> menuIdList);

    /**
     * 通过菜单Id查询property配置
     * @param menuId
     * @return
     */
    List<CtPropertyConfigBO> getPropertyConfigByMenuId(String menuId);

    /**
     * 新增property配置
     * @param propertyConfig
     * @return
     */
    String createPropertyConfig(CtPropertyConfigBO propertyConfig);

    /**
     * 更新property配置
     * @param propertyConfig
     */
    void updatePropertyConfig(CtPropertyConfigBO propertyConfig);

    /**
     * 批量删除property配置
     * @param idList
     */
    void batchDeletePropertyConfig(List<String> idList);

    /**
     * 通过key查询property配置
     * @param propertyKey
     * @param configMenuId
     * @return
     */
    CtPropertyConfigBO getPropertyConfigByKey(String propertyKey, String configMenuId);

    /**
     * 通过菜单内部名称查询property配置
     * @param menuInnerName
     * @return
     */
    List<CtPropertyConfigBO> getPropertyConfigByMenuInnerName(String menuInnerName);
}
