package ext.plm.adminTool.configCenter.dao;

import ext.plm.adminTool.configCenter.bo.CtMultiAttributeConfigBO;
import ext.plm.adminTool.configCenter.bo.CtStringDefinitionBO;
import ext.plm.adminTool.configCenter.bo.CtStringValueBO;

import java.util.HashMap;
import java.util.List;

/**
 * 多属性配置DAO组件接口
 * @author liangzh
 */
public interface CtMultiAttributeConfigDAO {

    /**
     * 通过菜单ids查询多属性配置
     * @param menuIdList
     * @return
     */
    List<CtMultiAttributeConfigBO> getMultiAttributeByMenuIds(List<String> menuIdList);

    /**
     * 通过对象ids 批量删除StringValue
     * @param objectIdList
     */
    void batchDeleteStringValueByObjectIds(List<String> objectIdList);

    /**
     * 通过菜单ids删除StringDefinition
     * @param menuIdList
     * @return
     */
    void batchDeleteStringDefinitionByMenuIds(List<String> menuIdList);

    /**
     * 通过菜单id查询多属性配置
     * @param menuId
     * @return
     */
    List<CtMultiAttributeConfigBO> getMultiAttributeByMenuId(String menuId);

    /**
     * 通过菜单内部名称查询多属性配置
     * @param menuInnerName
     * @return
     */
    List<CtMultiAttributeConfigBO> getMultiAttributeByMenuInnerName(String menuInnerName);

    /**
     * 通过对象id查询多属性配置
     * @param objectId
     * @return
     */
    List<HashMap<String, String>> getMultiAttributeByObjectId(String objectId);

    /**
     * 新增多属性配置
     * @param multiAttributeConfig
     * @return
     */
    String createMultiAttributeConfig(CtMultiAttributeConfigBO multiAttributeConfig);

    /**
     * 新增多属性配置 属性
     * @param stringValue
     */
    void createStringValue(CtStringValueBO stringValue);

    /**
     * 更新多属性配置
     * @param stringValue
     */
    void updateMultiAttributeConfig(CtStringValueBO stringValue);

    /**
     * 通过ids批量删除多属性配置
     * @param objIds
     */
    void batchDeleteMultiAttributeConfigByIds(List<String> objIds);

    /**
     * 通过菜单Id查询多属性配置key
     * @param menuId
     * @return
     */
    List<CtStringDefinitionBO> getStringDefinitionByMenuId(String menuId);

    /**
     * 通过内部名称获取StringDefinition
     * @param innerName
     * @return
     */
    CtStringDefinitionBO getStringDefinitionByInnerName(String innerName);

    /**
     * 新增stringDefinition
     * @param stringDefinition
     */
    void createStringDefinition(CtStringDefinitionBO stringDefinition);

    /**
     * 更新stringDefinition
     * @param stringDefinition
     */
    void updateStringDefinition(CtStringDefinitionBO stringDefinition);

    /**
     * 通过StrDefIds批量删除stringValue
     * @param strDefIds
     */
    void batchDeleteStringValueByStrDefIds(List<String> strDefIds);

    /**
     * 通过id批量删除StringDefinition
     * @param idList
     */
    void batchDeleteStringDefinitionByIds(List<String> idList);

    /**
     * 获取对象指定属性值
     * @param objectId
     * @param strDefinitionId
     * @return
     */
    String getStringValueByObjectIdAndDefId(String objectId, String strDefinitionId);


}
