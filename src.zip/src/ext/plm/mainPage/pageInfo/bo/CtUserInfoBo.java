package ext.plm.mainPage.pageInfo.bo;

public class CtUserInfoBo {
	//用户账户
	private String userName;
	//用户名称
	private String userFullName;
	//用户部门
	private String userDepartment;
	//二级部门长
	private boolean isSecDepartmentHead;
	//IPMT组
	private boolean isIPMT;
	//项目经理组
	private boolean isProjectManager;
	//产品经理组
	private boolean isProductManager;
	//部门经理组
	private boolean isDepartmentManager;
	//研发中心
	private boolean isRDCenter;
	//PQA组
	private boolean isPQA;
	//DQA组
	private boolean isDQA;
	//管理员组
	private boolean isAdministrators;
	// 财务组
	private boolean isFinanceSection;
	// 制造代表组
	private boolean isMRG;
	// PE组
	private boolean isPE;
	// 采购代表组
	private boolean isPRG;
	// 销售中心组
	private boolean isSalesCenterGroup;
	//外协厂组
	private boolean isOutsourcingFactoryGroup;
	//研发管理组
	private boolean isRdManager;
	//采购组(成本)
	private boolean isPurchasingGroupCost;
	//认证组(成本)
	private boolean isCertificationGroupCost;
	//FAE主页面查询组
	private boolean isFaeGroup;
	//PQE主页面查询组
	private boolean isPqeGroup;
	//项目总监组
	private boolean isProInspector;
	//产品经理组(GTYC)
	private boolean isProductManager_GTYC;
	//产品部总经理组
	private boolean isProductDepManangerGroup;
	//GTYC项目部
	private boolean isGTYCProDep;
	//研发管理涉敏组(GHT)
	private boolean isDevSenGroup;
	//广通远驰认证组
	private boolean isGTYCCertificationGroup;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	public boolean isSecDepartmentHead() {
		return isSecDepartmentHead;
	}
	public void setSecDepartmentHead(boolean isSecDepartmentHead) {
		this.isSecDepartmentHead = isSecDepartmentHead;
	}
	public boolean isIPMT() {
		return isIPMT;
	}
	public void setIPMT(boolean isIPMT) {
		this.isIPMT = isIPMT;
	}
	public boolean isProjectManager() {
		return isProjectManager;
	}
	public void setProjectManager(boolean isProjectManager) {
		this.isProjectManager = isProjectManager;
	}
	public boolean isProductManager() {
		return isProductManager;
	}
	public void setProductManager(boolean isProductManager) {
		this.isProductManager = isProductManager;
	}
	public boolean isDepartmentManager() {
		return isDepartmentManager;
	}
	public void setDepartmentManager(boolean isDepartmentManager) {
		this.isDepartmentManager = isDepartmentManager;
	}
	public boolean isRDCenter() {
		return isRDCenter;
	}
	public void setRDCenter(boolean isRDCenter) {
		this.isRDCenter = isRDCenter;
	}
	public boolean isPQA() {
		return isPQA;
	}
	public void setPQA(boolean isPQA) {
		this.isPQA = isPQA;
	}
	public boolean isDQA() {
		return isDQA;
	}
	public void setDQA(boolean isDQA) {
		this.isDQA = isDQA;
	}
	public boolean isAdministrators() {
		return isAdministrators;
	}
	public void setAdministrators(boolean isAdministrators) {
		this.isAdministrators = isAdministrators;
	}
	public boolean isFinanceSection() {
		return isFinanceSection;
	}
	public void setFinanceSection(boolean isFinanceSection) {
		this.isFinanceSection = isFinanceSection;
	}
	public boolean isMRG() {
		return isMRG;
	}
	public void setMRG(boolean isMRG) {
		this.isMRG = isMRG;
	}
	public boolean isPE() {
		return isPE;
	}
	public void setPE(boolean isPE) {
		this.isPE = isPE;
	}
	public boolean isPRG() {
		return isPRG;
	}
	public void setPRG(boolean isPRG) {
		this.isPRG = isPRG;
	}
	public boolean isSalesCenterGroup() {
		return isSalesCenterGroup;
	}
	public void setSalesCenterGroup(boolean isSalesCenterGroup) {
		this.isSalesCenterGroup = isSalesCenterGroup;
	}
	public boolean isOutsourcingFactoryGroup() {
		return isOutsourcingFactoryGroup;
	}
	public void setOutsourcingFactoryGroup(boolean isOutsourcingFactoryGroup) {
		this.isOutsourcingFactoryGroup = isOutsourcingFactoryGroup;
	}
	public boolean isRdManager() {
		return isRdManager;
	}
	public void setRdManager(boolean isRdManager) {
		this.isRdManager = isRdManager;
	}
	public boolean isPurchasingGroupCost() {
		return isPurchasingGroupCost;
	}
	public void setPurchasingGroupCost(boolean isPurchasingGroupCost) {
		this.isPurchasingGroupCost = isPurchasingGroupCost;
	}
	public boolean isCertificationGroupCost() {
		return isCertificationGroupCost;
	}
	public void setCertificationGroupCost(boolean isCertificationGroupCost) {
		this.isCertificationGroupCost = isCertificationGroupCost;
	}
	public boolean isFaeGroup() {
		return isFaeGroup;
	}
	public void setFaeGroup(boolean isFaeGroup) {
		this.isFaeGroup = isFaeGroup;
	}
	public boolean isPqeGroup() {
		return isPqeGroup;
	}
	public void setPqeGroup(boolean isPqeGroup) {
		this.isPqeGroup = isPqeGroup;
	}
	public boolean isProInspector() {
		return isProInspector;
	}
	public void setProInspector(boolean isProInspector) {
		this.isProInspector = isProInspector;
	}
	public boolean isProductManager_GTYC() {
		return isProductManager_GTYC;
	}
	public void setProductManager_GTYC(boolean isProductManager_GTYC) {
		this.isProductManager_GTYC = isProductManager_GTYC;
	}
	public boolean isProductDepManangerGroup() {
		return isProductDepManangerGroup;
	}
	public void setProductDepManangerGroup(boolean isProductDepManangerGroup) {
		this.isProductDepManangerGroup = isProductDepManangerGroup;
	}
	public boolean isGTYCProDep() {
		return isGTYCProDep;
	}
	public void setGTYCProDep(boolean isGTYCProDep) {
		this.isGTYCProDep = isGTYCProDep;
	}
	public boolean isDevSenGroup() {
		return isDevSenGroup;
	}
	public void setDevSenGroup(boolean isDevSenGroup) {
		this.isDevSenGroup = isDevSenGroup;
	}
	public boolean isGTYCCertificationGroup() {
		return isGTYCCertificationGroup;
	}
	public void setGTYCCertificationGroup(boolean isGTYCCertificationGroup) {
		this.isGTYCCertificationGroup = isGTYCCertificationGroup;
	}

	public String getUserDepartment() {
		return userDepartment;
	}

	public void setUserDepartment(String userDepartment) {
		this.userDepartment = userDepartment;
	}

	@Override
	public String toString() {
		return "CtUserInfoBo [userName=" + userName + ", userFullName=" + userFullName + ", isSecDepartmentHead="
				+ isSecDepartmentHead + ", isIPMT=" + isIPMT + ", isProjectManager=" + isProjectManager
				+ ", isProductManager=" + isProductManager + ", isDepartmentManager=" + isDepartmentManager
				+ ", isRDCenter=" + isRDCenter + ", isPQA=" + isPQA + ", isDQA=" + isDQA + ", isAdministrators="
				+ isAdministrators + ", isFinanceSection=" + isFinanceSection + ", isMRG=" + isMRG + ", isPE=" + isPE
				+ ", isPRG=" + isPRG + ", isSalesCenterGroup=" + isSalesCenterGroup + ", isOutsourcingFactoryGroup="
				+ isOutsourcingFactoryGroup + ", isRdManager=" + isRdManager + ", isPurchasingGroupCost="
				+ isPurchasingGroupCost + ", isCertificationGroupCost=" + isCertificationGroupCost + ", isFaeGroup="
				+ isFaeGroup + ", isPqeGroup=" + isPqeGroup + ", isProInspector=" + isProInspector
				+ ", isProductManager_GTYC=" + isProductManager_GTYC + ", isProductDepManangerGroup="
				+ isProductDepManangerGroup + ", isGTYCProDep=" + isGTYCProDep + ", isDevSenGroup=" + isDevSenGroup
				+ ", isGTYCCertificationGroup=" + isGTYCCertificationGroup + "]";
	}

	
	
}
