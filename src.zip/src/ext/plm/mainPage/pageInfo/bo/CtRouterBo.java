package ext.plm.mainPage.pageInfo.bo;

import java.util.List;

public class CtRouterBo {
	
	//页面ID
	private String id;
		
	//父级页面ID
	private String parentId;
	
	//页面路径
	private String path;
	
	//组件名称
	private String name;
	
	//组件
	private String component;
	
	//meta
	private CtMetaBo meta;
	
	private List<CtRouterBo> children;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public CtMetaBo getMeta() {
		return meta;
	}

	public void setMeta(CtMetaBo meta) {
		this.meta = meta;
	}

	public List<CtRouterBo> getChildren() {
		return children;
	}

	public void setChildren(List<CtRouterBo> children) {
		this.children = children;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	@Override
	public String toString() {
		return "CtRouterBo [id=" + id + ", parentId=" + parentId + ", path=" + path + ", name=" + name + ", component="
				+ component + ", meta=" + meta + ", children=" + children + "]";
	}
	
	
}
