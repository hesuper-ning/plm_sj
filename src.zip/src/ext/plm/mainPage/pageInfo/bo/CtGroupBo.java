package ext.plm.mainPage.pageInfo.bo;

public class CtGroupBo {
	
	private String name;
	
	private String pageId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	@Override
	public String toString() {
		return "CtGroupBo [name=" + name + ", pageId=" + pageId + "]";
	}
	
	
}
