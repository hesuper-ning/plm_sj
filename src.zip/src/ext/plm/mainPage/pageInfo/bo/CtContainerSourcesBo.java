package ext.plm.mainPage.pageInfo.bo;

public class CtContainerSourcesBo {
	
	private String containerName;
	
	private String containerReference;

	private String containerId;

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getContainerReference() {
		return containerReference;
	}

	public void setContainerReference(String containerReference) {
		this.containerReference = containerReference;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}
}
