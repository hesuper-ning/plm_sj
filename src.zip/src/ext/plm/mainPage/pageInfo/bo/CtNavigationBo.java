package ext.plm.mainPage.pageInfo.bo;

import java.util.List;

public class CtNavigationBo {
	
	//页面名称
	private String title;
	
	//页面ID
	private String id;
	
	//父级页面ID
	private String parentId;
	
	//页面icon
	private String icon;
	
	//页面路由
	private String index;
	
	//顺序
	private int serialNumber;
	
	private List<CtNavigationBo> children;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public List<CtNavigationBo> getChildren() {
		return children;
	}

	public void setChildren(List<CtNavigationBo> children) {
		this.children = children;
	}

	public int getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	@Override
	public String toString() {
		return "CtNavigationBo [title=" + title + ", id=" + id + ", parentId=" + parentId + ", icon=" + icon
				+ ", index=" + index + ", serialNumber=" + serialNumber + ", children=" + children + "]";
	}
	

	
	
	
}
