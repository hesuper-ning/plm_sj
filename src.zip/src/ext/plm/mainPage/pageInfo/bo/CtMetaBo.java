package ext.plm.mainPage.pageInfo.bo;

public class CtMetaBo {
	//页面名称
	private String title;
	
	//页面icon
	private String icon;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	@Override
	public String toString() {
		return "CtMetaBo [title=" + title + ", icon=" + icon + "]";
	}
	
	
}
