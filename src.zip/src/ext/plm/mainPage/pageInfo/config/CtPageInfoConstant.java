package ext.plm.mainPage.pageInfo.config;

public class CtPageInfoConstant {
	
}
