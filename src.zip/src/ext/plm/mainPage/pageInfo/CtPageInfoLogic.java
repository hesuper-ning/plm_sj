package ext.plm.mainPage.pageInfo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import ext.plm.mainPage.pageInfo.bo.CtNavigationBo;
import ext.plm.mainPage.pageInfo.bo.CtRouterBo;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import wt.org.WTPrincipal;

public class CtPageInfoLogic {
	
	public void filterList(List<List<String>> list) throws Exception{
		//获取当前用户
		WTPrincipal user = CtUserUtil.getCurrentUser();
		
		Iterator<List<String>> iterator = list.iterator();
		while(iterator.hasNext()) {
			boolean havePermissions=false;
			List<String> next = iterator.next();
			String value = next.get(6);
			if(StringUtils.isBlank(value)) {
				continue;
			}
			
			String[] split = value.split("/");
			for(String groupName:split) {
				if(groupName.equals("执行层首页")) {
					boolean isSecDepartmentHead = CtUserUtil.isInGroup(user, "直线主管及二级部门长组");
					boolean isIPMT = CtUserUtil.isInGroup(user, "IPMT组");
					boolean isProjectManager = CtUserUtil.isInGroup(user, "项目经理组");
					boolean isProductManager = CtUserUtil.isInGroup(user, "产品经理组");
					
					if(!isSecDepartmentHead&&!isIPMT&&!isProjectManager&&!isProductManager) {
						havePermissions=true;
						break;
					}
				}else {
					if(CtUserUtil.isInGroup(user, groupName)) {
						havePermissions=true;
						break;
					}
				}
			}
			
			if(!havePermissions) {
				iterator.remove();
			}
		}
	}
	

	/**
	 * 将数据处理成树形结构
	 * 
	 * @param resultList
	 * @return
	 * @throws Exception 
	 */
	public List<CtNavigationBo> getNavigationTreeData(List<CtNavigationBo> resultList) throws Exception{
		
		// 获取根节点
		List<CtNavigationBo> rootList = new ArrayList<CtNavigationBo>();
		for (CtNavigationBo bo : resultList) {
			if (!CtFormatUtil.hasContent(bo.getParentId())) {
				rootList.add(bo);
			}
		}
		// 建立树形结构
		List<CtNavigationBo> treeList = new ArrayList<CtNavigationBo>();
		for (CtNavigationBo tree : rootList) {
			tree = buildNavigationChildNode(tree, resultList);
			treeList.add(tree);
		}
		return treeList;
	}
	
	/**
	  * 递归创建子节点
	 * @param tree
	 * @param resultList
	 * @return
	 * @throws Exception 
	 */
	private CtNavigationBo buildNavigationChildNode(CtNavigationBo tree, List<CtNavigationBo> resultList) throws Exception {
		List<CtNavigationBo> childList = new ArrayList<CtNavigationBo>();
		for (CtNavigationBo child : resultList) {
			if (tree.getId().equals(child.getParentId())) {
				childList.add(buildNavigationChildNode(child, resultList));
			}
		}
		tree.setChildren(childList);
		return tree;
	}
	
	
	/**
	 * 将数据处理成树形结构
	 * 
	 * @param resultList
	 * @return
	 * @throws Exception 
	 */
	public List<CtRouterBo> getRouterTreeData(List<CtRouterBo> resultList) throws Exception{
		
		// 获取根节点
		List<CtRouterBo> rootList = new ArrayList<CtRouterBo>();
		for (CtRouterBo bo : resultList) {
			if (!CtFormatUtil.hasContent(bo.getParentId())) {
				rootList.add(bo);
			}
		}
		// 建立树形结构
		List<CtRouterBo> treeList = new ArrayList<CtRouterBo>();
		for (CtRouterBo tree : rootList) {
			tree = buildRouterChildNode(tree, resultList);
			treeList.add(tree);
		}
		return treeList;
	}
	
	/**
	  * 递归创建子节点
	 * @param tree
	 * @param resultList
	 * @return
	 * @throws Exception 
	 */
	private CtRouterBo buildRouterChildNode(CtRouterBo tree, List<CtRouterBo> resultList) throws Exception {
		List<CtRouterBo> childList = new ArrayList<CtRouterBo>();
		for (CtRouterBo child : resultList) {
			if (tree.getId().equals(child.getParentId())) {
				childList.add(buildRouterChildNode(child, resultList));
			}
		}
		tree.setChildren(childList);
		return tree;
	}
}
