package ext.plm.mainPage.pageInfo;

import ext.plm.common.CtConstant;
import ext.plm.mainPage.pageInfo.bo.*;
import ext.plm.mainPage.pageInfo.mapper.CtPageInfoMapper;
import org.springframework.stereotype.Repository;
import wt.util.WTException;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class CtPageInfoQuery {

	@Resource
	private CtPageInfoMapper mapper;
	
	/**
	  *   查询导航栏信息
	 * @param pageId 
	 * @return
	 * @throws Exception
	 */
	public List<CtNavigationBo> getNavigation(String pageId) throws Exception {
		return mapper.getNavigation(pageId);
	}
	
	/**
	 * 查询路由
	 * @param pageId
	 * @return
	 * @throws Exception
	 */
	public List<CtRouterBo> getRouter(String pageId) throws Exception{
		return mapper.getRouter(pageId);
	}
	
	/**
	  *   查询组
	 * @return
	 * @throws Exception
	 */
	public List<CtGroupBo> getGroup() throws Exception {
		return mapper.getGroup();
	}
	
	/**
	  *   批量插入导航栏信息
	 * @param resultList
	 * @throws Exception
	 */
	public void addNavigation(List<CtNavigationBo> resultList) throws Exception {
		try {
			for(CtNavigationBo bo:resultList) {
				mapper.addNavigation(bo);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
		}
	}
	
	/**
	 * 通过ID查询导航栏
	 * @param id
	 */
	public CtNavigationBo getNavigationById(Integer id) throws Exception{
		return mapper.getNavigationById(id);
	}

	/**
	 * 查所有用户信息
	 */
	public List<CtUserInfoBo> getAllUserInfo() throws Exception{
		return mapper.getAllUserInfo();
	}

	/**
	 * 查所有用户信息
	 */
	public List<CtContainerSourcesBo> getContainerSources(String containerReference) throws Exception{
		return mapper.getContainerSources(containerReference);
	}

	/**
	 * 查所有部门
	 */
	public List<String> getDepartmentList() throws Exception{
		return mapper.getDepartmentList();
	}

}
