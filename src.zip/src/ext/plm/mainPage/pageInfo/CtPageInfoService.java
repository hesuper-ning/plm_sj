package ext.plm.mainPage.pageInfo;

import ext.plm.mainPage.pageInfo.bo.CtContainerSourcesBo;
import ext.plm.mainPage.pageInfo.bo.CtNavigationBo;
import ext.plm.mainPage.pageInfo.bo.CtRouterBo;
import ext.plm.mainPage.pageInfo.bo.CtUserInfoBo;

import java.util.List;

public interface CtPageInfoService {

	List<CtNavigationBo> getNavigation() throws Exception;
	
	List<CtRouterBo> getRouter() throws Exception;

	CtUserInfoBo getUserInfo() throws Exception;

	List<CtUserInfoBo> getAllUserInfo() throws Exception;

	List<CtContainerSourcesBo> getContainerSources(String containerReference) throws Exception;

	List<String> getDepartmentList() throws Exception;
}
