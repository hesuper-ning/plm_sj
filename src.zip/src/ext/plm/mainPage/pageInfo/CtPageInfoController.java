package ext.plm.mainPage.pageInfo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtResApiResult;
import ext.plm.mainPage.pageInfo.bo.CtContainerSourcesBo;
import ext.plm.mainPage.pageInfo.bo.CtNavigationBo;
import ext.plm.mainPage.pageInfo.bo.CtRouterBo;
import ext.plm.mainPage.pageInfo.bo.CtUserInfoBo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.List;

@RestController
@RequestMapping(value="mainPage/pageInfo")
public class CtPageInfoController {

	private final CtPageInfoService service;

	@Autowired
	public CtPageInfoController(CtPageInfoService service) {
		this.service = service;
	}

	/**
	 * 获取导航栏
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/getNavigation", method = RequestMethod.GET)
	public void getNavigation(HttpServletRequest request, HttpServletResponse response) throws Exception{
		JSONObject result = new JSONObject();
		try {
			List<CtNavigationBo> resultList = service.getNavigation();
			result.put("resultList", JSONArray.parse(JSON.toJSONString(resultList)));
			result.put("success", true);
			result.put("msg", "查询成功！");
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "查询导航栏信息失败！");
		}

		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.write(result.toString());
	}
	
	/**
	 * 获取路由
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/getRouter", method = RequestMethod.GET)
	public void getRouter(HttpServletRequest request, HttpServletResponse response) throws Exception{
		JSONObject result = new JSONObject();
		try {
			List<CtRouterBo> resultList = service.getRouter();
			
			result.put("resultList", JSONArray.parse(JSON.toJSONString(resultList)));
			result.put("success", true);
			result.put("msg", "查询成功！");
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "查询导航栏信息失败！");
		}

		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.write(result.toString());
	}
	
	
	/**
	 * 获取用户信息
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/getUserInfo", method = RequestMethod.GET)
	public void getUserInfo(HttpServletRequest request, HttpServletResponse response) throws Exception{
		JSONObject result = new JSONObject();
		try {
			CtUserInfoBo bo = service.getUserInfo();
			
			result.put("result", JSON.toJSONString(bo));
			result.put("success", true);
			result.put("msg", "查询成功！");
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "查询用户信息失败！");
		}

		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.write(result.toString());
	}

	/**
	 * 获取所有用户信息
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/getAllUserInfo", method = RequestMethod.GET)
	public CtResApiResult getAllUserInfo(HttpServletRequest request, HttpServletResponse response) throws Exception{
		try {
			List<CtUserInfoBo> boList = service.getAllUserInfo();
			return CtResApiResult.success(boList);
		} catch (Exception e) {
			e.printStackTrace();
			return CtResApiResult.fail("查询用户信息失败！");
		}
	}

	/**
	 * 获取二级目录
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/getContainerSources", method = RequestMethod.GET)
	public CtResApiResult getContainerSources(HttpServletRequest request, HttpServletResponse response) throws Exception{
		try {
			String containerReference = request.getParameter("containerReference");
			List<CtContainerSourcesBo> boList = service.getContainerSources(containerReference);
			return CtResApiResult.success(boList);
		} catch (Exception e) {
			e.printStackTrace();
			return CtResApiResult.fail("查询二级目录信息失败！");
		}
	}

	/**
	 * 获取部门
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/getDepartmentList", method = RequestMethod.GET)
	public CtResApiResult getDepartmentList(HttpServletRequest request, HttpServletResponse response) throws Exception{
		try {
			List<String> list = service.getDepartmentList();
			return CtResApiResult.success(list);
		} catch (Exception e) {
			e.printStackTrace();
			return CtResApiResult.fail("查询部门信息失败！");
		}
	}
}
