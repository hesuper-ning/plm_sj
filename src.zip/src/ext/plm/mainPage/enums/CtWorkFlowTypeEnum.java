package ext.plm.mainPage.enums;

import ext.plm.util.CtFormatUtil;

/**
 * 流程类型 枚举对象
 */
public enum CtWorkFlowTypeEnum {
    Document("wt.doc.WTDocument,wt.epm.EPMDocument", "文档"),
    WTPart("wt.part.WTPart", "物料"),
    ChangeActivity("wt.change2.WTChangeActivity2", "更改任务"),
    ChangeIssue("wt.change2.WTChangeIssue", "问题报告"),
    ChangeOrder("wt.change2.WTChangeOrder2", "更改通告"),
    ChangeRequest("wt.change2.WTChangeRequest2", "更改请求"),
    PromotionNotice("wt.maturity.PromotionNotice", "升级请求"),
    WTChangeReview("wt.change2.WTChangeReview", "审阅");

    CtWorkFlowTypeEnum(String key, String description) {
        this.key = key;
        this.description = description;
    }

    private String key;
    private String description;

    public String getKey() {
        return key;
    }

    public String getDescription() {
        return description;
    }

    public static String getDescription(String objectReference) {
        if (!CtFormatUtil.hasContent(objectReference)) {
            return null;
        }
        for (CtWorkFlowTypeEnum ctWorkFlowTypeEnum : CtWorkFlowTypeEnum.values()) {
            String[] typeList = ctWorkFlowTypeEnum.getKey().split(",");
            for (String type : typeList) {
                if (objectReference.contains(type)) {
                    return ctWorkFlowTypeEnum.getDescription();
                }
            }
        }
        return objectReference;
    }

    public static String getKey(String enumValue){
        for (CtWorkFlowTypeEnum ctWorkFlowTypeEnum : CtWorkFlowTypeEnum.values()) {
            if (ctWorkFlowTypeEnum.name().equals(enumValue)) {
                return ctWorkFlowTypeEnum.getKey();
            }
        }
        return enumValue;
    }
}
