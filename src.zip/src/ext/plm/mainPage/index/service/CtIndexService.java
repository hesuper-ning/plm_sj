package ext.plm.mainPage.index.service;

import ext.plm.mainPage.bo.CtStatisticsBo;
import wt.util.WTException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface CtIndexService {

    /**
     * 统计项目偏差TOP5数据
     * @param pdt 产品线
     * @return 返回装载好的报表数据
     * @Exception
     **/
    Map<String, Object> statisticsTopProjectDeviationRate(String pdt,String mark) throws Exception;

    /**
     * 统计项目类型数据
     * @param startDate 开始时间
     * @param endDate 结束时间
     * @return 返回装载好的报表数据
     * @Exception
     **/
    Map<String, Object> statisticsProjectType(String startDate,String endDate,String mark) throws Exception;

    /**
     * 统计项目状态数据
     * @param pdt 产品线
     * @param startDate 开始时间
     * @param endDate 结束时间
     * @return 返回装载好的报表数据
     * @Exception
     **/
    List<CtStatisticsBo> loadProjectReportChart(String pdt,String startDate,String endDate,String mark) throws Exception;

    /**
     * 统计问题类型报表数据
     * @param domain 领域
     * @param pdt 产品线
     * @return 返回装载好的报表数据
     * @Exception
     **/
    Map<String, Object> statisticsProblemType(String domain, String pdt,String mark) throws Exception;

    /**
     * 统计风险类型报表数据
     * @param domain 领域
     * @param pdt 产品线
     * @return 返回装载好的报表数据
     * @Exception
     **/
    Map<String, Object> statisticsRiskType(String domain, String pdt,String mark) throws Exception;

    /**
     * 人力工时投入表
     * @param projectStatus
     * @param mark
     * @return
     * @Exception
     **/
    Map<String, Object> getProjectHoursAll(String projectStatus,String mark) throws Exception;

}
