package ext.plm.mainPage.index.service;

import ext.plm.mainPage.bo.CtStatisticsBo;
import ext.plm.mainPage.index.CtIndexLogic;
import ext.plm.mainPage.index.mapper.CtIndexMapper;
import ext.plm.mainPage.problemManager.CtProblemLogic;
import ext.plm.mainPage.projectManage.CtProjectManageQuery;
import ext.plm.mainPage.riskManage.CtRiskmentLogic;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CtIndexServiceImpl implements CtIndexService {
    @Autowired
    private CtIndexLogic ctIndexLogic;
    @Autowired
    private CtRiskmentLogic ctRiskmentLogic;
    @Autowired
    private CtProblemLogic ctProblemLogic;
    @Autowired
    private CtProjectManageQuery ctProjectManageQuery;
    @Autowired
    private CtIndexMapper ctIndexMapper;


    @Override
    public Map<String, Object> statisticsTopProjectDeviationRate(String pdt,String mark) throws Exception {
        List<String> projectNumberList = new ArrayList<>();
        if(StringUtils.isNotEmpty(mark) && "Manager".equals(mark)){
            projectNumberList = ctIndexLogic.getCurrentUserProjectTameNumberAll(pdt);
        }else{
            projectNumberList = ctIndexLogic.getPdtToProjectTamNumberAll(pdt);
        }
        LinkedList<CtStatisticsBo> linkedList = ctIndexMapper.statisticsTopProjectDeviationRate(projectNumberList);
        // 横轴数据
        String[] proXAxisData = new String[linkedList.size()];
        // 纵轴数据
        String[] proYAxisData = new String[linkedList.size()];
        // 纵轴数据的天数数据
        String[] proDiffDayData = new String[linkedList.size()];
        int i=0;
        for(CtStatisticsBo bo : linkedList){
            proYAxisData[i]=bo.getDateStr(); // 比例
            proDiffDayData[i]=bo.getValueStr(); // 天数
            proXAxisData[i]=bo.getName(); // 项目名称
            i ++;
        }
        Map<String, Object> resultMap = new HashMap<>(3);
        resultMap.put("proXAxisData", proXAxisData);
        resultMap.put("proYAxisData", proYAxisData);
        resultMap.put("proDiffDayData", proDiffDayData);
        return resultMap;
    }

    @Override
    public Map<String, Object> statisticsProjectType(String startDate,String endDate,String mark) throws Exception {
        List<String> projectNumberList = new ArrayList<>();
        if(StringUtils.isNotEmpty(mark) && "Manager".equals(mark)){
            projectNumberList = ctIndexLogic.getCurrentUserProjectTameNumberAll();
        }
        LinkedList<CtStatisticsBo> linkedList = ctIndexMapper.getProjectTypeAll(projectNumberList,startDate,endDate);
//        WHEN sv.VALUE2 LIKE '%基础%' THEN	'V'
//        WHEN sv.VALUE2 LIKE '%增强%' THEN	'R'
//        WHEN sv.VALUE2 LIKE '%微小%' THEN	'C'
//        WHEN sv.VALUE2 LIKE '%维护%' THEN	'W'
        Long V = 0l;
        Long R = 0l;
        Long C = 0l;
        Long W = 0l;
        Long T = 0l;
        LinkedList<String> peoductLine = new LinkedList<>();
        peoductLine.add("总计");
        for(CtStatisticsBo bo : linkedList){
            String num = bo.getValueStr(); // 数量
            String projectType = bo.getName(); // 项目类型
            if("V".equalsIgnoreCase(projectType)){
                V += Long.parseLong(num);
            }else if("R".equalsIgnoreCase(projectType)){
                R += Long.parseLong(num);
            }else if("C".equalsIgnoreCase(projectType)){
                C += Long.parseLong(num);
            }else if("W".equalsIgnoreCase(projectType)){
                W += Long.parseLong(num);
            }else if("T".equalsIgnoreCase(projectType)){
                T += Long.parseLong(num);
            }
            if(!peoductLine.contains(bo.getDateStr())){
                peoductLine.add(bo.getDateStr()); // 产品线
            }
        }
        System.out.println("peoductLine:"+peoductLine);
        // 横轴数据
        String[] proXAxisData = peoductLine.toArray(new String[peoductLine.size()]); // 产品线
        // 纵轴数据
        String[] VYAxisData = new String[peoductLine.size()];
        // 纵轴数据
        String[] RYAxisData = new String[peoductLine.size()];
        // 纵轴数据
        String[] CYAxisData = new String[peoductLine.size()];
        // 纵轴数据
        String[] WYAxisData = new String[peoductLine.size()];
        // 纵轴数据
        String[] TYAxisData = new String[peoductLine.size()];
        // 初始化
        VYAxisData[0] = String.valueOf(V);
        RYAxisData[0] = String.valueOf(R);
        CYAxisData[0] = String.valueOf(C);
        WYAxisData[0] = String.valueOf(W);
        TYAxisData[0] = String.valueOf(T);
        for(int x=1;x<peoductLine.size();x++){
            VYAxisData[x] = "0";
            RYAxisData[x] = "0";
            CYAxisData[x] = "0";
            WYAxisData[x] = "0";
            TYAxisData[x] = "0";
        }
        System.out.println("proXAxisData:"+proXAxisData.length);
        System.out.println("VYAxisData:"+VYAxisData.length);
        System.out.println("RYAxisData:"+RYAxisData.length);
        System.out.println("CYAxisData:"+CYAxisData.length);
        System.out.println("WYAxisData:"+WYAxisData.length);
        System.out.println("WYAxisData:"+TYAxisData.length);
        int i=0;
        for(String line:peoductLine){
            for(CtStatisticsBo bo : linkedList){
                String num = bo.getValueStr(); // 数量
                String projectType = bo.getName(); // 项目类型
                String proLine = bo.getDateStr(); // 产品线
                if(line.equalsIgnoreCase(proLine)){
                    if("V".equalsIgnoreCase(projectType)){
                        VYAxisData[i] = num;
                    }else if("R".equalsIgnoreCase(projectType)){
                        RYAxisData[i] = num;
                    }else if("C".equalsIgnoreCase(projectType)){
                        CYAxisData[i] = num;
                    }else if("W".equalsIgnoreCase(projectType)){
                        WYAxisData[i] = num;
                    }else if("T".equalsIgnoreCase(projectType)){
                        TYAxisData[i] = num;
                    }
                }
            }
            i ++;
        }
        Map<String, Object> resultMap = new HashMap<>(5);
        resultMap.put("proXAxisData", proXAxisData);
        resultMap.put("VYAxisData", VYAxisData);
        resultMap.put("RYAxisData", RYAxisData);
        resultMap.put("CYAxisData", CYAxisData);
        resultMap.put("WYAxisData", WYAxisData);
        resultMap.put("TYAxisData", TYAxisData);
        return resultMap;
    }

    @Override
    public List<CtStatisticsBo> loadProjectReportChart(String pdt,String startDate,String endDate,String mark) throws Exception {
        List<String> projectNumberList = new ArrayList<>();
        HashMap<String, Object> paramsMap = new HashMap<>();
        if(StringUtils.isNotEmpty(mark) && "Manager".equals(mark)){
            projectNumberList = ctIndexLogic.getCurrentUserProjectTameNumberAll(pdt);
        }else{
            projectNumberList = ctIndexLogic.getPdtToProjectTamNumberAll(pdt);
        }
        System.out.println("loadProjectReportChart:"+projectNumberList);
        paramsMap.put("projectNumberList",projectNumberList);
        paramsMap.put("productLine",pdt);
        paramsMap.put("startDate", startDate);
        paramsMap.put("endDate", endDate);
        return ctProjectManageQuery.getStatusStatistics(paramsMap);
    }

    @Override
    public Map<String, Object> statisticsProblemType(String domain,String pdt,String mark) throws Exception {
        List<String> projectNumberList = new ArrayList<>();
        if(StringUtils.isNotEmpty(mark) && "Manager".equals(mark)){
            projectNumberList = ctIndexLogic.getCurrentUserProjectTameNumberAll(pdt);
        }else{
            projectNumberList = ctIndexLogic.getPdtToProjectTamNumberAll(pdt);
        }
        return ctProblemLogic.statisticsProblemType(projectNumberList,domain);
    }

    @Override
    public Map<String, Object> statisticsRiskType(String domain,String pdt,String mark) throws Exception {
        List<String> projectNumberList = new ArrayList<>();
        if(StringUtils.isNotEmpty(mark) && "Manager".equals(mark)){
            projectNumberList = ctIndexLogic.getCurrentUserProjectTameNumberAll(pdt);
        }else{
            projectNumberList = ctIndexLogic.getPdtToProjectTamNumberAll(pdt);
        }
        return ctRiskmentLogic.statisticsRiskType(projectNumberList,domain);
    }

    @Override
    public Map<String, Object> getProjectHoursAll(String projectStatus,String mark) throws Exception {
        List<String> projectNumberList = new ArrayList<>();
        if(StringUtils.isNotEmpty(mark) && "Manager".equals(mark)){
            projectNumberList = ctIndexLogic.getCurrentUserProjectTameNumberAll();
        }
        LinkedList<CtStatisticsBo> linkedList = ctIndexMapper.getProjectHoursAll(projectNumberList,projectStatus);
        // 横轴数据
        String[] proXAxisData = new String[linkedList.size()];
        // 纵轴数据
        String[] proYAxisData = new String[linkedList.size()];
        int i=0;
        for(CtStatisticsBo bo : linkedList){
            proXAxisData[i]=bo.getName();
            proYAxisData[i]=bo.getValueStr();
            i ++;
        }
        Map<String, Object> resultMap = new HashMap<>(3);
        resultMap.put("proXAxisData", proXAxisData);
        resultMap.put("proYAxisData", proYAxisData);
        return resultMap;
    }
}
