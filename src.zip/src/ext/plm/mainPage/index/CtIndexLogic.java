package ext.plm.mainPage.index;

import ext.plm.common.CtConstant;
import ext.plm.mainPage.bo.CtProjectBo;
import ext.plm.mainPage.bo.CtStatisticsBo;
import ext.plm.mainPage.change.CtChangeService;
import ext.plm.mainPage.change.bo.CtChangeMilestoneBo;
import ext.plm.mainPage.change.bo.CtEngineeringChangeBo;
import ext.plm.mainPage.change.bo.CtPlanChangeBo;
import ext.plm.mainPage.change.bo.CtRequireChangeBo;
import ext.plm.mainPage.change.mapper.CtChangeMapper;
import ext.plm.mainPage.index.mapper.CtIndexMapper;
import ext.plm.mainPage.manHourReport.bo.ProductLineManHoursByMonthResult;
import ext.plm.mainPage.tool.project.CtProjectLogic;
import ext.plm.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.org.WTUser;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.util.WTException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class CtIndexLogic {

	@Autowired
	private CtIndexMapper ctIndexMapper;

	public boolean isAdmin(String userName) throws Exception {
		if(StringUtils.isNotEmpty(userName)){
			WTUser currentUser = CtUserUtil.getUserByAccountName(userName);
			if(currentUser == null){
				return false;
			}
			boolean isInAdminGroup = CtUserUtil.isInGroup(currentUser, "Administrators");
			if(isInAdminGroup){
				return true;
			}
			boolean isInAdminGroup1 = CtUserUtil.isInGroup(currentUser, "门户管理者查看组");
			if(isInAdminGroup1){
				return true;
			}
		}
		return false;
	}

	/**
	 * 根据产品线获取项目编码
	 * @return 无值时返回 NOANDERROR 让SQL无返回值
	 * @throws Exception
	 */
	public List<String> getTeamUserProjectNumberAll() throws Exception {
		List<String> listProjectnumber = new ArrayList<>();
		String userName = CtUserUtil.getCurrentUserAccountName(); // 工号
		if(isAdmin(userName)){
			return listProjectnumber; // 返回空代表查询所有
		}
		if(StringUtils.isNotEmpty(userName)) {
			LinkedList<CtProjectBo>  listBo= ctIndexMapper.getProjectTeamAll(userName,null);
			for (CtProjectBo bo : listBo){
				listProjectnumber.add(bo.getProjectNumber());
			}
			if(CollectionUtils.isEmpty(listProjectnumber)){
				listProjectnumber.add("NOANDERROR");
			}
		}
		return listProjectnumber;
	}

	/**
	 * 获取项目编码 项目团队除去访客的所有
	 * @return 无值时返回 NOANDERROR 让SQL无返回值
	 * @throws Exception
	 */
	public List<String> getCurrentUserProjectTameNumberAll() throws Exception {
		List<String> listProjectnumber = new ArrayList<>();
		String userName = CtUserUtil.getCurrentUserAccountName(); // 工号
		if(isAdmin(userName)){
			return listProjectnumber; // 返回空代表查询所有
		}
		if(StringUtils.isNotEmpty(userName)) {
//			LinkedList<CtProjectBo>  listBo= ctIndexMapper.getProjectAll(userName,null);
//			for (CtProjectBo bo : listBo){
//					listProjectnumber.add(bo.getProjectNumber());
//			}
			HashMap<String, String> projectNos = getProjectList(null);
			if(projectNos != null){
				System.out.println("all qrproject："+projectNos.size());
				for (String projectNumber : projectNos.keySet()){
					 listProjectnumber.add(projectNumber);
				}
			}
			// TODO 20250310
//			String userName2 = CtUserUtil.getCurrentUserDisplayName(); // 显示名称
//			LinkedList<CtProjectBo>  listBo2= ctIndexMapper.getPdtToProjectAll2(userName2,null);
//			for (CtProjectBo bo : listBo2){
//				listProjectnumber.add(bo.getProjectNumber());
//			}
			if(CollectionUtils.isEmpty(listProjectnumber)){
				listProjectnumber.add("NOANDERROR");
			}
		}
		return listProjectnumber;
	}

	/**
	 * 获取项目编码  项目团队除去访客的所有
	 * @return 无值时返回 NOANDERROR 让SQL无返回值
	 * @throws Exception
	 */
	public List<String> getCurrentUserProjectTameNumberAll(String productLine) throws Exception {
		List<String> listProjectnumber = new ArrayList<>();
		String userName = CtUserUtil.getCurrentUserAccountName(); // 工号
		if(StringUtils.isNotEmpty(userName)) {
//			LinkedList<CtProjectBo>  listBo= ctIndexMapper.getProjectAll(userName,productLine);
//			for (CtProjectBo bo : listBo){
//				listProjectnumber.add(bo.getProjectNumber());
//			}
			HashMap<String, String> projectNos = getProjectList(productLine);
			if(projectNos != null){
				System.out.println("pdt qrproject："+projectNos.size());
				for (String projectNumber : projectNos.keySet()){
					listProjectnumber.add(projectNumber);
				}
			}
			// TODO 20250310
//			String userName2 = CtUserUtil.getCurrentUserDisplayName(); // 显示名称
//			LinkedList<CtProjectBo>  listBo2= ctIndexMapper.getPdtToProjectAll2(userName2,productLine);
//			for (CtProjectBo bo : listBo2){
//				listProjectnumber.add(bo.getProjectNumber());
//			}
			if(CollectionUtils.isEmpty(listProjectnumber)){
				listProjectnumber.add("NOANDERROR");
			}
		}
		return listProjectnumber;
	}
	/**
	 * 根据产品线获取项目编码
	 * @return 无值时返回 NOANDERROR 让SQL无返回值
	 * @throws Exception
	 */
	public List<String> getPdtToProjectTamNumberAll(String productLine) throws Exception {
		List<String> listProjectnumber = new ArrayList<>();
		if(StringUtils.isNotEmpty(productLine)) {
			LinkedList<CtProjectBo>  listBo= ctIndexMapper.getPdtToProjectAll(productLine);
			for (CtProjectBo bo : listBo){
				listProjectnumber.add(bo.getProjectNumber());
			}
			if(CollectionUtils.isEmpty(listProjectnumber)){
				listProjectnumber.add("NOANDERROR");
			}
		}
		return listProjectnumber;
	}
	/**
	 * 查询项目
	 *
	 * @return List<HashMap<String,String>> {项目编号:产品线}
	 * @throws Exception
	 */
	public HashMap<String, String> getProjectList(String pdt) throws Exception {
		HashMap<String, String> result = new HashMap<String, String>();
		//用高级查询可以限定用户的权限，只查到自己有权限查看的项目
		QuerySpec qs;
		try {
			qs = new QuerySpec(Project2.class);
			//inforeport  com.ptc.projectmanagement.plan.PlanActivity  inforeport wt.projmgmt.admin.Project2
			QueryResult qr = PersistenceHelper.manager.find(qs);
			while(qr.hasMoreElements()) {
				Project2 prj = (Project2)qr.nextElement();
				IBAUtil ibaUtil = new IBAUtil(prj);
				String projectType = ibaUtil.getIBAValue("Ct_ProjectType");
				if(StringUtils.isNotEmpty(projectType) && (projectType.startsWith("产品开发项目") || projectType.startsWith("技术开发项目") || projectType.startsWith("预研项目"))){
					String productLine = ibaUtil.getIBAValue("ct_productLine");
					if(StringUtils.isNotEmpty(pdt)){
						if(pdt.equalsIgnoreCase(productLine)){
							result.put(prj.getProjectNumber(), productLine);
						}
					}else{
						result.put(prj.getProjectNumber(), productLine);
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
			throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
		}
		return result;
	}
}
