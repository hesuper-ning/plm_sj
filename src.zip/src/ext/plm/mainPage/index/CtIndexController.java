package ext.plm.mainPage.index;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.mainPage.bo.CtStatisticsBo;
import ext.plm.mainPage.index.service.CtIndexService;
import ext.plm.util.CtFormatUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value="/mainPage/index",produces = "application/json")
public class CtIndexController {

    @Autowired
    private CtIndexService ctIndexService;

    /**
     * 统计项目偏差率TOP5 -- 项目经理页
     */
    @GetMapping("/statisticsTopProjectDeviationRate")
    public void statisticsTopProjectDeviationRate(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            String mark = request.getParameter("mark");
            String pdt = request.getParameter("pdt");
            Map<String, Object> map = ctIndexService.statisticsTopProjectDeviationRate(pdt,mark);
            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 项目类型统计 -- 首页
     */
    @GetMapping("/statisticsProjectType")
    public void statisticsProjectType(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            String mark = request.getParameter("mark");
            String startDate = request.getParameter("startDate");
            String endDate = request.getParameter("endDate");

            Map<String, Object> map =  ctIndexService.statisticsProjectType(startDate,endDate,mark);
            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "项目等级统计失败：\r\n" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 统计项目状态 -- 主页公共
     * 项目群报表 中图表加载
     */
    @GetMapping("/loadProjectReportChart")
    public void loadProjectReportChart(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONObject result = new JSONObject();
        try {
            String mark = request.getParameter("mark");
            String pdt = request.getParameter("pdt");
            String startDate = request.getParameter("startDate");
            String endDate = request.getParameter("endDate");
            List<CtStatisticsBo> resultList = ctIndexService.loadProjectReportChart(pdt, startDate,endDate,mark);
            result.put("resultList", JSONArray.parse(JSON.toJSONString(resultList)));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询失败：\r\n" + e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    /**
     * 问题统计 -- 主页公共
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/statisticsProblemType", method = { RequestMethod.GET, RequestMethod.POST })
    public void statisticsProblemType(HttpServletRequest request, HttpServletResponse response) throws Exception{
        JSONObject result = new JSONObject();
        try {
            String mark = request.getParameter("mark");
            String pdt = request.getParameter("pdt");
            String domain = request.getParameter("domain");
            Map<String, Object> map = ctIndexService.statisticsProblemType(domain,pdt,mark);
            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询风险类型报表数据失败：\r\n"+e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    /**
     * 风险统计 -- 主页公共
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/statisticsRiskType", method = { RequestMethod.GET, RequestMethod.POST })
    public void statisticsRiskType(HttpServletRequest request, HttpServletResponse response) throws Exception{
        JSONObject result = new JSONObject();
        try {
            String mark = request.getParameter("mark");
            String pdt = request.getParameter("pdt");
            String domain = request.getParameter("domain");
            Map<String, Object> map = ctIndexService.statisticsRiskType(domain,pdt,mark);
            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询风险类型报表数据失败：\r\n"+e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 项目人力工时投入 -- 主页公共
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/getProjectHoursAll",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getProjectHoursAll(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            String mark = request.getParameter("mark");
            String projectStatus = request.getParameter("projectStatus");
            Map<String, Object> map =  ctIndexService.getProjectHoursAll(projectStatus,mark);

            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询变更总汇数据失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }



}
