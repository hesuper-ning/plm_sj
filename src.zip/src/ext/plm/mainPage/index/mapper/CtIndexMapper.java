package ext.plm.mainPage.index.mapper;

import ext.plm.mainPage.bo.CtProjectBo;
import ext.plm.mainPage.bo.CtStatisticsBo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.LinkedList;
import java.util.List;

@Mapper
public interface CtIndexMapper {

    /**
     * 根据用户获取 项目团队信息
     * @param userName 工号
     * @param roleName 角色内部名称
     * @return
     */
    LinkedList<CtProjectBo> getProjectTeamAll(@Param("userName") String userName,@Param("roleName") String roleName);

    /**
     * 获取 项目信息
     * @param productLine 产品线
     * @return
     */
    LinkedList<CtProjectBo> getPdtToProjectAll(@Param("productLine") String productLine);
    /**
     * 获取 项目信息
     * @param productLine 产品线
     * @return
     */
    LinkedList<CtProjectBo> getPdtToProjectAll2(@Param("userName") String userName,@Param("productLine") String productLine);

    /**
     * 获取 A002项目管理工程师 项目信息
     * @param userName 工号
     * @param productLine 产品线
     * @return
     */
    LinkedList<CtProjectBo> getProjectAll(@Param("userName") String userName,@Param("productLine") String productLine);

    /**
     * 项目类型
     * @param projectNumberList
     * @return
     */
    LinkedList<CtStatisticsBo> statisticsTopProjectDeviationRate(@Param("projectNumberList") List<String> projectNumberList);

    /**
     * 项目类型
     * @param projectNumberList
     * @param startDate
     * @param endDate
     * @return
     */
    LinkedList<CtStatisticsBo> getProjectTypeAll(@Param("projectNumberList") List<String> projectNumberList, @Param("startDate") String startDate, @Param("endDate") String endDate);

    /**
     * 项目人力工时
     * @param projectNumberList
     * @param projectStatus
     * @return
     */
    LinkedList<CtStatisticsBo> getProjectHoursAll(@Param("projectNumberList") List<String> projectNumberList, @Param("projectStatus") String projectStatus);

}
