package ext.plm.mainPage;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CtMainPageLogic {
    /**
     * 获取一年中 月份时间段  返回结果为 开始时间+","+结束时间
     */
    public static String getTimeFrame(String format,int year,int startMonth,int endMonth){
        SimpleDateFormat sdf = new SimpleDateFormat(format);

        Calendar startCal = Calendar.getInstance();
        startCal.set(Calendar.YEAR,year);
        startCal.set(Calendar.MONTH,startMonth-1);

        Calendar endCal = Calendar.getInstance();
        endCal.set(Calendar.YEAR,year);
        endCal.set(Calendar.MONTH,endMonth-1);

        int minDay = startCal.getActualMinimum(Calendar.DAY_OF_MONTH);
        int maxDay = endCal.getActualMaximum(Calendar.DAY_OF_MONTH);

        startCal.set(startCal.get(Calendar.YEAR), startCal.get(Calendar.MONTH), minDay, 00, 00, 00);

        endCal.set(endCal.get(Calendar.YEAR), endCal.get(Calendar.MONTH), maxDay, 23, 59, 59);


        return sdf.format(startCal.getTime())+","+sdf.format(endCal.getTime());
    }
}
