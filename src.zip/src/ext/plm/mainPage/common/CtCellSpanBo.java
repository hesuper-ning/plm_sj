package ext.plm.mainPage.common;

/**
 * 元格合并BO
 * @auther TanRuoTao
 */
public class CtCellSpanBo {

    /**
     * 列下标或需要合并列的BO字段名
     */
    private Object colIndexOrFieldName;

    /**
     * 跨的行数
     */
    private int rowspan;

    /**
     *  跨的列数
     */
    private int colspan;

    public CtCellSpanBo(Object colIndexOrFieldName) {
        this.colIndexOrFieldName = colIndexOrFieldName;
    }

    public CtCellSpanBo(int rowspan, int colspan) {
        this.rowspan = rowspan;
        this.colspan = colspan;
    }

    public CtCellSpanBo(Object colIndexOrFieldName, int rowspan, int colspan) {
        this.colIndexOrFieldName = colIndexOrFieldName;
        this.rowspan = rowspan;
        this.colspan = colspan;
    }

    public Object getColIndexOrFieldName() {
        return colIndexOrFieldName;
    }

    public void setColIndexOrFieldName(Object colIndexOrFieldName) {
        this.colIndexOrFieldName = colIndexOrFieldName;
    }

    public int getRowspan() {
        return rowspan;
    }

    public void setRowspan(int rowspan) {
        this.rowspan = rowspan;
    }

    public int getColspan() {
        return colspan;
    }

    public void setColspan(int colspan) {
        this.colspan = colspan;
    }
}
