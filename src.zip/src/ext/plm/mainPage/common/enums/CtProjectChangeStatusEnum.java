package ext.plm.mainPage.common.enums;

public enum CtProjectChangeStatusEnum {
    UnderDesign("UnderDesign","设计中"),
    UnderReview("UnderReview","审阅中"),
    RELEASED("RELEASED","已发布"),
    UnderChange("UnderChange","变更中"),
    REJECTED("REJECTED","已否决"),
    Nullify("Nullify","作废"),
    //本地
    DESIGNING("DESIGNING","设计中"),
    IN_REVIEW("IN REVIEW","审阅中"),
    CANCELLED("CANCELLED","已取消");

    private String status;
    private String description;

    CtProjectChangeStatusEnum(String status, String description) {
        this.status = status;
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public static String getDescription(String status){
        for (CtProjectChangeStatusEnum value : CtProjectChangeStatusEnum.values()) {
            if (value.getStatus().equals(status)) {
                return value.getDescription();
            }
        }
        return status;
    }
}
