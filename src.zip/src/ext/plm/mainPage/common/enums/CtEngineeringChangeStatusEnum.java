package ext.plm.mainPage.common.enums;

public enum CtEngineeringChangeStatusEnum {
    OPEN("OPEN","开启"),
    UnderReview("UNDERREVIEW","正在审阅"),
    APPROVED("APPROVED","已批准"),
    UnderChange("REJECTED","已否决"),
    PENDING_IMPLEMENTATION("PENDING IMPLEMENTATION","待实施"),
    IMPLEMENTATION("IMPLEMENTATION","实施"),
    REWORK("REWORK","返工"),
    PROTOTYPERELEASED("PROTOTYPERELEASED","已发布"),
    RESOLVED("RESOLVED","已解决"),
    CANCELLED("CANCELLED","已取消");

    private String status;
    private String description;

    CtEngineeringChangeStatusEnum(String status, String description) {
        this.status = status;
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public static String getDescription(String status){
        for (CtEngineeringChangeStatusEnum value : CtEngineeringChangeStatusEnum.values()) {
            if (value.getStatus().equals(status)) {
                return value.getDescription();
            }
        }
        return status;
    }
}
