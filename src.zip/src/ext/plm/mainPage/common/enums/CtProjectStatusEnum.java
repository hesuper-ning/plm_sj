package ext.plm.mainPage.common.enums;

/**
 * 项目状态枚举
 */
public enum CtProjectStatusEnum {
    DEFINED("DEFINED","已定义"),
    RUNNING("RUNNING","正在运行"),
    SUSPENDED("SUSPENDED","已暂停"),
    COMPLETED("COMPLETED","已完成"),
    CANCELLED("CANCELLED","已取消");

    private String key,value;

    CtProjectStatusEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }
}
