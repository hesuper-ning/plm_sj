package ext.plm.mainPage.common.constant;

public class CtConstant {
    /**
     * 首页组件
     */
    public final static String HOME_PAGE_COMPONENT = "homePage";

    /**
     * 首页菜单显示名称
     */
    public final static String HOME_PAGE_MENU_NAME = "首页";

    /**
     * 菜单查看所有
     */
    public final static Integer SHOW_ALL_MENU = -1;

    /**
     * 菜单只看显示
     */
    public final static Integer ONLY_CAN_SHOW_MENU = 0;

    /**
     * 新主页默认权限组：在组织下创建，不是站点
     * 没有分配权限的用户 默认使用的权限
     */
    public static final String DEFAULT_PERMISSION_GROUP="新主页默认权限组";

    // 产品开发里程碑阶段
    public static final String milestone_Phase="开工会或开始,TR2,PDCP,TR4,TR4A,TR5,送检,TR6,LDCP,结束";
    // 技术开发里程碑阶段
    public static final String milestone_Phase_TrPoint="开始,PDCP,第一阶段或TR4,第二阶段或TR5,第三阶段,第四阶段,结束";
}
