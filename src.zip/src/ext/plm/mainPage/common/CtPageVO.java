package ext.plm.mainPage.common;

import java.io.Serializable;
import java.util.List;

public class CtPageVO<T> implements Serializable {

    private static final long serialVersionUID = 2L;

    /**
     * 总数
     */
    private Long total;

    /**
     * 每页显示数据
     */
    private List<T> resultData;

    /**
     * 第几页
     */
    private Integer page;

    /**
     * 每页显示多少条数据
     */
    private Integer size;

    /**
     * 总页数
     */
    private Integer totalPage;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Integer getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(Integer totalPage) {
        this.totalPage = totalPage;
    }

    public CtPageVO() {
    }

    public CtPageVO(Long total, List<T> resultData) {
        this.total = total;
        this.resultData = resultData;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public List<T> getResultData() {
        return resultData;
    }

    public void setResultData(List<T> resultData) {
        this.resultData = resultData;
    }
}
