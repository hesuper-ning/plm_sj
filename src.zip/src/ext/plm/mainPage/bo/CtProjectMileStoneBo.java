package ext.plm.mainPage.bo;

import com.fasterxml.jackson.annotation.JsonFormat;
import ext.plm.common.CtAbstractBO;

import java.util.Date;

public class CtProjectMileStoneBo extends CtAbstractBO {
	// 变更ID
	private long docBranchId;
	// 里程碑名称
	private String milestoneName;
	//开始时间
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startTime;
	// 计划完成时间
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date finishTime;
	// 变更前时间
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date changeTimeBefore;
	// 变更后时间
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date changeTimeAfter;
	// 备注
	private String remark;
	//活动id
	private long activityOid;
	//内部行号
	private int innerLineNumber;

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public CtProjectMileStoneBo() {
	}

	public long getDocBranchId() {
		return docBranchId;
	}

	public void setDocBranchId(long docBranchId) {
		this.docBranchId = docBranchId;
	}

	public String getMilestoneName() {
		return milestoneName;
	}

	public void setMilestoneName(String milestoneName) {
		this.milestoneName = milestoneName;
	}

	public Date getFinishTime() {
		return finishTime;
	}

	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}

	public Date getChangeTimeBefore() {
		return changeTimeBefore;
	}

	public void setChangeTimeBefore(Date changeTimeBefore) {
		this.changeTimeBefore = changeTimeBefore;
	}

	public Date getChangeTimeAfter() {
		return changeTimeAfter;
	}

	public void setChangeTimeAfter(Date changeTimeAfter) {
		this.changeTimeAfter = changeTimeAfter;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public long getActivityOid() {
		return activityOid;
	}

	public void setActivityOid(long activityOid) {
		this.activityOid = activityOid;
	}

	public int getInnerLineNumber() {
		return innerLineNumber;
	}

	public void setInnerLineNumber(int innerLineNumber) {
		this.innerLineNumber = innerLineNumber;
	}
}
