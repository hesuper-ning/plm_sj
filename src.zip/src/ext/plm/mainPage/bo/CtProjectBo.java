package ext.plm.mainPage.bo;

import ext.plm.util.CtFormatUtil;

import java.math.BigDecimal;

public class CtProjectBo {

    // 项目编码
    private String projectNumber;

    // 项目名称
    private String projectName;

    // 项目OID
    private String projectOid;

    public String getProjectNumber() {
        return projectNumber;
    }

    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectOid() {
        return projectOid;
    }

    public void setProjectOid(String projectOid) {
        this.projectOid = projectOid;
    }
}
