package ext.plm.mainPage.bo;

import ext.plm.util.CtFormatUtil;

import java.math.BigDecimal;

public class CtStatisticsBo {

    public CtStatisticsBo(){
        super();
    }
    public CtStatisticsBo(String name,int value,String perecnt){
        this.name = name;
        this.value = value;
        this.perecnt = perecnt;
    }
    //统计字段名称
    private String name;

    //统计字段结果
    private int value;
    //统计字段结果
    private String valueStr;

    //百分比
    private String perecnt;

    // 日期
    private String dateStr;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getDateStr() {
        return dateStr;
    }

    public void setDateStr(String dateStr) {
        this.dateStr = dateStr;
    }

    public String getPerecnt() {
        if (CtFormatUtil.hasContent(perecnt)) {
            BigDecimal bigDecimal = new BigDecimal(perecnt);
            return String.valueOf(bigDecimal.doubleValue());
        }
        return perecnt;
    }

    public void setPerecnt(String perecnt) {
        this.perecnt = perecnt;
    }

    public String getValueStr() {
        return valueStr;
    }

    public void setValueStr(String valueStr) {
        this.valueStr = valueStr;
    }
}
