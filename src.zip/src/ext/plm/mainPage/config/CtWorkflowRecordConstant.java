package ext.plm.mainPage.config;

public class CtWorkflowRecordConstant {
    public static final String WORKFLOW_SUMMARY_TEMPLATE = "exportWorkflowRecords.xlsx";

    public static final String WORKFLOW_DETAIL_TEMPLATE = "PLM流程明细表模板.xlsx";

    public static final String DATABASE_EXCEPTION_PREFIX = "后台数据库异常，异常信息：";

    public static final String PART_REFERENCE = "wt.part.WTPart";

    public static final String PART_TYPE = "";

    public static final String DOC_REFERENCE = "wt.doc.WTDocument";

    public static final String DOC_TYPE = "";

    // 文档子类型
    public static final String DOC_SON_TYPE = "";
}
