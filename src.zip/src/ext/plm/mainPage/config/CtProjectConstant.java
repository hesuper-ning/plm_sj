package ext.plm.mainPage.config;

import ext.plm.adminTool.configCenter.manager.CtConfigCenterManager;
import ext.plm.adminTool.configCenter.manager.CtPropertyConfig;
import ext.plm.util.CtFormatUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class CtProjectConstant {

    public static final String trDocType = "com.fhsj.Doc_xmydsqb"; // P-005  暂时没用上
    public static final String dcpDocType = "com.fhsj.Doc_xmydsqb"; // P-005  暂时没用上
    public static final TreeMap<String,String> productTreeMap = new TreeMap<>();
    public static final TreeMap<String,String> devTreeMap = new TreeMap<>();

    static{
        // 里程碑点：喇叭头图取值
        productTreeMap.put("start","start");
        productTreeMap.put("TR2","TR2");
        productTreeMap.put("PDCP","PDCP");
        productTreeMap.put("TR4","TR4");
        productTreeMap.put("TR4A","TR4A");
        productTreeMap.put("TR5","TR5");
        productTreeMap.put("送检","送检");
        productTreeMap.put("TR6","TR6");
        productTreeMap.put("LDCP","LDCP");
        productTreeMap.put("结束","结束");

        // 里程碑点：喇叭头图取值
        devTreeMap.put("start1","start1");
        devTreeMap.put("PDCP","PDCP1");
        devTreeMap.put("TR4","TR41");
        devTreeMap.put("第一阶段","TR41");
        devTreeMap.put("TR5","TR51");
        devTreeMap.put("第二阶段","TR51");
        devTreeMap.put("第三阶段","第三阶段");
        devTreeMap.put("第四阶段","第四阶段");
        devTreeMap.put("结束","结束1");
    }

    public static String getProjectType(String projectType){
        if(projectType.startsWith("产品开发项目")){
            return "product";
        }else if(projectType.startsWith("技术开发项目")) {
            return "dev";
        }else {
            return "";
        }
    }
    public static String getProductValue(String key){
       return productTreeMap.get(key);
    }
    public static String getDevValue(String key){
       return devTreeMap.get(key);
    }
}
