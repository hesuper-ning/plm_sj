package ext.plm.mainPage.manHourReport.bo;

public class ManResourceWorkLoadResult {
    private String projectName;
    private String activityName;
    private String startDate;
    private String finishDate;
    private int daysDifference;
    private String  percentWorkComplete;

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(String finishDate) {
        this.finishDate = finishDate;
    }

    public int getDaysDifference() {
        return daysDifference;
    }

    public void setDaysDifference(int daysDifference) {
        this.daysDifference = daysDifference;
    }

    public String getPercentWorkComplete() {
        return percentWorkComplete;
    }

    public void setPercentWorkComplete(String percentWorkComplete) {
        this.percentWorkComplete = percentWorkComplete;
    }
}
