package ext.plm.mainPage.manHourReport.bo;

import java.math.BigDecimal;

public class ProductLineManHoursByMonthResult {
    private String yearMonth;
    private String productLine;
    private BigDecimal manHours;
    private String projectType;


    public String getYearMonth() {
        return yearMonth;
    }

    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }

    public String getProductLine() {
        return productLine;
    }

    public void setProductLine(String productLine) {
        this.productLine = productLine;
    }

    public BigDecimal getManHours() {
        return manHours;
    }

    public void setManHours(BigDecimal manHours) {
        this.manHours = manHours;
    }

    public String getProjectType() {
        return projectType;
    }

    public void setProjectType(String projectType) {
        this.projectType = projectType;
    }
}
