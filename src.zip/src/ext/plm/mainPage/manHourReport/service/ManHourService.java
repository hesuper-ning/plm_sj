package ext.plm.mainPage.manHourReport.service;

import ext.plm.mainPage.manHourReport.bo.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ManHourService {
    /**
     * 查询每月产品线人力工时
     * @param params 参数
     * @return 返回
     */
    List<ProductLineManHoursByMonthResult> getProductLineManHoursByMonth(QueryManHoursParams params);


    /**
     * 查询各种类型产品线人力工时
     * @param params 参数
     * @return 返回
     */
    List<ProductLineManHoursByMonthResult> getProductLineManHoursByProjectType(QueryManHoursParams params);

    /**
     * 查询项目类型每月工时
     * @param params 参数
     * @return 返回
     */
    List<ProductLineManHoursByMonthResult> getProjectTypeManHourByMonth(QueryManHoursParams params);

    /**
     * 查询人力资源负荷表
     * @param params 参数
     * @return 返回
     */
    List<ManResourceWorkLoadResult> getManResourceWorkload(QueryManResourceWorkloadParams params);

    /**
     * 获取所有部门
     * @return 部门名称
     */
    List<String> loadAllDepartment();

    /**
     * 查询用户所属部门
     * @param loginName 用户
     * @return 返回
     */
    String findDepartmentByUser(String loginName);

    /**
     * 查询用户所属的组
     * @param loginName 用户
     * @return 返回
     */
    List<String> findGroupNameByUser(String loginName);

    /**
     * 根据部门查询用户列表
     * @param params 参数
     * @return 返回
     */
    List<UserInfo> findUserByDepartment(QueryUserParams params);
}
