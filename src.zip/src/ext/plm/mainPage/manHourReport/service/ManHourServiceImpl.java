package ext.plm.mainPage.manHourReport.service;

import ext.plm.mainPage.manHourReport.bo.*;
import ext.plm.mainPage.manHourReport.mapper.ManHourMapper;
import ext.plm.util.CtUserUtil;
import ext.project.util.CtProjectUtil;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.calendar.CalendarHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.MethodContext;
import wt.org.WTGroup;
import wt.org.WTUser;
import wt.pom.WTConnection;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;


import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ManHourServiceImpl implements ManHourService{
    @Autowired
    private ManHourMapper manHourMapper;
    @Override
    public List<ProductLineManHoursByMonthResult> getProductLineManHoursByMonth(QueryManHoursParams params) {
        List<ProductLineManHoursByMonthResult> resultList = manHourMapper.getProductLineManHoursByMonth(params);
        setProductLineShortName(resultList);
        resultList = resultList.stream().filter(item -> !Arrays.asList("9-其它产品线","10-外购品产品管理团队").contains(item.getProductLine())).collect(Collectors.toList());
        List<String> monthsBetween = new ArrayList<>();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Calendar start = Calendar.getInstance();
            start.setTime(sdf.parse(params.getStartDate()));
            Calendar end = Calendar.getInstance();
            end.setTime(sdf.parse(params.getEndDate()));
            monthsBetween = getMonthsBetween(start, end);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        List<ProductLineManHoursByMonthResult> productLineManHoursByMonthResults = mergeAndSumResult(resultList);
        List<ProductLineManHoursByMonthResult> newResult = new ArrayList<>();
        for (String productLine : Arrays.asList("1-火报PDT","2-工业消防PDT","3-应急疏散PDT","4-海外火报PDT","5-防火门PDT","6-电气火灾PDT","7-城市更新SDT","7-储能SDT","7-工业SDT","8-TDT","9-部门工时")) {
            for (String month : monthsBetween) {
                ProductLineManHoursByMonthResult any = productLineManHoursByMonthResults.stream().filter(itm -> StringUtils.equals(itm.getProductLine(), productLine)
                        && StringUtils.equals(itm.getYearMonth(), month)
                ).findAny().orElse(null);
                if (any == null) {
                    ProductLineManHoursByMonthResult temp = new ProductLineManHoursByMonthResult();
                    temp.setProductLine(productLine);
                    temp.setManHours(new BigDecimal("0"));
                    temp.setYearMonth(month);
                    newResult.add(temp);
                } else {
                    newResult.add(any);
                }
            }
        }
        return newResult;
    }
    private static List<String> getMonthsBetween(Calendar startDate, Calendar endDate) {
        List<String> months = new ArrayList<>();
        Calendar currentDate = (Calendar) startDate.clone();
        currentDate.set(Calendar.DAY_OF_MONTH, 1); // 设置日期为每月的第一天

        while (currentDate.before(endDate) || currentDate.equals(endDate)) {
            int year = currentDate.get(Calendar.YEAR);
            int month = currentDate.get(Calendar.MONTH) + 1;
            String monthStr = year + "-" + (month < 10 ? "0" + month : month);
            months.add(monthStr);
            currentDate.add(Calendar.MONTH, 1); // 增加一个月
        }

        return months;
    }
    @Override
    public List<ProductLineManHoursByMonthResult> getProductLineManHoursByProjectType(QueryManHoursParams params) {
        List<ProductLineManHoursByMonthResult> resultList = manHourMapper.getProductLineManHoursByProjectType(params);
        setProductLineShortName(resultList);
        resultList = resultList.stream().filter(item -> !Arrays.asList("9-其它产品线","10-外购品产品管理团队").contains(item.getProductLine())).collect(Collectors.toList());
        List<String> productLists = Arrays.asList("1-火报PDT","2-工业消防PDT","3-应急疏散PDT","4-海外火报PDT","5-防火门PDT","6-电气火灾PDT","7-城市更新SDT","7-储能SDT","7-工业SDT","8-TDT");
        List<ProductLineManHoursByMonthResult> productLineManHoursByMonthResults = mergeAndSumResult(resultList);
        List<ProductLineManHoursByMonthResult> newResult = new ArrayList<>();
        for (String productLine : productLists) {
            for (String projectType : Arrays.asList("V","R","C","W","T","分摊工时","部门工时")) {
                ProductLineManHoursByMonthResult any = productLineManHoursByMonthResults.stream().filter(itm -> StringUtils.equals(itm.getProductLine(), productLine)
                        && StringUtils.equals(itm.getProjectType(), projectType)
                ).findAny().orElse(null);
                if (any == null) {
                    ProductLineManHoursByMonthResult temp = new ProductLineManHoursByMonthResult();
                    temp.setProductLine(productLine);
                    temp.setManHours(new BigDecimal("0"));
                    temp.setProjectType(projectType);
                    newResult.add(temp);
                } else {
                    newResult.add(any);
                }
            }
        }
        return newResult;
    }

    @Override
    public List<ProductLineManHoursByMonthResult> getProjectTypeManHourByMonth(QueryManHoursParams params) {
        List<ProductLineManHoursByMonthResult> projectTypeManHourByMonth = manHourMapper.getProjectTypeManHourByMonth(params);
        List<String> monthsBetween = new ArrayList<>();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Calendar start = Calendar.getInstance();
            start.setTime(sdf.parse(params.getStartDate()));
            Calendar end = Calendar.getInstance();
            end.setTime(sdf.parse(params.getEndDate()));
            monthsBetween = getMonthsBetween(start, end);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<ProductLineManHoursByMonthResult> newResult = new ArrayList<>();
        for (String month : monthsBetween) {
            for (String projectType : Arrays.asList("V","R","C","W","T","分摊工时","部门工时")) {
                ProductLineManHoursByMonthResult any = projectTypeManHourByMonth.stream().filter(itm -> StringUtils.equals(itm.getYearMonth(), month)
                        && StringUtils.equals(itm.getProjectType(), projectType)
                ).findAny().orElse(null);
                if (any == null) {
                    ProductLineManHoursByMonthResult temp = new ProductLineManHoursByMonthResult();
                    temp.setYearMonth(month);
                    temp.setManHours(new BigDecimal("0"));
                    temp.setProjectType(projectType);
                    newResult.add(temp);
                } else {
                    newResult.add(any);
                }
            }
        }
        return newResult;
    }

    @Override
    public List<ManResourceWorkLoadResult> getManResourceWorkload(QueryManResourceWorkloadParams params) {
        List<ManResourceWorkLoadResult> manResourceWorkload = manHourMapper.getManResourceWorkload(params);
        try {
            //WTUser user = CtUserUtil.getUserByAccountName(params.getUserName());
            //WTGroup group = getAdminWTGroup();
//            if(null != user){
                //查询管理员群组系统日历中休息日集合
                List<String> holidayList = queryCalendar("Administrators");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                for (ManResourceWorkLoadResult item : manResourceWorkload) {
//                    Date startDate = sdf.parse(item.getStartDate());
//                    Date endDate = sdf.parse(item.getFinishDate());
//                    Timestamp start = new Timestamp(startDate.getTime());
//                    Timestamp end = new Timestamp(endDate.getTime() - 1 * 24 * 3600 * 1000);

                    int durationDays = calculateDays(item.getStartDate(), item.getFinishDate(), holidayList);

                    //int durationDays = getDurationByStateAndFinishTime(user, start, end);
                    item.setDaysDifference(durationDays);
                }
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return manResourceWorkload;
    }

    /**
     * 查询管理员群组系统日历中休息日集合
     * param groupName Administrators
     * @return
     * @throws Exception
     */
    public List<String> queryCalendar(String groupName) throws Exception {
        List<String> dateList = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection wtConn = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            String sql = "SELECT TO_CHAR(c2.START_DATE, 'yyyy-mm-dd')  \n" +
                    "FROM WTCALENDAR c, COMPONENTLINK k, CALENDARCOMPONENT c2, WTGROUP w WHERE c.IDA2A2 =k.IDA3B5 AND k.IDA3A5 = c2.IDA2A2 \n" +
                    "AND w.NAME = ?\n" +
                    "AND c.IDA3A2OWNERSHIP = w.IDA2A2 AND c.CLASSNAMEKEYA2OWNERSHIP = 'wt.org.WTGroup' AND c2.WORKINGDAY = 0";
            statement = wtConn.prepareStatement(sql);
            statement.setString(1, groupName);
            resultSet = statement.executeQuery();
            String dateString = "";
            while (resultSet.next()) {
                dateString = resultSet.getString(1);
                dateList.add(dateString);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("后台数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (resultSet != null)
                resultSet.close();
            if (statement != null)
                statement.close();
            if (wtConn != null && wtConn.isActive())
                wtConn.release();
        }
        return dateList;
    }

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * 计算开始日期到结束日期之间，排除指定日期后的天数
     *
     * @param startDate 开始日期 (格式: yyyy-MM-dd)
     * @param endDate   结束日期 (格式: yyyy-MM-dd)
     * @param excludeDates 要排除的日期集合 (格式: yyyy-MM-dd)
     * @return 排除后的天数
     */
    public static int calculateDays(String startDate, String endDate, List<String> excludeDates) throws Exception {
        LocalDate start = LocalDate.parse(startDate, DATE_FORMATTER);
        LocalDate end = LocalDate.parse(endDate, DATE_FORMATTER);

        if (end.isBefore(start)) {
            throw new IllegalArgumentException("结束日期不能早于开始日期");
        }

        // 计算总天数（包含开始和结束日期）
        int totalDays = (int) (end.toEpochDay() - start.toEpochDay());

        //排除日期转换为 Set 便于快速查找
        Set<LocalDate> excludeSet = new HashSet<>();
        if (excludeDates != null) {
            for (String dateStr : excludeDates) {
                try {
                    excludeSet.add(LocalDate.parse(dateStr, DATE_FORMATTER));
                } catch (Exception e) {
                    // 忽略格式错误的日期
                }
            }
        }

        // 统计需要排除的日期数量（在范围内且在排除集合中）
        int excludeCount = 0;
        for (LocalDate date = start; !date.isAfter(end); date = date.plusDays(1)) {
            if (excludeSet.contains(date)) {
                excludeCount++;
            }
        }
        return totalDays - excludeCount;
    }

    public static int getDurationByStateAndFinishTime(WTUser user, Timestamp startTime, Timestamp finishTime) throws Exception {
        return CalendarHelper.service.calculateWorkingDays(user, startTime.getTime(), finishTime.getTime()) + 1;
    }

    private static WTGroup getAdminWTGroup() throws WTException {
        WTGroup group = null;
        QuerySpec qs = new QuerySpec(WTGroup.class);
        SearchCondition sc = new SearchCondition(WTGroup.class, "name", "=", "Administrators");
        qs.appendWhere(sc);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        if (qr.hasMoreElements()) {
            group = (WTGroup)qr.nextElement();
        }

        return group;
    }

    @Override
    public List<String> loadAllDepartment() {
        return manHourMapper.loadAllDepartment();
    }

    @Override
    public String findDepartmentByUser(String loginName) {
        return manHourMapper.findDepartmentByUser(loginName);
    }

    @Override
    public List<String> findGroupNameByUser(String loginName) {
        return manHourMapper.findGroupNameByUser(loginName);
    }

    @Override
    public List<UserInfo> findUserByDepartment(QueryUserParams params) {
        return manHourMapper.findUserByDepartment(params);
    }




    private void setProductLineShortName(List<ProductLineManHoursByMonthResult> resultList) {
        Map<String,String> shortNameMapping = new HashMap<>();
        shortNameMapping.put("火灾报警系统产品","1-火报PDT");
        shortNameMapping.put("物联网家用报警系统产品","2-工业消防PDT");
        shortNameMapping.put("工业消防报警系统产品","2-工业消防PDT");
        shortNameMapping.put("工业消防产品","2-工业消防PDT");
        shortNameMapping.put("消防应急照明和疏散指示系统产品","3-应急疏散PDT");
        shortNameMapping.put("海外火灾报警系统产品","4-海外火报PDT");
        shortNameMapping.put("防火门监控系统产品","5-防火门PDT");
        shortNameMapping.put("电气火灾监控系统&消防设备电源监控系统产品","6-电气火灾PDT");
        shortNameMapping.put("消防电气监控系统产品","6-电气火灾PDT");
        shortNameMapping.put("城市更新SDT产品","7-城市更新SDT");
        shortNameMapping.put("储能SDT产品","7-储能SDT");
        shortNameMapping.put("工业SDT产品","7-工业SDT");
        shortNameMapping.put("TDT","8-TDT");
        shortNameMapping.put("研发其他","9-其它产品线");
        shortNameMapping.put("外购品产品管理团队","10-外购品产品管理团队");
        shortNameMapping.put("部门工作","9-部门工时");
        for (ProductLineManHoursByMonthResult item : resultList) {
            if (StringUtils.isNotBlank(item.getProductLine())) {
                String productLine = item.getProductLine();
                productLine = shortNameMapping.containsKey(productLine) ? shortNameMapping.get(productLine) : productLine;
                item.setProductLine(productLine);
            }
        }
    }

    /**
     * 相同产品线相同月份或相同项目类型合并并且工时相加
     * @param list
     * @return
     */
    private List<ProductLineManHoursByMonthResult> mergeAndSumResult(List<ProductLineManHoursByMonthResult> list) {
        List<ProductLineManHoursByMonthResult> resultList = new ArrayList<>();
        for (ProductLineManHoursByMonthResult item : list) {
            ProductLineManHoursByMonthResult any = resultList.stream().filter(itm -> StringUtils.equals(itm.getProductLine(), item.getProductLine())
                    && StringUtils.equals(itm.getProjectType(), item.getProjectType())
                    && StringUtils.equals(itm.getYearMonth(), item.getYearMonth())
            ).findAny().orElse(null);
            if (any == null) {
                resultList.add(item);
            } else {
                any.setManHours(any.getManHours().add(item.getManHours()));
            }
        }
        return resultList;
    }
}
