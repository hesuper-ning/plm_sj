package ext.plm.mainPage.manHourReport;

import ext.plm.common.CtResApiResult;
import ext.plm.mainPage.manHourReport.bo.*;
import ext.plm.mainPage.manHourReport.service.ManHourService;
import ext.plm.mainPage.menuManage.bo.CtDomainBO;
import ext.plm.mainPage.menuManage.bo.CtMenuPermissionLinkVO;
import ext.plm.mainPage.menuManage.service.CtMenuPermissionLinkService;
import ext.plm.newec.CtCloseLoopWfPlugin;
import lombok.extern.slf4j.Slf4j;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.List;

/**
 * 人力工时统计 报表
 */
@RestController
@RequestMapping("/mainPage/manHour/report")
public class ManHourController {
    @Autowired
    private ManHourService manHourService;
    static Logger logger = Logger.getLogger(ManHourController.class);

    /**
     * 查询每月产品线人力工时
     * @param params 参数
     */
    @PostMapping("/getProductLineManHoursByMonth")
    public CtResApiResult getProductLineManHoursByMonth(@RequestBody QueryManHoursParams params){
        try {
            return CtResApiResult.success(manHourService.getProductLineManHoursByMonth(params));
        }catch (Exception e){
            logger.error("getProductLineManHoursByMonth >>> error",e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 查询每月产品线人力工时
     * @param params 参数
     */
    @PostMapping("/getProductLineManHoursByProjectType")
    public CtResApiResult getProductLineManHoursByProjectType(@RequestBody QueryManHoursParams params){
        try {
            return CtResApiResult.success(manHourService.getProductLineManHoursByProjectType(params));
        } catch (Exception e){
            logger.error("getProductLineManHoursByProjectType >>> error",e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 查询每月各项目类型人力工时
     * @param params 参数
     * @return 返回
     */
    @PostMapping("/getProjectTypeManHourByMonth")
    public CtResApiResult getProjectTypeManHourByMonth(@RequestBody QueryManHoursParams params) {
        try {
            return CtResApiResult.success(manHourService.getProjectTypeManHourByMonth(params));
        } catch (Exception e){
            logger.error("getProductLineManHoursByProjectType >>> error",e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }
    @PostMapping("/getManResourceWorkload")
    public CtResApiResult getManResourceWorkload(@RequestBody QueryManResourceWorkloadParams params) {
        try {
            return CtResApiResult.success(manHourService.getManResourceWorkload(params));
        } catch (Exception e){
            logger.error("getManResourceWorkload >>> error",e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    @PostMapping("/loadAllDepartment")
    public CtResApiResult loadAllDepartment() {
        try {
            return CtResApiResult.success(manHourService.loadAllDepartment());
        } catch (Exception e){
            logger.error("getManResourceWorkload >>> error",e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 根据部门查询用户列表
     * @param params 参数
     * @return 返回
     */
    @PostMapping("/findUserByDepartment")
    public CtResApiResult findUserByDepartment(@RequestBody QueryUserParams params){
        try {
            return CtResApiResult.success(manHourService.findUserByDepartment(params));
        } catch (Exception e){
            logger.error("getManResourceWorkload >>> error",e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }
    /**
     * 查询当前用户的部门
     * @return 返回
     */
    @PostMapping("/findCurrentUserDept")
    public CtResApiResult findCurrentUserDept(){
        try {
            WTUser user = (WTUser) SessionHelper.getPrincipal();
            return CtResApiResult.success(manHourService.findDepartmentByUser(user.getName()));
        } catch (Exception e){
            logger.error("getManResourceWorkload >>> error",e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 查询当前用户的部门
     * @return 返回
     */
    @PostMapping("/findCurrentUserGroup")
    public CtResApiResult findCurrentUserGroup(){
        try {
            WTUser user = (WTUser) SessionHelper.getPrincipal();
            return CtResApiResult.success(manHourService.findGroupNameByUser(user.getName()));
        } catch (Exception e){
            logger.error("getManResourceWorkload >>> error",e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }
}
