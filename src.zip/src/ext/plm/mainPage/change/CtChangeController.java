package ext.plm.mainPage.change;

import cn.hutool.core.util.NumberUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import ext.plm.common.CtResApiResult;
import ext.plm.ec.CtEcService;
import ext.plm.mainPage.bo.CtStatisticsBo;
import ext.plm.mainPage.change.bo.*;
import ext.plm.mainPage.common.CtPageVO;
import ext.plm.mainPage.common.enums.CtEngineeringChangeStatusEnum;
import ext.plm.mainPage.projectManage.CtProjectManageQuery;
import ext.plm.mainPage.tool.project.CtProjectLogic;
import ext.plm.mainPage.util.CtMainPageUtil;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtVersionUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import wt.doc.WTDocument;
import wt.services.ServiceFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping(value = "mainPage/change", produces = "application/json")
public class CtChangeController {

    @Autowired
    private CtChangeService ctChangeService;
    @Autowired
    private CtProjectManageQuery ctProjectManageQuery;
    @Autowired
    private CtChangeLogic ctChangeLogic;
    /**
     * 分页查询计划变更列表
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/getPlanChangeList",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getPlanChangeList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String projectId = request.getParameter("projectOid");
            List<CtPlanChangeBo> boList = ctChangeService.getPlanChangeList(projectId);
            LinkedHashMap<String,String> linkedHashMap = ctChangeService.getPlanChangeList(projectId,"A");
            LinkedHashMap<String,Date> avMap =new LinkedHashMap<>();
            List<CtPlanChangeBo> boListA = ctChangeService.getPlanChangeListAll(projectId,"A");
            Integer page = null;//记录开始序号
            Integer size = null;// 每页条数
            if (request.getParameter("page") != null && request.getParameter("limit") != null) {
                page = Integer.valueOf(request.getParameter("page"));
                size = Integer.valueOf(request.getParameter("limit"));
            }
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            for(CtPlanChangeBo bo:boListA){
                String tr = CtProjectLogic.getTrName(bo.getChangePhase());
                System.out.println("boListA- tr："+bo.getChangePhase() +" --> "+tr);
                if(StringUtils.isEmpty(tr)){
                    continue;
                }
                String initDate = bo.getInitDate();
                Date finishTime = simpleDateFormat.parse(initDate);
                avMap.put(tr,finishTime); // 最后时间-A版本完成时间
            }
            System.out.println("linkedHashMap"+linkedHashMap);
            List<CtPlanChangeBo> cutBoList = (List<CtPlanChangeBo>) CtMainPageUtil.CollectionPageHandler(page, size, boList);
            for(CtPlanChangeBo bo:cutBoList){
                if(StringUtils.isNotEmpty(bo.getPreChangePlan()) && StringUtils.isNotEmpty(bo.getPostChangePlan())){
                    String tr =  CtProjectLogic.getTrName(bo.getChangePhase());
                    Date upDate = simpleDateFormat.parse(bo.getPreChangePlan());
                    Date finishTime = simpleDateFormat.parse(bo.getPostChangePlan());
                    String day1 =  ctChangeLogic.getProjectDelayDays(finishTime,upDate);
                    String day2 = linkedHashMap.get(tr);
                    System.out.println("tr"+tr+" day1"+day1+" day2"+day2);
                    if(StringUtils.isNotEmpty(day1) && StringUtils.isNotEmpty(day2)){
                        BigDecimal noTr =  new BigDecimal(day1);
                        BigDecimal aTr =  new BigDecimal(day2);
//                        BigDecimal res =  noTr.divide(aTr,2, RoundingMode.HALF_UP);
                        BigDecimal res =  BigDecimal.ZERO;
                        if(aTr != BigDecimal.ZERO  && Integer.parseInt(day2) != 0){
                            res = noTr.divide(aTr,2, RoundingMode.HALF_UP);
                        }
                        Date adate = avMap.get(tr);
                        if (adate.getTime() < finishTime.getTime()){
                            bo.setDuringChanges("-"+res.multiply(new BigDecimal(String.valueOf(100))).toString()+"%");
                        }else{
                            bo.setDuringChanges(res.multiply(new BigDecimal(String.valueOf(100))).toString()+"%");
                        }

                    }
                }
                WTDocument document = CtDocUtil.getDocumentByBranchId(bo.getChangeDocVid());
                if(document != null){
                    IBAUtil ibaUtil = new IBAUtil(document);
                    String projectPhase = ibaUtil.getIBAValue("Ct_ProjectPhase");
                    bo.setChangePhase(projectPhase);
                    bo.setPromoter(document.getCreator().getFullName());
                    bo.setDocVersion(CtVersionUtil.getVersionInfo(document));
                }
            }
            result.put("total", boList.size());
            result.put("items", JSON.toJSON(cutBoList));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询计划变更列表失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    /**
     * TOP5计划变更
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/getPlanChangeReportData",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getPlanChangeReportData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String projectId = request.getParameter("projectOid");

            Map<String, Object> map = ctChangeService.getPlanChangeReportData(projectId);

            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询计划变更报表数据失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    /**
     * 分页查询需求变更列表
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/getRequiredChangeList",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getRequiredChangeList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            String projectId = request.getParameter("projectOid");
            List<CtRequireChangeBo> boList = ctChangeService.getRequiredChangeList(projectId);
            Integer page = null;//记录开始序号
            Integer size = null;// 每页条数
            if (request.getParameter("page") != null && request.getParameter("limit") != null) {
                page = Integer.valueOf(request.getParameter("page"));
                size = Integer.valueOf(request.getParameter("limit"));
            }
            System.out.println("boList"+boList.size());
            List<CtRequireChangeBo> cutBoList = (List<CtRequireChangeBo>) CtMainPageUtil.CollectionPageHandler(page, size, boList);
            System.out.println("cutBoList"+cutBoList.size());
            for(CtRequireChangeBo bo:cutBoList){
                WTDocument document = CtDocUtil.getDocumentByBranchId(bo.getChangeDocVid());
                if(document != null){
                    IBAUtil ibaUtil = new IBAUtil(document);
                    String projectPhase = ibaUtil.getIBAValue("Ct_ProjectPhase");
                    bo.setChangePhase(projectPhase);
                }
                String fullName = ctProjectManageQuery.getCurrentUser("VR:wt.doc.WTDocument:"+bo.getChangeDocVid()); // 流程当前处理人
                bo.setProcessHandler(fullName);
                String docState = CtWTObjectUtil.getStateDisplay(document, Locale.CHINA);
                bo.setChangeState(docState);
            }
            result.put("total", boList.size());
            result.put("items", JSON.toJSON(cutBoList));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询需求变更列表失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    /**
     * 需求变更--图表
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/getRequiredChangeReportData",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getRequiredChangeReportData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String projectId = request.getParameter("projectOid");

            Map<String, Object> map = ctChangeService.getRequiredChangeReportData(projectId);

            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询需求变更报表数据失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    /**
     * 获取工程变更列表
     */
    @RequestMapping(value = "/getEngineeringChangeList",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getEngineeringChangeList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            String projectId = request.getParameter("projectOid");
            List<CtEngineeringChangeBo> boList = ctChangeService.getEcChangeList(projectId);
            Integer page = null;//记录开始序号
            Integer size = null;// 每页条数
            if (request.getParameter("page") != null && request.getParameter("limit") != null) {
                page = Integer.valueOf(request.getParameter("page"));
                size = Integer.valueOf(request.getParameter("limit"));
            }

            List<CtEngineeringChangeBo> cutBoList = (List<CtEngineeringChangeBo>) CtMainPageUtil.CollectionPageHandler(page, size, boList);
            for(CtEngineeringChangeBo bo:cutBoList){
                String state = CtEngineeringChangeStatusEnum.getDescription(bo.getChangeState());
                bo.setChangeState(state);
                if("已解决".equals(state)){
                    String fullName = ctProjectManageQuery.getCurrentUser(bo.getChangeRequestId()); // 流程当前处理人
                    bo.setProcessHandler(fullName);
                }
            }
            result.put("total", boList.size());
            result.put("items", JSON.toJSON(cutBoList));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询工程变更列表失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    /**
     * 工程变更--图表
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/getEngineeringChangeReportData",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getEngineeringChangeReportData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String projectId = request.getParameter("projectOid");

            Map<String, Object> map = ctChangeService.getEngineeringChangeReportData(projectId);

            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询工程变更报表数据失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    /**
     * 变更变更--总汇
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/getChangeReportDataAll",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getChangeReportDataAll(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            String projectId = request.getParameter("projectOid");
            List<CtStatisticsBo> listMap = ctChangeService.getChangeReportDataAll(projectId);

            result.put("items", JSON.toJSON(listMap));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询变更总汇数据失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }
    /**
     * 变更变更--图表三个类型
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/getChangeSummaryDataAll",  method = { RequestMethod.GET,RequestMethod.POST })
    public void getChangeSummaryDataAll(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            String projectId = request.getParameter("projectOid");
            Map<String, Object> map =  ctChangeService.getChangeSummaryDataAll(projectId);

            result.put("items", JSON.toJSON(map));
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询变更总汇数据失败,后台异常："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }


    /**
     * 获取所有产品名称
     */
    @GetMapping("/getAllProductName")
    public CtResApiResult getAllProductName() {
        List<String> result= ctChangeService.getAllProductName();
        return CtResApiResult.success(result);
    }

    /**
     * 获取项目变更列表
     */
    @GetMapping("/getProjectChangeList")
    public CtResApiResult getProjectChangeList(String data) {
        try {
            Map<String, Object> params = JSON.parseObject(data, new TypeReference<Map>() {
            });
            int page=params.get("page")==null?1: Integer.parseInt(params.get("page").toString());
            int size=params.get("size")==null?10: Integer.parseInt(params.get("size").toString());
            params.put("page", (page - 1) * size);
            params.put("size", size);
            CtPageVO<CtProjectChangeBo> result = ctChangeService.getProjectChangeList(params);
            return CtResApiResult.success(result);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("获取项目变更列表失败：\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 获取需求变更列表
     * data.projectName 项目名称
     * data.requestName 需求名称
     * data.createUserId 需求创建者
     * data.requestStatus 需求状态，数字
     * data.requestCreateTimeGt 需求创建时间大于等于
     * data.requestCreateTimeLt 需求创建时间小于等于
     * data.requestUpdateTimeGt 需求更新时间大于等于
     * data.requestUpdateTimeLt 需求更新时间小于等于
     * data.page 第几页
     * data.size 每页多少条数据
     */
    @GetMapping("/getRequestChangeList")
    public CtResApiResult getRequestChangeList(String data) {
        try {
            Map<String, Object> params = JSON.parseObject(data, new TypeReference<Map>() {
            });
            CtRequestChangePageBo bo = ctChangeService.getRequestChangeList(params);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("获取需求变更列表失败：\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 获取变更统计--数据
     * data.projectOid 必传
     */
    @GetMapping(value = "/getChangeSummaryData")
    public CtResApiResult getChangeSummaryData(String data) {
        try {
            Map<String, Object> params = JSON.parseObject(data, new TypeReference<Map>() {
            });
            List<CtChangeSummaryBo> resultList = ctChangeService.getChangeSummaryData(params);
            Integer changeTotal = resultList.stream().map(CtChangeSummaryBo::getChangeTotal).reduce(Integer::sum).orElse(0);
            Integer requestChangeTotal = resultList.stream().map(CtChangeSummaryBo::getRequestChangeNum).reduce(Integer::sum).orElse(0);
            Integer projectChangeTotal = resultList.stream().map(CtChangeSummaryBo::getProjectChangeNum).reduce(Integer::sum).orElse(0);
            Integer engineeringChangeTotal = resultList.stream().map(CtChangeSummaryBo::getEngineeringChangeNum).reduce(Integer::sum).orElse(0);
            Map<String, Object> map = new HashMap<>();
            map.put("changeTotal", changeTotal);
            map.put("requestChangeTotal", requestChangeTotal);
            map.put("requestChangePercent", changeTotal == 0 ? 0 : NumberUtil.round((requestChangeTotal * 1.0 / changeTotal) * 100, 2));
            map.put("projectChangeTotal", projectChangeTotal);
            map.put("projectChangePercent", changeTotal == 0 ? 0 : NumberUtil.round((projectChangeTotal * 1.0 / changeTotal) * 100, 2));
            map.put("engineeringChangeTotal", engineeringChangeTotal);
            map.put("engineeringChangePercent", changeTotal == 0 ? 0 : NumberUtil.round((engineeringChangeTotal * 1.0 / changeTotal) * 100, 2));
            map.put("changeList", resultList);
            return CtResApiResult.success(map);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("获取变更统计失败：\n" + e.getLocalizedMessage());
        }
    }


}
