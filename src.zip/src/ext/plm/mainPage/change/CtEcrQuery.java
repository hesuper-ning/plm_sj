package ext.plm.mainPage.change;

import ext.plm.common.CtConstant;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.lang3.StringUtils;
import wt.change2.WTChangeRequest2;
import wt.method.MethodContext;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CtEcrQuery {
    /**
     * 获取所有的ECRID
     */
    public List<WTChangeRequest2> getEcrIdValues() throws Exception {
        List<WTChangeRequest2> list = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            String sql = "select 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO as ecrId from WTCHANGEREQUEST2 ec GROUP BY ec.BRANCHIDITERATIONINFO ";
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String attValue = resultSet.getString("ECRID");
                if(StringUtils.isNotBlank(attValue)){
                    WTChangeRequest2 changeRequest = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(attValue);
                    list.add(changeRequest);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            // connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return list;
    }

    /**
     * 保存字段（存在时更新，不存在时新建）
     *
     * @throws Exception
     */
    public void saveAttribute(String partNumberValue, String ecrId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String updateSql = "update ZEcParentPart set partNumberValue = ? where  ecrId= ?";
            statement = connection.prepareStatement(updateSql);
            statement.setString(1, partNumberValue);
            statement.setString(2, ecrId);
            int updateCount = statement.executeUpdate();
            // 更新条数为0，说明数据不存在，则执行添加
            if (updateCount == 0) {
                System.out.println(">>>>>新增字段>>>>" + ecrId + ">>>>" + partNumberValue);
                String createSql = "insert into ZEcParentPart(ecrId,partNumberValue)  values(?,?)";
                statement = connection.prepareStatement(createSql);
                statement.setString(1, ecrId);
                statement.setString(2, partNumberValue);
                statement.execute();
            } else {
                System.out.println(">>>>>执行保存>>>>" + ecrId + ">>>>" + partNumberValue + ">>>updateCount=" + updateCount);
            }
            connection.getConnection().commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }


}
