package ext.plm.mainPage.change;

import ext.plm.mainPage.bo.CtStatisticsBo;
import ext.plm.mainPage.change.bo.CtChangeMilestoneBo;
import ext.plm.mainPage.change.bo.CtEngineeringChangeBo;
import ext.plm.mainPage.change.bo.CtPlanChangeBo;
import ext.plm.mainPage.change.bo.CtRequireChangeBo;
import ext.plm.mainPage.change.mapper.CtChangeMapper;
import ext.plm.mainPage.tool.project.CtProjectLogic;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import wt.projmgmt.admin.Project2;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class CtChangeLogic {

	@Autowired
	private CtChangeService ctChangeService;
	@Autowired
	private CtChangeMapper ctChangeMapper;

	/**
	 * 获取项目的延迟天数
	 * @param finishTime 当前计划完成时间
	 * @param actualFinishTime  上一次完成时间
	 * @return
	 * @throws Exception
	 */
	public String getProjectDelayDays(Date finishTime, Date actualFinishTime) throws Exception {
		if(finishTime!=null) {
			DecimalFormat df = new DecimalFormat("0");
			// 当前时间减去阶段在计划完成时间
			long delayTime = finishTime.getTime() - actualFinishTime.getTime();
			if (delayTime > 0) {
				return df.format(delayTime / (float) (24 * 3600 * 1000)); // 延迟时长
			}else{
				return "-"+df.format(delayTime / (float) (24 * 3600 * 1000)); // 延迟时长
			}
		}
		return null;
	}

	public static void main(String[] args) {
		BigDecimal noTr =  new BigDecimal(21); // 最后的版本
		BigDecimal aTr =  new BigDecimal(97); // A版本
		BigDecimal res =  noTr.divide(aTr,2, RoundingMode.HALF_UP);
		System.out.println(res.multiply(new BigDecimal(String.valueOf(100))).longValue());
		Map<String, Integer> map = new HashMap<>();
		map.put("PDCP", 1);
		map.put("LDCP", 2);
		map.put("TR5", 2);
		map.put("TR4", 1);
		map.put("TR6", 2);
		map.put("送检", 1);

		List<Map.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
		list.sort(Map.Entry.comparingByValue());
		Map<String, Integer> sortedMap = new LinkedHashMap<>();
		for(int i=list.size()-1;i>=0;i-- ){
			Map.Entry<String, Integer> entry= list.get(i);
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		System.out.println(sortedMap);

		Map<String, Date> trMap = new HashMap<>(); // TR点的项目计划完成时间
		// 计划偏差值的横轴值
		String[] trLegend = trMap.keySet().toArray(new String[trMap.keySet().size()]); // TR点
	}
	/**
	 * 获取单项目计划变更中的报表数据
	 * @param projectId
	 * @return void
	 * @Exception
	 **/
	public  Map<String, Object> getSinglePlanChangeReportData(String projectId) throws Exception{
		Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
		List<CtPlanChangeBo> boList = ctChangeService.getPlanChangeList(projectId);
		List<CtPlanChangeBo> boListA = ctChangeService.getPlanChangeListAll(projectId,"A");
		LinkedHashMap<String,String> linkedHashMap = ctChangeService.getPlanChangeList(projectId,"A");
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		LinkedList<String> trPhase = new LinkedList<>(); // 横坐标基础值
		for(Map.Entry<String,String> map:linkedHashMap.entrySet()){
			trPhase.add(map.getKey());
		}
		// TODO 取计划钟的里程碑清单信息
		LinkedHashMap<String, Date> trMap = new LinkedHashMap<>(); // TR点的项目计划完成时间
		Map<String, Date> avMap = new HashMap<>(); // A版本的计划完成时间

		Map<String, Long> pcMap = new HashMap<>(); // 所有TR点偏差率,百分点
		Map<String, Long> dayMap = new HashMap<>(); // 所有TR点与A版本之间的差距天数
		Map<Long,String> vidMap = new HashMap<>(); // 所有版本Vid
		// 变更次数Map
		Map<String, Integer> changeCountMap = new HashMap<>();
		String ida2a2 = project.getPersistInfo().getObjectIdentifier().getId()+"";
		LinkedList<CtChangeMilestoneBo>  listPlan = ctChangeMapper.getMilestoneList(ida2a2);
		for(CtChangeMilestoneBo bo : listPlan){
			System.out.println("listPlan- tr："+bo.getMileStoneName());
			String tr = CtProjectLogic.getTrName(bo.getMileStoneName());
			Date endTime = bo.getMilestoneTime();
			trMap.put(tr,endTime);
		}
		long maxVid = 0l; // 最大版本的VID
		for(CtPlanChangeBo bo:boListA){
			String tr = CtProjectLogic.getTrName(bo.getChangePhase());
			System.out.println("boListA- tr："+bo.getChangePhase() +" --> "+tr);
			if(StringUtils.isEmpty(tr)){
				continue;
			}
			String initDate = bo.getInitDate();
			Date finishTime = simpleDateFormat.parse(initDate);
			avMap.put(tr,finishTime); // 最后时间-A版本完成时间
			pcMap.put(tr,0L); // 所有TR点偏差率,百分点
			dayMap.put(tr,0L); // 所有TR点与A版本之间的差距天数
			// vidMap.put(tr,finishTime); // 所有版本Vid
		}
		for(CtPlanChangeBo bo:boList){
			if(StringUtils.isNotEmpty(bo.getPreChangePlan()) && StringUtils.isNotEmpty(bo.getPostChangePlan())){
				String tr = CtProjectLogic.getTrName(bo.getChangePhase());
				System.out.println("boList- tr："+bo.getChangePhase() +" --> "+tr);
				if(StringUtils.isEmpty(tr)){
					continue;
				}
				long vid = Long.parseLong(bo.getChangeDocVid());
				vidMap.put(vid,bo.getChangeTime());
				System.out.println("maxVid："+maxVid+" vid："+vid);
				if(maxVid < vid){  // 取最大版本
					maxVid = vid;
				}
				Date upDate = simpleDateFormat.parse(bo.getPreChangePlan());
				Date finishTime = simpleDateFormat.parse(bo.getPostChangePlan());
				String day1 = getProjectDelayDays(finishTime,upDate);
				String day2 = linkedHashMap.get(tr);
				System.out.println("tr"+tr+" day1"+day1+" day2"+day2);
				if(StringUtils.isNotEmpty(day1) && StringUtils.isNotEmpty(day2)){
					BigDecimal noTr =  new BigDecimal(day1); // 最后的版本
					BigDecimal aTr =  new BigDecimal(day2); // A版本
					BigDecimal res =  BigDecimal.ZERO;
					if(aTr != BigDecimal.ZERO && Integer.parseInt(day2) != 0){
						res = noTr.divide(aTr,2, RoundingMode.HALF_UP);
					}
					pcMap.put(tr,res.multiply(new BigDecimal(String.valueOf(100))).longValue());
					long dates = CtDateUtil.getDistDates(finishTime, avMap.get(tr));
					dayMap.put(tr,dates); // 最后时间-A版本完成时间
					if(!Long.valueOf(dates).equals(0L)){
						System.out.println("changeCount: "+tr+" changeCount: "+changeCountMap);
						// 变更次数
						int changeCount = 1;
						if (changeCountMap.containsKey(tr)){
							Integer count = changeCountMap.get(tr);
							count += changeCount;
							changeCountMap.put(tr, count);
						}else {
							// 如果变更次数不为0(版本不为A) 则存入Map中
							changeCountMap.put(tr, changeCount);
						}
					}
				}
			}
		}
		System.out.println("横坐标基础值 trPhase"+trPhase);
		System.out.println("所有TR点偏差率,百分点 pcMap"+pcMap);
		System.out.println("所有TR点与A版本之间的差距天数 dayMap"+dayMap);
		System.out.println("所有版本Vid vidMap"+vidMap);
		System.out.println("A版本的计划完成时间 avMap"+avMap);
		System.out.println("TR点的项目计划完成时间 trMap"+trMap);
		System.out.println("变更次数Map changeCountMap"+changeCountMap);

		// 产更次数TOP5的横轴值
		LinkedList<String> changeCountLegend = new LinkedList<String>();
		// 变更测试TOP5的数据
		LinkedList<Integer> changeCountData = new LinkedList<Integer>();
		// 计划偏差值的横轴值
		String[] planDiffLegend = trPhase.toArray(new String[trPhase.size()]); // TR点
		// 计划偏差值的天数数据
		Long[] planDiffDayData = new Long[planDiffLegend.length];
		// 计划偏差值的数据
		Long[] planDiffData = new Long[planDiffLegend.length];

		// 计划变差值(用于存储数组下标)
		Map<String, Integer> planDiffMap = new LinkedHashMap<>();
		for(int i = 0; i < planDiffLegend.length; i++){
			planDiffMap.put(planDiffLegend[i], i);
			// 初始值
			planDiffData[i] = 0l;
			planDiffDayData[i] = 0l;
		}

		for (String tr : trPhase){
			Date adate = avMap.get(tr); // A版本计划完成时间，初始计划完成时间
			Date planDate = trMap.get(tr); // 项目计划里程碑TR点计划完成时间
			long dates = dayMap.get(tr); // 天数 变更版本与初始计划完成时间的相差天数
			long pcTa = pcMap.get(tr); // TR偏差率
			if (adate != null && planDate != null) {
				if(dates != 0){
					if (adate.getTime() < planDate.getTime()){
						dates = -dates;
					}
				}
				if (planDiffMap.containsKey(tr)) {
					int index = planDiffMap.get(tr);
					planDiffDayData[index] = dates;
					planDiffData[index] = pcTa;
				}
			}
		}

		// TOP 5排序
		Map<String, Integer> resCountMap = mapValue2Sort(changeCountMap);
		// 按变更次数排序，如变革次数超过5条数，则只拿前5条
		int x = 0;
		for (Map.Entry<String, Integer> item : resCountMap.entrySet()){
			if(x == 5){
 				break;
			}
//			Date date = trMap.get(item.getKey());
//			if (date != null) {
//				changeCountLegend.add(item.getKey() + "\n" + simpleDateFormat.format(date));
//			}else{
//				changeCountLegend.add(item.getKey());
//			}
			changeCountLegend.add(item.getKey());
			changeCountData.add(item.getValue());
			x++;
		}
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("changeCountLegend", changeCountLegend);
		resultMap.put("changeCountData", changeCountData);
		// resultMap.put("planDiffLegend", getPhaseLegend(project,planDiffLegend,trMap));
		resultMap.put("planDiffLegend",planDiffLegend);
		resultMap.put("planDiffDayData", planDiffDayData);
		resultMap.put("planDiffData", planDiffData);
		return resultMap;
	}
	/**
	 * 获取单项目需求变更中的报表数据
	 * @param projectId
	 * @return void
	 * @Exception
	 **/
	public  Map<String, Object> getSingleRequiredChangeReportData(String projectId) throws Exception{
		Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
		System.out.println("getRequiredChangeData "+project.getProjectNumber());
		List<CtRequireChangeBo> listBo = ctChangeMapper.getRequiredChangeData(project.getProjectNumber());
		// 来源X轴
		List<String> typeList = new ArrayList<>();
		List<String> dateList = new ArrayList<>();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		for(CtRequireChangeBo bo:listBo){
			String type = bo.getRequireChangeSource();
			typeList.add(type+":"+bo.getChangeState()); // 变更来源
			dateList.add(bo.getChangeState()+":"+bo.getChangeTime()); // 发起时间
		}

		// 来源横坐标
		LinkedList<String> changeCountLegend = new LinkedList<String>();
		// 来源变更中
		LinkedList<Integer> changeCount1Data = new LinkedList<Integer>();
		// 来源已完成
		LinkedList<Integer> changeCount2Data = new LinkedList<Integer>();
		Map<String, Integer> noMap = new HashMap<>();
		Map<String, Integer> yesMap = new HashMap<>();
		for(String str:typeList){
			String[] strs = str.split(":");
			String type = strs[0];
			String changeState = strs[1];
			if(!changeCountLegend.contains(type)){
				changeCountLegend.add(type);
			}
			int changeCount = 1;
			if("RELEASED".equals(changeState)){
				if (yesMap.containsKey(type)){
					Integer count = yesMap.get(type);
					count += changeCount;
					yesMap.put(type, count);
				}else {
					// 如果变更次数不为0(版本不为A) 则存入Map中
					yesMap.put(type, changeCount);
				}
			}else{
				if (noMap.containsKey(type)){
					Integer count = noMap.get(type);
					count += changeCount;
					noMap.put(type, count);
				}else {
					// 如果变更次数不为0(版本不为A) 则存入Map中
					noMap.put(type, changeCount);
				}
			}
		}
		for(int i = 0; i < changeCountLegend.size(); i++ ){
			String type = changeCountLegend.get(i);
			Integer count1 = noMap.get(type);
			Integer count2 = yesMap.get(type);
			if(count1 == null)count1 = 0;
			if(count2 == null)count2 = 0;
			changeCount1Data.add(count1);
			changeCount2Data.add(count2);
		}
		System.out.println("changeCountLegend:"+changeCountLegend);
		System.out.println("changeCount1Data:"+changeCount1Data);
		System.out.println("changeCount2Data:"+changeCount2Data);

		// 需求变更的TR变更中，已变更
		LinkedHashMap<String, Date> trMap = new LinkedHashMap<>(); // TR点的项目计划完成时间
		String ida2a2 = project.getPersistInfo().getObjectIdentifier().getId()+"";
		LinkedList<CtChangeMilestoneBo>  listPlan = ctChangeMapper.getMilestoneList(ida2a2);
		for(CtChangeMilestoneBo bo : listPlan){
			System.out.println("listRequired- tr："+bo.getMileStoneName());
			String tr = CtProjectLogic.getTrName(bo.getMileStoneName());
			Date endTime = bo.getMilestoneTime();
			trMap.put(tr,endTime);
		}
		// 计划偏差值的横轴值
		String[] trLegend = trMap.keySet().toArray(new String[trMap.keySet().size()]); // TR点
		// 计划偏差值的天数数据
		Integer[] tr1Data = new Integer[trLegend.length];
		// 计划偏差值的数据
		Integer[] tr2Data = new Integer[trLegend.length];

		noMap.clear();
		yesMap.clear();
		for(String str:dateList){
			String[] strs = str.split(":");
			String changeState = strs[0];
			String changeTime = strs[1];
			Date createTime = simpleDateFormat.parse(changeTime);
			String tr = null;
			boolean fal = false;
			for (Map.Entry<String, Date> map:trMap.entrySet()){
				tr = map.getKey();
				Date finishDate = map.getValue();
				if(createTime.getTime()<= finishDate.getTime()){
					fal = true;
				}
			}
			if(fal){
				int changeCount = 1;
				if("RELEASED".equals(changeState)){
					if (yesMap.containsKey(tr)){
						Integer count = yesMap.get(tr);
						count += changeCount;
						yesMap.put(tr, count);
					}else {
						// 如果变更次数不为0(版本不为A) 则存入Map中
						yesMap.put(tr, changeCount);
					}
				}else{
					if (noMap.containsKey(tr)){
						Integer count = noMap.get(tr);
						count += changeCount;
						noMap.put(tr, count);
					}else {
						// 如果变更次数不为0(版本不为A) 则存入Map中
						noMap.put(tr, changeCount);
					}
				}
			}
		}

		for(int i = 0; i < trLegend.length; i++){
			String tr = trLegend[i];
			// 初始值
			Integer count1 = noMap.get(tr);
			Integer count2 = yesMap.get(tr);
			if(count1 == null)count1 = 0;
			if(count2 == null)count2 = 0;
			tr1Data[i] = count1;
			tr2Data[i] = count2;
		}
		System.out.println("trLegend:"+trLegend);
		System.out.println("tr1Data:"+tr1Data);
		System.out.println("tr2Data:"+tr2Data);

		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("changeCountLegend", changeCountLegend);
		resultMap.put("changeCount1Data", changeCount1Data);
		resultMap.put("changeCount2Data", changeCount2Data);
		// resultMap.put("planDiffLegend", getPhaseLegend(project,planDiffLegend,trMap));
		resultMap.put("trLegend",trLegend);
		resultMap.put("tr1Data", tr1Data);
		resultMap.put("tr2Data", tr2Data);
		return resultMap;
	}
	/**
	 * 获取单项目工程变更中的报表数据
	 * @param projectId
	 * @return void
	 * @Exception
	 **/
	public  Map<String, Object> getEngineeringChangeReportData(String projectId) throws Exception{
		Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
		System.out.println("getRequiredChangeData "+project.getProjectNumber());
		List<CtEngineeringChangeBo > boList = ctChangeService.getEcChangeList(projectId);

		List<String> dateList = new ArrayList<>();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		for(CtEngineeringChangeBo bo:boList){
			dateList.add(bo.getApplyTime()); // 发起时间
		}
		System.out.println("getEngineeringChangeReportData dateList:"+dateList);
		Map<String, Object> resultMap = assemblyChangeNumber(dateList,project);
		return resultMap;
	}
	/**
	 * 获取单项目工程变更中的报表数据
	 * @param projectId
	 * @return void
	 * @Exception
	 **/
	public  List<CtStatisticsBo> getChangeReportDataAll(String projectId) throws Exception{
		Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
		System.out.println("getRequiredChangeData "+project.getProjectNumber());
		List<CtRequireChangeBo > boList1 = ctChangeMapper.getRequiredChangeData(project.getProjectNumber());

		List<CtPlanChangeBo > boList = ctChangeService.getPlanChangeList(projectId);
		Map<String,CtPlanChangeBo> map = new HashMap<>();
		for (CtPlanChangeBo bo:boList) {
			map.put(bo.getChangeDocVid(),bo);
		}
		List<CtPlanChangeBo > boList2 =new ArrayList<>(map.values());

		List<CtEngineeringChangeBo > boList3 = ctChangeService.getEcChangeList(projectId);

		List<CtStatisticsBo> resList = new ArrayList<>();
		long total = 0l;
		if(CollectionUtils.isNotEmpty(boList1)){
			total += boList1.size();
		}
		if(CollectionUtils.isNotEmpty(boList2)){
			total += boList2.size();
		}
		if(CollectionUtils.isNotEmpty(boList3)){
			total += boList3.size();
		}
		BigDecimal totalAll =  new BigDecimal(total); // 最后的版本
		BigDecimal c1 =  new BigDecimal(boList1.size()); //
		BigDecimal c2 =  new BigDecimal(boList2.size()); //
		BigDecimal c3 =  new BigDecimal(boList3.size()); //
		BigDecimal res =  c1.divide(totalAll,2, RoundingMode.HALF_UP);
		resList.add(new CtStatisticsBo("需求变更",boList1.size(),res.multiply(new BigDecimal(String.valueOf(100))).longValue()+""));
		res =  c2.divide(totalAll,2, RoundingMode.HALF_UP);
		resList.add(new CtStatisticsBo("计划变更",boList2.size(),res.multiply(new BigDecimal(String.valueOf(100))).longValue()+""));
		res =  c3.divide(totalAll,2, RoundingMode.HALF_UP);
		resList.add(new CtStatisticsBo("工程变更",boList3.size(),res.multiply(new BigDecimal(String.valueOf(100))).longValue()+""));
		return resList;
	}

	/**
	 * 获取单项目工程变更中的报表数据
	 * @param projectId
	 * @return void
	 * @Exception
	 **/
	public  Map<String, Object>  getChangeSummaryDataAll(String projectId) throws Exception{
		Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
		System.out.println("getChangeSummaryDataAll "+project.getProjectNumber());
		List<CtRequireChangeBo> boList1 = ctChangeMapper.getRequiredChangeData(project.getProjectNumber());
		List<CtPlanChangeBo > boList = ctChangeService.getPlanChangeList(projectId);
		Map<String,CtPlanChangeBo> map = new HashMap<>();
		for (CtPlanChangeBo bo:boList) {
			map.put(bo.getChangeDocVid(),bo);
		}
		List<CtPlanChangeBo > boList2 =new ArrayList<>(map.values());
		List<CtEngineeringChangeBo > boList3 = ctChangeService.getEcChangeList(projectId);

		List<String> date1List = new ArrayList<>();
		for(CtRequireChangeBo bo:boList1){
			date1List.add(bo.getChangeTime()); // 文档发起时间
		}
		List<String> date2List = new ArrayList<>();
		for(CtPlanChangeBo bo:boList2){
			date2List.add(bo.getChangeTime()); // 发起时间
		}
		List<String> date3List = new ArrayList<>();
		for(CtEngineeringChangeBo bo:boList3){
			date3List.add(bo.getApplyTime()); // 发起时间
		}

		System.out.println("getEngineeringChangeReportData date1List:"+date1List);
		Map<String, Object> result1Map = assemblyChangeNumber(date1List,project);

		System.out.println("getEngineeringChangeReportData date2List:"+date2List);
		Map<String, Object> result2Map = assemblyChangeNumber(date2List,project);

		System.out.println("getEngineeringChangeReportData date3List:"+date3List);
		Map<String, Object> result3Map = assemblyChangeNumber(date3List,project);

		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("trLegend",result1Map.get("trLegend"));
		resultMap.put("tr1Data", result1Map.get("trData"));
		resultMap.put("tr2Data", result2Map.get("trData"));
		resultMap.put("tr3Data", result3Map.get("trData"));
		System.out.println("getChangeSummaryDataAll resultMap "+resultMap);
		return resultMap;
	}

	// 封装方法
	private Map<String, Object> assemblyChangeNumber(List<String> dateList,Project2 project) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Map<String, Integer> yesMap = new HashMap<>();
		// 需求变更的TR变更中，已变更
		LinkedHashMap<String, Date> trMap = new LinkedHashMap<>(); // TR点的项目计划完成时间
		String ida2a2 = project.getPersistInfo().getObjectIdentifier().getId()+"";
		LinkedList<CtChangeMilestoneBo>  listPlan = ctChangeMapper.getMilestoneList(ida2a2);
		for(CtChangeMilestoneBo bo : listPlan){
			System.out.println("listRequired- tr："+bo.getMileStoneName());
			String tr = CtProjectLogic.getTrName(bo.getMileStoneName());
			Date endTime = bo.getMilestoneTime();
			trMap.put(tr,endTime);
		}
		// 计划偏差值的横轴值
		String[] trLegend = trMap.keySet().toArray(new String[trMap.keySet().size()]); // TR点
		// 计划偏差值的天数数据
		Integer[] trData = new Integer[trLegend.length];
		for(String changeState:dateList){
			Date createTime = simpleDateFormat.parse(changeState);
			String tr = null;
			boolean fal = false;
			for (Map.Entry<String, Date> map:trMap.entrySet()){
				tr = map.getKey();
				Date finishDate = map.getValue();
				if(createTime.getTime()<= finishDate.getTime()){
					fal = true;
					break; // 匹配到最小时间后，跳出TR循环
				}
			}
			if(fal){
				int changeCount = 1;
				if (yesMap.containsKey(tr)){
					Integer count = yesMap.get(tr);
					count += changeCount;
					yesMap.put(tr, count);
				}else {
					// 如果变更次数不为0(版本不为A) 则存入Map中
					yesMap.put(tr, changeCount);
				}
			}
		}
		for(int i = 0; i < trLegend.length; i++){
			String tr = trLegend[i];
			// 初始值
			Integer count1 = yesMap.get(tr);
			if(count1 == null)count1 = 0;
			trData[i] = count1;

			Date date = trMap.get(tr);
			if (date != null) {
				trLegend[i] = tr + "\n" + simpleDateFormat.format(date);
			}
		}
		System.out.println("assemblyChangeNumber trLegend:"+trLegend);
		System.out.println("assemblyChangeNumber trData:"+trData);
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("trLegend",trLegend);
		resultMap.put("trData", trData);
		return resultMap;
	}

	/**
	 * map 按值排序
	 * @param map
	 * @return
	 */
	private Map<String, Integer> mapValue2Sort(Map<String, Integer> map){
		List<Map.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
		list.sort(Map.Entry.comparingByValue());
		Map<String, Integer> sortedMap = new LinkedHashMap<>();
		for(int i=list.size()-1;i>=0;i-- ){
			Map.Entry<String, Integer> entry= list.get(i);
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}

	/**
	 * 获取所有项目计划变更中的报表数据
	 * @return void
	 * @Exception
	 **/
	public static Map<String, Object> getAllPlanChangeReportData() throws Exception{


		// 产更次数TOP5的横轴值
		List<String> changeCountLegend = new ArrayList<>(5);
		// 变更测试TOP5的数据
		List<Integer> changeCountData = new ArrayList<>(5);
		// 变更次数Map
		Map<String, Integer> changeCountMap = new HashMap<>();


		Integer minIndex = changeCountMap.size() > 5 ? changeCountMap.size() - 5 : 0;
		// 按变更次数排序，如变革次数超过5条数，则只拿前5条
		Collection<Integer> values = changeCountMap.values();
		List<Integer> counts = new ArrayList<>(values);
		Collections.sort(counts);
		for (int i = changeCountMap.size() - 1; i >= minIndex; i--){
			for (Map.Entry<String, Integer> item : changeCountMap.entrySet()){
				if (counts.get(i) == item.getValue() && !changeCountLegend.contains(item.getKey())){

					changeCountLegend.add(item.getKey());
					changeCountData.add(item.getValue());
				}
			}
		}


		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("changeCountLegend", changeCountLegend);
		resultMap.put("changeCountData", changeCountData);
		return resultMap;
	}

	/**
	 * 获取适用里程碑阶段图表的横轴刻度
	 * @return
	 * @throws Exception
	 */
	public static String[] getPhaseLegend(Project2 project,String[] phaseLegend,Map<String, Date> trMap) throws Exception{
		for(int i = 0; i < phaseLegend.length; i++) {
			if (trMap.containsKey(phaseLegend[i])) {
				Date actualFinishDate = trMap.get(phaseLegend[i]);
				if (actualFinishDate != null) {
					phaseLegend[i] += "\n" + CtDateUtil.parseDate(actualFinishDate,"yyyy-MM-dd");
				}
			}
		}
		return phaseLegend;
	}
}
