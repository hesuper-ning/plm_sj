package ext.plm.mainPage.change.mapper;

import ext.plm.mainPage.change.bo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@Mapper
public interface CtChangeMapper {

    /**
     * 获取计划变更列表
     * @param projectId
     * @param version 空为查询所有A版本之外的
     * @return
     */
    List<CtPlanChangeBo> getPlanChangeList(@Param("projectId") String projectId, @Param("version") String version);

    /**
     * 获取需求变更列表
     * @param projectId
     * @return
     */
    List<CtRequireChangeBo> getRequiredChangeList(@Param("projectId") String projectId);

    /**
     * 获取需求变更列表
     * @param projectId
     * @return
     */
    List<CtRequireChangeBo> getRequiredChangeData(@Param("projectId") String projectId);



    /**
     * 获取ECR变更列表
     * @param productModel
     * @return
     */
    List<CtEngineeringChangeBo> getEcChangeList(@Param("productModel") String productModel);




    @Select("select PlanActivity.name as milestoneName,PlanActivity.startDate as milestoneTime from wcadmin.PlanActivity " +
            "where PlanActivity.milestone=1 and PlanActivity.idA3containerReference=#{projectId} and PlanActivity.lineNumber!=0 " +
            "order by PlanActivity.lineNumber")
    LinkedList<CtChangeMilestoneBo> getMilestoneList(String projectId);


    /**
     * 查询项目库中的项目变更文档数量
     * @param projectId 项目id 必传
     * @param startTime 开始时间
     * @param endTime 结束时间 必传
     * @param projectChangeDocList 项目变更文档内部名称列表 必传
     * @return 数量
     */
    int getProjectChangeNum(@Param("projectId") String projectId, @Param("startTime") String startTime, @Param("endTime") String endTime, @Param("projectChangeDocList") List<String> projectChangeDocList);

    /**
     * 查询产品库中的更改通告数量
     * @param projectId 项目id 必传
     * @param startTime 开始时间
     * @param endTime 结束书剑 必传
     * @return 数量
     */
    int getEngineeringChangeNum(@Param("projectId") String projectId, @Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 获取项目变更总数
     */
    long getProjectChangeTotal(Map<String, Object> params);

    /**
     * 获取项目变更列表
     */
    List<CtProjectChangeBo> getProjectChangeList(Map<String, Object> params);

    @Select("select PDMLinkProduct.namecontainerInfo from wcadmin.PDMLinkProduct where PDMLinkProduct.markForDeleteA2=0")
    List<String> getAllProductName();

    /**
     * 获取工程变更总数
     */
    long getEngineeringChangeTotal(Map<String, Object> params);

    /**
     * 获取工程变更列表
     */
    List<CtEngineeringChangeBo> getEngineeringChangeList(Map<String, Object> params);
    /**
     * 获取工程变更列表
     */
    List<HashMap<String, Object>> getFatherPartList(Map<String, Object> params);
    /**
     * 获取工程变数据
     */
    List<HashMap<String, Object>> getEcParentPartList(Map<String, Object> params);
}
