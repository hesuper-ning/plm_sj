package ext.plm.mainPage.change.bo;

import java.util.List;
import java.util.Map;

public class CtRequestChangePageBo {
    private Integer total;

    private Integer current;

    private Integer size;

    private Map<String, Object> searchParams;

    private List<CtRequestChangeBo> records;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public List<CtRequestChangeBo> getRecords() {
        return records;
    }

    public void setRecords(List<CtRequestChangeBo> records) {
        this.records = records;
    }

    public Integer getCurrent() {
        return current;
    }

    public void setCurrent(Integer current) {
        this.current = current;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Map<String, Object> getSearchParams() {
        return searchParams;
    }

    public void setSearchParams(Map<String, Object> searchParams) {
        this.searchParams = searchParams;
    }
}
