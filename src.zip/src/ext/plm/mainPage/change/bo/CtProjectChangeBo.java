package ext.plm.mainPage.change.bo;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class CtProjectChangeBo {
    private String projectId,docId,docMasterId,businessObjectRef,containerOid;
    private String projectName;
    private String projectGrade;
    private String projectChangeName;
    private String changeDescription;
    private String changeType;
    private String createUser;
    private String status;
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    private Date createTime;
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    private Date updateTime;

    public String getContainerOid() {
        return containerOid;
    }

    public void setContainerOid(String containerOid) {
        this.containerOid = containerOid;
    }

    public String getBusinessObjectRef() {
        return businessObjectRef;
    }

    public void setBusinessObjectRef(String businessObjectRef) {
        this.businessObjectRef = businessObjectRef;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocMasterId() {
        return docMasterId;
    }

    public void setDocMasterId(String docMasterId) {
        this.docMasterId = docMasterId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectGrade() {
        return projectGrade;
    }

    public void setProjectGrade(String projectGrade) {
        this.projectGrade = projectGrade;
    }

    public String getProjectChangeName() {
        return projectChangeName;
    }

    public void setProjectChangeName(String projectChangeName) {
        this.projectChangeName = projectChangeName;
    }

    public String getChangeDescription() {
        return changeDescription;
    }

    public void setChangeDescription(String changeDescription) {
        this.changeDescription = changeDescription;
    }

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
