package ext.plm.mainPage.change.bo;

public class CtRequireChangeBo {
//	需求变更源->变更类型->变更描述->变更文档编号->版本->变更所属项目阶段->发起时间->发起人->产品型号->
//	流程当前处理人->变更原因->变更说明（可讨论）->变更状态

	//	需求变更源
	private String requireChangeSource;
	//	变更类型
	private String changeType;
	//	变更描述
	private String dsrequireDesc;
	//	发起人
	private String applicant;
	//	产品型号
	private String productModel;
	//	流程当前处理人 todo
	private String processHandler;
	//	变更原因
	private String requireChangeReason;
	//	变更说明
	private String requireChangeDesc;
	//	变更状态
	private String changeState;
	//	变更文档编号
	private String changeDocNum;
	//	版本
	private String docVersion;
	//	变更文档Vid
	private String changeDocVid;
	//	变更原因
	private String changeDesc;
	//	变更所属项目阶段 todo
	private String changePhase;
	//	发起时间
	private String changeTime;

	public String getRequireChangeSource() {
		return requireChangeSource;
	}

	public void setRequireChangeSource(String requireChangeSource) {
		this.requireChangeSource = requireChangeSource;
	}

	public String getChangeType() {
		return changeType;
	}

	public void setChangeType(String changeType) {
		this.changeType = changeType;
	}

	public String getDsrequireDesc() {
		return dsrequireDesc;
	}

	public void setDsrequireDesc(String dsrequireDesc) {
		this.dsrequireDesc = dsrequireDesc;
	}

	public String getApplicant() {
		return applicant;
	}

	public void setApplicant(String applicant) {
		this.applicant = applicant;
	}

	public String getProductModel() {
		return productModel;
	}

	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	public String getProcessHandler() {
		return processHandler;
	}

	public void setProcessHandler(String processHandler) {
		this.processHandler = processHandler;
	}

	public String getRequireChangeReason() {
		return requireChangeReason;
	}

	public void setRequireChangeReason(String requireChangeReason) {
		this.requireChangeReason = requireChangeReason;
	}

	public String getRequireChangeDesc() {
		return requireChangeDesc;
	}

	public void setRequireChangeDesc(String requireChangeDesc) {
		this.requireChangeDesc = requireChangeDesc;
	}

	public String getChangeState() {
		return changeState;
	}

	public void setChangeState(String changeState) {
		this.changeState = changeState;
	}

	public String getChangeDocNum() {
		return changeDocNum;
	}

	public void setChangeDocNum(String changeDocNum) {
		this.changeDocNum = changeDocNum;
	}

	public String getDocVersion() {
		return docVersion;
	}

	public void setDocVersion(String docVersion) {
		this.docVersion = docVersion;
	}

	public String getChangeDocVid() {
		return changeDocVid;
	}

	public void setChangeDocVid(String changeDocVid) {
		this.changeDocVid = changeDocVid;
	}

	public String getChangeDesc() {
		return changeDesc;
	}

	public void setChangeDesc(String changeDesc) {
		this.changeDesc = changeDesc;
	}

	public String getChangePhase() {
		return changePhase;
	}

	public void setChangePhase(String changePhase) {
		this.changePhase = changePhase;
	}

	public String getChangeTime() {
		return changeTime;
	}

	public void setChangeTime(String changeTime) {
		this.changeTime = changeTime;
	}
}
