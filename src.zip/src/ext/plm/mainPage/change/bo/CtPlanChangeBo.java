package ext.plm.mainPage.change.bo;

public class CtPlanChangeBo {
	//	变更文档编号
	private String changeDocNum;
//	A版本的时间
	private String initDate;
//	变更文档Vid
	private String changeDocVid;
//	变更前时间
	private String preChangePlan;
//	变更后时间
	private String postChangePlan;
	//	变更时进度偏差 todo
	private String duringChanges="0%";
	//	偏差天数 todo
	private String duringDays;
	//	变更原因
	private String changeDesc;
//	变更时项目阶段 todo
	private String changePhase;
//	变更时间
	private String changeTime;
//	发起人
	private String promoter;
	//	版本
	private String docVersion;

	public String getInitDate() {
		return initDate;
	}

	public void setInitDate(String initDate) {
		this.initDate = initDate;
	}

	public String getChangeDocNum() {
		return changeDocNum;
	}

	public void setChangeDocNum(String changeDocNum) {
		this.changeDocNum = changeDocNum;
	}

	public String getChangeDocVid() {
		return changeDocVid;
	}

	public void setChangeDocVid(String changeDocVid) {
		this.changeDocVid = changeDocVid;
	}

	public String getPreChangePlan() {
		return preChangePlan;
	}

	public void setPreChangePlan(String preChangePlan) {
		this.preChangePlan = preChangePlan;
	}

	public String getPostChangePlan() {
		return postChangePlan;
	}

	public void setPostChangePlan(String postChangePlan) {
		this.postChangePlan = postChangePlan;
	}

	public String getDuringChanges() {
		return duringChanges;
	}

	public void setDuringChanges(String duringChanges) {
		this.duringChanges = duringChanges;
	}

	public String getChangeDesc() {
		return changeDesc;
	}

	public void setChangeDesc(String changeDesc) {
		this.changeDesc = changeDesc;
	}

	public String getChangePhase() {
		return changePhase;
	}

	public void setChangePhase(String changePhase) {
		this.changePhase = changePhase;
	}

	public String getChangeTime() {
		return changeTime;
	}

	public void setChangeTime(String changeTime) {
		this.changeTime = changeTime;
	}

	public String getPromoter() {
		return promoter;
	}

	public void setPromoter(String promoter) {
		this.promoter = promoter;
	}

	public String getDocVersion() {
		return docVersion;
	}

	public void setDocVersion(String docVersion) {
		this.docVersion = docVersion;
	}

	public String getDuringDays() {
		return duringDays;
	}

	public void setDuringDays(String duringDays) {
		this.duringDays = duringDays;
	}
}
