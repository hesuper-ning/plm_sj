package ext.plm.mainPage.change.bo;

import java.util.Map;

public class CtChangeSummaryBo {
    //阶段名称
    private String gradeName;

    //需求变更数量
    private Integer requestChangeNum;

    //项目变更数量
    private Integer projectChangeNum;

    //工程变更数量
    private Integer engineeringChangeNum;

    //变更总数
    private Integer changeTotal;

    private Map<String, Object> requestChangeNumParams;
    private Map<String, Object> projectChangeParams;
    private Map<String, Object> engineeringChangeParams;

    public Map<String, Object> getRequestChangeNumParams() {
        return requestChangeNumParams;
    }

    public void setRequestChangeNumParams(Map<String, Object> requestChangeNumParams) {
        this.requestChangeNumParams = requestChangeNumParams;
    }

    public Map<String, Object> getProjectChangeParams() {
        return projectChangeParams;
    }

    public void setProjectChangeParams(Map<String, Object> projectChangeParams) {
        this.projectChangeParams = projectChangeParams;
    }

    public Map<String, Object> getEngineeringChangeParams() {
        return engineeringChangeParams;
    }

    public void setEngineeringChangeParams(Map<String, Object> engineeringChangeParams) {
        this.engineeringChangeParams = engineeringChangeParams;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public Integer getRequestChangeNum() {
        return requestChangeNum;
    }

    public void setRequestChangeNum(Integer requestChangeNum) {
        this.requestChangeNum = requestChangeNum;
    }

    public Integer getProjectChangeNum() {
        return projectChangeNum;
    }

    public void setProjectChangeNum(Integer projectChangeNum) {
        this.projectChangeNum = projectChangeNum;
    }

    public Integer getEngineeringChangeNum() {
        return engineeringChangeNum;
    }

    public void setEngineeringChangeNum(Integer engineeringChangeNum) {
        this.engineeringChangeNum = engineeringChangeNum;
    }

    public Integer getChangeTotal() {
        return changeTotal;
    }

    public void setChangeTotal(Integer changeTotal) {
        this.changeTotal = changeTotal;
    }
}
