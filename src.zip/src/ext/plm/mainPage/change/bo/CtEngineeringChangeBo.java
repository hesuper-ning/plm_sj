package ext.plm.mainPage.change.bo;

public class CtEngineeringChangeBo {
    // 变更Vid
    private String changeRequestId;
    // 创建时间
    private String applyTime;
    // 状态
    private String changeState;
    // 发起人
    private String applicant;
    // 受影响成品
    private String affectedEndParts;
    // 受影响BOM
    private String affectedBOMs;
    // 产品型号
    private String productModel;
    // ECR编号
    private String ecrNumber;
    // ECR名称
    private String ecrName;
    // 更改类型
    private String changeType;
    // 变更原因描述
    private String changeReason;
    // 变更来源
    private String changeSource;
    //	流程当前处理人 todo
    private String processHandler;

    public String getChangeRequestId() {
        return changeRequestId;
    }

    public void setChangeRequestId(String changeRequestId) {
        this.changeRequestId = changeRequestId;
    }

    public String getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(String applyTime) {
        this.applyTime = applyTime;
    }

    public String getChangeState() {
        return changeState;
    }

    public void setChangeState(String changeState) {
        this.changeState = changeState;
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant;
    }

    public String getAffectedEndParts() {
        return affectedEndParts;
    }

    public void setAffectedEndParts(String affectedEndParts) {
        this.affectedEndParts = affectedEndParts;
    }

    public String getAffectedBOMs() {
        return affectedBOMs;
    }

    public void setAffectedBOMs(String affectedBOMs) {
        this.affectedBOMs = affectedBOMs;
    }

    public String getProductModel() {
        return productModel;
    }

    public void setProductModel(String productModel) {
        this.productModel = productModel;
    }

    public String getEcrNumber() {
        return ecrNumber;
    }

    public void setEcrNumber(String ecrNumber) {
        this.ecrNumber = ecrNumber;
    }

    public String getEcrName() {
        return ecrName;
    }

    public void setEcrName(String ecrName) {
        this.ecrName = ecrName;
    }

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }

    public String getChangeReason() {
        return changeReason;
    }

    public void setChangeReason(String changeReason) {
        this.changeReason = changeReason;
    }

    public String getChangeSource() {
        return changeSource;
    }

    public void setChangeSource(String changeSource) {
        this.changeSource = changeSource;
    }

    public String getProcessHandler() {
        return processHandler;
    }

    public void setProcessHandler(String processHandler) {
        this.processHandler = processHandler;
    }
}
