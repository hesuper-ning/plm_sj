package ext.plm.mainPage.change.bo;

import java.util.Date;

public class CtChangeMilestoneBo {
    private String mileStoneName;
    private Date milestoneTime;

    public String getMileStoneName() {
        return mileStoneName;
    }

    public void setMileStoneName(String mileStoneName) {
        this.mileStoneName = mileStoneName;
    }

    public Date getMilestoneTime() {
        return milestoneTime;
    }

    public void setMilestoneTime(Date milestoneTime) {
        this.milestoneTime = milestoneTime;
    }
}
