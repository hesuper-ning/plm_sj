package ext.plm.mainPage.change;

import ext.plm.mainPage.bo.CtStatisticsBo;
import ext.plm.mainPage.change.bo.*;
import ext.plm.mainPage.common.CtPageVO;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public interface CtChangeService {
    List<CtPlanChangeBo> getPlanChangeList(String projectId) throws Exception;

    List<CtPlanChangeBo> getPlanChangeListAll(String projectId, String version) throws Exception;

    LinkedHashMap<String,String> getPlanChangeList(String projectId, String version) throws Exception;

    List<CtRequireChangeBo> getRequiredChangeList(String projectId) throws Exception;

    List<CtEngineeringChangeBo> getEcChangeList(String projectId) throws Exception;

    /**
     * 获取计划变更报表数据
     * @param projectId
     * @return
     * @Exception
     **/
    Map<String, Object> getPlanChangeReportData(String projectId) throws Exception;
    /**
     * 获取需求变更报表数据
     * @param projectId
     * @return
     * @Exception
     **/
    Map<String, Object> getRequiredChangeReportData(String projectId) throws Exception;
    /**
     * 获取工程变更报表数据
     * @param projectId
     * @return
     * @Exception
     **/
    Map<String, Object> getEngineeringChangeReportData(String projectId) throws Exception;
    /**
     * 获取变更总汇
     * @param projectId
     * @return
     * @Exception
     **/
    List<CtStatisticsBo> getChangeReportDataAll(String projectId) throws Exception;

    /**
     * 变更管理图表
     * @param projectId
     * @return
     * @Exception
     **/
    Map<String, Object> getChangeSummaryDataAll(String projectId) throws Exception;


    List<CtChangeSummaryBo> getChangeSummaryData(Map<String, Object> params) throws Exception;

    CtRequestChangePageBo getRequestChangeList(Map<String, Object> params) throws Exception;

    CtPageVO<CtProjectChangeBo> getProjectChangeList(Map<String, Object> params) throws Exception;

    List<String> getAllProductName();

    CtPageVO<CtEngineeringChangeBo> getEngineeringChangeList(Map<String, Object> params) throws Exception;
}
