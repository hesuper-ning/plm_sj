package ext.plm.mainPage.change;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.json.JSON;
import cn.hutool.json.JSONUtil;
import com.ptc.projectmanagement.plan.Plan;
import com.ptc.projectmanagement.plan.PlanHelper;
import ext.plm.common.CtConstant;
import ext.plm.mainPage.CtMainPageConstant;
import ext.plm.mainPage.bo.CtStatisticsBo;
import ext.plm.mainPage.change.bo.*;
import ext.plm.mainPage.change.mapper.CtChangeMapper;
import ext.plm.mainPage.common.CtPageVO;
import ext.plm.mainPage.common.enums.CtProjectChangeStatusEnum;
import ext.plm.mainPage.projectManage.mapper.CtProjectManageMapper;
import ext.plm.mainPage.tool.project.CtProjectLogic;
import ext.plm.mainPage.tool.report.workflow.bo.CtWorkflowBo;
import ext.plm.mainPage.util.CtListUtils;
import ext.plm.sampleConfirmation.CtSampleConfirmationQuery;
import ext.plm.util.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeRequest2;
import wt.fc.ObjectReference;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.projmgmt.admin.Project2;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class CtChangeServiceImpl implements CtChangeService {
    @Autowired
    private CtChangeMapper ctChangeMapper;
    @Autowired
    private CtProjectManageMapper ctProjectManageMapper;
    @Autowired
    private CtChangeLogic ctChangeLogic;

    @Override
    public List<CtPlanChangeBo> getPlanChangeList(String projectId) throws Exception {
        Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
        return ctChangeMapper.getPlanChangeList(project.getProjectNumber(),null);
    }
    @Override
    public List<CtPlanChangeBo> getPlanChangeListAll(String projectId,String version) throws Exception {
        Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
        return ctChangeMapper.getPlanChangeList(project.getProjectNumber(),version);
    }
    @Override
    public LinkedHashMap<String,String> getPlanChangeList(String projectId,String version) throws Exception {
        Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
        IBAUtility ibaUtil = new IBAUtility(project);
        // 项目启动时间
        String actualStartDate = ibaUtil.getIBAValue("Ct_MissionStatementID"); // 启动时间、
        Date upDate = null;
        if(StringUtils.isNotEmpty(actualStartDate)) {
            if(StringUtils.isNotBlank(actualStartDate)) {
                upDate = CtDateUtil.parseStringToDate(actualStartDate, "yyyy/MM/dd","GMT+8");
            }
        }else {
            Plan plan = (Plan) PlanHelper.service.getPlan(ObjectReference.newObjectReference(project));
            if (plan != null) {
                Timestamp actualStartDatePlan = plan.getActualStartDate(); // 实际开始时间
                if(actualStartDatePlan!=null) {
                    upDate = new Date(actualStartDatePlan.getTime());
                }
            }
        }
        List<CtPlanChangeBo> listBo = ctChangeMapper.getPlanChangeList(project.getProjectNumber(),version); // 版本
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        LinkedHashMap<String,String> linkedHashMap = new LinkedHashMap<>();
        for(CtPlanChangeBo bo:listBo){
            String day = "0";
            String initDate = bo.getInitDate();
            Date finishTime = simpleDateFormat.parse(initDate);
            if(upDate != null){
                day =  ctChangeLogic.getProjectDelayDays(finishTime,upDate);
            }
            String tr = CtProjectLogic.getTrName(bo.getChangePhase());
            if(StringUtils.isNotEmpty(tr)){
                linkedHashMap.put(tr,day);
                upDate = finishTime;
            }
        }
        return linkedHashMap;
    }

    @Override
    public List<CtRequireChangeBo> getRequiredChangeList(String projectId) throws Exception {
        Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
        System.out.println("getRequiredChangeList "+project.getProjectNumber());
        return ctChangeMapper.getRequiredChangeList(project.getProjectNumber());
    }
    @Override
    public List<CtEngineeringChangeBo> getEcChangeList(String projectId) throws Exception {
        Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
        Set<String> set = new HashSet<>();
        IBAUtility ibaUtil = new IBAUtility(project);
        Vector v = ibaUtil.getIBAValues("Ct_FinishedMaterialCode"); // 项目详细信息中成品信息
        if(null != v && v.size() > 0){
            for(int i = 0;i < v.size();i++){
                String productNumber = (String) v.get(i);
                set.add(productNumber);
            }
        }
        List<String> listPart = new ArrayList<>(set);
        List<CtEngineeringChangeBo> resEngineeringChangeList= new ArrayList<>();
        System.out.println("listPart:"+listPart);
        if(CollectionUtil.isEmpty(listPart)){
            return resEngineeringChangeList;
        }
        List<CtEngineeringChangeBo> engineeringChangeList=ctChangeMapper.getEcChangeList(null);
        //        20250316
        //        1、取工程变更“受影响对象的物料数据”
        //        2、根据物料向上反查（使用情况），一直查到所有的“成品/半成品”。
        //        3、所有成品合并去重，对比“项目库”产成品编码，再取到项目上

        Map<String,CtEngineeringChangeBo> boMap = new HashMap<>();
        for (CtEngineeringChangeBo bo : engineeringChangeList) {
            Set<String> setDb = new HashSet<>();
            if(StringUtils.isNotEmpty(bo.getAffectedEndParts())){
                List<String> list = Arrays.asList(bo.getAffectedEndParts().split(","));
                setDb.addAll(list);
            }
            if(StringUtils.isNotEmpty(bo.getAffectedBOMs())){
                List<String> list = Arrays.asList(bo.getAffectedBOMs().split(","));
                setDb.addAll(list);
            }
            boolean addFal = false;
            if(setDb !=null && setDb.size() > 0){
                List<String> listPartRes = new ArrayList<>(setDb);
                for(String ppartNum:listPart){
                    // 获取所有上阶物料，判断是否与项目IBA中匹配
                    if(listPartRes.contains(ppartNum)){
                        addFal = true;
                        break;
                    }
                }
            }
            if(addFal){
                resEngineeringChangeList.add(bo);
            }else{
                if(CtFormatUtil.hasContent(bo.getChangeRequestId())){
                    boMap.put(bo.getChangeRequestId(),bo);  // 可以稍微去重
                }
            }
//            Date changeCreateTime = bo.getCreateTime();
//            String projectGrade = getChangeProjectGrade(bo.getProjectId(), changeCreateTime);
//            bo.setProjectGrade(projectGrade);
        }
        System.out.println("第一轮条数: "+resEngineeringChangeList.size());
        Map<String, Object> parm = new HashMap<>();
//        parm.put("ecrId", ecrId);
        List<HashMap<String, Object>> allFatherPartList = ctChangeMapper.getEcParentPartList(parm);
        System.out.println("allFatherPartList:"+allFatherPartList.size());
        // 如果有值，就组装
        Set<CtEngineeringChangeBo> boSet = new HashSet<>();
        for (HashMap<String, Object> resMap : allFatherPartList){
            String partNumberValue = resMap.get("PARTNUMBERVALUE")+"";
            String ecrId = resMap.get("ECRID")+"";
            if(StringUtils.isNotBlank(partNumberValue) && StringUtils.isNotBlank(ecrId)){
                boolean falpp=false;
                List<String> list = Arrays.asList(partNumberValue.split(","));
                for(String ppartNum:listPart){
                    if(list.contains(ppartNum)){
                        falpp=true;
                        break;
                    }
                }
                if(falpp){
                    CtEngineeringChangeBo bo = boMap.get(ecrId);
                    if(bo !=null){
                        boSet.add(bo);
                    }
                }
            }
        }
        if(boSet !=null && boSet.size() >0){
            resEngineeringChangeList.addAll(new ArrayList<>(boSet));
        }
        System.out.println("第2轮条数: "+resEngineeringChangeList.size());
        return resEngineeringChangeList;
    }

    // 备份下，逻辑没错，数据多且慢导致不能使用
    public List<CtEngineeringChangeBo> getEcChangeList_blank(String projectId) throws Exception {
        Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectId);
        Set<String> set = new HashSet<>();
        IBAUtility ibaUtil = new IBAUtility(project);
        Vector v = ibaUtil.getIBAValues("Ct_FinishedMaterialCode"); // 项目详细信息中成品信息
        if(null != v && v.size() > 0){
            for(int i = 0;i < v.size();i++){
                String productNumber = (String) v.get(i);
                set.add(productNumber);
            }
        }
        List<String> listPart = new ArrayList<>(set);
        List<CtEngineeringChangeBo> resEngineeringChangeList= new ArrayList<>();
        System.out.println("listPart:"+listPart);
        if(CollectionUtil.isEmpty(listPart)){
            return resEngineeringChangeList;
        }
        List<CtEngineeringChangeBo> engineeringChangeList=ctChangeMapper.getEcChangeList(null);
        //        20250316
        //        1、取工程变更“受影响对象的物料数据”
        //        2、根据物料向上反查（使用情况），一直查到所有的“成品/半成品”。
        //        3、所有成品合并去重，对比“项目库”产成品编码，再取到项目上

        Map<String,CtEngineeringChangeBo> boMap = new HashMap<>();
        for (CtEngineeringChangeBo bo : engineeringChangeList) {
            Set<String> setDb = new HashSet<>();
            if(StringUtils.isNotEmpty(bo.getAffectedEndParts())){
                List<String> list = Arrays.asList(bo.getAffectedEndParts().split(","));
                setDb.addAll(list);
            }
            if(StringUtils.isNotEmpty(bo.getAffectedBOMs())){
                List<String> list = Arrays.asList(bo.getAffectedBOMs().split(","));
                setDb.addAll(list);
            }
            boolean addFal = false;
            if(setDb !=null && setDb.size() > 0){
                List<String> listPartRes = new ArrayList<>(setDb);
                for(String ppartNum:listPart){
                    // 获取所有上阶物料，判断是否与项目IBA中匹配
                    if(listPartRes.contains(ppartNum)){
                        addFal = true;
                        break;
                    }
                }
            }
            if(addFal){
                resEngineeringChangeList.add(bo);
            }else{
                if(CtFormatUtil.hasContent(bo.getChangeRequestId())){
                    boMap.put(bo.getChangeRequestId(),bo);  // 可以稍微去重
                }
            }
//            Date changeCreateTime = bo.getCreateTime();
//            String projectGrade = getChangeProjectGrade(bo.getProjectId(), changeCreateTime);
//            bo.setProjectGrade(projectGrade);
        }
        System.out.println("第一轮条数: "+resEngineeringChangeList.size());
        Map<String,String> strMap = new HashMap<>();
        Set<String> setIdAll = new HashSet<>();
        // 第一步，获取所有的相关对象ID，并且与ecrid对应上
        for(Map.Entry<String,CtEngineeringChangeBo> map : boMap.entrySet()){
            String ecrId = map.getKey();
            CtEngineeringChangeBo bo = map.getValue();
            // 新增逻辑
            WTChangeRequest2 changeRequest = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(ecrId);
            // 获取ECR受影响对象中是否有部件
            // ext.plm.sampleConfirmation.CtSampleConfirmationQuery#queryUsageLink
            QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
            Set<String> setId = new HashSet<>();
            // 收集受影响对象的ID
            while(queryResult.hasMoreElements()){
                Object obj = queryResult.nextElement();
                if(obj instanceof WTPart){
                    WTPart part = (WTPart)obj;
                    Long childPartId = part.getPersistInfo().getObjectIdentifier().getId();
                    setId.add(childPartId+"");
                    strMap.put(childPartId+"", ecrId);
                }
            }
            System.out.println(ecrId+"总数："+setId.size());
            System.out.println(ecrId+"详情："+setId);
            if(setId !=null && setId.size() > 0) {
                setIdAll.addAll(setId);
            }
        }

        // 第二步，批量查询父类，将物料和树形结构拿出来
        Map<String,String> mapRes = new HashMap<>();
        System.out.println("setIdAll:"+setIdAll.size());
        if(setIdAll !=null && setIdAll.size() > 0){
            List<List<String>> groupList = CtListUtils.generateListGroup(new ArrayList<>(setIdAll), 200);
            System.out.println("groupList:"+groupList.size());
            for (List<String> strings : groupList) {
                 // 开始批量查询
                if(strings !=null && strings.size() > 0){
                    Map<String, Object> parm = new HashMap<>();
                    parm.put("partIdList", strings);
                    List<HashMap<String, Object>> allParentList = ctChangeMapper.getFatherPartList(parm);
                    System.out.println("allParentList:"+allParentList.size());
                    // 如果有值，就组装
                    System.out.println("allParentList:"+allParentList.get(0));
                    for (HashMap<String, Object> resMap : allParentList){
                        String parentNumber = resMap.get("PARENTNUMBER")+"";
                        String treePath = resMap.get("TREEPATH")+"";
                        if(StringUtils.isNotBlank(parentNumber) && StringUtils.isNotBlank(treePath)){
                            mapRes.put(parentNumber,treePath);
                        }
                    }
                }
            }
        }
        // 第三步，开始组装，如果项目属性IBA的物料包含上阶物料，就取出相应的ecrid
        if(mapRes !=null && mapRes.size() > 0){
            Set<String> setecId = new HashSet<>();
            for(Map.Entry<String,String> map : mapRes.entrySet()){
                String parentNumber = map.getKey();
                String treePath = map.getValue();
                if(listPart.contains(parentNumber) && StringUtils.isNotBlank(treePath)){
                    List<String> list = Arrays.asList(treePath.split("/"));
                    for(String partId : list){
                        String ecrId = strMap.get(partId);
                        if(StringUtils.isNotBlank(ecrId)){
                            setecId.add(ecrId);
                        }
                    }
                }
            }

            // 第四步，利用第一步的ecrid和第四步的ecrid定位bo
            Set<CtEngineeringChangeBo> boSet = new HashSet<>();
            for(String ecrid:setecId){
                CtEngineeringChangeBo bo = boMap.get(ecrid);
                if(bo !=null){
                    boSet.add(bo);
                }
            }
            if(boSet !=null && boSet.size() >0){
                resEngineeringChangeList.addAll(new ArrayList<>(boSet));
            }
        }

        System.out.println("第2轮条数: "+resEngineeringChangeList.size());
        return resEngineeringChangeList;
    }

    @Override
    public Map<String, Object> getPlanChangeReportData(String projectId) throws Exception {
        Map<String, Object> resultMap = null;
        if (StringUtils.isEmpty(projectId)){
            // 查询所有项目的报表数据
            resultMap = CtChangeLogic.getAllPlanChangeReportData();
        }else {
            // projectId = projectId.contains(":") ? projectId.substring(projectId.lastIndexOf(":") + 1) : projectId;
            resultMap = ctChangeLogic.getSinglePlanChangeReportData(projectId);
        }

        return resultMap;
    }

    @Override
    public Map<String, Object> getRequiredChangeReportData(String projectId) throws Exception {
        Map<String, Object> resultMap = null;
        if (StringUtils.isEmpty(projectId)){
            // 查询所有项目的报表数据
            resultMap = CtChangeLogic.getAllPlanChangeReportData();
        }else {
            resultMap = ctChangeLogic.getSingleRequiredChangeReportData(projectId);
        }
        return resultMap;
    }
    @Override
    public Map<String, Object> getEngineeringChangeReportData(String projectId) throws Exception {
        Map<String, Object> resultMap = ctChangeLogic.getEngineeringChangeReportData(projectId);
        return resultMap;
    }
    @Override
    public List<CtStatisticsBo> getChangeReportDataAll(String projectId) throws Exception {
        List<CtStatisticsBo> resultMap = ctChangeLogic.getChangeReportDataAll(projectId);
        return resultMap;
    }

    @Override
    public Map<String, Object> getChangeSummaryDataAll(String projectId) throws Exception {
        Map<String, Object> resultMap = ctChangeLogic.getChangeSummaryDataAll(projectId);
        return resultMap;
    }


    @Override
    public List<CtChangeSummaryBo> getChangeSummaryData(Map<String, Object> params) throws Exception {
        String projectOid = (String) params.get("projectOid");
        Project2 project2 = (Project2) CtWTObjectUtil.getObjectByOid(projectOid);
        String projectId = CtWTObjectUtil.getId(project2);
        LinkedList<CtChangeMilestoneBo> milestoneList = ctChangeMapper.getMilestoneList(projectId);
        List<CtChangeSummaryBo> resultList = new ArrayList<>();
        String projectNumber = project2.getProjectNumber();
        List<String> projectChangeDocList = Arrays.asList(CtMainPageConstant.projectChangeDoc.split(","));//项目变更文档内部名称列表
        for (int i = 0; i < milestoneList.size(); i++) {
            CtChangeMilestoneBo milestoneBo = milestoneList.get(i);
            Date endTime = milestoneBo.getMilestoneTime();
            String endTimeStr = CtDateUtil.parseDate(endTime, CtConstant.DATE_FORMAT);
            Date startTime = null;
            String startTimeStr = null;
            if (i != 0) {
                CtChangeMilestoneBo previousMilestone = milestoneList.get(i - 1);
                startTime = previousMilestone.getMilestoneTime();
                startTimeStr = CtDateUtil.parseDate(startTime, CtConstant.DATE_FORMAT);
            }
            int requestChangeNum = getRequestChangeNum(startTime, endTime, projectNumber);
            Map<String, Object> map=new HashMap<>();
            map.put("projectId",projectId);
            map.put("startTime",startTime);
            map.put("endTime",endTime);
            int projectChangeNum = (int) ctChangeMapper.getProjectChangeTotal(map);
            int engineeringChangeNum = (int) ctChangeMapper.getEngineeringChangeTotal(map);
            CtChangeSummaryBo e = new CtChangeSummaryBo();
            String mileStoneName = milestoneBo.getMileStoneName();
            e.setGradeName(CtProjectLogic.getTrName(mileStoneName));
            e.setRequestChangeNum(requestChangeNum);
            e.setProjectChangeNum(projectChangeNum);
            e.setEngineeringChangeNum(engineeringChangeNum);
            e.setChangeTotal(requestChangeNum + projectChangeNum + engineeringChangeNum);
            HashMap<String, Object> requestChangeNumParams = new HashMap<>();
            requestChangeNumParams.put("startTime",startTime);
            requestChangeNumParams.put("endTime",endTime);
            requestChangeNumParams.put("projectNumber",projectNumber);
            e.setRequestChangeNumParams(requestChangeNumParams);
            HashMap<String, Object> projectChangeParams = new HashMap<>();
            projectChangeParams.put("projectId",projectId);
            projectChangeParams.put("startTimeStr",startTimeStr);
            projectChangeParams.put("endTimeStr",endTimeStr);
            projectChangeParams.put("projectChangeDocList",projectChangeDocList);
            e.setProjectChangeParams(projectChangeParams);
            HashMap<String, Object> engineeringChangeParams = new HashMap<>();
            engineeringChangeParams.put("projectId",projectId);
            engineeringChangeParams.put("startTimeStr",startTimeStr);
            engineeringChangeParams.put("endTimeStr",endTimeStr);
            e.setEngineeringChangeParams(engineeringChangeParams);
            resultList.add(e);
        }
        return resultList;
    }

    @Override
    public CtRequestChangePageBo getRequestChangeList(Map<String, Object> params) throws Exception {
        Object projectName = params.get("projectName");
        if (CtFormatUtil.hasContent(projectName)) {
            List<String> projectNumberList = ctProjectManageMapper.getProjectNumber((String) projectName);
            params.put("projectNumbers", String.join(",", projectNumberList));
        } else {
            params.put("projectNumbers", "");
        }
        CtRequestChangePageBo requestChangePage = getRmsRequestChangeList(params);
        for (CtRequestChangeBo ctRequestChangeBo : requestChangePage.getRecords()) {
            if (CtFormatUtil.hasContent(ctRequestChangeBo.getItemCode())) {
                Project2 project = CtProjectUtil.getProjectByNumber(ctRequestChangeBo.getItemCode());
                if (project==null) {
                    continue;
                }
                ctRequestChangeBo.setProjectId(CtWTObjectUtil.getId(project));
                Date changeCreateTime = CtDateUtil.parseStringToDate(ctRequestChangeBo.getCreationTime(), CtConstant.DATE_FORMAT, CtConstant.TIMEZONE_FORMAT);
                String changeProjectGrade = getChangeProjectGrade(CtWTObjectUtil.getId(project), changeCreateTime);
                ctRequestChangeBo.setProjectGrade(changeProjectGrade);
            }
        }
        return requestChangePage;
    }

    @Override
    public CtPageVO<CtProjectChangeBo> getProjectChangeList(Map<String, Object> params) throws Exception {
        long total = ctChangeMapper.getProjectChangeTotal(params);
        List<CtProjectChangeBo> projectChangeList = ctChangeMapper.getProjectChangeList(params);
        for (CtProjectChangeBo bo : projectChangeList) {
            bo.setStatus(CtProjectChangeStatusEnum.getDescription(bo.getStatus()));
            String changeProjectGrade = getChangeProjectGrade(bo.getProjectId(), bo.getCreateTime());
            bo.setProjectGrade(changeProjectGrade);
        }
        return new CtPageVO<>(total, projectChangeList);
    }

    @Override
    public List<String> getAllProductName() {
        return ctChangeMapper.getAllProductName();
    }

    @Override
    public CtPageVO<CtEngineeringChangeBo> getEngineeringChangeList(Map<String, Object> params) throws Exception {
        long total=ctChangeMapper.getEngineeringChangeTotal(params);
        List<CtEngineeringChangeBo> engineeringChangeList=ctChangeMapper.getEngineeringChangeList(params);
//        for (CtEngineeringChangeBo bo : engineeringChangeList) {
//            bo.setStatus(CtEngineeringChangeStatusEnum.getDescription(bo.getStatus()));
//            Date changeCreateTime = bo.getCreateTime();
//            String projectGrade = getChangeProjectGrade(bo.getProjectId(), changeCreateTime);
//            bo.setProjectGrade(projectGrade);
//        }
        return new CtPageVO<>(total,engineeringChangeList);
    }

    /**
     * 获取变更时的项目状态
     * 根据项目里程碑判断，变更时间大于前一个里程碑时间，小于当前里程碑时间，则当前里程碑满足条件
     */
    private String getChangeProjectGrade(String projectId, Date changeCreateTime) throws Exception {
        List<String> projectGradeList=new ArrayList<>();
        LinkedList<CtChangeMilestoneBo> milestoneList = ctChangeMapper.getMilestoneList(projectId);
        for (int i = 0; i < milestoneList.size(); i++) {
            CtChangeMilestoneBo milestoneBo = milestoneList.get(i);
            Date endTime = milestoneBo.getMilestoneTime();
            if (i != 0) {
                CtChangeMilestoneBo previousMilestone = milestoneList.get(i - 1);
                Date startTime = previousMilestone.getMilestoneTime();
                if (startTime.compareTo(changeCreateTime)<0&&endTime.compareTo(changeCreateTime)>=0) {
                    String mileStoneName = milestoneBo.getMileStoneName();
                    String projectGrade = CtProjectLogic.getTrName(mileStoneName);
                    projectGradeList.add(projectGrade);
                }
            }else {
                if (endTime.compareTo(changeCreateTime)>=0) {
                    String mileStoneName = milestoneBo.getMileStoneName();
                    String projectGrade = CtProjectLogic.getTrName(mileStoneName);
                    projectGradeList.add(projectGrade);
                }
            }
        }
        return String.join(",",projectGradeList);
    }

    /**
     * 获取RMS需求变更列表
     */
    private CtRequestChangePageBo getRmsRequestChangeList(Map<String, Object> params) throws Exception {
        String url = CtMainPageConstant.getRmsDomain() + "/projectManage/out/getDemandChangeList?name=" + objectHandler(params.get("requestName")) + "&status=" + objectHandler(params.get("requestStatus"))
                + "&creator=" + objectHandler(params.get("createUserId")) + "&itemCodes=" + objectHandler(params.get("projectNumbers")) + "&creationTimeStart=" + objectHandler(params.get("requestCreateTimeGt"))
                + "&creationTimeEnd=" + objectHandler(params.get("requestCreateTimeLt")) + "&updateTimeStart=" + objectHandler(params.get("requestUpdateTimeGt")) + "&updateTimeEnd=" + objectHandler(params.get("requestUpdateTimeLt"))
                + "&page=" + objectHandler(params.get("page")) + "&size=" + objectHandler(params.get("size"));
        System.out.println("rms获取需求变更列表>>>>>>url = " + url);
        String response = HttpRequest.get(url).execute().body();
        System.out.println("rms获取需求变更列表>>>>>>response = " + response);
        JSON parse = JSONUtil.parse(response);
        Object dataObj = parse.getByPath("data");
        if (!"2000".equals(parse.getByPath("code"))) {
            throw new Exception(dataObj.toString());
        }
        return JSONUtil.toBean(dataObj.toString(), CtRequestChangePageBo.class);
    }

    private Object objectHandler(Object object) {
        return CtFormatUtil.hasContent(object) ? object : "";
    }

    /**
     * 获取需求变更数量
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param itemCode  项目编号
     * @return 数量
     */
    private int getRequestChangeNum(Date startTime, Date endTime, String itemCode) throws Exception {
        String url = CtMainPageConstant.getRmsDomain() + "/projectManage/out/getDemandChange?itemCode=" + itemCode;
        if (startTime != null) {
            String startTimeStr = CtDateUtil.parseDate(startTime, CtConstant.DATE_FORMAT, CtConstant.TIMEZONE_FORMAT);
            url += "&startTime=" + startTimeStr;
        }
        if (endTime != null) {
            String endTimeStr = CtDateUtil.parseDate(endTime, CtConstant.DATE_FORMAT, CtConstant.TIMEZONE_FORMAT);
            url += "&endTime=" + endTimeStr;
        }
        System.out.println("rms获取需求变更数量>>>>>>url = " + url);
        String response = HttpRequest.get(url).execute().body();
        System.out.println("rms获取需求变更数量>>>>>>response = " + response);
        JSON parse = JSONUtil.parse(response);
        Object dataObj = parse.getByPath("data");
        if (!"2000".equals(parse.getByPath("code"))) {
            throw new Exception(dataObj.toString());
        }
        return Integer.parseInt(dataObj.toString());
    }
}
