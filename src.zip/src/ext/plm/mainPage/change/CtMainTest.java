package ext.plm.mainPage.change;

import ext.plm.sampleConfirmation.CtSampleConfirmationQuery;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtVersionUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeRequest2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.httpgw.GatewayAuthenticator;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.vc.VersionControlHelper;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.*;
import java.util.stream.Collectors;

public class CtMainTest implements Serializable, RemoteAccess {
	
	private static final long serialVersionUID = 4553392553491855817L;

	public static void main(String[] args) throws Exception {
		if (!RemoteMethodServer.ServerFlag) {
			Class[] cls = { String[].class };
			Object[] obj = { args };
			try {
				RemoteMethodServer server = RemoteMethodServer.getDefault();

				GatewayAuthenticator authenticator = new GatewayAuthenticator();
				authenticator.setRemoteUser("wcadmin");
				server.setAuthenticator(authenticator);

				server.invoke("main", CtMainTest.class.getName(), null, cls, obj);

			} catch (RemoteException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
			return;
		}

		String methodName = args[0]; 
		if ("refreshEcr2Db".equals(methodName)) {
			// windchill ext.plm.mainPage.change.CtMainTest refreshEcr2Db
			refreshEcr2Db();
		}
	}

	public static void refreshEcr2Db() throws Exception{
		String notSaveDocNum="";
		String notErrDocNum="";
		String errDocNum="";
		CtEcrQuery query = new CtEcrQuery();
		Set<WTChangeRequest2> setL = new HashSet<>();
		List<WTChangeRequest2> resultL =query.getEcrIdValues();
		setL.addAll(resultL);
		if(setL == null || setL.size() == 0) {
			throw new Exception("输入的参数有误，没有查询到ECRID");
		}
		System.out.println("PECRID查询总数 ： "+setL.size());
		// ECRID = VR:xxxxx
		CtSampleConfirmationQuery qqq = new CtSampleConfirmationQuery();
		for(WTChangeRequest2 changeRequest :setL) {
			ReferenceFactory rf = new ReferenceFactory();
			String ecrId = rf.getReferenceString(changeRequest);
			try {
				// WTChangeRequest2 changeRequest = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(ecrId);
				if(changeRequest != null) {
					QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
					Set<String> setPartNumner = new HashSet<>();
					// 收集受影响对象的ID
					while(queryResult.hasMoreElements()){
						Object obj = queryResult.nextElement();
						if(obj instanceof WTPart){
							WTPart part = (WTPart)obj;
							Long childPartId = part.getPersistInfo().getObjectIdentifier().getId();
							List<Map<String, String>> resultList = qqq.queryUsageLink(childPartId);
							if(CollectionUtils.isNotEmpty(resultList)){
								for (Map<String, String> resMap : resultList){
									String parentNumber = resMap.get("parentNumber")+"";
									if(StringUtils.isNotBlank(parentNumber)){
										setPartNumner.add(parentNumber+"");
									}
								}
							}
						}
					}
					if(setPartNumner !=null && setPartNumner.size()>0){
						String partNumberValue = "";
						for(String partNo : setPartNumner){
							if(StringUtils.isNotBlank(partNumberValue)){
								partNumberValue+=",";
							}
							partNumberValue+=partNo;
						}
						if(StringUtils.isNotBlank(partNumberValue)){
							query.saveAttribute(partNumberValue,ecrId);
							notErrDocNum +=ecrId+"\\r\\n";
						}else{
							notSaveDocNum +=ecrId+"\\r\\n";
						}
					}else{
						notSaveDocNum +=ecrId+"\\r\\n";
					}
				}else {
					errDocNum +=ecrId+"没找到相应的文档\\r\\n";
				}
			} catch (Exception e) {
				errDocNum +=ecrId+"处理异常";
			}
		}
		System.out.println("notSaveDocNum>>>>>>>\r\n"+notSaveDocNum);
		System.out.println("notErrDocNum>>>>>>>\r\n"+notErrDocNum);
		System.out.println("errDocNum>>>>>>>\r\n"+errDocNum);
	}
	
}
