package ext.plm.mainPage;

import ext.plm.adminTool.configCenter.manager.CtConfigCenterManager;
import ext.plm.adminTool.configCenter.manager.CtPropertyConfig;
import ext.plm.util.CtFormatUtil;

public class CtMainPageConstant {
    private static volatile CtMainPageConstant instance;

    /**
     * 项目变更文档内部名称
     */
    public static final String projectChangeDoc = "cn.emdoor.Em_smxmbg23" +//数码-项目变更（二、三部）
            ",cn.emdoor.Em_smxmbg1" +//数码-项目变更（四部）
            ",cn.emdoor.Em_smxmbg2" +//数码-项目变更（一部）
            ",cn.emdoor.Em_BGXX" +//信息项目变更
            ",cn.emdoor.Em_xmbgyj";//亿境-项目变更

    /**
     * 获取RMS域名
     */
    public static String getRmsDomain() throws Exception {
        CtPropertyConfig ctPropertyConfig = CtConfigCenterManager.getInstance().loadProperty("mainPageRelatedConfig");
        if (ctPropertyConfig == null) {
            throw new Exception("新主页相关配置【mainPageRelatedConfig】不存在，请联系管理员");
        }
        String rmsAddress = ctPropertyConfig.getValue("rmsAddress");
        if (!CtFormatUtil.hasContent(rmsAddress)) {
            throw new Exception("新主页相关配置【mainPageRelatedConfig】中的RMS地址【rmsAddress】不存在，请联系管理员");
        }
        return rmsAddress;
    }
}
