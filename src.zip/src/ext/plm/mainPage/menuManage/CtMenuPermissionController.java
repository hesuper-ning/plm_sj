package ext.plm.mainPage.menuManage;

import ext.plm.common.CtResApiResult;
import ext.plm.mainPage.menuManage.bo.CtDomainBO;
import ext.plm.mainPage.menuManage.bo.CtMenuPermissionLinkVO;
import ext.plm.mainPage.menuManage.service.CtMenuPermissionLinkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 菜单权限控制Controller
 */
@RestController
@RequestMapping("/mainPage/menu/permission")
public class CtMenuPermissionController {
    @Autowired
    private CtMenuPermissionLinkService menuPermissionLinkService;

    /**
     * 删除菜单权限
     */
    @DeleteMapping
    public CtResApiResult deleteMenuPermission(@RequestBody CtDomainBO domain){
        try {
            menuPermissionLinkService.deleteMenuPermission(domain);
            return CtResApiResult.success();
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 添加或更新菜单权限
     */
    @PostMapping
    public CtResApiResult saveMenuPermission(@RequestBody CtMenuPermissionLinkVO menuPermissionLinkVO){
        try {
            menuPermissionLinkService.saveMenuPermission(menuPermissionLinkVO);
            return CtResApiResult.success();
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 查询菜单权限列表
     * @param domain type 用户、组、角色 classname 必传。ext.plm.mainPage.menu.bo.CtMenuPermissionLinkBO#domainType
     */
    @GetMapping("/list")
    public CtResApiResult getMenuPermissionLink(CtDomainBO domain){
        try {
            List<CtMenuPermissionLinkVO> data=menuPermissionLinkService.getMenuPermissionLink(domain);
            return CtResApiResult.success(data);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }
}
