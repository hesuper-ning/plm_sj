package ext.plm.mainPage.menuManage.bo;

import java.util.List;

/**
 * 菜单权限VO
 */
public class CtMenuPermissionLinkVO {
    /**
     * 用户、组、角色ID
     */
    private Long domainId;

    /**
     * 用户、组、角色 classname
     */
    private String domainType;


    /**
     * 显示名称
     */
    private String displayName;


    /**
     * 权限状态 0:未开启 1:开启
     */
    private Integer permissionStatus;

    /**
     *
     */
    private String description;

    private List<Long> menuIdList;

    public Long getDomainId() {
        return domainId;
    }

    public void setDomainId(Long domainId) {
        this.domainId = domainId;
    }

    public String getDomainType() {
        return domainType;
    }

    public void setDomainType(String domainType) {
        this.domainType = domainType;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public Integer getPermissionStatus() {
        return permissionStatus;
    }

    public void setPermissionStatus(Integer permissionStatus) {
        this.permissionStatus = permissionStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Long> getMenuIdList() {
        return menuIdList;
    }

    public void setMenuIdList(List<Long> menuIdList) {
        this.menuIdList = menuIdList;
    }
}
