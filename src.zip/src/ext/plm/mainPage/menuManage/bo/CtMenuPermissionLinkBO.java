package ext.plm.mainPage.menuManage.bo;

import com.baomidou.mybatisplus.annotations.KeySequence;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

/**
 * 菜单权限link BO对象
 */
@TableName("ZMenuPermissionLink")
@KeySequence("ZMenu_seq")
public class CtMenuPermissionLinkBO {
    @TableId(value = "ID", type = IdType.INPUT)
    private Long id;

    /**
     * 用户、组、角色ID
     */
    private Long domainId;

    /**
     * 菜单ID
     */
    private Long menuId;

    /**
     * 用户、组、角色 classname
     */
    private String domainType;

    /**
     * 权限状态 0:未开启 1:开启
     */
    private Integer permissionStatus;

    /**
     * 描述
     */
    private String description;

    public Long getDomainId() {
        return domainId;
    }

    public void setDomainId(Long domainId) {
        this.domainId = domainId;
    }

    public Long getMenuId() {
        return menuId;
    }

    public void setMenuId(Long menuId) {
        this.menuId = menuId;
    }

    public String getDomainType() {
        return domainType;
    }

    public void setDomainType(String domainType) {
        this.domainType = domainType;
    }

    public Integer getPermissionStatus() {
        return permissionStatus;
    }

    public void setPermissionStatus(Integer permissionStatus) {
        this.permissionStatus = permissionStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
