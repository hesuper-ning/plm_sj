package ext.plm.mainPage.menuManage.bo;

import java.util.ArrayList;
import java.util.List;

/**
 * 路由BO对象
 */
public class CtRouterBO {
    private Long id;

    /**
     * 父级菜单ID
     */
    private Long parentId;

    /**
     * 路径
     */
    private String path;

    /**
     * 名称
     */
    private String name;

    /**
     * 组件
     */
    private String component;

    /**
     * 是否隐藏
     */
    private  boolean hidden;

    /**
     * meta
     */
    private CtRouterMetaBO meta;

    /**
     * 子集合
     */
    private List<CtRouterBO> children=new ArrayList<>();

    public CtRouterBO() {
    }

    public CtRouterBO(String path, String name, String component, boolean hidden) {
        this.path = path;
        this.name = name;
        this.component = component;
        this.hidden = hidden;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public CtRouterMetaBO getMeta() {
        return meta;
    }

    public void setMeta(CtRouterMetaBO meta) {
        this.meta = meta;
    }

    public List<CtRouterBO> getChildren() {
        return children;
    }

    public void setChildren(List<CtRouterBO> children) {
        this.children = children;
    }
}
