package ext.plm.mainPage.menuManage.bo;


/**
 * 路由meta BO对象
 */
public class CtRouterMetaBO {

    /**
     * 标题
     */
    private String title;

    /**
     * 图标
     */
    private String icon;

    /**
     * 页面中上方按钮
     */
    private String navbar;

    /**
     * 是否隐藏
     */
    private boolean hidden;

    public CtRouterMetaBO() {
    }

    public CtRouterMetaBO(String title, String icon, boolean hidden) {
        this.title = title;
        this.icon = icon;
        this.hidden = hidden;
    }

    public CtRouterMetaBO(String title, String icon, String navbar, boolean hidden) {
        this.title = title;
        this.icon = icon;
        this.navbar = navbar;
        this.hidden = hidden;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getNavbar() {
        return navbar;
    }

    public void setNavbar(String navbar) {
        this.navbar = navbar;
    }

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

}

