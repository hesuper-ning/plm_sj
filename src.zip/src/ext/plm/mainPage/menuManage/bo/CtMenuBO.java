package ext.plm.mainPage.menuManage.bo;

import com.baomidou.mybatisplus.annotations.*;
import com.baomidou.mybatisplus.enums.IdType;

import java.util.ArrayList;
import java.util.List;

/**
 * 菜单BO
 */
@TableName("ZMenu")
@KeySequence("ZMenu_seq")
public class CtMenuBO {
    /**
     * 主键
     */
    @TableId(value = "ID", type = IdType.INPUT)
    private Long id;

    /**
     * 删除标识 无效
     */
    @TableLogic
    private Integer delFlag;

    /**
     * 菜单名称
     */
    private String menuName;

    /**
     * 路由名称
     */
    private String menuRouterName;

    /**
     * 父级菜单ID
     */
    private Long parentId;

    /**
     * 菜单组件
     */
    private String menuComponent;

    /**
     * 菜单是否显示(0：否，1：是)
     */
    private Integer menuHidden;

    /**
     * 菜单 url
     */
    private String menuPath;

    /**
     * 菜单标题
     */
    private String metaTitle;

    /**
     * 菜单图标
     */
    private String metaIcon;

    /**
     * 是否有子菜单 1 有 0 没有
     */
    private Integer hasSon;

    /**
     * 优先级
     */
    private Integer priority;

    /**
     * 备注
     */
    private String remark;

    /**
     * 是否有权限
     */
    @TableField(exist = false)
    private Boolean isHavePermission;

    /**
     * 子集合
     */
    @TableField(exist = false)
    private List<CtMenuBO> children=new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getMenuRouterName() {
        return menuRouterName;
    }

    public void setMenuRouterName(String menuRouterName) {
        this.menuRouterName = menuRouterName;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getMenuComponent() {
        return menuComponent;
    }

    public void setMenuComponent(String menuComponent) {
        this.menuComponent = menuComponent;
    }

    public Integer getMenuHidden() {
        return menuHidden;
    }

    public void setMenuHidden(Integer menuHidden) {
        this.menuHidden = menuHidden;
    }

    public String getMenuPath() {
        return menuPath;
    }

    public void setMenuPath(String menuPath) {
        this.menuPath = menuPath;
    }

    public String getMetaTitle() {
        return metaTitle;
    }

    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }

    public String getMetaIcon() {
        return metaIcon;
    }

    public void setMetaIcon(String metaIcon) {
        this.metaIcon = metaIcon;
    }

    public Integer getHasSon() {
        return hasSon;
    }

    public void setHasSon(Integer hasSon) {
        this.hasSon = hasSon;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Boolean getHavePermission() {
        return isHavePermission;
    }

    public void setHavePermission(Boolean havePermission) {
        this.isHavePermission = havePermission;
    }

    public List<CtMenuBO> getChildren() {
        return children;
    }

    public void setChildren(List<CtMenuBO> children) {
        this.children = children;
    }
}
