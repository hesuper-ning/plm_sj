package ext.plm.mainPage.menuManage;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONUtil;
import ext.plm.bean.CtBeanFactory;
import ext.plm.mainPage.menuManage.bo.CtMenuBO;
import ext.plm.mainPage.menuManage.mapper.CtMenuMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtJasonUtil;
import wt.httpgw.GatewayAuthenticator;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;

import java.io.File;
import java.io.Serializable;

public class TestMain implements Serializable, RemoteAccess {
    public static void main(String[] args) throws Exception {
        if (!RemoteMethodServer.ServerFlag) {
            Class[] cls = {String[].class};
            Object[] obj = {args};
            try {
                RemoteMethodServer server = RemoteMethodServer.getDefault();
                GatewayAuthenticator authenticator = new GatewayAuthenticator();
                authenticator.setRemoteUser("wcadmin");
                server.setAuthenticator(authenticator);
                server.invoke("main", TestMain.class.getName(), null, cls, obj);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        System.out.println(">>>>>>>>");
        String path = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator + "ext" + File.separator + "plm" + File.separator + "mainPage" + File.separator + "menu";
        String content = CtJasonUtil.jsonFileConvertStr(path + File.separator + "menuInit.json");
        JSONArray objects = JSONUtil.parseArray(content);
        CtMenuMapper menuMapper = CtBeanFactory.newCtBeanFactory().getBean(CtMenuMapper.class);
        menuMapper.delete(null);

        for (Object object : objects) {
            CtMenuBO bo = JSONUtil.toBean(JSONUtil.toJsonStr(object), CtMenuBO.class);
            CtMenuBO t = new CtMenuBO();
            t.setMenuName(bo.getMenuName());
            if (!CtFormatUtil.hasContent(menuMapper.selectOne(t))) {
                Integer insert = menuMapper.insert(bo);
                if (insert == 1) System.out.println("一级菜单 = " + bo.getMenuName());
            }
            Object children = JSONUtil.parse(object).getByPath("children");
            childrenHandle(children, bo, menuMapper);
        }
    }

    private static void childrenHandle(Object children, CtMenuBO parent, CtMenuMapper menuMapper) {
        JSONArray objects = JSONUtil.parseArray(JSONUtil.toJsonStr(children));
        for (Object object : objects) {
            CtMenuBO bo = JSONUtil.toBean(JSONUtil.toJsonStr(object), CtMenuBO.class);
            bo.setParentId(parent.getId());
            CtMenuBO t = new CtMenuBO();
            t.setMenuName(bo.getMenuName());
            if (!CtFormatUtil.hasContent(menuMapper.selectOne(t))) {
                Integer insert = menuMapper.insert(bo);
                if (insert == 1) System.out.println("添加成功：" + JSONUtil.toJsonStr(bo));
            }
            Object children1 = JSONUtil.parse(object).getByPath("children");
            childrenHandle(children1, bo, menuMapper);
        }
    }
}
