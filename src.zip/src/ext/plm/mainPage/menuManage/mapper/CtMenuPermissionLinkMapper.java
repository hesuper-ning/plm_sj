package ext.plm.mainPage.menuManage.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.mainPage.menuManage.bo.CtDomainBO;
import ext.plm.mainPage.menuManage.bo.CtMenuPermissionLinkBO;
import ext.plm.mainPage.menuManage.bo.CtMenuPermissionLinkVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 蔡单权限Mapper
 */
@Mapper
public interface CtMenuPermissionLinkMapper extends BaseMapper<CtMenuPermissionLinkBO> {
    @Select("<script>" +
            "select distinct " +
            "domainTab.idA2A2 as domainId,domainTab.name as displayName,ZMenuPermissionLink.permission_status as permissionStatus," +
            "ZMenuPermissionLink.domain_type as domainType,ZMenuPermissionLink.description " +
            "from ZMenuPermissionLink " +
            "join WTGroup domainTab on ZMenuPermissionLink.domain_id = domainTab.idA2A2 " +
            "where ZMenuPermissionLink.domain_type = #{type} " +
            "<if test=\"displayName!=null and displayName!=''\">" +
            "and domainTab.name like concat('%',concat(#{displayName},'%'))" +
            "</if>" +
            "</script>")
    List<CtMenuPermissionLinkVO> getMenuPermissionLink(CtDomainBO domain);

    @Select("select WTGroup.idA2A2 from WTGroup where WTGroup.disabled=0 and WTGroup.internal=0 and WTGroup.name=#{groupName}")
    Long getGroupId(String groupName);
}
