package ext.plm.mainPage.menuManage.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.mainPage.menuManage.bo.CtMenuBO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 菜单Mapper
 */
@Mapper
public interface CtMenuMapper extends BaseMapper<CtMenuBO> {
}
