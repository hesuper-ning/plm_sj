package ext.plm.mainPage.menuManage;

import ext.plm.common.CtResApiResult;
import ext.plm.mainPage.menuManage.bo.CtDomainBO;
import ext.plm.mainPage.menuManage.bo.CtMenuBO;
import ext.plm.mainPage.menuManage.service.CtMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

/**
 * 菜单Controller
 */
@RestController
@RequestMapping("/mainPage/menu")
public class CtMenuController {
    @Autowired
    private CtMenuService menuService;

    /**
     * 获取组、用户、角色
     */
    @GetMapping("/domain")
    public CtResApiResult getDomain(@RequestParam String type){
        try {
            List<CtDomainBO> data=menuService.getDomain(type);
            return CtResApiResult.success(data);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 删除菜单组件
     */
    @DeleteMapping("/menuComponent")
    public CtResApiResult deleteMenuComponent(@RequestBody List<String> ids){
        try {
            menuService.deleteMenuComponent(ids);
            return CtResApiResult.success();
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 添加菜单组件
     */
    @PostMapping("/menuComponent")
    public CtResApiResult createMenuComponent(@RequestBody CtMenuBO menu){
        try {
            menuService.createMenuComponent(menu);
            return CtResApiResult.success(menu);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 更新菜单组件
     */
    @PutMapping("/menuComponent")
    public CtResApiResult updateMenuComponent(@RequestBody CtMenuBO menu){
        try {
            menuService.updateMenuComponent(menu);
            return CtResApiResult.success(menu);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 查询菜单
     */
    @GetMapping("/list")
    public CtResApiResult getMenu(CtDomainBO domain){
        try {
            List<CtMenuBO> data=menuService.getMenuList(domain);
            return CtResApiResult.success(data);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 获取路由和菜单
     */
    @GetMapping("/routerAndMenu")
    public CtResApiResult getRouterAndMenu() {
        try {
            HashMap<String, Object> data = menuService.getRouterAndMenu();
            return CtResApiResult.success(data);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }
}
