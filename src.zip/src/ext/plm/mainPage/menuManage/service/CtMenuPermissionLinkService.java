package ext.plm.mainPage.menuManage.service;

import ext.plm.mainPage.menuManage.bo.CtDomainBO;
import ext.plm.mainPage.menuManage.bo.CtMenuPermissionLinkVO;

import java.util.List;

/**
 * 菜单权限Service
 */
public interface CtMenuPermissionLinkService {
    List<CtMenuPermissionLinkVO> getMenuPermissionLink(CtDomainBO domain);

    void saveMenuPermission(CtMenuPermissionLinkVO menuPermissionLinkVO);

    void deleteMenuPermission(CtDomainBO domain);
}
