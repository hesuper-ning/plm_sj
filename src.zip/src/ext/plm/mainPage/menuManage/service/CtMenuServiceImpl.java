package ext.plm.mainPage.menuManage.service;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import ext.plm.mainPage.common.constant.CtConstant;
import ext.plm.mainPage.menuManage.bo.*;
import ext.plm.mainPage.menuManage.mapper.CtMenuMapper;
import ext.plm.mainPage.menuManage.mapper.CtMenuPermissionLinkMapper;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.OrgContainer;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.pds.StatementSpec;
import wt.query.*;
import wt.session.SessionHelper;

import java.util.*;

/**
 * 菜单ServiceImpl
 */
@Service
public class CtMenuServiceImpl implements CtMenuService {
    @Autowired
    private CtMenuMapper menuMapper;
    @Autowired
    private CtMenuPermissionLinkMapper menuPermissionLinkMapper;

    @Override
    public HashMap<String, Object> getRouterAndMenu() throws Exception {
        List<CtMenuBO> menuList = getCurrentUserMenu();

        if (CollectionUtils.isEmpty(menuList)) {
            return null;
        }

        HashMap<String, Object> result = new HashMap<>(4);

        //获取根节点菜单
        List<CtMenuBO> rootMenuList = new ArrayList<>();

        for (CtMenuBO ctMenuBO : menuList) {
            if (ctMenuBO.getParentId() == null) {
                rootMenuList.add(ctMenuBO);
            }
        }

        if (CtFormatUtil.hasContent(rootMenuList)) {
            rootMenuList.get(0).setMenuPath("/index");
        }

        //重置首页
        resetHomePage(rootMenuList);

        List<CtRouterBO> routerList = new ArrayList<>();

        //构建树形结构
        for (CtMenuBO rootMenu : rootMenuList) {
            boolean hidden = rootMenu.getMenuHidden() == 1;

            //创建根路由
            CtRouterBO rootRouter = new CtRouterBO(rootMenu.getMenuPath(), rootMenu.getMenuRouterName(), rootMenu.getMenuComponent(), hidden);
            rootRouter.setId(rootMenu.getId());
            rootRouter.setParentId(rootMenu.getParentId());

            //创建路由meta
            CtRouterMetaBO ctRouterMetaBo = new CtRouterMetaBO(rootMenu.getMetaTitle(), rootMenu.getMetaIcon(), hidden);
            rootRouter.setMeta(ctRouterMetaBo);

            createMenuToRouterTree(rootMenu, rootRouter, menuList);
            routerList.add(rootRouter);
        }

        result.put("menus", rootMenuList);
        result.put("routers", routerList);
        return result;
    }

    @Override
    public List<CtMenuBO> getMenuList(CtDomainBO domain) {
        List<CtMenuBO> menuList = getMenuByDomain(Arrays.asList(domain.getId()), domain.getType());
        HashMap<Long, CtMenuBO> permissionMenuMap = new HashMap<>();
        for (CtMenuBO menu : menuList) {
            permissionMenuMap.put(menu.getId(), menu);
        }

        EntityWrapper<CtMenuBO> wrapper = new EntityWrapper<>();
        wrapper.orderBy("priority");
        List<CtMenuBO> list = menuMapper.selectList(wrapper);
        List<CtMenuBO> rootMenuList = new ArrayList<>();
        for (CtMenuBO menu : list) {
            if (menu.getParentId() == null) {
                rootMenuList.add(menu);
            }
            menu.setHavePermission(permissionMenuMap.get(menu.getId()) != null);
        }

        for (CtMenuBO rootMenu : rootMenuList) {
            createMenuTree(rootMenu, list);
        }
        return rootMenuList;
    }

    @Override
    public void updateMenuComponent(CtMenuBO menu) {
        menuMapper.updateById(menu);
    }

    @Transactional
    @Override
    public void createMenuComponent(CtMenuBO menu) {
        menuMapper.insert(menu);
        if (CtFormatUtil.hasContent(menu.getParentId())) {
            CtMenuBO t = new CtMenuBO();
            t.setId(menu.getParentId());
            CtMenuBO ctMenuBO = menuMapper.selectOne(t);
            if (CtFormatUtil.hasContent(ctMenuBO)) {
                ctMenuBO.setHasSon(1);
                menuMapper.updateById(ctMenuBO);
            }
        }
    }

    @Override
    public void deleteMenuComponent(List<String> ids) {
        menuMapper.deleteBatchIds(ids);
    }

    @Override
    public List<CtDomainBO> getDomain(String type) throws Exception {
        ArrayList<CtDomainBO> data = new ArrayList<>();
        if (WTGroup.class.getName().equals(type)) {
            List<WTGroup> list = getAllGroup();
            for (WTGroup group : list) {
                CtDomainBO e = new CtDomainBO();
                e.setId(group.getPersistInfo().getObjectIdentifier().getId());
                e.setType(group.getClass().getName());
                e.setDisplayName(group.getName());
                e.setDescription(group.getDescription());
                e.setCreateTime(group.getCreateTimestamp());
                e.setUpdateTime(group.getModifyTimestamp());
                data.add(e);
            }
        }
        Collections.sort(data, new Comparator<CtDomainBO>() {
            @Override
            public int compare(CtDomainBO o1, CtDomainBO o2) {
                return o2.getCreateTime().compareTo(o1.getCreateTime());
            }
        });
        return data;
    }


    /**
     * 创建菜单树
     */
    private void createMenuTree(CtMenuBO rootMenu, List<CtMenuBO> menuList) {
        //如果有子菜单 进行查询 然后递归
        if (rootMenu.getHasSon() == 1) {
            for (CtMenuBO menu : menuList) {
                if (rootMenu.getId().equals(menu.getParentId())) {
                    rootMenu.getChildren().add(menu);
                    createMenuTree(menu, menuList);
                }
            }
        }
    }

    /**
     * 创建菜单和路由树形结构
     */
    private void createMenuToRouterTree(CtMenuBO rootMenu, CtRouterBO rootRouter, List<CtMenuBO> menuList) {
        //如果有子菜单 进行查询 然后递归
        if (rootMenu.getHasSon() == 1) {
            for (CtMenuBO menu : menuList) {
                if (rootMenu.getId().equals(menu.getParentId())) {
                    boolean hidden = menu.getMenuHidden() == 1;

                    rootMenu.getChildren().add(menu);

                    //创建根路由
                    CtRouterBO router = new CtRouterBO(menu.getMenuPath(), menu.getMenuRouterName(), menu.getMenuComponent(), hidden);
                    router.setId(menu.getId());
                    router.setParentId(menu.getParentId());

                    //创建路由meta
                    CtRouterMetaBO routerMeta = new CtRouterMetaBO(menu.getMetaTitle(), menu.getMetaIcon(), hidden);
                    router.setMeta(routerMeta);

                    rootRouter.getChildren().add(router);
                    createMenuToRouterTree(menu, router, menuList);

                }
            }
        }
    }

    /**
     * 重新设置首页
     */
    private void resetHomePage(List<CtMenuBO> menuList) {
        List<CtMenuBO> homePageList = new ArrayList<>();
        for (CtMenuBO menu : menuList) {
            if (menu.getMenuRouterName().equals(CtConstant.HOME_PAGE_COMPONENT)) {
                homePageList.add(menu);
            }
        }
        if (homePageList.size()==1) {
            CtMenuBO menu = homePageList.get(0);
            menu.setMenuName(CtConstant.HOME_PAGE_MENU_NAME);
            menu.setMetaTitle(CtConstant.HOME_PAGE_MENU_NAME);
        }
    }

    /**
     * 获取当前用户菜单
     */
    private List<CtMenuBO> getCurrentUserMenu() throws Exception {
        WTPrincipal principal = SessionHelper.getPrincipal();

        List<CtMenuBO> menuList = null;
        //判断当前用户是不是管理员
        if (CtUserUtil.isInGroup(principal, "Administrators")) {
            EntityWrapper<CtMenuBO> wrapper = new EntityWrapper<>();
            wrapper.eq("menu_hidden", 0);
            wrapper.orderBy("priority");
            menuList = menuMapper.selectList(wrapper);
        } else {
            List<Long> groupIdList = new ArrayList<>();
            List<String> groupNameList = new ArrayList<>();
            List<WTGroup> allGroup = getAllGroup();
            for (WTGroup group : allGroup) {
                if (group != null && group.isMember(principal)) {
                    groupNameList.add(group.getName());
                    groupIdList.add(group.getPersistInfo().getObjectIdentifier().getId());
                }
            }
            System.out.println("用户>>>>>" + ((WTUser) principal).getFullName() + "所在组>>>>>" + JSON.toJSONString(groupNameList));

            if (CollectionUtils.isNotEmpty(groupIdList)) {
                menuList = getMenuByDomain(groupIdList, WTGroup.class.getName());
            }

            //没有获取到菜单 读取默认组里面的主页权限
            if (CollectionUtils.isEmpty(menuList)) {
                Long id=menuPermissionLinkMapper.getGroupId(CtConstant.DEFAULT_PERMISSION_GROUP);
                if (id == null) throw new Exception("【"+CtConstant.DEFAULT_PERMISSION_GROUP+"】找不到");
                groupIdList.add(id);
                menuList = getMenuByDomain(groupIdList, WTGroup.class.getName());
            }
        }

        return menuList;
    }

    /**
     * 通过组权限获取菜单
     */
    private List<CtMenuBO> getMenuByDomain(List<Long> groupIdList, String domainType) {
        EntityWrapper<CtMenuPermissionLinkBO> wrapper1 = new EntityWrapper<>();
        wrapper1.in("domain_id", groupIdList);
        wrapper1.eq("domain_type", domainType);
        List<CtMenuPermissionLinkBO> links = menuPermissionLinkMapper.selectList(wrapper1);
        List<Long> menuIds = new ArrayList<>();
        for (CtMenuPermissionLinkBO link : links) {
            menuIds.add(link.getMenuId());
        }

        List<CtMenuBO> menus = new ArrayList<>();
        if (CtFormatUtil.hasContent(menuIds)) {
            EntityWrapper<CtMenuBO> wrapper = new EntityWrapper<>();
            wrapper.in("id", menuIds);
            wrapper.orderBy("priority");
            List<CtMenuBO> list = menuMapper.selectList(wrapper);
            menus.addAll(list);
        }
        return menus;
    }

    /**
     * 获取所有组，组织下的
     */
    private List<WTGroup> getAllGroup() throws Exception {
        List<WTGroup> result = new ArrayList<>();

        QuerySpec querySpec = new QuerySpec(WTGroup.class);
        int groupIndex = querySpec.addClassList(WTGroup.class, true);
        int orgContainerIndex = querySpec.appendClassList(OrgContainer.class, false);

        String[] aliases = new String[2];
        aliases[0] = querySpec.getFromClause().getAliasAt(groupIndex);
        aliases[1] = querySpec.getFromClause().getAliasAt(orgContainerIndex);

        CompositeWhereExpression andExpression = new CompositeWhereExpression(LogicalOperator.AND);
        andExpression.append(new SearchCondition(new TableColumn(aliases[0], "idA3containerReference"), "=", new TableColumn(aliases[1], "idA2A2")));
        andExpression.append(new SearchCondition(new TableColumn(aliases[0], "disabled"), "=", ConstantExpression.newExpression(0)));
        andExpression.append(new SearchCondition(new TableColumn(aliases[0], "internal"), "=", ConstantExpression.newExpression(0)));
        andExpression.append(new SearchCondition(new TableColumn(aliases[0], "name"), "<>", ConstantExpression.newExpression("ORG ADMIN")));
        andExpression.append(new SearchCondition(new TableColumn(aliases[1], "namecontainerInfo"), "=", ConstantExpression.newExpression("fhsj")));
        querySpec.appendWhere(andExpression, new int[]{groupIndex, orgContainerIndex});

        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) querySpec);

        while (qr.hasMoreElements()) {
            Object[] objectArray = (Object[]) qr.nextElement();
            WTGroup group = (WTGroup) objectArray[0];
            result.add(group);
        }
        return result;
    }

}
