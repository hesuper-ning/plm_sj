package ext.plm.mainPage.menuManage.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import ext.plm.mainPage.menuManage.bo.CtDomainBO;
import ext.plm.mainPage.menuManage.bo.CtMenuPermissionLinkBO;
import ext.plm.mainPage.menuManage.bo.CtMenuPermissionLinkVO;
import ext.plm.mainPage.menuManage.mapper.CtMenuPermissionLinkMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * 菜单权限关联表业务逻辑层
 */
@Service
public class CtMenuPermissionLinkServiceImpl implements CtMenuPermissionLinkService{
    @Autowired
    private CtMenuPermissionLinkMapper menuPermissionLinkMapper;

    @Override
    public List<CtMenuPermissionLinkVO> getMenuPermissionLink(CtDomainBO domain) {
        return menuPermissionLinkMapper.getMenuPermissionLink(domain);
    }

    @Transactional
    @Override
    public void saveMenuPermission(CtMenuPermissionLinkVO menuPermissionLinkVO) {
        List<CtMenuPermissionLinkBO> menuPermissionLinkList=new ArrayList<>();
        for (Long menuId : menuPermissionLinkVO.getMenuIdList()) {
            CtMenuPermissionLinkBO ctMenuPermissionLinkBO = new CtMenuPermissionLinkBO();
            BeanUtils.copyProperties(menuPermissionLinkVO,ctMenuPermissionLinkBO);
            ctMenuPermissionLinkBO.setMenuId(menuId);
            menuPermissionLinkList.add(ctMenuPermissionLinkBO);
        }

        //删除原来的权限
        EntityWrapper<CtMenuPermissionLinkBO> wrapper = new EntityWrapper<>();
        wrapper.eq("domain_id",menuPermissionLinkVO.getDomainId());
        wrapper.eq("domain_type",menuPermissionLinkVO.getDomainType());
        menuPermissionLinkMapper.delete(wrapper);

        //添加新的权限
        for (CtMenuPermissionLinkBO ctMenuPermissionLinkBO : menuPermissionLinkList) {
            menuPermissionLinkMapper.insert(ctMenuPermissionLinkBO);
        }
    }

    @Override
    public void deleteMenuPermission(CtDomainBO domain) {
        EntityWrapper<CtMenuPermissionLinkBO> wrapper = new EntityWrapper<>();
        wrapper.eq("domain_id",domain.getId());
        wrapper.eq("domain_type",domain.getType());
        menuPermissionLinkMapper.delete(wrapper);
    }
}
