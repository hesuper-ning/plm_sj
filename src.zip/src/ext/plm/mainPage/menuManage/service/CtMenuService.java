package ext.plm.mainPage.menuManage.service;

import ext.plm.mainPage.menuManage.bo.CtDomainBO;
import ext.plm.mainPage.menuManage.bo.CtMenuBO;

import java.util.HashMap;
import java.util.List;

/**
 * 菜单Service
 */
public interface CtMenuService {
    HashMap<String, Object> getRouterAndMenu() throws Exception;

    List<CtMenuBO> getMenuList(CtDomainBO domain);

    void updateMenuComponent(CtMenuBO menu);

    void createMenuComponent(CtMenuBO menu);

    void deleteMenuComponent(List<String>  ids);

    List<CtDomainBO> getDomain(String type) throws Exception;
}
