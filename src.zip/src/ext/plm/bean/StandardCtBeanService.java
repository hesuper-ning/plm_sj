package ext.plm.bean;

import wt.services.StandardManager;
import wt.util.WTException;

import java.lang.reflect.Method;

/**
 * @author liangzh
 */
public class StandardCtBeanService extends StandardManager implements CtBeanService {

    private static final long serialVersionUID = 6165172776780355043L;

    public static StandardCtBeanService newStandardCtBeanService() throws WTException {
        StandardCtBeanService instance = new StandardCtBeanService();
        instance.initialize();
        return instance;
    }


    @Override
    public Object doMethod(Class clazz, String methodName, Object[] args) throws Exception {
        CtBeanFactory beanFactory = CtBeanFactory.newCtBeanFactory();
        Object bean = beanFactory.getBean(clazz);
        Method method ;
        if (args!=null){
            Class<?>[] parameterTypes = new Class<?>[args.length];
            for (int i = 0; i < args.length; i++) {
                parameterTypes[i] = args[i].getClass();
            }
            method=bean.getClass().getMethod(methodName,parameterTypes);
        }else{
            method=bean.getClass().getMethod(methodName,null);
        }


        Object invoke = method.invoke(bean, args);
        return invoke;
    }
}
