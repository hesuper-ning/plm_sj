package ext.plm.bean;

import ext.plm.util.CtFileUtil;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import wt.util.WTProperties;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;

/**
 * @author liangzh
 */
public class CtMultipartResolver extends CommonsMultipartResolver {


    @Override
    public boolean isMultipart(HttpServletRequest request) {
        //防止与OOTB的请求冲突
        String includeUrl = "customUpload";
        if (request.getRequestURI().contains(includeUrl)) {
            System.out.println(">>>>>>>>>>>>>>>>>>"+request.getMethod());
            //上传的临时文件做清理
            WTProperties wtproperty = null;
            try {
                wtproperty = WTProperties.getLocalProperties();
                String uploadPath = wtproperty.getProperty("wt.home") + "/codebase/ext/uploadTemp/";

                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                CtFileUtil.deleteFileByTime(uploadDir,7*24*60*60*1000);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return super.isMultipart(request);
        }else{
            return false;
        }

    }
}
