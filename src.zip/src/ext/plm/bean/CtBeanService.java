package ext.plm.bean;

import wt.method.RemoteInterface;

/**
 * @author liangzh
 */
@RemoteInterface
public interface CtBeanService {

    Object doMethod(Class clazz, String methodName, Object[] args) throws Exception;
}
