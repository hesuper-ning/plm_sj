package ext.plm.bean;

import org.springframework.context.ApplicationContext;

/**
 * @author liangzh
 */
public class CtBeanFactory {

    private volatile static CtBeanFactory beanFactory = null;

    private static ApplicationContext context;

    public static CtBeanFactory newCtBeanFactory() {
        if (beanFactory == null) {
            synchronized (CtBeanFactory.class) {
                if (beanFactory == null) {
                    beanFactory = new CtBeanFactory();
                }
            }
        }
        return beanFactory;
    }

    private CtBeanFactory(){

    }

    public void setApplicationContext(ApplicationContext context) {
        this.context = context;
    }

    public <T> T getBean(Class<? extends T> clazz) {
        long currentTimeMillis = System.currentTimeMillis();
        //存在系统启动时 队列先执行 spring容器未加载情况，增加循环等待spring容器启动
        while (context==null){
            if (System.currentTimeMillis()-currentTimeMillis>5*60*1000){
                break;
            }
        }
        return context.getBean(clazz);
    }
}
