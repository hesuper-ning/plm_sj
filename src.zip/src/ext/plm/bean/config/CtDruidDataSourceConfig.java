package ext.plm.bean.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;
import java.sql.SQLException;

/**
 * 数据库连接配置
 * @author liangzh
 */
@Configuration
public class CtDruidDataSourceConfig {

    /**
     * 创建druid数据库连接池bean
     * @return
     */
    @Bean
    @Primary
    public DataSource dataSource(){
        CtDataSourceProperty property = new CtDataSourceProperty();

        DruidDataSource datasource = new DruidDataSource();
        datasource.setUrl(property.getDbUrl());
        datasource.setUsername(property.getUsername());
        datasource.setPassword(property.getPassword());
        datasource.setDriverClassName(property.getDriverClassName());
        datasource.setInitialSize(property.getInitialSize());
        datasource.setMinIdle(property.getMinIdle());
        datasource.setMaxActive(property.getMaxActive());
        datasource.setMaxWait(property.getMaxWait());
        datasource.setTimeBetweenEvictionRunsMillis(property.getTimeBetweenEvictionRunsMillis());
        datasource.setMinEvictableIdleTimeMillis(property.getMinEvictableIdleTimeMillis());
        datasource.setTestWhileIdle(property.isTestWhileIdle());
        datasource.setTestOnBorrow(property.isTestOnBorrow());
        datasource.setTestOnReturn(property.isTestOnReturn());
        datasource.setPoolPreparedStatements(property.isPoolPreparedStatements());
        datasource.setMaxPoolPreparedStatementPerConnectionSize(property.getMaxPoolPreparedStatementPerConnectionSize());

        try {
            datasource.setFilters(property.getFilters());
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("数据库连接创建失败>>>>>>>>>"+e.getMessage());
        }

        datasource.setConnectionProperties(property.getConnectionProperties());

        return datasource;
    }

}
