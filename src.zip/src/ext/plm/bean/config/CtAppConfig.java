package ext.plm.bean.config;

import com.baomidou.mybatisplus.entity.GlobalConfiguration;
import com.baomidou.mybatisplus.enums.DBType;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.incrementer.OracleKeyGenerator;
import com.baomidou.mybatisplus.plugins.PaginationInterceptor;
import com.baomidou.mybatisplus.plugins.pagination.optimize.JsqlParserCountOptimize;
import com.baomidou.mybatisplus.spring.MybatisSqlSessionFactoryBean;
import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.*;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.io.IOException;

/**
 *  spring bean管理配置bean
 *  @author liangzh
 */
@Configuration
@ComponentScan(basePackages = "ext",excludeFilters={@ComponentScan.Filter(type = FilterType.ANNOTATION, value= {Controller.class, RestController.class})})
@EnableAspectJAutoProxy
@EnableScheduling
@MapperScan(basePackages = "ext",annotationClass = Mapper.class)
public class CtAppConfig {

    /**
     * 创建mybatis-plus 全局配置bean
     * @return
     */
    @Bean
    @Primary
    public GlobalConfiguration globalConfiguration(){
        GlobalConfiguration globalConfiguration = new GlobalConfiguration();
        globalConfiguration.setDbType(DBType.ORACLE.getDb());
        globalConfiguration.setIdType(IdType.INPUT.getKey());
        globalConfiguration.setKeyGenerator(new OracleKeyGenerator());
        return globalConfiguration;
    }

    /**
     * 创建mybatis-plus mybatis会话工厂bean
     * @param dataSource
     * @param globalConfiguration
     * @return
     */
    @Bean
    @Primary
    public MybatisSqlSessionFactoryBean mybatisSqlSessionFactoryBean(DataSource dataSource, GlobalConfiguration globalConfiguration){
        MybatisSqlSessionFactoryBean mybatisSqlSessionFactoryBean = new MybatisSqlSessionFactoryBean();

        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

        mybatisSqlSessionFactoryBean.setDataSource(dataSource);
        try {
            mybatisSqlSessionFactoryBean.setMapperLocations(resolver.getResources("classpath:ext/**/**/*Mapper.xml"));
            mybatisSqlSessionFactoryBean.setConfigLocation(resolver.getResource("classpath:ext/plm/bean/config/mybatis-config.xml"));
            mybatisSqlSessionFactoryBean.setGlobalConfig(globalConfiguration);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return mybatisSqlSessionFactoryBean;
    }

    /**
     * 创建数据库事务管理bean
     * @param dataSource
     * @return
     */
    @Bean
    @Primary
    public DataSourceTransactionManager dataSourceTransactionManager(DataSource dataSource){
        DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager();
        dataSourceTransactionManager.setDataSource(dataSource);

        return dataSourceTransactionManager;
    }


    /**
     * 分页插件bean
     * @return
     */
    @Bean
    @Primary
    public PaginationInterceptor paginationInterceptor() {
        PaginationInterceptor paginationInterceptor = new PaginationInterceptor();

        paginationInterceptor.setSqlParser(new JsqlParserCountOptimize());
        return paginationInterceptor;
    }


}
