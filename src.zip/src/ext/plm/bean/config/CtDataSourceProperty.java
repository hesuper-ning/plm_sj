package ext.plm.bean.config;

import ext.plm.common.CtConstant;

import java.io.InputStreamReader;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * 数据库连接配置信息
 * @author liangzh
 */
public class CtDataSourceProperty {

    private String dbUrl;
    private String username;
    private String password;
    private String driverClassName;
    private int initialSize;
    private int minIdle;
    private int maxActive;
    private int maxWait;
    private int timeBetweenEvictionRunsMillis;
    private int minEvictableIdleTimeMillis;
    private boolean testWhileIdle;
    private boolean testOnBorrow;
    private boolean testOnReturn;
    private boolean poolPreparedStatements;
    private int maxPoolPreparedStatementPerConnectionSize;
    private String filters;
    private String connectionProperties;

    public CtDataSourceProperty(){

        init();
    }

    private void init() {
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            String host = inetAddress.getHostName();

            String suffix="";

            if (host.contains("plmlocal")){
                suffix="local";
            }else if ( CtConstant.isTestEnv()){
                suffix="demo";
            }else if (CtConstant.isPrdEnv()){
                suffix="prd";
            }

            Properties properties = new Properties();
            properties.load(new InputStreamReader(
                    this.getClass().getResourceAsStream("db-"+suffix+".properties"), StandardCharsets.UTF_8));

            this.dbUrl=properties.getProperty("dbUrl");
            this.username=properties.getProperty("username");
            this.password=properties.getProperty("password");
            this.driverClassName=properties.getProperty("driverClassName");
            this.initialSize=Integer.parseInt(properties.getProperty("initialSize"));
            this.minIdle=Integer.parseInt(properties.getProperty("minIdle"));
            this.maxActive=Integer.parseInt(properties.getProperty("maxActive"));
            this.maxWait=Integer.parseInt(properties.getProperty("maxWait"));
            this.timeBetweenEvictionRunsMillis=Integer.parseInt(properties.getProperty("timeBetweenEvictionRunsMillis"));
            this.minEvictableIdleTimeMillis=Integer.parseInt(properties.getProperty("minEvictableIdleTimeMillis"));
            this.testWhileIdle=Boolean.parseBoolean(properties.getProperty("testWhileIdle"));
            this.testOnBorrow=Boolean.parseBoolean(properties.getProperty("testOnBorrow"));
            this.testOnReturn=Boolean.parseBoolean(properties.getProperty("testOnReturn"));
            this.poolPreparedStatements=Boolean.parseBoolean(properties.getProperty("poolPreparedStatements"));
            this.maxPoolPreparedStatementPerConnectionSize=Integer.parseInt(properties.getProperty("maxPoolPreparedStatementPerConnectionSize"));
            this.filters=properties.getProperty("filters");
            this.connectionProperties=properties.getProperty("connectionProperties");
        }catch (Exception e){
            e.printStackTrace();
            System.err.println("获取数据库链接配置信息失败>>>>>>>>>>>>>"+e.getMessage());
        }
    }

    public String getDbUrl() {
        return dbUrl;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getDriverClassName() {
        return driverClassName;
    }

    public int getInitialSize() {
        return initialSize;
    }

    public int getMinIdle() {
        return minIdle;
    }

    public int getMaxActive() {
        return maxActive;
    }

    public int getMaxWait() {
        return maxWait;
    }

    public int getTimeBetweenEvictionRunsMillis() {
        return timeBetweenEvictionRunsMillis;
    }

    public int getMinEvictableIdleTimeMillis() {
        return minEvictableIdleTimeMillis;
    }

    public boolean isTestWhileIdle() {
        return testWhileIdle;
    }

    public boolean isTestOnBorrow() {
        return testOnBorrow;
    }

    public boolean isTestOnReturn() {
        return testOnReturn;
    }

    public boolean isPoolPreparedStatements() {
        return poolPreparedStatements;
    }

    public int getMaxPoolPreparedStatementPerConnectionSize() {
        return maxPoolPreparedStatementPerConnectionSize;
    }

    public String getFilters() {
        return filters;
    }

    public String getConnectionProperties() {
        return connectionProperties;
    }
}
