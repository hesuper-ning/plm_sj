package ext.plm.certification;

import cn.hutool.core.io.FileUtil;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.plm.adTool.CtAdToolLogic;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bean.CtBeanService;
import ext.plm.certification.bo.*;
import ext.plm.certification.config.CtCertfProperties;
import ext.plm.certification.mapper.CtCertificationMapper;
import ext.plm.certification.mapper.CtDocumentPassBoMapper;
import ext.plm.certification.mapper.CtRecertfOrEofMapper;
import ext.plm.ec.CtEcLogic;
import ext.plm.integration.sap.CtSapServiceImpl;
import ext.plm.part.bo.CtMViewExportBo;
import ext.plm.part.bo.CtPartExtendInfo;
import ext.plm.tool.bo.CtWTMailBo;
import ext.plm.tool.mail.CtMailTool;
import ext.plm.tool.part.CtPartCodingBo;
import ext.plm.tool.part.CtPartTool;
import ext.plm.tool.poi.CtExportModelTool;
import ext.plm.util.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.content.*;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.*;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContainer;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.pom.Transaction;
import wt.project.Role;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.team.Team;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.VersionControlHelper;
import wt.vc.baseline.BaselineHelper;
import wt.vc.baseline.ManagedBaseline;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipOutputStream;

public class CtCertificationLogis {

    private volatile static CtCertificationLogis instance = null;

    public static CtCertificationLogis getInstance() {
        if (instance == null) {
            synchronized (CtCertificationLogis.class) {
                if (instance == null) {
                    instance = new CtCertificationLogis();
                }
            }
        }
        return instance;
    }

    private  static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);

    private static CtCertificationMapper certificationMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationMapper.class);

    public static String getFileNameAndUpload(String temppath, HttpServletRequest request) throws Exception {
        String branchId = request.getParameter("branchId");
        String type = request.getParameter("type");
        String id = request.getParameter("id");
        String fileName = "";
        File fpath = new File(temppath);
        if (!fpath.exists()) {
            InetAddress inetAddress = InetAddress.getLocalHost();
            String host = inetAddress.getHostName(); // 获取本地的主机名
            if (!host.contains("tan") && !host.contains("plmlocal")) {
                Runtime.getRuntime().exec("chmod 777 -R " + temppath);
            }
            fpath.getParentFile().mkdirs();//创建父级文件路径
            fpath.mkdirs();//创建文件
        }
        //定时清理文件
        long delete = 720 * 3600 * 3000;
        //CtFileUtil.deleteFileByTime(fpath, delete);

        File file = null;
        DiskFileItemFactory fac = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(fac);
        List<FileItem> fileItems = new ArrayList<FileItem>();
        fileItems = upload.parseRequest(request);// 获取附件
        Iterator<FileItem> it = fileItems.iterator();
        while (it.hasNext()) {
            FileItem item = (FileItem) it.next();
            fileName = item.getName();
            fileName = getFileNewName(branchId, type, id, fileName);
            File tFile = new File(fileName); // 借助此File获得不带本地路径的文件名
            fileName = tFile.getName();
            tFile = null; // 释放
            fileName = fileName.replace(" ", "");
            System.out.println(">>>>>>temppath + fileName = " + temppath + fileName);
            file = new File(temppath + File.separator + fileName);

            boolean newFile = file.createNewFile();//创建新的文件至服务器目录
            System.out.println(">>>>newFile = " + newFile);
            item.write(file);//把文件写入file
            System.out.println(file.createNewFile());
        }
        return fileName;
    }

    /**
     * 拼接新名称
     * @param branchId
     * @param type
     * @param id
     * @param oldName
     * @return
     * @throws Exception
     */
    public static String getFileNewName(String branchId, String type, String id, String oldName) throws Exception {
        StringBuilder newName = new StringBuilder();
        String uploadType = "";
        if(!CtFormatUtil.hasContent(oldName)){
            throw new Exception("文件名不能为空！");
        }
        String prefix = oldName.substring(0, oldName.lastIndexOf("."));
        String suffix = oldName.substring(oldName.lastIndexOf(".")+ 1);
        if("applyFile".equals(type)){
            //命名规则：认证类型.产品型号.产品名称.送检类型.送检文件类型.打印档.YYYYMMDD.文件格式
            uploadType = "产品送检申请文件.打印档";
        }
        if("skillFile".equals(type)){
            //命名规则：认证类型.产品型号.产品名称.送检类型.送检文件类型.打印档.YYYYMMDD.文件格式
            uploadType = "产品送检技术文件.打印档";
        }
        if("scanSkillFile".equals(type)){
            //命名规则：认证类型.产品型号.产品名称.送检类型.盖章档.YYYYMMDD.文件格式
            uploadType = "盖章档";
        }
        if("其他文件".equals(type)){
            //命名规则：认证类型.产品型号.产品名称.送检类型.送检文件类型(加说明).YYYYMMDD.文件格式
            uploadType = "获证所需其他文件(" + prefix + ")";
        }
        if("baseLine".equals(type)){
            //命名规则：认证类型.产品型号.产品名称.送检类型.送检文件类型.YYYYMMDD.文件格式
            uploadType = "产品送检齐套技术文件";
        }

        //时间戳
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String dateString = dateFormat.format(new Date());
        //查询认证信息
        CtCertificationQuery query = new CtCertificationQuery();
        Map<String, String> map = query.getCertificationInfoByFileItemId(branchId, id);
        //认证类型
        String certificationType = map.get("certificationType");
        //产品型号
        String productType = map.get("productType");
        //产品名称
        String productName = map.get("productName");
        //送检类型
        String inspectType = map.get("inspectType");
        if(!CtFormatUtil.hasContent(certificationType) || !CtFormatUtil.hasContent(productType) ||
                !CtFormatUtil.hasContent(productName) || !CtFormatUtil.hasContent(inspectType)){
            throw new Exception("自动重命名失败，对应的认证类型、产品型号、产品名称、送检类型不能为空！");
        }
        newName.append(certificationType).append(".")
                .append(productType).append(".")
                .append(productName).append(".")
                .append(inspectType).append(".")
                .append(uploadType).append(".")
                .append(dateString).append(".")
                .append(suffix);
        return newName.toString().replace("/","_");
    }

    public static void deleteFile(File file) {
        if (file.exists()) {// 判断文件是否存在
            if (file.isFile()) {// 判断是否是文件
                file.delete();// 删除文件
            } else if (file.isDirectory()) {// 否则如果它是一个目录
                File[] files = file.listFiles();// 声明目录下所有的文件 files[];
                for (int i = 0; i < files.length; i++) {// 遍历目录下所有的文件
                    deleteFile(files[i]);// 把每个文件用这个方法进行迭代
                }
//					file.delete();// 删除文件夹
            }
        } else {
            System.out.println(file.getAbsolutePath() + "====所删除的文件不存在");
        }
    }

    /**
     * 删除文档附件
     * @param branchId
     * @throws Exception
     */
    public static void deleteFiles(String branchId, String fileName)throws Exception {
        ReferenceFactory rf = new ReferenceFactory();
        String docVr = "VR:wt.doc.WTDocument:" + branchId;
        WTDocument doc = (WTDocument) rf.getReference(docVr).getObject();
        // 单个主要内容  ContentRoleType.PRIMARY  附件 ContentRoleType.SECONDARY
        QueryResult qr = ContentHelper.service.getContentsByRole(doc, ContentRoleType.SECONDARY);
        while(qr !=null && qr.hasMoreElements()){
            ContentItem item = (ContentItem) qr.nextElement();
            if (item instanceof ApplicationData) {
                ApplicationData appData = (ApplicationData)item;
                System.out.println("Attachment File: " + appData.getFileName());
                String appDataFileName =appData.getFileName();
                if(CtFormatUtil.hasContent(appDataFileName) && appDataFileName.equals(fileName)) {
                    appData = (ApplicationData)PersistenceHelper.manager.delete(appData);
                }
            }
        }
        PersistenceHelper.manager.refresh(doc);
    }

    public static Map<String, String> uploadFiles(File localFile, String branchId, String text_name, String node, String type, String id)
            throws Exception {
        Map<String, String> map = new HashMap<>();
        String docUrl = "";
        String docVr = "VR:wt.doc.WTDocument:" + branchId;
        WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
        if(null != doc){
            //设置附件
            ApplicationData appData = ApplicationData.newApplicationData(doc);
            appData.setRole(ContentRoleType.SECONDARY);// 附件位置
            appData = ContentServerHelper.service.updateContent(doc, appData, localFile.getAbsolutePath());
            appData = (ApplicationData) PersistenceHelper.manager.save(appData);
            String fileNameAppOld = appData.getFileName();
            String fileNameApp = CtEcLogic.urlStr2Ascii(fileNameAppOld); // 特殊字符处理
            docUrl = " <a title='删除该附件' href='javascript:;' class =\"" + node + "\" style ='color:red;text-decoration:none;' " +
                    "onclick='deleteFilefield(\"" + branchId + "\",\"" + fileNameApp + "\",\"" + text_name + "\",\"" + node + "\",\"" + type + "\",\"" + id + "\")'>☒</a>";
            docUrl += "<a href=\"/Windchill/ptc1/certf/downLoadDoc?" + "&fileName=" + fileNameApp + "&branchId=" + branchId + "&type=" + type + "\" " +
                    "title=\"点击下载\" target=\"_blank\" >" + fileNameApp + "</a>";
            map.put("docUrl", docUrl);
            map.put("fileName", fileNameApp);
        }
        return map;
    }

    /**
     * 取得applicationData
     * @param branchId
     * @param fileName
     * @return
     * @throws Exception
     */
    public static ApplicationData getApplicationData(String branchId,String fileName) throws Exception {
        ReferenceFactory rf = new ReferenceFactory();
        String docVr = "VR:wt.doc.WTDocument:" + branchId;
        WTDocument doc = (WTDocument) rf.getReference(docVr).getObject();
        if(null != doc) {
            // 单个主要内容  ContentRoleType.PRIMARY  附件 ContentRoleType.SECONDARY
            QueryResult qr = ContentHelper.service.getContentsByRole(doc, ContentRoleType.SECONDARY);
            while(qr !=null && qr.hasMoreElements()){
                ContentItem item = (ContentItem) qr.nextElement();
                if (item instanceof ApplicationData) {
                    ApplicationData appData = (ApplicationData)item;
                    System.out.println("Attachment File: " + appData.getFileName());
                    String appDataFileName =appData.getFileName();
                    if(CtFormatUtil.hasContent(appDataFileName) && appDataFileName.equals(fileName)) {
                        return appData;
                    }
                }
            }
        }
        return null;
    }

    /**
     * 自动存档
     */
    public static void archive(String branchId) throws Exception {
        // 开启事务
        Transaction transaction = new Transaction();


        InputStream inputStream = null;
        ZipEntry zipEntry;
        WTProperties wtproperty = WTProperties.getLocalProperties();
        String filePath = "";//wtproperty.getProperty("wt.home") + File.separator + "CtFile" + File.separator + "certification" + File.separator  + branchId + File.separator + type + File.separator;// 临时路经
        CtCertificationQuery query = new CtCertificationQuery();

        try {
            transaction.start();

            List<CtCertificationFileItemBo> fileItemInfo = certificationMapper.getFileItemInfo(branchId);

            for (CtCertificationFileItemBo itemBo : fileItemInfo) {
                WTDocument doc = null;
                File file = null;
                if (CtFormatUtil.hasContent(itemBo.getApplyFilePath())) {
                    String attachmentName = getFileNameByPath(itemBo.getApplyFilePath());
                    doc = createDoc("com.fhsj.Doc_cpsjsqwj", itemBo.getDocBranchId(), itemBo.getTagId(), itemBo.getApplyFilePath(), attachmentName);
                }
                if (CtFormatUtil.hasContent(itemBo.getScanSkillFilePath()) && CtFormatUtil.hasContent(itemBo.getSkillFilePath())) {
                    //如两个技术文件都不为空  压缩为一个文件
                    filePath = wtproperty.getProperty("wt.home") + File.separator + "CtFile" + File.separator + "certification" + File.separator + branchId + File.separator + "技术文件";// 临时路经

                    filePath = compressSkillFile(filePath, itemBo);

                    doc = createDoc("com.fhsj.Doc_cpsjjswj", itemBo.getDocBranchId(), itemBo.getTagId(), filePath);
                } else if (CtFormatUtil.hasContent(itemBo.getScanSkillFilePath())) {
                    String attachmentName = getFileNameByPath(itemBo.getScanSkillFilePath());
                    doc = createDoc("com.fhsj.Doc_cpsjjswj", itemBo.getDocBranchId(), itemBo.getTagId(), itemBo.getScanSkillFilePath(), attachmentName);
                } else if (CtFormatUtil.hasContent(itemBo.getSkillFilePath())) {
                    String attachmentName = getFileNameByPath(itemBo.getSkillFilePath());
                    doc = createDoc("com.fhsj.Doc_cpsjjswj", itemBo.getDocBranchId(), itemBo.getTagId(), itemBo.getSkillFilePath(), attachmentName);
                }
                if (CtFormatUtil.hasContent(itemBo.getElseFilePath())) {
                    String attachmentName = getFileNameByPath(itemBo.getElseFilePath());
                    doc = createDoc("com.fhsj.Doc_hzsxqtwj", itemBo.getDocBranchId(), itemBo.getTagId(), itemBo.getElseFilePath(), attachmentName);
                }
                if (CtFormatUtil.hasContent(itemBo.getBaseLineNumber())) {
                    filePath = wtproperty.getProperty("wt.home") + File.separator + "CtFile" + File.separator + "certification" + File.separator + branchId + File.separator + "基线文件";// 临时路经
                    byte[] buf = new byte[1024];

                    File fpath = new File(filePath);
                    if (!fpath.exists()) {
                        InetAddress inetAddress = InetAddress.getLocalHost();
                        String host = inetAddress.getHostName(); // 获取本地的主机名
                        if (!host.contains("tan") && !host.contains("plmlocal")) {
                            Runtime.getRuntime().exec("chmod 777 -R " + filePath);
                        }
                        fpath.getParentFile().mkdirs();//创建父级文件路径
                        fpath.mkdirs();//创建文件
                    }

                    CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
                    List<Persistable> persistables = ctAdToolLogic.getPersistableByColumnName(ManagedBaseline.class, "BaselineNumber", itemBo.getBaseLineNumber());
                    ManagedBaseline managedBaseline = (ManagedBaseline) persistables.get(0);

                    //自动重命名
                    String newFileName = getFileNewName(branchId, "baseLine", itemBo.getId()+"", managedBaseline.getName()+ ".zip");

                    filePath = filePath + File.separator + newFileName;
                    file = new File(filePath);
                    ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(file));
                    //重复文件标识
                    int flag = 1;
                    ApplicationData primaryContent = null;
                    for (Persistable persistable : persistables) {
                        managedBaseline = (ManagedBaseline) persistable;
                        QueryResult queryResult = BaselineHelper.service.getBaselineItems(managedBaseline);
                        while (queryResult.hasMoreElements()) {
                            Object object = queryResult.nextElement();
                            if (object instanceof WTDocument || object instanceof EPMDocument) {
                                if(object instanceof WTDocument){
                                    WTDocument document = (WTDocument) object;
                                    primaryContent = CtDocUtil.getPrimaryContent(document);
                                    if (!CtFormatUtil.hasContent(primaryContent)) {
                                        continue;
                                    }
                                    inputStream = ContentServerHelper.service.findContentStream(primaryContent);
                                }
                                if(object instanceof EPMDocument){
                                    EPMDocument epm = (EPMDocument) object;
                                    primaryContent = CtEPMDocUtil.getPrimaryContent(epm);
                                    if (!CtFormatUtil.hasContent(primaryContent)) {
                                        continue;
                                    }
                                    if (primaryContent.getFileName().contains("$CAD_NAME")) {
                                        primaryContent.setFileName(epm.getCADName());
                                    }
                                    inputStream = ContentServerHelper.service.findContentStream(primaryContent);
                                }
                                if(null == inputStream){
                                    continue;
                                }

                                // 处理单个文件
                                try {
                                    String fileName = primaryContent.getFileName();
                                    String replace = fileName.replace(" ", "");
                                    zipEntry = new ZipEntry(replace);
                                    zipOutputStream.putNextEntry(zipEntry);
                                    IOUtils.copy(inputStream, zipOutputStream);
                                } catch (ZipException e) {
                                    e.getMessage();
                                    String localizedMessage = e.getLocalizedMessage();
                                    System.out.println(localizedMessage);
                                    if (localizedMessage.contains("duplicate entry")){
                                        String fileName = primaryContent.getFileName();
                                        int i = fileName.lastIndexOf(".");
                                        String substring = fileName.substring(0, i);
                                        String substring1 = fileName.substring(i, fileName.length());
                                        fileName = substring+"("+flag+")"+substring1;
                                        String replace = fileName.replace(" ", "");
                                        zipEntry = new ZipEntry(replace);
                                        zipOutputStream.putNextEntry(zipEntry);
                                        IOUtils.copy(inputStream, zipOutputStream);
                                        flag++;
                                    }
                                    //throw new Exception(e.getMessage());
                                }
                                int len;

                                while ((len = inputStream.read(buf)) > 0) {
                                    zipOutputStream.write(buf, 0, len);
                                }


                                inputStream.close();
                                zipOutputStream.closeEntry();
                            }
                        }


                        zipOutputStream.close();

                    }
                    doc = createDoc("com.fhsj.Doc_cpsjqtjswj", itemBo.getDocBranchId(), itemBo.getTagId(), filePath);
                }
            }
            transaction.commit();
        } catch (Exception e) {
            if(transaction != null)transaction.rollback();
            e.printStackTrace();
            throw new Exception(e.getLocalizedMessage());
        } finally {
            transaction = null;
        }
    }

    /**
     * 压缩技术文件
     *
     * @param filePath
     * @param itemBo
     * @throws IOException
     */
    private static String compressSkillFile(String filePath, CtCertificationFileItemBo itemBo) throws Exception {
        File file;
        InputStream inputStream;
        ZipEntry zipEntry;
        String branchId = itemBo.getDocBranchId();
        try {
            File fpath = new File(filePath);
            if (!fpath.exists()) {
                InetAddress inetAddress = InetAddress.getLocalHost();
                String host = inetAddress.getHostName(); // 获取本地的主机名
                if (!host.contains("tan") && !host.contains("plmlocal")) {
                    Runtime.getRuntime().exec("chmod 777 -R " + filePath);
                }
                fpath.getParentFile().mkdirs();//创建父级文件路径
                fpath.mkdirs();//创建文件
            }

            file = new File(itemBo.getSkillFilePath());
            String replace = file.getName().replace(" ", "");
            filePath = filePath + File.separator + replace.substring(0, replace.lastIndexOf(".")) + ".zip";
            String fileName = getFileNameByPath(itemBo.getSkillFilePath());
            ApplicationData appData = getApplicationData(branchId, fileName);
            if(appData != null) {
                //获取文件输入流
                inputStream = ContentServerHelper.service.findContentStream(appData);
            }else{
                inputStream = new FileInputStream(file);
            }
            // 处理单个文件
            ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(filePath));

            zipEntry = new ZipEntry("打印档" + File.separator + replace);
            zipOutputStream.putNextEntry(zipEntry);
            IOUtils.copy(inputStream, zipOutputStream);

            file = new File(itemBo.getScanSkillFilePath());
            String fileName1 = getFileNameByPath(itemBo.getScanSkillFilePath());
            ApplicationData appData1 = getApplicationData(branchId, fileName1);
            if(appData1 != null) {
                //获取文件输入流
                inputStream = ContentServerHelper.service.findContentStream(appData1);
            }else{
                inputStream = new FileInputStream(file);
            }
            replace = file.getName().replace(" ", "");
            zipEntry = new ZipEntry("扫描档" + File.separator + replace);
            zipOutputStream.putNextEntry(zipEntry);
            IOUtils.copy(inputStream, zipOutputStream);

            int temp = 0;
            while ((temp = inputStream.read()) != -1) {
                zipOutputStream.write(temp);
            }
            zipOutputStream.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e.getMessage());
        }
        return filePath;
    }

    public static String getFileNameByPath(String filePath) throws Exception {
        if(CtFormatUtil.hasContent(filePath) && filePath.contains("/")){
            return filePath.substring(filePath.lastIndexOf("/")+1);
        }
        return "";
    }

    private static WTDocument createDoc(String docType, String docBranchId, String tagId, String path) throws Exception {
        return createDoc(docType, docBranchId, tagId, path, "");
    }

    private static WTDocument createDoc(String docType, String docBranchId, String tagId, String path, String attachmentName) throws Exception {
        String prefix = "";
        if (docType.equalsIgnoreCase("com.fhsj.Doc_cpsjsqwj")) {
            prefix = "010";
        } else if (docType.equalsIgnoreCase("com.fhsj.Doc_cpsjjswj")) {
            prefix = "011";
        } else if (docType.equalsIgnoreCase("com.fhsj.Doc_hzsxqtwj")) {
            prefix = "012";
        } else if (docType.equalsIgnoreCase("com.fhsj.Doc_cpsjqtjswj")) { //"com.fhsj.Doc_cpsjqtjswj"
            prefix = "013";
        }
        WTUser administrator = (WTUser) CtUserUtil.getAdministrator();
        SessionHelper.manager.setAdministrator();//设置管理员权限
        WTDocument doc = new WTDocument();
        try {
            //获取认证送检文件信息
            CtCertificationItemBo certificationItemBo = certificationMapper.getCertfInfoByTagId(tagId, docBranchId);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
            String format = dateFormat.format(new Date());

            String number = certificationItemBo.getCertfType() + "." + certificationItemBo.getProductType() + "." + certificationItemBo.getInspectType();
            CtCertificationMapper certificationMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationMapper.class);
            //根据前缀获取最大编码
            String maxDocNumber = certificationMapper.queryMaxDocNumber(number, prefix);
            String substring = "";
            //判断是否是最新
            if (CtFormatUtil.hasContent(maxDocNumber) && !certificationItemBo.getInspectType().equals("变更确认检验")) {

                CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
                doc = CtDocUtil.getDocumentByNumber(maxDocNumber);
                doc = (WTDocument) ctAdToolLogic.doReviseObject(doc, "RELEASED", true);

                System.out.println(">>>>>>>>>>>修订" + docType);
            } else {

                String docNumber = getDocNumber(number + "." + format + "." + prefix + ".", prefix);

                WTContainer obj = CtCommonUtil.getContainerByName("A25_产品送检文件");


                // 开始创建文档
                PersistableAdapter persistableAdapter = new PersistableAdapter(docType, null, null);
                persistableAdapter.load("name", "containerReference", "folder.id",
                        "iterationInfo.creator", "iterationInfo.modifier", "state.state");
                persistableAdapter.set("name", docNumber);
                //persistableAdapter.set("number", docNumber);
                persistableAdapter.set("containerReference", obj);
                persistableAdapter.set("folder.id", obj.getDefaultCabinet());
                persistableAdapter.set("iterationInfo.creator", administrator);
                persistableAdapter.set("iterationInfo.modifier", administrator);
                persistableAdapter.set("state.state", State.RELEASED);

                doc = (WTDocument) persistableAdapter.apply();
                doc = (WTDocument) PersistenceHelper.manager.save(doc);

                System.out.println(docType + "创建");
            }

            IBAUtil ibaUtil = new IBAUtil(doc);
            //设置属性值
        /*跟踪表发起年月	ct_Tracetable
        认证类型	ct_Authenticationtype
        产品型号	fhsj_publicProperty
        送检类型	ct_Inspectionsent*/
            WTDocument document = CtDocUtil.getDocumentByBranchId(certificationItemBo.getDocBranchId());

            IBAUtil ibaUtil1 = new IBAUtil(document);
            String value = ibaUtil1.getIBAValue("ct_ItemNumber");

            String createDate = dateFormat.format(document.getCreateTimestamp());
            ibaUtil.setIBAValue("ct_ItemNumber", value);
            ibaUtil.setIBAValue("ct_Tracetable", createDate);
            ibaUtil.setIBAValue("ct_Authenticationtype", certificationItemBo.getCertfType());
            ibaUtil.setIBAValue("ct_productModel", certificationItemBo.getProductType());
            ibaUtil.setIBAValue("ct_Inspectionsent", certificationItemBo.getInspectType());
            ibaUtil.setIBAValue("ct_Submissionaudit", document.getNumber());

            ibaUtil.updateIBAHolder(doc);
            InputStream inputStream;
            File file = new File(path);

            //有存在附件中，则从文档附件中取，为兼容历史流程，有些还是从临时目录取文件
            if(CtFormatUtil.hasContent(attachmentName)){
                ApplicationData appData = getApplicationData(docBranchId, attachmentName);
                if(appData != null) {
                    //获取文件输入流
                    inputStream = ContentServerHelper.service.findContentStream(appData);
                }else{
                    inputStream = new FileInputStream(file);
                }
            }else{
                inputStream = new FileInputStream(file);
            }

            CtAdToolLogic.getInstance().uploadContentToDocument(doc, ContentRoleType.PRIMARY, file.getName(), inputStream);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e.getLocalizedMessage());
        }
        return doc;
    }

    /**
     * 生成标识id
     *
     * @return
     * @throws Exception
     */
    private static String getDocNumber(String numberPrefix, String tag) throws Exception {
        CtCertificationMapper certificationMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationMapper.class);
        String number = "";
        try {

            String substring = numberPrefix.substring(numberPrefix.length() - 12);
            substring = numberPrefix.substring(0, numberPrefix.indexOf(substring));
            //根据前缀获取最大编码
            number = certificationMapper.queryMaxDocNumber(substring, tag);


            //判断是否是最新
            if (!CtFormatUtil.hasContent(number)) {
                return number = numberPrefix + "01";
            }
            System.out.println(">>>>>>>>>numberPrefix---" + numberPrefix + "---number" + number);
            WTDocument document = CtDocUtil.getDocumentByNumber(number);
            CtPartCodingBo ctPartCodingBo = new CtPartCodingBo();
            ctPartCodingBo.setSequenceLength(2);
            ctPartCodingBo.setCodePrefix(numberPrefix);
            ctPartCodingBo.setCurrentMaxCode(document.getName());

            number = CtPartTool.genPartCode(ctPartCodingBo);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e.getLocalizedMessage());
        }
        return number;
    }

    /**
     * 发送认证证书有效期即将过期提醒
     * 1. 有效期在30天内过期的
     * 2.邮件发送给“产品认证组”
     *
     * @throws Exception
     */
    public static void sendCertfDocExpireNoticeMail() throws Exception {
        CtCertificationMapper certificationMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationMapper.class);
        List<HashMap<String, String>> docList = certificationMapper.queryExpireCertfDoc();

        List<HashMap<String, String>> filteredList = new ArrayList<HashMap<String, String>>();

        String docNumber = "";
        String version = "";
        WTDocument doc = null;
        //过滤掉正在续证的
        for (HashMap<String, String> record : docList) {
            docNumber = record.get("docNumber");
            version = record.get("version");
            doc = CtDocUtil.getDocumentByNumber(docNumber);
            String latestVer = doc.getVersionIdentifier().getValue();
            //只有最新大版本和查询出的一致时才添加，不一致说明快过期的版本已经修订，正在续证
            /*if(latestVer.equalsIgnoreCase(version)) {*/
            filteredList.add(record);
            /*}*/
        }

        String validDate = "";
        if (filteredList.size() > 0) {
            System.out.println("开始准备发送邮件");
            //开始准备发邮件
            StringBuffer tableBody = new StringBuffer();
            tableBody.append("您好,您在PLM系统中有如下认证证书将在270天内失效，请及时进行更新:<br><br>")
                    .append("<table border=1 cellspacing=0 cellpadding=5 bgcolor='#000000'><tr bgcolor='#D8D8D8'>")
                    .append("<th>序号</th><th>文档编号</th><th>文档名称</th><th>有效日期</th><th>创建人</th>")
                    .append("</tr>");
            int i = 0;
            for (HashMap<String, String> record : filteredList) {
                i++;
                docNumber = record.get("docNumber");
                doc = CtDocUtil.getDocumentByNumber(docNumber);
                version = record.get("version");
                validDate = record.get("validDate");
                String linkUrl = CtFormatUtil.getURL(doc, docNumber);
                System.out.println(linkUrl);
                tableBody.append("<tr bgcolor='#FFFFFF'><td align='center'>").append(i).append("</td>")
                        .append("<td>").append(linkUrl).append("</td>")
                        .append("<td>").append(doc.getName()).append("</td>")
                        .append("<td>").append(validDate).append("</td>")
                        .append("<td>").append(doc.getCreatorFullName()).append("</td>")
                        .append("</tr>");
            }
            tableBody.append("</table>");
            tableBody.append("<br><br>此邮件为系统自动发送,请勿回复,谢谢!<br>");
            tableBody.append("<br>Best Regards<br>");
            tableBody.append("===========================================================");
            tableBody.append("<br>泛海三江PLM项目组<br><br>").append(CtDateUtil.getCurrentDate());
            tableBody.append("<br>");
            tableBody.append("===========================================================");

            //从用户组中取邮件列表
            List<WTUser> users = CtUserUtil.getMembersInGroup("认证工程师");
            String[] toMails = new String[users.size()];
            int index = 0;
            for (WTUser user : users) {
                toMails[index] = user.getEMail();
                index++;
            }

            CtWTMailBo mailBo = new CtWTMailBo();
            mailBo.setSubject("PLM系统--认证证书过期提醒");
            mailBo.setFrom(CtUserUtil.getAdministrator());
            mailBo.setToMails(toMails);
            mailBo.setContent(tableBody.toString());
            CtMailTool.sendWTMail(mailBo);
            /*System.out.println("准备发送");
            CtMailConfigBo mailConfig = new CtMailConfigBo();
            mailConfig.setHost("smtp.exmail.qq.com");
            mailConfig.setUserName("plm@fhsjdz.com");
            mailConfig.setPassword("Fan@321");
            mailConfig.setFrom("plm@fhsjdz.com");
            mailConfig.setDebug(true);

            List<String> list = new ArrayList<String>();
            list.add("lyxivg@163.com");*/
            //CtMailTool.sendMail("PLM系统--认证证书过期提醒", tableBody.toString(), list,mailConfig);
            //service.testSendMail("PLM系统--认证证书过期提醒", tableBody.toString(), list,mailConfig);
            System.out.println(">>>>邮件发送成功！");
        }

    }

    /**
     * 导入
     *
     * @param proOid 当前对象oid
     * @param file   导入文件
     * @return
     * @throws Exception
     */
    public void importRecertfAssess(String proOid, File file, String number) throws Exception {
        CtSapServiceImpl ctSapService = CtBeanFactory.newCtBeanFactory().getBean(CtSapServiceImpl.class);
        CtCertificationQuery query = new CtCertificationQuery();
        Workbook wb = WorkbookFactory.create(file);
        Sheet sheet = wb.getSheetAt(0);
        String result = "";
        int lastRowNum = sheet.getLastRowNum();
        String MaterialCode = "";
        String id = query.getSequence(number);
        //收集错误信息
        String msg = "";
        for (int i = 1; i <= lastRowNum; i++) {

            MaterialCode = CtExcelReadUtil.getCellValue(sheet, i, 0);

            if (!CtFormatUtil.hasContent(MaterialCode)) {
                continue;
            }

            WTPart part = CtPartUtil.getPartByNumber(MaterialCode);
            if (!CtFormatUtil.hasContent(part)) {
                throw new WTException("第" + i + "行没有这个编码的物料");
            }
            String partType = CtWTObjectUtil.getTypeIdentifier(part);
            String partTypeLastName = partType.substring(partType.lastIndexOf(".") + 1);
            if ("1".equals(number)) {
                /*if (!partTypeLastName.contains("ct_fhsjSpecialMaterials")) {
                    throw new WTException("第" + i + "行物料不是专用物料");
                }*/

                //获取库存

                //ctSapService.getPartStorage(part.getNumber());
                query.updateAttById("ZRecertfOrEofSpecialItem", id, "materialName", part.getName());
                query.updateAttById("ZRecertfOrEofSpecialItem", id, "unit", part.getDefaultUnit().getDisplay(Locale.CHINA));

                query.certfInsertAttById("ZRecertfOrEofSpecialItem", proOid);
                query.updateAttById("ZRecertfOrEofSpecialItem", id, "specialMaterialCode", MaterialCode);
            } else if ("2".equals(number)) {
               /* if (!partTypeLastName.contains("ct_fhsjiallyPreparedProducts")) {
                    throw new WTException("第" + i + "行物料不是半成品");
                }*/

                //ctSapService.getPartStorage(part.getNumber());
                query.updateAttById("ZRecertfOrEofSpecialItem", id, "materialName", part.getName());
                query.updateAttById("ZRecertfOrEofSpecialItem", id, "unit", part.getDefaultUnit().getDisplay(Locale.CHINA));

                query.certfInsertAttById("ZRecertfOrEofSemiItem", proOid);
                query.updateAttById("ZRecertfOrEofSemiItem", id, "semiMaterialCode", MaterialCode);
            }
        }
    }

    /**
     * sod转换：1-10转换成对应胡A~J
     */
    private static String transformSOD(String value, boolean flag) {
        String real = "";
        String[] split = value.split("-");
        for (String s : split) {
            switch (s) {
                case "1":
                    real += "A";
                    break;
                case "2":
                    real += "B";
                    break;
                case "3":
                    real += "C";
                    break;
                case "4":
                    real += "D";
                    break;
                case "5":
                    real += "E";
                    break;
                case "6":
                    real += "F";
                    break;
                case "7":
                    real += "G";
                    break;
                case "8":
                    real += "H";
                    break;
                case "9":
                    real += "I";
                    break;
                case "10":
                    real += "J";
                    break;
                default:
                    break;
            }
        }
        if (flag && value.length() <= 1) {
            real += real;
        }
        return real;

    }


    public static boolean isNumeric(final String str) {
        // null or empty
        if (str == null || str.length() == 0) {
            return false;
        }
        return str.chars().allMatch(Character::isDigit);
    }

    public static void szRelevanceFinished(String importDocFilePath) throws Exception {
        File filePath = new File(importDocFilePath);
        if (filePath == null) {
            throw new Exception("路径或文件错误！找不到此路径或文件：" + importDocFilePath);
        }

        try {
            InputStream is = FileUtil.getInputStream(filePath);
            //List<List<Object>> allRows = excelReader.read(2, excelReader.getRowCount());
            // System.out.println(">>>>读取行数："+allRows.size());
            Workbook workbook = null;

            workbook = new XSSFWorkbook(is);
            Sheet sheet1 = workbook.getSheetAt(0);
            int n = 0;
            Row row = sheet1.getRow(n);
            CtMViewExportBo exportRecord = null;
            while (row != null) {
                System.out.println(n + "行开始");
                exportRecord = new CtMViewExportBo();
                String number = CtExcelReadUtil.getCellValue(sheet1, n, 0);//J列
                if (!CtFormatUtil.hasContent(number)) {
                    n++;
                    row = sheet1.getRow(n);
                    continue;
                }
                WTDocument doc = CtDocUtil.getDocumentByNumber(number);
                IBAUtil ibaUtil = new IBAUtil(doc);
                ;
                CtRecertfOrEofMapper eofMapper = CtBeanFactory.newCtBeanFactory().getBean(CtRecertfOrEofMapper.class);
                //如果是修改先拿出上一个版本的相关文档删除
                QueryResult queryResult = VersionControlHelper.service.allVersionsOf(doc.getMaster());

                if (queryResult.size() > 1) {
                    queryResult.nextElement();
                    WTDocument document = (WTDocument) queryResult.nextElement();

                    Map<String, List<String>> differentAttrs = CtWTObjectUtil.getDifferentAttrs(doc, document);
                    if (differentAttrs == null || !(differentAttrs.containsKey("型号") || differentAttrs.containsKey("认证类型"))) {
                        return;
                    }

                    IBAUtility ibaUtility = new IBAUtility(doc);
                    Vector types = ibaUtility.getIBAValues("ct_model");

                    IBAUtility ibaUtility1 = new IBAUtility(document);

                    if (differentAttrs.containsKey("型号")) {
                        ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(doc);
                        for (WTPart describesWTPart : describesWTParts) {
                            CtPartUtil.deleteDescribeLink(describesWTPart, doc);

                            //取出证书文档的认证类型
                            IBAUtil iba = new IBAUtil(describesWTPart);
                            String type = iba.getIBAValue("ct_model");
                            Set<String> strings = new HashSet<>();
                            List<HashMap<String, Object>> maps = eofMapper.getBranchIdsByType(type);
                            for (HashMap<String, Object> map : maps) {
                                String docNumber = map.get("docNumber").toString();
                                if (docNumber.equals(doc.getNumber())) continue;

                                WTDocument doc1 = CtDocUtil.getDocumentByNumber(docNumber);
                                IBAUtil ibaUtil1 = new IBAUtil(doc1);
                                if (CtFormatUtil.hasContent(ibaUtil1.getEnumDisplayValue(doc1, "ct_Authenticationtype"))) {
                                    String value = ibaUtil1.getEnumDisplayValue(doc1, "ct_Authenticationtype");
                                    strings.add(value);
                                    CtPartUtil.createDescribeLink(describesWTPart, doc1);
                                }
                            }
                            String certificationType = "";
                            if (CtFormatUtil.hasContent(strings)) {
                                certificationType = strings.toString();
                                if (certificationType.contains("[")) {
                                    certificationType = certificationType.replace("[", "");
                                }
                                if (certificationType.contains("]")) {
                                    certificationType = certificationType.replace("]", "");
                                }
                            }
                            System.out.println(">>>>>>>>type:" + type);
                            System.out.println(">>>>>partNumber:" + describesWTPart.getNumber());
                            System.out.println(">>>>>>>>>>certificationType:" + certificationType);
                            iba.setIBAValue("ct_whetherCensorship", certificationType);
                            describesWTPart = (WTPart) iba.updateIBAHolder(describesWTPart);
                            describesWTPart = (WTPart) CtACLUtil.checkout(describesWTPart, "编辑证书");
                            describesWTPart = (WTPart) CtACLUtil.checkIn(describesWTPart, "编辑证书");
                            doc = (WTDocument) CtACLUtil.checkIn(doc, "关联成品");
                            doc = (WTDocument) CtACLUtil.checkIn(doc, "关联成品");
                        }
                    }
                    if (differentAttrs.containsKey("认证类型") || differentAttrs.containsKey("型号")) {
                        //ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(doc);
                        for (Object type : types) {
                            List<HashMap<String, Object>> parts = eofMapper.getPartNumberByType((String) type);
                            for (HashMap<String, Object> part : parts) {
                                WTPart describesWTPart = CtPartUtil.getPartByNumber((String) part.get("partNumber"));
                                IBAUtil iba = new IBAUtil(describesWTPart);

                                Set<String> strings = new HashSet<>();
                                List<HashMap<String, Object>> maps = eofMapper.getBranchIdsByType((String) type);
                                for (HashMap<String, Object> map : maps) {
                                    String docNumber = map.get("docNumber").toString();
                                    //if (docNumber.equals(doc.getNumber())) continue;

                                    WTDocument doc1 = CtDocUtil.getDocumentByNumber(docNumber);
                                    IBAUtil ibaUtil1 = new IBAUtil(doc1);
                                    if (CtFormatUtil.hasContent(ibaUtil1.getEnumDisplayValue(doc1, "ct_Authenticationtype"))) {
                                        String value = ibaUtil1.getEnumDisplayValue(doc1, "ct_Authenticationtype");
                                        strings.add(value);
                                    }
                                }
                                CtPartUtil.createDescribeLink(describesWTPart, doc);
                                String certificationType = "";
                                if (CtFormatUtil.hasContent(strings)) {
                                    strings.add(ibaUtil.getEnumDisplayValue(doc, "ct_Authenticationtype"));
                                    certificationType = strings.toString();
                                    if (certificationType.contains("[")) {
                                        certificationType = certificationType.replace("[", "");
                                    }
                                    if (certificationType.contains("]")) {
                                        certificationType = certificationType.replace("]", "");
                                    }
                                }

                                System.out.println(">>>>>>>>type:" + type);
                                System.out.println(">>>>>partNumber:" + describesWTPart.getNumber());
                                System.out.println(">>>>>>>>>>certificationType:" + certificationType);
                                iba.setIBAValue("ct_whetherCensorship", certificationType);
                                describesWTPart = (WTPart) iba.updateIBAHolder(describesWTPart);
                                describesWTPart = (WTPart) CtACLUtil.checkout(describesWTPart, "编辑证书");
                                describesWTPart = (WTPart) CtACLUtil.checkIn(describesWTPart, "编辑证书");
                                doc = (WTDocument) CtACLUtil.checkIn(doc, "关联成品");
                                doc = (WTDocument) CtACLUtil.checkIn(doc, "关联成品");
                            }
                        }
                    }
                } else {
                    IBAUtility ibaUtility = new IBAUtility(doc);
                    Vector types = ibaUtility.getIBAValues("ct_model");
                    List<HashMap<String, Object>> maps = new ArrayList<>();

                    for (Object type1 : types) {
                        //将上一个版本关联的物料认证类型重新获取
                        List<HashMap<String, Object>> tempMaps = eofMapper.getPartNumberByType((String) type1);
                        for (HashMap<String, Object> tempMap : tempMaps) {
                            maps.add(tempMap);
                        }
                    }

                    for (HashMap<String, Object> map : maps) {
                        WTPart part = CtPartUtil.getPartByNumber((String) map.get("partNumber"));
                        String value = ibaUtil.getEnumDisplayValue(doc, "ct_Authenticationtype");

                        IBAUtil iba = new IBAUtil(part);
                        String whetherCensorship = iba.getIBAValue("ct_whetherCensorship");
                        if (CtFormatUtil.hasContent(whetherCensorship)) {
                            String[] split1 = whetherCensorship.split(",");
                            if (CtFormatUtil.hasContent(value)) {
                                if (!ArrayUtils.contains(split1, value)) {
                                    iba.setIBAValue("ct_whetherCensorship", whetherCensorship + "," + value);
                                }
                            }
                        } else {
                            iba.setIBAValue("ct_whetherCensorship", value);
                        }
                        iba.updateIBAHolder(part);
                        CtPartUtil.createDescribeLink(part, doc);
                        WTPart wtPart = (WTPart) CtACLUtil.checkout(part, "编辑证书");
                        CtACLUtil.checkIn(wtPart, "编辑证书");
                        doc = (WTDocument) CtACLUtil.checkIn(doc, "关联成品");
                        doc = (WTDocument) CtACLUtil.checkIn(doc, "关联成品");
                    }
                }
                n++;
                row = sheet1.getRow(n);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，证书关联成品出错！异常信息：" + e.getMessage());
        }
    }

    public static void updateModel(String filePath) throws Exception {
        List<Object> collectDataList = new ArrayList<>();
        System.out.println(filePath);
        InputStream is = FileUtil.getInputStream(filePath);
        //List<List<Object>> allRows = excelReader.read(2, excelReader.getRowCount());
        // System.out.println(">>>>读取行数："+allRows.size());
        Workbook workbook = null;

        try {
            workbook = new XSSFWorkbook(is);
            Sheet sheet1 = workbook.getSheetAt(0);
            int n = 1;
            Row row = sheet1.getRow(n);
            while (row != null) {
                CtMViewExportBo exportRecord = new CtMViewExportBo();
                String number = CtExcelReadUtil.getCellValue(sheet1, n, 0);//J列
                if (!CtFormatUtil.hasContent(number)) {
                    n++;
                    row = sheet1.getRow(n);
                    continue;
                }

                WTDocument document = CtDocUtil.getDocumentByNumber(number);
                if (CtFormatUtil.hasContent(document)) {
                    IBAUtility ibaUtil = new IBAUtility(document);
                    Vector ibaValues = ibaUtil.getIBAValues("ct_model");
                    Vector<String> strings = new Vector<>();
                    for (Object ibaValue : ibaValues) {
                        String value = ibaValue.toString();
                        String[] split = value.split(",");
                        for (String s : split) {
                            strings.add(s);
                        }
                    }

                    if (CtFormatUtil.hasContent(strings)){
                        ibaUtil.setIBAValues("ct_model",strings);
                        ibaUtil.updateAttributeContainer((IBAHolder) document);
                        IBAUtility.updateIBAHolder((IBAHolder) document);
                    }
                } else {
                    exportRecord.setResult("未找到该文档");
                }
                exportRecord.setNumber(number);

                collectDataList.add(exportRecord);
                n++;
                row = sheet1.getRow(n);
            }

            //========开始输出==============
            CtExportModelTool tool = new CtExportModelTool();
            String newExcelFile = filePath.replace(".xl", "-检查结果.xl");
            File file = new File(newExcelFile);
            tool.exportExcel(collectDataList, CtMViewExportBo.class, file.getAbsolutePath());

        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (is != null) {
                    is.close();
                    is = null;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 创建停用追踪文档
     * @param document
     * @param createUser
     * @throws Exception
     */
    public static void createStopTrackingDocument(WTDocument document, WTUser createUser) throws Exception {
        //是否需要退市
        boolean isDelisted = false;
        String branchId = document.getBranchIdentifier()+"";
        String[] strings = new String[1];
        strings[0] = branchId;
        List<CtRecertfOrEofItemBo> itemBos = (List<CtRecertfOrEofItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getRecertfItemInfo", strings);
        for(CtRecertfOrEofItemBo bo : itemBos){
            if("是".equals(bo.getWhetherDelisted())){
                isDelisted = true;
                break;
            }
        }
        //没有需要退市的条目则不创建停用追踪文档
        if(!isDelisted){
            return;
        }

        //创建停用追踪文档
        WTDocument newDoc = new WTDocument();
        String docNumber = document.getNumber();
        WTContainer obj = document.getContainer();

        // 开始创建文档
        PersistableAdapter persistableAdapter = new PersistableAdapter("com.fhsj.Doc_tyzzwj", null, null);
        persistableAdapter.load("name", "containerReference", "folder.id",
                "iterationInfo.creator", "iterationInfo.modifier", "state.state");
        persistableAdapter.set("name", docNumber);
        persistableAdapter.set("containerReference", obj);
        persistableAdapter.set("folder.id", obj.getDefaultCabinet());
        persistableAdapter.set("iterationInfo.creator", createUser);
        persistableAdapter.set("iterationInfo.modifier", createUser);
        //persistableAdapter.set("state.state", State.RELEASED);
        persistableAdapter.set("state.state", State.INWORK);
        newDoc = (WTDocument) persistableAdapter.apply();
        newDoc = (WTDocument) PersistenceHelper.manager.save(newDoc);
        String mark = "系统自动创建 – 关联续证退市文档编号" + docNumber;
        VersionControlHelper.setNote(newDoc, mark);
        PersistenceServerHelper.manager.update(newDoc);
        //设置修改人
        CtWTObjectUtil.setModifier(newDoc, createUser);

        //设置IBA属性“续证/退市申请表编号”
        newDoc = (WTDocument) PersistenceHelper.manager.refresh(newDoc);
        IBAUtil ibaUtil = new IBAUtil(newDoc);
        ibaUtil.setIBAValue("ct_RenewalDelistingApplicationFormNumber", docNumber);
        ibaUtil.updateIBAHolder(newDoc);
        String newDocNumber = newDoc.getNumber();
        String newDocState = newDoc.getLifeCycleState().getDisplay(Locale.CHINA);

        //查询"是否退市停用"为是的数据,设置表单数据:文档编号和状态
        //获取成品物料信息
        List<CtRecertfOrEofFinishedItemBo> finishedItemBos = (List<CtRecertfOrEofFinishedItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getFinishedItemInfo", strings);
        for(CtRecertfOrEofFinishedItemBo bo : finishedItemBos){
           if("是".equals(bo.getIsDelist())){
               certificationMapper.updateAttById("ZRecertfOrEofFinishedItem", bo.getId()+"", "stopUsingDocNumber", newDocNumber);
               certificationMapper.updateAttById("ZRecertfOrEofFinishedItem", bo.getId()+"", "stopUsingDocState", newDocState);
           }
        }

        //获取专用物料信息
        List<CtRecertfOrEofSpecialItemBo> specialItemBos = (List<CtRecertfOrEofSpecialItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getSpecialItemInfo", strings);
        for(CtRecertfOrEofSpecialItemBo bo : specialItemBos){
            if("是".equals(bo.getIsDelist())){
                certificationMapper.updateAttById("ZRecertfOrEofSpecialItem", bo.getId()+"", "stopUsingDocNumber", newDocNumber);
                certificationMapper.updateAttById("ZRecertfOrEofSpecialItem", bo.getId()+"", "stopUsingDocState", newDocState);
            }
        }
    }

    /**
     * 保存提交工程师数据到表格
     * @param document
     * @throws Exception
     */
    public static void saveEngineerData(WTDocument document) throws Exception {
        CtCertificationMapper certificationMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationMapper.class);
        CtDocumentPassBoMapper ctDocumentPassBoMapper = CtBeanFactory.newCtBeanFactory().getBean(CtDocumentPassBoMapper.class);
        List<CtCertificationFileItemBo> boList = certificationMapper.getFileItemInfo(document.getBranchIdentifier()+"");
        List<String> engineerList = new ArrayList<>();
        for(CtCertificationFileItemBo bo : boList){
            String submitEngineer = bo.getSubmitEngineer();
            if (!engineerList.contains(submitEngineer)) {
                engineerList.add(submitEngineer);
            }
        }
        for(String submitEngineer : engineerList){
            CtDocumentPassBo ctDocumentPassBo = new CtDocumentPassBo(document.getBranchIdentifier()+"");
            ctDocumentPassBo.setEngineer(submitEngineer);
            ctDocumentPassBoMapper.insert(ctDocumentPassBo);
        }
    }

    /**
     * 认证流程校验
     * 表单内容为否，只能选择“需修改证书补充资料”。
     * 表单内容为是，只能选择通过“通过”、“需工程师修改送检资料”
     * @param bean
     * @throws Exception
     */
    public static void checkAuthenticationRoute(NmCommandBean bean) throws Exception {
        NmOid nmoid = bean.getActionOid();
        Object obj = nmoid.getRef();
        WorkItem workitem = null;
        WTDocument document = null;
        String docType = "";
        if (obj instanceof WorkItem) {
            workitem = (WorkItem) obj;
            Object obj1 = workitem.getPrimaryBusinessObject().getObject();
            if (obj1 instanceof WTDocument) {
                document = (WTDocument)obj1;
                docType = CtWTObjectUtil.getLeafTypeIdentifier(document);
            }
            //文档类型：P-1.2.9.1-T04 认证送检审核跟踪表
            if("com.fhsj.Doc_sjcpzlshgzb".equals(docType)){
                //节点：三江电子-认证流程-认证工程师等待认证结果
                WfAssignedActivity activity = (WfAssignedActivity) workitem.getSource().getObject();
                String activityName = activity.getName();
                String currentActKey = CtCertfProperties.getActivityNodeName(activityName);
                if(!"waiting_authentication_result_node".equals(currentActKey)){
                    return;
                }

                CtDocumentPassBoMapper ctDocumentPassBoMapper = CtBeanFactory.newCtBeanFactory().getBean(CtDocumentPassBoMapper.class);
                Wrapper wrapper = new EntityWrapper<CtDocumentPassBo>().eq(("docBranchId"), document.getBranchIdentifier()+"");
                List<CtDocumentPassBo> boList = ctDocumentPassBoMapper.selectList(wrapper);
                String passString = "";
                for(CtDocumentPassBo bo : boList){
                    if(CtFormatUtil.hasContent(passString) && !passString.equals(bo.getWhetherPass())){
                        throw new Exception("“是否通过”，只能全部选“是”或者全部选“否”！");
                    }
                    passString = bo.getWhetherPass();
                }

                Enumeration parameterNames  = bean.getRequest().getParameterNames();
                String parameterName = "";
                String parameterValue = "";
                Vector routerVector = new Vector(); //当前用户选择的路由事件
                while(parameterNames.hasMoreElements()){
                    parameterName = (String)parameterNames.nextElement();
                    if(parameterName.indexOf("WfUserEvent") >= 0 && parameterName.lastIndexOf("old") == -1){
                        if(parameterName.indexOf("WfRouterCheck") >= 0)
                            parameterValue = parameterName.substring(parameterName.indexOf("WfRouterCheck") + "WfRouterCheck".length(), parameterName.lastIndexOf("___"));
                        else
                            parameterValue = bean.getTextParameter(parameterName);
                        routerVector.add(parameterValue);
                    }
                }
                if(routerVector.size() > 0){
                    if("否".equals(passString) && !routerVector.contains("需修改证书补充资料")){
                        throw new Exception("“是否通过”选否，只能选择“需修改证书补充资料”路由！");
                    }
                    if("是".equals(passString) && !routerVector.contains("通过") && !routerVector.contains("需工程师修改送检资料")){
                        throw new Exception("“是否通过”选是，只能选择“通过”或“需工程师修改送检资料”路由！");
                    }
                }
            }
        }
    }
}
