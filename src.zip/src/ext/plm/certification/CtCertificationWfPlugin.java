package ext.plm.certification;

import ext.plm.bean.CtBeanFactory;
import ext.plm.bean.CtBeanService;
import ext.plm.certification.bo.*;
import ext.plm.certification.config.CtCertfProperties;
import ext.plm.certification.mapper.CtCertificationMapper;
import ext.plm.certification.mapper.CtRecertfOrEofMapper;
import ext.plm.integration.sap.CtSapInterface;
import ext.plm.mobileWorkReport.CtMobileWorkReportService;
import ext.plm.newec.mapper.CtEBomChangeMapper;
import ext.plm.tool.CtReuseCheck;
import ext.plm.util.*;
import org.apache.commons.lang.ArrayUtils;
import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleServerHelper;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.project.Role;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.team.Team;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import java.text.SimpleDateFormat;
import java.util.*;

public class CtCertificationWfPlugin {

    private  static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);

    /**
     * 应用于认证请求流程里 各个节点的”完成任务“转变条件
     * 表单必填字段验证
     * @param pbo
     * @param self
     */
    public static void checkForm(WTObject pbo, Object self) throws WTException {
		/*
		  //必填验证
		  ext.plm.certification.CtCertificationWfPlugin.checkForm(primaryBusinessObject,self);
		 */

        try {

            WTDocument document = (WTDocument) pbo;
            String branchId = document.getBranchIdentifier()+"";
            String[] strings = new String[1];
            strings[0] = branchId;
            String emptyAtts = "";
            // 取activityKey
            String activityKey = getActivityKey(self);

            // 取必填字段
            List<String> requiredAtts = CtCertfProperties.getRequiredAtts(activityKey);

            CtReuseCheck ctReuseCheck = new CtReuseCheck();
            CtCertificationQuery query = new CtCertificationQuery();

            HashMap<String, String> headInfo = query.getHeadInfo(branchId);
            String demandSource = headInfo.get("head_demandSource");
            if (CtFormatUtil.hasContent(demandSource)) {
                if (demandSource.equals("新产品")) {
                    requiredAtts.add("head_projectNumber");
                } else if (demandSource.equals("老产品变更") || demandSource.equals("其它")) {
                    requiredAtts.add("head_remark");
                }
            }

            //表单必填
            for (Iterator<String> ite = requiredAtts.iterator(); ite.hasNext();) {
                String attKey = ite.next();
                String attValue = query.getAttributeValue(branchId, attKey);

                if (!CtFormatUtil.hasContent(attValue)) {
                    String displayName = CtCertfProperties.getAttDisplayName(attKey);
                    emptyAtts += displayName + "\r\n";
                }
            }

            if (CtFormatUtil.hasContent(emptyAtts)) {
                throw new WTException("以下字段必填，请输入内容后再提交！\r\n" + emptyAtts);
            }

            //提交、重新提交表格效验
            if (activityKey.equals("submit_node") || activityKey.equals("resubmit_node") || activityKey.equals("isDate_node")||activityKey.equals("hasConfirmationData_node")){
                List<CtCertificationItemBo> itemBos = (List<CtCertificationItemBo>) beanService.doMethod(CtCertificationServiceImpl.class,"getItemInfo",strings);
                String itemMag = ctReuseCheck.checkGridRequiredAtt(CtCertificationItemBo.class, "ZCERTFITEM", "产品送检表单", branchId);
                if (CtFormatUtil.hasContent(itemMag)){
                    throw new WTException(itemMag);
                }
                for (CtCertificationItemBo itemBo : itemBos) {
                    if (itemBo.getIsDevice().equals("是")&&!CtFormatUtil.hasContent(itemBo.getDeviceNumber())){
                        throw new WTException("如有关键元器件则关键元器件编码必填！！！");
                    }
                }

                /*String applyItemMag = ctReuseCheck.checkGridRequiredAtt(CtCertificationFileItemBo.class, "ZCERTFAPPLYITEM", "产品送检申请文件表单", branchId);
                if (CtFormatUtil.hasContent(applyItemMag)){
                    throw new WTException(applyItemMag);
                }*/

            }


            if (activityKey.equals("procurement_node")){
                if (headInfo.get("isPhysical").equals("否")){
                    throw new WTException("需已核对实物！");
                }
            }
           /* if (activityKey.equals("mDateCollect_node")){
                if (headInfo.get("inspectDataFiling").equals("否")){
                    throw new WTException("需送检资料已归档！");
                }
            }*/

            if (activityKey.equals("creationReport_node")){
                if (headInfo.get("certfCreateFiling").equals("否")){
                    throw new WTException("需检验报告已存档！");
                }
            }

            if (activityKey.equals("dateReconfirm_node")){
                if (headInfo.get("dataSave").equals("是")&&!CtFormatUtil.hasContent(headInfo.get("ECRNumber"))){
                    throw new WTException("有资料更新是ECR编号必填！");
                }
            }

            //资料补充负责人获取证书补充资料  表格效验
            /*if(activityKey.equals("cReplenishDate_node")){
                String skillItemMag = ctReuseCheck.checkGridRequiredAtt(CtCertificationSkillItemBo.class, "ZCERTFSKILLITEM", "获证所需其他文件表单", branchId);
                if (CtFormatUtil.hasContent(skillItemMag)){
                    throw new WTException(skillItemMag);
                }
            }*/

        } catch (WTException wte) {
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
        }
    }





    /**
     * 判断是否拥有关键元器件 无则不出现采购代表审核节点
     * @param pbo
     * @throws WTException
     */
    public static String checkDevice(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.checkDevice(primaryBusinessObject);
		 */

        try {
            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";

            int flag = 0;

            //获取产品信息
            List<CtCertificationItemBo> itemBos = (List<CtCertificationItemBo>) beanService.doMethod(CtCertificationServiceImpl.class,"getItemInfo",strings);
            for (CtCertificationItemBo itemBo : itemBos) {
                if (itemBo.getIsDevice().equals("是")){
                    flag++;
                }
            }

            if (flag>0){
                return "是";
            }else {
                return "否";
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，判断是否拥有关键元器件出错！异常信息：" + e.getMessage());
        }
    }

    /**
     * 自动存档认证文件
     * @param pbo
     * @throws WTException
     */
    public static String archive(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.archive(primaryBusinessObject);
		 */
        String message = "";
        try {
            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";
            CtCertificationLogis.archive(document.getBranchIdentifier()+"");

        } catch (Exception e) {
            e.printStackTrace();
            message =  "后台异常，自动存档出错！异常信息：" + e.getMessage();
            throw new WTException("后台异常，自动存档出错！异常信息：" + e.getMessage());
        }
        return message;
    }

    /**
     * 判断是否属于续证且属于CCC或自愿性认证的情形
     * @param pbo
     * @throws WTException
     */
    public static String checkCertfType(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.checkCertfType(primaryBusinessObject);
		 */

        try {
            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";

            //获取产品信息
            HashMap<String, String> formMap = (HashMap<String, String>) beanService.doMethod(CtCertificationServiceImpl.class,"getHeadInfo",strings);


            return formMap.get("recertification");

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，判断是否属于续证且属于CCC或自愿性认证出错！异常信息：" + e.getMessage());
        }
    }


    /**
     * 关联创建的证书
     * @param pbo
     * @throws WTException
     */
    public static void docLinkCertificate(WTObject pbo, Object self) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.docLinkCertificate(primaryBusinessObject,self);
		 */

        try {
            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";
            // 取activityKey
            String activityKey = getActivityKey(self);
            //获取产品信息
            HashMap<String, String> formMap = (HashMap<String, String>) beanService.doMethod(CtCertificationServiceImpl.class,"getHeadInfo",strings);
            System.out.println(">>>>>>>>>>>activityKey"+activityKey);
            if(activityKey.equalsIgnoreCase("creationReport_node")){
                String certfNumber = formMap.get("certfNumber");
                if (CtFormatUtil.hasContent(certfNumber)){
                    String[] split = certfNumber.split(",");
                    for (String number : split) {
                        WTDocument document1 = CtDocUtil.getDocumentByNumber(number);
                        CtDocUtil.createDocLink(document,document1);
                    }
                }
                CtCertificationServiceImpl bean = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationServiceImpl.class);
                bean.saveAttribute(document.getBranchIdentifier()+"",activityKey,"certfNumber1",certfNumber);
                bean.saveAttribute(document.getBranchIdentifier()+"",activityKey,"certfNumberLink1",formMap.get("certfNumberLink"));
            }else {
                String certfNumber = formMap.get("certfNumber1");
                if (CtFormatUtil.hasContent(certfNumber)){
                    String[] split = certfNumber.split(",");
                    for (String number : split) {
                        WTDocument document1 = CtDocUtil.getDocumentByNumber(number);
                        CtDocUtil.createDocLink(document,document1);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，关联证书出错！异常信息：" + e.getMessage());
        }
    }


    /**
     * 应用于退市续证请求流程里 各个节点的”完成任务“转变条件
     * 表单必填字段验证
     * @param pbo
     * @param self
     */
    public static void checkRecertfOrEof(WTObject pbo, Object self) throws WTException {
		/*
		  //必填验证
		  ext.plm.certification.CtCertificationWfPlugin.checkRecertfOrEof(primaryBusinessObject,self);
		 */

        try {

            WTDocument document = (WTDocument) pbo;
            String branchId = document.getBranchIdentifier()+"";
            String emptyAtts = "";
            // 取activityKey
            String activityKey = getActivityKey(self);

            // 取必填字段
            String requiredAtts = CtCertfProperties.getRequiredAtt(activityKey);


            CtReuseCheck ctReuseCheck = new CtReuseCheck();

            //提交 表格效验
            if(activityKey.equals("rSubmit_node")){
                String[] strings = new String[1];
                strings[0] = document.getBranchIdentifier()+"";
                //获取证书产品信息
                List<CtRecertfOrEofItemBo> itemBos = (List<CtRecertfOrEofItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getRecertfItemInfo", strings);
                for (CtRecertfOrEofItemBo itemBo : itemBos) {
                    String background = itemBo.getBackground();
                    if (background.equals("证书到期")){
                        if (!CtFormatUtil.hasContent(itemBo.getCertfNumber())||!CtFormatUtil.hasContent(itemBo.getCertfType())||!CtFormatUtil.hasContent(itemBo.getCertfDueDate())){
                            throw new WTException("如背景为证书到期，证书相关信息必须填写！");
                        }
                    }else {
                        if(!CtFormatUtil.hasContent(itemBo.getReason())){
                            throw new WTException("如背景为其他原因，发起原因必须填写！");
                        }
                    }
                }


                String itemMag = ctReuseCheck.checkGridRequiredAtt(CtRecertfOrEofItemBo.class, "ZRecertfOrEofItem", "退市、续证信息表", branchId,requiredAtts);
                if (CtFormatUtil.hasContent(itemMag)){
                    throw new WTException(itemMag);
                }
            }

            if (activityKey.equals("PDTManager_node")){
                if (self instanceof ObjectReference) {
                    self = ((ObjectReference) self).getObject();
                }
                if (self instanceof WorkItem) {
                    WorkItem workItem = (WorkItem) self;
                    WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
                    String taskVote = CtWorkFlowUtil.getTaskVote(activity);
                    if(taskVote.contains("不需要")){
                        String itemMag = ctReuseCheck.checkGridRequiredAtt(CtRecertfOrEofItemBo.class, "ZRecertfOrEofItem", "退市、续证信息表", branchId,requiredAtts);
                        if (CtFormatUtil.hasContent(itemMag)){
                            throw new WTException(itemMag);
                        }
                    }
                } else if (self instanceof WfAssignedActivity) {
                    WfAssignedActivity activity = (WfAssignedActivity) self;
                    String taskVote = CtWorkFlowUtil.getTaskVote(activity);
                    if(taskVote.contains("不需要")){
                        String itemMag = ctReuseCheck.checkGridRequiredAtt(CtRecertfOrEofItemBo.class, "ZRecertfOrEofItem", "退市、续证信息表", branchId,requiredAtts);
                        if (CtFormatUtil.hasContent(itemMag)){
                            throw new WTException(itemMag);
                        }
                    }
                }
            }


            if (activityKey.equals("exploit_node")||activityKey.equals("confirmPart_node")||activityKey.equals("purchase_node")){
                String[] strings = new String[1];
                strings[0] = branchId;
                //获取成品物料信息
                List<CtRecertfOrEofFinishedItemBo> finishedItemBos = (List<CtRecertfOrEofFinishedItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getFinishedItemInfo", strings);
                if (!CtFormatUtil.hasContent(finishedItemBos)){
                    throw new WTException("请添加成品物料信息");
                }

                String restsItemMag = ctReuseCheck.checkGridRequiredAtt(CtRecertfOrEofFinishedItemBo.class, "ZRecertfOrEofFinishedItem", "成品数据", branchId,requiredAtts);
                if (CtFormatUtil.hasContent(restsItemMag)){
                    throw new WTException(restsItemMag);
                }
                String applyItemMag = ctReuseCheck.checkGridRequiredAtt(CtRecertfOrEofSemiItemBo.class, "ZRecertfOrEofSemiItem", "半成品物料数据", branchId,requiredAtts);
                if (CtFormatUtil.hasContent(applyItemMag)){
                    throw new WTException(applyItemMag);
                }
                String itemMag = ctReuseCheck.checkGridRequiredAtt(CtRecertfOrEofSpecialItemBo.class, "ZRecertfOrEofSpecialItem", "本产品专用物料数据", branchId,requiredAtts);
                if (CtFormatUtil.hasContent(itemMag)){
                    throw new WTException(itemMag);
                }
            }

            if (activityKey.equals("sell_node")){
                String restsItemMag = ctReuseCheck.checkGridRequiredAtt(CtRecertfOrEofFinishedItemBo.class, "ZRecertfOrEofFinishedItem", "成品数据", branchId,requiredAtts);
                if (CtFormatUtil.hasContent(restsItemMag)){
                    throw new WTException(restsItemMag);
                }
            }

        } catch (WTException wte) {
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
        }
    }

    /**
     * 应用于提交节点完成后添加成品信息
     * @param pbo
     * @throws WTException
     */
    public static void addFinishedInfo(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.addFinishedInfo(primaryBusinessObject);
		 */

        try {
            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";
            //添加成品信息
            beanService.doMethod(CtCertificationServiceImpl.class, "addFinishedByType", strings);


        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，添加成品信息出错！异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 应用于确认待停用的成品及专用原材料编码  判断是否有退市项如果有就跑DCP流程
     * @param pbo
     * @throws WTException
     */
    public static String checkIsRecertfOrEof(WTObject pbo,String flag) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.checkIsRecertfOrEof(primaryBusinessObject);
		 */

        try {

            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";
            //获取证书产品信息
            List<CtRecertfOrEofItemBo> itemBos = (List<CtRecertfOrEofItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getRecertfItemInfo", strings);

            int is = 0;

            for (CtRecertfOrEofItemBo bo : itemBos) {
                if(CtFormatUtil.hasContent(bo.getWhetherDelisted()) && "是".equals(bo.getWhetherDelisted())) is++;
            }

            if (flag.equals("DCP")) {
                //获取成品物料信息
                List<CtRecertfOrEofFinishedItemBo> finishedItemBos = (List<CtRecertfOrEofFinishedItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getFinishedItemInfo", strings);
                //获取半成品物料信息
                List<CtRecertfOrEofSemiItemBo> semiItemBos = (List<CtRecertfOrEofSemiItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getSemiItemInfo", strings);
                //获取专用物料信息
                List<CtRecertfOrEofSpecialItemBo> specialItemBos = (List<CtRecertfOrEofSpecialItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getSpecialItemInfo", strings);

                for (CtRecertfOrEofFinishedItemBo bo : finishedItemBos) {
                    if (bo.getIsDelist().equals("是")) is++;
                }

                for (CtRecertfOrEofSemiItemBo bo : semiItemBos) {
                    if (bo.getIsDelist().equals("是")) is++;
                }

                for (CtRecertfOrEofSpecialItemBo bo : specialItemBos) {
                    if (bo.getIsDelist().equals("是")) is++;
                }
            }
            if (is>0){
                return "退市";
            }else {
                return "续证";
            }



        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，判断是否退市出错！异常信息：" + e.getMessage());
        }
    }

    /**
     * 应用于DCP流程完毕 设置物料状态为停用中
     * @param pbo
     * @throws WTException
     */
    public static String setState(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.setState(primaryBusinessObject);
		 */
        String result = "";

        try {

            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";
            //获取成品物料信息
            List<CtRecertfOrEofFinishedItemBo> finishedItemBos = (List<CtRecertfOrEofFinishedItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getFinishedItemInfo", strings);
            //获取半成品物料信息
            List<CtRecertfOrEofSemiItemBo> semiItemBos = (List<CtRecertfOrEofSemiItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getSemiItemInfo", strings);
            //获取专用物料信息
            List<CtRecertfOrEofSpecialItemBo> specialItemBos = (List<CtRecertfOrEofSpecialItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getSpecialItemInfo", strings);

            Set<String> stringSet = new HashSet<>();

            for (CtRecertfOrEofFinishedItemBo bo : finishedItemBos) {
                if(bo.getIsDelist().equals("是"))
                stringSet.add(bo.getFinishedMaterialCode());
            }

            for (CtRecertfOrEofSemiItemBo bo : semiItemBos) {
                if(bo.getIsDelist().equals("是"))
                stringSet.add(bo.getSemiMaterialCode());
            }

            for (CtRecertfOrEofSpecialItemBo bo : specialItemBos) {
                if(bo.getIsDelist().equals("是"))
                stringSet.add(bo.getSpecialMaterialCode());
            }

            List<WTPart> parts = new ArrayList<>();

            for (String partNumber : stringSet) {
                WTPart part = CtPartUtil.getPartByNumber(partNumber);
                if (part.getViewName().equalsIgnoreCase("Design")) {
                    WTPart part1 = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                    if(CtFormatUtil.hasContent(part1)){
                        parts.add(part1);
                    }
                }else {
                    WTPart part1 = CtPartUtil.getPartByNumber(partNumber, "Design");
                    if(CtFormatUtil.hasContent(part1)){
                        parts.add(part1);
                    }
                }
                parts.add(part);
            }

            for (WTPart part : parts) {

                if(WorkInProgressHelper.isCheckedOut(part, SessionHelper.getPrincipal())){
                    result = CtFormatUtil.combineStr(result, part.getNumber());

                }else {

                    /*LifeCycleState lc = LifeCycleState.newLifeCycleState();
                    lc.setState(State.toState("StopUsing"));
                    part.setState(lc);*/

                    LifeCycleServerHelper.service.setState((LifeCycleManaged) part, State.toState("StopUsing"));
                }
            }

            if (CtFormatUtil.hasContent(result)){
                result = "有物料状态为检出，编号为"+result+"请处理！";
            }
            System.out.println(result);


            return result;

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，设置物料状态为停用中出错！异常信息：" + e.getMessage());
        }
    }

    /**
     * 应用于停用追踪流程 设置证书状态为停用中
     * @param pbo
     * @throws WTException
     */
    public static String setCertificateState(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.setCertificateState(primaryBusinessObject);
		 */
        String result = "";

        try {

            WTDocument doc = (WTDocument) pbo;
            IBAUtil ibaUtil = new IBAUtil(doc);
            String docNumber = ibaUtil.getIBAValue("ct_RenewalDelistingApplicationFormNumber");
            WTDocument document = CtDocUtil.getDocumentByNumber(docNumber);
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";
            CtRecertfOrEofMapper eofMapper = CtBeanFactory.newCtBeanFactory().getBean(CtRecertfOrEofMapper.class);
            ArrayList<WTDocument> wtDocuments = new ArrayList<>();
            //获取成品物料信息
            List<CtRecertfOrEofFinishedItemBo> finishedItemBos = (List<CtRecertfOrEofFinishedItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getFinishedItemInfo", strings);
            HashSet<String> stringSet = new HashSet<>();

            for (CtRecertfOrEofFinishedItemBo bo : finishedItemBos) {
                List<HashMap<String, Object>> maps = eofMapper.getBranchIdsByType(bo.getProductType());
                for (HashMap<String, Object> map : maps) {
                    System.out.println("docNumber>>>>"+map.get("docNumber").toString());
                    stringSet.add(map.get("docNumber").toString());
                }
            }

            for (String number : stringSet) {
                WTDocument wtDocument = CtDocUtil.getDocumentByNumber(number);

                wtDocuments.add(wtDocument);
            }

            for (WTDocument wtDocument : wtDocuments) {

                if(WorkInProgressHelper.isCheckedOut(wtDocument, SessionHelper.getPrincipal())){
                    result = CtFormatUtil.combineStr(result, doc.getNumber());

                }else {

                    /*LifeCycleState lc = LifeCycleState.newLifeCycleState();
                    lc.setState(State.toState("StopUsing"));
                    part.setState(lc);*/
                    LifeCycleHelper.service.setLifeCycleState(wtDocument, State.toState("Deactivate"));
                }
            }

            if (CtFormatUtil.hasContent(result)){
                result = "有证书状态为检出，编号为"+result+"请处理！";
            }
            System.out.println(result);


            return result;

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，设置证书状态为停用出错！异常信息：" + e.getMessage());
        }
    }

    public static void dingInformRHCE(WTObject pbo, ObjectReference self, String roleName) throws WTException {
        dingInformRHCE(pbo, self, roleName, "");
    }

    /**
     * 用于 审批通过时
     * 钉钉通知认证工程师
     *
     * @throws WTException
     */
    public static void dingInformRHCE(WTObject pbo, ObjectReference self,String roleName,String text) throws WTException {
        /**
         * ext.plm.certification.CtCertificationWfPlugin.dingInformRHCE(primaryBusinessObject,self,角色内部名称,文案)
         */
        try {
            WTDocument document = (WTDocument) pbo;
            List<WTUser> userList = CtWorkFlowUtil.getUsersFromRole( self, roleName);
            long l = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:S");
            TimeZone tz = TimeZone.getTimeZone("GMT+08:00");
            sdf.setTimeZone(tz);
            String port = "";
            String format = sdf.format(l);
            for (WTUser user : userList) {
                //组装数据
                String oid = CtWTObjectUtil.getOid(document);
                String hostName = CtCommonUtil.getHostName();
                if (hostName.contains("plmdemo")) {
                    port = ":8885";
                } else if (hostName.contains("plmtest")) {
                    port = ":8886";
                }

                String subject = document.getDisplayIdentity().getLocalizedMessage(SessionHelper.manager.getLocale());
                String workItemTask = "";
                String urlPath = "http://" + hostName+ port + "/Windchill/app/#ptc1/tcomp/infoPage?oid=" + oid;
                String taskString = "<a href='" + urlPath + "' target='_blank'>" + workItemTask + "</a>";
                String body="{\"title\":\"流程提醒\"," +
                        "\"text\":\"您有一个流程待处理：\r\n" +
                        "主题："+subject+"\r\n" +
                        "任务：<"+taskString+">,\r\n" +
                        "提示时间："+format+"\"}";
                System.out.println("body>>>>>>>>>"+body);
                // 发送通知
                String userName =  user.getName();
                if (userName.equalsIgnoreCase("Administrator")){
                    userName = "wcadmin";
                }

                CtBeanFactory.newCtBeanFactory().getBean(CtMobileWorkReportService.class).sendMsgToDingTalk("markdown", body,userName);

            }

        } catch (WTException e) {
            e.printStackTrace();
            throw e;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, "通知失败！" + e.getMessage());
        }
    }

    /**
     *设置参与者
     * @param pbo
     * @throws WTException
     */
    public static void setUser(WTObject pbo, ObjectReference self) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.setUser(primaryBusinessObject,self);
		 */


        try {

            List<WTUser> userList = new ArrayList<WTUser>();
            WTUser managerUser = CtUserUtil.getUserByDisplayName("邓慧林");
            userList.add(managerUser);
            System.out.println("userList"+ userList.get(0).getFullName());
            CtWorkFlowUtil.setUsersToRole(pbo, self, userList, "HeadofData");
            System.out.println("设置参与者成功！！");
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，设置参与者出错！异常信息：" + e.getMessage());
        }
    }
 /**
     *设置参与者
     * @param pbo
     * @throws WTException
     */
    public static void setRecertificationUser(WTObject pbo, ObjectReference self,String condition,String roleName) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.setRecertificationUser(primaryBusinessObject,self);
		 */


        try {

            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";
            List<WTUser> userList = new ArrayList<WTUser>();
            //获取证书产品信息
            List<CtRecertfOrEofItemBo> itemBos = (List<CtRecertfOrEofItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getRecertfItemInfo", strings);
            for (CtRecertfOrEofItemBo itemBo : itemBos) {
                if("退市".equals(condition)){
                    if ("是".equals(itemBo.getWhetherDelisted()) && CtFormatUtil.hasContent(itemBo.getDelistingProcessPerson())){
                        WTUser managerUser = CtUserUtil.getUserByDisplayName(itemBo.getDelistingProcessPerson());
                        if(null != managerUser){
                            userList.add(managerUser);
                        }
                    }
                }
                if("续证".equals(condition)){
                    if ("是".equals(itemBo.getWhetherRenewCertificate()) && CtFormatUtil.hasContent(itemBo.getRenewalProcessPerson())){
                        WTUser managerUser = CtUserUtil.getUserByDisplayName(itemBo.getRenewalProcessPerson());
                        if (null != managerUser) {
                            userList.add(managerUser);
                        }
                    }
                }
            }
            CtWorkFlowUtil.setUsersToRole(pbo, self, userList, roleName);
            System.out.println("设置参与者成功！！");
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，设置参与者出错！异常信息：" + e.getMessage());
        }
    }

    /**
     *判断退市或续证
     * 用于 设置最后通知任务
     * @param pbo
     * @throws WTException
     */
    public static String checkRecertfOrEof(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.checkRecertfOrEof(primaryBusinessObject);
		 */

        try {

            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";

            int recertf = 0;
            int eof = 0;

            //获取证书产品信息
            List<CtRecertfOrEofItemBo> itemBos = (List<CtRecertfOrEofItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getRecertfItemInfo", strings);
            for (CtRecertfOrEofItemBo itemBo : itemBos) {
                if ("是".equals(itemBo.getWhetherDelisted())){
                    eof += 1;
                }
                if ("是".equals(itemBo.getWhetherRenewCertificate())){
                    recertf += 1;
                }
            }


            String result = "";
            if (eof > 0){
                result = "退市";
            }

            if (recertf > 0){
                result = "续证";
            }

            if(eof > 0 && recertf > 0){
                result = "退市续证";
            }

            return result;

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，判断出错退市续证出错！异常信息：" + e.getMessage());
        }
    }


    /**
     * 用于 证书关联成品
     * @param pbo
     * @throws WTException
     */
    public static void szRelevanceFinished(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.szRelevanceFinished(primaryBusinessObject);
		 */

        try {

            WTDocument doc = (WTDocument) pbo;
            IBAUtil ibaUtil = new IBAUtil(doc);

            //如果是修改先拿出上一个版本的相关文档删除
            QueryResult queryResult = VersionControlHelper.service.allVersionsOf(doc.getMaster());

            if (queryResult.size() > 1) {
                queryResult.nextElement();
                WTDocument document = (WTDocument) queryResult.nextElement();

                Map<String, List<String>> differentAttrs = CtWTObjectUtil.getDifferentAttrs(doc, document);
                if (differentAttrs == null || !(differentAttrs.containsKey("型号") || differentAttrs.containsKey("认证类型"))) {
                    return;
                }

                IBAUtility ibaUtility = new IBAUtility(doc);
                Vector types = ibaUtility.getIBAValues("ct_model");

                IBAUtility ibaUtility1 = new IBAUtility(document);
                CtRecertfOrEofMapper eofMapper = CtBeanFactory.newCtBeanFactory().getBean(CtRecertfOrEofMapper.class);
                if (differentAttrs.containsKey("型号")) {
                    ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(doc);
                    for (WTPart describesWTPart : describesWTParts) {
                        CtPartUtil.deleteDescribeLink(describesWTPart, doc);

                        //取出证书文档的认证类型
                        IBAUtil iba = new IBAUtil(describesWTPart);
                        String type = iba.getIBAValue("ct_model");
                        Set<String> strings = new HashSet<>();
                        List<HashMap<String, Object>> maps = eofMapper.getBranchIdsByType(type);
                        for (HashMap<String, Object> map : maps) {
                            String docNumber = map.get("docNumber").toString();
                            if (docNumber.equals(doc.getNumber())) continue;

                            WTDocument doc1 = CtDocUtil.getDocumentByNumber(docNumber);
                            IBAUtil ibaUtil1 = new IBAUtil(doc1);
                            if (CtFormatUtil.hasContent(ibaUtil1.getEnumDisplayValue(doc1, "ct_Authenticationtype"))) {
                                String value = ibaUtil1.getEnumDisplayValue(doc1, "ct_Authenticationtype");
                                strings.add(value);
                                CtPartUtil.createDescribeLink(describesWTPart, doc1);
                            }
                        }
                        String certificationType = "";
                        if (CtFormatUtil.hasContent(strings)) {
                            certificationType = strings.toString();
                            if (certificationType.contains("[")) {
                                certificationType = certificationType.replace("[", "");
                            }
                            if (certificationType.contains("]")) {
                                certificationType = certificationType.replace("]", "");
                            }
                        }
                        System.out.println(">>>>>>>>type:" + type);
                        System.out.println(">>>>>partNumber:" + describesWTPart.getNumber());
                        System.out.println(">>>>>>>>>>certificationType:" + certificationType);
                        iba.setIBAValue("ct_whetherCensorship", certificationType);
                        describesWTPart = (WTPart) iba.updateIBAHolder(describesWTPart);
                        describesWTPart = (WTPart) CtACLUtil.checkout(describesWTPart, "编辑证书");
                        describesWTPart = (WTPart) CtACLUtil.checkIn(describesWTPart, "编辑证书");
                    }
                }
                if (differentAttrs.containsKey("认证类型") || differentAttrs.containsKey("型号")) {
                    //ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(doc);
                    for (Object type : types) {
                        List<HashMap<String, Object>> parts = eofMapper.getPartNumberByType((String) type);
                        for (HashMap<String, Object> part : parts) {
                            WTPart describesWTPart = CtPartUtil.getPartByNumber((String) part.get("partNumber"));
                            IBAUtil iba = new IBAUtil(describesWTPart);

                            Set<String> strings = new HashSet<>();
                            List<HashMap<String, Object>> maps = eofMapper.getBranchIdsByType((String) type);
                            for (HashMap<String, Object> map : maps) {
                                String docNumber = map.get("docNumber").toString();
                                //if (docNumber.equals(doc.getNumber())) continue;

                                WTDocument doc1 = CtDocUtil.getDocumentByNumber(docNumber);
                                IBAUtil ibaUtil1 = new IBAUtil(doc1);
                                if (CtFormatUtil.hasContent(ibaUtil1.getEnumDisplayValue(doc1, "ct_Authenticationtype"))) {
                                    String value = ibaUtil1.getEnumDisplayValue(doc1, "ct_Authenticationtype");
                                    strings.add(value);
                                }
                            }
                            CtPartUtil.createDescribeLink(describesWTPart, doc);
                            String certificationType = "";
                            if (CtFormatUtil.hasContent(strings)) {
                                strings.add(ibaUtil.getEnumDisplayValue(doc, "ct_Authenticationtype"));
                                certificationType = strings.toString();
                                if (certificationType.contains("[")) {
                                    certificationType = certificationType.replace("[", "");
                                }
                                if (certificationType.contains("]")) {
                                    certificationType = certificationType.replace("]", "");
                                }
                            }

                            System.out.println(">>>>>>>>type:" + type);
                            System.out.println(">>>>>partNumber:" + describesWTPart.getNumber());
                            System.out.println(">>>>>>>>>>certificationType:" + certificationType);
                            iba.setIBAValue("ct_whetherCensorship", certificationType);
                            describesWTPart = (WTPart) iba.updateIBAHolder(describesWTPart);
                            describesWTPart = (WTPart) CtACLUtil.checkout(describesWTPart, "编辑证书");
                            describesWTPart = (WTPart) CtACLUtil.checkIn(describesWTPart, "编辑证书");
                        }
                    }
                }
            }else {
                IBAUtility ibaUtility = new IBAUtility(doc);
                Vector types = ibaUtility.getIBAValues("ct_model");
                List<HashMap<String, Object>> maps = new ArrayList<>();

                for (Object type1 : types) {
                    String[] strings = new String[1];
                    strings[0] = (String) type1;
                    //将上一个版本关联的物料认证类型重新获取
                    List<HashMap<String, Object>> tempMaps = (List<HashMap<String, Object>>) beanService.doMethod(CtRecertfOrEofMapper.class, "getPartNumberByType", strings);
                    for (HashMap<String, Object> tempMap : tempMaps) {
                        maps.add(tempMap);
                    }
                }

                for (HashMap<String, Object> map : maps) {
                    WTPart part = CtPartUtil.getPartByNumber((String) map.get("partNumber"));
                    String value = ibaUtil.getEnumDisplayValue(doc,"ct_Authenticationtype");

                    IBAUtil iba = new IBAUtil(part);
                    String whetherCensorship = iba.getIBAValue("ct_whetherCensorship");
                    if (CtFormatUtil.hasContent(whetherCensorship)) {
                        String[] split1 = whetherCensorship.split(",");
                        if (CtFormatUtil.hasContent(value)) {
                            if (!ArrayUtils.contains(split1, value)) {
                                iba.setIBAValue("ct_whetherCensorship", whetherCensorship + "," + value);
                            }
                        }
                    }else {
                        iba.setIBAValue("ct_whetherCensorship",  value);
                    }
                    iba.updateIBAHolder(part);
                    CtPartUtil.createDescribeLink(part, doc);
                    WTPart wtPart = (WTPart) CtACLUtil.checkout(part,"编辑证书");
                    CtACLUtil.checkIn(wtPart,"编辑证书");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，证书关联成品出错！异常信息：" + e.getMessage());
        }
    }


    /**
     * 从流程变更self出发，获得活动对应的key值，前台判断权限等功能需要用到此key
     *
     * @param self
     * @return
     * @throws Exception
     */
    private static String getActivityKey(Object self) throws Exception {

        String actName = ""; // 活动名称（工作流模板中的活动）
        String activityKey = "";// 活动Key值

        // self有时是ObjectReference对象，有时直接是WorkItem或WfAssignedActivity
        if (self instanceof ObjectReference) {
            self = ((ObjectReference) self).getObject();
        }

        if (self instanceof WorkItem) {

            WorkItem workItem = (WorkItem) self;
            WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
            actName = activity.getName();
            activityKey = CtCertfProperties.getActivityNodeName(actName);

        } else if (self instanceof WfAssignedActivity) {
            WfAssignedActivity activity = (WfAssignedActivity) self;
            actName = activity.getName();

            activityKey = CtCertfProperties.getActivityNodeName(actName);
        }

        if (!CtFormatUtil.hasContent(activityKey)) {
            System.out.println(">>>>actName='" + actName + "'无法找到对应的Key,需要核对配置表certfActivityKeyMap.properties！");
            throw new WTException("后台异常，无法找到当前流程活动对应的Key，请联系管理员！");
        }

        return activityKey;
    }


    /**
     * 应用于: 认证续证流程的 “停用SAP物料”表达式
     * ERP物料停用接口调用
     * @param pbo 文档流程主题对象
     * @param failedParts 工作流变量，上次失败的物料
     * @return  HashMap {errorMsg:第一个发送失败的异常信息, failedParts:失败的物料}， 无异常返回null
     * @throws WTException
     */
    // ext.plm.certification.CtCertificationWfPlugin.disableParts2Erp(pbo,failedParts)
    public static HashMap<String,String> disableParts2Erp(WTObject pbo, String failedParts) throws WTException{
        WTDocument document = (WTDocument)pbo;
        String processNo = "文档流程：" +document.getNumber();
        String newFailedParts = "";//记录失败物料异常信息
        String FailException = ""; //记录发送失败的异常信息

        HashMap<String,String> result = null;

        List<WTPart> partList = new ArrayList<WTPart>();
        List<WTPart> parts = new ArrayList<WTPart>();
        try {

            if(CtFormatUtil.hasContent(failedParts)) {
                //续传
                for(String partNumber :failedParts.split(",")) {
                    WTPart tmpPart = CtPartUtil.getPartByNumber(partNumber);
                    partList.add(tmpPart);
                }

            }else {
                //第一次, 从表单中拿数据
                IBAUtil ibaUtil = new IBAUtil(document);
                WTDocument doc = CtDocUtil.getDocumentByNumber(ibaUtil.getIBAValue("ct_RenewalDelistingApplicationFormNumber"));
                String[] strings = new String[1];
                strings[0] = doc.getBranchIdentifier()+"";
                //获取成品物料信息
                List<CtRecertfOrEofFinishedItemBo> finishedItemBos = (List<CtRecertfOrEofFinishedItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getFinishedItemInfo", strings);
                //获取半成品物料信息
                List<CtRecertfOrEofSemiItemBo> semiItemBos = (List<CtRecertfOrEofSemiItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getSemiItemInfo", strings);
                //获取专用物料信息
                List<CtRecertfOrEofSpecialItemBo> specialItemBos = (List<CtRecertfOrEofSpecialItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getSpecialItemInfo", strings);


                for (CtRecertfOrEofFinishedItemBo bo : finishedItemBos) {
                    if(bo.getIsDelist().equals("是"))
                    partList.add(CtPartUtil.getPartByNumber(bo.getFinishedMaterialCode()));
                }

                for (CtRecertfOrEofSemiItemBo bo : semiItemBos) {
                    if(bo.getIsDelist().equals("是"))
                    partList.add(CtPartUtil.getPartByNumber(bo.getSemiMaterialCode()));
                }

                for (CtRecertfOrEofSpecialItemBo bo : specialItemBos) {
                    if(bo.getIsDelist().equals("是"))
                    partList.add(CtPartUtil.getPartByNumber(bo.getSpecialMaterialCode()));
                }

                System.out.println("partList"+ArrayUtils.toString(partList));

                for (WTPart wtPart : partList) {
                    if (wtPart.getViewName().equalsIgnoreCase("Design")){
                        WTPart part = CtPartUtil.getPartByNumber(wtPart.getNumber(), "Manufacturing");
                        if(CtFormatUtil.hasContent(part)){
                            parts.add(part);
                        }
                    }else {
                        WTPart part = CtPartUtil.getPartByNumber(wtPart.getNumber(), "Design");
                        if(CtFormatUtil.hasContent(part)){
                            parts.add(part);
                        }
                    }
                    parts.add(wtPart);
                }
            }
            //开始接口调用
            failedParts=null;
            for(WTPart part: parts) {
                try {
                    CtSapInterface.disableSapPart(processNo,part);
                    System.out.println(">>>>partNumber："+part.getNumber());
                    LifeCycleServerHelper.service.setState((LifeCycleManaged)part,State.toState("Deactivate"));
                }catch(Exception e) {
                    e.printStackTrace();
                    //不抛异常，记录失败的物料，下次续传
                    FailException = CtFormatUtil.combineStr(FailException,part.getNumber()+" 停用失败! "+e.getLocalizedMessage(),"\r\n");
                    newFailedParts = CtFormatUtil.combineStr(newFailedParts,part.getNumber());
                }
            }

        }catch(Exception e) {
            e.printStackTrace();
            throw new WTException("SAP停用物料集成失败，PLM端异常信息："+e.getMessage());
        }

        if(CtFormatUtil.hasContent(newFailedParts)) {
            result = new HashMap<String,String>();
            result.put("errorMsg", "接口异常信息：\r\n"+FailException);
            result.put("failedParts", newFailedParts);
        }
        return result;
    }

    /**
     * 应用于认证流程：校验表格至少有一条数据
     * ext.plm.certification.CtCertificationWfPlugin.checkTableData(primaryBusinessObject);
     * @throws Exception
     */
    public static void checkTableData(WTObject obj) throws Exception {
        WTDocument document = (WTDocument)obj;
        CtCertificationMapper certificationMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationMapper.class);
        List<CtCertificationFileItemBo> list = certificationMapper.getFileItemInfo(document.getBranchIdentifier()+"");
        if(!CtFormatUtil.hasContent(list)){
            throw new Exception("表格至少要有一行数据！");
        }
    }

    /**
     * 应用于认证流程：校验提交工程师必填
     * ext.plm.certification.CtCertificationWfPlugin.checkSubmitEngineer(primaryBusinessObject);
     * @throws Exception
     */
    public static void checkSubmitEngineer(WTObject obj) throws Exception {
        WTDocument document = (WTDocument)obj;
        CtCertificationMapper certificationMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationMapper.class);
        List<CtCertificationFileItemBo> list = certificationMapper.getFileItemInfo(document.getBranchIdentifier()+"");
        for(CtCertificationFileItemBo bo : list){
            if(!CtFormatUtil.hasContent(bo.getSubmitEngineer())){
                throw new Exception("请填写“提交工程师”！");
            }
        }
    }

    /**
     * 应用于认证流程：给角色“B156资料补充负责人”里面设人
     * ext.plm.certification.CtCertificationWfPlugin.setSupplementaryInformation(primaryBusinessObject, self);
     * @throws Exception
     */
    public static void setSupplementaryInformation(WTObject obj, ObjectReference self) throws Exception {
        WTDocument document = (WTDocument)obj;
        CtCertificationMapper certificationMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificationMapper.class);
        List<CtCertificationFileItemBo> list = certificationMapper.getFileItemInfo(document.getBranchIdentifier()+"");
        List<WTUser> userList = new ArrayList<>();
        Set<String> set = new HashSet<>();
        for(CtCertificationFileItemBo bo : list){
            String userName = bo.getSubmitEngineer();
            if(CtFormatUtil.hasContent(userName) && !set.contains(userName)){
                set.add(userName);
                WTUser user = CtUserUtil.getUserByAccountName(userName);
                if(null != user){
                    userList.add(user);
                }
            }
        }
        CtWorkFlowUtil.setUsersToRole(obj, self, userList, "Personinchargeofdatasupplement");
    }

    /**
     * 应用于提交节点完成后添加仅用于成品的半成品和原材料
     * @param pbo
     * @throws WTException
     */
    public static void addRawMaterialAndSemiFinishedProduct(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.addRawMaterialAndSemiFinishedProduct(primaryBusinessObject);
		 */
        try {
            WTDocument document = (WTDocument) pbo;
            String[] strings = new String[1];
            strings[0] = document.getBranchIdentifier()+"";
            //添加成品信息
            beanService.doMethod(CtCertificationServiceImpl.class, "addRawMaterialAndSemiFinishedProduct", strings);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，添加物料出错！异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 应用于自动创建停用追踪文档com.fhsj.Doc_tyzzwj
     * @param pbo
     * @throws WTException
     */
    public static void createStopTrackingDocument(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.createStopTrackingDocument(primaryBusinessObject);
		 */
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        try {
            WTDocument document = (WTDocument) pbo;
            //取得业务指定的创建者
            WTUser createUser = null;
            WfProcess wfProcess = CtWorkFlowUtil.getProcessByPbo(document);
            Team team = (Team) wfProcess.getTeamId().getObject();
            Role role = Role.toRole("PDTManager");//A001PDT经理
            Enumeration userEnum = team.getPrincipalTarget(role);
            while (userEnum.hasMoreElements()) {
                WTPrincipalReference wtpRef = (WTPrincipalReference) userEnum.nextElement();
                Persistable pp = wtpRef.getObject();
                if (pp instanceof WTPrincipal && pp instanceof WTUser) {
                    createUser = (WTUser) pp;
                }
            }
            if(null == createUser){
                throw new Exception("自动创建停用追踪文档失败，无法取得流程团队中的PDT经理！");
            }
            SessionHelper.manager.setPrincipal(createUser.getName());
            boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
            try{
                CtCertificationLogis.createStopTrackingDocument(document, createUser);
            }catch(Exception e1){
                throw e1;
            }finally {
                SessionServerHelper.manager.setAccessEnforced(flag);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，自动创建停用追踪文档出错！异常信息：" + e.getLocalizedMessage());
        }finally {
            SessionHelper.manager.setPrincipal(currentUser.getName());
        }
    }

    /**
     * 不允许不退市也不续证
     * @param pbo
     * @throws Exception
     */
    //ext.plm.certification.CtCertificationWfPlugin.checkReturnOrRenewalCertificate(primaryBusinessObject);
    public static void checkReturnOrRenewalCertificate(WTObject pbo) throws Exception {
        StringBuilder msg = new StringBuilder();
        WTDocument document = (WTDocument) pbo;
        String[] strings = new String[1];
        strings[0] = document.getBranchIdentifier()+"";
        //获取证书产品信息
        List<CtRecertfOrEofItemBo> itemBos = (List<CtRecertfOrEofItemBo>) beanService.doMethod(CtCertificationServiceImpl.class, "getRecertfItemInfo", strings);
        for(CtRecertfOrEofItemBo itemBo : itemBos){
            if(!"是".equals(itemBo.getWhetherDelisted()) && !"是".equals(itemBo.getWhetherRenewCertificate())){
                msg.append("产品型号【" + itemBo.getProductType() + "】不允许不退市也不续证！\r\n");
            }
            if("是".equals(itemBo.getWhetherDelisted()) && !CtFormatUtil.hasContent(itemBo.getDelistingProcessPerson())){
                msg.append("产品型号【" + itemBo.getProductType() + "】的退市流程发起人不能为空！\r\n");
            }
            if("是".equals(itemBo.getWhetherRenewCertificate()) && !CtFormatUtil.hasContent(itemBo.getRenewalProcessPerson())){
                msg.append("产品型号【" + itemBo.getProductType() + "】的续证流程发起人不能为空！\r\n");
            }
//            if("是".equals(itemBo.getWhetherDelisted()) && "是".equals(itemBo.getWhetherRenewCertificate())){
//                msg.append("产品型号【" + itemBo.getProductType() + "】不允许退市和续证同时为“是”！\r\n");
//            }
        }
        if(msg.toString().length() > 0){
            throw new Exception(msg.toString());
        }
    }

    /**
     * 应用于认证流程：保存工程师表格数据
     * @param pbo
     * @throws WTException
     */
    public static void saveEngineerData(WTObject pbo) throws WTException {
        /*
		  ext.plm.certification.CtCertificationWfPlugin.saveEngineerData(primaryBusinessObject);
		 */
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            WTDocument document = (WTDocument) pbo;
            CtCertificationLogis.saveEngineerData(document);
        } catch (Exception e) {
            throw new WTException("保存工程师表格数据异常：" + e.getLocalizedMessage());
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }


    /**
     * 判断送检类型包含“变更确认检验”，如包含，返回“是”
     * @param pbo
     * @throws WTException
     */
    public static String checkInspectType(WTObject pbo) throws WTException {
        // result =
        // ext.plm.certification.CtCertificationWfPlugin.checkInspectType(primaryBusinessObject);
        try {
            WTDocument document = (WTDocument) pbo;
            String branchId = document.getBranchIdentifier() + "";
            String[] strings = new String[1];
            strings[0] = branchId;
            // List<CtCertificationItemBo> itemInfo =
            // service.getItemInfo(document.getBranchIdentifier() + "");
            List<CtCertificationItemBo> itemInfo = (List<CtCertificationItemBo>) beanService
                    .doMethod(CtCertificationServiceImpl.class, "getItemInfo", strings);
            for (int i = 0; i < itemInfo.size(); i++) {
                CtCertificationItemBo bo = itemInfo.get(i);
                String inspactType = bo.getInspectType();
                if ("变更确认检验".equals(inspactType)) {
                    return "是";
                }
            }
            return "否";
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("后台异常，判断送检类型包含“变更确认检验”出错！异常信息：" + e.getMessage());
        }
    }
}
