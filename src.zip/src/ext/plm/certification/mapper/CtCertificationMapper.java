package ext.plm.certification.mapper;

import ext.plm.certification.bo.CtCertificationFileItemBo;
import ext.plm.certification.bo.CtCertificationItemBo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

@Mapper
public interface CtCertificationMapper {
    //查询item信息
    List<CtCertificationItemBo> getItemInfo(@Param("certfId") String certfId);

    List<CtCertificationFileItemBo> getFileItemInfo(@Param("certfId") String certfId);

    void updateAttById(@Param("dbTableName") String dbTableName, @Param("id") String id, @Param("attKey") String attKey, @Param("attValue") String attValue);

    //删除item信息
    void deleteItemInfo(@Param("tableName") String tableName, @Param("ids") List<Long> idList);

    //查询产品型号集合
    List<HashMap<String,String>> getProductTypes(@Param("certfId") String certfId);

    //查询将过期的认证证书
    List<HashMap<String,String>> queryExpireCertfDoc();

    //生成标识id
    String queryMaxTagId(@Param("certfId") String certfId);

    CtCertificationItemBo getCertfInfoByTagId(@Param("tagId") String tagId, @Param("docBranchId") String docBranchId);

    String queryMaxDocNumber(@Param("numberPrefix") String numberPrefix, @Param("tag") String tag);

    void deleteFileItemData(@Param("branchId") String branchId, @Param("tagIdList") List<String> tagIdList);

    //获取所有证书
    List<String> getAllCertificateInfo();
}
