package ext.plm.certification.mapper;

import ext.plm.certification.bo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

@Mapper
public interface CtRecertfOrEofMapper {
    //添加form数据
    void addFromInfo(@Param("applyBo") CtRecertfOrEofApplyBo applyBo);
    //查询form表单中数据
    CtRecertfOrEofApplyBo getFormInfo(@Param("branchId") String branchId);
    //查询item信息
    List<CtRecertfOrEofItemBo> getItemInfo(@Param("branchId") String branchId);
    //根据id查询Item信息
    CtRecertfOrEofItemBo getItemInfoById(@Param("id") String id);
    //查询FinishedItem信息
    List<CtRecertfOrEofFinishedItemBo> getFinishedItemInfo(@Param("branchId") String branchId);
    //根据id查询FinishedItem信息
    CtRecertfOrEofFinishedItemBo getFinishedItemInfoById(@Param("id") String id);
    //查询SemiItem信息
    List<CtRecertfOrEofSemiItemBo> getSemiItemInfo(@Param("branchId") String branchId);
    //查询SpecialItem信息
    List<CtRecertfOrEofSpecialItemBo> getSpecialItemInfo(@Param("branchId") String branchId);
    //根据型号和编号获取文档
    List<HashMap<String,Object>> getBranchIds(@Param("numberIba") String numberIba, @Param("number") String number, @Param("type") String type);
    //根据型号获取文档
    List<HashMap<String,Object>> getBranchIdsByType(@Param("type") String type);

    //获取物料编号是否已存在
    HashMap<String,String> checkPartNumber(@Param("branchId") String branchId, @Param("partNumber") String partNumber, @Param("tableName") String tableName, @Param("key") String key);

    //根据表名及id获取信息
    String getItemByIdAndTable(@Param("tableName") String tableName, @Param("id") String id);

    //根据型号获取成品信息
    List<HashMap<String,Object>> getPartNumberByType(@Param("type") String type);
    //添加成品信息
    void addFinishedItemInfo(@Param("itemBo") CtRecertfOrEofFinishedItemBo itemBo);

    //添加物料信息
    void addPart(@Param("tableName") String tableName, @Param("key") String key, @Param("branchId") String branchId,
                 @Param("materialName") String materialName, @Param("unit") String unit, @Param("number") String number, @Param("inventory") String inventory);

    //获取所有证书
    HashMap<String,String> getAllCertificate();

    CtRecertfOrEofItemBo getCertfNumberById(@Param("itemId") String itemId);

    int getisDelist(@Param("type") String type, @Param("branchId") String branchId);

    void updateIsDelist(@Param("productType") String productType, @Param("isDelist") String isDelist);
}
