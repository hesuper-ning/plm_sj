package ext.plm.certification.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.certification.bo.CtDocumentPassBo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtDocumentPassBoMapper extends BaseMapper<CtDocumentPassBo> {

}
