package ext.plm.certification;

import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class dsafsa {
    /**

     * @Title: compress

     * @Description: TODO

     * @param filePaths 需要压缩的文件地址列表(绝对路径)

     * @param zipFilePath 需要压缩到哪个zip文件(无需创建这样一个zip，只需要指定一个全路径)

     * @param keepDirStructure 压缩后目录是否保持原目录结构

     * @throws IOException

     * @return int 压缩成功的文件个数

     */

    public static int compress(List filePaths, String zipFilePath,Boolean keepDirStructure) throws IOException{

        byte[] buf = new byte[1024];

        File zipFile = new File(zipFilePath);

//zip文件不存在，则创建文件，用于压缩

        if(!zipFile.exists())

            zipFile.createNewFile();

        int fileCount = 0;//记录压缩了几个文件？

        try {

            ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile));

            for(int i = 0; i < filePaths.size(); i++){

                String relativePath = (String) filePaths.get(i);

                if(StringUtils.isEmpty(relativePath)){

                    continue;

                }

                File sourceFile = new File(relativePath);//绝对路径找到file

                if(sourceFile == null || !sourceFile.exists()){

                    continue;

                }

                FileInputStream fis = new FileInputStream(sourceFile);

                if(keepDirStructure!=null && keepDirStructure){

//保持目录结构

                    zos.putNextEntry(new ZipEntry(relativePath));

                }else{

//直接放到压缩包的根目录

                    zos.putNextEntry(new ZipEntry(sourceFile.getName()));

                }

//System.out.println("压缩当前文件："+sourceFile.getName());

                int len;

                while((len = fis.read(buf)) > 0){

                    zos.write(buf, 0, len);

                }

                zos.closeEntry();

                fis.close();

                fileCount++;

            }

            zos.close();

//System.out.println("压缩完成");

        } catch (Exception e) {

            e.printStackTrace();

        }

        return fileCount;

    }


    public static void main(String[] args) throws IOException {
       /* String pattern = "((((1[6-9]|[2-9]\\d)\\d{2})(\\/|\\-)(0?[13578]|1[02])(\\/|\\-)(0?[1-9]|[12]\\d|3[01]))|(((1[6-9]|[2-9]\\d)\\d{2})(\\/|\\-)(0?[13456789]|1[012])(\\/|\\-)(0?[1-9]|[12]\\d|30))|(((1[6-9]|[2-9]\\d)\\d{2})(\\/|\\-)0?2(\\/|\\-)(0?[1-9]|1\\d|2[0-8]))|(((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))-0?2-29-))";
        String date = "2050/6/6";
        String s = "泛海三江“工程变更表单”-2021.6.3.xlsx";
        boolean isMatch = Pattern.matches(pattern, date);
        int i = s.lastIndexOf(".");
        String substring = s.substring(0, i);
        String substring1 = s.substring(i, s.length());
        System.out.println(substring+"(1)"+substring1);*/
        String s = "fajdadnaddciw";
        int i1 = s.hashCode();
        HashSet s1 = new HashSet();
        int h;
         int s12 = (h = s.hashCode()) ^ (h >>> 16);
        System.out.println("i1 = " + s12);
    }
}
