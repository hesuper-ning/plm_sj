package ext.plm.certification;

import ext.plm.common.CtConstant;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtFormatUtil;
import wt.method.MethodContext;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CtCertificationQuery {

    /**
     * 保存字段（存在时更新，不存在时新建）
     *
     * @param attKey       字段key
     * @param attValue     字段值
     * @param formMasterId 属性主表单的id
     * @throws Exception
     */
    public void saveAttribute(String attKey, String attValue, String formMasterId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {

            String updateSql = "update ZCERTFFORMATTS set attValue = ? where  masterId = ? and attKey= ?";
            statement = connection.prepareStatement(updateSql);
            statement.setString(1, attValue);
            statement.setString(2, formMasterId);
            statement.setString(3, attKey);
            int updateCount = statement.executeUpdate();

            // 更新条数为0，说明数据不存在，则执行添加
            if (updateCount == 0) {
                System.out.println(">>>>>新增字段>>>>" + attKey + ">>>>" + attValue);
                String createSql = "insert into ZCERTFFORMATTS(masterId,attKey,attValue)  values(?,?,?)";
                statement = connection.prepareStatement(createSql);
                statement.setString(1, formMasterId);
                statement.setString(2, attKey);
                statement.setString(3, attValue);
                statement.execute();
            } else {
                System.out.println(">>>>>执行保存>>>>" + attKey + ">>>>" + attValue + ">>>updateCount=" + updateCount);
            }

            connection.getConnection().commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();

            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 获取单个属性值（用于必填验证）
     *
     * @param certfId 变更单id
     * @param attKey  属性内部值
     */
    public String getAttributeValue(String certfId, String attKey) throws Exception {

        String attValue = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {

            String sql = "select attValue from ZCERTFFORMMASTER formMaster,ZCERTFFORMATTS atts "
                    + " where formMaster.id = atts.masterid " + " and formMaster.docBranchId =? and atts.attkey=? ";
            statement = connection.prepareStatement(sql);
            statement.setString(1, certfId);
            statement.setString(2, attKey);
            resultSet = statement.executeQuery();

            // 脏数据预防
            if (resultSet.getRow() > 1) {
                System.out.println(">>>数据库异常，存在脏数据，存在多条记录,attKey='" + attKey + ">>certfId=" + certfId);
                throw new WTException("数据库异常，存在脏数据，attKey='" + attKey + "'存在多条记录，本应该只有一条！请联系管理员！");
            }

            while (resultSet.next()) {
                attValue = resultSet.getString("attValue");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            // connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }

        return attValue;
    }

    /**
     * 查询认证表头信息
     *
     */
    public HashMap<String, String> getHeadInfo(String certfId) throws Exception {

        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        HashMap<String, String> resultData = new HashMap<String, String>();

        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "select attKey,attValue from ZCERTFFORMMASTER formMaster,ZCERTFFORMATTS atts "
                    + " where formMaster.id = atts.masterid "
                    + "and formMaster.docBranchId = ? ";
            statement = connection.prepareStatement(sql);
            statement.setString(1, certfId);
            result = statement.executeQuery();

            while (result.next()) {
                String attkey = result.getString("attKey");
                if(resultData.containsKey(attkey)) {
                    //检测是否存在重复key
                    System.out.println(">>>认证表单'"+certfId+"'存在重复key:"+attkey);
                }
                resultData.put(result.getString("attKey"), result.getString("attValue"));
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }

        return resultData;
    }


    /**
     * 通过文档branchId，和附件表格的Id查认证信息
     * @param branchId
     * @param id
     * @return
     * @throws Exception
     */
    public Map<String, String> getCertificationInfoByFileItemId(String branchId, String id) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        Map<String, String> resultData = new HashMap<String, String>();

        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT c.CERTFTYPE, c.PRODUCTTYPE, c.NAME, c.INSPECTTYPE FROM ZCertfFileItem t")
                    .append(" LEFT JOIN ZCERTFITEM c ON c.TAGID=t.TAGID AND c.DOCBRANCHID = t.DOCBRANCHID")
                    .append(" WHERE t.DOCBRANCHID = ? AND t.id = ?");
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, branchId);
            statement.setString(2, id);
            result = statement.executeQuery();

            if (result.next()) {
                resultData.put("certificationType", result.getString(1));
                resultData.put("productType", result.getString(2));
                resultData.put("productName", result.getString(3));
                resultData.put("inspectType", result.getString(4));
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return resultData;
    }

    /**
     * 查询活动表单主表是否创建,无则创建，并返回id
     *
     * @param certfId
     * @param activityKey
     * @return formMasterId 主键id
     */
    public String genFormMasterId(String certfId, String activityKey) throws Exception {

        String formMasterId = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();

        PreparedStatement statement = null;
        ResultSet result = null;
        String sql;
        boolean updateFlag = false;
        try {
            sql = "select * from  ZCERTFFORMMASTER where docBranchId=? and activityKey=?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, certfId);
            statement.setString(2, activityKey);
            result = statement.executeQuery();
            // 脏数据预防
            if (result.getRow() > 1) {
                throw new Exception("数据库异常，存在脏数据，请检查ZCERTFFORMMASTER表，docBranchId=" + certfId + ",activityKey="
                        + activityKey);
            }

            while (result.next()) {
                formMasterId = result.getString("id");
            }

            // 开始创建
            if (!CtFormatUtil.hasContent(formMasterId)) {
                sql = "select ZCertf_seq.NEXTVAL masterId from dual";
                statement = connection.prepareStatement(sql);
                result = statement.executeQuery();
                while (result.next()) {
                    formMasterId = result.getString("masterId");
                }
                sql = "insert into ZCERTFFORMMASTER(id,docBranchId,activityKey) " + " values(?,?,?)";
                statement = connection.prepareStatement(sql);
                statement.setString(1, formMasterId);
                statement.setString(2, certfId);
                statement.setString(3, activityKey);
                statement.execute();
                updateFlag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if(updateFlag) connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }

        return formMasterId;
    }


    /**
     * 按id更新属性(一般用于列表）
     * @param dbTableName 表名
     * @param id id
     * @param attKey  列名
     * @param attValue 值
     * @throws Exception
     */
    public void updateAttById(String dbTableName, String id,String attKey, String attValue) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;

        try {
            String sql ="update "+ dbTableName +" set ";
            sql += attKey+" = '"+ attValue +"' WHERE id = '"+id+"'";
            System.out.println(">>>sql=="+sql);
            statement = connection.prepareStatement(sql);

            statement.execute();

        }
        catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
                connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 认证表格插入空数据
     * @param
     * @throws Exception
     */
    public void certfInsertAttTagId(String dbTableName, String certfId,String tagId) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "";
            sql = "INSERT INTO "+dbTableName+" (ID,docBranchId,tagId) VALUES(ZCertf_seq.NEXTVAL,?,?)";
            System.out.println(">>>sql=="+sql);
            statement = connection.prepareStatement(sql);
            statement.setString(1,certfId);
            statement.setString(2,tagId);

            boolean execute = statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 认证表格插入空数据
     * @param
     * @throws Exception
     */
    public void certfInsertAttById(String dbTableName, String certfId) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "";
            sql = "INSERT INTO "+dbTableName+" (ID,docBranchId) VALUES(ZCertf_seq.NEXTVAL,?)";
            System.out.println(">>>sql=="+sql);
            statement = connection.prepareStatement(sql);
            statement.setString(1,certfId);

            boolean execute = statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 退市表格插入空数据
     * @param
     * @param
     * @throws Exception
     */
    public void recertfInsertAttById(String dbTableName, String certfId) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "";
            sql = "INSERT INTO "+dbTableName+" (ID,docBranchId) VALUES(ZCertf_seq.NEXTVAL,?)";
            System.out.println(">>>sql=="+sql);
            statement = connection.prepareStatement(sql);
            statement.setString(1,certfId);

            boolean execute = statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 加入文档名称
     * @param
     * @throws Exception
     */
    public void saveDocName(String dbTableName, String id, String docName) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "";
            sql = "UPDATE "+dbTableName+" set FILENAME = ? WHERE id = ?";
            System.out.println(">>>sql=="+sql);
            statement = connection.prepareStatement(sql);
            statement.setString(1,docName);
            statement.setString(2,id);

            boolean execute = statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 查询将过期的认证证书
     * 过滤条件： 文档类型 "wt.doc.WTDocument|com.fhsj.Doc_fhsj|com.fhsj.Doc_rz|com.fhsj.Doc_zs"
     * 有效日期内部名称”ct_Certificateexpirationdate“， 生命周期状态为量产发布”ProductionRelease“，提前90天通知
     * @return
     * @throws Exception
     */
    public List<HashMap<String,String>> queryExpireCertfDoc() throws Exception {

        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();

        List<HashMap<String,String>> resultList = new ArrayList<HashMap<String,String>>();
        PreparedStatement statement = null;
        ResultSet result = null;
        StringBuffer sqlSB = new StringBuffer();
        try {

			/*select docMaster.Name,docMaster.Wtdocumentnumber,wtdoc.versionida2versioninfo versionStr,timeValue.value validDate
			 from wtdocument wtdoc, wtdocumentmaster docMaster,Wttypedefinition typed,
			  Wttypedefinitionmaster typeMaster,TimestampDefinition timeDef, TimestampValue timeValue
			where wtdoc.ida3masterreference = docMaster.Ida2a2
			and wtdoc.latestiterationinfo =1
			and wtdoc.ida2typedefinitionreference = typed.ida2a2   --softtype info
			and typed.ida3masterreference = typeMaster.Ida2a2
			and typeMaster.Inthid = 'wt.doc.WTDocument|com.fibocom.ghtDocs|com.fibocom.ght_TechnologyDoc|com.fibocom.ght_AuthenticationDocumentDoc|com.fibocom.CF-004_rzzs'
			and timeValue.Ida3a4 = wtdoc.ida2a2
			and timeValue.ida3a6 = timeDef.Ida2a2
			and timeDef.name = 'ctf_expireDate'
			and wtdoc.statestate = 'RELEASED'
			and to_date('2019-9-20','yyyy-mm-dd') > timeValue.value - 30*/

            sqlSB.append("select docMaster.name,docMaster.Wtdocumentnumber docNumber,wtdoc.versionida2versioninfo versionStr,timeValue.value validDate")
                    .append(" from wtdocument wtdoc, wtdocumentmaster docMaster,Wttypedefinition typed,")
                    .append(" Wttypedefinitionmaster typeMaster,TimestampDefinition timeDef, TimestampValue timeValue")
                    .append(" where wtdoc.ida3masterreference = docMaster.Ida2a2")
                    .append(" and wtdoc.latestiterationinfo =1")
                    .append(" and wtdoc.ida2typedefinitionreference = typed.ida2a2 ")
                    .append(" and typed.ida3masterreference = typeMaster.Ida2a2")
                    .append(" and typeMaster.Inthid = 'wt.doc.WTDocument|com.fhsj.Doc_fhsj|com.fhsj.Doc_rz|com.fhsj.Doc_zs'")
                    .append(" and timeValue.Ida3a4 = wtdoc.ida2a2")
                    .append(" and timeValue.ida3a6 = timeDef.Ida2a2")
                    .append(" and timeDef.name = 'ct_Certificateexpirationdate'") //有效日期内部名称“ctf_expireDate”
                    //.append(" and wtdoc.statestate = 'RELEASED'")  //状态过滤为已发布 ”RELEASED“
                    .append(" and to_date('"+CtDateUtil.getCurrentDate("yyyy-MM-dd",null)+"','yyyy-mm-dd') > timeValue.value - 90 "); //提前120天通知

            statement = connection.prepareStatement(sqlSB.toString());
            result = statement.executeQuery();
            HashMap<String,String> record = null;
            while (result.next()) {
                record = new HashMap<String,String>();
                String name = result.getString("name");
                record.put("name", name);
                String docNumber = result.getString("docNumber");
                record.put("docNumber", docNumber);
                String version= result.getString("versionStr");
                record.put("version", version);
                String validDate= CtDateUtil.parseDate(result.getDate("validDate"), "yyyy-MM-dd","GMT+8");
                record.put("validDate", validDate);
                resultList.add(record);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null) statement.close();
            if (connection != null && connection.isActive()) connection.release();
        }

        return resultList;
    }

    /**
     * 获取序列值
     *
     * @return 序列值
     * @throws Exception
     */
    public String getSequence(String number) throws Exception {

        String nextSeq = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        String sql= "";
        try {
            if ("1".equals(number)) {
                sql = "select  MAX(id) id from ZRecertfOrEofSpecialItem";
            }else if("2".equals(number)){
                sql = "select  MAX(id) id from ZRecertfOrEofSemiItem";
            }
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();

            while (result.next()) {
                nextSeq = result.getString("id");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return nextSeq;
    }

}
