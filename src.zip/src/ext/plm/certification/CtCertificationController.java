package ext.plm.certification;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.certification.bo.*;
import ext.plm.certification.service.CtDocumentPassService;
import ext.plm.common.CtResApiResult;
import ext.plm.risk.CtRiskLogic;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wt.content.ApplicationData;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.wip.WorkInProgressHelper;
import wt.workflow.work.WorkItem;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

@RestController
public class CtCertificationController {

    @Autowired
    private CtCertificationService service;
    @Autowired
    private CtDocumentPassService ctDocumentPassService;

    //保存数据之前校验workItem是否完成
    //前台需要把workItemOid传过来  操作数据的controller中调用 查询的不用
    public void checkEditAccess(String oid) throws Exception {

        if (CtFormatUtil.hasContent(oid)) {
            wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
            WorkItem workItem = (WorkItem) rf.getReference(oid).getObject();
            if (workItem != null && workItem.isComplete()) {
                throw new Exception("活动已完成，请刷新页面");
            }
        }
    }


    //查询认证表头信息
    @RequestMapping(value = "/certf/getCertfApplyForm", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getHeadInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        String certfId = request.getParameter("certfId");
        try {
            HashMap<String, String> headInfo = service.getHeadInfo(certfId);
            String s = JSONObject.toJSONString(headInfo);
            result = JSONObject.parseObject(s);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询认证表头信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //单个保存表头属性
    @RequestMapping(value = "/certf/autoSaveAtt", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void autoSaveAtt(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("data"));
            String certfId = dataJson.getString("certfId");
            String attKey = dataJson.getString("attKey");
            String attValue = dataJson.getString("attValue");
            String activityKey = dataJson.getString("activityKey");
            String oid = dataJson.getString("oid");
            checkEditAccess(oid);
            service.saveAttribute(certfId, activityKey, attKey, attValue);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "实时保存失败:" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //查询grid信息
    @RequestMapping(value = "/certf/getItemsByCertfId", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getItemInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String certfId = request.getParameter("certfId");
            List<CtCertificationItemBo> itemInfo = service.getItemInfo(certfId);

            String jsonArrStr = JSON.toJSONString(itemInfo);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("item", itemArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询认证基本信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //查询grid信息
    @RequestMapping(value = "/certf/getFileItemsByCertfId", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getFileItemsByCertfId(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String certfId = request.getParameter("certfId");
            List<CtCertificationFileItemBo> itemInfo = service.getFileItemInfo(certfId);

            String jsonArrStr = JSON.toJSONString(itemInfo);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("item", itemArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询认证基本信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //实时保存grid数据
    @RequestMapping(value = "/certf/saveItemData", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void saveItemData(HttpServletRequest request, HttpServletResponse response) throws Exception, WTException {
        JSONObject result = new JSONObject();

        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("updateRecord"));
            String dbTableName = dataJson.getString("dbTableName");
            String itemId = dataJson.getString("itemId");
            String dataKey = dataJson.getString("dataKey");
            String dataValue = dataJson.getString("dataValue");
            String oid = dataJson.getString("oid");
            checkEditAccess(oid);

            service.saveItemData(dbTableName, itemId, dataKey, dataValue);

            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "保存失败！" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //grid插入null数据
    @RequestMapping(value = "/certf/insertItemData", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void insertItemData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String certfId = request.getParameter("certfId");
            String dbTableName = request.getParameter("dbTableName");
            String oid = request.getParameter("oid");
            checkEditAccess(oid);

            service.certfInsertAttById(dbTableName, certfId);
            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "插入失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //删除grid信息
    @RequestMapping(value = "/certf/deleteItemData", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void deleteItemData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String data = request.getParameter("data");
            String tagIds = request.getParameter("tagIds");
            List<Long> idList = JSON.parseObject(data, List.class);

            String dbTableName = request.getParameter("tableName");
            String branchId = request.getParameter("branchId");
            String oid = request.getParameter("oid");
            checkEditAccess(oid);

            service.deleteItemData(dbTableName, idList);
            if (CtFormatUtil.hasContent(tagIds)){
                List<String> tagIdList = JSON.parseObject(tagIds, List.class);
                service.deleteFileItemData(branchId,tagIdList);
            }

            result.put("success", true);
            result.put("msg", "删除成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "删除失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    //查询产品型号集合
    @RequestMapping(value = "/certf/getProductTypes", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getProductTypes(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String certfId = request.getParameter("certfId");
            List<HashMap<String, String>> productTypes = service.getProductTypes(certfId);

            String jsonArrStr = JSON.toJSONString(productTypes);
            JSONArray itemsArr = JSON.parseArray(jsonArrStr);
            System.out.println("productTypes" + jsonArrStr);
            result.put("items", itemsArr);
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询产品型号信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //获取产品名称
    @RequestMapping(value = "/certf/getCertfNumberLink", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public CtResApiResult getCertfNumberLink(@RequestParam("certfNumber") String certfNumber) {
        try {
            String link = "";
            if (CtFormatUtil.hasContent(certfNumber)) {
                String[] numbers = certfNumber.split(",");
                for (String number : numbers) {
                    WTDocument document = CtDocUtil.getDocumentByNumber(number);

                    if (CtFormatUtil.hasContent(document)) {
                        if (WorkInProgressHelper.isCheckedOut(document)){
                            return CtResApiResult.fail("所填写的文档编号的文档已被检出，请检入后填写！！！");
                        }
                        String docType = CtWTObjectUtil.getTypeIdentifier(document);
                        if (!docType.contains("com.fhsj.Doc_zs")){
                            return CtResApiResult.fail("所填写的文档编号不是证书类型！！！");
                        }
                        link = CtFormatUtil.combineStr(link, CtFormatUtil.getURL(document, document.getNumber()), ",");
                    }else {
                        return CtResApiResult.fail("证书文档不存在请检查编号!!!");
                    }
                }
            }
            return CtResApiResult.success(link);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("查询状态信息失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /////////退市||续证

    //查询认证表头信息
    @RequestMapping(value = "/certf/getRecertfForm", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getRecertfForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        String branchId = request.getParameter("branchId");
        try {
            CtRecertfOrEofApplyBo headInfo = service.getFormInfo(branchId);
            String s = JSONObject.toJSONString(headInfo);
            result = JSONObject.parseObject(s);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询退市/续证表头信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //查询grid信息
    @RequestMapping(value = "/recertf/getItemByBranchId", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getItemByBranchId(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String branchId = request.getParameter("branchId");
            List<CtRecertfOrEofItemBo> recertfItemInfo = service.getRecertfItemInfo(branchId);

            String jsonArrStr = JSON.toJSONString(recertfItemInfo);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("item", itemArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询退市/续证信息Grid失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //实时保存grid数据
    @RequestMapping(value = "/recertf/recertfSaveItemData", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void recertfSaveItemData(HttpServletRequest request, HttpServletResponse response) throws Exception, WTException {
        JSONObject result = new JSONObject();

        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("updateRecord"));
            String dbTableName = dataJson.getString("dbTableName");
            String itemId = dataJson.getString("itemId");
            String dataKey = dataJson.getString("dataKey");
            String dataValue = dataJson.getString("dataValue");
            String oid = dataJson.getString("oid");
            checkEditAccess(oid);

           service.recertfSaveItemData(dbTableName, itemId, dataKey, dataValue);

            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (WTException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "保存失败！" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //查询grid信息
    @RequestMapping(value = "/recertf/getSpecialItemByBranchId", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getSpecialItemByBranchId(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String branchId = request.getParameter("branchId");
            List<CtRecertfOrEofSpecialItemBo> specialItemInfo = service.getSpecialItemInfo(branchId);

            String jsonArrStr = JSON.toJSONString(specialItemInfo);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("item", itemArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询专用物料Grid信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //查询grid信息
    @RequestMapping(value = "/recertf/getSemiItemByBranchId", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getSemiItemByBranchId(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String branchId = request.getParameter("branchId");
            List<CtRecertfOrEofSemiItemBo> semiItemInfo = service.getSemiItemInfo(branchId);

            String jsonArrStr = JSON.toJSONString(semiItemInfo);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("item", itemArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询半成品物料Grid信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //查询grid信息
    @RequestMapping(value = "/recertf/getFinishItemByBranchId", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getFinishItemByBranchId(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String branchId = request.getParameter("branchId");
            List<CtRecertfOrEofFinishedItemBo> finishedItemInfo = service.getFinishedItemInfo(branchId);

            String jsonArrStr = JSON.toJSONString(finishedItemInfo);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("item", itemArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询成品物料Grid信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //grid插入null数据
    @RequestMapping(value = "/recertf/insertItemData", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void insertNullItem(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String branchId = request.getParameter("branchId");
            String dbTableName = request.getParameter("dbTableName");
            String oid = request.getParameter("oid");
            checkEditAccess(oid);
            //CtCertificationLogis.sendCertfDocExpireNoticeMail();
            service.recertfInsertAttById(dbTableName, branchId);

            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "插入失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //获取证书编号
    @RequestMapping(value = "/recertf/getCertificateNumber", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getCertificateNumber(HttpServletRequest request, HttpServletResponse response) throws Exception, WTException {
        JSONObject result = new JSONObject();

        try {

            String itemId =request.getParameter("id");

            HashMap<String, List<HashMap<String, String>>> map = service.getCertificateInfo(itemId);

            if (CtFormatUtil.hasContent(map)) {
                if (CtFormatUtil.hasContent(map.get("numbers"))) {
                    result.put("items", map.get("numbers"));
                    List<HashMap<String, String>> maps = map.get("numbers");
                    if (maps.size() == 1){
                        service.recertfSaveItemData("ZRecertfOrEofItem", itemId, "certfNumber", maps.get(0).get("displayText"));
                    }
                    System.out.println("result.get(numbers)>>>>>>>>>>>:" + result.get("items"));
                }
            }
            result.put("success", true);
            result.put("msg", "获取证书编号成功！");
        } catch (WTException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "获取证书编号失败！" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //获取认证/检验类型信息
    @RequestMapping(value = "/recertf/getType", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getCertificateInfo(HttpServletRequest request, HttpServletResponse response) throws Exception, WTException {
        JSONObject result = new JSONObject();

        try {
            String type =request.getParameter("type");

            List<HashMap<String, String>> certificateType = service.getCertificateType(type);

            /*if (CtFormatUtil.hasContent(map)) {
                if (CtFormatUtil.hasContent(map.get("types"))) {
                    result.put("items", map.get("types"));
                    System.out.println("result.get(types)>>>>>>>>>>>:" + result.get("items"));
                }
            }*/
            result.put("items", certificateType);
            result.put("success", true);
            result.put("msg", "获取认证/检验类型成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "获取认证/检验类型失败！" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //获取证书/报告到期时间信息
    @RequestMapping(value = "/recertf/endDateStore", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void endDateStore(HttpServletRequest request, HttpServletResponse response) throws Exception, WTException {
        JSONObject result = new JSONObject();

        try {
            String itemId =request.getParameter("id");

            HashMap<String, List<HashMap<String, String>>> map = service.getCertificateInfo( itemId);

            if (CtFormatUtil.hasContent(map)) {
                if (CtFormatUtil.hasContent(map.get("endDates"))) {
                    result.put("items", map.get("endDates"));
                    List<HashMap<String, String>> maps = map.get("endDates");
                    if (maps.size() == 1){
                        service.recertfSaveItemData("ZRecertfOrEofItem", itemId, "certfDueDate", maps.get(0).get("displayText"));
                    }
                    System.out.println("result.get(endDates)>>>>>>>>>>>:" + result.get("items"));
                }
            }
            result.put("success", true);
            result.put("msg", "获取证书/报告到期时间成功！");
        } catch (WTException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "获取证书/报告到期时间失败！" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }
    //获取产品名称
    @RequestMapping(value = "/recertf/productNameStore", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void productNameStore(HttpServletRequest request, HttpServletResponse response) throws Exception, WTException {
        JSONObject result = new JSONObject();

        try {
            String itemId =request.getParameter("id");

            HashMap<String, List<HashMap<String, String>>> map = service.getCertificateInfo( itemId);

            if (CtFormatUtil.hasContent(map)) {
                if (CtFormatUtil.hasContent(map.get("productNames"))) {
                    result.put("items", map.get("productNames"));
                    List<HashMap<String, String>> maps = map.get("productNames");
                    if (maps.size() == 1){
                        service.recertfSaveItemData("ZRecertfOrEofItem", itemId, "productName", maps.get(0).get("displayText"));
                    }
                    System.out.println("result.get(productNames)>>>>>>>>>>>:" + result.get("items"));
                }
            }
            result.put("success", true);
            result.put("msg", "获取产品名称成功！");
        } catch (WTException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "获取产品名称成功！" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 导入物料信息
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/recertf/importRecertfAssess",method = {RequestMethod.GET,RequestMethod.POST})
    public void importRecertfAssess(HttpServletRequest request, HttpServletResponse response) throws Exception{
        JSONObject result = new JSONObject();
        String msg ="";
        try {
            String proOid = request.getParameter("proOid");
            String oid = request.getParameter("oid");
            String number = request.getParameter("number");


            checkEditAccess(oid);
            File file = null;
            DiskFileItemFactory fac = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(fac);

            List<FileItem> fileItems = new ArrayList<FileItem>();
            fileItems = upload.parseRequest(request);
            Iterator<FileItem> it = fileItems.iterator();


            while (it.hasNext()) {
                FileItem item = (FileItem) it.next();
                String name = item.getName();
                File tFile = new File(name); // 借助此File获得不带本地路径的文件名
                file = CtRiskLogic.changeFileName(tFile);
                item.write(file);
            }
            // 获取上传的文件
             service.importRecertfAssess(proOid, file,number);
            if(CtFormatUtil.hasContent(msg)){
                throw new WTException(msg);
            }
            result.put("success", true);
            result.put("msg", "导入成功");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "导入失败" + e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }


    // *********************开始*****上传*下载*删除附件*********************************//

    /**
     * 上传文件到服务器
     */
    @RequestMapping(value = "/certf/uploadFiles", method = RequestMethod.POST)
    public void uploadFiles(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        try {
            String branchId = request.getParameter("branchId");
            String tetx_name = request.getParameter("tetx_name");
            String type = request.getParameter("type");
            String node = request.getParameter("node");// 用来判断删除的
            String id = request.getParameter("id");
            WTProperties wtproperty = WTProperties.getLocalProperties();
            Date date = new Date();
            String filePath = wtproperty.getProperty("wt.home") + File.separator + "CtFile" + File.separator + "certification" + File.separator  + branchId + File.separator + type + File.separator;// 临时路经
            List<CtCertificationItemBo> itemInfo = service.getItemInfo(branchId);
            String fileName = CtCertificationLogis.getFileNameAndUpload(filePath, request);//实现上传文件至服务器
            File file = new File(filePath + File.separator + fileName);//获取服务器文件

            Map<String, String> fileInfoMap = CtCertificationLogis.uploadFiles(file, branchId, tetx_name, node,type,id);//获取显示至前端的附件链接
            //service.updateAttachmentPath(filePath + fileName,branchId);
            result.put("fileName", fileInfoMap.get("docUrl"));
            result.put("filePath", filePath + fileInfoMap.get("fileName"));
            result.put("success", true);
            result.put("msg", "上传成功");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            result.put("success", false);
            result.put("msg", "上传附件异常信息：\r\n" + error);
        } finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    /**
     * 删除附件
     */
    @RequestMapping(value = "/certf/deleteFiles", method = RequestMethod.POST)
    public static void deleteFiles(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        try {

            WTProperties wtproperty = WTProperties.getLocalProperties();
            Date date = new Date();
            String fileName = request.getParameter("fileName");
            String branchId = request.getParameter("branchId");
            String type = request.getParameter("type");
            String filePath = wtproperty.getProperty("wt.home") + File.separator + "CtFile" + File.separator + "certification" + File.separator  + branchId + File.separator + type + File.separator;// 临时路经

            File file = new File(filePath + File.separator + fileName);//获取服务器文件
            CtCertificationLogis.deleteFiles(branchId, fileName);
            result.put("fileName", fileName);
            result.put("success", true);
            result.put("msg", fileName + "删除成功！");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            result.put("success", false);
            result.put("msg", "删除附件异常信息：\r\n" + error);
        } finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 下载附件
     *
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/certf/downLoadDoc", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public static void downLoadDoc(HttpServletRequest request, HttpServletResponse response) throws Exception {
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        JSONObject result = new JSONObject();
        String userAgent = request.getHeader("User-Agent");
        WTProperties wtproperty = WTProperties.getLocalProperties();
        Date date = new Date();
        String fileName = request.getParameter("fileName");
        String appDataFileName = fileName;
        String branchId = request.getParameter("branchId");
        String type = request.getParameter("type");
        String filePath = wtproperty.getProperty("wt.home") + File.separator + "CtFile" + File.separator + "certification" + File.separator  + branchId + File.separator + type + File.separator;// 临时路经
        File file = new File(filePath + File.separator + fileName);//获取服务器文件
        OutputStream out = null;
        InputStream in = null;
        if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
            //ie
            fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
        } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
            //edge
            fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
        } else {
            // //firefox、chrome、safari、opera：
            fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
        }
        response.setContentType("application/octet-stream");
        response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
        response.setCharacterEncoding("UTF-8");
        int len;
        //获取文件输入流
        ApplicationData appData = CtCertificationLogis.getApplicationData(branchId, appDataFileName);
        if(appData != null) {
            //获取文件输入流
            in = ContentServerHelper.service.findContentStream(appData);
        }else{
            in = new FileInputStream(file);
        }
        byte[] buffer = new byte[10240];
        out = response.getOutputStream();
        while ((len = in.read(buffer)) > 0) {
            //将缓冲区的数据输出到客户端浏览器
            out.write(buffer, 0, len);
        }
        result.put("success", true);
        result.put("msg", "下载成功！");
        out.close();
        in.close();
        response.setCharacterEncoding("utf-8");

    }
    // *********************结束*****上传*下载*删除附件*********************************//


    //所有证书信息
    @RequestMapping(value = "/certf/getAllCertificateInfo", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getAllCertificateInfo(HttpServletRequest request, HttpServletResponse response) throws Exception, WTException {
        JSONObject result = new JSONObject();

        try {

            List<HashMap<String, String>> allCertificateInfo = service.getAllCertificateInfo();


            result.put("items", allCertificateInfo);
            result.put("success", true);
            result.put("msg", "所有证书信息！");
        } catch (WTException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "所有证书信息！" + e.getLocalizedMessage());
        }
    }

    //查询grid信息
    @RequestMapping(value = "/certf/getDocumentPassData", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public void getDocumentPassData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            String certfId = request.getParameter("certfId");
            List<CtDocumentPassBo> itemInfo = ctDocumentPassService.getDocumentPassData(certfId);
            String jsonArrStr = JSON.toJSONString(itemInfo);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("item", itemArr);
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询认证基本信息失败！");
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     *
     * @param request
     * @return
     */
    @RequestMapping(value = {"/certf/updateDocumentPassBo"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult updateDocumentPassBo(HttpServletRequest request) {
        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("updateRecord"));
            String id = dataJson.getString("id");
            String key = dataJson.getString("key");
            String value = dataJson.getString("value");
            ctDocumentPassService.updateDocumentPassBo(id, key, value);
            return CtResApiResult.success();
        } catch (Exception e) {
            return CtResApiResult.fail("修改数据失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }
}
