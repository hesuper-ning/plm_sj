package ext.plm.certification;

import ext.plm.certification.bo.*;
import wt.util.WTException;

import java.io.File;
import java.util.HashMap;
import java.util.List;

public interface CtCertificationService {
    //获取表单信息
    HashMap<String,String> getHeadInfo(String changeRequestId) throws Exception;
    //实时保存表单信息
    void saveAttribute(String certfId, String activityKey, String attKey, String attValue) throws Exception;
    //查询item信息
    List<CtCertificationItemBo> getItemInfo(String certfId)throws Exception;
    //查询item信息
    List<CtCertificationFileItemBo> getFileItemInfo(String certfId)throws Exception;
    //实时保存item信息(共用方法)
    void saveItemData(String dbTableName, String id, String attKey, String attValue) throws Exception;
    //根据标识id和branchId删除文件表单信息
    void deleteFileItemData(String branchId, List<String> tagIdList);
    //添加item信息
    void certfInsertAttById(String tableName, String certfId) throws Exception;
    //删除item信息(共用方法)
    void deleteItemData(String tableName, List<Long> idList)throws Exception;
    //查询产品型号集合
    List<HashMap<String,String>> getProductTypes(String certfId)throws Exception ;
    //发送认证证书有效期即将过期提醒
    void sendCertfDocExpireNoticeMail()throws Exception;

    void szRelevanceFinished(String path) throws Exception;

    //获取所有证书信息
    public List<HashMap<String,String>> getAllCertificateInfo() throws Exception;
    ////////////     退市/续证         ///////////////

    //查询form表单中数据
    CtRecertfOrEofApplyBo getFormInfo(String branchId)throws Exception ;
    //实时保存
    void recertfSaveItemData(String dbTableName, String id, String attKey, String attValue)throws Exception ;
    //查询item信息
    List<CtRecertfOrEofItemBo> getRecertfItemInfo(String branchId)throws Exception ;
    //查询FinishedItem信息
    List<CtRecertfOrEofFinishedItemBo> getFinishedItemInfo(String branchId)throws Exception ;
    //查询SemiItem信息
    List<CtRecertfOrEofSemiItemBo> getSemiItemInfo(String branchId)throws Exception ;
    //查询SpecialItem信息
    List<CtRecertfOrEofSpecialItemBo> getSpecialItemInfo(String branchId) throws Exception ;
    //添加item信息
    void recertfInsertAttById(String tableName, String branchId) throws Exception;
    //对应的证书编号
    List<HashMap<String,String>> getCertificateNumber(String itemId) throws Exception;
    //根据产品型号及证书/检验报告编号查询证书iba属性
    HashMap<String, List<HashMap<String,String>>> getCertificateInfo(String itemId)throws Exception;
    //导入Excel
    void importRecertfAssess(String proOid, File file, String number) throws WTException, Exception;

    //根据查询出来的成品信息插入
    void addFinishedByType(String branchId) throws Exception;

    //获取认证/报告类型
    List<HashMap<String,String>> getCertificateType(String type) throws Exception;

    //添加仅用于成品的半成品和原材料
    void addRawMaterialAndSemiFinishedProduct(String branchId) throws Exception;

}
