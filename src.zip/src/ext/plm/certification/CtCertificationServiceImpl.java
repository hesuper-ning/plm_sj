package ext.plm.certification;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import ext.plm.adTool.CtAdToolLogic;
import ext.plm.bean.CtBeanFactory;
import ext.plm.certification.bo.*;
import ext.plm.certification.config.CtCertfProperties;
import ext.plm.certification.mapper.CtCertificationMapper;
import ext.plm.certification.mapper.CtRecertfOrEofMapper;
import ext.plm.common.CtCommonQuery;
import ext.plm.doc.certificate.bo.CtCertificateListBo;
import ext.plm.doc.certificate.bo.CtModelListBo;
import ext.plm.doc.certificate.bo.CtReportChecklistBo;
import ext.plm.doc.certificate.bo.CtReportLinkBo;
import ext.plm.doc.certificate.mapper.CtCertificateListMapper;
import ext.plm.doc.certificate.mapper.CtModelListMapper;
import ext.plm.doc.certificate.mapper.CtReportChecklistMapper;
import ext.plm.doc.certificate.mapper.CtReportLinkMapper;
import ext.plm.integration.hr.CtHrLogic;
import ext.plm.integration.hr.bo.CtHrPersonBo;
import ext.plm.integration.sap.CtSapServiceImpl;
import ext.plm.integration.sap.bo.CtSapPartStorageBo;
import ext.plm.newec.helper.CtAffectedObjectHelper;
import ext.plm.sampleConfirmation.CtSampleConfirmationQuery;
import ext.plm.tool.bo.CtWTMailBo;
import ext.plm.tool.mail.CtMailTool;
import ext.plm.tool.part.CtPartCodingBo;
import ext.plm.tool.part.CtPartTool;
import ext.plm.util.*;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.util.WTException;
import wt.vc.baseline.ManagedBaseline;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class CtCertificationServiceImpl implements CtCertificationService {

    @Autowired
    private CtCertificationMapper certificationMapper;
    @Autowired
    private CtRecertfOrEofMapper eofMapper;

    /**
     * 获取认证表单信息
     *
     * @param certfId 认证id
     * @return
     * @throws Exception
     */
    @Override
    public HashMap<String, String> getHeadInfo(String certfId) throws Exception {
        CtCertificationQuery query = new CtCertificationQuery();
        HashMap<String, String> headInfo = query.getHeadInfo(certfId);

        //获取文档基本信息
        if (!CtFormatUtil.hasContent(headInfo.get("head_applyUser"))) {
            WTDocument document = CtDocUtil.getDocumentByBranchId(certfId);
            IBAUtil ibaUtil = new IBAUtil(document);
            String value = ibaUtil.getIBAValue("ct_ItemNumber");
            String creatorName = document.getCreatorFullName();
            WTUser user = CtUserUtil.getUserByDisplayName(creatorName);
            String name = user.getName();
            String creatoDate = document.getCreateTimestamp().toString().substring(0, 10);
            //获取部门名称
            CtHrPersonBo personBo = CtHrLogic.getPersonByNo(name);
            String departmentName = personBo.getDepartmentName();

            saveAttribute(certfId, "submit_node", "head_applyUser", creatorName);
            saveAttribute(certfId, "submit_node", "head_projectNumber", value);
            saveAttribute(certfId, "submit_node", "head_department", departmentName);
            saveAttribute(certfId, "submit_node", "head_applyDate", creatoDate);

            headInfo = query.getHeadInfo(certfId);
        }

        return headInfo;
    }

    /**
     * 实时保存表单信息
     *
     * @param certfId     认证流程id
     * @param activityKey 活动名称
     * @param attKey      列名
     * @param attValue    值
     * @throws Exception
     */
    @Override
    public void saveAttribute(String certfId, String activityKey, String attKey, String attValue) throws Exception {
        CtCertificationQuery query = new CtCertificationQuery();
        //先获得主表id
        String formMasterId = query.genFormMasterId(certfId, activityKey);
        if (attValue == null) {
            attValue = "";
        }
        query.saveAttribute(attKey, attValue, formMasterId);
    }


    @Override
    public List<CtCertificationItemBo> getItemInfo(String certfId) throws Exception {
        return certificationMapper.getItemInfo(certfId);
    }

    @Override
    public List<CtCertificationFileItemBo> getFileItemInfo(String certfId) throws Exception {
        List<CtCertificationFileItemBo> list = certificationMapper.getFileItemInfo(certfId);
        //处理用户，显示带部门的用户信息
        CtCommonQuery ctCommonQuery = new CtCommonQuery();
        List<Map<String, String>> userList = ctCommonQuery.queryUserList("");
        Map<String, String> userInfoMap = CtAffectedObjectHelper.convertUserInfo(userList);
        for(CtCertificationFileItemBo bo : list){
            String engineer = bo.getSubmitEngineer();
            if(!CtFormatUtil.hasContent(engineer)) {
                continue;
            }
            String displayName = userInfoMap.get(engineer);
            if(CtFormatUtil.hasContent(displayName)){
                bo.setSubmitEngineer(displayName);
            }
        }
        return list;
    }

    /**
     * 实时保存item信息
     *
     * @param dbTableName 表名
     * @param id          id
     * @param attKey      列名
     * @param attValue    值
     * @throws Exception
     */
    @Override
    public void saveItemData(String dbTableName, String id, String attKey, String attValue) throws Exception {
        if (attValue == null) {
            attValue = "";
        }

        if (!attValue.equals("") && attKey.equalsIgnoreCase("baseLineNumber")) {
            CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
            List<Persistable> persistable = ctAdToolLogic.getPersistableByColumnName(ManagedBaseline.class, "BaselineNumber", attValue);
            if (!CtFormatUtil.hasContent(persistable)){
                throw new WTException("基线编号错误！请检查编号是否正确或基线是否存在！");
            }
        }

        //校验“成品编码”
        if(CtFormatUtil.hasContent(attValue) && "endItemNumber".equals(attKey)){
            WTPart part = CtPartUtil.getPartByNumber(attValue);
            if(null == part){
                throw new WTException("成品编码错误，请检查编号是否正确！");
            }
            if(!part.isEndItem() && !(part.getNumber().startsWith("40")) ){
                throw new WTException("成品编码错误，不是成品类型！");
            }
        }

        //校验“提交工程师”
        if(CtFormatUtil.hasContent(attValue) && "submitEngineer".equals(attKey)){
            WTUser user = CtUserUtil.getUserByAccountName(attValue);
            if (null == user) {
                if(!attValue.contains("-")){
                    throw new Exception(attValue + "该用户在系统中不存在或未带部门信息！");
                }
                String userName = attValue.substring(0, attValue.indexOf("-"));
                user = CtUserUtil.getUserByDisplayName(userName);
                if (null == user) {
                    throw new Exception(attValue + "该用户在系统中不存在！");
                }
            }
            if(null != user){
                attValue = user.getName();
            }
        }
        certificationMapper.updateAttById(dbTableName, id, attKey, attValue);
    }

    @Override
    public void deleteFileItemData(String branchId, List<String> tagIdList) {
        certificationMapper.deleteFileItemData(branchId, tagIdList);
    }

    /**
     * 认证表格插入空数据
     *
     * @param tableName
     * @param certfId
     * @throws Exception
     */
    @Override
    public void certfInsertAttById(String tableName, String certfId) throws Exception {
        CtCertificationQuery query = new CtCertificationQuery();
        String tagId = getTagId(certfId);
        query.certfInsertAttTagId(tableName,certfId,tagId);
        query.certfInsertAttTagId("ZCertfFileItem", certfId,tagId);
    }


    /**
     * 生成标识id
     *
     * @return
     * @throws Exception
     */
    private String getTagId(String certfId) throws Exception {

        //根据branchId获取最大编码
        String number = certificationMapper.queryMaxTagId(certfId);


        //生成编码前缀
        String CodePrefix = "DC";

        //判断是否是同一天
        if (!CtFormatUtil.hasContent(number)) {
            return CodePrefix = "DC" + "001";
        }
        CtPartCodingBo ctPartCodingBo = new CtPartCodingBo();
        ctPartCodingBo.setSequenceLength(3);
        ctPartCodingBo.setCodePrefix(CodePrefix);
        ctPartCodingBo.setCurrentMaxCode(number);

        String tagId = CtPartTool.genPartCode(ctPartCodingBo);

        return tagId;
    }

    /**
     * 删除item信息
     *
     * @param tableName
     * @param idList
     * @throws Exception
     */
    @Override
    public void deleteItemData(String tableName, List<Long> idList) throws Exception {
        certificationMapper.deleteItemInfo(tableName, idList);
    }

    /**
     * 查询产品型号集合
     *
     * @param certfId
     * @return
     */
    @Override
    public List<HashMap<String, String>> getProductTypes(String certfId) {
        List<HashMap<String, String>> productTypes = certificationMapper.getProductTypes(certfId);

        //删除为空的数据
        for (int i = 0; i < productTypes.size(); i++) {
            if (productTypes.get(i) == null) {
                productTypes.remove(i);
            }
        }
        return productTypes;
    }

    ////////////     退市/续证         ///////////////


    /**
     * 实时保存item信息
     *
     * @param dbTableName 表名
     * @param id          id
     * @param attKey      列名
     * @param attValue    值
     * @throws Exception
     */
    @Override
    public void recertfSaveItemData(String dbTableName, String id, String attKey, String attValue) throws Exception {

        CtCertificationQuery query = new CtCertificationQuery();
        if (attValue == null) {
            attValue = "";
        }

        //判断物料编码是否正确
        if ((attKey.equalsIgnoreCase("finishedMaterialCode") || attKey.equalsIgnoreCase("semiMaterialCode") ||
                attKey.equalsIgnoreCase("specialMaterialCode")) && CtFormatUtil.hasContent(attValue)) {
            WTPart part = CtPartUtil.getPartByNumber(attValue);

            if (CtFormatUtil.hasContent(part)) {
                /*String state = part.getLifeCycleState().getDisplay(Locale.CHINA);
                if (!state.equals("试产")||!state.equals("量产")){
                    throw new Exception("物料状态必须试产或量产！");
                }*/

                //判断物料是否已存在
                String branchId = eofMapper.getItemByIdAndTable(dbTableName, id);
                HashMap<String, String> map = eofMapper.checkPartNumber(branchId, part.getNumber(), dbTableName, attKey);
                if (CtFormatUtil.hasContent(map)) {
                    throw new WTException("请检查编号是否已存在表格中！");
                }

                //获取库存
                CtSapServiceImpl ctSapService = CtBeanFactory.newCtBeanFactory().getBean(CtSapServiceImpl.class);
                CtSapPartStorageBo partStorageBo = ctSapService.getPartStorageBo(attValue);

                IBAUtil ibaUtil = new IBAUtil(part);

                if (attKey.equalsIgnoreCase("finishedMaterialCode")) {
                    String type = ibaUtil.getIBAValue("ct_model");

                    int i = eofMapper.getisDelist(type, branchId);
                    if (i > 0) {
                        query.updateAttById(dbTableName, id, "isDelist", "是");
                    } else {
                        query.updateAttById(dbTableName, id, "isDelist", "否");
                    }
                    query.updateAttById(dbTableName, id, "productType", type);
                    query.updateAttById(dbTableName, id, "wipCount", partStorageBo.getStorageAtMake());
                }
                query.updateAttById(dbTableName, id, "materialName", part.getName());
                query.updateAttById(dbTableName, id, "inventory", partStorageBo.getStorage());
                query.updateAttById(dbTableName, id, "unit", part.getDefaultUnit().getDisplay(Locale.CHINA));

            } else {
                throw new WTException("物料编号错误，请检查编号是否错误或物料是否存在");
            }
        }

        if (dbTableName.equalsIgnoreCase("ZRecertfOrEofItem")) {
            if (attKey.equalsIgnoreCase("recertfOrEof") && CtFormatUtil.hasContent(attValue)) {
                String isDelist = "";
                CtRecertfOrEofItemBo itemInfo = eofMapper.getItemInfoById(id);
                if (attValue.equals("退市")) {
                    isDelist = "是";
                    eofMapper.updateIsDelist(itemInfo.getProductType(), isDelist);
                } else {
                    isDelist = "否";
                    eofMapper.updateIsDelist(itemInfo.getProductType(), isDelist);
                }
            }
        }

        query.updateAttById(dbTableName, id, attKey, attValue);
        //计算合计销量数据
        if (dbTableName.equalsIgnoreCase("ZRecertfOrEofFinishedItem")) {
            if (CtFormatUtil.hasContent(attKey) && (attKey.equalsIgnoreCase("topThreeYear") || attKey.equalsIgnoreCase("topTwoYear") ||
                    attKey.equalsIgnoreCase("topOneYear"))) {
                int sum = sum(id);
                query.updateAttById(dbTableName, id, "total", sum + "");
            }
        }
    }


    //根据获取型号及编号获取证书属性
    private void getCertificateIBA(String number, String type) throws Exception {
        String[] numberIBA = new String[6];
        numberIBA[0] = "ct_Certificatenumber";
        numberIBA[1] = "ct_1InspectionReportNo";
        numberIBA[2] = "ct_2InspectionReportNo";
        numberIBA[3] = "ct_3InspectionReportNo";
        numberIBA[4] = "ct_InspectionReportNo";
        numberIBA[5] = "ct_5InspectionReportNo";


        HashMap<String, Object> map = new HashMap<>();


        for (int i = 0; i < numberIBA.length; i++) {
            //根据iba属性获取文档
            List<HashMap<String, Object>> branchIds = eofMapper.getBranchIds(numberIBA[i], number, type);

            if (CtFormatUtil.hasContent(branchIds)) {

                for (HashMap<String, Object> branchId : branchIds) {

                    BigDecimal bgd = (BigDecimal) branchId.get("DOCID");
                    WTDocument document = CtDocUtil.getDocumentById(bgd.toString());
                    IBAUtil ibaUtil = new IBAUtil(document);
                    if (i == 0) {
                        //证书到期时间
                        String endDate = ibaUtil.getIBAValue("ct_Certificateexpirationdate");
                        //认证类型
                        String certfType = ibaUtil.getIBAValue("ct_Authenticationtype");
                        map.put("endDate", endDate.substring(0, 10));
                        map.put("type", certfType);
                    } else {
                        //获取报告有效期
                        String endDate = ibaUtil.getIBAValue("ct_" + i + "reportvalidity");
                        //获取类型枚举的显示值
                        String reportType = ibaUtil.getEnumDisplayValue(document, "ct_" + i + "reporttype");
                        map.put("endDate", endDate.substring(0, 10));
                        map.put("type", reportType);
                    }
                    //String productName = ibaUtil.getIBAValue("ct_productName");
                    //map.put("productName",productName);
                }
            }
        }

        if (map.size() == 0) {
            throw new Exception("未找到型号与编号对应的信息，请检查");
        }

    }

    public HashMap<String, List<HashMap<String, String>>> getCertificateInfo(String itemId) throws Exception {
        HashMap<String, List<HashMap<String, String>>> map = new HashMap<>();

        List<HashMap<String, String>> endDateList = new ArrayList<>();
        List<HashMap<String, String>> numberList = new ArrayList<>();
        List<HashMap<String, String>> productNameList = new ArrayList<>();

        CtRecertfOrEofItemBo itemBo = eofMapper.getCertfNumberById(itemId);
        if (CtFormatUtil.hasContent(itemBo)) {
            String type = itemBo.getCertfType();
            String productType = itemBo.getProductType();
            if (!CtFormatUtil.hasContent(type) || type.equals("NA")){
                return map;
            }
            String[] split = type.split(",");
            WTDocument document = CtDocUtil.getDocumentByNumber(split[1]);
            Long masterId = document.getMaster().getPersistInfo().getObjectIdentifier().getId();
            //取得产品名称
            String productNameString = "";
            CtModelListMapper ctModelListMapper = CtBeanFactory.newCtBeanFactory().getBean(CtModelListMapper.class);
            Wrapper<CtModelListBo> modelBoWrapper = new EntityWrapper<CtModelListBo>().eq("masterId", masterId);
            List<CtModelListBo> modelList = ctModelListMapper.selectList(modelBoWrapper);
            for(CtModelListBo ctModelListBo : modelList){
                if(productType.equals(ctModelListBo.getProductModel())){
                    productNameString = ctModelListBo.getProductName();
                    break;
                }
            }

            //产品名称
            HashMap<String, String> productName = new HashMap<>();
            if (CtFormatUtil.hasContent(productNameString)) {
                productName.put("displayText", productNameString);
            }

            //认证类型
            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
            CtCertificateListMapper ctCertificateListMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificateListMapper.class);
            Wrapper<CtCertificateListBo> ctCertificateListBoWrapper = new EntityWrapper<CtCertificateListBo>().eq("masterId", masterId).eq("certificateStatus", "生效中");
            List<CtCertificateListBo> certificateList = ctCertificateListMapper.selectList(ctCertificateListBoWrapper);
            for(CtCertificateListBo bo : certificateList){
                if(split[0].equals(bo.getCertificationType())){
                    HashMap<String, String> numbers = new HashMap<>();
                    HashMap<String, String> endDates = new HashMap<>();

                    if (CtFormatUtil.hasContent(bo.getCertificateNumber())) {
                        numbers.put("displayText", bo.getCertificateNumber());
                    }
                    if(null != bo.getCertificateExpirationDate()) {
                        endDates.put("displayText", dateFormat.format(bo.getCertificateExpirationDate()));
                    }

                    if (endDates.size() > 0) {
                        endDateList.add(endDates);
                    }
                    if (numbers.size() > 0) {
                        numberList.add(numbers);
                    }
                }
            }

            //报告类型
            CtReportChecklistMapper ctReportChecklistMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportChecklistMapper.class);
            Wrapper<CtReportChecklistBo> ctReportChecklistWrapper = new EntityWrapper<CtReportChecklistBo>().eq("reportStatus", "生效中").eq("masterId", masterId);
            List<CtReportChecklistBo> reportList = ctReportChecklistMapper.selectList(ctReportChecklistWrapper);
            for(CtReportChecklistBo reportBo : reportList){
                if(split[0].equals(reportBo.getReportType())){
                    HashMap<String, String> numbers = new HashMap<>();
                    HashMap<String, String> endDates = new HashMap<>();

                    if (CtFormatUtil.hasContent(reportBo.getReportNumber())) {
                        numbers.put("displayText", reportBo.getReportNumber());
                    }
                    if(null != reportBo.getValidityDate()) {
                        endDates.put("displayText", dateFormat.format(reportBo.getValidityDate()));
                    }

                    if (endDates.size() > 0) {
                        endDateList.add(endDates);
                    }
                    if (numbers.size() > 0) {
                        numberList.add(numbers);
                    }
                }
            }


//            for (Object key : allIBAKey.keySet()) {
//                HashMap<String, String> numbers = new HashMap<>();
//                HashMap<String, String> endDates = new HashMap<>();
//
//                if (key.toString().contains("认证类型")) {
//                    //证书到期时间
//                    String endDate = ibaUtil.getIBAValue("ct_Certificateexpirationdate");
//                    //认证编号
//                    String certfNumber = ibaUtil.getIBAValue("ct_Certificatenumber");
//                    String certfType = ibaUtil.getEnumDisplayValue( document,"ct_Authenticationtype");
//                    //String certfType = ibaUtil.getIBAValue( "ct_Authenticationtype");
//                    System.out.println("证书>>>>>"+certfType+"--"+certfNumber+"--"+split[0]);
//                    if (split[0].equals(certfType)){
//                        if (CtFormatUtil.hasContent(certfNumber))
//                            numbers.put("displayText", certfNumber);
//                        if(CtFormatUtil.hasContent(endDate))
//                            endDates.put("displayText", endDate.substring(0, 10));
//                    }
//                } else if (key.toString().contains("报告类型")) {
//                    String[] split1 = key.toString().split("-");
//                    //获取报告有效期
//                    //String endDate = ibaUtil.getIBAValue("ct_Reportvalidityperiod");
//                    String endDate = ibaUtil.getIBAValue("ct_" + split1[0] + "reportvalidity");
//                    //获取类型枚举的显示值
//                    //String reportNumner = ibaUtil.getIBAValue( "
//                    //ct_11InspectionReportNo");
//                    String reportNumner = ibaUtil.getIBAValue( "ct_" + split1[0] + "InspectionReportNo");
//                    //String reportType = ibaUtil.getIBAValue( "ct_identifycategory");
//                    //String reportType = ibaUtil.getEnumDisplayValue(document, "ct_" + split1[0] + "reporttype");
//                    String reportType = ibaUtil.getIBAValue( "ct_" + split1[0] + "reporttype");
//                    System.out.println("报告>>>>>"+reportType+"--"+reportNumner+"--"+split[0]);
//                    if (split[0].equals(reportType)) {
//                        if (CtFormatUtil.hasContent(reportNumner))
//                            numbers.put("displayText", reportNumner);
//                        if(CtFormatUtil.hasContent(endDate))
//                            endDates.put("displayText", endDate.substring(0, 10));
//                    }
//
//                }
//                if (endDates.size() > 0) endDateList.add(endDates);
//                if (numbers.size() > 0) numberList.add(numbers);
//            }
            if (productName.size() > 0) {
                productNameList.add(productName);
            }
            map.put("numbers", numberList);
            map.put("endDates", endDateList);
            map.put("productNames", productNameList);

        }
        return map;
    }

    @Override
    public List<HashMap<String, String>> getCertificateType(String type) throws Exception {
        //根据型号获取证书文档信息
//        List<HashMap<String, Object>> certificateDocs = eofMapper.getBranchIdsByType(type);
//
//        List<HashMap<String, String>> certificateTypes = new ArrayList<>();
//
//        for (HashMap<String, Object> certificateDoc : certificateDocs) {
//            WTDocument doc = CtDocUtil.getDocumentByNumber(certificateDoc.get("docNumber").toString());
//            System.out.println("docNumber"+certificateDoc.get("docNumber").toString());
//            IBAUtil ibaUtil = new IBAUtil(doc);
//            Hashtable allIBAKey = ibaUtil.getAllIBAKey(doc);
//            //获取证书及检验报告编号
//            for (Object key : allIBAKey.keySet()) {
//                HashMap<String, String> map = new HashMap<>();
//                if (key.toString().contains("认证类型")) {
//                    Object iba = allIBAKey.get(key);
//                    String value = ibaUtil.getEnumDisplayValue(doc,iba.toString());
//                    if (!CtFormatUtil.hasContent(value)){
//                        value = ibaUtil.getIBAValue(iba.toString());
//                        //System.out.println("认证类型"+value);
//                    }
//                    if (CtFormatUtil.hasContent(value)) {
//                        System.out.println("认证类型1"+value);
//                        map.put("displayText",value +"（"+doc.getNumber()+"/"+doc.getName() + "）");
//                        map.put("certificateType", value + "," + certificateDoc.get("docNumber"));
//                    }
//                }
//                if (key.toString().contains("报告类型")){
//                    //System.out.println("报告类型key"+allIBAKey.get(key));
//                    Object iba = allIBAKey.get(key);
//                    String value = ibaUtil.getEnumDisplayValue(doc,iba.toString());
//                    if (!CtFormatUtil.hasContent(value)){
//                        value = ibaUtil.getIBAValue(iba.toString());
//                        //System.out.println("报告类型"+value);
//                    }
//                    if (CtFormatUtil.hasContent(value)) {
//                        System.out.println("报告类型1"+value);
//                        map.put("displayText", value+"（"+doc.getNumber()+"/"+doc.getName() + "）");
//                        map.put("certificateType", value+"（"+doc.getNumber()+"/"+doc.getName() + "）" + "," + certificateDoc.get("docNumber"));
//                    }
//                }
//                if (map.size() > 0) {
//                    certificateTypes.add(map);
//                }
//            }
//        }
//        if (certificateTypes.size()<=0){
//            HashMap<String, String> map = new HashMap<>();
//            map.put("displayText", "NA");
//            map.put("certificateType", "NA");
//            certificateTypes.add(map);
//        }
        return getCertificateTypes(type);
    }

    public static List<HashMap<String, String>> getCertificateTypes(String productModel) throws Exception {
        List<HashMap<String, String>> certificateTypes = new ArrayList<>();
        //先通过产品型号查到符合条件的证书
        List<WTDocument> docList = new ArrayList<>();
        List<String> docNumberList = new ArrayList<>();
        CtModelListMapper ctModelListMapper = CtBeanFactory.newCtBeanFactory().getBean(CtModelListMapper.class);
        Wrapper<CtModelListBo> ctModelListBoWrapper = new EntityWrapper<CtModelListBo>().eq("productModel", productModel).eq("applicable", "是");
        List<CtModelListBo> modelList = ctModelListMapper.selectList(ctModelListBoWrapper);
        for(CtModelListBo bo : modelList){
            if(!CtFormatUtil.hasContent(bo.getBranchId())){
                continue;
            }
            String docBranchId = "VR:wt.doc.WTDocument:" + bo.getBranchId();
            WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docBranchId);
            if(null == doc){
                continue;
            }
            String docNumber = doc.getNumber();
            doc = CtDocUtil.getDocumentByNumber(docNumber);
            if(null != doc && !docNumberList.contains(docNumber) && "已发布".equals(doc.getLifeCycleState().getDisplay(Locale.CHINA))){
                docNumberList.add(docNumber);
                docList.add(doc);
            }
        }

        CtCertificateListMapper ctCertificateListMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificateListMapper.class);
        CtReportChecklistMapper ctReportChecklistMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportChecklistMapper.class);
        for(WTDocument doc : docList){
            String docNumber = doc.getNumber();
            Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
            //认证类型
            Wrapper<CtCertificateListBo> ctCertificateListBoWrapper = new EntityWrapper<CtCertificateListBo>().eq("masterId", masterId).eq("certificateStatus", "生效中");
            List<CtCertificateListBo> certificateList = ctCertificateListMapper.selectList(ctCertificateListBoWrapper);
            for(CtCertificateListBo bo : certificateList){
                if(!CtFormatUtil.hasContent(bo.getCertificationType())){
                    continue;
                }
                String[] values = bo.getCertificationType().split(",");
                for(int i = 0;i < values.length;i++){
                    String value = values[i];
                    HashMap<String, String> map = new HashMap<>();
                    map.put("displayText",value +"（"+docNumber+"/"+doc.getName() + "）");
                    map.put("certificateType", value + "," + docNumber);
                    certificateTypes.add(map);
                }
            }

            //报告类型
            Wrapper<CtReportChecklistBo> ctReportChecklistWrapper = new EntityWrapper<CtReportChecklistBo>().eq("masterId", masterId).eq("reportStatus", "生效中");
            List<CtReportChecklistBo> reportLinkList = ctReportChecklistMapper.selectList(ctReportChecklistWrapper);
            for(CtReportChecklistBo reportBo : reportLinkList){
                HashMap<String, String> map = new HashMap<>();
                String value = reportBo.getReportType();
                map.put("displayText", value+"（"+docNumber+"/"+doc.getName() + "）");
                //map.put("certificateType", value+"（"+docNumber+"/"+doc.getName() + "）" + "," + docNumber);
                map.put("certificateType", value + "," + docNumber);
                certificateTypes.add(map);
            }
        }
        if (certificateTypes.size()<=0){
            HashMap<String, String> map = new HashMap<>();
            map.put("displayText", "NA");
            map.put("certificateType", "NA");
            certificateTypes.add(map);
        }
        return certificateTypes;
    }


    @Override
    public List<HashMap<String, String>> getCertificateNumber(String id) throws Exception {
        //根据型号获取证书文档信息
        List<HashMap<String, Object>> certificateDocs = eofMapper.getBranchIdsByType(id);

        List<HashMap<String, String>> certificateNumbers = new ArrayList<>();

        for (HashMap<String, Object> certificateDoc : certificateDocs) {
            WTDocument doc = CtDocUtil.getDocumentByNumber(certificateDoc.get("docNumber").toString());
            IBAUtil ibaUtil = new IBAUtil(doc);
            Hashtable allIBAKey = ibaUtil.getAllIBAKey(doc);
            //获取证书及检验报告编号
            for (Object key : allIBAKey.keySet()) {
                HashMap<String, String> map = new HashMap<>();
                if (key.toString().contains("证书编号") || key.toString().contains("检验报告编号")) {
                    Object iba = allIBAKey.get(key);
                    String value = ibaUtil.getIBAValue(iba.toString());
                    if (CtFormatUtil.hasContent(value)) {
                        map.put("displayText", value);
                        map.put("certificateNumber", value + "," + certificateDoc.get("docNumber"));
                    }
                }
                if (map.size() > 0) {
                    certificateNumbers.add(map);
                }
            }
        }
        if (certificateNumbers.size()<=0){
            HashMap<String, String> map = new HashMap<>();
            map.put("displayText", "NA");
            map.put("certificateNumber", "NA");
            certificateNumbers.add(map);
        }
        return certificateNumbers;
    }

    //计算合计销量数据
    private int sum(String id) {
        CtRecertfOrEofFinishedItemBo itemInfo = eofMapper.getFinishedItemInfoById(id);
        int sum = 0;
        if (CtFormatUtil.hasContent(itemInfo)) {
            if (CtFormatUtil.hasContent(itemInfo.getTopOneYear())) {
                sum += Integer.valueOf(itemInfo.getTopOneYear());
            }
            if (CtFormatUtil.hasContent(itemInfo.getTopThreeYear())) {
                sum += Integer.valueOf(itemInfo.getTopThreeYear());
            }
            if (CtFormatUtil.hasContent(itemInfo.getTopTwoYear())) {
                sum += Integer.valueOf(itemInfo.getTopTwoYear());
            }
        }
        return sum;
    }


    /**
     * 查询form表单中数据
     *
     * @param branchId
     * @return
     */
    @Override
    public CtRecertfOrEofApplyBo getFormInfo(String branchId) throws Exception {
        CtRecertfOrEofApplyBo formInfo = eofMapper.getFormInfo(branchId);
        if (!CtFormatUtil.hasContent(formInfo)) {
            WTDocument document = CtDocUtil.getDocumentByBranchId(branchId);
            CtRecertfOrEofApplyBo applyBo = new CtRecertfOrEofApplyBo();
            applyBo.setApplyDate(document.getCreateTimestamp().toString().substring(0, 10));
            applyBo.setDocumentId(document.getNumber());
            applyBo.setUserName(document.getCreatorFullName());
            applyBo.setDocBranchId(branchId);
            CtHrPersonBo person = CtHrLogic.getPersonByNo(document.getCreatorName());
            applyBo.setDepartment(person.getDepartmentName());

            eofMapper.addFromInfo(applyBo);

            formInfo = eofMapper.getFormInfo(branchId);
        }
        return formInfo;
    }


    /**
     * 获取证书产品信息
     *
     * @param branchId
     * @return
     */
    @Override
    public List<CtRecertfOrEofItemBo> getRecertfItemInfo(String branchId) {
        return eofMapper.getItemInfo(branchId);
    }


    /**
     * 获取成品物料信息
     *
     * @param branchId
     * @return
     */
    @Override
    public List<CtRecertfOrEofFinishedItemBo> getFinishedItemInfo(String branchId) throws Exception {
        List<CtRecertfOrEofFinishedItemBo> itemBoList = eofMapper.getFinishedItemInfo(branchId);
        //实时取状态
        for(CtRecertfOrEofFinishedItemBo bo : itemBoList){
            String docNumber = bo.getStopUsingDocNumber();
            if(CtFormatUtil.hasContent(docNumber)){
                WTDocument doc = CtDocUtil.getDocumentByNumber(docNumber);
                if(null != doc){
                    bo.setStopUsingDocState(doc.getLifeCycleState().getDisplay(Locale.CHINA));
                    String url = CtFormatUtil.getURL(doc, doc.getNumber());
                    bo.setStopUsingDocUrl(url);
                }
            }
        }
        return itemBoList;
    }

    /**
     * 获取半成品物料信息
     *
     * @param branchId
     * @return
     */
    @Override
    public List<CtRecertfOrEofSemiItemBo> getSemiItemInfo(String branchId) {
        return eofMapper.getSemiItemInfo(branchId);
    }

    /**
     * 获取专用物料信息
     *
     * @param branchId
     * @return
     */
    @Override
    public List<CtRecertfOrEofSpecialItemBo> getSpecialItemInfo(String branchId) throws Exception {
        List<CtRecertfOrEofSpecialItemBo> itemBoList = eofMapper.getSpecialItemInfo(branchId);
        //实时取状态
        for(CtRecertfOrEofSpecialItemBo bo : itemBoList){
            String docNumber = bo.getStopUsingDocNumber();
            if(CtFormatUtil.hasContent(docNumber)){
                WTDocument doc = CtDocUtil.getDocumentByNumber(docNumber);
                if(null != doc){
                    bo.setStopUsingDocState(doc.getLifeCycleState().getDisplay(Locale.CHINA));
                    String url = CtFormatUtil.getURL(doc, doc.getNumber());
                    bo.setStopUsingDocUrl(url);
                }
            }
        }
        return itemBoList;
    }

    /**
     * 插入空数据
     *
     * @param tableName
     * @param branchId
     * @throws Exception
     */
    @Override
    public void recertfInsertAttById(String tableName, String branchId) throws Exception {
        CtCertificationQuery query = new CtCertificationQuery();
        query.recertfInsertAttById(tableName, branchId);
    }


    @Override
    public void importRecertfAssess(String proOid, File file, String number) throws Exception {
        CtSapServiceImpl ctSapService = CtBeanFactory.newCtBeanFactory().getBean(CtSapServiceImpl.class);
        Workbook wb = WorkbookFactory.create(file);
        Sheet sheet = wb.getSheetAt(0);
        int lastRowNum = sheet.getLastRowNum();
        String MaterialCode = "";

        //收集错误信息
        for (int i = 1; i <= lastRowNum; i++) {

            MaterialCode = CtExcelReadUtil.getCellValue(sheet, i, 0);

            if (!CtFormatUtil.hasContent(MaterialCode)) {
                continue;
            }

            WTPart part = CtPartUtil.getPartByNumber(MaterialCode);
            if (!CtFormatUtil.hasContent(part)) {
                throw new WTException("第" + i + "行没有这个编码的物料");
            }
            String partType = CtWTObjectUtil.getTypeIdentifier(part);
            String partTypeLastName = partType.substring(partType.lastIndexOf(".") + 1);
            if ("1".equals(number)) {
                /*if (!partTypeLastName.contains("ct_fhsjSpecialMaterials")) {
                    throw new WTException("第" + i + "行物料不是专用物料");
                }*/
                HashMap<String, String> map = eofMapper.checkPartNumber(proOid, MaterialCode, "ZRecertfOrEofSpecialItem", "specialMaterialCode");
                if (CtFormatUtil.hasContent(map)) {
                    throw new WTException("请检查编号是否已存在表格中！");
                }

                //获取库存
                String partStorage = ctSapService.getPartStorage(part.getNumber());
                eofMapper.addPart("ZRecertfOrEofSpecialItem", "specialMaterialCode", proOid, part.getName(), part.getDefaultUnit().getDisplay(Locale.CHINA)
                        , MaterialCode, partStorage);
            } else if ("2".equals(number)) {
               /* if (!partTypeLastName.contains("ct_fhsjiallyPreparedProducts")) {
                    throw new WTException("第" + i + "行物料不是半成品");
                }*/

                String partStorage = ctSapService.getPartStorage(part.getNumber());
                HashMap<String, String> map = eofMapper.checkPartNumber(proOid, MaterialCode, "ZRecertfOrEofSemiItem", "semiMaterialCode");
                if (CtFormatUtil.hasContent(map)) {
                    throw new WTException("请检查编号是否已存在表格中！");
                }
                eofMapper.addPart("ZRecertfOrEofSemiItem", "semiMaterialCode", proOid, part.getName(), part.getDefaultUnit().getDisplay(Locale.CHINA)
                        , MaterialCode, partStorage);
            }
        }
    }


    @Override
    public void addFinishedByType(String branchId) throws Exception {

        List<CtRecertfOrEofItemBo> itemInfo = eofMapper.getItemInfo(branchId);
        for (CtRecertfOrEofItemBo itemBo : itemInfo) {
            List<HashMap<String, Object>> partNumbers = eofMapper.getPartNumberByType(itemBo.getProductType());
            for (HashMap<String, Object> partNumber : partNumbers) {
                WTPart wtPart = CtPartUtil.getPartByNumber((String) partNumber.get("partNumber"),"Design");
                HashMap<String, String> map = eofMapper.checkPartNumber(branchId, wtPart.getNumber(), "ZRecertfOrEofFinishedItem", "finishedMaterialCode");
                if (CtFormatUtil.hasContent(map)) {
                    continue;
                }

                //获取库存
                CtSapServiceImpl ctSapService = CtBeanFactory.newCtBeanFactory().getBean(CtSapServiceImpl.class);
                CtSapPartStorageBo partStorageBo = ctSapService.getPartStorageBo(wtPart.getNumber());

                IBAUtil ibaUtil = new IBAUtil(wtPart);
                String type = ibaUtil.getIBAValue("ct_model");


                CtRecertfOrEofFinishedItemBo finishedItemBo = new CtRecertfOrEofFinishedItemBo();
                int i = eofMapper.getisDelist(type, branchId);
                if (i > 0) {
                    finishedItemBo.setIsDelist("是");
                } else {
                    finishedItemBo.setIsDelist("否");
                }
                finishedItemBo.setInventory(partStorageBo.getStorage());
                finishedItemBo.setWipCount(partStorageBo.getStorageAtMake());
                finishedItemBo.setDocBranchId(branchId);
                finishedItemBo.setFinishedMaterialCode(wtPart.getNumber());
                finishedItemBo.setMaterialName(wtPart.getName());
                finishedItemBo.setUnit(wtPart.getDefaultUnit().getDisplay(Locale.CHINA));
                finishedItemBo.setProductType(type);
                eofMapper.addFinishedItemInfo(finishedItemBo);
            }
        }
    }

    /**
     * 添加物料
     * @param branchId
     * @throws Exception
     */
    @Override
    public void addRawMaterialAndSemiFinishedProduct(String branchId) throws Exception {
        List<CtRecertfOrEofFinishedItemBo> itemInfo = eofMapper.getFinishedItemInfo(branchId);
        //取“是否退市停用”为是的成品
        List<WTPart> parentPartList = new ArrayList<>();
        List<String> parentNumberList = new ArrayList<>();
        for (CtRecertfOrEofFinishedItemBo itemBo : itemInfo) {
            if(!"是".equals(itemBo.getIsDelist())){
                continue;
            }
            WTPart wtPart = CtPartUtil.getPartByNumber(itemBo.getFinishedMaterialCode(), "Design");
            if (null != wtPart) {
                parentPartList.add(wtPart);
                parentNumberList.add(wtPart.getNumber());
            }
        }
        //查询所有子项
        List<WTPart> meetCriteriaChildList = new ArrayList<>();
        CtSampleConfirmationQuery query = new CtSampleConfirmationQuery();
        Set<WTPart> childSet = queryAllChild(parentPartList);
        Iterator<WTPart> it = childSet.iterator();
        while(it.hasNext()){
            WTPart childPart = it.next();
            Long childPartId = childPart.getPersistInfo().getObjectIdentifier().getId();
            List<Map<String, String>> allParentList = query.queryUsageLink(childPartId);
            boolean hasOtherParent = false;
            for(Map<String, String> map : allParentList){
                if("1".equals(map.get("isLeaf")) && CtFormatUtil.hasContent(map.get("parentNumber"))){
                    //筛选出只用于这些成品的子项
                    if(!parentNumberList.contains(map.get("parentNumber"))){
                        hasOtherParent = true;
                        break;
                    }
                }
            }
            if(!hasOtherParent){
                meetCriteriaChildList.add(childPart);
            }
        }
        //获取库存
        CtSapServiceImpl ctSapService = CtBeanFactory.newCtBeanFactory().getBean(CtSapServiceImpl.class);
        //保存子项数据
        for (WTPart wtPart : meetCriteriaChildList) {
//            IBAUtil ibaUtil = new IBAUtil(wtPart);
//            String type = ibaUtil.getIBAValue("ct_model");
//            CtRecertfOrEofSpecialItemBo specialItemBo = new CtRecertfOrEofSpecialItemBo();
//            int i = eofMapper.getisDelist(type, branchId);
//            if (i > 0) {
//                specialItemBo.setIsDelist("是");
//            } else {
//                specialItemBo.setIsDelist("否");
//            }
            //获取库存
            String partStorage = ctSapService.getPartStorage(wtPart.getNumber());
            eofMapper.addPart("ZRecertfOrEofSpecialItem", "specialMaterialCode", branchId, wtPart.getName(), wtPart.getDefaultUnit().getDisplay(Locale.CHINA)
                    , wtPart.getNumber(), partStorage);
        }
    }

    /**
     * 查询成品的所有子项
     * @param parentPartList
     * @return
     * @throws Exception
     */
    public static Set<WTPart> queryAllChild(List<WTPart> parentPartList) throws Exception {
        List<WTPart> allParts = new ArrayList<>();
        for(WTPart parentPart : parentPartList){
            CtBomUtil.getAllPartsInBOM(parentPart, allParts);
        }
        Set<WTPart> set = new HashSet<>();
        set.addAll(allParts);
        return set;
    }

    /**
     * 发送认证证书有效期即将过期提醒
     * 1. 有效期在270天内过期的
     * 2.邮件发送给“产品认证组”
     *
     * @throws Exception
     */
    public void sendCertfDocExpireNoticeMail() throws Exception {
        List<HashMap<String, String>> docList = certificationMapper.queryExpireCertfDoc();
        SimpleDateFormat myFormatter = new SimpleDateFormat("yyyy/MM/dd");
        List<HashMap<String, String>> filteredList = new ArrayList<HashMap<String, String>>();

        String docNumber = "";
        String version = "";
        WTDocument doc = null;
        //过滤掉正在续证的
        for (HashMap<String, String> record : docList) {
            docNumber = record.get("docNumber");
            //version = record.get("version");
            doc = CtDocUtil.getDocumentByNumber(docNumber);
            String latestVer = doc.getVersionIdentifier().getValue();


            IBAUtil ibaUtil = new IBAUtil(doc);
            Hashtable allIBAKey = ibaUtil.getAllIBAKey(doc);

            String info = "";
            //获取证书及检验报告编号
            for (Object key : allIBAKey.keySet()) {

                if (key.toString().contains("检验报告编号")) {
                    Object iba = allIBAKey.get(key);
                    String value = ibaUtil.getIBAValue(iba.toString());
                    if (CtFormatUtil.hasContent(value)) {

                        String[] split1 = key.toString().split("-");
                        //获取报告有效期
                        String endDate = ibaUtil.getIBAValue("ct_" + split1[0] + "reportvalidity");
                        if (CtFormatUtil.hasContent(endDate)) {
                            Date date = new Date();
                            //Date date1 = CtDateUtil.parseStringToDate(endDate, "yyyy-MM-dd");
                            Date date1 = myFormatter.parse(endDate);
                            long distDates = CtDateUtil.getDistDates(date, date1);
                            if (distDates < 270) {
                                System.out.println(key+"-检验报告编号-"+value+"-到期日期-"+endDate+"天"+distDates);
                                info = CtFormatUtil.combineStr(info,"编号：" + value + "(到期日期：" + endDate+")", ",");
                            }
                        }
                    }
                }else if (key.toString().contains("证书编号")){
                    Object iba = allIBAKey.get(key);
                    String value = ibaUtil.getIBAValue(iba.toString());
                    if (CtFormatUtil.hasContent(value)) {
                        //获取有效期
                        String endDate = ibaUtil.getIBAValue("ct_Certificateexpirationdate");
                        if (CtFormatUtil.hasContent(endDate)) {
                            Date date = new Date();
                            /*DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                            Date date1 = df.parse(endDate);*/
                            //Date date1 = CtDateUtil.parseStringToDate(endDate, "yyyy/MM/dd");
                            Date date1 = myFormatter.parse(endDate);
                            long distDates = CtDateUtil.getDistDates(date, date1);
                            if (distDates < 270) {
                                System.out.println(key+"-证书编号-"+value+"-到期日期-"+endDate+"天"+distDates);
                                info = CtFormatUtil.combineStr(info,"编号：" + value + "(到期日期：" + endDate+")", ",");
                            }
                        }
                    }
                }
                if (!CtFormatUtil.hasContent(info)){
                    continue;
                }else {
                    record.put("info",info);
                }

            }


            //只有最新大版本和查询出的一致时才添加，不一致说明快过期的版本已经修订，正在续证
            //if (latestVer.equalsIgnoreCase(version)) {
                filteredList.add(record);
            //}
        }

        String validDate = "";
        String info = "";
        if (filteredList.size() > 0) {
            System.out.println("开始准备发送邮件");
            //开始准备发邮件
            StringBuffer tableBody = new StringBuffer();
            tableBody.append("您好,您在PLM系统中有如下认证证书将在270天内失效，请及时进行更新:<br><br>")
                    .append("<table border=1 cellspacing=0 cellpadding=5 bgcolor='#000000'><tr bgcolor='#D8D8D8'>")
                    .append("<th>序号</th><th>文档编号</th><th>文档名称</th><th>证书/报告编号</th><th>创建人</th>")
                    .append("</tr>");
            int i = 0;
            for (HashMap<String, String> record : filteredList) {
                i++;
                docNumber = record.get("docNumber");
                doc = CtDocUtil.getDocumentByNumber(docNumber);
                //version = record.get("version");
                //validDate = record.get("validDate");
                info = record.get("info");
                if (!CtFormatUtil.hasContent(info)){
                    continue;
                }
                String linkUrl = CtFormatUtil.getURL(doc, docNumber);
                //System.out.println(linkUrl);
                tableBody.append("<tr bgcolor='#FFFFFF'><td align='center'>").append(i).append("</td>")
                        .append("<td>").append(linkUrl).append("</td>")
                        .append("<td>").append(doc.getName()).append("</td>")
                        .append("<td>").append(info).append("</td>")
                        .append("<td>").append(doc.getCreatorFullName()).append("</td>")
                        .append("</tr>");
            }
            tableBody.append("</table>");
            tableBody.append("<br><br>此邮件为系统自动发送,请勿回复,谢谢!<br>");
            tableBody.append("<br>Best Regards<br>");
            tableBody.append("===========================================================");
            tableBody.append("<br>泛海三江PLM项目组<br><br>").append(CtDateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss", "GMT+8"));
            tableBody.append("<br>");
            tableBody.append("===========================================================");

            //从用户组中取邮件列表
            List<WTUser> users = CtUserUtil.getMembersInGroup(CtCertfProperties.certificationGroup);
            //String[] toMails = new String[1];
            String[] toMails = new String[users.size()];
            int index = 0;
            for (WTUser user : users) {
                System.out.println(">>>>>>>>>>>>名称"+user.getEMail());
                toMails[index] = user.getEMail();
                index++;
            }
            //toMails[0] = "lyxivg@163.com";
            //toMails[1] = "passion3400@163.com";
            CtWTMailBo mailBo = new CtWTMailBo();
            mailBo.setSubject("PLM系统--认证证书过期提醒");
            mailBo.setFrom(CtUserUtil.getAdministrator());
            mailBo.setToMails(toMails);
            mailBo.setContent(tableBody.toString());
            System.out.println("准备发送");
            CtMailTool.sendWTMail(mailBo);
            /*System.out.println("准备发送");
            CtMailConfigBo mailConfig = new CtMailConfigBo();
            mailConfig.setHost("smtp.exmail.qq.com");
            mailConfig.setUserName("plm@fhsjdz.com");
            mailConfig.setPassword("Fan@321");
            mailConfig.setFrom("plm@fhsjdz.com");
            mailConfig.setDebug(true);

            List<String> list = new ArrayList<String>();
            list.add("passion3400@163.com");
            list.add("lyxivg@163.com");
            CtMailTool.sendMail("PLM系统--认证证书过期提醒", tableBody.toString(), list,mailConfig);*/
            //service.testSendMail("PLM系统--认证证书过期提醒", tableBody.toString(), list,mailConfig);
            System.out.println(">>>>邮件发送成功！");
        }

    }

    @Override
    public void szRelevanceFinished(String path) throws Exception {
        CtCertificationLogis.szRelevanceFinished(path);
    }



    public List<HashMap<String,String>> getAllCertificateInfo() throws Exception {
        List<String> certfDocNumbers = certificationMapper.getAllCertificateInfo();
        List<HashMap<String,String>> mapList = new ArrayList<>();
        for (String certfDocNumber : certfDocNumbers) {
            HashMap<String, String> map = new HashMap<>();

            WTDocument document = CtDocUtil.getDocumentByNumber(certfDocNumber);
            IBAUtil ibaUtil = new IBAUtil(document);
            //产品名称
            String productName = ibaUtil.getIBAValue("ct_productName");
            //产品型号
            String model = ibaUtil.getIBAValue("ct_model");
            //证书到期日期
            String certificateExpireDate = ibaUtil.getIBAValue("ct_Certificateexpirationdate");
            //证书编号
            String certificateNumber = ibaUtil.getIBAValue("ct_Certificatenumber");
            //首次发证日期
            String dateFirstIssue = ibaUtil.getIBAValue("ct_Dateoffirstissuance");
            //身份信息类型
            String identityInformationType = ibaUtil.getIBAValue("ct_Identityinformationtype");
            //获得证书日期
            String dataObtainCertificate = ibaUtil.getIBAValue("ct_DateofObtainingCertificate");
            //说明(更新履历)
            String description = ibaUtil.getIBAValue("description");
            //注销履历(格式：注销日期,证书编号,注销原因)
            String cancellationResume = ibaUtil.getIBAValue("ct_CancellationResume");
            //认证类型
            String authenticationType = IBAUtil.getEnumDisplayValue(document, "ct_Authenticationtype");
            Hashtable allIBAKey = ibaUtil.getAllIBAKey(document);
            String reportNumberAndType = "";
            String reportIndate = "";
            for (Object key : allIBAKey.keySet()) {
                if (key.toString().contains("报告类型")){
                    String[] split1 = key.toString().split("-");
                    //获取报告有效期
                    //String endDate = ibaUtil.getIBAValue("ct_Reportvalidityperiod");
                    String endDate = ibaUtil.getIBAValue("ct_" + split1[0] + "reportvalidity");
                    //获取类型枚举的显示值
                    //String reportNumner = ibaUtil.getIBAValue( "ct_Inspectionreportnumber");
                    String reportNumber = ibaUtil.getIBAValue( "ct_" + split1[0] + "InspectionReportNo");
                    String indate = ibaUtil.getIBAValue( "ct_" + split1[0] + "reportvalidity");
                    //String reportType = ibaUtil.getIBAValue( "ct_identifycategory");
                    String reportType = ibaUtil.getEnumDisplayValue(document, "ct_" + split1[0] + "reporttype");

                    reportNumberAndType = CtFormatUtil.combineStr(reportNumberAndType,reportType+":"+reportNumber,",");
                    reportIndate = CtFormatUtil.combineStr(reportIndate,indate+":"+reportNumber,",");
                }
            }

            map.put("productName",productName);
            map.put("model",model);
            map.put("certificateExpireDate",certificateExpireDate);
            map.put("certificateNumber",certificateNumber);
            map.put("dateFirstIssue",dateFirstIssue);
            map.put("identityInformationType",identityInformationType);
            map.put("dataObtainCertificate",dataObtainCertificate);
            map.put("description",description);
            map.put("cancellationResume",cancellationResume);
            map.put("authenticationType",authenticationType);
            map.put("reportNumberAndType",reportNumberAndType);
            map.put("reportIndate",reportIndate);
            mapList.add(map);
        }

        System.out.println(JSON.toJSONString(mapList));
        return mapList;
    }

    ///////测试方法////////
    public void testCertfMail() throws Exception {
        try {
            CtCertificationLogis.sendCertfDocExpireNoticeMail();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
}
