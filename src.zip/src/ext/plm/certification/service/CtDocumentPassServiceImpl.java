package ext.plm.certification.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.certification.bo.CtDocumentPassBo;
import ext.plm.certification.mapper.CtDocumentPassBoMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import org.springframework.stereotype.Service;
import wt.org.WTUser;

import java.util.List;

@Service
public class CtDocumentPassServiceImpl extends ServiceImpl<CtDocumentPassBoMapper, CtDocumentPassBo> implements CtDocumentPassService {
    @Override
    public void insertDocumentPass(String docBranchId) throws Exception {
        CtDocumentPassBo bo = new CtDocumentPassBo(docBranchId);
        super.insert(bo);
    }

    @Override
    public List<CtDocumentPassBo> getDocumentPassData(String docBranchId) throws Exception {
        Wrapper<CtDocumentPassBo> wrapper = new EntityWrapper<CtDocumentPassBo>();
        wrapper.eq("docBranchId", docBranchId);
        wrapper.orderBy("createTime", true);
        List<CtDocumentPassBo> boList = super.selectList(wrapper);
        for(CtDocumentPassBo bo : boList){
            String engineer = bo.getEngineer();
            if(CtFormatUtil.hasContent(engineer)){
                WTUser user = CtUserUtil.getUserByAccountName(engineer);
                if(null != user){
                    bo.setEngineer(user.getFullName());
                }
            }
        }
        return boList;
    }

    @Override
    public void updateDocumentPassBo(String id, String attKey, String attValue) throws Exception {
        CtDocumentPassBo bo = super.selectById(id);
        CtCommonUtil.setObjectValue(bo, attKey, attValue);
        super.updateById(bo);
    }
}

