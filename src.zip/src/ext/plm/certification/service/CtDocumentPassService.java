package ext.plm.certification.service;

import ext.plm.certification.bo.CtDocumentPassBo;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtDocumentPassService {
    //插入数据
    void insertDocumentPass(String docBranchId) throws Exception;
    //查询数据
    List<CtDocumentPassBo> getDocumentPassData(String docBranchId) throws Exception;

    void updateDocumentPassBo(String id, String attKey, String attValue) throws Exception;
}
