package ext.plm.certification;

import ext.plm.bean.CtBeanService;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtUserUtil;
import wt.doc.WTDocument;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.OrganizationServicesHelper;
import wt.org.WTUser;
import wt.services.ServiceFactory;

import java.io.Serializable;

public class TestMain implements Serializable, RemoteAccess {
	private static final long serialVersionUID = 1L;

	private static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);

	public static void main(String[] args) throws Exception {
		String host = args[0];
		if (!RemoteMethodServer.ServerFlag) {
			Class[] cls = {String[].class};
			Object[] obj = {args};
			try {
				RemoteMethodServer rms = RemoteMethodServer.getDefault();
				if ("plm".equals(host)) {
					rms.setUserName("wcadmin");
					rms.setPassword("fhsj.com");
				} else if ("demo".equals(host) || "plmtest".equals(host)) {
					rms.setUserName("wcadmin");
					rms.setPassword("wcadmin");
				}
				rms.invoke("main", TestMain.class.getName(), null, cls, obj);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return;
		}

		String methodName = args[1];
		CtCertificationLogis ctCertificationLogis = CtCertificationLogis.getInstance();
		if ("updateModel".equals(methodName)) {
			//windchill ext.plm.certification.TestMain demo updateModel  D:\test.xlsx
			//windchill ext.plm.certification.TestMain1 plm updateModel  D:\test.xlsx
			System.out.println("进入updateModel");
			ctCertificationLogis.updateModel(args[2]);
		} else if ("test".equals(methodName)){
			WTUser test = CtUserUtil.getUserByAccountName("test");
			OrganizationServicesHelper.manager.delete(test);
		} else if ("newSemiPart".equals(methodName)){
			WTDocument document = CtDocUtil.getDocumentByNumber("");
		}else {
			System.out.println("未找到该方法");
		}
	}
}
