package ext.plm.certification.bo;

import com.baomidou.mybatisplus.annotations.KeySequence;
import com.baomidou.mybatisplus.annotations.TableName;
import ext.plm.common.CtBoAttConfig;

public class CtRecertfOrEofSpecialItemBo {
    Long id;
    String docBranchId;
    //专用物料代码
    @CtBoAttConfig(displayName = "专用物料代码",required = true)
    String specialMaterialCode;
    //物料名称
    @CtBoAttConfig(displayName = "物料名称",required = true)
    String materialName;
    //单位
    @CtBoAttConfig(displayName = "单位",required = true)
    String unit;
    //库存
    @CtBoAttConfig(displayName = "库存",required = true)
    String inventory;
    //在途订单物料数量
    @CtBoAttConfig(displayName = "在途订单物料数量",required = true)
    String count ;
    //供应商库存
    @CtBoAttConfig(displayName = "供应商库存",required = true)
    String supplierInventory;
    //是否退市停用
    @CtBoAttConfig(displayName = "是否退市停用",required = true)
    String isDelist;

    @CtBoAttConfig(displayName = "停用追踪文档编号",required = true)
    String stopUsingDocNumber;//停用追踪文档编号

    @CtBoAttConfig(displayName = "停用追踪文档状态",required = true)
    String stopUsingDocState;//停用追踪文档状态

    String stopUsingDocUrl;//停用追踪文档链接

    public CtRecertfOrEofSpecialItemBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }

    public String getSpecialMaterialCode() {
        return specialMaterialCode;
    }

    public void setSpecialMaterialCode(String specialMaterialCode) {
        this.specialMaterialCode = specialMaterialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getInventory() {
        return inventory;
    }

    public void setInventory(String inventory) {
        this.inventory = inventory;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getSupplierInventory() {
        return supplierInventory;
    }

    public void setSupplierInventory(String supplierInventory) {
        this.supplierInventory = supplierInventory;
    }

    public String getIsDelist() {
        return isDelist;
    }

    public void setIsDelist(String isDelist) {
        this.isDelist = isDelist;
    }

    public String getStopUsingDocNumber() {
        return stopUsingDocNumber;
    }

    public void setStopUsingDocNumber(String stopUsingDocNumber) {
        this.stopUsingDocNumber = stopUsingDocNumber;
    }

    public String getStopUsingDocState() {
        return stopUsingDocState;
    }

    public void setStopUsingDocState(String stopUsingDocState) {
        this.stopUsingDocState = stopUsingDocState;
    }

    public String getStopUsingDocUrl() {
        return stopUsingDocUrl;
    }

    public void setStopUsingDocUrl(String stopUsingDocUrl) {
        this.stopUsingDocUrl = stopUsingDocUrl;
    }
}
