package ext.plm.certification.bo;

import ext.plm.common.CtBoAttConfig;

public class CtRecertfOrEofItemBo {
    Long id;
    String docBranchId;
    //产品型号
    @CtBoAttConfig(displayName = "产品型号",required = true)
    String productType;
    //产品名称
    @CtBoAttConfig(displayName = "产品名称",required = true)
    String productName;
    //所属产品线
    @CtBoAttConfig(displayName = "产品线",required = true)
    String productLine;
    //发起背景
    @CtBoAttConfig(displayName = "发起背景",required = true)
    String background;
    //证书/检验报告编号
    @CtBoAttConfig(displayName = "证书/检验报告编号",required = true)
    String certfNumber;
    //认证/检验类型
    @CtBoAttConfig(displayName = "认证/检验类型",required = true)
    String certfType;
    //证书/报告到期时间
    @CtBoAttConfig(displayName = "证书/报告到期时间",required = true)
    String certfDueDate;
    //发起原因
    @CtBoAttConfig(displayName = "发起原因",required = true)
    String reason;
    //续证/退市结论
    //@CtBoAttConfig(displayName = "续证/退市结论",required = true)
    String recertfOrEof;
    //续证/退市流程发起人
    //@CtBoAttConfig(displayName = "续证/退市流程发起人",required = true)
    String recertfPersonOrEofPerson;


    String whetherRenewCertificate;//是否续证
    String renewalProcessPerson;//续证流程发起人

    String whetherDelisted;//是否退市
    String delistingProcessPerson;//退市流程发起人

    public CtRecertfOrEofItemBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getCertfNumber() {
        return certfNumber;
    }

    public void setCertfNumber(String certfNumber) {
        this.certfNumber = certfNumber;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductLine() {
        return productLine;
    }

    public void setProductLine(String productLine) {
        this.productLine = productLine;
    }

    public String getCertfType() {
        return certfType;
    }

    public void setCertfType(String certfType) {
        this.certfType = certfType;
    }

    public String getCertfDueDate() {
        return certfDueDate;
    }

    public void setCertfDueDate(String certfDueDate) {
        this.certfDueDate = certfDueDate;
    }

//    public String getRecertfOrEof() {
//        return recertfOrEof;
//    }
//
//    public void setRecertfOrEof(String recertfOrEof) {
//        this.recertfOrEof = recertfOrEof;
//    }
//
//    public String getRecertfPersonOrEofPerson() {
//        return recertfPersonOrEofPerson;
//    }
//
//    public void setRecertfPersonOrEofPerson(String recertfPersonOrEofPerson) {
//        this.recertfPersonOrEofPerson = recertfPersonOrEofPerson;
//    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    public String getWhetherRenewCertificate() {
        return whetherRenewCertificate;
    }

    public void setWhetherRenewCertificate(String whetherRenewCertificate) {
        this.whetherRenewCertificate = whetherRenewCertificate;
    }

    public String getRenewalProcessPerson() {
        return renewalProcessPerson;
    }

    public void setRenewalProcessPerson(String renewalProcessPerson) {
        this.renewalProcessPerson = renewalProcessPerson;
    }

    public String getWhetherDelisted() {
        return whetherDelisted;
    }

    public void setWhetherDelisted(String whetherDelisted) {
        this.whetherDelisted = whetherDelisted;
    }

    public String getDelistingProcessPerson() {
        return delistingProcessPerson;
    }

    public void setDelistingProcessPerson(String delistingProcessPerson) {
        this.delistingProcessPerson = delistingProcessPerson;
    }
}
