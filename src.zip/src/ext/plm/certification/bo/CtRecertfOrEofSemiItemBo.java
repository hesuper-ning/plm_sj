package ext.plm.certification.bo;

import com.baomidou.mybatisplus.annotations.KeySequence;
import com.baomidou.mybatisplus.annotations.TableName;
import ext.plm.common.CtBoAttConfig;

public class CtRecertfOrEofSemiItemBo {
    Long id;
    String docBranchId;
    //半成品物料代码
    @CtBoAttConfig(displayName = "半成品物料代码",required = true)
    String semiMaterialCode;
    //物料名称
    @CtBoAttConfig(displayName = "物料名称",required = true)
    String materialName;
    //单位
    @CtBoAttConfig(displayName = "单位",required = true)
    String unit;
    //库存
    @CtBoAttConfig(displayName = "库存",required = true)
    String inventory;
    //在途订单物料数量
    @CtBoAttConfig(displayName = "在途订单物料数量",required = true)
    String count ;
    //供应商库存
    @CtBoAttConfig(displayName = "供应商库存",required = true)
    String supplierInventory;
    //是否退市停用
    @CtBoAttConfig(displayName = "是否退市停用",required = true)
    String isDelist;

    public CtRecertfOrEofSemiItemBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }

    public String getSemiMaterialCode() {
        return semiMaterialCode;
    }

    public void setSemiMaterialCode(String semiMaterialCode) {
        this.semiMaterialCode = semiMaterialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }


    public String getInventory() {
        return inventory;
    }

    public void setInventory(String inventory) {
        this.inventory = inventory;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getSupplierInventory() {
        return supplierInventory;
    }

    public void setSupplierInventory(String supplierInventory) {
        this.supplierInventory = supplierInventory;
    }

    public String getIsDelist() {
        return isDelist;
    }

    public void setIsDelist(String isDelist) {
        this.isDelist = isDelist;
    }
}
