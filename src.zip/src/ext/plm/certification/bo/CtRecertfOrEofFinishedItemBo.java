package ext.plm.certification.bo;

import ext.plm.common.CtBoAttConfig;

public class CtRecertfOrEofFinishedItemBo {
    Long id;
    String docBranchId;
    //成品物料代码
    @CtBoAttConfig(displayName = "成品物料代码",required = true)
    String finishedMaterialCode;
    //产品型号
    @CtBoAttConfig(displayName = "型号",required = true)
    String productType;
    //物料名称
    @CtBoAttConfig(displayName = "物料名称",required = true)
    String materialName;
    //库存
    @CtBoAttConfig(displayName = "库存",required = true)
    String inventory;
    //在制品数量
    @CtBoAttConfig(displayName = "在制品数量",required = true)
    String wipCount;
    //供应商库存
    @CtBoAttConfig(displayName = "供应商库存",required = true)
    String supplierInventory;
    //近三年销量数据
    @CtBoAttConfig(displayName = "当前年",required = true)
    String topOneYear;//当前年
    @CtBoAttConfig(displayName = "前一年",required = true)
    String topTwoYear;//前一年
    @CtBoAttConfig(displayName = "前两年",required = true)
    String topThreeYear;//前两年
    @CtBoAttConfig(displayName = "合计",required = true)
    String total;//合计
    //未履行销售订单产品数量
    @CtBoAttConfig(displayName = "未履行销售订单产品数量",required = true)
    String count;
    //单位
    String unit;
    //是否退市停用
    @CtBoAttConfig(displayName = "是否退市停用",required = true)
    String isDelist;

    @CtBoAttConfig(displayName = "停用追踪文档编号",required = true)
    String stopUsingDocNumber;//停用追踪文档编号

    @CtBoAttConfig(displayName = "停用追踪文档状态",required = true)
    String stopUsingDocState;//停用追踪文档状态

    String stopUsingDocUrl;//停用追踪文档链接


    public CtRecertfOrEofFinishedItemBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }

    public String getFinishedMaterialCode() {
        return finishedMaterialCode;
    }

    public void setFinishedMaterialCode(String finishedMaterialCode) {
        this.finishedMaterialCode = finishedMaterialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getInventory() {
        return inventory;
    }

    public void setInventory(String inventory) {
        this.inventory = inventory;
    }

    public String getTopOneYear() {
        return topOneYear;
    }

    public void setTopOneYear(String topOneYear) {
        this.topOneYear = topOneYear;
    }

    public String getTopTwoYear() {
        return topTwoYear;
    }

    public void setTopTwoYear(String topTwoYear) {
        this.topTwoYear = topTwoYear;
    }

    public String getTopThreeYear() {
        return topThreeYear;
    }

    public void setTopThreeYear(String topThreeYear) {
        this.topThreeYear = topThreeYear;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getWipCount() {
        return wipCount;
    }

    public void setWipCount(String wipCount) {
        this.wipCount = wipCount;
    }

    public String getSupplierInventory() {
        return supplierInventory;
    }

    public void setSupplierInventory(String supplierInventory) {
        this.supplierInventory = supplierInventory;
    }

    public String getIsDelist() {
        return isDelist;
    }

    public void setIsDelist(String isDelist) {
        this.isDelist = isDelist;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getStopUsingDocNumber() {
        return stopUsingDocNumber;
    }

    public void setStopUsingDocNumber(String stopUsingDocNumber) {
        this.stopUsingDocNumber = stopUsingDocNumber;
    }

    public String getStopUsingDocState() {
        return stopUsingDocState;
    }

    public void setStopUsingDocState(String stopUsingDocState) {
        this.stopUsingDocState = stopUsingDocState;
    }

    public String getStopUsingDocUrl() {
        return stopUsingDocUrl;
    }

    public void setStopUsingDocUrl(String stopUsingDocUrl) {
        this.stopUsingDocUrl = stopUsingDocUrl;
    }
}
