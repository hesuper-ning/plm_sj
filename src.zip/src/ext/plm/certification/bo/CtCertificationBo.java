package ext.plm.certification.bo;

public class CtCertificationBo {
    Long id;
    String certfId;
//跟踪表基本信息
    String applyDate;//申请日期
    String applyUser;//申请人
    String department;//部门
    String demandSource;//需求来源
    String remark;//备注

//基本信息审核
    String projectPrincipalAudit;//项目负责人审核　审核意见
    String procurementAudit;//采购主管审核审核　审核意见
    String isPhysical;//是否已核对实物

    String engineerAudit;//认证工程师审核 审核意见
    String PMAudit;//产品部副经理审核  审核意见
//产品送检申请文件 / 产品送检技术文件准备
    String filePrint;//送检资料处理  文件打印
    String dataDispose;//送检资料处理（打印、签字、盖章、复印、洗照片、寄出）
    String inspectDataAffirm;//资料室存档  送检资料留存确认
//获证前的送检资料确认
    String certfDataAffirm;//获证前的送检资料修改资料确认
//检验报告归档
    String reportArchiveRemark;//备注
//技术资料完善
    String ProcessData;//工艺资料 备注
    String productionRecord;//生产记录 备注
//认证证书归档
    String certfArchiveRemark;//备注
//生产资料再确认
    String ECRNumber;//ECR编号
    String revisionDocNumber;//修订文档编号
    String productionDataRemark;//备注

    public CtCertificationBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCertfId() {
        return certfId;
    }

    public void setCertfId(String certfId) {
        this.certfId = certfId;
    }


    public String getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(String applyDate) {
        this.applyDate = applyDate;
    }

    public String getApplyUser() {
        return applyUser;
    }

    public void setApplyUser(String applyUser) {
        this.applyUser = applyUser;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDemandSource() {
        return demandSource;
    }

    public void setDemandSource(String demandSource) {
        this.demandSource = demandSource;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getProjectPrincipalAudit() {
        return projectPrincipalAudit;
    }

    public void setProjectPrincipalAudit(String projectPrincipalAudit) {
        this.projectPrincipalAudit = projectPrincipalAudit;
    }

    public String getProcurementAudit() {
        return procurementAudit;
    }

    public void setProcurementAudit(String procurementAudit) {
        this.procurementAudit = procurementAudit;
    }

    public String getIsPhysical() {
        return isPhysical;
    }

    public void setIsPhysical(String isPhysical) {
        this.isPhysical = isPhysical;
    }

    public String getEngineerAudit() {
        return engineerAudit;
    }

    public void setEngineerAudit(String engineerAudit) {
        this.engineerAudit = engineerAudit;
    }

    public String getPMAudit() {
        return PMAudit;
    }

    public void setPMAudit(String PMAudit) {
        this.PMAudit = PMAudit;
    }

    public String getFilePrint() {
        return filePrint;
    }

    public void setFilePrint(String filePrint) {
        this.filePrint = filePrint;
    }

    public String getDataDispose() {
        return dataDispose;
    }

    public void setDataDispose(String dataDispose) {
        this.dataDispose = dataDispose;
    }

    public String getInspectDataAffirm() {
        return inspectDataAffirm;
    }

    public void setInspectDataAffirm(String inspectDataAffirm) {
        this.inspectDataAffirm = inspectDataAffirm;
    }

    public String getCertfDataAffirm() {
        return certfDataAffirm;
    }

    public void setCertfDataAffirm(String certfDataAffirm) {
        this.certfDataAffirm = certfDataAffirm;
    }

    public String getReportArchiveRemark() {
        return reportArchiveRemark;
    }

    public void setReportArchiveRemark(String reportArchiveRemark) {
        this.reportArchiveRemark = reportArchiveRemark;
    }

    public String getProcessData() {
        return ProcessData;
    }

    public void setProcessData(String processData) {
        ProcessData = processData;
    }

    public String getProductionRecord() {
        return productionRecord;
    }

    public void setProductionRecord(String productionRecord) {
        this.productionRecord = productionRecord;
    }

    public String getCertfArchiveRemark() {
        return certfArchiveRemark;
    }

    public void setCertfArchiveRemark(String certfArchiveRemark) {
        this.certfArchiveRemark = certfArchiveRemark;
    }

    public String getECRNumber() {
        return ECRNumber;
    }

    public void setECRNumber(String ECRNumber) {
        this.ECRNumber = ECRNumber;
    }

    public String getRevisionDocNumber() {
        return revisionDocNumber;
    }

    public void setRevisionDocNumber(String revisionDocNumber) {
        this.revisionDocNumber = revisionDocNumber;
    }

    public String getProductionDataRemark() {
        return productionDataRemark;
    }

    public void setProductionDataRemark(String productionDataRemark) {
        this.productionDataRemark = productionDataRemark;
    }
}
