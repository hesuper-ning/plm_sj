package ext.plm.certification.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonFormat;
import ext.plm.common.CtConstant;
import ext.plm.newec.bo.CtNewEcCommonBo;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

/**
 *  资料通过表
 */
@TableName("ZDocumentPassTable")
public class CtDocumentPassBo {
    @TableId(type = IdType.INPUT)
    @TableField("ID")
    private String id;
    @TableField("DOCBRANCHID")
    private String docBranchId;//
    @TableField("ENGINEER")
    private String engineer;//工程师
    @TableField("WHETHERPASS")
    private String whetherPass;//是否通过
    @TableField("WITHOUTEXPLANATION")
    private String withoutExplanation;//不通过说明

    @TableField("CREATETIME")
    private Date createTime;//创建时间

    @TableField("CREATEUSER")
    private String createUser;//创建用户

    @TableField("MODIFYTIME")
    private Date modifyTime;//修改时间

    @TableField("MODIFYUSER")
    private String modifyUser;//修改用户

    public CtDocumentPassBo(){}

    public CtDocumentPassBo(String docBranchId) throws Exception {
        this.id = UUID.randomUUID().toString();
        this.docBranchId = docBranchId;
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.createUser = currentUser.getName();
        this.modifyUser = currentUser.getName();
        this.createTime = new Date();
        this.modifyTime = new Date();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }

    public String getEngineer() {
        return engineer;
    }

    public void setEngineer(String engineer) {
        this.engineer = engineer;
    }

    public String getWhetherPass() {
        return whetherPass;
    }

    public void setWhetherPass(String whetherPass) {
        this.whetherPass = whetherPass;
    }

    public String getWithoutExplanation() {
        return withoutExplanation;
    }

    public void setWithoutExplanation(String withoutExplanation) {
        this.withoutExplanation = withoutExplanation;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }
}
