package ext.plm.certification.bo;

import ext.plm.common.CtBoAttConfig;

public class CtCertificationSkillItemBo {
    String docBranchId;
    @CtBoAttConfig(displayName = "产品型号",required = true)
    String productType;
    @CtBoAttConfig(displayName = "文件编号",required = true)
    String fileNumber;
    @CtBoAttConfig(displayName = "文件名",required = true)
    String fileName;
    Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public CtCertificationSkillItemBo() {

    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }


    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(String fileNumber) {
        this.fileNumber = fileNumber;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
