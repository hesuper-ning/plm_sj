package ext.plm.certification.bo;

public class CtRecertfOrEofApplyBo {
    Long id;
    String docBranchId;
    //需求申请人
    String userName;
    //需求部门
    String department;
    //申请日期
    String applyDate;
    //编号
    String documentId;

    public CtRecertfOrEofApplyBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(String applyDate) {
        this.applyDate = applyDate;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
}
