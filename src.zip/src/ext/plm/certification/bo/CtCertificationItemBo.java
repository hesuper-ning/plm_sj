package ext.plm.certification.bo;

import com.baomidou.mybatisplus.annotations.KeySequence;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import ext.plm.common.CtBoAttConfig;

@TableName("ZCERTFITEM")
@KeySequence("ZCertf_seq")
public class CtCertificationItemBo {
    @TableId(value = "id", type = IdType.INPUT)
    Long id;
    @TableField("DOCBRANCHID")
    String docBranchId;
    @TableField("tagId")
    String tagId; //标识
    @CtBoAttConfig(displayName = "产品型号",required = true)
    @TableField("PRODUCTTYPE")
    String productType;//产品型号
    @CtBoAttConfig(displayName = "名称",required = true)
    @TableField("NAME")
    String name;//名称
    @CtBoAttConfig(displayName = "认证类别",required = true)
    @TableField("CERTFTYPE")
    String certfType;//认证类别
    @CtBoAttConfig(displayName = "送检类型",required = true)
    @TableField("INSPECTTYPE")
    String inspectType;//送检类型
    @CtBoAttConfig(displayName = "是否有关键元器件",required = true)
    @TableField("ISDEVICE")
    String isDevice; //是否有关键元器件
    @TableField("DEVICENUMBER")
    String deviceNumber;//关键元器件编码
    @TableField("SAMPLECOUNT")
    String sampleCount;//样品数量
    @CtBoAttConfig(displayName = "成品编码",required = true)
    @TableField("ENDITEMNUMBER")
    String endItemNumber;//成品编码


    public CtCertificationItemBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCertfType() {
        return certfType;
    }

    public void setCertfType(String certfType) {
        this.certfType = certfType;
    }

    public String getInspectType() {
        return inspectType;
    }

    public void setInspectType(String inspectType) {
        this.inspectType = inspectType;
    }

    public String getIsDevice() {
        return isDevice;
    }

    public void setIsDevice(String isDevice) {
        this.isDevice = isDevice;
    }

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getSampleCount() {
        return sampleCount;
    }

    public void setSampleCount(String sampleCount) {
        this.sampleCount = sampleCount;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    public String getEndItemNumber() {
        return endItemNumber;
    }

    public void setEndItemNumber(String endItemNumber) {
        this.endItemNumber = endItemNumber;
    }
}
