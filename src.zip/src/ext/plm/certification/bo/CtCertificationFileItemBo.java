package ext.plm.certification.bo;

public class CtCertificationFileItemBo {
    //标识
    String tagId;
    String docBranchId;
    String productType;
    String applyFilePath;
    String skillFilePath;
    String scanSkillFilePath;
    String elseFilePath;
    String applyFile;
    String skillFile;
    String scanSkillFile;
    String elseFile;
    String baseLineNumber;
    String submitEngineer;//提交工程师
    Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CtCertificationFileItemBo() {
    }

    public String getDocBranchId() {
        return docBranchId;
    }

    public void setDocBranchId(String docBranchId) {
        this.docBranchId = docBranchId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getApplyFilePath() {
        return applyFilePath;
    }

    public void setApplyFilePath(String applyFilePath) {
        this.applyFilePath = applyFilePath;
    }

    public String getSkillFilePath() {
        return skillFilePath;
    }

    public void setSkillFilePath(String skillFilePath) {
        this.skillFilePath = skillFilePath;
    }

    public String getElseFilePath() {
        return elseFilePath;
    }

    public void setElseFilePath(String elseFilePath) {
        this.elseFilePath = elseFilePath;
    }

    public String getApplyFile() {
        return applyFile;
    }

    public void setApplyFile(String applyFile) {
        this.applyFile = applyFile;
    }

    public String getSkillFile() {
        return skillFile;
    }

    public void setSkillFile(String skillFile) {
        this.skillFile = skillFile;
    }

    public String getElseFile() {
        return elseFile;
    }

    public void setElseFile(String elseFile) {
        this.elseFile = elseFile;
    }

    public String getBaseLineNumber() {
        return baseLineNumber;
    }

    public void setBaseLineNumber(String baseLineNumber) {
        this.baseLineNumber = baseLineNumber;
    }

    public String getScanSkillFilePath() {
        return scanSkillFilePath;
    }

    public void setScanSkillFilePath(String scanSkillFilePath) {
        this.scanSkillFilePath = scanSkillFilePath;
    }

    public String getScanSkillFile() {
        return scanSkillFile;
    }

    public void setScanSkillFile(String scanSkillFile) {
        this.scanSkillFile = scanSkillFile;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    public String getSubmitEngineer() {
        return submitEngineer;
    }

    public void setSubmitEngineer(String submitEngineer) {
        this.submitEngineer = submitEngineer;
    }
}
