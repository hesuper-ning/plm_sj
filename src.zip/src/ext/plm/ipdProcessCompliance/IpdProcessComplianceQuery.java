package ext.plm.ipdProcessCompliance;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.ptc.core.components.util.TimeZoneHelper;
import com.ptc.projectmanagement.plan.Plan;
import com.ptc.projectmanagement.plan.PlanActivity;
import com.ptc.projectmanagement.plan.PlanHelper;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.ipdProcessCompliance.bo.CtIpdFractionBasicBo;
import ext.plm.ipdProcessCompliance.bo.CtIpdProcessComplianceBo;
import ext.plm.ipdProcessCompliance.bo.CtProjectScheduleDeviationRateBo;
import ext.plm.ipdProcessCompliance.mapper.CtIpdFractionBasicMapper;
import ext.plm.ipdProcessCompliance.service.IpdFractionBasicService;
import ext.plm.project.CtProjectLogic;
import ext.plm.report.reportForm.CtReportFormsQuery;
import ext.plm.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.method.MethodContext;
import wt.org.WTPrincipalReference;
import wt.pom.WTConnection;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class IpdProcessComplianceQuery {
    /*
     * @param projectName
     *
     * @return List<HashMap<String,String>> {name：项目名称，projectNumber：项目编号}
     *
     * @throws Exception
     */
    @Autowired
    private IpdFractionBasicService ctIpdFractionBasicService;

    private static java.text.DecimalFormat dfDt = new java.text.DecimalFormat("#.00");

    public static List<CtIpdProcessComplianceBo> getProjectList(Long branchId, String type, String currentMonth)
            throws Exception {
        List<CtIpdProcessComplianceBo> result = new ArrayList<CtIpdProcessComplianceBo>();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        try {
            // 只查询正在运行的项目
            String sql = "select project2.namecontainerinfo name,project2.projectNumber "
                    + " from project2 where stateContainerTeammanagedInf = 'RUNNING' OR stateContainerTeammanagedInf = 'COMPLETED'  ";
            System.out.println("ccc---->" + sql);
            statement = connection.prepareStatement(sql); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String projectNumber = rSet.getString("projectnumber");
                Project2 project = CtProjectUtil.getProjectByNumber(projectNumber);
                if (!CtFormatUtil.hasContent(project)) {
                    continue;
                }
//                String projectType = CtProjectLogic.getProjectType(project);
                String projectType = getProjectType(project);
                System.out.println("===============>" + type + "<-------->" + projectType);

                if ("VR".equals(type) && "VR型".equals(projectType)) {
                    CtIpdProcessComplianceBo bo = dealProData(project, df, branchId, type, currentMonth);
                    if (null != bo) {
                        result.add(bo);
                    }
                } else if ("C".equals(type) && "CW型".equals(projectType)) {
                    CtIpdProcessComplianceBo bo = dealProData(project, df, branchId, type, currentMonth);
                    if (null != bo) {
                        result.add(bo);
                    }
                } else {
                    continue;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return result;
    }
    /**
     * 根据项目IBA属性"Ct_ProjectType"判断项目类型
     */
    public static String getProjectType(Project2 project) {
        IBAUtil ibaUtil = new IBAUtil(project);
        String ct_projectType = ibaUtil.getIBAValue("Ct_ProjectType");
        switch (ct_projectType) {

            //VR型   CW型    TDT项目  Charter项目
            case "产品开发项目（基础）":
            case "产品开发项目（增强）":
                return "VR型";
            case "产品开发项目（维护）":
                return "CW型";
            default:
                return "";

        }
    }
    /**
     * 查询项目
     *
     * @param branchId
     * @param type
     * @param currentMonth
     * @return
     * @throws Exception
     */
    public List<CtIpdProcessComplianceBo> getRelationProjectList(Long branchId, String type, String currentMonth)
            throws Exception {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        QuerySpec qs;
        List<CtIpdProcessComplianceBo> result = new ArrayList<CtIpdProcessComplianceBo>();
        try {
            qs = new QuerySpec(Project2.class);
            QueryResult qr = PersistenceHelper.manager.find(qs);
            while (qr.hasMoreElements()) {
                Project2 project = (Project2) qr.nextElement();
                // IBAUtil ibaUtil = new IBAUtil(project);
                if (!CtFormatUtil.hasContent(project)) {
                    continue;
                }
                String projectState = project.getCtmState().getDisplay(Locale.CHINA);
                if (!("已完成".equals(projectState) || "正在运行".equals(projectState))) {
                    continue;
                }
                String projectType = CtProjectLogic.getProjectType(project);
                System.out.println("===============>" + type + "<-------->" + projectType);
                if ("VR".equals(type) && "VR型".equals(projectType)) {
                    CtIpdProcessComplianceBo bo = dealProData(project, df, branchId, type, currentMonth);
                    if (null != bo) {
                        result.add(bo);
                    }
                } else if ("C".equals(type) && "CW型".equals(projectType)) {
                    CtIpdProcessComplianceBo bo = dealProData(project, df, branchId, type, currentMonth);
                    if (null != bo) {
                        result.add(bo);
                    }
                } else {
                    continue;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        }
        return result;
    }

    public static CtIpdProcessComplianceBo dealProData(Project2 project, DateFormat df, Long branchId, String type,
                                                       String currentMonth) throws Exception {
        IBAUtil ibaUtil = new IBAUtil(project);
        // String ct_projectType = ibaUtil.getIBAValue("Ct_ProjectType");
        String projectState = project.getCtmState().getDisplay(Locale.CHINA);
        if ("已完成".equals(projectState)) {
            // 项目实际结束时间
            String value = ibaUtil.getIBAValue("Ct_Actualendtimeoftheproject");
            if (CtFormatUtil.hasContent(value)) {
                value = value.replace("/", "-");
                /*
                 * // 获取当前时间 LocalDateTime now = LocalDateTime.now(); //
                 * 定义日期时间的格式 DateTimeFormatter formatter =
                 * DateTimeFormatter.ofPattern("yyyy-MM"); // 格式化当前时间为字符串 String
                 * formattedDateTime = now.format(formatter);
                 */
                System.out.println("--->" + value + "<---->" + currentMonth);
                if (!(value.contains(currentMonth))) {
                    return null;
                }
            }
        }else if("已取消".equals(projectState) || "未定义".equals(projectState)  || "未启动".equals(projectState)){
            return null;
        }
        System.out.println("<---------------------->");
        CtIpdProcessComplianceBo bo = new CtIpdProcessComplianceBo((branchId + ""), currentMonth);
        bo.setProjectNumber(project.getProjectNumber());
        bo.setProjectName(project.getName());
        String sppp = ibaUtil.getIBAValue("specialProcessProjects");
        if(CtFormatUtil.hasContent(sppp) && "是".equals(sppp.trim())){
            return null;
        }
        bo.setSpecialProcessProjects(sppp);
        bo.setProductLine(ibaUtil.getIBAValue("ct_productLine"));
        // PQA GHT PQA
        String projectPQA = getProjectUsers(project, "QualityRepresentativePQA");// add
        bo.setPqa(projectPQA);

        bo = changeIpdComplianceBo(bo, project.getProjectNumber(), branchId, type, currentMonth);
        bo.setProjectType(type);

        return bo;
    }

    /**
     * @param bo
     * @param projectNumber
     * @param branchId
     * @param type
     * @param currentMonth
     * @return
     */
    public static CtIpdProcessComplianceBo changeIpdComplianceBo(CtIpdProcessComplianceBo bo, String projectNumber, Long branchId, String type,
                                                                 String currentMonth) {
        CtIpdFractionBasicMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtIpdFractionBasicMapper.class);
        Wrapper<CtIpdFractionBasicBo> wrapper = new EntityWrapper<CtIpdFractionBasicBo>();
        wrapper.eq("uniteObjectId", branchId);
        // wrapper.eq("itemType", type);
        wrapper.eq("projectNumber", projectNumber);
        wrapper.eq("belongingtoYM", currentMonth);
        List<CtIpdFractionBasicBo> lt = mapper.selectList(wrapper);
        if (null == lt || lt.size() == 0) {
            bo.setiPDPocessCompliance("0");
            bo.setFileScoreRate("0");
            bo.setKeyDeliverableRateScore("0");
            bo.setKeyDeEffectivenessEvaluation("0");
            bo.setKeyDeTimelinessScore("0");
            bo.setDeductPoints("0");
            bo.setBonusPoints("0");
        } else {
            CtIpdFractionBasicBo basicBo = lt.get(0);
            String submissionRate = "0";
            if (CtFormatUtil.hasContent(basicBo.getSubmissionRate())) {
                submissionRate = basicBo.getSubmissionRate();
            }
            bo.setFileScoreRate(submissionRate);
            String reviewRate = "0";
            if (CtFormatUtil.hasContent(basicBo.getReviewRate())) {
                reviewRate = basicBo.getReviewRate();
            }
            bo.setKeyDeliverableRateScore(reviewRate);
            String averageScoreTh = "0";
            if (CtFormatUtil.hasContent(basicBo.getAverageScoreTh())) {
                averageScoreTh = basicBo.getAverageScoreTh();
            }
            bo.setKeyDeEffectivenessEvaluation(averageScoreTh);
            String averageScoreFo = "0";
            if (CtFormatUtil.hasContent(basicBo.getAverageScoreFo())) {
                averageScoreFo = basicBo.getAverageScoreFo();
            }
            bo.setKeyDeTimelinessScore(averageScoreFo);
            String reduceScore = "0";
            if (CtFormatUtil.hasContent(basicBo.getReduceScore())) {
                reduceScore = basicBo.getReduceScore();
            }
            bo.setDeductPoints(reduceScore);
            String addScore = "0";
            if (CtFormatUtil.hasContent(basicBo.getAddScore())) {
                addScore = basicBo.getAddScore();
            }
            bo.setBonusPoints(addScore);

            Double IPDPocessCompliance = (0.3 * Double.parseDouble(submissionRate)
                    + (0.3 * Double.parseDouble(reviewRate)) + (0.2 * Double.parseDouble(averageScoreTh))
                    + (0.2 * Double.parseDouble(averageScoreFo)) + (0.2 * Double.parseDouble(reduceScore))
                    + (0.2 * Double.parseDouble(addScore)));
            System.out.println("IPDPocessCompliance------->" + IPDPocessCompliance);

            bo.setiPDPocessCompliance(CtReportFormsQuery.changeDf(dfDt.format((IPDPocessCompliance))));
        }
        return bo;
    }

    /**
     * 获取产品下的用户
     */
    public static String getProjectUsers(Project2 project, String roleInnerName) throws Exception {
        StringBuilder sb = new StringBuilder("");
        if (project != null) {
            ContainerTeam conTeamPdm = ContainerTeamHelper.service.getContainerTeam(project);
            ArrayList enumTeamPdm = conTeamPdm.getAllPrincipalsForTarget(Role.toRole(roleInnerName));
            int l = 0;
            for (Object object : enumTeamPdm) {
                ++l;
                WTPrincipalReference principal = (WTPrincipalReference) object;
                String fullName = principal.getFullName();
                if (l == enumTeamPdm.size()) {
                    sb.append(fullName);
                } else {
                    sb.append(fullName).append(",");
                }
            }
        }
        return sb.toString();
    }

    public static List<CtProjectScheduleDeviationRateBo> getDeviationRateProjectList(Long branchId, String type,
                                                                                     String currentYM) throws Exception {
        List<CtProjectScheduleDeviationRateBo> result = new ArrayList<CtProjectScheduleDeviationRateBo>();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        try {
            // 只查询正在运行的项目
            String sql = "select project2.namecontainerinfo name,project2.projectNumber "
                    + " from project2 where stateContainerTeammanagedInf = 'RUNNING' OR stateContainerTeammanagedInf = 'COMPLETED'  ";
            System.out.println("ccc---->" + sql);
            statement = connection.prepareStatement(sql); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String projectNumber = rSet.getString("projectnumber");
                Project2 project = CtProjectUtil.getProjectByNumber(projectNumber);
                if (!CtFormatUtil.hasContent(project)) {
                    continue;
                }
                String projectType = CtProjectLogic.getProjectType(project);
                System.out.println("===============>" + type + "<-------->" + projectType);
                if ("VR".equals(type) && "VR型".equals(projectType)) {
                    CtProjectScheduleDeviationRateBo bo = dealProDeviationRateData(project, df, branchId, type,
                            currentYM);
                    if (null != bo) {
                        result.add(bo);
                    }
                } else if ("C".equals(type) && "CW型".equals(projectType)) {
                    CtProjectScheduleDeviationRateBo bo = dealProDeviationRateData(project, df, branchId, type,
                            currentYM);
                    if (null != bo) {
                        result.add(bo);
                    }
                } else {
                    continue;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return result;
    }

    public static CtProjectScheduleDeviationRateBo dealProDeviationRateData(Project2 project, DateFormat df,
                                                                            Long branchId, String type, String currentYM) throws Exception {
        IBAUtil ibaUtil = new IBAUtil(project);
        // String ct_projectType = ibaUtil.getIBAValue("Ct_ProjectType");
        String projectState = project.getCtmState().getDisplay(Locale.CHINA);
        if ("已完成".equals(projectState)) {
            // 项目实际结束时间
            String value = ibaUtil.getIBAValue("Ct_Actualendtimeoftheproject");
            if (CtFormatUtil.hasContent(value)) {
                value = value.replace("/", "-");
                /*
                 * // 获取当前时间 LocalDateTime now = LocalDateTime.now(); //
                 * 定义日期时间的格式 DateTimeFormatter formatter =
                 * DateTimeFormatter.ofPattern("yyyy-MM"); // 格式化当前时间为字符串 String
                 * formattedDateTime = now.format(formatter);
                 */
                System.out.println("--->" + value + "<---->" + currentYM);
                if (!(value.contains(currentYM))) {
                    return null;
                }
            }
        }
        String sppp = ibaUtil.getIBAValue("specialProcessProjects");
        if(CtFormatUtil.hasContent(sppp) && "是".equals(sppp.trim())){
            return null;
        }

        System.out.println("<---------------------->");

        Plan plan = (Plan) PlanHelper.service.getPlan(ObjectReference.newObjectReference(project));
		/*PersistableAdapter adapter = new PersistableAdapter(project, null, null, null);
		Date a0 = null;
		if (null != adapter) {
			adapter.load("Ct_PDCPActualFinishDate", "Ct_LDCPFinishDateAfterPDCP");
			a0 = (Date) adapter.get("Ct_LDCPFinishDateAfterPDCP");
		}*/
        if (null != plan) {
            Date a0 = getCtPdcpTime(project);
            if(null  == a0){
                a0 =  getCtPdcpTime2(plan);
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(CtDateUtil.parseStringToDate(currentYM, "yyyy-MM"));
            Date currentDate = calendar.getTime();
            calendar.add(Calendar.MONTH, 1);
            Date nextDate = calendar.getTime();
            String year = String.valueOf(calendar.get(Calendar.YEAR));
            String month = String.valueOf(calendar.get(Calendar.MONTH) + 1);
            String day = String.valueOf(calendar.get(Calendar.DATE));
            System.out.println("1currentDate---->" + year + "-" + month + "-" + day);

            CtProjectScheduleDeviationRateBo bo = changeRateBo(project, plan, ibaUtil, branchId, type, a0, currentYM,
                    df);
            bo = getCtProjectScheduleDeviationRateBo(project, currentYM, bo, nextDate, df, a0);


            return bo;
        }
        return null;
    }

    public static CtProjectScheduleDeviationRateBo changeRateBo(Project2 project, Plan plan, IBAUtil ibaUtil,
                                                                Long branchId, String type, Date a0, String currentYM, DateFormat df) throws Exception {
        CtProjectScheduleDeviationRateBo bo = new CtProjectScheduleDeviationRateBo((branchId + ""), currentYM);
        bo.setProjectNumber(project.getProjectNumber());
        bo.setProjectName(project.getName());
        bo.setProductLine(ibaUtil.getIBAValue("ct_productLine"));
        bo.setProjectType(type);
        if (null != a0) {
            String pdcpPlannedTime = CtDateUtil.parseDate(a0, "yyyy-MM-dd");
            bo.setPdcpPlannedTime(pdcpPlannedTime);
        }
		/*if (CtFormatUtil.hasContent(plan.getFinishDate())) {
			bo.setPlanCompleteTimeEnd(df.format(plan.getFinishDate().getTime()));
		}
		if (CtFormatUtil.hasContent(plan.getActualFinishDate())) {
			bo.setActualCompleteTimeEnd(df.format(plan.getActualFinishDate().getTime()));
		}
		bo.setExecuteStatus(IpdProcessComplianceHelper.getExecuteStatus(plan.getFinishDate(),
				plan.getActualFinishDate(), currentYM, false));
		bo.setDeviationRate(IpdProcessComplianceHelper.getDeviationRate(a0, plan.getFinishDate(),
				plan.getFinishDate(), plan.getActualFinishDate()));*/
        return bo;
    }
	/*public static String getCurrentMileStone(Project2 prj, boolean jgIng) throws Exception {
		MethodContext context = MethodContext.getContext();
		WTConnection connection = (WTConnection) context.getConnection();
		PreparedStatement statement = null;
		ResultSet rSet = null;
		try {
			// 只查询正在运行的项目
			StringBuilder sqlSb = new StringBuilder(
					"select ida2a2 as \"id\",classnamea2a2 as \"className\" from planactivity where ida3containerreference = ")
							.append(prj.getPersistInfo().getObjectIdentifier().getId())
							.append(" and milestone = 1 and lineNumber in (")
							.append(" select min(linenumber) from planactivity where ")
							.append(" ida3containerreference = ")
							.append(prj.getPersistInfo().getObjectIdentifier().getId()).append(" and milestone = 1 ");
			if (jgIng) {
				sqlSb.append(" and percentworkcomplete!=100 and linenumber!=0 )");
			} else {
				sqlSb.append(" and percentworkcomplete=100 and linenumber!=0 )");
			}

			System.out.println("ccc2---->" + sqlSb.toString());
			statement = connection.prepareStatement(sqlSb.toString()); //
			rSet = statement.executeQuery();
			while (rSet.next()) {
				String id = rSet.getString("id");
				String className = rSet.getString("className");
				if (CtFormatUtil.hasContent(id) && CtFormatUtil.hasContent(className)) {
					// 获取当前阶段里程碑
					PlanActivity currentMileStone = (PlanActivity) CtWTObjectUtil
							.getObjectByOid("OR:" + className + ":" + id);
					return currentMileStone.getName();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
		} finally {
			if (statement != null)
				statement.close();
			if (connection != null && connection.isActive())
				connection.release();
		}
		return "";
	}*/

    public static String getNumberScore(String prjNum) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        try {
            // 只查询正在运行的项目
            StringBuilder sqlSb = new StringBuilder(
                    "SELECT t.NUMBERSCORE FROM WCADMIN.ZKEYDELIVERABLEBASICTABLE t WHERE t.PROJECTNUMBER='")
                    .append(prjNum).append("'  ORDER BY t.CREATETIME desc");
            System.out.println("cccscore---->" + sqlSb.toString());
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String num = rSet.getString("NUMBERSCORE");
                if (CtFormatUtil.hasContent(num)) {
                    return num;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return "0";
    }

    public static String getCurrentYM(String branchId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        try {
            StringBuilder sqlSb = new StringBuilder(
                    "SELECT belongingtoYM FROM WCADMIN.ZIPDASSOCIATEDDATE t WHERE t.UNITEOBJECTID='").append(branchId)
                    .append("' ");
            System.out.println("cccYM---->" + sqlSb.toString());
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String curent = rSet.getString("belongingtoYM");
                if (CtFormatUtil.hasContent(curent)) {
                    return curent;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return null;
    }

    public static void addAssociatedDateInfo(String currentYM, String branchId, String currentY, String currentM)
            throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder(
                    "INSERT INTO WCADMIN.ZIPDASSOCIATEDDATE (UNITEOBJECTID,belongingtoYM,")
                    .append(" belongingtoMouth,belongingtoYear) VALUES('").append(branchId).append("','")
                    .append(currentYM).append("','").append(currentM).append("','").append(currentY)
                    .append("')");
            System.out.println("ccccurrent---->" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 判断是否已经创建文档
     *
     * @param formattedDateTime
     * @return
     * @throws Exception
     */
    public static String getCurrentYMByDoc(String formattedDateTime) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        try {
            StringBuilder sqlSb = new StringBuilder(
                    "SELECT UNITEOBJECTID FROM WCADMIN.ZIPDASSOCIATEDDATE t WHERE t.BELONGINGTOYM='")
                    .append(formattedDateTime).append("' ");
            System.out.println("cYM---->" + sqlSb.toString());
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String curent = rSet.getString("UNITEOBJECTID");
                if (CtFormatUtil.hasContent(curent)) {
                    return curent;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return null;
    }

    /**
     * 获取所有时间
     *
     * @return
     * @throws Exception
     */
    public static Map<String, List<String>> getAllYM() throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        Map<String, List<String>> map = new HashMap<String, List<String>>();
        try {
            StringBuilder sqlSb = new StringBuilder(
                    "SELECT BELONGINGTOYEAR,BELONGINGTOMOUTH,BELONGINGTOYM FROM WCADMIN.ZIPDASSOCIATEDDATE ORDER BY BELONGINGTOYM ");
            System.out.println("callYM---->" + sqlSb.toString());
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String yy = rSet.getString("BELONGINGTOYEAR");
                String mm = rSet.getString("BELONGINGTOMOUTH");
                List<String> list = map.get(yy);
                if (null == list || list.size() == 0) {
                    list = new ArrayList<String>();
                    list.add(mm);
                    map.put(yy, list);
                } else {
                    list.add(mm);
                    map.put(yy, list);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return map;
    }

    /**
     * wrapper.eq("projectType", type);
     * 获取所有时间
     *
     * @return
     * @throws Exception
     */
    public static List<String> getProductLineByYM(String YM, String type) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        List<String> list = new ArrayList<String>();
        try {
            StringBuilder sqlSb = new StringBuilder(
                    "SELECT DISTINCT PRODUCTLINE  FROM WCADMIN.ZCtProjectScheduleDRateTable t WHERE BELONGINGTOYM='")
                    .append(YM).append("' AND projectType='").append(type).append("' ORDER BY PRODUCTLINE");
            System.out.println("getProductLineYM---->" + sqlSb.toString());
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String PRODUCTLINE = rSet.getString("PRODUCTLINE");
                if (CtFormatUtil.hasContent(PRODUCTLINE)) {
                    list.add(PRODUCTLINE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return list;
    }


    public static String getProductLineByYM(String YY, String MM, String num) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        try {
            StringBuilder sqlSb =
                    new StringBuilder("SELECT SUM(COSTAMOUNT) SM FROM WCADMIN.ZBISubjectCost t ")
                            .append("WHERE 1=1 ");
            if (CtFormatUtil.hasContent(YY)) {
                sqlSb.append(" AND PARTICULARYEAR='").append(YY).append("'");
            }
            if (CtFormatUtil.hasContent(MM)) {
                sqlSb.append(" AND ACCOUNTINGPERIOD='").append(MM).append("'");
            }
            if (CtFormatUtil.hasContent(num)) {
                sqlSb.append(" AND ORDERNUMBER='").append(num).append("'");
            }
            System.out.println("getProductLineYM---->" + sqlSb.toString());
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String SM = rSet.getString("SM");
                if (CtFormatUtil.hasContent(SM)) {
                    return SM;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return "0";
    }

    public static CtProjectScheduleDeviationRateBo getCtProjectScheduleDeviationRateBo(Project2 prj, String currentYM, CtProjectScheduleDeviationRateBo bo,
                                                                                       Date nextDate, DateFormat df, Date a0) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        List<PlanActivity> list = new ArrayList<PlanActivity>();
        try {
            // 只查询正在运行的项目
            StringBuilder sqlSb = new StringBuilder("select ida2a2 as \"id\",classnamea2a2 as \"className\" ")
                    .append(",TO_CHAR(PlanActivity.FINISHDATE, 'yyyy-MM-dd') as planFinishDate,TO_CHAR(PlanActivity.ACTUALFINISHDATE, 'yyyy-MM-dd') as actualPlanFinishDate ")
                    .append(" ,PERCENTWORKCOMPLETE  from planactivity where ida3containerreference = ")
                    .append(prj.getPersistInfo().getObjectIdentifier().getId())
                    .append(" and milestone = 1 and linenumber!=0 ").append("AND (UPPER(NAME) LIKE '%PDCP%'")
                    .append("OR UPPER(NAME) LIKE '%TR4%'").append("OR UPPER(NAME) LIKE '%TR4A%'")
                    .append("OR UPPER(NAME) LIKE '%第一阶段%'").append("OR UPPER(NAME) LIKE '%TR5%'")
                    .append("OR UPPER(NAME) LIKE '%第二阶段%'").append("OR UPPER(NAME) LIKE '%TR6%'")
                    .append("OR UPPER(NAME) LIKE '%送检%'").append("OR UPPER(NAME) LIKE '%LDCP%') ORDER BY LINENUMBER");

            System.out.println("ccc3---->" + sqlSb.toString());
            System.out.println("nextDate----->" + CtDateUtil.parseDate(nextDate, "yyyy-MM-dd"));
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();

            String planfinishDt = "";
            while (rSet.next()) {
                String id = rSet.getString("id");
                String className = rSet.getString("className");
                String planFinishDateStr = rSet.getString("planFinishDate");
                String actualPlanFinishDateStr = rSet.getString("actualPlanFinishDate");
                String PERCENTWORKCOMPLETE = rSet.getString("PERCENTWORKCOMPLETE");
                if (CtFormatUtil.hasContent(id) && CtFormatUtil.hasContent(className)) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(CtDateUtil.parseStringToDate(currentYM, "yyyy-MM"));
                    int lastDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                    Date lastDt = CtDateUtil.parseStringToDate((currentYM +"-" +lastDay), "yyyy-MM-dd");
                    Date currentDate = new Date();
                    if(currentDate.before(lastDt)){
//                            Date date1 = CtDateUtil.parseStringToDate(s, "yyyy-MM-dd");
                        lastDt = currentDate;
                    }

                    // 获取当前阶段里程碑
                    PlanActivity currentMileStone = (PlanActivity) CtWTObjectUtil
                            .getObjectByOid("OR:" + className + ":" + id);
                    if (CtFormatUtil.hasContent(planFinishDateStr)
                            && CtDateUtil.parseStringToDate(planFinishDateStr, "yyyy-MM-dd").before(nextDate)
                    ) {
                        bo.setMileStoneNameEnd(currentMileStone.getName());
                        bo.setRelatedMile(currentMileStone.getName());

                        Date planfinishDate = null;
                       /* if(CtFormatUtil.hasContent(planfinishDt)){
                            bo.setPlanCompleteTimeEnd(planfinishDt);
                            planfinishDate = CtDateUtil.parseStringToDate(planfinishDt, "yyyy-MM-dd");

                            System.out.println("1planFinishDateStr------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + planfinishDt );

                        }else */
                        if (CtFormatUtil.hasContent(planFinishDateStr)) {
                            bo.setPlanCompleteTimeEnd(planFinishDateStr);

                            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                            format.setTimeZone(TimeZoneHelper.getLocalTimeZone());
                            planfinishDate = format.parse(planFinishDateStr);
//                            planfinishDate = CtDateUtil.parseStringToDate(planFinishDateStr, "yyyy-MM-dd");
                            System.out.println("2planFinishDateStr------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + planFinishDateStr );

                        }
                        Date actualPlanFinishDate = null;
                        if (CtFormatUtil.hasContent(actualPlanFinishDateStr)) {
                            bo.setActualCompleteTimeEnd(actualPlanFinishDateStr);

                            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                            format.setTimeZone(TimeZoneHelper.getLocalTimeZone());
                            actualPlanFinishDate = format.parse(actualPlanFinishDateStr);
//                            actualPlanFinishDate = CtDateUtil.parseStringToDate(actualPlanFinishDateStr, "yyyy-MM-dd");
                            System.out.println("actualPlanFinishDateStr------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + actualPlanFinishDateStr );

                        }
                        bo.setExecuteStatus(IpdProcessComplianceHelper.getExecuteStatus(planfinishDate,
                                actualPlanFinishDate, currentYM, false));

                        System.out.println("rate------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + a0 + "---" +planfinishDate  + "---" +actualPlanFinishDate );
                       /* String rate = "";
                        if (null == actualPlanFinishDate && null != planfinishDate){
                            if(planfinishDate.before(lastDt)){
                                rate = IpdProcessComplianceHelper.getDeviationRate(a0, planfinishDate,
                                        planfinishDate, lastDt);
                            }else if(null == a0){
                                rate = "-";
                            }else{
                                rate = "0";
                            }

                        }else{
                            rate = IpdProcessComplianceHelper.getDeviationRate(a0, planfinishDate,
                                    planfinishDate, actualPlanFinishDate);
                        }*/
                        String rate = "";
                        if(planfinishDate == null || planfinishDate.after(lastDt)){
                            rate = "0";
                        }else{
                            rate = IpdProcessComplianceHelper.getDeviationRate(a0, planfinishDate,
                                    planfinishDate, actualPlanFinishDate);
                            System.out.println("2rate------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + rate );
                        }

                        System.out.println("rate------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + rate );

                        bo.setDeviationRate(rate);
                        System.out.println("6rate------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + bo.getDeviationRate() );

                        if (!CtFormatUtil.hasContent(actualPlanFinishDateStr)) {

                            return bo;
                        }
                    } else if (CtFormatUtil.hasContent(planFinishDateStr)
                            && CtDateUtil.parseStringToDate(planFinishDateStr, "yyyy-MM-dd").after(nextDate)
                        //&& ( !CtFormatUtil.hasContent(PERCENTWORKCOMPLETE) || !PERCENTWORKCOMPLETE.equals("100") )
                    ) {
                        bo.setMileStoneNameIng(currentMileStone.getName());


                        Date planfinishDate = null;
                        if (CtFormatUtil.hasContent(planFinishDateStr)) {
                            bo.setPlanCompleteTimeIng(planFinishDateStr);

                            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                            format.setTimeZone(TimeZoneHelper.getLocalTimeZone());
                            planfinishDate = format.parse(planFinishDateStr);
//                            planfinishDate = CtDateUtil.parseStringToDate(planFinishDateStr, "yyyy-MM-dd");
                        }
                        Date actualPlanFinishDate = null;
                        if (CtFormatUtil.hasContent(actualPlanFinishDateStr)) {

                            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                            format.setTimeZone(TimeZoneHelper.getLocalTimeZone());
                            actualPlanFinishDate = format.parse(actualPlanFinishDateStr);

//                            actualPlanFinishDate = CtDateUtil.parseStringToDate(actualPlanFinishDateStr, "yyyy-MM-dd");
                        }


                        //有相关里程碑
                        if(!CtFormatUtil.hasContent(bo.getRelatedMile())){
                            bo.setRelatedMile(currentMileStone.getName());
                            bo.setExecuteStatus(IpdProcessComplianceHelper.getExecuteStatus(planfinishDate,
                                    actualPlanFinishDate, currentYM, false));
                        }

                        System.out.println("2rate------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + a0 + "---" +planfinishDate  + "---" +actualPlanFinishDate );

                        String rate = "";
                        if(planfinishDate == null || planfinishDate.after(lastDt)){
                            rate = "0";
                        }else{
                            rate = IpdProcessComplianceHelper.getDeviationRate(a0, planfinishDate,
                                    a0, lastDt);
                            System.out.println("2rate------>" + prj.getProjectNumber() + "------" + currentMileStone.getName() + "<---->" + rate );
                        }
                        bo.setDeviationRate(rate);
                        return bo;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return bo;
    }

    public static Date getCtPdcpTime(Project2 prj) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        List<PlanActivity> list = new ArrayList<PlanActivity>();
        try {
            // 只查询正在运行的项目
            StringBuilder sqlSb = new StringBuilder("select ida2a2 as \"id\",classnamea2a2 as \"className\" ")
                    .append(",TO_CHAR(PlanActivity.FINISHDATE, 'yyyy-MM-dd') as planFinishDate,TO_CHAR(PlanActivity.ACTUALFINISHDATE, 'yyyy-MM-dd') as actualPlanFinishDate ")
                    .append(" ,PERCENTWORKCOMPLETE  from planactivity where ida3containerreference = ")
                    .append(prj.getPersistInfo().getObjectIdentifier().getId())
                    .append(" and milestone = 1 and linenumber!=0 ").append("AND UPPER(NAME) LIKE '%PDCP%' ORDER BY LINENUMBER");

            System.out.println("ccc3---->" + sqlSb.toString());
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                String planFinishDateStr = rSet.getString("planFinishDate");
                if (CtFormatUtil.hasContent(planFinishDateStr)) {
                    return CtDateUtil.parseStringToDate(planFinishDateStr, "yyyy-MM-dd");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return null;
    }

    public static Date getCtPdcpTime2(Plan plan) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rSet = null;
        List<PlanActivity> list = new ArrayList<PlanActivity>();
        try {
            // 只查询正在运行的项目
            StringBuilder sqlSb = new StringBuilder("SELECT t.STARTDATE FROM WCADMIN.PlanActivity t WHERE t.IDA3ROOTREFERENCE='")
                    .append(plan.getPersistInfo().getObjectIdentifier().getId()).append("' AND t.NAME ='计划阶段'");

            System.out.println("ccc4---->" + sqlSb.toString());
            statement = connection.prepareStatement(sqlSb.toString()); //
            rSet = statement.executeQuery();
            while (rSet.next()) {
                Date STARTDATE = rSet.getDate("STARTDATE");
                return STARTDATE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return null;
    }

}
