package ext.plm.ipdProcessCompliance.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import ext.plm.ipdProcessCompliance.IpdProcessComplianceQuery;
import ext.plm.ipdProcessCompliance.bo.CtIpdProcessComplianceBo;
import ext.plm.ipdProcessCompliance.mapper.CtIpdProcessComplianceMapper;
import ext.plm.util.CtFormatUtil;

@Service
public class IpdProcessComplianceServiceImpl extends ServiceImpl<CtIpdProcessComplianceMapper, CtIpdProcessComplianceBo>
		implements IpdProcessComplianceService {

	@Override
	public List<CtIpdProcessComplianceBo> getIpdProcessCompliance(Long branchId, String type, String currentYM,boolean isReport,boolean accrue)
			throws Exception {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);
		System.out.println("getIpdProcessCompliance---->" + formattedDateTime + "<------>" + currentYM + "<--->"
				+ (formattedDateTime.equals(currentYM)));
		if (!isReport && formattedDateTime.equals(currentYM)) {
			Wrapper<CtIpdProcessComplianceBo> wrapper = new EntityWrapper<CtIpdProcessComplianceBo>();
			if(CtFormatUtil.hasContent(branchId)){
				wrapper.eq("uniteObjectId", branchId);
			}
			wrapper.eq("belongingtoYM", currentYM);
			wrapper.eq("projectType", type);
			super.delete(wrapper);
			
			List<CtIpdProcessComplianceBo> entityList = IpdProcessComplianceQuery.getProjectList(branchId, type,
					currentYM);
			super.insertOrUpdateAllColumnBatch(entityList);
			return entityList;
		} else {
			List<CtIpdProcessComplianceBo> lt =  new ArrayList<CtIpdProcessComplianceBo>();
			if(accrue){
				String[] arrYM = currentYM.split("-");
				Wrapper<CtIpdProcessComplianceBo> wrapper = new EntityWrapper<CtIpdProcessComplianceBo>();
				if(CtFormatUtil.hasContent(branchId)){
					wrapper.eq("uniteObjectId", branchId);
				}
				wrapper.eq("belongingtoYear", arrYM[0]);
				wrapper.le("BELONGINGTOMOUTH",arrYM[1]);
				wrapper.eq("projectType", type);
				lt = super.selectList(wrapper);
			}else{
				Wrapper<CtIpdProcessComplianceBo> wrapper = new EntityWrapper<CtIpdProcessComplianceBo>();
				if(CtFormatUtil.hasContent(branchId)){
					wrapper.eq("uniteObjectId", branchId);
				}
				wrapper.eq("belongingtoYM", currentYM);
				wrapper.eq("projectType", type);
				lt = super.selectList(wrapper);
			}
			return lt;
		}
	}	
}
