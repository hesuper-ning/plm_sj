package ext.plm.ipdProcessCompliance.service;

import java.util.List;

import ext.plm.ipdProcessCompliance.bo.CtIpdProcessComplianceBo;
import ext.plm.ipdProcessCompliance.bo.CtProjectScheduleDeviationRateBo;
import wt.method.RemoteInterface;

@RemoteInterface
public interface IpdProcessComplianceService {
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	List<CtIpdProcessComplianceBo> getIpdProcessCompliance(Long branchId, String type,String currentMonth,boolean isReport,boolean accrue) throws Exception;

}
