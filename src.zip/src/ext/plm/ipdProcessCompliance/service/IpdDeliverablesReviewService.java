package ext.plm.ipdProcessCompliance.service;

import java.util.List;

import ext.plm.ipdProcessCompliance.bo.CtIpdDeliverablesReviewBo;
import wt.method.RemoteInterface;

@RemoteInterface
public interface IpdDeliverablesReviewService {
	/**
	 * 56加减
	 * 
	 * @return
	 * @throws Exception
	 */
	List<CtIpdDeliverablesReviewBo> getIpdDeliverablesReview(Long branchId, String showProjectNumber,String type,String currentYM) throws Exception;

	/**
	 * 保存基础信息--56
	 * 
	 * @param branchId
	 * @throws Exception
	 */
	public Boolean saveIpdDeliverablesReviewInfo(List<CtIpdDeliverablesReviewBo> entityList) throws Exception;

	/**
	 * 删除--56
	 * 
	 * @param ids
	 * @throws Exception
	 */
	void deleteIpdFractionBasicInfo(List<String> ids) throws Exception;
}
