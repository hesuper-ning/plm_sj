package ext.plm.ipdProcessCompliance.service;

import java.util.List;

import ext.plm.ipdProcessCompliance.bo.CtProjectScheduleDeviationRateBo;
import wt.method.RemoteInterface;

@RemoteInterface
public interface IPDProjectScheduleDevRateService {
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	List<CtProjectScheduleDeviationRateBo> getProjectScheduleDeviationRate(String pline,Long branchId, String type,String currentMonth,boolean isReport,boolean accrue) throws Exception;

}
