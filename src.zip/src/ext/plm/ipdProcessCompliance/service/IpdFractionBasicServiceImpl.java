package ext.plm.ipdProcessCompliance.service;

import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import ext.plm.ipdProcessCompliance.bo.CtIpdFractionBasicBo;
import ext.plm.ipdProcessCompliance.mapper.CtIpdFractionBasicMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtProjectUtil;
import ext.plm.util.IBAUtil;
import wt.projmgmt.admin.Project2;

@Service
public class IpdFractionBasicServiceImpl extends ServiceImpl<CtIpdFractionBasicMapper, CtIpdFractionBasicBo>
		implements IpdFractionBasicService {
	@Override
	public CtIpdFractionBasicBo getIpdFractionBasic(Long branchId, String showProjectNumber,String ym) throws Exception {
		Wrapper<CtIpdFractionBasicBo> wrapper = new EntityWrapper<CtIpdFractionBasicBo>();
		wrapper.eq("uniteObjectId", branchId);
		wrapper.eq("projectNumber", showProjectNumber);
		/*LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);*/
		wrapper.eq("belongingtoYM", ym);
		System.out.println("showProjectNumber----->" + showProjectNumber);
		List<CtIpdFractionBasicBo> lt =  super.selectList(wrapper);
		if(null == lt || lt.size() == 0){
			CtIpdFractionBasicBo entity = new CtIpdFractionBasicBo(branchId+"",showProjectNumber);
			Project2 project = CtProjectUtil.getProjectByNumber(showProjectNumber);	
			if (null == project) {
				lt.add(entity);
			}else{
				IBAUtil ibaUtil = new IBAUtil(project);
				entity.setProjectNumber1(project.getProjectNumber());
				entity.setProjectName1(project.getName());
				entity.setProductLine1(ibaUtil.getIBAValue("ct_productLine"));
			}
			String[] timeSpt = ym.split("-");
			if (null != timeSpt && timeSpt.length == 2) {
				entity.setBelongingtoYear(timeSpt[0]);
				entity.setBelongingtoMouth(timeSpt[1]);
				entity.setBelongingtoYM(ym);
			}
			lt.add(entity);
			super.insertOrUpdateAllColumnBatch(lt);
		}
		return lt.get(0);
	}

	@Override
	public CtIpdFractionBasicBo updateIpdFractionBasicInfo(String id, String key, String value, String branchId)
			throws Exception {
		CtIpdFractionBasicBo bo = super.selectById(id);
		CtCommonUtil.setObjectValue(bo, key, value);
		super.updateById(bo);
		return bo;
	}

	@Override
	public Boolean saveIpdFractionBasicInfo(List<CtIpdFractionBasicBo> entityList) throws Exception {
		return super.insertOrUpdateAllColumnBatch(entityList);
	}

	@Override
	public void deleteIpdFractionBasicInfo(List<String> ids) throws Exception {
		super.deleteBatchIds(ids);
	}

}
