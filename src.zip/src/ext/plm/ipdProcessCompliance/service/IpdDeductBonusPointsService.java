package ext.plm.ipdProcessCompliance.service;

import java.util.List;

import ext.plm.ipdProcessCompliance.bo.CtIpdDeductBonusPointsBo;
import wt.method.RemoteInterface;

@RemoteInterface
public interface IpdDeductBonusPointsService {
	/**
	 * 56加减
	 * 
	 * @return
	 * @throws Exception
	 */
	List<CtIpdDeductBonusPointsBo> getIpdProcessComplianceDeductBonusPoints(Long branchId, String itemType,
			String showProjectNumber,String currentYM) throws Exception;

	/**
	 * 更新
	 * 
	 * @param id
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
	CtIpdDeductBonusPointsBo updateDeductBonusPointsInfo(String id, String key, String value, String branchId,
			String itemType) throws Exception;

	/**
	 * 保存基础信息--56
	 * 
	 * @param branchId
	 * @throws Exception
	 */
	public Boolean saveDeductBonusPointsInfo(List<CtIpdDeductBonusPointsBo> entityList) throws Exception;

	/**
	 * 删除--56
	 * 
	 * @param ids
	 * @throws Exception
	 */
	void deleteDeductBonusPointsInfo(List<String> ids) throws Exception;
}
