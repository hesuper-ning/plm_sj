package ext.plm.ipdProcessCompliance.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import ext.plm.ipdProcessCompliance.IpdProcessComplianceQuery;
import ext.plm.ipdProcessCompliance.bo.CtProjectScheduleDeviationRateBo;
import ext.plm.ipdProcessCompliance.mapper.CtProjectScheduleDeviationRateMapper;
import ext.plm.util.CtFormatUtil;

@Service
public class IPDProjectScheduleDevRateServiceImpl
		extends ServiceImpl<CtProjectScheduleDeviationRateMapper, CtProjectScheduleDeviationRateBo>
		implements IPDProjectScheduleDevRateService {

	@Override
	public List<CtProjectScheduleDeviationRateBo> getProjectScheduleDeviationRate(String pline,Long branchId, String type,
			String currentYM, boolean isReport, boolean accrue) throws Exception {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);
		System.out.println("getCtScheduleDeviationRate---->" + formattedDateTime + "<------>" + currentYM + "<--->"
				+ (formattedDateTime.equals(currentYM)));

		if (!isReport && formattedDateTime.equals(currentYM)) {
			Wrapper<CtProjectScheduleDeviationRateBo> wrapper = new EntityWrapper<CtProjectScheduleDeviationRateBo>();
			if (CtFormatUtil.hasContent(branchId)) {
				wrapper.eq("uniteObjectId", branchId);
			}
			wrapper.eq("belongingtoYM", currentYM);
			wrapper.eq("projectType", type);
			super.delete(wrapper);

			List<CtProjectScheduleDeviationRateBo> entityList = IpdProcessComplianceQuery
					.getDeviationRateProjectList(branchId, type, currentYM); // 
			super.insertOrUpdateAllColumnBatch(entityList);
			return entityList;
		} else {
			List<CtProjectScheduleDeviationRateBo> lt = new ArrayList<CtProjectScheduleDeviationRateBo>();
			if (accrue) {
				String[] arrYM = currentYM.split("-");
				Wrapper<CtProjectScheduleDeviationRateBo> wrapper = new EntityWrapper<CtProjectScheduleDeviationRateBo>();
				if (CtFormatUtil.hasContent(branchId)) {
					wrapper.eq("uniteObjectId", branchId);
				}
				if (CtFormatUtil.hasContent(pline)) {
					wrapper.eq("PRODUCTLINE", pline);
				}
				wrapper.eq("belongingtoYear", arrYM[0]);
				wrapper.le("BELONGINGTOMOUTH", arrYM[1]);
				wrapper.eq("projectType", type);
				lt = super.selectList(wrapper);
			} else {
				Wrapper<CtProjectScheduleDeviationRateBo> wrapper = new EntityWrapper<CtProjectScheduleDeviationRateBo>();
				if (CtFormatUtil.hasContent(branchId)) {
					wrapper.eq("uniteObjectId", branchId);
				}
				if (CtFormatUtil.hasContent(pline)) {
					wrapper.eq("PRODUCTLINE", pline);
				}
				wrapper.eq("belongingtoYM", currentYM);
				wrapper.eq("projectType", type); //
				lt = super.selectList(wrapper);
			}
			return lt;
		}
	}

}
