package ext.plm.ipdProcessCompliance.service;

import java.util.List;

import ext.plm.ipdProcessCompliance.bo.CtIpdFractionBasicBo;
import wt.method.RemoteInterface;

@RemoteInterface
public interface IpdFractionBasicService {
	/**
	 * 56加减
	 * 
	 * @return
	 * @throws Exception
	 */
	CtIpdFractionBasicBo getIpdFractionBasic(Long branchId, String showProjectNumber,String ym) throws Exception;

	/**
	 * 更新
	 * 
	 * @param id
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
	CtIpdFractionBasicBo updateIpdFractionBasicInfo(String id, String key, String value, String branchId)
			throws Exception;

	/**
	 * 保存基础信息--56
	 * 
	 * @param branchId
	 * @throws Exception
	 */
	public Boolean saveIpdFractionBasicInfo(List<CtIpdFractionBasicBo> entityList) throws Exception;

	/**
	 * 删除--56
	 * 
	 * @param ids
	 * @throws Exception
	 */
	void deleteIpdFractionBasicInfo(List<String> ids) throws Exception;
}
