package ext.plm.ipdProcessCompliance.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import ext.plm.ipdProcessCompliance.IpdProcessComplianceHelper;
import ext.plm.ipdProcessCompliance.bo.CtIpdDeliverablesReviewBo;
import ext.plm.ipdProcessCompliance.mapper.CtIpdDeliverablesReviewMapper;
import ext.plm.util.CtFormatUtil;

@Service
public class IpdDeliverablesReviewServiceImpl extends
		ServiceImpl<CtIpdDeliverablesReviewMapper, CtIpdDeliverablesReviewBo> implements IpdDeliverablesReviewService {
	@Override
	public List<CtIpdDeliverablesReviewBo> getIpdDeliverablesReview(Long branchId, String showProjectNumber,
			String type, String currentYM) throws Exception {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);
		boolean jgCurrentYm = formattedDateTime.equals(currentYM);
		Wrapper<CtIpdDeliverablesReviewBo> wrapper = new EntityWrapper<CtIpdDeliverablesReviewBo>();
		if(CtFormatUtil.hasContent(branchId) && !"0".equals(branchId)){
			wrapper.eq("uniteObjectId", branchId);
		}
		wrapper.eq("projectNumberReview", showProjectNumber);
		wrapper.eq("lType", type);
		wrapper.eq("belongingtoYM", currentYM);
		List<CtIpdDeliverablesReviewBo> list = super.selectList(wrapper);
		List<String> idList = new ArrayList<String>();
		System.out
				.println("type----->" + type + "--showProjectNumber----->" + showProjectNumber + "<-->" + jgCurrentYm);
		if (jgCurrentYm) {
			if (null != list && list.size() > 0) {
				for (int l = 0; l < list.size(); l++) {
					CtIpdDeliverablesReviewBo bo = list.get(l);
					idList.add(bo.getId());
				}
				super.deleteBatchIds(idList);
			}
			list = new ArrayList<CtIpdDeliverablesReviewBo>();
			list = IpdProcessComplianceHelper.getPlanDeliverData(branchId + "", showProjectNumber, type, currentYM);
			if (null != list && list.size() > 0) {
				super.insertOrUpdateAllColumnBatch(list);
			}
		}
		return list;
	}

	@Override
	public Boolean saveIpdDeliverablesReviewInfo(List<CtIpdDeliverablesReviewBo> entityList) throws Exception {
		return super.insertOrUpdateAllColumnBatch(entityList);
	}

	@Override
	public void deleteIpdFractionBasicInfo(List<String> ids) throws Exception {
		super.deleteBatchIds(ids);
	}

}
