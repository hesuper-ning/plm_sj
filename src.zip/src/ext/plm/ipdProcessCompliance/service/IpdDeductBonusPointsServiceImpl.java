package ext.plm.ipdProcessCompliance.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import ext.plm.bean.CtBeanFactory;
import ext.plm.ipdProcessCompliance.bo.CtIpdDeductBonusPointsBo;
import ext.plm.ipdProcessCompliance.bo.CtIpdFractionBasicBo;
import ext.plm.ipdProcessCompliance.mapper.CtIpdDeductBonusPointsMapper;
import ext.plm.ipdProcessCompliance.mapper.CtIpdFractionBasicMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;

@Service
public class IpdDeductBonusPointsServiceImpl extends ServiceImpl<CtIpdDeductBonusPointsMapper, CtIpdDeductBonusPointsBo>
		implements IpdDeductBonusPointsService {

	@Override
	public List<CtIpdDeductBonusPointsBo> getIpdProcessComplianceDeductBonusPoints(Long branchId, String itemType,
			String showProjectNumber, String currentYM) throws Exception {
		Wrapper<CtIpdDeductBonusPointsBo> wrapper = new EntityWrapper<CtIpdDeductBonusPointsBo>();
		wrapper.eq("uniteObjectId", branchId);
		wrapper.eq("itemType", itemType);
		wrapper.eq("projectNumber", showProjectNumber);
		wrapper.eq("belongingtoYM", currentYM);
		System.out.println("showProjectNumber----->" + showProjectNumber + "<---itemType-->" + itemType);
		return super.selectList(wrapper);
	}

	@Override
	public CtIpdDeductBonusPointsBo updateDeductBonusPointsInfo(String id, String key, String value, String branchId,
			String itemType) throws Exception {
		CtIpdDeductBonusPointsBo bo = super.selectById(id);
		if ("projectData".equals(key) && CtFormatUtil.hasContent(value)
				&& !CtFormatUtil.hasContent(bo.getProjectData())) {
			CtIpdFractionBasicMapper ctMapper = CtBeanFactory.newCtBeanFactory()
					.getBean(CtIpdFractionBasicMapper.class);
			CtIpdFractionBasicBo basicBo = changeBo(ctMapper,bo.getProjectNumber(),bo.getBelongingtoYM(),branchId,bo.getItemType(),1);
			ctMapper.updateAllColumnById(basicBo);
		}
		CtCommonUtil.setObjectValue(bo, key, value);
		super.updateById(bo);
		return bo;
	}

	public CtIpdFractionBasicBo changeBo(CtIpdFractionBasicMapper ctMapper, String projectNum,String YM,
			String branchId,String itemType,int  dealData) {
		Wrapper<CtIpdFractionBasicBo> wrapper = new EntityWrapper<CtIpdFractionBasicBo>();
		wrapper.eq("uniteObjectId", branchId);
		wrapper.eq("projectNumber", projectNum);
		wrapper.eq("belongingtoYM", YM);
		List<CtIpdFractionBasicBo> lt = ctMapper.selectList(wrapper);
		CtIpdFractionBasicBo basicBo = lt.get(0);
		int score = 0;
		if ("add".equals(itemType)) {
			String scoreStr = basicBo.getAddScore();
			if (CtFormatUtil.hasContent(scoreStr)) {
				score = Integer.parseInt(scoreStr) + dealData * 10;
			}else{
				score = dealData * 10;
			}
			basicBo.setAddScore(score + "");
		} else if ("reduce".equals(itemType)) {
			String scoreStr = basicBo.getReduceScore();
			if (CtFormatUtil.hasContent(scoreStr)) {
				score = Integer.parseInt(scoreStr) + dealData * 10;
			}else{
				score = dealData * 10;
			}
			basicBo.setReduceScore(score + "");
		}
		return basicBo;
	}

	@Override
	public Boolean saveDeductBonusPointsInfo(List<CtIpdDeductBonusPointsBo> entityList) throws Exception {
		return super.insertOrUpdateAllColumnBatch(entityList);
	}

	@Override
	public void deleteDeductBonusPointsInfo(List<String> ids) throws Exception {
		if (null != ids && ids.size() > 0) {
			List<CtIpdDeductBonusPointsBo> list = super.selectBatchIds(ids);
			int dealDt1 = 0;
			int dealdt2 = 0;
			String projectNum = "";
			String ym = "";
			String itemT = "";
			String branchId = "";
			for (int l = 0; l < list.size(); l++) {
				CtIpdDeductBonusPointsBo bo = list.get(l);
				if ("add".equals(bo.getItemType()) && CtFormatUtil.hasContent(bo.getProjectData())) {
					++dealDt1;
				} else if ("reduce".equals(bo.getItemType()) && CtFormatUtil.hasContent(bo.getProjectData())) {
					++dealdt2;
				}
				projectNum = bo.getProjectNumber();
				ym = bo.getBelongingtoYM();
				itemT = bo.getItemType();
				branchId = bo.getUniteObjectId();
			}
			if (!(dealDt1 == 0)) {
				CtIpdFractionBasicMapper ctMapper = CtBeanFactory.newCtBeanFactory()
						.getBean(CtIpdFractionBasicMapper.class);
				CtIpdFractionBasicBo basicBo = changeBo(ctMapper, projectNum, ym, branchId, itemT, -dealDt1);
				ctMapper.updateAllColumnById(basicBo);
			}
			if (!(dealdt2 == 0)) {
				CtIpdFractionBasicMapper ctMapper = CtBeanFactory.newCtBeanFactory()
						.getBean(CtIpdFractionBasicMapper.class);
				CtIpdFractionBasicBo basicBo = changeBo(ctMapper, projectNum, ym, branchId, itemT, -dealdt2);
				ctMapper.updateAllColumnById(basicBo);
			}
		}
		super.deleteBatchIds(ids);
	}

}
