package ext.plm.ipdProcessCompliance;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.ptc.projectmanagement.deliverable.PlanDeliverable;
import com.ptc.projectmanagement.plan.Plan;
import com.ptc.projectmanagement.plan.PlanActivity;
import com.ptc.projectmanagement.plan.PlanHelper;
import com.ptc.projectmanagement.plan.Plannable;
import com.ptc.projectmanagement.plannable.PlannableHelper;

import ext.plm.adminTool.configCenter.manager.CtConfigCenterManager;
import ext.plm.adminTool.configCenter.manager.CtPropertyConfig;
import ext.plm.bean.CtBeanFactory;
import ext.plm.ipdProcessCompliance.bo.CtIpdDeliverablesReviewBo;
import ext.plm.ipdProcessCompliance.bo.CtIpdFractionBasicBo;
import ext.plm.ipdProcessCompliance.mapper.CtIpdFractionBasicMapper;
import ext.plm.keyDeliverable.CtKeyDeliverableConstant;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtProjectUtil;
import ext.plm.util.IBAUtil;
import wt.fc.ObjectReference;
import wt.fc.collections.WTCollection;
import wt.projmgmt.admin.Project2;

public class IpdProcessComplianceHelper {

	static Logger logger = Logger.getLogger(IpdProcessComplianceHelper.class);

	private static java.text.DecimalFormat dfDt = new java.text.DecimalFormat("#.00");

	private static CtPropertyConfig propertyConfig = CtConfigCenterManager.getInstance().loadProperty("WfConformanceConfig");

	public static List<CtIpdDeliverablesReviewBo> getPlanDeliverData(String branchId, String projectNumer,
																	 String type, String currentDateTime) {
		List<CtIpdDeliverablesReviewBo> list = new ArrayList<CtIpdDeliverablesReviewBo>();
		int actualfinish = 0;
		int palnfinish = 0;

		Double allscore = 0d;
		try {
			// Project2 project =
			// (Project2)CtWTObjectUtil.getObjectByOid(projectId);
			Project2 project = CtProjectUtil.getProjectByNumber(projectNumer);
			ObjectReference ob = ObjectReference.newObjectReference(project);
			Plan plan = (Plan) PlanHelper.service.getPlan(ob);
			WTCollection collection = PlannableHelper.service.getAllChildren(plan);
			Iterator iterator = collection.persistableIterator();
			while (iterator.hasNext()) {
				Plannable pb = (Plannable) iterator.next();
				PlanActivity activity = (PlanActivity) pb;
				WTCollection wta = PlannableHelper.service.getDeliverables(activity);
				Iterator ite1 = wta.persistableIterator();
				while (ite1.hasNext()) {
					Object o = ite1.next();
					if (o instanceof PlanDeliverable) {
						PlanDeliverable able = (PlanDeliverable) o;
						IBAUtil ibaUtil = new IBAUtil(able);
						String docType = ibaUtil.getIBAValue("Ct_DelDocType");
						if (StringUtils.isNotEmpty(docType)) {
							String value = propertyConfig.getValue(docType);
							if (StringUtils.isNotEmpty(value) && "否".equals(value)) {
								continue;
							}
						}
						// PlanActivity activity =
						// CtActivityUtil.getPlanActivityByPlanDeliverable(able);
						CtIpdDeliverablesReviewBo bo = new CtIpdDeliverablesReviewBo(branchId + "", projectNumer, type);
						bo.setBelongActivities(activity.getName());
						String docTypeName = able.getName();
						bo.setDeliveryName(docTypeName);
						bo.setResponsibler(able.getOwnership().getOwner().getDisplayName());
						double a = able.getPercentComplete();
						if ("1".equals(type)) {
							String finishDataStr = CtDateUtil.parseDate(able.getFinishDate(), "yyyy-MM-dd");
							bo.setPlanCompleTimeReview(finishDataStr);
							// IBAUtil ibaUtil = new IBAUtil(able);
							bo.setActualCompleTimeReview(ibaUtil.getIBAValue("Ct_DelActualFinishDate"));
							if (a >= 50) {
								++actualfinish;
							}
							++palnfinish;
							list.add(bo);
						} else if ("2".equals(type) && CtKeyDeliverableConstant.jgType(docType)) {
							String finishDataStr = CtDateUtil.parseDate(able.getFinishDate(), "yyyy-MM-dd");
							bo.setPlanCompleTimeReview(finishDataStr);
							// IBAUtil ibaUtil = new IBAUtil(able);
							bo.setActualCompleTimeReview(ibaUtil.getIBAValue("Ct_DelActualFinishDate"));
							if (a >= 50) {
								++actualfinish;
							}
							++palnfinish;
							list.add(bo);
						} else if ("3".equals(type) && CtKeyDeliverableConstant.jgType(docType)) {
							if (a == 100) {
								String scoreReview = IpdProcessComplianceQuery.getNumberScore(projectNumer);
								bo.setScoreReview(scoreReview);
								allscore += Double.parseDouble(scoreReview);
								++palnfinish;
								list.add(bo);
							}
						} else if ("4".equals(type) && CtKeyDeliverableConstant.jgType(docType)) {
							String finishDataStr = CtDateUtil.parseDate(able.getFinishDate(), "yyyy-MM-dd");
							bo.setPlanCompleTimeReview(finishDataStr);
							// IBAUtil ibaUtil = new IBAUtil(able);
							String actualFinishStr = ibaUtil.getIBAValue("Ct_DelActualFinishDate");
							System.out.println("11actualFinishStr----------->" +actualFinishStr);
							if((CtFormatUtil.hasContent(actualFinishStr))){
								actualFinishStr = actualFinishStr.replace("/","-");
							}
							System.out.println("22actualFinishStr----------->" +actualFinishStr);
							bo.setActualCompleTimeReview(actualFinishStr);
							System.out.println("dealDeviation---------->" + actualFinishStr + "<----->" + finishDataStr );

							long distDt = 0;
							if(CtFormatUtil.hasContent(finishDataStr) && !CtFormatUtil.hasContent(actualFinishStr)){
								String currentDate = CtDateUtil.getCurrentDate();
								distDt = CtDateUtil.getDistDates(finishDataStr, currentDate);
								Date finishDataDt = CtDateUtil.parseStringToDate(finishDataStr,"yyyy-MM-dd");
								Date actualFinishDt = CtDateUtil.parseStringToDate(currentDate,"yyyy-MM-dd");
								if(actualFinishDt.before(finishDataDt)){
									distDt = (-distDt);
								}
							}else if(CtFormatUtil.hasContent(actualFinishStr) && CtFormatUtil.hasContent(finishDataStr)) {
								distDt = CtDateUtil.getDistDates(finishDataStr,actualFinishStr);
								Date finishDataDt = CtDateUtil.parseStringToDate(finishDataStr,"yyyy-MM-dd");
								Date actualFinishDt = CtDateUtil.parseStringToDate(actualFinishStr,"yyyy-MM-dd");
								if(actualFinishDt.before(finishDataDt)){
									distDt = (-distDt);
								}
							}
							bo.setDeviation(distDt+"");
//							String scoreReview = IpdProcessComplianceQuery.getNumberScore(projectNumer);
							String scoreReview = dealDeviation2(distDt);
							bo.setScoreReview(scoreReview);
							allscore += Double.parseDouble(scoreReview);
							++palnfinish;
							list.add(bo);

						}
					}
				}
			}
			CtIpdFractionBasicMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtIpdFractionBasicMapper.class);
			Wrapper<CtIpdFractionBasicBo> wrapper = new EntityWrapper<CtIpdFractionBasicBo>();
			wrapper.eq("uniteObjectId", branchId);
			// wrapper.eq("itemType", type);
			wrapper.eq("projectNumber", projectNumer);
			wrapper.eq("belongingtoYM", currentDateTime);
			System.out.println("branchId---------->" + branchId + "<----->" + projectNumer + "<----->" + currentDateTime + "<----->"+ type);
			List<CtIpdFractionBasicBo> lt = mapper.selectList(wrapper);
			for (int c = 0; c < lt.size(); c++) {
				CtIpdFractionBasicBo entity = lt.get(c);
				String taskCompletionsRate = "0";
				if (!(palnfinish == 0) && ("1".equals(type) || "2".equals(type))) {
					NumberFormat numberFormat = NumberFormat.getInstance();
					numberFormat.setMaximumFractionDigits(2);
					taskCompletionsRate = numberFormat.format((float) actualfinish / (float) palnfinish * 100);// 完成率
				}
				if ("1".equals(type)) {
					entity.setPlanComple(palnfinish + "");
					entity.setActualComple(actualfinish + "");
					entity.setSubmissionRate(taskCompletionsRate);
				} else if ("2".equals(type)) {
					entity.setPlanCompleTw(palnfinish + "");
					entity.setActualCompleTw(actualfinish + "");
					entity.setReviewRate(taskCompletionsRate);
				} else if ("3".equals(type)) {
					double averageScoreTh = 0;
					if (palnfinish > 0) {
						averageScoreTh = allscore / palnfinish;
						;
					}
					entity.setAverageScoreTh(String.valueOf(averageScoreTh));
				} else if ("4".equals(type)) {
					double averageScoreTh = 0;
					System.out.println("allscore4----------->" +allscore);
					System.out.println("palnfinish4----------->" +palnfinish);
					if (palnfinish > 0) {
						averageScoreTh = allscore /  palnfinish;
						System.out.println("averageScoreTh4----------->" +averageScoreTh);
					}
					entity.setAverageScoreFo(changeDf(dfDt.format(averageScoreTh)));
				}
				entity.setAllScore(getIpdPocessComplianceData(entity));
				mapper.updateAllColumnById(entity);
			}
		} catch (Exception var14) {
			var14.printStackTrace();
			logger.error("ipd获取交付物列表异常,异常信息:" + var14.getMessage());
		}
		return list;
	}

	public static String getIpdPocessComplianceData(CtIpdFractionBasicBo basicBo) {
		String submissionRate = "0";
		if (CtFormatUtil.hasContent(basicBo.getSubmissionRate())) {
			submissionRate = basicBo.getSubmissionRate();
		}
		String reviewRate = "0";
		if (CtFormatUtil.hasContent(basicBo.getReviewRate())) {
			reviewRate = basicBo.getReviewRate();
		}
		String averageScoreTh = "0";
		if (CtFormatUtil.hasContent(basicBo.getAverageScoreTh())) {
			averageScoreTh = basicBo.getAverageScoreTh();
		}
		String averageScoreFo = "0";
		if (CtFormatUtil.hasContent(basicBo.getAverageScoreFo())) {
			averageScoreFo = basicBo.getAverageScoreFo();
		}
		String reduceScore = "0";
		if (CtFormatUtil.hasContent(basicBo.getReduceScore())) {
			reduceScore = basicBo.getReduceScore();
		}
		String addScore = "0";
		if (CtFormatUtil.hasContent(basicBo.getAddScore())) {
			addScore = basicBo.getAddScore();
		}
		System.out.println(0.3 * Double.parseDouble(submissionRate) + (0.3 * Double.parseDouble(reviewRate))
				+ (0.2 * Double.parseDouble(averageScoreTh)) + (0.2 * Double.parseDouble(averageScoreFo))
				+ (0.2 * Double.parseDouble(reduceScore)) + (0.2 * Double.parseDouble(addScore)));

		Double IPDPocessCompliance = (0.3 * Double.parseDouble(submissionRate) + (0.3 * Double.parseDouble(reviewRate))
				+ (0.2 * Double.parseDouble(averageScoreTh)) + (0.2 * Double.parseDouble(averageScoreFo))
				+ (0.2 * Double.parseDouble(reduceScore)) + (0.2 * Double.parseDouble(addScore)));
		System.out.println("getIpdPocessComplianceData-------->" + IPDPocessCompliance);

		return changeDf(dfDt.format(IPDPocessCompliance));

	}
	public static String changeDf(String df) {
		if (CtFormatUtil.hasContent(df) && df.equals(".00")) {
			return "0";
		}else if (CtFormatUtil.hasContent(df) && df.equals(".0")) {
			return "0";
		} else if (CtFormatUtil.hasContent(df) && df.startsWith(".")) {
			return "0" + df;
		}
		return df;
	}
	public static String dealDeviation(String finishDataStr, String actualFinishStr) {
		try {
			double distDt = CtDateUtil.getDistDates(actualFinishStr, finishDataStr);
			if (distDt <= 0) {
				return "100";
			} else if (distDt > 0 && distDt <= 3) {
				return "90";
			} else if (distDt > 3 && distDt <= 6) {
				return "80";
			} else if (distDt > 6 && distDt <= 9) {
				return "70";
			} else if (distDt > 9 && distDt <= 12) {
				return "60";
			} else if (distDt > 12 && distDt <= 30) {
				return "50";
			} else if (distDt > 30) {
				return "0";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "";
	}
	public static String dealDeviation2(double distDt ) {
		try {
			if (distDt <= 0) {
				return "100";
			} else if (distDt > 0 && distDt <= 3) {
				return "90";
			} else if (distDt > 3 && distDt <= 6) {
				return "80";
			} else if (distDt > 6 && distDt <= 9) {
				return "70";
			} else if (distDt > 9 && distDt <= 12) {
				return "60";
			} else if (distDt > 12 && distDt <= 30) {
				return "50";
			} else if (distDt > 30) {
				return "0";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "";
	}

	public static CtIpdFractionBasicBo getCtIpdFractionBasicBo(CtIpdFractionBasicBo ibo) {
		if (null == ibo) {
			return ibo;
		}
		if (!CtFormatUtil.hasContent(ibo.getAllScore())) {
			ibo.setAllScore("0");
		}
		if (!CtFormatUtil.hasContent(ibo.getReduceScore())) {
			ibo.setReduceScore("0");
		}
		if (!CtFormatUtil.hasContent(ibo.getAddScore())) {
			ibo.setAddScore("0");
		}
		if (!CtFormatUtil.hasContent(ibo.getPlanComple())) {
			ibo.setPlanComple("0");
		}
		if (!CtFormatUtil.hasContent(ibo.getActualComple())) {
			ibo.setActualComple("0");
		}
		if (!CtFormatUtil.hasContent(ibo.getSubmissionRate())) {
			ibo.setSubmissionRate("0");
		}
		if (!CtFormatUtil.hasContent(ibo.getPlanCompleTw())) {
			ibo.setPlanCompleTw("0");
		}
		if (!CtFormatUtil.hasContent(ibo.getActualCompleTw())) {
			ibo.setActualCompleTw("0");
		}
		if (!CtFormatUtil.hasContent(ibo.getReviewRate())) {
			ibo.setReviewRate("0");
		}
		return ibo;
	}

	public static String getCurrentYM(String branchId) throws Exception{
		String ym = IpdProcessComplianceQuery.getCurrentYM(branchId);
		if(CtFormatUtil.hasContent(ym)){
			return ym;
		}
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);
		String[] timeSpt = formattedDateTime.split("-");
		if (null != timeSpt && timeSpt.length == 2) {
			IpdProcessComplianceQuery
					.addAssociatedDateInfo(formattedDateTime,branchId, timeSpt[0], timeSpt[1]);
		}else{
			IpdProcessComplianceQuery
					.addAssociatedDateInfo(formattedDateTime,branchId,"", "");
		}
		return formattedDateTime;
	}


	/**
	 * 偏差率
	 * @param a
	 * @param b
	 * @param c
	 * @param d
	 * @return
	 */
	public static String getDeviationRate(Date a,Date b,Date c,Date d ){
		try{
			if(null == a || null == b || null == c || null == d){
				return "-";
			}
			double fl = (double)CtDateUtil.getDistDates(b, a);
			System.out.println("f1----" + fl);
			double dl = (double)CtDateUtil.getDistDates(d, c);
			System.out.println("dl----" + dl);
			if(fl == 0){
				return "0";
			}
			Double df = (dl*100/fl);
			System.out.println("df----" + df);
			return changeDf(dfDt.format(df));
//			return String.valueOf(df);
		}catch(Exception e){
			e.printStackTrace();
		}
		return "";
	}
	/**
	 * 计算执行状态
	 * @param dt   计划时间
	 * @param dt2     实际时间
	 * @return
	 */
	public static String getExecuteStatus(Date dt, Date dt2, String ym, boolean jg) {
		try {
			// 无统计目标 /跨月逾期未完成 /当月逾期未完成 /跨月逾期完成 /当月逾期完成 /
			// 当月提前完成 / 跨月提前完成
			String toDateStr = CtDateUtil.newDateString("yyyy-MM-dd", "GMT+8");
			Date toDateDT = CtDateUtil.parseStringToDate(toDateStr, "yyyy-MM-dd");
			String dtStr = CtDateUtil.parseDate(dt, "yyyy-MM", "GMT+8");
			String dt2Str = "";
			if(null != dt2){
				dt2Str = CtDateUtil.parseDate(dt2, "yyyy-MM", "GMT+8");
			}
			if (jg) {
				return "无统计目标1";
			} else {
				// long fl = CtDateUtil.getDistDates(dt2, dt);
				if (null == dt2 || !CtFormatUtil.hasContent(dt2)) {
					if (dt.after(toDateDT)) {
						return "无统计目标2";
					} else if (toDateStr.contains(dtStr)) {
						return "当月逾期未完成";
					} else {
						return "跨月逾期未完成";
					}
				} else if (dt2.before(dt)) {
					// 提前
					if (dtStr.equals(dt2Str)) {
						return "当月提前完成 ";
					} else {
						return "跨月提前完成";
					}
				} else if (dt2.after(dt)) {
					// 逾期
					if (dtStr.equals(dt2Str)) {
						if (dt2.after(toDateDT)) {
							return "当月逾期未完成";
						} else {
							return "当月逾期完成";
						}
					} else {
						if (dt2.after(toDateDT)) {
							return "跨月逾期未完成";
						} else {
							return "跨月逾期完成";
						}
					}
				} else {
					return "无统计目标3";
				}
				/*
				 * LocalDateTime now = LocalDateTime.now(); DateTimeFormatter
				 * formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); String
				 * formattedDateTime = now.format(formatter);
				 */
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
}
