package ext.plm.ipdProcessCompliance.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import ext.plm.ipdProcessCompliance.bo.CtProjectScheduleDeviationRateBo;

@Mapper
public interface CtProjectScheduleDeviationRateMapper extends BaseMapper<CtProjectScheduleDeviationRateBo> {
}
