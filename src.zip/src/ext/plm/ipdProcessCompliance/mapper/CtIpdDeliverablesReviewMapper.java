package ext.plm.ipdProcessCompliance.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import ext.plm.ipdProcessCompliance.bo.CtIpdDeliverablesReviewBo;

@Mapper
public interface CtIpdDeliverablesReviewMapper extends BaseMapper<CtIpdDeliverablesReviewBo> {

}
