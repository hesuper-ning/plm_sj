package ext.plm.ipdProcessCompliance.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import ext.plm.ipdProcessCompliance.bo.CtIpdFractionBasicBo;

@Mapper
public interface CtIpdFractionBasicMapper extends BaseMapper<CtIpdFractionBasicBo> {

}
