package ext.plm.ipdProcessCompliance.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import ext.plm.ipdProcessCompliance.bo.CtIpdDeductBonusPointsBo;

@Mapper
public interface CtIpdDeductBonusPointsMapper extends BaseMapper<CtIpdDeductBonusPointsBo> {

}
