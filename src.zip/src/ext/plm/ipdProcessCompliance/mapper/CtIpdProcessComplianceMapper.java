package ext.plm.ipdProcessCompliance.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import ext.plm.ipdProcessCompliance.bo.CtIpdProcessComplianceBo;

@Mapper
public interface CtIpdProcessComplianceMapper extends BaseMapper<CtIpdProcessComplianceBo> {
}
