package ext.plm.ipdProcessCompliance.bo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import ext.plm.keyDeliverable.bo.CtReportCommonBo;
import ext.plm.tool.poi.ref.ExcelColumn;
import ext.plm.util.CtFormatUtil;
import wt.org.WTUser;
import wt.session.SessionHelper;
@TableName("ZCtProjectScheduleDRateTable")
public class CtProjectScheduleDeviationRateBo extends CtReportCommonBo {

	private static final long serialVersionUID = -7134220276697494939L;
	@ExcelColumn(index = 3)
	@TableField("PROJECTNUMBER")
	private String projectNumber;// 项目编号
	@ExcelColumn(index = 4)
	@TableField("PROJECTNAME")
	private String projectName;// 项目名称
	@ExcelColumn(index = 2)
	@TableField("PRODUCTLINE")
	private String productLine;// 产品线
	@ExcelColumn(index = 8)
	@TableField("RELATEDMILE")
	private String relatedMile;// 相关里程碑
	@ExcelColumn(index = 9)
	@TableField("executeStatus")
	private String executeStatus;// 相关里程碑执行状况
	@ExcelColumn(index = 10)
	@TableField("PDCPPLANNEDTIME")
	private String pdcpPlannedTime;// PDCP计划时间
	@ExcelColumn(index = 11)
	@TableField("MILESTONENAMEEND")
	private String mileStoneNameEnd;// 当月完成里程碑 里程碑名称
	@ExcelColumn(index = 12)
	@TableField("PLANCOMPLETETIMEEND")
	private String planCompleteTimeEnd;// 当月完成里程碑 计划完成时间
	@ExcelColumn(index = 13)
	@TableField("ACTUALCOMPLETETIMEEND")
	private String actualCompleteTimeEnd;// 当月完成里程碑 实际完成时间
	@ExcelColumn(index = 14)
	@TableField("MILESTONENAMEING")
	private String mileStoneNameIng;// 当月进行中里程碑 里程碑名称
	@ExcelColumn(index = 15)
	@TableField("PLANCOMPLETETIMEING")
	private String planCompleteTimeIng;// 当月进行中里程碑 计划完成时间
	@ExcelColumn(index = 16)
	@TableField("DEVIATIONRATE")
	private String deviationRate;// 偏差率

	/*
	 * @TableField("MILEPOST") private String milepost;// 当前里程碑
	 * 
	 * @TableField("PLANCOMPLETETIME") private String planCompleteTime;// 计划完成时间
	 * 
	 * @TableField("ACTUALCOMPLETETIME") private String actualCompleteTime;//
	 * 实际完成时间
	 * 
	 * @TableField("PROGRESSDEVIATION") private String progressDeviation;// 进度偏差
	 */

	@TableField("PROJECTTYPE")
	private String projectType;
	@TableField("BELONGINGTOYEAR")
	private String belongingtoYear;
	@ExcelColumn(index = 1)
	@TableField("BELONGINGTOMOUTH")
	private String belongingtoMouth;
	@TableField("BELONGINGTOYM")
	private String belongingtoYM;

    // 子项 ext树规定的属性
	@TableField(exist = false)
	private List<CtProjectScheduleDeviationRateBo> children = new ArrayList<CtProjectScheduleDeviationRateBo>();
	// 是否展开 ext树规定的属性
	@TableField(exist = false)
	private boolean expanded;
	// 是否是叶子节点 ext树规定的属性
	@TableField(exist = false)
	private boolean leaf;
	// 节点图标样式 ext树规定的属性
	@TableField(exist = false)
	private String iconCls;
	@ExcelColumn(index = 0)
	@TableField(exist = false)
	private String ymShow;// 年月显示
	@ExcelColumn(index = 5)
	@TableField(exist = false)
	private String costAmount;// 已投入资金
	@ExcelColumn(index = 6)
	@TableField(exist = false)
	private String costweight;// 已投入资金权重
	@ExcelColumn(index = 7)
	@TableField(exist = false)
	private String weightDeviationRate;// 加权偏差率
	public String getProjectNumber() {
		return projectNumber;
	}

	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getRelatedMile() {
		return relatedMile;
	}

	public void setRelatedMile(String relatedMile) {
		this.relatedMile = relatedMile;
	}

	public String getExecuteStatus() {
		return executeStatus;
	}

	public void setExecuteStatus(String executeStatus) {
		this.executeStatus = executeStatus;
	}

	public String getPdcpPlannedTime() {
		return pdcpPlannedTime;
	}

	public void setPdcpPlannedTime(String pdcpPlannedTime) {
		this.pdcpPlannedTime = pdcpPlannedTime;
	}

	public String getMileStoneNameEnd() {
		return mileStoneNameEnd;
	}

	public void setMileStoneNameEnd(String mileStoneNameEnd) {
		this.mileStoneNameEnd = mileStoneNameEnd;
	}

	public String getPlanCompleteTimeEnd() {
		return planCompleteTimeEnd;
	}

	public void setPlanCompleteTimeEnd(String planCompleteTimeEnd) {
		this.planCompleteTimeEnd = planCompleteTimeEnd;
	}

	public String getActualCompleteTimeEnd() {
		return actualCompleteTimeEnd;
	}

	public void setActualCompleteTimeEnd(String actualCompleteTimeEnd) {
		this.actualCompleteTimeEnd = actualCompleteTimeEnd;
	}

	public String getMileStoneNameIng() {
		return mileStoneNameIng;
	}

	public void setMileStoneNameIng(String mileStoneNameIng) {
		this.mileStoneNameIng = mileStoneNameIng;
	}

	public String getPlanCompleteTimeIng() {
		return planCompleteTimeIng;
	}

	public void setPlanCompleteTimeIng(String planCompleteTimeIng) {
		this.planCompleteTimeIng = planCompleteTimeIng;
	}

	public String getDeviationRate() {
		return deviationRate;
	}

	public void setDeviationRate(String deviationRate) {
		this.deviationRate = deviationRate;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getBelongingtoYear() {
		return belongingtoYear;
	}

	public void setBelongingtoYear(String belongingtoYear) {
		this.belongingtoYear = belongingtoYear;
	}

	public String getBelongingtoMouth() {
		return belongingtoMouth;
	}

	public void setBelongingtoMouth(String belongingtoMouth) {
		this.belongingtoMouth = belongingtoMouth;
	}

	public String getBelongingtoYM() {
		return belongingtoYM;
	}

	public void setBelongingtoYM(String belongingtoYM) {
		this.belongingtoYM = belongingtoYM;
	}
	
	public List<CtProjectScheduleDeviationRateBo> getChildren() {
		return children;
	}

	public void setChildren(List<CtProjectScheduleDeviationRateBo> children) {
		this.children = children;
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

	public boolean isLeaf() {
		return leaf;
	}

	public void setLeaf(boolean leaf) {
		this.leaf = leaf;
	}

	public String getIconCls() {
		return iconCls;
	}

	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	public String getYmShow() {
		return ymShow;
	}

	public void setYmShow(String ymShow) {
		this.ymShow = ymShow;
	}

	public String getCostAmount() {
		return costAmount;
	}

	public void setCostAmount(String costAmount) {
		this.costAmount = costAmount;
	}

	public String getCostweight() {
		return costweight;
	}

	public void setCostweight(String costweight) {
		this.costweight = costweight;
	}

	public String getWeightDeviationRate() {
		return weightDeviationRate;
	}

	public void setWeightDeviationRate(String weightDeviationRate) {
		this.weightDeviationRate = weightDeviationRate;
	}

	public CtProjectScheduleDeviationRateBo() {
	}

	public CtProjectScheduleDeviationRateBo(String uniteObjectId, String currentYM) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		String[] timeSpt = null;
		if (CtFormatUtil.hasContent(currentYM)) {
			timeSpt = currentYM.split("-");
			this.setBelongingtoYM(currentYM);
		} else {
			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
			String formattedDateTime = now.format(formatter);
			this.setBelongingtoYM(formattedDateTime);
			timeSpt = formattedDateTime.split("-");
		}
		if (null != timeSpt && timeSpt.length == 2) {
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);

		}
	}

	public CtProjectScheduleDeviationRateBo(String uniteObjectId, String id, String currentYM) throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		String[] timeSpt = null;
		if (CtFormatUtil.hasContent(currentYM)) {
			timeSpt = currentYM.split("-");
			this.setBelongingtoYM(currentYM);
		} else {
			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
			String formattedDateTime = now.format(formatter);
			this.setBelongingtoYM(formattedDateTime);
			timeSpt = formattedDateTime.split("-");
		}
		if (null != timeSpt && timeSpt.length == 2) {
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);

		}
	}
}
