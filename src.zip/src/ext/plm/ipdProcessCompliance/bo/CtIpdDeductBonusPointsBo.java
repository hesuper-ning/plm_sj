package ext.plm.ipdProcessCompliance.bo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import ext.plm.keyDeliverable.bo.CtReportCommonBo;
import ext.plm.util.CtFormatUtil;
import wt.org.WTUser;
import wt.session.SessionHelper;

@TableName("ZIpdDeductBonusPointsTable")
public class CtIpdDeductBonusPointsBo extends CtReportCommonBo {

	private static final long serialVersionUID = 1L;
	
	@TableField("PROJECTDATA")
	private String projectData;// 扣分项目
	
	@TableField("EVENTDESCRIPTION")
	private String eventDescription;// 事件描述
	
	@TableField("REFERATTACHMENT")
	private String referAttachment;// 参考附件
	
	@TableField("RELATEDLINKS")
	private String relatedLinks;// 相关链接
	
	@TableField("ITEMTYPE")
	private String itemType;// 类型	

	@TableField("PROJECTNUMBER")
	private String projectNumber;// 项目编码
	
	@TableField("BELONGINGTOYEAR")
	private String belongingtoYear;
	@TableField("BELONGINGTOMOUTH")
	private String belongingtoMouth;
	@TableField("BELONGINGTOYM")
	private String belongingtoYM;
	
	public String getProjectData() {
		return projectData;
	}

	public void setProjectData(String projectData) {
		this.projectData = projectData;
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public String getReferAttachment() {
		return referAttachment;
	}

	public void setReferAttachment(String referAttachment) {
		this.referAttachment = referAttachment;
	}

	public String getRelatedLinks() {
		return relatedLinks;
	}

	public void setRelatedLinks(String relatedLinks) {
		this.relatedLinks = relatedLinks;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	
	public String getProjectNumber() {
		return projectNumber;
	}

	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}

	public String getBelongingtoYear() {
		return belongingtoYear;
	}

	public void setBelongingtoYear(String belongingtoYear) {
		this.belongingtoYear = belongingtoYear;
	}

	public String getBelongingtoMouth() {
		return belongingtoMouth;
	}

	public void setBelongingtoMouth(String belongingtoMouth) {
		this.belongingtoMouth = belongingtoMouth;
	}

	public String getBelongingtoYM() {
		return belongingtoYM;
	}

	public void setBelongingtoYM(String belongingtoYM) {
		this.belongingtoYM = belongingtoYM;
	}

	public CtIpdDeductBonusPointsBo() {
	}
	public CtIpdDeductBonusPointsBo(String uniteObjectId, String type,String projectNumber,String currentYM) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		this.setItemType(type);
		this.setProjectNumber(projectNumber);
		String[] timeSpt = null;
		if(CtFormatUtil.hasContent(currentYM)){
			timeSpt = currentYM.split("-");
			this.setBelongingtoYM(currentYM);
		}else{
			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
			String formattedDateTime = now.format(formatter);
			timeSpt = formattedDateTime.split("-");
			this.setBelongingtoYM(formattedDateTime);
		}
		if(null != timeSpt && timeSpt.length == 2){
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);
		}
	}

	public CtIpdDeductBonusPointsBo(String uniteObjectId, String id, String type,String projectNumber,String currentYM) throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		this.setItemType(type);
		this.setProjectNumber(projectNumber);
		String[] timeSpt = null;
		if(CtFormatUtil.hasContent(currentYM)){
			timeSpt = currentYM.split("-");
			this.setBelongingtoYM(currentYM);
		}else{
			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
			String formattedDateTime = now.format(formatter);
			timeSpt = formattedDateTime.split("-");
			this.setBelongingtoYM(formattedDateTime);
		}
		if(null != timeSpt && timeSpt.length == 2){
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);
		}
	}
}
