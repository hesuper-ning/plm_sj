package ext.plm.ipdProcessCompliance.bo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import ext.plm.keyDeliverable.bo.CtReportCommonBo;
import ext.plm.tool.poi.ref.ExcelColumn;
import ext.plm.util.CtFormatUtil;
import wt.org.WTUser;
import wt.session.SessionHelper;

@TableName("ZIpdProcessComplianceTable")
public class CtIpdProcessComplianceBo extends CtReportCommonBo {

	private static final long serialVersionUID = 6876522688200672139L;
	@ExcelColumn(index = 3)
	@TableField("PROJECTNUMBER")
	private String projectNumber;// 项目编号
	@ExcelColumn(index = 4)
	@TableField("PROJECTNAME")
	private String projectName;// 项目名称
	@TableField("SPECIALPROCESSPROJECTS")
	private String specialProcessProjects;// 是否为特殊流程项目
	@ExcelColumn(index = 2)
	@TableField("PRODUCTLINE")
	private String productLine;// 产品线
	@TableField("PQA")
	private String pqa;// PQA
	@TableField("IPDPOCESSCOMPLIANCE")
	private String iPDPocessCompliance;// IPD流程符合度
	@TableField("FILESCORERATE")
	private String fileScoreRate;// 文件提交率得分
	@TableField("KEYDELIVERABLERATESCORE")
	private String keyDeliverableRateScore;// 关键交付件评审率得分
	@TableField("KEYDEEFFECTIVENESSEVALUATION")
	private String keyDeEffectivenessEvaluation;// 关键交付物评审有效性评价
	@TableField("KEYDETIMELINESSSCORE")
	private String keyDeTimelinessScore;// 关键交付件交付及时性得分
	@TableField("DEDUCTPOINTS")
	private String deductPoints;// 不符合项扣分
	@TableField("BONUSPOINTS")
	private String bonusPoints;// 加分项
	@TableField("PROJECTTYPE")
	private String projectType;
	@TableField("BELONGINGTOYEAR")
	private String belongingtoYear;
	@ExcelColumn(index = 1)
	@TableField("BELONGINGTOMOUTH")
	private String belongingtoMouth;
	@TableField("BELONGINGTOYM")
	private String belongingtoYM;

	// 子项 ext树规定的属性
	@TableField(exist = false)
	private List<CtIpdProcessComplianceBo> children = new ArrayList<CtIpdProcessComplianceBo>();
	// 是否展开 ext树规定的属性
	@TableField(exist = false)
	private boolean expanded;
	// 是否是叶子节点 ext树规定的属性
	@TableField(exist = false)
	private boolean leaf;
	// 节点图标样式 ext树规定的属性
	@TableField(exist = false)
	private String iconCls;
	@ExcelColumn(index = 0)
	@TableField(exist = false)
	private String ymShow;// 年月显示
	@ExcelColumn(index = 5)
	@TableField(exist = false)
	private String allIPDPocessCompliance;// IPD流程符合度
	@ExcelColumn(index = 6)
	@TableField(exist = false)
	private String avelFileScoreRate;// 文件提交率得分
	@ExcelColumn(index = 7)
	@TableField(exist = false)
	private String avelKeyDeliverableRateScore;// 关键交付件评审率得分
	@ExcelColumn(index = 8)
	@TableField(exist = false)
	private String avelKeyDeEffectivenessEvaluation;// 关键交付物评审有效性评价
	@ExcelColumn(index = 9)
	@TableField(exist = false)
	private String avelKeyDeTimelinessScore;// 关键交付件交付及时性得分
	@ExcelColumn(index = 10)
	@TableField(exist = false)
	private String totalDeductPoints;// 不符合项扣分
	@ExcelColumn(index = 11)
	@TableField(exist = false)
	private String totalBonusPoints;// 加分项

	public String getBelongingtoYM() {
		return belongingtoYM;
	}

	public void setBelongingtoYM(String belongingtoYM) {
		this.belongingtoYM = belongingtoYM;
	}

	public String getProjectNumber() {
		return projectNumber;
	}

	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getSpecialProcessProjects() {
		return specialProcessProjects;
	}

	public void setSpecialProcessProjects(String specialProcessProjects) {
		this.specialProcessProjects = specialProcessProjects;
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getPqa() {
		return pqa;
	}

	public void setPqa(String pqa) {
		this.pqa = pqa;
	}

	public String getiPDPocessCompliance() {
		return iPDPocessCompliance;
	}

	public void setiPDPocessCompliance(String iPDPocessCompliance) {
		this.iPDPocessCompliance = iPDPocessCompliance;
	}

	public String getFileScoreRate() {
		return fileScoreRate;
	}

	public void setFileScoreRate(String fileScoreRate) {
		this.fileScoreRate = fileScoreRate;
	}

	public String getKeyDeliverableRateScore() {
		return keyDeliverableRateScore;
	}

	public void setKeyDeliverableRateScore(String keyDeliverableRateScore) {
		this.keyDeliverableRateScore = keyDeliverableRateScore;
	}

	public String getKeyDeEffectivenessEvaluation() {
		return keyDeEffectivenessEvaluation;
	}

	public void setKeyDeEffectivenessEvaluation(String keyDeEffectivenessEvaluation) {
		this.keyDeEffectivenessEvaluation = keyDeEffectivenessEvaluation;
	}

	public String getKeyDeTimelinessScore() {
		return keyDeTimelinessScore;
	}

	public void setKeyDeTimelinessScore(String keyDeTimelinessScore) {
		this.keyDeTimelinessScore = keyDeTimelinessScore;
	}

	public String getDeductPoints() {
		return deductPoints;
	}

	public void setDeductPoints(String deductPoints) {
		this.deductPoints = deductPoints;
	}

	public String getBonusPoints() {
		return bonusPoints;
	}

	public void setBonusPoints(String bonusPoints) {
		this.bonusPoints = bonusPoints;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getBelongingtoYear() {
		return belongingtoYear;
	}

	public void setBelongingtoYear(String belongingtoYear) {
		this.belongingtoYear = belongingtoYear;
	}

	public String getBelongingtoMouth() {
		return belongingtoMouth;
	}

	public void setBelongingtoMouth(String belongingtoMouth) {
		this.belongingtoMouth = belongingtoMouth;
	}

	public String getYmShow() {
		return ymShow;
	}

	public void setYmShow(String ymShow) {
		this.ymShow = ymShow;
	}

	public List<CtIpdProcessComplianceBo> getChildren() {
		return children;
	}

	public void setChildren(List<CtIpdProcessComplianceBo> children) {
		this.children = children;
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

	public boolean isLeaf() {
		return leaf;
	}

	public void setLeaf(boolean leaf) {
		this.leaf = leaf;
	}

	public String getIconCls() {
		return iconCls;
	}

	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	public String getAllIPDPocessCompliance() {
		return allIPDPocessCompliance;
	}

	public void setAllIPDPocessCompliance(String allIPDPocessCompliance) {
		this.allIPDPocessCompliance = allIPDPocessCompliance;
	}

	public String getAvelFileScoreRate() {
		return avelFileScoreRate;
	}

	public void setAvelFileScoreRate(String avelFileScoreRate) {
		this.avelFileScoreRate = avelFileScoreRate;
	}

	public String getAvelKeyDeliverableRateScore() {
		return avelKeyDeliverableRateScore;
	}

	public void setAvelKeyDeliverableRateScore(String avelKeyDeliverableRateScore) {
		this.avelKeyDeliverableRateScore = avelKeyDeliverableRateScore;
	}

	public String getAvelKeyDeEffectivenessEvaluation() {
		return avelKeyDeEffectivenessEvaluation;
	}

	public void setAvelKeyDeEffectivenessEvaluation(String avelKeyDeEffectivenessEvaluation) {
		this.avelKeyDeEffectivenessEvaluation = avelKeyDeEffectivenessEvaluation;
	}

	public String getAvelKeyDeTimelinessScore() {
		return avelKeyDeTimelinessScore;
	}

	public void setAvelKeyDeTimelinessScore(String avelKeyDeTimelinessScore) {
		this.avelKeyDeTimelinessScore = avelKeyDeTimelinessScore;
	}

	public String getTotalDeductPoints() {
		return totalDeductPoints;
	}

	public void setTotalDeductPoints(String totalDeductPoints) {
		this.totalDeductPoints = totalDeductPoints;
	}

	public String getTotalBonusPoints() {
		return totalBonusPoints;
	}

	public void setTotalBonusPoints(String totalBonusPoints) {
		this.totalBonusPoints = totalBonusPoints;
	}

	public CtIpdProcessComplianceBo() throws Exception {

	}

	public CtIpdProcessComplianceBo(String uniteObjectId, String currentYM) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		String[] timeSpt = null;
		if (CtFormatUtil.hasContent(currentYM)) {
			timeSpt = currentYM.split("-");
			this.setBelongingtoYM(currentYM);
		} else {
			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
			String formattedDateTime = now.format(formatter);
			this.setBelongingtoYM(formattedDateTime);
			timeSpt = formattedDateTime.split("-");
		}
		if (null != timeSpt && timeSpt.length == 2) {
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);

		}
	}

	public CtIpdProcessComplianceBo(String uniteObjectId, String id, String currentMonth, String currentYM)
			throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		String[] timeSpt = null;
		if (CtFormatUtil.hasContent(currentYM)) {
			timeSpt = currentYM.split("-");
			this.setBelongingtoYM(currentYM);
		} else {
			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
			String formattedDateTime = now.format(formatter);
			this.setBelongingtoYM(formattedDateTime);
			timeSpt = formattedDateTime.split("-");
		}
		if (null != timeSpt && timeSpt.length == 2) {
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);

		}
	}
}
