package ext.plm.ipdProcessCompliance.bo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import ext.plm.keyDeliverable.bo.CtReportCommonBo;
import wt.org.WTUser;
import wt.session.SessionHelper;

@TableName("ZIpdFractionBasicTable")
public class CtIpdFractionBasicBo extends CtReportCommonBo {
	private static final long serialVersionUID = 1L;
	@TableField("PROJECTNUMBER")
	private String projectNumber1;// 项目编号
	@TableField("PROJECTNAME")
	private String projectName1;// 项目名称
	@TableField("PRODUCTLINE")
	private String productLine1;// 产品线
	@TableField("ALLSCORE")
	private String allScore;// 得分
	@TableField("REDUCESCORE")
	private String reduceScore;// 得分
	@TableField("ADDSCORE")
	private String addScore;// 得分

	@TableField("PLANCOMPLE")
	private String planComple;// 计划完成
	@TableField("ACTUALCOMPLE")
	private String actualComple;// 实际完成
	@TableField("SUBMISSIONRATE")
	private String submissionRate;// 提交率

	@TableField("PLANCOMPLETW")
	private String planCompleTw;// 计划完成
	@TableField("ACTUALCOMPLETW")
	private String actualCompleTw;// 实际完成
	@TableField("REVIEWRATE")
	private String reviewRate;// 评审率

	@TableField("AVERAGESCORETH")
	private String averageScoreTh;// 平均得分
	@TableField("AVERAGESCOREFO")
	private String averageScoreFo;// 平均得分

	@TableField("BELONGINGTOYEAR")
	private String belongingtoYear;
	@TableField("BELONGINGTOMOUTH")
	private String belongingtoMouth;
	@TableField("BELONGINGTOYM")
	private String belongingtoYM;

	public String getProjectNumber1() {
		return projectNumber1;
	}

	public void setProjectNumber1(String projectNumber1) {
		this.projectNumber1 = projectNumber1;
	}

	public String getProjectName1() {
		return projectName1;
	}

	public void setProjectName1(String projectName1) {
		this.projectName1 = projectName1;
	}

	public String getProductLine1() {
		return productLine1;
	}

	public void setProductLine1(String productLine1) {
		this.productLine1 = productLine1;
	}

	public String getAllScore() {
		return allScore;
	}

	public void setAllScore(String allScore) {
		this.allScore = allScore;
	}

	public String getReduceScore() {
		return reduceScore;
	}

	public void setReduceScore(String reduceScore) {
		this.reduceScore = reduceScore;
	}

	public String getAddScore() {
		return addScore;
	}

	public void setAddScore(String addScore) {
		this.addScore = addScore;
	}

	public String getPlanComple() {
		return planComple;
	}

	public void setPlanComple(String planComple) {
		this.planComple = planComple;
	}

	public String getActualComple() {
		return actualComple;
	}

	public void setActualComple(String actualComple) {
		this.actualComple = actualComple;
	}

	public String getSubmissionRate() {
		return submissionRate;
	}

	public void setSubmissionRate(String submissionRate) {
		this.submissionRate = submissionRate;
	}

	public String getPlanCompleTw() {
		return planCompleTw;
	}

	public void setPlanCompleTw(String planCompleTw) {
		this.planCompleTw = planCompleTw;
	}

	public String getActualCompleTw() {
		return actualCompleTw;
	}

	public void setActualCompleTw(String actualCompleTw) {
		this.actualCompleTw = actualCompleTw;
	}

	public String getReviewRate() {
		return reviewRate;
	}

	public void setReviewRate(String reviewRate) {
		this.reviewRate = reviewRate;
	}

	public String getAverageScoreTh() {
		return averageScoreTh;
	}

	public void setAverageScoreTh(String averageScoreTh) {
		this.averageScoreTh = averageScoreTh;
	}

	public String getAverageScoreFo() {
		return averageScoreFo;
	}

	public void setAverageScoreFo(String averageScoreFo) {
		this.averageScoreFo = averageScoreFo;
	}

	public String getBelongingtoYear() {
		return belongingtoYear;
	}

	public void setBelongingtoYear(String belongingtoYear) {
		this.belongingtoYear = belongingtoYear;
	}

	public String getBelongingtoMouth() {
		return belongingtoMouth;
	}

	public void setBelongingtoMouth(String belongingtoMouth) {
		this.belongingtoMouth = belongingtoMouth;
	}

	public String getBelongingtoYM() {
		return belongingtoYM;
	}

	public void setBelongingtoYM(String belongingtoYM) {
		this.belongingtoYM = belongingtoYM;
	}

	public CtIpdFractionBasicBo() {
	}

	public CtIpdFractionBasicBo(String uniteObjectId, String projectNumber) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		this.setProjectNumber1(projectNumber);
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);
		String[] timeSpt = formattedDateTime.split("-");
		if (null != timeSpt && timeSpt.length == 2) {
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);
			this.setBelongingtoYM(formattedDateTime);
		}
	}

	public CtIpdFractionBasicBo(String uniteObjectId, String id, String projectNumber) throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		this.setProjectNumber1(projectNumber);
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);
		String[] timeSpt = formattedDateTime.split("-");
		if (null != timeSpt && timeSpt.length == 2) {
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);
			this.setBelongingtoYM(formattedDateTime);
		}
	}
}
