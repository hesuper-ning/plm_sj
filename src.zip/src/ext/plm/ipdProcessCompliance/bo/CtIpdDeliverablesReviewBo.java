package ext.plm.ipdProcessCompliance.bo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import ext.plm.keyDeliverable.bo.CtReportCommonBo;
import wt.org.WTUser;
import wt.session.SessionHelper;

@TableName("ZIpdDeliverablesReviewTable")
public class CtIpdDeliverablesReviewBo extends CtReportCommonBo {
	private static final long serialVersionUID = 1L;
	@TableField("PROJECTNUMBERREVIEW")
	private String projectNumberReview;// 项目编号

	@TableField("belongActivities")
	private String belongActivities;// 所属活动
	@TableField("DELIVERYNAME")
	private String deliveryName;// 可交付结果名称
	@TableField("RESPONSIBLER")
	private String responsibler;// 负责人

	@TableField("PLANCOMPLETIMEREVIEW")
	private String planCompleTimeReview;// 目标时间（计划完成时间）
	@TableField("ACTUALCOMPLETIMEREVIEW")
	private String actualCompleTimeReview;// 实际时间（实际完成时间）
	@TableField("DEVIATION")
	private String deviation;// 偏差
	@TableField("SCOREREVIEW")
	private String scoreReview;// 得分
	@TableField("LTYPE")
	private String lType;
	@TableField("BELONGINGTOYEAR")
	private String belongingtoYear;
	@TableField("BELONGINGTOMOUTH")
	private String belongingtoMouth;
	@TableField("BELONGINGTOYM")
	private String belongingtoYM;


	public String getProjectNumberReview() {
		return projectNumberReview;
	}

	public void setProjectNumberReview(String projectNumberReview) {
		this.projectNumberReview = projectNumberReview;
	}

	public String getBelongActivities() {
		return belongActivities;
	}

	public void setBelongActivities(String belongActivities) {
		this.belongActivities = belongActivities;
	}

	public String getDeliveryName() {
		return deliveryName;
	}

	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}

	public String getResponsibler() {
		return responsibler;
	}

	public void setResponsibler(String responsibler) {
		this.responsibler = responsibler;
	}

	public String getPlanCompleTimeReview() {
		return planCompleTimeReview;
	}

	public void setPlanCompleTimeReview(String planCompleTimeReview) {
		this.planCompleTimeReview = planCompleTimeReview;
	}

	public String getActualCompleTimeReview() {
		return actualCompleTimeReview;
	}

	public void setActualCompleTimeReview(String actualCompleTimeReview) {
		this.actualCompleTimeReview = actualCompleTimeReview;
	}

	public String getDeviation() {
		return deviation;
	}

	public void setDeviation(String deviation) {
		this.deviation = deviation;
	}

	public String getScoreReview() {
		return scoreReview;
	}

	public void setScoreReview(String scoreReview) {
		this.scoreReview = scoreReview;
	}

	public String getlType() {
		return lType;
	}

	public void setlType(String lType) {
		this.lType = lType;
	}

	public String getBelongingtoYear() {
		return belongingtoYear;
	}

	public void setBelongingtoYear(String belongingtoYear) {
		this.belongingtoYear = belongingtoYear;
	}

	public String getBelongingtoMouth() {
		return belongingtoMouth;
	}

	public void setBelongingtoMouth(String belongingtoMouth) {
		this.belongingtoMouth = belongingtoMouth;
	}

	public String getBelongingtoYM() {
		return belongingtoYM;
	}

	public void setBelongingtoYM(String belongingtoYM) {
		this.belongingtoYM = belongingtoYM;
	}
	public CtIpdDeliverablesReviewBo(){
		
	}
	public CtIpdDeliverablesReviewBo(String uniteObjectId, String projectNumber,String type) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		this.setProjectNumberReview(projectNumber);
		this.setlType(type);
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);
		String[] timeSpt = formattedDateTime.split("-");
		if (null != timeSpt && timeSpt.length == 2) {
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);
			this.setBelongingtoYM(formattedDateTime);
		}
	}

	public CtIpdDeliverablesReviewBo(String uniteObjectId, String id, String projectNumber,String type) throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		this.setProjectNumberReview(projectNumber);
		this.setlType(type);
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
		String formattedDateTime = now.format(formatter);
		String[] timeSpt = formattedDateTime.split("-");
		if (null != timeSpt && timeSpt.length == 2) {
			this.setBelongingtoYear(timeSpt[0]);
			this.setBelongingtoMouth(timeSpt[1]);
			this.setBelongingtoYM(formattedDateTime);
		}
	}
}
