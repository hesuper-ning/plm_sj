package ext.plm.ipdProcessCompliance;

import java.util.List;

import org.apache.log4j.Logger;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;

import ext.plm.bean.CtBeanFactory;
import ext.plm.ipdProcessCompliance.bo.CtIpdDeliverablesReviewBo;
import ext.plm.ipdProcessCompliance.bo.CtIpdProcessComplianceBo;
import ext.plm.ipdProcessCompliance.bo.CtProjectScheduleDeviationRateBo;
import ext.plm.ipdProcessCompliance.mapper.CtIpdDeliverablesReviewMapper;
import ext.plm.ipdProcessCompliance.mapper.CtIpdProcessComplianceMapper;
import ext.plm.ipdProcessCompliance.mapper.CtProjectScheduleDeviationRateMapper;
import ext.plm.ipdProcessCompliance.service.IpdFractionBasicService;
import ext.plm.keyDeliverable.config.CtKeyDeliverableProperties;
import ext.plm.util.CtFormatUtil;
import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.WTObject;
import wt.util.WTException;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;
public class IpdProcessComplianceWfplugin {

	static Logger logger = Logger.getLogger(IpdProcessComplianceWfplugin.class); // LogDemo为相关的类

	// private static IpdFractionBasicService ctIpdFractionBasicService =
	// ServiceFactory.getService(IpdFractionBasicService.class);

	public static void checkForm(WTObject pbo, Object self) throws WTException {
		/*
		 * //必填验证 ext.plm.keyDeliverable.CtKeyDeliverableWfplugin.checkForm(
		 * primaryBusinessObject,self);
		 */
		try {
			WTDocument document = (WTDocument) pbo;
			String branchId = document.getBranchIdentifier() + "";
			String emptyAtts = "";
			String ym = IpdProcessComplianceQuery.getCurrentYM(branchId);
			if (CtFormatUtil.hasContent(ym)) {
				emptyAtts += "本月已提交流程，不允许重复提交流程" + "\r\n";
			}

			if (CtFormatUtil.hasContent(emptyAtts)) {
				throw new WTException("以下字段必填，请输入内容后再提交！\r\n" + emptyAtts);
			}
		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
		}
	}

	/**
	 * 从流程变更self出发，获得活动对应的key值，前台判断权限等功能需要用到此key
	 *
	 * @param self
	 * @return
	 * @throws Exception
	 */
	private static String getActivityKey(Object self) throws Exception {

		String actName = ""; // 活动名称（工作流模板中的活动）
		String activityKey = "";// 活动Key值

		// self有时是ObjectReference对象，有时直接是WorkItem或WfAssignedActivity
		if (self instanceof ObjectReference) {
			self = ((ObjectReference) self).getObject();
		}
		if (self instanceof WorkItem) {

			WorkItem workItem = (WorkItem) self;
			WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
			actName = activity.getName();
			activityKey = CtKeyDeliverableProperties.getActivityNodeName(actName);

		} else if (self instanceof WfAssignedActivity) {
			WfAssignedActivity activity = (WfAssignedActivity) self;
			actName = activity.getName();
			activityKey = CtKeyDeliverableProperties.getActivityNodeName(actName);
			String activityKey1 = CtKeyDeliverableProperties.getActivityKey(actName);
		}

		if (!CtFormatUtil.hasContent(activityKey)) {
			System.out.println(
					">>>>actName='" + actName + "'无法找到对应的Key,需要核对配置表CtKeyDeliverableActivityKeyMap.properties！");
			throw new WTException("后台异常，无法找到当前流程活动对应的Key，请联系管理员！");
		}

		return activityKey;
	}

	public static void dealIpdProcessData(WTObject pbo, Object self, String typeStr) throws Exception {
		String[] arrStr = new String[] { "VR", "C" };
		WTDocument doc = (WTDocument) pbo;
		long branchId = doc.getBranchIdentifier();
		String currentYM = IpdProcessComplianceHelper.getCurrentYM(branchId + "");
		CtIpdProcessComplianceMapper mapper1 = CtBeanFactory.newCtBeanFactory()
				.getBean(CtIpdProcessComplianceMapper.class);

		CtProjectScheduleDeviationRateMapper mapper2 = CtBeanFactory.newCtBeanFactory()
				.getBean(CtProjectScheduleDeviationRateMapper.class);

		CtIpdDeliverablesReviewMapper mapper3 = CtBeanFactory.newCtBeanFactory()
				.getBean(CtIpdDeliverablesReviewMapper.class);

		for (String strType : arrStr) {
			List<CtIpdProcessComplianceBo> entityList = IpdProcessComplianceQuery.getProjectList(branchId, strType,
					currentYM);
			for (int i = 0; i < entityList.size(); i++) {
				CtIpdProcessComplianceBo ccBo = entityList.get(i);
				if (!("1".equals(typeStr))) {
					Wrapper<CtIpdProcessComplianceBo> wrapper = new EntityWrapper<CtIpdProcessComplianceBo>();
					wrapper.eq("uniteObjectId", branchId);
					wrapper.eq("belongingtoYM", currentYM);
					wrapper.eq("projectNumber", ccBo.getProjectNumber());
					wrapper.eq("projectType", strType);
					List<CtIpdProcessComplianceBo> lt = mapper1.selectList(wrapper);
					if (null != lt && lt.size() > 0) {
						CtIpdProcessComplianceBo ccbo = lt.get(i);
						mapper1.deleteById(ccbo.getId());
					}
				}
				mapper1.insert(ccBo);

				IpdFractionBasicService srvice = CtBeanFactory.newCtBeanFactory()
						.getBean(IpdFractionBasicService.class);
				srvice.getIpdFractionBasic(branchId, ccBo.getProjectNumber(), currentYM);

				for (int oi = 1; oi < 5; oi++) {
					List<CtIpdDeliverablesReviewBo> list = IpdProcessComplianceHelper.getPlanDeliverData(branchId + "",
							ccBo.getProjectNumber(), String.valueOf(oi), currentYM);
					if (null != list && list.size() > 0) {
						for (int ci = 0; ci < list.size(); ci++) {
							CtIpdDeliverablesReviewBo crBoEntity = list.get(ci);
							mapper3.insert(crBoEntity);
						}
					}
				}
			}
			// 项目进度偏差率
			List<CtProjectScheduleDeviationRateBo> entityList2 = IpdProcessComplianceQuery
					.getDeviationRateProjectList(branchId, strType, currentYM);
			for (int i = 0; i < entityList2.size(); i++) {
				CtProjectScheduleDeviationRateBo csrBo = entityList2.get(i);
				if (!("1".equals(typeStr))) {
					Wrapper<CtProjectScheduleDeviationRateBo> wrapper = new EntityWrapper<CtProjectScheduleDeviationRateBo>();
					wrapper.eq("uniteObjectId", branchId);
					wrapper.eq("belongingtoYM", currentYM);
					wrapper.eq("projectNumber", csrBo.getProjectNumber());
					wrapper.eq("projectType", strType);
					List<CtProjectScheduleDeviationRateBo> lt = mapper2.selectList(wrapper);
					if (null != lt && lt.size() > 0) {
						CtProjectScheduleDeviationRateBo ccbo = lt.get(i);
						mapper2.deleteById(ccbo.getId());
					}
				}
				mapper2.insert(csrBo);
			}
		}
	}

}
