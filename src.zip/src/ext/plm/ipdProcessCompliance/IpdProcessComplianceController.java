package ext.plm.ipdProcessCompliance;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ext.plm.common.CtResApiResult;
import ext.plm.ipdProcessCompliance.bo.CtIpdDeductBonusPointsBo;
import ext.plm.ipdProcessCompliance.bo.CtIpdDeliverablesReviewBo;
import ext.plm.ipdProcessCompliance.bo.CtIpdFractionBasicBo;
import ext.plm.ipdProcessCompliance.bo.CtProjectScheduleDeviationRateBo;
import ext.plm.ipdProcessCompliance.service.IPDProjectScheduleDevRateService;
import ext.plm.ipdProcessCompliance.service.IpdDeductBonusPointsService;
import ext.plm.ipdProcessCompliance.service.IpdDeliverablesReviewService;
import ext.plm.ipdProcessCompliance.service.IpdFractionBasicService;
import ext.plm.ipdProcessCompliance.service.IpdProcessComplianceService;
import ext.plm.tool.poi.CtExportExcelTool;
import ext.plm.util.CtFormatUtil;
import wt.org.WTUser;
import wt.session.SessionHelper;
import wt.util.WTException;

@RestController
@RequestMapping("/IpdProcessCompliance")
public class IpdProcessComplianceController {
	private static Logger logger = Logger.getLogger(IpdProcessComplianceController.class);
	@Autowired
	private IpdProcessComplianceService ctIpdProcessComplianceService;

	@Autowired
	private IpdDeductBonusPointsService ctIpdDeductBonusPointsService;

	@Autowired
	private IpdFractionBasicService ctIpdFractionBasicService;

	@Autowired
	private IpdDeliverablesReviewService ctIpdDeliverablesReviewService;

	@Autowired
	private IPDProjectScheduleDevRateService ctIPDProjectScheduleDevRateService;

	/**
	 * 查询S01：基础信息--表1
	 * 
	 * @param branchId
	 * @return
	 */
	@GetMapping(value = "/getIpdProcessComplianceBasis", produces = "application/json;charset=UTF-8")
	public CtResApiResult getIpdProcessComplianceBasis(HttpServletRequest request, HttpServletResponse response,
			Long branchId, String currentYM) {
		try {
			String showProjectNumber = request.getParameter("showProjectNumber");
			CtIpdFractionBasicBo bo = ctIpdFractionBasicService.getIpdFractionBasic(branchId, showProjectNumber,
					currentYM);
			// bo.setAllScore("90");
			return CtResApiResult.success(IpdProcessComplianceHelper.getCtIpdFractionBasicBo(bo));
		} catch (Exception e) {
			logger.error("查询ipd基础信息：--异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}
	}

	@GetMapping(value = "/getIpdProcessComplianceVR", produces = "application/json;charset=UTF-8")
	public CtResApiResult getIpdProcessComplianceVR(Long branchId, String currentYM) {
		WTUser curUser = null;
		try {
			curUser = (WTUser) SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			return CtResApiResult.success(
					ctIpdProcessComplianceService.getIpdProcessCompliance(branchId, "VR", currentYM, false, false));
		} catch (Exception e) {
			logger.error("表1异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		} finally {
			if (curUser != null) {
				try {
					SessionHelper.manager.setPrincipal(curUser.getName());
				} catch (WTException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@GetMapping(value = "/getIpdProcessComplianceC", produces = "application/json;charset=UTF-8")
	public CtResApiResult getIpdProcessComplianceC(Long branchId, String currentYM) {
		WTUser curUser = null;
		try {
			curUser = (WTUser) SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			return CtResApiResult.success(
					ctIpdProcessComplianceService.getIpdProcessCompliance(branchId, "C", currentYM, false, false));
		} catch (Exception e) {
			logger.error("表2异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}finally {
			if (curUser != null) {
				try {
					SessionHelper.manager.setPrincipal(curUser.getName());
				} catch (WTException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@GetMapping(value = "/getCtScheduleDeviationRateVR", produces = "application/json;charset=UTF-8")
	public CtResApiResult getCtScheduleDeviationRateVR(Long branchId, String currentYM) {
		WTUser curUser = null;
		try {
			curUser = (WTUser) SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			return CtResApiResult.success(ctIPDProjectScheduleDevRateService.getProjectScheduleDeviationRate(null,
					branchId, "VR", currentYM, false, false));
		} catch (Exception e) {
			logger.error("表3异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}finally {
			if (curUser != null) {
				try {
					SessionHelper.manager.setPrincipal(curUser.getName());
				} catch (WTException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@GetMapping(value = "/getCtScheduleDeviationRateC", produces = "application/json;charset=UTF-8")
	public CtResApiResult getCtScheduleDeviationRateC(Long branchId, String currentYM) {
		WTUser curUser = null;
		try {
			curUser = (WTUser) SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			return CtResApiResult.success(ctIPDProjectScheduleDevRateService.getProjectScheduleDeviationRate(null,
					branchId, "C", currentYM, false, false));
		} catch (Exception e) {
			logger.error("表4异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}finally {
			if (curUser != null) {
				try {
					SessionHelper.manager.setPrincipal(curUser.getName());
				} catch (WTException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@RequestMapping(value = "/exportCtScheduleDeviationRateReport", method = { RequestMethod.GET, RequestMethod.POST })
	public void exportCtScheduleDeviationRateReport(@RequestHeader("User-Agent") String userAgent,
			HttpServletRequest request, HttpServletResponse response, @RequestParam("prjtype") String prjtype,
			@RequestParam("branchId") Long branchId, @RequestParam("currentYM") String currentYM) throws Exception {
		{
			com.alibaba.fastjson.JSONObject result = new com.alibaba.fastjson.JSONObject();
			try {
				List<CtProjectScheduleDeviationRateBo> resultList = new ArrayList<CtProjectScheduleDeviationRateBo>();
				if (!CtFormatUtil.hasContent(prjtype)) {
					prjtype = "VR";
				}
				if ("VR".equals(prjtype)) {
					resultList = ctIPDProjectScheduleDevRateService.getProjectScheduleDeviationRate(null, branchId,
							"VR", currentYM, false, false);
				} else {
					resultList = ctIPDProjectScheduleDevRateService.getProjectScheduleDeviationRate(null, branchId, "C",
							currentYM, false, false);
				}
				List<Map> list = new ArrayList<>();
				for (int i = 0; i < resultList.size(); i++) {
					Map<String, String> map = new HashMap<String, String>();
					CtProjectScheduleDeviationRateBo bo = resultList.get(i);
					map.put("productLine", bo.getProductLine());
					map.put("projectNumber", bo.getProjectNumber());
					map.put("projectName", bo.getProjectName());
					map.put("relatedMile", bo.getRelatedMile());
					map.put("executeStatus", bo.getExecuteStatus());
					map.put("pdcpPlannedTime", bo.getPdcpPlannedTime());
					map.put("mileStoneNameEnd", bo.getMileStoneNameEnd());
					map.put("planCompleteTimeEnd", bo.getPlanCompleteTimeEnd());
					map.put("actualCompleteTimeEnd", bo.getActualCompleteTimeEnd());
					map.put("mileStoneNameIng", bo.getMileStoneNameIng());
					map.put("planCompleteTimeIng", bo.getPlanCompleteTimeIng());
					map.put("deviationRate", bo.getDeviationRate());
					list.add(map);
				}
				// Date date = new Date();
				// String fileName = "ECN报表-"+date.getTime()+".xlsx";

				String fileName = "进度偏差率导出_" + System.currentTimeMillis() + ".xlsx";
				response.setContentType("application/octet-stream");
				if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
					// ie
					fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
				} else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
					// edge
					fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
				} else {
					// //firefox、chrome、safari、opera：
					fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
				}
				response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
				response.setContentType("application/vnd.ms-excel;charset=utf-8");
				response.setCharacterEncoding("UTF-8");

				CtExportExcelTool exportExcelUtils = new CtExportExcelTool(fileName, "进度偏差率表单导出模板.xlsx");
				exportExcelUtils.expExcel(list, response.getOutputStream());
				result.put("success", true);
				result.put("msg", "进度偏差率表单导出成功！");
			} catch (Exception e) {
				e.printStackTrace();
				result.put("success", false);
				result.put("msg", "进度偏差率表单导出失败！");
			}
			response.setCharacterEncoding("utf-8");
			PrintWriter out = response.getWriter();
			out.write(result.toJSONString());
		}
	}
	/*
	 * @RequestMapping(value = "/exportCtScheduleDeviationRateReport", method =
	 * { RequestMethod.GET, RequestMethod.POST }) public void
	 * exportCtScheduleDeviationRateReport(@RequestHeader("User-Agent") String
	 * userAgent, HttpServletRequest request, HttpServletResponse response,
	 * 
	 * @RequestParam("prjtype") String prjtype,@RequestParam("branchId") Long
	 * branchId,
	 * 
	 * @RequestParam("currentYM") String currentYM) throws Exception {
	 * List<CtProjectScheduleDeviationRateBo> resultList = new
	 * ArrayList<CtProjectScheduleDeviationRateBo>(); if
	 * (!CtFormatUtil.hasContent(prjtype)) { prjtype = "VR"; }
	 * if("VR".equals(prjtype)){ resultList =
	 * ctIPDProjectScheduleDevRateService.getProjectScheduleDeviationRate(null,
	 * branchId, "VR", currentYM,false,false); }else{ resultList =
	 * ctIPDProjectScheduleDevRateService.getProjectScheduleDeviationRate(null,
	 * branchId, "C", currentYM,false,false); } System.out.println("size ----->"
	 * + resultList.size()); // String userAgent =
	 * request.getHeader("User-Agent"); String fileName = "进度偏差率导出_" +
	 * System.currentTimeMillis() + ".xlsx";
	 * 
	 * response.setContentType("application/octet-stream"); if
	 * (userAgent.contains("MSIE") || userAgent.contains("Trident")) { // ie
	 * fileName = java.net.URLEncoder.encode(fileName, "UTF-8"); } else if
	 * (userAgent.toUpperCase().indexOf("Edge") > 0) { // edge fileName = new
	 * String(fileName.getBytes("GBK"), "ISO8859-1"); } else { //
	 * //firefox、chrome、safari、opera： fileName = new
	 * String(fileName.getBytes("UTF-8"), "ISO-8859-1"); } //
	 * response.ContentEncoding = // System.Text.Encoding.GetEncoding("GB2312");
	 * response.setHeader("Content-disposition", String.format(
	 * "attachment; filename=\"%s\"", fileName));
	 * response.setContentType("application/vnd.ms-excel;charset=utf-8");
	 * response.setCharacterEncoding("UTF-8"); CtExportExcelTool exportExcelTool
	 * = new CtExportExcelTool(fileName, "进度偏差率表单导出模板.xlsx");
	 * exportExcelTool.expGridExcel(resultList, response.getOutputStream(), 1);
	 * }
	 */

	/**
	 * 不符合项扣分/加分
	 * 
	 * @param branchId
	 * @return
	 */
	@GetMapping(value = "/getIpdProcessComplianceDeductBonusPoints", produces = "application/json;charset=UTF-8")
	public CtResApiResult getIpdProcessComplianceDeductBonusPoints(HttpServletRequest request,
			HttpServletResponse response, Long branchId, String itemType, String showProjectNumber, String currentYM) {
		try {
			showProjectNumber = request.getParameter("showProjectNumber");
			/*
			 * if (CtFormatUtil.hasContent(showProjectNumber)) { String[]
			 * strNumber = showProjectNumber.split(","); if(strNumber.length >=
			 * 2){ showProjectNumber = strNumber[1]; }else if(strNumber.length
			 * == 1){ showProjectNumber = strNumber[0]; } } String[] strType =
			 * itemType.split(","); if(strType.length >= 2){ itemType =
			 * strType[1]; }else if(strType.length == 1){ itemType = strType[0];
			 * }
			 */
			return CtResApiResult.success(ctIpdDeductBonusPointsService
					.getIpdProcessComplianceDeductBonusPoints(branchId, itemType, showProjectNumber, currentYM));
		} catch (Exception e) {
			logger.error("查询表56异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}
	}

	@PostMapping(value = "/updateDeductBonusPointsInfo")
	public CtResApiResult updateDeductBonusPointsInfo(String id, String key, String value, String branchId,
			String itemType) {
		try {
			System.out.println("updateDeductBonusPointsInfo---->" + id + "<---->" + key + "<---->" + value + "<---->"
					+ branchId + "<-->" + itemType);
			return CtResApiResult.success(
					ctIpdDeductBonusPointsService.updateDeductBonusPointsInfo(id, key, value, branchId, itemType));
		} catch (Exception e) {
			logger.error("保存或更新加减信息异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 保存评审意见及改善方案纠正项
	 * 
	 * @param branchId
	 * @return
	 */
	@PostMapping(value = "/saveDeductBonusPointsInfo")
	public CtResApiResult saveDeductBonusPointsInfo(String branchId, String itemType, String showProjectNumber,
			String currentYM) {
		try {
			List<CtIpdDeductBonusPointsBo> entityList = new ArrayList<CtIpdDeductBonusPointsBo>();
			CtIpdDeductBonusPointsBo bo = new CtIpdDeductBonusPointsBo(branchId, itemType, showProjectNumber,
					currentYM);
			/*
			 * String userName = CtUserUtil.getCurrentUserAccountName();
			 * bo.setReviewer(userName);
			 */
			entityList.add(bo);
			return CtResApiResult.success(ctIpdDeductBonusPointsService.saveDeductBonusPointsInfo(entityList));
		} catch (Exception e) {
			logger.error("保存加减分项目异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 删除评审意见及改善方案纠正项
	 * 
	 * @param ids
	 * @return
	 */
	@DeleteMapping(value = "deleteDeductBonusPointsInfo", produces = "application/json;charset=UTF-8")
	public CtResApiResult deleteDeductBonusPointsInfo(@RequestBody List<String> ids) {
		try {
			ctIpdDeductBonusPointsService.deleteDeductBonusPointsInfo(ids);
			return CtResApiResult.success();
		} catch (Exception e) {
			logger.error("删除加减分项：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 不符合项扣分/加分
	 * 
	 * @param branchId
	 * @return
	 */
	@GetMapping(value = "/getIpdDeliverablesReviewInfo", produces = "application/json;charset=UTF-8")
	public CtResApiResult getIpdDeliverablesReviewInfo(HttpServletRequest request, HttpServletResponse response,
			Long branchId, String showProjectNumber, String ltype, String currentYM) {
		try {
			showProjectNumber = request.getParameter("showProjectNumber");
			currentYM = request.getParameter("currentYM");
			List<CtIpdDeliverablesReviewBo> list = ctIpdDeliverablesReviewService.getIpdDeliverablesReview(branchId,
					showProjectNumber, ltype, currentYM);
			return CtResApiResult.success(list);

		} catch (Exception e) {
			logger.error("查询表异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}
	}

}
