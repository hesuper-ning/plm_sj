package ext.plm.ec.bo;

import org.apache.ibatis.type.Alias;

@Alias("CtEcPmcMaterialItemBo")
public class CtEcPmcMaterialItemBo {
    String id;
    String changeRequestId;
    String partNumber;//物料编码
    String partName;//物料描述
    String stock;//库存量
    String inMaking;//在制量
    String maintain;//维修周转品数量
    String salesOrder;//销售订单量

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChangeRequestId() {
        return changeRequestId;
    }

    public void setChangeRequestId(String changeRequestId) {
        this.changeRequestId = changeRequestId;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getInMaking() {
        return inMaking;
    }

    public void setInMaking(String inMaking) {
        this.inMaking = inMaking;
    }

    public String getMaintain() {
        return maintain;
    }

    public void setMaintain(String maintain) {
        this.maintain = maintain;
    }

    public String getSalesOrder() {
        return salesOrder;
    }

    public void setSalesOrder(String salesOrder) {
        this.salesOrder = salesOrder;
    }

    @Override
    public String toString() {
        return "CtEcPmcMaterialItemBo{" +
                "id='" + id + '\'' +
                ", changeRequestId='" + changeRequestId + '\'' +
                ", partNumber='" + partNumber + '\'' +
                ", partName='" + partName + '\'' +
                ", stock='" + stock + '\'' +
                ", inMaking='" + inMaking + '\'' +
                ", maintain='" + maintain + '\'' +
                ", salesOrder='" + salesOrder + '\'' +
                '}';
    }
}
