package ext.plm.ec.bo;

import org.apache.ibatis.type.Alias;

@Alias("CtEcPcrMaterialItemBo")
public class CtEcPcrMaterialItemBo {
    String id;
    String changeRequestId;
    String partNumber;//物料编码
    String partName;//物料描述
    String stock;//库存量
    String po;//在外采购订单(PO)
    String pr;//在外采购(PR)
    String supplierName;//供应商名称
    String supplierStockUp;//供应商备货
    String remark;//备注

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChangeRequestId() {
        return changeRequestId;
    }

    public void setChangeRequestId(String changeRequestId) {
        this.changeRequestId = changeRequestId;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getPo() {
        return po;
    }

    public void setPo(String po) {
        this.po = po;
    }

    public String getPr() {
        return pr;
    }

    public void setPr(String pr) {
        this.pr = pr;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierStockUp() {
        return supplierStockUp;
    }

    public void setSupplierStockUp(String supplierStockUp) {
        this.supplierStockUp = supplierStockUp;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "CtEcPcrMaterialItemBo{" +
                "id='" + id + '\'' +
                ", changeRequestId='" + changeRequestId + '\'' +
                ", partNumber='" + partNumber + '\'' +
                ", partName='" + partName + '\'' +
                ", stock='" + stock + '\'' +
                ", po='" + po + '\'' +
                ", pr='" + pr + '\'' +
                ", supplierName='" + supplierName + '\'' +
                ", supplierStockUp='" + supplierStockUp + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }
}
