package ext.plm.ec.bo;

public class CtEcHeadInfoBo {
    /*
        变更表头字段key
     */
    public static final String ecrNumber_key = "head_ecrNumber"; //ECR编号
    public static final String ecrName_key = "head_ecrName"; //ECR名称
    public static final String changeType_key = "head_changeType"; //更改类型
    public static final String changeCategory_key = "head_changeCategory"; //更改类别
    public static final String productModel_key = "head_productModel"; //产品型号
    public static final String applicant_key = "head_applicant"; //申请人
    public static final String applyDept_key = "head_applyDept"; //申请部门
    public static final String applyTime_key = "head_applyTime"; //申请时间
    public static final String affectedEndParts_key = "head_affectedEndParts"; //受影响的成品
    public static final String affectedBOMs_key = "head_affectedBOMs"; //需更改的物料、BOM
    public static final String affectedDocs_key = "head_affectedDocs"; //图纸文档
    public static final String applicableScene_key = "head_applicableScene";//适用场景
    public static final String changeReason_key = "head_changeReason";//变更原因
    public static final String changeDesc_key = "head_changeDesc";//变更描述



}
