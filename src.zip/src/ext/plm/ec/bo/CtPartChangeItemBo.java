package ext.plm.ec.bo;

import org.apache.ibatis.type.Alias;

@Alias("CtPartChangeItemBo")
public class CtPartChangeItemBo {
    String id;
    String changeRequestId;
    String parentNumber;//父项编码
    String partNumber;//物料编码
    String partNameBefore;//物料描述 变更前
    String innerVersionBefore;//内部版本 变更前
    String partNameAfter;//物料描述 变更后
    String innerVersionAfter;//内部版本 变更后

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChangeRequestId() {
        return changeRequestId;
    }

    public void setChangeRequestId(String changeRequestId) {
        this.changeRequestId = changeRequestId;
    }

    public String getParentNumber() {
        return parentNumber;
    }

    public void setParentNumber(String parentNumber) {
        this.parentNumber = parentNumber;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartNameBefore() {
        return partNameBefore;
    }

    public void setPartNameBefore(String partNameBefore) {
        this.partNameBefore = partNameBefore;
    }

    public String getInnerVersionBefore() {
        return innerVersionBefore;
    }

    public void setInnerVersionBefore(String innerVersionBefore) {
        this.innerVersionBefore = innerVersionBefore;
    }

    public String getPartNameAfter() {
        return partNameAfter;
    }

    public void setPartNameAfter(String partNameAfter) {
        this.partNameAfter = partNameAfter;
    }

    public String getInnerVersionAfter() {
        return innerVersionAfter;
    }

    public void setInnerVersionAfter(String innerVersionAfter) {
        this.innerVersionAfter = innerVersionAfter;
    }
}
