package ext.plm.ec.bo;

import ext.plm.tool.poi.ref.ExcelColumn;
import org.apache.ibatis.type.Alias;

@Alias("CtMBomChangeItemBo")
public class CtMBomChangeItemBo extends CtEBomChangeItemBo {

}
