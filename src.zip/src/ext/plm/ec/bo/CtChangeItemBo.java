package ext.plm.ec.bo;

import ext.plm.tool.poi.ref.ExcelColumn;
import org.apache.ibatis.type.Alias;

@Alias("CtChangeItemBo")
public class CtChangeItemBo extends CtMBomChangeItemBo {

}
