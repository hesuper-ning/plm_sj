package ext.plm.ec.bo;

import org.apache.ibatis.type.Alias;

@Alias("CtEcPdtAuditInfoBo")
public class CtEcPdtAuditInfoBo {
    String id;
    String changeRequestId;
    String auditUser;//审批人
    String auditTime;//审批时间
    String auditComment;//审批信息

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChangeRequestId() {
        return changeRequestId;
    }

    public void setChangeRequestId(String changeRequestId) {
        this.changeRequestId = changeRequestId;
    }

    public String getAuditUser() {
        return auditUser;
    }

    public void setAuditUser(String auditUser) {
        this.auditUser = auditUser;
    }

    public String getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(String auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditComment() {
        return auditComment;
    }

    public void setAuditComment(String auditComment) {
        this.auditComment = auditComment;
    }
}
