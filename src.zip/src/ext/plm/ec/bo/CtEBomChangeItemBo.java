package ext.plm.ec.bo;

import ext.plm.tool.poi.ref.ExcelColumn;
import org.apache.ibatis.type.Alias;

@Alias("CtEBomChangeItemBo")
public class CtEBomChangeItemBo {
    String id;
    String changeRequestId;  //变更id
    @ExcelColumn(index = 0)
    String endPartNumber;//成品编码
    @ExcelColumn(index = 1)
    String parentNumber; //父项编码
    @ExcelColumn(index = 2)
    String parentName;//父项描述
    @ExcelColumn(index = 3)
    String childNumberBefore;//物料编码 变更前
    @ExcelColumn(index = 4)
    String childNameBefore; //物料描述 变更前
    @ExcelColumn(index = 5)
    String bitNumberBefore; //位号 变更前
    @ExcelColumn(index = 6)
    String amountBefore; //数量 变更前
    @ExcelColumn(index = 7)
    String replaceNumberBefore;//替代料编码 变更前
    @ExcelColumn(index = 8)
    String priorityBefore;//优先级 变更前
    @ExcelColumn(index = 9)
    String childNumberAfter; //物料编码 变更后
    @ExcelColumn(index = 10)
    String childNameAfter;//物料描述 变更后
    @ExcelColumn(index = 11)
    String bitNumberAfter;//位号 变更后
    @ExcelColumn(index = 12)
    String amountAfter; //数量 变更后
    @ExcelColumn(index = 13)
    String replaceNumberAfter; //替代料编码 变更后
    @ExcelColumn(index = 14)
    String priorityAfter; //优先级 变更后
    @ExcelColumn(index = 15)
    String changeType; //变更类型
    @ExcelColumn(index = 16)
    String remark; //备注

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }


    String bomRemarksBefore;//BOM备注  变更前
    String bomRemarksAfter;//BOM备注  变更后

    public String getBomRemarksBefore() {
        return bomRemarksBefore;
    }

    public void setBomRemarksBefore(String bomRemarksBefore) {
        this.bomRemarksBefore = bomRemarksBefore;
    }

    public String getBomRemarksAfter() {
        return bomRemarksAfter;
    }

    public void setBomRemarksAfter(String bomRemarksAfter) {
        this.bomRemarksAfter = bomRemarksAfter;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChangeRequestId() {
        return changeRequestId;
    }

    public void setChangeRequestId(String changeRequestId) {
        this.changeRequestId = changeRequestId;
    }

    public String getParentNumber() {
        return parentNumber;
    }

    public void setParentNumber(String parentNumber) {
        this.parentNumber = parentNumber;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getChildNumberBefore() {
        return childNumberBefore;
    }

    public void setChildNumberBefore(String childNumberBefore) {
        this.childNumberBefore = childNumberBefore;
    }

    public String getChildNameBefore() {
        return childNameBefore;
    }

    public void setChildNameBefore(String childNameBefore) {
        this.childNameBefore = childNameBefore;
    }

    public String getBitNumberBefore() {
        return bitNumberBefore;
    }

    public void setBitNumberBefore(String bitNumberBefore) {
        this.bitNumberBefore = bitNumberBefore;
    }

    public String getAmountBefore() {
        return amountBefore;
    }

    public void setAmountBefore(String amountBefore) {
        this.amountBefore = amountBefore;
    }

    public String getReplaceNumberBefore() {
        return replaceNumberBefore;
    }

    public void setReplaceNumberBefore(String replaceNumberBefore) {
        this.replaceNumberBefore = replaceNumberBefore;
    }

    public String getPriorityBefore() {
        return priorityBefore;
    }

    public void setPriorityBefore(String priorityBefore) {
        this.priorityBefore = priorityBefore;
    }

    public String getChildNumberAfter() {
        return childNumberAfter;
    }

    public void setChildNumberAfter(String childNumberAfter) {
        this.childNumberAfter = childNumberAfter;
    }

    public String getChildNameAfter() {
        return childNameAfter;
    }

    public void setChildNameAfter(String childNameAfter) {
        this.childNameAfter = childNameAfter;
    }

    public String getBitNumberAfter() {
        return bitNumberAfter;
    }

    public void setBitNumberAfter(String bitNumberAfter) {
        this.bitNumberAfter = bitNumberAfter;
    }

    public String getAmountAfter() {
        return amountAfter;
    }

    public void setAmountAfter(String amountAfter) {
        this.amountAfter = amountAfter;
    }

    public String getReplaceNumberAfter() {
        return replaceNumberAfter;
    }

    public void setReplaceNumberAfter(String replaceNumberAfter) {
        this.replaceNumberAfter = replaceNumberAfter;
    }

    public String getPriorityAfter() {
        return priorityAfter;
    }

    public void setPriorityAfter(String priorityAfter) {
        this.priorityAfter = priorityAfter;
    }


    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }


    public String getEndPartNumber() {
        return endPartNumber;
    }

    public void setEndPartNumber(String endPartNumber) {
        this.endPartNumber = endPartNumber;
    }

    @Override
    public String toString() {
        return "CtEBomChangeItemBo{" +
                "id='" + id + '\'' +
                ", changeRequestId='" + changeRequestId + '\'' +
                ", endPartNumber='" + endPartNumber + '\'' +
                ", parentNumber='" + parentNumber + '\'' +
                ", parentName='" + parentName + '\'' +
                ", childNumberBefore='" + childNumberBefore + '\'' +
                ", childNameBefore='" + childNameBefore + '\'' +
                ", bitNumberBefore='" + bitNumberBefore + '\'' +
                ", amountBefore='" + amountBefore + '\'' +
                ", replaceNumberBefore='" + replaceNumberBefore + '\'' +
                ", priorityBefore='" + priorityBefore + '\'' +
                ", childNumberAfter='" + childNumberAfter + '\'' +
                ", childNameAfter='" + childNameAfter + '\'' +
                ", bitNumberAfter='" + bitNumberAfter + '\'' +
                ", amountAfter='" + amountAfter + '\'' +
                ", replaceNumberAfter='" + replaceNumberAfter + '\'' +
                ", priorityAfter='" + priorityAfter + '\'' +
                ", changeType='" + changeType + '\'' +
                '}';
    }
}
