package ext.plm.ec;

import com.ptc.windchill.enterprise.history.HistoryTablesCommands;
import ext.plm.bom.CtBomWfPlugin;
import ext.plm.bom.bo.CtViewLinkBo;
import ext.plm.part.CtPartHelper;
import ext.plm.part.CtPartWfPlugin;
import ext.plm.util.*;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.*;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.maturity.PromotionNotice;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.ServiceFactory;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.workflow.engine.WfProcess;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class TestMain implements RemoteAccess {
	
	public static CtEcService service = ServiceFactory.getService(CtEcService.class);

	public static void main(String[] args) {
		System.out.println("======BasicMain.java 开始调用  " + args[0] + "=============");
		RemoteMethodServer server = RemoteMethodServer.getDefault();
		server.setUserName("wcadmin");
		server.setPassword("wcadmin");
		try {
//			PromotionNotice pn = (PromotionNotice) CtWTObjectUtil.getObjectByOid("OR:wt.maturity.PromotionNotice:178702340");
//			CtBomWfPlugin.saveConvertBomBo(pn);

			//CtPartUtil.getPartByMasterId(12132213L);


			if("genHeadInfo".equals(args[0])){
				//windchill ext.plm.ec.TestMain genHeadInfo VR:wt.change2.WTChangeRequest2:123222
				String changeRequestId = args[1];
				service.testGenHeadInfo(changeRequestId);
			}else if("autoAddPcrMaterials".equals(args[0])) {
				//windchill ext.plm.ec.TestMain autoAddPcrMaterials VR:wt.change2.WTChangeRequest2:7725137
				String changeRequestId = args[1];
				service.autoAddPcrMaterials(changeRequestId);
			}else if("autoAddPmcMaterials".equals(args[0])) {
				//windchill ext.plm.ec.TestMain autoAddPmcMaterials VR:wt.change2.WTChangeRequest2:7725137
				String changeRequestId = args[1];
				service.autoAddPmcMaterials(changeRequestId);
			}else if("autoChangeBom".equals(args[0])) {
				//windchill ext.plm.ec.TestMain autoChangeBom VR:wt.change2.WTChangeRequest2:7725137 changeType
				//windchill ext.plm.ec.TestMain autoChangeBom VR:wt.change2.WTChangeRequest2:7725137 mbom
				//windchill ext.plm.ec.TestMain autoChangeBom VR:wt.change2.WTChangeRequest2:123131813 2005365 ebom
				String changeRequestId = args[1];
				String partNumber = args[2];
				String type = args[3];
				service.autoChangeBom(changeRequestId,partNumber,type);
			}else if("historicalRevisionNotes".equals(args[0])) {
				//windchill ext.plm.ec.TestMain "historicalRevisionNotes" "" "plmtest"
				if(args[2].equals("plm")){//如果第三个参数是plm，则代表是正式机
					server.setUserName("pntadmin");
					server.setPassword("wcadmin");
				}
				server.invoke("historicalRevisionNotes", TestMain.class.getName(), null, new Class[] { String.class },
						new Object[]{args[1]});
			}else {
				System.out.println(">>>>>>没找到对应的方法，请检查第一个参数！");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("========= 执行结束！===========");
	}

	public static void main1(String[] args) throws Exception{
//		InputStream inputStream = null;
//		String zipPath = "E:\\防爆认证.J-SAP-M-A62G-Ex.手动火灾报警按钮.防爆委托.产品送检技术文件.打印档.20230706.zip";
//		ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(zipPath));
//
//		File file = new File("E:\\防爆认证.J-SAP-M-A62G-Ex.手动火灾报警按钮.防爆委托.产品送检技术文件.打印档.20230706.rar");
//		String replace = file.getName().replace(" ", "");
//		inputStream = new FileInputStream(file);
//		ZipEntry zipEntry = new ZipEntry("打印档" + File.separator + replace);
//		zipOutputStream.putNextEntry(zipEntry);
//		IOUtils.copy(inputStream, zipOutputStream);
//
//		file = new File("E:\\防爆认证.J-SAP-M-A62G-Ex.手动火灾报警按钮.防爆委托.盖章档.20230714.rar");
//		inputStream = new FileInputStream(file);
//		replace = file.getName().replace(" ", "");
//		zipEntry = new ZipEntry("扫描档" + File.separator + replace);
//		zipOutputStream.putNextEntry(zipEntry);
//		IOUtils.copy(inputStream, zipOutputStream);
//
//		int temp = 0;
//		while ((temp = inputStream.read()) != -1) {
//			zipOutputStream.write(temp);
//		}
//		zipOutputStream.close();
//		inputStream.close();

		String a = "123456789";
		Vector<String> b = new Vector<>();
		test(a, b);
		for(int i = 0;i < b.size();i++){
			System.out.println("------" + b.get(i));
		}



		// 创建样式并设置背景色为橙色
		Workbook workbook = null;
		CellStyle background = workbook.createCellStyle();
		background.setFillForegroundColor(IndexedColors.ORANGE.getIndex());
		background.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	}

	public static void test(String a, Vector<String> b){
		String part1 = a.substring(0,2);
		String part2 = a.substring(2);
		b.add(part1);
		if(part2.length() > 2){
			test(part2, b);
		}else{
			b.add(part2);
		}
	}


	public static Map<String, String> brushRelationPartDoc(String filePath) throws Exception {
		File file = new File(filePath);
		Workbook workbook = WorkbookFactory.create(file);
		Sheet sheet = workbook.getSheetAt(0);
		Map<String, String> map = new HashMap<>();
		String parentNumber = "";
		for (int rowIndex = 6; rowIndex < sheet.getPhysicalNumberOfRows(); rowIndex++) {
			String flag = CtExcelReadUtil.getCellValue(sheet, rowIndex, 1);
			String number = CtExcelReadUtil.getCellValue(sheet, rowIndex, 2);
			String q = CtExcelReadUtil.getCellValue(sheet, rowIndex, 7);
			if("0".equals(flag)){
				parentNumber = number;
			}
			map.put("parentNumber", parentNumber);
			map.put("number", number);
			map.put("q", q);
		}
		return map;
	}

	/**
	 * 历史的变更修订添加备注
	 */
	public static void historicalRevisionNotes(String args) throws Exception {

		//遍历所有eca，状态是已解决
		List<WTChangeRequest2> ecrList = new ArrayList<>();
		QuerySpec qs = new QuerySpec(WTChangeRequest2.class);
		SearchCondition sc2 = new SearchCondition(WTChangeRequest2.class
				, WTChangeRequest2.NUMBER
				, SearchCondition.LIKE, args + "%");
		qs.appendWhere(sc2);
		qs.appendOrderBy(new OrderBy(new ClassAttribute(WTChangeRequest2.class, WTChangeRequest2.NUMBER), true), new int[]{0});

		QueryResult qr = PersistenceHelper.manager.find(qs);
		while (qr.hasMoreElements()) {
			Object o = qr.nextElement();
			WTChangeRequest2 ecr = (WTChangeRequest2) o;
			String localizedMessage = ecr.getState().getState().getLocalizedMessage(Locale.CHINA);
			if (!(localizedMessage.equals("实施") || localizedMessage.equals("已解决"))) {
				continue;
			}
			ecrList.add(ecr);
		}

		//收集数据：对应的产生对象的大版本，对应的ecr的变更原因
		for (WTChangeRequest2 ecr : ecrList) {
			System.out.println();
			System.out.println();
			System.out.println("对ecr：" + ecr.getNumber() + "输入变更原因");
			IBAUtil iba = new IBAUtil(ecr);
			String ecReason = iba.getIBAValue("ct_changeReason");
			String mark = "ECR系统自动修订-" + ecr.getNumber() + "，变更原因：" + ecReason;
			QueryResult qrEcn = ChangeHelper2.service.getChangeOrders(ecr);
			if (qrEcn.hasMoreElements()) { //遍历ecn
				WTChangeOrder2 ecn = (WTChangeOrder2) qrEcn.nextElement();
				QueryResult qrEca = ChangeHelper2.service.getChangeActivities(ecn);
				while (qrEca.hasMoreElements()) {
					WTChangeActivity2 eca = (WTChangeActivity2) qrEca.nextElement();
					QueryResult changeablesAfter = ChangeHelper2.service.getChangeablesAfter(eca);
					while (changeablesAfter.hasMoreElements()) {
						Object o = changeablesAfter.nextElement();
						System.out.println(CtCommonUtil.getURL((Persistable) o) );
						System.out.println(CtWTObjectUtil.getNumberName(o)[0] + "|" + CtWTObjectUtil.getNumberName(o)[1] + "→");
						String versionInfo = ((RevisionControlled) o).getVersionIdentifier().getValue() + ".1";
						if (o instanceof WTPart) {
							versionInfo = versionInfo + "(" + ((WTPart) o).getViewName() + ")";
						}

						System.out.println("修改的版本：" + versionInfo );
						List var6 = HistoryTablesCommands.versionHistory((Versioned) o);
						for (Object o1 : var6) {
							String versionInfo2 = CtVersionUtil.getVersionInfo((RevisionControlled) o1);
							if (o1 instanceof WTPart) {
								versionInfo2 = versionInfo2 + "(" + ((WTPart) o1).getViewName() + ")";
							}

							if (versionInfo2.equals(versionInfo)) {
								String oldNote = VersionControlHelper.getNote((Iterated) o1);
								if (!CtFormatUtil.hasContent(oldNote)) {
									VersionControlHelper.setNote((Iterated) o1, mark);
									PersistenceServerHelper.manager.update((Persistable) o1);
								}
								else{
									System.out.println("已有备注跳过设置：" + oldNote );
								}
							}
						}
					}
				}
			}
		}
	}
}
