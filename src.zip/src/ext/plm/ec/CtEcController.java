package ext.plm.ec;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.TypeReference;
import ext.plm.common.CtConstant;
import ext.plm.common.CtResApiResult;
import ext.plm.ec.bo.*;
import ext.plm.oaFlow.pcbApply.config.CtPcbApplyProperties;
import ext.plm.tool.poi.CtExportExcelTool;
import ext.plm.util.CtFileUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.content.ApplicationData;
import wt.content.ContentServerHelper;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.workflow.work.WorkItem;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Controller
public class CtEcController {
    public static CtEcService service = ServiceFactory.getService(CtEcService.class);

    /**
     * 刷新表单信息
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/refreshHeadInfo", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public static void refreshHeadInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            checkEditAccess(request);
            String changeRequestId = request.getParameter("changeRequestId");
            result = JSONUtil.parseObj(service.refreshHeadInfo(changeRequestId));
            result.put("success", true);
            result.put("msg", "刷新成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "刷新失败！" + e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //查询变更表头信息
    @RequestMapping(value = "/ec/getHeadInfo",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getHeadInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        String changeRequestId = request.getParameter("changeRequestId");
        try {
            HashMap<String,String> headInfo = service.getHeadInfo(changeRequestId);

            result = JSONUtil.parseObj(headInfo);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询变更表头信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //插入一条数据
    @RequestMapping(value = "/ec/insertBomChangeItems",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void insertBomChangeItems(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        String type = request.getParameter("type");
        String changeRequestId = request.getParameter("changeRequestId");
        try {
            checkEditAccess(request);
            service.insertBomChangeItems(changeRequestId,type);
            result.put("success", true);
            result.put("msg", "添加成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "添加失败!"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //检验输入的对象编码是否正确，并返回对象名称  不返回了，直接后台保存，前台刷新页面
    @RequestMapping(value = "/ec/checkChangeObj",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void checkChangeObj(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        String updatedRecords = request.getParameter("updatedRecords");
        JSONObject jsonObject = JSONUtil.parseObj(updatedRecords);
        try {
            checkEditAccess(request);
            HashMap<String,String> dataMap  = new HashMap<String,String>();
            dataMap.put("id",jsonObject.getStr("id"));
            dataMap.put("changeRequestId",jsonObject.getStr("changeRequestId"));
            dataMap.put("objNumber",jsonObject.getStr("objNumber"));
            dataMap.put("mark",jsonObject.getStr("mark"));
            dataMap.put("type",jsonObject.getStr("type"));
            String objName = service.checkChangeObj(dataMap);
            result.put("objName", objName);
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    //查询物料变更列表信息
    @RequestMapping(value = "/ec/getPartChangeItems",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getPartChangeItems(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String changeRequestId = request.getParameter("changeRequestId");
            List<CtPartChangeItemBo> resultList = service.getPartChangeItems(changeRequestId);
            JSONArray itemsArr = JSONUtil.parseArray(resultList);
            result.put("items", itemsArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询失败！"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //查询MBOM变更列表信息
    @RequestMapping(value = "/ec/getChangeItems",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getChangeItems(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String changeRequestId = request.getParameter("changeRequestId");
            String type = request.getParameter("type");
            List<CtChangeItemBo> resultList = service.getChangeItems(changeRequestId,type);
            JSONArray itemsArr = JSONUtil.parseArray(resultList);
            result.put("items", itemsArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询失败！"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }



    //删除更改内容列表
    @RequestMapping(value = "/ec/deleteChangeItems", method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void deleteChangeItems(HttpServletRequest request, HttpServletResponse response) throws Exception{

        String deleteItems = request.getParameter("deleteItems");
        String type = request.getParameter("type");
        JSONObject result = new JSONObject();
        try{
            checkEditAccess(request);
            List<String> deleteIdList = new ArrayList<String>();
            JSONArray newItemsArray = JSONUtil.parseArray(deleteItems);
            for(int i=0; i<newItemsArray.size();i++){
                JSONObject obj = newItemsArray.getJSONObject(i);
                deleteIdList.add(obj.getStr("id"));
            }
            service.deleteChangeItems(deleteIdList,type);
            result.put("success", true);
            result.put("msg", "删除成功！");

        }catch(Exception e){
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "删除失败，后台异常信息："+e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //删除物料更改内容列表
    @RequestMapping(value = "/ec/deletePartChangeItems", method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void deletePartChangeItems(HttpServletRequest request, HttpServletResponse response) throws Exception{

        String deleteItems = request.getParameter("deleteItems");
        JSONObject result = new JSONObject();
        try{
            checkEditAccess(request);
            List<String> deleteIdList = new ArrayList<String>();
            JSONArray newItemsArray = JSONUtil.parseArray(deleteItems);
            for(int i=0; i<newItemsArray.size();i++){
                JSONObject obj = newItemsArray.getJSONObject(i);
                deleteIdList.add(obj.getStr("id"));
            }
            service.deletePartChangeItems(deleteIdList);
            result.put("success", true);
            result.put("msg", "删除成功！");

        }catch(Exception e){
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "删除失败，后台异常信息："+e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * EBOM列表 excel导入
     *
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/importChangeItems", method = RequestMethod.POST)
    public static void importChangeItems(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            checkEditAccess(request);
            String changeRequestId = request.getParameter("changeRequestId");
            String boms = request.getParameter("boms");
            String bomType = request.getParameter("type");
            WTProperties wtproperty = WTProperties.getLocalProperties();
            String temppath = wtproperty.getProperty("wt.home")+ "/codebase/ext/plm/ec/temp/";
            File fpath = new File(temppath);
            if(!fpath.exists()){
                fpath.mkdirs();
            }
            // 定时7天清理文件
            long delete = 604800000;
            CtFileUtil.deleteFileByTime(fpath, delete);
            File file = null;
            DiskFileItemFactory fac = new DiskFileItemFactory(); // 本地文件
            ServletFileUpload upload = new ServletFileUpload(fac);

            List<FileItem> fileItems = new ArrayList<FileItem>();
            fileItems = upload.parseRequest(request);
            Iterator<FileItem> it = fileItems.iterator();

            Date date = new Date();
            long time = date.getTime();

            while (it.hasNext()) {
                FileItem item = it.next();
                String name = item.getName();
                File tFile = new File(name); // 借助此File获得不带本地路径的文件名
                name = tFile.getName();
                // 加上时间戳
                String substring = name.substring(0, name.lastIndexOf("."));
                String type = name.substring(name.lastIndexOf("."));
                if (!".xls".equals(type) && !".xlsx".equals(type)) {
                    throw new Exception("请使用正确excel文件模板导入数据！！");
                }
                name = substring + "_" + time + type;
                tFile = null; // 释放
                file = new File(temppath + name);
                item.write(file);
            }

            service.importChangeItems(file,changeRequestId,boms,bomType);

            result.put("ifExport", false);
            result.put("success", true);
            result.put("msg", "导入成功");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            if(error.contains("org.apache.poi.POIXMLException: org.apache.poi.openxml4j.exceptions")) {
                error = "导入文件不是Excel文件或者文件已被加密！！";
            }
            result.put("success", false);
            result.put("msg", "导入失败，后台异常信息：\r\n" + error);
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 导出变更内容列表
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/exportChangeItems", method = { RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT })
    public static void exportChangeItems(HttpServletRequest request, HttpServletResponse response) throws Exception{
        JSONObject result = new JSONObject();

        try {
            String changeRequestId = request.getParameter("changeRequestId");
            String type = request.getParameter("type");
            String fileName = "变更内容列表";
            String userAgent = request.getHeader("User-Agent");
            if("ebom".equals(type)){
                fileName = "EBOM"+fileName+"_"+System.currentTimeMillis()+".xlsx";
            }else{
                fileName = "MBOM"+fileName+"_"+System.currentTimeMillis()+".xlsx";
            }


            response.setContentType("application/octet-stream");
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                //edge
                fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
            }else {
                // //firefox、chrome、safari、opera：
                fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
            }
            //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            List<Map> data = service.getChangeItemsData(changeRequestId,type);
            if("ebom".equals(type)){
                CtExportExcelTool exportExcelUtils = new CtExportExcelTool(fileName, "EBOM变更内容导入模板.xlsx");
                exportExcelUtils.expExcel(data, response.getOutputStream());
            }else{
                CtExportExcelTool exportExcelUtils = new CtExportExcelTool(fileName, "MBOM变更内容导入模板.xlsx");
                exportExcelUtils.expExcel(data, response.getOutputStream());
            }

            result.put("success", true);
            result.put("msg", "导出成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "导出失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 下载模板
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/downLoadTemplate", method = { RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT })
    public static void downLoadTemplate(HttpServletRequest request, HttpServletResponse response) throws Exception {

        JSONObject result = new JSONObject();

        try {
            String userAgent = request.getHeader("User-Agent");
            String fileName = request.getParameter("templateName")+".xlsx";
            String tempFileName = fileName;
            response.setContentType("application/octet-stream");
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                //edge
                fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
            }else {
                // //firefox、chrome、safari、opera：
                fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
            }
            //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            CtExportExcelTool exportExcelUtils = new CtExportExcelTool(fileName, tempFileName);
            exportExcelUtils.expExcel(null, response.getOutputStream());

            result.put("success", true);
            result.put("msg", "导出成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "下载模板失败，后台异常信息：" + e.getLocalizedMessage());
        }

    }

    //单个保存变更表头属性
    @RequestMapping(value = "/ec/autoSaveAtt",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void autoSaveAtt(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        try {
            checkEditAccess(request);
            JSONObject dataJson = JSONUtil.parseObj(request.getParameter("updatedRecords"));
            String changeRequestId = dataJson.getStr("changeRequestId");
            String attKey = dataJson.getStr("attKey");
            String attValue = dataJson.getStr("attValue");
            String activityKey = dataJson.getStr("activityKey");
            service.saveAttribute(changeRequestId,activityKey,attKey, attValue);
            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "实时保存属性失败！"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    //检验输入的物料编码是否正确，并返回物料名称
    @RequestMapping(value = "/ec/checkMaterialNumber",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void checkMaterialNumber(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        String partNumber = request.getParameter("partNumber");
        String changeRequestId = request.getParameter("changeRequestId");
        String boms = request.getParameter("boms");
        try {
            checkEditAccess(request);
            String materialName = service.checkMaterialNumber(partNumber,changeRequestId,boms);
            result.put("materialName", materialName);
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (WTException wte) {
            result.put("success", false);
            result.put("msg", wte.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //更改内容 列表除编码之外的其他列保存
    @RequestMapping(value = "/ec/saveChangeListField",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void saveChangeListField(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        String k = "";
        try {
            checkEditAccess(request);
            JSONObject dataJson = JSONUtil.parseObj(request.getParameter("updatedRecords"));
            String id = dataJson.getStr("id");
            if(!StringUtils.isNumber(id)){
                id = "";
            }
            String key = dataJson.getStr("key");
            k = key;
            String value = dataJson.getStr("value");
            String changeRequestId = dataJson.getStr("changeRequestId");
            String boms= dataJson.getStr("boms");
            String type = dataJson.getStr("type");
            service.saveChangeListField(id,key,value,changeRequestId,boms,type);
            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "实时保存属性失败！\r\n"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //物料变更列表  实时保存
    @RequestMapping(value = "/ec/savePartChangeItems",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void savePartChangeItems(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        String k = "";
        try {
            checkEditAccess(request);
            JSONObject dataJson = JSONUtil.parseObj(request.getParameter("updatedRecords"));
            String id = dataJson.getStr("id");
            if(!StringUtils.isNumber(id)){
                id = "";
            }
            String key = dataJson.getStr("key");
            String value = dataJson.getStr("value");
            String changeRequestId = dataJson.getStr("changeRequestId");
            service.savePartChangeItems(id,key,value,changeRequestId);
            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "实时保存属性失败！\r\n"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    // *********************开始*****上传*下载*删除附件*********************************//
    /**
     * 上传文件到文档附件
     */
    @RequestMapping(value = "/ec/uploadFiles", method = RequestMethod.POST)
    public static void uploadFiles(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        try {
            checkEditAccess(request);
            String changeRequestId = request.getParameter("changeRequestId");
            String tetx_name = request.getParameter("tetx_name");
            String node = request.getParameter("node");// 用来判断删除的
            WTProperties wtproperty = WTProperties.getLocalProperties();
            String filePath = wtproperty.getProperty("wt.home")+ "/codebase/ext/plm/ec/temp/";// 临时路经
            String fileName = CtEcLogic.getFileNameAndUpload(filePath, request);

            File file = new File(filePath+File.separator+fileName);
//	   			fileName = fileName.substring(0, fileName.lastIndexOf(".")); // 获取名称当文档名称
            CtEcLogic ecLogic = new CtEcLogic();
            String docUrl = ecLogic.uploadFiles(file, changeRequestId,tetx_name,node);
            result.put("fileName", docUrl);
            result.put("success", true);
            result.put("msg", "上传成功");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            result.put("success", false);
            result.put("msg", "上传附件异常信息：\r\n" + error);
        }finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 删除附件
     */
    @RequestMapping(value = "/ec/deleteFiles", method = RequestMethod.POST)
    public static void deleteFiles(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        try {
            checkEditAccess(request);
            String changeRequestId = request.getParameter("changeRequestId");
            String fileName = request.getParameter("fileName");
            CtEcLogic ecLogic = new CtEcLogic();
            ecLogic.deleteFiles(changeRequestId,fileName);
            result.put("success", true);
            result.put("msg", fileName+"删除成功！");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            result.put("success", false);
            result.put("msg", "删除附件异常信息：\r\n" + error);
        }finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 下载附件
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/downLoadDoc", method = { RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT })
    public static void downLoadDoc(HttpServletRequest request, HttpServletResponse response) throws Exception {
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        JSONObject result = new JSONObject();
        String number = request.getParameter("number");
        String fileName = request.getParameter("fileName");
        OutputStream out = null;
        InputStream in = null;
        try {
            if(CtFormatUtil.hasContent(number) && CtFormatUtil.hasContent(fileName)) {
                CtEcLogic ecLogic = new CtEcLogic();
                ApplicationData appData = ecLogic.getApplicationData(number, fileName);
                if(appData != null) {
                    String userAgent = request.getHeader("User-Agent");
                    response.setContentType("application/octet-stream");
                    if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                        //ie
                        fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                    } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                        //edge
                        fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
                    }else {
                        // //firefox、chrome、safari、opera：
                        fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
                    }
                    //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
                    response.setCharacterEncoding("UTF-8");
                    response.setContentType("application/octet-stream");
                    response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
                    response.setCharacterEncoding("UTF-8");

                    //获取文件输入流
                    in = ContentServerHelper.service.findContentStream(appData);
                    int len = 0;
                    byte[] buffer = new byte[10240];
                    out = response.getOutputStream();
                    while ((len = in.read(buffer)) > 0) {
                        //将缓冲区的数据输出到客户端浏览器
                        out.write(buffer,0,len);
                    }
                    result.put("success", true);
                    result.put("msg", "下载成功！");
                }else {
                    result.put("success", false);
                    result.put("msg", "No attachments to be found in the document!");// 文档中没找到需要下载的附件！
                }
            }else {
                result.put("success", false);
                result.put("msg", "Required parameters cannot be empty!");// 必传参数不能为空！
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "Download failed, background abnormal information:" + e.getLocalizedMessage());// 下载失败，后台异常信息：
        }finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out1 = response.getWriter();
        out1.write(result.toString());
    }
    // *********************结束*****上传*下载*删除附件*********************************//

    //自动添加受影响物料 采购列表
    @RequestMapping(value = "/ec/autoAddPcrMaterials",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void autoAddPcrMaterials(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            checkEditAccess(request);
            String changeRequestId = request.getParameter("changeRequestId");
            //去掉自动多出的引号
            changeRequestId = changeRequestId.replaceAll("\"", "");
            service.autoAddPcrMaterials(changeRequestId);
            result.put("success", true);
            result.put("msg", "添加成功！");

        } catch (WTException e) {
            result.put("success", false);
            result.put("msg", e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "自动加入受影响物料失败！异常信息："+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //自动添加受影响物料 物控列表
    @RequestMapping(value = "/ec/autoAddPmcMaterials",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void autoAddPmcMaterials(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            checkEditAccess(request);
            String changeRequestId = request.getParameter("changeRequestId");
            //去掉自动多出的引号
            changeRequestId = changeRequestId.replaceAll("\"", "");
            service.autoAddPmcMaterials(changeRequestId);
            result.put("success", true);
            result.put("msg", "添加成功！");

        } catch (WTException e) {
            result.put("success", false);
            result.put("msg", e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "自动加入受影响物料失败！异常信息："+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 查询采购分析列表
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/getPcrMaterialItems",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getPcrMaterialItems(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String changeRequestId = request.getParameter("changeRequestId");

            List<CtEcPcrMaterialItemBo> resultList = service.getPcrMaterialItems(changeRequestId);
            JSONArray itemsArr = JSONUtil.parseArray(resultList);
            result.put("items", itemsArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询采购分析信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 查询物控分析列表
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/getPmcMaterialItems",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getPmcMaterialItems(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String changeRequestId = request.getParameter("changeRequestId");

            List<CtEcPmcMaterialItemBo> resultList = service.getPmcMaterialItems(changeRequestId);
            JSONArray itemsArr = JSONUtil.parseArray(resultList);
            result.put("items", itemsArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询采购分析信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 查询PDT团队评审信息
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/getPdtAuditInfo",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getPdtAuditInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String changeRequestId = request.getParameter("changeRequestId");

            List<CtEcPdtAuditInfoBo> resultList = service.getPdtAuditInfo(changeRequestId);
            JSONArray itemsArr = JSONUtil.parseArray(resultList);
            result.put("items", itemsArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询采购分析信息失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 删除采购分析列表数据
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/deletePcrMatItems", method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void deletePcrMatItems(HttpServletRequest request, HttpServletResponse response) throws Exception{

        String deleteItems = request.getParameter("deleteItems");

        JSONObject result = new JSONObject();
        try{
            checkEditAccess(request);
            List<String> deleteIdList = new ArrayList<String>();

            JSONArray newItemsArray = JSONUtil.parseArray(deleteItems);
            for(int i=0; i<newItemsArray.size();i++){
                JSONObject obj = newItemsArray.getJSONObject(i);
                deleteIdList.add(obj.getStr("id"));
            }

            service.deletePcrMatItems(deleteIdList);
            //result = JSONObject.fromObject(partInfo);
            result.put("success", true);
            result.put("msg", "删除成功！");

        }catch(Exception e){
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "删除采购分析列表失败，后台异常信息："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 删除物控分析列表
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/deletePmcMatItems", method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void deletePmcMatItems(HttpServletRequest request, HttpServletResponse response) throws Exception{

        String deleteItems = request.getParameter("deleteItems");

        JSONObject result = new JSONObject();
        try{
            checkEditAccess(request);
            List<String> deleteIdList = new ArrayList<String>();

            JSONArray newItemsArray = JSONUtil.parseArray(deleteItems);
            for(int i=0; i<newItemsArray.size();i++){
                JSONObject obj = newItemsArray.getJSONObject(i);
                deleteIdList.add(obj.getStr("id"));
            }

            service.deletePmcMatItems(deleteIdList);
            //result = JSONObject.fromObject(partInfo);
            result.put("success", true);
            result.put("msg", "删除成功！");

        }catch(Exception e){
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "删除采购分析列表失败，后台异常信息："+e.getLocalizedMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 采购分析列表  保存编码和名称
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/ec/savePcrMaterialNumber",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void savePcrMaterialNumber(HttpServletRequest request, HttpServletResponse response)throws Exception{
        JSONObject result = new JSONObject();

        try {
            checkEditAccess(request);
            JSONObject dataJson = JSONUtil.parseObj(request.getParameter("updatedRecords"));
            HashMap<String,String> dataMap ;
            dataMap = (HashMap<String,String>)JSONUtil.toBean(dataJson,HashMap.class);
            service.savePcrMaterialNumber(dataMap);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (WTException e) {
            result.put("success", false);
            result.put("msg", e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "保存失败！异常信息:"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //采购分析列表实时保存 （除物料编码列)
    @RequestMapping(value = "/ec/savePcrMaterialField",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void savePcrMaterialField(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            checkEditAccess(request);
            JSONObject dataJson = JSONUtil.parseObj(request.getParameter("updatedRecords"));
            String id = dataJson.getStr("id");
            String key = dataJson.getStr("key");
            String value = dataJson.getStr("value");
            service.savePcrMaterialField(id,key,value);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "保存成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "实时保存属性失败！");
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }




    //保存数据之前校验workItem是否完成
    //前台需要把workItemOid传过来  操作数据的controller中调用 查询的不用
    private static void checkEditAccess(HttpServletRequest request) throws Exception {
        String workItemOid = request.getParameter("workItemOid");
        if(CtFormatUtil.hasContent(workItemOid)){
            wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
            WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
            if(workItem!=null&&workItem.isComplete()){
                throw new Exception("活动已完成，请刷新页面");
            }
        }
    }



    //查询MBOM变更列表信息
    @RequestMapping(value = "/ec/getBomList",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getBomList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String changeRequestId = request.getParameter("changeRequestId");
            String type = request.getParameter("type");
            CtEcLogic logic = new CtEcLogic();
            List<HashMap<String,String>> reloadList = CtEcLogic.getBomList(changeRequestId,type);
            JSONArray itemsArr = JSONUtil.parseArray(reloadList);
            result.put("items", itemsArr);
            // System.out.println(project.toString());
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询失败！"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //受影响对象中的所有EPart
    @RequestMapping(value = "/ec/getAffectedEPart",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getAffectedEPart(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String changeRequestId = request.getParameter("changeRequestId");
            List<HashMap<String,String>> resultList = CtEcLogic.getAffectedEPart(changeRequestId);
            JSONArray itemsArr = JSONUtil.parseArray(resultList);
            result.put("items", itemsArr);
            result.put("success", true);
            result.put("msg", "查询成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询失败！"+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //region ec汇总报表
    @RequestMapping(value = "/ec/getEcReport", method = { RequestMethod.GET, RequestMethod.POST,RequestMethod.PUT })
    public static void getEcReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
        com.alibaba.fastjson.JSONObject result = new com.alibaba.fastjson.JSONObject();
        String paramAll = request.getParameter("paramAll");
        String state = request.getParameter("state");
        String createDate_start = request.getParameter("createDate_start");
        String createDate_end = request.getParameter("createDate_end");
        int start = Integer.parseInt(request.getParameter("start"));//从前台传递的值
        int limit = Integer.parseInt(request.getParameter("limit"));// 每页条数
        int page = (start/limit)+1;
        try {
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("paramAll", paramAll);
            map.put("start", start);
            map.put("pageSize", page*limit);
            map.put("state", state);
            map.put("createDate_start", createDate_start);
            map.put("createDate_end", createDate_end);

            List<Map<String,String>> resultList = service.getEcReportItems(map);
            int totalCount = service.getEcReportItemsCount(map);
            result.put("success", true);
            result.put("msg", "查询成功！");
            result.put("items", resultList);
            result.put("totalCount", totalCount);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询信息失败，后台异常信息：" + e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    //报表导出
    @RequestMapping(value = "/ec/exportEcReport",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void exportEcReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
        com.alibaba.fastjson.JSONObject result = new com.alibaba.fastjson.JSONObject();
        try {
            String userAgent = request.getHeader("User-Agent");
            response.setContentType("application/octet-stream");
            String data = "{}";
            if(CtFormatUtil.hasContent(request.getParameter("data"))) {
                data = request.getParameter("data");
            }
            HashMap<String, Object> param = com.alibaba.fastjson.JSONObject.parseObject(data, new TypeReference<HashMap<String, Object>>(){});
            param.put("MARK","export");
            List list = service.getEcReportItems(param);

            Date date = new Date();
            String fileName = "ECN报表-"+date.getTime()+".xlsx";
            response.setContentType("application/octet-stream");
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                //edge
                fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
            }else {
                // //firefox、chrome、safari、opera：
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            CtExportExcelTool exportExcelUtils = new CtExportExcelTool(fileName, "Ecn报表.xlsx");
            exportExcelUtils.expExcel(list, response.getOutputStream());
            result.put("success", true);
            result.put("msg", "ECN报表导出成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "ECN报表导出失败！");
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }//endregion

    //新ec汇总报表
    @RequestMapping(value = "/ec/getNewEcReport", method = { RequestMethod.GET, RequestMethod.POST,RequestMethod.PUT })
    public static void getNewEcReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
        com.alibaba.fastjson.JSONObject result = new com.alibaba.fastjson.JSONObject();
        String paramAll = request.getParameter("paramAll");
        String state = request.getParameter("state");
        String createDate_start = request.getParameter("createDate_start");
        String createDate_end = request.getParameter("createDate_end");
        int start = Integer.parseInt(request.getParameter("start"));//从前台传递的值
        int limit = Integer.parseInt(request.getParameter("limit"));// 每页条数
        int page = (start/limit)+1;
        try {
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("paramAll", paramAll);
            map.put("start", start);
            map.put("pageSize", page*limit);
            map.put("state", state);
            map.put("createDate_start", createDate_start);
            map.put("createDate_end", createDate_end);

            List<Map<String,String>> resultList = service.getNewEcReportItems(map);
            int totalCount = service.getNewEcReportItemsCount(map);
            result.put("success", true);
            result.put("msg", "查询成功！");
            result.put("items", resultList);
            result.put("totalCount", totalCount);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "查询信息失败，后台异常信息：" + e.getLocalizedMessage());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    //新报表导出
    @RequestMapping(value = "/ec/exportNewEcReport",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void exportNewEcReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
        com.alibaba.fastjson.JSONObject result = new com.alibaba.fastjson.JSONObject();
        try {
            String userAgent = request.getHeader("User-Agent");
            response.setContentType("application/octet-stream");
            String data = "{}";
            if(CtFormatUtil.hasContent(request.getParameter("data"))) {
                data = request.getParameter("data");
            }
            HashMap<String, Object> param = com.alibaba.fastjson.JSONObject.parseObject(data, new TypeReference<HashMap<String, Object>>(){});
            param.put("MARK","export");
            List list = service.getNewEcReportItems(param);

            Date date = new Date();
            String fileName = "ECN报表-"+date.getTime()+".xlsx";
            response.setContentType("application/octet-stream");
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                //edge
                fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
            }else {
                // //firefox、chrome、safari、opera：
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            CtExportExcelTool exportExcelUtils = new CtExportExcelTool(fileName, "Ecn报表(新).xlsx");
            exportExcelUtils.expExcel(list, response.getOutputStream());
            result.put("success", true);
            result.put("msg", "ECN报表导出成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "ECN报表导出失败！");
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }//endregion


}
