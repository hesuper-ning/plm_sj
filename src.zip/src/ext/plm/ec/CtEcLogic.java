package ext.plm.ec;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.windchill.cadx.common.util.GenericUtilities;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.ec.bo.CtChangeItemBo;
import ext.plm.ec.bo.CtEcHeadInfoBo;
import ext.plm.ec.bo.CtPartChangeItemBo;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.ec.config.CtEcProperties;
import ext.plm.integration.hr.CtHrLogic;
import ext.plm.integration.hr.bo.CtHrPersonBo;
import ext.plm.mobileWorkReport.CtMobileWorkReportLogic;
import ext.plm.newec.bo.CtEcrInfoBo;
import ext.plm.newec.service.CtECRApprovalRecordsService;
import ext.plm.part.CtPartLogic;
import ext.plm.tool.CtCheckFitPlaceTool;
import ext.plm.util.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import wt.build.BuildRule;
import wt.change2.*;
import wt.content.*;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.fc.*;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.FolderNotFoundException;
import wt.httpgw.URLFactory;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleServerHelper;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.occurrence.OccurrenceHelper;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.ownership.Ownership;
import wt.part.*;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;
import wt.workflow.engine.WfProcess;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.math.RoundingMode;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


public class CtEcLogic {
    private static final Logger logger = LogR.getLogger(CtEcLogic.class.getName());

    /**
     * 生成ec表头信息
     * @param changeRequest
     * @throws Exception
     */
    public static void genEcHeadInfo(WTChangeRequest2 changeRequest) throws Exception {
        genEcHeadInfo(changeRequest,false);
    }

    /**
     *  首次生成 或者 刷新表单表头信息
     * @param changeRequest
     * @param refresh
     * @throws Exception
     */
    public static void genEcHeadInfo(WTChangeRequest2 changeRequest,boolean refresh) throws Exception {
        IBAUtil ibaUtil = new IBAUtil(changeRequest);
        // 需要创建的值
        HashMap<String, String> attKeyValueMap = new HashMap<String, String>();
        String changeRequestId = CtWTObjectUtil.getVid(changeRequest);
        String activityKey = "head_node";
        attKeyValueMap.put(CtEcHeadInfoBo.ecrNumber_key, changeRequest.getNumber());//ECR编号
//        attKeyValueMap.put(CtEcHeadInfoBo.changeCategory_key, changeRequest.getCategory().getDisplay(Locale.CHINA));//更改类别  取更改请求类别
        attKeyValueMap.put(CtEcHeadInfoBo.applicant_key, changeRequest.getCreatorFullName());//申请人
        CtHrPersonBo person = CtHrLogic.getPersonByNo(changeRequest.getCreatorName());
        attKeyValueMap.put(CtEcHeadInfoBo.applyDept_key, person.getDepartmentName());//申请部门
        String changeType = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_changeType);
        if(!CtFormatUtil.hasContent(changeType)){
            throw new Exception("更改请求属性【更改类型】为空!");
        }
        attKeyValueMap.put(CtEcHeadInfoBo.changeType_key, changeType);//更改类型
        String changeReason = ibaUtil.getIBAValue(CtEcConstant.formAtt_IBA_Map.get(CtEcHeadInfoBo.changeReason_key));
        String changeDesc = ibaUtil.getIBAValue(CtEcConstant.formAtt_IBA_Map.get(CtEcHeadInfoBo.changeDesc_key));
        attKeyValueMap.put(CtEcHeadInfoBo.changeReason_key, changeReason==null?"":changeReason);//变更原因
        attKeyValueMap.put(CtEcHeadInfoBo.changeDesc_key, changeDesc==null?"":changeDesc);//变更描述
        if(changeType.indexOf("快速变更1")>-1){//适用场景
            attKeyValueMap.put(CtEcHeadInfoBo.applicableScene_key, CtEcProperties.getPropertyValue("quickChange1"));
        }else if(changeType.indexOf("快速变更2")>-1){
            attKeyValueMap.put(CtEcHeadInfoBo.applicableScene_key, CtEcProperties.getPropertyValue("quickChange2"));
        }else if(changeType.indexOf("快速变更3")>-1){
            attKeyValueMap.put(CtEcHeadInfoBo.applicableScene_key, CtEcProperties.getPropertyValue("quickChange3"));
        }else if(changeType.indexOf("快速变更4")>-1){
            attKeyValueMap.put(CtEcHeadInfoBo.applicableScene_key, CtEcProperties.getPropertyValue("quickChange4"));
        }
        if(!refresh){//刷新表单时不刷新申请时间
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            TimeZone timeZone = WTContext.getContext().getTimeZone();
            System.out.println("生成EC表单>>>>>>>>当前时区>>>>>"+timeZone.getDisplayName(Locale.CHINA));
            sdf.setTimeZone(timeZone);
            attKeyValueMap.put(CtEcHeadInfoBo.applyTime_key, sdf.format(new Date(changeRequest.getCreateTimestamp().getTime())));//申请时间
        }

        // 收集受影响部件及图文档
        List<String> partNumbers = new ArrayList<String>();
        List<String> docNumbers = new ArrayList<String>();
        List<String> partNumberAndNames = new ArrayList<>();
        // 受影响成品
        List<String> affectedEndItemNumbers = new ArrayList<String>();
        QueryResult changeAbles = ChangeHelper2.service.getChangeables(changeRequest);
        Object obj = null;
        WTPart tmpPart;
        WTDocument tmpDoc;
        EPMDocument tmpEpm;
        while (changeAbles.hasMoreElements()) {
            obj = changeAbles.nextElement();
            if (obj instanceof WTPart) {
                tmpPart = (WTPart) obj;
                partNumbers.add(tmpPart.getNumber());
                partNumberAndNames.add(tmpPart.getNumber()+tmpPart.getName());
                String partType = CtWTObjectUtil.getTypeIdentifier(tmpPart);
                if(partType.contains(CtEcConstant.Ct_PartType_EndPart)){
                    affectedEndItemNumbers.add(tmpPart.getNumber());
                }
            } else if (obj instanceof WTDocument) {
                tmpDoc = (WTDocument) obj;
                docNumbers.add(tmpDoc.getNumber());
            } else if (obj instanceof EPMDocument) {
                tmpEpm = (EPMDocument) obj;
                docNumbers.add(tmpEpm.getNumber());
            }
        }


        QueryResult affectedEndItems = ChangeHelper2.service.getSubjectProducts(changeRequest);
        WTPartMaster tmpPartMaster = null;
        while (affectedEndItems.hasMoreElements()) {
            obj = affectedEndItems.nextElement();
            tmpPartMaster = (WTPartMaster) obj;
            tmpPart = (WTPart) CtVersionUtil.getLatest(tmpPartMaster);
            if(!affectedEndItemNumbers.contains(tmpPart.getNumber())){
                affectedEndItemNumbers.add(tmpPart.getNumber());
            }
        }

        String productModel= CtEcLogic.getProductModel(affectedEndItemNumbers,partNumbers);
        String affectedEndParts = String.join(",", affectedEndItemNumbers);
        String affectedParts = String.join(",", partNumbers);
        String affectedDocs = String.join(",", docNumbers);
        attKeyValueMap.put(CtEcHeadInfoBo.affectedBOMs_key, affectedParts);
        attKeyValueMap.put(CtEcHeadInfoBo.affectedDocs_key, affectedDocs);
        attKeyValueMap.put(CtEcHeadInfoBo.affectedEndParts_key, affectedEndParts);
        attKeyValueMap.put(CtEcHeadInfoBo.productModel_key, productModel);
        //ECR名称拼接规则:ECR名称-物料编码+物料描述,多个用逗号隔开
        String suffix = String.join(",", partNumberAndNames);
//        attKeyValueMap.put(CtEcHeadInfoBo.ecrName_key, changeRequest.getName()+"-"+suffix);//ECR名称
        attKeyValueMap.put(CtEcHeadInfoBo.ecrName_key, changeRequest.getName());//ECR名称
        CtEcQuery query = new CtEcQuery();
        query.createHeadInfo(changeRequestId, activityKey, attKeyValueMap);
    }


    //组装Excel导入的数据
    public static void assembleData(List<CtChangeItemBo> boList,String changeRequestId,String type) throws Exception{
        String errorMsg = "";
        String viewName = type.equals("ebom")?CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        //组装准备插入的数据
        for (CtChangeItemBo changeItemBo : boList) {
            String changeType = changeItemBo.getChangeType();
            if(!CtFormatUtil.hasContent(changeType)){
                //正常情况不会进来  解析Excel已经校验过了
                throw new Exception("检测到存在变更类型为空的数据，请检查!\r\n");
            }else{
                String parentNumber = changeItemBo.getParentNumber();
                WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber, viewName);
                if(parentPart==null)parentPart=CtPartUtil.getPartByNumber(parentNumber,CtConstant.VIEW_DESIGN);
                changeItemBo.setParentNumber(parentPart.getNumber());
                changeItemBo.setParentName(parentPart.getName());
                List<WTPart> endParts = new ArrayList<>();
                getEndParts(endParts,parentPart);//获取到全部上层的成品
                //父件本身是成品 也加进去
                if(CtWTObjectUtil.getTypeIdentifier(parentPart).contains(CtEcConstant.Ct_PartType_EndPart)){
                    endParts.add(parentPart);
                }
                String endPartNumbers = endParts.stream().map(wtPart -> wtPart.getNumber()).distinct().collect(Collectors.joining(","));
                changeItemBo.setEndPartNumber(endPartNumbers);
                if("增加".equals(changeType)){
                    String childNumberAfter = changeItemBo.getChildNumberAfter();
                    WTPart childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter, viewName);
                    if(childPartAfter==null)childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter,CtConstant.VIEW_DESIGN);
                    WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, childPartAfter);
                    if(usageLink!=null){
                        errorMsg+="父件编码 -"+parentNumber+" 变更后编码 -"+childNumberAfter+"已经存在上下阶关系\r\n";
                    }
                    //变更前信息置空
                    changeItemBo.setChildNumberBefore("");
                    changeItemBo.setChildNameBefore("");
                    changeItemBo.setPriorityBefore("");
                    changeItemBo.setAmountBefore("");
                    changeItemBo.setReplaceNumberBefore("");
                    changeItemBo.setBitNumberBefore("");
                    //变更后名称根据编号带出
                    changeItemBo.setChildNumberAfter(childPartAfter.getNumber());
                    changeItemBo.setChildNameAfter(childPartAfter.getName());

                }else if("删除".equals(changeType)){
                    String childNumberBefore = changeItemBo.getChildNumberBefore();
                    WTPart childPartBefore = CtPartUtil.getPartByNumber(childNumberBefore, viewName);
                    if(childPartBefore==null)childPartBefore=CtPartUtil.getPartByNumber(childNumberBefore,CtConstant.VIEW_DESIGN);
                    WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, childPartBefore);
                    if(usageLink==null){
                        errorMsg+="父件编码 -"+parentNumber+" 变更前编码 -"+childNumberBefore+"不存在上下阶关系!\r\n";
                    }else{
                        //变更前信息自动带出
                        changeItemBo.setChildNumberBefore(childPartBefore.getNumber());
                        changeItemBo.setChildNameBefore(childPartBefore.getName());
                        IBAUtil ibaUtil = new IBAUtil(usageLink);
                        String replaceGroupPriority = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority);
                        String replaceGroup = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroup);
                        changeItemBo.setPriorityBefore(replaceGroupPriority==null?"":replaceGroupPriority);
                        changeItemBo.setReplaceNumberBefore(replaceGroup==null?"":replaceGroup);
                        changeItemBo.setAmountBefore(CtBomUtil.getBomAmout(usageLink));//数量
                        changeItemBo.setBitNumberBefore(CtBomUtil.getReferenceDesignator(usageLink));//位号
                        //变更后信息置空
                        changeItemBo.setChildNumberAfter("");
                        changeItemBo.setChildNameAfter("");
                        changeItemBo.setPriorityAfter("");
                        changeItemBo.setAmountAfter("");
                        changeItemBo.setBitNumberAfter("");
                        changeItemBo.setReplaceNumberAfter("");
                    }

                }else if("修改".equals(changeType)){
                    String childNumberBefore = changeItemBo.getChildNumberBefore();
                    String childNumberAfter = changeItemBo.getChildNumberAfter();
                    WTPart childPartBefore = CtPartUtil.getPartByNumber(childNumberBefore,viewName);
                    if(childPartBefore==null)childPartBefore = CtPartUtil.getPartByNumber(childNumberBefore,CtConstant.VIEW_DESIGN);
                    WTPart childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter, viewName);
                    if(childPartAfter==null)childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter,CtConstant.VIEW_DESIGN);
                    WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, childPartBefore);
                    if(usageLink==null){
                        errorMsg+="父件编码 -"+parentNumber+" 变更前编码 -"+childNumberBefore+"不存在上下阶关系!\r\n";
                    }else{
                        //变更前信息自动带出
                        changeItemBo.setChildNumberBefore(childPartBefore.getNumber());
                        changeItemBo.setChildNameBefore(childPartBefore.getName());
                        changeItemBo.setAmountBefore(CtBomUtil.getBomAmout(usageLink));//数量
                        changeItemBo.setBitNumberBefore(CtBomUtil.getReferenceDesignator(usageLink));//位号
                        IBAUtil ibaUtil = new IBAUtil(usageLink);
                        String replaceGroupPriority = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority);
                        String replaceGroup = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroup);
                        changeItemBo.setPriorityBefore(replaceGroupPriority==null?"":replaceGroupPriority);
                        changeItemBo.setReplaceNumberBefore(replaceGroup==null?"":replaceGroup);

                    }
                    //变更后名称根据编号带出  替代组  优先级 也带出
                    changeItemBo.setChildNumberAfter(childPartAfter.getNumber());
                    changeItemBo.setChildNameAfter(childPartAfter.getName());
                    usageLink = CtBomUtil.getUsageLink(parentPart, childPartAfter);
                    if(usageLink!=null){
                        IBAUtil ibaUtil = new IBAUtil(usageLink);
                        String replaceGroupPriority = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority);
                        String replaceGroup = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroup);
                        changeItemBo.setPriorityAfter(replaceGroupPriority==null?"":replaceGroupPriority);
                        changeItemBo.setReplaceNumberAfter(replaceGroup==null?"":replaceGroup);
                    }

                }

            }


        }
        if(errorMsg!=null&&errorMsg.length()>0){
            throw new Exception(errorMsg);
        }

    }

    //根据对象编码 返回对象名称
    public static String getChangeObjName(HashMap<String, String> dataMap) throws Exception {
        logger.debug(">>>>>>>>>>>开始校验BOM变更列表>>>>>>>>>");
        logger.debug(">>>>>>>>>>>传入参数>>>>>>>>>"+ JSON.toJSONString(dataMap));
        List<String> listStr = new ArrayList<String>();
        List<CtChangeItemBo> listBo = new ArrayList<CtChangeItemBo>();
        String id = dataMap.get("id");
        String changeRequestId = dataMap.get("changeRequestId");
        String objNumber = dataMap.get("objNumber");
        String mark = dataMap.get("mark");
        String type = dataMap.get("type");
        String viewName = "ebom".equals(type)?CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        //收集受影响对象中的部件  父件必须存在受影响对象中
        List<WTPart> AffectedParts = new ArrayList<>();
        WTChangeRequest2 changRequest = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        QueryResult changeables = ChangeHelper2.service.getChangeables(changRequest);
        while(changeables.hasMoreElements()){
            Object obj = changeables.nextElement();
            if(obj instanceof WTPart){
                WTPart part = (WTPart)obj;
                if(!AffectedParts.contains(part)){
                    AffectedParts.add(part);
                }
            }
        }
        CtEcQuery query = new CtEcQuery();
        String objName = "";
        CtChangeItemBo changeItemBo = new CtChangeItemBo();//准备更新的BO
        if(CtFormatUtil.hasContent(objNumber)){
            WTPart part = CtPartUtil.getPartByNumber(objNumber,viewName);
            logger.debug(objNumber+">>>>>>>>视图"+viewName+">>>>>"+part);
            if(part == null)part = CtPartUtil.getPartByNumber(objNumber,CtConstant.VIEW_DESIGN);
            logger.debug(objNumber+">>>>>>>>视图Design>>>>>"+part);
            if (part == null) {
                throw new WTException("请检查输入的物料编码，系统中查找不到对应的数据！");
            }
            checkPartView(viewName, part);
            objName = part.getName();
            CtChangeItemBo findChangeItem = query.getChangeItemById(id, type);//当前编辑的数据
            List<CtChangeItemBo> allChangeItems = query.getChangeItems(changeRequestId,type);//变更列表中的所有数据
            if ("childNumberBefore".equals(mark)){//当前编辑变更前物料编码
                changeItemBo.setChildNumberBefore(part.getNumber());
                changeItemBo.setChildNameBefore(part.getName());//名称自动带出
                if(findChangeItem!=null){
                    String parentNumber = findChangeItem.getParentNumber();
                    String changeType = findChangeItem.getChangeType();
                    String childNumberAfter = findChangeItem.getChildNumberAfter();
                    if(CtFormatUtil.hasContent(changeType)){
                        if("增加".equals(changeType)){
                            throw new Exception("变更类型为【"+changeType+"】时，不能填写变更前编码!");
                        }
                    }
                    if(CtFormatUtil.hasContent(parentNumber)){//如果已经填写了父项编码
                        for(CtChangeItemBo bo : allChangeItems) {
                            String boId = bo.getId();
                            String boParentNumber = bo.getParentNumber();
                            String boChildNumberBefore = bo.getChildNumberBefore();
                            //父项编码和变更前编码都重复
                            if(CtFormatUtil.hasContent(boParentNumber)&&boParentNumber.equals(parentNumber)
                                    &&CtFormatUtil.hasContent(boChildNumberBefore)&&boChildNumberBefore.equals(objNumber)
                                    &&!boId.equals(id)){
                                throw new WTException("父项编码【"+parentNumber+"】,变更前编码【"+objNumber+"】在表单中已存在，请检查！");
                            }
                        }
                        WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber,viewName);
                        WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, part);
                        if(usageLink==null){
                            throw new WTException("【" + parentNumber + "】和【" + objNumber + "】不存在上下阶关系！");
                        }
                        if(CtFormatUtil.hasContent(childNumberAfter)&&!childNumberAfter.equals(objNumber)){
                            WTPart childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter);
                            WTPartUsageLink link = CtBomUtil.getUsageLink(parentPart, childPartAfter);
                            if(link!=null) {
                                throw new WTException("父项编码【" + parentNumber + "】,变更后编码【" + childNumberAfter + "】已存在上下阶关系，变更前后料号必须一样，请检查！");
                            }
                        }
                        IBAUtil ibaUtil = new IBAUtil(usageLink);
                        String replaceNumber = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroup);
                        String priority = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority);
                        String bomRemarks = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_bomNotes);
                        changeItemBo.setPriorityBefore(priority==null?"":priority);//替代组优先级
                        changeItemBo.setReplaceNumberBefore(replaceNumber==null?"":replaceNumber);//替代组编号
                        changeItemBo.setBomRemarksBefore(bomRemarks==null?"":bomRemarks);//BOM备注
                        changeItemBo.setAmountBefore(CtBomUtil.getBomAmout(usageLink));//数量
                        changeItemBo.setBitNumberBefore(CtBomUtil.getReferenceDesignator2(usageLink));//位号
                    }
                }
            }else if ("childNumberAfter".equals(mark)){//当前编辑变更后物料编码
                changeItemBo.setChildNumberAfter(part.getNumber());
                changeItemBo.setChildNameAfter(part.getName());//名称自动带出
                if(findChangeItem!=null){
                    String parentNumber = findChangeItem.getParentNumber();
                    String changeType = findChangeItem.getChangeType();
                    String childNumberBefore = findChangeItem.getChildNumberBefore();
                    if(CtFormatUtil.hasContent(changeType)){
                        if("删除".equals(changeType)){
                            throw new Exception("变更类型为【"+changeType+"】时，不能填写变更后编码!");
                        }
                    }
                    if(CtFormatUtil.hasContent(parentNumber)){//如果已经填写了父项编码
                        for (CtChangeItemBo bo : allChangeItems) {
                            String boId = bo.getId();
                            String boParentNumber = bo.getParentNumber();
                            String boChildNumberAfter = bo.getChildNumberAfter();
                            //父项编码和变更后编码都重复
                            if(CtFormatUtil.hasContent(boParentNumber)&&boParentNumber.equals(parentNumber)
                                    &&CtFormatUtil.hasContent(boChildNumberAfter)&&boChildNumberAfter.equals(objNumber)
                                    &&!boId.equals(id)){
                                throw new WTException("父项编码【"+parentNumber+"】,变更后编码【"+objNumber+"】在表单中已存在，请检查！");
                            }
                        }
                        WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber,viewName);
                        checkBomState(parentPart,part,type);

                        WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, part);
                        if(usageLink!=null){
                            if(CtFormatUtil.hasContent(childNumberBefore)&&!childNumberBefore.equals(objNumber)){
                                throw new WTException("父项编码【"+parentNumber+"】,变更后编码【"+objNumber+"】已存在上下阶关系，变更前后料号必须一样，请检查！");

                            }
                        }

                        if(usageLink!=null){
                            IBAUtil ibaUtil = new IBAUtil(usageLink);
                            String replaceNumber = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroup);
                            String priority = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority);
                            String bomRemarks = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_bomNotes);
                            changeItemBo.setPriorityAfter(priority==null?"":priority);//替代组优先级
                            changeItemBo.setReplaceNumberAfter(replaceNumber==null?"":replaceNumber);//替代组编号
                            changeItemBo.setBomRemarksAfter(bomRemarks==null?"":bomRemarks);//BOM备注
                            changeItemBo.setAmountAfter(CtBomUtil.getBomAmout(usageLink));//数量
                            changeItemBo.setBitNumberAfter(CtBomUtil.getReferenceDesignator2(usageLink));//位号
                        }
                    }
                }

            }else if("parentNumber".equals(mark)){
                //父件必须在受影响对象中
                if(!AffectedParts.contains(part)){
                    throw new Exception("父件"+part.getNumber()+"("+viewName+")不在受影响对象中!\r\n");
                }
                changeItemBo.setParentNumber(part.getNumber());
                changeItemBo.setParentName(part.getName());
                if(findChangeItem!=null){
                    String childNumberBefore = findChangeItem.getChildNumberBefore();
                    String childNumberAfter = findChangeItem.getChildNumberAfter();
                    String changeType = findChangeItem.getChangeType();
                    if(CtFormatUtil.hasContent(childNumberBefore)){//已经填写了变更前编码
                        WTPart childPart = CtPartUtil.getPartByNumber(childNumberBefore,viewName);
                        if(childPart==null)childPart=CtPartUtil.getPartByNumber(childNumberBefore,CtConstant.VIEW_DESIGN);
                        WTPartUsageLink usageLink = CtBomUtil.getUsageLink(part, childPart);//检查是否存在link关系
                        if(usageLink==null){
                            throw new WTException("【" + objNumber + "】和【" + childNumberBefore + "】不存在上下阶关系！");
                        }
                        if(CtFormatUtil.hasContent(childNumberAfter)&&!childNumberAfter.equals(childNumberBefore)){
                            WTPart childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter);
                            WTPartUsageLink link = CtBomUtil.getUsageLink(part, childPartAfter);
                            if(link!=null) {
                                throw new WTException("父项编码【" + objNumber + "】,变更后编码【" + childNumberAfter + "】已存在上下阶关系，变更前后料号必须一样，请检查！");
                            }
                        }
                        for (CtChangeItemBo bo : allChangeItems) {
                            String boId = bo.getId();
                            String boParentNumber = bo.getParentNumber();
                            String boChildNumberBefore = bo.getChildNumberBefore();
                            //父项编码和变更前编码都重复  报错
                            if(CtFormatUtil.hasContent(boParentNumber)&&boParentNumber.equals(objNumber)
                                    &&CtFormatUtil.hasContent(boChildNumberBefore)&&boChildNumberBefore.equals(childNumberBefore)
                                    &&!boId.equals(id)){
                                throw new WTException("父项编码【"+objNumber+"】,变更前编码【"+childNumberBefore+"】在表单中已存在，请检查！");
                            }

                        }
                        IBAUtil ibaUtil = new IBAUtil(usageLink);
                        String replaceNumber = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroup);
                        String priority = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority);
                        String bomRemarks = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_bomNotes);
                        changeItemBo.setPriorityBefore(priority==null?"":priority);//替代组优先级
                        changeItemBo.setReplaceNumberBefore(replaceNumber==null?"":replaceNumber);//替代组编号
                        changeItemBo.setBomRemarksBefore(bomRemarks==null?"":bomRemarks);//BOM备注
                        changeItemBo.setAmountBefore(CtBomUtil.getBomAmout(usageLink));//数量
                        changeItemBo.setBitNumberBefore(CtBomUtil.getReferenceDesignator2(usageLink));//位号
                    }
                    if(CtFormatUtil.hasContent(childNumberAfter)){//已经填写了变更后编号
                        for (CtChangeItemBo bo : allChangeItems) {
                            String boId = bo.getId();
                            String boParentNumber = bo.getParentNumber();
                            String boChildNumberAfter = bo.getChildNumberAfter();
                            //父项编码和变更后编码都重复  报错
                            if(CtFormatUtil.hasContent(boParentNumber)&&boParentNumber.equals(objNumber)
                                    &&CtFormatUtil.hasContent(boChildNumberAfter)&&boChildNumberAfter.equals(childNumberAfter)
                                    &&!boId.equals(id)){
                                throw new WTException("父项编码【"+objNumber+"】,变更后编码【"+childNumberAfter+"】在表单中已存在，请检查！");
                            }

                        }
                        WTPart childPart = CtPartUtil.getPartByNumber(childNumberAfter,viewName);
                        if(childPart==null)childPart=CtPartUtil.getPartByNumber(childNumberAfter,CtConstant.VIEW_DESIGN);
                        checkBomState(part,childPart,type);
                        WTPartUsageLink usageLink = CtBomUtil.getUsageLink(part, childPart);//检查是否存在link关系
                        if(usageLink!=null&&"增加".equals(changeType)){
                            throw new WTException("父项编码【" + objNumber + "】和变更后编码【" + childNumberAfter + "】已经存在上下阶关系，变更类型不能是【"+changeType+"】！");
                        }
                        if(CtFormatUtil.hasContent(childNumberBefore)&&!childNumberBefore.equals(childNumberAfter)){
                            if(usageLink!=null){
                                throw new WTException("父项编码【"+objNumber+"】,变更后编码【"+childNumberAfter+"】已存在上下阶关系，变更前后料号必须一样，请检查！");
                            }
                        }
                        if(usageLink!=null){
                            IBAUtil ibaUtil = new IBAUtil(usageLink);
                            String replaceNumber = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroup);
                            String priority = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority);
                            String bomRemarks = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_bomNotes);
                            changeItemBo.setPriorityAfter(priority==null?"":priority);//替代组优先级
                            changeItemBo.setReplaceNumberAfter(replaceNumber==null?"":replaceNumber);//替代组编号
                            changeItemBo.setBomRemarksAfter(bomRemarks==null?"":bomRemarks);//BOM备注
                            changeItemBo.setAmountAfter(CtBomUtil.getBomAmout(usageLink));//数量
                            changeItemBo.setBitNumberAfter(CtBomUtil.getReferenceDesignator2(usageLink));//位号
                        }
                    }
                }
                List<WTPart> endParts = new ArrayList<>();
                getEndParts(endParts,part);//获取到全部上层的成品
                //父件本身是成品 也加进去
                if(CtWTObjectUtil.getTypeIdentifier(part).contains(CtEcConstant.Ct_PartType_EndPart)){
                    endParts.add(part);
                }
                String endPartNumbers = endParts.stream().map(wtPart -> wtPart.getNumber()).distinct().collect(Collectors.joining(","));
                changeItemBo.setEndPartNumber(endPartNumbers);

            }
        }else{
            //输入的编号为空时  自动将相关的列置空
            if ("childNumberBefore".equals(mark)){//当前编辑变更前物料编码
                changeItemBo.setChildNumberBefore("");
                changeItemBo.setChildNameBefore("");
                changeItemBo.setAmountBefore("");
                changeItemBo.setPriorityBefore("");
                changeItemBo.setReplaceNumberBefore("");
                changeItemBo.setBitNumberBefore("");
                changeItemBo.setBomRemarksBefore("");
            }else if ("childNumberAfter".equals(mark)){//当前编辑变更后物料编码
                changeItemBo.setChildNumberAfter("");
                changeItemBo.setChildNameAfter("");
                changeItemBo.setAmountAfter("");
                changeItemBo.setPriorityAfter("");
                changeItemBo.setReplaceNumberAfter("");
                changeItemBo.setBitNumberAfter("");
                changeItemBo.setBomRemarksAfter("");
            }else if("parentNumber".equals(mark)){
                changeItemBo.setParentNumber("");
                changeItemBo.setParentName("");
                changeItemBo.setAmountBefore("");
                changeItemBo.setPriorityBefore("");
                changeItemBo.setBitNumberBefore("");
                changeItemBo.setReplaceNumberBefore("");
                changeItemBo.setBomRemarksBefore("");
                changeItemBo.setEndPartNumber("");
                changeItemBo.setAmountAfter("");
                changeItemBo.setPriorityAfter("");
                changeItemBo.setBitNumberAfter("");
                changeItemBo.setReplaceNumberAfter("");
                changeItemBo.setBomRemarksAfter("");
            }
        }

        changeItemBo.setId(id);
        changeItemBo.setChangeRequestId(changeRequestId);
        query.saveChangeObjInfo(changeItemBo, mark,type);
        return objName;
    }

    /**
     * 部件类型为成品或半成品  必须是指定视图
     * @param viewName
     * @param part
     * @throws Exception
     */
    public static void checkPartView(String viewName, WTPart part) throws Exception {
        checkPartView(viewName, part,true);
    }

    /**
     * 部件类型为成品或半成品  必须是指定视图
     * @param viewName
     * @param part
     * @param throwException 是否抛异常  不抛用字符串存储异常信息
     * @throws Exception
     */
    public static String checkPartView(String viewName, WTPart part,boolean throwException) throws Exception {
        String errorMsg = "";
        String partType = CtWTObjectUtil.getTypeIdentifier(part);
        //如果是成品半成品判断视图
        if(partType.contains(CtEcConstant.Ct_PartType_EndPart)||partType.contains(CtEcConstant.Ct_PartType_HalfEndPart)){
            if(!part.getViewName().equals(viewName)){
                if(throwException){
                    throw new Exception("系统中不存在编码为"+part.getNumber()+",视图为"+viewName+"的部件!");
                }else{
                    errorMsg += "系统中不存在编码为"+part.getNumber()+",视图为"+viewName+"的部件!\r\n";
                }

            }
        }
        return errorMsg;
    }


    /**
     * 根据部件查找所有上层成品  查找多层
     * @return
     */
    public static List<WTPart> getEndParts(List<WTPart> parts,WTPart part) throws Exception {
        List<WTPart> parentParts = CtBomUtil.getParentParts(part);
        for (WTPart wtPart : parentParts) {
            if(CtWTObjectUtil.getTypeIdentifier(wtPart).contains(CtEcConstant.Ct_PartType_EndPart)){
                 parts.add(wtPart);
            }
            getEndParts(parts,wtPart);
        }
        return parentParts;
    }

    /**
     * 变更前的数据查询
     * @param usageLink
     * @param listBo
     * @return
     * @throws Exception
     */
    public static String genPartAttribute(WTPartUsageLink usageLink,List<CtChangeItemBo> listBo) throws Exception {

        StringBuilder sb = new StringBuilder(); // 准备做判断的数据
        IBAUtil ibaUtil = new IBAUtil(usageLink);
        WTPartMaster partMaster = usageLink.getUses();
        WTPart childPart = (WTPart) CtVersionUtil.getLatest(partMaster);
        String childPartNumber = childPart.getNumber();
        IBAUtil ibaPart = new IBAUtil(childPart);
        // 编码，名称，位号，数量，替代料编码，优先级
        // 位号
        String bitNumber  = CtBomUtil.getReferenceDesignator(usageLink);
        //数量
        Quantity quantity = usageLink.getQuantity();
        double bomAmount = quantity.getAmount();
        //替代料编码
        String replaceNumber = "";//替代料编码 TODO 替代料编码 待修改
//      List<String> substituteParts = CtBomUtil.getSubstituteParts(usageLink);
        // 优先级 TODO IBA属性值  待修改
        String priority = ibaUtil.getIBAValue("priority");
        CtChangeItemBo bo = new CtChangeItemBo();
        bo.setChildNumberBefore(childPartNumber);// 编码
        bo.setChildNameBefore(childPart.getName());//名称
        bo.setBitNumberBefore(bitNumber);// 位号
        bo.setAmountBefore(bomAmount+"");//数量
        bo.setReplaceNumberBefore(replaceNumber);//替代料编码
        bo.setPriorityBefore(priority);// 优先级
        if(listBo != null) { // 目前只有excel导入时候是空 2020-05-22
            listBo.add(bo);
        }
        sb.append(childPartNumber);// 编码
        sb.append(childPart.getName());//名称
        sb.append(bitNumber);// 位号
        sb.append(bomAmount);//数量
        sb.append(replaceNumber);//替代料编码
        sb.append(priority);// 优先级
        return sb.toString();
    }




    /**
     * 检验更改类型
     * @param id
     * @param key
     * @param value
     * @param type
     */
    public static void checkChangeType(String id, String key, String value, String type) throws Exception {

        CtEcQuery query = new CtEcQuery();
        CtChangeItemBo changeItemBo = query.getChangeItemById(id, type);
        if(changeItemBo==null){//正常不会进来
            return;
        }
        String viewName = "ebom".equals(type)?CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        String parentNumber = changeItemBo.getParentNumber();
        if(!CtFormatUtil.hasContent(parentNumber)){
            throw new Exception("请先填写父项编码!");
        }
        WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber,viewName);
        if(parentPart==null){
            parentPart = CtPartUtil.getPartByNumber(parentNumber,CtConstant.VIEW_DESIGN);
        }
        String childNumberBefore = changeItemBo.getChildNumberBefore();
        String childNumberAfter = changeItemBo.getChildNumberAfter();
        if("增加".equals(value)){
            if(CtFormatUtil.hasContent(childNumberBefore)){
                throw new Exception("变更类型为【"+value+"】时，不能填写变更前物料编码!");
            }
            if(!CtFormatUtil.hasContent(childNumberAfter)){
                throw new Exception("变更类型为【"+value+"】时，必须先填写变更后物料编码!");
            }else{
                WTPart childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter,viewName);
                if(childPartAfter==null){
                    childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter,CtConstant.VIEW_DESIGN);
                }
                WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, childPartAfter);
                if(usageLink!=null){
                    throw new Exception("父项编码>>"+parentNumber+"变更后编码>>"+childNumberAfter+"已经存在上下级关系,变更类型不能为【增加】!");
                }
            }
        }else if("删除".equals(value)){
            if(!CtFormatUtil.hasContent(childNumberBefore)){
                throw new Exception("变更类型为【"+value+"】时，必须先填写变更前物料编码!");
            }else{
                WTPart childPartBefore = CtPartUtil.getPartByNumber(childNumberBefore,viewName);
                if(childPartBefore==null){
                    childPartBefore = CtPartUtil.getPartByNumber(childNumberBefore,CtConstant.VIEW_DESIGN);
                }
                WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, childPartBefore);
                if(usageLink==null){
                    throw new Exception("父项编码>>"+parentNumber+"变更前编码>>"+childNumberAfter+"不存在上下级关系,变更类型不能为【删除】!");
                }
            }
            if(CtFormatUtil.hasContent(childNumberAfter)){
                throw new Exception("变更类型为【"+value+"】时，不能填写变更后物料编码!");
            }
        }else if("修改".equals(value)){
            if(!CtFormatUtil.hasContent(childNumberBefore)||!CtFormatUtil.hasContent(childNumberAfter)){
                throw new Exception("变更类型为【"+value+"】时，必须先填写变更前、后物料编码!");
            }

        }

    }


    /**
     * 位号校验
     * @param id
     * @param key
     * @param value
     * @param type
     * @param changeRequestId
     * @throws Exception
     */
    public static void checkBitNumber(String id, String key, String value,String type,String changeRequestId) throws Exception {
        if(!CtFormatUtil.hasContent(value))return;
        StringBuffer errorMsg = new StringBuffer();
        CtEcQuery query = new CtEcQuery();
        CtChangeItemBo changeItemBo = query.getChangeItemById(id, type);
        if(changeItemBo==null){//正常不会进来
            return;
        }
        String childNumberAfter = changeItemBo.getChildNumberAfter();
        String parentNumber = changeItemBo.getParentNumber();
        if(!CtFormatUtil.hasContent(childNumberAfter)){
            errorMsg.append("请先填写正确的变更后物料编码!\r\n");
        }
        if(!CtFormatUtil.hasContent(parentNumber)){
            errorMsg.append("请先填写正确的父项编码!\r\n");
        }
        if(errorMsg.length()>0){
            throw new Exception(errorMsg.toString());
        }
        List<String> list = new ArrayList<String>(); // 页面输入的位号
        String num = CtCheckFitPlaceTool.checkFitPlace2NumAndList(value, list); // 第一步：检测输入的是否有重复的位号
        List<String> list1 = CtCheckFitPlaceTool.getCheckData(list);
        if(list1 != null && list1.size()>0) {
            throw new WTException("检测输入有重复位号：\r\n"+list1.toString());
        }else {
            List<CtChangeItemBo> listBo = query.getChangeItems(changeRequestId,type);
            StringBuffer sb = new StringBuffer();
            List<String> deleList = new ArrayList<>();//记录父项编码一样  变更前物料编码
            for(CtChangeItemBo bo:listBo) {//表单上父项编码一样  比较变更后位号是否有重复
                String boId = bo.getId();
                String boParentNumber = bo.getParentNumber();
                String boChildNumberBefore = bo.getChildNumberBefore();
                deleList.add(boChildNumberBefore);
                if(parentNumber.equals(boParentNumber)){
                    String newFitPlace = bo.getBitNumberAfter();
                    if(CtFormatUtil.hasContent(newFitPlace) && !id.equals(boId)) {
                        if(CtFormatUtil.hasContent(sb)) {
                            sb.append(",");
                        }
                        sb.append(newFitPlace);
                    }
                }
            }
            List<String> listOld = new ArrayList<String>();
            CtCheckFitPlaceTool.checkFitPlace2NumAndList(sb.toString(), listOld);// 第二步：检测输入的位号与表单中存在的位号是否有重复
            List<String> listCheck = CtCheckFitPlaceTool.getIntersection(listOld, list);
            if(listCheck != null && listCheck.size()>0) {
                throw new WTException("检测到表单中有重复位号：\r\n"+listCheck.toString());
            }else {
                checkBomFitPlace(parentNumber,deleList,list,type);// 第三步：检测输入的位号与系统BOM中存在的位号是否有重复
            }
        }

    }

    /**
     * 位号校验  表单位号和系统中的位号校验
     * @param parentNumber   父项编号
     * @param deleList       表单中变更前子项编码
     * @param list           表单填写位号
     * @param type           BOM变更内容表格类型
     * @throws Exception
     */
    public static void checkBomFitPlace(String parentNumber,List<String> deleList,List<String> list,String type) throws Exception {
        String viewName = "ebom".equals(type)?CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        WTPart fatherPart = CtPartUtil.getPartByNumber(parentNumber,viewName);// 获取父类的部件
        if(fatherPart != null) {
            List<WTPart> returnList = CtBomUtil.getPartsInBOMByView(fatherPart,null);  // 当前阶层的子料
            String errorMes = "";
            for(WTPart sonPart : returnList) {
                if(deleList.contains(sonPart.getNumber())) {
                    continue;// 过滤表单上变更前物料
                }
                WTPartUsageLink usageLink = CtBomUtil.getUsageLink(fatherPart, sonPart);
                if(usageLink != null) {
                    String fitPlace  = CtBomUtil.getReferenceDesignator(usageLink);
                    StringBuffer sb = new StringBuffer(); // 表单中的List
                    if(CtFormatUtil.hasContent(sb)) {
                        sb.delete(0,sb.length()); // 清空
                    }
                    if(CtFormatUtil.hasContent(fitPlace)) {
                        if(CtFormatUtil.hasContent(sb)) {
                            sb.append(",");
                        }
                        sb.append(fitPlace);
                    }
                    List<String> listOld = new ArrayList<String>();
                    CtCheckFitPlaceTool.checkFitPlace2NumAndList(sb.toString(), listOld); // 将系统中的bom下的某颗料号下的位号取出
                    List<String> listCheck = CtCheckFitPlaceTool.getIntersection(listOld, list);
                    if(listCheck != null && listCheck.size()>0) { // 说明有重复
                        errorMes +="位号与系统BOM【"+parentNumber+"】中的【"+sonPart.getNumber()+"】料号的"+listCheck.toString()+"重复！\r\n";
                    }
                }
            }
            if (CtFormatUtil.hasContent(errorMes)) {
                throw new WTException("检测到:\r\n"+errorMes);
            }
        }

    }

    public static void checkAffectData(List affectData, WTChangeRequest2 changeRequest) throws Exception {
        IBAUtil ibaUtil = new IBAUtil(changeRequest);
        String changeType = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_changeType);
        if(!CtFormatUtil.hasContent(changeType)){
            throw new Exception("属性【更改类型】为空!\r\n") ;
        }
        if(changeType.indexOf("快速变更1")>-1){
            for (Object obj : affectData) {
                if(!(obj instanceof WTPart)){
                    throw new Exception("快速变更（场景1）只能添加E视图物料!\r\n");
                }else{
                    WTPart part = (WTPart)obj;
                    if(part.getNumber().startsWith("3")){
                       // errorInfo+="快速变更（场景1）不能添加3开头的物料!\r\n";
                    }
                    String viewName = part.getViewName();
                    if(!viewName.equals(CtConstant.VIEW_DESIGN)){
                        throw new Exception("快速变更（场景1）只能添加E视图物料!\r\n");
                    }
                }
            }
        }else if(changeType.indexOf("快速变更2")>-1){
            for (Object obj : affectData) {
                if(!(obj instanceof WTDocument)&&!(obj instanceof EPMDocument)){
                    throw new Exception("快速变更（场景2）只能添加文档,图档!\r\n");
                }
            }
        }else if(changeType.indexOf("快速变更3")>-1){
            for (Object obj : affectData) {
                if(!(obj instanceof WTPart)){
                    throw new Exception("快速变更（场景3）只能添加非1,4开头的物料!\r\n");
                }else{
                    WTPart part = (WTPart)obj;
                    if(part.getNumber().startsWith("1")||part.getNumber().startsWith("4")){
                        throw new Exception("快速变更（场景3）只能添加非1,4开头的物料!\r\n");
                    }
                }
            }
        }else if(changeType.indexOf("快速变更4")>-1){
            for (Object obj : affectData) {
                if(!(obj instanceof WTPart)){
                    throw new Exception("快速变更（场景4）只能添加M视图物料!\r\n");
                }else{
                    WTPart part = (WTPart)obj;
                    String viewName = part.getViewName();
                    if(!viewName.equals(CtConstant.VIEW_MANUFACTURING)){
                        throw new Exception("快速变更（场景4）只能添加M视图物料!\r\n");
                    }
                }
            }
        }

        List<EPMDocument> affectEpmDoc = new ArrayList();//存储EPM文档对象
        List<String> partNumbers = new ArrayList<>();//存储Design视图的部件编号(EPM只关联Design视图)
        for (Object affectDatum : affectData) {
            if (affectDatum instanceof WTPart) {
                WTPart part = (WTPart) affectDatum;
                if(part.getViewName().equals(CtConstant.VIEW_DESIGN)){
                    partNumbers.add(part.getNumber());
                }
            } else if (affectDatum instanceof EPMDocument) {
                affectEpmDoc.add((EPMDocument) affectDatum);
            }
        }


        if (!changeType.contains("快速变更2")) {
            String errorMsg = "";
            for (EPMDocument epmDoc : affectEpmDoc) {
                QueryResult queryResult = PersistenceHelper.manager.navigate(epmDoc, EPMBuildRule.BUILD_TARGET_ROLE,
                        EPMBuildRule.class, false);
                while (queryResult.hasMoreElements()){
                    EPMBuildRule epmBuildRule = (EPMBuildRule) queryResult.nextElement();
                    Persistable persistable = epmBuildRule.getRoleBObject();
                    if (!(persistable instanceof WTPart)) continue;
                    WTPart part = (WTPart) persistable;
                    if(!partNumbers.contains(part.getNumber())){
                        errorMsg+=" EPM文档"+epmDoc.getNumber()+"关联的物料"+part.getIdentity()+"不在受影响对象中!\r\n";
                    }
                }
            }
            if (CtFormatUtil.hasContent(errorMsg)) {
                throw new Exception(errorMsg);
            }
        }
    }


    /**
     * 解析导入变更导入表单EXCEL的数据
     * @param file
     * @param sheetIndex
     * @param rowIndex
     * @param type bom类型
     * @return
     * @throws Exception
     */
    public LinkedList<List<String>> parse(File file, Integer sheetIndex, Integer rowIndex,String changeRequestId,String type) throws Exception{
        String errorMsg="";
        String viewName = "ebom".equals(type)?CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        Workbook workbook = CtExcelReadUtil.readExcel(file.getAbsolutePath(), new FileInputStream(file));
        Sheet sheet = workbook.getSheetAt(sheetIndex);
        int rowCount = sheet.getPhysicalNumberOfRows(); // 总行数
        int cellCount = sheet.getRow(0).getPhysicalNumberOfCells(); // 总列数
        int i =rowIndex; // 是否包含表头
        LinkedList<List<String>> result = new LinkedList<List<String>>();
        HashMap<String, String> hashOld = new HashMap<String, String>(); //父项编码@@@变更前编码
        HashMap<String, String> hashNew = new HashMap<String, String>(); //父项编码@@@变更后编码

        //收集受影响对象中的部件  父件必须存在受影响对象中
        List<WTPart> AffectedParts = new ArrayList<>();
        WTChangeRequest2 changRequest = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        QueryResult changeables = ChangeHelper2.service.getChangeables(changRequest);
        while(changeables.hasMoreElements()){
            Object obj = changeables.nextElement();
            if(obj instanceof WTPart){
                WTPart part = (WTPart)obj;
                if(!AffectedParts.contains(part)){
                    AffectedParts.add(part);
                }
            }
        }
        for (; i <= rowCount; i++) {
            List<String> cellResult = new ArrayList<String>();
            int z=0;
            for (int j = 0; j < cellCount; j++) {
                String res = CtExcelReadUtil.getCellValue(sheet, i, j);
                if(!CtFormatUtil.hasContent(res)) {
                    z++;
                }
                cellResult.add(res);
            }
            if(z != cellCount) { // 所有列为空才会不进入这里
                if(!cellResult.isEmpty()) {
                    String changeType = cellResult.get(15);//第16列为变更类型
                    int row = i+1;
                    if(!CtFormatUtil.hasContent(changeType)) {
                        errorMsg+="第"+row+"行- 变更类型 不能为空 \r\n";
                    }else {
                        if(!CtEcConstant.changeType.contains(changeType)) {
                            errorMsg+="第"+row+"行- 变更类型 格式不对，不在【"+CtEcConstant.changeType+"】之中\r\n";
                        }
                    }

                    String parentNumber = cellResult.get(1);//第2列为父项编码
                    if(!CtFormatUtil.hasContent(parentNumber)){
                        errorMsg+="第"+row+"行- 父项编码 不能为空 \r\n";
                    }else{
                        WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber,viewName);
                        if(parentPart == null)parentPart = CtPartUtil.getPartByNumber(parentNumber,CtConstant.VIEW_DESIGN);
                        if(parentPart == null){
                            errorMsg+="第"+row+"行- 父项编码"+parentNumber+"系统中不存在\r\n";
                        }
                        String checkInfo = checkPartView(viewName, parentPart,false);
                        if(CtFormatUtil.hasContent(checkInfo)){
                            errorMsg+="第"+row+"行- 父项编码填写有误:"+checkInfo;
                        }
                        if(!AffectedParts.contains(parentPart)){
                            errorMsg+="第"+row+"行- 父项编码:"+parentNumber+"("+viewName+")不在受影响对象中\r\n";
                        }
                    }

                    //变更类型为新增
                    if(CtFormatUtil.hasContent(changeType) && ("增加".equals(changeType))) {
                        String orgObjNumber = cellResult.get(3);//第4列为更改前物料编码
                        if(CtFormatUtil.hasContent(orgObjNumber)) {
                            errorMsg+="第"+row+"行- 变更前编码 不能填写 \r\n";
                        }
                        String newObjNumber = cellResult.get(9);//第10列为更改后物料编码
                        if(!CtFormatUtil.hasContent(newObjNumber)) {
                            errorMsg+="第"+row+"行- 变更后编码 不能为空 \r\n";
                        }else {
                            WTPart newPart = CtPartUtil.getPartByNumber(newObjNumber,viewName);
                            if(newPart == null)newPart = CtPartUtil.getPartByNumber(newObjNumber,CtConstant.VIEW_DESIGN);
                            if(newPart == null){
                                errorMsg+="第"+row+"行- 变更后编码"+parentNumber+"系统中不存在\r\n";
                            }
                            String checkInfo = checkPartView(viewName, newPart,false);
                            if(CtFormatUtil.hasContent(checkInfo)){
                                errorMsg+="第"+row+"行- 变更后编码填写有误:"+checkInfo;
                            }
                            if(CtFormatUtil.hasContent(parentNumber)){
                                String jude = hashNew.get(parentNumber+"@@@"+newObjNumber);
                                if(CtFormatUtil.hasContent(jude)) {
                                    errorMsg+="第"+row+"行- 父项编码"+parentNumber+"变更后编码"+newObjNumber+"与第"+jude+"行重复 \r\n";
                                }else {
                                    hashNew.put(parentNumber+"@@@"+newObjNumber, row+"");
                                }
                            }
                        }

                        if(!CtFormatUtil.hasContent(cellResult.get(12))) {//第13列为更改后数量
                            errorMsg+="第"+row+"行- 变更后数量 不能为空 \r\n";
                        }
                    }else if(CtFormatUtil.hasContent(changeType) && ("删除".equals(changeType) )) {
                        //变更类型为删除
                        String orgObjNumber = cellResult.get(3);
                        if(!CtFormatUtil.hasContent(orgObjNumber)) {
                            errorMsg+="第"+row+"行- 变更前编码 不能为空 \r\n";
                        }else {
                            WTPart oldPart = CtPartUtil.getPartByNumber(orgObjNumber,viewName);
                            if(oldPart == null)oldPart = CtPartUtil.getPartByNumber(orgObjNumber,CtConstant.VIEW_DESIGN);
                            if(oldPart == null){
                                errorMsg+="第"+row+"行- 变更前编码"+parentNumber+"系统中不存在\r\n";
                            }
                            String checkInfo = checkPartView(viewName, oldPart,false);
                            if(CtFormatUtil.hasContent(checkInfo)){
                                errorMsg+="第"+row+"行- 变更前编码填写有误:"+checkInfo;
                            }
                            if(CtFormatUtil.hasContent(parentNumber)) {
                                String jude = hashOld.get(parentNumber+"@@@"+orgObjNumber);
                                if (CtFormatUtil.hasContent(jude)) {
                                    errorMsg += "第" + row + "行- 父项编码"+parentNumber+"变更前编码" + orgObjNumber + "与第" + jude + "行重复 \r\n";
                                } else {
                                    hashOld.put(parentNumber+"@@@"+orgObjNumber, row + "");
                                }
                            }
                        }
                        String newObjNumber = cellResult.get(9);
                        if(CtFormatUtil.hasContent(newObjNumber)) {
                            errorMsg+="第"+row+"行- 变更后编码 不能填写 \r\n";
                        }
                    }else if(CtFormatUtil.hasContent(changeType) && ("修改".equals(changeType))) {
                        // 变更类型为修改
                        String orgObjNumber = cellResult.get(3);
                        if(!CtFormatUtil.hasContent(orgObjNumber)) {
                            errorMsg+="第"+row+"行- 变更前编码 不能为空 \r\n";
                        }else {
                            WTPart oldPart = CtPartUtil.getPartByNumber(orgObjNumber,viewName);
                            if(oldPart == null)oldPart = CtPartUtil.getPartByNumber(orgObjNumber,CtConstant.VIEW_DESIGN);
                            if(oldPart == null){
                                errorMsg+="第"+row+"行- 变更前编码"+parentNumber+"系统中不存在\r\n";
                            }
                            String checkInfo = checkPartView(viewName, oldPart,false);
                            if(CtFormatUtil.hasContent(checkInfo)){
                                errorMsg+="第"+row+"行- 变更前编码填写有误:"+checkInfo;
                            }
                            if(CtFormatUtil.hasContent(parentNumber)){
                                String jude = hashOld.get(parentNumber+"@@@"+orgObjNumber);
                                if(CtFormatUtil.hasContent(jude)) {
                                    errorMsg+="第"+row+"行- 父项编码"+parentNumber+"变更前编码"+orgObjNumber+"与第"+jude+"行重复 \r\n";
                                }else {
                                    hashOld.put(parentNumber+"@@@"+orgObjNumber, row+"");
                                }
                            }

                        }
                        String newObjNumber = cellResult.get(9);
                        if(!CtFormatUtil.hasContent(newObjNumber)) {
                            errorMsg+="第"+row+"行- 变更后编码 不能为空 \r\n";
                        }else {
                            WTPart newPart = CtPartUtil.getPartByNumber(newObjNumber,viewName);
                            if(newPart == null)newPart = CtPartUtil.getPartByNumber(newObjNumber,CtConstant.VIEW_DESIGN);
                            if(newPart == null){
                                errorMsg+="第"+row+"行- 变更后编码"+parentNumber+"系统中不存在\r\n";
                            }
                            String checkInfo = checkPartView(viewName, newPart,false);
                            if(CtFormatUtil.hasContent(checkInfo)){
                                errorMsg+="第"+row+"行- 变更后编码填写有误:"+checkInfo;
                            }
                            if(CtFormatUtil.hasContent(parentNumber)){
                                String jude = hashNew.get(parentNumber+"@@@"+newObjNumber);
                                if(CtFormatUtil.hasContent(jude)) {
                                    errorMsg+="第"+row+"行- 父项编码"+parentNumber+"变更后编码"+newObjNumber+"与第"+jude+"行重复 \r\n";
                                }else {
                                    hashNew.put(parentNumber+"@@@"+newObjNumber, row+"");
                                }
                            }
                        }
                        if(!CtFormatUtil.hasContent(cellResult.get(12))) {
                            errorMsg+="第"+row+"行- 变更后数量 不能为空 \r\n";
                        }
                    }
                }
                result.add(cellResult);
            }
        }

        if(CtFormatUtil.hasContent(errorMsg)) {
            throw new Exception(errorMsg);
        }
        return result;
    }



    /**
     * 获取产品型号  根据受影响成品IBA属性获取  多个用逗号分割
     * @param affectedEndItemNumbers
     * @param partNumbers
     * @return
     * @throws Exception
     */
    public static String getProductModel(List<String> affectedEndItemNumbers, List<String> partNumbers) throws Exception{
        String productModel="";
        if(CtFormatUtil.hasContent(affectedEndItemNumbers)) {
            for(String affectedEndItemNumber:affectedEndItemNumbers) {
                WTPart part = CtPartUtil.getPartByNumber(affectedEndItemNumber);
                IBAUtil ibaUtil2 = new IBAUtil(part);
                String ibaValue = ibaUtil2.getIBAValue(CtEcConstant.Ct_IBA_productModel);
                if(CtFormatUtil.hasContent(ibaValue)) {
                    productModel+=ibaValue+",";
                }
            }
        }else {
            for(String partNumber:partNumbers) {
                WTPart part = CtPartUtil.getPartByNumber(partNumber);
                IBAUtil ibaUtil2 = new IBAUtil(part);
                String ibaValue = ibaUtil2.getIBAValue(CtEcConstant.Ct_IBA_productModel);
                if(CtFormatUtil.hasContent(ibaValue)) {
                    productModel+=ibaValue+",";
                }
            }
        }

        if (productModel.contains(",")) {
            productModel = productModel.substring(0,productModel.lastIndexOf(","));
        }
        return productModel;
    }


    public static String getFileNameAndUpload(String temppath, HttpServletRequest request) throws Exception {
        String fileName = "";
        File fpath = new File(temppath);
        if (!fpath.exists()) {
            InetAddress inetAddress = InetAddress.getLocalHost();
            String host = inetAddress.getHostName(); // 获取本地的主机名
            if (!host.contains("tan") && !host.contains("plmlocal")) {
                Runtime.getRuntime().exec("chmod 777 -R " + temppath);
            }
            fpath.getParentFile().mkdirs();//创建父级文件路径
            fpath.mkdirs();//创建文件
        }
        // 定时4小时清理文件
//		long delete = 4 * 3600*1000;
//		CtFileUtil.deleteFileByTime(fpath, delete);// 4小时删除掉
        deleteFile(fpath);
        File file = null;
        DiskFileItemFactory fac = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(fac);
        List<FileItem> fileItems = new ArrayList<FileItem>();
        fileItems = upload.parseRequest(request);// 获取附件
        Iterator<FileItem> it = fileItems.iterator();
        while (it.hasNext()) {
            FileItem item = it.next();
            fileName = item.getName();
            File tFile = new File(fileName); // 借助此File获得不带本地路径的文件名
            fileName = tFile.getName();
            tFile = null; // 释放
            file = new File(temppath + fileName);
            item.write(file);
        }
        return fileName;
    }
    public static void deleteFile(File file) {
        if (file.exists()) {// 判断文件是否存在
            if (file.isFile()) {// 判断是否是文件
                file.delete();// 删除文件
            } else if (file.isDirectory()) {// 否则如果它是一个目录
                File[] files = file.listFiles();// 声明目录下所有的文件 files[];
                for (int i = 0; i < files.length; i++) {// 遍历目录下所有的文件
                    deleteFile(files[i]);// 把每个文件用这个方法进行迭代
                }
//					file.delete();// 删除文件夹
            }
        } else {
            System.out.println(file.getAbsolutePath() + "====所删除的文件不存在");
        }
    }

    // *********************开始*****上传*下载*删除附件*********************************//
    /**
     * 上传本地附件至文档附件
     * @param localFile
     * @param changeRequestId
     * @throws Exception
     */
    public String uploadFiles(File localFile,String changeRequestId,String tetx_name,String node)
            throws Exception {
        String docUrl ="";
        ReferenceFactory rf = new ReferenceFactory();
		WTChangeRequest2 request = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        //设置主内容
        ApplicationData appData = ApplicationData.newApplicationData(request);
        appData.setRole(ContentRoleType.SECONDARY);// 附件位置
        appData = ContentServerHelper.service.updateContent(request, appData, localFile.getAbsolutePath());
        appData = (ApplicationData) PersistenceHelper.manager.save(appData);
//		appData = (ApplicationData)PersistenceHelper.manager.refresh(appData);
        String fileNameAppOld = appData.getFileName();
//		String fileName = fileNameApp.substring(0, fileNameApp.lastIndexOf(".")); // 获取名称当文档名称
//		docUrl = CtFormatUtil.getURL(document, fileNameApp);
//		String fileNameApp = fileNameAppOld.replaceAll("\\+", "%2B"); // 特殊字符处理
        String fileNameApp = urlStr2Ascii(fileNameAppOld); // 特殊字符处理

        docUrl = "<a href=\"/Windchill/ptc1/ec/downLoadDoc?number=" + changeRequestId +"&fileName="+fileNameApp+"\" title=\"点击下载\" target=\"_blank\" >" + fileNameApp + "</a>";
        docUrl = docUrl+" <a title='删除该附件' href='javascript:;' class =\""+node+"\" style ='color:red;text-decoration:none;' onclick='deleteFilefield(\""+changeRequestId+"\",\""+fileNameAppOld+"\",\""+tetx_name+"\",\""+node+"\")'>☒</a>";
//		docUrl = "<span style ='border:1px solid #0000CC'>"+docUrl+"</span>";
        return docUrl;
    }
    /**
     * 删除文档附件
     * @param changeRequestId
     * @throws Exception
     */
    public void deleteFiles(String changeRequestId,String fileName)throws Exception {
//		WTChangeRequest2 request = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        ReferenceFactory rf = new ReferenceFactory();
        WTChangeRequest2 request = (WTChangeRequest2) rf.getReference(changeRequestId).getObject();
        // 单个主要内容  ContentRoleType.PRIMARY  附件 ContentRoleType.SECONDARY
        QueryResult qr = ContentHelper.service.getContentsByRole(request, ContentRoleType.SECONDARY);
        while(qr !=null && qr.hasMoreElements()){
            ContentItem item = (ContentItem) qr.nextElement();
            if (item instanceof ApplicationData) {
                ApplicationData appData = (ApplicationData)item;
                System.out.println("Attachment File: " + appData.getFileName());
                String appDataFileName =appData.getFileName();
                if(CtFormatUtil.hasContent(appDataFileName) && appDataFileName.equals(fileName)) {
                    appData = (ApplicationData)PersistenceHelper.manager.delete(appData);
                }
            }
        }
        request = (WTChangeRequest2)PersistenceHelper.manager.refresh(request);
    }

    public ApplicationData getApplicationData(String changeRequestId,String fileName) throws Exception {
        ReferenceFactory rf = new ReferenceFactory();
        WTChangeRequest2 request = (WTChangeRequest2) rf.getReference(changeRequestId).getObject();
        if(request != null) {
            // 单个主要内容  ContentRoleType.PRIMARY  附件 ContentRoleType.SECONDARY
            QueryResult qr = ContentHelper.service.getContentsByRole(request, ContentRoleType.SECONDARY);
            while(qr !=null && qr.hasMoreElements()){
                ContentItem item = (ContentItem) qr.nextElement();
                if (item instanceof ApplicationData) {
                    ApplicationData appData = (ApplicationData)item;
                    System.out.println("Attachment File: " + appData.getFileName());
                    String appDataFileName =appData.getFileName();
                    if(CtFormatUtil.hasContent(appDataFileName) && appDataFileName.equals(fileName)) {
                        return appData;
                    }
                }
            }
        }
        return null;
    }

    /**
     * url特殊字符转义
     * 文件名不支持如下字符：\ / : * ? " < > | 故无需转换
     * @param strName
     * @return
     */
    public static String urlStr2Ascii(String strName) {
        strName = strName.replaceAll("%", "%25"); // 特殊字符处理
        strName = strName.replaceAll("\\+", "%2B"); // 特殊字符处理
        strName = strName.replaceAll("\\?", "%3F"); // 特殊字符处理
        strName = strName.replaceAll("#", "%23"); // 特殊字符处理
        strName = strName.replaceAll("&", "%26"); // 特殊字符处理
        strName = strName.replaceAll("/", "%2F"); // 特殊字符处理
        strName = strName.replaceAll("=", "%3D"); // 特殊字符处理
        return strName;
    }

    /**
     * 自动创建变更通告
     *
     * @param vrChangeRequestId
     */
    public static void autoCreateECN(String vrChangeRequestId) throws Exception {
        ReferenceFactory rf = new ReferenceFactory();
        WTChangeRequest2 changeRequest = (WTChangeRequest2) rf.getReference(vrChangeRequestId).getObject();

        Ownership ownerShip = new Ownership();
        ownerShip.setOwner(changeRequest.getModifier());

        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(changeRequest.getCreatorName());//改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);//放大权限
        try{
            // **********创建ECN***************开始
            PersistableAdapter ecnObj = new PersistableAdapter(CtEcConstant.Ct_EcnType_CtECN, null, null);
            ecnObj.load("name");
            ecnObj.set("name", changeRequest.getName());//名称，同变更请求名称
            WTChangeOrder2 ecn = (WTChangeOrder2) ecnObj.apply();

            //ecn的 folder与ECR保持一致
            String folderPath = changeRequest.getFolderPath();
            String exactFolder = folderPath.substring(0,folderPath.lastIndexOf(changeRequest.getName())-1);//去除路径中变更名称
            System.out.println(">>>>创建ECN====="+exactFolder);
            Folder folder = null;
            try{
                folder = FolderHelper.service.getFolder(
                        exactFolder, changeRequest.getContainerReference());
            }catch(FolderNotFoundException e){
                e.printStackTrace();
                folder=FolderHelper.getFolder(changeRequest);
            }
            
            FolderHelper.assignFolder(ecn, folder);

            // 设置属性
            ecn.setContainer(changeRequest.getContainer());// 容器，同变更请求
            ecn.setDescription(changeRequest.getDescription());// 变更原因，同变更请求
            ecn.setChangeNoticeComplexity(ChangeNoticeComplexity.BASIC); // 复杂性
            if (CtFormatUtil.hasContent(changeRequest.getNeedDate())) {
                ecn.setNeedDate(changeRequest.getNeedDate()); // 需要日期，同变更请求
            }
            LifeCycleServerHelper.setState(ecn, State.toState("OPEN")); // 设置状态为“开启的”

            ecn = (WTChangeOrder2) ChangeHelper2.service.saveChangeOrder(changeRequest, ecn);

            // **********创建ECA***************开始

            // 复制变更请求的受影响对象到ECA中
            QueryResult qr = ChangeHelper2.service.getChangeables(changeRequest);
            //EBOM更改任务
            Vector<Persistable> affectedEBomList = new Vector<Persistable>();
            //MBOM更改任务
            Vector<Persistable> affectedMBomList = new Vector<Persistable>();
            //SIP更改任务
            Vector<Persistable> affectedSipList = new Vector<Persistable>();
            //SOP更改任务
            Vector<Persistable> affectedSopList = new Vector<Persistable>();
            //软件更改任务ECA
            Vector<Persistable> affectedSWList = new Vector<Persistable>();
            //技术支持更改任务ECA
            Vector<Persistable> affectedTechList = new Vector<Persistable>();
            //销售更改任务ECA
            Vector<Persistable> affectedSaleList = new Vector<Persistable>();
            //市场更改任务ECA
            Vector<Persistable> affectedMarketList = new Vector<Persistable>();
            //结构图纸更改任务
            Vector<Persistable> affectedStruList = new Vector<Persistable>();
            //电子图纸更改任务
            Vector<Persistable> affectedElecList = new Vector<Persistable>();
            //其他更改任务
            Vector<Persistable> affectedOtherList = new Vector<Persistable>();
            //快速变更
            Vector<Persistable> affectDataList = new Vector<Persistable>();

            boolean quickChange = false;
            CtEcQuery query = new CtEcQuery();
            String changeType = query.getAttributeValue(vrChangeRequestId, "head_changeType");
            if(!CtFormatUtil.hasContent(changeType))
                throw new Exception("更改类型为空!\r\n");
            if(changeType.contains("快速变更"))
                quickChange=true;
            WTDocument doc = null;
            WTPart part = null;
            EPMDocument epmDoc = null;
            while (qr.hasMoreElements()) {
                Persistable obj = (Persistable) qr.nextElement();
                affectDataList.add(obj);
                if(quickChange)continue;
                if(obj instanceof WTDocument) {
                    doc = (WTDocument)obj;
                    String docType = CtWTObjectUtil.getTypeIdentifier(doc);
                    docType = docType.substring(docType.lastIndexOf("|")+1);
                    if(CtEcProperties.getPropertyValue(CtEcConstant.Ct_EcaType_SIP+"_AffectData").contains(docType)){
                        affectedSipList.add(doc);
                    }else if(CtEcProperties.getPropertyValue(CtEcConstant.Ct_EcaType_SOP+"_AffectData").contains(docType)){
                        affectedSopList.add(doc);
                    }else if(CtEcProperties.getPropertyValue(CtEcConstant.Ct_EcaType_Dianzituzhi+"_AffectData").contains(docType)){
                        affectedElecList.add(doc);
                    }else if(CtEcProperties.getPropertyValue(CtEcConstant.Ct_EcaType_Jiegoutuzhi+"_AffectData").contains(docType)){
                        affectedStruList.add(doc);
                    }else if(CtEcProperties.getPropertyValue(CtEcConstant.Ct_EcaType_Market+"_AffectData").contains(docType)){
                        affectedMarketList.add(doc);
                    }else if(CtEcProperties.getPropertyValue(CtEcConstant.Ct_EcaType_Sale+"_AffectData").contains(docType)){
                        affectedSaleList.add(doc);
                    }else if(CtEcProperties.getPropertyValue(CtEcConstant.Ct_EcaType_SW+"_AffectData").contains(docType)){
                        affectedSWList.add(doc);
                    }else if(CtEcProperties.getPropertyValue(CtEcConstant.Ct_EcaType_Tech+"_AffectData").contains(docType)){
                        affectedTechList.add(doc);
                    }/*else{
                        affectedOtherList.add(doc);
                    }*/
                }else if(obj instanceof WTPart){
                    part = (WTPart)obj;
                    String partType = CtWTObjectUtil.getTypeIdentifier(part);
                    partType = partType.substring(partType.lastIndexOf("|")+1);
                    //如果是成品或半成品
                    if(CtEcConstant.Ct_PartType_EndPart.equals(partType)||CtEcConstant.Ct_PartType_HalfEndPart.equals(partType)){
                        String viewName = part.getViewName();
                        if(CtConstant.VIEW_DESIGN.equals(viewName)){
                            affectedEBomList.add(part);
                        }else if(CtConstant.VIEW_MANUFACTURING.equals(viewName)){
                            affectedMBomList.add(part);
                        }
                    }else{
                        affectedEBomList.add(part);
                    }
                /*else if(CtEcConstant.Ct_PartType_ElecPart.equals(partType)){//原材料 电子
                    affectedElecList.add(part);
                }else{//原材料  结构
                    affectedStruList.add(part);
                }*/
                }else if(obj instanceof EPMDocument){
                    epmDoc = (EPMDocument)obj;
                    affectedStruList.add(epmDoc);
                /*
                WTPart wtPart = CtEPMDocUtil.getWTPartByEPMDocument(epmDoc);
                if(wtPart!=null){
                    String partType = CtWTObjectUtil.getTypeIdentifier(wtPart);
                    partType = partType.substring(partType.lastIndexOf("|")+1);
                    if(CtEcConstant.Ct_PartType_EndPart.equals(partType)||CtEcConstant.Ct_PartType_HalfEndPart.equals(partType)){
                        String viewName = wtPart.getViewName();
                        if(CtConstant.VIEW_DESIGN.equals(viewName)){
                            affectedEBomList.add(epmDoc);
                        }else if(CtConstant.VIEW_MANUFACTURING.equals(viewName)){
                            affectedMBomList.add(epmDoc);
                        }
                    }else if(CtEcConstant.Ct_PartType_ElecPart.equals(partType)){
                        affectedElecList.add(epmDoc);
                    }else{
                        affectedStruList.add(epmDoc);
                    }
                }else{
                    System.out.println(">>>>>>>>>>EPM文档编号："+epmDoc.getNumber()+"未找到关联料号！");
                }*/
                }
            }

            if(quickChange){
                if(changeType.contains("快速变更1")){
                    autoCreateECA(changeRequest,ecn,affectDataList,"物料属性快速更改任务ECA",CtEcConstant.Ct_EcaType_QuickChange1);
                }else if(changeType.contains("快速变更2")){
                    autoCreateECA(changeRequest,ecn,affectDataList,"图纸文档工艺快速更改任务ECA",CtEcConstant.Ct_EcaType_QuickChange2);
                }else if(changeType.contains("快速变更3")){
                    autoCreateECA(changeRequest,ecn,affectDataList,"BOM快速更改任务ECA",CtEcConstant.Ct_EcaType_QuickChange3);
                }else if(changeType.contains("快速变更4")){
                    autoCreateECA(changeRequest,ecn,affectDataList,"MBOM辅料快速更改任务ECA",CtEcConstant.Ct_EcaType_QuickChange4);
                }
            }else{
                if(affectedEBomList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedEBomList,"EBOM更改任务ECA",CtEcConstant.Ct_EcaType_EBOM);
                }
                if(affectedMBomList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedMBomList,"MBOM更改任务ECA",CtEcConstant.Ct_EcaType_MBOM);
                }
                if(affectedSipList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedSipList,"SIP更改任务ECA",CtEcConstant.Ct_EcaType_SIP);
                }
                if(affectedSopList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedSopList,"SOP更改任务ECA",CtEcConstant.Ct_EcaType_SOP);
                }
                if(affectedElecList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedElecList,"电子图纸更改任务ECA",CtEcConstant.Ct_EcaType_Dianzituzhi);
                }
                if(affectedStruList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedStruList,"结构图纸更改任务ECA",CtEcConstant.Ct_EcaType_Jiegoutuzhi);
                }
                if(affectedSWList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedSWList,"软件更改任务ECA",CtEcConstant.Ct_EcaType_SW);
                }
                if(affectedTechList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedTechList,"技术支持更改任务ECA",CtEcConstant.Ct_EcaType_Tech);
                }
                if(affectedSaleList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedSaleList,"销售更改任务ECA",CtEcConstant.Ct_EcaType_Sale);
                }
                if(affectedMarketList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedMarketList,"市场更改任务ECA",CtEcConstant.Ct_EcaType_Market);
                }
                /*if(affectedOtherList.size() >0) {
                    autoCreateECA(changeRequest,ecn,affectedOtherList,"其他更改任务ECA",CtEcConstant.Ct_EcaType_Other);
                }*/
            }
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }finally{
            flag = SessionServerHelper.manager.setAccessEnforced(flag);//恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
    }


    public static WTChangeActivity2 autoCreateECA(WTChangeRequest2 changeRequest, WTChangeOrder2 ecn, Vector<Persistable> persisVector, String name, String type) throws Exception{

        //**********创建ECA***************开始
        //WTChangeActivity2 eca = WTChangeActivity2.newWTChangeActivity2();
        PersistableAdapter ecaObj = new PersistableAdapter(
                type, null, null);
        ecaObj.load("name");
        ecaObj.set("name", changeRequest.getNumber()+ "-" + name+"-"+changeRequest.getName());
        WTChangeActivity2 eca = (WTChangeActivity2) ecaObj.apply();

        //设置属性
        eca.setContainer(changeRequest.getContainer());//容器，同变更请求
        eca.setDescription(changeRequest.getDescription());//变更原因，同变更请求
        if(CtFormatUtil.hasContent(changeRequest.getNeedDate())){
            eca.setNeedDate(changeRequest.getNeedDate()); //需要日期，同变更请求
        }
        LifeCycleServerHelper.setState(eca, State.toState("OPEN")); //设置状态为“开启的”
        eca = (WTChangeActivity2)ChangeHelper2.service.saveChangeActivity(ecn, eca);
        ChangeHelper2.service.storeAssociations(AffectedActivityData.class, eca, persisVector);
        return eca;
    }

    /**
     * 将changeActivity的受影响对象升版加到产生后对象中
     *
     * @param changeActivity2 更改任务
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public static void autoReviseAffectedData(WTChangeActivity2 changeActivity2) throws Exception {
        Transaction tx = null;
        String errMsg = "";//记录已存在更新大版本的对象
        try {
            tx = new Transaction();
            tx.start();
        //保存升版前后对象  key:升版前对象 value:升版后对象
            HashMap<Persistable,Persistable> affectedMap = new HashMap<>();
            //保存产生对象编号
            List<String> changeAfterNumberList = new ArrayList<>();
            QueryResult changeAfter = ChangeHelper2.service.getChangeablesAfter(changeActivity2);
            while(changeAfter.hasMoreElements()){
                Object obj = changeAfter.nextElement();
                if(obj instanceof WTDocument){
                    WTDocument doc = (WTDocument)obj;
                    changeAfterNumberList.add(doc.getNumber());
                }else if(obj instanceof WTPart){
                    WTPart part =(WTPart)obj;
                    changeAfterNumberList.add(part.getNumber()+part.getViewName());
                }else if(obj instanceof EPMDocument){
                    EPMDocument epmDoc = (EPMDocument)obj;
                    changeAfterNumberList.add(epmDoc.getNumber());
                }
            }

            QueryResult changeAbles = ChangeHelper2.service.getChangeablesBefore(changeActivity2);
            Object obj = null;
            LifeCycleManaged newVersionObj = null;
            String changeState = CtEcConstant.Ct_State_InChange;
            //Step1  将对象升版
            WTChangeRequest2 changeRequest = CtEcUtil.getChangeRequest(changeActivity2);
            String mark = "";
            if (changeRequest != null) {
                //变更原因取值：旧版本的ECR和新版ECR取值不一样
                String ecrType = CtWTObjectUtil.getLeafTypeIdentifier(changeRequest);
                String changeReason = "";
                String vid = CtWTObjectUtil.getVid(changeRequest);
                if (ecrType.equals(CtEcConstant.Ct_EcrType_ProductionEC)) {//旧的
                    CtEcService service = ServiceFactory.getService(CtEcService.class);
                    HashMap<String, String> headInfo = service.getHeadInfo(vid);
                    changeReason = headInfo.get("head_changeReason");//获取变更原因
                } else {//新的
                    CtECRApprovalRecordsService service = CtBeanFactory.newCtBeanFactory().getBean(CtECRApprovalRecordsService.class);
                    CtEcrInfoBo ctEcrInfoBo = service.searchEcrInfoBo(vid);
                    changeReason = ctEcrInfoBo.getChangeReason();
                }
                mark = "ECR系统自动修订-" + changeRequest.getNumber() + "，变更原因：" + changeReason;
            }
            while (changeAbles.hasMoreElements()) {
                obj = changeAbles.nextElement();
                if (obj instanceof WTDocument) {
                    WTDocument wtdoc = (WTDocument) obj;
                    //过滤掉已经在产生对象中的  说明已经升版成功
                    if(changeAfterNumberList.contains(wtdoc.getNumber()))continue;
                    // 1.只能对已发布状态的升版，2. 只能对最新大版本进行升版
                    if (!CtVersionUtil.existGreaterVersion(wtdoc)) {
                        try {
                            wtdoc = (WTDocument) VersionControlHelper.service.getLatestIteration(wtdoc, false);
                            newVersionObj = (LifeCycleManaged) VersionControlHelper.service.newVersion(wtdoc);
                            //状态设为正在变更
                            //注意，每次设状态必须用新的LifeCycleState，不可以复用。已发现复用LifeCycleState会造成生命周期模板互串的bug。
                            LifeCycleState inChangeState =  new LifeCycleState();
                            inChangeState.setState(State.toState(changeState));
                            newVersionObj.setState(inChangeState);
                            VersionControlHelper.setNote((Iterated) newVersionObj, mark);
                            newVersionObj = (LifeCycleManaged)PersistenceHelper.manager.save(newVersionObj);
                            affectedMap.put((Persistable)obj,newVersionObj);
                        } catch (Exception e) {
                            e.printStackTrace();
                            throw new WTException("文档"+wtdoc.getIdentity()+"自动升版失败,请检查生命周期模板和状态！"+e.getMessage());
                        }
                    }else {
                        if("".equals(errMsg))
                            errMsg = wtdoc.getIdentity();
                        else
                            errMsg = wtdoc.getIdentity() + "," +errMsg;
                    }

                }else if (obj instanceof WTPart) {
                    WTPart wtpart = (WTPart) obj;
                    if(changeAfterNumberList.contains(wtpart.getNumber()+wtpart.getViewName()))continue;
                    // 1.只能对已发布状态的升版，2. 只能对最新大版本进行升版
                    if (!CtVersionUtil.existGreaterVersion(wtpart)) {
                        try {
                            wtpart = (WTPart) VersionControlHelper.service.getLatestIteration(wtpart, false);
                            newVersionObj = (LifeCycleManaged)VersionControlHelper.service.newVersion(wtpart);
                            //状态设为正在变更
                            LifeCycleState inChangeState =  new LifeCycleState();
                            inChangeState.setState(State.toState(changeState));
                            newVersionObj.setState(inChangeState);
                            VersionControlHelper.setNote((Iterated) newVersionObj, mark);
                            newVersionObj = (LifeCycleManaged)PersistenceHelper.manager.save(newVersionObj);
                            affectedMap.put((Persistable)obj,newVersionObj);
                        } catch (Exception e) {
                            e.printStackTrace();
                            throw new WTException("物料"+wtpart.getIdentity()+"自动升版失败,请检查生命周期模板和状态！"+e.getMessage());
                        }
                    }else {
                        if("".equals(errMsg))
                            errMsg = wtpart.getIdentity();
                        else
                            errMsg = wtpart.getIdentity() + "," +errMsg;
                    }
                }else if (obj instanceof EPMDocument) {
                    EPMDocument epmdoc = (EPMDocument) obj;
                    if(changeAfterNumberList.contains(epmdoc.getNumber()))continue;
                    // 1.只能对已发布状态的升版，2. 只能对最新大版本进行升版
                    if (!CtVersionUtil.existGreaterVersion(epmdoc)) {
                        try {
                            epmdoc = (EPMDocument) VersionControlHelper.service.getLatestIteration(epmdoc, false);
                            newVersionObj = (LifeCycleManaged)VersionControlHelper.service.newVersion(epmdoc);
                            //状态设为正在变更
                            LifeCycleState inChangeState =  new LifeCycleState();
                            inChangeState.setState(State.toState(changeState));
                            newVersionObj.setState(inChangeState);
                            VersionControlHelper.setNote((Iterated) newVersionObj, mark);
                            newVersionObj = (LifeCycleManaged)PersistenceHelper.manager.save(newVersionObj);
                            affectedMap.put((Persistable)obj,newVersionObj);
                        } catch (Exception e) {
                            e.printStackTrace();
                            throw new WTException("图纸"+epmdoc.getIdentity()+"自动升版失败！异常信息："+e.getMessage());
                        }
                    }else {
                        if("".equals(errMsg))
                            errMsg = epmdoc.getIdentity();
                        else
                            errMsg = epmdoc.getIdentity() + "," +errMsg;
                    }
                }
            }

            //Step2:EPM文档升版 部件也要一起升版  重新建立关联关系
            resetRelationship(affectedMap);

            //全部物料对象找一遍最新版，解决产生的对象中丢失物料的问题
            for(HashMap.Entry<Persistable,Persistable> entry : affectedMap.entrySet()){
                Persistable p = entry.getKey();
                if(p instanceof WTPart){
                    WTPart part = (WTPart) p;
                    WTPart lastPart = CtPartUtil.getPartByNumber(part.getNumber(), part.getViewName());
                    if(null != lastPart){
                        affectedMap.put(p, lastPart);
                    }
                }
            }

            // Step3: 将升大版本后的对象加入到产生的新对象
            if (affectedMap.size() > 0) {
                Vector<ChangeRecord2> newChangeRecords = null;
                Class changeRecord2Class = null;

                try {
                    changeRecord2Class = Class.forName("wt.change2.ChangeRecord2");
                } catch (ClassNotFoundException e) {
                    throw new WTException(e);
                }
                newChangeRecords = ChangeHelper2.service.storeAssociations(changeRecord2Class,
                        changeActivity2, new Vector(affectedMap.values()));
                // 添加描述
                for (ChangeRecord2 changeRecord : newChangeRecords) {
                    try {
                        changeRecord.setDescription("系统自动创建的新版本！");
                    } catch (WTPropertyVetoException e) {
                        throw new WTException(e);
                    }
                }
                ChangeHelper2.service.saveChangeRecord(newChangeRecords);
            }

            tx.commit();
            tx = null;
        }finally {
            if (tx != null) {
                tx.rollback();
                tx = null;
            }
        }
         if(CtFormatUtil.hasContent(errMsg)){
            throw new WTException("以下对象存在更高版本, 无法修订：" + errMsg + ",如有需要，请手动添加正确的版本！");
         }
    }

    /**
     *对象升版  返回升版后的对象
     * @param obj
     * @param errMsg 错误信息
     * @throws Exception
     */
    public static Persistable autoReviseObj(Object obj,String errMsg) throws Exception {
        LifeCycleManaged newVersionObj = null;
        String changeState = CtEcConstant.Ct_State_InChange;
        if (obj instanceof WTDocument) {
            WTDocument wtdoc = (WTDocument) obj;
            //creatorName = wtdoc.getModifierName();
            // 转化为将任务负责人当作对象升级后的创建人
            // SessionMgr.setPrincipal(creatorName);
            // 1.只能对已发布状态的升版，2. 只能对最新大版本进行升版
            if (!CtVersionUtil.existGreaterVersion(wtdoc)) {
                try {
                    newVersionObj = (LifeCycleManaged) VersionControlHelper.service.newVersion(wtdoc);
                    //状态设为正在变更
                    //注意，每次设状态必须用新的LifeCycleState，不可以复用。已发现复用LifeCycleState会造成生命周期模板互串的bug。
                    LifeCycleState inChangeState =  new LifeCycleState();
                    inChangeState.setState(State.toState(changeState));
                    newVersionObj.setState(inChangeState);
                    newVersionObj = (LifeCycleManaged)PersistenceHelper.manager.save(newVersionObj);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new WTException("文档自动升版失败！异常信息："+e.getMessage());
                }
            }else {
                if("".equals(errMsg))
                    errMsg = wtdoc.getIdentity();
                else
                    errMsg = wtdoc.getIdentity() + "," +errMsg;
            }

        }
        if (obj instanceof WTPart) {
            WTPart wtpart = (WTPart) obj;
            // 1.只能对已发布状态的升版，2. 只能对最新大版本进行升版
            if (!CtVersionUtil.existGreaterVersion(wtpart)) {
                try {
                    newVersionObj = (LifeCycleManaged)VersionControlHelper.service.newVersion(wtpart);
                    //状态设为正在变更
                    LifeCycleState inChangeState =  new LifeCycleState();
                    inChangeState.setState(State.toState(changeState));
                    newVersionObj.setState(inChangeState);
                    newVersionObj = (LifeCycleManaged)PersistenceHelper.manager.save(newVersionObj);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new WTException("物料自动升版失败！异常信息："+e.getMessage());
                }
            }else {
                if("".equals(errMsg))
                    errMsg = wtpart.getIdentity();
                else
                    errMsg = wtpart.getIdentity() + "," +errMsg;
            }
        }
        if (obj instanceof EPMDocument) {
            EPMDocument epmdoc = (EPMDocument) obj;
            // 1.只能对已发布状态的升版，2. 只能对最新大版本进行升版
            if (!CtVersionUtil.existGreaterVersion(epmdoc)) {
                try {
                    newVersionObj = (LifeCycleManaged)VersionControlHelper.service.newVersion(epmdoc);
                    //状态设为正在变更
                    LifeCycleState inChangeState =  new LifeCycleState();
                    inChangeState.setState(State.toState(changeState));
                    newVersionObj.setState(inChangeState);
                    newVersionObj = (LifeCycleManaged)PersistenceHelper.manager.save(newVersionObj);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new WTException("图纸自动升版失败！异常信息："+e.getMessage());
                }
            }else {
                if("".equals(errMsg))
                    errMsg = epmdoc.getIdentity();
                else
                    errMsg = epmdoc.getIdentity() + "," +errMsg;
            }
        }
       return newVersionObj;
    }

    /**
     * 重新建立关联关系，删除旧对象的关联关系，建立新的关联关系
     * @param affectMaps
     * @throws Exception
     */
    public static String resetRelationship(HashMap<Persistable, Persistable> affectMaps) throws Exception{
        StringBuffer stringBuffer = new StringBuffer();
        //Value中的对象需添加产生对象中
        HashMap<Persistable, Persistable> addItems = new HashMap<>();
        //设置状态 变更中
        String changeState = CtEcConstant.Ct_State_InChange;
        for (HashMap.Entry<Persistable, Persistable> item : affectMaps.entrySet()){
            try {
                Persistable key = item.getKey();
                Persistable value = item.getValue();
                if (key instanceof EPMDocument) {
                    WTPart newPart = null;
                    // 需要修订的物料
                    EPMDocument epmDocument = (EPMDocument) key;
                    EPMDocument newEpmDocument = (EPMDocument) value;
                    logger.debug(">>>>>>>>>>>>>>>key instanceof EPMDocument>>>>>>>>>>>>>");
                    logger.debug(">>>>>>>>>>>>>>>epmDocument>>>>>>>>>>>>>"+epmDocument.getIdentity());
                    logger.debug(">>>>>>>>>>>>>>>newEpmDocument>>>>>>>>>>>>>"+newEpmDocument.getIdentity());
                    // 过滤绘图文档的图纸，因为该图纸修订会实时更新，无需代码处理关联关系
                    if (epmDocument.getCADName().endsWith(".drw")||epmDocument.getCADName().endsWith(".frm")) continue;
                    // 先检查物料图纸一起修订的情况
                    QueryResult queryResult = PersistenceHelper.manager.navigate(epmDocument, EPMBuildRule.BUILD_TARGET_ROLE,
                            EPMBuildRule.class, false);
                    logger.debug(">>>>>>>>>>>查找epmDocument的关联>>>>>>>>>>>>>"+epmDocument.getIdentity());
                    while (queryResult.hasMoreElements()){
                        EPMBuildRule epmBuildRule = (EPMBuildRule) queryResult.nextElement();
                        Persistable persistable = epmBuildRule.getRoleBObject();
                        if (!(persistable instanceof WTPart)) continue;
                        WTPart part = (WTPart) persistable;
                        logger.debug(">>>>>>>>>>>查找到epmDocument关联部件>>>>>>>>>>>>>"+part.getIdentity());
                        boolean latest = CtVersionUtil.isLatest(part, CtConstant.VIEW_DESIGN);
                        if(!latest){//关联的不是最新版，判断最新版是否也关联修订前的EPM
                            newPart = (WTPart)CtVersionUtil.getLatest(part.getMaster(), CtConstant.VIEW_DESIGN);
                            QueryResult qs = PersistenceHelper.manager.navigate(newPart, EPMBuildRule.BUILD_SOURCE_ROLE,
                                    EPMBuildRule.class, false);
                            logger.debug(">>>>>>>>>>>查找newPart的关联 >>>>>>>>>>>>>"+newPart.getIdentity());
                            // 删除修订物料与之前图纸的关联关系
                            while (qs.hasMoreElements()){
                                EPMBuildRule buildRule = (EPMBuildRule) qs.nextElement();
                                EPMDocument epmDoc = (EPMDocument) buildRule.getRoleAObject();
                                logger.debug(">>>>>>>>>>>查找到newPart的关联 >>>>>>>>>>>>>"+epmDoc.getIdentity());
                                logger.debug(">>>>>>>>>>>epmDocument >>>>>>>>>>>>>"+epmDocument.getIdentity());
                                logger.debug(">>>>>>>>>>> epmDocument.equals(epmDoc)>>>>>>>>>>>>>"+epmDocument.equals(epmDoc));
                                if (epmDocument.equals(epmDoc)) {
//                                // 移除关联关系，并建立新版本的关联关系
                                    PersistenceServerHelper.manager.remove(buildRule);
                                    newPart = createWTPartAndEpmDocmentLink(newPart, newEpmDocument, false);
//                                buildRule.setRoleAObject(newEpmDocument);
//                                PersistenceHelper.manager.save(buildRule);
//                                addItems.put(part, newPart);
                                }
                            }

                        }
                    }
                }else if (key instanceof WTPart) {
                    EPMDocument newEpmDocument = null;
                    WTPart part = (WTPart) key;
                    WTPart newPart = (WTPart) value;
                    logger.debug(">>>>>>>>>>>>>>>key instanceof WTPart>>>>>>>>>>>>>");
                    logger.debug(">>>>>>>>>>>>>>>part>>>>>>>>>>>>>"+part.getIdentity());
                    logger.debug(">>>>>>>>>>>>>>>newPart>>>>>>>>>>>>>"+newPart.getIdentity());
                    QueryResult qs = PersistenceHelper.manager.navigate(newPart, EPMBuildRule.BUILD_SOURCE_ROLE,
                            EPMBuildRule.class, false);
                    logger.debug(">>>>>>>>>>>查找newPart的关联 >>>>>>>>>>>>>"+newPart.getIdentity());
                    // 删除修订物料与之前图纸的关联关系
                    while (qs.hasMoreElements()){
                        EPMBuildRule buildRule = (EPMBuildRule) qs.nextElement();
                        EPMDocument epmDoc = (EPMDocument) buildRule.getRoleAObject();
                        logger.debug(">>>>>>>>>>>查找到newPart的关联 >>>>>>>>>>>>>"+epmDoc.getIdentity());
                        boolean latest = CtVersionUtil.isLatest(epmDoc);
                        if(!latest){
                            newEpmDocument = (EPMDocument) CtVersionUtil.getLatest(epmDoc.getMaster());
                            PersistenceServerHelper.manager.remove(buildRule);
                            newPart = createWTPartAndEpmDocmentLink(newPart, newEpmDocument, false);
                            addItems.put(part, newPart);
                        }
                    }

                }
            } catch (Exception e) {
                stringBuffer.append("处理图纸：" + ((EPMDocument)item.getKey()).getCADName() + "的物料关联关系失败！\r\n");
                e.printStackTrace();
            }
        }
        if (addItems.size() > 0){
            affectMaps.putAll(addItems);
        }
        return stringBuffer.toString();
    }

    /**
     * 创建物料与图纸所有者关联关系
     * @param part 物料
     * @param epmDocument 图纸
     * @param isAllChange 是否同时走变更
     * @return 返回最新的物料，因为创建关联关系需要检出和检入操作，返回的是最新的物料
     * @throws Exception
     */
    public static WTPart createWTPartAndEpmDocmentLink(WTPart part, EPMDocument epmDocument, boolean isAllChange) throws Exception{
        WTPrincipal beforeModifier= part.getModifier().getPrincipal();
        part = (WTPart) CtACLUtil.checkout(part, "准备将修订后的关联关系转移到修订后！");
        // 拿小版本最新的图纸创建关联关系为所有者的数据
        BuildRule buildRule = GenericUtilities.createBuildRule(part, epmDocument);
        part =  (WTPart) CtACLUtil.checkIn(part, "自动将修订前的关联关系转移到修订后，并移除修订之前的关联关系！"
                + (isAllChange ? "" : "——single"));
        CtWTObjectUtil.setModifier(part, beforeModifier);
        return part;
    }

    /**
     * ECN自动改BOM
     * @param changeRequest
     * @param type
     * @throws Exception
     */
    public void changeBom(WTChangeRequest2 changeRequest,String type) throws Exception{
        changeBom(changeRequest,null, type);
    }

    /**
     * ECN自动改BOM  扩展方法    如果传了父项编码  只修改传入父项编码的BOM
     * @param changeRequest
     * @param type
     * @throws Exception
     */
    public void changeBom(WTChangeRequest2 changeRequest,String fPartNumber,String type) throws Exception{
        logger.error(">>>>>>>>>>>>>开始 自动改BOM>>>>>>>>>>>>>>>>>");
        logger.error(">>>>>>>>>>>>>传入父项编码>>>>>>>>>>>>>>>>"+fPartNumber);
        Transaction tx = null;
        try {
            tx = new Transaction();
            tx.start();
            ReferenceFactory rf = new ReferenceFactory();
            String changeRequestId = rf.getReferenceString(changeRequest);
            logger.error("changeRequestId>>>>>>>>>>>>>>>>>"+changeRequestId);
            logger.error("type>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+type);
            CtEcQuery query = new CtEcQuery();
            List<CtChangeItemBo> changeItems = query.getChangeItems(changeRequestId,type);
            logger.error("changeItems>>>>>>>>>>>>>>>>>>>>>"+JSON.toJSONString(changeItems));
            List<CtChangeItemBo> deleteItems = new ArrayList<>();
            List<CtChangeItemBo> addItems = new ArrayList<>();
            List<CtChangeItemBo> updateItems = new ArrayList<>();
            List<WTPart> parentParts = new ArrayList<>();
            for (CtChangeItemBo bo : changeItems) {
                String changeType = bo.getChangeType();
                String parentNumber = bo.getParentNumber();
                if (CtFormatUtil.hasContent(fPartNumber)&&!parentNumber.equalsIgnoreCase(fPartNumber)) {
                    continue;
                }
                if ("增加".equals(changeType)) {
                    addItems.add(bo);
                }else if ("删除".equals(changeType)){
                    deleteItems.add(bo);
                }else if ("修改".equals(changeType)) {
                    addItems.add(bo);
                    deleteItems.add(bo);
                }
            }
            logger.error("addItems>>>>>>>>>>>>>>>>>>>>>"+JSON.toJSONString(addItems));
            logger.error("deleteItems>>>>>>>>>>>>>>>>>>>>>"+JSON.toJSONString(deleteItems));
            deletePart(parentParts,deleteItems,type);
//          updatePart(parentParts,updateItems,type);
            addPart(parentParts,addItems,type);
            for(WTPart parentPart:parentParts) {
                parentPart = (WTPart) WorkInProgressHelper.service.checkin(parentPart, "自动变更");
            }
            tx.commit();
            tx=null;
            logger.error(">>>>>>>>>>>>>结束 自动改BOM>>>>>>>>>>>>>>>>>");
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e);
        }finally{
            if(tx!=null){
                tx.rollback();
                tx=null;
            }
        }

    }


    /**
     * 删除BOM
     * @param parentParts
     * @param deleteItems
     * @param type BOM类型
     * @throws Exception
     */
    public void deletePart(List<WTPart> parentParts,List<CtChangeItemBo> deleteItems,String type) throws Exception{
        if(!CtFormatUtil.hasContent(deleteItems)) {
            return;
        }
        String view = "ebom".equalsIgnoreCase(type)?CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        for(CtChangeItemBo bo:deleteItems) {
            String childNumberBefore = bo.getChildNumberBefore();
            WTPart deletePart = CtPartUtil.getPartByNumber(childNumberBefore,view);
            if(deletePart==null)deletePart=CtPartUtil.getPartByNumber(childNumberBefore,CtConstant.VIEW_DESIGN);
            checkPartView(view,deletePart);
            String parentNumber = bo.getParentNumber();
            WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber, view);
            if(parentPart==null){
                throw new Exception("父件编号【"+parentNumber+"】，视图【"+view+"】不存在!");
            }
            parentPart = (WTPart) CtACLUtil.checkout(parentPart,"自动变更");
            if(!parentParts.contains(parentPart)){
                parentParts.add(parentPart);
            }
            deleteUsageLink(parentPart, deletePart);
            logger.error("deletePart>>>>>>>>>>>>>>>>父件编号【"+parentNumber+"】，视图【"+view+"】,子项编号【"+childNumberBefore+"】,视图【"+deletePart.getViewName()+"】");
        }

    }



    /**
     * 新增BOM
     * @param parentParts
     * @param addItems
     * @param type BOM类型
     * @throws Exception
     */
    public void addPart(List<WTPart> parentParts, List<CtChangeItemBo> addItems,String type) throws Exception{
        if(!CtFormatUtil.hasContent(addItems)) {
            return;
        }
        String view = "ebom".equalsIgnoreCase(type)?CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        for(CtChangeItemBo bo:addItems) {
            String childNumberAfter = bo.getChildNumberAfter();
            String parentNumber = bo.getParentNumber();
            WTPart addPart = CtPartUtil.getPartByNumber(childNumberAfter,view);
            if(addPart==null)addPart=CtPartUtil.getPartByNumber(childNumberAfter);
            WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber, view);
            if(parentPart==null)parentPart=CtPartUtil.getPartByNumber(parentNumber);
            parentPart = (WTPart) CtACLUtil.checkout(parentPart,"自动变更");
            if(!parentParts.contains(parentPart)){
                parentParts.add(parentPart);
            }
            WTPartMaster master = addPart.getMaster();
            WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, addPart);
            if(usageLink==null){
                usageLink = WTPartUsageLink.newWTPartUsageLink(parentPart, master);
                usageLink = (WTPartUsageLink) PersistenceHelper.manager.store(usageLink);
            }
            logger.error("addPart>>>>>>>>>>>>>>>>父件编号【"+parentNumber+"】，视图【"+view+"】,子项编号【"+addPart.getNumber()+"】,视图【"+addPart.getViewName()+"】");
            updateUsageLink(usageLink,bo,view);
        }

    }

    /**
     * 修改BOM   先删除   再添加
     * @param parentParts
     * @param updateItems
     * @param type BOM类型
     * @throws Exception
     */
    private void updatePart(List<WTPart> parentParts, List<CtChangeItemBo> updateItems,String type) throws Exception{
        if(!CtFormatUtil.hasContent(updateItems)) {
            return;
        }
        String view = "ebom".equalsIgnoreCase(type)?CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        for(CtChangeItemBo bo:updateItems) {
            String childNumberBefore = bo.getChildNumberBefore();
            String childNumberAfter = bo.getChildNumberAfter();
            String parentNumber = bo.getParentNumber();
            WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber, view);
            if(parentPart==null){
                throw new Exception("父件编号【"+parentNumber+"】，视图【"+view+"】不存在!");
            }
            parentPart = (WTPart) CtACLUtil.checkout(parentPart,"自动变更");
            if(!parentParts.contains(parentPart)){
                parentParts.add(parentPart);
            }
            if(childNumberBefore.equals(childNumberAfter)){//前后编码一致  直接更新usageLink属性
                WTPart updatePart = CtPartUtil.getPartByNumber(childNumberAfter, view);
                if(updatePart==null)updatePart=CtPartUtil.getPartByNumber(childNumberAfter,CtConstant.VIEW_DESIGN);
                checkPartView(view,updatePart);
                WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, updatePart);
                if(usageLink==null){//正常情况不会进来
                    logger.error("BOM修改异常>>>>>>父:"+parentPart.getIdentity()+"子:"+updatePart.getIdentity()+">>>>>>未获取到usageLink");
                    WTPartMaster master = updatePart.getMaster();
                    usageLink = WTPartUsageLink.newWTPartUsageLink(parentPart, master);
                    usageLink = (WTPartUsageLink) PersistenceHelper.manager.store(usageLink);
                }
                //先删除原有位号
                long linkid = PersistenceHelper.getObjectIdentifier(usageLink).getId();
                QuerySpec qs = new QuerySpec(PartUsesOccurrence.class);
                qs.appendWhere(new SearchCondition(PartUsesOccurrence.class, "linkReference.key.id", "=", linkid));
                QueryResult qr = PersistenceHelper.manager.find(qs);
                if (CtFormatUtil.hasContent(qr)) {
                    while (qr.hasMoreElements()){
                        PartUsesOccurrence occurrence = (PartUsesOccurrence)qr.nextElement();
                        if (CtFormatUtil.hasContent(occurrence)) {
                            PersistenceServerHelper.manager.remove(occurrence);
                        }
                    }
                }
                usageLink = CtBomUtil.getUsageLink(parentPart, updatePart);
                updateUsageLink(usageLink, bo,view);
            }else{//先删除变更前物料  再新增变更后物料
                WTPart deletePart = CtPartUtil.getPartByNumber(childNumberBefore,view);
                if(deletePart==null)deletePart=CtPartUtil.getPartByNumber(childNumberBefore,CtConstant.VIEW_DESIGN);
                checkPartView(view, deletePart);
                parentPart = (WTPart) CtACLUtil.checkout(parentPart,"自动变更");
                if(!parentParts.contains(parentPart)){
                    parentParts.add(parentPart);
                }
                deleteUsageLink(parentPart, deletePart);
                WTPart addPart = CtPartUtil.getPartByNumber(childNumberAfter, view);
                if(addPart==null)addPart=CtPartUtil.getPartByNumber(childNumberAfter,CtConstant.VIEW_DESIGN);
                checkPartView(view, addPart);
                WTPartMaster master = addPart.getMaster();
                WTPartUsageLink usageLink = WTPartUsageLink.newWTPartUsageLink(parentPart, master);
                usageLink = (WTPartUsageLink) PersistenceHelper.manager.store(usageLink);
                updateUsageLink(usageLink,bo,view);
            }

        }
    }

    public void deleteUsageLink(WTPart parentPart, WTPart deletePart) throws Exception {
        WTPartUsageLink usageLink = CtBomUtil.getUsageLink(parentPart, deletePart);
        if(usageLink==null){//正常情况不会进来
            logger.error("BOM删除异常>>>>>>父:"+parentPart.getIdentity()+"子:"+deletePart.getIdentity()+">>>>>>未获取到usageLink");
            return;
        }
        //判断是否存在位号，存在先删除位号
        long linkid = PersistenceHelper.getObjectIdentifier(usageLink).getId();
        QuerySpec qs = new QuerySpec(PartUsesOccurrence.class);
        qs.appendWhere(new SearchCondition(PartUsesOccurrence.class, "linkReference.key.id", "=", linkid));
        QueryResult qr = PersistenceHelper.manager.find(qs);
        if (CtFormatUtil.hasContent(qr)) {
            while (qr.hasMoreElements()){
                PartUsesOccurrence occurrence = (PartUsesOccurrence)qr.nextElement();
                if (CtFormatUtil.hasContent(occurrence)) {
                    PersistenceServerHelper.manager.remove(occurrence);
                }
            }
        }
        usageLink = (WTPartUsageLink) PersistenceHelper.manager.refresh(usageLink);
        PersistenceHelper.manager.delete(usageLink);
    }

    /**
     * 更新link关系
     * @param usageLink
     * @param bo
     * @param view 视图
     * @throws Exception
     */
    private void updateUsageLink(WTPartUsageLink usageLink,CtChangeItemBo bo,String view) throws Exception{
        WTPart usedBy = usageLink.getUsedBy();
        WTPartMaster uses = usageLink.getUses();
        String parentNumber = usedBy.getNumber();
        String sonNumber = uses.getNumber();
        try{
            //单位
            QuantityUnit quantityUnit = QuantityUnit.toQuantityUnit("ea");
            //数量
            String bomAmountText = bo.getAmountAfter();
            if(!CtFormatUtil.hasContent(bomAmountText)){
                //正常情况不会进来  填写表单已经校验数量必填
                bomAmountText = "1";
            }
            NumberFormat numberFormat = NumberFormat.getInstance();
            //设置保留多少位小数
            numberFormat.setMaximumFractionDigits(8);
            numberFormat.setRoundingMode(RoundingMode.UP);
            // 取消科学计数法
            numberFormat.setGroupingUsed(false);
            //保留4位小数,在第5位直接进1
            String format = numberFormat.format(Double.valueOf(bomAmountText));
            Number parse = numberFormat.parse(format);
            Double bomAmount = null;
            if (parse instanceof Double){
                bomAmount = (Double) parse;
            }else if(parse instanceof Long){
                bomAmount = Double.valueOf((Long) parse);
            }else if(parse instanceof Integer){
                bomAmount = Double.valueOf((Integer) parse);
            }
            //判断是否为小数
            if(bomAmount.intValue()-bomAmount!=0){
                quantityUnit = QuantityUnit.toQuantityUnit("PC");
                quantityUnit.getStringValue();
            }
            Quantity quantity = Quantity.newQuantity(bomAmount, quantityUnit);
            usageLink.setQuantity(quantity);
            usageLink = (WTPartUsageLink) PersistenceHelper.manager.save(usageLink);
            //判断是否存在位号，存在先删除位号
            long linkid = PersistenceHelper.getObjectIdentifier(usageLink).getId();
            QuerySpec qs = new QuerySpec(PartUsesOccurrence.class);
            qs.appendWhere(new SearchCondition(PartUsesOccurrence.class, "linkReference.key.id", "=", linkid));
            QueryResult qr = PersistenceHelper.manager.find(qs);
            if (CtFormatUtil.hasContent(qr)) {
                while (qr.hasMoreElements()){
                    PartUsesOccurrence occurrence = (PartUsesOccurrence)qr.nextElement();
                    if (CtFormatUtil.hasContent(occurrence)) {
                        PersistenceServerHelper.manager.remove(occurrence);
                    }
                }
            }
            usageLink = (WTPartUsageLink) PersistenceHelper.manager.refresh(usageLink);
            //位号
            System.out.println("位号>>>>>>>>>>>>>>>>"+bo.getBitNumberAfter());
            if(CtFormatUtil.hasContent(bo.getBitNumberAfter())) {
                List<String> list = new ArrayList<String>();
                CtCheckFitPlaceTool.checkFitPlace2NumAndList(bo.getBitNumberAfter(), list);
                System.out.println("位号拆分后>>>>>>>>>>>>>>>>"+list);
                WTKeyedMap occurrences = new WTKeyedHashMap();
                for(String fit:list){
                    PartUsesOccurrence newOccurrence = PartUsesOccurrence.newPartUsesOccurrence(usageLink);
                    if (fit.startsWith("[") && fit.endsWith("]")){
                        fit = fit.substring(1);
                        fit = fit.substring(0,fit.length()-1);
                    }
                    newOccurrence.setName(fit);
                    occurrences.put(newOccurrence, null);
                }
                OccurrenceHelper.service.saveUsesOccurrenceAndData(occurrences);
            }

            usageLink = (WTPartUsageLink) PersistenceHelper.manager.refresh(usageLink);
            // 设置IBA属性
            IBAUtil linkIBA = new IBAUtil(usageLink);
            linkIBA.setIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority, CtFormatUtil.hasContent(bo.getPriorityAfter())?bo.getPriorityAfter():""); // 优先级
            linkIBA.setIBAValue(CtEcConstant.Ct_IBA_replaceGroup, CtFormatUtil.hasContent(bo.getReplaceNumberAfter())?bo.getReplaceNumberAfter():""); // 替代组
            linkIBA.setIBAValue(CtEcConstant.Ct_IBA_bomNotes, CtFormatUtil.hasContent(bo.getBomRemarksAfter())?bo.getBomRemarksAfter():""); // BOM备注
            // 保存IBA属性
            linkIBA.updateIBAHolder(usageLink);
        }catch (Exception e){
            e.printStackTrace();
            throw new Exception("父编号:"+parentNumber+"子编号:"+sonNumber+"\r\n"+e.getMessage());
        }

    }

    /**
     * 从受影响对象中找出对象在变更前的状态 逻辑：因变更前的对象有多种发布状态
     *
     * @param changeActivity2
     * @param objNumber 编码，可以是部件、文档、EPMDoc的编码
     * @return
     * @throws Exception
     */
    public static State getOrgState(WTChangeActivity2 changeActivity2, String objNumber,String view) throws Exception {

        State state = null;
        QueryResult changeAbles = ChangeHelper2.service.getChangeablesBefore(changeActivity2);
        LifeCycleManaged beforeObj = null;
        while (changeAbles.hasMoreElements()) {
            beforeObj = (LifeCycleManaged) changeAbles.nextElement();
            String beforeObjNumber = "";
            if(beforeObj instanceof WTPart ) {
                WTPart part = (WTPart)beforeObj;
                beforeObjNumber = part.getNumber();
                if (beforeObjNumber.equalsIgnoreCase(objNumber)&&view.equals(part.getViewName())) {
                    state = beforeObj.getLifeCycleState();
                    break;
                }
            }else if(beforeObj instanceof WTDocument ) {
                WTDocument doc = (WTDocument)beforeObj;
                beforeObjNumber = doc.getNumber();
                if (beforeObjNumber.equalsIgnoreCase(objNumber)) {
                    state = beforeObj.getLifeCycleState();
                    break;
                }
            }else if(beforeObj instanceof EPMDocument ) {
                EPMDocument doc = (EPMDocument)beforeObj;
                beforeObjNumber = doc.getNumber();
                if (beforeObjNumber.equalsIgnoreCase(objNumber)) {
                    state = beforeObj.getLifeCycleState();
                    break;
                }
            }

        }

        if (state == null) {
            throw new WTException("无法在受影响对象中找到与产生对象相对应的数据，请检查！"+objNumber);
        }

        return state;
    }

    public static List<WTPart> getParentList(String changeRequestId,String type) throws Exception {
        String viewName = "ebom".equals(type)? CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        WTChangeRequest2 changeRequest = (WTChangeRequest2)CtWTObjectUtil.getObjectByOid(changeRequestId);
        QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
        Object obj = null;
        WTPart tmpPart;
        List<WTPart> parentList = new ArrayList<>();
        while(queryResult.hasMoreElements()){
            obj = queryResult.nextElement();
            if(obj instanceof WTPart){
                tmpPart = (WTPart) obj;
                if (tmpPart.getViewName().equals(viewName)) {
                    String partType = CtWTObjectUtil.getTypeIdentifier(tmpPart);
                    partType = partType.substring(partType.lastIndexOf("|")+1);
                    //如果是成品或半成品
                    if(CtEcConstant.Ct_PartType_EndPart.equals(partType)||CtEcConstant.Ct_PartType_HalfEndPart.equals(partType)){
                        parentList.add(tmpPart);
                    }
                }
            }
        }
        return parentList;
    }

    public static List<HashMap<String,String>> getBomList(String changeRequestId,String type) throws Exception {
        CtEcQuery query = new CtEcQuery();
        String viewName = "ebom".equals(type)? CtConstant.VIEW_DESIGN:CtConstant.VIEW_MANUFACTURING;
        WTChangeRequest2 changeRequest = (WTChangeRequest2)CtWTObjectUtil.getObjectByOid(changeRequestId);
        QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
        Object obj = null;
        WTPart tmpPart;
        List<HashMap<String,String>> partNumbers = new ArrayList<>();
        HashMap<String, String> map = null;
        while(queryResult.hasMoreElements()){
            obj = queryResult.nextElement();
            if(obj instanceof WTPart){
                tmpPart = (WTPart) obj;
                if (tmpPart.getViewName().equals(viewName)) {
                    String partType = CtWTObjectUtil.getTypeIdentifier(tmpPart);
                    partType = partType.substring(partType.lastIndexOf("|")+1);
                    //如果是成品或半成品
                    if(CtEcConstant.Ct_PartType_EndPart.equals(partType)||CtEcConstant.Ct_PartType_HalfEndPart.equals(partType)){
                        map = new HashMap<>();
                        map.put("formInfo",tmpPart.getNumber());
                        partNumbers.add(map);
                    }
                }
            }
        }
        return partNumbers;
    }

    /**
     * 获取更改请求对应视图的 受影响BOM父项编号
     * @param changeRequest
     * @param viewName
     * @return
     * @throws Exception
     */
    public static HashSet<String> getAffectedBomNumbers(WTChangeRequest2 changeRequest,String viewName) throws Exception {
        QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
        Object obj = null;
        WTPart tmpPart;
        HashSet<String> partNumbers = new HashSet<>();
        HashMap<String, String> map = null;
        while(queryResult.hasMoreElements()){
            obj = queryResult.nextElement();
            if(obj instanceof WTPart){
                tmpPart = (WTPart) obj;
                if (tmpPart.getViewName().equals(viewName)) {
                    String partType = CtWTObjectUtil.getTypeIdentifier(tmpPart);
                    partType = partType.substring(partType.lastIndexOf("|")+1);
                    //如果是成品或半成品
                    if(CtEcConstant.Ct_PartType_EndPart.equals(partType)||CtEcConstant.Ct_PartType_HalfEndPart.equals(partType)){
                        partNumbers.add(tmpPart.getNumber());
                    }
                }
            }
        }
        return partNumbers;
    }


    /**
     * 获取受影响对象中所有design视图的物料
     * @param changeRequestId
     * @return
     * @throws Exception
     */
    public static List<HashMap<String,String>> getAffectedEPart(String changeRequestId) throws Exception {
        WTChangeRequest2 changeRequest = (WTChangeRequest2)CtWTObjectUtil.getObjectByOid(changeRequestId);
        QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
        Object obj = null;
        WTPart tmpPart;
        List<HashMap<String,String>> resultList = new ArrayList<>();
        HashMap<String, String> map = null;
        while(queryResult.hasMoreElements()){
            obj = queryResult.nextElement();
            if(obj instanceof WTPart){
                tmpPart = (WTPart) obj;
                if (tmpPart.getViewName().equals(CtConstant.VIEW_DESIGN)) {
                    map = new HashMap<>();
                    map.put("partNumber",tmpPart.getNumber());
                    map.put("viewName",tmpPart.getViewName());
                    resultList.add(map);
                }
            }
        }
        return resultList;
    }

    public static String genEcrNumber(WTChangeRequest2 changeRequest) throws Exception {
        String ecrNumber = "";
        CtEcQuery query = new CtEcQuery();
        String prefix = new SimpleDateFormat("yyyyMM").format(Calendar.getInstance().getTime());
        String maxNumber = query.getMaxEcrNumberByPrefix(prefix);
        int temp;
        String nextSeq;
        if ("".equals(maxNumber)){
            nextSeq = "0001";
        }else {
            nextSeq = maxNumber.substring(maxNumber.length()-4);
            temp = Integer.valueOf(nextSeq)+1;
            nextSeq = String.format("%04d",temp);
        }
        ecrNumber = prefix+nextSeq;
        CtEcUtil.updateEcrNumber(changeRequest,ecrNumber);
        System.out.println("ecrNumber = " + ecrNumber);
        return ecrNumber;
    }

    /**
     * ECN自动改部件描述和内部版本
     * @param changeRequest
     * @throws Exception
     */
    public static void autoChangePart(WTChangeRequest2 changeRequest) throws Exception{
        logger.error(">>>>>>>>>>>>>开始 自动改物料>>>>>>>>>>>>>>>>>");
        WTUser curUser = (WTUser) SessionHelper.manager.getPrincipal();
        SessionHelper.manager.setAdministrator();//设置管理员权限
        Transaction tx = new Transaction();
        tx.start();
        try {
            String errorMsg = "";
            String changeRequestId = CtWTObjectUtil.getVid(changeRequest);
            CtEcQuery query = new CtEcQuery();
            List<CtPartChangeItemBo> partChangeItems = query.getPartChangeItems(changeRequestId);
            if(partChangeItems!=null){
                for (CtPartChangeItemBo partChangeItem : partChangeItems) {
                    String partNumber = partChangeItem.getPartNumber();
                    String partNameAfter = partChangeItem.getPartNameAfter();
                    String innerVersionAfter = partChangeItem.getInnerVersionAfter();
                    try{
                        if(CtFormatUtil.hasContent(partNumber)){
                            WTPart ePart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);
                            if(ePart!=null){
                                ePart = (WTPart)CtACLUtil.checkout(ePart, "自动改部件");
                                ePart = (WTPart)CtACLUtil.checkIn(ePart,"自动改部件");
                                IBAUtil ibaUtil = new IBAUtil(ePart);
                                if(CtFormatUtil.hasContent(partNameAfter)){
                                    CtPartUtil.updatePartName(ePart,partNameAfter);
                                    ibaUtil.setIBAValue("ct_Materialdescription",partNameAfter);
                                    ibaUtil.updateIBAHolder(ePart);
                                }
                                if(partNumber.startsWith("13901")){
                                    continue;//软件物料不自动改内部版本
                                }
                                if(CtFormatUtil.hasContent(innerVersionAfter)){
                                    ibaUtil.setIBAValue("ct_banci",innerVersionAfter);
                                    ibaUtil.updateIBAHolder(ePart);
                                }else{
                                    ibaUtil.setIBAValue("ct_banci","");
                                    ibaUtil.updateIBAHolder(ePart);
                                }
                                //lzp start
                                //按研发描述规则更新到研发描述
                                CtPartLogic.genPartDesc(ePart);
                                //lzp end
                            }
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                        errorMsg+="部件编号:"+partNumber+">>>"+e.getMessage();
                    }
                }
            }
            if(CtFormatUtil.hasContent(errorMsg)){
                throw new Exception(errorMsg);
            }
            tx.commit();
            tx=null;
            logger.error(">>>>>>>>>>>>>结束 自动改部件>>>>>>>>>>>>>>>>>");
        } catch (Exception e) {
            if(tx!=null){
                tx.rollback();
                tx=null;
            }
            e.printStackTrace();
            throw new WTException(e.getLocalizedMessage());
        }finally{
            if(tx!=null){
                tx=null;
            }
            if (curUser != null) {
                try {
                    SessionHelper.manager.setPrincipal(curUser.getName());//恢复权限
                } catch (WTException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public static void sendMsgToDing(WTObject pbo)throws Exception{
        String msgTyp = "markdown";
        if(pbo instanceof WTChangeRequest2){
            WTChangeRequest2 changeRequest = (WTChangeRequest2)pbo;
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("title","ECR发起通知");
            jsonObject.put("text","#####ECR编号:"+changeRequest.getNumber()
                    +"\n#####ECR名称:"+changeRequest.getName()
                    +"\n#####PC端链接:"+ CtCommonUtil.getURL(changeRequest));
            WfProcess process = CtWorkFlowUtil.getProcessByPbo(changeRequest);
            List<WTUser> cc = CtWorkFlowUtil.getUsersFromRole(process, "CC");//CCB167抄送人
            if(cc!=null&&cc.size()>0){
                for (WTUser wtUser : cc) {
                    CtMobileWorkReportLogic logic = new CtMobileWorkReportLogic();
                    logic.sendMsgToDingTalk(msgTyp,jsonObject.toJSONString(),wtUser.getName());
                }
            }
        }else if(pbo instanceof WTChangeActivity2){
            WTChangeActivity2 changeActivity = (WTChangeActivity2)pbo;
            String ecaType = CtWTObjectUtil.getTypeIdentifier(changeActivity);
            ecaType = ecaType.substring(ecaType.lastIndexOf("|")+1);
            Map sendToConfig = getSendToConfig();
            System.out.println(">>>>>>>>>>>>获取ECA抄送配置表>>>>>>>>>"+JSON.toJSONString(sendToConfig));
            System.out.println(">>>>>>>>>>>>当前ECA类型>>>>>>>>>>>>>>"+ecaType);
            Map<String,List<String>> sendRoleOrUsers = (Map<String, List<String>>) sendToConfig.get(ecaType);
            if(sendRoleOrUsers==null){
                throw new Exception("未维护该类型ECA抄送人员，请联系管理员检查配置文件!");
            }
            List<String> roleList = sendRoleOrUsers.get("role");
            List<String> userList = sendRoleOrUsers.get("user");
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("title","ECA完成通知");
            jsonObject.put("text","#####ECA编号:"+changeActivity.getNumber()
                    +"\n#####ECA名称:"+changeActivity.getName()
                    +"\n#####PC端链接:"+ CtCommonUtil.getURL(changeActivity));
            List<String> sendToUsers = new ArrayList<>();
            sendToUsers.add(changeActivity.getCreatorName());
            WfProcess process = CtWorkFlowUtil.getProcessByPbo(changeActivity);
            for (String role : roleList) {
                List<WTUser> cc = CtWorkFlowUtil.getUsersFromRole(process, role);
                sendToUsers.addAll(cc.stream().map(user->user.getName()).collect(Collectors.toList()));
            }
            sendToUsers.addAll(userList);
            sendToUsers = sendToUsers.stream().distinct().collect(Collectors.toList());
            if(sendToUsers!=null&&sendToUsers.size()>0){
                for (String userName : sendToUsers) {
                    CtMobileWorkReportLogic logic = new CtMobileWorkReportLogic();
                    logic.sendMsgToDingTalk(msgTyp,jsonObject.toJSONString(),userName);
                }
            }

        }

    }
    public static Map getSendToConfig() throws Exception {
        Map resultMap = new HashMap();//Key:ecaType  Value:roleOrUserMap
        Workbook workbook = CtExcelReadUtil.readExcel(CtCommonUtil.getWTHomePath() + "/codebase/ext/plm/ec/config/ECA通知人员配置表.xlsx", null);
        Sheet sheet = workbook.getSheetAt(0);
        int physicalNumberOfRows = sheet.getPhysicalNumberOfRows();
        String ecaType = "";
        for (int i = 1; i < physicalNumberOfRows; i++) {//第一行是表头,从第二行开始
            //第2列为ECA类型内部值
            String cellValue = CtExcelReadUtil.getCellValue(sheet, i, 1);
            String role = CtExcelReadUtil.getCellValue(sheet, i, 3);
            String user = CtExcelReadUtil.getCellValue(sheet, i, 5);
            Map roleOrUserMap = new HashMap();//key:role/user  value:List<角色/用户名>
            List<String> roleList = new ArrayList<>();
            List<String> userList = new ArrayList<>();
            if(CtFormatUtil.hasContent(cellValue)){
                ecaType = cellValue;
            }
            if(resultMap.get(ecaType)!=null){
                roleOrUserMap = (Map) resultMap.get(ecaType);
                if(roleOrUserMap.get("role")!=null){
                    roleList = (List<String>) roleOrUserMap.get("role");
                }

                if(roleOrUserMap.get("user")!=null){
                    userList = (List<String>) roleOrUserMap.get("user");
                }
            }
            if (CtFormatUtil.hasContent(user))userList.add(user);
            if (CtFormatUtil.hasContent(role))roleList.add(role);
            roleOrUserMap.put("role",roleList);
            roleOrUserMap.put("user",userList);
            resultMap.put(ecaType,roleOrUserMap);
        }
        return resultMap;
    }

    public static Map assemblyEcReportData(HashMap<String, Object> ls) throws Exception {
        Map resultMap = new HashMap();
        int id = Integer.valueOf(ls.get("ID") + "");
        String changeRequestId = String.valueOf(ls.get("CHANGEREQUESTID"));
        WTChangeRequest2 ecr = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        Object mark = ls.get("MARK");
        resultMap.put("id",id);
        resultMap.put("changeRequestId",changeRequestId);
        String state = ecr.getLifeCycleState().getDisplay(Locale.CHINA);
        resultMap.put("state",state);
        String createDate = String.valueOf(ls.get("createDate"));
        resultMap.put("createDate",createDate);
        if (CtFormatUtil.hasContent(mark)) {
            resultMap.put("ecrNumber",ecr.getNumber());
        }else{
            resultMap.put("ecrNumber",CtFormatUtil.getURL(ecr,ecr.getNumber()));
        }
        //region 新增物料变更父项编码  EBOM父项编码  MBOM父项编码
        CtEcQuery query = new CtEcQuery();
        List<CtPartChangeItemBo> partChangeItems = query.getPartChangeItems(changeRequestId);
        String partF = partChangeItems.stream().map(bo -> bo.getParentNumber()).filter(CtFormatUtil::hasContent).distinct().collect(Collectors.joining(","));
        resultMap.put("partF",partF==null?"":partF);
        List<CtChangeItemBo> eBomChangeItems = query.getEBomChangeItems(changeRequestId);
        String ebomF = eBomChangeItems.stream().map(bo -> bo.getEndPartNumber()).filter(CtFormatUtil::hasContent).distinct().collect(Collectors.joining(","));
        resultMap.put("ebomF", ebomF==null?"":ebomF);
        List<CtChangeItemBo> mBomChangeItems = query.getMBomChangeItems(changeRequestId);
        String mbomF = mBomChangeItems.stream().map(bo -> bo.getEndPartNumber()).filter(CtFormatUtil::hasContent).distinct().collect(Collectors.joining(","));
        resultMap.put("mbomF", mbomF==null?"":mbomF);
        //endregion


        String attValue = String.valueOf(ls.get("ATTVALUE"));
        if(CtFormatUtil.hasContent(attValue)){
            String[] split = attValue.split("@");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            //CCB评审团队完成时间
            List<String> ccbGroupDateKey = Arrays.asList(new String[]{"mnfRep_auditTime", "struTechRep_auditTime", "elecTechRep_auditTime", "hwTechRep_auditTime", "pm_auditTime", "tm_auditTime"
                    , "swTechRep_auditTime", "processTechRep_auditTime", "qualityRep_auditTime", "dateManageMajor_auditTime"
                    , "dateManageEngineer_auditTime", "deviceEngineer_auditTime", "pcRep_auditTime", "mcRep_auditTime"});
            //ECR批准时间
            List<String> ecrApprovalDateKey = Arrays.asList(new String[]{"ecrApprovalTime", "ccb_auditTime"});
            List<Date> ccbGroupDate = new ArrayList<>();
            List<Date> ecrApprovalDate = new ArrayList<>();
            for (int i = 0; i < split.length; i++) {
                String str = split[i];
                if (!CtFormatUtil.hasContent(str)) {
                    continue; // 正常不会执行的
                }
                String[] fileds = str.split("-\\+-"); // eg: head_ecrNumber-+-05933
                if (fileds.length == 2) { // 正常数据都是 2
                    String key = fileds[0];
                    String value = fileds[1];
                    if (CtFormatUtil.hasContent(key)&&CtFormatUtil.hasContent(value)) {
                        resultMap.put(key,value);

                        if (ccbGroupDateKey.contains(key)) {
                            try{
                                Date date = sdf.parse(value);
                                ccbGroupDate.add(date);
                            }catch(Exception e){
                                System.out.println("key>>>>>>"+key+"value>>>>"+value+"日期解析失败");
                                e.printStackTrace();
                            }
                        }
                        if (ecrApprovalDateKey.contains(key)) {
                            try{
                                Date date = sdf.parse(value);
                                ecrApprovalDate.add(date);
                            }catch(Exception e){
                                System.out.println("key>>>>>>"+key+"value>>>>"+value+"日期解析失败");
                                e.printStackTrace();
                            }

                        }

                    }
                }
            }
            if(CtFormatUtil.hasContent(ccbGroupDate)){
                Collections.sort(ccbGroupDate,Collections.reverseOrder());
                Date ccbGroup_auditTime = ccbGroupDate.get(0);
                if(ccbGroup_auditTime!=null){
                    resultMap.put("ccbGroup_auditTime",sdf.format(ccbGroup_auditTime));
                }
            }
            if(CtFormatUtil.hasContent(ecrApprovalDate)){
                Collections.sort(ecrApprovalDate,Collections.reverseOrder());
                Date ecrApprovalTime = ecrApprovalDate.get(0);
                if(ecrApprovalTime!=null){
                    resultMap.put("ecrApprovalTime",sdf.format(ecrApprovalTime));
                }
            }
        }
        return resultMap;
    }

    private static void checkBomState(WTPart fatherPart,WTPart sonPart,String bomType) throws Exception{
        String parentState = fatherPart.getLifeCycleState().getDisplay(Locale.CHINA);
        String childState = sonPart.getLifeCycleState().getDisplay(Locale.CHINA);
        String sonType = CtWTObjectUtil.getTypeIdentifier(sonPart);
        if(bomType.equals("ebom")){
            //EBOM子项校验(父 正常是已生效）
            //父  已生效
            //子  认证中，样机，已生效，停用中
            List<String> validState = Arrays.stream("认证中,样机,已生效,停用中".split(",")).collect(Collectors.toList());
            if(!validState.contains(childState)){
                throw new Exception("子项状态为"+childState+"不符合要求!\r\n");
            }
        }else{//MBOM校验(父 正常是 试产/量产/停用中)
            // 父：量产/停用中  子：已生效、量产、停用中
            // 父：试产        子：已生效、试产/量产、认证中、停用中
            if(parentState.equals("量产")||parentState.equals("停用中")){
                List<String> validState = Arrays.stream("已生效,量产,停用中".split(",")).collect(Collectors.toList());
                if(!validState.contains(childState)){
                    throw new Exception("子项状态为"+childState+"不符合要求!\r\n");
                }
            }else if(parentState.equals("试产")){
                List<String> validState = Arrays.stream("已生效,认证中,试产,量产,停用中".split(",")).collect(Collectors.toList());
                if(!validState.contains(childState)){
                    throw new Exception("子项状态为"+childState+"不符合要求!\r\n");
                }
            }

        }
    }

    //region 获取ECA文档类型
    public static String getEcaDocTypes()throws Exception{
        String ecaDocType = "";
        Properties properties = new Properties();
        properties.load(new InputStreamReader(
                CtEcProperties.class.getResourceAsStream("CtEc.properties"), StandardCharsets.UTF_8));
        Enumeration<?> enumeration = properties.propertyNames();
        while(enumeration.hasMoreElements()){
            String key = (String) enumeration.nextElement();
            if(key.endsWith("_AffectData")){
                String value = (String) properties.get(key);
                if(CtFormatUtil.hasContent(value)){
                    if(CtFormatUtil.hasContent(ecaDocType)){
                        ecaDocType+=",";
                    }
                    ecaDocType+=value;
                }
            }
        }
        return ecaDocType;
    }
    //endregion

    public static Map assemblyNewEcReportData(Map<String, String> resultMap, DateFormat dateFormat) throws Exception {
        String changeRequestId = String.valueOf(resultMap.get("changeRequestId"));
        WTChangeRequest2 ecr = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        Object mark = resultMap.get("MARK");
        String state = ecr.getLifeCycleState().getDisplay(Locale.CHINA);
        resultMap.put("state",state);
        if (CtFormatUtil.hasContent(mark)) {
            resultMap.put("ecrNumber",ecr.getNumber());
        }else{
            resultMap.put("ecrNumber",CtFormatUtil.getURL(ecr,ecr.getNumber()));
        }
        //去重
        removalDuplicate(resultMap, "partF");
        removalDuplicate(resultMap, "ebomF");
        removalDuplicate(resultMap, "mbomF");
        //更改通知
        QueryResult rs = ChangeHelper2.service.getChangeOrders(ecr, true);
        if(rs.hasMoreElements()) {
            WTChangeOrder2 order = (WTChangeOrder2) rs.nextElement();
            if (CtFormatUtil.hasContent(mark)) {
                resultMap.put("ecnNumber",order.getNumber());
            }else{
                resultMap.put("ecnNumber",CtFormatUtil.getURL(order,order.getNumber()));
            }
            Timestamp createTimestamp = order.getCreateTimestamp();
            if(null != createTimestamp){
                String ecnStartTime = dateFormat.format(createTimestamp);
                resultMap.put("ecrApprovalTime", ecnStartTime);
                resultMap.put("ecn_startTime", ecnStartTime);
            }
            Timestamp ecnResolutionDate = order.getResolutionDate();
            if(null != ecnResolutionDate){
                resultMap.put("ecn_endTime", dateFormat.format(ecnResolutionDate));
            }
            //更改任务
            QueryResult rs1 = ChangeHelper2.service.getChangeActivities(order, true);
            if(rs1.hasMoreElements()) {
                WTChangeActivity2 eca = (WTChangeActivity2) rs1.nextElement();
                if (CtFormatUtil.hasContent(mark)) {
                    resultMap.put("ecaNumber",eca.getNumber());
                }else{
                    resultMap.put("ecaNumber",CtFormatUtil.getURL(eca, eca.getNumber()));
                }
                if(null != eca.getCreateTimestamp()){
                    resultMap.put("eca_startTime", dateFormat.format(eca.getCreateTimestamp()));
                }
                if(null != eca.getResolutionDate()){
                    resultMap.put("eca_endTime", dateFormat.format(eca.getResolutionDate()));
                    if(null != ecr.getCreateTimestamp()){
                        Long days = CtDateUtil.getDistDates(ecr.getCreateTimestamp(), eca.getResolutionDate());
                        resultMap.put("ecr_eca", days+"");
                    }
                }
            }
            //闭环流程
            String docBranchId = resultMap.get("branchId");
            if(CtFormatUtil.hasContent(docBranchId)){
                WTDocument closeDoc = null;
                try {
                    closeDoc = CtDocUtil.getDocumentByBranchId(docBranchId);
                } catch (Exception e) {
                }
                if(null != closeDoc){
                    if (CtFormatUtil.hasContent(mark)) {
                        resultMap.put("closeDocNumber",closeDoc.getNumber());
                    }else{
                        resultMap.put("closeDocNumber",CtFormatUtil.getURL(closeDoc,closeDoc.getNumber()));
                    }
                    if (null != closeDoc.getCreateTimestamp()) {
                        resultMap.put("doc_startTime", dateFormat.format(closeDoc.getCreateTimestamp()));
                    }
                    if (null != resultMap.get("closeDocEndTime")) {
                        resultMap.put("result_auditTime", resultMap.get("closeDocEndTime"));
                        if (null != ecr.getCreateTimestamp()) {
                            String closeDocEndTime = resultMap.get("closeDocEndTime");
                            Date closeDocDate = dateFormat.parse(closeDocEndTime);
                            Long days = CtDateUtil.getDistDates(ecr.getCreateTimestamp(), closeDocDate);
                            resultMap.put("ecr_close", days + "");
                        }
                    }
                }
            }
        }
//        Timestamp resolutionDate = ecr.getResolutionDate();
//        if(null != resolutionDate){
//            resultMap.put("result_auditTime", dateFormat.format(resolutionDate));
//        }
        return resultMap;
    }

    public static void removalDuplicate(Map<String, String> resultMap, String key) throws Exception {
        String mapValue = resultMap.get(key);
        if(CtFormatUtil.hasContent(mapValue)){
            String[] strArray = mapValue.split(",");
            Set<String> set = new HashSet<>();
            for(int i = 0;i < strArray.length;i++){
                set.add(strArray[i]);
            }
            resultMap.put(key, StringUtils.join(set, ","));
        }
    }
}
