package ext.plm.ec;

import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtConstant;
import ext.plm.ec.bo.*;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.ec.config.CtEcProperties;
import ext.plm.integration.hr.CtHrLogic;
import ext.plm.integration.sap.CtSapInterface;
import ext.plm.integration.sap.CtSapLogic;
import ext.plm.tool.workItem.config.CtWorkItemCheckProperties;
import ext.plm.util.*;
import jena.query;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.context.Lifecycle;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.*;
import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleServerHelper;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.pom.Transaction;
import wt.project.Role;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class CtEcWfPlugin {
	private static final Logger loggger = LogR.getLogger(CtEcWfPlugin.class.getName());
	// *********************开始****变更请求部分********************************//
	/**
	 * 应用于泛海三江-工程变更流程  流程表达式  生成表头信息
	 *
	 * @param pbo
	 * @throws WTException
	 */
	public static void genHeadInfo(WTObject pbo) throws WTException {

		WTChangeRequest2 changeRequest = (WTChangeRequest2) pbo;
		try {
			CtEcLogic.genEcHeadInfo(changeRequest);
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e.getMessage());
		}

	}


	/**
	 * 应用于： 泛海三江-工程变更流程 -> 自动创建ECN及ECA的条件表达式 自动创建更改通告和更改任务
	 * 
	 * @param pbo
	 * @return 返回失败异常信息
	 */
	public static void autoCreateECN(WTObject pbo) throws WTException {
		WTChangeRequest2 changeRequest = (WTChangeRequest2) pbo;
		try {
			ReferenceFactory rf = new ReferenceFactory();
			String vrChangeRequestId = rf.getReferenceString(changeRequest);
			CtEcLogic.autoCreateECN(vrChangeRequestId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("自动创建ECN失败，异常信息：" + e.getMessage());
		}
	}

	/**
	 * 应用于所有变更任务流程的“自动升版受影响对象”表达式 对受影响对象自动升版
	 * ext.plm.ec.CtEcWfPlugin.autoReviseAffectedData(primaryBusinessObject);
	 * @param pbo
	 */
	public static void autoReviseAffectedData(WTObject pbo) throws WTException {

		WTChangeActivity2 changeActivity2 = (WTChangeActivity2) pbo;
		try {
			CtEcLogic.autoReviseAffectedData(changeActivity2);
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常，请联系管理员！异常信息：" + e.getMessage());
		}
	}

    /**
     * ECA流程表达式: 放在流程已解决前
     * ext.plm.ec.CtEcWfPlugin.setObjState(primaryBusinessObject);
     * ECA流程走完之后  将产生后对象状态设置为受影响对象中相同编号的状态
     * 设置发布状态
     * @param pbo
     * @throws Exception
     */
	public static String  setObjState(WTObject pbo) throws Exception {
	    String errorMsg = "";
	    WTChangeActivity2 changeActivity = (WTChangeActivity2)pbo;
	    //存受影响对象中的部件状态 key:部件编号+@@@+视图   value:状态
	    HashMap<String,State> beforeParts = new HashMap<>();
        //存受影响对象中的文档状态   key:文档编号   value:状态
        HashMap<String,State> beforeEpmDocs = new HashMap<>();
        //存受影响对象中的EPM文档状态   key:EPM文档编号   value:状态
        HashMap<String,State> beforeDocs = new HashMap<>();
        QueryResult changeablesBefore = ChangeHelper2.service.getChangeablesBefore(changeActivity);
        while(changeablesBefore.hasMoreElements()){
            Object o = changeablesBefore.nextElement();
            if(o instanceof WTPart){
                WTPart part = (WTPart)o;
                beforeParts.put(part.getNumber()+"@@@"+part.getViewName(),part.getLifeCycleState());
            }else if(o instanceof WTDocument){
                WTDocument document = (WTDocument)o;
                beforeDocs.put(document.getNumber(),document.getLifeCycleState());
            }else if(o instanceof EPMDocument){
                EPMDocument epmDocument = (EPMDocument)o;
                beforeEpmDocs.put(epmDocument.getNumber(),epmDocument.getLifeCycleState());
            }
        }

        QueryResult changeablesAfter = ChangeHelper2.service.getChangeablesAfter(changeActivity);
        while(changeablesAfter.hasMoreElements()){
            Object o = changeablesAfter.nextElement();
            if(o instanceof WTPart){
                WTPart part = (WTPart)o;
                try{
                    State state = beforeParts.get(part.getNumber() + "@@@" + part.getViewName());
                    if(CtFormatUtil.hasContent(state)){//获取受影响对象中的对象状态，不存在获取上一个大版本最新状态
                        LifeCycleHelper.service.setLifeCycleState(part,state);
                    }else{
						errorMsg+="部件编号>>>>"+part.getNumber()+"视图>>>>"+part.getViewName()+"设置状态异常:未从受影响对象找到对应状态!\r\n";
                    }
                }catch(Exception e){
                    e.printStackTrace();
                    errorMsg+="部件编号>>>>"+part.getNumber()+"视图>>>>"+part.getViewName()+"设置状态异常!"+e.getMessage()+"\r\n";
                }
            }else if(o instanceof WTDocument){
                WTDocument doc = (WTDocument) o;
                try{
                    State state = beforeDocs.get(doc.getNumber());
                    if(CtFormatUtil.hasContent(state)){//获取受影响对象中的对象状态，不存在获取上一个大版本最新状态
                        LifeCycleHelper.service.setLifeCycleState(doc,state);
                    }else{
						errorMsg+="文档编号>>>>"+doc.getNumber()+"设置状态异常:未从受影响对象找到对应状态!\r\n";
                    }
                }catch(Exception e){
                    e.printStackTrace();
                    errorMsg+="文档编号>>>>"+doc.getNumber()+"设置状态异常:"+e.getMessage()+"\r\n";
                }
            }else if(o instanceof EPMDocument){
                EPMDocument epmDoc = (EPMDocument) o;
                try{
                    State state = beforeEpmDocs.get(epmDoc.getNumber());
                    if(CtFormatUtil.hasContent(state)){//获取受影响对象中的对象状态，不存在获取上一个大版本最新状态
                        LifeCycleHelper.service.setLifeCycleState(epmDoc,state);
                    }else{
						errorMsg+="EPM文档编号>>>>"+epmDoc.getNumber()+"设置状态异常:未从受影响对象找到对应状态!\r\n";
                    }
                }catch(Exception e){
                    e.printStackTrace();
                    errorMsg+="EPM文档编号>>>>"+epmDoc.getNumber()+"设置状态异常:"+e.getMessage()+"\r\n";
                }
            }
        }
        if(CtFormatUtil.hasContent(errorMsg)){
        	throw new Exception("设置产生对象状态异常:"+errorMsg);
		}
        return errorMsg;
    }


	/**
	 * 自动改BOM   应用于更改任务自动更改BOM列表
	 * ext.plm.ec.CtEcWfPlugin.autoChangeBom(primaryBusinessObject, "ebom")EBOM更改任务ECA
	 * ext.plm.ec.CtEcWfPlugin.autoChangeBom(primaryBusinessObject, "mbom")MBOM更改任务ECA
	 * @param pbo
	 * @param type  bom类型  ebom/mbom
	 * @throws WTException
	 */
	public static void autoChangeBom(WTObject pbo,String type) throws WTException {
		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			CtEcLogic logic  = new CtEcLogic();
			logic.changeBom(changeRequest,type);

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("自动变更失败：\r\n" + e.getLocalizedMessage());
		}
	}




	/**
	 * 应用于 变更请求 和 变更任务工作流： 所有提交及审批节点的“完成任务”转变条件 完成任务时保存审批用户，审批结果，审批时间
	 * ext.plm.ec.CtEcWfPlugin.saveAuditInfo(primaryBusinessObject,self);
	 * @param pbo
	 * @param self
	 * @throws WTException
	 */
	public static void saveAuditInfo(WTObject pbo, Object self) throws WTException {

		Transaction ts = new Transaction();
		ts.start();
		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			ReferenceFactory rf = new ReferenceFactory();
			String vrChangeRequestId = rf.getReferenceString(changeRequest);
			String activityKey = getActivityKey(self);

			String userName = CtCommonUtil.getCurrentUserFullName();
			String auditDate = CtDateUtil.getCurrentDate("yyyy-MM-dd", CtConstant.TIMEZONE_FORMAT);
			String auditResult = getAuditResult(self);
			// 获取活动节点前缀，如"head_"
			int index = activityKey.indexOf("_");
			String activityPrefix = activityKey.substring(0, index);

			// 保存审批用户与审批时间
			CtEcQuery query = new CtEcQuery();
			String formMasterId = query.genFormMasterId(vrChangeRequestId, activityKey);
			query.saveAttribute(activityPrefix + "_auditUser", userName, formMasterId);
			query.saveAttribute(activityPrefix + "_auditResult", auditResult, formMasterId);
			query.saveAttribute(activityPrefix + "_auditTime", auditDate, formMasterId);
			//如果是PDT团队评审  保存到PDT评审信息记录表中
			if("pdt2_node".equals(activityKey)){
				CtEcPdtAuditInfoBo pdtAuditInfoBo = new CtEcPdtAuditInfoBo();
				pdtAuditInfoBo.setChangeRequestId(vrChangeRequestId);
				pdtAuditInfoBo.setAuditUser(userName);
				pdtAuditInfoBo.setAuditTime(auditDate);
				pdtAuditInfoBo.setAuditComment(getAuditComment(self));
				query.savePdtAuditInfo(pdtAuditInfoBo);
			}
			ts.commit();
			ts = null;
		} catch (Exception e) {
			if(ts != null)ts.rollback();
			e.printStackTrace();
			throw new WTException("保存审批信息失败！异常信息：" + e.getMessage());
		}finally{
			if(ts!=null)ts=null;
		}
	}



	/**
	 * 应用于变更请求流程里 采购分析列表的”完成任务“转变条件
	 * 采购分析列表必填字段验证
	 * @param pbo
	 */
	public static void checkPcrList(WTObject pbo) throws Exception {
		/*
		  //采购领域表格数据必填验证
		  ext.plm.ec.CtEcWfPlugin.checkPcrList(primaryBusinessObject);
		 */
		StringBuffer errorMsg = new StringBuffer();
		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			//判断受影响对象中是否有部件
			boolean hasPart = false;
			QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
			while(queryResult.hasMoreElements()){
				Object obj = queryResult.nextElement();
				if(obj instanceof WTPart){
					WTPart part = (WTPart)obj;
					hasPart =true;
					break;
				}
			}
			if(hasPart){
				ReferenceFactory rf = new ReferenceFactory();
				String changeRequestId = rf.getReferenceString(changeRequest);
				CtEcQuery query = new CtEcQuery();
				List<CtEcPcrMaterialItemBo> items = query.getPcrMaterialItems(changeRequestId);
				if(CollectionUtils.isEmpty(items)) {
					throw new WTException("采购领域表格数据不能为空！");
				}
				for(CtEcPcrMaterialItemBo bo:items) {
					String str = "";
					String partNumber = bo.getPartNumber();
//				if(!CtFormatUtil.hasContent(bo.getSupplierName())) {
//					str += "  供应商名称  ";
//				}
//				if(!CtFormatUtil.hasContent(bo.getSupplierStockUp())) {
//					str += "  供应商备货  ";
//				}
//				if(!CtFormatUtil.hasContent(bo.getRemark())) {
//					str += "  备注  ";
//				}
					if(CtFormatUtil.hasContent(str)) {
						errorMsg.append("编码:"+partNumber+str+"字段为空!").append("\r\n");
					}
				}

				if(CtFormatUtil.hasContent(errorMsg.toString())) {
					throw new WTException("以下物料的对应必填字段不能为空:\r\n"+errorMsg.toString());
				}
			}
		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常，检查列表必填项出错！异常信息：" + e.getMessage());
		}
	}

	/*
	采购工程师节点校验必填
	 */
	public static void checkPcrList1(WTObject pbo, Object self) throws Exception {
		/*
		  //采购领域表格数据必填验证
		  ext.plm.ec.CtEcWfPlugin.checkPcrList(primaryBusinessObject);
		 */
		StringBuffer errorMsg = new StringBuffer();
		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			//判断受影响对象中是否有部件
			boolean hasPart = false;
			QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
			while(queryResult.hasMoreElements()){
				Object obj = queryResult.nextElement();
				if(obj instanceof WTPart){
					WTPart part = (WTPart)obj;
					hasPart =true;
					break;
				}
			}
			if(hasPart){
				ReferenceFactory rf = new ReferenceFactory();
				String changeRequestId = rf.getReferenceString(changeRequest);
				CtEcQuery query = new CtEcQuery();
				List<CtEcPcrMaterialItemBo> items = query.getPcrMaterialItems(changeRequestId);
				if(!CollectionUtils.isEmpty(items)) {
					for(CtEcPcrMaterialItemBo bo:items) {
						String str = "";
						String partNumber = bo.getPartNumber();
						String activityKey = getActivityKey(self);
						if("pcegRep_node".equals(activityKey)){
							if(!CtFormatUtil.hasContent(bo.getSupplierName())) {
								str += "  供应商名称  ";
							}
							if(!CtFormatUtil.hasContent(bo.getSupplierStockUp())) {
								str += "  供应商备货  ";
							}
						}

//				if(!CtFormatUtil.hasContent(bo.getRemark())) {
//					str += "  备注  ";
//				}
						if(CtFormatUtil.hasContent(str)) {
							errorMsg.append("编码:"+partNumber+str+"字段为空!").append("\r\n");
						}
					}
				}


				if(CtFormatUtil.hasContent(errorMsg.toString())) {
					throw new WTException("以下物料的对应必填字段不能为空:\r\n"+errorMsg.toString());
				}
			}
		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常，检查列表必填项出错！异常信息：" + e.getMessage());
		}
	}

	
	/**
	 *
	 *  库存和计划分析列表必填字段验证
	 * @param pbo
	 */
	public static void checkPmcList(WTObject pbo) throws WTException {
		/*
		  //物控领域表格必填验证
		  ext.plm.ec.CtEcWfPlugin.checkPmcList(primaryBusinessObject);
		 */
		StringBuffer errorMsg = new StringBuffer();
		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			//判断受影响对象中是否有部件
			boolean hasPart = false;
			QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
			while(queryResult.hasMoreElements()){
				Object obj = queryResult.nextElement();
				if(obj instanceof WTPart){
					WTPart part = (WTPart)obj;
					hasPart =true;
					break;
				}
			}
			if(hasPart) {
				ReferenceFactory rf = new ReferenceFactory();
				String changeRequestId = rf.getReferenceString(changeRequest);
				CtEcQuery query = new CtEcQuery();
				List<CtEcPmcMaterialItemBo> items = query.getPmcMaterialItems(changeRequestId);
				if(CollectionUtils.isEmpty(items)) {
					throw new WTException("物控领域表格数据不能为空！");
				}
				for(CtEcPmcMaterialItemBo bo:items) {
					String str = "";
					//空字段校验
//				if(!CtFormatUtil.hasContent(bo.getAmount())) {
//					str = bo.getMaterialNumber();
//				}

					if(CtFormatUtil.hasContent(str)) {
						errorMsg.append(str).append("\r\n");
					}
				}

				if(CtFormatUtil.hasContent(errorMsg.toString())) {
					throw new WTException("以下物料的对应必填字段不能为空:\r\n"+errorMsg.toString());
				}
			}

		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常，检查物控领域数据列表必填项出错！异常信息：" + e.getMessage());
		}
	}

	/**
	 *
	 * ext.plm.ec.CtEcWfPlugin.setEcrIBA(primaryBusinessObject,self);
	 * 应用于变更请求  工程变更流程里 提交节点  提交转变  反写表单属性到IBA
	 * @param pbo
	 * @param self
	 */
	public static void setEcrIBA(WTObject pbo, Object self) throws WTException {

		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			ReferenceFactory rf = new ReferenceFactory();
			String changeRequestId = rf.getReferenceString(changeRequest);
			CtEcQuery query = new CtEcQuery();
			IBAUtil ibaUtil = new IBAUtil(changeRequest);
			Set<Map.Entry<String, String>> entries = CtEcConstant.formAtt_IBA_Map.entrySet();
			for (Map.Entry<String, String> entry : entries) {
				String attributeValue = query.getAttributeValue(changeRequestId, entry.getKey());
				if(CtFormatUtil.hasContent(attributeValue)){
					ibaUtil.setIBAValue(entry.getValue(),attributeValue);
				}
			}
			ibaUtil.updateIBAHolder(changeRequest);

			//保存结束时间  报表使用
			String activityKey = "result_node";
			String auditDate = CtDateUtil.getCurrentDate("yyyy-MM-dd", CtConstant.TIMEZONE_FORMAT);
			String formMasterId = query.genFormMasterId(changeRequestId, activityKey);
			if (changeRequest.getLifeCycleState().getDisplay(Locale.CHINA).equals("已解决")) {
				query.saveAttribute("result_auditTime", auditDate, formMasterId);
			}
		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常，异常信息：" + e.getMessage());
		}
	}
	
	/**
	 *
	 * ext.plm.ec.CtEcWfPlugin.checkForm(primaryBusinessObject,self);
	 * 应用于变更请求  工程变更流程里 各个节点的”完成任务“转变条件
	 * 表单必填字段验证
	 * @param pbo
	 * @param self
	 */
	public static void checkForm(WTObject pbo, Object self) throws WTException {

		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			ReferenceFactory rf = new ReferenceFactory();
			String changeRequestId = rf.getReferenceString(changeRequest);
			String emptyAtts = "";
			// 取activityKey
			String activityKey = getActivityKey(self);
			System.out.println("=================变更表单校验===================");
			System.out.println("activityKey=============="+activityKey);

			// 取必填字段（来自配置文件EcFormRequiredAttMap.properties)
			List<String> requiredAtts = CtEcProperties.getRequiredAtts(activityKey);
			System.out.println("requiredAtts=============="+requiredAtts);
			CtEcQuery query = new CtEcQuery();
			String head_changeType = query.getAttributeValue(changeRequestId, "head_changeType");
			if("head_node".equals(activityKey)){
				if(head_changeType.indexOf("快速变更")>-1){
					requiredAtts.remove("trialSuggest");
				}
				if((head_changeType.indexOf("快速变更1")>-1||head_changeType.indexOf("快速变更2")>-1)){
					requiredAtts.remove("isSource");
					requiredAtts.remove("head_noNeedReason");
					requiredAtts.remove("head_uploadFileRecord");
				}else if(head_changeType.indexOf("快速变更3")>-1){
					requiredAtts.add("rdRep_ebomChangePlan");
				}
			}
			if(head_changeType.indexOf("快速变更")>-1){
					requiredAtts.remove("isNeedSmallCheck");
			}

			if (requiredAtts.contains("isSource") && query.getAttributeValue(changeRequestId, "isSource").equals("是")){
				requiredAtts.remove("head_noNeedReason");
			}else if (requiredAtts.contains("isSource") && query.getAttributeValue(changeRequestId, "isSource").equals("否")){
				requiredAtts.remove("head_uploadFileRecord");
			}else if (requiredAtts.contains("isEcrChange") && query.getAttributeValue(changeRequestId, "isEcrChange").equals("否")){
				requiredAtts.remove("mCaMbomCharge_uploadFileRecord");
			}else if (requiredAtts.contains("isEcrChange2") && query.getAttributeValue(changeRequestId, "isEcrChange2").equals("否")){
				requiredAtts.remove("eCaEbomCharge2_uploadFileRecord");
			}else if (requiredAtts.contains("trialConclusion") && query.getAttributeValue(changeRequestId, "trialConclusion").equals("V1")){
				requiredAtts.remove("eCaTrialRespon_ngConclusion");
			}
			for (Iterator<String> ite = requiredAtts.iterator(); ite.hasNext();) {
				String attKey = ite.next();
				String attValue = query.getAttributeValue(changeRequestId, attKey);
				System.out.println("attKey===================="+attKey);
				System.out.println("attValue===================="+attValue);
				if (!CtFormatUtil.hasContent(attValue)) {
					String attDisplayname = CtEcProperties.getAttDisplayName(attKey);
					emptyAtts += attDisplayname + "\r\n";
				}
			}

			if (CtFormatUtil.hasContent(emptyAtts)) {
				throw new WTException("以下字段必填，请输入内容后再提交！\r\n" + emptyAtts);
			}

		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
		}
	}

	/**
	 * 变更流程 >>>变更流程_CCB方案批准>>> 转变 >>>>无需IPMT批准时校验
	 * ext.plm.ec.CtEcWfPlugin.check3C(primaryBusinessObject);
	 * @param pbo
	 */
	public static void check3C(WTObject pbo) throws Exception{
		WTChangeRequest2 changeRequest = getChangeRequest(pbo);
		Set<String> affected3CEndItemNumbers = new HashSet<>();
		QueryResult changeAbles = ChangeHelper2.service.getChangeables(changeRequest);
		Object obj = null;
		WTPart tmpPart;
		while (changeAbles.hasMoreElements()) {
			obj = changeAbles.nextElement();
			if (obj instanceof WTPart) {
				tmpPart = (WTPart) obj;
				String partType = CtWTObjectUtil.getTypeIdentifier(tmpPart);
				if(partType.contains(CtEcConstant.Ct_PartType_EndPart)){
					IBAUtility ibaUtility = new IBAUtility(tmpPart);
					Vector<String> ibaValues = ibaUtility.getIBAValues("ct_whetherCensorship");
					for (String ibaValue : ibaValues) {
						if("1".equals(ibaValue)){
							affected3CEndItemNumbers.add(tmpPart.getNumber());
						}
					}
				}
			}
		}
		QueryResult affectedEndItems = ChangeHelper2.service.getSubjectProducts(changeRequest);
		WTPartMaster tmpPartMaster = null;
		while (affectedEndItems.hasMoreElements()) {
			obj = affectedEndItems.nextElement();
			tmpPartMaster = (WTPartMaster) obj;
			tmpPart = (WTPart) CtVersionUtil.getLatest(tmpPartMaster);
			IBAUtility ibaUtility = new IBAUtility(tmpPart);
			Vector<String> ibaValues = ibaUtility.getIBAValues("ct_whetherCensorship");//获证类型
			for (String ibaValue : ibaValues) {
				if("1".equals(ibaValue)){
					affected3CEndItemNumbers.add(tmpPart.getNumber());
				}
			}
		}
		if(affected3CEndItemNumbers!=null&&affected3CEndItemNumbers.size()>0){
			throw new Exception("以下受影响成品为'CCC认证',不允许选择'无需IPMT批准'!\r\n"+affected3CEndItemNumbers);
		}

	}

	/**
	 * 泛海三江-MBOM更改任务ECA
	 * 提交节点校验:
	 * 			是否存在并行的EBOM更改任务，如有，必须已解决
	 * ext.plm.ec.CtEcWfPlugin.checkEbomECA(primaryBusinessObject,self);
	 * @param pbo
	 */
	public static void checkEbomECA(WTObject pbo,Object self) throws Exception{
		WTChangeActivity2 changeActivity = (WTChangeActivity2)pbo;
		WTChangeOrder2 changeOrder = null;
		QueryResult qr =ChangeHelper2.service.getChangeOrder(changeActivity);
		if(qr.hasMoreElements()){
			changeOrder =  (WTChangeOrder2)qr.nextElement();
			QueryResult qr2 = ChangeHelper2.service.getChangeActivities(changeOrder);
			while(qr2.hasMoreElements()){
				Object o = qr2.nextElement();
				WTChangeActivity2 ca = (WTChangeActivity2)o;
				String state = ca.getLifeCycleState().getDisplay(Locale.CHINA);
				String ecType = CtWTObjectUtil.getTypeIdentifier(ca);
				if(ecType.contains(CtEcConstant.Ct_EcaType_EBOM)){
					if(!"已解决".equals(state)){
						throw new Exception("存在并行的EBOM更改任务ECA待解决!\r\n");
					}
				}
			}
		}

	}

	/**
	 * MBOM更改任务ECA
	 * 			是否存在并行的EBOM更改任务，如有，等待
	 * @param pbo
	 * @param self
	 * @return
	 * @throws Exception
	 */
	public static boolean isEbomECA(WTObject pbo, Object self) {
		try {
			WTChangeActivity2 changeActivity = (WTChangeActivity2) pbo;
			WTChangeOrder2 changeOrder = null;
			QueryResult qr = ChangeHelper2.service.getChangeOrder(changeActivity);
			if (qr.hasMoreElements()) {
				changeOrder = (WTChangeOrder2) qr.nextElement();
				QueryResult qr2 = ChangeHelper2.service.getChangeActivities(changeOrder);
				while (qr2.hasMoreElements()) {
					Object o = qr2.nextElement();
					WTChangeActivity2 ca = (WTChangeActivity2) o;
					String state = ca.getLifeCycleState().getDisplay(Locale.CHINA);
					String ecType = CtWTObjectUtil.getTypeIdentifier(ca);
					if (ecType.contains(CtEcConstant.Ct_EcaType_EBOM)) {
						if (!"已解决".equals(state)) {
							return false;
						} else {
							return true;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			loggger.error("mbom审核异常----》" + e);
		}
		return true;
	}
	/**
	 * 变更请求流程中调用  获取发起人填写的更改类型  用于判断流程路由
	 * result = ext.plm.ec.CtEcWfPlugin.getChangeType(primaryBusinessObject,self);
	 * @param pbo
	 * @param self
	 * @return
	 * @throws WTException
	 */
	public static String getChangeType(WTObject pbo, Object self) throws WTException {

		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			ReferenceFactory rf = new ReferenceFactory();
			String changeRequestId = rf.getReferenceString(changeRequest);
			CtEcQuery query = new CtEcQuery();
			String attKey = "head_changeType";
			String attValue = query.getAttributeValue(changeRequestId, attKey);

			if (!CtFormatUtil.hasContent(attValue)) {
				throw new WTException("更改类型为空!");
			}
			if(attValue.length()>5){
				attValue = attValue.substring(0,5);
			}
			return attValue;
		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常！异常信息：" + e.getMessage());
		}
	}

	/**
	 * 变更请求流程中调用  获取发起人填写的更改子类型  用于判断流程路由
	 * result = ext.plm.ec.CtEcWfPlugin.getChangeSubType(primaryBusinessObject,self);
	 * @param pbo
	 * @param self
	 * @return
	 * @throws WTException
	 */
	public static String getChangeSubType(WTObject pbo, Object self) throws WTException {

		try {
			WTChangeRequest2 changeRequest = getChangeRequest(pbo);
			ReferenceFactory rf = new ReferenceFactory();
			String changeRequestId = rf.getReferenceString(changeRequest);
			CtEcQuery query = new CtEcQuery();
			String attKey = "head_changeSubType";
			String attValue = query.getAttributeValue(changeRequestId, attKey);
			if (!CtFormatUtil.hasContent(attValue)) {
				throw new WTException("更改子类型为空!");
			}
			return attValue;
		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常！异常信息：" + e.getMessage());
		}
	}



	
	/**
	 * 应用于工程变更流程
     *      变更流程_EBOM变更负责人制定EBOM变更方案    转变-->完成
     *          ext.plm.ec.CtEcWfPlugin.checkChangeItems(primaryBusinessObject, "ebom")
     *      变更流程_MBOM变更负责人制定MBOM变更方案    转变-->通过
     *          ext.plm.ec.CtEcWfPlugin.checkChangeItems(primaryBusinessObject, "mbom")
	 * @param pbo
	 * @throws WTException
	 */

	public static void checkChangeItems(WTObject pbo,String bomType) throws Exception {
        StringBuffer errorMsg = new StringBuffer();
		WTChangeRequest2 changeRequest = getChangeRequest(pbo);
        String changeRequestId = CtWTObjectUtil.getVid(changeRequest);
        CtEcQuery query = new CtEcQuery();
		//校验替代组和优先级
		String viewName = "mbom".equals(bomType)?CtConstant.VIEW_MANUFACTURING:CtConstant.VIEW_DESIGN;
        List<CtChangeItemBo> changeItems = query.getChangeItems(changeRequestId, bomType);
		if(changeItems==null&&changeItems.size()==0){
//            throw new Exception("变更列表为空!\r\n");
            return;
        }
		//基本校验  EBOM和MBOM列表
        for (CtChangeItemBo changeItem : changeItems) {
            String changeType = changeItem.getChangeType();
			String parentNumber = changeItem.getParentNumber();
			String childNumberBefore = changeItem.getChildNumberBefore();
			String childNumberAfter = changeItem.getChildNumberAfter();
			if(!CtFormatUtil.hasContent(changeType)){
                throw new Exception("检测到变更列表中存在【变更类型】为空的数据,请检查!\r\n");
            }
            if(CtFormatUtil.hasContent(childNumberAfter)){
                String amountAfter = changeItem.getAmountAfter();
                if(!CtFormatUtil.hasContent(amountAfter)){
                    errorMsg.append("变更后编码【"+childNumberAfter+"】变更后数量为空!\r\n");
                }
            }
			String replaceNumberAfter = changeItem.getReplaceNumberAfter();
			String priorityAfter = changeItem.getPriorityAfter();
			if((CtFormatUtil.hasContent(replaceNumberAfter)&&!CtFormatUtil.hasContent(priorityAfter))
				||(!CtFormatUtil.hasContent(replaceNumberAfter)&&CtFormatUtil.hasContent(priorityAfter))){
				throw new Exception("数据填写不规范,替代组编号和替代组优先级必须一起填写!\r\n");
			}
			if(!CtFormatUtil.hasContent(parentNumber)){
				throw new Exception("检测到变更列表中存在父项料号未填写的数据,请检查!\r\n");
			}
			if(CtFormatUtil.hasContent(childNumberBefore)&&CtFormatUtil.hasContent(childNumberAfter)&&!childNumberAfter.equals(childNumberBefore)){
				WTPart parentPart = CtPartUtil.getPartByNumber(parentNumber, viewName);
				WTPart childPartAfter = CtPartUtil.getPartByNumber(childNumberAfter);
				if(CtFormatUtil.hasContent(CtBomUtil.getUsageLink(parentPart,childPartAfter))){
					throw new Exception("父项编码"+parentNumber+"变更后子项编码"+childNumberAfter+"已经存在上下阶关系，变更前编码"+childNumberBefore+"不一致,请检查修改!");
				}
			}

		}

		//第一步:校验表单是否有重复替代组
		HashMap<String,HashSet<String>> replaceGroupMap = new HashMap<>();;//key:父项编号  value:替代组和优先级集合
		HashSet<String> replaceGroupSet = null;//替代组编号@@@替代组优先级
		for (CtChangeItemBo changeItem : changeItems) {
			String replaceNumberAfter = changeItem.getReplaceNumberAfter();
			String priorityAfter = changeItem.getPriorityAfter();
			if(!CtFormatUtil.hasContent(replaceNumberAfter)){
				continue;//跳过替代组为空的
			}
			String parentNumber = changeItem.getParentNumber();
			replaceGroupSet = replaceGroupMap.get(parentNumber);
			if(!CtFormatUtil.hasContent(replaceGroupSet)){
				replaceGroupSet = new HashSet<>();
			}
			if(replaceGroupSet.contains(replaceNumberAfter+"@@@"+priorityAfter)){
				throw new Exception("更改列表中父项:"+parentNumber+"\r\n存在相同替代组:"+replaceNumberAfter+"优先级:"+priorityAfter);
			}
			replaceGroupSet.add(replaceNumberAfter+"@@@"+priorityAfter);
			replaceGroupMap.put(parentNumber,replaceGroupSet);
		}
		//第二步 收集所有受影响BOM下的替代组和优先级
		HashSet<String> affectedMBomNumbers = CtEcLogic.getAffectedBomNumbers(changeRequest, viewName);
		for (String affectedMBomNumber : affectedMBomNumbers) {
			replaceGroupSet = new HashSet<>();
			WTPart parentPart = CtPartUtil.getPartByNumber(affectedMBomNumber,viewName);
			QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(parentPart);
			while (linkQr.hasMoreElements()) {
				WTPartUsageLink qrLink = (WTPartUsageLink) linkQr.nextElement();
				IBAUtil ibaUtil = new IBAUtil(qrLink);
				String replaceGroup = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroup);
				String replacePriority = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_replaceGroupPriority);
				if(CtFormatUtil.hasContent(replaceGroup)&&CtFormatUtil.hasContent(replacePriority)){
					replaceGroupSet.add(replaceGroup+"@@@"+replacePriority);
				}
			}
			replaceGroupMap.put(affectedMBomNumber,replaceGroupSet);
		}
		//第三步  去除更改前的替代组
		for (CtChangeItemBo changeItem : changeItems) {
			String parentNumber = changeItem.getParentNumber();
			String priorityBefore = changeItem.getPriorityBefore();
			String replaceNumberBefore = changeItem.getReplaceNumberBefore();
			replaceGroupSet = replaceGroupMap.get(parentNumber);
			if(!CtFormatUtil.hasContent(replaceNumberBefore)&&!CtFormatUtil.hasContent(priorityBefore)){
				continue;
			}
			boolean remove = replaceGroupSet.remove(replaceNumberBefore + "@@@" + priorityBefore);
			if(!remove){
				System.out.println("MBOM变更列表校验:存在异常数据>>>>>>>>父项:"+parentNumber+"\r\n替代组:"+replaceNumberBefore + "@@@" + priorityBefore);
			}
		}
		HashSet<String> parentNumbers = new HashSet<>();
		for (CtChangeItemBo changeItem : changeItems) {
			String parentNumber = changeItem.getParentNumber();
			parentNumbers.add(parentNumber);
			String replaceNumberAfter = changeItem.getReplaceNumberAfter();
			String priorityAfter = changeItem.getPriorityAfter();
			replaceGroupSet = replaceGroupMap.get(parentNumber);
			if(CtFormatUtil.hasContent(replaceNumberAfter)){
				if(replaceGroupSet.contains(replaceNumberAfter+"@@@"+priorityAfter)){
					errorMsg.append("变更列表父项编号:"+parentNumber+"更改后BOM存在重复替代组:"+replaceNumberAfter+"优先级:"+priorityAfter+"\r\n");
				}else{
					replaceGroupSet.add(replaceNumberAfter+"@@@"+priorityAfter);
				}
			}
		}
		for (String parentNumber : parentNumbers) {
			HashMap<String,List<String>> map = new HashMap<>();//key:替代组  value:优先级集合
			List<String> list = null;
			HashSet<String> set = replaceGroupMap.get(parentNumber);
			if(set==null)continue;
			Iterator<String> iterator = set.iterator();
			while(iterator.hasNext()){
				String next = iterator.next();
				String[] split = next.split("@@@");
				String s = split[0];//替代组
				String s1 = split[1];//优先级
				list = map.get(s);
				if(list==null){
					list = new ArrayList<>();
				}
				list.add(s1);
				map.put(s,list);
			}
			for (String s : map.keySet()) {
				List<String> stringList = map.get(s);
				if(stringList.size()==1){
					errorMsg.append("变更列表父项编号:"+parentNumber+"更改后BOM存在替代组:"+s+"仅有一个优先级!\r\n");
				}
				if(!stringList.contains("1")){
					errorMsg.append("变更列表父项编号:"+parentNumber+"更改后BOM中替代组:"+s+"没有优先级为1的!\r\n");
				}
			}

		}


        if(errorMsg!=null&&errorMsg.length()>0){
            throw new Exception("当前变更列表中:\r\n"+errorMsg.toString());
        }

	}



	

	/**
	 * 从流程变更self出发，获得活动对应的key值，前台判断权限等功能需要用到此key
	 *
	 * @param self
	 * @return
	 * @throws Exception
	 */
	private static String getActivityKey(Object self) throws Exception {

		String actName = ""; // 活动名称（工作流模板中的活动）
		String activityKey = "";// 活动Key值

		// self有时是ObjectReference对象，有时直接是WorkItem或WfAssignedActivity
		if (self instanceof ObjectReference) {
			self = ((ObjectReference) self).getObject();
		}

		if (self instanceof WorkItem) {

			WorkItem workItem = (WorkItem) self;
			WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
			actName = activity.getName();
			activityKey = CtEcProperties.getActivityKey(actName);

		} else if (self instanceof WfAssignedActivity) {
			WfAssignedActivity activity = (WfAssignedActivity) self;
			actName = activity.getName();
			// activityKey = CtEcLogic.getActivityKeyByActivityName(actName);
			activityKey = CtEcProperties.getActivityKey(actName);
		}

		if (!CtFormatUtil.hasContent(activityKey)) {
			System.out.println(">>>>actName='" + actName + "'无法找到对应的Key,需要核对配置表EcActivityKeyMap.properties！");
			throw new WTException("后台异常，无法找到当前流程活动对应的Key，请联系管理员！");
		}

		return activityKey;
	}

	/**
	 * 获取更改请求
	 * @param pbo
	 * @return
	 * @throws WTException
	 */
	public static WTChangeRequest2 getChangeRequest(WTObject pbo) throws WTException {
		WTChangeRequest2 changeRequest = null;
		if(pbo instanceof WTChangeRequest2){
			changeRequest = (WTChangeRequest2)pbo;
		}

		if(pbo instanceof WTChangeOrder2){
			WTChangeOrder2 changeOrder = (WTChangeOrder2)pbo;
			QueryResult qr =ChangeHelper2.service.getChangeRequest(changeOrder);
			while(qr.hasMoreElements()){
				changeRequest = (WTChangeRequest2)qr.nextElement();
			}
		}

		if(pbo instanceof WTChangeActivity2){
			WTChangeActivity2 changeActivity = (WTChangeActivity2)pbo;
			WTChangeOrder2 changeOrder = null;
			QueryResult qr =ChangeHelper2.service.getChangeOrder(changeActivity);
			if(qr.hasMoreElements()){
				changeOrder =  (WTChangeOrder2)qr.nextElement();
			}
			QueryResult qr2 =ChangeHelper2.service.getChangeRequest(changeOrder);
			if(qr2.hasMoreElements()){
				changeRequest =  (WTChangeRequest2)qr2.nextElement();
			}
		}
		return changeRequest;
	}

	/**
	 * 获取投票结果
	 */
	private static String getAuditResult(Object self) throws Exception{
		String result = "通过";
		if (self instanceof ObjectReference) {
			self = ((ObjectReference) self).getObject();
		}
		if (self instanceof WorkItem) {
			WorkItem workItem = (WorkItem) self;
			WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
			String taskVote = CtWorkFlowUtil.getTaskVote(activity);
			if(taskVote.contains("驳回")){
				return "驳回";
			}
		} else if (self instanceof WfAssignedActivity) {
			WfAssignedActivity activity = (WfAssignedActivity) self;
			String taskVote = CtWorkFlowUtil.getTaskVote(activity);
			if(taskVote.contains("驳回")){
				return "驳回";
			}
		}
		return result;
	}

	/**
	 * 获取投票备注信息
	 */
	private static String getAuditComment(Object self) throws Exception{
		String result = "";
		if (self instanceof ObjectReference) {
			self = ((ObjectReference) self).getObject();
		}
		if (self instanceof WorkItem) {
			WorkItem workItem = (WorkItem) self;
			WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
			result = CtWorkFlowUtil.getTaskComment(activity);
		} else if (self instanceof WfAssignedActivity) {
			WfAssignedActivity activity = (WfAssignedActivity) self;
			result = CtWorkFlowUtil.getTaskComment(activity);
		}
		return result;
	}

	/**
	 *应用于ECA流程表达式，自动带入ECR相应角色下的人
	 * 2021/11/14新增  自动带出库团队的人
	 *ext.plm.ec.CtEcWfPlugin.setECARoles(primaryBusinessObject,self)
	 */
	public static void setECARoles(WTObject pbo,ObjectReference self) throws Exception {
		WTChangeActivity2 eca = (WTChangeActivity2)pbo;
		WTChangeRequest2 changeRequest = getChangeRequest(eca);

		//重新分配流程角色  带入库下的人
		assignWfProcessUser(pbo, self);

		//自动带入更改请求对应角色下的用户
		Team team = TeamHelper.service.getTeam(changeRequest);
		WfProcess process = CtWorkFlowUtil.getProcess(self);
		Team processTeam = (Team) process.getTeamId().getObject();
		Map rolePrincipalMap = processTeam.getRolePrincipalMap();
		for (Object obj : rolePrincipalMap.keySet()) {
			Enumeration userEnum = team.getPrincipalTarget(Role.toRole(obj.toString()));
			List<WTUser> users = new ArrayList<>();
			while (userEnum.hasMoreElements()) {
				WTPrincipalReference wtpRef = (WTPrincipalReference) userEnum.nextElement() ;
				Persistable  pp = wtpRef.getObject() ;
				if (pp instanceof WTPrincipal && pp instanceof WTUser) {
					WTUser tempUser = (WTUser) pp ;
					users.add(tempUser) ;
				}
			}
			if(users!=null&&users.size()>0){
				CtWorkFlowUtil.setUsersToRole(pbo,self,users,obj.toString());
			}
		}
	}

	/**
	 *应用于ECR变更流程表达式  用于清空非必选的角色下的人员
	 *ext.plm.ec.CtEcWfPlugin.setAllowEmptyRoles(primaryBusinessObject,self)
	 */
	public static void setAllowEmptyRoles(WTObject pbo,ObjectReference self) throws Exception {
		WTChangeRequest2 changeRequest = getChangeRequest(pbo);
		IBAUtil ibaUtil = new IBAUtil(changeRequest);
		String changeType = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_changeType);
		if(!CtFormatUtil.hasContent(changeType)){
			throw new Exception("变更类型为空!无法判断非必填角色!\r\n");
		}
		HashMap<String, String> allowEmptyUserMap = CtWorkItemCheckProperties.getAllowEmptyUserMap();
		String allowEmptyRoles = allowEmptyUserMap.get(changeType);
		if(!CtFormatUtil.hasContent(allowEmptyRoles)){
			throw new Exception("变更类型+【"+changeType+"】未配置非必选角色，请联系管理员维护配置文件!");
		}
		WfProcess process = CtWorkFlowUtil.getProcess(self);
		Team team = (Team) process.getTeamId().getObject();
		HashMap rolePrincipals = TeamHelper.service.findAllParticipantsByRole(team);
		for(Role role : (Set<Role>)rolePrincipals.keySet()) {
			if(allowEmptyRoles.contains(role.getDisplay(Locale.CHINA))){
				List<WTPrincipalReference> principals =  (List<WTPrincipalReference>) rolePrincipals.get(role);
				for (WTPrincipalReference priRef : principals) {
					TeamHelper.service.deleteRolePrincipalMap(role, priRef.getPrincipal(), team);
				}
			}
		}
	}

	/**
	 * 重新分配流程角色
	 * @param pbo
	 * @param self
	 * @throws Exception
	 */
	public static void assignWfProcessUser(WTObject pbo, ObjectReference self) throws Exception{
		WfProcess process = CtWorkFlowUtil.getProcess(self);
		Team team = TeamHelper.service.getTeam(process);
		team = (Team) PersistenceHelper.manager.refresh(team);
		WTContainer container = process.getContainer();
		if (container instanceof ContainerTeamManaged) {
			ContainerTeam containerTeam = ContainerTeamHelper.service
					.getContainerTeam((ContainerTeamManaged) container);
			Map map = team.getRolePrincipalMap();
			for (Object obj : map.keySet()) {
				ArrayList userList = containerTeam.getAllPrincipalsForTarget(Role.toRole(obj.toString()));
				if (userList == null || userList.size() == 0) {

				} else {
					for (Object userObj : userList) {
						Object principal = null;
						if (userObj instanceof WTPrincipalReference) {
							WTPrincipalReference prf = (WTPrincipalReference) userObj;
							principal = prf.getPrincipal();
						} else {
							principal = userObj;
						}
						if (principal instanceof WTUser) {
							team.addPrincipal(Role.toRole(obj.toString()), (WTUser) principal);
						} else if (principal instanceof WTGroup) {
							WTGroup group = (WTGroup) principal;
							Enumeration enumer = group.members();
							while (enumer.hasMoreElements()) {
								Object enumObj = enumer.nextElement();
								if (enumObj instanceof WTPrincipalReference) {
									team.addPrincipal(Role.toRole(obj.toString()),
											((WTPrincipalReference) enumObj).getPrincipal());
								} else if (enumObj instanceof WTUser) {
									team.addPrincipal(Role.toRole(obj.toString()), ((WTUser) enumObj));
								}
							}
							// 解析完组删除组
							team.deletePrincipalTarget(Role.toRole(obj.toString()), group);
						}
					}
				}

			}
			// 更新团队
			team = (Team) PersistenceHelper.manager.refresh(team);
			team = (Team) PersistenceHelper.manager.save(team);
		}

	}

	/**
	 * 应用于泛海三江-EBOM更改任务ECA  路由表达式  判断是否需要进行小批量试产验证
	 *ext.plm.ec.CtEcWfPlugin.isNeedTrialCheck(primaryBusinessObject)
	 */
	public static String isNeedTrialCheck(WTObject pbo) throws Exception {
		WTChangeRequest2 changeRequest = getChangeRequest(pbo);
		String changeRequestId = CtWTObjectUtil.getVid(changeRequest);
		CtEcQuery query = new CtEcQuery();
		return query.getAttributeValue(changeRequestId,"isNeedSmallCheck");//是否需要小批量试产验证
	}

	/**
	 * 应用于泛海三江-工程变更流程  路由表达式  判断是否需要进入EBOM变更负责人指定EBOM更改方案节点
	 *ext.plm.ec.CtEcWfPlugin.isNeedEBomMakePlan(primaryBusinessObject)
	 */
	public static boolean isNeedEBomMakePlan(WTObject pbo) throws Exception {
		boolean isNeed = true;
		WTChangeRequest2 changeRequest = getChangeRequest(pbo);
		String changeRequestId = CtWTObjectUtil.getVid(changeRequest);
		CtEcQuery query = new CtEcQuery();
		String changeSubType = query.getAttributeValue(changeRequestId,"head_changeSubType");//更改子类型
		if("试产工艺变更".equals(changeSubType)||"量产工艺变更".equals(changeSubType)
			||"BOM变更(试产辅料变更)".equals(changeSubType)||"BOM变更(量产辅料变更)".equals(changeSubType)){
			isNeed =  false;
		}
		return isNeed;
	}

	//=====================开始 SAP 集成 部分==================================

	/**
	 * 应用于变更任务的 创建SAP变更单 表达式
	 * 集成SAP创建 变更表头
	 * @param pbo
	 */
	public static void createSapECN(WTObject pbo) throws WTException {

		WTChangeActivity2 changeActivity = (WTChangeActivity2) pbo;

		try {
			WTChangeRequest2 changeRequest = CtEcUtil.getChangeRequest(changeActivity);
			String processNo = "变更请求："+changeRequest.getNumber();
			CtSapInterface.createSapECN(changeRequest,processNo);
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}

	}


	/**
	 * 应用于变更任务流程的 集成修改SAP BOM 表达式
	 * 修改SAP BOM
	 * @param pbo
	 * @param  failedBoms 上次失败的BOM,为json格式 {bom_Number1:'plant1,plant2',bom_Number2:'plant1,plant2'}
	 * @return HashMap<String,String> key含 errorMsg和failedBoms(字符串) ，无异常返回null
	 * @throws WTException
	 */
	//针对MBOM变更
	public static HashMap<String, String> sendBomChange2SAP(WTObject pbo, String failedBoms) throws WTException {

		WTChangeActivity2 changeActivity = (WTChangeActivity2) pbo;
		HashMap<String, String> result = null; // 无异常时返回null
        List<String> plantList = null; //工厂
		String failedErrorMsg = ""; //异常信息
        // 创建失败的BOM，按“料号：工厂列表”的map格式
        JSONObject failedBomMap = new JSONObject();


		try {
			WTChangeRequest2 changeRequest = CtEcUtil.getChangeRequest(changeActivity);
			String processNo = "变更请求："+changeRequest.getNumber();
			String ecnNumber = changeRequest.getNumber();

			List<WTPart> bomList = new ArrayList<>();
			List<String> bomNumList = new ArrayList<>();
            boolean continueFlag = false;// 是否续传标志,决定后面工厂的获取方式
            JSONObject lastFailedBomMap = null;
			QueryResult rs = ChangeHelper2.service.getChangeOrders(changeRequest);
			//遍历查询变更下所有eca的Mbom
			while(rs.hasMoreElements()) {
				Object obj=rs.nextElement();
				if(obj instanceof WTChangeOrder2) {
					WTChangeOrder2 order = (WTChangeOrder2) obj;
					QueryResult ecaqr = ChangeHelper2.service.getChangeActivities(order);
					while (ecaqr.hasMoreElements()) {
						Object obj2=ecaqr.nextElement();
						if(obj2 instanceof WTChangeActivity2) {
							WTChangeActivity2 eca = (WTChangeActivity2)obj2;
							QueryResult qrBefore = ChangeHelper2.service.getChangeablesBefore(eca);
							while (qrBefore.hasMoreElements()) {
								Object beforeObj = qrBefore.nextElement();
								if (beforeObj instanceof WTPart) {
									WTPart part = (WTPart) beforeObj;
									if(CtConstant.VIEW_MANUFACTURING.equals(part.getViewName())){
										bomNumList.add(part.getNumber());

									}

								}
							}
						}
					}
				}
			}


			if (CtFormatUtil.hasContent(failedBoms)) {
                // 续传BOM
                continueFlag = true;
                lastFailedBomMap = JSONObject.parseObject(failedBoms);
                for (String bomNumber : lastFailedBomMap.keySet()) {
                    WTPart tmpPart = CtPartUtil.getPartByNumber(bomNumber,CtConstant.VIEW_MANUFACTURING);
                    bomList.add(tmpPart);
                }
			} else {
				// 第一次修改BOM, 从受影响对象中拿BOM
				QueryResult qr = ChangeHelper2.service.getChangeablesAfter(changeActivity);
				while (qr.hasMoreElements()) {
					Object afterObj = qr.nextElement();
					if (afterObj instanceof WTPart) {
						WTPart part = (WTPart) afterObj;
						//只处理BOM
                        List<WTPart> partsInBOM = CtBomUtil.getPartsInBOMByView(part,null);
						String viewName = part.getViewName();
                        if(CtFormatUtil.hasContent(partsInBOM)&&viewName.equals(CtConstant.VIEW_MANUFACTURING)){
							bomList.add(part);
						}
					}
				}
			}
			loggger.debug("sendBomChange2SAP>>>>bomList" + bomList.size());

			// 按BOM调用接口
			for (WTPart bom : bomList) {
                // ****先确认要发送的工厂
                plantList = new ArrayList<>();
                if (continueFlag) {
                    // 续传从json中拿失败的工厂列表
                    String failedPlants = lastFailedBomMap.getString(bom.getNumber());
                    for (String tmpPlant : failedPlants.split(",")) {
                        plantList.add(tmpPlant);
                    }
                } else {
                    plantList = CtSapLogic.getPlants();
                }
				loggger.debug("sendBomChange2SAP>>>>plantList" + plantList.size());

                for (String plant : plantList) {
                    try {
                        //确定变更类型（试产或量产），从ECA的受影响对象中找原状态
                        String bomType = "";
                        State orgState = CtEcLogic.getOrgState(changeActivity, bom.getNumber(),CtConstant.VIEW_MANUFACTURING);
                        String orgStateName = orgState.getDisplay(Locale.CHINA);
                        if("试产".equals(orgStateName)){
                            bomType = "2"; //试产变更
                        }else if("量产".equals(orgStateName)||"停用中".equals(orgStateName)){
                            bomType = "1"; //量产变更
                        }else {
                            throw new WTException("BOM的状态异常，预期为试产或量产状态！当前BOM'" + bom.getNumber() + "'的状态为" + orgStateName);
                        }
                        //调用接口
                        CtSapInterface.changeSapBOM(processNo, ecnNumber,bom,bomType, plant, bomNumList);
                    } catch (Exception e) {
                        // 不抛异常，记录失败的BOM：工厂信息，下次续传
                        String failException = "BOM " + bom.getNumber() + ", 工厂 " + plant
                                + " :" + e.getMessage();
                        failedErrorMsg = CtFormatUtil.combineStr(failedErrorMsg, failException, "\r\n");
                        String plants = "";//收集bom创建异常工厂集合
                        if (failedBomMap.containsKey(bom.getNumber())) {
                            plants = failedBomMap.getString(bom.getNumber());
                        }
                        // 增加失败的工厂记录
                        plants = CtFormatUtil.combineStr(plants, plant);
                        failedBomMap.put(bom.getNumber(), plants);
                    }
                }
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}

		if (CtFormatUtil.hasContent(failedErrorMsg) ||  failedBomMap.keySet().size() > 0) {
			result = new HashMap<String, String>();
			result.put("errorMsg", "接口异常信息：" + failedErrorMsg);
			result.put("failedBoms", failedBomMap.toJSONString());
		}

		return result;
	}

	public static HashMap<String, String> sendPartChange2SAP(WTObject pbo, String failedParts) throws WTException {
		return sendPartChange2SAP(pbo, failedParts, false);
	}

	/**
	 * 应用于变更任务流程的 集成修改SAP物料 表达式
	 * 修改SAP Part
	 * @param pbo
	 * @param  failedParts 为逗号分隔的物料编号字符串
	 * @return HashMap<String,String> key含 errorMsg和failedBoms(字符串) ，无异常返回null
	 * @throws WTException
	 */
	public static HashMap<String, String> sendPartChange2SAP(WTObject pbo, String failedParts, boolean isDefaultState) throws WTException {

		WTChangeActivity2 changeActivity = (WTChangeActivity2) pbo;
		HashMap<String, String> result = null; // 无异常时返回null
		String newFailedParts = "";
		String failedErrorMsg = ""; //异常信息

		try {
			WTChangeRequest2 changeRequest = CtEcUtil.getChangeRequest(changeActivity);
			String processNo = "变更请求："+changeRequest.getNumber();
			String ecnNumber = changeRequest.getNumber();

			List<WTPart> partList = new ArrayList<WTPart>();

			if (CtFormatUtil.hasContent(failedParts)) {
				// 续传物料
				for (String tmpPartNumber : failedParts.split(",")) {
					WTPart tmpPart = CtPartUtil.getPartByNumber(tmpPartNumber,CtConstant.VIEW_DESIGN);
					partList.add(tmpPart);
				}
			} else {
				// 第一次传BOM, 从升级请求中拿BOM
				List<WTPart> tempPartList = new ArrayList<>();
				Map<String, WTPart> mMap = new HashMap<>();
				QueryResult qr = ChangeHelper2.service.getChangeablesAfter(changeActivity);
				while (qr.hasMoreElements()) {
					Object afterObj = qr.nextElement();
					if (afterObj instanceof WTPart) {
						WTPart part = (WTPart) afterObj;
						tempPartList.add(part);
						//BOM和原材料都更新一遍
						String viewName = part.getViewName();
						if(viewName.equals(CtConstant.VIEW_MANUFACTURING)){
							mMap.put(part.getNumber(), part);
						}
					}
				}
				//同料号D视图和M视图在产生的对象中都有时，优先取M视图
				for(WTPart part : tempPartList){
					String viewName = part.getViewName();
					String partNumber = part.getNumber();
					if(viewName.equals(CtConstant.VIEW_DESIGN) && mMap.containsKey(partNumber)){
						//该物料在产生的对象中存在M视图，则取M视图
						if(!partList.contains(part)){
							partList.add(part);
						}
					}else{
						partList.add(part);
					}
				}
			}

			// 按BOM调用接口
			for (WTPart tmpPart : partList) {
				try {
					CtSapInterface.updateSapPart(processNo, tmpPart, isDefaultState);
				} catch (Exception e) {
					// 不抛异常，记录失败的BOM,下次续传
					String oneFailException = tmpPart.getNumber()+","+e.getMessage();
					failedErrorMsg = CtFormatUtil.combineStr(failedErrorMsg, oneFailException, "\r\n");

					newFailedParts = CtFormatUtil.combineStr(newFailedParts, tmpPart.getNumber());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		}

		if (CtFormatUtil.hasContent(failedErrorMsg) || CtFormatUtil.hasContent(newFailedParts)) {
			result = new HashMap<String, String>();
			result.put("errorMsg", "接口异常信息：" + failedErrorMsg);
			result.put("failedParts", newFailedParts);
		}

		return result;
	}

	/**
	 * 应用于EBOM-eca，“SAP BOM集成"表达式
	 * 与SAP集成BOM
	 * @param pbo
	 * @param failedBoms 上次失败的BOM,为json格式 {bom_Number1:'plant1,plant2',bom_Number2:'plant1,plant2'}
	 * @param bomType BOM类型，0为样机,1为生产BOM， 2为试产BOM
	 * @return  HashMap {errorMsg:多个发送失败的异常信息, failedBoms:失败的物料}， 无异常返回null
	 * @throws WTException
	 */
	//针对EBOM变更
	public static HashMap<String,String> createEcSapBom(WTObject pbo, String failedBoms,String bomType) throws WTException {

		WTChangeActivity2 changeActivity = (WTChangeActivity2) pbo;
		String newFailedBoms = "";//记录失败物料
		String failedErrorMsg = ""; //记录发送失败的异常信息
		// 创建失败的BOM，按“料号：工厂列表”的map格式
		JSONObject failedBomMap = new JSONObject();
		HashMap<String,String> result = null;
		List<String> plantList = null; //工厂
		boolean continueFlag = false;// 是否续传标志
		JSONObject lastFailedBomMap = null;
		List<WTPart> bomList = new ArrayList<WTPart>();
		try {
			WTChangeRequest2 changeRequest = CtEcUtil.getChangeRequest(changeActivity);
			String processNo = "变更请求："+changeRequest.getNumber();
			List<String> bomNumList=new ArrayList<>();
			QueryResult rs = ChangeHelper2.service.getChangeOrders(changeRequest);

			while(rs.hasMoreElements()) {
				Object obj=rs.nextElement();
				if(obj instanceof WTChangeOrder2) {
					WTChangeOrder2 order = (WTChangeOrder2) obj;
					QueryResult ecaqr = ChangeHelper2.service.getChangeActivities(order);
					while (ecaqr.hasMoreElements()) {
						Object obj2=ecaqr.nextElement();
						if(obj2 instanceof WTChangeActivity2) {
							WTChangeActivity2 eca = (WTChangeActivity2)obj2;
							QueryResult qrBefore = ChangeHelper2.service.getChangeablesBefore(eca);
							while (qrBefore.hasMoreElements()) {
								Object beforeObj = qrBefore.nextElement();
								if (beforeObj instanceof WTPart) {
									WTPart part = (WTPart) beforeObj;
									if(CtConstant.VIEW_DESIGN.equals(part.getViewName())){
										bomNumList.add(part.getNumber());
									}
								}
							}
						}
					}
				}
			}

			if(CtFormatUtil.hasContent(failedBoms)) {
				// 续传BOM
				continueFlag = true;
				lastFailedBomMap = JSONObject.parseObject(failedBoms);
				for (String bomNumber : lastFailedBomMap.keySet()) {
					WTPart tmpPart = CtPartUtil.getPartByNumber(bomNumber,CtConstant.VIEW_DESIGN);
					bomList.add(tmpPart);
				}
			}else {
				// 第一次传BOM, 从升级请求中拿BOM
				QueryResult qr = ChangeHelper2.service.getChangeablesAfter(changeActivity);
				while (qr.hasMoreElements()) {
					Object tmpObj = qr.nextElement();
					if(tmpObj instanceof WTPart){
						WTPart part = (WTPart) tmpObj;
						//只发送Ebom
						List<WTPart> partsInBOM = CtBomUtil.getPartsInBOMByView(part,null);
						if(CtFormatUtil.hasContent(partsInBOM)&&part.getViewName().equals(CtConstant.VIEW_DESIGN)){
							bomList.add(part);
						}
					}
				}
			}
			for(WTPart bom: bomList) {

				// ****先确认要发送的工厂
				plantList = new ArrayList<>();
				if (continueFlag) {
					// 续传从json中拿失败的工厂列表
					String failedPlants = lastFailedBomMap.getString(bom.getNumber());
					for (String tmpPlant : failedPlants.split(",")) {
						plantList.add(tmpPlant);
					}
				} else {
					plantList = CtSapLogic.getPlants();
				}

				for (String plant : plantList) {
					try {
						// 创建对应的bom
						CtSapInterface.changeSapBOM2(processNo,changeRequest.getNumber(), bom, bomType, plant,bomNumList);
					} catch (Exception e) {
						// 不抛异常，记录失败的BOM：工厂信息，下次续传
						String failException = "BOM " + bom.getNumber() + ", 工厂 " + plant
								+ " :" + e.getMessage();
						failedErrorMsg = CtFormatUtil.combineStr(failedErrorMsg, failException, "\r\n");
						String plants = "";//收集bom创建异常工厂集合
						if (failedBomMap.containsKey(bom.getNumber())) {
							plants = failedBomMap.getString(bom.getNumber());
						}
						// 增加失败的工厂记录
						plants = CtFormatUtil.combineStr(plants, plant);
						failedBomMap.put(bom.getNumber(), plants);
					}
				}

			}

		}catch(Exception e) {
			e.printStackTrace();
			throw new WTException(e,"与SAP集成BOM失败，异常信息: "+e.getMessage());
		}

		if (CtFormatUtil.hasContent(failedErrorMsg) || failedBomMap.keySet().size() > 0) {
			result = new HashMap<String,String>();
			result.put("errorMsg", "接口异常信息：\r\n"+failedErrorMsg);
			result.put("failedBoms", failedBomMap.toJSONString());
		}

		return result;
	}




	//=====================结束  SAP 集成 部分==================================

	/**
	 * 应用于泛海三江-工程变更流程  流程表达式  设置Iba属性
	 *
	 * @param pbo
	 * @throws WTException
	 */
	//ext.plm.ec.CtEcWfPlugin.setBomIbaValue(pbo);
	public static void setBomIbaValue(WTObject pbo) throws WTException {

		WTChangeActivity2 eca = (WTChangeActivity2) pbo;
		try {
//			WTChangeRequest2 changeRequest = CtEcUtil.getChangeRequest(eca);
			QueryResult qr = ChangeHelper2.service.getChangeablesAfter(eca);
			while (qr.hasMoreElements()) {
				Object afterObj = qr.nextElement();
				if (afterObj instanceof WTPart) {
					WTPart part = (WTPart) afterObj;
					//BOM和原材料都更新一遍
					String viewName = part.getViewName();
					if(viewName.equals(CtConstant.VIEW_DESIGN)){
						IBAUtil ibaUtil = new IBAUtil(part);
						//成功了之后同步修改Iba
						ibaUtil.setIBAValue("ct_historicaldata","");
						ibaUtil.updateIBAHolder(part);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e.getMessage());
		}

	}

	/**
	 * 泛海三江变更流程  校验部件变更内容列表
	 * @throws Exception
	 */
	public static void checkPartChangeItems(WTObject obj) throws Exception{
		WTChangeRequest2 changeRequest = getChangeRequest(obj);
		String changeRequestId = CtWTObjectUtil.getVid(changeRequest);
		CtEcQuery query = new CtEcQuery();
		List<CtPartChangeItemBo> partChangeItems = query.getPartChangeItems(changeRequestId);
		if(partChangeItems!=null&&partChangeItems.size()>0){
			for (CtPartChangeItemBo partChangeItem : partChangeItems) {
				if(!CtFormatUtil.hasContent(partChangeItem.getPartNameAfter())){
					throw new Exception("变更后物料名称不能为空!请检查物料变更内容列表\r\n");
				}
			}
		}

	}

	/**
	 * 泛海三江变更流程  自动更改部件描述和内部版本
	 * ext.plm.ec.CtEcWfPlugin.autoChangePart(primaryBusinessObject);
	 * @throws Exception
	 */
	public static String  autoChangePart(WTObject obj) {
		String errorMsg ="";
		try{
			WTChangeRequest2 changeRequest = getChangeRequest(obj);
			CtEcLogic.autoChangePart(changeRequest);
		}catch(Exception e){
			e.printStackTrace();
			errorMsg+="物料变更列表自动变更失败:"+e.getMessage();
		}
		return errorMsg;
	}

	/**
	 * 工程变更>>>> 发送钉钉提醒  B167抄送人
	 * ECA流程结束发送通知相应人   取配置文件里面的对应角色或者固定人员
	 * errorMsg = ext.plm.ec.CtEcWfPlugin.sendMsgToDing(primaryBusinessObject);
	 */
	public static String sendMsgToDing(WTObject pbo) throws Exception {
		String errorMsg = "";
		try{
			CtEcLogic.sendMsgToDing(pbo);
		}catch(Exception e){
			e.printStackTrace();
			errorMsg+="发送钉钉通知失败:"+e.getMessage();
		}
		return errorMsg;
	}

	/**
	 * 泛海三江-EBOM更改任务ECA
	 * 提交节点校验:
	 * 			是否存在并行的MBOM更改任务
	 *  		result = ext.plm.ec.CtEcWfPlugin.checkMbomECA(primaryBusinessObject,self);
	 * @param pbo
	 */
	public static String checkMbomECA(WTObject pbo,Object self) throws Exception{
		WTChangeActivity2 changeActivity = (WTChangeActivity2)pbo;
		WTChangeOrder2 changeOrder = null;
		QueryResult qr =ChangeHelper2.service.getChangeOrder(changeActivity);
		if(qr.hasMoreElements()){
			changeOrder =  (WTChangeOrder2)qr.nextElement();
			QueryResult qr2 = ChangeHelper2.service.getChangeActivities(changeOrder);
			while(qr2.hasMoreElements()){
				Object o = qr2.nextElement();
				WTChangeActivity2 ca = (WTChangeActivity2)o;
				String state = ca.getLifeCycleState().getDisplay(Locale.CHINA);
				String ecType = CtWTObjectUtil.getTypeIdentifier(ca);
				if(ecType.contains(CtEcConstant.Ct_EcaType_MBOM)){
					return "是";
				}
			}
		}
		return "否";
	}

	/**
	 * 校验产生对象和受影响对象数量是否一致
	 * 				ext.plm.ec.CtEcWfPlugin.checkAffectAndResultData(primaryBusinessObject,self);
	 * @param obj
	 * @throws Exception
	 */
	public static void checkAffectAndResultData(WTObject obj) throws Exception {
		WTChangeActivity2 changeActivity = (WTChangeActivity2) obj;
		List<String> affectTypeAndNum = new ArrayList<>();//受影响对象类型+编号
		List resultTypeAndNum = new ArrayList<>();//产生对象类型+编号
		List resultData = new ArrayList<>();//产生对象
		QueryResult changeablesBefore = ChangeHelper2.service.getChangeablesBefore(changeActivity);
		while (changeablesBefore.hasMoreElements()) {
			Object o = changeablesBefore.nextElement();
			affectTypeAndNum.add(getObjIdentity(o));
		}
		QueryResult changeablesAfter = ChangeHelper2.service.getChangeablesAfter(changeActivity);
		while (changeablesAfter.hasMoreElements()) {
			Object o = changeablesAfter.nextElement();
			resultData.add(o);
			resultTypeAndNum.add(getObjIdentity(o));
		}
		//对比产生对象和受影响对象是否一致
		List<String> all = new ArrayList();
		all.addAll(affectTypeAndNum);
		all.addAll(resultTypeAndNum);
		String errorMsg = "";
		for (String objTypeAndNum : all) {
			if (affectTypeAndNum.contains(objTypeAndNum)&&!resultTypeAndNum.contains(objTypeAndNum)) {
				errorMsg += "受影响对象:" + objTypeAndNum + ",没有对应的产生对象！\r\n";
			}
			if (!affectTypeAndNum.contains(objTypeAndNum)&&resultTypeAndNum.contains(objTypeAndNum)) {
				errorMsg += "产生对象:" + objTypeAndNum + ",没有对应的受影响对象！\r\n";
			}
		}
		if(CtFormatUtil.hasContent(errorMsg)) throw new Exception("受影响对象和产生对象不一致:\r\n"+errorMsg);
	}

	public static String getObjIdentity(Object object) {
		if (object instanceof WTPart) {
			WTPart part = (WTPart) object;
			return "部件:" + part.getNumber() + part.getViewName();
		} else if (object instanceof WTDocument) {
			WTDocument doc = (WTDocument) object;
			return "文档:" + doc.getNumber() ;
		}else if (object instanceof EPMDocument) {
			EPMDocument doc = (EPMDocument) object;
			return "图文档:" + doc.getNumber() ;
		}
		return "";
	}
}
