package ext.plm.ec;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.NumberUtil;
import com.alibaba.fastjson.JSON;
import ext.plm.common.CtConstant;
import ext.plm.ec.bo.*;
import ext.plm.integration.sap.CtSapInterface;
import ext.plm.integration.sap.bo.CtSapPartStorageBo;
import ext.plm.tool.CtCheckFitPlaceTool;
import ext.plm.tool.poi.CtParseExcelTool;
import ext.plm.util.*;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeRequest2;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.pom.Transaction;
import wt.services.StandardManager;
import wt.util.WTException;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class StandardCtEcService extends StandardManager implements CtEcService {

    private static final long serialVersionUID = 7809689627592971496L;

    public static StandardCtEcService newStandardCtEcService() throws WTException {
        StandardCtEcService instance = new StandardCtEcService();
        instance.initialize();
        return instance;
    }



    @Override
    public String checkChangeObj(HashMap<String,String> dataMap) throws Exception {
        String objName = CtEcLogic.getChangeObjName(dataMap);
        return objName;
    }

    @Override
    public void insertBomChangeItems(String changeRequestId,String type) throws Exception {
        CtEcQuery query = new CtEcQuery();
        if("ebom".equals(type)){
            query.insertEBomChangeIems(changeRequestId);
        }else{
            query.insertMBomChangeIems(changeRequestId);
        }
    }

    @Override
    public void autoChangeBom(String changeRequestId, String partNumber,String type) throws Exception {
        WTChangeRequest2 ecr = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        CtEcLogic ecLogic = new CtEcLogic();
        ecLogic.changeBom(ecr, partNumber,type);
    }


    @Override
    public List<CtChangeItemBo> getChangeItems(String changeRequestId, String type) throws Exception {
        CtEcQuery query = new CtEcQuery();
        return query.getChangeItems(changeRequestId,type);
    }

    @Override
    public List<CtPartChangeItemBo> getPartChangeItems(String changeRequestId) throws Exception {
        CtEcQuery query = new CtEcQuery();
        return query.getPartChangeItems(changeRequestId);
    }

    @Override
    public List<Map> getChangeItemsData(String changeRequestId, String type) throws Exception {
        CtEcQuery query = new CtEcQuery();
        List<Map> resultList = new ArrayList<>();
        List<CtChangeItemBo> changeItems = query.getChangeItems(changeRequestId, type);
        for (CtChangeItemBo changeItem : changeItems) {
            Map<String, Object> map = BeanUtil.beanToMap(changeItem);
            resultList.add(map);
        }
        return resultList;
    }



    @Override
    public void deleteChangeItems(List<String> deleteIdList,String type) throws Exception {
        CtEcQuery query = new CtEcQuery();
        query.deleteChangeItems(deleteIdList,type);
    }

    @Override
    public void deletePartChangeItems(List<String> deleteIdList) throws Exception {
        CtEcQuery query = new CtEcQuery();
        query.deletePartChangeItems(deleteIdList);
    }



    @Override
    public void importChangeItems(File file, String changeRequestId, String boms,String type) throws Exception {
        CtEcLogic logic = new CtEcLogic();
        LinkedList<List<String>> excelInfo = logic.parse(file, 0, 2,changeRequestId,type);// 获取数据并校验
        LinkedList<CtChangeItemBo> boList = new LinkedList<CtChangeItemBo>();
        CtEcQuery query = new CtEcQuery();
        if("ebom".equals(type)) {
            for (List<String> list : excelInfo) {
                CtChangeItemBo bo = new CtChangeItemBo();
                CtEBomChangeItemBo obj = CtParseExcelTool.setField(CtEBomChangeItemBo.class, list);
                BeanUtil.copyProperties(obj, bo);
                boList.add(bo);
            }
        }else if ("mbom".equals(type)) {
            for (List<String> list : excelInfo) {
                CtChangeItemBo bo = new CtChangeItemBo();
                CtMBomChangeItemBo obj = CtParseExcelTool.setField(CtMBomChangeItemBo.class, list);
                BeanUtil.copyProperties(obj, bo);
                boList.add(bo);
            }
        }
        //校验组装数据
        CtEcLogic.assembleData(boList,changeRequestId,type);

        //开启事务 防止导入失败但是之前的列表清空
        Transaction ts = new Transaction();
        try{
            ts.start();
            //先清空列表
            query.clearChangeItems(changeRequestId,type);
            query.importChangeItems(boList,type);
            ts.commit();
            ts=null;
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }finally {
            if(ts!=null){
                ts.rollback();
                ts=null;
            }
        }


    }



    @Override
    public void saveAttribute(String changeRequestId,String activityKey,String attKey, String attValue) throws Exception {
        CtEcQuery query = new CtEcQuery();
        if(attKey.equals("eCaTrialRespon_smallTrialCheckDocNum")){
            if(CtFormatUtil.hasContent(attValue)){
                String[] split = attValue.split(",");
                String docUrl = "";
                for (String s : split) {
                    WTDocument doc = CtDocUtil.getDocumentByNumber(s);
                    if (doc == null) {
                        throw new Exception("文档编号:" + s + "不存在!\r\n");
                    } else {
                        String docType = CtWTObjectUtil.getTypeIdentifier(doc);
                        if (!docType.contains("com.fhsj.Doc_xqpxplscsqjgz")) {//F-ME-005_新产品小批量试产申请及跟踪
                            throw new Exception(s+"文档类型不是《F-ME-005_新产品小批量试产申请及跟踪》！\r\n");
                        }
                    }
                    docUrl = CtFormatUtil.combineStr(docUrl,CtCommonUtil.getURL(doc, s),",");
                }
                //先获得主表id
                String formMasterId = query.genFormMasterId(changeRequestId, activityKey);
                query.saveAttribute(attKey, attValue, formMasterId);
                query.saveAttribute("eCaTrialRespon_smallTrialCheckDocUrl", docUrl, formMasterId);
            }else{
                //先获得主表id
                String formMasterId = query.genFormMasterId(changeRequestId, activityKey);
                query.saveAttribute(attKey, "", formMasterId);
                query.saveAttribute("eCaTrialRespon_smallTrialCheckDocUrl", "", formMasterId);
            }
        }else{
            //先获得主表id
            String formMasterId = query.genFormMasterId(changeRequestId, activityKey);
            query.saveAttribute(attKey, attValue, formMasterId);
        }
    }

    @Override
    public HashMap<String,String> refreshHeadInfo(String changeRequestId) throws Exception {
        WTChangeRequest2 changeRequest = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        CtEcLogic.genEcHeadInfo(changeRequest,true);
        return getHeadInfo(changeRequestId);

    }

    @Override
    public HashMap<String,String> getHeadInfo(String changeRequestId) throws Exception {
        CtEcQuery query = new CtEcQuery();
        HashMap<String, String> headInfo = query.getHeadInfo(changeRequestId);
        return headInfo;
    }

    @Override
    public String checkMaterialNumber(String materialNumber,String changeRequestId,String boms) throws Exception {
        if(!CtFormatUtil.hasContent(materialNumber)) {
            throw new WTException("请输入正确的物料编码！");
        }
        CtEcQuery query = new CtEcQuery();
        boolean fal = false;
        if(boms.contains(materialNumber)) {
            fal = true;
        }else {
            List<CtChangeItemBo> mbomList = query.getChangeItems(changeRequestId,"mbom");
            List<CtChangeItemBo> ebomList = query.getChangeItems(changeRequestId,"ebom");
            mbomList.addAll(ebomList);
            for(CtChangeItemBo bo:mbomList) {
                String orgObjNumber = bo.getChildNumberBefore();
                String newObjNumber = bo.getChildNumberAfter();
                if(orgObjNumber.equals(materialNumber)) {
                    fal = true;
                    break;
                }
                if(newObjNumber.equals(materialNumber)) {
                    fal = true;
                    break;
                }
            }
        }
        if(!fal) {
            throw new WTException("您输入的物料编码在受影响成品、BOM、变更内容表单中不存在！");
        }
        WTPart part = CtPartUtil.getPartByNumber(materialNumber);
        String materialName = "";
        if(part == null) {
            throw new WTException("请输入正确的物料编码！当前编码'"+materialNumber+"'在系统中不存在！");
        }else {
            materialName = part.getName();
        }
        return materialName;
    }

    @Override
    public void saveChangeListField(String id, String key, String value,String changeRequestId,String boms,String type) throws Exception {
        CtEcQuery query = new CtEcQuery();
        if("changeType".equals(key)){//校验更改类型
            try{
                CtEcLogic.checkChangeType(id,key,value,type);
            }catch(Exception e){
                query.saveChangeListField(id,key,"",type);//校验不通过，将更改类型置空
                throw new Exception(e.getMessage());
            }
        }
        else if("bitNumberAfter".equals(key)){//位号校验
            CtEcLogic.checkBitNumber(id,key,value,type,changeRequestId);
        }else if("replaceNumberAfter".equals(key)||"priorityAfter".equals(key)){
            //变更后属性字段需要先校验变更后物料编码
            CtChangeItemBo changeItemBo = query.getChangeItemById(id, type);
            if(changeItemBo==null){//正常不会进来
                return;
            }
            String childNumberAfter = changeItemBo.getChildNumberAfter();
            if(!CtFormatUtil.hasContent(childNumberAfter)){
                throw new Exception("请先填写正确的变更后物料编码!\r\n");
            }
        }else if("amountAfter".equals(key)){//数量
            if(CtFormatUtil.hasContent(value)){
                double v = Double.parseDouble(value);
                if(v<=0){
                    throw new Exception("数量必须大于0!");
                }
                //变更后属性字段需要先校验变更后物料编码
                CtChangeItemBo changeItemBo = query.getChangeItemById(id, type);
                if(changeItemBo==null){//正常不会进来
                    return;
                }
                String childNumberAfter = changeItemBo.getChildNumberAfter();
                if(!CtFormatUtil.hasContent(childNumberAfter)){
                    throw new Exception("请先填写正确的变更后物料编码!\r\n");
                }
                WTPart part = CtPartUtil.getPartByNumber(childNumberAfter);
                String unit = part.getDefaultUnit().getDisplay(Locale.CHINA);
                if(unit.equals("PCS")&&value.contains(".")){
                    throw new Exception("物料:"+childNumberAfter+"默认单位为PCS，数量不能为小数!\r\n");
                }
                String bitNumberAfter = changeItemBo.getBitNumberAfter();
                if(CtFormatUtil.hasContent(bitNumberAfter)){
                    if(!NumberUtil.isNumber(value)){
                        throw new Exception("填写了变更后位号,变更后数量必须为整数!");
                    }else{
                        List<String> list = new ArrayList<>();
                        CtCheckFitPlaceTool.checkFitPlace2NumAndList(bitNumberAfter,list);
                        if(list.size()!=Integer.parseInt(value)){
                            throw new Exception("变更后位号拆分后数量为:"+list.size()+",填写数量为:"+value+",数量不一致!");
                        }
                    }
                }
            }
        }
        query.saveChangeListField(id,key,value,type);
    }

    @Override
    public void savePartChangeItems(String id, String key, String value,String changeRequestId) throws Exception {
        CtEcQuery query = new CtEcQuery();
        if("partNumber".equals(key)){
            if(!CtFormatUtil.hasContent(id)){
                if(!CtFormatUtil.hasContent(value)){
                    throw new Exception("部件编号不能为空!\r\n");
                }else{
                    WTPart part =  CtPartUtil.getPartByNumber(value, CtConstant.VIEW_DESIGN);
                    if(part ==null){
                       throw new Exception("部件编号:"+value+"不存在!\r\n");
                    }
                    id = query.savePartChangeItems(id,key,value,changeRequestId);
                    IBAUtil ibaUtil = new IBAUtil(part);
                    String ct_version = ibaUtil.getIBAValue("ct_banci");
                    query.savePartChangeItems(id,key,value,changeRequestId);
                    query.savePartChangeItems(id,"partNameBefore",part.getName(),changeRequestId);
                    query.savePartChangeItems(id,"innerVersionBefore",ct_version,changeRequestId);
                    query.savePartChangeItems(id,"partNameAfter",part.getName(),changeRequestId);
                    String parentNumber = CtBomUtil.getParentParts(part).stream().map( wtPart -> wtPart.getNumber()).distinct().collect(Collectors.joining(","));
                    query.savePartChangeItems(id,"parentNumber",parentNumber,changeRequestId);
                }
            }else{
                if(!CtFormatUtil.hasContent(value)){
                    query.savePartChangeItems(id,key,"",changeRequestId);
                    query.savePartChangeItems(id,"partNameBefore","",changeRequestId);
                    query.savePartChangeItems(id,"innerVersionBefore","",changeRequestId);
                    query.savePartChangeItems(id,"partNameAfter","",changeRequestId);
                    query.savePartChangeItems(id,"parentNumber","",changeRequestId);
                }else{
                    WTPart part =  CtPartUtil.getPartByNumber(value, CtConstant.VIEW_DESIGN);
                    IBAUtil ibaUtil = new IBAUtil(part);
                    String ct_version = ibaUtil.getIBAValue("ct_banci");
                    query.savePartChangeItems(id,key,value,changeRequestId);
                    query.savePartChangeItems(id,"partNameBefore",part.getName(),changeRequestId);
                    query.savePartChangeItems(id,"innerVersionBefore",ct_version,changeRequestId);
                    query.savePartChangeItems(id,"partNameAfter",part.getName(),changeRequestId);
                    String parentNumber = CtBomUtil.getParentParts(part).stream().map( wtPart -> wtPart.getNumber()).distinct().collect(Collectors.joining(","));
                    query.savePartChangeItems(id,"parentNumber",parentNumber,changeRequestId);
                }
            }
        }else if("innerVersionAfter".equals(key)){
            if(CtFormatUtil.hasContent(value)){
                boolean matches = Pattern.matches("V\\d.\\d",value);
                if(!matches){
                    throw new Exception("'内部版本'字段不符合格式要求,例:V1.1");
                }
            }
            query.savePartChangeItems(id,key,value,changeRequestId);
        }else{
            query.savePartChangeItems(id,key,value,changeRequestId);
        }

    }


    @Override
    public void autoAddPcrMaterials(String changeRequestId) throws Exception {
        ReferenceFactory rf = new ReferenceFactory();
        WTChangeRequest2 changeRequest = (WTChangeRequest2)rf.getReference(changeRequestId).getObject();
        List<CtEcPcrMaterialItemBo> materials = new ArrayList<>();
        List<String> partNumbers = new ArrayList<>();
        //收集受影响对象
        QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
        while(queryResult.hasMoreElements()){
            Object obj = queryResult.nextElement();
            if(obj instanceof WTPart){
                WTPart part = (WTPart)obj;
                if(partNumbers.contains(part.getNumber())){
                    continue;
                }else{
                    partNumbers.add(part.getNumber());
                }
                try{
                    CtEcPcrMaterialItemBo bo = new CtEcPcrMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    CtSapPartStorageBo partStorage = CtSapInterface.getPartStorage(part.getNumber());
                    String storage = partStorage.getStorage();
                    bo.setStock(CtFormatUtil.hasContent(storage)?storage:"0");
                    String po = partStorage.getStorageAtPO();
                    bo.setPo(CtFormatUtil.hasContent(po)?po:"0");
                    String pr = partStorage.getStorageAtPR();
                    bo.setPr(CtFormatUtil.hasContent(pr)?pr:"0");
                    materials.add(bo);
                }catch (Exception e){
                    System.out.println(">>>>>>>>>获取库存信息异常>>>>>>>>>");
                    e.printStackTrace();
                    CtEcPcrMaterialItemBo bo = new CtEcPcrMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    bo.setStock("未获取到数据");
                    bo.setPo("未获取到数据");
                    bo.setPr("未获取到数据");
                    materials.add(bo);
                }
            }
        }
        CtEcQuery query = new CtEcQuery();
        query.deletePcrMatItems(changeRequestId);
        List<CtChangeItemBo> mBomChangeItems = query.getMBomChangeItems(changeRequestId);
        for (CtChangeItemBo mBomChangeItem : mBomChangeItems) {
            String childNumberBefore = mBomChangeItem.getChildNumberBefore();
            String childNumberAfter = mBomChangeItem.getChildNumberAfter();
            if(CtFormatUtil.hasContent(childNumberBefore)){
                WTPart part = CtPartUtil.getPartByNumber(childNumberBefore);
                if(part==null)continue;
                if(partNumbers.contains(part.getNumber())){
                    continue;
                }else{
                    partNumbers.add(part.getNumber());
                }
                try{
                    CtEcPcrMaterialItemBo bo = new CtEcPcrMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    CtSapPartStorageBo partStorage = CtSapInterface.getPartStorage(part.getNumber());
                    String storage = partStorage.getStorage();
                    bo.setStock(CtFormatUtil.hasContent(storage)?storage:"0");
                    String po = partStorage.getStorageAtPO();
                    bo.setPo(CtFormatUtil.hasContent(po)?po:"0");
                    String pr = partStorage.getStorageAtPR();
                    bo.setPr(CtFormatUtil.hasContent(pr)?pr:"0");
                    materials.add(bo);
                }catch (Exception e){
                    System.out.println(">>>>>>>>>获取库存信息异常>>>>>>>>>");
                    e.printStackTrace();
                    CtEcPcrMaterialItemBo bo = new CtEcPcrMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    bo.setStock("未获取到数据");
                    bo.setPo("未获取到数据");
                    bo.setPr("未获取到数据");
                    materials.add(bo);
                }
            }
            if(CtFormatUtil.hasContent(childNumberAfter)){
                WTPart part = CtPartUtil.getPartByNumber(childNumberAfter);
                if(part==null)continue;
                if(partNumbers.contains(part.getNumber())){
                    continue;
                }else{
                    partNumbers.add(part.getNumber());
                }
                try{
                    CtEcPcrMaterialItemBo bo = new CtEcPcrMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    CtSapPartStorageBo partStorage = CtSapInterface.getPartStorage(part.getNumber());
                    String storage = partStorage.getStorage();
                    bo.setStock(CtFormatUtil.hasContent(storage)?storage:"0");
                    String po = partStorage.getStorageAtPO();
                    bo.setPo(CtFormatUtil.hasContent(po)?po:"0");
                    String pr = partStorage.getStorageAtPR();
                    bo.setPr(CtFormatUtil.hasContent(pr)?pr:"0");
                    materials.add(bo);
                }catch (Exception e){
                    System.out.println(">>>>>>>>>获取库存信息异常>>>>>>>>>");
                    e.printStackTrace();
                    CtEcPcrMaterialItemBo bo = new CtEcPcrMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    bo.setStock("未获取到数据");
                    bo.setPo("未获取到数据");
                    bo.setPr("未获取到数据");
                    materials.add(bo);
                }
            }
        }
        if(materials.size() >0 ) {
            query.autoAddPcrMaterials(materials, changeRequestId);
        }else {
            throw new WTException("无法找到能自动添加的物料，请检查受影响对象是否为空！");
        }

    }

    @Override
    public void autoAddPmcMaterials(String changeRequestId) throws Exception {
        ReferenceFactory rf = new ReferenceFactory();
        WTChangeRequest2 changeRequest = (WTChangeRequest2)rf.getReference(changeRequestId).getObject();
        List<CtEcPmcMaterialItemBo> materials = new ArrayList<>();
        List<String> partNumbers = new ArrayList<>();
        //收集受影响对象
        QueryResult queryResult = ChangeHelper2.service.getChangeables(changeRequest);
        while(queryResult.hasMoreElements()){
            Object obj = queryResult.nextElement();
            if(obj instanceof WTPart){
                WTPart part = (WTPart)obj;
                if(partNumbers.contains(part.getNumber())){
                    continue;
                }else{
                    partNumbers.add(part.getNumber());
                }
                try{
                    CtEcPmcMaterialItemBo bo = new CtEcPmcMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    CtSapPartStorageBo partStorage = CtSapInterface.getPartStorage(part.getNumber());
                    //库存量
                    String storage = partStorage.getStorage();
                    if(!CtFormatUtil.hasContent(storage))storage = "0";
                    bo.setStock(storage);
                    //在制量
                    String storageAtMake = partStorage.getStorageAtMake();
                    if(!CtFormatUtil.hasContent(storageAtMake))storageAtMake = "0";
                    bo.setInMaking(storageAtMake);
                    //维修周转品数量
                    String storageAtMaintain = partStorage.getStorageAtMaintain();
                    if(!CtFormatUtil.hasContent(storageAtMaintain))storageAtMaintain = "0";
                    bo.setMaintain(storageAtMaintain);
                    //销售订单量
                    String storageAtSaleOrder = partStorage.getStorageAtSaleOrder();
                    if(!CtFormatUtil.hasContent(storageAtSaleOrder))storageAtSaleOrder = "0";
                    bo.setSalesOrder(storageAtSaleOrder);
                    materials.add(bo);
                }catch(Exception e){
                    e.printStackTrace();
                    System.out.println(">>>>>>>>获取库存信息异常>>>>>>>>");
                    CtEcPmcMaterialItemBo bo = new CtEcPmcMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    bo.setStock("未获取到数据");
                    bo.setInMaking("未获取到数据");
                    bo.setMaintain("未获取到数据");
                    bo.setSalesOrder("未获取到数据");
                    materials.add(bo);
                }

            }

        }
        CtEcQuery query = new CtEcQuery();
        query.deletePcrMatItems(changeRequestId);
        List<CtChangeItemBo> mBomChangeItems = query.getMBomChangeItems(changeRequestId);
        for (CtChangeItemBo mBomChangeItem : mBomChangeItems) {
            String childNumberBefore = mBomChangeItem.getChildNumberBefore();
            String childNumberAfter = mBomChangeItem.getChildNumberAfter();
            if(CtFormatUtil.hasContent(childNumberBefore)){
                WTPart part = CtPartUtil.getPartByNumber(childNumberBefore);
                if(part==null)continue;
                if(partNumbers.contains(part.getNumber())){
                    continue;
                }else{
                    partNumbers.add(part.getNumber());
                }
                try{
                    CtEcPmcMaterialItemBo bo = new CtEcPmcMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    CtSapPartStorageBo partStorage = CtSapInterface.getPartStorage(part.getNumber());
                    //库存量
                    String storage = partStorage.getStorage();
                    if(!CtFormatUtil.hasContent(storage))storage = "0";
                    bo.setStock(storage);
                    //在制量
                    String storageAtMake = partStorage.getStorageAtMake();
                    if(!CtFormatUtil.hasContent(storageAtMake))storageAtMake = "0";
                    bo.setInMaking(storageAtMake);
                    //维修周转品数量
                    String storageAtMaintain = partStorage.getStorageAtMaintain();
                    if(!CtFormatUtil.hasContent(storageAtMaintain))storageAtMaintain = "0";
                    bo.setMaintain(storageAtMaintain);
                    //销售订单量
                    String storageAtSaleOrder = partStorage.getStorageAtSaleOrder();
                    if(!CtFormatUtil.hasContent(storageAtSaleOrder))storageAtSaleOrder = "0";
                    bo.setSalesOrder(storageAtSaleOrder);
                    materials.add(bo);
                }catch(Exception e){
                    e.printStackTrace();
                    System.out.println(">>>>>>>>获取库存信息异常>>>>>>>>");
                    CtEcPmcMaterialItemBo bo = new CtEcPmcMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    bo.setStock("未获取到数据");
                    bo.setInMaking("未获取到数据");
                    bo.setMaintain("未获取到数据");
                    bo.setSalesOrder("未获取到数据");
                    materials.add(bo);
                }
            }
            if(CtFormatUtil.hasContent(childNumberAfter)){
                WTPart part = CtPartUtil.getPartByNumber(childNumberAfter);
                if(part==null)continue;
                if(partNumbers.contains(part.getNumber())){
                    continue;
                }else{
                    partNumbers.add(part.getNumber());
                }
                try{
                    CtEcPmcMaterialItemBo bo = new CtEcPmcMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    CtSapPartStorageBo partStorage = CtSapInterface.getPartStorage(part.getNumber());
                    //库存量
                    String storage = partStorage.getStorage();
                    if(!CtFormatUtil.hasContent(storage))storage = "0";
                    bo.setStock(storage);
                    //在制量
                    String storageAtMake = partStorage.getStorageAtMake();
                    if(!CtFormatUtil.hasContent(storageAtMake))storageAtMake = "0";
                    bo.setInMaking(storageAtMake);
                    //维修周转品数量
                    String storageAtMaintain = partStorage.getStorageAtMaintain();
                    if(!CtFormatUtil.hasContent(storageAtMaintain))storageAtMaintain = "0";
                    bo.setMaintain(storageAtMaintain);
                    //销售订单量
                    String storageAtSaleOrder = partStorage.getStorageAtSaleOrder();
                    if(!CtFormatUtil.hasContent(storageAtSaleOrder))storageAtSaleOrder = "0";
                    bo.setSalesOrder(storageAtSaleOrder);
                    materials.add(bo);
                }catch(Exception e){
                    e.printStackTrace();
                    System.out.println(">>>>>>>>获取库存信息异常>>>>>>>>");
                    CtEcPmcMaterialItemBo bo = new CtEcPmcMaterialItemBo();
                    bo.setPartNumber(part.getNumber());
                    bo.setPartName(part.getName());
                    bo.setStock("未获取到数据");
                    bo.setInMaking("未获取到数据");
                    bo.setMaintain("未获取到数据");
                    bo.setSalesOrder("未获取到数据");
                    materials.add(bo);
                }
            }
        }
        if(materials.size() >0 ) {
            query.autoAddPmcMaterials(materials, changeRequestId);
        }else {
            throw new WTException("无法找到能自动添加的物料，请检查受影响对象是否为空！");
        }

    }

    @Override
    public List<CtEcPcrMaterialItemBo> getPcrMaterialItems(String changeRequestId) throws Exception {
        CtEcQuery query = new CtEcQuery();
        return query.getPcrMaterialItems(changeRequestId);
    }

    @Override
    public List<CtEcPmcMaterialItemBo> getPmcMaterialItems(String changeRequestId) throws Exception {
        CtEcQuery query = new CtEcQuery();
        return query.getPmcMaterialItems(changeRequestId);
    }

    @Override
    public List<CtEcPdtAuditInfoBo> getPdtAuditInfo(String changeRequestId) throws Exception {
        CtEcQuery query = new CtEcQuery();
        return query.getPdtAuditInfo(changeRequestId);
    }

    @Override
    public void deletePcrMatItems(List<String> deleteIdList) throws Exception {
        CtEcQuery query = new CtEcQuery();
        query.deletePcrMatItems(deleteIdList);

    }

    @Override
    public void deletePmcMatItems(List<String> deleteIdList) throws Exception {
        CtEcQuery query = new CtEcQuery();
        query.deletePmcMatItems(deleteIdList);

    }

    @Override
    public void savePcrMaterialNumber(HashMap<String, String> pcrMaterialNumberInfo) throws Exception {
        CtEcQuery query = new CtEcQuery();
        query.savePcrMaterialNumber(pcrMaterialNumberInfo);

    }

    @Override
    public void savePmcMaterialNumber(HashMap<String, String> pmcMaterialNumberInfo) throws Exception {
        CtEcQuery query = new CtEcQuery();
        query.savePmcMaterialNumber(pmcMaterialNumberInfo);

    }

    @Override
    public void savePcrMaterialField(String id, String key, String value) throws Exception {
        CtEcQuery query = new CtEcQuery();
        query.savePcrMaterialField(id,key,value);
    }

    @Override
    public void savePmcMaterialField(String id, String key, String value) throws Exception {
        CtEcQuery query = new CtEcQuery();
        query.savePmcMaterialField(id,key,value);
    }

    @Override
    public List<Map<String,String>> getEcReportItems(HashMap<String, Object> params) throws Exception {
        CtEcQuery query = new CtEcQuery();
        List<HashMap<String, Object>> list = query.getEcReportItems(params);
        List<Map<String,String>> resultList = new ArrayList<>();
        for(HashMap<String, Object> ls:list) {
            if(CtFormatUtil.hasContent(params.get("MARK"))){
                ls.put("MARK","export");
            }
            Map map = CtEcLogic.assemblyEcReportData(ls);
            resultList.add(map);
        }
        return resultList;
    }

    @Override
    public int getEcReportItemsCount(HashMap<String, Object> params) throws Exception {
        CtEcQuery query = new CtEcQuery();
        params.put("start", null);
        params.put("pageSize", null);
        List<HashMap<String, Object>>  list = query.getEcReportItems(params);
        if(!CtFormatUtil.hasContent(list)) {
            return 0;
        }else {
            return list.size();
        }
    }

    //==============================测试方法  begin================================
    public void testGenHeadInfo(String changeRequestId) throws Exception{
        WTChangeRequest2 changeRequest = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(changeRequestId);
        CtEcWfPlugin.genHeadInfo(changeRequest);
    }

    @Override
    public List<Map<String,String>> getNewEcReportItems(HashMap<String, Object> params) throws Exception {
        CtEcQuery query = new CtEcQuery();
        List<Map<String,String>> list = query.getNewEcReportItems(params);
        DateFormat reportDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        reportDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        for(Map<String, String> ls:list) {
            if(CtFormatUtil.hasContent(params.get("MARK"))){
                ls.put("MARK","export");
            }
            CtEcLogic.assemblyNewEcReportData(ls, reportDateFormat);
        }
        return list;
    }

    @Override
    public int getNewEcReportItemsCount(HashMap<String, Object> params) throws Exception {
        CtEcQuery query = new CtEcQuery();
        params.put("start", null);
        params.put("pageSize", null);
        List<Map<String,String>> list = query.getNewEcReportItems(params);
        if(!CtFormatUtil.hasContent(list)) {
            return 0;
        }else {
            return list.size();
        }
    }
}
