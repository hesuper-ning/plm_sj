package ext.plm.ec.config;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import ext.plm.util.CtFormatUtil;
import org.apache.log4j.Logger;
import wt.log4j.LogR;
import wt.util.WTException;


public class CtEcProperties {
	private static final Logger logger = LogR.getLogger(CtEcProperties.class.getName());


	/**
	 * 根据活动节点名称获得activityKey
	 * @param activityName
	 */
	public static String getActivityKey(String activityName) throws Exception{
		Properties activityKeyMap = new Properties();
		activityKeyMap.load(new InputStreamReader(
				CtEcProperties.class.getResourceAsStream("EcActivityKeyMap.properties"), StandardCharsets.UTF_8));

		String activityKey =  activityKeyMap.getProperty(activityName);
		if(!CtFormatUtil.hasContent(activityKey)) {
//			System.out.println("ERROR>>>>流程活动'"+activityName+"'无法找到对应的Key,需要核对配置表EcActivityKeyMap.properties！");
//			throw new WTException("后台异常，无法找到当前流程活动对应的Key，请联系管理员！");
			activityKey = "";
		}
		
		return activityKey;
	}
	
	/**
	 * 按流程活动Key获取当前活动的必填字段
	 * @param activityKey
	 */
	public static List<String> getRequiredAtts(String activityKey)throws Exception{
		Properties formRequiredAttMap = new Properties();
		formRequiredAttMap.load(new InputStreamReader(
				CtEcProperties.class.getResourceAsStream("EcFormRequiredAttMap.properties"), StandardCharsets.UTF_8));

		List<String> result = new ArrayList<String>();
		String attStr = formRequiredAttMap.getProperty(activityKey);
		System.out.println("attStr===================="+attStr);
		if(CtFormatUtil.hasContent(attStr)) {
			String[] requiredAtts = attStr.split(",");
			for(String attKey: requiredAtts) {
				result.add(attKey);
			}
		}
		
		return result;
	}
	
	/**
	 * 获取属性的显示名称
	 * @param attKey
	 */
	public static String getAttDisplayName(String attKey) throws Exception{
		Properties attDisplayMap = new Properties();
		attDisplayMap.load(new InputStreamReader(
				CtEcProperties.class.getResourceAsStream("EcFormAttDisplayMap.properties"), StandardCharsets.UTF_8));

		return attDisplayMap.getProperty(attKey);
	}
	
	/**
	 * ec通用配置文件获取值
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String getPropertyValue(String key) throws Exception{
		String value = "";
		Properties ecProp = new Properties();
		ecProp.load(new InputStreamReader(
				CtEcProperties.class.getResourceAsStream("CtEc.properties"), StandardCharsets.UTF_8));
		String property = ecProp.getProperty(key);
		if(CtFormatUtil.hasContent(property)){
			value = property;
		}
		return value;
	}

}
