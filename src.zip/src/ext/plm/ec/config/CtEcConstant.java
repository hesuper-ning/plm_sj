package ext.plm.ec.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CtEcConstant {

	public static HashMap<String,String> formAtt_IBA_Map = null;
	static{
		formAtt_IBA_Map = new HashMap<>();
//		formAtt_IBA_Map.put("head_changeType","ct_changeType");
		formAtt_IBA_Map.put("head_changeSubType","ct_changeSubType");
		formAtt_IBA_Map.put("head_changeReason","ct_changeReason");
		formAtt_IBA_Map.put("head_changeDesc","ct_changeDesc");
		formAtt_IBA_Map.put("head_productModel","ct_productModel");
	}


	//BOM变更类型
	public static String changeType = "增加|删除|修改";
	//更改请求  工程变更
	public static String Ct_EcrType_ProductionEC = "com.fhsj.ctProductionEC";
	//更改请求  快速变更01
	public static String Ct_EcrType_ECR01 = "com.fhsj.ECR01";
	//更改请求  快速变更02
	public static String Ct_EcrType_ECR02 = "com.fhsj.ECR02";
	//更改请求  快速变更03
	public static String Ct_EcrType_ECR03 = "com.fhsj.ECR03";

	//更改通告  变更通告
	public static String Ct_EcnType_CtECN = "com.fhsj.CtECN";
	//更改任务  EBOM更改任务ECA
	public static String Ct_EcaType_EBOM = "com.fhsj.ctEBOMECA";
	//更改任务 MBOM更改任务ECA
	public static String Ct_EcaType_MBOM = "com.fhsj.ctMBOMECA";
	//更改任务 SIP更改任务ECA
	public static String Ct_EcaType_SIP = "com.fhsj.ctSIPECA";
	//更改任务 SOP更改任务ECA
	public static String Ct_EcaType_SOP = "com.fhsj.ctSOPECA";
	//更改任务 电子图纸更改任务ECA
	public static String Ct_EcaType_Dianzituzhi = "com.fhsj.ctdianzituzhiECA";
	//更改任务 结构图纸更改任务ECA
	public static String Ct_EcaType_Jiegoutuzhi = "com.fhsj.ctjiegoutuzhiECA";
	//更改任务 软件更改任务ECA
	public static String Ct_EcaType_SW = "com.fhsj.ctrjECA";
	//更改任务 技术支持更改任务ECA
	public static String Ct_EcaType_Tech = "com.fhsj.ctjszcECA";
	//更改任务 销售更改任务ECA
	public static String Ct_EcaType_Sale = "com.fhsj.ctxsECA";
	//更改任务 市场更改任务ECA
	public static String Ct_EcaType_Market = "com.fhsj.ctscECA";
	//更改任务 其他更改任务ECA
	public static String Ct_EcaType_Other = "com.fhsj.ctqtggrwECA";
	//更改任务 快速变更(场景1)ECA    物料属性快速更改任务ECA
	public static String Ct_EcaType_QuickChange1 = "com.fhsj.ctwlsxECA";
	//更改任务 快速变更(场景2)ECA    图纸文档工艺快速更改任务ECA
	public static String Ct_EcaType_QuickChange2 = "com.fhsj.tzwdECA";
	//更改任务 快速变更(场景3)ECA    BOM快速更改任务ECA
	public static String Ct_EcaType_QuickChange3 = "com.fhsj.BOMECA";
	//更改任务 快速变更(场景4)ECA    MBOM辅料快速更改任务ECA
	public static String Ct_EcaType_QuickChange4 = "com.fhsj.MBOMflECA";




	//新工程变更
	//更改任务 快速变更(场景1)ECA    物料属性快速更改任务ECA_14
	public static String Ct_EcaType_QuickChange1_14 = "com.fhsj.ECA_14";
	//更改任务 快速变更(场景2)ECA    图纸文档工艺快速更改任务ECA_13
	public static String Ct_EcaType_QuickChange2_13 = "com.fhsj.ECA_13";
	//更改任务 快速变更(场景3)ECA    BOM快速更改任务ECA_01
	public static String Ct_EcaType_QuickChange3_01 = "com.fhsj.ECA_01";
	//更改任务 快速变更(场景4)ECA    MBOM辅料快速更改任务ECA_03
	public static String Ct_EcaType_QuickChange4_03 = "com.fhsj.ECA_03";
	public static String Ct_EcaType_Generic = "com.fhsj.ECA_16";
	//更改任务 快速变更(场景5)ECA
	public static String Ct_EcaType_QuickChange5_15 = "com.fhsj.ECA_15";


	//部件类型
	// 成品
	public static String Ct_PartType_EndPart = "com.fhsj.ct_fhsjfinishedproduct";
	// 半成品
	public static String Ct_PartType_HalfEndPart = "com.fhsj.ct_fhsjiallyPreparedProducts";
	// 原材料（电子）
	public static String Ct_PartType_ElecPart = "com.fhsj.ct_fhsjRawMaterialElectronics";
	// 原材料（结构）
	public static String Ct_PartType_StructurePart = "com.fhsj.ct_fhsjRawmaterialstructure";

	public static String Ct_PartType_OutsourcingPart = "com.fhsj.ct_fhsjOutsourcingProduct";


	//部件IBA属性 型号   即产品型号
	public static  final String Ct_IBA_productModel = "ct_model";

	//部件使用关系IBA属性  替代组编号
	public static  final String Ct_IBA_replaceGroup = "ct_substituteGroupNumber";

	//部件使用关系IBA属性  替代组优先级
	public static  final String Ct_IBA_replaceGroupPriority = "ct_Alternategrouppriority";

	//部件使用关系IBA属性  BOM备注
	public static final String Ct_IBA_bomNotes = "ct_BOMNotes";

	//生命周期状态   变更中
	public static String Ct_State_InChange = "InChang";

	//变更IBA属性   更改类型
	public static String Ct_IBA_changeType = "ct_changeType";
}
