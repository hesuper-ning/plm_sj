package ext.plm.ec.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ext.plm.ec.bo.*;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtEcDaoMapper {

	List<CtChangeItemBo> getEBomChangeItems(String changeRequestId) throws Exception;

	List<CtChangeItemBo> getMBomChangeItems(String changeRequestId) throws Exception;

	List<CtPartChangeItemBo> getPartChangeItems(String changeRequestId) throws Exception;

	CtChangeItemBo getEBomChangeItem(String id) throws Exception;

	CtChangeItemBo getMBomChangeItem(String id) throws Exception;

	List<CtEcPcrMaterialItemBo> getPcrMaterialItems(String changeRequestId) throws Exception;

	List<CtEcPmcMaterialItemBo> getPmcMaterialItems(String changeRequestId) throws Exception;

	List<CtEcPdtAuditInfoBo> getPdtAuditInfo(String changeRequestId) throws Exception;

//	List<HashMap<String, Object>> getEcReportItems(HashMap<String, Object> params);
}
