package ext.plm.ec;

import com.alibaba.druid.util.StringUtils;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.ec.bo.*;
import ext.plm.ec.config.CtEcDaoMapper;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import wt.change2.WTChangeRequest2;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.MethodContext;
import wt.pom.Transaction;
import wt.pom.WTConnection;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class CtEcQuery {


    /**
     * 查询更改对象列表
     *
     * @param changeRequestId
     */
    public List<CtChangeItemBo> getChangeItems(String changeRequestId,String type) throws Exception {
        if("ebom".equals(type)){
            return getEBomChangeItems(changeRequestId);
        }
        if("mbom".equals(type)){
            return getMBomChangeItems(changeRequestId);
        }
        return new ArrayList<>();
    }

    /**
     * 查询物料变更
     *
     * @param changeRequestId
     */
    public List<CtPartChangeItemBo> getPartChangeItems(String changeRequestId) throws Exception {

        List<CtPartChangeItemBo> resultList;
        try {
            CtEcDaoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtEcDaoMapper.class);
            resultList = mapper.getPartChangeItems(changeRequestId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
        }
        return resultList;
    }

    /**
     * 查询更改对象列表 EBOM
     *
     * @param changeRequestId
     */
    public List<CtChangeItemBo> getEBomChangeItems(String changeRequestId) throws Exception {

        List<CtChangeItemBo> resultList;
        try {
            CtEcDaoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtEcDaoMapper.class);
            resultList = mapper.getEBomChangeItems(changeRequestId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
        }
        return resultList;
    }

    /**
     * 查询更改对象列表 MBOM
     *
     * @param changeRequestId
     */
    public List<CtChangeItemBo> getMBomChangeItems(String changeRequestId) throws Exception {

        List<CtChangeItemBo> resultList;
        try {
            CtEcDaoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtEcDaoMapper.class);
            resultList = mapper.getMBomChangeItems(changeRequestId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
        }
        return resultList;
    }

    /**
     * 查询更改对象列表
     *
     * @param id
     * @param type
     */
    public CtChangeItemBo getChangeItemById(String id,String type) throws Exception {
        if("ebom".equals(type)){
            return getEBomChangeItem(id);
        }
        if("mbom".equals(type)){
            return getMBomChangeItem(id);
        }
        return null;
    }

    /**
     * 根据ID查询更改对象列表中的一条数据 EBOM
     *
     * @param id
     */
    public CtChangeItemBo getEBomChangeItem(String id) throws Exception {

        CtChangeItemBo resultBo;
        try {
            CtEcDaoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtEcDaoMapper.class);
            resultBo = mapper.getEBomChangeItem(id);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
        }
        return resultBo;
    }

    /**
     * 根据ID查询更改对象列表中的一条数据 MBOM
     *
     * @param id
     */
    public CtChangeItemBo getMBomChangeItem(String id) throws Exception {

        CtChangeItemBo resultBo;
        try {
            CtEcDaoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtEcDaoMapper.class);
            resultBo = mapper.getMBomChangeItem(id);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
        }
        return resultBo;
    }




    /**
     * 清空更改对象列表
     *
     */
    public void clearChangeItems(String changeRequestId,String type) throws Exception {
        if("ebom".equals(type)){
            clearEBomChangeItems(changeRequestId);
        }else if("mbom".equals(type)){
            clearMBomChangeItems(changeRequestId);
        }
    }

    /**
     * 清空更改对象列表  EBOM
     *
     */
    public void clearEBomChangeItems(String changeRequestId) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;

        try {
            ts = new Transaction();
            ts.start();
            String sql = "";
            sql = "delete from ZEcEBomChangeItems where changeRequestId=" + changeRequestId;
            statement = connection.prepareStatement(sql);
            statement.execute();

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 清空更改对象列表  MBOM
     *
     */
    public void clearMBomChangeItems(String changeRequestId) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;

        try {
            ts = new Transaction();
            ts.start();
            String sql = "";
            sql = "delete from ZEcMBomChangeItems where changeRequestId=" + changeRequestId;
            statement = connection.prepareStatement(sql);
            statement.execute();
            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }



    /**
     * 删除更改对象列表
     *
     * @param deleteIdList
     */
    public void deleteChangeItems(List<String> deleteIdList,String type) throws Exception {
        if("ebom".equals(type)){
            deleteEBomChangeItems(deleteIdList);
        }else if("mbom".equals(type)){
            deleteMBomChangeItems(deleteIdList);
        }
    }

    /**
     * 删除物料变更列表
     *
     * @param deleteIdList
     */
    public void deletePartChangeItems(List<String> deleteIdList) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;

        try {
            ts = new Transaction();
            ts.start();
            String sql = "";
            for (String id : deleteIdList) {
                sql = "delete from ZEcPartChangeItems where id=" + id;
                statement = connection.prepareStatement(sql);
                statement.execute();
            }

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 删除更改对象列表  EBOM
     *
     * @param deleteIdList
     */
    public void deleteEBomChangeItems(List<String> deleteIdList) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;

        try {
            ts = new Transaction();
            ts.start();
            String sql = "";
            for (String id : deleteIdList) {
                sql = "delete from ZEcEBomChangeItems where id=" + id;
                statement = connection.prepareStatement(sql);
                statement.execute();
            }

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 删除更改对象列表  MBOM
     *
     * @param deleteIdList
     */
    public void deleteMBomChangeItems(List<String> deleteIdList) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;

        try {
            ts = new Transaction();
            ts.start();
            String sql = "";
            for (String id : deleteIdList) {
                sql = "delete from ZEcMBomChangeItems where id=" + id;
                statement = connection.prepareStatement(sql);
                statement.execute();
            }
            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 导入变更列表
     * @param boList
     * @param type
     * @throws Exception
     */
    public void importChangeItems(List<CtChangeItemBo> boList,String type) throws Exception{
        if("ebom".equals(type)){
            importEBomChangeItems(boList);
        }else if("mbom".equals(type)){
            importMBomChangeItems(boList);
        }
    }

    /**
     * 导入EBOM更改列表
     * @param boList
     * @throws Exception
     */
    public void importEBomChangeItems(List<CtChangeItemBo> boList) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        Transaction  ts = null;
        try {
            if(boList==null||boList.size()==0) {
                return;
            }
            ts = new Transaction();
            ts.start();
            String createSql = "insert into ZEcEBomChangeItems(id,changeRequestId,parentNumber,parentName,childNumberBefore,"
                    + "childNameBefore,bitNumberBefore,amountBefore,replaceNumberBefore,priorityBefore,childNumberAfter,childNameAfter,"
                    + "bitNumberAfter,amountAfter,replaceNumberAfter,priorityAfter,changeType,remark) "
                    + "values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            statement = connection.prepareStatement(createSql);
            for (CtEBomChangeItemBo bo : boList) {
                statement.setString(1, bo.getChangeRequestId());
                statement.setString(2, bo.getParentNumber());
                statement.setString(3, bo.getParentName());
                statement.setString(4, bo.getChildNumberBefore());
                statement.setString(5, bo.getChildNameBefore());
                statement.setString(6, bo.getBitNumberBefore());
                statement.setString(7, bo.getAmountBefore());
                statement.setString(8, bo.getReplaceNumberBefore());
                statement.setString(9, bo.getPriorityBefore());
                statement.setString(10, bo.getChildNumberAfter());
                statement.setString(11, bo.getChildNameAfter());
                statement.setString(12, bo.getBitNumberAfter());
                statement.setString(13, bo.getAmountAfter());
                statement.setString(14, bo.getReplaceNumberAfter());
                statement.setString(15, bo.getPriorityAfter());
                statement.setString(16, bo.getChangeType());
                statement.setString(17, bo.getRemark());
                statement.addBatch();
                int z = 0;
                // 每100次提交一次
                if (z != 0 && z % 100 == 0) {
                    statement.executeBatch();
                    connection.getConnection().commit();
                }
                z++;
            }
            statement.executeBatch();

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(ts!=null) {
                ts.rollback();
            }
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 导入MBOM更改列表
     * @param boList
     * @throws Exception
     */
    public void importMBomChangeItems(List<CtChangeItemBo> boList) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        Transaction  ts = null;
        try {
            if(boList==null||boList.size()==0) {
                return;
            }
            ts = new Transaction();
            ts.start();
            String createSql = "insert into ZEcMBomChangeItems(id,changeRequestId,parentNumber,parentName,childNumberBefore,"
                    + "childNameBefore,bitNumberBefore,amountBefore,replaceNumberBefore,priorityBefore,childNumberAfter,childNameAfter,"
                    + "bitNumberAfter,amountAfter,replaceNumberAfter,priorityAfter,changeType,remark) "
                    + "values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            statement = connection.prepareStatement(createSql);
            for (CtMBomChangeItemBo bo : boList) {
                statement.setString(1, bo.getChangeRequestId());
                statement.setString(2, bo.getParentNumber());
                statement.setString(3, bo.getParentName());
                statement.setString(4, bo.getChildNumberBefore());
                statement.setString(5, bo.getChildNameBefore());
                statement.setString(6, bo.getBitNumberBefore());
                statement.setString(7, bo.getAmountBefore());
                statement.setString(8, bo.getReplaceNumberBefore());
                statement.setString(9, bo.getPriorityBefore());
                statement.setString(10, bo.getChildNumberAfter());
                statement.setString(11, bo.getChildNameAfter());
                statement.setString(12, bo.getBitNumberAfter());
                statement.setString(13, bo.getAmountAfter());
                statement.setString(14, bo.getReplaceNumberAfter());
                statement.setString(15, bo.getPriorityAfter());
                statement.setString(16, bo.getChangeType());
                statement.setString(17, bo.getRemark());
                statement.addBatch();
                int z = 0;
                // 每100次提交一次
                if (z != 0 && z % 100 == 0) {
                    statement.executeBatch();
                    connection.getConnection().commit();
                }
                z++;
            }
            statement.executeBatch();

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(ts!=null) {
                ts.rollback();
            }
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 查询活动表单主表是否创建,无则创建，并返回id
     *
     * @param changeRequestId
     * @param activityKey
     * @return formMasterId 主键id
     */
    public String genFormMasterId(String changeRequestId, String activityKey) throws Exception {

        String formMasterId = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();

        PreparedStatement statement = null;
        ResultSet result = null;
        String sql;
        boolean updateFlag = false;
        try {
            sql = "select * from  ZEcFormMaster where changeRequestId=? and activityKey=?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, changeRequestId);
            statement.setString(2, activityKey);
            result = statement.executeQuery();
            // 脏数据预防
            if (result.getRow() > 1) {
                throw new Exception("数据库异常，存在脏数据，请检查ZEcFormMaster表，changeRequestId=" + changeRequestId + ",activityKey="
                        + activityKey);
            }

            while (result.next()) {
                formMasterId = result.getString("id");
            }

            // 开始创建
            if (!CtFormatUtil.hasContent(formMasterId)) {
                sql = "select ZEc_sequence.NEXTVAL masterId from dual";
                statement = connection.prepareStatement(sql);
                result = statement.executeQuery();
                while (result.next()) {
                    formMasterId = result.getString("masterId");
                }
                sql = "insert into ZEcFormMaster(id,changeRequestId,activityKey) " + " values(?,?,?)";
                statement = connection.prepareStatement(sql);
                statement.setString(1, formMasterId);
                statement.setString(2, changeRequestId);
                statement.setString(3, activityKey);
                statement.execute();
                updateFlag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if(updateFlag) connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }

        return formMasterId;
    }

    /**
     * 保存字段（存在时更新，不存在时新建）
     *
     * @param attKey       字段key
     * @param attValue     字段值
     * @param formMasterId 属性主表单的id
     * @throws Exception
     */
    public void saveAttribute(String attKey, String attValue, String formMasterId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {

            String updateSql = "update ZEcFormAtts set attValue = ? where  masterId = ? and attKey= ?";
            statement = connection.prepareStatement(updateSql);
            statement.setString(1, attValue);
            statement.setString(2, formMasterId);
            statement.setString(3, attKey);
            int updateCount = statement.executeUpdate();

            // 更新条数为0，说明数据不存在，则执行添加
            if (updateCount == 0) {
                System.out.println(">>>>>新增字段>>>>" + attKey + ">>>>" + attValue);
                String createSql = "insert into ZEcFormAtts(masterId,attKey,attValue)  values(?,?,?)";
                statement = connection.prepareStatement(createSql);
                statement.setString(1, formMasterId);
                statement.setString(2, attKey);
                statement.setString(3, attValue);
                statement.execute();
            } else {
                System.out.println(">>>>>执行保存>>>>" + attKey + ">>>>" + attValue + ">>>updateCount=" + updateCount);
            }

            connection.getConnection().commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();

            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 查询变更表头信息
     *
     * @param changeRequestId
     */
    public HashMap<String, String> getHeadInfo(String changeRequestId) throws Exception {

        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        HashMap<String, String> resultData = new HashMap<String, String>();

        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "select attKey,attValue from ZEcFormMaster formMaster,ZEcFormAtts atts "
                    + " where formMaster.id = atts.masterid "
                    + "and formMaster.Changerequestid = ? ";
            statement = connection.prepareStatement(sql);
            statement.setString(1, changeRequestId);
            result = statement.executeQuery();
            int i = 0;
            while (result.next()) {
                i++;
                String attkey = result.getString("attKey");
                if(resultData.containsKey(attkey)) {
                    //检测是否存在重复key
                    System.out.println(">>>变更表单'"+changeRequestId+"'存在重复key:"+attkey);
                }
                resultData.put(result.getString("attKey"), result.getString("attValue"));
            }
            System.out.println(">>>变更表单'"+changeRequestId+"========="+i);

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }

        return resultData;
    }

    /**
     * 保存更改对象列表的主要字段（前后对象的编码及名称）
     *
     * @param bo
     * @throws Exception
     */
    public void saveChangeObjInfo(CtChangeItemBo bo,String mark,String type) throws Exception {
        if("ebom".equals(type)){
            saveEBomChangeObjInfo(bo, mark);
        }else if("mbom".equals(type)){
            saveMBomChangeObjInfo(bo, mark);
        }
    }


    public void insertEBomChangeIems(String changeRequestId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String createSql = "insert into ZEcEBomChangeItems(id,changeRequestId) values(ZEc_sequence.NEXTVAL,?)";
            statement = connection.prepareStatement(createSql);
            statement.setString(1, changeRequestId);
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    public void insertMBomChangeIems(String changeRequestId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String createSql = "insert into ZEcMBomChangeItems(id,changeRequestId) values(ZEc_sequence.NEXTVAL,?)";
            statement = connection.prepareStatement(createSql);
            statement.setString(1, changeRequestId);
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 保存EBOM更改对象列表的主要字段（前后对象的编码及名称）
     *
     * @param bo
     * @throws Exception
     */
    public void saveEBomChangeObjInfo(CtChangeItemBo bo,String mark) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String id = bo.getId();
            String changeRequestId = CtFormatUtil.nullToBlank(bo.getChangeRequestId());
            if (!CtFormatUtil.hasContent(changeRequestId)) {
                throw new Exception("后台数据库异常，更改对象列表缺少changeRequestId！请联系管理员！");
            }
            if (CtFormatUtil.hasContent(id)) {
                // 执行更新
                if("childNumberBefore".equals(mark)) {
                    String updateSql = "update ZEcEBomChangeItems set childNumberBefore = ?,childNameBefore=?,bitNumberBefore=?,amountBefore=?,replaceNumberBefore=?,"
                            + "priorityBefore=?,bomRemarksBefore=?  where  id = ?";
                    statement = connection.prepareStatement(updateSql);
                    statement.setString(1, bo.getChildNumberBefore());
                    statement.setString(2, bo.getChildNameBefore());
                    statement.setString(3, bo.getBitNumberBefore());
                    statement.setString(4, bo.getAmountBefore());
                    statement.setString(5, bo.getReplaceNumberBefore());
                    statement.setString(6, bo.getPriorityBefore());
                    statement.setString(7, bo.getBomRemarksBefore());
                    statement.setString(8, id);
                }else if("childNumberAfter".equals(mark)) {
                    String updateSql = "update ZEcEBomChangeItems set childNumberAfter = ?,childNameAfter=?,bitNumberAfter=?,amountAfter=?,replaceNumberAfter=?,"
                            + "priorityAfter=? ,bomRemarksAfter=? where  id = ?";
                    statement = connection.prepareStatement(updateSql);
                    statement.setString(1, bo.getChildNumberAfter());
                    statement.setString(2, bo.getChildNameAfter());
                    statement.setString(3, bo.getBitNumberAfter());
                    statement.setString(4, bo.getAmountAfter());
                    statement.setString(5, bo.getReplaceNumberAfter());
                    statement.setString(6, bo.getPriorityAfter());
                    statement.setString(7, bo.getBomRemarksAfter());
                    statement.setString(8, id);
                }else if("parentNumber".equals(mark)){
                    String updateSql = "update ZEcEBomChangeItems set parentNumber = ?,parentName=?,bitNumberBefore=?,amountBefore=?,replaceNumberBefore=?,"
                            + "priorityBefore=?,bomRemarksBefore=?,endPartNumber=?,bitNumberAfter=?,amountAfter=?,replaceNumberAfter=?,priorityAfter=?,bomRemarksAfter=?  where  id = ?";
                    statement = connection.prepareStatement(updateSql);
                    statement.setString(1, bo.getParentNumber());
                    statement.setString(2, bo.getParentName());
                    statement.setString(3, bo.getBitNumberBefore());
                    statement.setString(4, bo.getAmountBefore());
                    statement.setString(5, bo.getReplaceNumberBefore());
                    statement.setString(6, bo.getPriorityBefore());
                    statement.setString(7, bo.getBomRemarksBefore());
                    statement.setString(8, bo.getEndPartNumber());
                    statement.setString(9, bo.getBitNumberAfter());
                    statement.setString(10, bo.getAmountAfter());
                    statement.setString(11, bo.getReplaceNumberAfter());
                    statement.setString(12, bo.getPriorityAfter());
                    statement.setString(13, bo.getBomRemarksAfter());
                    statement.setString(14, id);
                }else{
                    throw new Exception("后台数据库异常，mark 不是正常数据："+mark+"！请联系管理员！");
                }
                statement.executeUpdate();
            } else {
                // 执行创建
                if("childNumberBefore".equals(mark)) { // 取bom的值
                    String createSql = "insert into ZEcEBomChangeItems(id,changeRequestId,childNumberBefore,childNameBefore,bitNumberBefore,amountBefore,replaceNumberBefore,"
                            + "priorityBefore,bomRemarksBefore) values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?,?)";
                    statement = connection.prepareStatement(createSql);
                    statement.setString(1, bo.getChangeRequestId());
                    statement.setString(2, bo.getChildNumberBefore());
                    statement.setString(3, bo.getChildNameBefore());
                    statement.setString(4, bo.getBitNumberBefore());
                    statement.setString(5, bo.getAmountBefore());
                    statement.setString(6, bo.getReplaceNumberBefore());
                    statement.setString(7, bo.getPriorityBefore());
                    statement.setString(8, bo.getBomRemarksBefore());
                }else if("childNumberAfter".equals(mark)) {
                    String createSql = "insert into ZEcEBomChangeItems(id,changeRequestId,childNumberAfter,childNameAfter,bitNumberAfter,amountAfter,replaceNumberAfter,"
                            + "priorityAfter,bomRemarksAfter) values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?,?)";
                    statement = connection.prepareStatement(createSql);
                    statement.setString(1, bo.getChangeRequestId());
                    statement.setString(2, bo.getChildNumberAfter());
                    statement.setString(3, bo.getChildNameAfter());
                    statement.setString(4, bo.getBitNumberAfter());
                    statement.setString(5, bo.getAmountAfter());
                    statement.setString(6, bo.getReplaceNumberAfter());
                    statement.setString(7, bo.getPriorityAfter());
                    statement.setString(8, bo.getBomRemarksAfter());
                }else if("parentNumber".equals(mark)){
                    String createSql = "insert into ZEcEBomChangeItems(id,changeRequestId,parentNumber,parentName,bitNumberBefore,amountBefore,replaceNumberBefore,"
                            + "priorityBefore,bomRemarksBefore,endPartNumber,bitNumberAfter,amountAfter,replaceNumberAfter,priorityAfter,bomRemarksAfter) values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                    statement = connection.prepareStatement(createSql);
                    statement.setString(1, bo.getChangeRequestId());
                    statement.setString(2, bo.getParentNumber());
                    statement.setString(3, bo.getParentName());
                    statement.setString(4, bo.getBitNumberBefore());
                    statement.setString(5, bo.getAmountBefore());
                    statement.setString(6, bo.getReplaceNumberBefore());
                    statement.setString(7, bo.getPriorityBefore());
                    statement.setString(8, bo.getBomRemarksBefore());
                    statement.setString(9, bo.getEndPartNumber());
                    statement.setString(10, bo.getBitNumberAfter());
                    statement.setString(11, bo.getAmountAfter());
                    statement.setString(12, bo.getReplaceNumberAfter());
                    statement.setString(13, bo.getPriorityAfter());
                    statement.setString(14, bo.getBomRemarksAfter());
                }else{
                    throw new Exception("后台数据库异常，mark 不是正常数据："+mark+"！请联系管理员！");
                }
                statement.execute();
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 保存MBOM更改对象列表的主要字段（前后对象的编码及名称）
     *
     * @param bo
     * @throws Exception
     */
    public void saveMBomChangeObjInfo(CtChangeItemBo bo,String mark) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String id = bo.getId();
            String changeRequestId = CtFormatUtil.nullToBlank(bo.getChangeRequestId());
            if (!CtFormatUtil.hasContent(changeRequestId)) {
                throw new Exception("后台数据库异常，更改对象列表缺少changeRequestId！请联系管理员！");
            }
            if (CtFormatUtil.hasContent(id)) {
                // 执行更新
                if("childNumberBefore".equals(mark)) {
                    String updateSql = "update ZEcMBomChangeItems set childNumberBefore = ?,childNameBefore=?,bitNumberBefore=?,amountBefore=?,replaceNumberBefore=?,"
                            + "priorityBefore=?,bomRemarksBefore=?  where  id = ?";
                    statement = connection.prepareStatement(updateSql);
                    statement.setString(1, bo.getChildNumberBefore());
                    statement.setString(2, bo.getChildNameBefore());
                    statement.setString(3, bo.getBitNumberBefore());
                    statement.setString(4, bo.getAmountBefore());
                    statement.setString(5, bo.getReplaceNumberBefore());
                    statement.setString(6, bo.getPriorityBefore());
                    statement.setString(7, bo.getBomRemarksBefore());
                    statement.setString(8, id);
                }else if("childNumberAfter".equals(mark)) {
                    String updateSql = "update ZEcMBomChangeItems set childNumberAfter = ?,childNameAfter=?,bitNumberAfter=?,amountAfter=?,replaceNumberAfter=?,"
                            + "priorityAfter=? ,bomRemarksAfter=? where  id = ?";
                    statement = connection.prepareStatement(updateSql);
                    statement.setString(1, bo.getChildNumberAfter());
                    statement.setString(2, bo.getChildNameAfter());
                    statement.setString(3, bo.getBitNumberAfter());
                    statement.setString(4, bo.getAmountAfter());
                    statement.setString(5, bo.getReplaceNumberAfter());
                    statement.setString(6, bo.getPriorityAfter());
                    statement.setString(7, bo.getBomRemarksAfter());
                    statement.setString(8, id);
                }else if("parentNumber".equals(mark)){
                    String updateSql = "update ZEcMBomChangeItems set parentNumber = ?,parentName=?,bitNumberBefore=?,amountBefore=?,replaceNumberBefore=?,"
                            + "priorityBefore=?,bomRemarksBefore=?,endPartNumber=?,bitNumberAfter=?,amountAfter=?,replaceNumberAfter=?,priorityAfter=?,bomRemarksAfter=?  where  id = ?";
                    statement = connection.prepareStatement(updateSql);
                    statement.setString(1, bo.getParentNumber());
                    statement.setString(2, bo.getParentName());
                    statement.setString(3, bo.getBitNumberBefore());
                    statement.setString(4, bo.getAmountBefore());
                    statement.setString(5, bo.getReplaceNumberBefore());
                    statement.setString(6, bo.getPriorityBefore());
                    statement.setString(7, bo.getBomRemarksBefore());
                    statement.setString(8, bo.getEndPartNumber());
                    statement.setString(9, bo.getBitNumberAfter());
                    statement.setString(10, bo.getAmountAfter());
                    statement.setString(11, bo.getReplaceNumberAfter());
                    statement.setString(12, bo.getPriorityAfter());
                    statement.setString(13, bo.getBomRemarksAfter());
                    statement.setString(14, id);
                }else{
                    throw new Exception("后台数据库异常，mark 不是正常数据："+mark+"！请联系管理员！");
                }
                statement.executeUpdate();
            } else {
                // 执行创建
                if("childNumberBefore".equals(mark)) { // 取bom的值
                    String createSql = "insert into ZEcMBomChangeItems(id,changeRequestId,childNumberBefore,childNameBefore,bitNumberBefore,amountBefore,replaceNumberBefore,"
                            + "priorityBefore,bomRemarksBefore) values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?,?)";
                    statement = connection.prepareStatement(createSql);
                    statement.setString(1, bo.getChangeRequestId());
                    statement.setString(2, bo.getChildNumberBefore());
                    statement.setString(3, bo.getChildNameBefore());
                    statement.setString(4, bo.getBitNumberBefore());
                    statement.setString(5, bo.getAmountBefore());
                    statement.setString(6, bo.getReplaceNumberBefore());
                    statement.setString(7, bo.getPriorityBefore());
                    statement.setString(8, bo.getBomRemarksBefore());
                }else if("childNumberAfter".equals(mark)) {
                    String createSql = "insert into ZEcMBomChangeItems(id,changeRequestId,childNumberAfter,childNameAfter,bitNumberAfter,amountAfter,replaceNumberAfter,"
                            + "priorityAfter,bomRemarksAfter) values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?,?)";
                    statement = connection.prepareStatement(createSql);
                    statement.setString(1, bo.getChangeRequestId());
                    statement.setString(2, bo.getChildNumberAfter());
                    statement.setString(3, bo.getChildNameAfter());
                    statement.setString(4, bo.getBitNumberAfter());
                    statement.setString(5, bo.getAmountAfter());
                    statement.setString(6, bo.getReplaceNumberAfter());
                    statement.setString(7, bo.getPriorityAfter());
                    statement.setString(8, bo.getBomRemarksAfter());
                }else if("parentNumber".equals(mark)){
                    String createSql = "insert into ZEcMBomChangeItems(id,changeRequestId,parentNumber,parentName,bitNumberBefore,amountBefore,replaceNumberBefore,"
                            + "priorityBefore,bomRemarksBefore,endPartNumber,bitNumberAfter,amountAfter,replaceNumberAfter,priorityAfter,bomRemarksAfter) values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                    statement = connection.prepareStatement(createSql);
                    statement.setString(1, bo.getChangeRequestId());
                    statement.setString(2, bo.getParentNumber());
                    statement.setString(3, bo.getParentName());
                    statement.setString(4, bo.getBitNumberBefore());
                    statement.setString(5, bo.getAmountBefore());
                    statement.setString(6, bo.getReplaceNumberBefore());
                    statement.setString(7, bo.getPriorityBefore());
                    statement.setString(8, bo.getBomRemarksBefore());
                    statement.setString(9, bo.getEndPartNumber());
                    statement.setString(10, bo.getBitNumberAfter());
                    statement.setString(11, bo.getAmountAfter());
                    statement.setString(12, bo.getReplaceNumberAfter());
                    statement.setString(13, bo.getPriorityAfter());
                    statement.setString(14, bo.getBomRemarksAfter());
                }else{
                    throw new Exception("后台数据库异常，mark 不是正常数据："+mark+"！请联系管理员！");
                }
                statement.execute();
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 创建变更表头信息
     *
     * @param changeRequestId
     */
    public void createHeadInfo(String changeRequestId, String activityKey, HashMap<String, String> keyValueMap)
            throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();

        PreparedStatement statement = null;
        Transaction ts = null;
        try {
            ts = new Transaction();
            ts.start();

            // 生成活动表单主表
            String formMasterId = genFormMasterId(changeRequestId, activityKey);
            for (String attKey : keyValueMap.keySet()) {

                String updateSql = "update ZEcFormAtts set attValue = ? where  masterId = ? and attKey= ?";
                statement = connection.prepareStatement(updateSql);
                statement.setString(1, keyValueMap.get(attKey));
                statement.setString(2, formMasterId);
                statement.setString(3, attKey);
                int updateCount = statement.executeUpdate();

                // 更新条数为0，说明数据不存在，则执行添加
                if (updateCount == 0) {
                    System.out.println(">>>>>新增字段>>>>" + attKey + ">>>>" + keyValueMap.get(attKey));
                    String sql2 = "insert into ZEcFormAtts(masterId,attKey,attValue)  values(?,?,?)";
                    statement = connection.prepareStatement(sql2);
                    statement.setString(1, formMasterId);
                    statement.setString(2, attKey);
                    statement.setString(3, keyValueMap.get(attKey));
                    statement.execute();
                }
            }

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            // connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }


    /**
     * 查询pcr采购分析信息列表
     *
     * @param changeRequestId
     */
    public List<CtEcPcrMaterialItemBo> getPcrMaterialItems(String changeRequestId) throws Exception {

        List<CtEcPcrMaterialItemBo> resultList;
        try {
            CtEcDaoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtEcDaoMapper.class);
            resultList = mapper.getPcrMaterialItems(changeRequestId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {

        }
        return resultList;
    }

    /**
     * 查询pmc采购分析信息列表
     *
     * @param changeRequestId
     */
    public List<CtEcPmcMaterialItemBo> getPmcMaterialItems(String changeRequestId) throws Exception {

        List<CtEcPmcMaterialItemBo> resultList;
        try {
            CtEcDaoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtEcDaoMapper.class);
            resultList = mapper.getPmcMaterialItems(changeRequestId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
        }
        return resultList;
    }

    /**
     * 查询PDT团队评审信息
     *
     * @param changeRequestId
     */
    public List<CtEcPdtAuditInfoBo> getPdtAuditInfo(String changeRequestId) throws Exception {

        List<CtEcPdtAuditInfoBo> resultList;
        try {
            CtEcDaoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtEcDaoMapper.class);
            resultList = mapper.getPdtAuditInfo(changeRequestId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
        }
        return resultList;
    }

    /**
     * 获取单个属性值（用于必填验证）
     *
     * @param changeRequestId 变更单id
     * @param attKey          属性内部值
     */
    public String getAttributeValue(String changeRequestId, String attKey) throws Exception {

        String attValue = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {

            /*
             * select attValue from ZEcFormMaster formMaster,ZEcFormAtts atts where
             * formMaster.id = atts.masterid and formMaster.Changerequestid =
             * 'VR:wt.change2.WTChangeRequest2:344175' and atts.attkey = 'head_backgroud'
             */
            String sql = "select attValue from ZEcFormMaster formMaster,ZEcFormAtts atts "
                    + " where formMaster.id = atts.masterid " + " and formMaster.Changerequestid =? and atts.attkey=? ";
            statement = connection.prepareStatement(sql);
            statement.setString(1, changeRequestId);
            statement.setString(2, attKey);
            resultSet = statement.executeQuery();

            // 脏数据预防
            if (resultSet.getRow() > 1) {
                System.out.println(">>>数据库异常，存在脏数据，存在多条记录,attKey='" + attKey + ">>changeRequestId=" + changeRequestId);
                throw new WTException("数据库异常，存在脏数据，attKey='" + attKey + "'存在多条记录，本应该只有一条！请联系管理员！");
            }

            while (resultSet.next()) {
                attValue = resultSet.getString("attValue");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            // connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }

        return attValue;
    }


    /**
     * 保存更改对象列表 除编码、名称之外的其他列
     *
     * @param id
     * @param key
     * @param value
     */
    public void saveChangeListField(String id, String key, String value,String type) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            if("ebom".equals(type)){
                String updateSql = "update ZEcEBomChangeItems set " + key + "=? where id=?";
                statement = connection.prepareStatement(updateSql);
                statement.setString(1, value);
                statement.setString(2, id);
                statement.executeUpdate();
            }else if("mbom".equals(type)){
                String updateSql = "update ZEcMBomChangeItems set " + key + "=? where id=?";
                statement = connection.prepareStatement(updateSql);
                statement.setString(1, value);
                statement.setString(2, id);
                statement.executeUpdate();
            }


        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 保存物料变更列表
     *
     * @param id
     * @param key
     * @param value
     */
    public String savePartChangeItems(String id, String key, String value,String changeRequestId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {

            if (StringUtils.isEmpty(id)) {
                String sql = "select ZEc_sequence.NEXTVAL id from dual";
                statement = connection.prepareStatement(sql);
                resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    id = resultSet.getString("id");
                }
                String insertSql = "insert into ZEcPartChangeItems (id," + key + ",changeRequestId) values (?,?,?)";
                statement = connection.prepareStatement(insertSql);
                statement.setString(1,id);
                statement.setString(2,value);
                statement.setString(3, changeRequestId);

            }else{
                String updateSql = "update ZEcPartChangeItems set " + key + " = ? where  id=?";
                statement = connection.prepareStatement(updateSql);
                statement.setString(1,value);
                statement.setString(2, id);
            }
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return id;
    }

    /**
     * 自动加入受影响物料到采购分析列表
     *
     * @param materials       需要自动 加入的物料
     * @param changeRequestId
     */
    public void autoAddPcrMaterials(List<CtEcPcrMaterialItemBo> materials, String changeRequestId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;
        try {
            ts = new Transaction();
            ts.start();

            for (CtEcPcrMaterialItemBo bo : materials) {
                // 执行创建
                String createSql = "insert into ZEcPcrMaterialItems(id,partNumber,partName,changeRequestId,stock,po,pr) "
                        + " values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?)";
                statement = connection.prepareStatement(createSql);
                statement.setString(1, bo.getPartNumber());
                statement.setString(2, bo.getPartName());
                statement.setString(3, changeRequestId);
                statement.setString(4, bo.getStock());
                statement.setString(5, bo.getPo());
                statement.setString(6, bo.getPr());
                statement.execute();
            }
            ts.commit();
            ts = null;

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 自动加入受影响物料到物控分析列表
     *
     * @param materials       需要自动 加入的物料
     * @param changeRequestId
     */
    public void autoAddPmcMaterials(List<CtEcPmcMaterialItemBo> materials, String changeRequestId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;
        try {
            ts = new Transaction();
            ts.start();

            for (CtEcPmcMaterialItemBo bo : materials) {
                // 执行创建
                String createSql = "insert into ZEcPmcMaterialItems(id,partNumber,partName,changeRequestId,stock,inMaking,maintain,salesOrder) "
                        + " values(ZEc_sequence.NEXTVAL,?,?,?,?,?,?,?)";
                statement = connection.prepareStatement(createSql);
                statement.setString(1, bo.getPartNumber());
                statement.setString(2, bo.getPartName());
                statement.setString(3, changeRequestId);
                statement.setString(4, bo.getStock());
                statement.setString(5, bo.getInMaking());
                statement.setString(6, bo.getMaintain());
                statement.setString(7, bo.getSalesOrder());
                statement.execute();
            }
            ts.commit();
            ts = null;

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    public void deletePcrMatItems(List<String> deleteIdList) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;

        try {
            ts = new Transaction();
            ts.start();

            String sql = "";
            for (String id : deleteIdList) {
                sql = "delete from ZEcPcrMaterialItems where id=" + id;
                statement = connection.prepareStatement(sql);
                statement.execute();
            }

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            // connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    public void deletePmcMatItems(List<String> deleteIdList) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;

        try {
            ts = new Transaction();
            ts.start();

            String sql = "";
            for (String id : deleteIdList) {
                sql = "delete from ZECPMCMATERIALITEMS where id=" + id;
                statement = connection.prepareStatement(sql);
                statement.execute();
            }

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            // connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    public void deletePcrMatItems(String changeRequestId) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "delete from ZEcPcrMaterialItems where changeRequestId = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1,changeRequestId);
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    public void deletePmcMatItems(String changeRequestId) throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = (WTConnection) methodContext.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "delete from ZECPMCMATERIALITEMS where changeRequestId=?";
            statement = connection.prepareStatement(sql);
            statement.setString(1,changeRequestId);
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null)
                statement.close();
             connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 保存采购分析列表的物料编码及名称字段 （根据id判断是新增还是更新)
     *
     * @param pcrMaterialNumberInfo
     * @throws Exception
     */
    public void savePcrMaterialNumber(HashMap<String, String> pcrMaterialNumberInfo) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {

            String id = pcrMaterialNumberInfo.get("id");
            String changeRequestId = CtFormatUtil.nullToBlank(pcrMaterialNumberInfo.get("changeRequestId"));
            if (!CtFormatUtil.hasContent(changeRequestId)) {
                throw new Exception("后台数据库异常，更改对象列表缺少changeRequestId！请联系管理员！");
            }
            String materialNumber = CtFormatUtil.nullToBlank(pcrMaterialNumberInfo.get("materialNumber"));
            String materialName = CtFormatUtil.nullToBlank(pcrMaterialNumberInfo.get("materialName"));

            if (CtFormatUtil.hasContent(id)) {
                // 执行更新
                String updateSql = "update ZEcPcrMaterialItems set partNumber = ?,partName=? "
                        + "  where  id = ?";
                statement = connection.prepareStatement(updateSql);
                statement.setString(1, materialNumber);
                statement.setString(2, materialName);
                statement.setString(3, id);
                statement.executeUpdate();
            } else {
                // 执行创建
                String createSql = "insert into ZEcPcrMaterialItems(id,partNumber,partName,changeRequestId) "
                        + " values(ZEc_sequence.NEXTVAL,?,?,?)";
                statement = connection.prepareStatement(createSql);
                statement.setString(1, materialNumber);
                statement.setString(2, materialName);
                statement.setString(3, changeRequestId);
                statement.execute();
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 采购分析 列表实时保存 （除物料编码列）
     *
     * @param id
     * @param key
     * @param value
     */
    public void savePcrMaterialField(String id, String key, String value) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {

            String updateSql = "update ZEcPcrMaterialItems set " + key + "=? where id=?";
            statement = connection.prepareStatement(updateSql);
            statement.setString(1, value);
            statement.setString(2, id);
            statement.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 保存物控分析列表的物料编码及名称字段 （根据id判断是新增还是更新)
     *
     * @param pmcMaterialNumberInfo
     * @throws Exception
     */
    public void savePmcMaterialNumber(HashMap<String, String> pmcMaterialNumberInfo) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {

            String id = pmcMaterialNumberInfo.get("id");
            String changeRequestId = CtFormatUtil.nullToBlank(pmcMaterialNumberInfo.get("changeRequestId"));
            if (!CtFormatUtil.hasContent(changeRequestId)) {
                throw new Exception("后台数据库异常，更改对象列表缺少changeRequestId！请联系管理员！");
            }
            String materialNumber = CtFormatUtil.nullToBlank(pmcMaterialNumberInfo.get("materialNumber"));
            String materialName = CtFormatUtil.nullToBlank(pmcMaterialNumberInfo.get("materialName"));

            if (CtFormatUtil.hasContent(id)) {
                // 执行更新
                String updateSql = "update ZEcPmcMaterialItems set partNumber = ?,partName=? "
                        + "  where  id = ?";
                statement = connection.prepareStatement(updateSql);
                statement.setString(1, materialNumber);
                statement.setString(2, materialName);
                statement.setString(3, id);
                statement.executeUpdate();
            } else {
                // 执行创建
                String createSql = "insert into ZEcPmcMaterialItems(id,partNumber,partName,changeRequestId) "
                        + " values(ZEc_sequence.NEXTVAL,?,?,?)";
                statement = connection.prepareStatement(createSql);
                statement.setString(1, materialNumber);
                statement.setString(2, materialName);
                statement.setString(3, changeRequestId);
                statement.execute();
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     *  物控分析列表实时保存 （除物料编码列）
     *
     * @param id
     * @param key
     * @param value
     */
    public void savePmcMaterialField(String id, String key, String value) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {

            String updateSql = "update ZEcPmcMaterialItems set " + key + "=? where id=?";
            statement = connection.prepareStatement(updateSql);
            statement.setString(1, value);
            statement.setString(2, id);
            statement.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 保存PDT团队评审信息
     *
     * @param bo
     */
    public void savePdtAuditInfo(CtEcPdtAuditInfoBo bo) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            // 执行创建
            String createSql = "insert into ZEcPdtAuditInfo(id,changeRequestId,auditUser,auditTime,auditComment) "
                    + " values(ZEc_sequence.NEXTVAL,?,?,?,?)";
            statement = connection.prepareStatement(createSql);
            statement.setString(1, bo.getChangeRequestId());
            statement.setString(2, bo.getAuditUser());
            statement.setString(3, bo.getAuditTime());
            statement.setString(4, bo.getAuditComment());
            statement.execute();


        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    /**
     * 获取固定前缀+四位流水号  ECR最大编号
     * @param prefix
     * @return
     * @throws Exception
     */
    public String getMaxEcrNumberByPrefix(String prefix) throws Exception {
        QuerySpec querySpec = new QuerySpec(WTChangeRequest2.class);
        querySpec.setAdvancedQueryEnabled(true);
        querySpec.appendSearchCondition(new SearchCondition(WTChangeRequest2.class,WTChangeRequest2.NUMBER,SearchCondition.LIKE,prefix+"____"));
        ClassAttribute cls = new ClassAttribute(WTChangeRequest2.class, WTChangeRequest2.NUMBER);
        querySpec.appendOrderBy(new OrderBy(cls,true));
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        while(queryResult.hasMoreElements()){
            Object obj = queryResult.nextElement();
            WTChangeRequest2 changeRequest = (WTChangeRequest2)obj;
            return changeRequest.getNumber();
        }
        return "";
    }

    /**
     * 增加ecn编号
     * @param ecNumber ecn编号
     * @return  String  ItemId
     * @throws Exception
     */
    public String genEcNumber(String ecNumber) throws Exception{
        String returnId="";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "";
            //新增操作
            String nextSeq = getEcSequence();
            sql = "insert into ZEcNumber(id,ecNumber) values(?,?)";
            statement = connection.prepareStatement(sql);
            statement.setString(1,nextSeq);
            statement.setString(2,ecNumber);
            statement.execute();
            returnId = nextSeq;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {

            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }

        return returnId;
    }
    /**
     * 查找ECN流水号
     * @param number 编号
     * @return  String  ItemId
     * @throws Exception
     */
    public String getEcNumber(String number) throws Exception{
        String returnNumber="";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "";
            sql = "select max(ecNumber) ecNumber from ZEcNumber where ecNumber like ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1,number+"___");
            statement.execute();
            result = statement.executeQuery();

            while (result.next()) {
                returnNumber = result.getString("ecNumber");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null){
                statement.close();
            }
            if (connection != null && connection.isActive()){
                connection.release();
            }
        }

        return returnNumber;
    }

    /**
     * 获取序列值
     * @return
     * @throws Exception
     */
    public String  getEcSequence() throws Exception{

        String nextSeq = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "select ZEc_sequence.Nextval nextSeq from dual" ;
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();

            while (result.next()) {
                nextSeq = result.getString("nextSeq");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return nextSeq;
    }

    public List<HashMap<String, Object>> getEcReportItems(HashMap<String, Object> params) throws Exception {
        List<HashMap<String,Object>> resultList = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = " select * from ( select rownum id,tempTab.* from ( select totalData.* from ( " +
                    "  select 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO CHANGEREQUESTID,  TO_CHAR((ec.CREATESTAMPA2+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss')  createDate,ec.statestate state,formAtt.ATTVALUE from ( " +
                    "  SELECT zm.CHANGEREQUESTID, " +
                    "  XMLAGG(xmlparse(CONTENT (za.ATTKEY|| '-+-' ||za.ATTVALUE)||'@' wellformed )ORDER BY za.ATTVALUE).getclobval() " +
                    "  as ATTVALUE " +
                    "  from ZECFORMMASTER zm " +
                    "  left join ZECFORMATTS za on zm.id = za.MASTERID " +
                    "  where za.ATTKEY in ('head_ecrNumber','head_ecrName', 'head_changeType', 'head_productModel', 'head_changeReason', 'head_changeDesc', " +
                    "  'trialSuggest', 'head_applicant', 'head_applyTime', 'head_affectedEndParts', 'head_affectedBOMs', 'head_affectedDocs', " +
                    "  'rdRep_auditUser', 'rdRep_auditTime', 'ebomCharge_auditUser', 'ebomCharge_auditTime', 'mbomCharge_auditUser', " +
                    "  'mbomCharge_auditTime', 'consistencyRisk_auditUser', 'consistencyRisk_auditTime', 'ccbGroup_auditTime', " +
                    "  'pdt_auditTime', 'pdt_auditUser', 'ccb_auditTime', 'ipmt_auditTime', 'ecrApprovalTime', 'result_auditTime', " +
                    "  'pdt_endItemsPlan1','pdt_endItemsPlan2','pdt_endItemsPlan3','pdt_endItemsPlan4','pdt_endItemsPlan5','pdt_materialPlan1','pdt_materialPlan2','pdt_materialPlan3','pdt_materialPlan4') " +
                    "  GROUP BY zm.CHANGEREQUESTID " +
                    "  ) formAtt " +
                    "  RIGHT JOIN WTCHANGEREQUEST2 ec ON 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO = formAtt.CHANGEREQUESTID" +
                    " LEFT JOIN WTTYPEDEFINITION w ON ec.IDA2TYPEDEFINITIONREFERENCE=w.IDA2A2" +
                    " LEFT JOIN WTTYPEDEFINITIONMASTER w2 ON w.IDA3MASTERREFERENCE = w2.IDA2A2" +
                    " WHERE w2.INTHID = 'wt.change2.WTChangeRequest2|com.fhsj.ctProductionEC'";
            sql += " ) totalData order by CREATEDATE DESC ) tempTab where 1=1 ";
            if(CtFormatUtil.hasContent(params.get("paramAll"))){
                sql+=" and upper(ATTVALUE) like upper('%"+(String)params.get("paramAll")+"%') ";
            }
            if(CtFormatUtil.hasContent(params.get("state"))){
                sql+=" and state = '"+(String)params.get("state")+"' ";
            }
            if(CtFormatUtil.hasContent(params.get("createDate_start"))){
                sql+=" and  createDate >= '"+(String)params.get("createDate_start")+"' ";
            }
            if(CtFormatUtil.hasContent(params.get("createDate_end"))){
                sql+=" and createDate <= '"+(String)params.get("createDate_end")+"' ";
            }
            if(CtFormatUtil.hasContent(params.get("pageSize"))){
                sql+=" and ROWNUM <= "+params.get("pageSize");
            }
            sql+="  ) totalAll";
            if(CtFormatUtil.hasContent(params.get("start"))){
                sql+=" where totalAll.id > "+params.get("start");
            }
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();
            while (result.next()) {
                HashMap<String,Object> map = new HashMap<>();
                String id = result.getString("ID");
                if(CtFormatUtil.hasContent(id)){
                    map.put("ID",id);
                }
                String changeRequestId = result.getString("CHANGEREQUESTID");
                if(CtFormatUtil.hasContent(changeRequestId)){
                    map.put("CHANGEREQUESTID",changeRequestId);
                }
                String state = result.getString("state");
                if(CtFormatUtil.hasContent(state)){
                    map.put("state",state);
                }
                String createDate = result.getString("createDate");
                if(CtFormatUtil.hasContent(createDate)){
                    map.put("createDate",createDate);
                }
                Clob clob = result.getClob("ATTVALUE");
                if(CtFormatUtil.hasContent(clob)){
                    String attValue = clob.getSubString(1L, (int) clob.length());
                    map.put("ATTVALUE",attValue);
                }
                resultList.add(map);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return resultList;
    }

    public List<Map<String,String>> getNewEcReportItems(HashMap<String, Object> params) throws Exception {
        List<Map<String,String>> resultList = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = " select * from (" +
                    " select rownum id,tempTab.* from (" +
                    " SELECT y.*," +
                    " y.head_ecrNumber||y.head_applicant||y.createDate||y.head_ecrName||y.state||y.head_changeType||y.head_changeReason||" +
                    " y.head_productModel||y.partF||y.ebomF||y.mbomF||y.head_affectedBOMs||y.head_affectedDocs||y.trialSuggest||y.rdRep_auditUser||" +
                    " y.rdRep_auditTime||y.ebomCharge_auditUser||y.mbomCharge_auditUser||y.consistencyRisk_auditUser||y.handlingOpinions||y.pdt_auditUser||y.CHANGESOURCE AS ATTVALUE " +
                    " from (" +
                    " SELECT" +
                    " 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO CHANGEREQUESTID," +
                    " z1.ECRNUMBER head_ecrNumber,z1.applicant head_applicant," +
                    " TO_CHAR((z1.applicationTime+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') createDate," +
                    " z1.ECRNAME head_ecrName,ec.statestate state,z1.CHANGETYPE head_changeType,z1.CHANGEREASON head_changeReason," +
                    " z1.PRODUCTMODEL head_productModel, s1.partF, s2.ebomF, s3.mbomF, s4.head_affectedBOMs," +
                    " s5.head_affectedDocs, s6.trialSuggest, s10.APPROVEDBY rdRep_auditUser, " +
                    " TO_CHAR((s10.APPROVALTIME+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') rdRep_auditTime," +
                    " s11.APPROVEDBY ebomCharge_auditUser, TO_CHAR((s11.APPROVALTIME+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') ebomCharge_auditTime," +
                    " s12.APPROVEDBY mbomCharge_auditUser, TO_CHAR((s12.APPROVALTIME+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') mbomCharge_auditTime," +
                    " s13.APPROVEDBY consistencyRisk_auditUser, TO_CHAR((s13.APPROVALTIME+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') consistencyRisk_auditTime," +
                    " s7.handlingOpinions, TO_CHAR((s8.ccbGroup_auditTime+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss')ccbGroup_auditTime," +
                    " s14.APPROVEDBY pdt_auditUser, TO_CHAR((s14.APPROVALTIME+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') pdt_auditTime," +
                    " TO_CHAR((s15.APPROVALTIME+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') ccb_auditTime," +
                    " TO_CHAR((s16.APPROVALTIME+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') ipmt_auditTime," +
                    " s9.BRANCHID, s9.closeDocEndTime, z1.CHANGESOURCE" +
                    " FROM WTCHANGEREQUEST2 ec LEFT JOIN WTTYPEDEFINITION w ON ec.IDA2TYPEDEFINITIONREFERENCE=w.IDA2A2 " +
                    "  LEFT JOIN WTTYPEDEFINITIONMASTER w2 ON w.IDA3MASTERREFERENCE = w2.IDA2A2" +
                    "  LEFT JOIN ZEcrInfoTable z1 ON z1.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT z2.CHANGEREQUESTID, rtrim(XMLAGG(XMLPARSE(CONTENT(z2.PARENTNUMBER||',') WELLFORMED) ORDER BY z2.PARENTNUMBER).getclobval(),',') as partF FROM ZMaterialChangeTable z2 " +
                    "  WHERE z2.TABLETYPE = 'EcrMaterialChange'" +
                    " GROUP BY z2.CHANGEREQUESTID" +
                    "  ) s1 ON s1.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT z3.CHANGEREQUESTID, rtrim(XMLAGG(XMLPARSE(CONTENT(z3.FINISHEDPRODUCTNUMBER||',') WELLFORMED) ORDER BY z3.FINISHEDPRODUCTNUMBER).getclobval(),',') as ebomF FROM ZEBomChangeTable z3 " +
                    "  WHERE z3.TABLETYPE = 'EcrEBomChange'" +
                    " GROUP BY z3.CHANGEREQUESTID" +
                    "  ) s2 ON s2.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT z4.CHANGEREQUESTID, rtrim(XMLAGG(XMLPARSE(CONTENT(z4.FINISHEDPRODUCTNUMBER||',') WELLFORMED) ORDER BY z4.FINISHEDPRODUCTNUMBER).getclobval(),',') as mbomF FROM ZMBomChangeTable z4 " +
                    "  WHERE z4.TABLETYPE = 'EcrMBomChange'" +
                    " GROUP BY z4.CHANGEREQUESTID" +
                    "  ) s3 ON s3.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT z5.CHANGEREQUESTID, rtrim(XMLAGG(XMLPARSE(CONTENT(z5.OBJECTNUMBER||',') WELLFORMED) ORDER BY z5.OBJECTNUMBER).getclobval(),',') as head_affectedBOMs" +
                    " FROM (" +
                    " SELECT DISTINCT z4.OBJECTNUMBER, z4.CHANGEREQUESTID FROM ZAffectedObjectTable z4 WHERE z4.OBJECTTYPE = '部件'" +
                    " ) z5 GROUP BY z5.CHANGEREQUESTID" +
                    "  ) s4 ON s4.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT z7.CHANGEREQUESTID, rtrim(XMLAGG(XMLPARSE(CONTENT(z7.OBJECTNUMBER||',') WELLFORMED) ORDER BY z7.OBJECTNUMBER).getclobval(),',') as head_affectedDocs" +
                    " FROM " +
                    " (" +
                    " SELECT DISTINCT z6.OBJECTNUMBER, z6.CHANGEREQUESTID FROM ZAffectedObjectTable z6 WHERE z6.OBJECTTYPE != '部件'" +
                    " ) z7 GROUP BY z7.CHANGEREQUESTID" +
                    "  ) s5 ON s5.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT z9.CHANGEREQUESTID, " +
                    " CASE WHEN INSTR(z9.trialSuggest, '是')>0 THEN '是' WHEN INSTR(z9.trialSuggest, '是')=0 THEN '否' ELSE '' END trialSuggest FROM " +
                    " (" +
                    " SELECT z8.CHANGEREQUESTID, rtrim(XMLAGG(XMLPARSE(CONTENT(z8.productionTrial||',') WELLFORMED) ORDER BY z8.productionTrial).getclobval(),',') AS trialSuggest " +
                    " FROM ZAffectedObjectTable z8 GROUP BY z8.CHANGEREQUESTID" +
                    " ) z9" +
                    "  ) s6 ON s6.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT u1.FULLNAME APPROVEDBY, z10.APPROVALTIME, z10.CHANGEREQUESTID FROM ZApprovalOpinionTable z10 LEFT JOIN wtuser u1 ON u1.NAME = z10.APPROVEDBY WHERE z10.NODEINTERNALNAME = 'SEApprovedBy'" +
                    "  ) s10 ON s10.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT u1.FULLNAME APPROVEDBY, z11.APPROVALTIME, z11.CHANGEREQUESTID FROM ZApprovalOpinionTable z11 LEFT JOIN wtuser u1 ON u1.NAME = z11.APPROVEDBY WHERE z11.NODEINTERNALNAME = 'EBOMApprovedBy'" +
                    "  ) s11 ON s11.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT u1.FULLNAME APPROVEDBY, z12.APPROVALTIME, z12.CHANGEREQUESTID FROM ZApprovalOpinionTable z12 LEFT JOIN wtuser u1 ON u1.NAME = z12.APPROVEDBY WHERE z12.NODEINTERNALNAME = 'MBOMApprovedBy'" +
                    "  ) s12 ON s12.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT u1.FULLNAME APPROVEDBY, z13.APPROVALTIME, z13.CHANGEREQUESTID FROM ZApprovalOpinionTable z13 LEFT JOIN wtuser u1 ON u1.NAME = z13.APPROVEDBY WHERE z13.NODEINTERNALNAME = 'ECR09ApprovalOpinions'" +
                    "  ) s13 ON s13.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT u1.FULLNAME APPROVEDBY, z13.APPROVALTIME, z13.CHANGEREQUESTID FROM ZApprovalOpinionTable z13 LEFT JOIN wtuser u1 ON u1.NAME = z13.APPROVEDBY WHERE z13.NODEINTERNALNAME = 'ECR07ApprovalOpinions'" +
                    "  ) s14 ON s14.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT u1.FULLNAME APPROVEDBY, z13.APPROVALTIME, z13.CHANGEREQUESTID FROM ZApprovalOpinionTable z13 LEFT JOIN wtuser u1 ON u1.NAME = z13.APPROVEDBY WHERE z13.NODEINTERNALNAME = 'ECR08ApprovalOpinions'" +
                    "  ) s15 ON s15.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT u1.FULLNAME APPROVEDBY, z13.APPROVALTIME, z13.CHANGEREQUESTID FROM ZApprovalOpinionTable z13 LEFT JOIN wtuser u1 ON u1.NAME = z13.APPROVEDBY WHERE z13.NODEINTERNALNAME = 'ECR10ApprovalOpinions'" +
                    "  ) s16 ON s16.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT z14.CHANGEREQUESTID, rtrim(XMLAGG(XMLPARSE(CONTENT(z14.handlingOpinions||',') WELLFORMED) ORDER BY z14.handlingOpinions).getclobval(),',') AS handlingOpinions " +
                    "  FROM ZAffectedObjectTable z14 GROUP BY z14.CHANGEREQUESTID" +
                    "  ) s7 ON s7.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT max(z15.REVIEWTIME) ccbGroup_auditTime, z15.CHANGEREQUESTID FROM ZDomainReviewTable z15 WHERE z15.TABLENAME = 'CBBReview' " +
                    "  GROUP BY z15.CHANGEREQUESTID" +
                    "  ) s8 ON s8.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  LEFT JOIN (" +
                    "  SELECT z18.CHANGEREQUESTID, z18.BRANCHID, TO_CHAR((f.ENDTIME+INTERVAL '8' HOUR),'yyyy-MM-dd HH24:mi:ss') closeDocEndTime FROM ZClosedLoopInfoTable z18 LEFT JOIN  WFPROCESS f ON f.BUSINESSOBJREFERENCE = 'VR:wt.doc.WTDocument:'||z18.BRANCHID " +
                    "  ) s9 ON s9.CHANGEREQUESTID = 'VR:wt.change2.WTChangeRequest2:'||ec.BRANCHIDITERATIONINFO" +
                    "  WHERE w2.INTHID != 'wt.change2.WTChangeRequest2|com.fhsj.ctProductionEC'"+
                    "  ) y ) tempTab where 1=1";
            if(CtFormatUtil.hasContent(params.get("paramAll"))){
                sql+=" and upper(ATTVALUE) like upper('%"+(String)params.get("paramAll")+"%') ";
            }
            if(CtFormatUtil.hasContent(params.get("state"))){
                sql+=" and state = '"+(String)params.get("state")+"' ";
            }
            if(CtFormatUtil.hasContent(params.get("createDate_start"))){
                sql+=" and  createDate >= '"+(String)params.get("createDate_start")+"' ";
            }
            if(CtFormatUtil.hasContent(params.get("createDate_end"))){
                sql+=" and createDate <= '"+(String)params.get("createDate_end")+"' ";
            }
            if(CtFormatUtil.hasContent(params.get("pageSize"))){
                sql+=" and ROWNUM <= "+params.get("pageSize");
            }
            sql+="  ) totalAll";
            if(CtFormatUtil.hasContent(params.get("start"))){
                sql+=" where totalAll.id > "+params.get("start");
            }
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();
            while (result.next()) {
                Map<String,String> map = new HashMap<>();
                setMapValue("id", map, result);
                setMapValue("changeRequestId", map, result);
                setMapValue("head_ecrNumber", map, result);
                setMapValue("head_applicant", map, result);
                setMapValue("createDate", map, result);
                setMapValue("head_ecrName", map, result);
                setMapValue("state", map, result);
                setMapValue("head_changeType", map, result);
                setMapValue("head_changeReason", map, result);
                setMapValue("head_productModel", map, result);
                setMapValue("partF", map, result);
                setMapValue("ebomF", map, result);
                setMapValue("mbomF", map, result);
                setMapValue("head_affectedBOMs", map, result);
                setMapValue("head_affectedDocs", map, result);
                setMapValue("trialSuggest", map, result);
                setMapValue("rdRep_auditUser", map, result);
                setMapValue("rdRep_auditTime", map, result);
                setMapValue("ebomCharge_auditUser", map, result);
                setMapValue("ebomCharge_auditTime", map, result);
                setMapValue("mbomCharge_auditUser", map, result);
                setMapValue("mbomCharge_auditTime", map, result);
                setMapValue("consistencyRisk_auditUser", map, result);
                setMapValue("consistencyRisk_auditTime", map, result);
                setMapValue("handlingOpinions", map, result);
                setMapValue("ccbGroup_auditTime", map, result);
                setMapValue("pdt_auditUser", map, result);
                setMapValue("pdt_auditTime", map, result);
                setMapValue("ccb_auditTime", map, result);
                setMapValue("ipmt_auditTime", map, result);
                setMapValue("branchId", map, result);
                setMapValue("closeDocEndTime", map, result);
                setMapValue("changeSource", map, result);
                resultList.add(map);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return resultList;
    }

    public static void setMapValue(String key, Map<String,String> map, ResultSet result) throws Exception {
        String value = result.getString(key);
        if(CtFormatUtil.hasContent(value)){
            map.put(key,value);
        }
    }

}
