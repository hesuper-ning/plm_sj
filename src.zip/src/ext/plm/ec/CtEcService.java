package ext.plm.ec;

import ext.plm.ec.bo.*;
import wt.method.RemoteInterface;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RemoteInterface
public interface CtEcService  {
    //刷新表单表头信息
    HashMap<String,String> refreshHeadInfo(String changeRequestId) throws Exception;
    //检验输入的对象编码是否正确
    String checkChangeObj(HashMap<String,String> dataMap) throws Exception;
    //单个保存表单属性
    void saveAttribute(String changeRequestId,String activityKey,String attKey,String attValue) throws Exception;
    //查询变更表头信息
    HashMap<String,String> getHeadInfo(String changeRequestId) throws Exception;
    //获取物料变更列表
    List<CtPartChangeItemBo> getPartChangeItems(String changeRequestId) throws Exception;
    //获取变更列表
    List<CtChangeItemBo> getChangeItems(String changeRequestId,String type) throws Exception;
    //删除变更列表
    void deleteChangeItems(List<String> deleteIdList,String type) throws Exception;
    //删除物料变更列表
    void deletePartChangeItems(List<String> deleteIdList) throws Exception;
    //导入变更列表
    void importChangeItems(File file, String changeRequestId, String boms,String type) throws Exception;
    //获取变更列表 返回Map集合
    List<Map> getChangeItemsData(String changeRequestId, String type) throws Exception;
    //校验采购/物控分析列表对象编码
    String checkMaterialNumber(String materialNumber,String changeRequestId,String boms) throws Exception;
    //保存变更内容字段
    void saveChangeListField(String id,String key,String value,String changeRequestId,String boms,String type) throws Exception;
    //保存物料变更内容字段
    void savePartChangeItems(String id,String key,String value,String changeRequestId) throws Exception;
    //采购列表自动添加受影响对象
    void autoAddPcrMaterials(String changeRequestId) throws Exception;
    //物控列表自动添加受影响对象
    void autoAddPmcMaterials(String changeRequestId) throws Exception;
    //查询采购分析列表
    List<CtEcPcrMaterialItemBo> getPcrMaterialItems(String changeRequestId) throws Exception;
    //查询物控分析列表
    List<CtEcPmcMaterialItemBo> getPmcMaterialItems(String changeRequestId) throws Exception;
    //查询PDT团队评审信息
    List<CtEcPdtAuditInfoBo> getPdtAuditInfo(String changeRequestId) throws Exception;
    //采购分析列表  删除
    void deletePcrMatItems(List<String> deleteIdList) throws Exception;
    //物控分析列表  删除
    void deletePmcMatItems(List<String> deleteIdList) throws Exception;
    //保存编码和名称 采购分析列表
    void savePcrMaterialNumber(HashMap<String,String> pcrMaterialNumberInfo) throws Exception;
    //保存编码和名称 物控分析列表
    void savePmcMaterialNumber(HashMap<String,String> pmcMaterialNumberInfo) throws Exception;
    //实时保存列  采购分析列表
    void savePcrMaterialField(String id,String key,String value) throws Exception;
    //实时保存列  物控分析列表
    void savePmcMaterialField(String id,String key,String value) throws Exception;
    //EC报表
    List<Map<String,String>>  getEcReportItems(HashMap<String, Object> params) throws Exception;
    int getEcReportItemsCount(HashMap<String, Object> params) throws Exception;

    //=====================test  begin==========================//
    void testGenHeadInfo(String changeRequestId) throws Exception;

    void insertBomChangeItems(String changeRequestId,String type)throws Exception;

    void autoChangeBom(String changeRequestId,String partNumber,String type)throws Exception;

    //EC报表
    List<Map<String,String>> getNewEcReportItems(HashMap<String, Object> params) throws Exception;
    int getNewEcReportItemsCount(HashMap<String, Object> params) throws Exception;
}
