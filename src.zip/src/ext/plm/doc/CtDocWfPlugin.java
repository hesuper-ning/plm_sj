package ext.plm.doc;

import ext.plm.util.CtDocUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import wt.doc.WTDocument;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleServerHelper;
import wt.lifecycle.State;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.List;

public class CtDocWfPlugin {

	/**
	 * 关联物料
	 * @param pbo
	 * @return
	 * @throws WTException
	 */
	public static void relevancyPart(WTObject pbo) throws WTException {

		/**
		 * ext.plm.doc.CtDocWfPlugin.relevancyPart(primaryBusinessObject)
		 */

		WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
		SessionHelper.manager.setAdministrator();
		try {
			WTDocument document = (WTDocument) pbo;

			IBAUtil ibaUtil = new IBAUtil(document);
			String value = ibaUtil.getIBAValue("ct_materialsnumber");
			String[] partNumbers = value.split(",");
			for (String partNumber : partNumbers) {
				WTPart part = CtPartUtil.getPartByNumber(partNumber);
				CtPartUtil.createDescribeLink(part, document);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("关联物料失败:\r\n" + e.getLocalizedMessage());
		}finally {
			//设置回原用户
			SessionHelper.manager.setPrincipal(user.getName());
		}
	}

	/**
	 * 根据关联物料的情况，设置文档的发布状态
	 * @param pbo
	 * @throws Exception
	 */
	//ext.plm.doc.CtDocWfPlugin.setDocReleaseState(primaryBusinessObject);
	public static void setDocReleaseState(WTObject pbo) throws Exception {
		WTDocument document = (WTDocument) pbo;
		ArrayList<WTPart> partList = CtDocUtil.getDescribesWTParts(document);
		boolean hasD = false;
		String partNumber = "";
		for(WTPart part : partList){
			partNumber = part.getNumber();
			if(partNumber.endsWith("D01")){
				hasD = true;
				break;
			}
		}
		if(hasD){
			//有打样物料，设置文档状态为打样发布
			LifeCycleHelper.service.setLifeCycleState(document, State.toState("Proofrelease"));
		}else{
			//没有打样物料，设置文档状态为已发布
			LifeCycleHelper.service.setLifeCycleState(document, State.toState("RELEASED"));
		}
	}


	/**
	 * 提交时，校验文档是否有“打样发布”状态
	 * @param pbo
	 * @throws Exception
	 */
	//ext.plm.doc.CtDocWfPlugin.checkDocState(primaryBusinessObject);
	public static void checkDocState(WTObject pbo) throws Exception {
		List<WTDocument> docList = new ArrayList<>();
		if(pbo instanceof PromotionNotice){
			PromotionNotice promotionNotice = (PromotionNotice)pbo;
			QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
			while (qr.hasMoreElements()) {
				Object afterObj = qr.nextElement();
				if (afterObj instanceof WTDocument) {
					WTDocument document = (WTDocument) afterObj;
					docList.add(document);
				}
			}
		}
		if(pbo instanceof WTDocument){
			WTDocument document = (WTDocument) pbo;
			docList.add(document);
		}

		StringBuilder msg = new StringBuilder();
		CtDocQuery query = new CtDocQuery();
		for(WTDocument doc : docList){
			boolean needCheck = false;
			ArrayList<WTPart> partList = CtDocUtil.getDescribesWTParts(doc);
			String partNumber = "";
			for(WTPart part : partList){
				partNumber = part.getNumber();
				if(partNumber.endsWith("D01")){
					needCheck = true;
				}
			}
			//需要校验文档的状态
			if(needCheck){
				boolean hasState = query.docHasState(doc, "打样发布");
				if(!hasState){
					msg.append("文档" + doc.getNumber() + "关联了打样物料，但是该文档当前的生命周期没有“打样发布”状态！\r\n");
				}
			}
		}
		if(msg.toString().length() > 0){
			throw new Exception(msg.toString());
		}
	}

}
