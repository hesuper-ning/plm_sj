package ext.plm.doc.config;


import java.io.InputStreamReader;
import java.util.Properties;
/**
 * @Author: lcd
 * @Date: 2021/10/13 19:57
 * @Description:
 */
public class CtDocProperties {
    /**
     * 获取对应part的key值
     *
     * @param key
     * @return
     * @throws Exception
     */
    public static String getProperties(String key) throws Exception {
        Properties docKeyMap = new Properties();
        docKeyMap.load(new InputStreamReader(
                CtDocProperties.class.getResourceAsStream("CtDocProperties.properties"), "UTF-8"));
        String docTemplate = docKeyMap.getProperty(key);
        return docTemplate;
    }
}
