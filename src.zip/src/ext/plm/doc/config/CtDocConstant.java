package ext.plm.doc.config;

public class CtDocConstant {

    //IBA-文档类型
    public final static String IBA_WDLX = "ct_wdlx";

    //IBA-供应商
    public final static String IBA_SUPPLIER = "ct_supplier";

    //物料试用单
    public static String CT_TRIAL_ORDER = "com.fhsj.doc_02";


}
