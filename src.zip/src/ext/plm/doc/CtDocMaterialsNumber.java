package ext.plm.doc;

import ext.plm.oaFlow.materialRequisition.CtMaterialRequisitionQuery;
import ext.plm.util.*;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.method.MethodContext;
import wt.org.WTUser;
import wt.part.Quantity;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;
import wt.pom.WTConnection;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.IterationInfo;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.VersionInfo;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.WorkInProgressServiceEvent;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

/**
 * @Author: lzp
 * @Date: 2023/9/27
 * @Description:修改说明方文档物料编号属性
 */
public class CtDocMaterialsNumber {


    public static void modifyDocMaterialsNumber(WorkInProgressServiceEvent eventObject) throws Exception {
        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
        //设置成管理员 (普通用户可能没有更新标识权限)
        SessionHelper.manager.setAdministrator();

        try {
        WTPart oldPart = (WTPart) ((WorkInProgressServiceEvent) eventObject).getOriginalCopy();
        WTPart newPart = (WTPart) ((WorkInProgressServiceEvent) eventObject).getWorkingCopy();
        System.out.println("进入方法！！！！！！！！！！！！");


        IterationInfo iterationInfo = newPart.getIterationInfo();
        String iterationInfoValue = iterationInfo.getNote();


        System.out.println("判断是否是由文档编号改变进入此方法");
        if("1-文档关联物料，系统自动升版".equals(iterationInfoValue)||"2-文档从关联物料中移除，系统自动升版".equals(iterationInfoValue)){
            return;
        }


        List<WTDocument> docNewList = CtPartUtil.getDescribeDocs(newPart);
        List<WTDocument> docOldList = CtPartUtil.getDescribeDocs(oldPart);
            checkDocState(docNewList,docOldList);
        WTUser curUser = null;

        String viewName = newPart.getViewName();
        List<WTDocument> addListDoc = new ArrayList<>();
        List<WTDocument> deleteListDoc = new ArrayList<>();

        //获取部件新增加的说明方文档
        boolean delete = false;
        boolean add = false;
        if(docNewList!=null) {
            System.out.println("docNewList.size()!!!!!!"+docNewList.size());
            for (int j = 0; j < docNewList.size(); j++) {
                boolean b = true;
                //判断是否有新增的文档
                if(docOldList!=null) {
                    for (int k = 0; k < docOldList.size(); k++) {
                        if (docNewList.get(j).getNumber().equals(docOldList.get(k).getNumber())) {
                            b = false;
                        }
                    }
                }
                if (b) {
                    WTDocument doc = docNewList.get(j);
                    WTDocument docOld = docNewList.get(j);
                    IBAUtil ibaUtil = new IBAUtil(doc);
                    String materialsNumber = ibaUtil.getIBAValue("ct_materialsnumber");
                    System.out.println("@@位置01："+materialsNumber);
                    //if (materialsNumber != null && materialsNumber != "") {
                    if (CtFormatUtil.hasContent(materialsNumber)) {
                        String[] docNumber = materialsNumber.split(",");
                        boolean docbl = true;
                        for (String number : docNumber) {
                            if (number.equals(newPart.getNumber())) {
                                docbl = false;
                            }
                        }
                        if (docbl) {
                            materialsNumber += "," + newPart.getNumber();
                        }

                    } else {
                        materialsNumber = newPart.getNumber();
                    }
                    try {
                        //添加备注
                        curUser = (WTUser) SessionHelper.manager.getPrincipal();
                        SessionHelper.manager.setAdministrator();//设置管理员权限
                        doc = (WTDocument) CtACLUtil.checkout(doc, "1-文档关联物料，系统自动升版");
                        IBAUtil ibaUtildoc = new IBAUtil(doc);
                        AttributeDefDefaultView a = ibaUtildoc.getAttributeDefinition("ct_materialsnumber");
                        if (a != null) {
                            if(CtFormatUtil.hasContent(materialsNumber)) {
                                ibaUtildoc.setIBAValue("ct_materialsnumber", materialsNumber);
                                ibaUtildoc.updateIBAHolder(doc);
                            }
                        }
                        doc = (WTDocument) CtACLUtil.checkIn(doc, "1-文档关联物料，系统自动升版");
                        //设置修改者
                        CtWTObjectUtil.setModifier(doc,user);
                        addListDoc.add(doc);

                        //if(CtFormatUtil.hasContent(iterationInfoValue)) {
                            VersionControlHelper.setNote(newPart, iterationInfoValue + "（1-文档关联物料，系统自动升版）");
                            PersistenceServerHelper.manager.update(newPart);

                        CtPartUtil.deleteDescribeLink(newPart, docOld);
                        //}
                        add = true;
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new WTException(e.getLocalizedMessage());
                    }finally {
                        if (curUser != null) {
                            try {
                                SessionHelper.manager.setPrincipal(curUser.getName());//恢复权限
                                CtWTObjectUtil.setModifier(doc, user);
                            } catch (WTException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
        if(docOldList!=null) {
            //获取部件移除的说明方文档
            for (int j = 0; j < docOldList.size(); j++) {
                boolean b = true;
                if(docNewList!=null) {
                    for (int k = 0; k < docNewList.size(); k++) {
                        if (docOldList.get(j).getNumber().equals(docNewList.get(k).getNumber())) {
                            b = false;
                        }
                    }
                }
                if (b) {
                    WTDocument doc = docOldList.get(j);
                    IBAUtil ibaUtil = new IBAUtil(doc);
                    String materialsNumber = ibaUtil.getIBAValue("ct_materialsnumber");
                    if (CtFormatUtil.hasContent(materialsNumber)) {
                        String[] docNumber = materialsNumber.split(",");
                        boolean docbl = true;
                        String partNumbers = "";
                        for (String number : docNumber) {
                            if (!number.equals(oldPart.getNumber())) {
                                if (partNumbers == "") {
                                    partNumbers = number;
                                } else {
                                    partNumbers += "," + number;
                                }
                            }
                        }
                        materialsNumber = partNumbers;
                    }
                    try {
                        curUser = (WTUser) SessionHelper.manager.getPrincipal();
                        SessionHelper.manager.setAdministrator();//设置管理员权限
                        doc = (WTDocument) CtACLUtil.checkout(doc, "2-文档从关联物料中移除，系统自动升版");
                        IBAUtil ibaUtildoc = new IBAUtil(doc);
                        AttributeDefDefaultView a = ibaUtildoc.getAttributeDefinition("ct_materialsnumber");
                        if (a != null) {
                            if(CtFormatUtil.hasContent(materialsNumber)) {
                                ibaUtildoc.setIBAValue("ct_materialsnumber", materialsNumber);
                                ibaUtildoc.updateIBAHolder(doc);
                            }
                        }
                        doc = (WTDocument) CtACLUtil.checkIn(doc, "2-文档从关联物料中移除，系统自动升版");
                        //设置修改者
                        CtWTObjectUtil.setModifier(doc,user);
                        System.out.println("@@位置dddddddd："+materialsNumber);
                        deleteListDoc.add(doc);

                        VersionControlHelper.setNote(newPart, iterationInfoValue + "（2-文档从关联物料中移除，系统自动升版）");
                        PersistenceServerHelper.manager.update(newPart);

                        delete = true;
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new WTException(e.getLocalizedMessage());
                    }finally {
                        if (curUser != null) {
                            try {
                                SessionHelper.manager.setPrincipal(curUser.getName());//恢复权限
                                CtWTObjectUtil.setModifier(doc, user);
                            } catch (WTException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
        //由于通过WorkInProgressServiceEvent无法获取指定视图在最后添加与另外一个视图的关联
        if(delete&&add){

            WTPart dPartD = CtPartUtil.getPartByNumber(newPart.getNumber(), "Design");
            WTPart dPartM = CtPartUtil.getPartByNumber(newPart.getNumber(), "Manufacturing");
            if (viewName.equals("Manufacturing")) {
                if (CtFormatUtil.hasContent(dPartD)) {
                    dPartD = (WTPart) CtACLUtil.checkout(dPartD, "");
                    CtACLUtil.checkIn(dPartD, "");
                    //设置修改者
                    CtWTObjectUtil.setModifier(dPartD,user);
                }
            }
            if (viewName.equals("Design")) {
                if (CtFormatUtil.hasContent(dPartM)) {
                    dPartM = (WTPart) CtACLUtil.checkout(dPartM, "");
                    CtACLUtil.checkIn(dPartM, "");
                    //设置修改者
                    CtWTObjectUtil.setModifier(dPartM,user);
                }
            }
            for(int i = 0; i<addListDoc.size(); i++) {
                WTDocument doc = addListDoc.get(i);
                //必须与当前视图不同才进入
                if (viewName.equals("Manufacturing")&&CtFormatUtil.hasContent(dPartD)) {
                    CtPartUtil.createDescribeLink(dPartD, doc);
                }
                if (viewName.equals("Design")&&CtFormatUtil.hasContent(dPartM)) {
                    CtPartUtil.createDescribeLink(dPartM, doc);
                }
            }
            for(int i = 0; i<deleteListDoc.size(); i++) {
                WTDocument doc = deleteListDoc.get(i);
                if (viewName.equals("Manufacturing")&&CtFormatUtil.hasContent(dPartD)) {
                    CtPartUtil.deleteDescribeLink(dPartD, doc);
                }

                if (viewName.equals("Design")&&CtFormatUtil.hasContent(dPartM)) {
                    CtPartUtil.deleteDescribeLink(dPartM, doc);
                }
            }

            if (viewName.equals("Manufacturing")) {
                if (CtFormatUtil.hasContent(dPartD)) {
                    dPartD = (WTPart) PersistenceHelper.manager.refresh(dPartD);
                    VersionControlHelper.setNote(dPartD,"（3-关联对象变更-删除后增加）");
                    PersistenceServerHelper.manager.update(dPartD);
                }
            }
            if (viewName.equals("Design")) {
                if (CtFormatUtil.hasContent(dPartM)) {
                    dPartM = (WTPart) PersistenceHelper.manager.refresh(dPartM);
                    VersionControlHelper.setNote(dPartM,"（3-关联对象变更-删除后增加）");
                    PersistenceServerHelper.manager.update(dPartM);
                }
            }

            VersionControlHelper.setNote(newPart,iterationInfoValue+"（3-关联对象变更-删除后增加）");
            PersistenceServerHelper.manager.update(newPart);
        }else if(delete){

            WTPart dPartD = CtPartUtil.getPartByNumber(newPart.getNumber(), "Design");
            WTPart dPartM = CtPartUtil.getPartByNumber(newPart.getNumber(), "Manufacturing");
            if (viewName.equals("Manufacturing")) {
                if (CtFormatUtil.hasContent(dPartD)) {
                    dPartD = (WTPart) CtACLUtil.checkout(dPartD, "（2-文档从关联物料中移除，系统自动升版）");
                    CtACLUtil.checkIn(dPartD, "（2-文档从关联物料中移除，系统自动升版）");
                    //设置修改者
                    CtWTObjectUtil.setModifier(dPartD,user);
                }
            }
            if (viewName.equals("Design")) {
                if (CtFormatUtil.hasContent(dPartM)) {
                    dPartM = (WTPart) CtACLUtil.checkout(dPartM, "（2-文档从关联物料中移除，系统自动升版）");
                    CtACLUtil.checkIn(dPartM, "（2-文档从关联物料中移除，系统自动升版）");
                    //设置修改者
                    CtWTObjectUtil.setModifier(dPartM,user);
                }
            }

            for(int i = 0; i<deleteListDoc.size(); i++) {
                WTDocument doc = deleteListDoc.get(i);
                if (viewName.equals("Manufacturing")&&CtFormatUtil.hasContent(dPartD)) {
                    CtPartUtil.deleteDescribeLink(dPartD, doc);
                }
                if (viewName.equals("Design")&&CtFormatUtil.hasContent(dPartM)) {
                    CtPartUtil.deleteDescribeLink(dPartM, doc);
                }
            }
        }else if(add){

            WTPart dPartD = CtPartUtil.getPartByNumber(newPart.getNumber(), "Design");
            WTPart dPartM = CtPartUtil.getPartByNumber(newPart.getNumber(), "Manufacturing");
            if (viewName.equals("Manufacturing")) {
                if (CtFormatUtil.hasContent(dPartD)) {
                    dPartD = (WTPart) CtACLUtil.checkout(dPartD, "（1-文档关联物料，系统自动升版）");
                    CtACLUtil.checkIn(dPartD, "（1-文档关联物料，系统自动升版）");
                    //设置修改者
                    CtWTObjectUtil.setModifier(dPartD,user);
                }
            }
            if (viewName.equals("Design")) {
                if (CtFormatUtil.hasContent(dPartM)) {
                    dPartM = (WTPart) CtACLUtil.checkout(dPartM, "（1-文档关联物料，系统自动升版）");
                    CtACLUtil.checkIn(dPartM, "（1-文档关联物料，系统自动升版）");
                    //设置修改者
                    CtWTObjectUtil.setModifier(dPartM,user);
                }
            }
            for(int i = 0; i<addListDoc.size(); i++) {
                WTDocument doc = addListDoc.get(i);
                if (viewName.equals("Manufacturing")&&CtFormatUtil.hasContent(dPartD)) {
                    CtPartUtil.createDescribeLink(dPartD, doc);
                }

                if (viewName.equals("Design")&&CtFormatUtil.hasContent(dPartM)) {
                    CtPartUtil.createDescribeLink(dPartM, doc);
                }

            }
        }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("关联失败,原因如下:\r\n" + e.getLocalizedMessage());
        } finally {
            //设置回原用户
            SessionHelper.manager.setPrincipal(user.getName());
        }
    }

    public static void checkDocState(List<WTDocument> docNewList,List<WTDocument> docOldList) throws WTException {
        String errorInfo = "";

        if(!CtFormatUtil.hasContent(docNewList)){
            return;
        }
        for(WTDocument docNew : docNewList){
            String docNumberNew = docNew.getNumber();
            boolean foundMatch = false; // 标记变量
            if(CtFormatUtil.hasContent(docOldList)) {
                for (WTDocument docOld : docOldList) {
                    String docNumberOld = docOld.getNumber();
                    if (docNumberNew.equals(docNumberOld)) {
                        foundMatch = true; // 找到匹配
                        break; // 退出内层循环
                    }
                }
            }
            if (foundMatch) {
                continue; // 继续外层循环
            }
            if(WorkInProgressHelper.isWorkingCopy(docNew)){
                errorInfo += "文档编号：" + docNumberNew + "已经被检出，请检入后再操作！\n";
            }
        }
        if(CtFormatUtil.hasContent(errorInfo)){
            throw new WTException(errorInfo);
        }
    }

    public static void checkPartState(String[] partNumbers,String materialsNumber) throws Exception {
        String errorInfo = "";
        for (String partNumber : partNumbers) {
            if (CtFormatUtil.hasContent(materialsNumber) && materialsNumber.contains(partNumber)) {
                continue;
            }
            WTPart part = CtPartUtil.getPartByNumber(partNumber);
            if (!CtFormatUtil.hasContent(part)) {
                errorInfo += "没有" + partNumber + "这个部件编号的部件\n";
                //throw new WTException("没有" + partNumber + "这个部件编号的部件");
                continue;
            }
            WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
            WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
            if(WorkInProgressHelper.isWorkingCopy(dPartD)){
                errorInfo += "物料编号：" + partNumber + "“Design”视图已经被检出\n";
            }
            if(WorkInProgressHelper.isWorkingCopy(dPartM)){
                errorInfo += "物料编号：" + partNumber + "“Manufacturing”视图已经被检出\n";
            }
        }
        if(CtFormatUtil.hasContent(errorInfo)){
            throw new WTException(errorInfo);
        }
    }


}
