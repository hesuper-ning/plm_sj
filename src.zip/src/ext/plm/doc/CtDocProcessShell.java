package ext.plm.doc;

import cn.hutool.core.io.FileUtil;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtExcelReadUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.httpgw.GatewayAuthenticator;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.workflow.engine.WfEngineHelper;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfState;
import wt.workflow.work.WfAssignedActivity;

import java.io.File;
import java.io.InputStream;
import java.io.Serializable;

/**
 * 正在工作的状态需要删除第一个进程
 * 删除终止流程，重新启用旧流程
 */
public class CtDocProcessShell implements Serializable, RemoteAccess {

    public static void main(String[] args) throws Exception {
        if (!RemoteMethodServer.ServerFlag) {
            Class[] cls = new Class[]{String[].class};
            Object[] obj = new Object[]{args};

            try {
                RemoteMethodServer server = RemoteMethodServer.getDefault();
                GatewayAuthenticator authenticator = new GatewayAuthenticator();
                authenticator.setRemoteUser("wcadmin");
                server.setAuthenticator(authenticator);
                server.invoke("main", CtDocProcessShell.class.getName(), null, cls, obj);
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //windchill ext.plm.doc.CtDocProcessShell /home/ptc/Windchill_11.0/Windchill/codebase/exportTemp/docNumber.xlsx
        System.out.println(">>>>>restartActivity 准备执行:");
        System.out.println(">>>>>restartActivity 文件路径：" + args[0]);
        dealDoc(args[0]);
    }

    private static void dealDoc(String path) throws Exception {
        File filePath = new File(path);
        if(filePath == null){
            throw new Exception("路径或文件错误！找不到此路径或文件："+path);
        }
        InputStream is = FileUtil.getInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(is);
        Sheet sheet = workbook.getSheetAt(0);
        System.out.println(">>>>>restartActivity 读取excel第一页");
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String docNumber = CtExcelReadUtil.getCellFormatValue(row.getCell(0), row, 0);
            System.out.println(">>>>>restartActivity 当前执行文档编号:" + docNumber);
            run(docNumber);
        }
    }

    private static void run(String docNumber) throws Exception {
        WTDocument doc = (WTDocument) CtDocUtil.getDocumentByNumber(docNumber);
        if(null == doc){
            System.out.println("编号" + docNumber + "不存在！");
            return;
        }
        //获取工作流进程，API按创建时间倒序，第一个是最新的
        QueryResult qr = WfEngineHelper.service.getAssociatedProcesses(doc, null, null);
        WfProcess wfProcess = null;
        while(qr.hasMoreElements()) {
            wfProcess = (WfProcess) qr.nextElement();
            //正在工作的状态需要删除第一个进程
            if (qr.hasMoreElements() && "INWORK".equals(doc.getLifeCycleState().toString())) {
                PersistenceHelper.manager.delete(wfProcess);
            }
        }
        //重启终止进程
        if (wfProcess != null && WfState.CLOSED_TERMINATED.equals(wfProcess.getState())) {
            wfProcess.setState(WfState.OPEN_RUNNING);
            PersistenceHelper.manager.save(wfProcess);
            restartActivity(wfProcess);
        }
    }

    /**
     * 重启已终止的活动
     *
     * @param process
     * @throws Exception
     */
    private static void restartActivity(WfProcess process) throws Exception {
        QuerySpec qs = new QuerySpec(WfAssignedActivity.class);
        SearchCondition sc = new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key.id"
                , SearchCondition.EQUAL, process.getPersistInfo().getObjectIdentifier().getId());
        qs.appendWhere(sc);
        qs.appendAnd();
        sc = new SearchCondition(WfAssignedActivity.class, WfAssignedActivity.STATE, SearchCondition.EQUAL, "CLOSED_TERMINATED");
        qs.appendWhere(sc);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        while (qr.hasMoreElements()) {
            WfAssignedActivity wfActivity = (WfAssignedActivity) qr.nextElement();
            System.out.println(">>>>>restartActivity wfActivity name:" + wfActivity.getName());
            wfActivity.setState(WfState.OPEN_RUNNING);
            PersistenceHelper.manager.save(wfActivity);
            wfActivity.doStartTransition();
        }
    }


}
