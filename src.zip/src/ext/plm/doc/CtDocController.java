package ext.plm.doc;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtResApiResult;
import ext.plm.util.CtFormatUtil;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

@Controller
public class CtDocController {

    @RequestMapping(value = "/doc/downloadDoc", method = RequestMethod.POST)
    public void  downloadDoc(HttpServletRequest request,
                             HttpServletResponse response) throws Exception {

        String jsonData = request.getParameter("jsonData");
        JSONArray dataJson = JSONArray.parseArray(jsonData);
        List<Map> list = new ArrayList<>();
        if(CtFormatUtil.hasContent(jsonData)){
            list = dataJson.toJavaList(Map.class);
        }

        ServletOutputStream outputStream = null;
        ZipOutputStream zipOutputStream = null;
        try {
            String fileName = "document_contents";

            String userAgent = request.getHeader("User-Agent");
            outputStream = response.getOutputStream();
            response.setContentType("application/octet-stream");
            if (StringUtils.isNotEmpty(userAgent)) {
                if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                    //ie
                    fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                    //edge
                    fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
                } else {
                    // //firefox、chrome、safari、opera：
                    fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
                }
            }
            response.setCharacterEncoding("GBK");
            response.setContentType("application/octet-stream");
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            zipOutputStream = new ZipOutputStream(outputStream, Charset.forName("GBK"));

            CtDocLogic.downloadDoc(list,zipOutputStream);

        } catch (Exception e) {
            e.printStackTrace();
            try {
                response.setContentType("application/json;charset=UTF-8");
                CtResApiResult resApiResult = CtResApiResult.fail("压缩文档的主内容和附件失败，后台异常：" + e.getLocalizedMessage());
                IOUtils.write(JSONObject.toJSONString(resApiResult), outputStream, "UTF-8");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } finally {
            try {
                if (zipOutputStream != null) zipOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}
