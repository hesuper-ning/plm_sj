package ext.plm.doc;

import java.io.File;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.view.PropertyHolderHelper;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.LWCTypeDefinition;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bean.CtBeanService;
import ext.plm.doc.certificate.bo.CtCertificateListBo;
import ext.plm.doc.certificate.bo.CtProductApplicabilityBo;
import ext.plm.doc.certificate.bo.CtReportChecklistBo;
import ext.plm.doc.certificate.mapper.CtCertificateListMapper;
import ext.plm.doc.certificate.mapper.CtProductApplicabilityMapper;
import ext.plm.doc.certificate.mapper.CtReportChecklistMapper;
import ext.plm.ec.CtEcLogic;
import ext.plm.ipdProcessCompliance.IpdProcessComplianceQuery;
import ext.plm.project.milestone.CtMilestoneConstant;
import ext.plm.qms.CtQualityMetricServiceImpl;
import ext.plm.qms.bo.CtQualityMetricBo;
import ext.plm.requirement.CtRequireQuery;
import ext.plm.requirement.config.CtRequireConstant;
import ext.plm.supplier.CtSupplierDocumentLogic;
import ext.plm.util.CtACLUtil;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtFolderUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtProjectUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.content.ApplicationData;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.ClientTypedUtility;
import wt.util.WTException;
import wt.vc.IterationInfo;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.WorkInProgressServiceEvent;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.InputStream;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @Author: lcd
 * @Date: 2021/8/4 17:28
 * @Description:
 */
public class CtDocLogic {
    private static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);

    /**
     * 移动文件夹CtEPMDocUtil.java
     *
     * @param doc
     * @throws Exception
     */
    public static void moveFolder(WTDocument doc) throws Exception {
        boolean orgAccessEnfored = SessionServerHelper.manager.setAccessEnforced(false);
        try {
//            String versionInfo = CtVersionUtil.getVersionInfo(doc);
//            String typeName = CtWTObjectUtil.getTypeIdentifier(doc);
//            if(!versionInfo.equals("A.1")
//                    && !typeName.contains("com.fibocom.CS-010_prodcutDoc")) { // 产品文档不做版本校验
//                return;
//            }

//            typeName = typeName.substring(typeName.lastIndexOf("|")+1);
//            System.out.println("typeName>>>>>>>>>>>>>>>>>>"+typeName);
            String containerName = doc.getContainerName();
            if (!"站点".equals(containerName)) {
                Folder folder = getCreateFolder(doc, doc.getContainer());
                if (CtFormatUtil.hasContent(folder) && !doc.getFolderPath().equals(folder.getFolderPath())
                        && !WorkInProgressHelper.isCheckedOut(doc)) {
                    FolderHelper.service.changeFolder(doc, folder);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(orgAccessEnfored);
        }
    }

    /**
     * 移动文件夹
     *
     * @param doc
     * @throws Exception
     */
    public static void updateIba(WTDocument doc) throws Exception {
        boolean orgAccessEnfored = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            CtDocQuery ctDocQuery = new CtDocQuery();
            IBAUtil ibaUtil = new IBAUtil(doc);
            String innerName = ClientTypedUtility.getExternalTypeIdentifier(doc);
            String[] split = innerName.split("\\|");
            if (split[split.length - 1].equals("com.fhsj.Doc_xmfxqd")) {
                String projectNumber = "";
                WTContainer container = doc.getContainer();
                if (container instanceof Project2) {
                    Project2 pro = (Project2) container;
                    projectNumber = pro.getProjectNumber();
                    if (!CtFormatUtil.hasContent(projectNumber)) {
                        throw new Exception("所在项目库‘编号’为空--请添加或联系管理员");
                    }
                    ibaUtil.setIBAValue("ct_ItemNumber", projectNumber);
                    ibaUtil.updateIBAHolder(doc);
                } else if (container instanceof PDMLinkProduct) {
                    PDMLinkProduct pro = (PDMLinkProduct) container;
                    projectNumber = pro.getDescription();
                    if (!CtFormatUtil.hasContent(projectNumber)) {
                        throw new Exception("所在产品库‘项目编码(说明)’为空--请添加或联系管理员");
                    }
                    Project2 projectByNumber = CtProjectUtil.getProjectByNumber(projectNumber);
                    if (!CtFormatUtil.hasContent(projectByNumber)) {
                        throw new Exception("该项目编号所属项目库未创建,请先创建对应项目库！！！");
                    }
                    ibaUtil.setIBAValue("ct_ItemNumber", projectNumber);
                    ibaUtil.updateIBAHolder(doc);
                } else {
                    projectNumber = ibaUtil.getIBAValue("ct_ItemNumber");
                    if (!CtFormatUtil.hasContent(projectNumber)) {
                        throw new Exception("项目编号未填写\n");
                    }
                    Project2 projectByNumber = CtProjectUtil.getProjectByNumber(projectNumber);
                    if (!CtFormatUtil.hasContent(projectByNumber)) {
                        throw new Exception("该项目编号所属项目库未创建,请先创建对应项目库！！！");
                    }
                }
                String ibaProjectNumDoc = ctDocQuery.getIbaProjectNumDoc(projectNumber, doc.getNumber());
//                String replace = ibaProjectNumDoc.replace(doc.getNumber(), "");
                if (CtFormatUtil.hasContent(ibaProjectNumDoc)) {
                    throw new Exception("该项目编号已创建对应得风险管理，文档编号如下：\n" + ibaProjectNumDoc);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(orgAccessEnfored);
        }
    }

    /**
     * 获取文档类型默认的文件路径
     *
     * @param doc
     * @param wtcontainer
     * @return
     * @throws WTException
     */
    public static Folder getCreateFolder(WTDocument doc, WTContainer wtcontainer) throws Exception {
        Folder folder = null;
        boolean orgAccessEnfored = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            LWCTypeDefinition typeDefinition = CtWTObjectUtil.getTypeDefinition(doc);

            // 获取类型里面的说明信息
            TypeDefinitionReadView typeDefinitionReadView = TypeDefinitionServiceHelper.service.getTypeDefView(
                    AttributeTemplateFlavor.getAttributeTemplateFlavor(typeDefinition),
                    Long.valueOf(typeDefinition.getPersistInfo().getObjectIdentifier().getId()));
            // 描述为存储路径
            String description = PropertyHolderHelper.getPropertyValue(typeDefinitionReadView, Locale.CHINA, "description");
            if (CtFormatUtil.hasContent(description) && description.contains("/")) {
                String substring = description.substring(description.indexOf("|") + 1);
                String folderPath = "";
                //找不到路径返回空
                if (!CtFormatUtil.hasContent(substring)) {
                    return null;
                }
                folderPath = "/Default/" + substring;

                System.out.println("result>>>>>>>>>>>>" + folderPath);
                folder = CtFolderUtil.getFolder(folderPath, wtcontainer);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(orgAccessEnfored);
        }

        return folder;
    }

    //当文档IBA属性部件编号发生改变的时候进行相关关联或者断联操作
    public static void modifyRemarks(WorkInProgressServiceEvent eventObject) throws Exception {
        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
        //设置成管理员 (普通用户可能没有更新标识权限)
        SessionHelper.manager.setAdministrator();

        try {
        WTDocument oldDoc = (WTDocument) ((WorkInProgressServiceEvent) eventObject).getOriginalCopy();
        WTDocument doc = (WTDocument) ((WorkInProgressServiceEvent) eventObject).getWorkingCopy();
        IterationInfo iterationInfo = doc.getIterationInfo();
        String iterationInfoValue = iterationInfo.getNote();
        System.out.println("当文档IBA属性部件编号发生改变的时候进行相关关联或者断联操作1111");
        if ("1-文档关联物料，系统自动升版".equals(iterationInfoValue) || "2-文档从关联物料中移除，系统自动升版".equals(iterationInfoValue)) {
            return;
        }

        //if (CtFormatUtil.hasContent(oldDoc)) {
        //    ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(oldDoc);
        //    //先删除旧关联
        //    for (WTPart describesWTPart : describesWTParts) {
        //        CtPartUtil.deleteDescribeLink(describesWTPart, oldDoc);
        //    }
        //}

        System.out.println("当文档IBA属性部件编号发生改变的时候进行相关关联或者断联操作2222222");
        boolean delete = false;
        boolean add = false;
        IBAUtil ibaUtilNew = new IBAUtil(doc);
        String materialsNumberNew = ibaUtilNew.getIBAValue("ct_materialsnumber");
        List<String> listAdd = new ArrayList<>();
        List<String> listDelete = new ArrayList<>();
        if (CtFormatUtil.hasContent(oldDoc)) {
            IBAUtil ibaUtilOld = new IBAUtil(oldDoc);
            String materialsNumberOld = ibaUtilOld.getIBAValue("ct_materialsnumber");
            String[] partNumbersNew = null;
            if (CtFormatUtil.hasContent(materialsNumberNew)) {
                partNumbersNew = materialsNumberNew.split(",");
            }
            String[] partNumbersOld = null;
            if (CtFormatUtil.hasContent(materialsNumberOld)) {
                partNumbersOld = materialsNumberOld.split(",");
            }

            //if (!CtFormatUtil.hasContent(materialsNumberNew)) {
            //    ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(doc);
            //    //先删除旧关联
            //    for (WTPart describesWTPart : describesWTParts) {
            //        CtPartUtil.deleteDescribeLink(describesWTPart, doc);
            //    }
            //}

            String errorInfo = "";

            if (CtFormatUtil.hasContent(partNumbersNew)) {
                CtDocMaterialsNumber.checkPartState(partNumbersNew,materialsNumberOld);
            }

            if (CtFormatUtil.hasContent(partNumbersNew)) {
                for (String partNumber : partNumbersNew) {
                    if (CtFormatUtil.hasContent(materialsNumberOld) && materialsNumberOld.contains(partNumber)) {
                        continue;
                    }
                    WTPart part = CtPartUtil.getPartByNumber(partNumber);
                    if (!CtFormatUtil.hasContent(part)) {
                        throw new WTException("没有" + partNumber + "这个部件编号的部件");
                    }
                    String viewName = "";

                    WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                    if (CtFormatUtil.hasContent(dPartD)) {
                        dPartD = (WTPart) CtACLUtil.checkout(dPartD, "1-文档关联物料，系统自动升版");
                        CtACLUtil.checkIn(dPartD, "1-文档关联物料，系统自动升版");
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartD,user);
                        CtPartUtil.createDescribeLink(dPartD, doc);
                    }
                    WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                    if (CtFormatUtil.hasContent(dPartM)) {
                        dPartM = (WTPart) CtACLUtil.checkout(dPartM, "1-文档关联物料，系统自动升版");
                        CtACLUtil.checkIn(dPartM, "1-文档关联物料，系统自动升版");
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartM,user);
                        CtPartUtil.createDescribeLink(dPartM, doc);
                    }


                    //if (part.getViewName().equalsIgnoreCase("Manufacturing")) {
                    //    WTPart dPart = CtPartUtil.getPartByNumber(partNumber, "Design");
                    //    if (CtFormatUtil.hasContent(dPart)) {
                    //        dPart = (WTPart) CtACLUtil.checkout(dPart, "1-文档关联物料，系统自动升版");
                    //        CtACLUtil.checkIn(dPart, "1-文档关联物料，系统自动升版");
                    //        CtPartUtil.createDescribeLink(dPart, doc);
                    //    }
                    //}
                    //part = (WTPart) CtACLUtil.checkout(part, "1-文档关联物料，系统自动升版");
                    //CtACLUtil.checkIn(part, "1-文档关联物料，系统自动升版");
                    //CtPartUtil.createDescribeLink(part, doc);
                    //if(CtFormatUtil.hasContent(iterationInfoValue)) {
                    VersionControlHelper.setNote(doc, iterationInfoValue + "（1-文档关联物料，系统自动升版）");
                    PersistenceServerHelper.manager.update(doc);
                    //}
                    add = true;
                }
            }

            if (CtFormatUtil.hasContent(partNumbersOld)) {
                CtDocMaterialsNumber.checkPartState(partNumbersOld,materialsNumberNew);
            }

            if (CtFormatUtil.hasContent(partNumbersOld)) {
                for (String partNumber : partNumbersOld) {
                    if (CtFormatUtil.hasContent(materialsNumberNew) && materialsNumberNew.contains(partNumber)) {
                        continue;
                    }
                    WTPart part = CtPartUtil.getPartByNumber(partNumber);
                    if (!CtFormatUtil.hasContent(part)) {
                        throw new WTException("没有" + partNumber + "这个部件编号的部件");
                    }

                    WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                    if (CtFormatUtil.hasContent(dPartD)) {
                        //系统自动会在文档升版本后关联文档生版本前关联的部件的版本，因此要断开最新文档与升部件版本前的关联
                        CtPartUtil.deleteDescribeLink(dPartD, doc);
                        dPartD = (WTPart) CtACLUtil.checkout(dPartD, "2-物料从关联文档中移除，系统自动升版");
                        CtACLUtil.checkIn(dPartD, "2-物料从关联文档中移除，系统自动升版");
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartD,user);
                        CtPartUtil.deleteDescribeLink(dPartD, doc);
                    }
                    WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                    if (CtFormatUtil.hasContent(dPartM)) {
                        //系统自动会在文档升版本后关联文档生版本前关联的部件的版本，因此要断开最新文档与升部件版本前的关联
                        CtPartUtil.deleteDescribeLink(dPartM, doc);
                        dPartM = (WTPart) CtACLUtil.checkout(dPartM, "2-物料从关联文档中移除，系统自动升版");
                        CtACLUtil.checkIn(dPartM, "2-物料从关联文档中移除，系统自动升版");
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartM,user);
                        CtPartUtil.deleteDescribeLink(dPartM, doc);
                    }

                    //
                    //String viewName = "";
                    //if (part.getViewName().equalsIgnoreCase("Manufacturing")) {
                    //    WTPart dPart = CtPartUtil.getPartByNumber(partNumber, "Design");
                    //    if (CtFormatUtil.hasContent(dPart)) {
                    //        dPart = (WTPart) CtACLUtil.checkout(dPart, "2-物料从关联文档中移除，系统自动升版");
                    //        CtACLUtil.checkIn(dPart, "2-物料从关联文档中移除，系统自动升版");
                    //        CtPartUtil.deleteDescribeLink(dPart, doc);
                    //    }
                    //}
                    //part = (WTPart) CtACLUtil.checkout(part, "2-物料从关联文档中移除，系统自动升版");
                    //CtACLUtil.checkIn(part, "2-物料从关联文档中移除，系统自动升版");
                    //CtPartUtil.deleteDescribeLink(part, doc);
                    //if(CtFormatUtil.hasContent(iterationInfoValue)) {
                    VersionControlHelper.setNote(doc, iterationInfoValue + "（2-物料从关联文档中移除，系统自动升版）");
                    PersistenceServerHelper.manager.update(doc);
                    //}
                    delete = true;
                }
            }
        } else {
            //增加新物料关联关系
            if (CtFormatUtil.hasContent(materialsNumberNew)) {
                String[] partNumbers = materialsNumberNew.split(",");

                CtDocMaterialsNumber.checkPartState(partNumbers,"materialsNumberNew");

                for (String partNumber : partNumbers) {
                    WTPart part = CtPartUtil.getPartByNumber(partNumber);
                    if (!CtFormatUtil.hasContent(part)) {
                        throw new WTException("没有" + partNumber + "这个部件编号的部件");
                    }


                    WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                    if (CtFormatUtil.hasContent(dPartD)) {
                        dPartD = (WTPart) CtACLUtil.checkout(dPartD, "1-文档关联物料，系统自动升版");
                        CtACLUtil.checkIn(dPartD, "1-文档关联物料，系统自动升版");
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartD,user);
                        CtPartUtil.createDescribeLink(dPartD, doc);
                    }
                    WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                    if (CtFormatUtil.hasContent(dPartM)) {
                        dPartM = (WTPart) CtACLUtil.checkout(dPartM, "1-文档关联物料，系统自动升版");
                        CtACLUtil.checkIn(dPartM, "1-文档关联物料，系统自动升版");
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartD,user);
                        CtPartUtil.createDescribeLink(dPartM, doc);
                    }

                    //String viewName = "";
                    //if (part.getViewName().equalsIgnoreCase("Manufacturing")) {
                    //    WTPart dPart = CtPartUtil.getPartByNumber(partNumber, "Design");
                    //    if (CtFormatUtil.hasContent(dPart)) {
                    //        dPart = (WTPart) CtACLUtil.checkout(dPart, "1-文档关联物料，系统自动升版");
                    //        CtACLUtil.checkIn(dPart, "1-文档关联物料，系统自动升版");
                    //        CtPartUtil.createDescribeLink(dPart, doc);
                    //    }
                    //}
                    //part = (WTPart) CtACLUtil.checkout(part, "1-文档关联物料，系统自动升版");
                    //CtACLUtil.checkIn(part, "1-文档关联物料，系统自动升版");
                    //CtPartUtil.createDescribeLink(part, doc);
                    //if(CtFormatUtil.hasContent(iterationInfoValue)) {
                    VersionControlHelper.setNote(doc, iterationInfoValue + "（1-文档关联物料，系统自动升版）");
                    PersistenceServerHelper.manager.update(doc);
                    //}
                }
            }
        }
        if (delete && add) {
            VersionControlHelper.setNote(doc, iterationInfoValue + "（3-关联对象变更-删除后增加）");
            PersistenceServerHelper.manager.update(doc);
        }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("关联失败,原因如下:\r\n" + e.getLocalizedMessage());
        } finally {
            //设置回原用户
            SessionHelper.manager.setPrincipal(user.getName());
        }


    }

    public static String bindDocAndPartByDescribeLink(WTDocument doc, WTDocument oldDoc) throws Exception {
        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
        return bindDocAndPartByDescribeLink(doc, oldDoc, user);
    }

    public static String bindDocAndPartByDescribeLink(WTDocument doc, WTDocument oldDoc, WTUser user) throws Exception {
        IBAUtil ibaUtilNew = new IBAUtil(doc);
        String materialsNumberNew = ibaUtilNew.getIBAValue("ct_materialsnumber");
        List<String> listAdd = new ArrayList<>();
        List<String> listDelete = new ArrayList<>();

        //if(CtFormatUtil.hasContent(oldDoc)) {
        //    ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(oldDoc);
        //
        //    //IterationInfo iterationInfo = doc.getIterationInfo();
        //    //String iterationInfoValue = iterationInfo.getNote();
        //    //先删除旧关联
        //    for (WTPart describesWTPart : describesWTParts) {
        //        CtPartUtil.deleteDescribeLink(describesWTPart, doc);
        //    }
        //}

        String errorInfo = "";

        if (CtFormatUtil.hasContent(oldDoc)) {
            IBAUtil ibaUtilOld = new IBAUtil(oldDoc);
            String materialsNumberOld = ibaUtilOld.getIBAValue("ct_materialsnumber");
            String[] partNumbersNew = null;
            if (CtFormatUtil.hasContent(materialsNumberNew)) {
                partNumbersNew = materialsNumberNew.split(",");
            }
            String[] partNumbersOld = null;
            if (CtFormatUtil.hasContent(materialsNumberOld)) {
                partNumbersOld = materialsNumberOld.split(",");
            }


            if (CtFormatUtil.hasContent(partNumbersNew)) {

                CtDocMaterialsNumber.checkPartState(partNumbersNew,materialsNumberOld);

                for (String partNumber : partNumbersNew) {
                    if (CtFormatUtil.hasContent(materialsNumberOld) && materialsNumberOld.contains(partNumber)) {
                        continue;
                    }
                    WTPart part = CtPartUtil.getPartByNumber(partNumber);
                    if (!CtFormatUtil.hasContent(part)) {
                        throw new WTException("没有" + partNumber + "这个部件编号的部件");
                    }
                    String viewName = "";

                    WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                    if (CtFormatUtil.hasContent(dPartD)) {
                        dPartD = (WTPart) CtACLUtil.checkout(dPartD, "1-文档关联物料，系统自动升版");
                        CtACLUtil.checkIn(dPartD, "1-文档关联物料，系统自动升版");
                        CtPartUtil.createDescribeLink(dPartD, doc);
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartD,user);
                    }
                    WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                    if (CtFormatUtil.hasContent(dPartM)) {
                        dPartM = (WTPart) CtACLUtil.checkout(dPartM, "1-文档关联物料，系统自动升版");
                        CtACLUtil.checkIn(dPartM, "1-文档关联物料，系统自动升版");
                        CtPartUtil.createDescribeLink(dPartM, doc);
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartM,user);
                    }


                    //if (part.getViewName().equalsIgnoreCase("Manufacturing")) {
                    //    WTPart dPart = CtPartUtil.getPartByNumber(partNumber, "Design");
                    //    if (CtFormatUtil.hasContent(dPart)) {
                    //        dPart = (WTPart) CtACLUtil.checkout(dPart, "1-文档关联物料，系统自动升版");
                    //        CtACLUtil.checkIn(dPart, "1-文档关联物料，系统自动升版");
                    //        CtPartUtil.createDescribeLink(dPart, doc);
                    //    }
                    //}
                    //part = (WTPart) CtACLUtil.checkout(part, "1-文档关联物料，系统自动升版");
                    //CtACLUtil.checkIn(part, "1-文档关联物料，系统自动升版");
                    //CtPartUtil.createDescribeLink(part, doc);
                }
            }

            if (CtFormatUtil.hasContent(partNumbersOld)) {

                CtDocMaterialsNumber.checkPartState(partNumbersOld,materialsNumberNew);

                for (String partNumber : partNumbersOld) {
                    if (CtFormatUtil.hasContent(materialsNumberNew) && materialsNumberNew.contains(partNumber)) {
                        continue;
                    }
                    WTPart part = CtPartUtil.getPartByNumber(partNumber);
                    if (!CtFormatUtil.hasContent(part)) {
                        throw new WTException("没有" + partNumber + "这个部件编号的部件");
                    }

                    WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                    if (CtFormatUtil.hasContent(dPartD)) {
                        dPartD = (WTPart) CtACLUtil.checkout(dPartD, "2-物料从关联文档中移除，系统自动升版");
                        CtACLUtil.checkIn(dPartD, "2-物料从关联文档中移除，系统自动升版");
                        CtPartUtil.deleteDescribeLink(dPartD, doc);
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartD,user);
                    }
                    WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                    if (CtFormatUtil.hasContent(dPartM)) {
                        dPartM = (WTPart) CtACLUtil.checkout(dPartM, "2-物料从关联文档中移除，系统自动升版");
                        CtACLUtil.checkIn(dPartM, "2-物料从关联文档中移除，系统自动升版");
                        CtPartUtil.deleteDescribeLink(dPartM, doc);
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartM,user);
                    }

                    //String viewName = "";
                    //if (part.getViewName().equalsIgnoreCase("Manufacturing")) {
                    //    WTPart dPart = CtPartUtil.getPartByNumber(partNumber, "Design");
                    //    if (CtFormatUtil.hasContent(dPart)) {
                    //        dPart = (WTPart) CtACLUtil.checkout(dPart, "2-物料从关联文档中移除，系统自动升版");
                    //        CtACLUtil.checkIn(dPart, "2-物料从关联文档中移除，系统自动升版");
                    //        CtPartUtil.deleteDescribeLink(dPart, doc);
                    //    }
                    //}
                    //part = (WTPart) CtACLUtil.checkout(part, "2-物料从关联文档中移除，系统自动升版");
                    //CtACLUtil.checkIn(part, "2-物料从关联文档中移除，系统自动升版");
                    //CtPartUtil.deleteDescribeLink(part, doc);
                }
            }
        } else {
            //增加新物料关联关系
            if (CtFormatUtil.hasContent(materialsNumberNew)) {
                String[] partNumbers = materialsNumberNew.split(",");

                CtDocMaterialsNumber.checkPartState(partNumbers,"materialsNumberNew");

                for (String partNumber : partNumbers) {
                    WTPart part = CtPartUtil.getPartByNumber(partNumber);
                    if (!CtFormatUtil.hasContent(part)) {
                        throw new WTException("没有" + partNumber + "这个部件编号的部件");
                    }

                    WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                    if (CtFormatUtil.hasContent(dPartD)) {
                        dPartD = (WTPart) CtACLUtil.checkout(dPartD, "1-文档关联物料，系统自动升版");
                        CtACLUtil.checkIn(dPartD, "1-文档关联物料，系统自动升版");
                        CtPartUtil.createDescribeLink(dPartD, doc);
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartD,user);
                    }
                    WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                    if (CtFormatUtil.hasContent(dPartM)) {
                        dPartM = (WTPart) CtACLUtil.checkout(dPartM, "1-文档关联物料，系统自动升版");
                        CtACLUtil.checkIn(dPartM, "1-文档关联物料，系统自动升版");
                        CtPartUtil.createDescribeLink(dPartM, doc);
                        //设置修改者
                        CtWTObjectUtil.setModifier(dPartM,user);
                    }

                    //String viewName = "";
                    //if (part.getViewName().equalsIgnoreCase("Manufacturing")) {
                    //    WTPart dPart = CtPartUtil.getPartByNumber(partNumber, "Design");
                    //    if (CtFormatUtil.hasContent(dPart)) {
                    //        dPart = (WTPart) CtACLUtil.checkout(dPart, "1-文档关联物料，系统自动升版");
                    //        CtACLUtil.checkIn(dPart, "1-文档关联物料，系统自动升版");
                    //        CtPartUtil.createDescribeLink(dPart, doc);
                    //    }
                    //}
                    //part = (WTPart) CtACLUtil.checkout(part, "1-文档关联物料，系统自动升版");
                    //CtACLUtil.checkIn(part, "1-文档关联物料，系统自动升版");
                    //CtPartUtil.createDescribeLink(part, doc);
                }
            }
        }


        //历史方法
        String errorMsg = "";
        //IBAUtil ibaUtil = new IBAUtil(doc);
        //IBAUtil ibaUtil2 = new IBAUtil(oldDoc);
        //String oldIba = "";
        //String[] oldIbapartNumbers = null;
        //List<String> list = new ArrayList<>();
        //List<String> list2 = new ArrayList<>();
        //ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(doc);
        //
        //IterationInfo iterationInfo = doc.getIterationInfo();
        //String iterationInfoValue = iterationInfo.getNote();
        ////先删除旧关联
        //for (WTPart describesWTPart : describesWTParts) {
        //    CtPartUtil.deleteDescribeLink(describesWTPart, doc);
        //}
        //List<String> deleteList = new ArrayList<>();
        //if (CtFormatUtil.hasContent(oldDoc)) {
        //    String ibaValue2 = ibaUtil2.getIBAValue("ct_materialsnumber");
        //    String ibaValue = ibaUtil.getIBAValue("ct_materialsnumber");
        //    String[] partNumbers2 = null;
        //    if (CtFormatUtil.hasContent(ibaValue2)) {
        //        if (ibaValue2.contains("，")) {
        //            throw new WTException("请用英文逗号来分隔部件编号");
        //        }
        //        partNumbers2 = ibaValue2.split(",");
        //        if (CtFormatUtil.hasContent(partNumbers2)) {
        //            for (String partNumber : partNumbers2) {
        //                if(CtFormatUtil.hasContent(ibaValue)) {
        //                    if(!ibaValue.contains(partNumber)) {
        //                        deleteList.add(partNumber);
        //                    }
        //                }else {
        //                    deleteList.add(partNumber);
        //                }
        //            }
        //        }
        //    }
        //
        //
        //    String[] partNumbers = null;
        //    if (CtFormatUtil.hasContent(ibaValue2)) {
        //        if (ibaValue2.contains("，")) {
        //            throw new WTException("请用英文逗号来分隔部件编号");
        //        }
        //        partNumbers = ibaValue2.split(",");
        //    }
        //
        //    if (CtFormatUtil.hasContent(partNumbers)) {
        //        //删除新物料关联关系
        //        for (String partNumber : partNumbers) {
        //            if(!deleteList.contains(partNumber)){
        //                continue;
        //            }
        //            WTPart part = CtPartUtil.getPartByNumber(partNumber);
        //            if (!CtFormatUtil.hasContent(part)) {
        //                throw new WTException("没有"+partNumber+"这个部件编号的部件");
        //            }
        //            String viewName = "";
        //            if (part.getViewName().equalsIgnoreCase("Manufacturing")) {
        //                WTPart dPart = CtPartUtil.getPartByNumber(partNumber, "Design");
        //                if (CtFormatUtil.hasContent(dPart)) {
        //                    dPart = (WTPart) CtACLUtil.checkout(dPart, "2-物料从关联文档中移除，系统自动升版");
        //                    CtACLUtil.checkIn(dPart, "2-物料从关联文档中移除，系统自动升版");
        //
        //                }
        //            }
        //            part = (WTPart) CtACLUtil.checkout(part, "2-物料从关联文档中移除，系统自动升版");
        //            CtACLUtil.checkIn(part, "2-物料从关联文档中移除，系统自动升版");
        //        }
        //    }
        //}
        //历史方法


        return errorMsg;
    }
    /**
     * 更新关联关系
     * @param doc
     * @throws Exception
     */
    public static void updateDocRefLink(WTDocument doc, WTDocument preDoc) throws Exception{
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        try{
            ArrayList<WTPart> describesWTParts = CtDocUtil.getDescribesWTParts(preDoc);
            for (WTPart describesWTPart : describesWTParts) {
                if(!checkPartTypes(describesWTPart)){
                    continue;
                }
                describesWTPart = (WTPart) CtACLUtil.checkout(describesWTPart, "后台重新关联检出");
                describesWTPart = (WTPart) WorkInProgressHelper.service.checkin(describesWTPart,
                        "后台重新关联检入");
                CtPartUtil.deleteDescribeLink(describesWTPart, preDoc);
                CtPartUtil.createDescribeLink(describesWTPart, doc);
            }
        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }

    }

    //文档修订时校验打样物料是否是最新版本，如果不是则不升小版本，不建立与修订后文档的关联
    public static boolean checkPartTypes(WTPart part) throws Exception {
        String partNumber = part.getNumber();
        //if(partNumber.contains("D01")){
            WTPart upToDatePart = CtPartUtil.getPartByNumber(partNumber,part.getViewName());
            long ida2a2 = part.getPersistInfo().getObjectIdentifier().getId();
            long upToDateIda2a2 = upToDatePart.getPersistInfo().getObjectIdentifier().getId();
            if(ida2a2 == upToDateIda2a2){
                return true;
            }else {
                return false;
            }
        //}
        //return true;
    }

    /**
     * 根据不同类型文档做特殊处理处理
     *
     * @param arg0
     * @param doc
     * @throws Exception
     */
    public static void dealWithByType(NmCommandBean arg0, WTDocument doc, String projectId) throws Exception {
        String innerName = ClientTypedUtility.getExternalTypeIdentifier(doc);

        String[] split = innerName.split("\\|");
        IBAUtil ibaUtil = new IBAUtil(doc);
        //标志位,一个项目下是否只能有一种这类的文档类型
        String projectOnlyOne = ibaUtil.getIBAValue("ct_sfjyxmbhzwyxjy");
        System.out.println("===是否基于项目编号做唯一性校验==" + projectOnlyOne);

        /*if ("是".equals(projectOnlyOne)) {
            String number = doc.getNumber();
            WTContainer container = doc.getContainer();
            List<String> docNums = new ArrayList<>();
            if (container instanceof PDMLinkProduct) {
                docNums = CtCommonUtil.getDocUnderContainer(CtWTObjectUtil.getId(doc.getContainer()), split[split.length - 1]).stream().map(wtDocument -> wtDocument.getNumber()).collect(Collectors.toList());
            } else if (container instanceof WTLibrary) {
            } else if (container instanceof Project2) {
                Project2 pro = (Project2) container;
                IBAUtil ibaUtil1 = new IBAUtil(pro);
                String ct_mainLibrary = ibaUtil1.getIBAValue("Ct_MainLibrary");
                PDMLinkProduct product = getProduct(ct_mainLibrary);
                if (CtFormatUtil.hasContent(product)) {
                    docNums = CtCommonUtil.getDocUnderContainer(CtWTObjectUtil.getId(product), split[split.length - 1]).stream().map(wtDocument -> wtDocument.getNumber()).collect(Collectors.toList());
                }
            }

            Set<String> set = new HashSet<>();
            for (String docNum : docNums) {
                if (!docNum.equals(number)) {
                    set.add(docNum);
                }
            }
            if (set != null && set.size() > 0) {
                throw new Exception("该库下已存在该文档，编号为:" + set + "\r\n");
            }
        }*/
		if (split[split.length - 1].equals("com.fhsj.Doc.ipdlcfhdbd")) {
			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
			String formattedDateTime = now.format(formatter);
			String ymByDoc = IpdProcessComplianceQuery.getCurrentYMByDoc(formattedDateTime);
			if (CtFormatUtil.hasContent(ymByDoc)) {
				String docVr = "VR:wt.doc.WTDocument:" + ymByDoc;
				WTDocument docExit = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
				throw new Exception("当月文档(" + docExit.getNumber() + ")已创建完成，请不要重复创建");
			}
			
			String[] timeSpt = formattedDateTime.split("-");
			long branchId = doc.getBranchIdentifier();
			if (null != timeSpt && timeSpt.length == 2) {
				IpdProcessComplianceQuery.addAssociatedDateInfo(formattedDateTime, branchId + "", timeSpt[0],
						timeSpt[1]);
			}
		}else if (split[split.length - 1].equals("com.fhsj.Doc_cpzlgj")) {
            Project2 project2 = CtProjectUtil.getProjectByNumber(projectId);
            if (!CtFormatUtil.hasContent(project2)) {
                throw new Exception("项目编号错误，请检查填写是否正确或是否存在该项目");
            }
            String[] strings = new String[4];
            strings[0] = "";
            strings[1] = projectId;
            strings[2] = "";
            strings[3] = "";
            List<CtQualityMetricBo> metricBos = (List<CtQualityMetricBo>) beanService.doMethod(CtQualityMetricServiceImpl.class, "getQualityMetric", strings);
            if (CtFormatUtil.hasContent(metricBos)) {
                throw new Exception("一个项目只能拥有一个质量计划文档");
            }
        } else if (split[split.length - 1].equals("com.fhsj.Doc_TRpsbgmb")) {

            String projectPhase = ibaUtil.getIBAValue("Ct_ProjectPhase");

            Project2 project2 = CtProjectUtil.getProjectByNumber(projectId);
            if (!CtFormatUtil.hasContent(project2)) {
                throw new Exception("项目编号错误，请检查填写是否正确或是否存在该项目");
            }
            String[] strings = new String[4];
            strings[0] = "";
            strings[1] = projectId;
            strings[2] = "";
            strings[3] = projectPhase;
//            List<CtTrReviewBo> reviewBos = (List<CtTrReviewBo>) beanService.doMethod(CtTrReviewServiceImpl.class, "getTrReviewByBranchId", strings);
//            if (CtFormatUtil.hasContent(reviewBos)) {
//                throw new Exception("一个项目的每一个阶段只能拥有一个TR评审文档");
//            }
        } else if (split[split.length - 1].equals("com.fhsj.Doc_xqpxplscsqjgz")) {
            String partNumber = ibaUtil.getIBAValue("ct_materialsnumber");
            //判断物料编码是否正确
            if (CtFormatUtil.hasContent(partNumber)) {
                WTPart part = CtPartUtil.getPartByNumber(partNumber);
                if (!CtFormatUtil.hasContent(part)) {
                    throw new Exception("未找到此物料,请检查物料编码是否正确或物料是否存在");
                }
            }
        } else if (split[split.length - 1].equals(CtMilestoneConstant.MILESTONE_DOC_TYPE)) {
            String projectNumber = "";
            HttpServletRequest request = arg0.getRequest();
            String projectOid = request.getParameter("projectOid");
            if (projectOid != null) {
                Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectOid);
                if (project != null) {
                    projectNumber = project.getProjectNumber();
                }
            } else {
                throw new Exception("请通过在项目操作菜单点击里程碑发起创建里程碑文档，此处禁止创建!");
            }
            ibaUtil.setIBAValue("ct_ItemNumber", projectNumber);
            ibaUtil.updateIBAHolder(doc);
        } else if (split[split.length - 1].equals("com.fhsj.Doc_xmfxqd")) {
            WTContainer container = doc.getContainer();
            if (container instanceof Project2) {
                Project2 pro = (Project2) container;
                String projectNumber = pro.getProjectNumber();
                ibaUtil.setIBAValue("ct_ItemNumber", projectNumber);
                ibaUtil.updateIBAHolder(doc);
            }
        } else if (split[split.length - 1].equals(CtRequireConstant.Ct_RequireDoc)) {
            String docNumber = doc.getNumber();
/*
                    String projectNumber = ibaUtil.getIBAValue("ct_ItemNumber");
                    Project2 project = CtProjectUtil.getProjectByNumber(projectNumber);
                    if(project==null){
                        throw new Exception("项目编号填写有误,不存在项目编号为"+projectNumber+"的项目!");
                    }
                  List<String> docNums = CtProjectLogic.getDocNumsByProjectNumberAndDocType(projectNumber, CtRequireConstant.Ct_RequireDoc);
*/

         /*   List<String> docNums = CtCommonUtil.getDocUnderContainer(CtWTObjectUtil.getId(doc.getContainer()), CtRequireConstant.Ct_RequireDoc).stream().map(wtDocument -> wtDocument.getNumber()).collect(Collectors.toList());
            Set<String> set = new HashSet<>();
            for (String docNum : docNums) {
                if (!docNum.equals(docNumber)) {
                    set.add(docNum);
                }
            }
            if (set != null && set.size() > 0) {
                throw new Exception("该库下已存在需求矩阵文档，编号为:" + set + "\r\n");
            }*/
            Project2 project2 = CtProjectUtil.getProjectByNumber(projectId);
            IBAUtil ibaUtil2 = new IBAUtil(project2);
            String projectType = ibaUtil2.getIBAValue("Ct_ProjectType");

            CtRequireQuery ctRequireQuery = new CtRequireQuery();
            WTContainer container = doc.getContainer();
            String id = CtWTObjectUtil.getId(container);
            List<String> drDocNumber = ctRequireQuery.isORDocExist(id, "com.fhsj.Doc_cpxqggsms");
            String hostName = CtCommonUtil.getHostName();
            String port = "";
            if (!CtFormatUtil.hasContent(drDocNumber)&&(!"产品开发项目（维护）".equals(projectType))) {
                throw new WTException("未创建DR文档，请先创建！！！");
            } else {
                if(CtFormatUtil.hasContent(drDocNumber)){
                    WTDocument drDocument = CtDocUtil.getDocumentByNumber(drDocNumber.get(0));
                    String drOid = CtWTObjectUtil.getOid(drDocument);
                    IBAUtil ibaUtil1 = new IBAUtil(drDocument);
                    String value = ibaUtil1.getIBAValue("ct_orLink");

                    if (hostName.contains("plmdemo")) {
                        port = ":8885";
                    } else if (hostName.contains("plmtest")) {
                        port = ":8886";
                    }
                    //ibaUtil.setIBAURLValue(doc,"ct_drLink","http://plmlocal.fhsj.com/Windchill/app/#ptc1/tcomp/infoPage?oid="+oid+"$$$"+document.getName());
                    System.out.println("ct_orLink" + value);
                    ibaUtil.setIBAValue("ct_orLink", value);
                    ibaUtil.setIBAValue("ct_drLink", "http://" + hostName + port + "/Windchill/app/#ptc1/tcomp/infoPage?oid=" + drOid);
                    ibaUtil.updateIBAHolder(doc);
                }

            }

        } else if (split[split.length - 1].equals("com.fhsj.Doc_tyzzwj")) {
            String recertfNumber = ibaUtil.getIBAValue("ct_RenewalDelistingApplicationFormNumber");
            WTDocument document = CtDocUtil.getDocumentByNumber(recertfNumber);
            if (CtFormatUtil.hasContent(document)) {
                CtDocUtil.createDocLink(doc, document);
            } else {
                throw new Exception("请检查续证/退市申请表编号是否正确，未找到该文档");
            }
        }
        //P-010_项目优先级调整申请   --需要自动修改 原项目优先级 iba属性
        else if (split[split.length - 1].equals("com.fhsj.Doc_xmyxjtzsq")) {
            String ct_itemNumber = ibaUtil.getIBAValue("ct_ItemNumber");
            Project2 pro = CtProjectUtil.getProjectByNumber(ct_itemNumber);
            if (!CtFormatUtil.hasContent(pro)) {
                throw new Exception("请检查所填写的项目编号是否存在");
            }
            IBAUtil iba = new IBAUtil(pro);
            String ct_projectpriority = iba.getIBAValue("Ct_Projectpriority");
            ibaUtil.setIBAValue("Ct_Priorityoftheoriginalproject", ct_projectpriority);
            ibaUtil.updateIBAHolder(doc);
        } else if (split[split.length - 1].equals("com.fhsj.Doc_zs")) {
            String value = ibaUtil.getIBAValue("ct_CancellationResume");
            if (CtFormatUtil.hasContent(value)){
                String[] split1 = value.split("-");
                String pattern = "((((1[6-9]|[2-9]\\d)\\d{2})(\\/|\\-)(0?[13578]|1[02])(\\/|\\-)(0?[1-9]|[12]\\d|3[01]))|(((1[6-9]|[2-9]\\d)\\d{2})(\\/|\\-)(0?[13456789]|1[012])(\\/|\\-)(0?[1-9]|[12]\\d|30))|(((1[6-9]|[2-9]\\d)\\d{2})(\\/|\\-)0?2(\\/|\\-)(0?[1-9]|1\\d|2[0-8]))|(((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))-0?2-29-))";
                boolean isMatch = Pattern.matches(pattern, split1[0]);
                System.out.println(isMatch);
                if (!isMatch){
                    throw new Exception("请检查所填写的注销履历中的日期是否正确");
                }
            }
        } else if (split[split.length - 1].equals("com.fhsj.Doc_jcxzqxxmrwsx")) {
            //基础型、增强型项目任务书
            CtRequireQuery ctRequireQuery = new CtRequireQuery();
            WTContainer container = doc.getContainer();
            String id = CtWTObjectUtil.getId(container);
            List<String> docNumber = ctRequireQuery.isORDocExist(id, "com.fhsj.Doc_whxxmrws");
            if (CtFormatUtil.hasContent(docNumber)) {
                throw new WTException("该产品库下已存在“维护型项目任务书”无法继续创建");
            }
        } else if (split[split.length - 1].equals("com.fhsj.Doc_whxxmrws")) {
            //维护型项目任务书
            CtRequireQuery ctRequireQuery = new CtRequireQuery();
            WTContainer container = doc.getContainer();
            String id = CtWTObjectUtil.getId(container);
            List<String> docNumber = ctRequireQuery.isORDocExist(id, "com.fhsj.Doc_jcxzqxxmrwsx");
            if (CtFormatUtil.hasContent(docNumber)) {
                throw new WTException("该产品库下已存在“基础型、增强型项目任务书”无法继续创建");
            }
        } else if (split[split.length - 1].equals("com.fhsj.Doc_cpxqggsms")) {
            CtRequireQuery ctRequireQuery = new CtRequireQuery();
            WTContainer container = doc.getContainer();
            String id = CtWTObjectUtil.getId(container);

            List<String> orDocExist = ctRequireQuery.isORDocExist(id, "com.fhsj.Doc_cpxqggsms");
            if (CtFormatUtil.hasContent(orDocExist)) {
                throw new WTException("该产品库下已存在“产品需求规格说明书”无法继续创建");
            }
            String hostName = CtCommonUtil.getHostName();
            List<String> docNumber = ctRequireQuery.isORDocExist(id, "com.fhsj.Doc_jcxzqxxmrwsx");
            List<String> mDocNumber = ctRequireQuery.isORDocExist(id, "com.fhsj.Doc_whxxmrws");
            if (CtFormatUtil.hasContent(docNumber)) {
                WTDocument document = CtDocUtil.getDocumentByNumber(docNumber.get(0));
                String oid = CtWTObjectUtil.getOid(document);
                Hashtable allIBAKey = ibaUtil.getAllIBAKey(doc);
                System.out.println(">>>>>>>>allIBAKey" + ArrayUtils.toString(allIBAKey));
                System.out.println(">>>>>>>ORdocNumber:" + docNumber + ",hostName:" + hostName + ",oid:" + oid);
                //ibaUtil.setIBAURLValue(doc,"ct_orLink","http://plmlocal.fhsj.com/Windchill/app/#ptc1/tcomp/infoPage?oid="+oid+"$$$"+document.getName());
                String port = "";
                if (hostName.contains("plmdemo")) {
                    port = ":8885";
                } else if (hostName.contains("plmtest")) {
                    port = ":8886";
                }
                ibaUtil.setIBAValue("ct_orLink", "http://" + hostName + port + "/Windchill/app/#ptc1/tcomp/infoPage?oid=" + oid);
                ibaUtil.updateIBAHolder(doc);
            } else if (CtFormatUtil.hasContent(mDocNumber)) {
                WTDocument document = CtDocUtil.getDocumentByNumber(mDocNumber.get(0));
                String oid = CtWTObjectUtil.getOid(document);
                System.out.println(">>>>>>>ORdocNumber:" + mDocNumber + ",hostName:" + hostName + ",oid:" + oid);
                //ibaUtil.setIBAURLValue(doc,"ct_orLink","http://plmlocal.fhsj.com/Windchill/app/#ptc1/tcomp/infoPage?oid="+oid+"$$$"+document.getName());
                String port = "";
                if (hostName.contains("plmdemo")) {
                    port = ":8885";
                } else if (hostName.contains("plmtest")) {
                    port = ":8886";
                }
                ibaUtil.setIBAValue("ct_orLink", "http://" + hostName + port + "/Windchill/app/#ptc1/tcomp/infoPage?oid=" + oid);
                ibaUtil.updateIBAHolder(doc);
            } else {
                throw new WTException("未创建OR文档，请先创建！！！");
            }

        }
    }

    /**
     * 更新文档IBA
     *
     * @param doc
     * @throws Exception
     */
    public static String updateDocIba(WTDocument doc) throws Exception {
        String projectNumber = "";
        IBAUtil ibaUtil = new IBAUtil(doc);
        WTContainer container = doc.getContainer();
        //如果文档在产品库中--自动把产品库中的说明修改为文档的“项目编号”
        if (container instanceof PDMLinkProduct) {
            PDMLinkProduct pdm = (PDMLinkProduct) container;
            String description = pdm.getDescription();
            ibaUtil.setIBAValue("ct_ItemNumber", description);
            ibaUtil.updateIBAHolder(doc);
            projectNumber = description;
        } else if (container instanceof Project2) {
            Project2 pro = (Project2) container;
            ibaUtil.setIBAValue("ct_ItemNumber", pro.getProjectNumber());
            ibaUtil.updateIBAHolder(doc);
            projectNumber = pro.getProjectNumber();
        }
        System.out.println("projectNumber===" + projectNumber);
        return projectNumber;
    }

    private static PDMLinkProduct getProduct(String name) throws Exception {
        QuerySpec qs = new QuerySpec(PDMLinkProduct.class);
        qs.appendWhere(new SearchCondition(PDMLinkProduct.class,
                PDMLinkProduct.NAME, SearchCondition.EQUAL, name
                .toUpperCase(), false));
        QueryResult qr = PersistenceHelper.manager.find(qs);
        PDMLinkProduct product = null;
        while (qr.hasMoreElements()) {
            product = (PDMLinkProduct) qr.nextElement();
        }
        return product;
    }

    public static void downloadDoc(List<Map> list, ZipOutputStream zipOutputStream) throws Exception {
        for (Map map : list) {
            System.out.println(">>>>>>>fileNumber:" + map.get("fileNumber"));
            WTDocument doc = CtDocUtil.getDocumentByNumber(map.get("fileNumber").toString());
            ApplicationData primaryAppData = CtDocUtil.getPrimaryContent(doc);

            List<ApplicationData> attachments = CtSupplierDocumentLogic.getAttachmentByDoc(doc);

            InputStream inputStream;
            ZipEntry zipEntry;

            String docType = CtWTObjectUtil.getLeafTypeIdentifier(doc);
            List<String> effectiveAppDataList = getEffectiveAppDataList(doc, docType);

            if (CtFormatUtil.hasContent(attachments)) {
                for (ApplicationData attachment : attachments) {
                    inputStream = ContentServerHelper.service.findContentStream(attachment);
                    if (inputStream == null) continue;

                    String fileName = attachment.getFileName();

                    //证书筛选掉已失效的附件
                    if("com.fhsj.Doc_zs".equals(docType)){
                        fileName = CtEcLogic.urlStr2Ascii(fileName); // 特殊字符处理
                        if(!effectiveAppDataList.contains(fileName)){
                            continue;
                        }
                    }

                    String replace = fileName.replace(" ", "");
                    String fileName1 = (String)map.get("fileName");
                    if(fileName1==null){
                        fileName1="";
                    }
                    String replace2 = fileName1.replace(" ", "");
                    //replace= URLDecoder.decode(replace, "ISO-8859-7");
                    System.out.println(">>>>>>>file:"+map.get("fileNumber")+"-" + replace2 + File.separator+"系统文档附件" + File.separator + replace);
                    // 处理单个文件
                    zipEntry = new ZipEntry(map.get("fileNumber") + "-" + replace2 + File.separator+"系统文档附件" + File.separator + replace);
                    zipOutputStream.putNextEntry(zipEntry);
                    IOUtils.copy(inputStream, zipOutputStream);
                    zipOutputStream.closeEntry();
                }
            }

            if (CtFormatUtil.hasContent(primaryAppData)) {
                inputStream = ContentServerHelper.service.findContentStream(primaryAppData);

                String fileName = primaryAppData.getFileName();
                String fileName1 = (String)map.get("fileName");
                if(fileName1==null){
                    fileName1="";
                }
                String replace2 = fileName1.replace(" ", "");
                // 处理单个文件
                String replace = fileName.replace(" ", "");
                zipEntry = new ZipEntry(map.get("fileNumber")+ "-" + replace2 + File.separator+"系统文档主内容" + File.separator + replace);
                zipOutputStream.putNextEntry(zipEntry);
                IOUtils.copy(inputStream, zipOutputStream);
                zipOutputStream.closeEntry();
            }
        }
    }

    /**
     * 找出有效的附件清单
     * @param doc
     * @return
     * @throws Exception
     */
    public static List<String> getEffectiveAppDataList(WTDocument doc, String docType) throws Exception {
        List<String> list = new ArrayList<>();
        if(!"com.fhsj.Doc_zs".equals(docType)){
            return list;
        }
        Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
        CtCertificateListMapper ctCertificateListMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificateListMapper.class);
        List<CtCertificateListBo> certificateListBoList = ctCertificateListMapper.selectList(new EntityWrapper<CtCertificateListBo>().eq("MASTERID", masterId));
        for(CtCertificateListBo bo : certificateListBoList){
            if("生效中".equals(bo.getCertificateStatus())){
                if(CtFormatUtil.hasContent(bo.getCertificateFile())){
                    String[] certificateFileArray = bo.getCertificateFile().split(";;;qqq");
                    for(int i = 0;i < certificateFileArray.length;i++){
                        list.add(certificateFileArray[i]);
                    }
                }
                if(CtFormatUtil.hasContent(bo.getElectronicCertificate())){
                    String[] electronicFileArray = bo.getElectronicCertificate().split(";;;qqq");
                    for(int i = 0;i < electronicFileArray.length;i++){
                        list.add(electronicFileArray[i]);
                    }
                }
            }
        }
        CtReportChecklistMapper ctReportChecklistMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportChecklistMapper.class);
        List<CtReportChecklistBo> reportChecklistBoList = ctReportChecklistMapper.selectList(new EntityWrapper<CtReportChecklistBo>().eq("MASTERID", masterId));
        for(CtReportChecklistBo bo : reportChecklistBoList){
            if("生效中".equals(bo.getReportStatus())){
                if(CtFormatUtil.hasContent(bo.getReportFile())){
                    String[] reportFileArray = bo.getReportFile().split(";;;qqq");
                    for(int i = 0;i < reportFileArray.length;i++){
                        list.add(reportFileArray[i]);
                    }
                }
                if(CtFormatUtil.hasContent(bo.getFeatureFiles())){
                    String[] featureFilesArray = bo.getFeatureFiles().split(";;;qqq");
                    for(int i = 0;i < featureFilesArray.length;i++){
                        list.add(featureFilesArray[i]);
                    }
                }
            }
        }
        return list;
    }

    /**
     * 标准文件流水号生成
     *
     * @param doc
     * @throws Exception
     */
    public static void genStandardNumber(WTDocument doc) throws Exception {
        boolean orgAccessEnfored = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            String innerName = ClientTypedUtility.getExternalTypeIdentifier(doc);

            String[] split = innerName.split("\\|");
            String s = split[split.length - 1];
            if("com.fhsj.Doc_bzwj".equals(s)){
                CtDocQuery ctDocQuery = new CtDocQuery();
                String maxDocNumberByPrefix = ctDocQuery.getMaxDocNumberByPrefix("BZ-001_");
                maxDocNumberByPrefix=maxDocNumberByPrefix.substring(7);
                if("99999".equals(maxDocNumberByPrefix)){
                    throw new Exception("编码已达到最大流水位：BZ-001_99999");
                }else{
                    int i ;
                    try {
                        i = Integer.parseInt(maxDocNumberByPrefix);
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new Exception("【BZ-001_"+maxDocNumberByPrefix+"】流水码不为纯数字,无法正确流水,请联系管理员修改正确或自行手动修改");
                    }
                    i+=1;
                    String numStr=i+"";
                    while (numStr.length()<5){
                        numStr="0"+numStr;
                    }
                    maxDocNumberByPrefix="BZ-001_"+numStr;
                }
                System.out.println("maxDocNumberByPrefix====="+maxDocNumberByPrefix);
                CtDocUtil.updateDocNumber(doc, maxDocNumberByPrefix);
                doc = (WTDocument) PersistenceHelper.manager.refresh(doc);
            }else if("com.fhsj.Doc_txxy".equals(s)){
                CtDocQuery ctDocQuery = new CtDocQuery();
                String maxDocNumberByPrefix = ctDocQuery.getMaxDocNumberByPrefix("XY-001_");
                maxDocNumberByPrefix=maxDocNumberByPrefix.substring(7);
                if("99999".equals(maxDocNumberByPrefix)){
                    throw new Exception("编码已达到最大流水位：XY-001_99999");
                }else{
                    int i ;
                    try {
                        i = Integer.parseInt(maxDocNumberByPrefix);
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new Exception("【XY-001_"+maxDocNumberByPrefix+"】流水码不为纯数字,无法正确流水,请联系管理员修改正确或自行手动修改");
                    }
                    i+=1;
                    String numStr=i+"";
                    while (numStr.length()<5){
                        numStr="0"+numStr;
                    }
                    maxDocNumberByPrefix="XY-001_"+numStr;
                }
                System.out.println("maxDocNumberByPrefix====="+maxDocNumberByPrefix);
                CtDocUtil.updateDocNumber(doc, maxDocNumberByPrefix);
                doc = (WTDocument) PersistenceHelper.manager.refresh(doc);
            }else{
                String[] disableDoc = new String[]{"com.fhsj.Doc_CG","com.fhsj.Doc_IPMT","com.fhsj.Doc_PDTGL","com.fhsj.Doc_cpgl","com.fhsj.Doc_cs","com.fhsj.Doc_cw","com.fhsj.Doc_gbhb","com.fhsj.Doc_jgkf","com.fhsj.Doc_jszc","com.fhsj.Doc_qtlxwd","com.fhsj.Doc_rjkf","com.fhsj.Doc_rz",
                        "com.fhsj.Doc_sc","com.fhsj.Doc_scgf","com.fhsj.Doc_wgpzl","com.fhsj.Doc_wlrzzl","com.fhsj.Doc_xmgl","com.fhsj.Doc_xs","com.fhsj.Doc_xtgc","com.fhsj.Doc_yf","com.fhsj.Doc_yjkf","com.fhsj.Doc_yxgj","com.fhsj.Doc_zl","com.fhsj.Doc_yjscwj","com.fhsj.Doc_dbrj","com.fhsj.Doc_tdtxmwd"};
                int i=0;
                
                for(String element:disableDoc){
                   if(element.equals(s)){
                       i=1;
                      break;
                   }
                }
                if(i==1){
                    throw new Exception("该文档类型不可创建！");
                }

            }
        } catch(Exception e) {
            e.printStackTrace();
            throw new Exception(e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(orgAccessEnfored);
        }
    }
}
