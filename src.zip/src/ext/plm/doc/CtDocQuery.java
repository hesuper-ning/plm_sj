package ext.plm.doc;

import ext.plm.common.CtConstant;
import ext.plm.doc.config.CtDocProperties;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import wt.change2.WTChangeRequest2;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.MethodContext;
import wt.pom.WTConnection;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * @Author: lcd
 * @Date: 2021/10/13 19:52
 * @Description:
 */
public class CtDocQuery {
    /**
     * 查找改项目编号有没有文档占用
     * @return
     * @throws Exception
     */
    public String  getIbaProjectNumDoc(String projectNum,String docNumber) throws Exception{
        String name = CtUserUtil.getCurrentUserAccountName();

        String epm = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "SELECT DISTINCT\n" +
                    "            docMaster.WTDocumentNumber\n" +
                    "        FROM\n" +
                    "            wcadmin.WTDocument doc,\n" +
                    "            wcadmin.WTDocumentMaster docMaster,\n" +
                    "            wcadmin.WTTypeDefinition typed,\n" +
                    "            wcadmin.WTTypeDefinitionMaster typeMater,\n" +
                    "            wcadmin.StringDefinition strDef,\n" +
                    "            wcadmin.StringValue strVal\n" +
                    "        WHERE\n" +
                    "            doc.idA3masterReference = docMaster.idA2A2\n" +
                    "        AND docMaster.markForDeleteA2 = 0\n" +
                    "        AND doc.latestiterationInfo = 1\n" +
                    "        AND typed.idA3masterReference = typeMater.idA2A2\n" +
                    "        AND typed.idA2A2 = doc.idA2typeDefinitionReference\n" +
                    "        AND typeMater.markForDeleteA2 = 0\n" +
                    "        AND typeMater.intHid LIKE '%com.fhsj.Doc_xmfxqd%'\n" +
                    "        AND strDef.idA2A2 = strVal.idA3A6\n" +
                    "        AND strVal.idA3A4 = doc.idA2A2\n" +
                    "        AND strDef.name =?\n" +
                    "        AND strVal.value2 = ?"+
                    "        AND  docMaster.WTDocumentNumber != ?" ;
            statement = connection.prepareStatement(sql);
            System.out.println(">>>projectName"+CtDocProperties.getProperties("projectName"));
            statement.setString(1, CtDocProperties.getProperties("projectName"));
            statement.setString(2, projectNum);
            statement.setString(3, docNumber);
            result = statement.executeQuery();

            while (result.next()) {
                String number=result.getString("WTDOCUMENTNUMBER");
                epm = CtFormatUtil.combineStr(epm, number, ",");
            }
            System.out.println(">>>epm"+epm);

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return epm;
    }

    /**
     * 获取标准文件最大流水号
     * @param prefix
     * @return
     * @throws Exception
     */
    public  String getMaxDocNumberByPrefix(String prefix) throws Exception {
        QuerySpec querySpec = new QuerySpec(WTDocument.class);
        querySpec.setAdvancedQueryEnabled(true);
        querySpec.appendSearchCondition(new SearchCondition(WTDocument.class,WTDocument.NUMBER,SearchCondition.LIKE,prefix+"_____"));
        ClassAttribute cls = new ClassAttribute(WTDocument.class, WTDocument.NUMBER);
        querySpec.appendOrderBy(new OrderBy(cls,true));
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        while(queryResult.hasMoreElements()){
            Object obj = queryResult.nextElement();
            WTDocument changeRequest = (WTDocument)obj;
            return changeRequest.getNumber();
        }
        return "";
    }

    /**
     * 查询文档当前的生命周期是否有某个状态
     * @param doc
     * @param docState
     * @return
     * @throws Exception
     */
    public boolean docHasState(WTDocument doc, String docState) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT p.NAME FROM WTDOCUMENT t, PHASELINK k, PhaseTemplate p WHERE t.IDA3A2STATE = k.IDA3A5")
                .append(" AND p.IDA2A2 = k.IDA3B5")
                .append(" AND t.IDA2A2 = ?")
                .append("AND p.NAME = ?");
            statement = connection.prepareStatement(sql.toString());
            statement.setLong(1, doc.getPersistInfo().getObjectIdentifier().getId());
            statement.setString(2, docState);
            result = statement.executeQuery();
            if (result.next()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return false;
    }
}
