package ext.plm.doc;

import ext.plm.util.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.httpgw.GatewayAuthenticator;
import wt.method.MethodContext;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.pom.Transaction;
import wt.pom.WTConnection;
import wt.util.WTProperties;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

/**
 * @Author: lzp
 * @Date: 2023/9/28
 * @Description:后台刷新文档物料编号
 */
public class CtRefreshDocMaterialsNumberMain implements Serializable, RemoteAccess {
    // windchill ext.plm.doc.CtRefreshDocMaterialsNumberMain
    public static void main(String[] args) throws Exception {
        if (!RemoteMethodServer.ServerFlag) {
            Class[] cls = {String[].class};
            Object[] obj = {args};
            try {
                RemoteMethodServer server = RemoteMethodServer.getDefault();

                GatewayAuthenticator authenticator = new GatewayAuthenticator();
                authenticator.setRemoteUser("wcadmin");
                server.setAuthenticator(authenticator);

                server.invoke("main", CtRefreshDocMaterialsNumberMain.class.getName(), null, cls, obj);
            } catch (RemoteException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            return;
        }
        String info = refreshDocMaterialsNumber();
        if(CtFormatUtil.hasContent(info)){
            throw new Exception(info);
        }
    }

    public static String refreshDocMaterialsNumber() throws Exception {
        MethodContext methodContext = MethodContext.getContext();
        WTConnection connection = null;
        PreparedStatement statement = null;
        ResultSet rs = null;
        Transaction transaction = new Transaction();
        String info = "";
        InputStream is = null;
        String errorInfo = "";
        String errorInfoNumber = "";
        String error = "";
        List<String> errorList = new ArrayList<>();
        try {

            WTDocument docConfig = CtDocUtil.getDocumentByNumber("MODIFYASSOCIATIONTABLE");
            is = CtDocUtil.getInputStreamByDoc(docConfig);
            XSSFWorkbook workbook = new XSSFWorkbook(is);
            Sheet sheet = workbook.getSheetAt(0);
            //用于判断文档物料编码属性是否已经被置空过了
            Set<String> set = new HashSet<>();
            //Set<String> deleteDescribeLinkSet = new HashSet<>();
            //Set<String> partSet = new HashSet<>();
            System.out.println("获取文档成功");
            HashMap<String, List<String>> hash = new HashMap<>();
            HashMap<String, List<String>> deleteHash = new HashMap<>();
            HashMap<String, List<String>> deleteOidHash = new HashMap<>();

            transaction.start();
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                String partNumber = CtExcelReadUtil.getCellFormatValue(row.getCell(4), row, 4);
                String docNumber = CtExcelReadUtil.getCellFormatValue(row.getCell(1), row, 1);
                String partOid = CtExcelReadUtil.getCellFormatValue(row.getCell(10), row, 10);
                String docOid = CtExcelReadUtil.getCellFormatValue(row.getCell(9), row, 9);
                try {
                    WTPart part = CtPartUtil.getPartByOid(partOid);
                    WTDocument docByNumber = CtDocUtil.getDocumentByNumber(docNumber);

                    //先删除文档关联的所有部件
                    if(!(deleteHash.containsKey(partNumber)&&deleteHash.get(partNumber).contains(docNumber))) {
                        WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                        WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                        if (CtFormatUtil.hasContent(dPartD)) {
                            QueryResult queryresult = PersistenceHelper.manager.find(
                                    WTPartDescribeLink.class, dPartD, WTPartDescribeLink.DESCRIBES_ROLE, docByNumber);
                            while (queryresult.hasMoreElements()) {
                                Object object = queryresult.nextElement();
                                if (object instanceof WTPartDescribeLink) {
                                    WTPartDescribeLink link = (WTPartDescribeLink) object;
                                    CtPartUtil.deleteDescribeLink(link);
                                }
                            }
                        }
                        if (CtFormatUtil.hasContent(dPartM)) {
                            QueryResult queryresult = PersistenceHelper.manager.find(
                                    WTPartDescribeLink.class, dPartM, WTPartDescribeLink.DESCRIBES_ROLE, docByNumber);
                            while (queryresult.hasMoreElements()) {
                                Object object = queryresult.nextElement();
                                if (object instanceof WTPartDescribeLink) {
                                    WTPartDescribeLink link = (WTPartDescribeLink) object;
                                    CtPartUtil.deleteDescribeLink(link);
                                }
                            }
                        }
                        if(!deleteHash.containsKey(partNumber)){
                            List<String> deleteList = new ArrayList<>();
                            deleteList.add(docNumber);
                            deleteHash.put(partNumber,deleteList);
                        }
                        if(!deleteHash.get(partNumber).contains(docNumber)){
                            deleteHash.get(partNumber).add(docNumber);
                        }

                        //partSet.add(partNumber);
                        //deleteDescribeLinkSet.add(docNumber);
                    }

                    WTDocument docByOid = null;

                    //删除旧文档与最新部件的关联关系
                    if(!(deleteOidHash.containsKey(partNumber)&&deleteOidHash.get(partNumber).contains(docOid))) {
                        try {
                            docByOid = (WTDocument) CtWTObjectUtil.getObjectByOid("OR:wt.doc.WTDocument:" + docOid);
                        } catch (Exception e) {
                            //System.out.println("文档:" + docNumber + "根据IDA2A2获取对象错误跳过");
                            errorList.add("文档:" + docNumber + "根据IDA2A2获取对象错误跳过" + e);
                            error += "文档:" + docNumber + "根据IDA2A2获取对象错误跳过" + e+"\n";
                        }
                        //deleteDescribeLinkSetOid.add(docOid);
                        if (CtFormatUtil.hasContent(docByOid)) {
                            WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                            WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");

                            if (CtFormatUtil.hasContent(dPartD)) {
                                QueryResult queryresult = PersistenceHelper.manager.find(
                                        WTPartDescribeLink.class, dPartD, WTPartDescribeLink.DESCRIBES_ROLE, docByOid);
                                while (queryresult.hasMoreElements()) {
                                    Object object = queryresult.nextElement();
                                    if (object instanceof WTPartDescribeLink) {
                                        WTPartDescribeLink link = (WTPartDescribeLink) object;
                                        CtPartUtil.deleteDescribeLink(link);
                                    }
                                }
                            }
                            if (CtFormatUtil.hasContent(dPartM)) {
                                QueryResult queryresult = PersistenceHelper.manager.find(
                                        WTPartDescribeLink.class, dPartM, WTPartDescribeLink.DESCRIBES_ROLE, docByOid);
                                while (queryresult.hasMoreElements()) {
                                    Object object = queryresult.nextElement();
                                    if (object instanceof WTPartDescribeLink) {
                                        WTPartDescribeLink link = (WTPartDescribeLink) object;
                                        CtPartUtil.deleteDescribeLink(link);
                                    }
                                }
                            }

                            if(!deleteOidHash.containsKey(partNumber)){
                                List<String> deleteList = new ArrayList<>();
                                deleteList.add(docOid);
                                deleteOidHash.put(partNumber,deleteList);
                            }
                            if(!deleteOidHash.get(partNumber).contains(docOid)){
                                deleteOidHash.get(partNumber).add(docOid);
                            }

                            //if (CtFormatUtil.hasContent(dPartD)) {
                            //    CtPartUtil.deleteDescribeLink(dPartD, docByOid);
                            //}
                            //if (CtFormatUtil.hasContent(dPartM)) {
                            //    CtPartUtil.deleteDescribeLink(dPartM, docByOid);
                            //}
                            //CtPartUtil.deleteDescribeLink(part, docByOid);
                        }
                    }

                    //如果是旧关联就跳过
                    if(CtFormatUtil.hasContent(docByNumber)&&CtFormatUtil.hasContent(docByOid)) {
                        String versionInfoByNumber = CtVersionUtil.getVersionInfo(docByNumber);
                        String versionInfoByOid = CtVersionUtil.getVersionInfo(docByOid);
                        if (!versionInfoByNumber.equals(versionInfoByOid)) {
                            continue;
                        }
                    }

                    //给文档物料编码属性赋值
                    boolean containsApple = set.contains(docNumber);
                    IBAUtil modifyIbaValue = new IBAUtil(docByNumber);
                    if(!containsApple){
                        modifyIbaValue.setIBAValue("ct_materialsnumber","");
                        modifyIbaValue.updateIBAHolder(docByNumber);
                        set.add(docNumber);
                    }
                    String materialsnumberValue = modifyIbaValue.getIBAValue("ct_materialsnumber");
                    if(!CtFormatUtil.hasContent(materialsnumberValue)){
                        modifyIbaValue.setIBAValue("ct_materialsnumber",partNumber);
                    }else {
                        if(!materialsnumberValue.contains(partNumber)){
                            modifyIbaValue.setIBAValue("ct_materialsnumber",materialsnumberValue+","+partNumber);
                        }
                    }
                    modifyIbaValue.updateIBAHolder(docByNumber);

                    //创建最新文档与最新部件两个视图的关联
                    if(hash.containsKey(partNumber)){
                        if(!hash.get(partNumber).contains(docNumber)){
                            hash.get(partNumber).add(docNumber);
                            WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                            if (CtFormatUtil.hasContent(dPartD)) {
                                CtPartUtil.createDescribeLink(dPartD, docByNumber);
                            }
                            WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                            if (CtFormatUtil.hasContent(dPartM)) {
                                CtPartUtil.createDescribeLink(dPartM, docByNumber);
                            }
                        }
                    }else {
                        List<String> list = new ArrayList<>();
                        list.add(docNumber);
                        hash.put(partNumber,list);
                        WTPart dPartD = CtPartUtil.getPartByNumber(partNumber, "Design");
                        if (CtFormatUtil.hasContent(dPartD)) {
                            CtPartUtil.createDescribeLink(dPartD, docByNumber);
                        }
                        WTPart dPartM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                        if (CtFormatUtil.hasContent(dPartM)) {
                            CtPartUtil.createDescribeLink(dPartM, docByNumber);
                        }
                    }
                }catch (Exception e) {
                    //System.out.println("部件:"+partNumber+"修改关联关系错误"+e);
                    errorList.add("文档:"+docNumber+" docOid:"+docOid+" 部件:"+partNumber+" partOid:"+partOid+"修改关联关系错误"+e);
                    errorInfo += "文档:"+docNumber+" docOid:"+docOid+" 部件:"+partNumber+" partOid:"+partOid+"修改关联关系错误"+e+"\n";
                    e.printStackTrace();
                }
            }


        }catch (Exception wte) {
            transaction.rollback();
            errorList.add("后台刷新文档物料编号出现错误，具体请查看日志！");
            info = "后台刷新文档物料编号出现错误，具体请查看日志！";
            wte.printStackTrace();
        } finally {


            if(errorList.size()!=0) {
                // 创建工作簿
                Workbook workbook = new XSSFWorkbook();

                // 创建工作表
                Sheet sheet = workbook.createSheet("Sheet1");

                Row row0 = sheet.createRow(0);
                Cell cell = row0.createCell(0);
                cell.setCellValue("错误信息");
                try {
                    int j = 1;
                    for (int i = 0; i < errorList.size(); i++) {
                        Row row = sheet.createRow(j++);
                        Cell cell0 = row.createCell(0);
                        cell0.setCellValue(errorList.get(i));
                    }
                } catch (Exception wte) {
                    //transaction.rollback();
                    wte.printStackTrace();
                } finally {
                    try {
                        if (rs != null) {
                            rs.close();
                        }
                        if (statement != null) {
                            statement.close();
                        }
                        if (connection != null && connection.isActive()) {
                            connection.release();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                // 保存为 Excel 文件
                WTProperties wtProperty = WTProperties.getLocalProperties();
                String filePath = wtProperty.getProperty("wt.home") + File.separator + "codebase" + File.separator + "ext" + File.separator +
                        "plm" + File.separator + "doc" + File.separator + "刷关联关系错误信息.xlsx";

                try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
                    workbook.write(fileOut);
                    System.out.println("Excel 文件导出成功！");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            System.out.println(error);
            try {
                if (rs != null) {
                    rs.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null && connection.isActive()){
                    connection.release();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if(!CtFormatUtil.hasContent(info)&&!CtFormatUtil.hasContent(errorInfo)){
            System.out.println("重置关联关系成功！");
            transaction.commit();
        }else {
            System.out.println("重置关联关系失败！");
            System.out.println("@@##$$"+errorInfo);
            info += errorInfo;
            transaction.rollback();
        }


        return info;
    }
}
