package ext.plm.doc;

import ext.plm.bom.CtBomService;
import ext.plm.common.CtConstant;
import wt.doc.WTDocument;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTList;
import wt.lifecycle.LifeCycleHelper;
import wt.method.RemoteMethodServer;
import wt.services.ServiceFactory;

import java.util.List;

public class TestMain {

    public static CtBomService service = ServiceFactory.getService(CtBomService.class);
    public static void main(String[] args) {
        System.out.println("======TestMain.java 开始调用  " + args[0] + "=============");
        try {
            RemoteMethodServer server = RemoteMethodServer.getDefault();
            if (CtConstant.isLocalEnv() || CtConstant.isTestEnv()) {
                server.setUserName("wcadmin");
                server.setPassword("wcadmin");
            } else if (CtConstant.isPrdEnv()) {
                server.setUserName("wcadmin");
                server.setPassword("fhsj.com");
            }
            if ("refreshDocumentLifeCycle".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.doc.TestMain refreshDocumentLifeCycle
                //刷文档生命周期完成
                long start = System.currentTimeMillis();
                List<WTDocument> docList = service.getAllLastDoc();
                System.out.println("======文档总数=============" + docList.size());
                for(WTDocument doc : docList){
                    try {
                        WTList list = new WTArrayList();
                        list.add(doc);
                        LifeCycleHelper.service.reassign(list, doc.getLifeCycleTemplate(), doc.getContainerReference(), true);
                        //System.out.println("======单个耗时=============" + (System.currentTimeMillis()-start)/(1000*60));
                    }catch (Exception e){
                        System.out.println("异常信息：" + e.getLocalizedMessage());
                        System.out.println("异常编号：" + doc.getNumber());
                    }
                }
                System.out.println("======全部刷完耗时=============" + (System.currentTimeMillis()-start)/(1000*60));
                System.out.println("======刷文档生命周期完成！=============");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
