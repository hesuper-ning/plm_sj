package ext.plm.doc.bo;


import ext.plm.tool.poi.ref.ExcelColumn;

public class CtImportDocBo {
	
	@ExcelColumn(index=0)
	private String type;
	@ExcelColumn(index=1)
	private String creator;
	@ExcelColumn(index=2)
	private String number;
	@ExcelColumn(index=3)
	private String name;
	@ExcelColumn(index=4)
	private String version;
	@ExcelColumn(index=5)
	private String description;
	@ExcelColumn(index=6)
	private String containerName;
	@ExcelColumn(index=7)
	private String location;
	@ExcelColumn(index=8)
	private String state;
	@ExcelColumn(index=9)
	private String primaryPath;
	@ExcelColumn(index=10)
	private String primaryFileName;
	@ExcelColumn(index=11)
	private String attachmentPath;
	@ExcelColumn(index=12)
	private String attachmentFileName;
	@ExcelColumn(index=13)
	private String partNumber;
	
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContainerName() {
		return containerName;
	}
	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPrimaryPath() {
		return primaryPath;
	}
	public void setPrimaryPath(String primaryPath) {
		this.primaryPath = primaryPath;
	}
	public String getPrimaryFileName() {
		return primaryFileName;
	}
	public void setPrimaryFileName(String primaryFileName) {
		this.primaryFileName = primaryFileName;
	}
	public String getAttachmentPath() {
		return attachmentPath;
	}
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}
	public String getAttachmentFileName() {
		return attachmentFileName;
	}
	public void setAttachmentFileName(String attachmentFileName) {
		this.attachmentFileName = attachmentFileName;
	}
	
	
}
