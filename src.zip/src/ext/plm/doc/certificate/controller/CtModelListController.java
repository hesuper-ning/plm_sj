package ext.plm.doc.certificate.controller;

import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtResApiResult;
import ext.plm.doc.certificate.service.CtModelListService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wt.session.SessionServerHelper;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/ext/plm/doc/certificate/modelList")
public class CtModelListController {

    static Logger logger = Logger.getLogger(CtModelListController.class);

    @Autowired
    private CtModelListService ctModelListService;

    /**
     * 增加相关型号清单
     * @param request
     * @return
     */
    @RequestMapping(value = {"/addModelListData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult addModelListData(HttpServletRequest request) {
        try {
            String masterId = request.getParameter("masterId");
            String branchId = request.getParameter("branchId");
            ctModelListService.insertModelList(Long.valueOf(masterId), Long.valueOf(branchId));
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("增加相关型号清单异常：", e);
            return CtResApiResult.fail("增加相关型号清单失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 删除相关型号清单
     * @param ids
     * @return
     * @throws Exception
     */
    @DeleteMapping(value = "/deleteModelListData")
    public CtResApiResult deleteModelListData(@RequestBody List<String> ids) {
        try {
            ctModelListService.deleteModelListData(ids);
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("删除相关型号清单异常：", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 修改相关型号清单
     * @param request
     * @return
     */
    @RequestMapping(value = {"/updateModelListData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult updateModelListData(HttpServletRequest request) {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("updateRecord"));
            String id = dataJson.getString("id");
            String key = dataJson.getString("key");
            String value = dataJson.getString("value");
            return CtResApiResult.success(ctModelListService.updateModelListData(id, key, value));
        } catch (Exception e) {
            logger.error("更新相关型号清单异常：", e);
            return CtResApiResult.fail("修改数据库失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }finally{
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 查询相关型号清单
     * @param request
     * @return
     */
    @GetMapping(value = "/getModelListData", produces = "application/json;charset=UTF-8")
    public CtResApiResult getModelListData(HttpServletRequest request) {
        String masterId = request.getParameter("masterId");
        String ids = request.getParameter("ids");
        String certificateIds = request.getParameter("certificateIds");
        String reportIds = request.getParameter("reportIds");
        try {
            return CtResApiResult.success(ctModelListService.getModelListData(Long.valueOf(masterId), ids, certificateIds, reportIds));
        } catch (Exception e) {
            logger.error("查询相关型号清单异常：", e);
            return CtResApiResult.fail("查询相关型号清单失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }




}
