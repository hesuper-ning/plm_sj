package ext.plm.doc.certificate.controller;

import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtResApiResult;
import ext.plm.doc.certificate.service.CtCertificateListService;
import ext.plm.doc.certificate.service.CtProductApplicabilityService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wt.session.SessionServerHelper;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/ext/plm/doc/certificate/productApplicability")
public class CtProductApplicabilityController {

    static Logger logger = Logger.getLogger(CtProductApplicabilityController.class);

    @Autowired
    private CtProductApplicabilityService ctProductApplicabilityService;

    /**
     * 增加相关成品适用性
     * @param request
     * @return
     */
    @RequestMapping(value = {"/addProductApplicabilityData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult addProductApplicabilityData(HttpServletRequest request) {
        try {
            String masterId = request.getParameter("masterId");
            String branchId = request.getParameter("branchId");
            ctProductApplicabilityService.insertProductApplicability(Long.valueOf(masterId), Long.valueOf(branchId));
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("增加相关成品适用性异常：", e);
            return CtResApiResult.fail("增加相关成品适用性失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 删除相关成品适用性
     * @param ids
     * @return
     * @throws Exception
     */
    @DeleteMapping(value = "/deleteProductApplicabilityData")
    public CtResApiResult deleteProductApplicabilityData(@RequestBody List<String> ids) {
        try {
            ctProductApplicabilityService.deleteProductApplicabilityData(ids);
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("删除相关成品适用性异常：", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 修改相关成品适用性
     * @param request
     * @return
     */
    @RequestMapping(value = {"/updateProductApplicabilityData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult updateProductApplicabilityData(HttpServletRequest request) {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("updateRecord"));
            String id = dataJson.getString("id");
            String key = dataJson.getString("key");
            String value = dataJson.getString("value");
            return CtResApiResult.success(ctProductApplicabilityService.updateProductApplicabilityData(id, key, value));
        } catch (Exception e) {
            logger.error("更新相关成品适用性异常：", e);
            return CtResApiResult.fail("修改数据库失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 查询相关成品适用性
     * @param masterId
     * @return
     */
    @GetMapping(value = "/getProductApplicabilityData", produces = "application/json;charset=UTF-8")
    public CtResApiResult getProductApplicabilityData(Long masterId) {
        try {
            return CtResApiResult.success(ctProductApplicabilityService.getProductApplicabilityData(masterId));
        } catch (Exception e) {
            logger.error("查询相关成品适用性异常：", e);
            return CtResApiResult.fail("查询相关成品适用性失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }




}
