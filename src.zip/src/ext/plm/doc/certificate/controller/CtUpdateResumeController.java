package ext.plm.doc.certificate.controller;

import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtResApiResult;
import ext.plm.doc.certificate.service.CtUpdateResumeService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/ext/plm/doc/certificate/updateResume")
public class CtUpdateResumeController {

    static Logger logger = Logger.getLogger(CtUpdateResumeController.class);

    @Autowired
    private CtUpdateResumeService ctUpdateResumeService;

    /**
     * 增加更新履历
     * @param request
     * @return
     */
    @RequestMapping(value = {"/addUpdateResumeData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult addUpdateResumeData(HttpServletRequest request) {
        try {
            String masterId = request.getParameter("masterId");
            String branchId = request.getParameter("branchId");
            ctUpdateResumeService.insertUpdateResume(Long.valueOf(masterId), Long.valueOf(branchId));
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("增加更新履历异常：", e);
            return CtResApiResult.fail("增加更新履历失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 删除更新履历
     * @param ids
     * @return
     * @throws Exception
     */
    @DeleteMapping(value = "/deleteUpdateResumeData")
    public CtResApiResult deleteUpdateResumeData(@RequestBody List<String> ids) {
        try {
            ctUpdateResumeService.deleteUpdateResumeData(ids);
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("删除更新履历异常：", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 修改更新履历
     * @param request
     * @return
     */
    @RequestMapping(value = {"/updateUpdateResumeData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult updateUpdateResumeData(HttpServletRequest request) {
        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("updateRecord"));
            String id = dataJson.getString("id");
            String key = dataJson.getString("key");
            String value = dataJson.getString("value");
            return CtResApiResult.success(ctUpdateResumeService.updateUpdateResumeData(id, key, value));
        } catch (Exception e) {
            logger.error("更新更新履历异常：", e);
            return CtResApiResult.fail("修改数据库失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询更新履历
     * @param masterId
     * @return
     */
    @GetMapping(value = "/getUpdateResumeData", produces = "application/json;charset=UTF-8")
    public CtResApiResult getUpdateResumeData(Long masterId) {
        try {
            return CtResApiResult.success(ctUpdateResumeService.getUpdateResumeData(masterId));
        } catch (Exception e) {
            logger.error("查询更新履历异常：", e);
            return CtResApiResult.fail("查询更新履历失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }
}
