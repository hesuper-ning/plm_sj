package ext.plm.doc.certificate.controller;

import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtCommonLogic;
import ext.plm.common.CtResApiResult;
import ext.plm.doc.certificate.CtCertificateHelper;
import ext.plm.doc.certificate.service.CtCertificateListService;
import ext.plm.util.CtFormatUtil;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.tools.zip.ZipOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wt.content.ApplicationData;
import wt.content.ContentServerHelper;
import wt.httpgw.URLFactory;
import wt.org.WTPrincipal;
import wt.pom.Transaction;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTProperties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/ext/plm/doc/certificate/certificateList")
public class CtCertificateListController {

    static Logger logger = Logger.getLogger(CtCertificateListController.class);

    @Autowired
    private CtCertificateListService ctCertificateListService;

    /**
     * 增加证书清单
     *
     * @param request
     * @return
     */
    @RequestMapping(value = {"/addCertificateListData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult addCertificateListData(HttpServletRequest request) {
        try {
            String masterId = request.getParameter("masterId");
            String branchId = request.getParameter("branchId");
            ctCertificateListService.insertCertificateList(Long.valueOf(masterId), Long.valueOf(branchId));
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("增加证书清单异常：", e);
            return CtResApiResult.fail("增加证书清单失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 删除证书清单
     * @param ids
     * @return
     * @throws Exception
     */
    @DeleteMapping(value = "/deleteCertificateListData")
    public CtResApiResult deleteCertificateListData(@RequestBody List<String> ids) {
        Transaction ts = null;
        try {
            ts = new Transaction();
            ts.start();
            ctCertificateListService.deleteCertificateListData(ids);
            ts.commit();
            ts = null;
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("删除证书清单异常：", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }finally{
            if (ts != null) {
                ts.rollback();
            }
        }
    }

    /**
     * 修改证书清单
     *
     * @param request
     * @return
     */
    @RequestMapping(value = {"/updateCertificateListData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult updateCertificateListData(HttpServletRequest request) {
        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("updateRecord"));
            String id = dataJson.getString("id");
            String key = dataJson.getString("key");
            String value = dataJson.getString("value");
            return CtResApiResult.success(ctCertificateListService.updateCertificateListData(id, key, value));
        } catch (Exception e) {
            logger.error("更新证书清单异常：", e);
            return CtResApiResult.fail("修改数据库失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询证书清单
     *
     * @param masterId
     * @return
     */
    @GetMapping(value = "/getCertificateListData", produces = "application/json;charset=UTF-8")
    public CtResApiResult getCertificateListData(@RequestParam(value = "masterId") Long masterId, @RequestParam(value = "ids", required = false) String ids, @RequestParam(value = "reportIds", required = false) String reportIds
            , @RequestParam(value = "effective", required = false) String effective) {
        try {
            return CtResApiResult.success(ctCertificateListService.getCertificateListData(masterId, ids, reportIds, effective));
        } catch (Exception e) {
            logger.error("查询证书清单异常：", e);
            return CtResApiResult.fail("查询证书清单失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 通过id查询证书
     *
     * @param ids
     * @return
     */
    @GetMapping(value = "/getCertificateById", produces = "application/json;charset=UTF-8")
    public CtResApiResult getCertificateById(String ids) {
        try {
            return CtResApiResult.success(ctCertificateListService.getCertificateById(ids));
        } catch (Exception e) {
            logger.error("通过id查询证书异常：", e);
            return CtResApiResult.fail("通过id查询证书失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询有效的证书
     *
     * @param masterId
     * @return
     */
    @GetMapping(value = "/getEffectiveCertificate", produces = "application/json;charset=UTF-8")
    public CtResApiResult getEffectiveCertificate(Long masterId) {
        try {
            return CtResApiResult.success(ctCertificateListService.getEffectiveCertificate(masterId));
        } catch (Exception e) {
            logger.error("查询有效的证书异常：", e);
            return CtResApiResult.fail("查询有效的证书失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 点击显示关联的证书
     *
     * @param request
     * @return
     */
    @RequestMapping(value = {"/getRelationCertificateByReport"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getRelationCertificateByReport(HttpServletRequest request) {
        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("selectRecord"));
            String masterId = dataJson.getString("masterId");
            String certificateIds = dataJson.getString("certificateIds");
            return CtResApiResult.success(ctCertificateListService.getRelationCertificateByReport(Long.valueOf(masterId), certificateIds));
        } catch (Exception e) {
            logger.error("查询关联的证书异常：", e);
            return CtResApiResult.fail("查询关联的证书失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 上传文件
     *
     * @param request
     * @param response
     * @throws Exception
     */

    @RequestMapping(value = "/uploadFile", method = {
            RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public void uploadFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        org.json.JSONObject result = new org.json.JSONObject();
        List<String> pathList = new ArrayList<String>();
        try {
            String fileColumnId = request.getParameter("fileColumnId");
            String fileColumnName = request.getParameter("fileColumnName");
            String branchId = request.getParameter("branchId");
            String uploadTableName = request.getParameter("uploadTableName");
            WTProperties wtproperty = WTProperties.getLocalProperties();
            String filePath = wtproperty.getProperty("wt.home") + File.separator + "CtFile" + File.separator + "sampleConfirmation" + File.separator + branchId + File.separator + fileColumnName + File.separator;// 临时路经
            String fileName = "";
            List<String> fileNameList = CtCertificateHelper.getFileNameAndUpload(filePath, request);//实现上传文件至服务器
            for (int i = 0; i < fileNameList.size(); i++) {
                fileName = fileNameList.get(i);
                File file = new File(filePath + File.separator + fileName);//获取服务器文件
                String fileNameApp = CtCertificateHelper.uploadFiles(file, branchId, fileColumnName);
                String fileNameInTable = ctCertificateListService.getFileNameInTable(fileColumnId, fileColumnName, uploadTableName);
                if (CtFormatUtil.hasContent(fileNameInTable)) {
                    fileNameApp = fileNameInTable + ";;;qqq" + fileNameApp;
                }
                ctCertificateListService.updateFileNameInTable(uploadTableName, fileColumnId, fileColumnName, fileNameApp);
            }

            String imgs = JSONObject.toJSONString(pathList);
            result.put("imgs", imgs);
            result.put("success", true);
            result.put("msg", "导入成功");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "导入失败");
        } finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toJSONString());
    }

    /**
     * 下载附件
     *
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/downLoadDoc", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public static void downLoadDoc(HttpServletRequest request, HttpServletResponse response) throws Exception {
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
        String branchId = request.getParameter("branchId");
        String fileName = request.getParameter("fileName");
        String fileColumnName = request.getParameter("fileColumnName");
        OutputStream out = null;
        InputStream in = null;
        try {
            if (CtFormatUtil.hasContent(branchId) && CtFormatUtil.hasContent(fileName)) {
                ApplicationData appData = CtCertificateHelper.getApplicationData(branchId, fileName,fileColumnName);
                if (appData != null) {
                    String userAgent = request.getHeader("User-Agent");
                    response.setContentType("application/octet-stream");
                    if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                        //ie
                        fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                    } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                        //edge
                        fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
                    } else {
                        // //firefox、chrome、safari、opera：
                        fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
                    }
                    //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
                    response.setCharacterEncoding("UTF-8");
                    response.setContentType("application/octet-stream");
                    response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
                    response.setCharacterEncoding("UTF-8");

                    //获取文件输入流
                    in = ContentServerHelper.service.findContentStream(appData);
                    int len = 0;
                    byte[] buffer = new byte[10240];
                    out = response.getOutputStream();
                    while ((len = in.read(buffer)) > 0) {
                        //将缓冲区的数据输出到客户端浏览器
                        out.write(buffer, 0, len);
                    }
                    result.put("success", true);
                    result.put("msg", "下载成功！");
                } else {
                    result.put("success", false);
                    result.put("msg", "No attachments to be found in the document!");// 文档中没找到需要下载的附件！
                }
            } else {
                result.put("success", false);
                result.put("msg", "Required parameters cannot be empty!");// 必传参数不能为空！
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "Download failed, background abnormal information:" + e.getLocalizedMessage());// 下载失败，后台异常信息：
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out1 = response.getWriter();
        out1.write(result.toString());
    }

    /**
     * 下载所有附件
     *
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/downLoadAllDoc", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public static void downLoadAllDoc(HttpServletRequest request, HttpServletResponse response) throws Exception {
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
        String branchId = request.getParameter("branchId");
        String fileName = request.getParameter("fileName");
        String fileColumnName = request.getParameter("fileColumnName");

        // 使用 split 方法按照分隔符 ";;;qqq" 将字符串分割成数组
        String[] arr = fileName.split(";;;qqq");

        // 将数组转换为列表
        List<String> list = Arrays.asList(arr);

        OutputStream out = null;

        try {
            if (CtFormatUtil.hasContent(branchId) && CtFormatUtil.hasContent(fileName)) {

                fileName = "全部文件压缩包" + System.currentTimeMillis() + ".zip";
                String userAgent = request.getHeader("User-Agent");
                response.setContentType("application/octet-stream");
                if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                    //ie
                    fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                    //edge
                    fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
                } else {
                    // //firefox、chrome、safari、opera：
                    fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
                }
                response.setCharacterEncoding("UTF-8");
                response.setContentType("application/octet-stream");
                response.setCharacterEncoding("UTF-8");
                response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", fileName));

                // 创建一个字节数组输出流，用于存放打包后的 ZIP 数据
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                try (ZipOutputStream zos = new ZipOutputStream(baos)) {
                    // 将压缩包中的文件逐个添加到 ZIP 输出流中
                    for (String name : list) {
                        ApplicationData appData = CtCertificateHelper.getApplicationData(branchId, name,fileColumnName);
                        if (appData != null) {
                            // 获取文件输入流
                            InputStream in = ContentServerHelper.service.findContentStream(appData);
                            // 添加文件到 ZIP 输出流中
                            CtCommonLogic.addFileToZip(name, in, zos);
                            if (in != null) {
                                in.close();
                            }
                        } else {
                            // 处理文件不存在的情况
                            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                            //response.getWriter().println("No attachments to be found in the document!");
                            throw new WTException("文件名：" + name + "在附件中已经不存在，请联系管理员处理！");
                        }
                    }
                    // 关闭 ZIP 输出流
                    zos.close();
                } catch (Exception e) {
                    e.printStackTrace();
                    result.put("success", false);
                    result.put("msg", "下载失败" + e.getLocalizedMessage());// 下载失败，后台异常信息：
                }

                // 将打包后的 ZIP 数据写入 HttpServletResponse 输出流
                OutputStream os = response.getOutputStream();
                baos.writeTo(os);
                os.flush();
                result.put("success", true);
                result.put("msg", "下载成功！");
            } else {
                result.put("success", false);
                result.put("msg", "必传参数不能为空!");// 必传参数不能为空！
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "下载异常:" + e.getLocalizedMessage());// 下载失败，后台异常信息：
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out1 = response.getWriter();
        out1.write(result.toString());
    }

    /**
     * 删除附件
     */
    @RequestMapping(value = "/deleteFiles", method = RequestMethod.POST)
    public void deleteFiles(HttpServletRequest request, HttpServletResponse response) throws Exception {
        cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String param = IOUtils.toString(reader);
            JSONObject json = JSONObject.parseObject(param);
            String branchId = json.getString("branchId");
            String fileName = json.getString("fileName");
            String fileColumnId = json.getString("fileColumnId");
            String fileColumnName = json.getString("fileColumnName");
            String uploadTableName = json.getString("uploadTableName");

            //删除附件
            CtCertificateHelper.deleteFiles(branchId, fileName,fileColumnName);

            String fileNames = ctCertificateListService.getFileNameInTable(fileColumnId, fileColumnName, uploadTableName);
            if (CtFormatUtil.hasContent(fileNames)) {
                String[] array = fileNames.split(";;;qqq");
                //转换为集合
                List<String> list = new ArrayList<>(Arrays.asList(array));
                //去除集合中指定字符串，重新拼接
                String fileNameFinal = list.stream()
                        .filter(s -> !s.equals(fileName))  // 过滤掉指定的字符串
                        .collect(Collectors.joining(";;;qqq"));
                ctCertificateListService.updateFileNameInTable(uploadTableName, fileColumnId, fileColumnName, fileNameFinal);
            }


            result.put("success", true);
            result.put("msg", fileName + "删除成功！");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            result.put("success", false);
            result.put("msg", "删除附件异常信息：\r\n" + error);
        } finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(null != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    /**
     * 查询文档名称
     *
     * @return
     */
    @GetMapping(value = "/searchFileName", produces = "application/json;charset=UTF-8")
    public CtResApiResult searchFileName(@RequestParam("fileColumnId") String fileColumnId, @RequestParam("fileColumnName") String fileColumnName,
                                         @RequestParam("uploadTableName") String uploadTableName) {
        List<HashMap<String, String>> fileNameList = new ArrayList<>();
        try {
            String fileNames = ctCertificateListService.getFileNameInTable(fileColumnId, fileColumnName, uploadTableName);
            if (CtFormatUtil.hasContent(fileNames)) {
                String[] array = fileNames.split(";;;qqq");

                for (int i = 0; i < array.length; i++) {
                    String fileName = array[i];
                    HashMap<String, String> hm = new HashMap<>();
                    hm.put("fileName", fileName);
                    fileNameList.add(hm);
                }
                //List<String> fileNameList = new ArrayList<>(Arrays.asList(array));
                //return CtResApiResult.success(fileNameList);
            }
            return CtResApiResult.success(fileNameList);
        } catch (Exception e) {
            logger.error("查询文档名称异常：", e);
            return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
        }
    }


    /**
     * 下载文件
     * @param masterId
     * @param viewName 如果下载选中的传:select;如果下载生效的传:effective
     * @param selectedIds 选中证书条目的id，用英文逗号分隔
     * @return
     */
    @RequestMapping(value = "/exportZipFile", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public CtResApiResult exportZipFile(String masterId, String branchId, String viewName, String selectedIds) {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            //生成zip
            String fileName = CtCertificateHelper.createDownloadFile(Long.valueOf(masterId), Long.valueOf(branchId), selectedIds, viewName);
            URLFactory urlFactory = new URLFactory();
            String url = urlFactory.getBaseHREF() + "fileDownload_temp/downloadPartInfoAndRefDoc/" + fileName;
            return CtResApiResult.success(url);
        } catch (Exception e) {
            logger.error("下载文件的压缩包:", e);
            return CtResApiResult.fail(e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 查询认证类型
     * @param partNumber
     * @return
     */
    @RequestMapping(value = "/getTypeByPartNumber", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public CtResApiResult getTypeByPartNumber(String partNumber) {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            List<Map<String, String>> list = ctCertificateListService.getTypeByPartNumber(partNumber);
            return CtResApiResult.success(list);
        } catch (Exception e) {
            logger.error("查询认证类型异常:", e);
            return CtResApiResult.fail(e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 复制认证数据
     * @param
     * @return
     */
    @RequestMapping(value = "/copyCertificateData", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public CtResApiResult copyCertificateData(String id, String masterId, String branchId) {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            ctCertificateListService.copyCertificateData(id, Long.valueOf(masterId), Long.valueOf(branchId));
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("复制认证数据异常:", e);
            return CtResApiResult.fail(e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

}
