package ext.plm.doc.certificate.controller;

import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtResApiResult;
import ext.plm.doc.certificate.bo.CtReportChecklistBo;
import ext.plm.doc.certificate.service.CtReportChecklistService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wt.pom.Transaction;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/ext/plm/doc/certificate/reportChecklist")
public class CtReportChecklistController {

    static Logger logger = Logger.getLogger(CtReportChecklistController.class);

    @Autowired
    private CtReportChecklistService ctReportChecklistService;

    /**
     * 增加报告清单
     *
     * @param request
     * @return
     */
    @RequestMapping(value = {"/addReportChecklistData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult addReportChecklistData(HttpServletRequest request) {
        try {
            String masterId = request.getParameter("masterId");
            String branchId = request.getParameter("branchId");
            ctReportChecklistService.insertReportChecklist(Long.valueOf(masterId), Long.valueOf(branchId));
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("增加报告清单异常：", e);
            return CtResApiResult.fail("增加报告清单失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 删除报告清单
     *
     * @param ids
     * @return
     * @throws Exception
     */
    @DeleteMapping(value = "/deleteReportChecklistData")
    public CtResApiResult deleteReportChecklistData(@RequestBody List<String> ids) {
        Transaction ts = null;
        try {
            ts = new Transaction();
            ts.start();
            ctReportChecklistService.deleteReportChecklistData(ids);
            ts.commit();
            ts = null;
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("删除报告清单异常：", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }finally{
            if (ts != null) {
                ts.rollback();
            }
        }
    }

    /**
     * 修改报告清单
     *
     * @param request
     * @return
     */
    @RequestMapping(value = {"/updateReportChecklistData"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult updateReportChecklistData(HttpServletRequest request) {
        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("updateRecord"));
            String id = dataJson.getString("id");
            String key = dataJson.getString("key");
            String value = dataJson.getString("value");
            return CtResApiResult.success(ctReportChecklistService.updateReportChecklistData(id, key, value));
        } catch (Exception e) {
            logger.error("更新报告清单异常：", e);
            return CtResApiResult.fail("修改数据库失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询报告清单
     *
     * @param masterId
     * @param ids
     * @param ids
     * @return
     */
    @GetMapping(value = "/getReportChecklistData", produces = "application/json;charset=UTF-8")
    public CtResApiResult getReportChecklistData(Long masterId, @RequestParam(value = "ids", required = false) String ids, @RequestParam(value = "certificateIds", required = false) String certificateIds
            , @RequestParam(value = "effective", required = false) String effective) {
        try {
            return CtResApiResult.success(ctReportChecklistService.getReportChecklistData(masterId, ids, certificateIds, effective));
        } catch (Exception e) {
            logger.error("查询报告清单异常：", e);
            return CtResApiResult.fail("查询报告清单失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 通过id查询报告
     *
     * @param ids
     * @return
     */
    @GetMapping(value = "/getReportById", produces = "application/json;charset=UTF-8")
    public CtResApiResult getReportById(String ids) {
        try {
            return CtResApiResult.success(ctReportChecklistService.getReportById(ids));
        } catch (Exception e) {
            logger.error("通过id查询报告异常：", e);
            return CtResApiResult.fail("通过id查询报告失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询有效的报告
     *
     * @param masterId
     * @return
     */
    @GetMapping(value = "/getEffectiveReport", produces = "application/json;charset=UTF-8")
    public CtResApiResult getEffectiveReport(Long masterId) {
        try {
            return CtResApiResult.success(ctReportChecklistService.getEffectiveReport(masterId));
        } catch (Exception e) {
            logger.error("查询有效的报告异常：", e);
            return CtResApiResult.fail("查询有效的报告失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 点击显示关联的报告
     *
     * @param request
     * @return
     */
    @RequestMapping(value = {"/getRelationReportByCertificate"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getRelationReportByCertificate(HttpServletRequest request) {
        try {
            JSONObject dataJson = JSONObject.parseObject(request.getParameter("selectRecord"));
            String masterId = dataJson.getString("masterId");
            String certificateIds = dataJson.getString("certificateIds");
            return CtResApiResult.success(ctReportChecklistService.getRelationReportByCertificate(Long.valueOf(masterId), certificateIds));
        } catch (Exception e) {
            logger.error("查询关联的报告异常：", e);
            return CtResApiResult.fail("查询关联的报告失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }


}
