package ext.plm.doc.certificate;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.doc.certificate.bo.*;
import ext.plm.doc.certificate.mapper.*;
import ext.plm.ec.CtEcLogic;
import ext.plm.report.part.CtPartReportHelper;
import ext.plm.util.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.StringUtils;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;
import wt.content.*;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.org.WTUser;
import wt.session.SessionHelper;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.lang.reflect.Field;
import java.io.InputStream;
import java.net.InetAddress;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.*;

public class CtCertificateHelper {
    /**
     * 上传文件到临时文件夹
     *
     * @return
     * @throws Exception
     */
    public static List<String> getFileNameAndUpload(String temppath, HttpServletRequest request) throws Exception {
        List<String> fileNameList = new ArrayList<>();
        String fileName = "";
        File fpath = new File(temppath);
        if (!fpath.exists()) {
            InetAddress inetAddress = InetAddress.getLocalHost();
            String host = inetAddress.getHostName(); // 获取本地的主机名
            if (!host.contains("tan") && !host.contains("plmlocal")) {
                Runtime.getRuntime().exec("chmod 777 -R " + temppath);
            }
            fpath.getParentFile().mkdirs();//创建父级文件路径
            fpath.mkdirs();//创建文件
        }
        //定时一个月清理文件
        long delete = 720 * 3600 * 1000;
        CtFileUtil.deleteFileByTime(fpath, delete);

        File file = null;
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        List<FileItem> items = upload.parseRequest(request);
        Iterator<FileItem> it = items.iterator();


        while (it.hasNext()) {

            FileItem item = (FileItem) it.next();
            fileName = item.getName();
            File tFile = new File(fileName); // 借助此File获得不带本地路径的文件名
            fileName = tFile.getName();
            tFile = null; // 释放
            file = new File(temppath + fileName);

            file.createNewFile();//创建新的文件至服务器目录

            item.write(file);//把文件写入file
            System.out.println(file.createNewFile());
            fileNameList.add(fileName);
        }
        return fileNameList;
    }

    /**
     * 拼接文件路径
     *
     * @param localFile
     * @param branchId
     * @return
     * @throws Exception
     */
    public static String uploadFiles(File localFile, String branchId,String columnName)
            throws Exception {
        String fileNameApp = "";
        String docVr = "VR:wt.doc.WTDocument:" + branchId;
        WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
        if (null != doc&&!"certificateFile".equals(columnName)) {
            //设置附件
            ApplicationData appData = ApplicationData.newApplicationData(doc);
            appData.setRole(ContentRoleType.SECONDARY);// 附件位置
            appData = ContentServerHelper.service.updateContent(doc, appData, localFile.getAbsolutePath());
            appData = (ApplicationData) PersistenceHelper.manager.save(appData);
            String fileNameAppOld = appData.getFileName();
            //fileNameApp = CtEcLogic.urlStr2Ascii(fileNameAppOld); // 特殊字符处理
            fileNameApp = fileNameAppOld;
        }
        if("certificateFile".equals(columnName)){
            //删除需要被覆盖的文档主内容
            ApplicationData primaryData = CtDocUtil.getPrimaryContent(doc);
            if(primaryData != null) {
                System.out.println("删除文档主内容");
                ContentServerHelper.service.deleteContent(doc, primaryData);
            }
            ApplicationData appDataIn = ApplicationData.newApplicationData(doc);
            appDataIn.setRole(ContentRoleType.PRIMARY);
            appDataIn.setFileName(localFile.getName());
            ContentServerHelper.service.updateContent(doc, appDataIn,localFile.getAbsolutePath());
            appDataIn = (ApplicationData) PersistenceHelper.manager.save(appDataIn);
            String fileNameAppOld = appDataIn.getFileName();
            //fileNameApp = CtEcLogic.urlStr2Ascii(fileNameAppOld);
            fileNameApp = fileNameAppOld;
        }
        return fileNameApp;
    }

    /**
     * 取得applicationData
     *
     * @param branchId
     * @param fileName
     * @return
     * @throws Exception
     */
    public static ApplicationData getApplicationData(String branchId, String fileName,String columnName) throws Exception {
        ReferenceFactory rf = new ReferenceFactory();
        String docVr = "VR:wt.doc.WTDocument:" + branchId;
        WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
        //WTDocument doc = CtDocUtil.getDocumentByNumber(docNumber);
        if (null != doc&&!"certificateFile".equals(columnName)) {
            // 单个主要内容  ContentRoleType.PRIMARY  附件 ContentRoleType.SECONDARY
            QueryResult qr = ContentHelper.service.getContentsByRole(doc, ContentRoleType.SECONDARY);
            while (qr != null && qr.hasMoreElements()) {
                ContentItem item = (ContentItem) qr.nextElement();
                if (item instanceof ApplicationData) {
                    ApplicationData appData = (ApplicationData) item;
                    System.out.println("Attachment File: " + appData.getFileName());
                    String appDataFileName = appData.getFileName();
                    if (CtFormatUtil.hasContent(appDataFileName) && appDataFileName.equals(fileName)) {
                        return appData;
                    }
                }
            }
        }
        if("certificateFile".equals(columnName)){
            ApplicationData primaryData = CtDocUtil.getPrimaryContent(doc);
            if(primaryData != null) {
                return primaryData;
            }
        }
        return null;
    }

    /**
     * 删除文档附件
     *
     * @param branchId
     * @throws Exception
     */
    public static void deleteFiles(String branchId, String fileName,String columnName) throws Exception {
        ReferenceFactory rf = new ReferenceFactory();
        String docVr = "VR:wt.doc.WTDocument:" + branchId;
        WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
        if(!"certificateFile".equals(columnName)) {
            // 单个主要内容  ContentRoleType.PRIMARY  附件 ContentRoleType.SECONDARY
            QueryResult qr = ContentHelper.service.getContentsByRole(doc, ContentRoleType.SECONDARY);
            while (qr != null && qr.hasMoreElements()) {
                ContentItem item = (ContentItem) qr.nextElement();
                if (item instanceof ApplicationData) {
                    ApplicationData appData = (ApplicationData) item;
                    System.out.println("Attachment File: " + appData.getFileName());
                    String appDataFileName = appData.getFileName();
                    if (CtFormatUtil.hasContent(appDataFileName) && appDataFileName.equals(fileName)) {
                        appData = (ApplicationData) PersistenceHelper.manager.delete(appData);
                    }
                }
            }
        }
        if("certificateFile".equals(columnName)){
            //删除需要被覆盖的文档主内容
            ApplicationData primaryData = CtDocUtil.getPrimaryContent(doc);
            if(primaryData != null) {
                System.out.println("删除文档主内容");
                ContentServerHelper.service.deleteContent(doc, primaryData);
            }
            primaryData = (ApplicationData) PersistenceHelper.manager.save(primaryData);
        }
        PersistenceHelper.manager.refresh(doc);
    }

    public static void setFieldValue(Object object, String fieldName, String value) throws Exception {
        Field field = object.getClass().getDeclaredField(fieldName);
        field.setAccessible(true); // 使私有字段可访问
        if ("java.util.Date".equals(field.getType().getName())) {
            if(CtFormatUtil.hasContent(value)){
                field.set(object, strTransferToDate(value));
            }else{
                field.set(object, null);
            }
        }else{
            field.set(object, value);
        }
    }

    /**
     * 字符串转时间
     *
     * @param str 2024-07-11T00:00:00
     * @return
     */
    private static Date strTransferToDate(String str) throws Exception{
        LocalDateTime localDateTime = LocalDateTime.parse(str);
        // 假设我们使用UTC时区
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of("UTC"));
        // 将ZonedDateTime转换为Date
        Date date = Date.from(zonedDateTime.toInstant());
        return date;
    }

    /**
     * 取得压纹文件的临时目录
     *
     * @return
     * @throws Exception
     */
    private static String getSaveFolderPath() throws Exception {
        String folderPath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator + "fileDownload_temp"
                + File.separator + "downloadPartInfoAndRefDoc";
        File folder = new File(folderPath);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        //清理7天之前的文件
        CtFileUtil.deleteFileByTime(folder, 7 * 3600 * 24 * 1000);
        return folderPath;
    }

    /**
     * 生成压缩文件
     *
     * @param masterId
     * @param currentBranchId
     * @param selectedIds 选中的id
     * @param viewName    如果下载选中的传:select;如果下载生效的传:effective
     * @return
     * @throws Exception
     */
    public static String createDownloadFile(Long masterId, Long currentBranchId, String selectedIds, String viewName) throws Exception {
        String fileName = "";
        ZipOutputStream zos = null;
        try {
            //当前用户
            WTUser curUser = (WTUser) SessionHelper.manager.getPrincipal();
            String currUserName = curUser.getName();
            //日期
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
            dateFormat.setTimeZone(TimeZone.getTimeZone(CtConstant.TIMEZONE_FORMAT));
            String dateString = dateFormat.format(new Date());
            //拼文件名
            String docName = "证书管理导出文件";
            WTDocument currentDoc = (WTDocument) CtWTObjectUtil.getObjectByOid("VR:wt.doc.WTDocument:" + currentBranchId);
            if (null != currentDoc) {
                docName = currentDoc.getName();
            }
            String formatName = currUserName + "_" + docName + "_" + dateString + ".zip";

            String saveFolderPath = getSaveFolderPath();
            String filePath = saveFolderPath + File.separator + formatName;
            File file = new File(filePath);
            if (!file.exists()) {
                file.createNewFile();
            }
            zos = new ZipOutputStream(file);
            zos.setEncoding("utf-8");
            byte[] buf = new byte[1024];

            //如果是下载选中的证书条目的文件
            List<String> selectedIdList = new ArrayList<>();
            if ("select".equals(viewName) && CtFormatUtil.hasContent(selectedIds)) {
                String[] idArray = selectedIds.split(",");
                selectedIdList = Arrays.asList(idArray);
            }

            //证书
            CtCertificateListMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificateListMapper.class);
            List<CtCertificateListBo> ctCertificateListBoList = mapper.selectList(new EntityWrapper<CtCertificateListBo>()
                    .eq(("masterId"), masterId));
            WTDocument doc = null;
            if (CtFormatUtil.hasContent(ctCertificateListBoList)) {
                for (CtCertificateListBo ctCertificateListBo : ctCertificateListBoList) {
                    Long branchId = ctCertificateListBo.getBranchId();
                    doc = (WTDocument) CtWTObjectUtil.getObjectByOid("VR:wt.doc.WTDocument:" + branchId);
                    if (null == doc) {
                        continue;
                    }
                    //如果是下载选中的，则根据id进行筛选
                    if ("select".equals(viewName) && !selectedIdList.contains(ctCertificateListBo.getId())) {
                        continue;
                    }
                    //下载生效的
                    if ("effective".equals(viewName) && !"生效中".equals(ctCertificateListBo.getCertificateStatus())) {
                        continue;
                    }
                    String certificateState = ctCertificateListBo.getCertificateStatus();
                    if(!CtFormatUtil.hasContent(certificateState)){
                        certificateState = "证书文件";
                    }else{
                        if(!"已失效".equals(certificateState) && !"生效中".equals(certificateState)){
                            continue;
                        }
                    }

                    //证书文件
                    addSourceFile(zos, buf, certificateState, doc);

                    //电子证书
                    String electronicCertificate = ctCertificateListBo.getElectronicCertificate();
                    if (CtFormatUtil.hasContent(electronicCertificate)) {
                        String[] electronicCertificateArray = electronicCertificate.split(";;;qqq");
                        for (int i = 0; i < electronicCertificateArray.length; i++) {
                            addAttachment(zos, buf, certificateState, doc, electronicCertificateArray[i]);
                        }
                    }
                }

                //报告
                if (null != doc) {
                    //取最新版本
                    doc = CtDocUtil.getDocumentByNumber(doc.getNumber());
                    if(null != doc){
                        CtReportChecklistMapper reportMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportChecklistMapper.class);
                        List<CtReportChecklistBo> ctReportChecklistBoList = reportMapper.selectList(new EntityWrapper<CtReportChecklistBo>()
                                .eq(("masterId"), masterId));
                        if (CtFormatUtil.hasContent(ctReportChecklistBoList)) {
                            for (CtReportChecklistBo ctReportChecklistBo : ctReportChecklistBoList) {
                                //如果是下载选中的，则根据id进行筛选
                                if ("select".equals(viewName) && !selectedIdList.contains(ctReportChecklistBo.getId())) {
                                    continue;
                                }
                                //下载生效的
                                if ("effective".equals(viewName) && !"生效中".equals(ctReportChecklistBo.getReportStatus())) {
                                    continue;
                                }

                                //检验报告文件
                                String reportFile = ctReportChecklistBo.getReportFile();
                                if (CtFormatUtil.hasContent(reportFile)) {
                                    String[] reportFileArray = reportFile.split(";;;qqq");
                                    for (int i = 0; i < reportFileArray.length; i++) {
                                        addAttachment(zos, buf, ctReportChecklistBo.getReportStatus(), doc, reportFileArray[i]);
                                    }
                                }
                                //特性文件表文件
                                String featureFiles = ctReportChecklistBo.getFeatureFiles();
                                if (CtFormatUtil.hasContent(featureFiles)) {
                                    String[] featureFilesArray = featureFiles.split(";;;qqq");
                                    for (int i = 0; i < featureFilesArray.length; i++) {
                                        addAttachment(zos, buf, ctReportChecklistBo.getReportStatus(), doc, featureFilesArray[i]);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fileName = file.getName();
            zos.close();
            zos = null;
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        } finally {
            if (zos != null) {
                zos.close();
            }
        }
        return fileName;
    }

    /**
     * 源文件
     * 只需要下载关联文档相关文件
     *
     * @param zos
     * @param buf
     * @param o
     * @throws Exception
     */
    private static void addSourceFile(ZipOutputStream zos, byte[] buf, String number, Object o) throws Exception {
        if (o instanceof WTDocument) {
            WTDocument doc = (WTDocument) o;
            ApplicationData data = CtDocUtil.getPrimaryContent(doc);
            if (null == data) {
                return;
            }
            InputStream is = ContentServerHelper.service.findContentStream(data);
            if (is != null) {
                String filePath = setFilePath(number, data.getFileName());
                addFileToZip(zos, buf, filePath, is);
            }
        }
    }

    /**
     * 拼接压缩文件条目路径
     *
     * @param number
     * @param fileName
     * @return
     * @throws Exception
     */
    public static String setFilePath(String number, String fileName) throws Exception {
        StringBuilder filePath = new StringBuilder();
        filePath.append(number).append("/").append(fileName);
        return filePath.toString();
    }

    /**
     * 将文件添加到压缩包中
     *
     * @param zos
     * @param buf
     * @param fileName
     * @param is
     * @throws Exception
     */
    private static void addFileToZip(ZipOutputStream zos, byte[] buf, String fileName, InputStream is) throws Exception {
        zos.putNextEntry(new ZipEntry(fileName));
        zos.setEncoding("utf-8");
        int len = 0;
        while ((len = is.read(buf)) >= 0) {
            zos.write(buf, 0, len);
        }
    }

    /**
     * 添加附件到压缩文件
     *
     * @param zos
     * @param buf
     * @param number
     * @param o
     * @param fileName
     * @throws Exception
     */
    private static void addAttachment(ZipOutputStream zos, byte[] buf, String number, Object o, String fileName) throws Exception {
        if (o instanceof WTDocument) {
            WTDocument doc = (WTDocument) o;
            ContentHolder contentHolder = ContentHelper.service.getContents(doc);
            QueryResult qr = ContentHelper.service.getContentsByRole(contentHolder, ContentRoleType.SECONDARY);
            while (qr != null && qr.hasMoreElements()) {
                ContentItem item = (ContentItem) qr.nextElement();
                if (item instanceof ApplicationData) {
                    ApplicationData appData = (ApplicationData) item;
                    String appDataFileName = appData.getFileName();
                    System.out.println(">>>>>addAttachment fileName:" + fileName);
                    System.out.println(">>>>>addAttachment appDataFileName:" + appDataFileName);
                    appDataFileName = CtEcLogic.urlStr2Ascii(appDataFileName); // 特殊字符处理
                    if (!fileName.equals(appDataFileName)) {
                        continue;
                    }
                    InputStream is = ContentServerHelper.service.findContentStream(appData);
                    if (is != null) {
                        String filePath = setFilePath(number, appData.getFileName());
                        addFileToZip(zos, buf, filePath, is);
                    }
                }
            }
        }
    }

    /**
     * 1. 自动填充，如果所有关联证书的状态均为已失效，则显示已失效，否则显示生效中
     * 2. 如果该文档表单没有证书记录，则根据报告有效期进行判断
     * @param masterId
     * @throws Exception
     */
    public static void updateReportState(Long masterId) throws Exception {
        //先把证书的状态放在map中
        Map<String, String> certificateStateMap = new HashMap<>();
        CtCertificateListMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificateListMapper.class);
        List<CtCertificateListBo> certificateList = mapper.selectList(new EntityWrapper<CtCertificateListBo>().eq("MASTERID", masterId));
        for(CtCertificateListBo ctCertificateListBo : certificateList){
            certificateStateMap.put(ctCertificateListBo.getId(), ctCertificateListBo.getCertificateStatus());
        }
        //查询所有报告   再判断报告对应的证书，是否全为“已失效”状态
        CtReportChecklistMapper reportMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportChecklistMapper.class);
        List<CtReportChecklistBo> reportList = reportMapper.selectList(new EntityWrapper<CtReportChecklistBo>().eq("MASTERID", masterId));
        CtReportLinkMapper linkMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportLinkMapper.class);
        for(CtReportChecklistBo ctReportChecklistBo : reportList){
            //通过报告查询关联的证书
            List<CtReportLinkBo> linkList = linkMapper.selectList(new EntityWrapper<CtReportLinkBo>().eq("REPORTID", ctReportChecklistBo.getId()));
            if(CtFormatUtil.hasContent(linkList)){
                //如果有关联的证书
                boolean flag = false;
                for(CtReportLinkBo linkBo : linkList){
                    String state = certificateStateMap.get(linkBo.getCertificateId());
                    if("生效中".equals(state)){
                        flag = true;
                        break;
                    }
                }
                //设置报告的状态
                if(flag){
                    ctReportChecklistBo.setReportStatus("生效中");
                }else{
                    ctReportChecklistBo.setReportStatus("已失效");
                }
            }else{
                //如果没关联的证书，则通过报告有效期进行判断
                Date validityDate = ctReportChecklistBo.getValidityDate();
                if(null != validityDate){
                    Long currentTime = new Date().getTime();
                    if(currentTime > validityDate.getTime()){
                        ctReportChecklistBo.setReportStatus("已失效");
                    }else{
                        ctReportChecklistBo.setReportStatus("生效中");
                    }
                }
            }
            reportMapper.updateById(ctReportChecklistBo);
        }
    }

    /**
     * 校验表单必填字段
     * @param masterId
     * @throws Exception
     */
    public static void checkMandatoryField(Long masterId) throws Exception {
        Set<String> result = new HashSet<>();
        //型号表
        CtModelLinkMapper modelLinkMapper = CtBeanFactory.newCtBeanFactory().getBean(CtModelLinkMapper.class);
        CtModelListMapper ctModelListMapper = CtBeanFactory.newCtBeanFactory().getBean(CtModelListMapper.class);
        List<CtModelListBo> modelList = ctModelListMapper.selectList(new EntityWrapper<CtModelListBo>().eq("MASTERID", masterId));
        for(CtModelListBo bo : modelList){
            if(!CtFormatUtil.hasContent(bo.getProductModel())){
                result.add("产品型号");
            }
            if(!CtFormatUtil.hasContent(bo.getProductName())){
                result.add("产品名称");
            }
        }
        //证书表
        CtCertificateListMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificateListMapper.class);
        List<CtCertificateListBo> certificateList = mapper.selectList(new EntityWrapper<CtCertificateListBo>().eq("MASTERID", masterId));
        CtReportChecklistMapper ctReportChecklistMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportChecklistMapper.class);
        List<CtReportChecklistBo> reportList = ctReportChecklistMapper.selectList(new EntityWrapper<CtReportChecklistBo>().eq("MASTERID", masterId));
        CtReportLinkMapper ctReportLinkMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportLinkMapper.class);
        for(CtCertificateListBo bo : certificateList){
            if(!CtFormatUtil.hasContent(bo.getCertificationType())){
                result.add("认证类型");
            }
            List<CtModelLinkBo> modelLinkList = modelLinkMapper.selectList(new EntityWrapper<CtModelLinkBo>().eq("MASTERID", masterId).eq("certificateId", bo.getId()));
            if(!CtFormatUtil.hasContent(modelLinkList)){
                result.add("产品型号");
            }
            if(!CtFormatUtil.hasContent(bo.getCertificateNumber())){
                result.add("证书编号");
            }
            if(!CtFormatUtil.hasContent(bo.getObtainingCertificateDate())){
                result.add("获得证书日期");
            }
//            if(!CtFormatUtil.hasContent(bo.getCertificateExpirationDate())){
//                result.add("证书到期日期");
//            }
            if(!CtFormatUtil.hasContent(bo.getIdentityInformationType())){
                result.add("身份信息类型");
            }
            if(!CtFormatUtil.hasContent(bo.getCertificationMark())){
                result.add("认证标识");
            }
            //认证标识不为“无”时，标识编号必填
            if(!CtFormatUtil.hasContent(bo.getIdentificationNumber())){
                if(CtFormatUtil.hasContent(bo.getCertificationMark())){
                    if(!"无".equals(bo.getCertificationMark())){
                        result.add("标识编号");
                    }
                }else{
                    result.add("标识编号");
                }
            }
            if(!CtFormatUtil.hasContent(bo.getWhetherToCancel())){
                result.add("状态选择");
            }
            if(!CtFormatUtil.hasContent(bo.getCertificateFile())){
                result.add("证书文件");
            }
            //有报告时，才校验报告编号必填
            if(CtFormatUtil.hasContent(reportList)){
                Wrapper<CtReportLinkBo> entityWrapper = new EntityWrapper<CtReportLinkBo>().eq("MASTERID", masterId).eq("certificateId", bo.getId());
                List<CtReportLinkBo> ctReportLinkList = ctReportLinkMapper.selectList(entityWrapper);
                if(!CtFormatUtil.hasContent(ctReportLinkList)){
                    result.add("关联报告编号");
                }
            }
        }
        //报告表
        for(CtReportChecklistBo bo : reportList){
            if(!CtFormatUtil.hasContent(bo.getReportType())){
                result.add("检验报告类型");
            }
            if(!CtFormatUtil.hasContent(bo.getProductModel())){
                result.add("产品型号");
            }
            if(!CtFormatUtil.hasContent(bo.getReportNumber())){
                result.add("检验报告编号");
            }
//            if(!CtFormatUtil.hasContent(bo.getValidityDate())){
//                result.add("报告有效期");
//            }
            if(!CtFormatUtil.hasContent(bo.getReportFile())){
                result.add("检验报告文件");
            }
        }
        //成品表
        CtProductApplicabilityMapper ctProductApplicabilityMapper = CtBeanFactory.newCtBeanFactory().getBean(CtProductApplicabilityMapper.class);
        List<CtProductApplicabilityBo> productList = ctProductApplicabilityMapper.selectList(new EntityWrapper<CtProductApplicabilityBo>().eq("MASTERID", masterId));
        for(CtProductApplicabilityBo bo : productList){
            if(!CtFormatUtil.hasContent(bo.getProductNumber())){
                result.add("成品编码");
            }
            if(!CtFormatUtil.hasContent(bo.getProductModel())){
                result.add("产品型号");
            }
            if(!CtFormatUtil.hasContent(bo.getApplicableCertificates())){
                result.add("是否适用证书");
            }
        }
        //履历表
        CtUpdateResumeMapper ctUpdateResumeMapper = CtBeanFactory.newCtBeanFactory().getBean(CtUpdateResumeMapper.class);
        List<CtUpdateResumeBo> resumeList = ctUpdateResumeMapper.selectList(new EntityWrapper<CtUpdateResumeBo>().eq("MASTERID", masterId));
        for(CtUpdateResumeBo bo : resumeList){
            if(!CtFormatUtil.hasContent(bo.getUpdateResume())){
                result.add("更新履历");
            }
        }
        if (result.size() > 0){
            throw new WTException("表单以下字段必填：\r\n"+ StringUtils.join(result, "、"));
        }
    }

}
