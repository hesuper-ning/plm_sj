package ext.plm.doc.certificate;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import ext.plm.bean.CtBeanFactory;
import ext.plm.doc.certificate.bo.CtCertificateListBo;
import ext.plm.doc.certificate.bo.CtModelLinkBo;
import ext.plm.doc.certificate.bo.CtModelListBo;
import ext.plm.doc.certificate.mapper.CtCertificateListMapper;
import ext.plm.doc.certificate.mapper.CtModelLinkMapper;
import ext.plm.doc.certificate.mapper.CtModelListMapper;
import ext.plm.util.CtFormatUtil;
import org.apache.log4j.Logger;
import wt.doc.WTDocument;
import wt.fc.WTObject;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Author: heqingbo
 * @Date: 2024/7/15 21:34
 * @Description:
 */
public class CtCertificateWfPlugin {

    static Logger logger = Logger.getLogger(CtCertificateWfPlugin.class);

    /**
     * 提交时，校验证书数据
     * @param object
     * @throws Exception
     */
    //ext.plm.doc.certificate.CtCertificateWfPlugin.checkCertificateData(primaryBusinessObject);
    public static void checkCertificateData(WTObject object) throws Exception {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try{
            if(object instanceof WTDocument){
                WTDocument doc = (WTDocument) object;
                Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();

                //校验必填字段
                CtCertificateHelper.checkMandatoryField(masterId);

                CtCertificateListMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificateListMapper.class);
                List<CtCertificateListBo> boList = mapper.selectList(new EntityWrapper<CtCertificateListBo>()
                        .eq(("masterId"), masterId));
                int i = 0;
                for(CtCertificateListBo bo : boList){
                    if("勘误".equals(bo.getWhetherToCancel())){
                        throw new Exception("“状态选择”为勘误时，不能提交！");
                    }
                    if("生效中".equals(bo.getCertificateStatus())){
                        i++;
                    }
                    if("注销".equals(bo.getWhetherToCancel())){
                        if(!CtFormatUtil.hasContent(bo.getExpirationDate()) || !CtFormatUtil.hasContent(bo.getCancelResume())){
                            throw new Exception("“状态选择”为注销时，“注销日期”和“注销履历”为必填！");
                        }
                    }
                }
                if(i > 1){
                    throw new Exception("只能有一条“生效中”的证书数据，请修改后再提交！");
                }


                /**
                 * 1. 根据最新“生效中”的证书自动填写 是 / 否，即如果该型号如果在生效中证书的产品型号清单中，则显示是，否则显示否；
                 */
                CtModelListMapper ctModelListMapper = CtBeanFactory.newCtBeanFactory().getBean(CtModelListMapper.class);
                List<String> productModelList = new ArrayList<>();
                List<CtModelListBo> cttModelListBoList = new ArrayList<>();
                String certificateId = "";
                for(CtCertificateListBo bo : boList){
                    if("生效中".equals(bo.getCertificateStatus())){
                        certificateId = bo.getId();
                    }
                }
                //先查询link集合
                CtModelLinkMapper ctModelLinkMapper = CtBeanFactory.newCtBeanFactory().getBean(CtModelLinkMapper.class);
                List<CtModelLinkBo> ctModelLinkBooList = ctModelLinkMapper.selectList(new EntityWrapper<CtModelLinkBo>().eq(("certificateId"), certificateId));
                //收集reportId
                List<String> modelIdList = new ArrayList<>();
                for(CtModelLinkBo ctModelLinkBo : ctModelLinkBooList){
                    modelIdList.add(ctModelLinkBo.getModelId());
                }
                //通过reportId查数据
                if(CtFormatUtil.hasContent(modelIdList)){
                    cttModelListBoList = ctModelListMapper.selectList(new EntityWrapper<CtModelListBo>().in(("id"), modelIdList).orderBy("createTime", true));
                }
                if(CtFormatUtil.hasContent(cttModelListBoList)) {
                    for(CtModelListBo ctModelLinkBo : cttModelListBoList){
                        productModelList.add(ctModelLinkBo.getProductModel());
                    }
                }
                List<CtModelListBo> ctModelListBoList = ctModelListMapper.selectList(new EntityWrapper<CtModelListBo>().eq(("masterId"), masterId));
                for(CtModelListBo ctModelListBo : ctModelListBoList){
                    if(productModelList.contains(ctModelListBo.getProductModel())){
                        ctModelListBo.setApplicable("是");
                    }else{
                        ctModelListBo.setApplicable("否");
                    }
                    ctModelListMapper.updateById(ctModelListBo);
                }
            }
        } catch (Exception e) {
            logger.error("校验证书表单数据异常：", e);
            throw new WTException("校验证书表单数据异常，异常信息：" + e.getMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

}
