package ext.plm.doc.certificate;

import ext.plm.common.CtConstant;
import ext.plm.doc.certificate.bo.CtCertificateListBo;
import wt.method.MethodContext;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CtCertificateListQuery {
    /**
     * 根据产品型号查认证类型
     * @return
     * @throws Exception
     */
    public List<Map<String, String>> getTypeByProductModel(String productModel) throws Exception {
        List<Map<String, String>> certificationTypeList = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "SELECT c.CERTIFICATIONTYPE FROM ZModelListTable t, ZMODELLINKTABLE z, ZCertificateListTable c WHERE 1=1" +
                    " AND t.ID = z.MODELID AND z.CERTIFICATEID = c.ID" +
                    " AND t.APPLICABLE = '是'" +
                    " AND t.PRODUCTMODEL = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, productModel);
            result = statement.executeQuery();
            while (result.next()) {
                Map<String, String> certificationTypeMap = new HashMap<>();
                String certificationType = result.getString(1);
                certificationTypeMap.put("certificationType", certificationType);
                certificationTypeList.add(certificationTypeMap);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return certificationTypeList;
    }


}
