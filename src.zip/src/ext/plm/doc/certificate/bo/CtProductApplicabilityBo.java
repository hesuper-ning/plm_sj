package ext.plm.doc.certificate.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

/**
 * 相关成品适用性
 */
@TableName("ZProductApplicabilityTable")
public class CtProductApplicabilityBo extends CtCertificateCommonBo{
    //成品编码
    @TableField("PRODUCTNUMBER")
    private String productNumber;
    //成品描述
    @TableField("PRODUCTDESC")
    private String productDesc;
    //产品型号
    @TableField("PRODUCTMODEL")
    private String productModel;
    //是否适用证书
    @TableField("APPLICABLECERTIFICATES")
    private String applicableCertificates;
    //说明
    @TableField("EXPLAIN")
    private String explain;

    public CtProductApplicabilityBo() {}

    public CtProductApplicabilityBo(Long masterId, Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setMasterId(masterId);
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getProductModel() {
        return productModel;
    }

    public void setProductModel(String productModel) {
        this.productModel = productModel;
    }

    public String getApplicableCertificates() {
        return applicableCertificates;
    }

    public void setApplicableCertificates(String applicableCertificates) {
        this.applicableCertificates = applicableCertificates;
    }

    public String getExplain() {
        return explain;
    }

    public void setExplain(String explain) {
        this.explain = explain;
    }
}
