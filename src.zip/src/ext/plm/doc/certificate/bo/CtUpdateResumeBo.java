package ext.plm.doc.certificate.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

/**
 * 更新履历
 */
@TableName("ZUpdateResumeTable")
public class CtUpdateResumeBo extends CtCertificateCommonBo{
    //更新日期
    @TableField("UPDATEDATE")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date updateDate;
    //更新人员
    @TableField("UPDATEPERSONNEL")
    private String updatePersonnel;
    //更新履历
    @TableField("UPDATERESUME")
    private String updateResume;

    public CtUpdateResumeBo() {}

    public CtUpdateResumeBo(Long masterId, Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setMasterId(masterId);
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdatePersonnel() {
        return updatePersonnel;
    }

    public void setUpdatePersonnel(String updatePersonnel) {
        this.updatePersonnel = updatePersonnel;
    }

    public String getUpdateResume() {
        return updateResume;
    }

    public void setUpdateResume(String updateResume) {
        this.updateResume = updateResume;
    }
}
