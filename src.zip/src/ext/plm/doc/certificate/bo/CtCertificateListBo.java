package ext.plm.doc.certificate.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

/**
 * 证书清单
 */
@TableName("ZCertificateListTable")
public class CtCertificateListBo extends CtCertificateCommonBo{
    //证书状态
    @TableField("CERTIFICATESTATUS")
    private String certificateStatus;
    //认证类型
    @TableField("CERTIFICATIONTYPE")
    private String certificationType;
    //产品型号
    @TableField("PRODUCTMODEL")
    private String productModel;
    //证书编号
    @TableField("CERTIFICATENUMBER")
    private String certificateNumber;
    //首次发证日期
    @TableField("FIRSTISSUANCEDATE")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date firstIssuanceDate;
    //获得证书日期
    @TableField("OBTAININGCERTIFICATEDATE")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date obtainingCertificateDate;
    //证书到期日期
    @TableField("CERTIFICATEEXPIRATIONDATE")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date certificateExpirationDate;
    //关联报告编号
    @TableField("RELATEDREPORTNUMBER")
    private String relatedReportNumber;
    //证书文件
    @TableField("CERTIFICATEFILE")
    private String certificateFile;
    //电子证书
    @TableField("ELECTRONICCERTIFICATE")
    private String electronicCertificate;
    //存档类型
    @TableField("ARCHIVETYPE")
    private String archiveType;
    //状态选择
    @TableField("WHETHERTOCANCEL")
    private String whetherToCancel;
    //注销日期
    @TableField("EXPIRATIONDATE")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date expirationDate;
    //注销履历
    @TableField("CANCELRESUME")
    private String cancelResume;
    //身份信息类型
    @TableField("IDENTITYINFORMATIONTYPE")
    private String identityInformationType;
    //认证标识
    @TableField("CERTIFICATIONMARK")
    private String certificationMark;
    //标识编号
    @TableField("IDENTIFICATIONNUMBER")
    private String identificationNumber;
    //生产企业
    @TableField("MANUFACTURINGENTERPRISE")
    private String manufacturingEnterprise;

    public CtCertificateListBo() {}

    public CtCertificateListBo(Long masterId, Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setMasterId(masterId);
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getCertificateStatus() {
        return certificateStatus;
    }

    public void setCertificateStatus(String certificateStatus) {
        this.certificateStatus = certificateStatus;
    }

    public String getCertificationType() {
        return certificationType;
    }

    public void setCertificationType(String certificationType) {
        this.certificationType = certificationType;
    }

    public String getProductModel() {
        return productModel;
    }

    public void setProductModel(String productModel) {
        this.productModel = productModel;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public Date getFirstIssuanceDate() {
        return firstIssuanceDate;
    }

    public void setFirstIssuanceDate(Date firstIssuanceDate) {
        this.firstIssuanceDate = firstIssuanceDate;
    }

    public Date getObtainingCertificateDate() {
        return obtainingCertificateDate;
    }

    public void setObtainingCertificateDate(Date obtainingCertificateDate) {
        this.obtainingCertificateDate = obtainingCertificateDate;
    }

    public Date getCertificateExpirationDate() {
        return certificateExpirationDate;
    }

    public void setCertificateExpirationDate(Date certificateExpirationDate) {
        this.certificateExpirationDate = certificateExpirationDate;
    }

    public String getRelatedReportNumber() {
        return relatedReportNumber;
    }

    public void setRelatedReportNumber(String relatedReportNumber) {
        this.relatedReportNumber = relatedReportNumber;
    }

    public String getCertificateFile() {
        return certificateFile;
    }

    public void setCertificateFile(String certificateFile) {
        this.certificateFile = certificateFile;
    }

    public String getElectronicCertificate() {
        return electronicCertificate;
    }

    public void setElectronicCertificate(String electronicCertificate) {
        this.electronicCertificate = electronicCertificate;
    }

    public String getArchiveType() {
        return archiveType;
    }

    public void setArchiveType(String archiveType) {
        this.archiveType = archiveType;
    }

    public String getWhetherToCancel() {
        return whetherToCancel;
    }

    public void setWhetherToCancel(String whetherToCancel) {
        this.whetherToCancel = whetherToCancel;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getCancelResume() {
        return cancelResume;
    }

    public void setCancelResume(String cancelResume) {
        this.cancelResume = cancelResume;
    }

    public String getIdentityInformationType() {
        return identityInformationType;
    }

    public void setIdentityInformationType(String identityInformationType) {
        this.identityInformationType = identityInformationType;
    }

    public String getCertificationMark() {
        return certificationMark;
    }

    public void setCertificationMark(String certificationMark) {
        this.certificationMark = certificationMark;
    }

    public String getManufacturingEnterprise() {
        return manufacturingEnterprise;
    }

    public void setManufacturingEnterprise(String manufacturingEnterprise) {
        this.manufacturingEnterprise = manufacturingEnterprise;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }
}
