package ext.plm.doc.certificate.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

/**
 * 证书与报告的关联
 */
@TableName("ZReportLinkTable")
public class CtReportLinkBo extends CtCertificateCommonBo{
    //证书id
    @TableField("CERTIFICATEID")
    private String certificateId;
    //报告id
    @TableField("REPORTID")
    private String reportId;

    public CtReportLinkBo() {}

    public CtReportLinkBo(Long masterId, Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setMasterId(masterId);
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getCertificateId() {
        return certificateId;
    }

    public void setCertificateId(String certificateId) {
        this.certificateId = certificateId;
    }

    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }
}
