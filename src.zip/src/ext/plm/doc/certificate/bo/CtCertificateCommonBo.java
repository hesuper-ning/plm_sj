package ext.plm.doc.certificate.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;



public abstract class CtCertificateCommonBo implements Serializable {

    @TableId(type = IdType.INPUT)
    @TableField("ID")
    private String id;

    @TableField("MASTERID")
    private Long masterId;;  //文档masterId

    @TableField("BRANCHID")
    private Long branchId;;  //文档branchId

    @TableField("CREATETIME")
    private Date createTime;//创建时间

    @TableField("CREATEUSER")
    private String createUser;//创建用户

    @TableField("MODIFYTIME")
    private Date modifyTime;//修改时间

    @TableField("MODIFYUSER")
    private String modifyUser;//修改用户

    public CtCertificateCommonBo(){}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Long getBranchId() {
        return branchId;
    }

    public void setBranchId(Long branchId) {
        this.branchId = branchId;
    }

    public Long getMasterId() {
        return masterId;
    }

    public void setMasterId(Long masterId) {
        this.masterId = masterId;
    }
}
