package ext.plm.doc.certificate.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

/**
 * 报告清单
 */
@TableName("ZReportChecklistTable")
public class CtReportChecklistBo extends CtCertificateCommonBo{
    //报告状态
    @TableField("REPORTSTATUS")
    private String reportStatus;
    //检验报告类型
    @TableField("REPORTTYPE")
    private String reportType;
    //产品型号
    @TableField("PRODUCTMODEL")
    private String productModel;
    //检验报告编号
    @TableField("REPORTNUMBER")
    private String reportNumber;
    //产品标准
    @TableField("PRODUCTSTANDARDS")
    private String productStandards;
    //报告签发日期
    @TableField("ISSUANCEDATE")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date issuanceDate;
    //报告有效期
    @TableField("VALIDITYDATE")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date validityDate;
    //关联证书编号
    @TableField(exist = false)
    private String certificateNumber;
    //检验报告文件
    @TableField("REPORTFILE")
    private String reportFile;
    //特性文件表文件
    @TableField("FEATUREFILES")
    private String featureFiles;
    //状态选择
    @TableField("WHETHERTOCANCEL")
    private String whetherToCancel;

    public CtReportChecklistBo() {}

    public CtReportChecklistBo(Long masterId, Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setMasterId(masterId);
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getReportStatus() {
        return reportStatus;
    }

    public void setReportStatus(String reportStatus) {
        this.reportStatus = reportStatus;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getProductModel() {
        return productModel;
    }

    public void setProductModel(String productModel) {
        this.productModel = productModel;
    }

    public String getReportNumber() {
        return reportNumber;
    }

    public void setReportNumber(String reportNumber) {
        this.reportNumber = reportNumber;
    }

    public String getProductStandards() {
        return productStandards;
    }

    public void setProductStandards(String productStandards) {
        this.productStandards = productStandards;
    }

    public Date getIssuanceDate() {
        return issuanceDate;
    }

    public void setIssuanceDate(Date issuanceDate) {
        this.issuanceDate = issuanceDate;
    }

    public Date getValidityDate() {
        return validityDate;
    }

    public void setValidityDate(Date validityDate) {
        this.validityDate = validityDate;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getReportFile() {
        return reportFile;
    }

    public void setReportFile(String reportFile) {
        this.reportFile = reportFile;
    }

    public String getFeatureFiles() {
        return featureFiles;
    }

    public void setFeatureFiles(String featureFiles) {
        this.featureFiles = featureFiles;
    }

    public String getWhetherToCancel() {
        return whetherToCancel;
    }

    public void setWhetherToCancel(String whetherToCancel) {
        this.whetherToCancel = whetherToCancel;
    }
}
