package ext.plm.doc.certificate.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

/**
 * 证书与型号的关联
 */
@TableName("ZModelLinkTable")
public class CtModelLinkBo extends CtCertificateCommonBo{
    //证书id
    @TableField("CERTIFICATEID")
    private String certificateId;
    //型号id
    @TableField("MODELID")
    private String modelId;

    public CtModelLinkBo() {}

    public CtModelLinkBo(Long masterId, Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setMasterId(masterId);
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getCertificateId() {
        return certificateId;
    }

    public void setCertificateId(String certificateId) {
        this.certificateId = certificateId;
    }

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String modelId) {
        this.modelId = modelId;
    }
}
