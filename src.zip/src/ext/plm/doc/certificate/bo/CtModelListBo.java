package ext.plm.doc.certificate.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

/**
 * 相关型号清单
 */
@TableName("ZModelListTable")
public class CtModelListBo extends CtCertificateCommonBo{
    //产品型号
    @TableField("PRODUCTMODEL")
    private String productModel;
    //产品名称
    @TableField("PRODUCTNAME")
    private String productName;
    //是否依然适用
    @TableField("APPLICABLE")
    private String applicable;

    public CtModelListBo() {}

    public CtModelListBo(Long masterId, Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setMasterId(masterId);
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getProductModel() {
        return productModel;
    }

    public void setProductModel(String productModel) {
        this.productModel = productModel;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getApplicable() {
        return applicable;
    }

    public void setApplicable(String applicable) {
        this.applicable = applicable;
    }
}
