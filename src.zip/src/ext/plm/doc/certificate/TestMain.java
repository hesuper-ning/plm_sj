package ext.plm.doc.certificate;

import cn.hutool.core.io.FileUtil;
import com.sun.naming.internal.VersionHelper;
import ext.plm.bean.CtBeanFactory;
import ext.plm.doc.certificate.bo.*;
import ext.plm.doc.certificate.mapper.*;
import ext.plm.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.fc.QueryResult;
import wt.httpgw.GatewayAuthenticator;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.vc.VersionControlHelper;

import java.io.File;
import java.io.InputStream;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class TestMain implements Serializable, RemoteAccess {

    public static void main(String[] args) throws Exception {
        if (!RemoteMethodServer.ServerFlag) {
            Class[] cls = new Class[]{String[].class};
            Object[] obj = new Object[]{args};

            try {
                RemoteMethodServer server = RemoteMethodServer.getDefault();
                GatewayAuthenticator authenticator = new GatewayAuthenticator();
                authenticator.setRemoteUser("wcadmin");
                server.setAuthenticator(authenticator);
                server.invoke("main", TestMain.class.getName(), null, cls, obj);
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //windchill ext.plm.doc.certificate.TestMain /home/ptc/Windchill_11.0/Windchill/codebase/exportTemp/docNumber.xlsx
        System.out.println(">>>>>Authentication historical data process 准备执行:");
        dealDoc(args[0]);
    }

    /**
     * 读取excel中需要刷的文档编号
     * @param path
     * @throws Exception
     */
    public static void dealDoc(String path) throws Exception {
        System.out.println(">>>>>Authentication historical data process start!");
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        File filePath = new File(path);
        if(filePath == null){
            throw new Exception("路径或文件错误！找不到此路径或文件："+path);
        }
        InputStream is = FileUtil.getInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(is);
        Sheet sheet = workbook.getSheetAt(0);
        System.out.println(">>>>>Authentication historical data process 读取excel第一页");
        CtModelListMapper modelMapper = CtBeanFactory.newCtBeanFactory().getBean(CtModelListMapper.class);
        CtReportLinkMapper linkMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportLinkMapper.class);
        CtModelLinkMapper linkMapper1 = CtBeanFactory.newCtBeanFactory().getBean(CtModelLinkMapper.class);
        CtCertificateListMapper certificateMapper = CtBeanFactory.newCtBeanFactory().getBean(CtCertificateListMapper.class);
        CtReportChecklistMapper reportMapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportChecklistMapper.class);
        CtUpdateResumeMapper resumeMapper = CtBeanFactory.newCtBeanFactory().getBean(CtUpdateResumeMapper.class);
        //获取认证类型的枚举
        Map<String, String> authenticationTypeEnumMap = CtPartUtil.getEnumMap("ct_AuthenticationType");
        //获取报告类型的枚举
        Map<String, String> reportTypeEnumMap = CtPartUtil.getEnumMap("ct_bglx");
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String docNumber = CtExcelReadUtil.getCellFormatValue(row.getCell(0), row, 0);
            System.out.println(">>>>>Authentication historical data process 当前在刷的文档编号:" + docNumber);
            WTDocument doc = CtDocUtil.getDocumentByNumber(docNumber);
            if(null != doc){
                dealData(doc, dateFormat, modelMapper, linkMapper, linkMapper1, certificateMapper, reportMapper, resumeMapper, authenticationTypeEnumMap, reportTypeEnumMap);
            }else{
                System.out.println(">>>>>Authentication historical data process 当前在刷的文档编号找不到对应的文档:" + docNumber);
            }
        }
    }

    /**
     * 找到A版本的最新小版本
     * @param doc
     * @return
     * @throws Exception
     */
    private static WTDocument getVersionA(WTDocument doc) throws Exception {
        QueryResult queryResult = VersionControlHelper.service.allVersionsOf(doc.getMaster());
        while (queryResult.hasMoreElements()) {
            WTDocument docVersion = (WTDocument)queryResult.nextElement();
            String version = docVersion.getVersionInfo().getIdentifier().getValue();
            if (version.contains("A")) {
                return docVersion;
            }
        }
        return null;
    }

    /**
     * 将iba中存的数据，刷到表格中
     * @param doc
     * @param dateFormat
     * @param modelMapper
     * @param linkMapper
     * @param linkMapper1
     * @param certificateMapper
     * @param reportMapper
     * @param resumeMapper
     * @throws Exception
     */
    private static void dealData(WTDocument doc, DateFormat dateFormat, CtModelListMapper modelMapper,
        CtReportLinkMapper linkMapper, CtModelLinkMapper linkMapper1, CtCertificateListMapper certificateMapper,
                                 CtReportChecklistMapper reportMapper, CtUpdateResumeMapper resumeMapper
            , Map<String, String> authenticationTypeEnumMap, Map<String, String> reportTypeEnumMap) throws Exception {
        IBAUtil ibaUtil = new IBAUtil(doc);

        //型号表
        List<CtModelListBo> modelBoList = saveModel(doc, modelMapper);

        //注销履历
        String docState = doc.getLifeCycleState().getDisplay(Locale.CHINA);
        String cancellationResume = dealString(ibaUtil.getIBAValue("ct_CancellationResume"));
        if(CtFormatUtil.hasContent(cancellationResume) && !"停用".equals(docState)){
            String versionValue = doc.getVersionInfo().getIdentifier().getValue();
            if(!versionValue.contains("A")){
                WTDocument docA = getVersionA(doc);
                //证书表
                CtCertificateListBo ctCertificateListBo = saveCertificate(docA, dateFormat, cancellationResume, certificateMapper, authenticationTypeEnumMap);
                //报告表
                String certificateStatus = "";
                if(null != ctCertificateListBo){
                    certificateStatus = ctCertificateListBo.getCertificateStatus();
                }
                List<CtReportChecklistBo> reportList = saveReport(docA, dateFormat, certificateStatus, reportMapper, reportTypeEnumMap);
                //证书与报告关联表
                saveLink(linkMapper, ctCertificateListBo, reportList, docA);
                //证书与型号关联表
                saveLink1(linkMapper1, ctCertificateListBo, modelBoList, docA);
            }
        }
        //证书表
        CtCertificateListBo ctCertificateListBo = saveCertificate(doc, dateFormat, "", certificateMapper, authenticationTypeEnumMap);
        //报告表
        String certificateStatus = "";
        if(null != ctCertificateListBo){
            certificateStatus = ctCertificateListBo.getCertificateStatus();
        }
        List<CtReportChecklistBo> reportList = saveReport(doc, dateFormat, certificateStatus, reportMapper, reportTypeEnumMap);
        //证书与报告关联表
        saveLink(linkMapper, ctCertificateListBo, reportList, doc);
        //证书与型号关联表
        saveLink1(linkMapper1, ctCertificateListBo, modelBoList, doc);

        //履历表
        saveUpdateResume(resumeMapper, doc);
    }

    /**
     * 保存更改履历
     * @param resumeMapper
     * @param doc
     * @return
     * @throws Exception
     */
    private static CtUpdateResumeBo saveUpdateResume(CtUpdateResumeMapper resumeMapper, WTDocument doc) throws Exception {
        Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
        Long branchId = doc.getBranchIdentifier();
        CtUpdateResumeBo ctUpdateResumeBo = new CtUpdateResumeBo(masterId, branchId);
        ctUpdateResumeBo.setUpdateDate(new Date());
        ctUpdateResumeBo.setUpdatePersonnel("wcadmin");
        ctUpdateResumeBo.setUpdateResume("数据初始化");
        resumeMapper.insert(ctUpdateResumeBo);
        return ctUpdateResumeBo;
    }

    /**
     * 保存型号表
     * @param doc
     * @param modelMapper
     * @return
     * @throws Exception
     */
    private static List<CtModelListBo> saveModel(WTDocument doc, CtModelListMapper modelMapper) throws Exception {
        List<CtModelListBo> list = new ArrayList<>();
        Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
        Long branchId = doc.getBranchIdentifier();
        IBAUtility ibaUtil = new IBAUtility(doc);

        //产品型号
        Vector values = ibaUtil.getIBAValues("ct_model");
        if (CollectionUtils.isNotEmpty(values)) {
            for(int i = 0;i < values.size();i++){
                if(null != values.get(i)){
                    CtModelListBo bo = new CtModelListBo(masterId, branchId);
                    bo.setProductModel(values.get(i).toString());

                    //产品名称
                    String productName = dealString(ibaUtil.getIBAValue("ct_productName"));
                    bo.setProductName(productName);

                    //是否依然适用
                    String docState = doc.getLifeCycleState().getDisplay(Locale.CHINA);
                    if("停用".equals(docState)){
                        bo.setApplicable("否");
                    }else{
                        bo.setApplicable("是");
                    }
                    modelMapper.insert(bo);
                    list.add(bo);
                }
            }
        }
        return list;
    }

    /**
     * 保存证书表格数据
     * @param doc
     * @param dateFormat
     * @return
     * @throws Exception
     */
    private static CtCertificateListBo saveCertificate(WTDocument doc, DateFormat dateFormat, String cancelInfo
            , CtCertificateListMapper certificateMapper, Map<String, String> authenticationTypeEnumMap) throws Exception {
        Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
        Long branchId = doc.getBranchIdentifier();
        IBAUtil ibaUtil = new IBAUtil(doc);
        //证书编号
        String certificateNumber = dealString(ibaUtil.getIBAValue("ct_Certificatenumber"));
        if(!CtFormatUtil.hasContent(certificateNumber)){
            return null;
        }
        CtCertificateListBo bo = new CtCertificateListBo(masterId, branchId);


        //证书编号
        bo.setCertificateNumber(certificateNumber);

        //证书状态
        String certificateStatus = "";
        String docState = doc.getLifeCycleState().getDisplay(Locale.CHINA);
        if(CtFormatUtil.hasContent(cancelInfo) || "停用".equals(docState)){
            certificateStatus = "已失效";
        }else{
            certificateStatus = "生效中";
        }
        bo.setCertificateStatus(certificateStatus);

        //认证类型
        String certificationType = "";
        String authenticationTypeKey = ibaUtil.getIBAValue("ct_Authenticationtype");
        if(CtFormatUtil.hasContent(authenticationTypeKey)){
            certificationType = authenticationTypeEnumMap.get(authenticationTypeKey);
            if(null == certificationType){
                certificationType = "";
            }
        }
        certificationType = certificationType.replace("(停)", "");
        bo.setCertificationType(certificationType);

        //产品型号
        String productModel = dealString(ibaUtil.getIBAValue("ct_model"));
        bo.setProductModel(productModel);

        //首次发证日期
        Date firstIssuanceDate = null;
        String firstIssuanceStr = ibaUtil.getIBAValue("ct_Dateoffirstissuance");
        if(CtFormatUtil.hasContent(firstIssuanceStr)){
            firstIssuanceStr = firstIssuanceStr.substring(0, 10);
            firstIssuanceStr = firstIssuanceStr.replaceAll("/", "-");
            firstIssuanceDate = dateFormat.parse(firstIssuanceStr);
        }
        bo.setFirstIssuanceDate(firstIssuanceDate);

        //获得证书日期
        Date obtainingCertificateDate = null;
        String obtainingCertificateStr = ibaUtil.getIBAValue("ct_DateofObtainingCertificate");
        if(CtFormatUtil.hasContent(obtainingCertificateStr)){
            obtainingCertificateStr = obtainingCertificateStr.substring(0, 10);
            obtainingCertificateStr = obtainingCertificateStr.replaceAll("/", "-");
            obtainingCertificateDate = dateFormat.parse(obtainingCertificateStr);
        }
        bo.setObtainingCertificateDate(obtainingCertificateDate);

        //证书到期日期
        Date certificateExpirationDate = null;
        String certificateExpirationStr = ibaUtil.getIBAValue("ct_Certificateexpirationdate");
        if(CtFormatUtil.hasContent(certificateExpirationStr)){
            certificateExpirationStr = certificateExpirationStr.substring(0, 10);
            certificateExpirationStr = certificateExpirationStr.replaceAll("/", "-");
            certificateExpirationDate = dateFormat.parse(certificateExpirationStr);
        }
        bo.setCertificateExpirationDate(certificateExpirationDate);

        //状态选择
        String whetherToCancel = "";
        //注销日期
        Date expirationDate = null;
        //注销履历
        String cancelResume = "";
        if(CtFormatUtil.hasContent(cancelInfo) || "停用".equals(docState)){
            if(!CtFormatUtil.hasContent(cancelInfo)){
                cancelInfo = dealString(ibaUtil.getIBAValue("ct_CancellationResume"));
            }
            whetherToCancel = "注销";
            if(cancelInfo.contains("；")){
                String[] cancelInfoArray1 = cancelInfo.split("；");//中文逗号
                if(cancelInfoArray1.length == 3){
                    expirationDate = dateFormat.parse(cancelInfoArray1[0]);
                    cancelResume = cancelInfoArray1[2];
                }
            }else{
                String[] cancelInfoArray = cancelInfo.split(";");
                if(cancelInfoArray.length == 3){
                    expirationDate = dateFormat.parse(cancelInfoArray[0]);
                    cancelResume = cancelInfoArray[2];
                }
            }
        }else{
            whetherToCancel = "生效";
        }
        bo.setWhetherToCancel(whetherToCancel);
        bo.setExpirationDate(expirationDate);
        bo.setCancelResume(cancelResume);

        //身份信息类型
        String identityInformationType = dealString(ibaUtil.getIBAValue("ct_Identityinformationtype"));
        if(!CtFormatUtil.hasContent(identityInformationType)){
            identityInformationType = "不适用";
        }
        bo.setIdentityInformationType(identityInformationType);

        //认证标识
        String certificationMark = "无";
        bo.setCertificationMark(certificationMark);

        //证书文件
        String certificateFile = "";
        ApplicationData primaryData = CtDocUtil.getPrimaryContent(doc);
        if(primaryData != null) {
            certificateFile = primaryData.getFileName();
        }
        bo.setCertificateFile(certificateFile);

        //电子证书
        String electronicCertificate = getFileName(doc, "", "电子证书");
        bo.setElectronicCertificate(electronicCertificate);

        certificateMapper.insert(bo);
        return bo;
    }

    /**
     * 保存报告表格数据
     * @return
     */
    private static List<CtReportChecklistBo> saveReport(WTDocument doc, DateFormat dateFormat, String certificateState
            , CtReportChecklistMapper reportMapper, Map<String, String> reportTypeEnumMap) throws Exception {
        List<CtReportChecklistBo> list = new ArrayList<>();
        Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
        Long branchId = doc.getBranchIdentifier();
        IBAUtil ibaUtil = new IBAUtil(doc);

        for(int i = 1;i < 25;i++){
            //检验报告编号
            String ct_InspectionReportNo = "ct_" + i + "InspectionReportNo";
            if(i == 4){
                ct_InspectionReportNo = "ct_InspectionReportNo";
            }
            String reportNumber = dealString(ibaUtil.getIBAValue(ct_InspectionReportNo));

            if(CtFormatUtil.hasContent(reportNumber)){
                CtReportChecklistBo bo = new CtReportChecklistBo(masterId, branchId);
                //检验报告类型
                String ct_reportType = "ct_" + i + "reporttype";
                String reportType = dealString(ibaUtil.getIBAValue(ct_reportType));
                if(CtFormatUtil.hasContent(reportType)){
                    String reportTypeDisplay = reportTypeEnumMap.get(reportType);
                    if(CtFormatUtil.hasContent(reportTypeDisplay)){
                        bo.setReportType(reportTypeDisplay);
                    }else{
                        bo.setReportType(reportType);
                    }
                }

                //产品型号
                String ct_model = "ct_model" + i;
                String productModel = dealString(ibaUtil.getIBAValue(ct_model));
                bo.setProductModel(productModel);

                //检验报告编号
                bo.setReportNumber(reportNumber);

                //产品标准
                String ct_ProductStandard = "";
                if(i == 1){
                    ct_ProductStandard = "ct_" + i + "Productstandard";
                }else{
                    ct_ProductStandard = "ct_" + i + "ProductStandards";
                }
                String productStandards = dealString(ibaUtil.getIBAValue(ct_ProductStandard));
                bo.setProductStandards(productStandards);

                //报告签发日期
                String ct_dateofissueofthereport = "ct_" + i + "dateofissueofthereport";
                Date issuanceDate = null;
                String issuanceStr = ibaUtil.getIBAValue(ct_dateofissueofthereport);
                if(CtFormatUtil.hasContent(issuanceStr)){
                    issuanceStr = issuanceStr.substring(0, 10);
                    issuanceStr = issuanceStr.replaceAll("/", "-");
                    issuanceDate = dateFormat.parse(issuanceStr);
                }
                bo.setIssuanceDate(issuanceDate);

                //报告有效期
                String ct_reportvalidity = "ct_" + i + "reportvalidity";
                Date validityDate = null;
                String validityStr = ibaUtil.getIBAValue(ct_reportvalidity);
                if(CtFormatUtil.hasContent(validityStr)){
                    validityStr = validityStr.substring(0, 10);
                    validityStr = validityStr.replaceAll("/", "-");
                    validityDate = dateFormat.parse(validityStr);
                }
                bo.setValidityDate(validityDate);

                //报告状态
                if(CtFormatUtil.hasContent(certificateState)){
                    if("生效中".equals(certificateState)){
                        bo.setReportStatus("生效中");
                    }else{
                        bo.setReportStatus("已失效");
                    }
                }else{
                    //如果没有证书，则根据报告有效期判断报告状态
                    if(null != validityDate){
                        if(validityDate.getTime() >= new Date().getTime()){
                            bo.setReportStatus("生效中");
                        }else{
                            bo.setReportStatus("已失效");
                        }
                    }else{
                        //如果报告有效期也为空，则根据文档的状态判断
                        String docState = doc.getLifeCycleState().getDisplay(Locale.CHINA);
                        if("停用".equals(docState)){
                            bo.setReportStatus("已失效");
                        }else{
                            bo.setReportStatus("生效中");
                        }
                    }
                }

                //检验报告文件
                String reportFile = getFileName(doc, reportNumber, "报告文件");
                bo.setReportFile(reportFile);

                //特性文件表文件
                String featureFiles = getFileName(doc, reportNumber, "特性文件");
                bo.setFeatureFiles(featureFiles);

                reportMapper.insert(bo);
                list.add(bo);
            }
        }
        return list;
    }

    /**
     * 保存证书与报告关联
     * @param linkMapper
     * @param ctCertificateListBo
     * @param reportList
     */
    private static void saveLink(CtReportLinkMapper linkMapper, CtCertificateListBo ctCertificateListBo, List<CtReportChecklistBo> reportList, WTDocument doc) throws Exception {
        if(null == ctCertificateListBo){
            return;
        }
        Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
        Long branchId = doc.getBranchIdentifier();
        String certificateId = ctCertificateListBo.getId();
        for(CtReportChecklistBo ctReportChecklistBo : reportList){
            CtReportLinkBo link = new CtReportLinkBo(masterId, branchId);
            link.setCertificateId(certificateId);
            link.setReportId(ctReportChecklistBo.getId());
            linkMapper.insert(link);
        }
    }

    /**
     * 保存证书与型号关联
     * @param linkMapper1
     * @param ctCertificateListBo
     * @param modelBoList
     */
    private static void saveLink1(CtModelLinkMapper linkMapper1, CtCertificateListBo ctCertificateListBo, List<CtModelListBo> modelBoList, WTDocument doc) throws Exception {
        if(null == ctCertificateListBo){
            return;
        }
        for(CtModelListBo modelBo : modelBoList){
            Long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
            Long branchId = doc.getBranchIdentifier();
            CtModelLinkBo link = new CtModelLinkBo(masterId, branchId);
            link.setCertificateId(ctCertificateListBo.getId());
            link.setModelId(modelBo.getId());
            linkMapper1.insert(link);
        }
    }

    /**
     * 取得附件中的某类文件的名称
     * @param doc
     * @param reportNumber
     * @param flag
     * @return
     * @throws Exception
     */
    private static String getFileName(WTDocument doc, String reportNumber, String flag) throws Exception {
        Set<String> fileNameSet = new HashSet<>();
        QueryResult qr = ContentHelper.service.getContentsByRole(doc, ContentRoleType.SECONDARY);
        while (qr != null && qr.hasMoreElements()) {
            ContentItem item = (ContentItem) qr.nextElement();
            if (item instanceof ApplicationData) {
                ApplicationData appData = (ApplicationData) item;
                String appDataFileName = appData.getFileName();
                if(!CtFormatUtil.hasContent(appDataFileName)){
                    continue;
                }
                if ("电子证书".equals(flag) && appDataFileName.contains("电子证")) {
                    fileNameSet.add(appDataFileName);
                }
                if("特性文件".equals(flag) && appDataFileName.contains("特性文件") && CtFormatUtil.hasContent(reportNumber) && appDataFileName.contains(reportNumber)){
                    fileNameSet.add(appDataFileName);
                }
                if("报告文件".equals(flag) && !appDataFileName.contains("特性文件") && CtFormatUtil.hasContent(reportNumber) && appDataFileName.contains(reportNumber)){
                    fileNameSet.add(appDataFileName);
                }
            }
        }
        return StringUtils.join(fileNameSet, ";;;qqq");
    }

    private static String dealString(String s) throws Exception {
        if (!CtFormatUtil.hasContent(s)) {
            return "";
        }
        return s;
    }
}
