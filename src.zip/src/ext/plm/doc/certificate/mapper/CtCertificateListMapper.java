package ext.plm.doc.certificate.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.doc.certificate.bo.CtCertificateListBo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtCertificateListMapper extends BaseMapper<CtCertificateListBo> {

}
