package ext.plm.doc.certificate.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.doc.certificate.bo.CtModelListBo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtModelListMapper extends BaseMapper<CtModelListBo> {

}
