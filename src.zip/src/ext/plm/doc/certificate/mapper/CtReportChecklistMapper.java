package ext.plm.doc.certificate.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.doc.certificate.bo.CtReportChecklistBo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtReportChecklistMapper extends BaseMapper<CtReportChecklistBo> {

}
