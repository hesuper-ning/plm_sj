package ext.plm.doc.certificate.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.doc.certificate.bo.CtReportLinkBo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtReportLinkMapper extends BaseMapper<CtReportLinkBo> {

}
