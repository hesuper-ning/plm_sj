package ext.plm.doc.certificate.service;

import ext.plm.doc.certificate.bo.CtUpdateResumeBo;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtUpdateResumeService {
    //插入
    void insertUpdateResume(Long masterId, Long branchId) throws Exception;
    //查询数据
    List<CtUpdateResumeBo> getUpdateResumeData(Long masterId) throws Exception;
    //删除数据
    void deleteUpdateResumeData(List<String> ids) throws Exception;
    //更新数据
    CtUpdateResumeBo updateUpdateResumeData(String id, String key, String value) throws Exception;
}
