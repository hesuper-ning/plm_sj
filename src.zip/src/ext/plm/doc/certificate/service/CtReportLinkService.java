package ext.plm.doc.certificate.service;

import ext.plm.doc.certificate.bo.CtReportLinkBo;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtReportLinkService {
    //插入
    void batchInsertReportLink(Long masterId, Long branchId, String certificateId, List<String> reportIdList) throws Exception;
    //查询数据
    List<CtReportLinkBo> getReportLink(Long masterId, String certificateId) throws Exception;
    //查询数据
    List<CtReportLinkBo> getReportLinkByReportId(Long masterId, String reportId) throws Exception;
    List<CtReportLinkBo> getReportLinkByCertificateId(Long masterId, String certificateId) throws Exception;
    //删除数据
    void batchDeleteReportLink(List<CtReportLinkBo> ctReportLinkBo) throws Exception;
}
