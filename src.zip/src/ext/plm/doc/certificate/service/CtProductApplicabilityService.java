package ext.plm.doc.certificate.service;

import ext.plm.doc.certificate.bo.CtProductApplicabilityBo;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtProductApplicabilityService {
    //插入
    void insertProductApplicability(Long masterId, Long branchId) throws Exception;
    //查询数据
    List<CtProductApplicabilityBo> getProductApplicabilityData(Long masterId) throws Exception;
    //删除数据
    void deleteProductApplicabilityData(List<String> ids) throws Exception;
    //更新数据
    CtProductApplicabilityBo updateProductApplicabilityData(String id, String key, String value) throws Exception;
}
