package ext.plm.doc.certificate.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.bean.CtBeanFactory;
import ext.plm.doc.certificate.CtCertificateHelper;
import ext.plm.doc.certificate.CtCertificateListQuery;
import ext.plm.doc.certificate.bo.*;
import ext.plm.doc.certificate.mapper.CtCertificateListMapper;
import ext.plm.doc.certificate.mapper.CtReportChecklistMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.method.MethodContext;
import wt.part.WTPart;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

@Service
public class CtCertificateListServiceImpl extends ServiceImpl<CtCertificateListMapper, CtCertificateListBo> implements CtCertificateListService {
    @Autowired
    private CtModelListServiceImpl ctModelListServiceImpl;
    @Autowired
    private CtReportChecklistServiceImpl ctReportChecklistServiceImpl;
    @Autowired
    private CtReportLinkServiceImpl ctReportLinkServiceImpl;
    @Autowired
    private CtModelLinkServiceImpl ctModelLinkServiceImpl;

    @Override
    public void insertCertificateList(Long masterId, Long branchId) throws Exception {
        List<CtCertificateListBo> boList = super.selectList(new EntityWrapper<CtCertificateListBo>()
                .eq(("masterId"), masterId).eq(("branchId"), branchId));
        if(CtFormatUtil.hasContent(boList)){
            throw new Exception("一个大版本只能增加一行证书记录！");
        }
        CtCertificateListBo ctCertificateListBo = new CtCertificateListBo(masterId, branchId);
        super.insert(ctCertificateListBo);
    }

    @Override
    public List<CtCertificateListBo> getCertificateListData(Long masterId, String ids, String reportIds, String effective) throws Exception {
        List<CtCertificateListBo> resultList = new ArrayList<>();
        if (CtFormatUtil.hasContent(reportIds)) {
            resultList = this.getRelationCertificateByReport(masterId, reportIds);
        }
        else if("effective".equals(effective)){
            resultList = super.selectList(new EntityWrapper<CtCertificateListBo>()
                    .eq(("masterId"), masterId).eq(("certificateStatus"), "生效中").orderBy("createTime", true).orderBy("branchId", true));
        }
        else {
            Wrapper<CtCertificateListBo> wrapper = new EntityWrapper<CtCertificateListBo>()
                    .eq(("masterId"), masterId);
            if (CtFormatUtil.hasContent(ids)) {
                String[] idArray = ids.split(",");
                List<String> idList = new ArrayList<>(Arrays.asList(idArray));
                wrapper.in("id", idList);
            }
            wrapper.orderBy("createTime", true).orderBy("branchId", true);
            resultList = super.selectList(wrapper);
        }

        for(CtCertificateListBo ctCertificateListBo : resultList){
            //1：查询关联的报告
            List<CtReportLinkBo> reportLinkList = ctReportLinkServiceImpl.getReportLinkByCertificateId(masterId, ctCertificateListBo.getId());
            List<String> reportNumberList = new ArrayList<>();
            for(CtReportLinkBo linkBo : reportLinkList){
                CtReportChecklistBo queryBo = new CtReportChecklistBo();
                queryBo.setId(linkBo.getReportId());
                CtReportChecklistBo tempCtReportChecklistBo = ctReportChecklistServiceImpl.selectById(queryBo);
                if(null != tempCtReportChecklistBo){
                    if(CtFormatUtil.hasContent(tempCtReportChecklistBo.getReportNumber())){
                        reportNumberList.add(tempCtReportChecklistBo.getReportNumber());
                    }
                }
            }
            //2：给报告编号属性赋值
            ctCertificateListBo.setRelatedReportNumber(StringUtils.join(reportNumberList, ","));

            //查询关联的型号
            List<CtModelLinkBo> modelLinkList = ctModelLinkServiceImpl.getModelLink(masterId, ctCertificateListBo.getId());
            List<String> modelNumberList = new ArrayList<>();
            for(CtModelLinkBo linkBo : modelLinkList){
                CtModelListBo queryBo = new CtModelListBo();
                queryBo.setId(linkBo.getModelId());
                CtModelListBo tempCtModelListBo = ctModelListServiceImpl.selectById(queryBo);
                if(null != tempCtModelListBo){
                    if(CtFormatUtil.hasContent(tempCtModelListBo.getProductModel())){
                        modelNumberList.add(tempCtModelListBo.getProductModel());
                    }
                }
            }
            //给关联的型号属性赋值
            ctCertificateListBo.setProductModel(StringUtils.join(modelNumberList, ","));
        }
        return resultList;
    }

    @Override
    public void deleteCertificateListData(List<String> ids) throws Exception {
        //删除对象时，同时删除关联
        ctReportLinkServiceImpl.delete(new EntityWrapper<CtReportLinkBo>().in(("certificateId"), ids));
        ctModelLinkServiceImpl.delete(new EntityWrapper<CtModelLinkBo>().in(("certificateId"), ids));
        super.deleteBatchIds(ids);
    }

    /**
     * 更新数据
     * @param id
     * @param key
     * @param value
     * @return
     * @throws Exception
     */
    @Override
    public CtCertificateListBo updateCertificateListData(String id, String key, String value) throws Exception {
        if(!CtFormatUtil.hasContent(value)){
            if("firstIssuanceDate".equals(key) || "obtainingCertificateDate".equals(key)
                    || "certificateExpirationDate".equals(key) || "expirationDate".equals(key)){
                super.updateForSet(key + "=" + value, new EntityWrapper<CtCertificateListBo>().eq("id", id));
            }
        }

        CtCertificateListBo ctCertificateListBo = super.selectById(id);
        Long masterId = ctCertificateListBo.getMasterId();
        Long branchId = ctCertificateListBo.getBranchId();
        String certificateId = ctCertificateListBo.getId();
        CtCommonUtil.setObjectValue(ctCertificateListBo,key,value);
        if("relatedReportNumber".equals(key)){
            //关联报告编号
            if(CtFormatUtil.hasContent(value)){
                //通过报告编号查询报告条目
                String[] reportNumberArray = value.split(",");
                List<String> reportIdList = new ArrayList<>();
                for(int i = 0;i < reportNumberArray.length;i++){
                    List<CtReportChecklistBo> ctReportChecklistBoList = ctReportChecklistServiceImpl.selectList(new EntityWrapper<CtReportChecklistBo>()
                            .eq(("masterId"), masterId).eq(("reportNumber"), reportNumberArray[i]));
                    for(CtReportChecklistBo ctReportChecklistBo : ctReportChecklistBoList){
                        String reportId = ctReportChecklistBo.getId();
                        if(!reportIdList.contains(reportId)){
                            reportIdList.add(reportId);
                        }
                    }
                }
                //查询旧的证书与报告关联关系
                List<CtReportLinkBo> ctReportLinkBoList = ctReportLinkServiceImpl.getReportLink(masterId, certificateId);
                //删除旧的证书与报告关联关系
                ctReportLinkServiceImpl.batchDeleteReportLink(ctReportLinkBoList);
                //保存新的证书与报告关联关系
                ctReportLinkServiceImpl.batchInsertReportLink(masterId, branchId, certificateId, reportIdList);
            }
        }
        if("whetherToCancel".equals(key)){
            //状态选择
            if(CtFormatUtil.hasContent(value)){
                if("注销".equals(value) || "证书到期".equals(value)){
                    ctCertificateListBo.setCertificateStatus("已失效");
                }
                if("有效".equals(value)){
                    ctCertificateListBo.setCertificateStatus("生效中");

                    /**
                     * 1. 根据最新“生效中”的证书自动填写 是 / 否，即如果该型号如果在生效中证书的产品型号清单中，则显示是，否则显示否；
                     */
                    List<String> productModelList = new ArrayList<>();
                    List<CtModelListBo> cttModelListBoList = ctModelListServiceImpl.getModelListDataByCertificateId(masterId, certificateId);
                    if(CtFormatUtil.hasContent(cttModelListBoList)) {
                        for(CtModelListBo ctModelLinkBo : cttModelListBoList){
                            productModelList.add(ctModelLinkBo.getProductModel());
                        }
                    }
                    List<CtModelListBo> ctModelListBoList = ctModelListServiceImpl.getModelListData(ctCertificateListBo.getMasterId(), null, null, null);
                    for(CtModelListBo ctModelListBo : ctModelListBoList){
                        if(productModelList.contains(ctModelListBo.getProductModel())){
                            ctModelListBo.setApplicable("是");
                        }else{
                            ctModelListBo.setApplicable("否");
                        }
                        ctModelListServiceImpl.updateById(ctModelListBo);
                    }
                }
                if("勘误".equals(value)){
                    ctCertificateListBo.setCertificateStatus("勘误");
                }
            }
        }
        if("productModel".equals(key)){
            //产品型号
            if(CtFormatUtil.hasContent(value)){
                //通过型号查询条目
                String[] modelArray = value.split(",");
                List<String> modelIdList = new ArrayList<>();
                for(int i = 0;i < modelArray.length;i++){
                    List<CtModelListBo> ctModelLinkBoList = ctModelListServiceImpl.selectList(new EntityWrapper<CtModelListBo>()
                            .eq(("masterId"), masterId).eq(("productModel"), modelArray[i]));
                    for(CtModelListBo ctModelListBo : ctModelLinkBoList){
                        String modelId = ctModelListBo.getId();
                        if(!modelIdList.contains(modelId)){
                            modelIdList.add(modelId);
                        }
                    }
                }
                //查询旧的证书与型号关联关系
                List<CtModelLinkBo> cttModelLinkBoList = ctModelLinkServiceImpl.getModelLink(masterId, certificateId);
                //删除旧的证书与型号关联关系
                ctModelLinkServiceImpl.batchDeleteModelLink(cttModelLinkBoList);
                //保存新的证书与型号关联关系
                ctModelLinkServiceImpl.batchInsertReportLink(masterId, branchId, certificateId, modelIdList);
            }
        }
//        super.updateForSet(key + "=\'" + value + "\'", new EntityWrapper<CtCertificateListBo>().eq("id", id));
        super.updateById(ctCertificateListBo);

        //更新报告的状态
        if("whetherToCancel".equals(key) || "relatedReportNumber".equals(key)){
            CtCertificateHelper.updateReportState(masterId);
        }
        return ctCertificateListBo;
    }

    /**
     * 点击显示关联的证书
     * @param masterId
     * @param reportIds
     * @return
     * @throws Exception
     */
    @Override
    public List<CtCertificateListBo> getRelationCertificateByReport(Long masterId, String reportIds) throws Exception {
        List<CtCertificateListBo> resultList = new ArrayList<>();
        //先查询所选的报告，取得型号集合
        List<String> modelList = new ArrayList<>();
        String[] reportIdArray = reportIds.split(",");
        CtReportChecklistMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtReportChecklistMapper.class);
        for (int j = 0; j < reportIdArray.length; j++) {
            List<CtReportChecklistBo> ctReportChecklistBoList = mapper.selectList(new EntityWrapper<CtReportChecklistBo>()
                    .eq(("id"), reportIdArray[j]));
            for (CtReportChecklistBo ctReportChecklistBo : ctReportChecklistBoList) {
                String productModel = ctReportChecklistBo.getProductModel();
                String[] productModelArray = productModel.split(",");
                for (int i = 0; i < productModelArray.length; i++) {
                    if (!modelList.contains(productModelArray[i])) {
                        modelList.add(productModelArray[i]);
                    }
                }
            }
        }
        //通过型号筛选数据
        List<CtCertificateListBo> ctCertificateListBoList = super.selectList(new EntityWrapper<CtCertificateListBo>().eq(("masterId"), masterId));
        if (CtFormatUtil.hasContent(ctCertificateListBoList)) {
            for (CtCertificateListBo bo : ctCertificateListBoList) {
                String cProductModel = bo.getProductModel();
                if (!CtFormatUtil.hasContent(cProductModel)) {
                    continue;
                }
                String[] cProductModelArray = cProductModel.split(",");
                for (int z = 0; z < cProductModelArray.length; z++) {
                    if (modelList.contains(cProductModelArray[z])) {
                        resultList.add(bo);
                    }
                }
            }
        }
        return resultList;
    }

    /**
     * 通过id查询证书数据
     *
     * @param ids
     * @return
     * @throws Exception
     */
    @Override
    public List<CtCertificateListBo> getCertificateById(String ids) throws Exception {
        String[] idArray = ids.split(",");
        List<String> idList = new ArrayList<>(Arrays.asList(idArray));
        return super.selectBatchIds(idList);
    }

    /**
     * 查询有效的证书
     *
     * @param masterId
     * @return
     * @throws Exception
     */
    @Override
    public List<CtCertificateListBo> getEffectiveCertificate(Long masterId) throws Exception {
        List<CtCertificateListBo> ctCertificateListBoList = super.selectList(new EntityWrapper<CtCertificateListBo>()
                .eq(("masterId"), masterId).eq(("whetherToCancel"), "否").orderBy("createTime", true));
        return ctCertificateListBoList;
    }

    @Override
    public String getFileNameInTable(String id, String fileColumnName, String tableName) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        String fileName = "";

        String sql = "SELECT " + fileColumnName + " FROM  " + tableName + " WHERE id = ?";
        System.out.println(">>>sql==" + sql);
        statement = connection.prepareStatement(sql);
        statement.setString(1, id);
        System.out.println(">>>>>queryAllPartAttribute sql:" + sql.toString());
        rs = statement.executeQuery();
        System.out.println("@查询结束");
        int i = 0;
        while (rs.next()) {
            fileName = rs.getString(1);
        }

        return fileName;
    }

    @Override
    public void updateFileNameInTable(String uploadTableName, String fileColumnId, String fileColumnName, String value) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "update " + uploadTableName + " set  " + fileColumnName + "  = ? WHERE id = ?";
            System.out.println(">>>sql==" + sql);
            statement = connection.prepareStatement(sql);
            statement.setString(1, value);
            statement.setString(2, fileColumnId);
            statement.execute();
        } catch (Exception var12) {
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
    }

    @Override
    public List<Map<String, String>> getTypeByPartNumber(String partNumber) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        CtCertificateListQuery query = new CtCertificateListQuery();
        WTPart part = CtPartUtil.getPartByNumber(partNumber);
        if(null != part){
            IBAUtil ibaUtil = new IBAUtil(part);
            String productModel = ibaUtil.getIBAValue("ct_model");
            if(CtFormatUtil.hasContent(productModel)){
                list = query.getTypeByProductModel(productModel);
            }
        }
        return list;
    }

    /**
     * 复制功能
     * @param id
     * @param masterId
     * @param branchId
     * @throws Exception
     */
    @Override
    public void copyCertificateData(String id, Long masterId, Long branchId) throws Exception {
        List<CtCertificateListBo> boList = super.selectList(new EntityWrapper<CtCertificateListBo>()
                .eq(("masterId"), masterId).eq(("branchId"), branchId));
        if(CtFormatUtil.hasContent(boList)){
            throw new Exception("一个大版本只能增加一行证书记录！");
        }
        CtCertificateListBo ctCertificateListBo = super.selectById(id);
        CtCertificateListBo bo = new CtCertificateListBo(masterId, branchId);
        bo.setCertificationType(ctCertificateListBo.getCertificationType());
        bo.setCertificateNumber(ctCertificateListBo.getCertificateNumber());
        bo.setFirstIssuanceDate(ctCertificateListBo.getFirstIssuanceDate());
        bo.setObtainingCertificateDate(ctCertificateListBo.getObtainingCertificateDate());
        bo.setArchiveType(ctCertificateListBo.getArchiveType());
        bo.setExpirationDate(ctCertificateListBo.getExpirationDate());
        bo.setCancelResume(ctCertificateListBo.getCancelResume());
        bo.setIdentityInformationType(ctCertificateListBo.getIdentityInformationType());
        bo.setCertificationMark(ctCertificateListBo.getCertificationMark());
        bo.setIdentificationNumber(ctCertificateListBo.getIdentificationNumber());
        bo.setManufacturingEnterprise(ctCertificateListBo.getManufacturingEnterprise());
        super.insert(bo);

        //保存证书和型号的关联
        List<CtModelLinkBo> modelLinkList = ctModelLinkServiceImpl.getModelLink(masterId, ctCertificateListBo.getId());
        for(CtModelLinkBo ctModelLinkBo : modelLinkList){
            CtModelLinkBo modelLinkBo = new CtModelLinkBo(masterId, branchId);
            modelLinkBo.setCertificateId(bo.getId());
            modelLinkBo.setModelId(ctModelLinkBo.getModelId());
            ctModelLinkServiceImpl.insert(modelLinkBo);
        }

        //保存证书和报告的关联
        List<CtReportLinkBo> reportLinkList = ctReportLinkServiceImpl.getReportLink(masterId, ctCertificateListBo.getId());
        for(CtReportLinkBo ctReportLinkBo : reportLinkList){
            CtReportLinkBo reportLinkBo = new CtReportLinkBo(masterId, branchId);
            reportLinkBo.setCertificateId(bo.getId());
            reportLinkBo.setReportId(ctReportLinkBo.getReportId());
            ctReportLinkServiceImpl.insert(reportLinkBo);
        }
    }
}

