package ext.plm.doc.certificate.service;

import ext.plm.doc.certificate.bo.CtCertificateListBo;
import wt.method.RemoteInterface;

import java.util.List;
import java.util.Map;

@RemoteInterface
public interface CtCertificateListService {
    //插入
    void insertCertificateList(Long masterId, Long branchId) throws Exception;

    //查询数据
    List<CtCertificateListBo> getCertificateListData(Long masterId, String ids, String reportIds, String effective) throws Exception;

    //删除数据
    void deleteCertificateListData(List<String> ids) throws Exception;

    //更新数据
    CtCertificateListBo updateCertificateListData(String id, String key, String value) throws Exception;

    //点击显示关联的证书
    List<CtCertificateListBo> getRelationCertificateByReport(Long masterId, String reportIds) throws Exception;

    //通过id查询证书
    List<CtCertificateListBo> getCertificateById(String ids) throws Exception;

    //查询生效中的证书
    List<CtCertificateListBo> getEffectiveCertificate(Long masterId) throws Exception;

    //获取已经上传的文档名称
    String getFileNameInTable(String id, String fileColumnName, String tableName) throws Exception;

    //修改上传的文件名称
    void updateFileNameInTable(String uploadTableName, String fileColumnId, String fileColumnName, String value) throws Exception;

    //根据物料编号查认证类型
    List<Map<String, String>> getTypeByPartNumber(String partNumber) throws Exception;

    //复制
    void copyCertificateData(String id, Long masterId, Long branchId) throws Exception;
}
