package ext.plm.doc.certificate.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.doc.certificate.bo.CtModelLinkBo;
import ext.plm.doc.certificate.bo.CtModelListBo;
import ext.plm.doc.certificate.bo.CtReportChecklistBo;
import ext.plm.doc.certificate.mapper.CtModelListMapper;
import ext.plm.oaFlow.tinyAssignment.CtTinyAssignmentQuery;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.IBAUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.part.WTPart;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class CtModelListServiceImpl extends ServiceImpl<CtModelListMapper, CtModelListBo> implements CtModelListService {
    @Autowired
    private CtModelLinkServiceImpl ctModelLinkServiceImpl;
    @Autowired
    private CtReportChecklistServiceImpl ctReportChecklistServiceImpl;

    //插入数据
    @Override
    public void insertModelList(Long masterId, Long branchId) throws Exception {
        CtModelListBo bo = new CtModelListBo(masterId, branchId);
        bo.setApplicable("是");
        super.insert(bo);
    }

    //查询数据
    @Override
    public List<CtModelListBo> getModelListData(Long masterId, String ids, String certificateIds, String reportIds) throws Exception {
        List<CtModelListBo> resultList = new ArrayList<>();
        if (CtFormatUtil.hasContent(certificateIds)) {
            resultList = this.getModelListDataByCertificateId(masterId, certificateIds);
        }
        else if(CtFormatUtil.hasContent(reportIds)){
            resultList = this.getModelListDataByReportId(masterId, reportIds);
        }
        else {
            Wrapper<CtModelListBo> wrapper = new EntityWrapper<CtModelListBo>().eq(("masterId"), masterId);
            if (CtFormatUtil.hasContent(ids)) {
                String[] idArray = ids.split(",");
                List<String> idList = new ArrayList<>(Arrays.asList(idArray));
                wrapper.in("id", idList);
            }
            wrapper.orderBy("createTime", true).orderBy("branchId", true);
            resultList = super.selectList(wrapper);
        }
        return resultList;
    }

    //根据证书id查询数据
    @Override
    public List<CtModelListBo> getModelListDataByCertificateId(Long masterId, String certificateIds) throws Exception {
        //先查询link集合
        String[] certificateIdArray = certificateIds.split(",");
        List<String> certificateIdList = Arrays.asList(certificateIdArray);
        List<CtModelLinkBo> ctModelLinkBooList = ctModelLinkServiceImpl.selectList(new EntityWrapper<CtModelLinkBo>().in(("certificateId"), certificateIdList));
        //收集reportId
        List<String> modelIdList = new ArrayList<>();
        for(CtModelLinkBo ctModelLinkBo : ctModelLinkBooList){
            modelIdList.add(ctModelLinkBo.getModelId());
        }
        //通过reportId查数据
        if(CtFormatUtil.hasContent(modelIdList)){
            return super.selectList(new EntityWrapper<CtModelListBo>().in(("id"), modelIdList).orderBy("createTime", true));
        }else{
            return new ArrayList<CtModelListBo>();
        }
    }

    //根据报告id查询数据
    @Override
    public List<CtModelListBo> getModelListDataByReportId(Long masterId, String reportIds) throws Exception {
        //查询报告中的产品型号
        String[] reportIdArray = reportIds.split(",");
        List<String> reportIdList = Arrays.asList(reportIdArray);
        List<CtReportChecklistBo> ctReportChecklistBoList = ctReportChecklistServiceImpl.selectList(new EntityWrapper<CtReportChecklistBo>().in(("id"), reportIdList));
        List<String> productModelList = new ArrayList<>();
        for(CtReportChecklistBo ctReportChecklistBo : ctReportChecklistBoList){
            String productModel = ctReportChecklistBo.getProductModel();
            if(CtFormatUtil.hasContent(productModel) && !productModelList.contains(productModel)){
                productModelList.add(productModel);
            }
        }
        //查询型号清单数据
        if(CtFormatUtil.hasContent(productModelList)){
            return super.selectList(new EntityWrapper<CtModelListBo>().in(("productModel"), productModelList).orderBy("createTime", true));
        }else{
            return new ArrayList<CtModelListBo>();
        }
    }

    //删除数据
    @Override
    public void deleteModelListData(List<String> ids) throws Exception {
        super.deleteBatchIds(ids);
    }
    //更新数据
    @Override
    public CtModelListBo updateModelListData(String id, String key, String value) throws Exception {
        CtModelListBo ctModelListBo = super.selectById(id);
        //Long branchId = ctModelListBo.getBranchId();
        //super.updateById(ctModelListBo);

        //根据产品型号带出产品名称
        if("productModel".equals(key)){
            if(CtFormatUtil.hasContent(value)){
                String productName = "";
                CtTinyAssignmentQuery query = new CtTinyAssignmentQuery();
                String productTypeReplace = value.trim().replace("*", "%");
                List<WTPart> partList = query.searchPartByProductType("ct_model",productTypeReplace);
                if(CtFormatUtil.hasContent(partList)){
                    WTPart part = partList.get(0);
                    if(null != part){
                        IBAUtil ibaUtil = new IBAUtil(part);
                        productName = ibaUtil.getIBAValue("ct_Materialname");//物料名称
                    }
                }
                if(CtFormatUtil.hasContent(productName)){
                    ctModelListBo.setProductName(productName);
                    super.updateById(ctModelListBo);
                }
            }
        }
        super.updateForSet(key + "=\'" + value + "\'", new EntityWrapper<CtModelListBo>().eq("id", id));
        return ctModelListBo;
    }
}

