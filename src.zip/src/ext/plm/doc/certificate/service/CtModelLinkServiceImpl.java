package ext.plm.doc.certificate.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.doc.certificate.bo.CtModelLinkBo;
import ext.plm.doc.certificate.bo.CtReportLinkBo;
import ext.plm.doc.certificate.mapper.CtModelLinkMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CtModelLinkServiceImpl extends ServiceImpl<CtModelLinkMapper, CtModelLinkBo> implements CtModelLinkService {
    //插入数据
    @Override
    public void insertModelLink(Long masterId, Long branchId, String certificateId, String modelId) throws Exception {
        CtModelLinkBo bo = new CtModelLinkBo(masterId, branchId);
        bo.setCertificateId(certificateId);
        bo.setModelId(modelId);
        super.insert(bo);
    }
    @Override
    public void batchInsertReportLink(Long masterId, Long branchId, String certificateId, List<String> modelIdList) throws Exception {
        for(String modelId : modelIdList){
            CtModelLinkBo bo = new CtModelLinkBo(masterId, branchId);
            bo.setCertificateId(certificateId);
            bo.setModelId(modelId);
            super.insert(bo);
        }
    }
    //查询数据
    @Override
    public List<CtModelLinkBo> getModelLink(Long masterId, String certificateId) throws Exception {
        List<CtModelLinkBo> list = super.selectList(new EntityWrapper<CtModelLinkBo>()
                .eq(("masterId"), masterId).eq(("certificateId"), certificateId));
        return list;
    }
    //删除数据
    @Override
    public void deleteModelLink(CtModelLinkBo ctModelLinkBo) throws Exception {
        super.deleteById(ctModelLinkBo);
    }
    //批量删除
    @Override
    public void batchDeleteModelLink(List<CtModelLinkBo> ctModelLinkBoList) throws Exception {
        for(CtModelLinkBo ctModelLinkBo : ctModelLinkBoList){
            super.deleteById(ctModelLinkBo);
        }
    }
}

