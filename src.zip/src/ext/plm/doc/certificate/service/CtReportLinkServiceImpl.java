package ext.plm.doc.certificate.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.doc.certificate.bo.CtModelLinkBo;
import ext.plm.doc.certificate.bo.CtReportLinkBo;
import ext.plm.doc.certificate.mapper.CtModelLinkMapper;
import ext.plm.doc.certificate.mapper.CtReportLinkMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CtReportLinkServiceImpl extends ServiceImpl<CtReportLinkMapper, CtReportLinkBo> implements CtReportLinkService {
    @Override
    public void batchInsertReportLink(Long masterId, Long branchId, String certificateId, List<String> reportIdList) throws Exception {
        for(String reportId : reportIdList){
            CtReportLinkBo bo = new CtReportLinkBo(masterId, branchId);
            bo.setCertificateId(certificateId);
            bo.setReportId(reportId);
            super.insert(bo);
        }
    }

    @Override
    public List<CtReportLinkBo> getReportLink(Long masterId, String certificateId) throws Exception {
        List<CtReportLinkBo> list = super.selectList(new EntityWrapper<CtReportLinkBo>()
                .eq(("masterId"), masterId).eq(("certificateId"), certificateId));
        return list;
    }

    @Override
    public List<CtReportLinkBo> getReportLinkByReportId(Long masterId, String reportId) throws Exception {
        List<CtReportLinkBo> list = super.selectList(new EntityWrapper<CtReportLinkBo>()
                .eq(("masterId"), masterId).eq(("reportId"), reportId));
        return list;
    }

    @Override
    public List<CtReportLinkBo> getReportLinkByCertificateId(Long masterId, String certificateId) throws Exception {
        List<CtReportLinkBo> list = super.selectList(new EntityWrapper<CtReportLinkBo>()
                .eq(("masterId"), masterId).eq(("certificateId"), certificateId));
        return list;
    }

    @Override
    public void batchDeleteReportLink(List<CtReportLinkBo> ctReportLinkBoList) throws Exception {
        for(CtReportLinkBo ctReportLinkBo : ctReportLinkBoList){
            super.deleteById(ctReportLinkBo);
        }
    }
}

