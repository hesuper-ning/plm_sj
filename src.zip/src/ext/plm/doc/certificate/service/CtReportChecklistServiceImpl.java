package ext.plm.doc.certificate.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.bean.CtBeanFactory;
import ext.plm.doc.certificate.CtCertificateHelper;
import ext.plm.doc.certificate.bo.CtCertificateListBo;
import ext.plm.doc.certificate.bo.CtReportChecklistBo;
import ext.plm.doc.certificate.bo.CtReportLinkBo;
import ext.plm.doc.certificate.mapper.CtCertificateListMapper;
import ext.plm.doc.certificate.mapper.CtReportChecklistMapper;
import ext.plm.newec.mapper.CtPcnInfoMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CtReportChecklistServiceImpl extends ServiceImpl<CtReportChecklistMapper, CtReportChecklistBo> implements CtReportChecklistService {
    @Autowired
    private CtReportLinkServiceImpl ctReportLinkServiceImpl;
    @Autowired
    private CtCertificateListServiceImpl ctCertificateListServiceImpl;

    //插入数据
    @Override
    public void insertReportChecklist(Long masterId, Long branchId) throws Exception {
        CtReportChecklistBo bo = new CtReportChecklistBo(masterId, branchId);
        //默认生效中
        bo.setReportStatus("生效中");
        super.insert(bo);
    }

    //查询数据
    @Override
    public List<CtReportChecklistBo> getReportChecklistData(Long masterId, String ids, String certificateIds, String effective) throws Exception {
        List<CtReportChecklistBo> resultList = new ArrayList<>();
        if (StringUtils.isNotBlank(certificateIds)) {
            resultList = this.getRelationReportByCertificate(masterId, certificateIds);
        }
        else if("effective".equals(effective)){
            resultList = super.selectList(new EntityWrapper<CtReportChecklistBo>()
                    .eq(("masterId"), masterId).eq(("reportStatus"), "生效中").orderBy("createTime", true).orderBy("branchId", true));
        }
        else if("noEffective".equals(effective)){
            List<CtReportChecklistBo> resultList0 = super.selectList(new EntityWrapper<CtReportChecklistBo>()
                    .eq(("masterId"), masterId).eq(("reportStatus"), "生效中"));
            List<CtReportChecklistBo> resultList1 = super.selectList(new EntityWrapper<CtReportChecklistBo>()
                    .eq(("masterId"), masterId).isNull("reportStatus"));
            resultList.addAll(resultList0);
            resultList.addAll(resultList1);
        }
        else {
            Wrapper<CtReportChecklistBo> wrapper = new EntityWrapper<CtReportChecklistBo>().eq(("masterId"), masterId);
            if (StringUtils.isNotBlank(ids)) {
                String[] idArray = ids.split(",");
                List<String> idList = new ArrayList<>(Arrays.asList(idArray));
                wrapper.in("id", idList);
            }
            wrapper.orderBy("createTime", true).orderBy("branchId", true);
            resultList = super.selectList(wrapper);
        }
        //1：查询关联的证书
        for(CtReportChecklistBo ctReportChecklistBo : resultList){
            List<CtReportLinkBo> reportLinkList = ctReportLinkServiceImpl.getReportLinkByReportId(masterId, ctReportChecklistBo.getId());
            List<String> certificateNumberList = new ArrayList<>();
            for(CtReportLinkBo linkBo : reportLinkList){
                CtCertificateListBo queryBo = new CtCertificateListBo();
                queryBo.setId(linkBo.getCertificateId());
                CtCertificateListBo tempCtCertificateListBo = ctCertificateListServiceImpl.selectById(queryBo);
                if(null != tempCtCertificateListBo){
                    if(CtFormatUtil.hasContent(tempCtCertificateListBo.getCertificateNumber())){
                        if(!certificateNumberList.contains(tempCtCertificateListBo.getCertificateNumber())){
                            certificateNumberList.add(tempCtCertificateListBo.getCertificateNumber());
                        }
                    }
                }
            }
            //2：给报告的“认证编号”属性赋值
            ctReportChecklistBo.setCertificateNumber(StringUtils.join(certificateNumberList, ","));
        }
        return resultList;
    }

    //删除数据
    @Override
    public void deleteReportChecklistData(List<String> ids) throws Exception {
        //删除对象时，同时删除关联
        ctReportLinkServiceImpl.delete(new EntityWrapper<CtReportLinkBo>().in(("reportId"), ids));
        super.deleteBatchIds(ids);
    }

    //更新数据
    @Override
    public CtReportChecklistBo updateReportChecklistData(String id, String key, String value) throws Exception {
        CtReportChecklistBo ctReportChecklistBo = super.selectById(id);
        if(!CtFormatUtil.hasContent(value)){
            if("issuanceDate".equals(key) || "validityDate".equals(key)){
                super.updateForSet(key + "=" + value, new EntityWrapper<CtReportChecklistBo>().eq("id", id));
            }
        }

        if("reportNumber".equalsIgnoreCase(key)){
            if(CtFormatUtil.hasContent(value)){
                List<CtReportChecklistBo> reportList = super.selectList(new EntityWrapper<CtReportChecklistBo>().eq(("masterId"), ctReportChecklistBo.getMasterId()).eq(("reportNumber"), value));
                for(CtReportChecklistBo bo : reportList){
                    if(value.equals(bo.getReportNumber()) && !id.equals(bo.getId())){
                        throw new Exception("检验报告编号不能重复！");
                    }
                }
            }
        }

        if("whetherToCancel".equals(key)){
            //状态选择
            if(CtFormatUtil.hasContent(value)){
                if("注销".equals(value) || "证书到期".equals(value)){
                    ctReportChecklistBo.setReportStatus("已失效");
                }
                if("有效".equals(value)){
                    ctReportChecklistBo.setReportStatus("生效中");
                }
            }
        }

        CtCommonUtil.setObjectValue(ctReportChecklistBo,key,value);
        super.updateById(ctReportChecklistBo);
        //更新报告状态
        if("validityDate".equals(key)){
            CtCertificateHelper.updateReportState(ctReportChecklistBo.getMasterId());
        }
        return ctReportChecklistBo;
    }

    //点击显示关联的报告
    @Override
    public List<CtReportChecklistBo> getRelationReportByCertificate(Long masterId, String certificateIds) throws Exception {
        //先查询link集合
        String[] certificateIdArray = certificateIds.split(",");
        List<String> certificateIdList = Arrays.asList(certificateIdArray);
        List<CtReportLinkBo> ctReportLinkBoList = ctReportLinkServiceImpl.selectList(new EntityWrapper<CtReportLinkBo>().in(("certificateId"), certificateIdList));
        //收集reportId
        List<String> reportIdList = new ArrayList<>();
        for(CtReportLinkBo ctReportLinkBo : ctReportLinkBoList){
            reportIdList.add(ctReportLinkBo.getReportId());
        }
        //通过reportId查数据
        return super.selectList(new EntityWrapper<CtReportChecklistBo>().in(("id"), reportIdList).orderBy("createTime", true));
    }

    @Override
    public List<CtReportChecklistBo> getReportById(String ids) throws Exception {
        String[] idArray = ids.split(",");
        List<String> idList = new ArrayList<>(Arrays.asList(idArray));
        return super.selectBatchIds(idList);
    }

    /**
     * 查询有效的报告
     * @param masterId
     * @return
     * @throws Exception
     */
    @Override
    public List<CtReportChecklistBo> getEffectiveReport(Long masterId) throws Exception {
        List<CtReportChecklistBo> ctReportChecklistBoList = super.selectList(new EntityWrapper<CtReportChecklistBo>()
                .eq(("masterId"), masterId).le(("validityDate"), new Date()).orderBy("createTime", true));
        return ctReportChecklistBoList;
    }
}

