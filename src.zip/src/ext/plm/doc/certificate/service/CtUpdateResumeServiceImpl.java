package ext.plm.doc.certificate.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.doc.certificate.bo.CtUpdateResumeBo;
import ext.plm.doc.certificate.mapper.CtUpdateResumeMapper;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import org.springframework.stereotype.Service;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.List;

@Service
public class CtUpdateResumeServiceImpl extends ServiceImpl<CtUpdateResumeMapper, CtUpdateResumeBo> implements CtUpdateResumeService {
    //插入数据
    @Override
    public void insertUpdateResume(Long masterId, Long branchId) throws Exception {
        //校验同一大版本，只能添加一行
        List<CtUpdateResumeBo> ctUpdateResumeBoList = super.selectList(new EntityWrapper<CtUpdateResumeBo>()
                .eq(("masterId"), masterId).eq(("branchId"), branchId));
        if(CtFormatUtil.hasContent(ctUpdateResumeBoList)){
            throw new Exception("当时版本只能存在一行更新履历！");
        }
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        CtUpdateResumeBo bo = new CtUpdateResumeBo(masterId, branchId);
        bo.setUpdateDate(new Date());
        bo.setUpdatePersonnel(currentUser.getName());
        super.insert(bo);
    }
    //查询数据
    @Override
    public List<CtUpdateResumeBo> getUpdateResumeData(Long masterId) throws Exception {
        List<CtUpdateResumeBo> ctUpdateResumeBoList = super.selectList(new EntityWrapper<CtUpdateResumeBo>()
            .eq(("masterId"), masterId).orderBy("createTime", true));
        for(CtUpdateResumeBo bo : ctUpdateResumeBoList){
            String userName = bo.getUpdatePersonnel();
            if(CtFormatUtil.hasContent(userName)){
                WTUser user = CtUserUtil.getUserByAccountName(userName);
                if(null != user){
                    bo.setUpdatePersonnel(user.getFullName());
                }
            }
        }
        return ctUpdateResumeBoList;
    }
    //删除数据
    @Override
    public void deleteUpdateResumeData(List<String> ids) throws Exception {
        super.deleteBatchIds(ids);
    }
    //更新数据
    @Override
    public CtUpdateResumeBo updateUpdateResumeData(String id, String key, String value) throws Exception {
        CtUpdateResumeBo ctUpdateResumeBo = super.selectById(id);
        //Long branchId = ctModelListBo.getBranchId();
        //super.updateById(ctModelListBo);
        super.updateForSet(key + "=\'" + value + "\'", new EntityWrapper<CtUpdateResumeBo>().eq("id", id));
        return ctUpdateResumeBo;
    }
}

