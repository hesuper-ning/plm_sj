package ext.plm.doc.certificate.service;

import ext.plm.doc.certificate.bo.CtReportChecklistBo;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtReportChecklistService {
    //插入
    void insertReportChecklist(Long masterId, Long branchId) throws Exception;

    //查询数据
    List<CtReportChecklistBo> getReportChecklistData(Long masterId, String ids, String certificateIds, String effective) throws Exception;

    //删除数据
    void deleteReportChecklistData(List<String> ids) throws Exception;

    //更新数据
    CtReportChecklistBo updateReportChecklistData(String id, String key, String value) throws Exception;

    //点击显示关联的报告
    List<CtReportChecklistBo> getRelationReportByCertificate(Long masterId, String certificateIds) throws Exception;

    //通过id查询报告
    List<CtReportChecklistBo> getReportById(String ids) throws Exception;

    //查询有效的报告
    List<CtReportChecklistBo> getEffectiveReport(Long masterId) throws Exception;
}
