package ext.plm.doc.certificate.service;

import ext.plm.doc.certificate.bo.CtModelListBo;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtModelListService {
    //插入
    void insertModelList(Long masterId, Long branchId) throws Exception;
    //查询数据
    List<CtModelListBo> getModelListData(Long masterId, String ids, String certificateIds, String reportIds) throws Exception;
    //根据证书id查询数据
    List<CtModelListBo> getModelListDataByCertificateId(Long masterId, String certificateIds) throws Exception;
    //根据报告id查询数据
    List<CtModelListBo> getModelListDataByReportId(Long masterId, String reportIds) throws Exception;
    //删除数据
    void deleteModelListData(List<String> ids) throws Exception;
    //更新数据
    CtModelListBo updateModelListData(String id, String key, String value) throws Exception;
}
