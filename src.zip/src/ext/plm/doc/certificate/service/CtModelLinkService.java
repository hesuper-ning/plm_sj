package ext.plm.doc.certificate.service;

import ext.plm.doc.certificate.bo.CtModelLinkBo;
import ext.plm.doc.certificate.bo.CtModelListBo;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtModelLinkService {
    //插入
    void insertModelLink(Long masterId, Long branchId, String certificateId, String modelId) throws Exception;
    //批量插入
    void batchInsertReportLink(Long masterId, Long branchId, String certificateId, List<String> modelIdList) throws Exception;
    //查询数据
    List<CtModelLinkBo> getModelLink(Long masterId, String certificateId) throws Exception;
    //删除数据
    void deleteModelLink(CtModelLinkBo ctModelLinkBo) throws Exception;
    //批量删除
    void batchDeleteModelLink(List<CtModelLinkBo> ctModelLinkBoList) throws Exception;
}
