package ext.plm.doc.certificate.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.doc.certificate.CtCertificateHelper;
import ext.plm.doc.certificate.bo.CtModelListBo;
import ext.plm.doc.certificate.bo.CtProductApplicabilityBo;
import ext.plm.doc.certificate.mapper.CtProductApplicabilityMapper;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.part.config.CtPartConstant;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.part.WTPart;

import java.util.ArrayList;
import java.util.List;

@Service
public class CtProductApplicabilityServiceImpl extends ServiceImpl<CtProductApplicabilityMapper, CtProductApplicabilityBo> implements CtProductApplicabilityService {
    @Autowired
    private CtModelListServiceImpl ctModelListServiceImpl;

    @Override
    public void insertProductApplicability(Long masterId, Long branchId) throws Exception {
        CtProductApplicabilityBo ctProductApplicabilityBo = new CtProductApplicabilityBo(masterId, branchId);
        super.insert(ctProductApplicabilityBo);
    }

    @Override
    public List<CtProductApplicabilityBo> getProductApplicabilityData(Long masterId) throws Exception {
        List<CtProductApplicabilityBo> ctProductApplicabilityBoList = super.selectList(new EntityWrapper<CtProductApplicabilityBo>()
                .eq(("masterId"), masterId).orderBy("createTime", true));
        return ctProductApplicabilityBoList;
    }

    @Override
    public void deleteProductApplicabilityData(List<String> ids) throws Exception {
        super.deleteBatchIds(ids);
    }

    @Override
    public CtProductApplicabilityBo updateProductApplicabilityData(String id, String key, String value) throws Exception {
        CtProductApplicabilityBo ctProductApplicabilityBo = super.selectById(id);
        CtCertificateHelper.setFieldValue(ctProductApplicabilityBo, key, value);
        if("productNumber".equals(key)){
            if(CtFormatUtil.hasContent(value)){
                WTPart part = CtPartUtil.getPartByNumber(value);
                if(null != part){
                    if(!part.isEndItem()){
                        throw new Exception("物料编码【"+ value +"】不是成品！");
                    }
                    IBAUtil ibaUtil = new IBAUtil(part);
                    String partDesc = ibaUtil.getIBAValue(CtPartConstant.IBA_MATERIAL_DESCRIPTION);
                    if(CtFormatUtil.hasContent(partDesc)){
                        ctProductApplicabilityBo.setProductDesc(partDesc);
                    }
                    //带出产品型号
                    List<String> modelList = new ArrayList<>();
                    List<CtModelListBo> ctModelListBoList = ctModelListServiceImpl.getModelListData(ctProductApplicabilityBo.getMasterId(), null, null, null);
                    for(CtModelListBo ctModelListBo : ctModelListBoList){
                        if(CtFormatUtil.hasContent(ctModelListBo.getProductModel())){
                            modelList.add(ctModelListBo.getProductModel());
                        }
                    }
                    String productModel = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_productModel);
                    if(CtFormatUtil.hasContent(productModel)){
                        if(!modelList.contains(productModel)){
                            throw new Exception("物料编码【"+ value +"】的型号【" + productModel + "】不存在当前表单“相关型号清单”中！");
                        }else{
                            ctProductApplicabilityBo.setProductModel(productModel);
                        }
                    }else{
                        throw new Exception("物料编码【"+ value +"】的型号为空！");
                    }
                }else{
                    throw new Exception("成品编码【"+ value +"】在系统中不存在！");
                }
            }else{
                ctProductApplicabilityBo.setProductDesc("");
                ctProductApplicabilityBo.setProductModel("");
            }
        }
        super.updateById(ctProductApplicabilityBo);
        return ctProductApplicabilityBo;
    }
}

