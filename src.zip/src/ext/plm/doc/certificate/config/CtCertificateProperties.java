package ext.plm.doc.certificate.config;

import ext.plm.util.CtFormatUtil;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * @Author: heqingbo
 * @Date: 2024/9/10
 * @Description:
 */
public class CtCertificateProperties {
    /**
     * 根据活动节点名称获得activityKey
     * @param activityName
     */
    public static String getActivityKey(String activityName) throws Exception{
        Properties activityKeyMap = new Properties();
        activityKeyMap.load(new InputStreamReader(
                CtCertificateProperties.class.getResourceAsStream("CtCertificateConfig.properties"), StandardCharsets.UTF_8));

        String activityKey =  activityKeyMap.getProperty(activityName);
        if(!CtFormatUtil.hasContent(activityKey)) {
            activityKey = "";
        }
        return activityKey;
    }
}
