package ext.plm.fanh.service;

import cn.hutool.poi.excel.cell.CellUtil;
import ext.plm.fanh.dto.RzReportDto;
import ext.plm.fanh.dto.ZsReportDto;
import ext.plm.util.CtDocUtil;
import ext.plm.util.IBAUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import wt.doc.WTDocument;
import wt.method.MethodContext;
import wt.pom.WTConnection;

import java.io.OutputStream;
import java.lang.reflect.Method;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @Author: lcd
 * @Date: 2022/7/26 8:42
 * @Description:
 */
@Service
public class ReportService {
    /**
     * jdbc获取
     * 认证
     * @throws Exception
     */
    public List<RzReportDto> queryDataRzReportJdbc() throws Exception{

        List<RzReportDto> rzReportDtos = new ArrayList<>();

        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "with t1 as (\n" +
                    "    select t1.docId,\n" +
                    "           t2.name,\n" +
                    "           t2.value,\n" +
                    "           t1.description,\n" +
                    "           t1.FolderName,\n" +
                    "           t1.docnumber,\n" +
                    "           t1.VERSIONIDA2VERSIONINFO,\n" +
                    "           t1.branchiditerationinfo,\n" +
                    "           rank() over (partition by docnumber order by VERSIONIDA2VERSIONINFO desc) rank\n" +
                    "    from (\n" +
                    "           SELECT doc.IDA2A2 docId,\n" +
                    "                  doc.description,\n" +
                    "                  doc.VERSIONIDA2VERSIONINFO,\n" +
                    "                  doc.branchiditerationinfo,\n" +
                    "                  Folder.Name                FolderName,\n" +
                    "                  docMaster.Wtdocumentnumber docnumber\n" +
                    "           FROM wcadmin.WTDocument doc,\n" +
                    "                wcadmin.WTDocumentMaster docMaster,\n" +
                    "                wcadmin.WTTypeDefinition typed,\n" +
                    "                wcadmin.WTTypeDefinitionMaster typeMater,\n" +
                    "                SubFolder Folder\n" +
                    "           WHERE doc.idA3masterReference = docMaster.idA2A2\n" +
                    "           AND docMaster.markForDeleteA2 = 0\n" +
                    "           AND doc.latestiterationInfo = 1\n" +
                    "           AND typed.idA3masterReference = typeMater.idA2A2\n" +
                    "           AND typed.idA2A2 = doc.idA2typeDefinitionReference\n" +
                    "           AND typeMater.markForDeleteA2 = 0\n" +
                    "           AND typeMater.intHid LIKE '%com.fhsj.Doc_zs%'\n" +
                    "           AND doc.ida3b2folderinginfo = Folder.Ida2a2\n" +
                    "     ) t1 left join (\n" +
                    "          select strDef.name name,\n" +
                    "                 strVal.value2 value,\n" +
                    "                 strVal.ida3a4 attrId\n" +
                    "          from wcadmin.StringDefinition strDef,\n" +
                    "               wcadmin.StringValue strVal\n" +
                    "          where strDef.idA2A2 = strVal.idA3A6\n" +
                    "     ) t2 on t2.attrId = t1.docId\n" +
                    "),\n" +
                    "a1 as (select * from t1 where t1.rank = 1),\n" +
                    "iba1 as (\n" +
                    "         select *\n" +
                    "         from a1\n" +
                    "             pivot (\n" +
                    "             max(value)\n" +
                    "             FOR name IN (\n" +
                    "                 'ct_productName' as ct_productName,\n" +
                    "                 'ct_materialsnumber' as ct_materialsnumber,\n" +
                    "                 'ct_Identityinformationtype' as ct_Identityinformationtype,\n" +
                    "                 'ct_Authenticationtype' as ct_Authenticationtype,\n" +
                    "                 'ct_Certificatenumber' as ct_Certificatenumber,\n" +
                    "                 'ct_model' as ct_model,\n" +
                    "                 'ct_model1' as ct_model1,\n" +
                    "                 'ct_1reporttype' as ct_1reporttype,\n" +
                    "                 'ct_1InspectionReportNo' as ct_1InspectionReportNo,\n" +
                    "                 'ct_1Productstandard' as ct_1Productstandards,\n" +
                    "                 'ct_model2' as ct_model2,\n" +
                    "                 'ct_2reporttype' as ct_2reporttype,\n" +
                    "                 'ct_2InspectionReportNo' as ct_2InspectionReportNo,\n" +
                    "                 'ct_2ProductStandards' as ct_2Productstandards,\n" +
                    "                 'ct_model3' as ct_model3,\n" +
                    "                 'ct_3reporttype' as ct_3reporttype,\n" +
                    "                 'ct_3InspectionReportNo' as ct_3InspectionReportNo,\n" +
                    "                 'ct_3ProductStandards' as ct_3Productstandards,\n" +
                    "                 'ct_model4' as ct_model4,\n" +
                    "                 'ct_4reporttype' as ct_4reporttype,\n" +
                    "                 'ct_InspectionReportNo' as ct_4InspectionReportNo,\n" +
                    "                 'ct_4ProductStandards' as ct_4Productstandards,\n" +
                    "                 'ct_model5' as ct_model5,\n" +
                    "                 'ct_5reporttype' as ct_5reporttype,\n" +
                    "                 'ct_5InspectionReportNo' as ct_5InspectionReportNo,\n" +
                    "                 'ct_5ProductStandards' as ct_5Productstandards,\n" +
                    "                 'ct_model6' as ct_model6,\n" +
                    "                 'ct_6reporttype' as ct_6reporttype,\n" +
                    "                 'ct_6InspectionReportNo' as ct_6InspectionReportNo,\n" +
                    "                 'ct_6ProductStandards' as ct_6Productstandards,\n" +
                    "                 'ct_model7' as ct_model7,\n" +
                    "                 'ct_7reporttype' as ct_7reporttype,\n" +
                    "                 'ct_7InspectionReportNo' as ct_7InspectionReportNo,\n" +
                    "                 'ct_7ProductStandards' as ct_7Productstandards,\n" +
                    "                 'ct_model8' as ct_model8,\n" +
                    "                 'ct_8reporttype' as ct_8reporttype,\n" +
                    "                 'ct_8InspectionReportNo' as ct_8InspectionReportNo,\n" +
                    "                 'ct_8ProductStandards' as ct_8Productstandards,\n" +
                    "                 'ct_model9' as ct_model9,\n" +
                    "                 'ct_9reporttype' as ct_9reporttype,\n" +
                    "                 'ct_9InspectionReportNo' as ct_9InspectionReportNo,\n" +
                    "                 'ct_9ProductStandards' as ct_9Productstandards,\n" +
                    "                 'ct_model10' as ct_model10,\n" +
                    "                 'ct_10reporttype' as ct_10reporttype,\n" +
                    "                 'ct_10InspectionReportNo' as ct_10InspectionReportNo,\n" +
                    "                 'ct_10ProductStandards' as ct_10Productstandards,\n" +
                    "                 'ct_model11' as ct_model11,\n" +
                    "                 'ct_11reporttype' as ct_11reporttype,\n" +
                    "                 'ct_11InspectionReportNo' as ct_11InspectionReportNo,\n" +
                    "                 'ct_11ProductStandards' as ct_11Productstandards,\n" +
                    "                 'ct_model12' as ct_model12,\n" +
                    "                 'ct_12reporttype' as ct_12reporttype,\n" +
                    "                 'ct_12InspectionReportNo' as ct_12InspectionReportNo,\n" +
                    "                 'ct_12ProductStandards' as ct_12Productstandards,\n" +
                    "                 'ct_model13' as ct_model13,\n" +
                    "                 'ct_13reporttype' as ct_13reporttype,\n" +
                    "                 'ct_13InspectionReportNo' as ct_13InspectionReportNo,\n" +
                    "                 'ct_13ProductStandards' as ct_13Productstandards,\n" +
                    "                 'ct_model14' as ct_model14,\n" +
                    "                 'ct_14reporttype' as ct_14reporttype,\n" +
                    "                 'ct_14InspectionReportNo' as ct_14InspectionReportNo,\n" +
                    "                 'ct_14ProductStandards' as ct_14Productstandards,\n" +
                    "                 'ct_model15' as ct_model15,\n" +
                    "                 'ct_15reporttype' as ct_15reporttype,\n" +
                    "                 'ct_15InspectionReportNo' as ct_15InspectionReportNo,\n" +
                    "                 'ct_15ProductStandards' as ct_15Productstandards,\n" +
                    "                 'ct_model16' as ct_model16,\n" +
                    "                 'ct_16reporttype' as ct_16reporttype,\n" +
                    "                 'ct_16InspectionReportNo' as ct_16InspectionReportNo,\n" +
                    "                 'ct_16ProductStandards' as ct_16Productstandards,\n" +
                    "                 'ct_model17' as ct_model17,\n" +
                    "                 'ct_17reporttype' as ct_17reporttype,\n" +
                    "                 'ct_17InspectionReportNo' as ct_17InspectionReportNo,\n" +
                    "                 'ct_17ProductStandards' as ct_17Productstandards,\n" +
                    "                 'ct_model18' as ct_model18,\n" +
                    "                 'ct_18reporttype' as ct_18reporttype,\n" +
                    "                 'ct_18InspectionReportNo' as ct_18InspectionReportNo,\n" +
                    "                 'ct_18ProductStandards' as ct_18Productstandards,\n" +
                    "                 'ct_model19' as ct_model19,\n" +
                    "                 'ct_19reporttype' as ct_19reporttype,\n" +
                    "                 'ct_19InspectionReportNo' as ct_19InspectionReportNo,\n" +
                    "                 'ct_19ProductStandards' as ct_19Productstandards,\n" +
                    "                 'ct_model20' as ct_model20,\n" +
                    "                 'ct_20reporttype' as ct_20reporttype,\n" +
                    "                 'ct_20InspectionReportNo' as ct_20InspectionReportNo,\n" +
                    "                 'ct_20ProductStandards' as ct_20Productstandards,\n" +
                    "                 'ct_model21' as ct_model21,\n" +
                    "                 'ct_21reporttype' as ct_21reporttype,\n" +
                    "                 'ct_21InspectionReportNo' as ct_21InspectionReportNo,\n" +
                    "                 'ct_21ProductStandards' as ct_21Productstandards,\n" +
                    "                 'ct_model22' as ct_model22,\n" +
                    "                 'ct_22reporttype' as ct_22reporttype,\n" +
                    "                 'ct_22InspectionReportNo' as ct_22InspectionReportNo,\n" +
                    "                 'ct_22ProductStandards' as ct_22Productstandards,\n" +
                    "                 'ct_model23' as ct_model23,\n" +
                    "                 'ct_23reporttype' as ct_23reporttype,\n" +
                    "                 'ct_23InspectionReportNo' as ct_23InspectionReportNo,\n" +
                    "                 'ct_23ProductStandards' as ct_23Productstandards,\n" +
                    "                 'ct_model24' as ct_model24,\n" +
                    "                 'ct_24reporttype' as ct_24reporttype,\n" +
                    "                 'ct_24InspectionReportNo' as ct_24InspectionReportNo,\n" +
                    "                 'ct_24ProductStandards' as ct_24Productstandards\n" +
                    "                 )\n" +
                    "             )\n" +
                    " ),\n" +
                    "t3 as (\n" +
                    "   select td.name, tv.value, tv.ida3a4\n" +
                    "   from TimestampDefinition td,\n" +
                    "        TimestampValue tv\n" +
                    "   where td.ida2a2 = tv.ida3a6\n" +
                    "),\n" +
                    "iba2 as (\n" +
                    "   select\n" +
                    "      *\n" +
                    "   from t3\n" +
                    "   pivot (\n" +
                    "     max(value)\n" +
                    "     FOR name IN (\n" +
                    "         'ct_Dateoffirstissuance' as ct_Dateoffirstissuance,\n" +
                    "         'ct_DateofObtainingCertificate' as ct_DateofObtainingCertificate,\n" +
                    "         'ct_Certificateexpirationdate' as ct_Certificateexpirationdate,\n" +
                    "         'ct_1reportvalidity' as ct_1reportvalidity,\n" +
                    "         'ct_2reportvalidity' as  ct_2reportvalidity,\n" +
                    "         'ct_3reportvalidity' as  ct_3reportvalidity,\n" +
                    "         'ct_4reportvalidity' as  ct_4reportvalidity,\n" +
                    "         'ct_5reportvalidity' as  ct_5reportvalidity,\n" +
                    "         'ct_6reportvalidity' as  ct_6reportvalidity,\n" +
                    "         'ct_7reportvalidity' as  ct_7reportvalidity,\n" +
                    "         'ct_8reportvalidity' as  ct_8reportvalidity,\n" +
                    "         'ct_9reportvalidity' as  ct_9reportvalidity,\n" +
                    "         'ct_10reportvalidity' as  ct_10reportvalidity,\n" +
                    "         'ct_11reportvalidity' as  ct_11reportvalidity,\n" +
                    "         'ct_12reportvalidity' as  ct_12reportvalidity,\n" +
                    "         'ct_13reportvalidity' as  ct_13reportvalidity,\n" +
                    "         'ct_14reportvalidity' as  ct_14reportvalidity,\n" +
                    "         'ct_15reportvalidity' as  ct_15reportvalidity,\n" +
                    "         'ct_16reportvalidity' as  ct_16reportvalidity,\n" +
                    "         'ct_17reportvalidity' as  ct_17reportvalidity,\n" +
                    "         'ct_18reportvalidity' as  ct_18reportvalidity,\n" +
                    "         'ct_19reportvalidity' as  ct_19reportvalidity,\n" +
                    "         'ct_20reportvalidity' as  ct_20reportvalidity,\n" +
                    "         'ct_21reportvalidity' as  ct_21reportvalidity,\n" +
                    "         'ct_22reportvalidity' as  ct_22reportvalidity,\n" +
                    "         'ct_23reportvalidity' as  ct_23reportvalidity,\n" +
                    "         'ct_24reportvalidity' as  ct_24reportvalidity\n" +
                    "         )\n" +
                    "  )\n" +
                    "),\n" +
                    "t4 as (\n" +
                    "   select\n" +
                    "       distinct\n" +
                    "       iba1.docid,\n" +
                    "       iba1.docnumber,\n" +
                    "       iba1.branchiditerationinfo,\n" +
                    "       iba1.ct_productName,\n" +
                    "       iba1.ct_materialsnumber,\n" +
                    "       iba1.ct_Identityinformationtype,\n" +
                    "       iba1.ct_Authenticationtype,\n" +
                    "       iba2.ct_Dateoffirstissuance,\n" +
                    "       iba2.ct_DateofObtainingCertificate,\n" +
                    "       iba2.ct_Certificateexpirationdate,\n" +
                    "       iba1.ct_Certificatenumber,\n" +
                    "       iba1.ct_model,\n" +
                    "       \n" +
                    "       iba1.ct_model1,\n" +
                    "       ConvertReportType(iba1.ct_1reporttype)  ct_1reporttype,\n" +
                    "       iba1.ct_1InspectionReportNo,\n" +
                    "       iba1.ct_1Productstandards,\n" +
                    "       iba2.ct_1reportvalidity,\n" +
                    "       \n" +
                    "       iba1.ct_model2,\n" +
                    "       ConvertReportType(iba1.ct_2reporttype)  ct_2reporttype,\n" +
                    "       iba1.ct_2InspectionReportNo,\n" +
                    "       iba1.ct_2Productstandards,\n" +
                    "       iba2.ct_2reportvalidity,\n" +
                    "       \n" +
                    "       \n" +
                    "       iba1.ct_model3,\n" +
                    "       ConvertReportType(iba1.ct_3reporttype)  ct_3reporttype,\n" +
                    "       iba1.ct_3InspectionReportNo,\n" +
                    "       iba1.ct_3Productstandards,\n" +
                    "       iba2.ct_3reportvalidity,\n" +
                    "       \n" +
                    "       iba1.ct_model4,\n" +
                    "       ConvertReportType(iba1.ct_4reporttype)  ct_4reporttype,\n" +
                    "       iba1.ct_4InspectionReportNo,\n" +
                    "       iba1.ct_4Productstandards,\n" +
                    "       iba2.ct_4reportvalidity,\n" +
                    "       \n" +
                    "       iba1.ct_model5,\n" +
                    "       ConvertReportType(iba1.ct_5reporttype)  ct_5reporttype,\n" +
                    "       iba1.ct_5InspectionReportNo,\n" +
                    "       iba1.ct_5Productstandards,\n" +
                    "       iba2.ct_5reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model6,\n" +
                    "       ConvertReportType(iba1.ct_6reporttype)  ct_6reporttype,\n" +
                    "       iba1.ct_6InspectionReportNo,\n" +
                    "       iba1.ct_6Productstandards,\n" +
                    "       iba2.ct_6reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model7,\n" +
                    "       ConvertReportType(iba1.ct_7reporttype)  ct_7reporttype,\n" +
                    "       iba1.ct_7InspectionReportNo,\n" +
                    "       iba1.ct_7Productstandards,\n" +
                    "       iba2.ct_7reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model8,\n" +
                    "       ConvertReportType(iba1.ct_8reporttype)  ct_8reporttype,\n" +
                    "       iba1.ct_8InspectionReportNo,\n" +
                    "       iba1.ct_8Productstandards,\n" +
                    "       iba2.ct_8reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model9,\n" +
                    "       ConvertReportType(iba1.ct_9reporttype)  ct_9reporttype,\n" +
                    "       iba1.ct_9InspectionReportNo,\n" +
                    "       iba1.ct_9Productstandards,\n" +
                    "       iba2.ct_9reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model10,\n" +
                    "       ConvertReportType(iba1.ct_10reporttype) ct_10reporttype,\n" +
                    "       iba1.ct_10InspectionReportNo,\n" +
                    "       iba1.ct_10Productstandards,\n" +
                    "       iba2.ct_10reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model11,\n" +
                    "       ConvertReportType(iba1.ct_11reporttype) ct_11reporttype,\n" +
                    "       iba1.ct_11InspectionReportNo,\n" +
                    "       iba1.ct_11Productstandards,\n" +
                    "       iba2.ct_11reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model12,\n" +
                    "       ConvertReportType(iba1.ct_12reporttype) ct_12reporttype,\n" +
                    "       iba1.ct_12InspectionReportNo,\n" +
                    "       iba1.ct_12Productstandards,\n" +
                    "       iba2.ct_12reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model13,\n" +
                    "       ConvertReportType(iba1.ct_13reporttype) ct_13reporttype,\n" +
                    "       iba1.ct_13InspectionReportNo,\n" +
                    "       iba1.ct_13Productstandards,\n" +
                    "       iba2.ct_13reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model14,\n" +
                    "       ConvertReportType(iba1.ct_14reporttype) ct_14reporttype,\n" +
                    "       iba1.ct_14InspectionReportNo,\n" +
                    "       iba1.ct_14Productstandards,\n" +
                    "       iba2.ct_14reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model15,\n" +
                    "       ConvertReportType(iba1.ct_15reporttype) ct_15reporttype,\n" +
                    "       iba1.ct_15InspectionReportNo,\n" +
                    "       iba1.ct_15Productstandards,\n" +
                    "       iba2.ct_15reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model16,\n" +
                    "       ConvertReportType(iba1.ct_16reporttype) ct_16reporttype,\n" +
                    "       iba1.ct_16InspectionReportNo,\n" +
                    "       iba1.ct_16Productstandards,\n" +
                    "       iba2.ct_16reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model17,\n" +
                    "       ConvertReportType(iba1.ct_17reporttype) ct_17reporttype,\n" +
                    "       iba1.ct_17InspectionReportNo,\n" +
                    "       iba1.ct_17Productstandards,\n" +
                    "       iba2.ct_17reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model18,\n" +
                    "       ConvertReportType(iba1.ct_18reporttype) ct_18reporttype,\n" +
                    "       iba1.ct_18InspectionReportNo,\n" +
                    "       iba1.ct_18Productstandards,\n" +
                    "       iba2.ct_18reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model19,\n" +
                    "       ConvertReportType(iba1.ct_19reporttype) ct_19reporttype,\n" +
                    "       iba1.ct_19InspectionReportNo,\n" +
                    "       iba1.ct_19Productstandards,\n" +
                    "       iba2.ct_19reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model20,\n" +
                    "       ConvertReportType(iba1.ct_20reporttype) ct_20reporttype,\n" +
                    "       iba1.ct_20InspectionReportNo,\n" +
                    "       iba1.ct_20Productstandards,\n" +
                    "       iba2.ct_20reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model21,\n" +
                    "       ConvertReportType(iba1.ct_21reporttype) ct_21reporttype,\n" +
                    "       iba1.ct_21InspectionReportNo,\n" +
                    "       iba1.ct_21Productstandards,\n" +
                    "       iba2.ct_21reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model22,\n" +
                    "       ConvertReportType(iba1.ct_22reporttype) ct_22reporttype,\n" +
                    "       iba1.ct_22InspectionReportNo,\n" +
                    "       iba1.ct_22Productstandards,\n" +
                    "       iba2.ct_22reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model23,\n" +
                    "       ConvertReportType(iba1.ct_23reporttype) ct_23reporttype,\n" +
                    "       iba1.ct_23InspectionReportNo,\n" +
                    "       iba1.ct_23Productstandards,\n" +
                    "       iba2.ct_23reportvalidity,\n" +
                    "\n" +
                    "       iba1.ct_model24,\n" +
                    "       ConvertReportType(iba1.ct_24reporttype) ct_24reporttype,\n" +
                    "       iba1.ct_24InspectionReportNo,\n" +
                    "       iba1.ct_24Productstandards,\n" +
                    "       iba2.ct_24reportvalidity,\n" +
                    "\n" +
                    "       iba1.description\n" +
                    "    from iba1\n" +
                    "    left join iba2\n" +
                    "    on iba1.docid = iba2.ida3a4\n" +
                    "    where iba1.FolderName = 'A0901_证书'\n" +
                    "    and ct_Authenticationtype not in (\n" +
                    "      'ct_TCCC_certification',\n" +
                    "      'ct_TZYX_certification',\n" +
                    "      'ct_TJSJD_certification',\n" +
                    "      'ct_TFB_certification',\n" +
                    "      'ct_TLPCB_certification',\n" +
                    "      'ct_TAPPLUS_certification',\n" +
                    "      'ct_TCoC_certification',\n" +
                    "      'ct_TDX_certification',\n" +
                    "      'ct_TWXD_certification',\n" +
                    "      'ct_TJLQJ_certification',\n" +
                    "      'ct_TCCS_certification',\n" +
                    "      'ct_TUL_certification',\n" +
                    "      'ct_TSIL_certification',\n" +
                    "      'ct_TCEGN_certification',\n" +
                    "      'ct_TCJ_certification',\n" +
                    "      'ct_TNothing_certification',\n" +
                    "      'ct_TCEOZ_certification',\n" +
                    "      'ct_TUKCA_certification'\n" +
                    "    )\n" +
                    "),\n" +
                    "t6 as (\n" +
                    "    select\n" +
                    "        t4.docid,\n" +
                    "        t4.docnumber,\n" +
                    "        t4.branchiditerationinfo,\n" +
                    "        ct_productName,\n" +
                    "        ct_materialsnumber,\n" +
                    "        ct_Identityinformationtype,\n" +
                    "        ct_Authenticationtype,\n" +
                    "        ct_Dateoffirstissuance,\n" +
                    "        ct_DateofObtainingCertificate,\n" +
                    "        ct_Certificateexpirationdate,\n" +
                    "        ct_Certificatenumber,\n" +
                    "        ct_model,\n" +
                    "        ct_model1,\n" +
                    "        concat(concat(ct_1reporttype,':'),ct_1InspectionReportNo||',')||TO_CHAR(ct_1reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_1reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_1InspectionReportNo,       \n" +
                    "        ct_1Productstandards,\n" +
                    "        ct_model2,\n" +
                    "        concat(concat(ct_2reporttype,':'),ct_2InspectionReportNo||',')||TO_CHAR(ct_2reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_2reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_2InspectionReportNo,         \n" +
                    "        ct_2Productstandards,\n" +
                    "        ct_model3,\n" +
                    "        concat(concat(ct_3reporttype,':'),ct_3InspectionReportNo||',')||TO_CHAR(ct_3reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_3reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_3InspectionReportNo,    \n" +
                    "        ct_3Productstandards,\n" +
                    "        ct_model4,\n" +
                    "        concat(concat(ct_4reporttype,':'),ct_4InspectionReportNo||',')||TO_CHAR(ct_4reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_4reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_4InspectionReportNo,    \n" +
                    "        ct_4Productstandards,\n" +
                    "        ct_model5,\n" +
                    "        concat(concat(ct_5reporttype,':'),ct_5InspectionReportNo||',')||TO_CHAR(ct_5reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_5reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_5InspectionReportNo,    \n" +
                    "        ct_5Productstandards,\n" +
                    "        ct_model6,\n" +
                    "        concat(concat(ct_6reporttype,':'),ct_6InspectionReportNo||',')||TO_CHAR(ct_6reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_6reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_6InspectionReportNo,    \n" +
                    "        ct_6Productstandards,\n" +
                    "        ct_model7,\n" +
                    "        concat(concat(ct_7reporttype,':'),ct_7InspectionReportNo||',')||TO_CHAR(ct_7reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_7reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_7InspectionReportNo,    \n" +
                    "        ct_7Productstandards,\n" +
                    "        ct_model8,\n" +
                    "        concat(concat(ct_8reporttype,':'),ct_8InspectionReportNo||',')||TO_CHAR(ct_8reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_8reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_8InspectionReportNo,    \n" +
                    "        ct_8Productstandards,\n" +
                    "        ct_model9,\n" +
                    "        concat(concat(ct_9reporttype,':'),ct_9InspectionReportNo||',')||TO_CHAR(ct_9reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_9reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_9InspectionReportNo,    \n" +
                    "        ct_9Productstandards,\n" +
                    "        ct_model10,\n" +
                    "        concat(concat(ct_10reporttype,':'),ct_10InspectionReportNo||',')||TO_CHAR(ct_10reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_10reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_10InspectionReportNo,     \n" +
                    "        ct_10Productstandards,\n" +
                    "        ct_model11,\n" +
                    "        concat(concat(ct_11reporttype,':'),ct_11InspectionReportNo||',')||TO_CHAR(ct_11reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_11reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_11InspectionReportNo,    \n" +
                    "        ct_11Productstandards,\n" +
                    "        ct_model12,\n" +
                    "        concat(concat(ct_12reporttype,':'),ct_12InspectionReportNo||',')||TO_CHAR(ct_12reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_12reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_12InspectionReportNo,\n" +
                    "        ct_12Productstandards,\n" +
                    "        ct_model13,\n" +
                    "        concat(concat(ct_13reporttype,':'),ct_13InspectionReportNo||',')||TO_CHAR(ct_13reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_13reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_13InspectionReportNo,\n" +
                    "        ct_13Productstandards,\n" +
                    "        ct_model14,\n" +
                    "        concat(concat(ct_14reporttype,':'),ct_14InspectionReportNo||',')||TO_CHAR(ct_14reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_14reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_14InspectionReportNo,\n" +
                    "        ct_14Productstandards,\n" +
                    "        ct_model15,\n" +
                    "        concat(concat(ct_15reporttype,':'),ct_15InspectionReportNo||',')||TO_CHAR(ct_15reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_15reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_15InspectionReportNo,\n" +
                    "        ct_15Productstandards,\n" +
                    "        ct_model16,\n" +
                    "        concat(concat(ct_16reporttype,':'),ct_16InspectionReportNo||',')||TO_CHAR(ct_16reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_16reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_16InspectionReportNo,\n" +
                    "        ct_16Productstandards,\n" +
                    "        ct_model17,\n" +
                    "        concat(concat(ct_17reporttype,':'),ct_17InspectionReportNo||',')||TO_CHAR(ct_17reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_17reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_17InspectionReportNo,\n" +
                    "        ct_17Productstandards,\n" +
                    "        ct_model18,\n" +
                    "        concat(concat(ct_18reporttype,':'),ct_18InspectionReportNo||',')||TO_CHAR(ct_18reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_18reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_18InspectionReportNo,\n" +
                    "        ct_18Productstandards,\n" +
                    "        ct_model19,\n" +
                    "        concat(concat(ct_19reporttype,':'),ct_19InspectionReportNo||',')||TO_CHAR(ct_19reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_19reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_19InspectionReportNo,\n" +
                    "        ct_19Productstandards,\n" +
                    "        ct_model20,\n" +
                    "        concat(concat(ct_20reporttype,':'),ct_20InspectionReportNo||',')||TO_CHAR(ct_20reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_20reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_20InspectionReportNo,\n" +
                    "        ct_20Productstandards,\n" +
                    "        ct_model21,\n" +
                    "        concat(concat(ct_21reporttype,':'),ct_21InspectionReportNo||',')||TO_CHAR(ct_21reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_21reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_21InspectionReportNo,\n" +
                    "        ct_21Productstandards,\n" +
                    "        ct_model22,\n" +
                    "        concat(concat(ct_22reporttype,':'),ct_22InspectionReportNo||',')||TO_CHAR(ct_22reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_22reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_22InspectionReportNo,\n" +
                    "        ct_22Productstandards,\n" +
                    "        ct_model23,\n" +
                    "        concat(concat(ct_23reporttype,':'),ct_23InspectionReportNo||',')||TO_CHAR(ct_23reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_23reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_23InspectionReportNo,\n" +
                    "        ct_23Productstandards,\n" +
                    "        ct_model24,\n" +
                    "        concat(concat(ct_24reporttype,':'),ct_24InspectionReportNo||',')||TO_CHAR(ct_24reportvalidity, 'YYYY-MM-DD')|| DECODE(TO_CHAR(ct_24reportvalidity, 'YYYY-MM-DD'), '', '', '到期' )as ct_24InspectionReportNo,\n" +
                    "        ct_24Productstandards,\n" +
                    "        description\n" +
                    " from t4\n" +
                    "),\n" +
                    "t7 as (\n" +
                    "  select\n" +
                    "        distinct\n" +
                    "        docid,\n" +
                    "        docnumber,\n" +
                    "        ct_model,\n" +
                    "        ct_InspectionReportNo,\n" +
                    "        ct_Productstandards\n" +
                    "  from (\n" +
                    "          select\n" +
                    "               docid,\n" +
                    "               docnumber,\n" +
                    "               ct_model ct_model,\n" +
                    "               ''ct_InspectionReportNo,\n" +
                    "               ''ct_Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select\n" +
                    "               docid,\n" +
                    "               docnumber,\n" +
                    "               ct_model1              ct_model,\n" +
                    "               ct_1InspectionReportNo ct_InspectionReportNo,\n" +
                    "               ct_1Productstandards   ct_Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select\n" +
                    "               docid,\n" +
                    "               docnumber,\n" +
                    "               ct_model2,\n" +
                    "               ct_2InspectionReportNo,\n" +
                    "               ct_2Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select\n" +
                    "                docid,\n" +
                    "                docnumber,\n" +
                    "                ct_model3,\n" +
                    "                ct_3InspectionReportNo,\n" +
                    "                ct_3Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select\n" +
                    "                docid,\n" +
                    "                docnumber,\n" +
                    "                ct_model4,\n" +
                    "                ct_4InspectionReportNo,\n" +
                    "                ct_4Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select\n" +
                    "               docid,\n" +
                    "               docnumber,\n" +
                    "               ct_model5,\n" +
                    "               ct_5InspectionReportNo,\n" +
                    "               ct_5Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model6,\n" +
                    "                 ct_6InspectionReportNo,\n" +
                    "                 ct_6Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model7,\n" +
                    "                 ct_7InspectionReportNo,\n" +
                    "                 ct_7Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model8,\n" +
                    "                 ct_8InspectionReportNo,\n" +
                    "                 ct_8Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model9,\n" +
                    "                 ct_9InspectionReportNo,\n" +
                    "                 ct_9Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model10,\n" +
                    "                 ct_10InspectionReportNo,\n" +
                    "                 ct_10Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model11,\n" +
                    "                 ct_11InspectionReportNo,\n" +
                    "                 ct_11Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model12,\n" +
                    "                 ct_12InspectionReportNo,\n" +
                    "                 ct_12Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model13,\n" +
                    "                 ct_13InspectionReportNo,\n" +
                    "                 ct_13Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model14,\n" +
                    "                 ct_14InspectionReportNo,\n" +
                    "                 ct_14Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model15,\n" +
                    "                 ct_15InspectionReportNo,\n" +
                    "                 ct_15Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model16,\n" +
                    "                 ct_16InspectionReportNo,\n" +
                    "                 ct_16Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model17,\n" +
                    "                 ct_17InspectionReportNo,\n" +
                    "                 ct_17Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model18,\n" +
                    "                 ct_18InspectionReportNo,\n" +
                    "                 ct_18Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model19,\n" +
                    "                 ct_19InspectionReportNo,\n" +
                    "                 ct_19Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model20,\n" +
                    "                 ct_20InspectionReportNo,\n" +
                    "                 ct_20Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model21,\n" +
                    "                 ct_21InspectionReportNo,\n" +
                    "                 ct_21Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model22,\n" +
                    "                 ct_22InspectionReportNo,\n" +
                    "                 ct_22Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model23,\n" +
                    "                 ct_23InspectionReportNo,\n" +
                    "                 ct_23Productstandards\n" +
                    "          from t6\n" +
                    "\n" +
                    "          union all\n" +
                    "\n" +
                    "          select docid,\n" +
                    "                 docnumber,\n" +
                    "                 ct_model24,\n" +
                    "                 ct_24InspectionReportNo,\n" +
                    "                 ct_24Productstandards\n" +
                    "          from t6\n" +
                    "        ) f0\n" +
                    " ),\n" +
                    " p1 as (\n" +
                    "     select part.ida2a2             partId,\n" +
                    "            partMaster.Name         partName,\n" +
                    "            partMaster.Wtpartnumber partNumber\n" +
                    "     from wtpart part,\n" +
                    "          WTPartMaster partMaster\n" +
                    "     where part.ida3masterreference = partMaster.Ida2a2\n" +
                    "     and (Wtpartnumber like '3%' or Wtpartnumber like '4%')\n" +
                    " ),\n" +
                    " p2 as (\n" +
                    "     select strDef.name   name,\n" +
                    "            strVal.value2 ct_model,\n" +
                    "            strVal.ida3a4 attrId\n" +
                    "     from wcadmin.StringDefinition strDef,\n" +
                    "          wcadmin.StringValue strVal\n" +
                    "     where strDef.idA2A2 = strVal.idA3A6\n" +
                    "     and name = 'ct_model'\n" +
                    " ),\n" +
                    " p3 as (\n" +
                    "     select xmlagg(\n" +
                    "                    xmlparse(content partNumber || ',' wellformed) order by ct_model\n" +
                    "            ).getclobval() ct_materialsnumber,\n" +
                    "            ct_model\n" +
                    "     from (\n" +
                    "          select\n" +
                    "            distinct\n" +
                    "            p1.partNumber,\n" +
                    "            p2.ct_model\n" +
                    "          from p1,\n" +
                    "               p2\n" +
                    "          where p1.partId = p2.attrId\n" +
                    "    ) f0\n" +
                    "    group by ct_model\n" +
                    "),\n" +
                    "t8 as (\n" +
                    "     select\n" +
                    "        distinct\n" +
                    "           t7.docid,\n" +
                    "           t7.ct_model,\n" +
                    "           t6.docnumber,\n" +
                    "           t6.branchiditerationinfo,\n" +
                    "           t6.ct_productName,\n" +
                    "           t6.ct_Identityinformationtype,\n" +
                    "           t6.ct_Authenticationtype,\n" +
                    "           t6.ct_Dateoffirstissuance,\n" +
                    "           t6.ct_DateofObtainingCertificate,\n" +
                    "           t6.ct_Certificateexpirationdate,\n" +
                    "           t6.ct_Certificatenumber,\n" +
                    "           t7.ct_InspectionReportNo,\n" +
                    "           t7.ct_Productstandards,\n" +
                    "           t6.description\n" +
                    "     from t7\n" +
                    "     left join t6\n" +
                    "     on t6.docid = t7.docid\n" +
                    "     and t6.docnumber = t7.docnumber\n" +
                    "),\n" +
                    "t5 as (select * from t8 where ct_model is not null),\n" +
                    "t9 as (\n" +
                    "     select\n" +
                    "          docid,\n" +
                    "          docnumber,\n" +
                    "          branchiditerationinfo,\n" +
                    "          ct_productName,\n" +
                    "          ct_model,\n" +
                    "          ct_Identityinformationtype,\n" +
                    "          ct_Authenticationtype,\n" +
                    "          ct_Dateoffirstissuance,\n" +
                    "          ct_DateofObtainingCertificate,\n" +
                    "          ct_Certificateexpirationdate,\n" +
                    "          ct_Certificatenumber,\n" +
                    "          listagg(ct_InspectionReportNo, ';') within group (order by ct_InspectionReportNo) ct_InspectionReportNo,\n" +
                    "          listagg(ct_Productstandards, ';') within group (order by ct_Productstandards) ct_Productstandards,\n" +
                    "          description\n" +
                    "     from t5\n" +
                    "     group by\n" +
                    "          docid,\n" +
                    "          docnumber,\n" +
                    "          branchiditerationinfo,\n" +
                    "          ct_productName,\n" +
                    "          ct_model,\n" +
                    "          ct_Identityinformationtype,\n" +
                    "          ct_Authenticationtype,\n" +
                    "          ct_Dateoffirstissuance,\n" +
                    "          ct_DateofObtainingCertificate,\n" +
                    "          ct_Certificateexpirationdate,\n" +
                    "          ct_Certificatenumber,\n" +
                    "          description\n" +
                    " )\n" +
                    " select\n" +
                    "    t9.docid,\n" +
                    "    t9.docnumber,\n" +
                    "    t9.branchiditerationinfo,\n" +
                    "    t9.ct_productName,\n" +
                    "    t9.ct_model,\n" +
                    "    p3.ct_materialsnumber,\n" +
                    "    t9.ct_Identityinformationtype,\n" +
                    "    t9.ct_Authenticationtype,\n" +
                    "    to_char((t9.ct_Dateoffirstissuance + 1), 'yyyy/MM/dd')        ct_Dateoffirstissuance,\n" +
                    "    to_char((t9.ct_DateofObtainingCertificate + 1), 'yyyy/MM/dd') ct_DateofObtainingCertificate,\n" +
                    "    to_char((t9.ct_Certificateexpirationdate + 1), 'yyyy/MM/dd')  ct_Certificateexpirationdate,\n" +
                    "    t9.ct_Certificatenumber,\n" +
                    "    t9.ct_InspectionReportNo,\n" +
                    "    t9.ct_Productstandards,\n" +
                    "    t9.description\n" +
                    " from t9\n" +
                    " left join p3\n" +
                    " on t9.ct_model = p3.ct_model \n" +
                    " order by ct_Certificateexpirationdate, docnumber" ;
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();

            //序号
            int groupno = 1;

            while (result.next()) {
                RzReportDto rzReportDto = new RzReportDto();
                String docid=result.getString("docid");
                String docnumber=result.getString("docnumber");
                String docurl=result.getString("branchiditerationinfo");
                String ct_productName=result.getString("ct_productName");
                String ct_model=result.getString("ct_model");
                String ct_materialsnumber=result.getString("ct_materialsnumber");
                String ct_Identityinformationtype=result.getString("ct_Identityinformationtype");
                String ct_Authenticationtype=result.getString("ct_Authenticationtype");
                String ct_Dateoffirstissuance=result.getString("ct_Dateoffirstissuance");
                String ct_DateofObtainingCertificate=result.getString("ct_DateofObtainingCertificate");
                String ct_Certificateexpirationdate=result.getString("ct_Certificateexpirationdate");
                String ct_Certificatenumber=result.getString("ct_Certificatenumber");
                String ct_InspectionReportNo=result.getString("ct_InspectionReportNo");
                String ct_Productstandards=result.getString("ct_Productstandards");
                String description=result.getString("description");

                rzReportDto.setGroupno(groupno);
                rzReportDto.setDocid(docid);
                rzReportDto.setDocnumber(docnumber);
                rzReportDto.setDocurl(docurl);
                rzReportDto.setCt_productName(ct_productName);
                rzReportDto.setCt_model(ct_model);
                rzReportDto.setCt_materialsnumber(ct_materialsnumber);
                rzReportDto.setCt_Identityinformationtype(ct_Identityinformationtype);
                rzReportDto.setCt_Authenticationtype(ct_Authenticationtype);
                rzReportDto.setCt_Dateoffirstissuance(ct_Dateoffirstissuance);
                rzReportDto.setCt_DateofObtainingCertificate(ct_DateofObtainingCertificate);
                rzReportDto.setCt_Certificateexpirationdate(ct_Certificateexpirationdate);
                rzReportDto.setCt_Certificatenumber(ct_Certificatenumber);
                rzReportDto.setCt_1InspectionReportNo(ct_InspectionReportNo);
                rzReportDto.setCt_1Productstandard(ct_Productstandards);
                rzReportDto.setDescription(description);
                rzReportDtos.add(rzReportDto);
                groupno++;
            }

            //枚举类编号处理
            for (RzReportDto rzReportDto : rzReportDtos) {
                WTDocument document = CtDocUtil.getDocumentById(rzReportDto.getDocid());
                IBAUtil ibaUtil = new IBAUtil(document);
                String AuthenticationtypeName = ibaUtil.getEnumDisplayValue(document, "ct_Authenticationtype");
                rzReportDto.setCt_Authenticationtype(AuthenticationtypeName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return rzReportDtos;
    }

    /**
     *
     * @throws Exception
     */
    public  List<ZsReportDto> queryDataZsReprot() throws Exception {
        List<ZsReportDto> zsReportDtos = new ArrayList<>();

        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "with t1 as (  \n" +
                    "     select \n" +
                    "        t1.docId,\n" +
                    "        t2.name,\n" +
                    "        t2.value,\n" +
                    "        t1.description,\n" +
                    "        t1.FolderName,\n" +
                    "        t1.docnumber,\n" +
                    "        t1.iterationida2iterationinfo,\n" +
                    "        t1.branchiditerationinfo,\n" +
                    "        t1.VERSIONIDA2VERSIONINFO,\n" +
                    "        t1.latestiterationInfo\n" +
                    "      from (\n" +
                    "        SELECT\n" +
                    "           doc.IDA2A2 docId,\n" +
                    "           doc.description,\n" +
                    "           doc.branchiditerationinfo,\n" +
                    "           doc.latestiterationInfo,\n" +
                    "           doc.iterationida2iterationinfo,\n" +
                    "           doc.VERSIONIDA2VERSIONINFO,\n" +
                    "           Folder.Name FolderName,\n" +
                    "           docMaster.Wtdocumentnumber docnumber\n" +
                    "        FROM\n" +
                    "            wcadmin.WTDocument doc,\n" +
                    "            wcadmin.WTDocumentMaster docMaster,\n" +
                    "            wcadmin.WTTypeDefinition typed,\n" +
                    "            wcadmin.WTTypeDefinitionMaster typeMater,\n" +
                    "            SubFolder Folder\n" +
                    "        WHERE\n" +
                    "            doc.idA3masterReference = docMaster.idA2A2\n" +
                    "        AND docMaster.markForDeleteA2 = 0\n" +
                    "        AND doc.latestiterationInfo = 1\n" +
                    "        AND typed.idA3masterReference = typeMater.idA2A2\n" +
                    "        AND typed.idA2A2 = doc.idA2typeDefinitionReference\n" +
                    "        AND typeMater.markForDeleteA2 = 0\n" +
                    "        AND typeMater.intHid LIKE '%com.fhsj.Doc_zs%'\n" +
                    "        AND doc.ida3b2folderinginfo=Folder.Ida2a2\n" +
                    "        --and doc.statestate='RELEASED'\n" +
                    "      ) t1\n" +
                    "      left join (\n" +
                    "        select \n" +
                    "          strDef.name name,\n" +
                    "          strVal.value2 value,\n" +
                    "          strVal.ida3a4 attrId\n" +
                    "        from \n" +
                    "          wcadmin.StringDefinition strDef,\n" +
                    "          wcadmin.StringValue strVal\n" +
                    "        where strDef.idA2A2 = strVal.idA3A6\n" +
                    "       \n" +
                    "      ) t2 on t2.attrId = t1.docId \n" +
                    "),\n" +
                    "t3 as (  \n" +
                    "      select \n" +
                    "        docId,\n" +
                    "        name,\n" +
                    "        value,\n" +
                    "        description,\n" +
                    "        FolderName,\n" +
                    "        docnumber,\n" +
                    "        iterationida2iterationinfo,\n" +
                    "        VERSIONIDA2VERSIONINFO,\n" +
                    "        rank() over (partition by docnumber order by VERSIONIDA2VERSIONINFO desc) rank\n" +
                    "      from t1 where t1.FolderName='A0901_证书' \n" +
                    "      and name = 'ct_model'\n" +
                    "      and latestiterationInfo = 1\n" +
                    "      order by VERSIONIDA2VERSIONINFO desc\n" +
                    "),\n" +
                    "t4 as (\n" +
                    "      select \n" +
                    "        docId,\n" +
                    "        docnumber,\n" +
                    "        name,\n" +
                    "        listagg(value, ',') within group (order by value) value,\n" +
                    "        description,\n" +
                    "        FolderName,\n" +
                    "        iterationida2iterationinfo,\n" +
                    "        VERSIONIDA2VERSIONINFO\n" +
                    "      from t3 where rank = 1\n" +
                    "      group by \n" +
                    "        docId,\n" +
                    "        docnumber,\n" +
                    "        name,\n" +
                    "        description,\n" +
                    "        FolderName,\n" +
                    "        iterationida2iterationinfo,\n" +
                    "        VERSIONIDA2VERSIONINFO\n" +
                    "),\n" +
                    "iba1 as(\n" +
                    "      select * from t1 \n" +
                    "      pivot (\n" +
                    "        max(value)\n" +
                    "        FOR name IN(\n" +
                    "          'ct_productName' as ct_productName,\n" +
                    "          'ct_Certificatenumber' as ct_Certificatenumber,\n" +
                    "          'ct_CancellationResume' as ct_CancellationResume,\n" +
                    "          'ct_Authenticationtype' as ct_Authenticationtype\n" +
                    "        )\n" +
                    "      )\n" +
                    "),\n" +
                    "iba2 as (\n" +
                    "    select \n" +
                    "    distinct\n" +
                    "      iba1.docid,\n" +
                    "      iba1.DESCRIPTION,\n" +
                    "      iba1.foldername,\n" +
                    "      iba1.docnumber,\n" +
                    "      iba1.branchiditerationinfo,\n" +
                    "      iba1.ITERATIONIDA2ITERATIONINFO,\n" +
                    "      iba1.VERSIONIDA2VERSIONINFO,\n" +
                    "      iba1.LATESTITERATIONINFO,\n" +
                    "      iba1.CT_productName,\n" +
                    "      iba1.ct_Certificatenumber,\n" +
                    "      iba1.ct_CancellationResume,\n" +
                    "      iba1.ct_Authenticationtype,\n" +
                    "      t4.value ct_model\n" +
                    "    from iba1 \n" +
                    "    inner join t4 \n" +
                    "    on iba1.docid = t4.docid \n" +
                    ")\n" +
                    "select \n" +
                    "  docid,\n" +
                    "  docnumber,\n" +
                    "  branchiditerationinfo,\n" +
                    "  ct_productName,\n" +
                    "  ct_model,\n" +
                    "  ct_CancellationResume\n" +
                    "from iba2\n" +
                    "where iba2.FolderName='A0901_证书' \n" +
                    "and (\n" +
                    "iba2.ct_CancellationResume is not null\n" +
                    "or ct_Authenticationtype in (\n" +
                    "      'ct_TCCC_certification',\n" +
                    "      'ct_TZYX_certification',\n" +
                    "      'ct_TJSJD_certification',\n" +
                    "      'ct_TFB_certification',\n" +
                    "      'ct_TLPCB_certification',\n" +
                    "      'ct_TAPPLUS_certification',\n" +
                    "      'ct_TCoC_certification',\n" +
                    "      'ct_TDX_certification',\n" +
                    "      'ct_TWXD_certification',\n" +
                    "      'ct_TJLQJ_certification',\n" +
                    "      'ct_TCCS_certification',\n" +
                    "      'ct_TUL_certification',\n" +
                    "      'ct_TSIL_certification',\n" +
                    "      'ct_TCEGN_certification',\n" +
                    "      'ct_TCJ_certification',\n" +
                    "      'ct_TNothing_certification',\n" +
                    "      'ct_TCEOZ_certification'\n" +
                    "    )\n" +
                    ")";
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();
            int groupno = 1;
            while (result.next()) {
                ZsReportDto zsReportDto = new ZsReportDto();
                String docid=result.getString("docid");
                String docnumber=result.getString("docnumber");
                String docurl=result.getString("branchiditerationinfo");
                String ct_productName=result.getString("ct_productName");
                String ct_model=result.getString("ct_model");
                String ct_CancellationResume=result.getString("ct_CancellationResume");
                zsReportDto.setGroupno(groupno);
                zsReportDto.setDocid(docid);
                zsReportDto.setDocnumber(docnumber);
                zsReportDto.setDocurl(docurl);
                zsReportDto.setCt_productName(ct_productName);
                zsReportDto.setCt_model(ct_model);
                zsReportDto.setCt_CancellationResume(ct_CancellationResume);
                zsReportDtos.add(zsReportDto);
                groupno++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return  zsReportDtos;
    }

    /**
     * 认证导出
     * @param os
     * @throws Exception
     */
    public void exportproductrz(OutputStream os) throws Exception{
        //获取认证数据导出
        List<RzReportDto> rzReportDtos = queryDataRzReportJdbc();

        XSSFWorkbook workBook = new XSSFWorkbook();
        //sheet标题
        XSSFSheet sheet = workBook.createSheet("产品认证信息对照表");
        //设置单元格格式
        CellStyle cellStyle = getCellStyle(workBook);
        //创建第一行
        XSSFRow titleRow = sheet.createRow(0);
        //第一行第一个单元格
        XSSFCell titleCell = titleRow.createCell(0);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("序号");
        //第一行第二个单元格
        titleCell = titleRow.createCell(1);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("文档编号");
        titleCell = titleRow.createCell(2);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("认证产品名称");
        titleCell = titleRow.createCell(3);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("型号");
        titleCell = titleRow.createCell(4);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("物料编码(此代码为PLM系统所有同型号代码，非所有代码都经过认证送检)");
        titleCell = titleRow.createCell(5);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("认证类型");
        titleCell = titleRow.createCell(6);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("首次发证日期");
        titleCell = titleRow.createCell(7);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("获得证书日期");
        titleCell = titleRow.createCell(8);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("证书到期日期");
        titleCell = titleRow.createCell(9);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("证书编号");
        titleCell = titleRow.createCell(10);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("校验报告");
        titleCell = titleRow.createCell(11);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("产品标准");
        titleCell = titleRow.createCell(12);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("变更履历");
        titleCell = titleRow.createCell(13);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("身份信息类型");
        int rowNum = 1;
        for (RzReportDto rzReportDto : rzReportDtos) {
            XSSFRow row = sheet.createRow(rowNum);

            XSSFCell cell = row.createCell(0);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getGroupno());

            cell = row.createCell(1);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getDocnumber());

            cell = row.createCell(2);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_productName());

            cell = row.createCell(3);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_model());

            cell = row.createCell(4);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_materialsnumber());

            cell = row.createCell(5);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_Authenticationtype());

            cell = row.createCell(6);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_Dateoffirstissuance());

            cell = row.createCell(7);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_DateofObtainingCertificate());

            cell = row.createCell(8);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_Certificateexpirationdate());

            cell = row.createCell(9);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_Certificatenumber());

            cell = row.createCell(10);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_1InspectionReportNo());

            cell = row.createCell(11);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_1Productstandard());

            cell = row.createCell(12);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getDescription());

            cell = row.createCell(13);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(rzReportDto.getCt_Identityinformationtype());

            rowNum++;
        }
        workBook.write(os);
        os.close();
        os.flush();
    }

    /**
     * 证书注销汇总表
     * @param os
     * @throws Exception
     */
    public void exportproductzs(OutputStream os) throws Exception{
        //获取认证数据导出
        List<ZsReportDto> zsReportDtos = queryDataZsReprot();

        XSSFWorkbook workBook = new XSSFWorkbook();
        //sheet标题
        XSSFSheet sheet = workBook.createSheet("产品认证信息对照表");
        //设置单元格格式
        CellStyle cellStyle = getCellStyle(workBook);
        //创建第一行
        XSSFRow titleRow = sheet.createRow(0);
        //第一行第一个单元格
        XSSFCell titleCell = titleRow.createCell(0);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("序号");
        //第一行第二个单元格
        titleCell = titleRow.createCell(1);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("文档编号");
        titleCell = titleRow.createCell(2);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("认证产品名称");
        titleCell = titleRow.createCell(3);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("型号");
        titleCell = titleRow.createCell(4);
        titleCell.setCellStyle(cellStyle);
        titleCell.setCellValue("注销履历");
        titleCell = titleRow.createCell(5);
        titleCell.setCellStyle(cellStyle);

        int rowNum = 1;
        for (ZsReportDto zsReportDto : zsReportDtos) {
            XSSFRow row = sheet.createRow(rowNum);

            XSSFCell cell = row.createCell(0);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(zsReportDto.getGroupno());

            cell = row.createCell(1);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(zsReportDto.getDocnumber());

            cell = row.createCell(2);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(zsReportDto.getCt_productName());

            cell = row.createCell(3);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(zsReportDto.getCt_model());

            cell = row.createCell(4);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(zsReportDto.getCt_CancellationResume());

            rowNum++;
        }
        workBook.write(os);
        os.close();
        os.flush();
    }

    private static CellStyle getCellStyle(Workbook workbook) {
        // 列样式
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setWrapText(true); // 自动换行
        Class<? extends CellStyle> cellStyleClass = cellStyle.getClass();
        try {
            // 优先找 wc3rdpartylibs.jar 下的POI类方法

            // 设置垂直居中
            Class<?> verticalAlignment = Class.forName("org.apache.poi.ss.usermodel.VerticalAlignment");
            Method setVerticalAlignment = cellStyleClass.getMethod("setVerticalAlignment", verticalAlignment);
            Object[] objects = verticalAlignment.getEnumConstants();
            for (Object object : objects) {
                if ("CENTER".equals(object.toString())) {
                    setVerticalAlignment.invoke(cellStyle, object);
                    break;
                }
            }

            // 设置水平居中
            Class<?> horizontalAlignment = Class.forName("org.apache.poi.ss.usermodel.HorizontalAlignment");
            Method setAlignment = cellStyleClass.getMethod("setAlignment", horizontalAlignment);
            objects = horizontalAlignment.getEnumConstants();
            for (Object object : objects) {
                if ("CENTER".equals(object.toString())) {
                    setAlignment.invoke(cellStyle, object);
                    break;
                }
            }

            Class<?> borderStyle = Class.forName("org.apache.poi.ss.usermodel.BorderStyle");
            Method setBorderTop = cellStyleClass.getMethod("setBorderTop", borderStyle);
            Method setBorderBottom = cellStyleClass.getMethod("setBorderBottom", borderStyle);
            Method setBorderLeft = cellStyleClass.getMethod("setBorderLeft", borderStyle);
            Method setBorderRight = cellStyleClass.getMethod("setBorderRight", borderStyle);

            objects = borderStyle.getEnumConstants();
            for (Object object : objects) {
                if ("THIN".equals(object.toString())) {
                    setBorderTop.invoke(cellStyle, object);
                    setBorderBottom.invoke(cellStyle, object);
                    setBorderLeft.invoke(cellStyle, object);
                    setBorderRight.invoke(cellStyle, object);
                    break;
                }
            }
        } catch (Exception e) {
            // 找不到，则加载 POI.jar 下的类方法
            try {
                Method setVerticalAlignment = cellStyleClass.getMethod("setVerticalAlignment", short.class);
                setVerticalAlignment.invoke(cellStyle, 1);

                Method setAlignment = cellStyleClass.getMethod("setAlignment", short.class);
                setAlignment.invoke(cellStyle, 2);


                Method setBorderTop = cellStyleClass.getMethod("setBorderTop", short.class);
                Method setBorderBottom = cellStyleClass.getMethod("setBorderBottom", short.class);
                Method setBorderLeft = cellStyleClass.getMethod("setBorderLeft", short.class);
                Method setBorderRight = cellStyleClass.getMethod("setBorderRight", short.class);

                setBorderTop.invoke(cellStyle, 1);
                setBorderBottom.invoke(cellStyle, 1);
                setBorderLeft.invoke(cellStyle, 1);
                setBorderRight.invoke(cellStyle, 1);
            } catch (Exception ex) {
                System.out.println("系统中不存在POI包！");
            }
        }
        return cellStyle;
    }
}
