package ext.plm.fanh.mapper;

import ext.plm.fanh.dto.RzReportDto;
import ext.plm.fanh.dto.ZsReportDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Author: cz
 * @Date: 2022/07/14
 * @Description:
 */
@Mapper
public interface CtFanhMapper {
    //产品认证信息
    List<RzReportDto> queryDataRzReport();

    //产品认证信息数量
    int queryDataRzReportNum();

    //证书注销汇总表
    List<ZsReportDto> queryDataZsReprot();

    //证书注销汇总表数量
    int queryDataZsReportNum();
}
