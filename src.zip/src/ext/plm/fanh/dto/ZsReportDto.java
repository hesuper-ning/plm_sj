package ext.plm.fanh.dto;

/**
 * @Author: lcd
 * @Date: 2022/7/14 16:50
 * @Description:
 */
public class ZsReportDto {
    /**
     * 序号
     */
    private int groupno;
    /**
     * 主文档id
     */
    private String docid;
    /**
     * 认证产品名称
     */
    private String docnumber;
    private String docurl;
    private String ct_productName;
    /**
     * 型号
     */
    private String ct_model;
    /**
     * 注销履历
     */
    private String ct_CancellationResume;

    public ZsReportDto() {
    }

    public String getDocnumber() {
        return docnumber;
    }

    public void setDocnumber(String docnumber) {
        this.docnumber = docnumber;
    }

    public String getDocurl() {
        return docurl;
    }

    public void setDocurl(String docurl) {
        this.docurl = docurl;
    }

    public String getDocid() {
        return docid;
    }
    public void setDocid(String docid) {
        this.docid = docid;
    }
    public String getCt_productName() {
        return ct_productName;
    }

    public void setCt_productName(String ct_productName) {
        this.ct_productName = ct_productName;
    }

    public String getCt_model() {
        return ct_model;
    }

    public void setCt_model(String ct_model) {
        this.ct_model = ct_model;
    }

    public String getCt_CancellationResume() {
        return ct_CancellationResume;
    }

    public void setCt_CancellationResume(String ct_CancellationResume) {
        this.ct_CancellationResume = ct_CancellationResume;
    }

    public int getGroupno() {
        return groupno;
    }

    public void setGroupno(int groupno) {
        this.groupno = groupno;
    }
}
