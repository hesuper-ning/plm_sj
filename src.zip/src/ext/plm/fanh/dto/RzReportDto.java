package ext.plm.fanh.dto;

/**
 * @Author: lcd
 * @Date: 2022/7/14 16:50
 * @Description:
 */
public class RzReportDto {
    /**
     * 序号
     */
    private int groupno;
    /**
     * 主键
     */
    private String docid;
    /**
     * 主文档id
     */
    private String docnumber;

    private String docurl;
    /**
     * 认证产品名称
     */
    private String ct_productName;
    /**
     * 型号
     */
    private String ct_model;
    /**
     * 物料编码
     */
    private String ct_materialsnumber;
    /**
     * 身份信息类型
     */
    private String ct_Identityinformationtype;
    /**
     * 认证类型
     */
    private String ct_Authenticationtype;
    /**
     * 首次发证日期
     */
    private String ct_Dateoffirstissuance;
    /**
     * 获得证书日期
     */
    private String ct_DateofObtainingCertificate;
    /**
     * 证书到期日期
     */
    private String ct_Certificateexpirationdate;
    /**
     * 证书
     */
    private String ct_Certificatenumber;
    /**
     * 校验报告
     */
    private String ct_1InspectionReportNo;
    /**
     * 产品标准
     */
    private String ct_1Productstandard;
    /**
     * 描述
     */
    private String description;

    public String getDocid() {
        return docid;
    }

    public void setDocid(String docid) {
        this.docid = docid;
    }

    public String getDocnumber() {
        return docnumber;
    }

    public void setDocnumber(String docnumber) {
        this.docnumber = docnumber;
    }

    public String getDocurl() {
        return docurl;
    }

    public void setDocurl(String docurl) {
        this.docurl = docurl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCt_productName() {
        return ct_productName;
    }

    public void setCt_productName(String ct_productName) {
        this.ct_productName = ct_productName;
    }

    public String getCt_model() {
        return ct_model;
    }

    public void setCt_model(String ct_model) {
        this.ct_model = ct_model;
    }

    public String getCt_materialsnumber() {
        return ct_materialsnumber;
    }

    public void setCt_materialsnumber(String ct_materialsnumber) {
        this.ct_materialsnumber = ct_materialsnumber;
    }

    public String getCt_Identityinformationtype() {
        return ct_Identityinformationtype;
    }

    public void setCt_Identityinformationtype(String ct_Identityinformationtype) {
        this.ct_Identityinformationtype = ct_Identityinformationtype;
    }

    public String getCt_Authenticationtype() {
        return ct_Authenticationtype;
    }

    public void setCt_Authenticationtype(String ct_Authenticationtype) {
        this.ct_Authenticationtype = ct_Authenticationtype;
    }

    public String getCt_Dateoffirstissuance() {
        return ct_Dateoffirstissuance;
    }

    public void setCt_Dateoffirstissuance(String ct_Dateoffirstissuance) {
        this.ct_Dateoffirstissuance = ct_Dateoffirstissuance;
    }

    public String getCt_DateofObtainingCertificate() {
        return ct_DateofObtainingCertificate;
    }

    public void setCt_DateofObtainingCertificate(String ct_DateofObtainingCertificate) {
        this.ct_DateofObtainingCertificate = ct_DateofObtainingCertificate;
    }

    public String getCt_Certificateexpirationdate() {
        return ct_Certificateexpirationdate;
    }

    public void setCt_Certificateexpirationdate(String ct_Certificateexpirationdate) {
        this.ct_Certificateexpirationdate = ct_Certificateexpirationdate;
    }

    public String getCt_Certificatenumber() {
        return ct_Certificatenumber;
    }

    public void setCt_Certificatenumber(String ct_Certificatenumber) {
        this.ct_Certificatenumber = ct_Certificatenumber;
    }

    public String getCt_1InspectionReportNo() {
        return ct_1InspectionReportNo;
    }

    public void setCt_1InspectionReportNo(String ct_1InspectionReportNo) {
        this.ct_1InspectionReportNo = ct_1InspectionReportNo;
    }

    public String getCt_1Productstandard() {
        return ct_1Productstandard;
    }

    public void setCt_1Productstandard(String ct_1Productstandard) {
        this.ct_1Productstandard = ct_1Productstandard;
    }

    public int getGroupno() {
        return groupno;
    }

    public void setGroupno(int groupno) {
        this.groupno = groupno;
    }
}
