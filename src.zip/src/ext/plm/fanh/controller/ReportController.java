package ext.plm.fanh.controller;
import com.alibaba.fastjson.JSONObject;
import ext.plm.fanh.dto.RzReportDto;
import ext.plm.fanh.dto.ZsReportDto;
import ext.plm.fanh.mapper.CtFanhMapper;
import ext.plm.fanh.model.LayuiTableResult;

import ext.plm.fanh.service.ReportService;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import wt.doc.WTDocument;
import wt.part.WTPart;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.util.List;

@RequestMapping("/fanh/report")
@RestController
public class ReportController {
    @Autowired
    private CtFanhMapper ctFanhMapper;

    @Autowired
    private ReportService reportService;

    @GetMapping("/productrz")
    public LayuiTableResult productrz() throws Exception {
        List<RzReportDto> rzReportDtos = reportService.queryDataRzReportJdbc();
        return new LayuiTableResult(0,rzReportDtos);
    }

    @RequestMapping(value = "/productrz/export", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportproductrz(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        JSONObject result = new JSONObject();
        OutputStream os = response.getOutputStream();
        try {
            response.setCharacterEncoding("utf-8");
            response.setContentType("application/msexcel");
            response.setHeader("Content-Disposition", "attachment;filename="
                    + java.net.URLEncoder.encode("产品认证信息对照表", "UTF-8") + ".xlsx");
            response.setHeader("Cache-Control", "no-cache");
            reportService.exportproductrz(os);
        } catch (Exception e){
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "导出Excel失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    @GetMapping("/productzs")
    public LayuiTableResult productzs() throws Exception {
        List<ZsReportDto> zsReportDtos = reportService.queryDataZsReprot();
        return new LayuiTableResult(0,zsReportDtos);
    }

    @RequestMapping(value = "/productzs/export", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportproductzs(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        JSONObject result = new JSONObject();
        OutputStream os = response.getOutputStream();
        try {
            response.setCharacterEncoding("utf-8");
            response.setContentType("application/msexcel");
            response.setHeader("Content-Disposition", "attachment;filename="
                    + java.net.URLEncoder.encode("证书注销汇总表", "UTF-8") + ".xlsx");
            response.setHeader("Cache-Control", "no-cache");
            reportService.exportproductzs(os);
        } catch (Exception e){
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "导出Excel失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }
}
