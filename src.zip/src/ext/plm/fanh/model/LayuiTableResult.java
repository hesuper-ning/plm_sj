package ext.plm.fanh.model;


import java.util.List;

/**
 * layui表格返回参数
 */
public class LayuiTableResult {
     Integer code;
     String msg;
     Integer count;
     List<? extends Object> data;

     public LayuiTableResult(){}
     public LayuiTableResult(Integer code,String msg,Integer count,List<? extends Object>  data){
          this.code = code;
          this.msg = msg;
          this.count = count;
          this.data = data;
     }
     public LayuiTableResult(Integer count,List<? extends Object>  data){
          this.code = 0;
          this.msg = "success";
          this.count = count;
          this.data = data;
     }

     public Integer getCode() {
          return code;
     }

     public void setCode(Integer code) {
          this.code = code;
     }

     public String getMsg() {
          return msg;
     }

     public void setMsg(String msg) {
          this.msg = msg;
     }

     public Integer getCount() {
          return count;
     }

     public void setCount(Integer count) {
          this.count = count;
     }

     public List<? extends Object> getData() {
          return data;
     }

     public void setData(List<? extends Object> data) {
          this.data = data;
     }
}
