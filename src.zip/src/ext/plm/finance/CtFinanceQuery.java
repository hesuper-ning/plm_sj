package ext.plm.finance;

import ext.plm.ec.bo.CtChangeItemBo;
import ext.plm.ec.bo.CtEBomChangeItemBo;
import ext.plm.finance.bo.CtEarlyWarningBo;
import ext.plm.util.CtFormatUtil;
import org.apache.log4j.Logger;
import wt.method.MethodContext;
import wt.pom.Transaction;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class CtFinanceQuery {

    static Logger logger = Logger.getLogger(CtFinanceQuery.class);

    /**
     * 通过项目编号查询各部门实际工时
     * @param projectNumber
     * @return
     * @throws Exception
     */
    public static Map<String, Double> queryDepartmentActualWorkingHours(String projectNumber) throws Exception {
        Map<String, Double> map = new HashMap<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("select z.USERDEPARTMENT, SUM(i.MANHOUR) from ZWORKREPORT z")
                    .append(" join ZWORKREPORTITEM i on z.id = i.masterId where 1=1")
                    .append(" and z.docState != '创建' and z.docState != '返工'")
                    .append(" AND i.PROJECTNUMBER = ?")
                    .append(" GROUP BY z.USERDEPARTMENT");
            logger.debug("queryDepartmentActualWorkingHours>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, projectNumber);
            rs = statement.executeQuery();
            String departmentName = "";
            double workingHours = 0;
            while (rs.next()) {
                departmentName = rs.getString(1);
                workingHours = rs.getDouble(2);
                map.put(departmentName, workingHours);
            }
        } catch (Exception var12) {
            logger.error("通过项目工号查询各部门实际工时异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return map;
    }

    /**
     * 通过项目编号查询各部门实际金额
     * @param projectNumber
     * @return
     * @throws Exception
     */
    public static Map<String, String> queryDepartmentActualAmount(String projectNumber) throws Exception {
        Map<String, String> map = new HashMap<>();
        if(!CtFormatUtil.hasContent(projectNumber) || projectNumber.length() < 4){
            return map;
        }
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT z1.PROPERTYVALUE, ROUND(sum(COSTAMOUNT), 2)  FROM ZBISUBJECTCOST z LEFT JOIN\n" +
                    "                 (SELECT c2.PROPERTYKEY, c2.PROPERTYVALUE FROM ZConfigMenu c1 INNER JOIN ZPropertyConfig c2\n" +
                    "                 ON c1.ID = c2.CONFIGMENUID WHERE c1.INNERNAME = 'departmentNameAndNumberMapping'\n" +
                    "                 ) z1 ON z1.PROPERTYKEY = z.COSTCENTERCODE\n" +
                    "                 LEFT JOIN (SELECT c2.PROPERTYKEY, c2.PROPERTYVALUE FROM ZConfigMenu c1 INNER JOIN ZPropertyConfig c2\n" +
                    "                     ON c1.ID = c2.CONFIGMENUID WHERE c1.INNERNAME = 'projectSubjectsMapping'\n" +
                    "                 ) z2 ON z2.PROPERTYKEY = z.SUBJECT\n" +
                    "                 WHERE z.ORDERNUMBER like ?\n" +
                    "                 AND z1.PROPERTYVALUE IS NOT NULL\n" +
                    "                 AND z2.PROPERTYVALUE = '人力资源费用（元）'\n" +
                    "                 GROUP BY z1.PROPERTYVALUE");
            logger.debug("queryDepartmentActualAmount>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            //截掉前面4位公司编号再去查询
            projectNumber = projectNumber.substring(4);
            statement.setString(1, "%" + projectNumber);
            rs = statement.executeQuery();
            String departmentName = "";
            String actualAmount = "";
            while (rs.next()) {
                departmentName = rs.getString(1);
                actualAmount = rs.getString(2);
                map.put(departmentName, actualAmount);
            }
        } catch (Exception var12) {
            logger.error("通过项目编号查询各部门实际金额异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return map;
    }

    /**
     * 通过项目编号查询各科目实际金额
     * @param projectNumber
     * @return
     * @throws Exception
     */
    public static Map<String, String> querySubjectActualAmount(String projectNumber) throws Exception {
        Map<String, String> map = new HashMap<>();
        if(!CtFormatUtil.hasContent(projectNumber) || projectNumber.length() < 4){
            return map;
        }
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT z1.PROPERTYVALUE, ROUND(sum(COSTAMOUNT), 2)  FROM ZBISUBJECTCOST z LEFT JOIN")
                    .append(" (SELECT c2.PROPERTYKEY, c2.PROPERTYVALUE FROM ZConfigMenu c1 INNER JOIN ZPropertyConfig c2")
                    .append(" ON c1.ID = c2.CONFIGMENUID WHERE c1.INNERNAME = 'projectSubjectsMapping'")
                    .append(" ) z1 ON z1.PROPERTYKEY = z.SUBJECT")
                    .append(" WHERE z.ORDERNUMBER like ?")
                    .append(" AND z1.PROPERTYVALUE IS NOT NULL")
                    .append(" GROUP BY z1.PROPERTYVALUE");
            logger.debug("querySubjectActualAmount>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            //截掉前面4位公司编号再去查询
            projectNumber = projectNumber.substring(4);
            statement.setString(1, "%" + projectNumber);
            rs = statement.executeQuery();
            String subjectName = "";
            String actualAmount = "";
            while (rs.next()) {
                subjectName = rs.getString(1);
                actualAmount = rs.getString(2);
                map.put(subjectName, actualAmount);
            }
        } catch (Exception var12) {
            logger.error("通过项目编号查询各科目实际金额异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return map;
    }

    /**
     * 查询物料所有阶梯
     * @param branchId
     * @return
     * @throws Exception
     */
    public static Map<String, String> queryAllPartStep(Long branchId) throws Exception {
        Map<String, String> map = new HashMap<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.PARTNUMBER, '0-' || LISTAGG(t.STEPCOUNT,'-') WITHIN GROUP(ORDER BY TO_NUMBER(STEPCOUNT)) partStep")
                    .append(" FROM ZTargetCostTable t")
                    .append(" WHERE t.BRANCHID = ? AND t.COSTPROJECT = '制造成本-制造费用' AND t.CHARTERCOST IS NOT NULL")
                    .append(" GROUP BY t.PARTNUMBER");
            logger.debug("queryAllPartStep>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setLong(1, branchId);
            rs = statement.executeQuery();
            String partNumber = "";
            String partStep = "";
            while (rs.next()) {
                partNumber = rs.getString(1);
                partStep = rs.getString(2);
                map.put(partNumber, partStep);
            }
        } catch (Exception var12) {
            logger.error("查询物料所有阶梯异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return map;
    }

    /**
     * 项目群预算执行报表
     * @param
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> queryBudgetExecutionReport(String projectName, String productLine,
        String startTime1, String startTime2, String endTime1, String endTime2) throws Exception {
        List<Map<String, String>> resultList = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT p.PROJECTNUMBER, p.NAMECONTAINERINFO, z.value2, f4.WORKINGHOURS0, s1.manHour, f5.SUMMARY budgetAmount,\n" +
                    "                     s3.executionAmount, s2.budgetAmount1, s4.executionAmount1\n" +
                    "                     FROM PROJECT2 p\n" +
                    "                     LEFT JOIN (\n" +
                    "                     SELECT f1.PREDICTEDSITUATION, f1.BRANCHID FROM WTDOCUMENT w\n" +
                    "                     LEFT JOIN ZFINANCEBD001TABLE f1 ON w.BRANCHIDITERATIONINFO = f1.BRANCHID AND f1.PROJECT = '项目编码*'\n" +
                    "                     where w.LATESTITERATIONINFO = 1 AND w.STATECHECKOUTINFO IN ('c/o','c/i') AND w.STATESTATE = 'RELEASED' AND f1.PREDICTEDSITUATION IS NOT null\n" +
                    "                     ) s0 ON s0.PREDICTEDSITUATION = p.PROJECTNUMBER\n" +
                    "                     LEFT JOIN ZFINANCEBD004TABLE f4 ON f4.BRANCHID = s0.BRANCHID AND f4.type1='总计'\n" +
                    "                     LEFT JOIN (\n" +
                    "                     select SUM(i.MANHOUR) AS manHour, i.PROJECTNUMBER from ZWORKREPORT z\n" +
                    "                     join ZWORKREPORTITEM i on z.id = i.masterId where 1=1\n" +
                    "                     and z.docState != '创建' and z.docState != '返工'\n" +
                    "                     GROUP BY i.PROJECTNUMBER\n" +
                    "                     ) s1 ON s1.PROJECTNUMBER = p.PROJECTNUMBER\n" +
                    "                     LEFT JOIN ZFINANCEBD005TABLE f5 ON f4.BRANCHID=f5.BRANCHID AND f5.COSTTYPE = '人力资源费用（元）'\n" +
                    "                     LEFT JOIN (\n" +
                    "                     SELECT SUM(f6.SUMMARY) AS budgetAmount1, f6.BRANCHID FROM ZFINANCEBD005TABLE f6 where f6.COSTTYPE IN (\n" +
                    "                     '其他（元）*','专利登记及年费（元）*','物料消耗（元）*','开发材料费（元）*','技术协作费（元）*','公杂费（元）*','产品试制模具费（元）*','产品检测费（元）*')\n" +
                    "                     GROUP BY f6.BRANCHID\n" +
                    "                     ) s2 ON f4.BRANCHID=s2.BRANCHID\n" +
                    "                     LEFT JOIN (\n" +
                    "                     SELECT sum(COSTAMOUNT) executionAmount, SUBSTR(z.ORDERNUMBER, 5) ORDERNUMBER FROM ZBISUBJECTCOST z LEFT JOIN\n" +
                    "                     (SELECT c2.PROPERTYKEY, c2.PROPERTYVALUE FROM ZConfigMenu c1 INNER JOIN ZPropertyConfig c2\n" +
                    "                     ON c1.ID = c2.CONFIGMENUID WHERE c1.INNERNAME = 'projectSubjectsMapping'\n" +
                    "                     ) z1 ON z1.PROPERTYKEY = z.SUBJECT\n" +
                    "                     WHERE z1.PROPERTYVALUE IS NOT NULL\n" +
                    "                     AND z1.PROPERTYVALUE = '人力资源费用（元）'\n" +
                    "                     GROUP BY SUBSTR(z.ORDERNUMBER, 5) \n" +
                    "                     ) s3 ON s3.ORDERNUMBER = SUBSTR(p.PROJECTNUMBER, 5)\n" +
                    "                     LEFT JOIN (\n" +
                    "                     SELECT sum(COSTAMOUNT) executionAmount1, SUBSTR(z.ORDERNUMBER, 5) ORDERNUMBER FROM ZBISUBJECTCOST z LEFT JOIN\n" +
                    "                     (SELECT c2.PROPERTYKEY, c2.PROPERTYVALUE FROM ZConfigMenu c1 INNER JOIN ZPropertyConfig c2\n" +
                    "                     ON c1.ID = c2.CONFIGMENUID WHERE c1.INNERNAME = 'projectSubjectsMapping'\n" +
                    "                     ) z1 ON z1.PROPERTYKEY = z.SUBJECT\n" +
                    "                     WHERE z1.PROPERTYVALUE IS NOT NULL\n" +
                    "                     AND z1.PROPERTYVALUE != '人力资源费用（元）' AND z1.PROPERTYVALUE != '间接费用（元）*'\n" +
                    "                     GROUP BY SUBSTR(z.ORDERNUMBER, 5) \n" +
                    "                     ) s4 ON s4.ORDERNUMBER = SUBSTR(p.PROJECTNUMBER, 5) \n" +
                    "                     LEFT JOIN (\n" +
                    "                     SELECT s.value2, s.IDA3A4 FROM wcadmin.STRINGVALUE s, wcadmin.STRINGDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'ct_productLine'\n" +
                    "                     ) z ON p.IDA2A2 = z.IDA3A4\n" +
                    "                     LEFT JOIN(\n" +
                    "                     SELECT s.value, s.IDA3A4 FROM wcadmin.TIMESTAMPVALUE s, wcadmin.TIMESTAMPDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'Ct_Actualendtimeoftheproject'\n" +
                    "                     ) z1 ON p.IDA2A2 = z1.IDA3A4\n" +
                    "                     LEFT JOIN (\n" +
                    "                     SELECT pr.ENDTIME, z2.value2, w.BRANCHIDITERATIONINFO FROM WFPROCESS pr\n" +
                    "                     LEFT JOIN WTDOCUMENT w ON pr.BUSINESSOBJREFERENCE = 'VR:wt.doc.WTDocument:' || w.BRANCHIDITERATIONINFO\n" +
                    "                     LEFT JOIN (\n" +
                    "                     SELECT s.value2, s.IDA3A4 FROM wcadmin.STRINGVALUE s, wcadmin.STRINGDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'ct_ItemNumber'\n" +
                    "                     ) z2 ON w.IDA2A2 = z2.IDA3A4\n" +
                    "                     WHERE w.VERSIONIDA2VERSIONINFO = 'A'\n" +
                    "                     AND w.STATESTATE = 'RELEASED'\n" +
                    "                     AND z2.value2 IS NOT null\n" +
                    "                     AND w.IDA2TYPEDEFINITIONREFERENCE in\n" +
                    "                     (SELECT td.IDA2A2 FROM WTTYPEDEFINITIONMASTER tm INNER join WTTYPEDEFINITION td on tm.IDA2A2 = td.IDA3MASTERREFERENCE\n" +
                    "                     where tm.INTHID = 'wt.doc.WTDocument|com.fhsj.Doc_fhsj|com.fhsj.Doc_cw|com.fhsj.Doc_xmys')\n" +
                    "                     ) e ON e.value2 = p.PROJECTNUMBER  AND e.BRANCHIDITERATIONINFO = s0.BRANCHID\n" +
                    "                     WHERE 1=1 AND p.MARKFORDELETEA2=0");
            logger.debug("queryProjectNumberByCondition>>>>>>>>" + sql.toString());
            if(CtFormatUtil.hasContent(projectName)){
                sql.append(" AND p.NAMECONTAINERINFO LIKE ?");
            }
            if(CtFormatUtil.hasContent(productLine)){
                sql.append(" AND z.value2 = ?");
            }
            if(CtFormatUtil.hasContent(startTime1)){
                sql.append(" AND e.ENDTIME >= TO_DATE(?, 'yyyy-mm-dd') ");
            }
            if(CtFormatUtil.hasContent(startTime2)){
                sql.append(" AND e.ENDTIME <= TO_DATE(?, 'yyyy-mm-dd') ");
            }
            if(CtFormatUtil.hasContent(endTime1)){
                sql.append(" AND z1.value >= TO_DATE(?, 'yyyy-mm-dd') ");
            }
            if(CtFormatUtil.hasContent(endTime2)){
                sql.append(" AND z1.value <= TO_DATE(?, 'yyyy-mm-dd') ");
            }
            statement = connection.prepareStatement(sql.toString());

            int paramIndex = 1;
            if(CtFormatUtil.hasContent(projectName)){
                statement.setString(paramIndex, "%" + projectName + "%");
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(productLine)){
                statement.setString(paramIndex, productLine);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(startTime1)){
                statement.setString(paramIndex, startTime1);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(startTime2)){
                statement.setString(paramIndex, startTime2);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(endTime1)){
                statement.setString(paramIndex, endTime1);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(endTime2)){
                statement.setString(paramIndex, endTime2);
            }
            rs = statement.executeQuery();
            String projectNumber = "";
            String tempProjectName = "";
            String tempProductLine = "";
            String plannedWorkingHours = "";
            String actualWorkingHours = "";
            String budgetAmount = "";
            String executionAmount = "";
            String budgetAmount1 = "";
            String executionAmount1 = "";
            while (rs.next()) {
                Map<String, String> tempMap = new HashMap<>();
                projectNumber = rs.getString(1);
                tempProjectName = rs.getString(2);
                tempProductLine = rs.getString(3);
                plannedWorkingHours = rs.getString(4);
                actualWorkingHours = rs.getString(5);
                budgetAmount = rs.getString(6);
                executionAmount = rs.getString(7);
                budgetAmount1 = rs.getString(8);
                executionAmount1 = rs.getString(9);
                tempMap.put("projectNumber", projectNumber);
                tempMap.put("projectName", tempProjectName);
                tempMap.put("productLine", tempProductLine);
                tempMap.put("plannedWorkingHours", plannedWorkingHours);
                tempMap.put("actualWorkingHours", actualWorkingHours);
                if(CtFormatUtil.hasContent(plannedWorkingHours) && CtFormatUtil.hasContent(actualWorkingHours)
                        && Double.valueOf(plannedWorkingHours) != 0){
                    tempMap.put("utilizationRate", (Double.valueOf(actualWorkingHours)/Double.valueOf(plannedWorkingHours))+"");
                }
                tempMap.put("budgetAmount", budgetAmount);
                tempMap.put("executionAmount", executionAmount);
                if(CtFormatUtil.hasContent(budgetAmount) && CtFormatUtil.hasContent(executionAmount)
                        && Double.valueOf(budgetAmount) != 0){
                    tempMap.put("executionRate", (Double.valueOf(executionAmount)/Double.valueOf(budgetAmount))+"");
                }
                tempMap.put("budgetAmount1", budgetAmount1);
                tempMap.put("executionAmount1", executionAmount1);
                if(CtFormatUtil.hasContent(budgetAmount1) && CtFormatUtil.hasContent(executionAmount1)
                        && Double.valueOf(budgetAmount1) != 0){
                    tempMap.put("executionRate1", (Double.valueOf(executionAmount1)/Double.valueOf(budgetAmount1))+"");
                }
                resultList.add(tempMap);
            }
        } catch (Exception var12) {
            logger.error("通过项目编号查询各科目实际金额异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return resultList;
    }

    /**
     * 目标成本达成报表
     * @param
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> queryTargetCostAchievementReport(String projectName, String productLine,
        String startTime1, String startTime2, String endTime1, String endTime2, String productNumber, String costProject) throws Exception {
        List<Map<String, String>> resultList = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT p.PROJECTNUMBER,p.NAMECONTAINERINFO,z.value2,s0.productNumber,s1.PARTDESC,s1.costProject1,s1.STEPCOUNT,s1.partStep,")
                    .append(" CASE when s1.costProject1 = '制造成本-制造费用' THEN s1.CHARTERCOST ELSE s2.CHARTERCOST END CHARTERCOST,")
                    .append(" CASE when s1.costProject1 = '制造成本-制造费用' THEN s1.PDCPCOST ELSE s2.PDCPCOST END PDCPCOST,")
                    .append(" CASE when s1.costProject1 = '制造成本-制造费用' THEN s1.TR2COST ELSE s2.TR2COST END TR2COST,")
                    .append(" CASE when s1.costProject1 = '制造成本-制造费用' THEN s1.TR5COST ELSE s2.TR5COST END TR5COST,")
                    .append(" CASE when s1.costProject1 = '制造成本-制造费用' THEN s1.TR6COST ELSE s2.TR6COST END TR6COST,")
                    .append(" CASE when s1.costProject1 = '制造成本-制造费用' THEN s1.TR4COST ELSE s2.TR4COST END TR4COST")
                    .append(" FROM PROJECT2 p LEFT JOIN (")
                    .append(" SELECT DISTINCT s.value2 AS productNumber, s.IDA3A4 FROM wcadmin.STRINGVALUE s, wcadmin.STRINGDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'Ct_FinishedMaterialCode'")
                    .append(" ) s0 ON p.IDA2A2 = s0.IDA3A4")
                    .append(" LEFT JOIN (")
                    .append(" SELECT f1.BRANCHID, f1.PARTNUMBER, f1.PARTDESC, f2.costProject1, f1.STEPCOUNT, f1.CHARTERCOST, f1.PDCPCOST")
                    .append(" ,f1.TR2COST, f1.TR5COST, f1.TR6COST, f1.partStep, f1.TR4COST")
                    .append(" FROM WTDOCUMENT w LEFT JOIN ZTargetCostTable f1 ON w.BRANCHIDITERATIONINFO = f1.BRANCHID")
                    .append(" LEFT JOIN (")
                    .append(" SELECT 'BOM成本-电子' costProject1, '制造成本-制造费用' costProject2 FROM dual UNION")
                    .append(" SELECT 'BOM成本-结构' costProject1, '制造成本-制造费用' costProject2 FROM dual UNION")
                    .append(" SELECT 'BOM成本-包装' costProject1, '制造成本-制造费用' costProject2 FROM dual UNION")
                    .append(" SELECT 'BOM成本-其他' costProject1, '制造成本-制造费用' costProject2 FROM dual UNION")
                    .append(" SELECT '制造成本-委外加工' costProject1, '制造成本-制造费用' costProject2 FROM dual UNION")
                    .append(" SELECT '制造成本-制造费用' costProject1, '制造成本-制造费用' costProject2 FROM dual ")
                    .append(" ) f2 ON f2.costProject2=f1.COSTPROJECT")
                    .append(" WHERE w.LATESTITERATIONINFO = 1")
                    .append(" AND w.STATECHECKOUTINFO IN ('c/o','c/i')")
                    .append(" AND w.STATESTATE = 'RELEASED'")
                    .append(" AND f1.COSTPROJECT = '制造成本-制造费用'")
                    .append(" ) s1 ON s1.PARTNUMBER = s0.productNumber")
                    .append(" LEFT JOIN ZTargetCostTable s2 ON s2.BRANCHID=s1.BRANCHID AND s2.PARTNUMBER=s1.PARTNUMBER AND s2.COSTPROJECT=s1.costProject1 AND s2.COSTPROJECT != '制造成本-制造费用'")
                    .append(" LEFT JOIN (")
                    .append(" SELECT s.value2, s.IDA3A4 FROM wcadmin.STRINGVALUE s, wcadmin.STRINGDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'ct_productLine'")
                    .append(" ) z ON p.IDA2A2 = z.IDA3A4")
                    .append(" LEFT JOIN(")
                    .append(" SELECT s.value, s.IDA3A4 FROM wcadmin.TIMESTAMPVALUE s, wcadmin.TIMESTAMPDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'Ct_Actualendtimeoftheproject'")
                    .append(" ) z1 ON p.IDA2A2 = z1.IDA3A4")
                    .append(" LEFT JOIN (")
                    .append(" SELECT pr.ENDTIME, z2.value2, w.BRANCHIDITERATIONINFO FROM WFPROCESS pr")
                    .append(" LEFT JOIN WTDOCUMENT w ON pr.BUSINESSOBJREFERENCE = 'VR:wt.doc.WTDocument:' || w.BRANCHIDITERATIONINFO")
                    .append(" LEFT JOIN (")
                    .append(" SELECT s.value2, s.IDA3A4 FROM wcadmin.STRINGVALUE s, wcadmin.STRINGDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'ct_ItemNumber'")
                    .append(" ) z2 ON w.IDA2A2 = z2.IDA3A4")
                    .append(" WHERE w.VERSIONIDA2VERSIONINFO = 'A'")
                    .append(" AND w.STATESTATE = 'RELEASED'")
                    .append(" AND z2.value2 IS NOT null")
                    .append(" AND w.IDA2TYPEDEFINITIONREFERENCE in")
                    .append(" (SELECT td.IDA2A2 FROM WTTYPEDEFINITIONMASTER tm INNER join WTTYPEDEFINITION td on tm.IDA2A2 = td.IDA3MASTERREFERENCE")
                    .append(" where tm.INTHID = 'wt.doc.WTDocument|com.fhsj.Doc_fhsj|com.fhsj.Doc_cw|com.fhsj.Doc_cpmbcbfxygzb') AND pr.STATE = 'CLOSED_COMPLETED_EXECUTED'")
                    .append(" ) e ON e.value2 = p.PROJECTNUMBER WHERE 1=1 AND p.MARKFORDELETEA2=0");
            logger.debug("queryTargetCostAchievementReport>>>>>>>>" + sql.toString());
            if(CtFormatUtil.hasContent(projectName)){
                sql.append(" AND p.NAMECONTAINERINFO LIKE ?");
            }
            if(CtFormatUtil.hasContent(productLine)){
                sql.append(" AND z.value2 = ?");
            }
            if(CtFormatUtil.hasContent(startTime1)){
                sql.append(" AND e.ENDTIME >= TO_DATE(?, 'yyyy-mm-dd') ");
            }
            if(CtFormatUtil.hasContent(startTime2)){
                sql.append(" AND e.ENDTIME <= TO_DATE(?, 'yyyy-mm-dd') ");
            }
            if(CtFormatUtil.hasContent(endTime1)){
                sql.append(" AND z1.value >= TO_DATE(?, 'yyyy-mm-dd') ");
            }
            if(CtFormatUtil.hasContent(endTime2)){
                sql.append(" AND z1.value <= TO_DATE(?, 'yyyy-mm-dd') ");
            }
            if(CtFormatUtil.hasContent(productNumber)){
                sql.append(" AND s0.productNumber = ?");
            }
            if(CtFormatUtil.hasContent(costProject)){
                sql.append(" AND s1.costProject1 = ?");
            }
            sql.append(" ORDER BY p.PROJECTNUMBER, s0.productNumber,s1.STEPCOUNT,s1.COSTPROJECT1");
            statement = connection.prepareStatement(sql.toString());

            int paramIndex = 1;
            if(CtFormatUtil.hasContent(projectName)){
                statement.setString(paramIndex, "%" + projectName + "%");
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(productLine)){
                statement.setString(paramIndex, productLine);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(startTime1)){
                statement.setString(paramIndex, startTime1);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(startTime2)){
                statement.setString(paramIndex, startTime2);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(endTime1)){
                statement.setString(paramIndex, endTime1);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(endTime2)){
                statement.setString(paramIndex, endTime2);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(productNumber)){
                statement.setString(paramIndex, productNumber);
                paramIndex++;
            }
            if(CtFormatUtil.hasContent(costProject)){
                statement.setString(paramIndex, costProject);
            }

            rs = statement.executeQuery();
            String projectNumber = "";
            String tempProjectName = "";
            String tempProductLine = "";
            String partNumber = "";
            String partDesc = "";
            String costProject1 = "";
            String stepCount = "";
            String partStep = "";
            String charterCost = "";
            String pdcpCost = "";
            String tr2Cost = "";
            String tr5Cost = "";
            String tr6Cost = "";
            String tr4Cost = "";
            while (rs.next()) {
                Map<String, String> tempMap = new HashMap<>();
                projectNumber = rs.getString(1);
                tempMap.put("projectNumber", projectNumber);
                tempProjectName = rs.getString(2);
                tempMap.put("projectName", tempProjectName);
                tempProductLine = rs.getString(3);
                tempMap.put("productLine", tempProductLine);
                partNumber = rs.getString(4);
                tempMap.put("productNumber", partNumber);
                partDesc = rs.getString(5);
                tempMap.put("productDesc", partDesc);
                costProject1 = rs.getString(6);
                tempMap.put("costProject", costProject1);
                stepCount = rs.getString(7);
                tempMap.put("stepCount", stepCount);
                partStep = rs.getString(8);
                tempMap.put("partStep", partStep);
                charterCost = rs.getString(9);
                tempMap.put("charterCost", charterCost);
                pdcpCost = rs.getString(10);
                tempMap.put("pdcpCost", pdcpCost);
                tr2Cost = rs.getString(11);
                tempMap.put("tr2Cost", tr2Cost);
                tr5Cost = rs.getString(12);
                tempMap.put("tr5Cost", tr5Cost);
                tr6Cost = rs.getString(13);
                tempMap.put("tr6Cost", tr6Cost);
                tr4Cost = rs.getString(14);
                tempMap.put("tr4Cost", tr4Cost);
                resultList.add(tempMap);
            }
        } catch (Exception var12) {
            logger.error("目标成本达成报表异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return resultList;
    }

    /**
     * 查询上个月完成项目的成本分解与跟踪表数据
     * @return
     * @throws Exception
     */
    public static Map<String, Map<String, List<Map<String, String>>>> queryProjectsCompletedLastMonthData() throws Exception {
        Map<String, Map<String, List<Map<String, String>>>> resultMap = new HashMap<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT a.PROJECTNUMBER, w2.WTDocumentnumber ,c.PARTNUMBER, c.COSTPROJECT, c.PDCPCOST, c.PARTSTEP FROM \n" +
                    "(SELECT p.PROJECTNUMBER, p.IDA2A2 FROM PROJECT2 p WHERE 1=1 AND MARKFORDELETEA2 = 0\n" +
                    "AND TO_CHAR(p.ACTUALENDCONTAINERTEAMMANAGE, 'yyyy-mm-dd')  >= TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -1), 'yyyy-mm-dd')\n" +
                    "AND TO_CHAR(p.ACTUALENDCONTAINERTEAMMANAGE, 'yyyy-mm-dd') <= TO_CHAR(ADD_MONTHS(LAST_DAY(SYSDATE), -1), 'yyyy-mm-dd') AND p.STATECONTAINERTEAMMANAGEDINF = 'COMPLETED'\n" +
                    ") a\n" +
                    "LEFT JOIN \n" +
                    "(\n" +
                    "SELECT s.value2, s.IDA3A4 FROM wcadmin.STRINGVALUE s, wcadmin.STRINGDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'ct_ItemNumber'\n" +
                    ") z ON a.PROJECTNUMBER = z.value2 \n" +
                    "LEFT JOIN \n" +
                    "(\n" +
                    "SELECT s.value2, s.IDA3A4 FROM wcadmin.STRINGVALUE s, wcadmin.STRINGDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'Ct_FinishedMaterialCode'\n" +
                    ") z1 ON a.IDA2A2 = z1.IDA3A4 \n" +
                    "\n" +
                    "LEFT JOIN \n" +
                    "WTDOCUMENT w ON w.IDA2A2 = z.IDA3A4\n" +
                    "LEFT JOIN ZTargetCostTable c ON c.BRANCHID = w.BRANCHIDITERATIONINFO \n" +
                    "LEFT JOIN WTDOCUMENTMASTER w2 ON w.IDA3MASTERREFERENCE = w2.IDA2A2 \n" +
                    "WHERE 1=1\n" +
                    "AND c.PARTNUMBER IS NOT NULL\n" +
                    "AND c.PARTNUMBER = z1.value2\n" +
                    "AND w.LATESTITERATIONINFO = 1\n" +
                    "AND w.VERSIONSORTIDA2VERSIONINFO = (SELECT max(w4.VERSIONSORTIDA2VERSIONINFO) FROM wcadmin.WTDOCUMENT w4 WHERE w4.IDA3MASTERREFERENCE = w.IDA3MASTERREFERENCE\n" +
                    "                     AND w4.LATESTITERATIONINFO=1) \n" +
                    "ORDER BY a.PROJECTNUMBER,c.PARTNUMBER\n");
            logger.debug("queryProjectsCompletedLastMonthData>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            rs = statement.executeQuery();
            String projectNumber = "";
            String partNumber = "";
            String costProject = "";
            String pdcpCost = "";
            String partStep = "";
            while (rs.next()) {
                projectNumber = rs.getString(1);
                partNumber = rs.getString(3);
                costProject = rs.getString(4);
                pdcpCost = rs.getString(5);
                partStep = rs.getString(6);

                if(resultMap.containsKey(projectNumber)){
                    Map<String, List<Map<String, String>>> projectMap = resultMap.get(projectNumber);
                    Map<String, String> partMap = new HashMap<>();
                    if(projectMap.containsKey(partNumber)){
                        List<Map<String, String>> partList = projectMap.get(partNumber);
                        partList.add(partMap);
                    }else{
                        List<Map<String, String>> partList = new ArrayList<>();
                        partList.add(partMap);
                    }
                    partMap.put("projectNumber", projectNumber);
                    partMap.put("partNumber", partNumber);
                    partMap.put("costProject", costProject);
                    partMap.put("pdcpCost", pdcpCost);
                    partMap.put("partStep", partStep);
                }else{
                    Map<String, List<Map<String, String>>> projectMap = new HashMap<>();
                    resultMap.put(projectNumber, projectMap);
                    Map<String, String> partMap = new HashMap<>();
                    List<Map<String, String>> list = new ArrayList<>();
                    list.add(partMap);
                    projectMap.put(partNumber, list);
                    partMap.put("projectNumber", projectNumber);
                    partMap.put("partNumber", partNumber);
                    partMap.put("costProject", costProject);
                    partMap.put("pdcpCost", pdcpCost);
                    partMap.put("partStep", partStep);
                }
            }
        } catch (Exception var12) {
            logger.error("查询上个月完成项目的成本分解与跟踪表数据异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return resultMap;
    }

    /**
     * 查询BD05有数据的项目--（汇总-间接费用（元）*）
     * @return
     * @throws Exception
     */
    public static Map<String, Double> queryBD05Summary() throws Exception {
        Map<String, Double> map = new HashMap<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT st.value2, (zt.SUMMARY-zt1.SUMMARY) FROM wcadmin.ZFINANCEBD005TABLE zt, wcadmin.ZFINANCEBD005TABLE zt1, WTDOCUMENT w \n" +
                    "                                         LEFT JOIN \n" +
                    "                    (\n" +
                    "                    SELECT s.value2, s.IDA3A4 FROM wcadmin.STRINGVALUE s, wcadmin.STRINGDEFINITION s2 WHERE s.IDA3A6 = s2.IDA2A2 AND s2.NAME = 'ct_ItemNumber'\n" +
                    "                    ) st ON w.IDA2A2 = st.IDA3A4 \n" +
                    "                                        WHERE zt.COSTTYPE = '汇总' \n" +
                    "                                        AND zt.SUMMARY IS NOT null\n" +
                    "                                        AND w.BRANCHIDITERATIONINFO = zt.BRANCHID \n" +
                    "                                        AND zt1.COSTTYPE = '间接费用（元）*' \n" +
                    "                                        AND zt1.SUMMARY IS NOT NULL\n" +
                    "                                        AND w.BRANCHIDITERATIONINFO = zt1.BRANCHID \n" +
                    "                                        AND w.STATESTATE = 'RELEASED'\n" +
                    "                                        AND w.LATESTITERATIONINFO = 1\n" +
                    "                                        AND w.VERSIONSORTIDA2VERSIONINFO =     \n" +
                    "                                    (SELECT max(w4.VERSIONSORTIDA2VERSIONINFO) FROM wcadmin.WTDOCUMENT w4 WHERE w4.IDA3MASTERREFERENCE = w.IDA3MASTERREFERENCE AND w4.LATESTITERATIONINFO=1)\n");
            logger.debug("queryBD05Summary>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            rs = statement.executeQuery();
            String projectNumber = "";
            String summaryString = "";
            double summary = 0;
            while (rs.next()) {
                projectNumber = rs.getString(1);
                summaryString = rs.getString(2);
                summary = 0;
                if(CtFormatUtil.hasContent(summaryString)){
                    try{
                        summary = Double.parseDouble(summaryString);
                    }catch (Exception e){}
                }
                map.put(projectNumber, summary);
            }
        } catch (Exception var12) {
            logger.error("查询BD05有汇总数据的项目异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return map;
    }

    /**
     * 按项目编号汇总BI成本
     * @return
     * @throws Exception
     */
    public static Map<String, Double> queryActualAmountByProjectNumber() throws Exception {
        Map<String, Double> map = new HashMap<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT substr(z.ORDERNUMBER, 5), ROUND(sum(COSTAMOUNT), 2)  FROM ZBISUBJECTCOST z LEFT JOIN\n" +
                    "                     (SELECT c2.PROPERTYKEY, c2.PROPERTYVALUE FROM ZConfigMenu c1 INNER JOIN ZPropertyConfig c2\n" +
                    "                     ON c1.ID = c2.CONFIGMENUID WHERE c1.INNERNAME = 'projectSubjectsMapping'\n" +
                    "                     ) z1 ON z1.PROPERTYKEY = z.SUBJECT\n" +
                    "                     WHERE 1=1\n" +
                    "                     AND z1.PROPERTYVALUE IS NOT NULL\n" +
                    "                     GROUP BY substr(z.ORDERNUMBER, 5)");
            logger.debug("queryActualAmountByProjectNumber>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            rs = statement.executeQuery();
            String projectNumber = "";//去掉了前面4位公司编号
            String actualAmount = "";
            while (rs.next()) {
                projectNumber = rs.getString(1);
                actualAmount = rs.getString(2);
                Double d = 0d;
                if(CtFormatUtil.hasContent(projectNumber) && CtFormatUtil.hasContent(actualAmount)){
                    try{
                        d = Double.valueOf(actualAmount);
                    }catch(Exception e){}
                    map.put(projectNumber, d);
                }
            }
        } catch (Exception var12) {
            logger.error("按项目编号汇总BI成本异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return map;
    }

    /**
     * 查询里程碑的计划完成时间
     * @return
     * @throws Exception
     */
    public static Date queryMilestoneFinishDate(Long projectId, String milestoneName) throws Exception {
        Date milestoneFinishDate = null;
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("select PlanActivity.FINISHDATE as milestoneTime from wcadmin.PlanActivity \n" +
                    "            where PlanActivity.milestone=1 and PlanActivity.idA3containerReference=? and PlanActivity.lineNumber!=0 \n" +
                    "            AND PlanActivity.NAME = ?");
            logger.debug("queryMilestoneFinishDate>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setLong(1, projectId);
            statement.setString(2, milestoneName);
            rs = statement.executeQuery();
            if (rs.next()) {
                milestoneFinishDate = rs.getDate(1);
            }
        } catch (Exception var12) {
            logger.error("查询里程碑的计划完成时间异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return milestoneFinishDate;
    }

    /**
     * 查询已发过的预警
     * @return
     * @throws Exception
     */
    public static List<String> queryAlreadyNotifiedEarlyWarning() throws Exception {
        List<String> earlyWarningList = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.PROJECTNUMBER || '-' || t.BUDGETAMOUNT FROM ZAlreadyNotifiedTable t");
            logger.debug("queryAlreadyNotifiedEarlyWarning>>>>>>>>" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            rs = statement.executeQuery();
            String earlyWarningKey = "";
            while (rs.next()) {
                earlyWarningKey = rs.getString(1);
                earlyWarningList.add(earlyWarningKey);
            }
        } catch (Exception var12) {
            logger.error("查询已发过的预警异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if(null != rs){
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return earlyWarningList;
    }

    /**
     * 记录预警
     * @param boList
     * @throws Exception
     */
    public static void recordWarning(List<CtEarlyWarningBo> boList) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;
        try {
            if(boList==null||boList.size()==0) {
                return;
            }
            ts = new Transaction();
            ts.start();
            String createSql = "insert into ZAlreadyNotifiedTable(id,createTime,modifyTime,warningType,projectNumber,budgetAmount,actualAmount)"
                    + " values(?,?,?,?,?,?,?)";
            statement = connection.prepareStatement(createSql);
            for (CtEarlyWarningBo bo : boList) {
                statement.setString(1, UUID.randomUUID().toString());
                statement.setDate(2, new java.sql.Date(new Date().getTime()));
                statement.setDate(3, new java.sql.Date(new Date().getTime()));
                statement.setString(4, "A");
                statement.setString(5, bo.getProjectNumber());
                statement.setString(6, bo.getBudgetAmount());
                statement.setString(7, bo.getActualAmount());
                statement.addBatch();
                int z = 0;
                // 每100次提交一次
                if (z != 0 && z % 100 == 0) {
                    statement.executeBatch();
                    connection.getConnection().commit();
                }
                z++;
            }
            statement.executeBatch();

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(ts!=null) {
                ts.rollback();
            }
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }
}
