package ext.plm.finance.service;

import ext.plm.finance.bo.CtFinanceBD003Bo;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.method.RemoteInterface;

import java.io.File;
import java.util.List;

@RemoteInterface
public interface CtFinanceBD003Service {
    //插入数据
    void insertFinanceBD003(Long branchId) throws Exception;
    //查询数据
    List<CtFinanceBD003Bo> getFinanceBD003(Long branchId) throws Exception;
    //删除数据
    void deleteFinanceBD003(List<String> ids) throws Exception;
    //更新数据
    CtFinanceBD003Bo updateFinanceBD003(String id, String key, String value) throws Exception;
    //导入数据
    void importData(XSSFWorkbook workbook, FormulaEvaluator formulaEvaluator, String branchId) throws Exception;
    //通过分类查询
    List<CtFinanceBD003Bo> getProductInfo(Long branchId, String type) throws Exception;
}
