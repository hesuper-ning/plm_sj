package ext.plm.finance.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.finance.CtFinanceHelper;
import ext.plm.finance.bo.CtFinanceBD003Bo;
import ext.plm.finance.config.CtFinanceConstant;
import ext.plm.finance.mapper.CtFinanceBD003Mapper;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import wt.part.WTPart;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CtFinanceBD003ServiceImpl extends ServiceImpl<CtFinanceBD003Mapper, CtFinanceBD003Bo> implements CtFinanceBD003Service {

    @Override
    public void insertFinanceBD003(Long branchId) throws Exception {
        CtFinanceBD003Bo bo = new CtFinanceBD003Bo(branchId);
        super.insert(bo);
    }

    @Override
    public List<CtFinanceBD003Bo> getFinanceBD003(Long branchId) throws Exception {
        List<CtFinanceBD003Bo> ctFinanceBD003BoList = super.selectList(new EntityWrapper<CtFinanceBD003Bo>()
                .eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        return ctFinanceBD003BoList;
    }

    @Override
    public void deleteFinanceBD003(List<String> ids) throws Exception {

    }

    @Override
    public CtFinanceBD003Bo updateFinanceBD003(String id, String key, String value) throws Exception {
        return null;
    }

    @Override
    public void importData(XSSFWorkbook workbook, FormulaEvaluator formulaEvaluator, String branchId) throws Exception {
        //读取Excel数据，并导入
        List<CtFinanceBD003Bo> ctFinanceBD003BoList = new ArrayList<>();
        Sheet sheet = workbook.getSheetAt(2);
        if(!"销售毛利预算表-BD003".equals(sheet.getSheetName())){
            throw new Exception("导入模板Sheet页名称不是“销售毛利预算表-BD003”，不能导入！");
        }
        Map<String, List<String>> parameterTypeMap = new HashMap<>();
        List<String> parameterTypeList = null;

        int rowCount = sheet.getPhysicalNumberOfRows(); // 总行数
        int cellCount = sheet.getRow(0).getPhysicalNumberOfCells(); // 总列数
        StringBuilder msg = new StringBuilder();
        for (int i = 1; i < rowCount; i++) {
            CtFinanceBD003Bo ctFinanceBD003Bo = new CtFinanceBD003Bo(Long.parseLong(branchId));
            ctFinanceBD003Bo.setSerialNumber(i+"");
            boolean nullData = false;
            WTPart part = null;
            for (int j = 0; j < cellCount; j++) {
                String value = CtFinanceHelper.getCellValue(sheet, i, j, formulaEvaluator);
                if(0 == j){
                    if(!CtFormatUtil.hasContent(value)){
                        nullData = true;
                        break;
                    }
                    part = CtPartUtil.getPartByNumber(value);
                    if(null == part){
                        msg.append("sheet3中产品编码" + value + "不存在！\r\n");
                    }
                    ctFinanceBD003Bo.setProductCode(value);
                }else if(1 == j){
                    if(null != part){
                        ctFinanceBD003Bo.setProductDescription(part.getName());
                    }
                }else if(2 == j){
                    String productCode = ctFinanceBD003Bo.getProductCode();
                    if(parameterTypeMap.containsKey(productCode)){
                        parameterTypeList = parameterTypeMap.get(productCode);
                    }else{
                        parameterTypeList = new ArrayList<>();
                    }
                    if(!parameterTypeList.contains(value)){
                        parameterTypeList.add(value);
                    }
                    ctFinanceBD003Bo.setParameterType(value);
                }
                else if(3 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD003Bo.getParameterType());
                    ctFinanceBD003Bo.setSummary(value);
                }
                else if(4 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD003Bo.getParameterType());
                    ctFinanceBD003Bo.setYear1(value);
                }
                else if(5 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD003Bo.getParameterType());
                    ctFinanceBD003Bo.setYear2(value);
                }
                else if(6 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD003Bo.getParameterType());
                    ctFinanceBD003Bo.setYear3(value);
                }
                else if(7 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD003Bo.getParameterType());
                    ctFinanceBD003Bo.setYear4(value);
                }
                else if(8 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD003Bo.getParameterType());
                    ctFinanceBD003Bo.setYear5(value);
                }
                else if(9 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD003Bo.getParameterType());
                    ctFinanceBD003Bo.setYear6(value);
                }
            }
            if(!nullData){
                ctFinanceBD003BoList.add(ctFinanceBD003Bo);
            }
        }

        //校验参数类型，导入的数据中必须包含全部参数类型
        for(Map.Entry<String, List<String>> entry : parameterTypeMap.entrySet()){
            String productCode = entry.getKey();
            List<String> parameterTypeTempList = entry.getValue();
            List<String> list = new ArrayList<>();
            list.addAll(CtFinanceConstant.BD03_PARAMETER_TYPE_LIST);
            list.removeAll(parameterTypeTempList);
            if(CtFormatUtil.hasContent(list)){
                msg.append("sheet3中产品编码【" + productCode + "】缺少以下参数类型：\r\n" + StringUtils.join(list, ",") + "\r\n");
            }
        }
        if(msg.toString().length() > 0){
            throw new Exception(msg.toString());
        }

        //先删除掉原来的数据
        super.delete(new EntityWrapper<CtFinanceBD003Bo>().eq(("branchId"), branchId));
        //再插入新数据
        if(!ctFinanceBD003BoList.isEmpty()){
            super.insertBatch(ctFinanceBD003BoList);
        }else{
            throw new Exception("sheet3导入数据为空，导入模板第一列不能没有数据！");
        }
    }

    /**
     * 通过分类查询
     * @param branchId
     * @param type
     * @return
     * @throws Exception
     */
    @Override
    public List<CtFinanceBD003Bo> getProductInfo(Long branchId, String type) throws Exception {
        List<CtFinanceBD003Bo> ctFinanceBD003BoList = super.selectList(new EntityWrapper<CtFinanceBD003Bo>()
                .eq(("branchId"), branchId).like("parameterType", type).orderBy("productCode"));
        return ctFinanceBD003BoList;
    }
}

