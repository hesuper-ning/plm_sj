package ext.plm.finance.service;

import com.alibaba.druid.util.StringUtils;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.finance.bo.CtTargetCostBo;
import ext.plm.finance.mapper.CtTargetCostMapper;
import ext.plm.part.config.CtPartConstant;
import ext.plm.util.*;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.doc.WTDocument;
import wt.part.WTPart;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class CtTargetCostServiceImpl extends ServiceImpl<CtTargetCostMapper, CtTargetCostBo> implements CtTargetCostService {

    @Autowired
    private CtTargetCostMapper ctTargetCostMapper;

    @Override
    public CtTargetCostBo insertTargetCostBo(Long branchId) throws Exception {
        int serialNumber = ctTargetCostMapper.queryMaxSerialNumber(branchId);
        CtTargetCostBo ctTargetCostBo = new CtTargetCostBo(branchId);
        ctTargetCostBo.setSerialNumber((serialNumber+1)+"");
        super.insert(ctTargetCostBo);
        return ctTargetCostBo;
    }

    @Override
    public List<CtTargetCostBo> getTargetCostBo(Long branchId) throws Exception {
        List<CtTargetCostBo> ctTargetCostBoList = super.selectList(new EntityWrapper<CtTargetCostBo>()
                .eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        return ctTargetCostBoList;
    }

    @Override
    public void deleteTargetCostBo(List<String> ids) throws Exception {
        if(CtFormatUtil.hasContent(ids)){
            super.deleteBatchIds(ids);
        }
    }

    @Override
    public CtTargetCostBo updateTargetCostBo(String id, String key, String value) throws Exception {
        CtTargetCostBo ctTargetCostBo = super.selectById(id);
        Long branchId = ctTargetCostBo.getBranchId();
        CtCommonUtil.setObjectValue(ctTargetCostBo, key, value);
        if("partNumber".equals(key)){
            if(CtFormatUtil.hasContent(value)){
                WTPart part = CtPartUtil.getPartByNumber(value);
                if(null != part){
                    if(!part.isEndItem()){
                        throw new Exception("物料编码" + value + "不是成品类型!");
                    }
                    List<CtTargetCostBo> boList = super.selectList(new EntityWrapper<CtTargetCostBo>().eq(("partNumber"), value));
                    for(CtTargetCostBo tempBo : boList){
                        if(!branchId.equals(tempBo.getBranchId())){
                            WTDocument otherDoc = CtDocUtil.getDocumentByBranchId(tempBo.getBranchId()+"");
                            if(null != otherDoc){
                                throw new Exception("物料编码已经在文档" + otherDoc.getNumber() +"表单中添加！");
                            }else{
                                throw new Exception("物料编码已经在branchId为" + tempBo.getBranchId() +"的表单中添加！");
                            }
                        }
                    }
                    IBAUtil ibaUtil = new IBAUtil(part);
                    String partDesc = ibaUtil.getIBAValue(CtPartConstant.IBA_MATERIAL_DESCRIPTION);
                    if(CtFormatUtil.hasContent(partDesc)){
                        ctTargetCostBo.setPartDesc(partDesc);
                    }
                }else{
                    throw new Exception("成品编码" + value + "不存在!");
                }
            }else{
                ctTargetCostBo.setPartDesc("");
            }
        }else if("costProject".equals(key)){
            if(CtFormatUtil.hasContent(value)){
                if("制造成本-制造费用".equals(ctTargetCostBo.getCostProject())){
                    //由"制造成本-制造费用"改为其他值时，则下面三个字段不能编辑，所以清空
                    ctTargetCostBo.setStepCount("");
                    ctTargetCostBo.setTargetLadder("");
                    ctTargetCostBo.setStepCost("");
                }
            }
        }else if("stepCount".equals(key)){
            if(CtFormatUtil.hasContent(value)){
                if(!StringUtils.isNumber(value)){
                    throw new Exception("阶梯数量" + value + "不是数字!");
                }
                if(0 == Integer.valueOf(value)){
                    throw new Exception("阶梯数量不能为0!");
                }
            }
        }
        super.updateById(ctTargetCostBo);
        return ctTargetCostBo;
    }

    @Override
    public void importData(File file, String branchId) throws Exception {
        //读取Excel数据，并导入
        List<CtTargetCostBo> ctTargetCostBoList = new ArrayList<>();
        Workbook workbook = CtExcelReadUtil.readExcel(file.getAbsolutePath(), new FileInputStream(file));
        Sheet sheet = workbook.getSheetAt(0);
        if(!"产品目标成本分解与跟踪表".equals(sheet.getSheetName())){
            throw new Exception("导入模板Sheet页名称不是“产品目标成本分解与跟踪表”，不能导入！");
        }
        int rowCount = sheet.getPhysicalNumberOfRows(); // 总行数
        int cellCount = sheet.getRow(0).getPhysicalNumberOfCells(); // 总列数
        StringBuilder msg = new StringBuilder();
        for (int i = 1; i < rowCount; i++) {
            CtTargetCostBo ctTargetCostBo = new CtTargetCostBo(Long.parseLong(branchId));
            ctTargetCostBo.setSerialNumber(i+"");
            boolean nullData = false;
            String costProject = "";
            for (int j = 0; j < cellCount; j++) {
                String value = CtExcelReadUtil.getCellValue(sheet, i, j);
                if(0 == j){
                    if(!CtFormatUtil.hasContent(value)){
                        nullData = true;
                        break;
                    }
                    WTPart part = CtPartUtil.getPartByNumber(value);
                    if(null != part){
                        if(!part.isEndItem()){
                            msg.append("第" + (i+1) + "行，物料编码【" + value + "】不是成品类型!\r\n");
                        }
                        IBAUtil ibaUtil = new IBAUtil(part);
                        String partDesc = ibaUtil.getIBAValue(CtPartConstant.IBA_MATERIAL_DESCRIPTION);
                        if(CtFormatUtil.hasContent(partDesc)){
                            ctTargetCostBo.setPartDesc(partDesc);
                        }
                    }else{
                        msg.append("第" + (i+1) + "行，成品编码【" + value + "】不存在!\r\n");
                    }
                    ctTargetCostBo.setPartNumber(value);
                }else if(1 == j){
                    if(!"BOM成本-电子".equals(value) && !"BOM成本-结构".equals(value) && !"BOM成本-包装".equals(value)
                            && !"BOM成本-其他".equals(value) && !"BOM成本".equals(value) && !"制造成本-制造费用".equals(value)
                            && !"制造成本-委外加工".equals(value)){
                        msg.append("第" + (i+1) + "行，“成本项目”的值【" + value + "】不合法!\r\n");
                    }
                    ctTargetCostBo.setCostProject(value);
                    costProject = value;
                }else if(2 == j){
                    ctTargetCostBo.setCharterCost(value);
                }
                else if(3 == j){
                    ctTargetCostBo.setPdcpCost(value);
                }
                else if(4 == j){
                    ctTargetCostBo.setTr2Cost(value);
                }
                else if(5 == j){
                    ctTargetCostBo.setTr4Cost(value);
                }
                else if(6 == j){
                    ctTargetCostBo.setTr5Cost(value);
                }
                else if(7 == j){
                    ctTargetCostBo.setTr6Cost(value);
                }
                else if(8 == j){
                    if("制造成本-制造费用".equals(costProject)){
                        ctTargetCostBo.setStepCount(value);
                    }
                }
                else if(9 == j){
                    if("制造成本-制造费用".equals(costProject)){
                        if(CtFormatUtil.hasContent(value) && !"是".equals(value) && !"否".equals(value)){
                            msg.append("第" + (i+1) + "行，“是否目标阶梯”的值必须为“是”或“否”!\r\n");
                        }
                        ctTargetCostBo.setTargetLadder(value);
                    }
                }else if(10 == j){
                    if("制造成本-制造费用".equals(costProject)){
                        ctTargetCostBo.setStepCost(value);
                    }
                }
            }
            if(!nullData){
                ctTargetCostBoList.add(ctTargetCostBo);
            }
        }

        if(msg.toString().length() > 0){
            throw new Exception(msg.toString());
        }

        //先删除掉原来的数据
        super.delete(new EntityWrapper<CtTargetCostBo>().eq(("branchId"), branchId));
        //再插入新数据
        super.insertBatch(ctTargetCostBoList);
    }
}

