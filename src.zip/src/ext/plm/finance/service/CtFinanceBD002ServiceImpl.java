package ext.plm.finance.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.finance.CtFinanceHelper;
import ext.plm.finance.bo.CtFinanceBD002Bo;
import ext.plm.finance.config.CtFinanceConstant;
import ext.plm.finance.mapper.CtFinanceBD002Mapper;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class CtFinanceBD002ServiceImpl extends ServiceImpl<CtFinanceBD002Mapper, CtFinanceBD002Bo> implements CtFinanceBD002Service {

    @Override
    public void insertFinanceBD002(Long branchId) throws Exception {
        CtFinanceBD002Bo bo = new CtFinanceBD002Bo(branchId);
        super.insert(bo);
    }

    @Override
    public List<CtFinanceBD002Bo> getFinanceBD002(Long branchId) throws Exception {
        List<CtFinanceBD002Bo> ctFinanceBD002BoList = super.selectList(new EntityWrapper<CtFinanceBD002Bo>()
                .eq(("branchId"), branchId).orderBy("to_number(serialNumber)"));
        return ctFinanceBD002BoList;
    }

    @Override
    public void deleteFinanceBD002(List<String> ids) throws Exception {

    }

    @Override
    public CtFinanceBD002Bo updateFinanceBD002(String id, String key, String value) throws Exception {
        return null;
    }

    @Override
    public void importData(XSSFWorkbook workbook, FormulaEvaluator formulaEvaluator, String branchId) throws Exception {
        //读取Excel数据，并导入
        List<CtFinanceBD002Bo> ctFinanceBD002BoList = new ArrayList<>();
        Sheet sheet = workbook.getSheetAt(1);
        if(!"利润预算表-BD002".equals(sheet.getSheetName())){
            throw new Exception("导入模板Sheet页名称不是“利润预算表-BD002”，不能导入！");
        }
        int rowCount = sheet.getPhysicalNumberOfRows(); // 总行数
        int cellCount = sheet.getRow(0).getPhysicalNumberOfCells(); // 总列数
        for (int i = 1; i < rowCount; i++) {
            CtFinanceBD002Bo ctFinanceBD002Bo = new CtFinanceBD002Bo(Long.parseLong(branchId));
            ctFinanceBD002Bo.setSerialNumber(i+"");
            boolean nullData = false;
            for (int j = 0; j < cellCount; j++) {
                String value = CtFinanceHelper.getCellValue(sheet, i, j, formulaEvaluator);
                if(0 == j){
                    if(!CtFormatUtil.hasContent(value)){
                        nullData = true;
                        break;
                    }
                    ctFinanceBD002Bo.setProject(value);
                }else if(1 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD002Bo.getProject());
                    ctFinanceBD002Bo.setLifeCycle0(value);
                }else if(2 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD002Bo.getProject());
                    ctFinanceBD002Bo.setLifeCycle1(value);
                }
                else if(3 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD002Bo.getProject());
                    ctFinanceBD002Bo.setLifeCycle2(value);
                }
                else if(4 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD002Bo.getProject());
                    ctFinanceBD002Bo.setLifeCycle3(value);
                }
                else if(5 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD002Bo.getProject());
                    ctFinanceBD002Bo.setLifeCycle4(value);
                }
                else if(6 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD002Bo.getProject());
                    ctFinanceBD002Bo.setLifeCycle5(value);
                }
                else if(7 == j){
                    value = CtFinanceHelper.formatData(value, ctFinanceBD002Bo.getProject());
                    ctFinanceBD002Bo.setTotal(value);
                }
                else if (8 == j){
                    ctFinanceBD002Bo.setRemarks(value);
                }
            }
            if(!nullData){
                ctFinanceBD002BoList.add(ctFinanceBD002Bo);
            }
        }
        //先删除掉原来的数据
        super.delete(new EntityWrapper<CtFinanceBD002Bo>().eq(("branchId"), branchId));
        //再插入新数据
        if(!ctFinanceBD002BoList.isEmpty()){
            super.insertBatch(ctFinanceBD002BoList);
        }else{
            throw new Exception("sheet2导入数据为空，导入模板第一列不能没有数据！");
        }
    }
}

