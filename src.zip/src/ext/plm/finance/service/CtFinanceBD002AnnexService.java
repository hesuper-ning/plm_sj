package ext.plm.finance.service;

import ext.plm.finance.bo.CtFinanceBD002AnnexBo;
import wt.method.RemoteInterface;

import java.io.File;
import java.util.List;

@RemoteInterface
public interface CtFinanceBD002AnnexService {
    //插入数据
    void insertFinanceBD002Annex(Long branchId) throws Exception;
    //查询数据
    List<CtFinanceBD002AnnexBo> getFinanceBD002Annex(Long branchId) throws Exception;
    //删除数据
    void deleteFinanceBD002Annex(List<String> ids) throws Exception;
    //更新数据
    CtFinanceBD002AnnexBo updateFinanceBD002Annex(String id, String key, String value) throws Exception;
}
