package ext.plm.finance.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.finance.CtFinanceHelper;
import ext.plm.finance.bo.CtFinanceBD004Bo;
import ext.plm.finance.mapper.CtFinanceBD004Mapper;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtVersionUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import wt.doc.WTDocument;
import wt.projmgmt.admin.Project2;

import java.util.ArrayList;
import java.util.List;

@Service
public class CtFinanceBD004ServiceImpl extends ServiceImpl<CtFinanceBD004Mapper, CtFinanceBD004Bo> implements CtFinanceBD004Service {
    
    @Override
    public void insertFinanceBD004(Long branchId) throws Exception {
        CtFinanceBD004Bo bo = new CtFinanceBD004Bo(branchId);
        super.insert(bo);
    }

    @Override
    public List<CtFinanceBD004Bo> getFinanceBD004(Long branchId) throws Exception {
        List<CtFinanceBD004Bo> ctFinanceBD004BoList = super.selectList(new EntityWrapper<CtFinanceBD004Bo>()
                .eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        return ctFinanceBD004BoList;
    }

    @Override
    public void deleteFinanceBD004(List<String> ids) throws Exception {

    }

    @Override
    public CtFinanceBD004Bo updateFinanceBD004(String id, String key, String value) throws Exception {
        return null;
    }

    @Override
    public void importData(XSSFWorkbook workbook, FormulaEvaluator formulaEvaluator, String branchId) throws Exception {
        WTDocument doc = CtDocUtil.getDocumentByBranchId(branchId);
        CtFinanceBD004Bo previousDocSummaryBo = null;//上个版本总计这一行
        CtFinanceBD004Bo docSummaryBo = null;//当前总计这一行
        if(!"A".equals(doc.getVersionIdentifier().getValue())){
            //查上个大版本的最新小版本
            WTDocument previousDoc = (WTDocument) CtVersionUtil.getPreviousVersion(doc.getMaster());
            if(null != previousDoc){
                List<CtFinanceBD004Bo> previousList = getFinanceBD004(previousDoc.getBranchIdentifier());
                for(CtFinanceBD004Bo bo : previousList){
                    if("总计".equals(bo.getType1())){
                        previousDocSummaryBo = bo;
                        break;
                    }
                }
            }
        }

        //读取Excel数据，并导入
        List<CtFinanceBD004Bo> ctFinanceBD004BoList = new ArrayList<>();
        Sheet sheet = workbook.getSheetAt(3);
        if(!"人力费用预算表-BD004".equals(sheet.getSheetName())){
            throw new Exception("导入模板Sheet页名称不是“人力费用预算表-BD004”，不能导入！");
        }
        int rowCount = sheet.getPhysicalNumberOfRows(); // 总行数
        int cellCount = sheet.getRow(0).getPhysicalNumberOfCells(); // 总列数
        String type1 = "";
        for (int i = 1; i < rowCount; i++) {
            CtFinanceBD004Bo ctFinanceBD004Bo = new CtFinanceBD004Bo(Long.parseLong(branchId));
            ctFinanceBD004Bo.setSerialNumber(i+"");
            boolean nullData = false;
            for (int j = 0; j < cellCount; j++) {
                String value = CtFinanceHelper.getCellValue(sheet, i, j, formulaEvaluator);
                if(0 == j){
                    if(!CtFormatUtil.hasContent(value)){
                        nullData = true;
                        break;
                    }
                    ctFinanceBD004Bo.setType1(value);
                }else if(1 == j){
                    ctFinanceBD004Bo.setType2(value);
                }else if(2 == j){
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getWorkingHours0();
                            ctFinanceBD004Bo.setWorkingHours0(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = getCalcResult(docSummaryBo.getWorkingHours0(), previousDocSummaryBo.getWorkingHours0());
                            ctFinanceBD004Bo.setWorkingHours0(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setWorkingHours0(value);
                    }
                }
                else if(3 == j){
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getBudget0();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD004Bo.setBudget0(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = getCalcResult(docSummaryBo.getBudget0(), previousDocSummaryBo.getBudget0());
                            ctFinanceBD004Bo.setBudget0(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setBudget0(value);
                    }
                } else if (4 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            ctFinanceBD004Bo.setWorkingHours1(previousDocSummaryBo.getWorkingHours1());
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            ctFinanceBD004Bo.setWorkingHours1(getCalcResult(docSummaryBo.getWorkingHours1(), previousDocSummaryBo.getWorkingHours1()));
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setWorkingHours1(value);
                    }
                } else if (5 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getBudget1();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD004Bo.setBudget1(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = getCalcResult(docSummaryBo.getBudget1(), previousDocSummaryBo.getBudget1());
                            ctFinanceBD004Bo.setBudget1(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setBudget1(value);
                    }
                } else if (6 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            ctFinanceBD004Bo.setWorkingHours2(previousDocSummaryBo.getWorkingHours2());
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            ctFinanceBD004Bo.setWorkingHours2(getCalcResult(docSummaryBo.getWorkingHours2(), previousDocSummaryBo.getWorkingHours2()));
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setWorkingHours2(value);
                    }
                } else if (7 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getBudget2();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD004Bo.setBudget2(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = getCalcResult(docSummaryBo.getBudget2(), previousDocSummaryBo.getBudget2());
                            ctFinanceBD004Bo.setBudget2(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setBudget2(value);
                    }
                } else if (8 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            ctFinanceBD004Bo.setWorkingHours3(previousDocSummaryBo.getWorkingHours3());
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            ctFinanceBD004Bo.setWorkingHours3(getCalcResult(docSummaryBo.getWorkingHours3(), previousDocSummaryBo.getWorkingHours3()));
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setWorkingHours3(value);
                    }
                } else if (9 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getBudget3();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD004Bo.setBudget3(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = getCalcResult(docSummaryBo.getBudget3(), previousDocSummaryBo.getBudget3());
                            ctFinanceBD004Bo.setBudget3(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setBudget3(value);
                    }
                } else if (10 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            ctFinanceBD004Bo.setWorkingHours4(previousDocSummaryBo.getWorkingHours4());
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            ctFinanceBD004Bo.setWorkingHours4(getCalcResult(docSummaryBo.getWorkingHours4(), previousDocSummaryBo.getWorkingHours4()));
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setWorkingHours4(value);
                    }
                } else if (11 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getBudget4();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD004Bo.setBudget4(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = getCalcResult(docSummaryBo.getBudget4(), previousDocSummaryBo.getBudget4());
                            ctFinanceBD004Bo.setBudget4(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setBudget4(value);
                    }
                } else if (12 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            ctFinanceBD004Bo.setWorkingHours5(previousDocSummaryBo.getWorkingHours5());
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            ctFinanceBD004Bo.setWorkingHours5(getCalcResult(docSummaryBo.getWorkingHours5(), previousDocSummaryBo.getWorkingHours5()));
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setWorkingHours5(value);
                    }
                } else if (13 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getBudget5();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD004Bo.setBudget5(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = getCalcResult(docSummaryBo.getBudget5(), previousDocSummaryBo.getBudget5());
                            ctFinanceBD004Bo.setBudget5(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setBudget5(value);
                    }
                } else if (14 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            ctFinanceBD004Bo.setWorkingHours6(previousDocSummaryBo.getWorkingHours6());
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            ctFinanceBD004Bo.setWorkingHours6(getCalcResult(docSummaryBo.getWorkingHours6(), previousDocSummaryBo.getWorkingHours6()));
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setWorkingHours6(value);
                    }
                } else if (15 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getBudget6();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD004Bo.setBudget6(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = (getCalcResult(docSummaryBo.getBudget6(), previousDocSummaryBo.getBudget6()));
                            ctFinanceBD004Bo.setBudget6(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setBudget6(value);
                    }
                } else if (16 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            ctFinanceBD004Bo.setWorkingHours7(previousDocSummaryBo.getWorkingHours7());
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            ctFinanceBD004Bo.setWorkingHours7(getCalcResult(docSummaryBo.getWorkingHours7(), previousDocSummaryBo.getWorkingHours7()));
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setWorkingHours7(value);
                    }
                } else if (17 == j) {
                    type1 = ctFinanceBD004Bo.getType1();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getBudget7();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD004Bo.setBudget7(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = getCalcResult(docSummaryBo.getBudget7(), previousDocSummaryBo.getBudget7());
                            ctFinanceBD004Bo.setBudget7(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD004Bo.setBudget7(value);
                    }
                }
                if("总计".equals(ctFinanceBD004Bo.getType1())){
                    docSummaryBo = ctFinanceBD004Bo;
                }
            }
            if(!nullData){
                ctFinanceBD004BoList.add(ctFinanceBD004Bo);
            }
        }
        //先删除掉原来的数据
        super.delete(new EntityWrapper<CtFinanceBD004Bo>().eq(("branchId"), branchId));
        //再插入新数据
        if(!ctFinanceBD004BoList.isEmpty()){
            super.insertBatch(ctFinanceBD004BoList);
        }else{
            throw new Exception("sheet4中导入数据为空，导入模板第一列不能没有数据！");
        }
    }

    public static String getCalcResult(String s, String s1) throws Exception {
        if (null == s || null == s1) {
            return "";
        }
        double d = Double.parseDouble(s);
        double d1 = Double.parseDouble(s1);
        String v = ((d - d1) / d1) + "";
        return CtFinanceHelper.formatData(v, "（%）");
    }
}

