package ext.plm.finance.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import ext.plm.finance.CtFinanceHelper;
import ext.plm.finance.CtFinanceQuery;
import ext.plm.finance.bo.CtFinanceBD004Bo;
import ext.plm.finance.bo.CtFinanceBD005Bo;
import ext.plm.finance.bo.CtSapProductCostBo;
import ext.plm.finance.bo.CtTargetCostBo;
import ext.plm.finance.mapper.CtFinanceBD004Mapper;
import ext.plm.finance.mapper.CtFinanceBD005Mapper;
import ext.plm.finance.mapper.CtTargetCostMapper;
import ext.plm.integration.sap.CtSapInterface;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtility;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.part.WTPart;
import wt.projmgmt.admin.Project2;
import wt.util.WTProperties;

import java.io.File;
import java.io.FileInputStream;
import java.util.*;

@Service
public class CtBudgetCostReportServiceImpl implements CtBudgetCostReportService {

    @Autowired
    private CtFinanceBD004Mapper ctFinanceBD004Mapper;
    @Autowired
    private CtFinanceBD005Mapper ctFinanceBD005Mapper;
    @Autowired
    private CtTargetCostMapper ctTargetCostMapper;

    @Override
    public Long queryDocBranchId(String projectNumber) throws Exception {
        return ctFinanceBD004Mapper.queryDocBranchId(projectNumber);
    }

    @Override
    public List<Map<String, String>> getHumanResourceBudget(String projectNumber, Long branchId) throws Exception {
        List<Map<String, String>> resultList = new ArrayList<>();
        //各部门实际工时数据
        Map<String, Double> actualWorkingHoursMap = CtFinanceQuery.queryDepartmentActualWorkingHours(projectNumber);
        //查询BI各部门实际金额
        Map<String, String> actualAmountMap = CtFinanceQuery.queryDepartmentActualAmount(projectNumber);

        //预算数据
        List<CtFinanceBD004Bo> ctFinanceBD004BoList = ctFinanceBD004Mapper.selectList(new EntityWrapper<CtFinanceBD004Bo>()
                .eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        double plannedWorkingHoursSummary = 0;
        double actualWorkingHoursSummary = 0;
        double budgetAmountSummary = 0;
        double actualAmountSummary = 0;
        for(CtFinanceBD004Bo bo : ctFinanceBD004BoList){
            String workingHours = bo.getWorkingHours0();
            String budget = bo.getBudget0();
            String department = bo.getType1();
            Map<String, String> map = new HashMap<>();
            map.put("type1", department);
            map.put("type2", bo.getType2());
            map.put("plannedWorkingHours", CtFinanceHelper.formatData(workingHours, "（元）"));
            map.put("budgetAmount", CtFinanceHelper.formatData(budget, "（元）"));
            if("小计".equals(bo.getType2())){
                if(CtFormatUtil.hasContent(workingHours)){
                    plannedWorkingHoursSummary += Double.valueOf(workingHours);

                    Double actualWorkingHours = actualWorkingHoursMap.get(department);
                    if(null != actualWorkingHours){
                        actualWorkingHoursSummary += actualWorkingHours;
                        map.put("actualWorkingHours", CtFinanceHelper.formatData(actualWorkingHours+"", "（元）"));
                        //工时使用率
                        map.put("utilizationRate", CtFinanceHelper.formatData((actualWorkingHours/Double.valueOf(workingHours))+"", "（%）"));
                    }
                }

                if(CtFormatUtil.hasContent(budget)) {
                    Double budgetDouble = Double.valueOf(budget);
                    budgetAmountSummary += budgetDouble;
                    //实际金额
                    String actualAmountString = actualAmountMap.get(department);
                    if (CtFormatUtil.hasContent(actualAmountString)) {
                        map.put("actualAmount", CtFinanceHelper.formatData(actualAmountString, "（元）"));
                        Double actualAmount = Double.valueOf(actualAmountString);
                        actualAmountSummary += actualAmount;
                        //预算执行率
                        map.put("implementationRate", CtFinanceHelper.formatData((actualAmount/budgetDouble) + "", "（%）"));
                    }
                }
            }else{
                map.put("actualAmount", "/");
            }
            resultList.add(map);
        }

        //处理总计
        for(Map<String, String> tempMap : resultList){
            if("总计".equals(tempMap.get("type1"))){
                //计划工时
                tempMap.put("plannedWorkingHours", CtFinanceHelper.formatData(plannedWorkingHoursSummary+"","（元）"));
                //实际工时
                tempMap.put("actualWorkingHours", CtFinanceHelper.formatData(actualWorkingHoursSummary+"","（元）"));
                //工时使用率
                tempMap.put("utilizationRate", CtFinanceHelper.formatData((actualWorkingHoursSummary/plannedWorkingHoursSummary)+"", "（%）"));
                //预算金额
                tempMap.put("budgetAmount", CtFinanceHelper.formatData(budgetAmountSummary+"","（元）"));
                //实际金额
                tempMap.put("actualAmount", CtFinanceHelper.formatData(actualAmountSummary+"","（元）"));
                //预算执行率
                tempMap.put("implementationRate", CtFinanceHelper.formatData((actualAmountSummary/budgetAmountSummary)+"", "（%）"));
                break;
            }
        }
        return resultList;
    }

    @Override
    public List<Map<String, String>> getDevelopmentCostBudget(String projectNumber, Long branchId) throws Exception {
        List<Map<String, String>> resultList = new ArrayList<>();
        //查询BI各科目实际金额
        Map<String, String> actualAmountMap = CtFinanceQuery.querySubjectActualAmount(projectNumber);
        //预算数据
        List<CtFinanceBD005Bo> ctFinanceBD005BoList = ctFinanceBD005Mapper.selectList(new EntityWrapper<CtFinanceBD005Bo>()
                .eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        String costType = "";
        String summary = "";
        for(CtFinanceBD005Bo bo : ctFinanceBD005BoList){
            costType = bo.getCostType();
            summary = bo.getSummary();
            Map<String, String> map = new HashMap<>();
            //费用类型
            map.put("costType", costType);
            map.put("budgetAmount", CtFinanceHelper.formatData(summary, "（元）"));
            //执行金额
            String actualAmount = actualAmountMap.get(costType);
            if(CtFormatUtil.hasContent(actualAmount)){
                map.put("actualAmount", CtFinanceHelper.formatData(actualAmount, "（元）"));
            }else{
                map.put("actualAmount", "");
            }
            if(CtFormatUtil.hasContent(summary) && CtFormatUtil.hasContent(actualAmount)){
                //预算执行率
                Double implementationRate = Double.valueOf(actualAmount)/Double.valueOf(summary);
                map.put("implementationRate", CtFinanceHelper.formatData(implementationRate+"", "（元）"));
            }
            resultList.add(map);
        }
        return resultList;
    }

    @Override
    public List<Map<String, String>> getProductCost(Project2 project) throws Exception {
        List<Map<String, String>> resultList = new ArrayList<>();
        IBAUtility ibaUtility = new IBAUtility(project);
        Vector partNumberVector = ibaUtility.getIBAValues("Ct_FinishedMaterialCode");
        List<String> partNumberList = new ArrayList<>();
        if(partNumberVector.size() > 0){
            for(Object obj : partNumberVector){
                if(CtFormatUtil.hasContent(obj.toString()) && !partNumberList.contains(obj.toString())){
                    partNumberList.add(obj.toString());
                }
            }
        }

        Map<String, List<CtTargetCostBo>> map = new HashMap();//找出各编号“制造成本-制造费用”类别的数据
        Map<String, CtTargetCostBo> map1 = new HashMap();//记录各编号非“制造成本-制造费用”类别的数据，key为编号+“-”+类别
        List<CtTargetCostBo> boList = ctTargetCostMapper.queryProductData(partNumberList);
        List<CtTargetCostBo> tempList = null;
        for(CtTargetCostBo bo : boList){
            String partNumber = bo.getPartNumber();
            String costProject = bo.getCostProject();
            map1.put(partNumber + "-" + costProject, bo);
            if("制造成本-制造费用".equals(costProject)){
                if(map.containsKey(partNumber)){
                    tempList = map.get(partNumber);
                }else{
                    tempList = new ArrayList<>();
                    map.put(partNumber, tempList);
                }
                tempList.add(bo);
            }
        }

        Map<String, Map<String, Float>> partProjectCost = new HashMap<>();//存放已经从sap查回来的tr6数据
        Map<String, Map<String, Map<String, Double>>> actualCostMap = new HashMap<>();//存放已经从sap查回来的数据

        Map<String, String> tempMap = null;
        for(String number : partNumberList){
            WTPart part = CtPartUtil.getPartByNumber(number);
            if(null == part){
                continue;
            }

            //从SAP查询产品编码对应的成本
            Map<String, Float> costProjectMap = new HashMap<>();
            if(partProjectCost.containsKey(number)){
                costProjectMap = partProjectCost.get(number);
            }else{
                //从SAP查询产品编码对应的成本
                List<CtSapProductCostBo> sapProductCostBoList = CtSapInterface.getProductCost(project.getProjectNumber(), number);
                CtFinanceHelper.summaryCostProject(sapProductCostBoList, costProjectMap);
                partProjectCost.put(number, costProjectMap);
            }

            //从SAP查询实际成本、实际生产数量
            Map<String, Map<String, Double>> actualQuantityMap = new HashMap<>();
            if(actualCostMap.containsKey(number)){
                actualQuantityMap = actualCostMap.get(number);
            }else{
                //从SAP查询实际成本、实际生产数量
                List<Map<String, String>> actualQuantityList = CtSapInterface.getProductionQuantity(number);
                CtFinanceHelper.summaryCostProjectQuantity(number, actualQuantityList, actualQuantityMap);
                actualCostMap.put(number, actualQuantityMap);
            }

            String partDesc = part.getName();
            List<CtTargetCostBo> list = map.get(number);
            if(null == list || list.isEmpty()){
                tempMap = createRow(number, partDesc, "BOM成本-结构", null,  map1, costProjectMap, actualQuantityMap);
                resultList.add(tempMap);
                tempMap = createRow(number, partDesc, "BOM成本-电子", null, map1, costProjectMap, actualQuantityMap);
                resultList.add(tempMap);
                tempMap = createRow(number, partDesc, "BOM成本-包装", null, map1, costProjectMap, actualQuantityMap);
                resultList.add(tempMap);
                tempMap = createRow(number, partDesc, "BOM成本-其他", null, map1, costProjectMap, actualQuantityMap);
                resultList.add(tempMap);
                tempMap = createRow(number, partDesc, "制造成本-委外加工", null, map1, costProjectMap, actualQuantityMap);
                resultList.add(tempMap);
                tempMap = createRow(number, partDesc, "制造成本-制造费用", null, map1, costProjectMap, actualQuantityMap);
                resultList.add(tempMap);
            }else{
                for(CtTargetCostBo bo : list){
                    String stepCount = bo.getStepCount();
                    String partStep = bo.getPartStep();
//                    if(!CtFormatUtil.hasContent(stepCount)){
//                        continue;
//                    }
                    tempMap = createRow(number, partDesc, "BOM成本-结构", bo, map1, costProjectMap, actualQuantityMap);
                    resultList.add(tempMap);
                    tempMap = createRow(number, partDesc, "BOM成本-电子", bo, map1, costProjectMap, actualQuantityMap);
                    resultList.add(tempMap);
                    tempMap = createRow(number, partDesc, "BOM成本-包装", bo, map1, costProjectMap, actualQuantityMap);
                    resultList.add(tempMap);
                    tempMap = createRow(number, partDesc, "BOM成本-其他", bo, map1, costProjectMap, actualQuantityMap);
                    resultList.add(tempMap);
                    tempMap = createRow(number, partDesc, "制造成本-委外加工", bo, map1, costProjectMap, actualQuantityMap);
                    resultList.add(tempMap);
                    tempMap = createRow(number, partDesc, "制造成本-制造费用", bo, map1, costProjectMap, actualQuantityMap);
                    resultList.add(tempMap);
                }
            }
        }

        System.out.println(project.getProjectNumber() + "-----SAP生产数量：\r\n" + JSON.toJSONString(actualCostMap));

        return resultList;
    }

    /**
     * 创建单行数据
     * @param partNumber
     * @param partDesc
     * @param costProject
     * @param map1
     * @return
     * @throws Exception
     */
    public static Map<String, String> createRow(String partNumber, String partDesc, String costProject, CtTargetCostBo cBo,
        Map<String, CtTargetCostBo> map1, Map<String, Float> costProjectMap, Map<String, Map<String, Double>> actualQuantityMap) throws Exception {

        String stepCount = "";
        String partStep = "";
        if(null != cBo){
            stepCount = cBo.getStepCount();
            partStep = cBo.getPartStep();
        }

        Map<String, String> map = new HashMap<>();
        map.put("partNumber", partNumber);
        map.put("partDesc", partDesc);
        map.put("costProject", CtFinanceHelper.formatData(costProject, "（元）"));
        map.put("stepCount", stepCount);

        boolean tr6CostHasValue = false;//记录tr6Cost是否有值
        //根据成品编码和成本项目，找到表单数据
        if("制造成本-制造费用".equals(costProject)){
            if(null != cBo){
                map.put("charterCost", CtFinanceHelper.formatData(cBo.getCharterCost(), "（元）"));
                map.put("pdcpCost", CtFinanceHelper.formatData(cBo.getPdcpCost(), "（元）"));
                map.put("tr2Cost", CtFinanceHelper.formatData(cBo.getTr2Cost(), "（元）"));
                map.put("tr4Cost", CtFinanceHelper.formatData(cBo.getTr4Cost(), "（元）"));
                map.put("tr5Cost", CtFinanceHelper.formatData(cBo.getTr5Cost(), "（元）"));
                String tr6Cost = cBo.getTr6Cost();
                if(CtFormatUtil.hasContent(tr6Cost)){
                    map.put("tr6Cost", CtFinanceHelper.formatData(tr6Cost, "（元）"));
                    tr6CostHasValue = true;
                }
            }
        }else{
            CtTargetCostBo bo = map1.get(partNumber + "-" + costProject);
            if(null != bo){
                map.put("charterCost", CtFinanceHelper.formatData(bo.getCharterCost(), "（元）"));
                map.put("pdcpCost", CtFinanceHelper.formatData(bo.getPdcpCost(), "（元）"));
                map.put("tr2Cost", CtFinanceHelper.formatData(bo.getTr2Cost(), "（元）"));
                map.put("tr4Cost", CtFinanceHelper.formatData(bo.getTr4Cost(), "（元）"));
                map.put("tr5Cost", CtFinanceHelper.formatData(bo.getTr5Cost(), "（元）"));
                String tr6Cost = bo.getTr6Cost();
                if(CtFormatUtil.hasContent(tr6Cost)){
                    map.put("tr6Cost", CtFinanceHelper.formatData(tr6Cost, "（元）"));
                    tr6CostHasValue = true;
                }
            }else{
                map.put("charterCost", "");
                map.put("pdcpCost", "");
                map.put("tr2Cost", "");
                map.put("tr4Cost", "");
                map.put("tr5Cost", "");
            }
        }
        if(!tr6CostHasValue){
            //取SAP数据
            Float tr6Cost = costProjectMap.get(costProject);
            if(null != tr6Cost){
                map.put("tr6Cost", CtFinanceHelper.formatData(tr6Cost+"", "（元）"));
            }else{
                map.put("tr6Cost", "");
            }
        }

        if(CtFormatUtil.hasContent(partStep)){
            //实际成本
            Map<String, Double> infoMap = actualQuantityMap.get(costProject);
            if(null != infoMap){
                //实际生产数量
                Double actualQuantity = infoMap.get("actualQuantity");
                if(null != actualQuantity){
                    //判断数量属于这个阶梯，然后取实际成本
                    String[] stepArray = partStep.split("-");
                    if(2 == stepArray.length && Double.valueOf(stepArray[0]) <= actualQuantity && Double.valueOf(stepArray[1]) >= actualQuantity){
                        map.put("productionQuantity", actualQuantity+"");
                        Double actualCost = infoMap.get("actualCost");
                        if(null != actualCost){
                            map.put("actualCost", CtFinanceHelper.formatData(actualCost+"", "（元）"));
                        }
                    }
                }
            }
        }
        return map;
    }

    /**
     * 项目群预算执行报表
     * @param projectName
     * @param productLine
     * @param startTime1
     * @param startTime2
     * @param endTime1
     * @param endTime2
     * @return
     * @throws Exception
     */
    @Override
    public List<Map<String, String>> getBudgetExecutionReport(String projectName, String productLine,
        String startTime1, String startTime2, String endTime1, String endTime2) throws Exception {
        return CtFinanceQuery.queryBudgetExecutionReport(projectName, productLine, startTime1, startTime2, endTime1, endTime2);
    }

    /**
     * 目标成本达成报表
     * @param projectName
     * @param productLine
     * @param startTime1
     * @param startTime2
     * @param endTime1
     * @param endTime2
     * @param productNumber
     * @param costProject
     * @return
     * @throws Exception
     */
    @Override
    public List<Map<String, String>> getTargetCostAchievementReport(String projectName, String productLine, String startTime1, String startTime2, String endTime1, String endTime2, String productNumber, String costProject) throws Exception {
        List<Map<String, String>> resultList = CtFinanceQuery.queryTargetCostAchievementReport(projectName, productLine, startTime1, startTime2, endTime1, endTime2, productNumber, costProject);
        Map<String, Map<String, Float>> partProjectCost = new HashMap<>();//存放已经从sap查回来的tr6数据
        Map<String, Map<String, Map<String, Double>>> actualCostMap = new HashMap<>();//存放已经从sap查回来的数据
        String tr6Cost = "";
        String partNumber = "";
        String costProject1 = "";
        String partStep = "";
        Map<String, Float> costProjectMap = null;
        for(Map<String, String> tempMap : resultList){
            tr6Cost = tempMap.get("tr6Cost");
            partNumber = tempMap.get("productNumber");
            costProject1 = tempMap.get("costProject");
            partStep = tempMap.get("partStep");
            if(!CtFormatUtil.hasContent(partNumber)){
                continue;
            }
            if(!CtFormatUtil.hasContent(tr6Cost)){
                //tr6成本没有值，则从sap查询
                if(partProjectCost.containsKey(partNumber)){
                    costProjectMap = partProjectCost.get(partNumber);
                }else{
                    costProjectMap = new HashMap<>();
                    //从SAP查询产品编码对应的成本
                    List<CtSapProductCostBo> sapProductCostBoList = CtSapInterface.getProductCost(null, partNumber);
                    CtFinanceHelper.summaryCostProject(sapProductCostBoList, costProjectMap);
                    partProjectCost.put(partNumber, costProjectMap);
                }
                if(null != costProjectMap.get(costProject1)){
                    tempMap.put("tr6Cost", costProjectMap.get(costProject1)+"");
                }
            }
            //从SAP查询实际成本
            if(CtFormatUtil.hasContent(partStep)){
                Map<String, Map<String, Double>> actualQuantityMap = new HashMap<>();
                if(actualCostMap.containsKey(partNumber)){
                    //已经查过则直接使用
                    actualQuantityMap = actualCostMap.get(partNumber);
                }else{
                    //没有查过再从sap取
                    List<Map<String, String>> actualQuantityList = CtSapInterface.getProductionQuantity(partNumber);
                    CtFinanceHelper.summaryCostProjectQuantity(partNumber, actualQuantityList, actualQuantityMap);
                    actualCostMap.put(partNumber, actualQuantityMap);
                }
                Map<String, Double> infoMap = actualQuantityMap.get(costProject1);
                if(null != infoMap){
                    //实际生产数量
                    Double actualQuantity = infoMap.get("actualQuantity");
                    if(null != actualQuantity){
                        String[] stepArray = partStep.split("-");
                        //判断数量属于这个阶梯，然后取实际成本
                        if(2 == stepArray.length && Double.valueOf(stepArray[0]) <= actualQuantity && Double.valueOf(stepArray[1]) >= actualQuantity){
                            Double actualCost = infoMap.get("actualCost");
                            if(null != actualCost){
                                tempMap.put("actualCost", actualCost+"");
                            }
                        }
                    }
                }
            }
        }
        return resultList;
    }

    @Override
    public Workbook exportProjectBudgetReport(String data) throws Exception {
        FileInputStream fileInputStream = null;
        Workbook workbook = null;
        try{
            WTProperties wtProperty = WTProperties.getLocalProperties();
            String path = wtProperty.getProperty("wt.home") + File.separator + "codebase" + File.separator + "ext" + File.separator +
                    "plm" + File.separator + "templates" + File.separator + "项目群预算执行报表导出模板.xlsx";
            fileInputStream = new FileInputStream(path);
            workbook = WorkbookFactory.create(fileInputStream);
            Sheet sheet = workbook.getSheetAt(0);
            //处理前端传过来的数据
            JSONArray array = JSONArray.parseArray(data);
            //写入数据
            writeProjectBudgetRowData(array, sheet);
        }finally {
            if (null != fileInputStream) {
                fileInputStream.close();
            }
        }
        return workbook;
    }

    /**
     * 导出excel
     */
    public void writeProjectBudgetRowData(JSONArray data, Sheet sheet) throws Exception {
        Row row = null;
        int rowIndex = 2;
        for(int i = 0; i < data.size();i++){
            JSONObject json = data.getJSONObject(i);
            row = sheet.getRow(rowIndex);
            if(null == row){
                row = sheet.createRow(rowIndex);
            }
            //项目编号
            CtExcelReadUtil.setExcelCellValue(0, json.getString("projectNumber"), row);
            CtExcelReadUtil.setExcelCellValue(1, json.getString("projectName"), row);
            CtExcelReadUtil.setExcelCellValue(2, json.getString("productLine"), row);
            CtExcelReadUtil.setExcelCellValue(3, json.getString("plannedWorkingHours"), row);
            CtExcelReadUtil.setExcelCellValue(4, json.getString("actualWorkingHours"), row);
            CtExcelReadUtil.setExcelCellValue(5, json.getString("utilizationRate"), row);
            CtExcelReadUtil.setExcelCellValue(6, json.getString("budgetAmount"), row);
            CtExcelReadUtil.setExcelCellValue(7, json.getString("executionAmount"), row);
            CtExcelReadUtil.setExcelCellValue(8, json.getString("executionRate"), row);
            CtExcelReadUtil.setExcelCellValue(9, json.getString("budgetAmount1"), row);
            CtExcelReadUtil.setExcelCellValue(10, json.getString("executionAmount1"), row);
            CtExcelReadUtil.setExcelCellValue(11, json.getString("executionRate1"), row);
            rowIndex++;
        }
    }

    @Override
    public Workbook exportTargetCostReport(String data) throws Exception {
        FileInputStream fileInputStream = null;
        Workbook workbook = null;
        try{
            WTProperties wtProperty = WTProperties.getLocalProperties();
            String path = wtProperty.getProperty("wt.home") + File.separator + "codebase" + File.separator + "ext" + File.separator +
                    "plm" + File.separator + "templates" + File.separator + "目标成本达成报表导出模板.xlsx";

            fileInputStream = new FileInputStream(path);
            workbook = WorkbookFactory.create(fileInputStream);
            Sheet sheet = workbook.getSheetAt(0);
            //处理前端传过来的数据
            JSONArray array = JSONArray.parseArray(data);
            //写入数据
            writeTargetCostRowData(array, sheet);
        }finally {
            if (null != fileInputStream) {
                fileInputStream.close();
            }
        }
        return workbook;
    }

    /**
     * 导出excel
     */
    public void writeTargetCostRowData(JSONArray data, Sheet sheet) throws Exception {
        Row row = null;
        int rowIndex = 1;
        for(int i = 0; i < data.size();i++){
            JSONObject json = data.getJSONObject(i);
            row = sheet.getRow(rowIndex);
            if(null == row){
                row = sheet.createRow(rowIndex);
            }
            //项目编号
            CtExcelReadUtil.setExcelCellValue(0, json.getString("projectNumber"), row);
            CtExcelReadUtil.setExcelCellValue(1, json.getString("projectName"), row);
            CtExcelReadUtil.setExcelCellValue(2, json.getString("productLine"), row);
            CtExcelReadUtil.setExcelCellValue(3, json.getString("productNumber"), row);
            CtExcelReadUtil.setExcelCellValue(4, json.getString("productDesc"), row);
            CtExcelReadUtil.setExcelCellValue(5, json.getString("costProject"), row);
            CtExcelReadUtil.setExcelCellValue(6, json.getString("stepCount"), row);
            CtExcelReadUtil.setExcelCellValue(7, json.getString("charterCost"), row);
            CtExcelReadUtil.setExcelCellValue(8, json.getString("pdcpCost"), row);
            CtExcelReadUtil.setExcelCellValue(9, json.getString("tr2Cost"), row);
            CtExcelReadUtil.setExcelCellValue(10, json.getString("tr4Cost"), row);
            CtExcelReadUtil.setExcelCellValue(11, json.getString("tr5Cost"), row);
            CtExcelReadUtil.setExcelCellValue(12, json.getString("tr6Cost"), row);
            CtExcelReadUtil.setExcelCellValue(13, json.getString("actualCost"), row);
            rowIndex++;
        }
    }
}

