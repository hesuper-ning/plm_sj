package ext.plm.finance.service;

import ext.plm.finance.bo.CtFinanceBD004Bo;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.method.RemoteInterface;

import java.io.File;
import java.util.List;

@RemoteInterface
public interface CtFinanceBD004Service {
    //插入数据
    void insertFinanceBD004(Long branchId) throws Exception;
    //查询数据
    List<CtFinanceBD004Bo> getFinanceBD004(Long branchId) throws Exception;
    //删除数据
    void deleteFinanceBD004(List<String> ids) throws Exception;
    //更新数据
    CtFinanceBD004Bo updateFinanceBD004(String id, String key, String value) throws Exception;
    //导入数据
    void importData(XSSFWorkbook workbook, FormulaEvaluator formulaEvaluator, String branchId) throws Exception;
}
