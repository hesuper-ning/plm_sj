package ext.plm.finance.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.finance.CtFinanceHelper;
import ext.plm.finance.bo.CtFinanceBD004Bo;
import ext.plm.finance.bo.CtFinanceBD005Bo;
import ext.plm.finance.mapper.CtFinanceBD005Mapper;
import ext.plm.util.CtDocUtil;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtVersionUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import wt.doc.WTDocument;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class CtFinanceBD005ServiceImpl extends ServiceImpl<CtFinanceBD005Mapper, CtFinanceBD005Bo> implements CtFinanceBD005Service {

    @Override
    public void insertFinanceBD005(Long branchId) throws Exception {
        CtFinanceBD005Bo bo = new CtFinanceBD005Bo(branchId);
        super.insert(bo);
    }

    @Override
    public List<CtFinanceBD005Bo> getFinanceBD005(Long branchId) throws Exception {
        List<CtFinanceBD005Bo> ctFinanceBD005BoList = super.selectList(new EntityWrapper<CtFinanceBD005Bo>()
                .eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        return ctFinanceBD005BoList;
    }

    @Override
    public void deleteFinanceBD005(List<String> ids) throws Exception {

    }

    @Override
    public CtFinanceBD005Bo updateFinanceBD005(String id, String key, String value) throws Exception {
        return null;
    }

    @Override
    public void importData(XSSFWorkbook workbook, FormulaEvaluator formulaEvaluator, String branchId) throws Exception {
        WTDocument doc = CtDocUtil.getDocumentByBranchId(branchId);
        CtFinanceBD005Bo previousDocSummaryBo = null;//上个版本"汇总"这一行
        CtFinanceBD005Bo docSummaryBo = null;//当前"汇总"这一行
        if(!"A".equals(doc.getVersionIdentifier().getValue())){
            //查上个大版本的最新小版本
            WTDocument previousDoc = (WTDocument) CtVersionUtil.getPreviousVersion(doc.getMaster());
            if(null != previousDoc){
                List<CtFinanceBD005Bo> previousList = getFinanceBD005(previousDoc.getBranchIdentifier());
                for(CtFinanceBD005Bo bo : previousList){
                    if("汇总".equals(bo.getCostType())){
                        previousDocSummaryBo = bo;
                        break;
                    }
                }
            }
        }

        //读取Excel数据，并导入
        List<CtFinanceBD005Bo> ctFinanceBD005BoList = new ArrayList<>();
        Sheet sheet = workbook.getSheetAt(4);
        if(!"研发费用预算表-BD005".equals(sheet.getSheetName())){
            throw new Exception("导入模板Sheet页名称不是“研发费用预算表-BD005”，不能导入！");
        }
        int rowCount = sheet.getPhysicalNumberOfRows(); // 总行数
        int cellCount = sheet.getRow(0).getPhysicalNumberOfCells(); // 总列数
        for (int i = 1; i < rowCount; i++) {
            CtFinanceBD005Bo ctFinanceBD005Bo = new CtFinanceBD005Bo(Long.parseLong(branchId));
            ctFinanceBD005Bo.setSerialNumber(i+"");
            boolean nullData = false;
            String type1 = "";
            for (int j = 0; j < cellCount; j++) {
                String value = CtFinanceHelper.getCellValue(sheet, i, j, formulaEvaluator);
                if(0 == j){
                    if(!CtFormatUtil.hasContent(value)){
                        nullData = true;
                        break;
                    }
                    ctFinanceBD005Bo.setCostType(value);
                }else if(1 == j){
                    type1 = ctFinanceBD005Bo.getCostType();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getSummary();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD005Bo.setSummary(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = CtFinanceBD004ServiceImpl.getCalcResult(docSummaryBo.getSummary(), previousDocSummaryBo.getSummary());
                            ctFinanceBD005Bo.setSummary(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD005Bo.setSummary(value);
                    }
                }else if(2 == j){
                    type1 = ctFinanceBD005Bo.getCostType();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getExtraMilestoneBudget();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD005Bo.setExtraMilestoneBudget(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = CtFinanceBD004ServiceImpl.getCalcResult(docSummaryBo.getExtraMilestoneBudget(), previousDocSummaryBo.getExtraMilestoneBudget());
                            ctFinanceBD005Bo.setExtraMilestoneBudget(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD005Bo.setExtraMilestoneBudget(value);
                    }
                }
                else if(3 == j){
                    type1 = ctFinanceBD005Bo.getCostType();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getStartTr2();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD005Bo.setStartTr2(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = CtFinanceBD004ServiceImpl.getCalcResult(docSummaryBo.getStartTr2(), previousDocSummaryBo.getStartTr2());
                            ctFinanceBD005Bo.setStartTr2(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD005Bo.setStartTr2(value);
                    }
                }
                else if(4 == j){
                    type1 = ctFinanceBD005Bo.getCostType();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getTr2Pdcp();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD005Bo.setTr2Pdcp(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = CtFinanceBD004ServiceImpl.getCalcResult(docSummaryBo.getTr2Pdcp(), previousDocSummaryBo.getTr2Pdcp());
                            ctFinanceBD005Bo.setTr2Pdcp(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD005Bo.setTr2Pdcp(value);
                    }
                }
                else if(5 == j){
                    type1 = ctFinanceBD005Bo.getCostType();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getPdcpTr4();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD005Bo.setPdcpTr4(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = CtFinanceBD004ServiceImpl.getCalcResult(docSummaryBo.getPdcpTr4(), previousDocSummaryBo.getPdcpTr4());
                            ctFinanceBD005Bo.setPdcpTr4(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD005Bo.setPdcpTr4(value);
                    }
                }
                else if(6 == j){
                    type1 = ctFinanceBD005Bo.getCostType();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getTr4Tr5();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD005Bo.setTr4Tr5(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = CtFinanceBD004ServiceImpl.getCalcResult(docSummaryBo.getTr4Tr5(), previousDocSummaryBo.getTr4Tr5());
                            ctFinanceBD005Bo.setTr4Tr5(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD005Bo.setTr4Tr5(value);
                    }
                }
                else if(7 == j){
                    type1 = ctFinanceBD005Bo.getCostType();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getTr5Tr6();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD005Bo.setTr5Tr6(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = CtFinanceBD004ServiceImpl.getCalcResult(docSummaryBo.getTr5Tr6(), previousDocSummaryBo.getTr5Tr6());
                            ctFinanceBD005Bo.setTr5Tr6(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD005Bo.setTr5Tr6(value);
                    }
                }
                else if(8 == j){
                    type1 = ctFinanceBD005Bo.getCostType();
                    if(null != previousDocSummaryBo && ("上一版本批准预算金额".equals(type1) || "预算金额变化率".equals(type1))){
                        if("上一版本批准预算金额".equals(type1)){
                            value = previousDocSummaryBo.getTr6End();
                            value = CtFinanceHelper.formatData(value, "（元）");
                            ctFinanceBD005Bo.setTr6End(value);
                        }
                        if("预算金额变化率".equals(type1) && null != docSummaryBo){
                            value = CtFinanceBD004ServiceImpl.getCalcResult(docSummaryBo.getTr6End(), previousDocSummaryBo.getTr6End());
                            ctFinanceBD005Bo.setTr6End(value);
                        }
                    }else{
                        value = CtFinanceHelper.formatData(value, "（元）");
                        ctFinanceBD005Bo.setTr6End(value);
                    }
                }
                if("汇总".equals(ctFinanceBD005Bo.getCostType())){
                    docSummaryBo = ctFinanceBD005Bo;
                }
            }
            if(!nullData){
                ctFinanceBD005BoList.add(ctFinanceBD005Bo);
            }
        }
        //先删除掉原来的数据
        super.delete(new EntityWrapper<CtFinanceBD005Bo>().eq(("branchId"), branchId));
        //再插入新数据
        if(!ctFinanceBD005BoList.isEmpty()){
            super.insertBatch(ctFinanceBD005BoList);
        }else{
            throw new Exception("sheet5中导入数据为空，导入模板第一列不能没有数据！");
        }
    }
}

