package ext.plm.finance.service;

import ext.plm.finance.bo.CtFinanceBD005Bo;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.method.RemoteInterface;

import java.io.File;
import java.util.List;

@RemoteInterface
public interface CtFinanceBD005Service {
    //插入数据
    void insertFinanceBD005(Long branchId) throws Exception;
    //查询数据
    List<CtFinanceBD005Bo> getFinanceBD005(Long branchId) throws Exception;
    //删除数据
    void deleteFinanceBD005(List<String> ids) throws Exception;
    //更新数据
    CtFinanceBD005Bo updateFinanceBD005(String id, String key, String value) throws Exception;
    //导入数据
    void importData(XSSFWorkbook workbook, FormulaEvaluator formulaEvaluator, String branchId) throws Exception;
}
