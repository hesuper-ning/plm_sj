package ext.plm.finance.service;

import org.apache.poi.ss.usermodel.Workbook;
import wt.method.RemoteInterface;
import wt.projmgmt.admin.Project2;

import java.util.List;
import java.util.Map;

@RemoteInterface
public interface CtBudgetCostReportService {
    /**
     * 查询人力费用预算执行报表(BB001)
     * @param projectNumber
     * @return
     * @throws Exception
     */
    List<Map<String, String>> getHumanResourceBudget(String projectNumber, Long branchId) throws Exception;

    /**
     * 查询开发费用预算执行报表(BB002)
     * @param projectNumber
     * @return
     * @throws Exception
     */
    List<Map<String, String>> getDevelopmentCostBudget(String projectNumber, Long branchId) throws Exception;

    /**
     * 查询产品目标成本与实际成本
     * @param project
     * @return
     * @throws Exception
     */
    List<Map<String, String>> getProductCost(Project2 project) throws Exception;

    /**
     * 根据项目编号查询项目预算文档BranchId
     * @param projectNumber
     * @return
     * @throws Exception
     */
    Long queryDocBranchId(String projectNumber) throws Exception;

    /**
     * 项目群预算执行报表
     * @param
     * @return
     * @throws Exception
     */
    List<Map<String, String>> getBudgetExecutionReport(String projectName, String productLine, String startTime1,
        String startTime2, String endTime1, String endTime2) throws Exception;

    List<Map<String, String>> getTargetCostAchievementReport(String projectName, String productLine, String startTime1,
        String startTime2, String endTime1, String endTime2, String productNumber, String costProject) throws Exception;

    Workbook exportProjectBudgetReport(String bomData) throws Exception;

    Workbook exportTargetCostReport(String bomData) throws Exception;
}
