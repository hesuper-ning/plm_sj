package ext.plm.finance.service;

import ext.plm.finance.bo.CtTargetCostBo;
import wt.method.RemoteInterface;

import java.io.File;
import java.util.List;

@RemoteInterface
public interface CtTargetCostService {
    //插入数据
    CtTargetCostBo insertTargetCostBo(Long branchId) throws Exception;
    //查询数据
    List<CtTargetCostBo> getTargetCostBo(Long branchId) throws Exception;
    //删除数据
    void deleteTargetCostBo(List<String> ids) throws Exception;
    //更新数据
    CtTargetCostBo updateTargetCostBo(String id, String key, String value) throws Exception;
    //导入数据
    void importData(File file, String branchId) throws Exception;
}
