package ext.plm.finance.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.finance.bo.CtFinanceBD002AnnexBo;
import ext.plm.finance.mapper.CtFinanceBD002AnnexMapper;
import ext.plm.newec.bo.CtAffectedObjectBo;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class CtFinanceBD002AnnexServiceImpl extends ServiceImpl<CtFinanceBD002AnnexMapper, CtFinanceBD002AnnexBo> implements CtFinanceBD002AnnexService {

    @Override
    public void insertFinanceBD002Annex(Long branchId) throws Exception {
        CtFinanceBD002AnnexBo bo = new CtFinanceBD002AnnexBo(branchId);
        super.insert(bo);
    }

    @Override
    public List<CtFinanceBD002AnnexBo> getFinanceBD002Annex(Long branchId) throws Exception {
        List<CtFinanceBD002AnnexBo> ctFinanceBD002AnnexBoList = super.selectList(new EntityWrapper<CtFinanceBD002AnnexBo>()
                .eq(("branchId"), branchId));
        if(null == ctFinanceBD002AnnexBoList || ctFinanceBD002AnnexBoList.size() < 1){
            //初始化
            CtFinanceBD002AnnexBo ctFinanceBD002AnnexBo = new CtFinanceBD002AnnexBo(branchId);
            super.insert(ctFinanceBD002AnnexBo);
            ctFinanceBD002AnnexBoList.add(ctFinanceBD002AnnexBo);
        }
        return ctFinanceBD002AnnexBoList;
    }

    @Override
    public void deleteFinanceBD002Annex(List<String> ids) throws Exception {

    }

    @Override
    public CtFinanceBD002AnnexBo updateFinanceBD002Annex(String id, String key, String value) throws Exception {
        super.updateForSet(key + "=\'" + value + "\'", new EntityWrapper<CtFinanceBD002AnnexBo>().eq("id", id));
        CtFinanceBD002AnnexBo ctFinanceBD002AnnexBo = super.selectById(id);
        return ctFinanceBD002AnnexBo;
    }

}

