package ext.plm.finance.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.finance.CtFinanceHelper;
import ext.plm.finance.bo.CtFinanceBD001Bo;
import ext.plm.finance.mapper.CtFinanceBD001Mapper;
import ext.plm.project.assocProduct.bo.CtAssocProductBo;
import ext.plm.project.assocProduct.dao.CtAssocProductDAO;
import ext.plm.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import wt.doc.WTDocument;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.time.Year;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class CtFinanceBD001ServiceImpl extends ServiceImpl<CtFinanceBD001Mapper, CtFinanceBD001Bo> implements CtFinanceBD001Service {
    @Resource
    private CtAssocProductDAO ctAssocProductDAO;

    @Override
    public void insertFinanceBD001(Long branchId) throws Exception {
        CtFinanceBD001Bo bo = new CtFinanceBD001Bo(branchId);
        super.insert(bo);
    }

    @Override
    public List<CtFinanceBD001Bo> getFinanceBD001(Long branchId) throws Exception {
        List<CtFinanceBD001Bo> ctFinanceBD001BoList = super.selectList(new EntityWrapper<CtFinanceBD001Bo>()
                .eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        return ctFinanceBD001BoList;
    }

    @Override
    public void deleteFinanceBD001(List<String> ids) throws Exception {

    }

    @Override
    public CtFinanceBD001Bo updateFinanceBD001(String id, String key, String value) throws Exception {
        return null;
    }

    @Override
    public void importData(XSSFWorkbook workbook, FormulaEvaluator formulaEvaluator, String branchId) throws Exception {
        //读取Excel数据，并导入
        List<CtFinanceBD001Bo> ctFinanceBD001BoList = new ArrayList<>();
        //XSSFWorkbook workbook = CtExcelReadUtil.readExcel(file.getAbsolutePath(), new FileInputStream(file));
        int sheetNumber = workbook.getNumberOfSheets();
        if(sheetNumber != 5){
            throw new Exception("导入模板Sheet数不对，请检查模板！");
        }
        Sheet sheet = workbook.getSheetAt(0);
        if(!"项目基础信息汇总表-BD001".equals(sheet.getSheetName())){
            throw new Exception("导入模板Sheet1页名称不是“项目基础信息汇总表-BD001”，不能导入！");
        }
        int rowCount = sheet.getPhysicalNumberOfRows(); // 总行数
        int cellCount = sheet.getRow(0).getPhysicalNumberOfCells(); // 总列数
        Project2 project = null;
        for (int i = 1; i < rowCount; i++) {
            CtFinanceBD001Bo ctFinanceBD001Bo = new CtFinanceBD001Bo(Long.parseLong(branchId));
            ctFinanceBD001Bo.setSerialNumber(i+"");
            boolean nullData = false;
            for (int j = 0; j < cellCount; j++) {
                String value = CtFinanceHelper.getCellValue(sheet, i, j, formulaEvaluator);
                if(0 == j){
                    if(!CtFormatUtil.hasContent(value)){
                        nullData = true;
                        break;
                    }
                    ctFinanceBD001Bo.setProject(value);
                }else if(1 == j){
                    if("预计上市年份*".equals(ctFinanceBD001Bo.getProject())){
                        if(!CtFormatUtil.hasContent(value)){
                            throw new Exception("Sheet1中“预计上市年份*”不能为空！");
                        }
                        if(!isValidYear(value)){
                            throw new Exception("Sheet1中“预计上市年份*”" + value + "不是有效的年份！");
                        }
                    }
                    if("项目编码".equals(ctFinanceBD001Bo.getProject())){
                        if(!CtFormatUtil.hasContent(value)){
                            throw new Exception("Sheet1中“项目编码”不能为空！");
                        }
                        project = CtProjectUtil.getProjectByNumber(value);
                        if(null == project){
                            throw new Exception("Sheet1中“项目编码”" + value + "不存在！");
                        }
                        //校验同一个项目编码不能导入到不同的文档
                        List<CtFinanceBD001Bo> boList = super.selectList(new EntityWrapper<CtFinanceBD001Bo>()
                                .eq(("project"), "项目编码").eq(("predictedSituation"), value));
                        if(null != boList && boList.size() > 0){
                            Long otherBranchId = boList.get(0).getBranchId();
                            if(!branchId.equals(otherBranchId.toString())){
                                WTDocument otherDoc = CtDocUtil.getDocumentByBranchId(otherBranchId.toString());
                                throw new Exception("Sheet1中项目编码" + value + "已在文档" + otherDoc.getNumber() + "中有项目预算数据！");
                            }
                        }
                    }
                    value = CtFinanceHelper.formatData(value, ctFinanceBD001Bo.getProject());
                    ctFinanceBD001Bo.setPredictedSituation(value);
                }else if(2 == j){
                    ctFinanceBD001Bo.setRemarks(value);
                }
            }
            if(!nullData){
                ctFinanceBD001BoList.add(ctFinanceBD001Bo);
            }
        }

        //带出数据
        if(null != project){
            String projectName = project.getName();
            setValue(ctFinanceBD001BoList, "项目名称", projectName);
            IBAUtil ibaUtil = new IBAUtil(project);
            String productLine = ibaUtil.getIBAValue("ct_productLine");
            setValue(ctFinanceBD001BoList, "所属产品PDT", productLine);

            Set<String> modelSet = new HashSet<>();
            List<CtAssocProductBo> records = ctAssocProductDAO.getRecords(project.getPersistInfo().getObjectIdentifier().getId());
            if (CtFormatUtil.hasContent(records)) {
                for(CtAssocProductBo ctAssocProductBo : records){
                    PDMLinkProduct pdmLinkProduct = (PDMLinkProduct) CtWTObjectUtil.getObjectByOid("OR:wt.pdmlink.PDMLinkProduct:" + ctAssocProductBo.getProductId());
                    if(null == pdmLinkProduct){
                        continue;
                    }
                    IBAUtil ibaUtilProduct = new IBAUtil(pdmLinkProduct);
                    String finishedMaterialCode = ibaUtilProduct.getIBAValue("Ct_FinishedMaterialCode");
                    if(!CtFormatUtil.hasContent(finishedMaterialCode)){
                        continue;
                    }
                    //校验物料编号
                    WTPart part = CtPartUtil.getPartByNumber(finishedMaterialCode);
                    if(null == part){
                        continue;
                    }
                    IBAUtil ibaUtilPart = new IBAUtil(part);
                    String model = ibaUtilPart.getIBAValue("ct_model");
                    if(!CtFormatUtil.hasContent(model)){
                        continue;
                    }
                    modelSet.add(model);
                }
            }
            setValue(ctFinanceBD001BoList, "开发产品型号", StringUtils.join(modelSet, ","));
        }

        //先删除掉原来的数据
        super.delete(new EntityWrapper<CtFinanceBD001Bo>().eq(("branchId"), branchId));
        //再插入新数据
        if(!ctFinanceBD001BoList.isEmpty()){
            super.insertBatch(ctFinanceBD001BoList);
        }else{
            throw new Exception("Sheet1中导入数据为空，导入模板第一列不能没有数据！");
        }
    }

    /**
     * 带出默认值
     * @param ctFinanceBD001BoList
     * @param key
     * @param value
     * @throws Exception
     */
    public static void setValue(List<CtFinanceBD001Bo> ctFinanceBD001BoList, String key, String value) throws Exception{
        for(CtFinanceBD001Bo bo : ctFinanceBD001BoList){
            if(key.equals(bo.getProject())){
                bo.setPredictedSituation(value);
                break;
            }
        }
    }

    /**
     * 校验年份
     * @param year
     * @return
     */
    public static boolean isValidYear(String year) {
        try {
            // 尝试解析年份
            Year.parse(year);
            // 长度检查
            return year.length() == 4;
        } catch (DateTimeParseException e) {
            // 解析异常，返回false
            return false;
        }
    }
}

