package ext.plm.finance.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

@TableName("ZTargetCostTable")
public class CtTargetCostBo extends CtFinanceCommonBo{
    //序号
    @TableField(value="serialNumber")
    private String serialNumber;
    //成品编码
    @TableField(value="partNumber")
    private String partNumber;
    //成品描述
    @TableField(value="partDesc")
    private String partDesc;
    //成本项目
    @TableField(value="costProject")
    private String costProject;
    //Charter目标成本
    @TableField(value="charterCost")
    private String charterCost;
    //PDCP成本
    @TableField(value="pdcpCost")
    private String pdcpCost;
    //TR2成本
    @TableField(value="tr2Cost")
    private String tr2Cost;
    //TR4成本
    @TableField(value="tr4Cost")
    private String tr4Cost;
    //TR5成本
    @TableField(value="tr5Cost")
    private String tr5Cost;
    //TR6成本
    @TableField(value="tr6Cost")
    private String tr6Cost;
    //阶梯数量
    @TableField(value="stepCount")
    private String stepCount;
    //是否目标阶梯
    @TableField(value="targetLadder")
    private String targetLadder;
    //阶梯成本
    @TableField(value="stepCost")
    private String stepCost;
    //阶梯数量所处阶梯
    @TableField(value="partStep")
    private String partStep;//阶梯数量所处阶梯范围

    public CtTargetCostBo() {}

    public CtTargetCostBo(Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartDesc() {
        return partDesc;
    }

    public void setPartDesc(String partDesc) {
        this.partDesc = partDesc;
    }

    public String getCostProject() {
        return costProject;
    }

    public void setCostProject(String costProject) {
        this.costProject = costProject;
    }

    public String getCharterCost() {
        return charterCost;
    }

    public void setCharterCost(String charterCost) {
        this.charterCost = charterCost;
    }

    public String getPdcpCost() {
        return pdcpCost;
    }

    public void setPdcpCost(String pdcpCost) {
        this.pdcpCost = pdcpCost;
    }

    public String getTr2Cost() {
        return tr2Cost;
    }

    public void setTr2Cost(String tr2Cost) {
        this.tr2Cost = tr2Cost;
    }

    public String getTr5Cost() {
        return tr5Cost;
    }

    public void setTr5Cost(String tr5Cost) {
        this.tr5Cost = tr5Cost;
    }

    public String getTr6Cost() {
        return tr6Cost;
    }

    public void setTr6Cost(String tr6Cost) {
        this.tr6Cost = tr6Cost;
    }

    public String getStepCount() {
        return stepCount;
    }

    public void setStepCount(String stepCount) {
        this.stepCount = stepCount;
    }

    public String getTargetLadder() {
        return targetLadder;
    }

    public void setTargetLadder(String targetLadder) {
        this.targetLadder = targetLadder;
    }

    public String getStepCost() {
        return stepCost;
    }

    public void setStepCost(String stepCost) {
        this.stepCost = stepCost;
    }

    public String getPartStep() {
        return partStep;
    }

    public void setPartStep(String partStep) {
        this.partStep = partStep;
    }

    public String getTr4Cost() {
        return tr4Cost;
    }

    public void setTr4Cost(String tr4Cost) {
        this.tr4Cost = tr4Cost;
    }
}
