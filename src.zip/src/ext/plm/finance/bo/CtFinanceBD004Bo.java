package ext.plm.finance.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

@TableName("ZFinanceBD004Table")
public class CtFinanceBD004Bo extends CtFinanceCommonBo{
    //导入时的序号
    @TableField(value="serialNumber")
    private String serialNumber;
    //工程师分类1
    @TableField(value="type1")
    private String type1;
    //工程师分类2
    @TableField(value="type2")
    private String type2;
    //预计工时
    @TableField(value="workingHours0")
    private String workingHours0;
    //预算
    @TableField(value="budget0")
    private String budget0;
    //预计工时(里程碑外预算)
    @TableField(value="workingHours1")
    private String workingHours1;
    //预算(里程碑外预算)
    @TableField(value="budget1")
    private String budget1;
    //预计工时(Start-TR2)
    @TableField(value="workingHours2")
    private String workingHours2;
    //预算(Start-TR2)
    @TableField(value="budget2")
    private String budget2;
    //预计工时(TR2-PDCP)
    @TableField(value="workingHours3")
    private String workingHours3;
    //预算(TR2-PDCP)
    @TableField(value="budget3")
    private String budget3;
    //预计工时(PDCP-TR4)
    @TableField(value="workingHours4")
    private String workingHours4;
    //预算(PDCP-TR4)
    @TableField(value="budget4")
    private String budget4;
    //预计工时(TR4-TR5)
    @TableField(value="workingHours5")
    private String workingHours5;
    //预算(TR4-TR5)
    @TableField(value="budget5")
    private String budget5;
    //预计工时(TR5-TR6)
    @TableField(value="workingHours6")
    private String workingHours6;
    //预算(TR5-TR6)
    @TableField(value="budget6")
    private String budget6;
    //预计工时(TR6-End)
    @TableField(value="workingHours7")
    private String workingHours7;
    //预算(TR6-End)
    @TableField(value="budget7")
    private String budget7;

    public CtFinanceBD004Bo() {}

    public CtFinanceBD004Bo(Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getWorkingHours0() {
        return workingHours0;
    }

    public void setWorkingHours0(String workingHours0) {
        this.workingHours0 = workingHours0;
    }

    public String getBudget0() {
        return budget0;
    }

    public void setBudget0(String budget0) {
        this.budget0 = budget0;
    }

    public String getWorkingHours1() {
        return workingHours1;
    }

    public void setWorkingHours1(String workingHours1) {
        this.workingHours1 = workingHours1;
    }

    public String getBudget1() {
        return budget1;
    }

    public void setBudget1(String budget1) {
        this.budget1 = budget1;
    }

    public String getWorkingHours2() {
        return workingHours2;
    }

    public void setWorkingHours2(String workingHours2) {
        this.workingHours2 = workingHours2;
    }

    public String getBudget2() {
        return budget2;
    }

    public void setBudget2(String budget2) {
        this.budget2 = budget2;
    }

    public String getWorkingHours3() {
        return workingHours3;
    }

    public void setWorkingHours3(String workingHours3) {
        this.workingHours3 = workingHours3;
    }

    public String getBudget3() {
        return budget3;
    }

    public void setBudget3(String budget3) {
        this.budget3 = budget3;
    }

    public String getWorkingHours4() {
        return workingHours4;
    }

    public void setWorkingHours4(String workingHours4) {
        this.workingHours4 = workingHours4;
    }

    public String getBudget4() {
        return budget4;
    }

    public void setBudget4(String budget4) {
        this.budget4 = budget4;
    }

    public String getWorkingHours5() {
        return workingHours5;
    }

    public void setWorkingHours5(String workingHours5) {
        this.workingHours5 = workingHours5;
    }

    public String getBudget5() {
        return budget5;
    }

    public void setBudget5(String budget5) {
        this.budget5 = budget5;
    }

    public String getWorkingHours6() {
        return workingHours6;
    }

    public void setWorkingHours6(String workingHours6) {
        this.workingHours6 = workingHours6;
    }

    public String getBudget6() {
        return budget6;
    }

    public void setBudget6(String budget6) {
        this.budget6 = budget6;
    }

    public String getWorkingHours7() {
        return workingHours7;
    }

    public void setWorkingHours7(String workingHours7) {
        this.workingHours7 = workingHours7;
    }

    public String getBudget7() {
        return budget7;
    }

    public void setBudget7(String budget7) {
        this.budget7 = budget7;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getType1() {
        return type1;
    }

    public void setType1(String type1) {
        this.type1 = type1;
    }

    public String getType2() {
        return type2;
    }

    public void setType2(String type2) {
        this.type2 = type2;
    }
}
