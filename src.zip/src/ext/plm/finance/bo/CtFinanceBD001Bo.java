package ext.plm.finance.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

@TableName("ZFinanceBD001Table")
public class CtFinanceBD001Bo extends CtFinanceCommonBo{

    //导入的序号
    @TableField(value="serialNumber")
    private String serialNumber;
    //项目
    @TableField(value="project")
    private String project;
    //预测情况
    @TableField(value="predictedSituation")
    private String predictedSituation;
    //单位
    @TableField(value="company")
    private String company;
    //备注
    @TableField(value="remarks")
    private String remarks;

    public CtFinanceBD001Bo() {}

    public CtFinanceBD001Bo(Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getPredictedSituation() {
        return predictedSituation;
    }

    public void setPredictedSituation(String predictedSituation) {
        this.predictedSituation = predictedSituation;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
}
