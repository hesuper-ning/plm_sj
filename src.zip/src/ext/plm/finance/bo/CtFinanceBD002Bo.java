package ext.plm.finance.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

@TableName("ZFinanceBD002Table")
public class CtFinanceBD002Bo extends CtFinanceCommonBo{
    //导入时的序号
    @TableField(value="serialNumber")
    private String serialNumber;
    //项目
    @TableField(value="project")
    private String project;
    //生命周期T+0
    @TableField(value="lifeCycle0")
    private String lifeCycle0;
    //生命周期T+1
    @TableField(value="lifeCycle1")
    private String lifeCycle1;
    //生命周期T+2
    @TableField(value="lifeCycle2")
    private String lifeCycle2;
    //生命周期T+3
    @TableField(value="lifeCycle3")
    private String lifeCycle3;
    //生命周期T+4
    @TableField(value="lifeCycle4")
    private String lifeCycle4;
    //生命周期T+5
    @TableField(value="lifeCycle5")
    private String lifeCycle5;
    //合计
    @TableField(value="total")
    private String total;
    //备注
    @TableField(value="remarks")
    private String remarks;

    public CtFinanceBD002Bo() {}

    public CtFinanceBD002Bo(Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getLifeCycle0() {
        return lifeCycle0;
    }

    public void setLifeCycle0(String lifeCycle0) {
        this.lifeCycle0 = lifeCycle0;
    }

    public String getLifeCycle1() {
        return lifeCycle1;
    }

    public void setLifeCycle1(String lifeCycle1) {
        this.lifeCycle1 = lifeCycle1;
    }

    public String getLifeCycle2() {
        return lifeCycle2;
    }

    public void setLifeCycle2(String lifeCycle2) {
        this.lifeCycle2 = lifeCycle2;
    }

    public String getLifeCycle3() {
        return lifeCycle3;
    }

    public void setLifeCycle3(String lifeCycle3) {
        this.lifeCycle3 = lifeCycle3;
    }

    public String getLifeCycle4() {
        return lifeCycle4;
    }

    public void setLifeCycle4(String lifeCycle4) {
        this.lifeCycle4 = lifeCycle4;
    }

    public String getLifeCycle5() {
        return lifeCycle5;
    }

    public void setLifeCycle5(String lifeCycle5) {
        this.lifeCycle5 = lifeCycle5;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
}
