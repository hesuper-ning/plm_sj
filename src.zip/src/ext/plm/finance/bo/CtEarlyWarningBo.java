package ext.plm.finance.bo;

public class CtEarlyWarningBo {
    //项目编号
    private String projectNumber;
    //项目名称
    private String projectName;
    //成品编号
    private String partNumber;
    //成品名称
    private String partName;
    //成本类别
    private String costType;
    //PDCP目标成本
    private String pdcpCost;
    //TR节点成本
    private String trCost;
    //TR节点名称
    private String trNode;

    //预算金额
    private String budgetAmount;
    //实际金额
    private String actualAmount;

    public String getProjectNumber() {
        return projectNumber;
    }

    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getCostType() {
        return costType;
    }

    public void setCostType(String costType) {
        this.costType = costType;
    }

    public String getPdcpCost() {
        return pdcpCost;
    }

    public void setPdcpCost(String pdcpCost) {
        this.pdcpCost = pdcpCost;
    }

    public String getTrCost() {
        return trCost;
    }

    public void setTrCost(String trCost) {
        this.trCost = trCost;
    }

    public String getTrNode() {
        return trNode;
    }

    public void setTrNode(String trNode) {
        this.trNode = trNode;
    }

    public String getBudgetAmount() {
        return budgetAmount;
    }

    public void setBudgetAmount(String budgetAmount) {
        this.budgetAmount = budgetAmount;
    }

    public String getActualAmount() {
        return actualAmount;
    }

    public void setActualAmount(String actualAmount) {
        this.actualAmount = actualAmount;
    }
}
