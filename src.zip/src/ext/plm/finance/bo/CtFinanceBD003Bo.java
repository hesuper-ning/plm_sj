package ext.plm.finance.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import ext.plm.trialProcess.bo.CtTrialCommonBo;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

@TableName("ZFinanceBD003Table")
public class CtFinanceBD003Bo extends CtFinanceCommonBo{
    //导入时的序号
    @TableField(value="serialNumber")
    private String serialNumber;
    //产品编码
    @TableField(value="productCode")
    private String productCode;
    //产品描述
    @TableField(value="productDescription")
    private String productDescription;
    //参数类型
    @TableField(value="parameterType")
    private String parameterType;
    //2023年
    @TableField(value="year1")
    private String year1;
    //2024年
    @TableField(value="year2")
    private String year2;
    //2025年
    @TableField(value="year3")
    private String year3;
    //2026年
    @TableField(value="year4")
    private String year4;
    //2027年
    @TableField(value="year5")
    private String year5;
    //2028年
    @TableField(value="year6")
    private String year6;
    //汇总
    @TableField(value="summary")
    private String summary;

    public CtFinanceBD003Bo() {}

    public CtFinanceBD003Bo(Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getParameterType() {
        return parameterType;
    }

    public void setParameterType(String parameterType) {
        this.parameterType = parameterType;
    }

    public String getYear1() {
        return year1;
    }

    public void setYear1(String year1) {
        this.year1 = year1;
    }

    public String getYear2() {
        return year2;
    }

    public void setYear2(String year2) {
        this.year2 = year2;
    }

    public String getYear3() {
        return year3;
    }

    public void setYear3(String year3) {
        this.year3 = year3;
    }

    public String getYear4() {
        return year4;
    }

    public void setYear4(String year4) {
        this.year4 = year4;
    }

    public String getYear5() {
        return year5;
    }

    public void setYear5(String year5) {
        this.year5 = year5;
    }

    public String getYear6() {
        return year6;
    }

    public void setYear6(String year6) {
        this.year6 = year6;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }
}
