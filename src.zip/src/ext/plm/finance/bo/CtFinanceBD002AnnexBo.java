package ext.plm.finance.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import ext.plm.trialProcess.bo.CtTrialCommonBo;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

@TableName("ZFinanceBD002AnnexTable")
public class CtFinanceBD002AnnexBo extends CtFinanceCommonBo{

    //附件
    @TableField(value="annex")
    private String annex;
    //备注
    @TableField(value="remarks")
    private String remarks;

    public CtFinanceBD002AnnexBo() {}

    public CtFinanceBD002AnnexBo(Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getAnnex() {
        return annex;
    }

    public void setAnnex(String annex) {
        this.annex = annex;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
