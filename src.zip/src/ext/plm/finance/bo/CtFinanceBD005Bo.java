package ext.plm.finance.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

@TableName("ZFinanceBD005Table")
public class CtFinanceBD005Bo extends CtFinanceCommonBo{
    //序号
    @TableField(value="serialNumber")
    private String serialNumber;
    //费用类型
    @TableField(value="costType")
    private String costType;
    //汇总
    @TableField(value="summary")
    private String summary;
    //里程碑外预算
    @TableField(value="extraMilestoneBudget")
    private String extraMilestoneBudget;
    //Start-TR2
    @TableField(value="startTr2")
    private String startTr2;
    //TR2-PDCP
    @TableField(value="tr2Pdcp")
    private String tr2Pdcp;
    //PDCP-TR4
    @TableField(value="pdcpTr4")
    private String pdcpTr4;
    //TR4-TR5
    @TableField(value="tr4Tr5")
    private String tr4Tr5;
    //TR5-TR6
    @TableField(value="tr5Tr6")
    private String tr5Tr6;
    //TR6-End
    @TableField(value="tr6End")
    private String tr6End;

    public CtFinanceBD005Bo() {}

    public CtFinanceBD005Bo(Long branchId) throws Exception {
        this.setId(UUID.randomUUID().toString());
        this.setBranchId(branchId);
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.setCreateUser(currentUser.getName());
        this.setCreateTime(new Date());
        this.setModifyUser(currentUser.getName());
        this.setModifyTime(new Date());
    }

    public String getCostType() {
        return costType;
    }

    public void setCostType(String costType) {
        this.costType = costType;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getExtraMilestoneBudget() {
        return extraMilestoneBudget;
    }

    public void setExtraMilestoneBudget(String extraMilestoneBudget) {
        this.extraMilestoneBudget = extraMilestoneBudget;
    }

    public String getStartTr2() {
        return startTr2;
    }

    public void setStartTr2(String startTr2) {
        this.startTr2 = startTr2;
    }

    public String getTr2Pdcp() {
        return tr2Pdcp;
    }

    public void setTr2Pdcp(String tr2Pdcp) {
        this.tr2Pdcp = tr2Pdcp;
    }

    public String getPdcpTr4() {
        return pdcpTr4;
    }

    public void setPdcpTr4(String pdcpTr4) {
        this.pdcpTr4 = pdcpTr4;
    }

    public String getTr4Tr5() {
        return tr4Tr5;
    }

    public void setTr4Tr5(String tr4Tr5) {
        this.tr4Tr5 = tr4Tr5;
    }

    public String getTr5Tr6() {
        return tr5Tr6;
    }

    public void setTr5Tr6(String tr5Tr6) {
        this.tr5Tr6 = tr5Tr6;
    }

    public String getTr6End() {
        return tr6End;
    }

    public void setTr6End(String tr6End) {
        this.tr6End = tr6End;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
}
