package ext.plm.finance.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

@TableName("ZAlreadyNotifiedTable")
public class CtAlreadyNotifiedBo extends CtFinanceCommonBo {
    //预警类型
    @TableField(value="warningType")
    private String warningType;
    //项目编号
    @TableField(value="projectNumber")
    private String projectNumber;
    //预算金额
    @TableField(value="budgetAmount")
    private String budgetAmount;
    //实际金额
    @TableField(value="actualAmount")
    private String actualAmount;

    public CtAlreadyNotifiedBo() {}

    public String getWarningType() {
        return warningType;
    }

    public void setWarningType(String warningType) {
        this.warningType = warningType;
    }

    public String getProjectNumber() {
        return projectNumber;
    }

    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }

    public String getBudgetAmount() {
        return budgetAmount;
    }

    public void setBudgetAmount(String budgetAmount) {
        this.budgetAmount = budgetAmount;
    }

    public String getActualAmount() {
        return actualAmount;
    }

    public void setActualAmount(String actualAmount) {
        this.actualAmount = actualAmount;
    }
}
