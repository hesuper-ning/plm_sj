package ext.plm.finance;

import wt.doc.WTDocument;
import wt.fc.WTObject;
import wt.session.SessionServerHelper;

public class CtFinanceWfPlugin {

    /**
     * 文档升小版，并导出表单到主内容
     * @param pbo
     * @throws Exception
     */
    //ext.plm.finance.CtFinanceWfPlugin.updateDoc(primaryBusinessObject);
    public static void updateDoc(WTObject pbo) throws Exception{
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try{
            if(pbo instanceof WTDocument){
                WTDocument doc = (WTDocument) pbo;
                CtFinanceLogic.getInstance().updateDoc(doc);
            }
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 校验“产品目标成本分解与跟踪表”数据
     * @param pbo
     * @throws Exception
     */
    //ext.plm.finance.CtFinanceWfPlugin.checkTargetCostForm(primaryBusinessObject);
    public static void checkTargetCostForm(WTObject pbo) throws Exception{
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try{
            if(pbo instanceof WTDocument){
                WTDocument doc = (WTDocument) pbo;
                CtFinanceLogic.getInstance().checkTargetCostForm(doc);
            }
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 设置阶梯范围(产品目标成本分解与跟踪表--放在发布之前不能再编辑表单的地方)
     * @param pbo
     * @throws Exception
     */
    //ext.plm.finance.CtFinanceWfPlugin.setPartStep(primaryBusinessObject);
    public static void setPartStep(WTObject pbo) throws Exception{
        if(pbo instanceof WTDocument){
            WTDocument doc = (WTDocument) pbo;
            CtFinanceLogic.getInstance().setPartStep(doc.getBranchIdentifier());
        }
    }

    /**
     * 单位产品成本超支预警
     * @throws Exception
     */
    //ext.plm.finance.CtFinanceWfPlugin.costEarlyWarning(primaryBusinessObject);
    public static void costEarlyWarning(WTObject pbo) throws Exception {
        if(pbo instanceof WTDocument){
            WTDocument doc = (WTDocument) pbo;
            CtFinanceLogic.getInstance().costEarlyWarning(doc);
        }
    }
}
