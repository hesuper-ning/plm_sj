package ext.plm.finance.config;

import ext.plm.util.CtFormatUtil;
import org.apache.log4j.Logger;
import wt.log4j.LogR;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;


public class CtFinanceProperties {
	private static final Logger logger = LogR.getLogger(CtFinanceProperties.class.getName());


	/**
	 * 根据活动节点名称获得activityKey
	 * @param activityName
	 */
	public static String getActivityKey(String activityName) throws Exception{
		Properties activityKeyMap = new Properties();
		activityKeyMap.load(new InputStreamReader(
				CtFinanceProperties.class.getResourceAsStream("FinanceProcessActivityKeyMap.properties"), StandardCharsets.UTF_8));
		String activityKey =  activityKeyMap.getProperty(activityName);
		if(!CtFormatUtil.hasContent(activityKey)) {
			activityKey = "";
		}
		return activityKey;
	}
	
//	/**
//	 * 按流程活动Key获取当前活动的必填字段
//	 * @param activityKey
//	 */
//	public static List<String> getRequiredAtts(String activityKey)throws Exception{
//		Properties formRequiredAttMap = new Properties();
//		formRequiredAttMap.load(new InputStreamReader(
//				CtTrialProperties.class.getResourceAsStream("EcFormRequiredAttMap.properties"), StandardCharsets.UTF_8));
//
//		List<String> result = new ArrayList<String>();
//		String attStr = formRequiredAttMap.getProperty(activityKey);
//		System.out.println("attStr===================="+attStr);
//		if(CtFormatUtil.hasContent(attStr)) {
//			String[] requiredAtts = attStr.split(",");
//			for(String attKey: requiredAtts) {
//				result.add(attKey);
//			}
//		}
//
//		return result;
//	}
//
//	/**
//	 * 获取属性的显示名称
//	 * @param attKey
//	 */
//	public static String getAttDisplayName(String attKey) throws Exception{
//		Properties attDisplayMap = new Properties();
//		attDisplayMap.load(new InputStreamReader(
//				CtTrialProperties.class.getResourceAsStream("EcFormAttDisplayMap.properties"), StandardCharsets.UTF_8));
//
//		return attDisplayMap.getProperty(attKey);
//	}
//
//	/**
//	 * ec通用配置文件获取值
//	 * @param key
//	 * @return
//	 * @throws Exception
//	 */
//	public static String getPropertyValue(String key) throws Exception{
//		String value = "";
//		Properties ecProp = new Properties();
//		ecProp.load(new InputStreamReader(
//				CtTrialProperties.class.getResourceAsStream("CtEc.properties"), StandardCharsets.UTF_8));
//		String property = ecProp.getProperty(key);
//		if(CtFormatUtil.hasContent(property)){
//			value = property;
//		}
//		return value;
//	}

}
