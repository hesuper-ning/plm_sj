package ext.plm.finance.config;

import java.util.ArrayList;
import java.util.List;

public class CtFinanceConstant {

    public static final List<String> BD03_PARAMETER_TYPE_LIST = new ArrayList<>();
    static{
        BD03_PARAMETER_TYPE_LIST.add("01-面价预估");
        BD03_PARAMETER_TYPE_LIST.add("02-销售数量小计");
        BD03_PARAMETER_TYPE_LIST.add("03-直销销售折扣预估");
        BD03_PARAMETER_TYPE_LIST.add("04-直销单价预估");
        BD03_PARAMETER_TYPE_LIST.add("05-直销数量预估");
        BD03_PARAMETER_TYPE_LIST.add("06-直销收入");
        BD03_PARAMETER_TYPE_LIST.add("07-经销销售折扣预估");
        BD03_PARAMETER_TYPE_LIST.add("08-经销单价预估");
        BD03_PARAMETER_TYPE_LIST.add("09-经销数量预估");
        BD03_PARAMETER_TYPE_LIST.add("10-经销收入");
        BD03_PARAMETER_TYPE_LIST.add("11-销售收入");
        BD03_PARAMETER_TYPE_LIST.add("12-单位电子物料成本");
        BD03_PARAMETER_TYPE_LIST.add("13-单位结构物料成本");
        BD03_PARAMETER_TYPE_LIST.add("14-单位包装物料成本");
        BD03_PARAMETER_TYPE_LIST.add("15-单位BOM成本");
        BD03_PARAMETER_TYPE_LIST.add("16-单位制造成本");
        BD03_PARAMETER_TYPE_LIST.add("17-销售成本");
        BD03_PARAMETER_TYPE_LIST.add("18-产品毛利");
    }

















}
