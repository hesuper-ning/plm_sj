package ext.plm.finance;

import cn.hutool.json.JSONObject;
import com.ptc.projectmanagement.plan.Plan;
import ext.plm.common.CtResApiResult;
import ext.plm.finance.bo.*;
import ext.plm.finance.service.*;
import ext.plm.tool.poi.CtExportExcelTool;
import ext.plm.util.CtFileUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtProjectUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wt.pom.Transaction;
import wt.projmgmt.admin.Project2;
import wt.session.SessionServerHelper;
import wt.util.WTProperties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * @Author: heqingbo
 * @Date: 2024/11/13
 * @Description:
 */
@RestController
@RequestMapping("/finance")
public class CtFinanceController {
    static Logger logger = Logger.getLogger(CtFinanceController.class);

    @Autowired
    private CtFinanceBD001Service ctFinanceBD001Service;
    @Autowired
    private CtFinanceBD002Service ctFinanceBD002Service;
    @Autowired
    private CtFinanceBD002AnnexService ctFinanceBD002AnnexService;
    @Autowired
    private CtFinanceBD003Service ctFinanceBD003Service;
    @Autowired
    private CtFinanceBD004Service ctFinanceBD004Service;
    @Autowired
    private CtFinanceBD005Service ctFinanceBD005Service;
    @Autowired
    private CtTargetCostService ctTargetCostService;
    @Autowired
    private CtBudgetCostReportService ctBudgetCostReportService;


    /**
     * 查询BD001
     * @param branchId
     * @return
     */
    @RequestMapping(value = {"/getBD001"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getBD001(Long branchId) {
        try {
            List<CtFinanceBD001Bo> bo = ctFinanceBD001Service.getFinanceBD001(branchId);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            logger.error("查询BD001异常：", e);
            return CtResApiResult.fail("查询BD001失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询BD002
     * @param branchId
     * @return
     */
    @RequestMapping(value = {"/getBD002"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getBD002(Long branchId) {
        try {
            List<CtFinanceBD002Bo> bo = ctFinanceBD002Service.getFinanceBD002(branchId);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            logger.error("查询BD002异常：", e);
            return CtResApiResult.fail("查询BD002失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询BD002Annex
     * @param branchId
     * @return
     */
    @RequestMapping(value = {"/getBD002Annex"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getBD002Annex(Long branchId) {
        try {
            List<CtFinanceBD002AnnexBo> bo = ctFinanceBD002AnnexService.getFinanceBD002Annex(branchId);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            logger.error("查询BD002附件异常：", e);
            return CtResApiResult.fail("查询BD002附件失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 修改BD002Annex
     * @param request
     * @return
     */
    @RequestMapping(value = {"/updateBD002Annex"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult updateBD002Annex(HttpServletRequest request) {
        try {
            com.alibaba.fastjson.JSONObject dataJson = com.alibaba.fastjson.JSONObject.parseObject(request.getParameter("updateRecord"));
            String id = dataJson.getString("id");
            String key = dataJson.getString("key");
            String value = dataJson.getString("value");
            return CtResApiResult.success(ctFinanceBD002AnnexService.updateFinanceBD002Annex(id, key, value));
        } catch (Exception e) {
            logger.error("更新表格属性异常：", e);
            return CtResApiResult.fail("修改数据库失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 根据项目分类查询产品信息
     * @param branchId
     * @return
     */
    @RequestMapping(value = {"/getProductInfo"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getProductInfo(Long branchId, String type) {
        try {
            if(type.contains("销售收入")){
                type = "销售收入";
            }
            if(type.contains("销售成本")){
                type = "销售成本";
            }
            List<CtFinanceBD003Bo> bo = ctFinanceBD003Service.getProductInfo(branchId, type);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            logger.error("根据项目分类查询产品信息异常：", e);
            return CtResApiResult.fail("根据项目分类查询产品信息失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询BD003
     * @param branchId
     * @return
     */
    @RequestMapping(value = {"/getBD003"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getBD003(Long branchId) {
        try {
            List<CtFinanceBD003Bo> bo = ctFinanceBD003Service.getFinanceBD003(branchId);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            logger.error("查询BD003异常：", e);
            return CtResApiResult.fail("查询BD003失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询BD004
     * @param branchId
     * @return
     */
    @RequestMapping(value = {"/getBD004"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getBD004(Long branchId) {
        try {
            List<CtFinanceBD004Bo> bo = ctFinanceBD004Service.getFinanceBD004(branchId);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            logger.error("查询BD004异常：", e);
            return CtResApiResult.fail("查询BD004失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 查询BD005
     * @param branchId
     * @return
     */
    @RequestMapping(value = {"/getBD005"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getBD005(Long branchId) {
        try {
            List<CtFinanceBD005Bo> bo = ctFinanceBD005Service.getFinanceBD005(branchId);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            logger.error("查询BD005异常：", e);
            return CtResApiResult.fail("查询BD005失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 下载模板
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/downLoadTemplate", method = { RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT })
    public static void downLoadTemplate(HttpServletRequest request, HttpServletResponse response) throws Exception {
        cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
        try {
            String userAgent = request.getHeader("User-Agent");
            String fileName = request.getParameter("templateName")+".xlsx";
            String tempFileName = fileName;
            response.setContentType("application/octet-stream");
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                //edge
                fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
            }else {
                // //firefox、chrome、safari、opera：
                fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
            }
            //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");
            CtExportExcelTool exportExcelUtils = new CtExportExcelTool(fileName, tempFileName);
            exportExcelUtils.expExcel(null, response.getOutputStream());
            result.put("success", true);
            result.put("msg", "导出成功！");
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "下载模板失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * excel导入
     *
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/importBD", method = RequestMethod.POST)
    public void importBD(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();
        Transaction transaction = new Transaction();
        transaction.start();
        try {
            String branchId = request.getParameter("branchId");
            String tabName = request.getParameter("tabName");
            WTProperties wtProperty = WTProperties.getLocalProperties();
            String tempPath = wtProperty.getProperty("wt.home") + "/codebase/exportTemp";
            File fpath = new File(tempPath);
            if(!fpath.exists()){
                fpath.mkdirs();
            }
            // 定时7天清理文件
            long delete = 604800000;
            CtFileUtil.deleteFileByTime(fpath, delete);
            File file = null;
            DiskFileItemFactory fac = new DiskFileItemFactory(); // 本地文件
            ServletFileUpload upload = new ServletFileUpload(fac);

            List<FileItem> fileItems = new ArrayList<FileItem>();
            fileItems = upload.parseRequest(request);
            Iterator<FileItem> it = fileItems.iterator();

            Date date = new Date();
            long time = date.getTime();
            while (it.hasNext()) {
                FileItem item = it.next();
                String name = item.getName();
                File tFile = new File(name); // 借助此File获得不带本地路径的文件名
                name = tFile.getName();
                // 加上时间戳
                String substring = name.substring(0, name.lastIndexOf("."));
                String type = name.substring(name.lastIndexOf("."));
                if (!".xls".equals(type) && !".xlsx".equals(type)) {
                    throw new Exception("请使用正确excel文件模板导入数据！！");
                }
                name = substring + "_" + time + type;
                tFile = null; // 释放
                file = new File(tempPath + File.separator + name);
                item.write(file);
            }
            if("targetCost".equals(tabName)){
                ctTargetCostService.importData(file, branchId);
            }else{
                //后面使用它来执行计算公式
                XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(file));
                //刷新公式
                workbook.setForceFormulaRecalculation(true);
                //强制计算
                workbook.getCreationHelper().createFormulaEvaluator().evaluateAll();
                FormulaEvaluator formulaEvaluator = new XSSFFormulaEvaluator((XSSFWorkbook) workbook);
                ctFinanceBD001Service.importData(workbook, formulaEvaluator, branchId);
                ctFinanceBD002Service.importData(workbook, formulaEvaluator, branchId);
                ctFinanceBD003Service.importData(workbook, formulaEvaluator, branchId);
                ctFinanceBD004Service.importData(workbook, formulaEvaluator, branchId);
                ctFinanceBD005Service.importData(workbook, formulaEvaluator, branchId);
            }
            result.put("success", true);
            result.put("msg", "导入成功");
            transaction.commit();
            transaction = null;
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            if(error.contains("org.apache.poi.POIXMLException: org.apache.poi.openxml4j.exceptions")) {
                error = "导入文件不是Excel文件或者文件已被加密！！";
            }
            result.put("success", false);
            result.put("msg", "导入失败，后台异常信息：\r\n" + error);
        }finally{
            if (transaction != null) {
                transaction.rollback();
            }
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 导出项目预算
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/exportBD", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportBD(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        SXSSFWorkbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "";

            //取得body中的参数
            String branchId = request.getParameter("branchId");
            String changeRequestId = request.getParameter("changeRequestId");
            fileName = "项目预算-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //生成需要导出的excel
            if(CtFormatUtil.hasContent(branchId)){
                workbook = CtFinanceHelper.exportExcel(Long.valueOf(branchId));
                workbook.write(response.getOutputStream());
            }
        } catch (Exception e) {
            logger.error("导出项目预算异常:", e);
            throw new Exception("导出项目预算异常：" + e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
            if(null != workbook){
                workbook.dispose();
                //workbook.close();
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(inputStreamReader != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

    /**
     * 查询产品目标成本分解与跟踪表
     * @param branchId
     * @return
     */
    @RequestMapping(value = {"/getTargetCost"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getTargetCost(Long branchId) {
        try {
            List<CtTargetCostBo> bo = ctTargetCostService.getTargetCostBo(branchId);
            return CtResApiResult.success(bo);
        } catch (Exception e) {
            logger.error("查询产品目标成本分解与跟踪表异常：", e);
            return CtResApiResult.fail("查询产品目标成本分解与跟踪表失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }
    }

    /**
     * 保存产品目标成本分解与跟踪表
     * @param branchId
     * @return
     */
    @PostMapping(value = "/saveTargetCost")
    public CtResApiResult saveTargetCost(Long branchId) {
        try {
            return CtResApiResult.success(ctTargetCostService.insertTargetCostBo(branchId));
        } catch (Exception e) {
            logger.error("保存产品目标成本分解与跟踪表异常：", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 删除产品目标成本分解与跟踪表
     * @param ids
     * @return
     */
    @DeleteMapping(value = "/deleteTargetCost", produces = "application/json;charset=UTF-8")
    public CtResApiResult deleteTargetCost(@RequestBody List<String> ids) {
        try {
            ctTargetCostService.deleteTargetCostBo(ids);
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("删除产品目标成本分解与跟踪表异常：", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 更新产品目标成本分解与跟踪表
     * @param id
     * @param key
     * @param value
     * @return
     */
    @PostMapping(value = "/updateTargetCost")
    public CtResApiResult updateTargetCost(String id, String key, String value) {
        try {
            return CtResApiResult.success(ctTargetCostService.updateTargetCostBo(id, key, value));
        } catch (Exception e) {
            logger.error("更新产品目标成本分解与跟踪表异常：", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 查询预算报表
     * @param oid
     * @return
     */
    @RequestMapping(value = {"/getBudgetReport"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getBudgetReport(String oid, String reportType) {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            List<Map<String, String>> list = new ArrayList<>();
            if(CtFormatUtil.hasContent(oid)){
                Plan plan = (Plan) CtWTObjectUtil.getObjectByOid(oid);
                Project2 project = CtProjectUtil.getProject(plan);
                String projectNumber = project.getProjectNumber();
                Long branchId = ctBudgetCostReportService.queryDocBranchId(projectNumber);
                if("getHumanResourceBudget".equals(reportType)){
                    //查询人力费用预算执行报表
                    list = ctBudgetCostReportService.getHumanResourceBudget(projectNumber, branchId);
                }else if("getDevelopmentCostBudget".equals(reportType)){
                    //查询开发费用预算执行报表(BB002)
                    list = ctBudgetCostReportService.getDevelopmentCostBudget(projectNumber, branchId);
                }else{
                    //查询产品目标成本与实际成本(BB003)
                    list = ctBudgetCostReportService.getProductCost(project);
                }
            }
            return CtResApiResult.success(list);
        } catch (Exception e) {
            logger.error("查询预算报表异常：", e);
            return CtResApiResult.fail("查询预算报表失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 导出“目标成本达成报表”的数据
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/exportTargetCostReportData", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportTargetCostReportData(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Workbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "目标成本达成报表-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String data = IOUtils.toString(reader);

            //生成需要导出的excel
            workbook = ctBudgetCostReportService.exportTargetCostReport(data);
            workbook.write(response.getOutputStream());
        } catch (Exception e) {
            logger.error("导出“目标成本达成报表”的数据异常:", e);
            throw new Exception("导出“目标成本达成报表”的数据异常：" + e.getLocalizedMessage());
        } finally {
            if(null != workbook){
                //workbook.close();
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(inputStreamReader != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

    /**
     * 导出“项目群预算执行报表”的数据
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/exportProjectBudgetReportData", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportProjectBudgetReportData(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Workbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "项目群预算执行报表-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String data = IOUtils.toString(reader);

            //生成需要导出的excel
            workbook = ctBudgetCostReportService.exportProjectBudgetReport(data);
            workbook.write(response.getOutputStream());
        } catch (Exception e) {
            logger.error("导出“项目群预算执行报表”的数据异常:", e);
            throw new Exception("导出“项目群预算执行报表”的数据异常：" + e.getLocalizedMessage());
        } finally {
            if(null != workbook){
                //workbook.close();CtProjectGroupQueryBo
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(inputStreamReader != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

    /**
     * 项目群预算执行报表
     * @param request
     * @return
     */
    @RequestMapping(value = {"/getBudgetExecutionReport"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getBudgetExecutionReport(HttpServletRequest request, HttpServletResponse response) {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            String projectName = request.getParameter("projectName");
            String productLine = request.getParameter("productLine");
            String startTime1 = request.getParameter("startTime1");
            if(CtFormatUtil.hasContent(startTime1)){
                startTime1 = startTime1.substring(0, 10);
            }
            String startTime2 = request.getParameter("startTime2");
            if(CtFormatUtil.hasContent(startTime2)){
                startTime2 = startTime2.substring(0, 10);
            }
            String endTime1 = request.getParameter("endTime1");
            if(CtFormatUtil.hasContent(endTime1)){
                endTime1 = endTime1.substring(0, 10);
            }
            String endTime2 = request.getParameter("endTime2");
            if(CtFormatUtil.hasContent(endTime2)){
                endTime2 = endTime2.substring(0, 10);
            }
            List<Map<String, String>> list = ctBudgetCostReportService.getBudgetExecutionReport(projectName, productLine, startTime1, startTime2, endTime1, endTime2);
            return CtResApiResult.success(list);
        } catch (Exception e) {
            logger.error("查询项目群预算执行报表异常：", e);
            return CtResApiResult.fail("查询项目群预算执行报表失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 目标成本达成报表
     * @param request
     * @return
     */
    @RequestMapping(value = {"/getTargetCostAchievementReport"}, method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
    public CtResApiResult getTargetCostAchievementReport(HttpServletRequest request, HttpServletResponse response) {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            String projectName = request.getParameter("projectName");
            String productLine = request.getParameter("productLine");
            String startTime1 = request.getParameter("startTime1");
            if(CtFormatUtil.hasContent(startTime1)){
                startTime1 = startTime1.substring(0, 10);
            }
            String startTime2 = request.getParameter("startTime2");
            if(CtFormatUtil.hasContent(startTime2)){
                startTime2 = startTime2.substring(0, 10);
            }
            String endTime1 = request.getParameter("endTime1");
            if(CtFormatUtil.hasContent(endTime1)){
                endTime1 = endTime1.substring(0, 10);
            }
            String endTime2 = request.getParameter("endTime2");
            if(CtFormatUtil.hasContent(endTime2)){
                endTime2 = endTime2.substring(0, 10);
            }
            String productNumber = request.getParameter("productNumber");
            String costProject = request.getParameter("costProject");
            List<Map<String, String>> list = ctBudgetCostReportService.getTargetCostAchievementReport(projectName, productLine,
                    startTime1, startTime2, endTime1, endTime2, productNumber, costProject);
            return CtResApiResult.success(list);
        } catch (Exception e) {
            logger.error("查询项目群预算执行报表异常：", e);
            return CtResApiResult.fail("查询项目群预算执行报表失败，后台异常信息：\r\n" + e.getLocalizedMessage());
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

}
