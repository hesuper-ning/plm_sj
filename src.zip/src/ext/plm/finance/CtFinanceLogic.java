package ext.plm.finance;

import com.alibaba.druid.util.StringUtils;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.mks.webservice._2009.integrity.schema.Project;
import com.ptc.projectmanagement.plan.Plan;
import com.ptc.projectmanagement.plan.PlanActivity;
import com.ptc.projectmanagement.plan.PlanHelper;
import ext.plm.bean.CtBeanFactory;
import ext.plm.finance.bo.CtEarlyWarningBo;
import ext.plm.finance.bo.CtSapProductCostBo;
import ext.plm.finance.bo.CtTargetCostBo;
import ext.plm.finance.mapper.CtSapProductCostMapper;
import ext.plm.finance.mapper.CtTargetCostMapper;
import ext.plm.integration.sap.CtSapInterface;
import ext.plm.mobileWorkReport.CtMobileWorkReportLogic;
import ext.plm.mobileWorkReport.CtMobileWorkReportService;
import ext.plm.project.milestone.dao.CtMilestoneDAO;
import ext.plm.supplier.CtSupplierDocumentLogic;
import ext.plm.supplier.bo.ApiReturnReceiptVo;
import ext.plm.tool.mail.CtMailTool;
import ext.plm.util.*;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.mvel2.util.Make;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.org.*;
import wt.part.WTPart;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.session.SessionServerHelper;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.wip.WorkInProgressHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class CtFinanceLogic {

    static Logger logger = Logger.getLogger(CtFinanceLogic.class);

    private volatile static CtFinanceLogic instance = null;

    public static CtFinanceLogic getInstance() {
        if (instance == null) {
            synchronized (CtFinanceLogic.class) {
                if (instance == null) {
                    instance = new CtFinanceLogic();
                }
            }
        }
        return instance;
    }

    /**
     * 文档升小版，并导出表单到主内容
     * @param doc
     * @throws Exception
     */
    public void updateDoc(WTDocument doc) throws Exception {
        FileOutputStream outputStream = null;
        try{
            //将表单内容写入到临时文件
            String fileName = "项目预算-" + System.currentTimeMillis() + ".xlsx";
            WTProperties wtProperty = WTProperties.getLocalProperties();
            String tempPath = wtProperty.getProperty("wt.home") + "/codebase/exportTemp";
            File tempPathFile = new File(tempPath);
            if(!tempPathFile.exists()){
                tempPathFile.mkdirs();
            }
            File file = new File(tempPath + File.separator + fileName);
            outputStream = new FileOutputStream(file.getPath());
            SXSSFWorkbook workbook = CtFinanceHelper.exportExcel(doc.getBranchIdentifier());
            workbook.write(outputStream);

            //检出
            doc = CtDocUtil.checkOut(doc, "研发项目预算编制与录入流程更新文档主内容");
            //更新文档主内容
            CtDocUtil.updatePrimaryFile(doc, file.getPath(), fileName);
            //LifeCycleHelper.service.setLifeCycleState(doc, State.toState("EFFECTED"));
            //检入
            WorkInProgressHelper.service.checkin(doc, "研发项目预算编制与录入流程更新文档主内容");
        }catch (Exception e){
            throw e;
        }finally{
            try{
                if(null != outputStream){
                    outputStream.close();
                    outputStream = null;
                }
            }catch (Exception e){
                logger.error("关流时异常：", e);
            }
        }
    }

    /**
     * 校验表单数据
     * @param doc
     * @throws Exception
     */
    public void checkTargetCostForm(WTDocument doc) throws Exception {
        Long branchId = doc.getBranchIdentifier();
        CtTargetCostMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtTargetCostMapper.class);
        List<CtTargetCostBo> list = mapper.selectList(new EntityWrapper<CtTargetCostBo>().eq(("branchId"), branchId));
        String partNumber = "";
        String costProject = "";
        List<String> projectList = null;
        Map<String, List<String>> map = new HashMap<>();
        StringBuilder msg = new StringBuilder();
        for(CtTargetCostBo bo : list){
            partNumber = bo.getPartNumber();
            if(!CtFormatUtil.hasContent(partNumber)){
                throw new Exception("成品编码不能为空，请检查！");
            }
            costProject = bo.getCostProject();
            if("制造成本-制造费用".equals(costProject)){
                continue;
            }
            if(map.containsKey(partNumber)){
                projectList = map.get(partNumber);
                if(projectList.contains(costProject)){
                    msg.append("成品编码【" + partNumber + "】只能有一条成本项目为【" + costProject + "】的数据！\r\n");
                }else{
                    projectList.add(costProject);
                }
            }else{
                projectList = new ArrayList<>();
                projectList.add(costProject);
                map.put(partNumber, projectList);
            }
        }
        if(msg.toString().length() > 0){
            throw new Exception(msg.toString());
        }
    }

    /**
     * 通过计划oid取得里程碑名称集合
     * @param planOid
     * @return
     * @throws Exception
     */
    public List<String> getMilestoneNameList(String planOid) throws Exception {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        List<String> resultList = new ArrayList<>();
        try{
            Plan plan = (Plan) CtWTObjectUtil.getObjectByOid(planOid);
            long projectId = plan.getContainer().getPersistInfo().getObjectIdentifier().getId();
            CtMilestoneDAO ctMilestoneDAO = CtBeanFactory.newCtBeanFactory().getBean(CtMilestoneDAO.class);
            List<PlanActivity> planActivityList = ctMilestoneDAO.getMilestones(projectId);
            if(null != planActivityList){
                for(PlanActivity planActivity : planActivityList){
                    resultList.add(planActivity.getName());
                }
            }
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
        return resultList;
    }

    /**
     * 保存产品成本数据
     * @param project
     * @throws Exception
     */
    public void saveProductCost(Project2 project) throws Exception {
        String projectNumber = project.getProjectNumber();
        IBAUtility ibaUtil = new IBAUtility(project);
        Vector v = ibaUtil.getIBAValues("Ct_FinishedMaterialCode");
        if(null != v && v.size() > 0){
            for(int i = 0;i < v.size();i++){
                String productNumber = (String) v.get(i);
                //SAP查询数据
                List<CtSapProductCostBo> boList = CtSapInterface.getProductCost(projectNumber, productNumber);
                if(!boList.isEmpty()){
                    //先清掉旧数据
                    CtSapProductCostMapper ctSapProductCostMapper = CtBeanFactory.newCtBeanFactory().getBean(CtSapProductCostMapper.class);
                    Wrapper deleteWrapper = new EntityWrapper<CtSapProductCostBo>().eq(("projectNumber"), projectNumber).eq(("productNumber"), productNumber);
                    ctSapProductCostMapper.delete(deleteWrapper);
                    //存入新的
                    for(CtSapProductCostBo bo : boList){
                        ctSapProductCostMapper.insert(bo);
                    }
                }
            }
        }
    }

    /**
     * 设置阶梯范围
     * @param branchId
     * @throws Exception
     */
    public void setPartStep(Long branchId) throws Exception {
        Map<String, String> map = CtFinanceQuery.queryAllPartStep(branchId);
        //分配好阶梯数量范围
        Map<String, String> stepMap = new HashMap<>();
        for(Map.Entry<String, String> entry : map.entrySet()){
            String number = entry.getKey();
            String value = entry.getValue();
            String[] valueArray = value.split("-");
            for(int i = 1;i < valueArray.length;i++){
                stepMap.put(number + "-" + valueArray[i], valueArray[i-1] + "-" + valueArray[i]);
            }
        }
        CtTargetCostMapper ctTargetCostMapper = CtBeanFactory.newCtBeanFactory().getBean(CtTargetCostMapper.class);
        List<CtTargetCostBo> boList = ctTargetCostMapper.selectList(new EntityWrapper<CtTargetCostBo>().eq(("branchId"), branchId));
        for(CtTargetCostBo bo : boList){
            if("制造成本-制造费用".equals(bo.getCostProject())){
                String partNumber = bo.getPartNumber();
                String stepCount = bo.getStepCount();
                String partStep = stepMap.get(partNumber + "-" + stepCount);
                bo.setPartStep(partStep);
                ctTargetCostMapper.updateById(bo);
            }
        }
    }

    /**
     * 单位产品成本超支预警
     * @param doc
     * @throws Exception
     */
    public void costEarlyWarning(WTDocument doc) throws Exception {
        System.out.println("----------进了预警代码");

        Long branchId = doc.getBranchIdentifier();
        IBAUtil ibaUtil = new IBAUtil(doc);
        String projectNumber = ibaUtil.getIBAValue("ct_ItemNumber");
        if(!CtFormatUtil.hasContent(projectNumber)){
            return;
        }
        Project2 project2 = CtProjectUtil.getProjectByNumber(projectNumber);
        if(null == project2){
            return;
        }
        String projectName = project2.getName();

        CtTargetCostMapper ctTargetCostMapper = CtBeanFactory.newCtBeanFactory().getBean(CtTargetCostMapper.class);
        List<CtTargetCostBo> boList = ctTargetCostMapper.selectList(new EntityWrapper<CtTargetCostBo>().eq(("branchId"), branchId));
        Map<String, Map<String, Double>> map = new HashMap<>();//按物料编号、TR点两个维度加总成本
        Map<String, Map<String, Map<String, Double>>> typeMap = new HashMap<>();//按物料编号、成本项目、TR点三个维度加总成本
        String partNumber = "";
        String type = "";
        String pdcpCost = "";
        String tr2Cost = "";
        String tr4Cost = "";
        String tr5Cost = "";
        String tr6Cost = "";
        for(CtTargetCostBo bo : boList){
            partNumber = bo.getPartNumber();
            type = bo.getCostProject();
            pdcpCost = bo.getPdcpCost();
            tr2Cost = bo.getTr2Cost();
            tr4Cost = bo.getTr4Cost();
            tr5Cost = bo.getTr5Cost();
            tr6Cost = bo.getTr6Cost();

            //按物料编号、成本项目、TR点三个维度加总成本
            if(typeMap.containsKey(partNumber)){
                Map<String, Map<String, Double>> costTypeMap = typeMap.get(partNumber);
                if(costTypeMap.containsKey(type)){
                    Map<String, Double> trCostMap = costTypeMap.get(type);
                    trCostMap.put("pdcpCost", getDouble(trCostMap.get("pdcpCost")) + getDouble(pdcpCost));
                    trCostMap.put("tr2Cost", getDouble(trCostMap.get("tr2Cost")) + getDouble(tr2Cost));
                    trCostMap.put("tr4Cost", getDouble(trCostMap.get("tr4Cost")) + getDouble(tr4Cost));
                    trCostMap.put("tr5Cost", getDouble(trCostMap.get("tr5Cost")) + getDouble(tr5Cost));
                    trCostMap.put("tr6Cost", getDouble(trCostMap.get("tr6Cost")) + getDouble(tr6Cost));
                }else{
                    Map<String, Double> trCostMap = new HashMap<>();
                    trCostMap.put("pdcpCost", getDouble(pdcpCost));
                    trCostMap.put("tr2Cost", getDouble(tr2Cost));
                    trCostMap.put("tr4Cost", getDouble(tr4Cost));
                    trCostMap.put("tr5Cost", getDouble(tr5Cost));
                    trCostMap.put("tr6Cost", getDouble(tr6Cost));
                    costTypeMap.put(type, trCostMap);
                }
            }else{
                Map<String, Map<String, Double>> costTypeMap = new HashMap<>();
                typeMap.put(partNumber, costTypeMap);
                Map<String, Double> trCostMap = new HashMap<>();
                trCostMap.put("pdcpCost", getDouble(pdcpCost));
                trCostMap.put("tr2Cost", getDouble(tr2Cost));
                trCostMap.put("tr4Cost", getDouble(tr4Cost));
                trCostMap.put("tr5Cost", getDouble(tr5Cost));
                trCostMap.put("tr6Cost", getDouble(tr6Cost));
                costTypeMap.put(type, trCostMap);
            }

            //按物料编号、TR点两个维度加总成本
            if(map.containsKey(partNumber)){
                Map<String, Double> trCostMap = map.get(partNumber);
                trCostMap.put("pdcpCost", getDouble(trCostMap.get("pdcpCost")) + getDouble(pdcpCost));
                trCostMap.put("tr2Cost", getDouble(trCostMap.get("tr2Cost")) + getDouble(tr2Cost));
                trCostMap.put("tr4Cost", getDouble(trCostMap.get("tr4Cost")) + getDouble(tr4Cost));
                trCostMap.put("tr5Cost", getDouble(trCostMap.get("tr5Cost")) + getDouble(tr5Cost));
                trCostMap.put("tr6Cost", getDouble(trCostMap.get("tr6Cost")) + getDouble(tr6Cost));
            }else{
                Map<String, Double> trCostMap = new HashMap<>();
                trCostMap.put("pdcpCost", getDouble(pdcpCost));
                trCostMap.put("tr2Cost", getDouble(tr2Cost));
                trCostMap.put("tr4Cost", getDouble(tr4Cost));
                trCostMap.put("tr5Cost", getDouble(tr5Cost));
                trCostMap.put("tr6Cost", getDouble(tr6Cost));
                map.put(partNumber, trCostMap);
            }
        }

        //成品维度，比对成本
        List<CtEarlyWarningBo> ctEarlyWarningBoList = new ArrayList<>();
        for(Map.Entry<String, Map<String, Double>> entry : map.entrySet()){
            partNumber = entry.getKey();
            WTPart part = CtPartUtil.getPartByNumber(partNumber);
            if(null == part){
                continue;
            }
            String partName = part.getName();
            Map<String, Double> trCostMap = entry.getValue();
            double trCost = 0d;
            String trNode = "";
            if(CtFormatUtil.hasContent(trCostMap.get("tr6Cost"))){
                trCost = trCostMap.get("tr6Cost");
                trNode = "TR6";
            }else if(CtFormatUtil.hasContent(trCostMap.get("tr5Cost"))){
                trCost = trCostMap.get("tr5Cost");
                trNode = "TR5";
            }else if(CtFormatUtil.hasContent(trCostMap.get("tr4Cost"))){
                trCost = trCostMap.get("tr4Cost");
                trNode = "TR4";
            }else{
                trCost = trCostMap.get("tr2Cost");
                trNode = "TR2";
            }
            double pdcpCostDouble = getDouble(trCostMap.get("pdcpCost"));
            System.out.println("-----trCost:" + trCost);
            System.out.println("-----pdcpCostDouble:" + pdcpCostDouble);
            if(trCost >= pdcpCostDouble){
                CtEarlyWarningBo ctEarlyWarningBo = new CtEarlyWarningBo();
                ctEarlyWarningBo.setProjectNumber(projectNumber);
                ctEarlyWarningBo.setProjectName(projectName);
                ctEarlyWarningBo.setPartNumber(partNumber);
                ctEarlyWarningBo.setPartName(partName);
                ctEarlyWarningBo.setPdcpCost(pdcpCostDouble+"");
                ctEarlyWarningBo.setTrCost(trCost+"");
                ctEarlyWarningBo.setTrNode(trNode);
                ctEarlyWarningBoList.add(ctEarlyWarningBo);
            }
        }

        //成品下的成本项目维度，比对成本
        List<CtEarlyWarningBo> ctEarlyWarningBoList1 = new ArrayList<>();
        for(Map.Entry<String, Map<String, Map<String, Double>>> entry : typeMap.entrySet()) {
            partNumber = entry.getKey();
            WTPart part = CtPartUtil.getPartByNumber(partNumber);
            if (null == part) {
                continue;
            }
            String partName = part.getName();
            Map<String, Map<String, Double>> costTypeMap = entry.getValue();
            for(Map.Entry<String, Map<String, Double>> tempEntry : costTypeMap.entrySet()){
                String costType = tempEntry.getKey();
                Map<String, Double> trCostMap = tempEntry.getValue();
                double trCost = 0d;
                String trNode = "";
                if(CtFormatUtil.hasContent(trCostMap.get("tr6Cost"))){
                    trCost = trCostMap.get("tr6Cost");
                    trNode = "TR6";
                }else if(CtFormatUtil.hasContent(trCostMap.get("tr5Cost"))){
                    trCost = trCostMap.get("tr5Cost");
                    trNode = "TR5";
                }else if(CtFormatUtil.hasContent(trCostMap.get("tr4Cost"))){
                    trCost = trCostMap.get("tr4Cost");
                    trNode = "TR4";
                }else{
                    trCost = trCostMap.get("tr2Cost");
                    trNode = "TR2";
                }
                double pdcpCostDouble = getDouble(trCostMap.get("pdcpCost"));
                System.out.println("-----trCost1:" + trCost);
                System.out.println("-----pdcpCostDouble1:" + pdcpCostDouble);
                if(trCost >= pdcpCostDouble){
                    CtEarlyWarningBo ctEarlyWarningBo = new CtEarlyWarningBo();
                    ctEarlyWarningBo.setProjectNumber(projectNumber);
                    ctEarlyWarningBo.setProjectName(projectName);
                    ctEarlyWarningBo.setPartNumber(partNumber);
                    ctEarlyWarningBo.setPartName(partName);
                    ctEarlyWarningBo.setPdcpCost(pdcpCostDouble+"");
                    ctEarlyWarningBo.setTrCost(trCost+"");
                    ctEarlyWarningBo.setCostType(costType);
                    ctEarlyWarningBo.setTrNode(trNode);
                    ctEarlyWarningBoList1.add(ctEarlyWarningBo);
                }
            }
        }

        System.out.println("-----ctEarlyWarningBoList:" + ctEarlyWarningBoList.size());
        System.out.println("-----ctEarlyWarningBoList1:" + ctEarlyWarningBoList1.size());

        if (ctEarlyWarningBoList.size() > 0) {
            //发预警
            sendEarlyWarning("B", project2, ctEarlyWarningBoList);
        }

        if (ctEarlyWarningBoList1.size() > 0) {
            //发预警
            sendEarlyWarning("D", project2, ctEarlyWarningBoList1);
        }
    }

    /**
     * 发预警
     * @param warningType
     * @param project2
     * @param boList
     * @throws Exception
     */
    public static void sendEarlyWarning(String warningType, Project2 project2, List<CtEarlyWarningBo> boList) throws Exception {
        String subject = "";
        StringBuilder mailBodySb = new StringBuilder();
        StringBuilder dingTalkBodySb = new StringBuilder();
        List<WTUser> recipientList = new ArrayList<>();

        if("A".equals(warningType)){
            subject = "研发费用超支预警";
            mailBodySb.append("研发费用超支预警：\r\n");
            for(CtEarlyWarningBo bo : boList){
                mailBodySb.append("-项目编号：" + bo.getProjectNumber() + "\r\n")
                        .append("-项目名称：" + bo.getProjectName() + "\r\n")
                        .append("-预算金额：" + bo.getBudgetAmount() + "\r\n")
                        .append("-实际金额：" + bo.getActualAmount() + "\r\n");
            }

            dingTalkBodySb.append("{\"title\":\"研发费用超支预警\",\"text\":\"研发费用超支预警：\n\n");
            for(CtEarlyWarningBo bo : boList){
                dingTalkBodySb.append("-项目编号：" + bo.getProjectNumber() + "\n\n")
                        .append("-项目名称：" + bo.getProjectName() + "\n\n")
                        .append("-预算金额：" + bo.getBudgetAmount() + "\n\n")
                        .append("-实际金额：" + bo.getActualAmount() + "\n\n");
            }
            dingTalkBodySb.append("\"}");
            //取角色下的人员
            String[] roleNameArray = {"PDTManager", "DirectorofRDCenter", "FinancialRepresentativeFPDT", "Projectmanagementengineer", "DevelopmentRepresentative"};
            recipientList = getRecipientList(roleNameArray, project2);
        }
        if("B".equals(warningType)){
            subject = "单位产品成本超支预警";
            mailBodySb.append("单位产品成本超支预警（总成本）\r\n");
            for(CtEarlyWarningBo bo : boList){
                mailBodySb.append("-项目编号：" + bo.getProjectNumber() + "\r\n")
                .append("-项目名称：" + bo.getProjectName() + "\r\n")
                .append("-成品编号：" + bo.getPartNumber() + "\r\n")
                .append("-成品名称：" + bo.getPartName() + "\r\n")
                .append("-PDCP目标成本：" + bo.getPdcpCost() + "\r\n")
                .append("-TR节点成本：" + bo.getTrCost() + "/" + bo.getTrNode() + "\r\n");
            }

            dingTalkBodySb.append("{\"title\":\"单位产品成本超支预警\",\"text\":\"单位产品成本超支预警（总成本）\n\n");
            for(CtEarlyWarningBo bo : boList){
                dingTalkBodySb.append("-项目编号：" + bo.getProjectNumber() + "\n\n")
                        .append("-项目名称：" + bo.getProjectName() + "\n\n")
                        .append("-成品编号：" + bo.getPartNumber() + "\n\n")
                        .append("-成品名称：" + bo.getPartName() + "\n\n")
                        .append("-PDCP目标成本：" + bo.getPdcpCost() + "\n\n")
                        .append("-TR节点成本：" + bo.getTrCost() + "/" + bo.getTrNode() + "\n\n");
            }
            dingTalkBodySb.append("\"}");
            //取角色下的人员
            String[] roleNameArray = {"PDTManager", "FinancialRepresentativeFPDT", "Projectmanagementengineer", "DirectorofRDCenter", "DevelopmentRepresentative"};
            recipientList = getRecipientList(roleNameArray, project2);
        }
        if("C".equals(warningType)){
            subject = "单位产品成本超支预警";
            mailBodySb.append("单位产品成本超支预警（总成本）\r\n");
            for(CtEarlyWarningBo bo : boList){
                mailBodySb.append("-项目编号：" + bo.getProjectNumber() + "\r\n")
                        .append("-项目名称：" + bo.getProjectName() + "\r\n")
                        .append("-成品编号：" + bo.getPartNumber() + "\r\n")
                        .append("-成品名称：" + bo.getPartName() + "\r\n")
                        .append("-PDCP目标成本：" + bo.getPdcpCost() + "\r\n")
                        .append("-实际成本：" + bo.getTrCost() + "\r\n");
            }

            dingTalkBodySb.append("{\"title\":\"单位产品成本超支预警\",\"text\":\"单位产品成本超支预警（总成本）\n\n");
            for(CtEarlyWarningBo bo : boList){
                dingTalkBodySb.append("-项目编号：" + bo.getProjectNumber() + "\n\n")
                        .append("-项目名称：" + bo.getProjectName() + "\n\n")
                        .append("-成品编号：" + bo.getPartNumber() + "\n\n")
                        .append("-成品名称：" + bo.getPartName() + "\n\n")
                        .append("-PDCP目标成本：" + bo.getPdcpCost() + "\n\n")
                        .append("-实际成本：" + bo.getTrCost() + "\n\n");
            }
            dingTalkBodySb.append("\"}");
            //取角色下的人员
            String[] roleNameArray = {"PDTManager", "FinancialRepresentativeFPDT"};
            recipientList = getRecipientList(roleNameArray, project2);
        }
        if(("D").equals(warningType)){
            subject = "单位产品成本超支预警";
            mailBodySb.append("单位产品成本超支预警（总成本）\r\n");
            for(CtEarlyWarningBo bo : boList){
                mailBodySb.append("-项目编号：" + bo.getProjectNumber() + "\r\n")
                        .append("-项目名称：" + bo.getProjectName() + "\r\n")
                        .append("-成品编号：" + bo.getPartNumber() + "\r\n")
                        .append("-成品名称：" + bo.getPartName() + "\r\n")
                        .append("-成本类别：" + bo.getCostType() + "\r\n")
                        .append("-PDCP目标成本：" + bo.getPdcpCost() + "\r\n")
                        .append("-TR节点成本：" + bo.getTrCost() + "/" + bo.getTrNode() + "\r\n");
            }

            dingTalkBodySb.append("{\"title\":\"单位产品成本超支预警\",\"text\":\"单位产品成本超支预警（总成本）\n\n");
            for(CtEarlyWarningBo bo : boList){
                dingTalkBodySb.append("-项目编号：" + bo.getProjectNumber() + "\n\n")
                        .append("-项目名称：" + bo.getProjectName() + "\n\n")
                        .append("-成品编号：" + bo.getPartNumber() + "\n\n")
                        .append("-成品名称：" + bo.getPartName() + "\n\n")
                        .append("-成本类别：" + bo.getCostType() + "\n\n")
                        .append("-PDCP目标成本：" + bo.getPdcpCost() + "\n\n")
                        .append("-TR节点成本：" + bo.getTrCost() + "/" + bo.getTrNode() + "\n\n");
            }
            dingTalkBodySb.append("\"}");
            //取角色下的人员
            String[] roleNameArray = {"PDTManager", "Projectmanagementengineer", "DevelopmentRepresentative", "HardwareRDManager",
                    "StructuralDepartmentManager", "ProductEngineeringManager", "TechnicalManager"};
            recipientList = getRecipientList(roleNameArray, project2);
        }

        System.out.println("--------recipientList：" + recipientList.size());
        for(WTUser u : recipientList){
            System.out.println("--------预警接收人：" + u.getName());
        }

        sendMailAndDingTalk(subject, mailBodySb.toString(), dingTalkBodySb.toString(), recipientList);
    }

    /**
     * 按类型取项目团队下不同角色人员
     * @param roleNameArray
     * @param project2
     * @return
     * @throws Exception
     */
    public static List<WTUser> getRecipientList(String[] roleNameArray, Project2 project2) throws Exception {
        List<WTUser> recipientList = new ArrayList<>();
        if(null == project2){
            return recipientList;
        }
        ContainerTeamManaged container = project2;
        ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged) container);
        ArrayList userList = new ArrayList();

        for(int i = 0;i < roleNameArray.length;i++){
            getUserByRole(container, containerTeam, Role.toRole(roleNameArray[i]), userList);
        }

        for(int i = 0;i < userList.size();i++){
            WTPrincipal p = (WTPrincipal) userList.get(i);
            WTUser u = (WTUser) p;
            if(!recipientList.contains(u)){
                recipientList.add(u);
            }
        }
        return recipientList;
    }

    public static void sendMailAndDingTalk(String subject, String mailBody, String dingTalkBody, List<WTUser> recipientList) throws Exception {
        System.out.println("--------sendMailAndDingTalk--开始发预警");

        //发钉钉
        CtMobileWorkReportLogic logic = new CtMobileWorkReportLogic();
        System.out.println(">>>>>>>>>>>sendMailAndDingTalk--recipientList size:" + recipientList.size());

//        recipientList.clear();
//        WTUser user = CtUserUtil.getUserByDisplayName("王日成");
//        if(null != user){
//            recipientList.add(user);
//        }
//        WTUser user1 = CtUserUtil.getUserByAccountName("wcadmin");
//        if(null != user1){
//            recipientList.add(user1);
//        }

        for(WTUser tempUser : recipientList){
            logic.sendMsgToDingTalk("markdown", dingTalkBody, tempUser.getName());
        }


        //发邮件
//        List<String> stringList = new ArrayList<>();
//        for(WTUser tempUser : recipientList){
//            String email = tempUser.getEMail();
//            System.out.println(">>>>>>>>>>>sendMailAndDingTalk--email:" + email);
//            if(CtFormatUtil.hasContent(email)){
//                stringList.add(email);
//            }
//        }
//
//        System.out.println(">>>>>>>>>>>sendMailAndDingTalk--stringList size:" + stringList.size());
//        if (CtFormatUtil.hasContent(stringList)) {
//            // 发送邮件
//            CtMailTool.sendMail(subject, mailBody, stringList);
//            System.out.println(">>>>>>>>>>>sendMailAndDingTalk--发邮件结束");
//        }
    }

    public static double getDouble(Object cost) throws Exception {
        double d = 0d;
        if(CtFormatUtil.hasContent(cost)){
            if(cost instanceof String){
                String c = (String) cost;
                if(isNumber(c)){
                    d = Double.valueOf(c);
                }
            }
            if(cost instanceof Double){
                d = (double) cost;
            }
        }
        return d;
    }

    public static boolean isNumber(String input) {
        return input.matches("-?\\d+(\\.\\d+)?");
    }

    /**
     * 研发费用超支预警、C类单位产品成本超支预警，在队列中调用
     * @throws Exception
     */
    public static void costEarlyWarning() throws Exception {
        System.out.println(">>>进入队列预警逻辑代码！");
        //每月2号预警上月已完成的项目
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String nowDateString = dateFormat.format(new Date());
        if("02".equals(nowDateString.substring(8))){
                //C类单位产品成本超支预警
                costEarlyWarningC();
        }

        //研发费用超支预警
        researchAndDevelopmentEarlyWarning();
        System.out.println(">>>执行队列预警逻辑代码结束！");
    }

    /**
     * 研发费用超支预警
     * @throws Exception
     */
    public static void researchAndDevelopmentEarlyWarning() throws Exception {
        List<CtEarlyWarningBo> recordList = new ArrayList();
        //查询系统中所有BD05的汇总字段有数据的项目
        CtFinanceQuery query = new CtFinanceQuery();
        Map<String, Double> projectSummaryMap = query.queryBD05Summary();

        //按项目编号汇总BI成本
        Map<String, Double> projectActualAmountMap = query.queryActualAmountByProjectNumber();

        //查询已发过的预警
        List<String> warningList = query.queryAlreadyNotifiedEarlyWarning();

        for(Map.Entry<String, Double> entry : projectSummaryMap.entrySet()){
            List<CtEarlyWarningBo> ctEarlyWarningBoList = new ArrayList();
            String projectNumber = entry.getKey();
            System.out.println("-----研发费用超支预警 projectNumber:" + projectNumber);

            //BD05的汇总-间接费用即是总预算
            double projectSummary = entry.getValue();
            System.out.println("-----研发费用超支预警 总预算:" + projectSummary);
            Project2 project2 = CtProjectUtil.getProjectByNumber(projectNumber);
            if(null == project2){
                continue;
            }

            //截取掉项目编号前面4位公司代码查到该项目的BI成本汇总，没有这个数据则跳过
            String projectNumberStr = projectNumber.substring(4);
            Double projectActualAmount = projectActualAmountMap.get(projectNumberStr);
            System.out.println("-----研发费用超支预警 projectNumberStr:" + projectNumberStr);
            System.out.println("-----研发费用超支预警 BI成本:" + projectActualAmount);
            if(null == projectActualAmount){
                continue;
            }

            //目标预算总费用的计算：总预算*((当前里程碑计划完成日期-项目计划开始日期)/(项目计划结束日期-项目计划开始日期))
//            Plan plan = (Plan) PlanHelper.service.getPlan(ObjectReference.newObjectReference(project2));
//            if (null == plan) {
//                continue;
//            }
//            Date startDate = new Date(plan.getStartDate().getTime());
//            Date finishDate = new Date(plan.getFinishDate().getTime());
//            IBAUtil ibaUtil = new IBAUtil(project2);
//            String projectPhase = ibaUtil.getIBAValue("Ct_ProjectPhase");
//            if(!CtFormatUtil.hasContent(projectPhase)){
//                continue;
//            }
//            Long projectId = project2.getPersistInfo().getObjectIdentifier().getId();
//            Date milestoneFinishDate = query.queryMilestoneFinishDate(projectId, projectPhase);
//            if(null == milestoneFinishDate){
//                continue;
//            }
            //数据都取到了，开始计算，先计算出目标预算总费用
//            double targetBudget = projectSummary * (CtDateUtil.getDistDates(startDate, milestoneFinishDate) * 1.0d/CtDateUtil.getDistDates(startDate, finishDate));
//            System.out.println("-----研发费用超支预警 targetBudget:" + targetBudget);

            //当前费用/目标预算总费用 >= 90%，则预警
            double percentage = projectActualAmount/projectSummary;
            System.out.println("-----研发费用超支预警 percentage:" + percentage);
            if(percentage >= 0.9){
                CtEarlyWarningBo bo = new CtEarlyWarningBo();
                bo.setProjectNumber(projectNumber);
                bo.setProjectName(project2.getName());
                bo.setBudgetAmount(projectSummary+"");
                bo.setActualAmount(projectActualAmount+"");
                ctEarlyWarningBoList.add(bo);
            }

            //预警
            if (ctEarlyWarningBoList.size() > 0) {
                Iterator<CtEarlyWarningBo> it = ctEarlyWarningBoList.iterator();
                while (it.hasNext()){
                    CtEarlyWarningBo bo = it.next();
                    //根据记录的预警，判断此预警是否有发过，发过的则移除
                    String key = bo.getProjectNumber() + "-" + bo.getBudgetAmount();
                    if(warningList.contains(key)){
                        it.remove();
                    }
                }
                if (ctEarlyWarningBoList.size() > 0) {
                    //发预警
                    sendEarlyWarning("A", project2, ctEarlyWarningBoList);

                    //记录预警
                    for(CtEarlyWarningBo bo : ctEarlyWarningBoList){
                        recordList.add(bo);
                    }
                }
            }
        }
        //一起记录
        if (recordList.size() > 0) {
            //记录预警
            query.recordWarning(recordList);
        }
    }

    /**
     * C类单位产品成本超支预警
     * @throws Exception
     */
    public static void costEarlyWarningC() throws Exception {
        Map<String, Map<String, Map<String, Double>>> actualCostMap = new HashMap<>();//存放已经从sap查回来的数据
        //上月已完成的项目的数据
        CtFinanceQuery query = new CtFinanceQuery();
        Map<String, Map<String, List<Map<String, String>>>> map = query.queryProjectsCompletedLastMonthData();
        if(map.size() > 0){
            for(Map.Entry<String, Map<String, List<Map<String, String>>>> entry : map.entrySet()){
                String projectNumber = entry.getKey();
                if(!CtFormatUtil.hasContent(projectNumber)){
                    continue;
                }
                Project2 project2 = CtProjectUtil.getProjectByNumber(projectNumber);
                if(null == project2){
                    continue;
                }
                String projectName = project2.getName();
                List<CtEarlyWarningBo> ctEarlyWarningBoList = new ArrayList<>();
                Map<String, List<Map<String, String>>> partMap = entry.getValue();
                for(Map.Entry<String, List<Map<String, String>>> partEntry : partMap.entrySet()){
                    String partNumber = partEntry.getKey();
                    if(!CtFormatUtil.hasContent(partNumber)){
                        continue;
                    }
                    WTPart part = CtPartUtil.getPartByNumber(partNumber);
                    if(null == part){
                        continue;
                    }
                    String partName = part.getName();
                    //从SAP查询实际成本、实际生产数量
                    Map<String, Map<String, Double>> actualQuantityMap = new HashMap<>();
                    if(actualCostMap.containsKey(partNumber)){
                        actualQuantityMap = actualCostMap.get(partNumber);
                    }else{
                        //从SAP查询实际成本、实际生产数量
                        List<Map<String, String>> actualQuantityList = CtSapInterface.getProductionQuantity(partNumber);
                        CtFinanceHelper.summaryCostProjectQuantity(partNumber, actualQuantityList, actualQuantityMap);
                        actualCostMap.put(partNumber, actualQuantityMap);
                    }

                    //加总sap的实际成本
                    double actualQuantity = 0d;//实际生产数量
                    double actualCountCost = 0d;//汇总实际成本
                    for(Map.Entry<String, Map<String, Double>> costEntry : actualQuantityMap.entrySet()){
                        Map<String, Double> infoMap = costEntry.getValue();
                        if(actualQuantity == 0 && null != infoMap.get("actualQuantity")){
                            actualQuantity = infoMap.get("actualQuantity");
                        }
                        Double actualCost = infoMap.get("actualCost");
                        actualCountCost += getDouble(actualCost);
                    }

                    double pdcpCountCost = 0d;
                    List<Map<String, String>> partList = partEntry.getValue();
                    //只有“制造成本-制造费用”有阶段数量，所以先处理这一类的
                    for(Map<String, String> costTypeMap : partList){
                        String partStep = costTypeMap.get("partStep");
                        String costProject = costTypeMap.get("costProject");
                        String pdcpCost = costTypeMap.get("pdcpCost");
                        if(CtFormatUtil.hasContent(partStep) && "制造成本-制造费用".equals(costProject)){
                            //判断数量属于这个阶梯，然后取实际成本
                            String[] stepArray = partStep.split("-");
                            if(2 == stepArray.length && Double.valueOf(stepArray[0]) <= actualQuantity && Double.valueOf(stepArray[1]) >= actualQuantity){
                                pdcpCountCost = getDouble(pdcpCost);
                            }
                        }
                    }
                    //说明没有匹配到阶梯
                    if(pdcpCountCost == 0){
                        continue;
                    }
                    //加总非“制造成本-制造费用”的PDCP成本
                    for(Map<String, String> costTypeMap : partList){
                        String costProject = costTypeMap.get("costProject");
                        String pdcpCost = costTypeMap.get("pdcpCost");
                        if(!"制造成本-制造费用".equals(costProject)){
                            pdcpCountCost += getDouble(pdcpCost);
                        }
                    }

                    if(0 != actualCountCost && actualCountCost >= pdcpCountCost){
                        //预警
                        CtEarlyWarningBo ctEarlyWarningBo = new CtEarlyWarningBo();
                        ctEarlyWarningBo.setProjectNumber(projectNumber);
                        ctEarlyWarningBo.setProjectName(projectName);
                        ctEarlyWarningBo.setPartNumber(partNumber);
                        ctEarlyWarningBo.setPartName(partName);
                        ctEarlyWarningBo.setPdcpCost(pdcpCountCost+"");
                        ctEarlyWarningBo.setTrCost(actualCountCost+"");
                        ctEarlyWarningBoList.add(ctEarlyWarningBo);
                    }
                }

                if (ctEarlyWarningBoList.size() > 0) {
                    //发预警
                    sendEarlyWarning("C", project2, ctEarlyWarningBoList);
                }
            }
        }
    }

    /**
     * 获取角色下的user
     * @param containerTeam
     * @param role
     * @param availableUsers
     * @throws WTException
     */
    public static void getUserByRole(WTContainer container, ContainerTeam containerTeam, Role role, ArrayList availableUsers) throws WTException{
        if(role == null){
            return;
        }
        List tempList = new ArrayList();
        tempList = containerTeam.getAllPrincipalsForTarget(role);
        WTPrincipal tempPrincipal = null;
        WTPrincipalReference principalRef = null;
        Enumeration enuUsers = null;
        //tempList = getAllPrincipalsForTarget(tempRole, containerTeam);
        //获取团队角色下的user，如果是group则继续遍历
        if(tempList != null && tempList.size() > 0){
            for(int i = 0; i < tempList.size(); i++){
                principalRef = (WTPrincipalReference)tempList.get(i);
                tempPrincipal = principalRef.getPrincipal();
                if(tempPrincipal instanceof WTGroup){
                    enuUsers = OrganizationServicesHelper.manager.members((WTGroup)tempPrincipal);
                    if(enuUsers != null){
                        while(enuUsers.hasMoreElements()){
                            tempPrincipal = (WTPrincipal)enuUsers.nextElement();
                            principalRef = WTPrincipalReference.newWTPrincipalReference(tempPrincipal);
                            if(!availableUsers.contains(tempPrincipal))
                                availableUsers.add(tempPrincipal);
                        }
                    }
                }else {
                    if(!availableUsers.contains(tempPrincipal))
                        availableUsers.add(tempPrincipal);
                }
            }
        }
    }

}
