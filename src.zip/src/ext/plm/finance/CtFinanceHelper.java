package ext.plm.finance;

import com.alibaba.druid.util.StringUtils;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.google.common.base.Flag;
import ext.plm.adminTool.configCenter.manager.CtConfigCenterManager;
import ext.plm.adminTool.configCenter.manager.CtPropertyConfig;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.baselineQuery.mapper.CtBomBaselineBoMapper;
import ext.plm.finance.bo.*;
import ext.plm.finance.mapper.*;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import wt.part.WTPart;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.*;

public class CtFinanceHelper {
    /**
     * 取得BD001中的年份，没有则返回当前年份
     * @param branchId
     * @return
     * @throws Exception
     */
    public static int getProductLifeCycle(Long branchId) throws Exception {
        CtFinanceBD001Mapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtFinanceBD001Mapper.class);
        List<CtFinanceBD001Bo> list = mapper.selectList(new EntityWrapper<CtFinanceBD001Bo>().eq(("branchId"), branchId));
        for(CtFinanceBD001Bo bo : list){
            if("预计上市年份*".equals(bo.getProject())){
                String productLifeCycle = bo.getPredictedSituation();
                if(CtFormatUtil.hasContent(productLifeCycle)){
                    return Integer.parseInt(productLifeCycle);
                }
            }
        }
        //默认值
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.YEAR);
    }

    /**
     * 导出
     * @param branchId
     * @return
     * @throws Exception
     */
    public static SXSSFWorkbook exportExcel(Long branchId) throws Exception {
        SXSSFWorkbook workbook = new SXSSFWorkbook();//默认100行，超100行将写入临时文件
        workbook.setCompressTempFiles(false);//是否压缩临时文件，否则写入速度更快，但更占磁盘，但程序最后是会将临时文件删掉的
        //设置样式
        XSSFCellStyle titleCellStyle = (XSSFCellStyle) workbook.createCellStyle();
        titleCellStyle.setBorderBottom(BorderStyle.THIN);
        titleCellStyle.setBorderLeft(BorderStyle.THIN);
        titleCellStyle.setBorderTop(BorderStyle.THIN);
        titleCellStyle.setBorderRight(BorderStyle.THIN);
        titleCellStyle.setAlignment(HorizontalAlignment.CENTER);
        Font font = workbook.createFont();
        font.setBold(true); // 设置字体加粗
        titleCellStyle.setFont(font);
        //黑色字体带边框样式
        XSSFCellStyle cellStyle = (XSSFCellStyle) workbook.createCellStyle();
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);

        //取得年份，用于生成标题
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        CtFinanceBD001Mapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtFinanceBD001Mapper.class);
        List<CtFinanceBD001Bo> list = mapper.selectList(new EntityWrapper<CtFinanceBD001Bo>().eq(("branchId"), branchId));
        for(CtFinanceBD001Bo bo : list){
            if("预计上市年份*".equals(bo.getProject())){
                String productLifeCycle = bo.getPredictedSituation();
                if(CtFormatUtil.hasContent(productLifeCycle)){
                    year = Integer.parseInt(productLifeCycle);
                }
            }
        }

        //写入excel
        writeBD001(branchId, workbook, titleCellStyle, cellStyle);
        writeBD002(branchId, workbook, titleCellStyle, cellStyle, year);
        writeBD003(branchId, workbook, titleCellStyle, cellStyle, year);
        writeBD004(branchId, workbook, titleCellStyle, cellStyle);
        writeBD005(branchId, workbook, titleCellStyle, cellStyle);
        return workbook;
    }

    /**
     * 写BD001的数据到第一个sheet
     * @param branchId
     * @param workbook
     * @param titleCellStyle
     * @param cellStyle
     * @throws Exception
     */
    public static void writeBD001(Long branchId, SXSSFWorkbook workbook, XSSFCellStyle titleCellStyle, XSSFCellStyle cellStyle) throws Exception {
        Sheet sheet = workbook.createSheet("项目基础信息汇总表-BD001");
        sheet.setColumnWidth(0, 5000);
        sheet.setColumnWidth(1, 8000);
        sheet.setColumnWidth(2, 5000);
        sheet.setColumnWidth(3, 18000);
        Row row = null;
        Cell cell = null;
        int rowIndex = 0;
        //表头
        String[] titleArray = {"项目", "预测情况", "单位", "备注"};
        row = sheet.createRow(rowIndex);
        for(int i = 0;i < titleArray.length; i++){
            cell = row.createCell(i);
            cell.setCellValue(titleArray[i]);
            cell.setCellStyle(titleCellStyle);
        }
        //正文
        CtFinanceBD001Mapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtFinanceBD001Mapper.class);
        List<CtFinanceBD001Bo> list = mapper.selectList(new EntityWrapper<CtFinanceBD001Bo>().eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        for(int i = 0;i < list.size();i++){
            rowIndex = i+1;
            CtFinanceBD001Bo bo = list.get(i);
            row = sheet.createRow(rowIndex);
            cell = row.createCell(0);
            cell.setCellValue(bo.getProject());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(1);
            cell.setCellValue(bo.getPredictedSituation());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(2);
            cell.setCellValue(bo.getCompany());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(3);
            cell.setCellValue(bo.getRemarks());
            cell.setCellStyle(cellStyle);
        }
    }

    /**
     * 写BD002的数据到第二个sheet
     * @param branchId
     * @param workbook
     * @param titleCellStyle
     * @param cellStyle
     * @throws Exception
     */
    public static void writeBD002(Long branchId, SXSSFWorkbook workbook, XSSFCellStyle titleCellStyle, XSSFCellStyle cellStyle, int year) throws Exception {
        Sheet sheet = workbook.createSheet("利润预算表-BD002");
        sheet.setColumnWidth(0, 6000);
        sheet.setColumnWidth(1, 5000);
        sheet.setColumnWidth(2, 5000);
        sheet.setColumnWidth(3, 5000);
        sheet.setColumnWidth(4, 5000);
        sheet.setColumnWidth(5, 5000);
        sheet.setColumnWidth(6, 5000);
        sheet.setColumnWidth(7, 5000);
        sheet.setColumnWidth(8, 5000);
        Row row = null;
        Cell cell = null;
        int rowIndex = 0;
        //表头
        String[] titleArray = new String[9];
        titleArray[0] = "项目";
        titleArray[1] = year + "年";
        titleArray[2] = (year+1) + "年";
        titleArray[3] = (year+2) + "年";
        titleArray[4] = (year+3) + "年";
        titleArray[5] = (year+4) + "年";
        titleArray[6] = (year+5) + "年";
        titleArray[7] = "合计";
        titleArray[8] = "备注";
        row = sheet.createRow(rowIndex);
        for(int i = 0;i < titleArray.length; i++){
            cell = row.createCell(i);
            cell.setCellValue(titleArray[i]);
            cell.setCellStyle(titleCellStyle);
        }
        //正文
        CtFinanceBD002Mapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtFinanceBD002Mapper.class);
        List<CtFinanceBD002Bo> list = mapper.selectList(new EntityWrapper<CtFinanceBD002Bo>().eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        for(int i = 0;i < list.size();i++){
            rowIndex = i+1;
            CtFinanceBD002Bo bo = list.get(i);
            row = sheet.createRow(rowIndex);
            cell = row.createCell(0);
            cell.setCellValue(bo.getProject());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(1);
            cell.setCellValue(bo.getLifeCycle0());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(2);
            cell.setCellValue(bo.getLifeCycle1());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(3);
            cell.setCellValue(bo.getLifeCycle2());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(4);
            cell.setCellValue(bo.getLifeCycle3());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(5);
            cell.setCellValue(bo.getLifeCycle4());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(6);
            cell.setCellValue(bo.getLifeCycle5());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(7);
            cell.setCellValue(bo.getTotal());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(8);
            cell.setCellValue(bo.getRemarks());
            cell.setCellStyle(cellStyle);
        }
    }

    /**
     * 写BD003的数据到第三个sheet
     * @param branchId
     * @param workbook
     * @param titleCellStyle
     * @param cellStyle
     * @throws Exception
     */
    public static void writeBD003(Long branchId, SXSSFWorkbook workbook, XSSFCellStyle titleCellStyle, XSSFCellStyle cellStyle, int year) throws Exception {
        Sheet sheet = workbook.createSheet("销售毛利预算表-BD003");
        sheet.setColumnWidth(0, 5000);
        sheet.setColumnWidth(1, 5000);
        sheet.setColumnWidth(2, 6000);
        sheet.setColumnWidth(3, 5000);
        sheet.setColumnWidth(4, 5000);
        sheet.setColumnWidth(5, 5000);
        sheet.setColumnWidth(6, 5000);
        sheet.setColumnWidth(7, 5000);
        sheet.setColumnWidth(8, 5000);
        Row row = null;
        Cell cell = null;
        int rowIndex = 0;
        //表头
        String[] titleArray = new String[9];
        titleArray[0] = "产品编码";
        titleArray[1] = "产品描述";
        titleArray[2] = "参数类型";
        titleArray[3] = year + "年";
        titleArray[4] = (year+1) + "年";
        titleArray[5] = (year+2) + "年";
        titleArray[6] = (year+3) + "年";
        titleArray[7] = (year+4) + "年";
        titleArray[8] = (year+5) + "年";
        row = sheet.createRow(rowIndex);
        for(int i = 0;i < titleArray.length; i++){
            cell = row.createCell(i);
            cell.setCellValue(titleArray[i]);
            cell.setCellStyle(titleCellStyle);
        }
        //正文
        CtFinanceBD003Mapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtFinanceBD003Mapper.class);
        List<CtFinanceBD003Bo> list = mapper.selectList(new EntityWrapper<CtFinanceBD003Bo>().eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        for(int i = 0;i < list.size();i++){
            rowIndex = i+1;
            CtFinanceBD003Bo bo = list.get(i);
            row = sheet.createRow(rowIndex);
            cell = row.createCell(0);
            cell.setCellValue(bo.getProductCode());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(1);
            cell.setCellValue(bo.getProductDescription());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(2);
            cell.setCellValue(bo.getParameterType());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(3);
            cell.setCellValue(bo.getYear1());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(4);
            cell.setCellValue(bo.getYear2());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(5);
            cell.setCellValue(bo.getYear3());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(6);
            cell.setCellValue(bo.getYear4());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(7);
            cell.setCellValue(bo.getYear5());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(8);
            cell.setCellValue(bo.getYear6());
            cell.setCellStyle(cellStyle);
        }
    }

    /**
     * 写BD004的数据到第四个sheet
     * @param branchId
     * @param workbook
     * @param titleCellStyle
     * @param cellStyle
     * @throws Exception
     */
    public static void writeBD004(Long branchId, SXSSFWorkbook workbook, XSSFCellStyle titleCellStyle, XSSFCellStyle cellStyle) throws Exception {
        Sheet sheet = workbook.createSheet("人力费用预算表-BD004");
        sheet.setColumnWidth(0, 5000);
        sheet.setColumnWidth(1, 4000);
        sheet.setColumnWidth(2, 4000);
        sheet.setColumnWidth(3, 4000);
        sheet.setColumnWidth(4, 4000);
        sheet.setColumnWidth(5, 4000);
        sheet.setColumnWidth(6, 4000);
        sheet.setColumnWidth(7, 4000);
        sheet.setColumnWidth(8, 4000);
        sheet.setColumnWidth(9, 4000);
        sheet.setColumnWidth(10, 4000);
        sheet.setColumnWidth(11, 4000);
        sheet.setColumnWidth(12, 4000);
        sheet.setColumnWidth(13, 4000);
        sheet.setColumnWidth(14, 4000);
        sheet.setColumnWidth(15, 4000);
        sheet.setColumnWidth(16, 4000);
        sheet.setColumnWidth(17, 4000);
        Row row = null;
        Cell cell = null;
        int rowIndex = 0;
        //表头
        row = sheet.createRow(rowIndex);
        Row row1 = sheet.createRow(rowIndex+1);
        cell = row.createCell(0);
        cell.setCellValue("工程师分类");
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        CellRangeAddress mergedRegion = new CellRangeAddress(0, 1, 0, 1);
        sheet.addMergedRegion(mergedRegion);

        cell = row.createCell(2);
        cell.setCellValue("预计工时");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(2);
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 1, 2, 2);
        sheet.addMergedRegion(mergedRegion);

        cell = row.createCell(3);
        cell.setCellValue("预算");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(3);
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 1, 3, 3);
        sheet.addMergedRegion(mergedRegion);

        cell = row.createCell(4);
        cell.setCellValue("里程碑外预算");
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 0, 4, 5);
        sheet.addMergedRegion(mergedRegion);
        cell = row1.createCell(4);
        cell.setCellValue("预计工时");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(5);
        cell.setCellValue("预算");
        cell.setCellStyle(titleCellStyle);

        cell = row.createCell(6);
        cell.setCellValue("Start-TR2");
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 0, 6, 7);
        sheet.addMergedRegion(mergedRegion);
        cell = row1.createCell(6);
        cell.setCellValue("预计工时");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(7);
        cell.setCellValue("预算");
        cell.setCellStyle(titleCellStyle);

        cell = row.createCell(8);
        cell.setCellValue("TR2-PDCP");
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 0, 8, 9);
        sheet.addMergedRegion(mergedRegion);
        cell = row1.createCell(8);
        cell.setCellValue("预计工时");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(9);
        cell.setCellValue("预算");
        cell.setCellStyle(titleCellStyle);

        cell = row.createCell(10);
        cell.setCellValue("PDCP-TR4");
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 0, 10, 11);
        sheet.addMergedRegion(mergedRegion);
        cell = row1.createCell(10);
        cell.setCellValue("预计工时");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(11);
        cell.setCellValue("预算");
        cell.setCellStyle(titleCellStyle);

        cell = row.createCell(12);
        cell.setCellValue("TR4-TR5");
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 0, 12, 13);
        sheet.addMergedRegion(mergedRegion);
        cell = row1.createCell(12);
        cell.setCellValue("预计工时");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(13);
        cell.setCellValue("预算");
        cell.setCellStyle(titleCellStyle);

        cell = row.createCell(14);
        cell.setCellValue("TR5-TR6");
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 0, 14, 15);
        sheet.addMergedRegion(mergedRegion);
        cell = row1.createCell(14);
        cell.setCellValue("预计工时");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(15);
        cell.setCellValue("预算");
        cell.setCellStyle(titleCellStyle);

        cell = row.createCell(16);
        cell.setCellValue("TR6-End");
        cell.setCellStyle(titleCellStyle);
        cell = row.createCell(17);
        cell.setCellValue("");
        cell.setCellStyle(titleCellStyle);
        //合并单元格
        mergedRegion = new CellRangeAddress(0, 0, 16, 17);
        sheet.addMergedRegion(mergedRegion);
        cell = row1.createCell(16);
        cell.setCellValue("预计工时");
        cell.setCellStyle(titleCellStyle);
        cell = row1.createCell(17);
        cell.setCellValue("预算");
        cell.setCellStyle(titleCellStyle);

        //正文
        CtFinanceBD004Mapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtFinanceBD004Mapper.class);
        List<CtFinanceBD004Bo> list = mapper.selectList(new EntityWrapper<CtFinanceBD004Bo>().eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        int firstRow = 0;
        String proValue = "";
        for(int i = 0;i < list.size();i++){
            rowIndex = i+2;
            CtFinanceBD004Bo bo = list.get(i);
            row = sheet.createRow(rowIndex);
            cell = row.createCell(0);
            cell.setCellValue(bo.getType1());
            cell.setCellStyle(cellStyle);
            //合并单元格，把第一列值相同的行合并起来
            if(CtFormatUtil.hasContent(proValue)){
                if(!proValue.equals(bo.getType1()) && (rowIndex-1 > firstRow)){
                    mergedRegion = new CellRangeAddress(firstRow, rowIndex-1, 0, 0);
                    sheet.addMergedRegion(mergedRegion);
                    firstRow = rowIndex;//下一次合并的起始行
                    proValue = bo.getType1();
                }
            }else{
                firstRow = rowIndex;//下一次合并的起始行
                proValue = bo.getType1();
            }

            cell = row.createCell(1);
            cell.setCellValue(bo.getType2());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(2);
            cell.setCellValue(bo.getWorkingHours0());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(3);
            cell.setCellValue(bo.getBudget0());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(4);
            cell.setCellValue(bo.getWorkingHours1());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(5);
            cell.setCellValue(bo.getBudget1());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(6);
            cell.setCellValue(bo.getWorkingHours2());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(7);
            cell.setCellValue(bo.getBudget2());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(8);
            cell.setCellValue(bo.getWorkingHours3());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(9);
            cell.setCellValue(bo.getBudget3());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(10);
            cell.setCellValue(bo.getWorkingHours4());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(11);
            cell.setCellValue(bo.getBudget4());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(12);
            cell.setCellValue(bo.getWorkingHours5());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(13);
            cell.setCellValue(bo.getBudget5());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(14);
            cell.setCellValue(bo.getWorkingHours6());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(15);
            cell.setCellValue(bo.getBudget6());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(16);
            cell.setCellValue(bo.getWorkingHours7());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(17);
            cell.setCellValue(bo.getBudget7());
            cell.setCellStyle(cellStyle);
        }
    }

    /**
     * 写BD005的数据到第五个sheet
     * @param branchId
     * @param workbook
     * @param titleCellStyle
     * @param cellStyle
     * @throws Exception
     */
    public static void writeBD005(Long branchId, SXSSFWorkbook workbook, XSSFCellStyle titleCellStyle, XSSFCellStyle cellStyle) throws Exception {
        Sheet sheet = workbook.createSheet("开发费用预算表-BD005");
        sheet.setColumnWidth(0, 6000);
        sheet.setColumnWidth(1, 4000);
        sheet.setColumnWidth(2, 4000);
        sheet.setColumnWidth(3, 4000);
        sheet.setColumnWidth(4, 4000);
        sheet.setColumnWidth(5, 4000);
        sheet.setColumnWidth(6, 4000);
        sheet.setColumnWidth(7, 4000);
        sheet.setColumnWidth(8, 4000);
        Row row = null;
        Cell cell = null;
        int rowIndex = 0;
        //表头
        String[] titleArray = {"费用类型", "汇总", "里程碑外预算", "Start-TR2", "TR2-PDCP", "PDCP-TR4", "TR4-TR5", "TR5-TR6", "TR6-End"};
        row = sheet.createRow(rowIndex);
        for(int i = 0;i < titleArray.length; i++){
            cell = row.createCell(i);
            cell.setCellValue(titleArray[i]);
            cell.setCellStyle(titleCellStyle);
        }
        //正文
        CtFinanceBD005Mapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtFinanceBD005Mapper.class);
        List<CtFinanceBD005Bo> list = mapper.selectList(new EntityWrapper<CtFinanceBD005Bo>().eq(("branchId"), branchId).orderBy("TO_NUMBER(serialNumber)"));
        for(int i = 0;i < list.size();i++){
            rowIndex = i+1;
            CtFinanceBD005Bo bo = list.get(i);
            row = sheet.createRow(rowIndex);
            cell = row.createCell(0);
            cell.setCellValue(bo.getCostType());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(1);
            cell.setCellValue(bo.getSummary());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(2);
            cell.setCellValue(bo.getExtraMilestoneBudget());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(3);
            cell.setCellValue(bo.getStartTr2());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(4);
            cell.setCellValue(bo.getTr2Pdcp());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(5);
            cell.setCellValue(bo.getPdcpTr4());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(6);
            cell.setCellValue(bo.getTr4Tr5());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(7);
            cell.setCellValue(bo.getTr5Tr6());
            cell.setCellStyle(cellStyle);

            cell = row.createCell(8);
            cell.setCellValue(bo.getTr6End());
            cell.setCellStyle(cellStyle);
        }
    }

    /**
     * 以成本项目为维度汇总成本
     * @param sapProductCostBoList
     * @param costProjectMap
     * @throws Exception
     */
    public static void summaryCostProject(List<CtSapProductCostBo> sapProductCostBoList, Map<String, Float> costProjectMap) throws Exception {
        CtPropertyConfig classificationConfig = CtConfigCenterManager.getInstance().loadProperty("CostProjectAndClassificationMapping");
        for(CtSapProductCostBo bo : sapProductCostBoList){
            String partNumber = bo.getPartNumber();
            Float partCost = bo.getTotalPrice();
            if(!partNumber.startsWith("1")){
                continue;
            }
            WTPart part = CtPartUtil.getPartByNumber(partNumber);
            if(null == part){
                continue;
            }
            IBAUtil ibaUtil = new IBAUtil(part);
            String classification = ibaUtil.getIBAValue("fhsj_Classification");
            String costProject = classificationConfig.getValue(classification);
            if(CtFormatUtil.hasContent(costProject)){
                if(costProjectMap.containsKey(costProject)){
                    Float projectCost = costProjectMap.get(costProject);
                    costProjectMap.put(costProject, projectCost+partCost);
                }else{
                    costProjectMap.put(costProject, partCost);
                }
            }
        }
    }

    /**
     * 以成本项目为维度汇总成本和数量
     * @param sapInfoList
     * @param resultMap
     * @throws Exception
     */
    public static void summaryCostProjectQuantity(String endPartNumber, List<Map<String, String>> sapInfoList, Map<String, Map<String, Double>> resultMap) throws Exception {
        double quantity1 = 0d;
        double quantity2 = 0d;
        Map<String, Double> projectCostMap = new HashMap<>();
        CtPropertyConfig classificationConfig = CtConfigCenterManager.getInstance().loadProperty("CostProjectAndClassificationMapping");
        for(Map<String, String> tempMap : sapInfoList){
            String actualCost = tempMap.get("actualCost");
            String partNumber = tempMap.get("partNumber");
            String actualQuantity = tempMap.get("actualQuantity");
            String takeQuantity = tempMap.get("takeQuantity");

            //如果是该成品，则取生产数量、收货数量
            if(endPartNumber.equals(partNumber)){
                if(CtFormatUtil.hasContent(actualQuantity)){
                    quantity1 = Double.parseDouble(actualQuantity);
                }else{
                    throw new Exception("成品编码" + endPartNumber + "已生产数量为空！");
                }
                if(CtFormatUtil.hasContent(takeQuantity)){
                    quantity2 = Double.parseDouble(takeQuantity);
                }else{
                    throw new Exception("成品编码" + endPartNumber + "最新订单收货数量为空！");
                }
                continue;
            }

            if(!CtFormatUtil.hasContent(actualCost) || !CtFormatUtil.hasContent(partNumber)){
                continue;
            }
            double actualCostDouble = Double.parseDouble(actualCost);
            //制造成本-制造费用类型汇总成本
            if("10".equals(partNumber) || "20".equals(partNumber) || "30".equals(partNumber) || "40".equals(partNumber)){
                //制造费用
                if(projectCostMap.containsKey("制造成本-制造费用")){
                    double allCost = actualCostDouble + projectCostMap.get("制造成本-制造费用");
                    projectCostMap.put("制造成本-制造费用", allCost);
                }else{
                    projectCostMap.put("制造成本-制造费用", actualCostDouble);
                }
                continue;
            }

            //其他类型汇总成本
            WTPart part = CtPartUtil.getPartByNumber(partNumber);
            if(null == part){
                continue;
            }
            IBAUtil ibaUtil = new IBAUtil(part);
            String classification = ibaUtil.getIBAValue("fhsj_Classification");
            String costProject = classificationConfig.getValue(classification);
            if(CtFormatUtil.hasContent(costProject)){
                if(projectCostMap.containsKey(costProject)){
                    double allCost = actualCostDouble + projectCostMap.get(costProject);
                    projectCostMap.put(costProject, allCost);
                }else{
                    projectCostMap.put(costProject, actualCostDouble);
                }
            }
        }

        //计算并返回数据
        for(Map.Entry<String, Double> tempEntry : projectCostMap.entrySet()){
            String project = tempEntry.getKey();
            double cost = tempEntry.getValue();
            Map<String, Double> tempMap = new HashMap();
            tempMap.put("actualQuantity", quantity1);
            tempMap.put("actualCost", cost/quantity2);
            resultMap.put(project, tempMap);
        }
    }

    /**
     * 返回指定单元格数据，不去前后两端空格
     * @Description:
     * @param sheet
     * @param rowIndex  从第几行开始
     * @param cellIndex 从第几列开始
     * @return
     */
    public static String getCellValue(Sheet sheet, int rowIndex, int cellIndex, FormulaEvaluator formulaEvaluator) throws Exception {
        if(sheet.getRow(rowIndex) == null || sheet.getRow(rowIndex).getCell(cellIndex) == null) {
            return null;
        }
        return getCellValue(sheet, sheet.getRow(rowIndex).getCell(cellIndex), formulaEvaluator);
    }

    /**
     * 解析日期字符串
     * @param date
     * @param pattern
     * @return
     */
    private static String getDateStr(Date date, String pattern) {
        if(date==null) {
            return "";
        }
        return new SimpleDateFormat(pattern).format(date);
    }

    /**
     * 格式化解析数据
     *
     * @param cell
     * @return
     */
    private static String getCellValue(Sheet sheet, Cell cell, FormulaEvaluator formulaEvaluator) throws Exception {
        String cellValue = "";
        if (cell != null) {
            switch (cell.getCellType()) {
                case Cell.CELL_TYPE_NUMERIC: // 数值类型
                    if (DateUtil.isCellDateFormatted(cell)) {
                        cellValue = getDateStr(cell.getDateCellValue(), "yyyy-MM-dd HH:mm:ss");
                    } else {
                        cell.setCellType(Cell.CELL_TYPE_STRING);
                        cellValue = cell.getStringCellValue();
                    }
                    break;
                case Cell.CELL_TYPE_STRING: // 字符串类型
                    cellValue = cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_BOOLEAN: // 布尔类型
                    cellValue = String.valueOf(cell.getBooleanCellValue());
                    break;
                case Cell.CELL_TYPE_FORMULA: // 公式类型
                    //取得单元格的字符串
                    try {
                        cellValue = String.valueOf(cell.getNumericCellValue());
                    } catch (IllegalStateException e) {
                        try{
                            cellValue = String.valueOf(cell.getRichStringCellValue());
                        }catch (Exception e1) {
                            cellValue = String.valueOf(cell.getCellFormula());
//                            String sheetName = sheet.getSheetName();
//                            int rowIndex = cell.getRowIndex();
//                            int cellIndex = cell.getColumnIndex();
//                            throw new Exception(sheetName + "第" +(rowIndex+1)+ "行第" +(cellIndex+1)+ "列公式有误，请检查！", e1);
                        }
                    }
                    //执行公式，此处cell的值就是公式
//                    CellValue evaluate = formulaEvaluator.evaluate(cell);
//                    cellValue = evaluate.formatAsString();
                    break;
                case Cell.CELL_TYPE_BLANK: // 空白类型
                    cellValue = "";
                    break;
                case Cell.CELL_TYPE_ERROR:
                    cellValue = "";
                    break;
                default:
                    cellValue = cell.toString().trim();
                    break;
            }
        }
        return cellValue.trim();
    }

    public static String formatData(String value, String flag) throws Exception {
        if(null == value){
            return null;
        }
        if(!StringUtils.isNumber(value)){
            return value;
        }
        int digit = 0;
        if(flag.contains("（%）")){
            digit = 4;
        }else if(flag.contains("（元）")){
            digit = 2;
        }else{
            return value;
        }
        return formatDouble(value, digit);
    }

    /**
     * 保留小数
     * @param d
     * @param digit
     * @return
     * @throws Exception
     */
    public static String formatDouble(String d, int digit) throws Exception {
        if(null == d){
            return "";
        }
        BigDecimal value = new BigDecimal(d);
        BigDecimal roundedValue = value.setScale(digit, RoundingMode.HALF_UP);
        return roundedValue.toString();
    }


}
