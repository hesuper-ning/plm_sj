package ext.plm.finance.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.finance.bo.CtSapProductCostBo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtSapProductCostMapper extends BaseMapper<CtSapProductCostBo> {

}
