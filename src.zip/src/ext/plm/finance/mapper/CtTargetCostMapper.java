package ext.plm.finance.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.finance.bo.CtTargetCostBo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CtTargetCostMapper extends BaseMapper<CtTargetCostBo> {

    //查询最大的序号
    int queryMaxSerialNumber(Long branchId) throws Exception;

    //通过产品编号查询数据
    List<CtTargetCostBo> queryProductData(@Param("partNumberList") List<String> partNumberList) throws Exception;

}
