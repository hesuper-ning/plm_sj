package ext.plm.finance.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.finance.bo.CtFinanceBD001Bo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtFinanceBD001Mapper extends BaseMapper<CtFinanceBD001Bo> {

}
