package ext.plm.finance.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.finance.bo.CtFinanceBD002Bo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtFinanceBD002Mapper extends BaseMapper<CtFinanceBD002Bo> {

}
