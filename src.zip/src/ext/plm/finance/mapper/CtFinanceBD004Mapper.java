package ext.plm.finance.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.finance.bo.CtFinanceBD004Bo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CtFinanceBD004Mapper extends BaseMapper<CtFinanceBD004Bo> {
    /**
     * 根据项目编号查询人力费用预算
     * @param projectNumber
     * @return
     * @throws Exception
     */
    Long queryDocBranchId(@Param("projectNumber") String projectNumber) throws Exception;

}
