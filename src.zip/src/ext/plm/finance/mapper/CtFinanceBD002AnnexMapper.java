package ext.plm.finance.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.finance.bo.CtFinanceBD002AnnexBo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtFinanceBD002AnnexMapper extends BaseMapper<CtFinanceBD002AnnexBo> {

}
