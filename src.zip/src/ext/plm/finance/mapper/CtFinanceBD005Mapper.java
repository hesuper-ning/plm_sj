package ext.plm.finance.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.finance.bo.CtFinanceBD005Bo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtFinanceBD005Mapper extends BaseMapper<CtFinanceBD005Bo> {

}
