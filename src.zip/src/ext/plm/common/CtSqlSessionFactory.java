package ext.plm.common;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import wt.util.WTProperties;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class CtSqlSessionFactory {
	
	//mybatis 的配置文件 local
	private final static String CONFIG_FILE = "/codebase/ext/plm/common/mybatis.xml";

	private static SqlSessionFactory sqlSessionFactory;

	/**
	 * 获取Mybatis 的SqlSessionFactory
	 * 
	 * @return
	 * @author 
	 */
	public static SqlSessionFactory getSqlSessionFactory() {

		if (sqlSessionFactory == null) {
			InputStream inputStream = null;
			try {
				WTProperties wtProperties = WTProperties.getLocalProperties();
				String filePath = wtProperties.getProperty("wt.home")+CONFIG_FILE;
				inputStream = new FileInputStream(filePath);
				sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);

			} catch (IOException e) {
				e.printStackTrace();
				System.out.println(">>>ERROR>>>>>获取Mybatis配置文件失败" + e.getMessage());
			} finally {
				try {
					if (inputStream != null) {
						inputStream.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		return sqlSessionFactory;
	}
}
