package ext.plm.common;

public class CtComboBo {

    private String key;//combo内部值

    private String value;//combo显示值

    public CtComboBo() {
    }

    public CtComboBo(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
