package ext.plm.common;

import ext.plm.common.resultCode.ResultCode;

import java.io.Serializable;

/**
 * @author liangzh
 */
public class CtResApiResult<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    protected int status;

    protected String message;

    protected T data;

    //ExtJs 文件上传 等 通过success属性判断是否请求成功 故而增加该属性
    protected boolean success;

    protected T children;

    public CtResApiResult(ResultCode resultCode) {
        this.status = resultCode.status();
        this.message = resultCode.message();
        this.data = (T) resultCode.data();
        this.success = resultCode.success();
        this.children = (T) resultCode.children();
    }

    public CtResApiResult() {
        this.status = CtConstant.RESP_STATUS_SUCCESS;
        this.message = "success";
        this.success = true;
    }

    public CtResApiResult(int status, String message, boolean success) {
        this.status = status;
        this.message = message;
        this.success = success;
    }

    public CtResApiResult(int status, String message, T data, boolean success) {
        this.status = status;
        this.message = message;
        this.data = data;
        this.success = success;
    }

    public CtResApiResult(int status, String message, T data, boolean success, T children) {
        this.status = status;
        this.message = message;
        this.data = data;
        this.success = success;
        this.children = children;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public T getChildren() {
        return children;
    }

    public void setChildren(T children) {
        this.children = children;
    }

    public static <T> CtResApiResult success() {
        return new CtResApiResult();
    }

    public static <T> CtResApiResult success(T data) {
        return new CtResApiResult(CtConstant.RESP_STATUS_SUCCESS, "success", data, true);
    }

    public static <T> CtResApiResult success(String message, T data) {
        return new CtResApiResult(CtConstant.RESP_STATUS_SUCCESS, message, data, true);
    }

    public static <T> CtResApiResult fail() {
        return new CtResApiResult(CtConstant.RESP_STATUS_SYS_ERROR, "系统异常，请联系管理员", null, false);
    }

    public static <T> CtResApiResult fail(String message) {
        return new CtResApiResult(CtConstant.RESP_STATUS_SYS_ERROR, message, null, false);
    }

    public static <T> CtResApiResult fail(T data) {
        return new CtResApiResult(CtConstant.RESP_STATUS_SYS_ERROR, "系统异常，请联系管理员", data, false);
    }

    public static <T> CtResApiResult fail(String message, T data) {
        return new CtResApiResult(CtConstant.RESP_STATUS_SYS_ERROR, message, data, false);
    }

    public static <T> CtResApiResult fail(int status, String message, T data) {
        return new CtResApiResult(status, message, data, false);
    }

    public static <T> CtResApiResult children(T children) {
        return new CtResApiResult(CtConstant.RESP_STATUS_SUCCESS, "success", null, true, children);
    }

    public static <T> CtResApiResult successTree(T children) {
        return new CtResApiResult(CtConstant.RESP_STATUS_SUCCESS, "success", null, true, children);
    }
}

