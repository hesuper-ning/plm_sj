package ext.plm.common.resultCode;

import java.io.Serializable;

public interface ResultCode extends Serializable {
    //状态码
    int status();
    //信息
    String message();
    //数据
    Object data();
    //是否成功
    boolean success();
    //数据
    Object children();
}
