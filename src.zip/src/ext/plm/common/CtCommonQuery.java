package ext.plm.common;

import org.apache.log4j.Logger;
import wt.method.MethodContext;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CtCommonQuery {

    static Logger logger = Logger.getLogger(CtCommonQuery.class);

    /**
     * 查询用户下拉值集
     * @return
     * @throws Exception
     */
    public List<Map<String, String>> queryUserList(String userName) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT name,loginName,departmentName FROM ZHrPerson where name like ?");
            logger.debug(">>>queryPcnNumber sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, "%" + userName + "%");
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                String name = rs.getString(1);
                String loginName = rs.getString(2);
                String departmentName = rs.getString(3);
                Map<String, String> map = new HashMap<>();
                map.put("name", loginName);
                map.put("fullName", name + "-" + departmentName);
                list.add(map);
            }
        } catch (Exception var12) {
            logger.error("查询用户下拉值集异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return list;
    }

    public List<Map<String, String>> getSupplierInfo(String query) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT concat(SUPPLIERCODE,concat('-',SUPPLIERNAME)) \"supplierName\",SUPPLIERCODE \"supplierCode\"  FROM zsupplierinfo where SUPPLIERNAME like ?");
            logger.debug(">>>queryPcnNumber sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, "%" + query + "%");
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                String supplierName = rs.getString(1);
                String supplierCode = rs.getString(2);
                Map<String, String> map = new HashMap<>();
                map.put("supplierName", supplierName);
                map.put("supplierCode", supplierCode);
                list.add(map);
            }
        } catch (Exception var12) {
            logger.error("查询供应商下拉值集异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return list;
    }


}
