package ext.plm.common;

import com.ptc.netmarkets.model.NmException;
import ext.plm.ec.CtEcLogic;
import ext.plm.keyDeliverable.CtKeyDeliverableConstant;
import ext.plm.newec.config.CtNewEcProperties;
import ext.plm.util.CtFileUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;
import wt.change2.WTChangeRequest2;
import wt.content.*;
import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.pom.WTConnection;
import wt.projmgmt.execution.ProjectWorkItem;
import wt.projmgmt.resource.ProjResourceHelper;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.workflow.definer.UserEventVector;
import wt.workflow.definer.WfProcessTemplate;
import wt.workflow.engine.*;
import wt.workflow.work.StandardWorkflowService;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;
import wt.workflow.work.WorkflowHelper;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author: lzp
 * @Date: 2024/4/12
 * @Description:
 */
public class CtCommonLogic {
    private static final Logger logger = LogR.getLogger(CtCommonLogic.class.getName());

    // 添加文件到 ZIP 输出流中的辅助方法
    public static void addFileToZip(String fileName, InputStream inputStream, ZipOutputStream zipOutputStream)
            throws Exception {
        // 创建 ZIP 实体，并设置文件名
        ZipEntry zipEntry = new ZipEntry(fileName);
        zipOutputStream.putNextEntry(zipEntry);

        // 将输入流复制到 ZIP 输出流中
        byte[] buffer = new byte[1024];
        int len;
        while ((len = inputStream.read(buffer)) > 0) {
            zipOutputStream.write(buffer, 0, len);
        }

        // 关闭 ZIP 实体
        zipOutputStream.closeEntry();

        // 关闭输入流
        inputStream.close();
    }

    //传入“String”类型的数据，通过分隔符“splitInfo”获取list集合
    public static List<String> getListStringBySplit(String info, String splitInfo){
        List<String> listString = new ArrayList<>();
        if(CtFormatUtil.hasContent(info)&&CtFormatUtil.hasContent(splitInfo)) {
            listString = Arrays.stream(info.split(splitInfo)).collect(Collectors.toList());
        }
        return listString;
    }

    //通过流程获取分配前的工作负责人（最新一次分配前的工作负责人）
    public static String getFormerWorkLeader(WorkItem workItem) throws Exception {
        WfAssignedActivity wfAssignedActivity = (WfAssignedActivity) workItem.getSource().getObject();
        long key = wfAssignedActivity.getKey();
        StringBuilder sql = new StringBuilder();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        sql.append(" SELECT wu.name FROM WfAssignmentEventAudit wae, WTUser wu ")
                .append(" WHERE wae.ActivityKey = ? ")
                .append(" and wae.ida3b6 = wu.ida2a2 ")
                .append(" ORDER BY wae.createstampa2 DESC ");
        statement = connection.prepareStatement(sql.toString());
        statement.setLong(1, key);
        ResultSet rs = statement.executeQuery();
        while (rs.next()) {
            return rs.getString(1);
        }
        return null;
    }

    //上传文件
    public static void uploadFiles(String oid,String type,String uploadTableName,String fileColumnName,String fileColumnId,HttpServletRequest request) throws Exception {
        WTProperties wtproperty = WTProperties.getLocalProperties();
        String filePath = wtproperty.getProperty("wt.home") + File.separator + "CtFile" + File.separator + "uploadFiles" + File.separator + oid + File.separator + fileColumnName + File.separator;// 临时路经
        String fileName = "";
        List<String> fileNameList = getFileNameAndUpload(filePath, request);//实现上传文件至服务器
        for (int i = 0; i < fileNameList.size(); i++) {
            fileName = fileNameList.get(i);
            File file = new File(filePath + File.separator + fileName);//获取服务器文件
            String fileNameApp =getFileName(oid, type, file);
            String fileNameInTable = fileNameInTable(fileColumnName, uploadTableName, fileColumnId);
            if (CtFormatUtil.hasContent(fileNameInTable)) {
                fileNameApp = fileNameInTable + ";;;qqq" + fileNameApp;
            }
            updateFileNameInTable(uploadTableName, fileColumnId, fileColumnName, fileNameApp);
        }
    }

    //删除上传的文件
    public static void deleteFile(String oid, String type, String fileName, String uploadTableName, String fileColumnName, String fileColumnId) throws Exception {
        //删除附件
        getOrDeleteApplicationData(oid,type,fileName,"delete");
        String fileNamesInTable = fileNameInTable(fileColumnName, uploadTableName, fileColumnId);;
        if (CtFormatUtil.hasContent(fileNamesInTable)) {
            String[] array = fileNamesInTable.split(";;;qqq");
            //转换为集合
            List<String> list = new ArrayList<>(Arrays.asList(array));
            //去除集合中指定字符串，重新拼接
            String fileNameFinal = list.stream()
                    .filter(s -> !s.equals(fileName))  // 过滤掉指定的字符串
                    .collect(Collectors.joining(";;;qqq"));
            updateFileNameInTable(uploadTableName, fileColumnId, fileColumnName, fileNameFinal);
        }
    }

    //下载单个文件
    public static InputStream downLoadFile(String oid,String type,String fileName) throws Exception {
        System.out.println("下载单个文件==>>>>"+oid+type+fileName);
        ApplicationData appData = getOrDeleteApplicationData(oid,type,fileName,"downLoad");
        if(CtFormatUtil.hasContent(appData)){
            InputStream in = ContentServerHelper.service.findContentStream(appData);
            return in;
        }
        return null;
    }

    //下载所有文件
    public static ByteArrayOutputStream downLoadAllDoc(String oid,String type,List<String> fileNames) throws Exception {
        // 创建一个字节数组输出流，用于存放打包后的 ZIP 数据
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            // 将压缩包中的文件逐个添加到 ZIP 输出流中
            for (String name : fileNames) {
                // 获取文件输入流
                InputStream in = downLoadFile(oid, type,name);
                if(CtFormatUtil.hasContent(in)){
                    // 添加文件到 ZIP 输出流中
                    CtCommonLogic.addFileToZip(name, in, zos);
                    if (in != null) {
                        in.close();
                    }
                }else {
                    throw new WTException("文件名：" + name + "在附件中已经不存在，请联系管理员处理！");
                }
            }
            // 关闭 ZIP 输出流
            zos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return baos;
    }

    //方法
    //将上传的文件保存到表单主对象的附件上,并且获取附件名称
    public static String getFileName(String oid,String type,File file) throws Exception {
        String fileNameApp = "";
        ApplicationData appData = null;
        if("doc".equals(type)){
            WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid("VR:wt.doc.WTDocument:"+oid);
            appData = ApplicationData.newApplicationData(doc);
            ApplicationData.newApplicationData(doc);
            appData = ContentServerHelper.service.updateContent(doc, appData, file.getAbsolutePath());
        }
        if("part".equals(type)){

        }
        if("ChangeRequest".equals(type)){
            WTChangeRequest2 changeObject = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(oid);
            appData = ApplicationData.newApplicationData(changeObject);
            ApplicationData.newApplicationData(changeObject);
            appData = ContentServerHelper.service.updateContent(changeObject, appData, file.getAbsolutePath());
        }
        appData.setRole(ContentRoleType.SECONDARY);// 附件位置
        appData = (ApplicationData) PersistenceHelper.manager.save(appData);
        String fileNameAppOld = appData.getFileName();
        fileNameApp = CtEcLogic.urlStr2Ascii(fileNameAppOld); // 特殊字符处理
        return fileNameApp;
    }

    //获取表格中已经上传的文件名
    public static String fileNameInTable(String fileColumnName,String tableName,String id) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet rs = null;
        String fileName = "";
        String sql = "SELECT " + fileColumnName + " FROM  " + tableName + " WHERE id = ?";
        statement = connection.prepareStatement(sql);
        statement.setString(1, id);
        rs = statement.executeQuery();
        while (rs.next()) {
            fileName = rs.getString(1);
        }
        return fileName;
    }

    //修改数据库保存的文件名称
    public static void updateFileNameInTable(String uploadTableName, String fileColumnId, String fileColumnName, String value) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            String sql = "update " + uploadTableName + " set  " + fileColumnName + "  = ? WHERE id = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, value);
            statement.setString(2, fileColumnId);
            statement.execute();
        } catch (Exception var12) {
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
    }

    //上传文件到临时文件夹
    public static List<String> getFileNameAndUpload(String temppath, HttpServletRequest request) throws Exception {
        List<String> fileNameList = new ArrayList<>();
        String fileName = "";
        File fpath = new File(temppath);
        if (!fpath.exists()) {
            InetAddress inetAddress = InetAddress.getLocalHost();
            String host = inetAddress.getHostName(); // 获取本地的主机名
            if (!host.contains("tan") && !host.contains("plmlocal")) {
                Runtime.getRuntime().exec("chmod 777 -R " + temppath);
            }
            fpath.getParentFile().mkdirs();//创建父级文件路径
            fpath.mkdirs();//创建文件
        }
        //定时一个月清理文件
        long delete = 720 * 3600 * 1000;
        CtFileUtil.deleteFileByTime(fpath, delete);

        File file = null;
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        List<FileItem> items = upload.parseRequest(request);
        Iterator<FileItem> it = items.iterator();

        while (it.hasNext()) {
            FileItem item = (FileItem) it.next();
            fileName = item.getName();
            File tFile = new File(fileName); // 借助此File获得不带本地路径的文件名
            fileName = tFile.getName();
            tFile = null; // 释放
            file = new File(temppath + fileName);
            file.createNewFile();//创建新的文件至服务器目录
            item.write(file);//把文件写入file
            System.out.println(file.createNewFile());
            fileNameList.add(fileName);
        }
        return fileNameList;
    }

    //下载或者删除文件
    public static ApplicationData getOrDeleteApplicationData(String oid,String type,String fileName,String operate) throws Exception {
        System.out.println("下载或者删除文件==>>>>"+oid+type+fileName+operate);
        QueryResult qr = null;
        if("doc".equals(type)){
            WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid("VR:wt.doc.WTDocument:"+oid);
            qr = ContentHelper.service.getContentsByRole(doc, ContentRoleType.SECONDARY);
        }
        if("part".equals(type)){

        }
        if("ChangeRequest".equals(type)){
            WTChangeRequest2 changeObject = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(oid);
            qr = ContentHelper.service.getContentsByRole(changeObject, ContentRoleType.SECONDARY);
        }
        while (qr != null && qr.hasMoreElements()) {
            ContentItem item = (ContentItem) qr.nextElement();
            if (item instanceof ApplicationData) {
                ApplicationData appData = (ApplicationData) item;
                String appDataFileName = appData.getFileName();
                System.out.println("appDataFileName=====>>>"+appDataFileName);
                if (CtFormatUtil.hasContent(appDataFileName) && appDataFileName.equals(fileName)) {
                    if(operate.equals("delete")){
                        appData = (ApplicationData) PersistenceHelper.manager.delete(appData);
                    }else {
                        return appData;
                    }
                }
            }
        }
        return null;
    }

    //委派任务给其他人时修改表格人员 委派人-delegatePersonnel 被委派人-appointedPersonnel
    public static void taskDelegation(WorkItem workItem,WTUser delegatePersonnel,WTUser appointedPersonnel) throws Exception {
        Persistable object2 = workItem.getPrimaryBusinessObject().getObject();
        WfActivity activity = (WfActivity) workItem.getSource().getObject();
        String activityName = activity.getName();
        String currentActKey = CtNewEcProperties.getActivityKey(activityName);

        if(object2 instanceof WTDocument) {
            WTDocument doc = (WTDocument) object2;
            String docType = CtWTObjectUtil.getLeafTypeIdentifier(doc);
            String branchId = doc.getBranchIdentifier()+"";
            String docNumber = doc.getNumber();

            //委派人名称
            //String userName = getFormerWorkLeader(workItem);

            //委派人名称
            WTPrincipal currentUser = CtUserUtil.getCurrentUser();
            String userName = currentUser.getName();
            //WTUser user = CtUserUtil.getUserByAccountName(userName);
            String userFullName = delegatePersonnel.getFullName();

            //被委派人名称
            String delegateUserName = workItem.getOwnership().getOwner().getName();
            //String delegateUserFullName = workItem.getOwnership().getOwner().getFullName();
            String delegateUserFullName = appointedPersonnel.getFullName();

            //需求跟踪矩阵
            if("com.fhsj.Doc_cpxqgzjzb".equals(docType)){
                //三江电子-产品需求跟踪矩阵流程-确认需求实现
                if("三江电子-产品需求跟踪矩阵流程-确认需求实现".equals(activityName)){
                    //研发责任人
                    updateTableUserName("ZRequire","rdPersonLiable",userFullName,delegateUserFullName,"docBranchId",branchId);
                }
                if("三江电子-产品需求跟踪矩阵流程-测试验证确认".equals(activityName)){
                    //验收责任人
                    updateTableUserName("ZRequire","caPersonLiable",userFullName,delegateUserFullName,"docBranchId",branchId);
                }
            }
            //TR评审
            if("com.fhsj.Doc_TRpsbgmb".equals(docType)){
                if("TR评审流程-要素表自检".equals(activityName)){
                    //TR评审表 责任人
                    updateTableUserName("ZTrReview","principal",userFullName,delegateUserFullName,"docBranchId",branchId);
                    //项目度量表 度量责任人
                    updateTableUserName("ZQUALITYMETRIC","principal",userFullName,delegateUserFullName,"docBranchId",branchId);
                    //质量标准表 度量责任人
                    updateTableUserName("ZQUALITYSTANDARD","principal",userFullName,delegateUserFullName,"docBranchId",branchId);
                }
            }

            if (CtKeyDeliverableConstant.jgType(docType) && "关键交付件评审流程-创建问题".equals(activityName)) {
                System.out.println("jgTttt----------->" + userName + "<--->" + delegateUserName + "<--->" + branchId);
                updateTableUserName("ZKEYDELIVERABLEAPPROVALTABLE", "REVIEWER", userName, delegateUserName, "docBranchId", branchId);
            }
        }
    }

    //修改表单人员
    public static void updateTableUserName(String tableName,String key,String beforeName,String afterName,String branchKey,String branchId) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        //String sqlS01 = "UPDATE "+ tableName +" set " + key + " = " + afterName + " WHERE " + branchKey + " = " + branchId + " and " + key + "=" + beforeName;
        String sqlS01 = "UPDATE "+ tableName +" set " + key + " = ?"  + " WHERE " + branchKey + " = ?" + " and " + key + "=?";

        statement = connection.prepareStatement(sqlS01);
        statement.setString(1, afterName);
        statement.setString(2, branchId);
        statement.setString(3, beforeName);
        statement.execute();
        if (statement != null) {
            statement.close();
        }
        connection.getConnection().commit();
        if (connection != null && connection.isActive()) {
            connection.release();
        }
    }

    //将任务委派给wcadmin
    public static void delegateTasks(String oid) throws Exception {
        oid = "OR:wt.workflow.work.WorkItem:" + oid;
        WorkItem workItem = (WorkItem) CtWTObjectUtil.getObjectByOid(oid);
        MethodContext var2 = null;
        try {
            var2 = MethodContext.getContext();
            if (var2 != null) {
                var2.put("bypassforreassign", true);
            }
            WorkItem var17 = workItem;
            Object var8 = CtUserUtil.getUserByDisplayName("wcadmin");
            if (var17 instanceof ProjectWorkItem) {
                ProjResourceHelper.service.delegate((ProjectWorkItem)var17, (WTPrincipal)var8);
            } else {
                StandardWorkflowService var10 = StandardWorkflowService.newStandardWorkflowService();
                try {
                    var17.setReassigned(true);
                    var17.setActionPerformed("Reassigned");
                } catch (WTPropertyVetoException var15) {

                    throw new NmException(var15);
                }
                var10.delegate(var17, (WTPrincipal)var8, "");
            }
        } finally {
            var2 = MethodContext.getContext();
            if (var2.get("bypassforreassign") != null) {
                var2.remove("bypassforreassign");
            }
        }
    }

    //自动完成任务
    public static void automaticallyCompleteTasks(String oid) throws Exception {
        oid = "OR:wt.workflow.work.WorkItem:" + oid;
        WorkItem workItem = (WorkItem) CtWTObjectUtil.getObjectByOid(oid);
        List<String> routerResult = new ArrayList<>();
        String remark = "通过";
        routerResult.add(remark);
        WTPrincipal currentUser = CtUserUtil.getCurrentUser();
        try {
            WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
            WfProcess process = activity.getParentProcess();

            Vector<Object> vector = new Vector<Object>();
            if (CtFormatUtil.hasContent(routerResult)) {
                for (String router : routerResult) {
                    vector.add(router);
                }
            }

            UserEventVector routerEvent = activity.getUserEventList();
            Vector toVector = routerEvent.toVector();
            if (CtFormatUtil.hasContent(toVector) && !CtFormatUtil.hasContent(vector)) {
                throw new Exception("请先选择路由！");
            }

            ProcessData itemData = workItem.getContext();
            ProcessData activityData = activity.getContext();

            WTPrincipalReference wtpRef = SessionHelper.manager.getPrincipalReference();
            WfVotingEventAudit audit = WfVotingEventAudit.newWfVotingEventAudit(activity.getContainerReference());
            audit.setWorkItem(workItem);
            audit.setWorkItemReference(ObjectReference.newObjectReference(workItem));
            audit.setActivityKey(activity.getKey());
            audit.setActivityName(activity.getName());
            audit.setRole(workItem.getRole());
            audit.setProcessKey(process.getKey());
            audit.setProcessName(process.getName());
            audit.setDomainRef(process.getContainer().getSystemDomainReference());
            audit.setTimestamp(new Timestamp(System.currentTimeMillis()));
            audit.setTripCount(activity.getTripCount());
            WfProcessTemplate processTemplate = (WfProcessTemplate) process.getTemplate().getObject();

            audit.setProcessTemplateName(processTemplate.getName());
            audit.setProcessTemplateVersion(processTemplate.getIterationIdentifier().getValue());

            if (StringUtils.isNotBlank(remark)) {
                //audit.setUserComment(remark);
                String userName = getFormerWorkLeader(workItem);
                if(userName==null){
                    userName="(未在数据库中找到该任务的转办人)";
                }else{
                    WTUser userByAccountName = CtUserUtil.getUserByAccountName(userName);
                    if(userByAccountName == null){
                        userName=userName+"(该用户已被删除)";
                    }else{
                        userName = userByAccountName.getFullName();
                    }
                }
                audit.setUserComment("A01 – 三日内工作负责人" + userName + "未审批，系统自动完成审批");


            }

            audit.setAssigneeRef(wtpRef);
            UserEventVector eventVector = new UserEventVector(vector);
            audit.setEventList(eventVector);
            audit.setUserRef(wtpRef);

            audit.setRole(workItem.getRole());
            audit.setProcessTemplateVersion(VersionControlHelper.getIterationIdentifier(processTemplate).getValue());
            if (StringUtils.isNotBlank(remark)) {
                if (itemData == null) {
                    itemData = activityData.copy();
                }
                //itemData.setTaskComments(remark);
                String userName = getFormerWorkLeader(workItem);
                if(userName==null){
                    userName="(未在数据库中找到该任务的转办人)";
                }else{
                    WTUser userByAccountName = CtUserUtil.getUserByAccountName(userName);
                    if(userByAccountName == null){
                        userName=userName+"(该用户已被删除)";
                    }else {
                        userName = userByAccountName.getFullName();
                    }
                }
                itemData.setTaskComments("A01 – 三日内工作负责人" + userName + "未审批，系统自动完成审批");
            }
            workItem.setContext(itemData);
            workItem = (WorkItem) PersistenceHelper.manager.save(workItem);

            SessionHelper.manager.setAdministrator();
            PersistenceHelper.manager.save(audit);
            PersistenceHelper.manager.refresh(audit);
            WorkflowHelper.service.workComplete(workItem, wtpRef, vector);
        } catch (Exception e) {
            e.printStackTrace();
            String message = e.getMessage();
            if (StringUtils.isNotEmpty(message)) {
                String subFlag = "嵌套异常是: wt.util.WTException: ";
                int lastIndexOf = message.lastIndexOf(subFlag);
                if (lastIndexOf != -1) {
                    message = message.substring(lastIndexOf + subFlag.length());
                }
                if (message.contains("wt.util.WTException: ")) {
                    message = message.replace("wt.util.WTException: ", "");
                }
                message = message.trim();
                if (message.contains("wt.workflow.work.workResource/34")) {
                    message = "该任务不再有效，因为它已完成！";
                }
            }
            throw new Exception(message);
        } finally {
            SessionHelper.manager.setPrincipal(currentUser.getName());
        }
    }

    //自动完成任务
    public static void automaticallyCompleteTasks(WorkItem workItem,String context) throws Exception {

        List<String> routerResult = new ArrayList<>();
        String remark = "通过";
        routerResult.add(remark);
        WTPrincipal currentUser = CtUserUtil.getCurrentUser();
        try {
            WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
            WfProcess process = activity.getParentProcess();

            Vector<Object> vector = new Vector<Object>();
            if (CtFormatUtil.hasContent(routerResult)) {
                for (String router : routerResult) {
                    vector.add(router);
                }
            }

            UserEventVector routerEvent = activity.getUserEventList();
            Vector toVector = routerEvent.toVector();
            if (CtFormatUtil.hasContent(toVector) && !CtFormatUtil.hasContent(vector)) {
                throw new Exception("请先选择路由！");
            }

            ProcessData itemData = workItem.getContext();
            ProcessData activityData = activity.getContext();

            WTPrincipalReference wtpRef = SessionHelper.manager.getPrincipalReference();
            WfVotingEventAudit audit = WfVotingEventAudit.newWfVotingEventAudit(activity.getContainerReference());
            audit.setWorkItem(workItem);
            audit.setWorkItemReference(ObjectReference.newObjectReference(workItem));
            audit.setActivityKey(activity.getKey());
            audit.setActivityName(activity.getName());
            audit.setRole(workItem.getRole());
            audit.setProcessKey(process.getKey());
            audit.setProcessName(process.getName());
            audit.setDomainRef(process.getContainer().getSystemDomainReference());
            audit.setTimestamp(new Timestamp(System.currentTimeMillis()));
            audit.setTripCount(activity.getTripCount());
            WfProcessTemplate processTemplate = (WfProcessTemplate) process.getTemplate().getObject();

            audit.setProcessTemplateName(processTemplate.getName());
            audit.setProcessTemplateVersion(processTemplate.getIterationIdentifier().getValue());

            if (StringUtils.isNotBlank(remark)) {
                audit.setUserComment(context);
            }

            audit.setAssigneeRef(wtpRef);
            UserEventVector eventVector = new UserEventVector(vector);
            audit.setEventList(eventVector);
            audit.setUserRef(wtpRef);

            audit.setRole(workItem.getRole());
            audit.setProcessTemplateVersion(VersionControlHelper.getIterationIdentifier(processTemplate).getValue());
            if (StringUtils.isNotBlank(remark)) {
                if (itemData == null) {
                    itemData = activityData.copy();
                }
                itemData.setTaskComments(context);
            }
            workItem.setContext(itemData);
            workItem = (WorkItem) PersistenceHelper.manager.save(workItem);

            SessionHelper.manager.setAdministrator();
            PersistenceHelper.manager.save(audit);
            PersistenceHelper.manager.refresh(audit);
            WorkflowHelper.service.workComplete(workItem, wtpRef, vector);
        } catch (Exception e) {
            e.printStackTrace();
            String message = e.getMessage();
            if (StringUtils.isNotEmpty(message)) {
                String subFlag = "嵌套异常是: wt.util.WTException: ";
                int lastIndexOf = message.lastIndexOf(subFlag);
                if (lastIndexOf != -1) {
                    message = message.substring(lastIndexOf + subFlag.length());
                }
                if (message.contains("wt.util.WTException: ")) {
                    message = message.replace("wt.util.WTException: ", "");
                }
                message = message.trim();
                if (message.contains("wt.workflow.work.workResource/34")) {
                    message = "该任务不再有效，因为它已完成！";
                }
            }
            throw new Exception(message);
        } finally {
            SessionHelper.manager.setPrincipal(currentUser.getName());
        }
    }
}
