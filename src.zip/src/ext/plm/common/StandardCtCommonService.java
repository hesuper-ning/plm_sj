package ext.plm.common;

import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.services.StandardManager;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class StandardCtCommonService extends StandardManager implements CtCommonService {

    public static StandardCtCommonService newStandardCtCommonService() throws WTException {
        StandardCtCommonService instance = new StandardCtCommonService();
        instance.initialize();
        return instance;
    }

    @Override
    public List<HashMap<String, String>> getAllUserNames() throws Exception {
        List<HashMap<String, String>> resultList = new ArrayList<HashMap<String, String>>();

        List<String> userNames = CtUserUtil.getAllUserNames();

        HashMap<String,String> tmpMap = null;
        for(String userName:userNames){
            tmpMap = new HashMap<String,String>();
            tmpMap.put("userFullName",userName);
            resultList.add(tmpMap);
        }

        return resultList;
    }

    @Override
    public List<HashMap<String, String>> getCtContainerUserNames(String containerOid) throws Exception {
        List<HashMap<String, String>> resultList = new ArrayList<HashMap<String, String>>();

        ContainerTeamManaged containerTeamManaged = (ContainerTeamManaged) CtWTObjectUtil.getObjectByOid(containerOid);
        ContainerTeam team = ContainerTeamHelper.service.getContainerTeam(containerTeamManaged);

        HashMap<String,String> tmpMap = null;
        HashMap membersMap = team.getAllMembers();
        for(Object key:membersMap.keySet()) {
            WTPrincipalReference wpr = (WTPrincipalReference) key;
            if (wpr.getObject() instanceof WTUser) {
                WTUser user = (WTUser) wpr.getObject();
                tmpMap = new HashMap<String,String>();
                tmpMap.put("userFullName",user.getFullName());
                resultList.add(tmpMap);
            }
        }

        return resultList;
    }
}
