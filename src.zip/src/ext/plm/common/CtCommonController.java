package ext.plm.common;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.integration.sap.CtSapInterface;
import ext.plm.integration.sap.bo.CtPartSupplierBo;
import ext.plm.util.CtFormatUtil;
import org.apache.tools.zip.ZipOutputStream;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import wt.content.ApplicationData;
import wt.content.ContentServerHelper;
import wt.org.WTPrincipal;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTProperties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@ResponseBody
public class CtCommonController {

    private static CtCommonService service = ServiceFactory.getService(CtCommonService.class);

    //获取Windchill 所有用户，过滤掉带“离职”字眼的用户
    @RequestMapping(value = "/common/getAllUserNames",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getAllUserNames(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String objectKey = request.getParameter("objectKey");
            List<HashMap<String,String>> itemList = service.getAllUserNames();
            List<HashMap<String,String>> deleteList = new ArrayList<>();
            for (HashMap<String, String> map : itemList) {
                // 获得用户名
                String userName = map.get("userFullName");
                if(userName.contains("离职")){
                    deleteList.add(map);
                }
            }
            // 将离职的用户删除
            List<Map<String,String>> linkedList = new LinkedList<Map<String, String>>(itemList);
            linkedList.removeAll(deleteList);
            String jsonArrStr = JSON.toJSONString(itemList);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("items", linkedList);
            result.put("success", true);
            result.put("msg", "查询成功！");
        }catch (WTException wte){
            wte.printStackTrace();
            result.put("success", false);
            result.put("error", wte.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("error", "查询信息失败！异常信息："+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }


    //获取容器团队里的所有用户
    @RequestMapping(value = "/common/getCtContainerUserNames",  method = { RequestMethod.GET,RequestMethod.POST,
            RequestMethod.PUT })
    public static void getCtContainerUserNames(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String containerOid = request.getParameter("containerOid");
            List<HashMap<String,String>> itemList = service.getCtContainerUserNames(containerOid);
            String jsonArrStr = JSON.toJSONString(itemList);
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("items", itemArr);
            result.put("success", true);
            result.put("msg", "查询成功！");
        }catch (WTException wte){
            wte.printStackTrace();
            result.put("success", false);
            result.put("error", wte.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("error", "查询信息失败！异常信息："+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    //获取角色下的成员
    @RequestMapping(value = "/common/queryPersonList", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult personLiableList (@RequestParam("query") String query) {
        try{
            CtCommonQuery ctCommonQuery = new CtCommonQuery();
            List<Map<String, String>> userList = ctCommonQuery.queryUserList(query);
            return CtResApiResult.success(userList);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 查询供应商
     * @return
     */
    @RequestMapping(value = "/common/supplierNameList", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult supplierNameList(@RequestParam("query") String query) throws Exception {
        try{
            CtCommonQuery ctCommonQuery = new CtCommonQuery();
            List<Map<String, String>> itemInfo = ctCommonQuery.getSupplierInfo(query);
            return CtResApiResult.success(itemInfo);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 查询供应商
     * @return
     */
    @RequestMapping(value = "/common/supplierNameListByPartNumber", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult supplierNameListByPartNumber(@RequestParam("partNumber") String partNumber) throws Exception {
        CtSapInterface sap = new CtSapInterface();
        List<Map<String, String>> list = new ArrayList<>();
        List<CtPartSupplierBo> supplierBoList = sap.querySupplierInfoByPartNumber(partNumber);
        if (CtFormatUtil.hasContent(supplierBoList)) {
            String supplierName = "";
            String supplierAccountNumber = "";
            CtPartSupplierBo supplierBo = null;
            Set<String> supplierNameSet = new HashSet<>();
            for (int j = 0; j < supplierBoList.size(); j++) {
                supplierBo = supplierBoList.get(j);
                supplierName = supplierBo.getSupplierName();
                supplierAccountNumber = supplierBo.getSupplierAccountNumber();
                if(!supplierNameSet.contains(supplierName)) {

                    Map<String, String> map = new HashMap<>();
                    map.put("supplierName", supplierAccountNumber+"-"+supplierName);
                    //map.put("supplierCode", supplierAccountNumber);
                    list.add(map);
                    supplierNameSet.add(supplierName);
                }
            }
        }
        return CtResApiResult.success(list);
    }

    /**
     * 上传文件到文档附件
     */
    @RequestMapping(value = "/common/uploadFiles", method = RequestMethod.POST)
    public static void uploadFiles(HttpServletRequest request, HttpServletResponse response) throws Exception {
        cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        try {
            String branchId = request.getParameter("branchId");
            String type = request.getParameter("type");
            String uploadTableName = request.getParameter("uploadTableName");
            String fileColumnName = request.getParameter("fileColumnName");
            String fileColumnId = request.getParameter("fileColumnId");

            CtCommonLogic.uploadFiles(branchId,type,uploadTableName,fileColumnName,fileColumnId,request);

            result.put("success", true);
            result.put("msg", "上传成功");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            result.put("success", false);
            result.put("msg", "上传附件异常信息：\r\n" + error);
        }finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 下载附件
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/common/downLoadDoc", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public static void downLoadDoc(HttpServletRequest request, HttpServletResponse response) throws Exception {
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
        String branchId = request.getParameter("branchId");
        String type = request.getParameter("type");
        String fileName = request.getParameter("fileName");
        String downLoadfileName = request.getParameter("fileName");
        OutputStream out = null;
        InputStream in = null;
        try {
            if(CtFormatUtil.hasContent(branchId) && CtFormatUtil.hasContent(fileName)) {
                String userAgent = request.getHeader("User-Agent");
                response.setContentType("application/octet-stream");
                if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                    //ie
                    fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                    //edge
                    fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
                }else {
                    // //firefox、chrome、safari、opera：
                    fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
                }
                //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
                response.setCharacterEncoding("UTF-8");
                response.setContentType("application/octet-stream");
                response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
                response.setCharacterEncoding("UTF-8");

                //获取文件输入流
                in = CtCommonLogic.downLoadFile(branchId,type,downLoadfileName);
                if(CtFormatUtil.hasContent(in)){
                    int len = 0;
                    byte[] buffer = new byte[10240];
                    out = response.getOutputStream();
                    while ((len = in.read(buffer)) > 0) {
                        //将缓冲区的数据输出到客户端浏览器
                        out.write(buffer,0,len);
                    }
                    result.put("success", true);
                    result.put("msg", "下载成功！");
                }else {
                    result.put("success", false);
                    result.put("msg", "文档中没找到需要下载的附件!");// 文档中没找到需要下载的附件！
                }

            }else {
                result.put("success", false);
                result.put("msg", "必传参数不能为空!");// 必传参数不能为空！
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "下载失败，后台异常信息：" + e.getLocalizedMessage());// 下载失败，后台异常信息：
        }finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out1 = response.getWriter();
        out1.write(result.toString());
    }


    ///**
    // * 下载附件
    // * @param request
    // * @param response
    // * @throws Exception
    // */
    //@RequestMapping(value = "/common/downLoadDoc", method = {RequestMethod.GET, RequestMethod.POST,
    //        RequestMethod.PUT})
    //public static void downLoadDoc(HttpServletRequest request, HttpServletResponse response) throws Exception {
    //    WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
    //    SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
    //    boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
    //    cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
    //    String branchId = request.getParameter("branchId");
    //    String type = request.getParameter("type");
    //    String fileName = request.getParameter("fileName");
    //    OutputStream out = null;
    //    InputStream in = null;
    //    try {
    //        if(CtFormatUtil.hasContent(branchId) && CtFormatUtil.hasContent(fileName)) {
    //            String userAgent = request.getHeader("User-Agent");
    //            response.setContentType("application/octet-stream");
    //            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
    //                //ie
    //                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
    //            } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
    //                //edge
    //                fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
    //            }else {
    //                // //firefox、chrome、safari、opera：
    //                fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
    //            }
    //            //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
    //            response.setCharacterEncoding("UTF-8");
    //            response.setContentType("application/octet-stream");
    //            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
    //            response.setCharacterEncoding("UTF-8");
    //            //获取文件输入流
    //            in = CtCommonLogic.downLoadFile(branchId,type,fileName);
    //            if(CtFormatUtil.hasContent(in)){
    //                int len = 0;
    //                byte[] buffer = new byte[10240];
    //                out = response.getOutputStream();
    //                while ((len = in.read(buffer)) > 0) {
    //                    //将缓冲区的数据输出到客户端浏览器
    //                    out.write(buffer,0,len);
    //                }
    //                result.put("success", true);
    //                result.put("msg", "下载成功！");
    //            }else {
    //                result.put("success", false);
    //                result.put("msg", "文档中没找到需要下载的附件!");// 文档中没找到需要下载的附件！
    //            }
    //        }else {
    //            result.put("success", false);
    //            result.put("msg", "必传参数不能为空!");// 必传参数不能为空！
    //        }
    //    } catch (Exception e) {
    //        e.printStackTrace();
    //        result.put("success", false);
    //        result.put("msg", "下载失败，后台异常信息：" + e.getLocalizedMessage());// 下载失败，后台异常信息：
    //    }finally {
    //        try {
    //            if (out != null) {
    //                out.close();
    //            }
    //            if (in != null) {
    //                in.close();
    //            }
    //        } catch (IOException e) {
    //            e.printStackTrace();
    //        }
    //        flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
    //        SessionHelper.manager.setPrincipal(currentPrincipal.getName());
    //    }
    //    response.setCharacterEncoding("utf-8");
    //    PrintWriter out1 = response.getWriter();
    //    out1.write(result.toString());
    //}

    /**
     * 下载所有附件
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/common/downLoadAllDoc", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public static void downLoadAllDoc(HttpServletRequest request, HttpServletResponse response) throws Exception {
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
        String branchId = request.getParameter("branchId");
        String type = request.getParameter("type");
        String fileName = request.getParameter("fileName");

        // 使用 split 方法按照分隔符 ";;;qqq" 将字符串分割成数组
        String[] arr = fileName.split(";;;qqq");

        // 将数组转换为列表
        List<String> list = Arrays.asList(arr);

        OutputStream out = null;

        try {
            if(CtFormatUtil.hasContent(branchId) && CtFormatUtil.hasContent(fileName)) {

                fileName = "全部文件压缩包"+System.currentTimeMillis()+".zip";
                String userAgent = request.getHeader("User-Agent");
                response.setContentType("application/octet-stream");
                if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                    //ie
                    fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                    //edge
                    fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
                }else {
                    // //firefox、chrome、safari、opera：
                    fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
                }
                response.setCharacterEncoding("UTF-8");
                response.setContentType("application/octet-stream");
                response.setCharacterEncoding("UTF-8");
                response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", fileName));

                // 创建一个字节数组输出流，用于存放打包后的 ZIP 数据
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                baos = CtCommonLogic.downLoadAllDoc(branchId,type,list);

                // 将打包后的 ZIP 数据写入 HttpServletResponse 输出流
                OutputStream os = response.getOutputStream();
                baos.writeTo(os);
                os.flush();
                result.put("success", true);
                result.put("msg","下载成功！");
            }else {
                result.put("success", false);
                result.put("msg", "必传参数不能为空!");// 必传参数不能为空！
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "下载异常:" + e.getLocalizedMessage());// 下载失败，后台异常信息：
        }finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out1 = response.getWriter();
        out1.write(result.toString());
    }

    /**
     * 删除附件
     */
    @RequestMapping(value = "/common/deleteFiles", method = RequestMethod.POST)
    public void deleteFiles(HttpServletRequest request, HttpServletResponse response) throws Exception {
        cn.hutool.json.JSONObject result = new cn.hutool.json.JSONObject();
        WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);// 放大权限
        try {
            String branchId = request.getParameter("branchId");
            String type = request.getParameter("type");
            String fileName = request.getParameter("fileName");
            String fileColumnId = request.getParameter("fileColumnId");
            String fileColumnName = request.getParameter("fileColumnName");
            String uploadTableName = request.getParameter("uploadTableName");

            CtCommonLogic.deleteFile(branchId,type,fileName,uploadTableName,fileColumnName,fileColumnId);

            result.put("success", true);
            result.put("msg", fileName+"删除成功！");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getLocalizedMessage();
            result.put("success", false);
            result.put("msg", "删除附件异常信息：\r\n" + error);
        }finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);// 恢复权限
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        }
        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 查询文档名称
     * @return
     */
    @GetMapping(value = "/common/searchFileName", produces = "application/json;charset=UTF-8")
    public CtResApiResult searchFileName(@RequestParam("fileColumnId") String fileColumnId, @RequestParam("fileColumnName") String fileColumnName,
                                         @RequestParam("uploadTableName") String uploadTableName) {
        List<HashMap<String,String>> fileNameList = new ArrayList<>();
        try {
            System.out.println("fileColumnId================>>>>>>>>"+fileColumnId);
            System.out.println("fileColumnName================>>>>>>>>"+fileColumnName);
            System.out.println("uploadTableName================>>>>>>>>"+uploadTableName);
            String fileNames = CtCommonLogic.fileNameInTable(fileColumnName,uploadTableName,fileColumnId);
            System.out.println("fileNames================>>>>>>>>"+fileNames);
            if(CtFormatUtil.hasContent(fileNames)) {
                String[] array = fileNames.split(";;;qqq");

                for (int i = 0; i < array.length; i++) {
                    String fileName = array[i];
                    HashMap<String, String> hm = new HashMap<>();
                    hm.put("fileName", fileName);
                    fileNameList.add(hm);
                }
                //List<String> fileNameList = new ArrayList<>(Arrays.asList(array));
                //return CtResApiResult.success(fileNameList);
            }
            return CtResApiResult.success(fileNameList);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
        }
    }

}
