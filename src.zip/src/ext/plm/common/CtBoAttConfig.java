package ext.plm.common;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * BO 属性的注释类
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface CtBoAttConfig {
    public String displayName(); //显示名称
    public boolean required() default false; // 是否必填
    public String dateFormat() default ""; // 当 JavaBean 的属性为 Date 类型时，指定 Date 的格式化模式

}

