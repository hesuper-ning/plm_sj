package ext.plm.common;

import java.io.Serializable;
import java.util.List;

/**
 * 分页 BO
 * @auther TanRuoTao
 */
public class CtPageBo<T> implements Serializable {

    private static final long serialVersionUID = 2L;

    /**
     * 总数
     */
    private Long total;

    /**
     * 每页显示数据
     */
    private List<T> resultData;

    public CtPageBo() {
    }

    public CtPageBo(Long total, List<T> resultData) {
        this.total = total;
        this.resultData = resultData;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public List<T> getResultData() {
        return resultData;
    }

    public void setResultData(List<T> resultData) {
        this.resultData = resultData;
    }
}
