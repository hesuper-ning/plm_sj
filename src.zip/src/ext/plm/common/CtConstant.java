package ext.plm.common;

import wt.util.WTException;
import wt.util.WTProperties;

import java.net.InetAddress;

public class CtConstant {

	private static String host = "";//主机名

	static{
		try {
			//根据主机名选择不同的配置
			InetAddress inetAddress = InetAddress.getLocalHost();
			host =inetAddress.getHostName(); //获取本地的主机名
			System.out.println(">>当前Host:"+host);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	//java 统一日期格式
	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	// 时间格式，只精确到天
	public static final String DATE_FORMAT_DAY = "yyyy-MM-dd";

	//设置北京时区，系统时区为GMT+0
	public static final String TIMEZONE_FORMAT = "GMT+8";
	
	//后台数据库操作的未知异常信息前缀
	public static final String DATABASE_EXCEPTION_PREFIX = "后台数据库异常，异常信息：";
	
	//"制造" 视图
	public  static final String VIEW_MANUFACTURING = "Manufacturing";

	//"设计" 视图
	public  static final String VIEW_DESIGN = "Design";


	//状态 - 已发布
	public static final String STATE_RELEASED = "RELEASED";

	//状态 - 已生效
	public static final String STATE_Inforce = "Inforce";

    //状态 - 样机
    public static final String STATE_FApprove = "FApprove";

	//状态 - 试产
	public static final String STATE_trialProduction = "trialProduction";

	//状态 - 量产
	public static final String STATE_massProduction = "massProduction";

	//状态 - 认证中
	public static final String STATE_progress = "progress";

	//状态 - 工作中
	public static final String STATE_WORKING = "WORKING";





	/**
	 * linux  下模板存放路径
	 * @return
	 * @throws Exception
	 */
	public static String getFtlPath() throws Exception {
		WTProperties wtproperty = WTProperties.getLocalProperties();
		String temppath = wtproperty.getProperty("wt.home") + "/codebase/template/ftl/";
		return temppath;
	}

	//本地主机名
	public static final String HostName_Local = "plmlocal";

	//测试机主机名
	public static final String HostName_Test = "plmtest";

	//测试机主机名
	public static final String HostName_uat = "plmuat";

	//正式机主机名
	public static final String HostName_Prd = "plmapp01";

	//是否本地开发环境
	public static boolean isLocalEnv() throws Exception{
		checkEnvValid();//确保环境配置合法
		if(host.equals(HostName_Local)){
			return true;
		}else{
			return false;
		}
	}

	//是否测试环境
	public static boolean isTestEnv() throws Exception {
		checkEnvValid();//确保环境配置合法
		if(host.equals(HostName_uat)|| host.equals(HostName_Test)||host.contains("plmdemo")){
			return true;
		}else{
			return false;
		}
	}

	//是否正式环境
	public static boolean isPrdEnv() throws Exception{
		checkEnvValid();//确保环境配置合法
		if(host.equals(HostName_Prd)||host.contains("plmapp02")||host.contains("plmapp03")){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * 检查环境合法性
	 * @throws Exception
	 */
	public static void checkEnvValid() throws Exception{
		if(host.equals(HostName_uat)|| host.equals(HostName_Local)||host.equals(HostName_Test)||host.equals(HostName_Prd)
				||host.contains("plmdemo")||host.contains("plmapp02")||host.contains("plmapp03")){
			//配置正常情况
		}else{
			//三个配置环境都不匹配，需要检查配置
			throw new WTException("无法确认当前环境，请联系管理检查主机环境配置！当前主机：" + host);
		}
	}

	//**********自定义接口状态码 start*************//
	public final static int RESP_STATUS_SUCCESS = 200;

	public final static int RESP_STATUS_NO_AUTH = 401;

	public final static int RESP_STATUS_SYS_ERROR = 500;

	public final static int RESP_STATUS_BAD_REQUEST =400;

	//**********自定义接口状态码 end*************//
}

