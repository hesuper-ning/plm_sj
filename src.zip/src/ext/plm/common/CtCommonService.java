package ext.plm.common;

import wt.method.RemoteInterface;

import java.util.HashMap;
import java.util.List;

@RemoteInterface
public interface CtCommonService {

    /**
     * 获取Windchill 所有用户，过滤掉带“离职”字眼的用户
     * @return
     * @throws Exception
     */
    List<HashMap<String,String>> getAllUserNames() throws Exception;

    /**
     * 获取容器团队里的所有用户
     * @param containerOid
     * @return
     * @throws Exception
     */
    List<HashMap<String, String>> getCtContainerUserNames(String containerOid) throws Exception;
}
