package ext.plm.keyDeliverable;
import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

import ext.plm.common.CtResApiResult;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableApprovalBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableBasicsBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableExecuteBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableReviewBo;
import ext.plm.keyDeliverable.service.CtKeyDeliverableApprovalService;
import ext.plm.keyDeliverable.service.CtKeyDeliverableExecuteService;
import ext.plm.keyDeliverable.service.CtKeyDeliverableReviewService;
import ext.plm.keyDeliverable.service.CtKeyDeliverableService;
import ext.plm.problem.CtProblemMgtLogic;
import ext.plm.problem.CtProblemMgtService;
import ext.plm.problem.bo.CtProblemMgtBo;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.workReport.CtWorkReportService;
import wt.fc.Persistable;
import wt.fc.ReferenceFactory;
import wt.org.WTUser;
import wt.session.SessionHelper;
import wt.workflow.work.WorkItem;
@RestController
@RequestMapping("/keyDeliverable")
public class CtKeyDeliverableController {
	private static Logger logger = Logger.getLogger(CtKeyDeliverableController.class);
	@Autowired
	private CtKeyDeliverableService ctKeyDeliverableService;
	@Autowired
	private CtKeyDeliverableExecuteService ctKeyDeliverableExecuteService;
	@Autowired
	private CtKeyDeliverableApprovalService ctKeyDeliverableApprovalService;
	@Autowired
	private CtKeyDeliverableReviewService ctKeyDeliverableReviewService;

	@Autowired
	private CtWorkReportService reportService;

    @Autowired
    private CtProblemMgtService mgtService;
	// 单个保存表头属性
	@RequestMapping(value = "/autoSaveAtt", method = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT })
	public void autoSaveAtt(HttpServletRequest request, HttpServletResponse response) throws Exception {
		JSONObject result = new JSONObject();

		try {
			JSONObject dataJson = JSONObject.parseObject(request.getParameter("data"));
			String dbTableName = dataJson.getString("dbTableName");
			String branchId = dataJson.getString("branchId");
			String attKey = dataJson.getString("attKey");
			String attValue = dataJson.getString("attValue");
			String oid = dataJson.getString("oid");
			this.checkEditAccess(oid);
			if ("1".equals(dbTableName)) {
				ctKeyDeliverableService.updateAttById(attKey, attValue, branchId);
			}
			// System.out.println(project.toString());
			result.put("success", true);
			result.put("msg", "保存成功！");
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "实时保存失败:" + e.getLocalizedMessage());
		}

		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.write(result.toString());
	}

	public void checkEditAccess(String oid) throws Exception {
		if (CtFormatUtil.hasContent(oid)) {
			ReferenceFactory rf = new ReferenceFactory();
			Persistable p = rf.getReference(oid).getObject();
			if (p instanceof WorkItem) {
				WorkItem workItem = (WorkItem) rf.getReference(oid).getObject();
				if (workItem != null && workItem.isComplete()) {
					throw new Exception("活动已完成，请刷新页面");
				}
			}
		}
	}

	/**
	 * 删除表单数据
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = { "/deleteTableData" }, method = { RequestMethod.GET, RequestMethod.POST,
			RequestMethod.PUT })
	public CtResApiResult deleteTableData(HttpServletRequest request) {
		try {
			JSONObject dataJson = JSONObject.parseObject(request.getParameter("deleteRecord"));
			String dbTableName = dataJson.getString("dbTableName");
			String ids = dataJson.getString("ids");
			ctKeyDeliverableService.deleteTableData("", ids);
			return CtResApiResult.success();
		} catch (Exception e) {
			logger.error("删除表单数据异常：", e);
			return CtResApiResult.fail("删除表单数据失败，后台异常信息：\r\n" + e.getLocalizedMessage());
		}
	}

	/**
	 * 查询S01：基础信息--表1
	 * 
	 * @param branchId
	 * @return
	 */
	@GetMapping(value = "/getKeyDeliverableBasis", produces = "application/json;charset=UTF-8")
	public CtResApiResult getKeyDeliverableBasis(Long branchId) {
		try {
			CtKeyDeliverableBasicsBo bo = ctKeyDeliverableService.getKeyDeliverableBasis(branchId);
			return CtResApiResult.success(ctKeyDeliverableService.getKeyDeliverableAssembleBasis(bo));
		} catch (Exception e) {
			logger.error("查询基础信息：--表1异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}
	}

	/**
	 * 查询S01：--表2
	 * 
	 * @param branchId
	 * @return
	 */
	@GetMapping(value = "/getKeyDeliverableReview", produces = "application/json;charset=UTF-8")
	public CtResApiResult getKeyDeliverableReview(Long branchId) {
		try {
			return CtResApiResult.success(ctKeyDeliverableReviewService.getKeyDeliverableReview(branchId));
		} catch (Exception e) {
			logger.error("查询基础信息：--表2异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}
	}

	/**
	 * 删除主审人预审意见及评审专家
	 * 
	 * @param ids
	 * @return
	 */
	@DeleteMapping(value = "deleteKeyDeliverableReview", produces = "application/json;charset=UTF-8")
	public CtResApiResult deleteKeyDeliverableReview(@RequestBody List<String> ids) {
		try {
			ctKeyDeliverableReviewService.deleteKeyDeliverableReview(ids);
			return CtResApiResult.success();
		} catch (Exception e) {
			logger.error("删除主审人预审意见及评审专家异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 保存主审人预审意见及评审专家
	 * 
	 * @param branchId
	 * @return
	 */
	@PostMapping(value = "/saveKeyDeliverableReview")
	public CtResApiResult saveKeyDeliverableReview(String branchId) {
		try {
			System.out.println("saveKeyDeliverableReview---------->" + branchId);
			List<CtKeyDeliverableReviewBo> entityList = new ArrayList<CtKeyDeliverableReviewBo>();
			CtKeyDeliverableReviewBo bo = new CtKeyDeliverableReviewBo(branchId);
			entityList.add(bo);
			return CtResApiResult.success(ctKeyDeliverableReviewService.saveKeyDeliverableReview(entityList));
		} catch (Exception e) {
			logger.error("保存主审人预审意见及评审专家异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 更新评审意见及改善方案纠正项
	 * 
	 * @param id
	 * @param key
	 * @param value
	 * @return
	 */
	@PostMapping(value = "/updateKeyDeliverableReview")
	public CtResApiResult updateKeyDeliverableReview(String id, String key, String value,String branchId) {
		try {
			System.out.println("updateKeyDeliverableReview---->"  + id+ "<---->"  + key+ "<---->" + value+ "<---->" + branchId);
			List<CtKeyDeliverableReviewBo> list= ctKeyDeliverableReviewService.getKeyDeliverableReview(Long.parseLong(branchId));
			if(null != list && list.size() > 0 && "reviewExperts".equals(key)){
				for(int i =0; i < list.size(); i++){
					CtKeyDeliverableReviewBo bo = list.get(i);
					if(null != bo && value.equals(bo.getReviewExperts())){
						return CtResApiResult.fail("不能重复选择专家");
					}
				}
			}
			return CtResApiResult.success(ctKeyDeliverableReviewService.updateCtKeyDeliverableReviewBo(id, key, value,branchId));
		} catch (Exception e) {
			logger.error("保存或更新试用流程基础信息异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	// 获取角色下的成员
	@RequestMapping(value = "/getPersonLiableList", method = { RequestMethod.GET, RequestMethod.POST })
	public CtResApiResult getPersonLiableList(Long branchId, String type, @RequestParam("query") String query) {
		try {

			List<Map<String, String>> userList = ctKeyDeliverableService.getPersonLiableList(branchId, type, query);
			return CtResApiResult.success(userList);
		} catch (Exception e) {
			e.printStackTrace();
			return CtResApiResult.fail(e.getMessage());
		}
	}

	/**
	 * 查询评审意见及改善方案纠正项
	 * 
	 * @param branchId
	 * @return
	 */
	@GetMapping(value = "/getKeyDeliverableErrorCollection", produces = "application/json;charset=UTF-8")
	public CtResApiResult getKeyDeliverableErrorCollection(Long branchId) {
		try {
			return CtResApiResult.success(ctKeyDeliverableApprovalService.getKeyDeliverableErrorColletion(branchId));
		} catch (Exception e) {
			logger.error("查询基础信息：--表2异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}
	}

	/**
	 * 删除评审意见及改善方案纠正项
	 * 
	 * @param ids
	 * @return
	 */
	@DeleteMapping(value = "deleteKeyDeliverableErrorCollection", produces = "application/json;charset=UTF-8")
	public CtResApiResult deleteKeyDeliverableErrorCollection(@RequestBody List<String> ids) {
		try {
			ctKeyDeliverableApprovalService.deleteKeyDeliverableErrorColletion(ids);
			return CtResApiResult.success();
		} catch (Exception e) {
			logger.error("删除评审意见及改善方案纠正项：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 保存评审意见及改善方案纠正项
	 * 
	 * @param branchId
	 * @return
	 */
	@PostMapping(value = "/saveKeyDeliverableErrorCollection")
	public CtResApiResult saveKeyDeliverableErrorCollection(String branchId) {
		try {
			List<CtKeyDeliverableApprovalBo> entityList = new ArrayList<CtKeyDeliverableApprovalBo>();
			CtKeyDeliverableApprovalBo bo = new CtKeyDeliverableApprovalBo(branchId);
			if(!CtFormatUtil.hasContent(bo.getReviewer())){
				String userName = CtUserUtil.getCurrentUserAccountName();
				bo.setReviewer(userName);
			}
			entityList.add(bo);
			return CtResApiResult.success(ctKeyDeliverableApprovalService.saveKeyDeliverableErrorColletion(entityList));
		} catch (Exception e) {
			logger.error("保存评审意见及改善方案纠正项异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 更新评审意见及改善方案纠正项
	 * 
	 * @param id
	 * @param key
	 * @param value
	 * @return
	 */
	@PostMapping(value = "/updateKeyDeliverableErrorCollection")
	public CtResApiResult updateKeyDeliverableErrorCollection(String id, String key, String value) {
		try {
			return CtResApiResult
					.success(ctKeyDeliverableApprovalService.updateCtKeyDeliverableApprovalBo(id, key, value));
		} catch (Exception e) {
			logger.error("保存或更新试用流程基础信息异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 查询交付件评审执行情况评价表
	 * 
	 * @param branchId
	 * @return
	 */
	@GetMapping(value = "/getKeyDeliverableExecute", produces = "application/json;charset=UTF-8")
	public CtResApiResult getKeyDeliverableExecute(Long branchId) {
		try {
			return CtResApiResult.success(ctKeyDeliverableExecuteService.getKeyDeliverableExecute(branchId));
		} catch (Exception e) {
			logger.error("查询：--表3异常：", e);
			return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
		}
	}

	/**
	 * 删除交付件评审执行情况评价表
	 * 
	 * @param ids
	 * @return
	 */
	@DeleteMapping(value = "deleteKeyDeliverableExecute", produces = "application/json;charset=UTF-8")
	public CtResApiResult deleteKeyDeliverableExecute(@RequestBody List<String> ids) {
		try {
			ctKeyDeliverableExecuteService.deleteKeyDeliverableExecute(ids);
			return CtResApiResult.success();
		} catch (Exception e) {
			logger.error("删除：--表3异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 保存交付件评审执行情况评价表
	 * 
	 * @param branchId
	 * @return
	 */
	@PostMapping(value = "/saveKeyDeliverableExecute")
	public CtResApiResult saveKeyDeliverableExecute(String branchId) {
		try {
			List<CtKeyDeliverableExecuteBo> entityList = new ArrayList<CtKeyDeliverableExecuteBo>();
			CtKeyDeliverableExecuteBo bo = new CtKeyDeliverableExecuteBo(branchId);
			entityList.add(bo);
			return CtResApiResult.success(ctKeyDeliverableExecuteService.saveKeyDeliverableExecute(entityList));
		} catch (Exception e) {
			logger.error("保存评审意见及改善方案纠正项异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	/**
	 * 更新交付件评审执行情况评价表
	 * 
	 * @param id
	 * @param key
	 * @param value
	 * @return
	 */
	@PostMapping(value = "/updateKeyDeliverableExecute")
	public CtResApiResult updateKeyDeliverableExecute(String id, String key, String value) {
		try {
			return CtResApiResult.success(ctKeyDeliverableExecuteService.updateKeyDeliverableExecuteBo(id, key, value));
		} catch (Exception e) {
			logger.error("保存或更新试用流程基础信息异常：", e);
			return CtResApiResult.fail(e.getLocalizedMessage());
		}
	}

	@RequestMapping(value = "/importKeyDeliverable", method = { RequestMethod.GET, RequestMethod.POST })
	public void importKeyDeliverable(HttpServletRequest request, HttpServletResponse response) throws Exception {
		JSONObject result = new JSONObject();
		try {
			String branchId = request.getParameter("branchId");
			File file = null;
			DiskFileItemFactory fac = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(fac);
			List<FileItem> fileItems = new ArrayList<FileItem>();
			fileItems = upload.parseRequest(request);
			Iterator<FileItem> it = fileItems.iterator();

			while (it.hasNext()) {
				FileItem item = (FileItem) it.next();
				String name = item.getName();
				File tFile = new File(name); // 借助此File获得不带本地路径的文件名
				file = CtProblemMgtLogic.changeFileName(tFile);
				item.write(file);
			}
			// 导入
			CtKeyDeliverableHelper.importKeydeliverable(Long.valueOf(branchId), file);
			result.put("success", true);
			result.put("msg", "导入成功");
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "导入评审意见失败，后台异常信息：\r\n" + e.getLocalizedMessage());
		}
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.write(result.toJSONString());
	}

	// 查询项目阶段列表
	@RequestMapping(value = "/getProjectPhase", method = { RequestMethod.GET, RequestMethod.POST })
	public CtResApiResult getProjectPhase(String projectNumber, @RequestParam("query") String query) {
		try {
			List<HashMap<String, String>> projects = new ArrayList<HashMap<String, String>>();
			if (CtFormatUtil.hasContent(projectNumber)) {
				projects = reportService.getProjectPhase(projectNumber);
			} else if (CtFormatUtil.hasContent(query)) {
				projects = reportService.getProjectPhase(projectNumber);
			}
			return CtResApiResult.success(projects);
		} catch (Exception e) {
			e.printStackTrace();
			return CtResApiResult.fail(e.getMessage());
		}
	}
	
	/**
     * 添加数据
     *
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/dealRelationships", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
	public void dealRelationships(HttpServletRequest request, HttpServletResponse response) throws Exception {
		JSONObject result = new JSONObject();
		WTUser curUser = null;
		try {
			curUser = (WTUser) SessionHelper.manager.getPrincipal();
	        SessionHelper.manager.setAdministrator();
			String problemNum = request.getParameter("problemNum");
			System.out.println("problemNum---->" + problemNum);
			String approvalId = request.getParameter("approvalId");
			System.out.println("approvalId---->" + approvalId);
			String branchId = request.getParameter("branchId");
			System.out.println("branchId---->" + branchId);
			CtProblemMgtBo bo = mgtService.getProblem(problemNum);
			CtKeyDeliverableApprovalBo approvalBo = CtKeyDeliverableHelper.getApprovalbyId(approvalId);
			if (CtFormatUtil.hasContent(approvalBo.getTechnologicalProcess())) {
				/*
				 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				 * Date date = new Date(); bo.setStartDate(sdf.format(date));
				 */
				// String docVr = "VR:wt.doc.WTDocument:" + branchId;
				// WTDocument doc = (WTDocument)
				// CtWTObjectUtil.getObjectByOid(docVr);
				/*
				 * bo.setDocBranchId(doc.getBranchIdentifier() + "");
				 * bo.setProcessLink(approvalBo.getTechnologicalProcess());
				 * bo.setProblemStatus("开始");
				 */
				System.out.println("ccccc---->" + bo.getId() + "<--------------->" + approvalBo.getAttachmentUrl());
				mgtService.updateProblem("" + bo.getId(), "docBranchId", approvalBo.getAttachmentUrl());
				System.out.println(
						"2ccccc---->" + bo.getId() + "<--------------->" + approvalBo.getTechnologicalProcess());
				mgtService.updateProblem("" + bo.getId(), "processLink", approvalBo.getTechnologicalProcess());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date date = new Date();
				mgtService.updateProblem("" + bo.getId(), "startDate", sdf.format(date));
				mgtService.updateProblem("" + bo.getId(), "problemStatus", "开始");

			} else {
				List<Long> ids = new ArrayList<>();
				ids.add(bo.getId());
				mgtService.createProblemSolve(ids, bo.getContainerId(), "");
				String link = mgtService.getProcessLinkByNumber(problemNum);
				bo = mgtService.getProblem(problemNum);
				CtKeyDeliverableHelper.updateTechnologicalProcessbyId(approvalId, link, bo.getDocBranchId());

			}
			result.put("success", true);
			result.put("msg", "添加成功！");
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("error", "添加失败！异常信息：" + e.getMessage());
		} finally {
			if (curUser != null) {
				try {
					SessionHelper.manager.setPrincipal(curUser.getName());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.write(result.toString());
	}
}
