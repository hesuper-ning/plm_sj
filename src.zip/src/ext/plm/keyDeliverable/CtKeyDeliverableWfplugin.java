package ext.plm.keyDeliverable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;

import ext.plm.bean.CtBeanFactory;
import ext.plm.integration.hr.CtHrLogic;
import ext.plm.integration.hr.bo.CtHrPersonBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableApprovalBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableReviewBo;
import ext.plm.keyDeliverable.config.CtKeyDeliverableProperties;
import ext.plm.keyDeliverable.mapper.CtKeyDeliverableApproValMapper;
import ext.plm.keyDeliverable.mapper.CtKeyDeliverableReviewMapper;
import ext.plm.keyDeliverable.service.CtKeyDeliverableServiceImpl;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.CtWorkFlowUtil;
import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.WTObject;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

public class CtKeyDeliverableWfplugin {

	static Logger logger = Logger.getLogger(CtKeyDeliverableWfplugin.class); // LogDemo为相关的类

	/**
	 * 应用于认证请求流程里 各个节点的”完成任务“转变条件 表单必填字段验证
	 * 
	 * @param pbo
	 * @param self
	 */
	public static void checkForm(WTObject pbo, Object self) throws WTException {
		/*
		 * //必填验证 ext.plm.keyDeliverable.CtKeyDeliverableWfplugin.checkForm(
		 * primaryBusinessObject,self);
		 */
		try {
			WTDocument document = (WTDocument) pbo;
			String branchId = document.getBranchIdentifier() + "";
			String emptyAtts = "";
			// 取activityKey
			String activityKey = getActivityKey(self);

			System.out.println("activityKey------>" + activityKey);
			// String exttra = "";
			CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
			// 取必填字段
			List<String> requiredAtts = CtKeyDeliverableProperties.getRequiredAtts(activityKey);
			if (!("keydeliver_chiefReviewerFeedback_node".equals(activityKey)
					|| "keydeliver_fillReviewComments_node".equals(activityKey)
					|| "keydeliver_replyToReviewComments_node".equals(activityKey)
					|| "keydeliver_processAuditAndProblemFollow_node".equals(activityKey)
					|| "keydeliver_competitiveReceptionAndImport_node".equals(activityKey))) {
				// 表单必填
				for (Iterator<String> ite = requiredAtts.iterator(); ite.hasNext();) {
					String attKey = ite.next();
					String attValue = query.getAttributeValue(branchId, attKey);
					// exttra = attValue;
					if (!CtFormatUtil.hasContent(attValue)) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName(attKey);
						emptyAtts += displayName + "\r\n";
					}
				}
			}
			if ("keydeliver_reviewerAndReviewFormat_node".equals(activityKey)) {
				System.out.println("branchId------------" + branchId);
				List<CtKeyDeliverableReviewBo> listReviewBo = query.getAttributeValueExtra(branchId);
				String exttra = query.getAttributeValue(branchId, "REVIEWFORMAT");
				System.out.println("exttra------------" + exttra);
				if (null == listReviewBo || listReviewBo.size() == 0) {
					System.out.println("listReviewBo------------is null");
					if ("线上".equals(exttra)) {
						emptyAtts += "必须指定评审专家" + "\r\n";
					}
				} else {
					String judgeReviewExperts = "";
					int judgeChiefExaminer = 0;
					System.out.println("size------>" + listReviewBo.size());
					Map<String, String> map = new HashMap<String, String>();
					for (int j = 0; j < listReviewBo.size(); j++) {
						CtKeyDeliverableReviewBo bo = listReviewBo.get(j);
						if (null != bo && CtFormatUtil.hasContent(bo.getReviewExperts())) {
							judgeReviewExperts = bo.getReviewExperts();
						}
						if (null != bo && !CtFormatUtil.hasContent(bo.getReviewExperts())) {
							throw new WTException("第" + (j + 1) + "行，主审专家必填\r\n");
						} else if (null != bo && CtFormatUtil.hasContent(bo.getReviewExperts())
								&& CtFormatUtil.hasContent(map.get(bo.getReviewExperts()))) {
							throw new WTException("第" + (j + 1) + "行，主审专家重复\r\n");
						} else if (null != bo && CtFormatUtil.hasContent(bo.getReviewExperts())) {
							map.put(bo.getReviewExperts(), "1");
						}
						if (null != bo && !CtFormatUtil.hasContent(bo.getChiefExaminer())) {
							throw new WTException("第" + (j + 1) + "行，是否是主审人必填\r\n");
						}
						if (null != bo && CtFormatUtil.hasContent(bo.getChiefExaminer())
								&& "是".equals(bo.getChiefExaminer())) {
							++judgeChiefExaminer;
						}
					}
					if ("线下".equals(exttra) && (listReviewBo.size() > 1)) {
						emptyAtts += "线下评审最多只可以指定一位评审专家" + "\r\n";
					} else if ("线上".equals(exttra) && !CtFormatUtil.hasContent(judgeReviewExperts)) {
						emptyAtts += "必须指定评审专家" + "\r\n";
					} else if (("线上".equals(exttra) || "线下".equals(exttra)) && (judgeChiefExaminer > 1)) {
						emptyAtts += "最多只能指定一位主审人" + "\r\n";
					} 
					/*else if ("线上".equals(exttra) && (judgeChiefExaminer == 0)) {
						emptyAtts += "评审形式“线上”,必须指定一位主审人" + "\r\n";
					}*/
				}
			} else if ("keydeliver_chiefReviewerFeedback_node".equals(activityKey)
					|| "keydeliver_fillReviewComments_node".equals(activityKey)
					|| "keydeliver_replyToReviewComments_node".equals(activityKey)
					|| "keydeliver_competitiveReceptionAndImport_node".equals(activityKey)
					|| "keydeliver_createProblem_node".equals(activityKey)) {
				System.out.println("233activityKey------->" + activityKey);
				/*
				 * boolean judegeProblemConscientiouser=false; boolean
				 * judegePlannedCompleTime=false;
				 */
				Properties formRequiredAttMap = CtKeyDeliverableProperties.formRequiredAttMap;
				String attStr = formRequiredAttMap.getProperty(activityKey);
				/*
				 * List<String> requiredAttsbefore =
				 * CtKeyDeliverableProperties.getRequiredAtts(activityKey); for
				 * (Iterator<String> ite = requiredAttsbefore.iterator();
				 * ite.hasNext();) { String attKey = ite.next();
				 * if("problemConscientiouser".equals(attKey)){
				 * judegeProblemConscientiouser=true; }
				 * if("plannedCompleTime".equals(attKey)){
				 * judegePlannedCompleTime=true; } List<String> attValue =
				 * query.getAttributeApprovalValue(branchId, attKey); if(null ==
				 * attValue || attValue.size() == 0){ continue; } for (int m =
				 * 0; m < attValue.size(); m++) { if
				 * (!CtFormatUtil.hasContent(attValue.get(m))) { String
				 * displayName =
				 * CtKeyDeliverableProperties.getAttDisplayName(attKey);
				 * emptyAtts += "第" + (m + 1) + "行" + displayName + "\r\n"; } }
				 * }
				 */
				System.out.println("11attStr----------------->" + attStr);
				List<CtKeyDeliverableApprovalBo> problemList = query.getAttributeApprovalValues(branchId);
				String userFullName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
				String userName = ext.plm.util.CtUserUtil.getCurrentUserAccountName();
				for (int l = 0; l < problemList.size(); l++) {
					CtKeyDeliverableApprovalBo approvalBo = problemList.get(l);
					if (null == approvalBo) {
						continue;
					}
					String reviewer = approvalBo.getReviewer();
					boolean isItMe = false;
					System.out.println("isItMe--------->" + userName + "<------>" + reviewer);
					System.out.println(reviewer.equals(userName) + "<------>"  + !CtFormatUtil.hasContent(approvalBo.getReviewComments()) + "<------>" + attStr.contains("reviewComments,"));
					if (reviewer.equals(userName)) {
						isItMe = true;
					}
					System.out.println(isItMe && !CtFormatUtil.hasContent(approvalBo.getReviewComments())
							&& attStr.contains("reviewComments,"));
					if (isItMe && !CtFormatUtil.hasContent(approvalBo.getReviewComments())
							&& attStr.contains("reviewComments,")) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName("reviewComments");
						emptyAtts += "第" + (l + 1) + "行" + displayName + "\r\n";
					}
					if (isItMe && !CtFormatUtil.hasContent(approvalBo.getReviewTypeComments())
							&& attStr.contains("reviewTypeComments,")) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName("reviewTypeComments");
						emptyAtts += "第" + (l + 1) + "行" + displayName + "\r\n";
					}
					if (isItMe && !CtFormatUtil.hasContent(approvalBo.getPalnDefect())
							&& attStr.contains("palnDefect,")) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName("palnDefect");
						emptyAtts += "第" + (l + 1) + "行" + displayName + "\r\n";
					}
					if (isItMe && !CtFormatUtil.hasContent(approvalBo.getOptimizationPlan())
							&& attStr.contains("optimizationPlan,")) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName("optimizationPlan");
						emptyAtts += "第" + (l + 1) + "行" + displayName + "\r\n";
					}
					if (isItMe && !CtFormatUtil.hasContent(approvalBo.getEffectDescription())
							&& attStr.contains("effectDescription,")) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName("effectDescription");
						emptyAtts += "第" + (l + 1) + "行" + displayName + "\r\n";
					}
                    if("keydeliver_replyToReviewComments_node".equals(activityKey) && !CtFormatUtil.hasContent(approvalBo.getTransferProblem())
							&& attStr.contains("transferProblem,")){
						if("采纳".equals(approvalBo.getOptimizationPlan())){
							String displayName = CtKeyDeliverableProperties.getAttDisplayName("transferProblem");
							emptyAtts += "第" + (l + 1) + "行" + displayName + "\r\n";
						}
					}else if (isItMe && !("keydeliver_replyToReviewComments_node".equals(activityKey))
							&& !CtFormatUtil.hasContent(approvalBo.getTransferProblem())
							&& attStr.contains("transferProblem,")) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName("transferProblem");
						emptyAtts += "第" + (l + 1) + "行" + displayName + "\r\n";
					}
					
                    boolean akey = true;
                    if("keydeliver_fillReviewComments_node".equals(activityKey) ||
                    		"keydeliver_chiefReviewerFeedback_node".equals(activityKey)){
                    	akey = false;
                    }
					if ((isItMe || akey) && CtFormatUtil.hasContent(approvalBo.getTransferProblem())
							&& "是".equals(approvalBo.getTransferProblem())) {
						if ((isItMe || akey) && !CtFormatUtil.hasContent(approvalBo.getProblemConscientiouser())
								&& attStr.contains("problemConscientiouser,")) {
							emptyAtts += "第" + (l + 1) + "行转问题负责人\r\n";
						}
						if ((isItMe || akey) && !CtFormatUtil.hasContent(approvalBo.getTechnologicalProcess())
								&& attStr.contains("technologicalProcess,")) {
							emptyAtts += "第" + (l + 1) + "行转问题流程\r\n";
						}
						if ((isItMe || akey) && !CtFormatUtil.hasContent(approvalBo.getPlannedCompleTime())
								&& attStr.contains("plannedCompleTime,")) {
							emptyAtts += "第" + (l + 1) + "行计划完成时间\r\n";
						}
					}

				}
			} else if ("keydeliver_toReview_node".equals(activityKey)) {
				List<String> attValue2 = query.getAttributeApprovalValue(branchId, "palnDefect");
				for (int m = 0; m < attValue2.size(); m++) {
					if (!CtFormatUtil.hasContent(attValue2.get(m))) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName("palnDefect");
						emptyAtts += "第" + (m + 1) + "行" + displayName + "\r\n";
					}
				}
			} else if ("keydeliver_processAuditAndProblemFollow_node".equals(activityKey)) {
				for (Iterator<String> ite = requiredAtts.iterator(); ite.hasNext();) {
					String attKey = ite.next();
					List<String> attValue = query.getAttributeExecuteValues(branchId, attKey);
					for (int m = 0; m < attValue.size(); m++) {
						if (!CtFormatUtil.hasContent(attValue.get(m))) {
							String displayName = CtKeyDeliverableProperties.getAttDisplayName(attKey);
							emptyAtts += "第" + (m + 1) + "行" + displayName + "\r\n";
						}
					}
				}
				List<String> attValue2 = query.getAttributeApprovalValue(branchId, "palnDefect");
				for (int m = 0; m < attValue2.size(); m++) {
					if (!CtFormatUtil.hasContent(attValue2.get(m))) {
						String displayName = CtKeyDeliverableProperties.getAttDisplayName("palnDefect");
						emptyAtts += "第" + (m + 1) + "行" + displayName + "\r\n";
					}
				}
			}
			if (CtFormatUtil.hasContent(emptyAtts)) {
				throw new WTException("以下字段必填，请输入内容后再提交！\r\n" + emptyAtts);
			}
		} catch (WTException wte) {
			throw wte;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
		}
	}

	/**
	 * 从流程变更self出发，获得活动对应的key值，前台判断权限等功能需要用到此key
	 *
	 * @param self
	 * @return
	 * @throws Exception
	 */
	private static String getActivityKey(Object self) throws Exception {

		String actName = ""; // 活动名称（工作流模板中的活动）
		String activityKey = "";// 活动Key值

		// self有时是ObjectReference对象，有时直接是WorkItem或WfAssignedActivity
		if (self instanceof ObjectReference) {
			self = ((ObjectReference) self).getObject();
		}

		if (self instanceof WorkItem) {

			WorkItem workItem = (WorkItem) self;
			WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
			actName = activity.getName();
			System.out.println("1actName------>" + actName);
			activityKey = CtKeyDeliverableProperties.getActivityNodeName(actName);
			System.out.println("activityKey------>" + activityKey);

		} else if (self instanceof WfAssignedActivity) {
			WfAssignedActivity activity = (WfAssignedActivity) self;
			actName = activity.getName();
			System.out.println("2actName------>" + actName);
			activityKey = CtKeyDeliverableProperties.getActivityNodeName(actName);
			String activityKey1 = CtKeyDeliverableProperties.getActivityKey(actName);
			System.out.println("activityKey------>" + activityKey + "---activityKey1--" + activityKey1);
		}

		if (!CtFormatUtil.hasContent(activityKey)) {
			System.out.println(
					">>>>actName='" + actName + "'无法找到对应的Key,需要核对配置表CtKeyDeliverableActivityKeyMap.properties！");
			throw new WTException("后台异常，无法找到当前流程活动对应的Key，请联系管理员！");
		}

		return activityKey;
	}

	/**
	 * //大版本是否是A true 是A
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public static boolean judgeDocType(WTObject obj) throws Exception {
		WTDocument doc = (WTDocument) obj;
		/*
		 * String docType = CtWTObjectUtil.getLeafTypeIdentifier(doc); if
		 * (CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGYJ.equals(docType) ||
		 * CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGJG.equals(docType) ||
		 * CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGRJ.equals(docType) ||
		 * CtKeyDeliverableConstant.CT_DOCTYPE_CSBG.equals(docType)) { return
		 * false; }
		 */
		// 单个主要内容 ContentRoleType.PRIMARY 附件 ContentRoleType.SECONDARY
		// CtVersionUtil.getVersionInfo(doc);
		String versionStr = doc.getVersionIdentifier().getValue();
		System.out.println("versionStr------------->" + versionStr);
		if ("A".equals(versionStr)) {
			return true;
		}
		return false;
	}

	/**
	 * 判断流程分支
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public static String judgeProcessBranch(WTObject obj) throws Exception {
		WTDocument doc = (WTDocument) obj;
		String docType = CtWTObjectUtil.getLeafTypeIdentifier(doc);
		System.out.println("docType------------------->" + docType);
		if (CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGYJ.equals(docType)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGJG.equals(docType)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGRJ.equals(docType)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_CSBG.equals(docType)) {
			return "符合交付件评审报告路由的文档";
		}
		// 单个主要内容 ContentRoleType.PRIMARY 附件 ContentRoleType.SECONDARY
		return "符合关键交付件评审路由的文档";
	}

	/**
	 * 判断是否添加主审人
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public static String judgeChiefExaminer(WTObject obj) throws Exception {
		WTDocument doc = (WTDocument) obj;
		String branchId = doc.getBranchIdentifier() + "";
		CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
		List<CtKeyDeliverableReviewBo> listReviewBo = query.getAttributeValueExtra(branchId);
		if (null == listReviewBo || listReviewBo.size() == 0) {
			return "否";
		} else {
			String reviewFormat = query.getAttributeValue(branchId, "reviewFormat");
			for (int j = 0; j < listReviewBo.size(); j++) {
				CtKeyDeliverableReviewBo bo = listReviewBo.get(j);
				if (CtFormatUtil.hasContent(bo.getChiefExaminer()) && "是".equals(bo.getChiefExaminer())) {
					return "是";
				} else if ("线下".equals(reviewFormat)) {
					return "是";
				}
			}
			return "否";
		}
	}

	/**
	 * 添加主审人
	 * 
	 * @param pbo
	 * @param self
	 * @return
	 * @throws Exception
	 */
	public static void addUserToContainer(WTObject pbo, Object self) throws Exception {
		try {
			List<WTUser> users = new ArrayList<>();
			List<WTUser> expertsUsers = new ArrayList<>();
			List<WTUser> allUsers = new ArrayList<>();
			WTDocument doc = (WTDocument) pbo;
			String branchId = doc.getBranchIdentifier() + "";
			CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
			List<CtKeyDeliverableReviewBo> listReviewBo = query.getAttributeValueExtra(branchId);
			if (null == listReviewBo || listReviewBo.size() == 0) {
				return;
			}
			String reviewFormat = query.getAttributeValue(branchId, "reviewFormat");
			for (int j = 0; j < listReviewBo.size(); j++) {
				CtKeyDeliverableReviewBo bo = listReviewBo.get(j);
				WTUser user = CtUserUtil.getUserByAccountName(bo.getReviewExperts());
				if (CtFormatUtil.hasContent(bo.getChiefExaminer()) && "是".equals(bo.getChiefExaminer())) {
					users.add(user);
				} else {
					expertsUsers.add(user);
				}
				allUsers.add(user);
			}
			System.out.println("listReviewBo--------->" + users.size() + "<--->" + (self == null));
			if (self instanceof ObjectReference) {
				if ("线下".equals(reviewFormat)) {
//					if (null != allUsers && allUsers.size() > 0) {
						CtWorkFlowUtil.setUsersToRole(pbo, (ObjectReference) self, allUsers, "PrincipalApprover");
//					}
				} else {
					// 主审人
//					if (null != users && users.size() > 0) {
						CtWorkFlowUtil.setUsersToRole(pbo, (ObjectReference) self, users, "PrincipalApprover");
//					}
					// 评审专家
//					if (null != expertsUsers && expertsUsers.size() > 0) {
						CtWorkFlowUtil.setUsersToRole(pbo, (ObjectReference) self, expertsUsers, "EvaluationExperts");
//					}
				}
			}
		} catch (WTException wte) {
			System.out.println("wte----------->");
			wte.printStackTrace();
			throw wte;
		} catch (Exception e) {
			System.out.println("e----------->");
			e.printStackTrace();
			throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
		}

	}

	/**
	 * 判断评审形式
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public static String judgeReviewFormat(WTObject obj) throws Exception {
		WTDocument doc = (WTDocument) obj;
		String branchId = doc.getBranchIdentifier() + "";
		CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
		String attValue = query.getAttributeValue(branchId, "REVIEWFORMAT");
		if (CtFormatUtil.hasContent(attValue) && "线上".equals(attValue)) {
			return "线上";
		} else {
			return "线下";
		}
	}

	/**
	 * 判断是否转问题
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public static String judgeTransferProblem(WTObject obj) throws Exception {
		WTDocument doc = (WTDocument) obj;
		String branchId = doc.getBranchIdentifier() + "";
		CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
		List<CtKeyDeliverableApprovalBo> listApprovalBo = query.getAttributeApprovalValues(branchId);
		if (null == listApprovalBo || listApprovalBo.size() == 0) {
			return "否";
		} else {
			for (int j = 0; j < listApprovalBo.size(); j++) {
				CtKeyDeliverableApprovalBo bo = listApprovalBo.get(j);
				if (CtFormatUtil.hasContent(bo.getTransferProblem()) && "是".equals(bo.getTransferProblem())) {
					return "是";
				}
			}
			return "否";
		}
	}

	/**
	 * 添加主审人
	 * 
	 * @param pbo
	 * @param self
	 * @return
	 * @throws Exception
	 */
	public static void addProblemUsersToContainer(WTObject pbo, Object self) throws Exception {
		try {
			List<WTUser> users = new ArrayList<>();
			WTDocument doc = (WTDocument) pbo;
			String branchId = doc.getBranchIdentifier() + "";
			CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
			List<CtKeyDeliverableApprovalBo> listApprovalBo = query.getAttributeApprovalValues(branchId);
			for (int j = 0; j < listApprovalBo.size(); j++) {
				CtKeyDeliverableApprovalBo bo = listApprovalBo.get(j);
				if (CtFormatUtil.hasContent(bo.getTransferProblem()) && "是".equals(bo.getTransferProblem())) {
					WTUser user = CtUserUtil.getUserByAccountName(bo.getProblemConscientiouser());
					if (null == user) {
						System.out.println("addProblemUsersToContainer------------->" + bo.getProblemConscientiouser());
						user = CtUserUtil.getUserByDisplayName(bo.getProblemConscientiouser());
					}
					users.add(user);
				}
			}
			if (self instanceof ObjectReference) {
				// B139问题承担者
				CtWorkFlowUtil.setUsersToRole(pbo, (ObjectReference) self, users, "Problembearer");
			}
		} catch (WTException wte) {
			System.out.println("wte----------->");
			wte.printStackTrace();
			throw wte;
		} catch (Exception e) {
			System.out.println("e----------->");
			e.printStackTrace();
			throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
		}

	}

	/**
	 * 添加pqa
	 * 
	 * @param pbo
	 * @param self
	 * @return
	 * @throws Exception
	 */
	public static void addEngineerUsersToContainer(WTObject pbo, Object self) throws Exception {
		try {
			List<WTUser> users = new ArrayList<>();
			WTDocument doc = (WTDocument) pbo;
			String branchId = doc.getBranchIdentifier() + "";
			CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
			String engineer = query.getAttributeValue(branchId, "projectManagEngineer");
			WTUser user = CtUserUtil.getUserByAccountName(engineer);
			if (null == user) {
				System.out.println("addPpaUsersToContainer------------->" + engineer);
				user = CtUserUtil.getUserByDisplayName(engineer);
			}
			users.add(user);
			if (self instanceof ObjectReference) {
				// A002项目管理工程师
				CtWorkFlowUtil.setUsersToRole(pbo, (ObjectReference) self, users, "Projectmanagementengineer");
			}
		} catch (WTException wte) {
			System.out.println("wte----------->");
			wte.printStackTrace();
			throw wte;
		} catch (Exception e) {
			System.out.println("e----------->");
			e.printStackTrace();
			throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
		}

	}
	/**
	 * 添加pqa
	 * 
	 * @param pbo
	 * @param self
	 * @return
	 * @throws Exception
	 */
	public static void addPpaUsersToContainer(WTObject pbo, Object self) throws Exception {
		try {
			List<WTUser> users = new ArrayList<>();
			WTDocument doc = (WTDocument) pbo;
			String branchId = doc.getBranchIdentifier() + "";
			CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
			String pqa = query.getAttributeValue(branchId, "pqa");
			WTUser user = CtUserUtil.getUserByAccountName(pqa);
			if (null == user) {
				System.out.println("addPpaUsersToContainer------------->" + pqa);
				user = CtUserUtil.getUserByDisplayName(pqa);
			}
			users.add(user);
			if (self instanceof ObjectReference) {
				// A003质量代表（PQA）
				CtWorkFlowUtil.setUsersToRole(pbo, (ObjectReference) self, users, "QualityRepresentativePQA");
			}
		} catch (WTException wte) {
			System.out.println("wte----------->");
			wte.printStackTrace();
			throw wte;
		} catch (Exception e) {
			System.out.println("e----------->");
			e.printStackTrace();
			throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
		}

	}
	/**
	 *
	 * @param pbo
	 * @param self
	 * @throws Exception
	 */
	public static void judgeDealCompleted(WTObject pbo, Object self) throws Exception {
		try {
			WTDocument doc = (WTDocument) pbo;
			String branchId = doc.getBranchIdentifier() + "";
			CtKeyDeliverableQuery query = new CtKeyDeliverableQuery();
			List<CtKeyDeliverableApprovalBo> listApprovalBo = query.getAttributeApprovalValues(branchId);
			WTPrincipal p = SessionHelper.getPrincipal();
			WTUser CurrentUser = (WTUser) p;
			for (int j = 0; j < listApprovalBo.size(); j++) {
				CtKeyDeliverableApprovalBo bo = listApprovalBo.get(j);
				if (CtFormatUtil.hasContent(bo.getTransferProblem()) && "是".equals(bo.getTransferProblem())) {
					WTUser user = CtUserUtil.getUserByAccountName(bo.getProblemConscientiouser());
					if (null == user) {
						user = CtUserUtil.getUserByDisplayName(bo.getProblemConscientiouser());
						if(null == user){
							continue;
						}
					}
					System.out.println("judgeDealCompleted----->" + CurrentUser.getName() + "<------->" + user.getName());
					if ((CurrentUser.getName().equals(user.getName()))
							&& !CtFormatUtil.hasContent(bo.getTechnologicalProcess())) {
						throw new WTException("有未处理的转问题流程");
					}
				}
			}
		} catch (WTException wte) {
			System.out.println("wte----------->");
			wte.printStackTrace();
			throw wte;
		} catch (Exception e) {
			System.out.println("e----------->");
			e.printStackTrace();
			throw new WTException("后台异常，检查转问题流程出错！异常信息：" + e.getMessage());
		}
	}

	/**
	 * 初始化专家
	 * 
	 * @param pbo
	 * @param self
	 * @return
	 * @throws Exception
	 */
	public static void addExpertsUserToContainer(WTObject pbo, Object self) throws Exception {
		try {
			WTDocument doc = (WTDocument) pbo;
			String branchId = doc.getBranchIdentifier() + "";
			CtKeyDeliverableApproValMapper approValMapper = CtBeanFactory.newCtBeanFactory()
					.getBean(CtKeyDeliverableApproValMapper.class);

			CtKeyDeliverableReviewMapper reviewMapper = CtBeanFactory.newCtBeanFactory()
					.getBean(CtKeyDeliverableReviewMapper.class);
			Wrapper<CtKeyDeliverableReviewBo> wrapper = new EntityWrapper<CtKeyDeliverableReviewBo>();
			wrapper.eq("uniteObjectId", branchId);
			List<CtKeyDeliverableReviewBo> expertsList = reviewMapper.selectList(wrapper);
			if (!(null == expertsList || expertsList.size() == 0)) {
				reviewMapper.delete(wrapper);
		     }
			List<Map<String, String>> engeerList = new CtKeyDeliverableServiceImpl()
					.getPersonLiableList(Long.parseLong(branchId), "3", null);
			for (int i = 0; i < engeerList.size(); i++) {
				Map<String, String> map = engeerList.get(i);
				if (null == map || map.size() == 0) {
					continue;
				}
				CtKeyDeliverableReviewBo bo = new CtKeyDeliverableReviewBo(String.valueOf(branchId));
				String name = map.get("name");
				bo.setReviewExperts(name);
				bo.setChiefExaminer("否");
				if (CtFormatUtil.hasContent(name)) {
					WTUser usre = CtUserUtil.getUserByAccountName(name);
					if (null != usre) {
						// bo.setReviewExperts(usre.getFullName());
						try {
							CtHrPersonBo person = CtHrLogic.getPersonByNo(usre.getName());
							if (null != person) {
								bo.setDepartment(person.getDepartmentName());
								bo.setPost(person.getPostNames());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						bo.setOpinionCount("0");
						bo.setOpinionsAdoptedCount("0");
					}
				}
				reviewMapper.insert(bo);
			}
		} catch (Exception e) {
			System.out.println("e----------->");
			e.printStackTrace();
			throw new WTException("后台异常，检查表单必填项出错！异常信息：" + e.getMessage());
		}

	}
}
