package ext.plm.keyDeliverable;

public class CtKeyDeliverableConstant {

	//文档类型
	//P-1.1.4-T07 产品需求规格说明书
	public static String CT_DOCTYPE_CPXQGGSMS = "com.fhsj.Doc_cpxqggsms";
	//P-1.1.4-T08 产品概念说明书
	public static String CT_DOCTYPE_CPGLSMS = "com.fhsj.Doc_cpglsms";
	//P-1.1.4-T13 产品总体设计说明书
	public static String CT_DOCTYPE_CPZTSJSMS = "com.fhsj.Doc_cpztsjsms";
	//P-1.1.5-T01 系统联调报告
	public static String CT_DOCTYPE_XTLDBG = "com.fhsj.Doc_xtldbg";
	//P-1.1.7.4-T08 维护类项目产品特性设计说明书
	public static String CT_DOCTYPE_WHLXMCPTXSMS = "com.fhsj.Doc_whlxmcptxsms";
	//P-1.2.10.1-T02 产品测试用例和记录
	public static String CT_DOCTYPE_CPCSYLHJL = "com.fhsj.Doc_cpcsylhjl";
	//P-1.2.10.1-T06 产品测试方案
	public static String CT_DOCTYPE_CPCSGASMS = "com.fhsj.Doc_cpcsgasms";
	//P-1.2.8.1-T01_单板硬件调测报告
	public static String CT_DOCTYPE_DBYJTCBG = "com.fhsj.Doc_dbyjtcbg";
	//P-1.2.8.1-T02 单板硬件设计说明书
	public static String CT_DOCTYPE_DBYJSJSMS = "com.fhsj.Doc_dbyjsjsms";
	//P-1.2.8.2-T03 软件设计说明书
	public static String CT_DOCTYPE_RJSJSMS = "com.fhsj.Doc_rjsjsms";
	//P-1.2.8.3-T02 工业设计方案说明书
	public static String CT_DOCTYPE_YGSJFASMS = "com.fhsj.Doc_ygsjfasms";
	//P-1.2.8.3-T04 结构设计说明书
	public static String CT_DOCTYPE_JGSJSMS = "com.fhsj.Doc_jgsjsms";
	//P-1.5.1-T02 制造系统验证方案
	public static String CT_DOCTYPE_ZZXTYQFA = "com.fhsj.Doc_zzxtyqfa";
	//P-1.5.1-T03 生产测试方案说明书
	public static String CT_DOCTYPE_SCCSFASMS = "com.fhsj.Doc_sccsfasms";
	//P-1.5.1-T04 工艺设计说明书
	public static String CT_DOCTYPE_GYSJSMS = "com.fhsj.Doc_gysjsms";
	//P-1.5.1-T05 制造系统验证报告
	public static String CT_DOCTYPE_ZZXTYZBG = "com.fhsj.Doc_zzxtyzbg";
	//P-1.2.8.2-T04 单板软件设计说明书
	public static String CT_DOCTYPE_DBRJSJSMS = "com.fhsj.Doc_dbrjsjsms";
	//P-1.1-T45-1 交付件评审报告（硬件类）
	public static String CT_DOCTYPE_JFJPSBGYJ = "com.fhsj.Doc_jfjpsbgyj";
	//P-1.1-T45-3 交付件评审报告（结构类）
	public static String CT_DOCTYPE_JFJPSBGJG = "com.fhsj.Doc_jfjpsbgjg";
	//P-1.1-T45-2 交付件评审报告（软件类）
	public static String CT_DOCTYPE_JFJPSBGRJ = "com.fhsj.Doc_jfjpsbgrj";
	//P-1.2.10.1-T03 测试报告
	public static String CT_DOCTYPE_CSBG = "com.fhsj.Doc_csbg";

	public static boolean jgType(String type) {
		if (CtKeyDeliverableConstant.CT_DOCTYPE_CPXQGGSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_CPGLSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_CPZTSJSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_XTLDBG.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_WHLXMCPTXSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_CPCSYLHJL.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_CPCSGASMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_DBYJTCBG.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_DBYJSJSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_RJSJSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_YGSJFASMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_JGSJSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_ZZXTYQFA.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_SCCSFASMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_SCCSFASMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_GYSJSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_ZZXTYZBG.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_DBRJSJSMS.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGYJ.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGJG.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_JFJPSBGRJ.equals(type)
				|| CtKeyDeliverableConstant.CT_DOCTYPE_CSBG.equals(type)) {
			return true;
		}
		return false;
	}
}
