package ext.plm.keyDeliverable.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import ext.plm.keyDeliverable.bo.CtKeyDeliverableBasicsBo;


@Mapper
public interface CtKeyDeliverableMapper extends BaseMapper<CtKeyDeliverableBasicsBo> {
}
