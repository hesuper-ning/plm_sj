package ext.plm.keyDeliverable.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import ext.plm.keyDeliverable.bo.CtKeyDeliverableExecuteBo;

@Mapper
public interface CtKeyDeliverableExecuteMapper extends BaseMapper<CtKeyDeliverableExecuteBo> {
}
