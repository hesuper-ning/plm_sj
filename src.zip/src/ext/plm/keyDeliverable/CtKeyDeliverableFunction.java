package ext.plm.keyDeliverable;

import java.util.List;

import org.apache.log4j.Logger;

import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.sampleConfirmation.bo.CtConfirmMainContentBo;
import ext.plm.sampleConfirmation.mapper.CtConfirmMainContentMapper;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import wt.doc.WTDocument;
import wt.fc.WTObject;
import wt.log4j.LogR;
import wt.part.WTPart;

public class CtKeyDeliverableFunction {

	private static final Logger logger = LogR.getLogger(CtKeyDeliverableFunction.class.getName());

	// 是否所有物料都无环保要求
	public static boolean containsRoHS(WTObject obj) throws Exception {
		WTDocument document = (WTDocument) obj;
		long branchId = document.getBranchIdentifier();
		
		CtConfirmMainContentMapper confirmMainContentMapper = CtBeanFactory.newCtBeanFactory()
				.getBean(CtConfirmMainContentMapper.class);
		List<CtConfirmMainContentBo> confirmMainContentBos = confirmMainContentMapper
				.queryConfirmMainContentBo(branchId);
		for (int i = 0; i < confirmMainContentBos.size(); i++) {
			CtConfirmMainContentBo bo = confirmMainContentBos.get(i);
			WTPart part = CtPartUtil.getPartByNumber(bo.getPartNumber(), CtConstant.VIEW_DESIGN);
			IBAUtil ibaUtil = new IBAUtil(part);
			// String roHs = ibaUtil.getIBAValue("ct_isRohs");
			String roHs = ibaUtil.getIBAValue("ct_Environmental");
			if (CtFormatUtil.hasContent(roHs) && "RoHS+REACH|RoHS|REACH".contains(roHs)) {
				return true;
			}
		}
		return false;
	}
}
