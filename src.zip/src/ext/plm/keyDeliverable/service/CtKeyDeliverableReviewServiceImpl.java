package ext.plm.keyDeliverable.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import ext.plm.integration.hr.CtHrLogic;
import ext.plm.integration.hr.bo.CtHrPersonBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableReviewBo;
import ext.plm.keyDeliverable.mapper.CtKeyDeliverableReviewMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import wt.org.WTUser;

@Service
public class CtKeyDeliverableReviewServiceImpl extends
		ServiceImpl<CtKeyDeliverableReviewMapper, CtKeyDeliverableReviewBo> implements CtKeyDeliverableReviewService {
	@Autowired
	private CtKeyDeliverableApprovalService ctKeyDeliverableApprovalService;
	@Override
	public List<CtKeyDeliverableReviewBo> getKeyDeliverableReview(Long branchId) throws Exception {
		Wrapper<CtKeyDeliverableReviewBo> wrapper = new EntityWrapper<CtKeyDeliverableReviewBo>();
		wrapper.eq("uniteObjectId", branchId);
		wrapper.orderBy("createTime", true);
		List<CtKeyDeliverableReviewBo> boList = super.selectList(wrapper);
		List<CtKeyDeliverableReviewBo> list = new ArrayList<CtKeyDeliverableReviewBo>();
		if (null == boList || boList.size() == 0) {
			return list;
		} else {
			for (int i = 0; i < boList.size(); i++) {
				CtKeyDeliverableReviewBo bo = boList.get(i);
				if (CtFormatUtil.hasContent(bo.getReviewExperts())) {
					WTUser usre = CtUserUtil.getUserByAccountName(bo.getReviewExperts());
					if (null != usre) {
						bo.setReviewExperts(usre.getFullName());
						try {
							CtHrPersonBo person = CtHrLogic.getPersonByNo(usre.getName());
							if (null != person) {
								bo.setDepartment(person.getDepartmentName());
								bo.setPost(person.getPostNames());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						int reviewerCt = ctKeyDeliverableApprovalService.getKeyDeliverableErrorColletionBykey(
								new String[] { "reviewer" }, new String[] { usre.getName() },branchId);
						bo.setOpinionCount("" + reviewerCt);
						int reviewerOptimizationPlanCt = ctKeyDeliverableApprovalService
								.getKeyDeliverableErrorColletionBykey(new String[] { "reviewer", "optimizationPlan" },
										new String[] { usre.getName(), "采纳" },branchId);
						bo.setOpinionsAdoptedCount("" + reviewerOptimizationPlanCt);
						/*
						 * if(!CtFormatUtil.hasContent(bo.getChiefExaminer())){
						 * bo.setChiefExaminer("否");
						 * updateCtKeyDeliverableReviewBo(bo.getId(),
						 * "chiefExaminer", "否",""+branchId); }
						 */
					}
				}
				list.add(bo);
			}
		}

		return list;
	}

	@Override
	public void deleteKeyDeliverableReview(List<String> ids) throws Exception {
		super.deleteBatchIds(ids);
	}

	@Override
	public Boolean saveKeyDeliverableReview(List<CtKeyDeliverableReviewBo> entityList) throws Exception {
		return super.insertOrUpdateAllColumnBatch(entityList);
	}

	@Override
	public CtKeyDeliverableReviewBo updateCtKeyDeliverableReviewBo(String id, String key, String value,String branchId)
			throws Exception {
		CtKeyDeliverableReviewBo bo = null;
		if(CtFormatUtil.hasContent(id)){
			bo = super.selectById(id);
		}else{
			bo = new CtKeyDeliverableReviewBo(branchId);
			super.insert(bo);
		}
		CtCommonUtil.setObjectValue(bo, key, value);
		super.updateById(bo);
		return bo;
	}

}
