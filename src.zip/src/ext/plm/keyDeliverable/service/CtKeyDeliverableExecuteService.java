package ext.plm.keyDeliverable.service;

import java.util.List;

import ext.plm.keyDeliverable.bo.CtKeyDeliverableExecuteBo;
import wt.method.RemoteInterface;

@RemoteInterface
public interface CtKeyDeliverableExecuteService {
	/**
	 * 查询S01：基础信息--表4
	 * 
	 * @return
	 * @throws Exception
	 */
	List<CtKeyDeliverableExecuteBo> getKeyDeliverableExecute(Long branchId) throws Exception;

	/**
	 * 删除基础信息--表4
	 * 
	 * @param ids
	 * @throws Exception
	 */
	void deleteKeyDeliverableExecute(List<String> ids) throws Exception;

	/**
	 * 保存基础信息--表4
	 * 
	 * @param branchId
	 * @throws Exception
	 */
	Boolean saveKeyDeliverableExecute(List<CtKeyDeliverableExecuteBo> entityList) throws Exception;

	/**
	 * 更新
	 * 
	 * @param id
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
	CtKeyDeliverableExecuteBo updateKeyDeliverableExecuteBo(String id, String key, String value) throws Exception;

}
