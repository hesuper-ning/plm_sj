package ext.plm.keyDeliverable.service;

import java.util.List;
import java.util.Map;

import ext.plm.keyDeliverable.bo.CtKeyDeliverableBasicsBo;
import wt.method.RemoteInterface;

@RemoteInterface
public interface CtKeyDeliverableService {
	/**
	 * 实时保存item信息
	 * 
	 * @param dbTableName
	 * @param id
	 * @param attKey
	 * @param attValue
	 * @throws Exception
	 */
	void updateAttById(String attKey, String attValue, String branchId) throws Exception;

	/**
	 * 插入数据
	 * 
	 * @param dbTableName
	 * @param branchId
	 * @throws Exception
	 */
	void insertTableData(CtKeyDeliverableBasicsBo bo) throws Exception;

	public void updateTableData(CtKeyDeliverableBasicsBo bo) throws Exception ;
	
	/**
	 * 删除数据
	 * 
	 * @param dbTableName
	 * @param id
	 * @throws Exception
	 */
	void deleteTableData(String dbTableName, String id) throws Exception;

	/**
	 * 查询S01：基础信息--表1
	 * 
	 * @return
	 * @throws Exception
	 */
	CtKeyDeliverableBasicsBo getKeyDeliverableBasis(Long branchId) throws Exception;

	List<Map<String, String>> getPersonLiableList(Long branchId, String type, String query) throws Exception;

	CtKeyDeliverableBasicsBo getKeyDeliverableAssembleBasis(CtKeyDeliverableBasicsBo bo) throws Exception ;
}
