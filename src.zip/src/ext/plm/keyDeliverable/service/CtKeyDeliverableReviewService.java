package ext.plm.keyDeliverable.service;

import java.util.List;

import ext.plm.keyDeliverable.bo.CtKeyDeliverableReviewBo;
import ext.plm.trialProcess.bo.CtTrialCombinationBo;
import wt.method.RemoteInterface;

@RemoteInterface
public interface CtKeyDeliverableReviewService {

	/**
	 * 查询S01：基础信息--表2
	 * 
	 * @return
	 * @throws Exception
	 */
	List<CtKeyDeliverableReviewBo> getKeyDeliverableReview(Long branchId) throws Exception;

    /**
     * 删除基础信息--表2
     * @param ids
     * @throws Exception
     */
    void deleteKeyDeliverableReview(List<String> ids) throws Exception;

    /**
     * 保存基础信息--表2
     * @param branchId
     * @throws Exception
     */
    public Boolean saveKeyDeliverableReview(List<CtKeyDeliverableReviewBo> entityList) throws Exception;

	/**
	 * 更新
	 * @param id
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
    CtKeyDeliverableReviewBo updateCtKeyDeliverableReviewBo(String id, String key, String value,String branchId) throws Exception;
	
}
