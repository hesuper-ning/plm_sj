package ext.plm.keyDeliverable.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.joda.time.format.FormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableApprovalBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableBasicsBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableExecuteBo;
import ext.plm.keyDeliverable.mapper.CtKeyDeliverableApproValMapper;
import ext.plm.keyDeliverable.mapper.CtKeyDeliverableExecuteMapper;
import ext.plm.part.config.CtPartConstant;
import ext.plm.sampleConfirmation.bo.CtConfirmMainContentBo;
import ext.plm.sampleConfirmation.bo.CtPartBrandInfo;
import ext.plm.sampleConfirmation.bo.CtProductIdentificationBo;
import ext.plm.sampleConfirmation.mapper.CtConfirmMainContentMapper;
import ext.plm.sampleConfirmation.mapper.CtProductIdentificationMapper;
import ext.plm.trialProcess.bo.CtTrialStandardBo;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.doc.WTDocument;
import wt.org.WTUser;
import wt.part.WTPart;

@Service
public class CtKeyDeliverableExecuteServiceImpl
extends ServiceImpl<CtKeyDeliverableExecuteMapper, CtKeyDeliverableExecuteBo>
implements CtKeyDeliverableExecuteService{

	@Autowired
	private CtKeyDeliverableService ctKeyDeliverableService;
	
	@Override
	public List<CtKeyDeliverableExecuteBo> getKeyDeliverableExecute(Long branchId) throws Exception {
		Wrapper<CtKeyDeliverableExecuteBo> wrapper = new EntityWrapper<CtKeyDeliverableExecuteBo>();
		wrapper.eq("uniteObjectId", branchId);
		//wrapper.orderBy("createTime", true);
		List<CtKeyDeliverableExecuteBo> boList = super.selectList(wrapper);
		if (null == boList || boList.size() == 0) {
			boList = changeBo(""+branchId);
			saveKeyDeliverableExecute(boList);
		}
		return boList;
	}

	@Override
	public void deleteKeyDeliverableExecute(List<String> ids) throws Exception {
		super.deleteBatchIds(ids);
	}

	@Override
	public Boolean saveKeyDeliverableExecute(List<CtKeyDeliverableExecuteBo> entityList) throws Exception {
		return super.insertOrUpdateAllColumnBatch(entityList);
	}

	public List<CtKeyDeliverableExecuteBo> changeBo(String branchId) throws Exception {
		List<CtKeyDeliverableExecuteBo> list = new ArrayList<CtKeyDeliverableExecuteBo>();
		CtKeyDeliverableExecuteBo bo = new CtKeyDeliverableExecuteBo(branchId);
		bo.setEvaluationProcess("评审计划");
		bo.setAssessmentElement("本交付件的评审计划是否合理？");
		bo.setFixedScore("10");
		list.add(bo);
		
		CtKeyDeliverableExecuteBo bo2 = new CtKeyDeliverableExecuteBo(branchId);
		bo2.setEvaluationProcess("评审计划");
		bo2.setAssessmentElement("本交付件输出是否按照项目计划时间完成？");
		bo2.setFixedScore("10");
		list.add(bo2);
		
		CtKeyDeliverableExecuteBo bo3 = new CtKeyDeliverableExecuteBo(branchId);
		bo3.setEvaluationProcess("评审计划");
		bo3.setAssessmentElement("本交付件评审计划是否发给对应的全部专家？");
		bo3.setFixedScore("10");
		list.add(bo3);
		
		CtKeyDeliverableExecuteBo bo4 = new CtKeyDeliverableExecuteBo(branchId);
		bo4.setEvaluationProcess("评审执行");
		bo4.setAssessmentElement("评审专家是否提交自己的评审意见？");
		bo4.setFixedScore("10");
		list.add(bo4);
		
		CtKeyDeliverableExecuteBo bo5 = new CtKeyDeliverableExecuteBo(branchId);
		bo5.setEvaluationProcess("评审执行");
		bo5.setAssessmentElement("是否覆盖到所需专业领域？");
		bo5.setFixedScore("10");
		list.add(bo5);
		
		CtKeyDeliverableExecuteBo bo6 = new CtKeyDeliverableExecuteBo(branchId);
		bo6.setEvaluationProcess("评审执行");
		bo6.setAssessmentElement("交付件责任人是否记录评审意见，并对相关文件做出修订？");
		bo6.setFixedScore("10");
		list.add(bo6);
		
		CtKeyDeliverableExecuteBo bo7 = new CtKeyDeliverableExecuteBo(branchId);
		bo7.setEvaluationProcess("评审执行");
		bo7.setAssessmentElement("应参会评审专家是否全部参会？");
		bo7.setFixedScore("10");
		list.add(bo7);
		
		
		CtKeyDeliverableExecuteBo bo10 = new CtKeyDeliverableExecuteBo(branchId);
		bo10.setEvaluationProcess("填写评审报告、评审问题跟踪");
		bo10.setAssessmentElement("评审报告中各项信息是否完整？");
		bo10.setFixedScore("10");
		list.add(bo10);
		
		CtKeyDeliverableExecuteBo bo11 = new CtKeyDeliverableExecuteBo(branchId);
		bo11.setEvaluationProcess("填写评审报告、评审问题跟踪");
		bo11.setAssessmentElement("评审出的问题点和改进方案是否有分配到责任人和完成时间计划？");
		bo11.setFixedScore("10");
		list.add(bo11);
		
		CtKeyDeliverableExecuteBo bo12 = new CtKeyDeliverableExecuteBo(branchId);
		bo12.setEvaluationProcess("填写评审报告、评审问题跟踪");
		bo12.setAssessmentElement("评审过程是效率是否接受？报告是否及时存档？超过10天未完成评审审批的此项不给分。");
		bo12.setFixedScore("10");
		list.add(bo12);

		return list;
	}

	@Override
	public CtKeyDeliverableExecuteBo updateKeyDeliverableExecuteBo(String id, String key, String value) throws Exception {
		CtKeyDeliverableExecuteBo bo = super.selectById(id);
	    CtCommonUtil.setObjectValue(bo, key, value);
	    super.updateById(bo);
	    if ("score".equals(key)) {
	    	CtKeyDeliverableBasicsBo basicBo
	    	            = ctKeyDeliverableService.getKeyDeliverableBasis(Long.parseLong(bo.getUniteObjectId()));
	    	//basicBo.setFileNumberPages("");
	    	List<CtKeyDeliverableExecuteBo> exeList = getKeyDeliverableExecute(Long.parseLong(bo.getUniteObjectId()));
	    	int numberdefects = 0;
	    	for(CtKeyDeliverableExecuteBo exeBo : exeList){
	    		if(CtFormatUtil.hasContent(exeBo.getScore())){
	    			numberdefects += Integer.parseInt(exeBo.getScore()) ;
	    		}
	    	}
	    	//basicBo.setNumberDefects(""+numberdefects);
	    	//basicBo.setDefectDensity("");
	    	basicBo.setNumberScore(""+numberdefects);
	    	String userName = CtUserUtil.getCurrentUserAccountName();
	    	basicBo.setEvaluationPQA(userName);
	    	basicBo.setEvaluationAuditDate(CtDateUtil.getCurrentDate("yyyy-MM-dd", "GMT+8"));
	    	ctKeyDeliverableService.updateTableData(basicBo);
	    }else if("remark".equals(key)){
	    	CtKeyDeliverableBasicsBo basicBo
            = ctKeyDeliverableService.getKeyDeliverableBasis(Long.parseLong(bo.getUniteObjectId()));
	    	String userName = CtUserUtil.getCurrentUserAccountName();
	    	basicBo.setEvaluationPQA(userName);
	    	basicBo.setEvaluationAuditDate(CtDateUtil.getCurrentDate("yyyy-MM-dd", "GMT+8"));
	    	ctKeyDeliverableService.updateTableData(basicBo);
	    }
	    return bo;
	}
	//ext.plm.keyDeliverable.CtKeyDeliverableHelper.getPageContByDocument(String)
}
