package ext.plm.keyDeliverable.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ptc.core.components.util.TimeZoneHelper;

import ext.plm.keyDeliverable.CtKeyDeliverableHelper;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableBasicsBo;
import ext.plm.keyDeliverable.mapper.CtKeyDeliverableMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtProjectUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.doc.WTDocument;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.project.Role;
import wt.projmgmt.admin.Project2;

@Service
public class CtKeyDeliverableServiceImpl extends ServiceImpl<CtKeyDeliverableMapper, CtKeyDeliverableBasicsBo>
		implements CtKeyDeliverableService {

	@Autowired
	private CtKeyDeliverableApprovalService ctKeyDeliverableApprovalService;

	@Autowired
	private CtKeyDeliverableService ctKeyDeliverableService;

	@Override
	public void updateAttById(String attKey, String attValue, String branchId) throws Exception {
		Wrapper<CtKeyDeliverableBasicsBo> wrapper = new EntityWrapper<CtKeyDeliverableBasicsBo>();
		wrapper.eq("uniteObjectId", branchId);
		List<CtKeyDeliverableBasicsBo> boList = super.selectList(wrapper);

		CtKeyDeliverableBasicsBo bo = boList.get(0);
		if ("approvalOpinion".equals(attKey) || "approvalExplain".equals(attKey)) {
			String currentUserDisplayName = CtUserUtil.getCurrentUserAccountName();
			bo.setApprover(currentUserDisplayName);
			bo.setApprovalAuditDate(CtDateUtil.getCurrentDate("yyyy-MM-dd", "GMT+8"));
		}
		if ("reviewConclusion".equals(attKey) || "reviewExplain".equals(attKey)) {
			String currentUserDisplayName = CtUserUtil.getCurrentUserAccountName();
			bo.setReviewChiefExaminer(currentUserDisplayName);
			bo.setRevieAauditDate(CtDateUtil.getCurrentDate("yyyy-MM-dd", "GMT+8"));
		}
		CtCommonUtil.setObjectValue(bo, attKey, attValue);
		super.updateById(bo);
	}

	@Override
	public void insertTableData(CtKeyDeliverableBasicsBo bo) throws Exception {
		super.insert(bo);
	}

	@Override
	public void updateTableData(CtKeyDeliverableBasicsBo bo) throws Exception {
		Wrapper<CtKeyDeliverableBasicsBo> wrapper = new EntityWrapper<CtKeyDeliverableBasicsBo>();
		wrapper.eq("uniteObjectId", bo.getUniteObjectId());
		super.update(bo, wrapper);
	}

	@Override
	public void deleteTableData(String dbTableName, String id) throws Exception {
		// TODO Auto-generated method stub
		String[] idStr = id.split(",");
		List<String> idList = Arrays.asList(idStr);
		super.deleteBatchIds(idList);
	}

	@Override
	public CtKeyDeliverableBasicsBo getKeyDeliverableAssembleBasis(CtKeyDeliverableBasicsBo bo) throws Exception {
		/*
		 * if (CtFormatUtil.hasContent(bo.getProjectManagEngineer())) { WTUser
		 * usre = CtUserUtil.getUserByAccountName(bo.getProjectManagEngineer());
		 * bo.setProjectManagEngineer(usre.getFullName()); } if
		 * (CtFormatUtil.hasContent(bo.getPqa())) { WTUser usre =
		 * CtUserUtil.getUserByAccountName(bo.getPqa());
		 * bo.setPqa(usre.getFullName()); }
		 */
		if (CtFormatUtil.hasContent(bo.getApprover())) {
			WTUser usre = CtUserUtil.getUserByAccountName(bo.getApprover());
			bo.setApprover(usre.getFullName());
		}
		if (CtFormatUtil.hasContent(bo.getReviewChiefExaminer())) {
			WTUser usre = CtUserUtil.getUserByAccountName(bo.getReviewChiefExaminer());
			bo.setReviewChiefExaminer(usre.getFullName());
		}
		if (CtFormatUtil.hasContent(bo.getEvaluationPQA())) {
			WTUser usre = CtUserUtil.getUserByAccountName(bo.getEvaluationPQA());
			bo.setEvaluationPQA(usre.getFullName());
		}
		if (CtFormatUtil.hasContent(bo.getProposedPerson())) {
			WTUser usre = CtUserUtil.getUserByAccountName(bo.getProposedPerson());
			bo.setProposedPerson(usre.getFullName());
		}
		String docVr = "VR:wt.doc.WTDocument:" + bo.getUniteObjectId();
		WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
		int ct = CtKeyDeliverableHelper.getpageCont(doc);
		bo.setFileNumberPages(String.valueOf(ct));
		ctKeyDeliverableService.updateAttById("fileNumberPages", String.valueOf(ct), bo.getUniteObjectId());
		
		String defectDensity = "0";
		if(CtFormatUtil.hasContent(bo.getNumberDefects()) && CtFormatUtil.hasContent(ct) && ct != 0){
			Double dt = (Double)((Double.parseDouble(bo.getNumberDefects())*10)/ct);
			java.text.DecimalFormat df =new java.text.DecimalFormat("#.00");
			defectDensity= df.format(dt);
		}
		bo.setDefectDensity(changeDf(defectDensity));
		ctKeyDeliverableService.updateAttById("defectDensity", defectDensity, bo.getUniteObjectId());
		
		// String userName = CtUserUtil.getCurrentUserAccountName();
		int numberDefectsCt = ctKeyDeliverableApprovalService.getKeyDeliverableErrorColletionBykey(
				new String[] { "UNITEOBJECTID" }, new String[] { bo.getUniteObjectId() },Long.parseLong(bo.getUniteObjectId()));
		bo.setNumberDefects("" + numberDefectsCt);
		ctKeyDeliverableService.updateAttById("numberDefects", String.valueOf(numberDefectsCt), bo.getUniteObjectId());
		return bo;
	}
	public static String changeDf(String df) {
		if (CtFormatUtil.hasContent(df) && df.equals(".0")) {
			return "0";
		} else if (CtFormatUtil.hasContent(df) && df.startsWith(".")) {
			return "0" + df;
		}
		return df;
	}
	@Override
	public CtKeyDeliverableBasicsBo getKeyDeliverableBasis(Long branchId) throws Exception {
		Wrapper<CtKeyDeliverableBasicsBo> wrapper = new EntityWrapper<CtKeyDeliverableBasicsBo>();
		wrapper.eq("uniteObjectId", branchId);
		wrapper.orderBy("createTime", true);
		List<CtKeyDeliverableBasicsBo> boList = super.selectList(wrapper);
		if (null == boList || boList.size() == 0) {
			CtKeyDeliverableBasicsBo bo = changeBo(branchId);
			super.insert(bo);
			boList.add(bo);
		}
		CtKeyDeliverableBasicsBo bo = boList.get(0);
		return bo;
	}

	// 校验当前人员是否在角色下
	@Override
	public List<Map<String, String>> getPersonLiableList(Long branchId, String type, String query) throws Exception {
		List<Map<String, String>> listUser = new ArrayList<>();
		String docVr = "VR:wt.doc.WTDocument:" + branchId;
		WTDocument changeObject = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
		// 获取库团队角色成员
		WTContained containedbi = (WTContained) changeObject;
		WTContainer wtContainer = containedbi.getContainer();
		ContainerTeamManaged ctm = (ContainerTeamManaged) wtContainer;
		ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam(ctm);
		Vector roleList = containerTeam.getRoles();

		for (Object o : roleList) {
			Role role = (Role) o;
			String dDisplay = role.getDisplay(Locale.CHINA);
			System.out.println("角色显示名称" + dDisplay);
			if ("1".equals(type) && dDisplay.contains("项目管理工程师")) {
				ArrayList list = containerTeam.getAllPrincipalsForTarget(role);
				for (Object objRole : list) {
					if (objRole instanceof WTPrincipalReference) {
						WTPrincipal principal = ((WTPrincipalReference) objRole).getPrincipal();
						if (principal instanceof WTUser) {
							WTUser user = (WTUser) principal;
							String name = user.getName();
							Map<String, String> map = new HashMap<>();
							if (CtFormatUtil.hasContent(query)) {
								if (user.getFullName().contains(query)) {
									map.put("name", name);
									map.put("fullName", user.getFullName());
									// map.put("fullName", user.getFullName()+
									// "(" + name + ")");
									listUser.add(map);
								}
							} else {
								map.put("name", user.getName());
								map.put("fullName", user.getFullName());
								// map.put("fullName", user.getFullName()+ "(" +
								// user.getName() + ")");
								listUser.add(map);
							}

						}
					}
				}
			} else if ("2".equals(type) && dDisplay.contains("PQA")) {
				ArrayList list = containerTeam.getAllPrincipalsForTarget(role);
				for (Object objRole : list) {
					if (objRole instanceof WTPrincipalReference) {
						WTPrincipal principal = ((WTPrincipalReference) objRole).getPrincipal();
						if (principal instanceof WTUser) {
							WTUser user = (WTUser) principal;
							String name = user.getName();
							Map<String, String> map = new HashMap<>();
							if (CtFormatUtil.hasContent(query)) {
								if (user.getFullName().contains(query)) {
									map.put("name", user.getName());
									map.put("fullName", user.getFullName());
									// map.put("fullName", user.getFullName()+
									// "(" + user.getName() + ")");
									listUser.add(map);
								}
							} else {
								map.put("name", user.getName());
								map.put("fullName", user.getFullName());
								// map.put("fullName", user.getFullName()+ "(" +
								// user.getName() + ")");
								listUser.add(map);
							}
						}
					}
				}
			} else if ("3".equals(type) && dDisplay.contains("评审专家")) {
				ArrayList list = containerTeam.getAllPrincipalsForTarget(role);
				for (Object objRole : list) {
					Object principalCm = null;
					if (objRole instanceof WTPrincipalReference) {
						System.out.println("----->6666");
						principalCm = ((WTPrincipalReference) objRole).getPrincipal();
					} else {
						System.out.println("----->7777");
						principalCm = objRole;
					}
					if (principalCm instanceof WTUser) {
						System.out.println("----->8888");
						if (principalCm instanceof WTUser) {
							WTUser user = (WTUser) principalCm;
							String name = user.getName();
							Map<String, String> map = new HashMap<>();
							if (CtFormatUtil.hasContent(query)) {
								if (user.getFullName().contains(query)) {
									map.put("name", user.getName());
									map.put("fullName", user.getFullName());
									// map.put("fullName", user.getFullName()+
									// "(" + user.getName() + ")");
									listUser.add(map);
								}
							} else {
								map.put("name", user.getName());
								map.put("fullName", user.getFullName());
								// map.put("fullName", user.getFullName()+ "(" +
								// user.getName() + ")");
								listUser.add(map);
							}
						} else if (principalCm instanceof WTGroup) {
							WTGroup group = (WTGroup) principalCm;
							System.out.println("group1----->" + group.getName());
							Enumeration enumer = group.members();
							while (enumer.hasMoreElements()) {
								Object enumObj = enumer.nextElement();
								if (enumObj instanceof WTPrincipalReference) {
									System.out.println("1----->2222");
									principalCm = ((WTPrincipalReference) enumObj).getPrincipal();
									WTUser user = (WTUser) principalCm;
									String name = user.getName();
									Map<String, String> map = new HashMap<>();
									if (CtFormatUtil.hasContent(query)) {
										if (user.getFullName().contains(query)) {
											map.put("name", user.getName());
											map.put("fullName", user.getFullName());
											// map.put("fullName",
											// user.getFullName()+ "(" +
											// user.getName() + ")");
											listUser.add(map);
										}
									} else {
										map.put("name", user.getName());
										map.put("fullName", user.getFullName());
										// map.put("fullName",
										// user.getFullName()+
										// "(" + user.getName() + ")");
										listUser.add(map);
									}

								} else if (enumObj instanceof WTUser) {
									WTUser user = ((WTUser) enumObj);
									String name = user.getName();
									Map<String, String> map = new HashMap<>();
									System.out.println("----->3333" + name);
									if (CtFormatUtil.hasContent(query)) {
										if (user.getFullName().contains(query)) {
											map.put("name", user.getName());
											map.put("fullName", user.getFullName());
											// map.put("fullName",
											// user.getFullName()+ "(" +
											// user.getName() + ")");
											listUser.add(map);
										}
									} else {
										map.put("name", user.getName());
										map.put("fullName", user.getFullName());
										// map.put("fullName",
										// user.getFullName()+
										// "(" + user.getName() + ")");
										listUser.add(map);
									}
								}
								System.out.println("----->4444");
							}

						}
					} else if (principalCm instanceof WTGroup) {
						WTGroup group = (WTGroup) principalCm;
						System.out.println("group----->" + group.getName());
						Enumeration enumer = group.members();
						while (enumer.hasMoreElements()) {
							Object enumObj = enumer.nextElement();
							if (enumObj instanceof WTPrincipalReference) {
								System.out.println("----->2222");
								principalCm = ((WTPrincipalReference) enumObj).getPrincipal();
								WTUser user = (WTUser) principalCm;
								String name = user.getName();
								Map<String, String> map = new HashMap<>();
								if (CtFormatUtil.hasContent(query)) {
									if (user.getFullName().contains(query)) {
										map.put("name", user.getName());
										map.put("fullName", user.getFullName());
										// map.put("fullName",
										// user.getFullName()+ "(" +
										// user.getName() + ")");
										listUser.add(map);
									}
								} else {
									map.put("name", user.getName());
									map.put("fullName", user.getFullName());
									// map.put("fullName", user.getFullName()+
									// "(" + user.getName() + ")");
									listUser.add(map);
								}

							} else if (enumObj instanceof WTUser) {
								System.out.println("----->3333");
								WTUser user = ((WTUser) enumObj);
								String name = user.getName();
								Map<String, String> map = new HashMap<>();
								if (CtFormatUtil.hasContent(query)) {
									if (user.getFullName().contains(query)) {
										map.put("name", user.getName());
										map.put("fullName", user.getFullName());
										// map.put("fullName",
										// user.getFullName()+ "(" +
										// user.getName() + ")");
										listUser.add(map);
									}
								} else {
									map.put("name", user.getName());
									map.put("fullName", user.getFullName());
									// map.put("fullName", user.getFullName()+
									// "(" + user.getName() + ")");
									listUser.add(map);
								}
							}
							System.out.println("----->4444");
						}

					}
				}
			}
		}
		return listUser;
	}

	public CtKeyDeliverableBasicsBo changeBo(Long branchId) throws Exception {
		CtKeyDeliverableBasicsBo bo = new CtKeyDeliverableBasicsBo("" + branchId);
		WTDocument doc = null;
		System.out.println("branchId---->"  +  branchId);
		try{
			String docVr = "VR:wt.doc.WTDocument:" + branchId;
			doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
		}catch(Exception e){
			String docVr = "OR:wt.doc.WTDocument:"+branchId;
			doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docVr);
		}
		bo.setDeliveryNumber(doc.getNumber());
		bo.setDeliveryName(doc.getName());
		bo.setDeliveryType(doc.getType());
		IBAUtil ibaUtil1 = new IBAUtil(doc);
		String value = ibaUtil1.getIBAValue("ct_ItemNumber");
		if (CtFormatUtil.hasContent(value)) {
			bo.setProjectNumber(value);
			Project2 project2 = CtProjectUtil.getProjectByNumber(value);
			if(null != project2){
				bo.setProjectName(project2.getName());
			}
			IBAUtil ibaUtil = new IBAUtil(project2);
			String ct_projectPhase = ibaUtil.getIBAValue("Ct_ProjectPhase");
			bo.setProjectPhase(ct_projectPhase);
		}
		WTUser user = (WTUser) doc.getCreator().getObject();
		bo.setProposedPerson(user.getName());

		List<Map<String, String>> engeerList = new CtKeyDeliverableServiceImpl().getPersonLiableList(branchId, "1",
				null);
		if (null != engeerList && engeerList.size() == 1) {
			bo.setProjectManagEngineer(engeerList.get(0).get("fullName"));
		}
		List<Map<String, String>> peaList = new CtKeyDeliverableServiceImpl().getPersonLiableList(branchId, "2", null);
		if (null != peaList && peaList.size() == 1) {
			bo.setPqa(peaList.get(0).get("fullName"));
		}

		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		format.setTimeZone(TimeZoneHelper.getLocalTimeZone());
		bo.setProcessLaunchDate(format.format(doc.getCreateTimestamp()));

		/*
		 * bo.setReviewExplain("asdfs333333");
		 * 
		 * bo.setNumberScore("10");
		 * 
		 * 
		 * bo.setApprovalExplain("werqwrqwerqwerwqr我说谁");
		 */

		return bo;
	}

}
