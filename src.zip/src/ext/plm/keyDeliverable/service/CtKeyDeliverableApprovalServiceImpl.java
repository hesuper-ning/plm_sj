package ext.plm.keyDeliverable.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import ext.plm.keyDeliverable.CtKeyDeliverableHelper;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableApprovalBo;
import ext.plm.keyDeliverable.mapper.CtKeyDeliverableApproValMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import wt.doc.WTDocument;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.session.SessionHelper;

@Service
public class CtKeyDeliverableApprovalServiceImpl
		extends ServiceImpl<CtKeyDeliverableApproValMapper, CtKeyDeliverableApprovalBo>
		implements CtKeyDeliverableApprovalService {

	@Override
	public List<CtKeyDeliverableApprovalBo> getKeyDeliverableErrorColletion(Long branchId) throws Exception {
		Wrapper<CtKeyDeliverableApprovalBo> wrapper = new EntityWrapper<CtKeyDeliverableApprovalBo>();
		wrapper.eq("uniteObjectId", branchId);
		wrapper.orderBy("createTime", true);
		List<CtKeyDeliverableApprovalBo> boList = super.selectList(wrapper);
		List<CtKeyDeliverableApprovalBo> list = new ArrayList<CtKeyDeliverableApprovalBo>();
		for (int i = 0; i < boList.size(); i++) {
			CtKeyDeliverableApprovalBo bo = boList.get(i);
			if (CtFormatUtil.hasContent(bo.getReviewer())) {
				WTUser usre = CtUserUtil.getUserByAccountName(bo.getReviewer());
				bo.setReviewer(usre.getFullName());
			}
			if (CtFormatUtil.hasContent(bo.getProblemConscientiouser())) {
				WTUser usre = CtUserUtil.getUserByAccountName(bo.getProblemConscientiouser());
				if (null != usre) {
					bo.setProblemConscientiouser(usre.getFullName());
				}
			}
			list.add(bo);
		}
		return list;
	}

	@Override
	public void deleteKeyDeliverableErrorColletion(List<String> ids) throws Exception {
		super.deleteBatchIds(ids);

	}

	@Override
	public Boolean saveKeyDeliverableErrorColletion(List<CtKeyDeliverableApprovalBo> entityList) throws Exception {
		return super.insertOrUpdateAllColumnBatch(entityList);
	}

	@Override
	public CtKeyDeliverableApprovalBo updateCtKeyDeliverableApprovalBo(String id, String key, String value)
			throws Exception {
		CtKeyDeliverableApprovalBo bo = super.selectById(id);
		CtCommonUtil.setObjectValue(bo, key, value);
		if(!CtFormatUtil.hasContent(bo.getReviewer())){
			String userName = CtUserUtil.getCurrentUserAccountName();
			bo.setReviewer(userName);
		}
		super.updateById(bo);
		return bo;
	}

	@Override
	public Integer getKeyDeliverableErrorColletionBykey(String[] key, String[] value,Long branchId) throws Exception {
		// TODO Auto-generated method stub
		Wrapper<CtKeyDeliverableApprovalBo> wrapper = new EntityWrapper<CtKeyDeliverableApprovalBo>();
		wrapper.eq("uniteObjectId", branchId);
		for (int i = 0; i < key.length; i++) {
			wrapper.eq(key[i], value[i]);
		}
		List<CtKeyDeliverableApprovalBo> boList = super.selectList(wrapper);
		if (null == boList || boList.size() == 0) {
			return 0;
		}
		return boList.size();
	}
}
