package ext.plm.keyDeliverable.service;

import java.util.List;

import ext.plm.keyDeliverable.bo.CtKeyDeliverableApprovalBo;
import wt.method.RemoteInterface;
@RemoteInterface
public interface CtKeyDeliverableApprovalService {

	/**
	 * 查询S01：基础信息--表3
	 * 
	 * @return
	 * @throws Exception
	 */
	List<CtKeyDeliverableApprovalBo> getKeyDeliverableErrorColletion(Long branchId) throws Exception;

    /**
     * 删除基础信息--表3
     * @param ids
     * @throws Exception
     */
    void deleteKeyDeliverableErrorColletion(List<String> ids) throws Exception;

    /**
     * 保存基础信息--表3
     * @param branchId
     * @throws Exception
     */
    public Boolean saveKeyDeliverableErrorColletion(List<CtKeyDeliverableApprovalBo> entityList) throws Exception;


	/**
	 * 更新
	 * @param id
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
    CtKeyDeliverableApprovalBo updateCtKeyDeliverableApprovalBo(String id, String key, String value) throws Exception;
	
    Integer getKeyDeliverableErrorColletionBykey(String[] key, String[] value,Long branchId) throws Exception;
}
