package ext.plm.keyDeliverable.bo;

import java.util.Date;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import wt.org.WTUser;
import wt.session.SessionHelper;

@TableName("ZKeyDeliverableExecuteTable")
public class CtKeyDeliverableExecuteBo extends CtReportCommonBo {

	private static final long serialVersionUID = -3033786401074593118L;

	@TableField("EVALUATIONPROCESS")
	private String evaluationProcess;// 评价环节	﻿

	@TableField("ASSESSMENTELEMENT")
	private String assessmentElement;// 评价要素					

	@TableField("FIXEDSCORE")
	private String fixedScore;// 分值

	@TableField("SCORE")
	private String score;// 得分

	@TableField("REMARK")
	private String remark;// 备注	


	public String getEvaluationProcess() {
		return evaluationProcess;
	}

	public void setEvaluationProcess(String evaluationProcess) {
		this.evaluationProcess = evaluationProcess;
	}

	public String getAssessmentElement() {
		return assessmentElement;
	}

	public void setAssessmentElement(String assessmentElement) {
		this.assessmentElement = assessmentElement;
	}

	public String getFixedScore() {
		return fixedScore;
	}

	public void setFixedScore(String fixedScore) {
		this.fixedScore = fixedScore;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public CtKeyDeliverableExecuteBo() {
	}

	public CtKeyDeliverableExecuteBo(String uniteObjectId) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
	}

	public CtKeyDeliverableExecuteBo(String uniteObjectId, String id) throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
	}
}
