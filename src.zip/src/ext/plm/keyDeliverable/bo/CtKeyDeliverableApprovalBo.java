package ext.plm.keyDeliverable.bo;

import java.util.Date;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import wt.org.WTUser;
import wt.session.SessionHelper;

@TableName("ZKeyDeliverableApprovalTable")
public class CtKeyDeliverableApprovalBo extends CtReportCommonBo {

	private static final long serialVersionUID = -2753783525629156444L;

	@TableField("REVIEWCOMMENTS")
	private String reviewComments;// 评审意见	﻿

	@TableField("ATTACHMENTNAME")
	private String attachmentName;// 附件					

	@TableField("ATTACHMENTURL")
	private String attachmentUrl;// 附件	
	
	@TableField("REVIEWTYPECOMMENTS")
	private String reviewTypeComments;// 评审意见类型

	@TableField("PALNDEFECT")
	private String palnDefect;// 是否属于方案本身缺陷

	@TableField("REVIEWER")
	private String reviewer;// 评审人
	
	@TableField("OPTIMIZATIONPLAN")
	private String optimizationPlan;// 优化方案
	
	@TableField("EFFECTDESCRIPTION")
	private String effectDescription;// 优化执行效果说明
	
	@TableField("TRANSFERPROBLEM")
	private String transferProblem;// 是否转问题

	
	@TableField("PROBLEMCONSCIENTIOUSER")
	private String problemConscientiouser;// 转问题负责人

	
	@TableField("TECHNOLOGICALPROCESS")
	private String technologicalProcess;// 转问题流程

	
	@TableField("PLANNEDCOMPLETIME")
	private String plannedCompleTime;// 计划完成时间


	public String getReviewComments() {
		return reviewComments;
	}

	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getAttachmentUrl() {
		return attachmentUrl;
	}

	public void setAttachmentUrl(String attachmentUrl) {
		this.attachmentUrl = attachmentUrl;
	}

	public String getReviewTypeComments() {
		return reviewTypeComments;
	}

	public void setReviewTypeComments(String reviewTypeComments) {
		this.reviewTypeComments = reviewTypeComments;
	}

	public String getPalnDefect() {
		return palnDefect;
	}

	public void setPalnDefect(String palnDefect) {
		this.palnDefect = palnDefect;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public String getOptimizationPlan() {
		return optimizationPlan;
	}

	public void setOptimizationPlan(String optimizationPlan) {
		this.optimizationPlan = optimizationPlan;
	}

	public String getEffectDescription() {
		return effectDescription;
	}

	public void setEffectDescription(String effectDescription) {
		this.effectDescription = effectDescription;
	}

	public String getTransferProblem() {
		return transferProblem;
	}

	public void setTransferProblem(String transferProblem) {
		this.transferProblem = transferProblem;
	}

	public String getProblemConscientiouser() {
		return problemConscientiouser;
	}

	public void setProblemConscientiouser(String problemConscientiouser) {
		this.problemConscientiouser = problemConscientiouser;
	}

	public String getTechnologicalProcess() {
		return technologicalProcess;
	}

	public void setTechnologicalProcess(String technologicalProcess) {
		this.technologicalProcess = technologicalProcess;
	}

	public String getPlannedCompleTime() {
		return plannedCompleTime;
	}

	public void setPlannedCompleTime(String plannedCompleTime) {
		this.plannedCompleTime = plannedCompleTime;
	}

	public CtKeyDeliverableApprovalBo() {
	}

	public CtKeyDeliverableApprovalBo(String uniteObjectId) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
	}

	public CtKeyDeliverableApprovalBo(String uniteObjectId, String id) throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
	}
}
