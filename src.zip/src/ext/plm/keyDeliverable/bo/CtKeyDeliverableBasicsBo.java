package ext.plm.keyDeliverable.bo;

import java.util.Date;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import wt.org.WTUser;
import wt.session.SessionHelper;

//交付件bo
@TableName("ZKeyDeliverableBasicTable")
public class CtKeyDeliverableBasicsBo extends CtReportCommonBo {
	
	private static final long serialVersionUID = 7939969579800482899L;
	@TableField("REVIEWTITLE")
	private String reviewTitle;// 评审主题
	@TableField("DELIVERYNUMBER")
	private String deliveryNumber;// 交付件编号
	@TableField("DELIVERYNAME")
	private String deliveryName;// 交付件名称
	@TableField("DELIVERYTYPE")
	private String deliveryType;// 交付件类型
	@TableField("PROJECTNUMBER")
	private String projectNumber;// 项目编号
	@TableField("PROJECTNAME")
	private String projectName;// 项目名称
	@TableField("PROJECTPHASE")
	private String projectPhase;// 项目阶段
	@TableField("BELONGINGPV")
	private String belongingPV;// 所属产品/版本
	@TableField("PROPOSEDPERSON")
	private String proposedPerson;// 拟制人
	@TableField("PROJECTMANAGENGINEER")
	private String projectManagEngineer;// 项目管理工程师
	@TableField("PQA")
	private String pqa;// PQA
	@TableField("PROCESSLAUNCHDATE")
	private String processLaunchDate;// 流程发起日期

	@TableField("REVIEWFORMAT")
	private String reviewFormat;// 评审形式

	@TableField("REVIEWCONCLUSION")
	private String reviewConclusion;// 评审结论
	@TableField("REVIEWEXPLAIN")
	private String reviewExplain;// 说明
	@TableField("REVIEWCHIEFEXAMINER")
	private String reviewChiefExaminer;// 主审人
	@TableField("REVIEAAUDITDATE")
	private String revieAauditDate;// 审核日期

	@TableField("FILENUMBERPAGES")
	private String fileNumberPages;// 文件页数
	@TableField("NUMBERDEFECTS")
	private String numberDefects;// 缺陷数
	@TableField("DEFECTDENSITY")
	private String defectDensity;// 缺陷密度
	@TableField("numberScore")
	private String numberScore;// 得分
	@TableField("EVALUATIONPQA")
	private String evaluationPQA;// PQA
	@TableField("EVALUATIONAUDITDATE")
	private String evaluationAuditDate;// 审核日期
	
	@TableField("APPROVALOPINION")
	private String approvalOpinion;// 批准意见
	@TableField("APPROVALEXPLAIN")
	private String approvalExplain;// 说明
	@TableField("APPROVER")
	private String approver;// 批准人
	@TableField("APPROVALAUDITDATE")
	private String approvalAuditDate;// 审核日期

	public String getReviewTitle() {
		return reviewTitle;
	}

	public void setReviewTitle(String reviewTitle) {
		this.reviewTitle = reviewTitle;
	}

	public String getDeliveryNumber() {
		return deliveryNumber;
	}

	public void setDeliveryNumber(String deliveryNumber) {
		this.deliveryNumber = deliveryNumber;
	}

	public String getDeliveryName() {
		return deliveryName;
	}

	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}

	public String getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	public String getProjectNumber() {
		return projectNumber;
	}

	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectPhase() {
		return projectPhase;
	}

	public void setProjectPhase(String projectPhase) {
		this.projectPhase = projectPhase;
	}

	public String getBelongingPV() {
		return belongingPV;
	}

	public void setBelongingPV(String belongingPV) {
		this.belongingPV = belongingPV;
	}

	public String getProposedPerson() {
		return proposedPerson;
	}

	public void setProposedPerson(String proposedPerson) {
		this.proposedPerson = proposedPerson;
	}

	public String getProjectManagEngineer() {
		return projectManagEngineer;
	}

	public void setProjectManagEngineer(String projectManagEngineer) {
		this.projectManagEngineer = projectManagEngineer;
	}

	public String getPqa() {
		return pqa;
	}

	public void setPqa(String pqa) {
		this.pqa = pqa;
	}

	public String getProcessLaunchDate() {
		return processLaunchDate;
	}

	public void setProcessLaunchDate(String processLaunchDate) {
		this.processLaunchDate = processLaunchDate;
	}

	public String getReviewFormat() {
		return reviewFormat;
	}

	public void setReviewFormat(String reviewFormat) {
		this.reviewFormat = reviewFormat;
	}

	public String getReviewConclusion() {
		return reviewConclusion;
	}

	public void setReviewConclusion(String reviewConclusion) {
		this.reviewConclusion = reviewConclusion;
	}

	public String getReviewExplain() {
		return reviewExplain;
	}

	public void setReviewExplain(String reviewExplain) {
		this.reviewExplain = reviewExplain;
	}

	public String getReviewChiefExaminer() {
		return reviewChiefExaminer;
	}

	public void setReviewChiefExaminer(String reviewChiefExaminer) {
		this.reviewChiefExaminer = reviewChiefExaminer;
	}

	public String getRevieAauditDate() {
		return revieAauditDate;
	}

	public void setRevieAauditDate(String revieAauditDate) {
		this.revieAauditDate = revieAauditDate;
	}

	public String getApprovalOpinion() {
		return approvalOpinion;
	}

	public void setApprovalOpinion(String approvalOpinion) {
		this.approvalOpinion = approvalOpinion;
	}

	public String getApprovalExplain() {
		return approvalExplain;
	}

	public void setApprovalExplain(String approvalExplain) {
		this.approvalExplain = approvalExplain;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getApprovalAuditDate() {
		return approvalAuditDate;
	}

	public void setApprovalAuditDate(String approvalAuditDate) {
		this.approvalAuditDate = approvalAuditDate;
	}

	public String getFileNumberPages() {
		return fileNumberPages;
	}

	public void setFileNumberPages(String fileNumberPages) {
		this.fileNumberPages = fileNumberPages;
	}

	public String getNumberDefects() {
		return numberDefects;
	}

	public void setNumberDefects(String numberDefects) {
		this.numberDefects = numberDefects;
	}

	public String getDefectDensity() {
		return defectDensity;
	}

	public void setDefectDensity(String defectDensity) {
		this.defectDensity = defectDensity;
	}

	public String getNumberScore() {
		return numberScore;
	}

	public void setNumberScore(String numberScore) {
		this.numberScore = numberScore;
	}

	public String getEvaluationPQA() {
		return evaluationPQA;
	}

	public void setEvaluationPQA(String evaluationPQA) {
		this.evaluationPQA = evaluationPQA;
	}

	public String getEvaluationAuditDate() {
		return evaluationAuditDate;
	}

	public void setEvaluationAuditDate(String evaluationAuditDate) {
		this.evaluationAuditDate = evaluationAuditDate;
	}

	public CtKeyDeliverableBasicsBo() {
	}

	public CtKeyDeliverableBasicsBo(String uniteObjectId) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
	}

	public CtKeyDeliverableBasicsBo(String uniteObjectId, String id) throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
	}

}
