package ext.plm.keyDeliverable.bo;

import java.util.Date;
import java.util.UUID;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import wt.org.WTUser;
import wt.session.SessionHelper;

@TableName("ZKeyDeliverableReviewTable")
public class CtKeyDeliverableReviewBo extends CtReportCommonBo {

	private static final long serialVersionUID = -3924928645801846001L;

	@TableField("REVIEWEXPERTS")
	private String reviewExperts;// 评审专家 ﻿

	@TableField("CHIEFEXAMINER")
	private String chiefExaminer;// 是否是主审人

	@TableField("POST")
	private String post;// 职务

	@TableField("DEPARTMENT")
	private String department;// 部门

	@TableField("OPINIONCOUNT")
	private String opinionCount;// 意见提出数

	@TableField("OPINIONSADOPTEDCOUNT")
	private String OpinionsAdoptedCount;// 意见采纳数

	
	public String getReviewExperts() {
		return reviewExperts;
	}

	public void setReviewExperts(String reviewExperts) {
		this.reviewExperts = reviewExperts;
	}

	public String getChiefExaminer() {
		return chiefExaminer;
	}

	public void setChiefExaminer(String chiefExaminer) {
		this.chiefExaminer = chiefExaminer;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getOpinionCount() {
		return opinionCount;
	}

	public void setOpinionCount(String opinionCount) {
		this.opinionCount = opinionCount;
	}

	public String getOpinionsAdoptedCount() {
		return OpinionsAdoptedCount;
	}

	public void setOpinionsAdoptedCount(String opinionsAdoptedCount) {
		OpinionsAdoptedCount = opinionsAdoptedCount;
	}

	public CtKeyDeliverableReviewBo() {
	}

	public CtKeyDeliverableReviewBo(String uniteObjectId) throws Exception {
		this.setId(UUID.randomUUID().toString());
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		this.setChiefExaminer("否");
	}

	public CtKeyDeliverableReviewBo(String uniteObjectId, String id) throws Exception {
		this.setId(id);
		this.setUniteObjectId(uniteObjectId);
		WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
		this.setCreateUser(currentUser.getName());
		this.setCreateTime(new Date());
		this.setModifyUser(currentUser.getName());
		this.setModifyTime(new Date());
		this.setChiefExaminer("否");
	}
}
