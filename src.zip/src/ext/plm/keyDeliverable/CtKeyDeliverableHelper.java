package ext.plm.keyDeliverable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ptc.core.lwc.server.PersistableAdapter;
import com.spire.doc.Document;

import cn.hutool.core.io.FileUtil;
import ext.plm.bean.CtBeanFactory;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableApprovalBo;
import ext.plm.keyDeliverable.mapper.CtKeyDeliverableApproValMapper;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtDownloadUtil;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.inf.container.WTContainer;
import wt.lifecycle.State;
import wt.method.MethodContext;
import wt.org.WTUser;
import wt.pom.WTConnection;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.VersionControlHelper;
public class CtKeyDeliverableHelper {
	static Logger logger = Logger.getLogger(CtKeyDeliverableHelper.class);

	/**
	 * 评审意见数据导入
	 * 
	 * @param branchId
	 * @param file
	 * @throws Exception
	 */
	public static void importKeydeliverable(Long branchId, File file) throws Exception {
		Workbook wb = WorkbookFactory.create(file);
		Sheet sheet = wb.getSheetAt(0);
		int lastRowNum = sheet.getLastRowNum();
		StringBuilder msg = new StringBuilder();

		List<CtKeyDeliverableApprovalBo> ctBoList = new ArrayList<CtKeyDeliverableApprovalBo>();
		for (int i = 1; i <= lastRowNum; i++) {
			CtKeyDeliverableApprovalBo bo = new CtKeyDeliverableApprovalBo(String.valueOf(branchId));
			int rowIndex = i + 1;
			String cell0 = CtExcelReadUtil.getCellValue(sheet, i, 0);
			String cell1 = CtExcelReadUtil.getCellValue(sheet, i, 1);
			String cell2 = CtExcelReadUtil.getCellValue(sheet, i, 2);
			String cell3 = CtExcelReadUtil.getCellValue(sheet, i, 3);
			String cell4 = CtExcelReadUtil.getCellValue(sheet, i, 4);
			/*
			 * String cell5 = CtExcelReadUtil.getCellValue(sheet, i, 5); String
			 * cell6 = CtExcelReadUtil.getCellValue(sheet, i, 6); String cell7 =
			 * CtExcelReadUtil.getCellValue(sheet, i, 7);
			 */
			if (CtFormatUtil.hasContent(cell0)) {
				bo.setReviewComments(cell0.trim());
			}else{
				throw new Exception("评审意见不能为空");
			}
			// 校验评审意见类型
			if (CtFormatUtil.hasContent(cell1)) {
				if (!("问题点".equals(cell1.trim()) || "优化点".equals(cell1.trim()))) {
					msg.append("第" + rowIndex + "行，评审意见类型选择错误！\r\n");
				} else {
					bo.setReviewTypeComments(cell1.trim());
				}
			}else{
				throw new Exception("评审意见类型不能为空");
			}
			// 校验是否属于方案本身缺陷
			if (CtFormatUtil.hasContent(cell2)) {
				if (!(("是".equals(cell2.trim()) || "否".equals(cell2.trim())))) {
					msg.append("第" + rowIndex + "行，是否属于方案本身缺陷选择错误！\r\n");
				} else {
					bo.setPalnDefect(cell2.trim());
				}
			}
			// // 校验优化方案
			// if (CtFormatUtil.hasContent(cell3)) {
			// if (!(("采纳".equals(cell3) || "拒绝".equals(cell3)))) {
			// msg.append("第" + rowIndex + "行，优化方案选择错误！\r\n");
			// } else {
			// bo.setOptimizationPlan(cell3.trim());
			// }
			// }
			String departMent = "222222";
			if (!CtFormatUtil.hasContent(cell4)) {
				msg.append("第" + rowIndex + "行，部门不能为空！\r\n");
			}else{
				departMent = cell4.trim();
			}
			if (CtFormatUtil.hasContent(cell3)) {
//				WTUser usre = CtUserUtil.getUserByAccountName(cell3.trim());
				String fuName = queryUserName(cell3.trim(), departMent);
				if (CtFormatUtil.hasContent(fuName)) {
					bo.setReviewer(fuName);
				} else {
					msg.append("第" + rowIndex + "行，评审人和部门填写错误！\r\n");
				}
			} else {
				msg.append("第" + rowIndex + "行，评审人不能为空！\r\n");
			}

			/*
			 * if (CtFormatUtil.hasContent(cell4)) {
			 * bo.setEffectDescription(cell4.trim()); } // 校验评审意见类型 if
			 * (CtFormatUtil.hasContent(cell5)) { if (!(("是".equals(cell5) ||
			 * "否".equals(cell5)))) { msg.append("第" + rowIndex +
			 * "行，是否转问题选择错误！\r\n"); } else { bo.setTransferProblem(cell5); } }
			 * // 校验评审意见类型 if (CtFormatUtil.hasContent(cell6)) { WTUser usre =
			 * CtUserUtil.getUserByAccountName(cell6.trim()); if (null == usre)
			 * { msg.append("第" + rowIndex + "行，转问题负责人填写错误！\r\n"); } else {
			 * bo.setProblemConscientiouser(cell6.trim()); } } // 校验评审意见类型 if
			 * (CtFormatUtil.hasContent(cell7)) { Date testDate =
			 * CtDateUtil.parseStringToDate(cell7.trim(), "yyyy-MM-dd"); if
			 * (null == testDate) { msg.append("第" + rowIndex +
			 * "行，计划完成时间填写错误！\r\n"); } else { bo.setPlannedCompleTime(cell7); }
			 * }
			 */
			if (null != bo) {
				ctBoList.add(bo);
			}
		}
		// 抛出错误
		if (msg.toString().length() > 0) {
			throw new Exception(msg.toString());
		}
		if (null == ctBoList || ctBoList.size() == 0) {
			throw new Exception("数据为空，无需导入");
		}
		CtKeyDeliverableApproValMapper ctKeyDeliverableApproValMapper = CtBeanFactory.newCtBeanFactory()
				.getBean(CtKeyDeliverableApproValMapper.class);
		for (int i = 0; i < ctBoList.size(); i++) {
			CtKeyDeliverableApprovalBo bo = ctBoList.get(i);
			// String userName = CtUserUtil.getCurrentUserAccountName();
			// bo.setReviewer(userName);
			ctKeyDeliverableApproValMapper.insert(bo);
		}
	}

	public static String queryUserName(String fuName, String department) throws Exception {
		// List<Map<String, String>> list = new ArrayList<>();
		MethodContext context = MethodContext.getContext();
		WTConnection connection = (WTConnection) context.getConnection();
		PreparedStatement statement = null;
		try {
			StringBuilder sql = new StringBuilder();
			// sql.append("SELECT name,loginName,departmentName FROM ZHrPerson
			// WHERE NAME = ?");
			sql.append(
					" SELECT name,loginName,departmentName FROM ZHrPerson WHERE NAME = ? AND DEPARTMENTNAME LIKE ? ");
			System.out.println(">>>param fuName==" + fuName + "<---->" + department);
			System.out.println(">>>queryPcnNumber sql==" + sql.toString());
			statement = connection.prepareStatement(sql.toString());
			statement.setString(1, fuName);
			statement.setString(2, "%" + department + "%");
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				// String name = rs.getString(1);
				String loginName = rs.getString(2);
				// String departmentName = rs.getString(3);
				// Map<String, String> map = new HashMap<>();
				// map.put("name", loginName);

				// list.add(map);
				return loginName;
			}
		} catch (Exception var12) {
			logger.error("导入评审账号异常：" + var12);
			var12.printStackTrace();
			throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
		} finally {
			if (statement != null) {
				statement.close();
			}
			connection.getConnection().commit();
			if (connection != null && connection.isActive()) {
				connection.release();
			}
		}
		return null;
	}

	public static void updateTechnologicalProcessbyId(String id, String linkUrl, String attachmentUrl)
			throws Exception {
		CtKeyDeliverableApproValMapper ctKeyDeliverableApproValMapper = CtBeanFactory.newCtBeanFactory()
				.getBean(CtKeyDeliverableApproValMapper.class);
		CtKeyDeliverableApprovalBo bo = ctKeyDeliverableApproValMapper.selectById(id);
		bo.setTechnologicalProcess(linkUrl);
		bo.setAttachmentUrl(attachmentUrl);
		ctKeyDeliverableApproValMapper.updateById(bo);
	}

	public static CtKeyDeliverableApprovalBo getApprovalbyId(String id) throws Exception {
		CtKeyDeliverableApproValMapper ctKeyDeliverableApproValMapper = CtBeanFactory.newCtBeanFactory()
				.getBean(CtKeyDeliverableApproValMapper.class);
		CtKeyDeliverableApprovalBo bo = ctKeyDeliverableApproValMapper.selectById(id);
		return bo;
	}

	/**
	 * 创建
	 * 
	 * @param document
	 * @param createUser
	 * @throws Exception
	 */
	public static void createProblemDocument(WTDocument document, WTUser createUser, String id) throws Exception {
		String branchId = document.getBranchIdentifier() + "";

		// 创建停用追踪文档
		WTDocument newDoc = new WTDocument();
		String docNumber = document.getNumber();
		WTContainer obj = document.getContainer();

		// 开始创建文档
		PersistableAdapter persistableAdapter = new PersistableAdapter("com.fhsj.Doc_wtgzb", null, null);
		persistableAdapter.load("name", "containerReference", "folder.id", "iterationInfo.creator",
				"iterationInfo.modifier", "state.state");
		persistableAdapter.set("name", docNumber);
		persistableAdapter.set("containerReference", obj);
		persistableAdapter.set("folder.id", obj.getDefaultCabinet());
		persistableAdapter.set("iterationInfo.creator", createUser);
		persistableAdapter.set("iterationInfo.modifier", createUser);
		// persistableAdapter.set("state.state", State.RELEASED);
		persistableAdapter.set("state.state", State.toState("tobesolved"));

		newDoc = (WTDocument) persistableAdapter.apply();
		newDoc = (WTDocument) PersistenceHelper.manager.save(newDoc);
		String mark = "系统自动创建 – 转问题流程文档编号" + docNumber;
		VersionControlHelper.setNote(newDoc, mark);
		PersistenceServerHelper.manager.update(newDoc);
		// 设置修改人
		CtWTObjectUtil.setModifier(newDoc, createUser);

		// 设置IBA属性“续证/退市申请表编号”
		newDoc = (WTDocument) PersistenceHelper.manager.refresh(newDoc);
		IBAUtil ibaUtil = new IBAUtil(newDoc);
		ibaUtil.setIBAValue("ct_RenewalDelistingApplicationFormNumber", docNumber);
		ibaUtil.updateIBAHolder(newDoc);
		String newDocNumber = newDoc.getNumber();
		String newDocState = newDoc.getLifeCycleState().getDisplay(Locale.CHINA);
		// 获取跳转链接
		String url = CtCommonUtil.getURL(newDoc, newDoc.getName());

		CtKeyDeliverableApproValMapper ctKeyDeliverableApproValMapper = CtBeanFactory.newCtBeanFactory()
				.getBean(CtKeyDeliverableApproValMapper.class);

		CtKeyDeliverableApprovalBo bo = ctKeyDeliverableApproValMapper.selectById(id);
		bo.setTechnologicalProcess(url);
		ctKeyDeliverableApproValMapper.updateById(bo);

		// String docUrl = CtPcbApplyLogic.uploadFiles(file, branchId,
		// tetx_name, node);// 获取显示至前端的附件链接
		/*
		 * //查询"是否退市停用"为是的数据,设置表单数据:文档编号和状态 //获取成品物料信息
		 * List<CtRecertfOrEofFinishedItemBo> finishedItemBos =
		 * (List<CtRecertfOrEofFinishedItemBo>)
		 * beanService.doMethod(CtCertificationServiceImpl.class,
		 * "getFinishedItemInfo", strings); for(CtRecertfOrEofFinishedItemBo bo
		 * : finishedItemBos){ if("是".equals(bo.getIsDelist())){
		 * certificationMapper.updateAttById("ZRecertfOrEofFinishedItem",
		 * bo.getId()+"", "stopUsingDocNumber", newDocNumber);
		 * certificationMapper.updateAttById("ZRecertfOrEofFinishedItem",
		 * bo.getId()+"", "stopUsingDocState", newDocState); } }
		 */

	}

	private static File outFile(ApplicationData appData, String filepath) throws Exception {
		File file = null;
		OutputStream os = null;
		InputStream is = null;
		WTUser curUser = null;
		try {
			curUser = (WTUser) SessionHelper.manager.getPrincipal();
			SessionHelper.manager.setAdministrator();
			// 删除文件夹下超过一天的文件
			// CtDownloadUtil.deleteFileByTime(folder, 1 * 24 * 3600 * 1000);
			// recursiveDeleteFilesOlderThanNDays(1 * 24 * 3600 * 1000, cFold);

			// 如果不指定文件名，将用主内容的文件名
			// String fileName = appData.getFileName();
			is = ContentServerHelper.service.findContentStream(appData);
			if (is != null) {
				// String filepath = folder.getAbsolutePath() + File.separator +
				// fileName;
				// String templateFolder = CtCommonUtil.getWTHomePath() +
				// File.separator;
				System.out.println("filepath---------------->" + filepath);
				file = new File(filepath);
				if (file.exists()) {
					// 已经存在的文件，删除后重新创建
					CtDownloadUtil.deleteFile(file);
				} else {
					file.createNewFile();
				}
				os = new FileOutputStream(file);
				int byteread = 0;
				byte[] buffer = new byte[8192];
				while ((byteread = is.read(buffer, 0, 8192)) != -1) {
					os.write(buffer, 0, byteread);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (curUser != null) {
				try {
					SessionHelper.manager.setPrincipal(curUser.getName());
				} catch (WTException e) {
					e.printStackTrace();
				}
			}
			try {
				if (os != null) {
					os.close();
				}
				if (is != null) {
					is.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return file;
	}

	public static int getpageCont(WTDocument doc) throws Exception {
		File file = null;
		try {
			QueryResult qr = ContentHelper.service.getContentsByRole(doc, ContentRoleType.PRIMARY);
			while (qr != null && qr.hasMoreElements()) {
				ContentItem item = (ContentItem) qr.nextElement();
				if (null == item) {
					continue;
				}
				if (item instanceof ApplicationData) {
					ApplicationData appData = (ApplicationData) item;
					String appDataFileName = appData.getFileName();
					/*
					 * System.out.println("appDataFileName---------------->" +
					 * appDataFileName); String filepath =
					 * CtCommonUtil.getWTHomePath() + File.separator + "tmp" +
					 * File.separator + "keyd" + File.separator +
					 * appDataFileName;
					 * System.out.println("1filepath---------------->" +
					 * filepath);
					 */
					WTProperties wtproperty = WTProperties.getLocalProperties();
					String filePath = wtproperty.getProperty("wt.home") + File.separator + "tmp" + File.separator
							+ "keyd" + File.separator + System.currentTimeMillis() + appDataFileName;// 临时路经
					System.out.println("filepath1---------------->" + filePath);
					file = outFile(appData, filePath);

					int ct = getPageContByDocument(filePath);
					System.out.println("docpage---------->" + ct);
					if (ct == 0) {
						ct = getPageContByPDDocument(filePath);
						System.out.println("pdDocpage---------->" + ct);
					}
					if (ct == 0) {
						ct = getPageContByExcel(filePath);
						System.out.println("pdExcel---------->" + ct);
					}

					return ct;
				}
			}
		} catch (Exception e) {

		} finally {
			// CtDownloadUtil.deleteFile(file);
		}
		return 0;
	}

	public static Integer getPageContByExcel(String url) {
		try {
			InputStream is = FileUtil.getInputStream(url);
			Workbook workbook = new XSSFWorkbook(is);
			Sheet sheet = workbook.getSheetAt(0);
			int lenth = sheet.getLastRowNum();
			return lenth;
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return 0;
	}

	public static Integer getPageContByDocument(String url) {
		try {
			Document doc = new Document();
			doc.loadFromFile(url);
			int pagecount = doc.getPageCount();
			return pagecount;
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return 0;
	}

	public static Integer getPageContByPDDocument(String url) {
		try {
			PDDocument p = PDDocument.load(new File(url));
			return p.getNumberOfPages();
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return 0;
	}

	public static void main(String[] args) throws Exception {
		// FileInputStream fis = new FileInputStream(new
		// File("E:\\样品确认流程待修改3-4.docx"));
		// XWPFDocument document = new XWPFDocument(fis);
		// document.getProperties();
		// int pages =
		// document.getProperties().getExtendedProperties().getUnderlyingProperties().getPages();
		// System.out.println("////" + pages);
		//
		//
		// int pageCount = 0;
		// for(XWPFParagraph p : document.getParagraphs()){
		// String s = p.getText();
		// if(s.contains("page")){
		// pageCount++;
		// }
		// }
		// System.out.println("////" + pageCount);

		Document doc = new Document();
		doc.loadFromFile("E:\\样品确认流程待修改3-4.docx");
		int pagecount = doc.getPageCount();
		System.out.println(String.format("该Word共有 %d 页", pagecount));

		PDDocument p = PDDocument.load(new File("E:\\SOLIDWORKS 品牌介绍1.pdf"));
		System.out.println(String.format("该PDF共有 %d 页", p.getNumberOfPages()));
	}
}
