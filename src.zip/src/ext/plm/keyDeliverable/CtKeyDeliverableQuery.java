package ext.plm.keyDeliverable;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ext.plm.common.CtConstant;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableApprovalBo;
import ext.plm.keyDeliverable.bo.CtKeyDeliverableReviewBo;
import wt.method.MethodContext;
import wt.pom.WTConnection;
import wt.util.WTException;

public class CtKeyDeliverableQuery {

	/**
	 * 获取单个属性值（用于必填验证）
	 *
	 * @param certfId
	 *            变更单id
	 * @param attKey
	 *            属性内部值
	 */
	public String getAttributeValue(String uniteId, String attKey) throws Exception {

		String attValue = "";
		MethodContext context = MethodContext.getContext();
		WTConnection connection = (WTConnection) context.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {

			String sql = "SELECT * FROM ZKEYDELIVERABLEBASICTABLE WHERE UNITEOBJECTID=?  ";
			statement = connection.prepareStatement(sql);
			// statement.setString(1, attKey);
			// statement.setString(2, tableName);
			statement.setString(1, uniteId);
			resultSet = statement.executeQuery();

			// 脏数据预防
			if (resultSet.getRow() > 1) {
				System.out.println(">>>数据库异常，存在脏数据，存在多条记录,attKey='" + attKey + ">>certfId=" + uniteId);
				throw new WTException("数据库异常，存在脏数据，attKey='" + attKey + "'存在多条记录，本应该只有一条！请联系管理员！");
			}

			while (resultSet.next()) {
				attValue = resultSet.getString(attKey);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
		} finally {
			if (statement != null)
				statement.close();
			// connection.getConnection().commit();
			if (connection != null && connection.isActive())
				connection.release();
		}

		return attValue;
	}

	/**
	 * 获取单个属性值（用于必填验证）
	 *
	 * @param certfId
	 *            变更单id
	 * @param attKey
	 *            属性内部值
	 */
	public List<CtKeyDeliverableReviewBo> getAttributeValueExtra(String uniteId) throws Exception {
		List<CtKeyDeliverableReviewBo> list = new ArrayList<CtKeyDeliverableReviewBo>();
		MethodContext context = MethodContext.getContext();
		WTConnection connection = (WTConnection) context.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			String sql = "SELECT * FROM ZKeyDeliverableReviewTable WHERE UNITEOBJECTID=?  ";
			statement = connection.prepareStatement(sql);
			statement.setString(1, uniteId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				CtKeyDeliverableReviewBo bo = new CtKeyDeliverableReviewBo();
				bo.setReviewExperts(resultSet.getString("reviewExperts"));
				bo.setChiefExaminer(resultSet.getString("chiefExaminer"));
				list.add(bo);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
		} finally {
			if (statement != null)
				statement.close();
			if (connection != null && connection.isActive())
				connection.release();
		}

		return list;
	}

	/**
	 * 获取评审意见及改善方案纠正项
	 * 
	 * @param uniteId
	 * @return
	 * @throws Exception
	 */
	public List<String> getAttributeApprovalValue(String uniteId, String attKey) throws Exception {
		List<String> list = new ArrayList<String>();
		MethodContext context = MethodContext.getContext();
		WTConnection connection = (WTConnection) context.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			String sql = "SELECT * FROM ZKeyDeliverableApprovalTable WHERE UNITEOBJECTID=? order by createTime ";
			statement = connection.prepareStatement(sql);
			statement.setString(1, uniteId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				String attKeyStr = resultSet.getString(attKey);
				list.add(attKeyStr);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
		} finally {
			if (statement != null)
				statement.close();
			if (connection != null && connection.isActive())
				connection.release();
		}
		return list;
	}

	public List<CtKeyDeliverableApprovalBo> getAttributeApprovalValues(String uniteId) throws Exception {
		List<CtKeyDeliverableApprovalBo> list = new ArrayList<CtKeyDeliverableApprovalBo>();
		MethodContext context = MethodContext.getContext();
		WTConnection connection = (WTConnection) context.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			String sql = "SELECT * FROM ZKeyDeliverableApprovalTable WHERE UNITEOBJECTID=? order by createTime ";
			statement = connection.prepareStatement(sql);
			statement.setString(1, uniteId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				CtKeyDeliverableApprovalBo bo = new CtKeyDeliverableApprovalBo();
				String reviewComments = resultSet.getString("reviewComments");
				bo.setReviewComments(reviewComments);
				String attachmentName = resultSet.getString("attachmentName");
				bo.setAttachmentName(attachmentName);
				String attachmentUrl = resultSet.getString("attachmentUrl");
				bo.setAttachmentUrl(attachmentUrl);
				String reviewTypeComments = resultSet.getString("reviewTypeComments");
				bo.setReviewTypeComments(reviewTypeComments);
				String palnDefect = resultSet.getString("palnDefect");
				bo.setPalnDefect(palnDefect);
				String reviewer = resultSet.getString("reviewer");
				bo.setReviewer(reviewer);
				String optimizationPlan = resultSet.getString("optimizationPlan");
				bo.setOptimizationPlan(optimizationPlan);
				String effectDescription = resultSet.getString("effectDescription");
				bo.setEffectDescription(effectDescription);
				String transferProblem = resultSet.getString("transferProblem");
				bo.setTransferProblem(transferProblem);
				String problemConscientiouser = resultSet.getString("problemConscientiouser");
				bo.setProblemConscientiouser(problemConscientiouser);
				String technologicalProcess = resultSet.getString("technologicalProcess");
				bo.setTechnologicalProcess(technologicalProcess);
				String plannedCompleTime = resultSet.getString("plannedCompleTime");
				bo.setPlannedCompleTime(plannedCompleTime);
				list.add(bo);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
		} finally {
			if (statement != null)
				statement.close();
			if (connection != null && connection.isActive())
				connection.release();
		}
		return list;
	}
	/**
	 * 获取评审意见及改善方案纠正项
	 * 
	 * @param uniteId
	 * @return
	 * @throws Exception
	 */
	public List<String> getAttributeExecuteValues(String uniteId, String attKey) throws Exception {
		List<String> list = new ArrayList<String>();
		MethodContext context = MethodContext.getContext();
		WTConnection connection = (WTConnection) context.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			String sql = "SELECT * FROM ZKeyDeliverableExecuteTable WHERE UNITEOBJECTID=?  ";
			statement = connection.prepareStatement(sql);
			statement.setString(1, uniteId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				// CtKeyDeliverableExecuteBo bo = new
				// CtKeyDeliverableExecuteBo();
				String attKeyValues = resultSet.getString(attKey);
				list.add(attKeyValues);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
		} finally {
			if (statement != null)
				statement.close();
			if (connection != null && connection.isActive())
				connection.release();
		}
		return list;
	}
}
