package ext.plm.keyDeliverable.config;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import ext.plm.certification.config.CtCertfProperties;
import ext.plm.util.CtFormatUtil;
import wt.log4j.LogR;

public class CtKeyDeliverableProperties {
	private static final Logger logger = LogR.getLogger(CtKeyDeliverableProperties.class.getName());

	//活动名称与活动Key的对照关系
	public static Properties activityKeyMap = new Properties();

	//活动表单必填字段与活动Key的对照关系
	public static Properties formRequiredAttMap = new Properties();

	//表单属性key与显示名称的对应关系
	static Properties attDisplayMap = new Properties();

	static {
		try {
			activityKeyMap.load(new InputStreamReader(
					CtKeyDeliverableProperties.class.getResourceAsStream("keyDeliverableActivityKeyMap.properties"), "UTF-8"));
			formRequiredAttMap.load(new InputStreamReader(
					CtKeyDeliverableProperties.class.getResourceAsStream("keyDeliverableRequiredMap.properties"), "UTF-8"));
			attDisplayMap.load(new InputStreamReader(
					CtKeyDeliverableProperties.class.getResourceAsStream("keyDeliverableFormAttDisplayMap.properties"),"UTF-8"));
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * 根据活动节点名称获得activityKey
	 * 
	 * @param activityName
	 */
	public static String getActivityKey(String activityName) throws Exception {
		Properties activityKeyMap = new Properties();
		activityKeyMap.load(new InputStreamReader(
				CtKeyDeliverableProperties.class.getResourceAsStream("keyDeliverableActivityKeyMap.properties"),
				StandardCharsets.UTF_8));
		String activityKey = activityKeyMap.getProperty(activityName);
		if (!CtFormatUtil.hasContent(activityKey)) {
			activityKey = "";
		}
		System.out.println("activityKey-------------->"+ activityName + "<---->" + activityKey);
		return activityKey;
	}
	
	/**
	 * 工作流程任务表单，根据活动key查找表单必填字段
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String getRequiredAtt(String key) throws Exception{
		String attStr = formRequiredAttMap.getProperty(key);
		if(!CtFormatUtil.hasContent(attStr)) {
			attStr = "";
		}

		return attStr;
	}

	/**
	 * 获取活动名称
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String getActivityNodeName(String key) throws Exception{
		String activityNodeName =  activityKeyMap.getProperty(key);
		if(!CtFormatUtil.hasContent(activityNodeName)) {
			activityNodeName="";
		}
		return activityNodeName;
	}

	/**
	 * 获取属性的显示名称
	 * @param attKey
	 */
	public static String getAttDisplayName(String attKey) throws Exception{
		return attDisplayMap.getProperty(attKey);
	}
	
	/**
	 * 工作流程任务表单，根据活动key查找表单必填字段
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static List<String> getRequiredAtts(String key) throws Exception{
		List<String> result = new ArrayList<String>();
		String attStr = formRequiredAttMap.getProperty(key);
		if(CtFormatUtil.hasContent(attStr)) {
			String[] requiredAtts = attStr.split(",");
			for(String attKey: requiredAtts) {
				result.add(attKey);
			}
		}

		return result;
	}
}
