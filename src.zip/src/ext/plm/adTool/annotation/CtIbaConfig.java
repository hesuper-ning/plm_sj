package ext.plm.adTool.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface CtIbaConfig {
	/**
	 * IBA属性内部名称
	 */
	public String name();

	public boolean isMultivalued() default false;
}