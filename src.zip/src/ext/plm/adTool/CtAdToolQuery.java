package ext.plm.adTool;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.adTool.annotation.CtCondition;
import ext.plm.adTool.bo.CtAdToolParamsBo;
import ext.plm.adTool.bo.CtCentralLibraryBo;
import ext.plm.adTool.bo.CtCentralLibraryParamsBo;
import ext.plm.adTool.bo.CtSubstituteParemBo;
import ext.plm.adTool.config.CtAdToolConnectionUtil;
import ext.plm.adTool.config.CtAdToolProperties;
import ext.plm.adTool.mapper.CtAdToolMapper;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.util.CtVersionUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.folder.SubFolder;
import wt.inf.container.WTContainer;
import wt.pds.StatementSpec;
import wt.query.*;
import wt.util.WTException;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.sql.*;
import java.util.Date;
import java.util.*;

@Repository
@SuppressWarnings("all")
public class CtAdToolQuery extends ServiceImpl<CtAdToolMapper, CtCentralLibraryBo> {

    @Resource
    private CtAdToolMapper ctAdToolMapper;

    public CtAdToolMapper  initMapper() {
        if (ctAdToolMapper == null) {
            System.out.println("ctAdToolMapper == null，从BeanFactory中获取Bean！");
            ctAdToolMapper = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolMapper.class);
        }
        return ctAdToolMapper;
    }

    /**
     * 添加数据
     * @param bo BO对象
     * @param <T> bo对象
     * @return 影响行数
     * @throws Exception
     */
    public <T> Integer addDataByBo(T bo) throws Exception {
        if(bo == null) throw new Exception("Bo对象不能为空！");

        Connection connection = null;

        int count = 0;
        // 用于存储数据库字段值
        List<String> columnList = new ArrayList<>();
        // 用于存储占位符的值
        List<Object> valueList = new ArrayList<>();
        // 用于存储占位符
        List<String> placeholderList = new ArrayList<>();

        PreparedStatement statement = null;
        try {
            connection = CtAdToolConnectionUtil.get();
            Class<?> boClass = bo.getClass();
            TableName tableName = boClass.getAnnotation(TableName.class);
            String tableNameStr = null;
            if (tableName != null) {
                tableNameStr = tableName.value();
            } else {
                Field field = boClass.getDeclaredField("tableName");
                field.setAccessible(true);
                Object obj = field.get(bo);
                if (obj != null) {
                    tableNameStr = obj.toString();
                }
            }

            if(StringUtils.isEmpty(tableNameStr)){
                throw new Exception("未指定表名，不执行添加操作！");
            }

            Field[] declaredFields = boClass.getDeclaredFields();
            for (Field field : declaredFields) {
                TableField tableField = field.getAnnotation(TableField.class);
                // 数据库字段名
                String column = null;
                if (tableField != null) {
                    column = tableField.value();
                } else {
                    TableId tableId = field.getAnnotation(TableId.class);
                    if (tableId != null) {
                        column = tableId.value();
                    }
                }

                if (StringUtils.isEmpty(column)) continue;

                field.setAccessible(true);
                Object obj = field.get(bo);
                if(obj != null){
                    columnList.add(column);
                    valueList.add(obj);
                    placeholderList.add("?");
                }
            }

            String keyStr = StringUtils.join(columnList, ",");
            String placeholderStr = StringUtils.join(placeholderList, ",");
            String sql = "insert into "+ tableNameStr +"(" + keyStr + ") values (" + placeholderStr + ")";

            String isOpen = CtAdToolProperties.getInstance().getStringValue("open.sql.print");
            if ("true".equals(isOpen)) {
                System.out.println(CtAdToolQuery.class.getName() +  " 添加SQL >>>>>> " + sql);
                System.out.println(CtAdToolQuery.class.getName() +  " 保存数据 >>>>>> " + JSONObject.toJSONString(valueList));
            }

            statement = connection.prepareStatement(sql);
            int index = 1;
            for(Object value : valueList){
                if (value instanceof String){
                    statement.setString(index, value.toString());
                }else if (value instanceof Date) {
                    Date tempDate = (Date) value;
                    statement.setDate(index, new java.sql.Date(tempDate.getTime()));
                }else if (value instanceof Long){
                    statement.setLong(index, (Long)value);
                } else {
                    statement.setObject(index, value);
                }
                index++;
            }
            count = statement.executeUpdate();
            connection.commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (connection != null) connection.rollback();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null) statement.close();
            if (connection != null) CtAdToolConnectionUtil.backConn(connection);
        }

        return count;
    }

    /**
     * 条件更新数据
     * @param bo BO对象
     * @param whereColumn 根据哪个字段更新
     * @return 影响行数
     * @throws Exception
     */
    public <T> Integer updateDataByBo(T bo, String whereColumn) throws Exception{
        if(bo == null) throw new Exception("Bo对象不能为空！");
        Integer count = 0;

        Connection connection = null;

        // 用于存对象中的ID值
        String condition = null;
        // 用于存储数据库字段值
        List<String> columnList = new ArrayList<>();
        // 用于存储占位符的值
        List<Object> valueList = new ArrayList<>();

        PreparedStatement statement = null;
        try {
            connection = CtAdToolConnectionUtil.get();
            Class<?> boClass = bo.getClass();
            TableName tableName = boClass.getAnnotation(TableName.class);
            String tableNameStr = null;
            if (tableName != null) {
                tableNameStr = tableName.value();
            } else {
                Field field = boClass.getDeclaredField("tableName");
                field.setAccessible(true);
                Object obj = field.get(bo);
                if (obj != null) {
                    tableNameStr = obj.toString();
                }
            }

            if(StringUtils.isEmpty(tableNameStr)){
                throw new Exception("未指定表名，不执行查询操作！");
            }

            Field[] declaredFields = boClass.getDeclaredFields();
            boolean isId = false;
            for (Field field : declaredFields) {
                TableField tableField = field.getAnnotation(TableField.class);
                // 数据库字段名
                String column = null;
                if (tableField != null) {
                    column = tableField.value();
                    isId = false;
                } else {
                    TableId tableId = field.getAnnotation(TableId.class);
                    if (tableId != null) {
                        column = tableId.value();
                        isId = true;
                    }
                }

                if (StringUtils.isEmpty(column)) continue;

                field.setAccessible(true);
                Object obj = field.get(bo);
                if (obj != null) {
                    if(column.equals(whereColumn)){
                        condition = obj.toString();
                    } else if (!isId){
                        columnList.add(column + "=?");
                        valueList.add(obj);
                    }
                }
            }
            if(StringUtils.isEmpty(condition)){
                throw new Exception("更新数据的条件" + whereColumn + "不能为空！");
            }

            String keyStr = StringUtils.join(columnList, ",");
            String sql = "update " + tableNameStr + " set " + keyStr + " where " + whereColumn + "=?";

            String isOpen = CtAdToolProperties.getInstance().getStringValue("open.sql.print");
            if ("true".equals(isOpen)) {
                System.out.println(CtAdToolQuery.class.getName() +  " 更新SQL >>>>>> " + sql);
                System.out.println(CtAdToolQuery.class.getName() +  " 更新数据 >>>>>> " + JSONObject.toJSONString(valueList));
                System.out.println(CtAdToolQuery.class.getName() +  " 条件参数 >>>>>> " + condition);
            }

            statement = connection.prepareStatement(sql);
            int index = 1;
            for(Object value : valueList){
                if (value instanceof String) {
                    statement.setString(index, value.toString());
                }else if (value instanceof Date){
                    Date tempDate = (Date) value;
                    statement.setDate(index, new java.sql.Date(tempDate.getTime()));
                }else {
                    statement.setObject(index, value);
                }
                index++;
            }
            statement.setString(index, condition);
            count = statement.executeUpdate();

            if (count > 0) {
                connection.commit();
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (connection != null) connection.rollback();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null) statement.close();
            if (connection != null) CtAdToolConnectionUtil.backConn(connection);
        }
        return count;
    }

    /**
     * 根据条件删除数据
     * @param bo BO对象
     * @param whereColumn 根据哪个字段更新
     * @return 影响行数
     * @throws Exception
     */
    public void deleteDataByParamsBo(Object paramsBo) throws Exception{
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = CtAdToolConnectionUtil.get();
            Class<?> paramsBoClass = paramsBo.getClass();
            TableName tableName = paramsBoClass.getAnnotation(TableName.class);
            String tableNameStr = null;
            if (tableName != null) {
                tableNameStr = tableName.value();
            } else {
                Field field = paramsBo.getClass().getDeclaredField("tableName");
                field.setAccessible(true);
                Object obj = field.get(paramsBo);
                if (obj != null) {
                    tableNameStr = obj.toString();
                }
            }

            if(StringUtils.isEmpty(tableNameStr)){
                throw new Exception("未指定表名，不执行查询操作！");
            }

            // 获取查询的参数
            List<String> conditionSqlList = new ArrayList<>();
            List<Object> paramsValueList = new ArrayList<>();
            Field[] declaredFields = paramsBoClass.getDeclaredFields();
            for (Field field : declaredFields) {
                TableField tableField = field.getAnnotation(TableField.class);
                // 数据库字段名
                String column = null;
                if (tableField != null) {
                    column = tableField.value();
                } else {
                    TableId tableId = field.getAnnotation(TableId.class);
                    if (tableId != null) {
                        column = tableId.value();
                    }
                }
                if (StringUtils.isEmpty(column)) continue;

                CtCondition ctCondition = field.getAnnotation(CtCondition.class);
                if (ctCondition == null) continue;

                field.setAccessible(true);
                Object obj = field.get(paramsBo);
                if (obj != null) {
                    String condition = ctCondition.condition();
                    if (obj instanceof List) {
                        List list = (List) obj;
                        if (list.size() > 0) {
                            String key = "";
                            if ("like".equalsIgnoreCase(condition)) {
                                for (int i = 0; i < list.size(); i++) {
                                    key += " or " + column + " like lower('%" + list.get(i).toString() + "%') or " + column + " like Upper('%" + list.get(i).toString() + "%') ";
                                }
                                key = "(" + key.substring(4) + ")";
                            } else {
                                for (int i = 0; i < list.size(); i++) {
                                    key += ",?";
                                    paramsValueList.add(list.get(i));
                                }
                                key = column + " in (" + key.substring(1) + ")";
                            }
                            conditionSqlList.add(key);
                        }
                    } else {
                        conditionSqlList.add(column + ctCondition.condition() + "?");
                        if ("like".equalsIgnoreCase(condition)) {
                            paramsValueList.add("%" + obj.toString() + "%");
                        } else {
                            paramsValueList.add(obj);
                        }
                    }
                }
            }

            String sql = "delete from " + tableNameStr;
            if (CollectionUtils.isNotEmpty(conditionSqlList)) {
                sql += " where " + StringUtils.join(conditionSqlList, " and ");
            } else {
                throw new Exception("删除表【" + tableNameStr + "】数据时未指定删除条件，不做删除整个表数据的操作！" );
            }

            statement = connection.prepareStatement(sql);
            if (CollectionUtils.isNotEmpty(paramsValueList)) {
                int index = 1;
                for (Object value : paramsValueList) {
                    if (value instanceof String) {
                        statement.setString(index, value.toString());
                    }else if (value instanceof Date){
                        Date tempDate = (Date) value;
                        statement.setDate(index, new java.sql.Date(tempDate.getTime()));
                    }else {
                        statement.setObject(index, value);
                    }
                    index++;
                }
            }
            int affectCout = statement.executeUpdate();
            if (affectCout > 0) {
                connection.commit();
            }

            String isOpen = CtAdToolProperties.getInstance().getStringValue("open.sql.print");
            if ("true".equals(isOpen)) {
                System.out.println(CtAdToolQuery.class.getName() +  " 删除SQL >>>>>> " + sql);
                System.out.println(CtAdToolQuery.class.getName() +  " 删除参数 >>>>>> " + JSONObject.toJSONString(paramsValueList));
                System.out.println(CtAdToolQuery.class.getName() +  " 删除条数 >>>>>> " + affectCout);
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (connection != null) connection.rollback();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null) statement.close();
            if (connection != null) CtAdToolConnectionUtil.backConn(connection);
        }
    }

    /**
     * 根据参数BO查询数据
     * @param paramsBo 参数BO对象
     * @param boClazz 将结果集装载的目标BO
     * @return 影响行数
     * @throws Exception
     */
    public <T> List<T> queryDataByParamsBo(Object paramsBo, Class<T> boClazz) throws Exception{
        return queryDataByParamsBo(paramsBo, boClazz, true);
    }

    /**
     * 根据参数BO查询数据
     * @param paramsBo 参数BO对象
     * @param boClazz 将结果集装载的目标BO
     * @param againExecute 是否再次执行该方法
     * @return 影响行数
     * @throws Exception
     */
    public <T> List<T> queryDataByParamsBo(Object paramsBo, Class<T> boClazz, boolean againExecute) throws Exception{
        List<T> boList = null;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = CtAdToolConnectionUtil.get();
            Class<?> paramsBoClass = paramsBo.getClass();
            TableName tableName = paramsBoClass.getAnnotation(TableName.class);
            String tableNameStr = null;
            if (tableName != null) {
                tableNameStr = tableName.value();
            } else {
                Field field = paramsBo.getClass().getDeclaredField("tableName");
                field.setAccessible(true);
                Object obj = field.get(paramsBo);
                if (obj != null) {
                    tableNameStr = obj.toString();
                }
            }

            if (StringUtils.isEmpty(tableNameStr)) {
                throw new Exception("未指定表名，不执行查询操作！");
            }

            // 获取查询的参数
            List<String> conditionSqlList = new ArrayList<>();
            List<Object> paramsValueList = new ArrayList<>();
            Field[] declaredFields = paramsBoClass.getDeclaredFields();
            for (Field field : declaredFields) {
                TableField tableField = field.getAnnotation(TableField.class);
                // 数据库字段名
                String column = null;
                if (tableField != null) {
                    column = tableField.value();
                } else {
                    TableId tableId = field.getAnnotation(TableId.class);
                    if (tableId != null) {
                        column = tableId.value();
                    }
                }
                if (StringUtils.isEmpty(column)) continue;

                CtCondition ctCondition = field.getAnnotation(CtCondition.class);
                if (ctCondition == null) continue;

                field.setAccessible(true);
                Object obj = field.get(paramsBo);
                if (obj != null) {
                    String condition = ctCondition.condition();
                    if (obj instanceof List) {
                        List list = (List) obj;
                        if (list.size() > 0) {
                            String key = "";
                            if ("like".equalsIgnoreCase(condition)) {
                                for (int i = 0; i < list.size(); i++) {
                                    key += " or " + column + " like lower('%" + list.get(i).toString() + "%') or " + column + " like Upper('%" + list.get(i).toString() + "%') ";
                                }
                                key = "(" + key.substring(4) + ")";
                            } else {
                                for (int i = 0; i < list.size(); i++) {
                                    key += ",?";
                                    paramsValueList.add(list.get(i));
                                }
                                key = column + " in (" + key.substring(1) + ")";
                            }
                            conditionSqlList.add(key);
                        }
                    } else {
                        conditionSqlList.add(column + ctCondition.condition() + "?");
                        if ("like".equalsIgnoreCase(condition)) {
                            paramsValueList.add("%" + obj.toString() + "%");
                        } else {
                            paramsValueList.add(obj);
                        }
                    }
                }
            }

            // 获取表中的字段
            Map<String, Field> columnMap = new HashMap<>();
            Field[] fields = boClazz.getDeclaredFields();
            for (Field field : fields) {
                TableField tableField = field.getAnnotation(TableField.class);
                // 数据库字段名
                String column = null;
                if (tableField != null) {
                    column = tableField.value();
                } else {
                    TableId tableId = field.getAnnotation(TableId.class);
                    if (tableId != null) {
                        column = tableId.value();
                    }
                }
                if (StringUtils.isEmpty(column)) continue;

                columnMap.put(column, field);
            }

            String keyStr = StringUtils.join(columnMap.keySet(), ",");
            String sql = "select " + keyStr + " from " + tableNameStr;
            if (CollectionUtils.isNotEmpty(conditionSqlList)) {
                sql += " where " + StringUtils.join(conditionSqlList, " and ");
            }

            Field orderBy = paramsBoClass.getDeclaredField("orderBy");
            if (orderBy != null) {
                orderBy.setAccessible(true);
                Object object = orderBy.get(paramsBo);
                if (object != null) {
                    sql += " order by " + object.toString();
                }
            }

            String isOpen = CtAdToolProperties.getInstance().getStringValue("open.sql.print");
            if ("true".equals(isOpen)) {
                System.out.println(CtAdToolQuery.class.getName() + " 查询SQL >>>>>> " + sql);
                System.out.println(CtAdToolQuery.class.getName() + " 查询参数 >>>>>> " + JSONObject.toJSONString(paramsValueList));
            }

            statement = connection.prepareStatement(sql);
            if (CollectionUtils.isNotEmpty(paramsValueList)) {
                int index = 1;
                for (Object value : paramsValueList) {
                    if (value instanceof String) {
                        statement.setString(index, value.toString());
                    } else if (value instanceof Date) {
                        Date tempDate = (Date) value;
                        statement.setDate(index, new java.sql.Date(tempDate.getTime()));
                    } else {
                        statement.setObject(index, value);
                    }
                    index++;
                }
            }
            ResultSet resultSet = statement.executeQuery();
            boList = new ArrayList<>();
            while (resultSet.next()) {
                T bo = (T) boClazz.newInstance();
                for (Map.Entry<String, Field> item : columnMap.entrySet()) {
                    String key = item.getKey();
                    key = key.replace("\"", "");
                    Object object = resultSet.getObject(key);
                    Field field = item.getValue();
                    field.setAccessible(true);
                    field.set(bo, object);
                }

                // 将表名设置到BO中
                Field field = boClazz.getDeclaredField("tableName");
                if (field != null) {
                    field.setAccessible(true);
                    field.set(bo, tableNameStr);
                }
                boList.add(bo);
            }
        } catch (SQLRecoverableException se) {
            se.printStackTrace();
            System.out.println("queryDataByParamsBo -> againExecute >>>>>> " + againExecute);
            if (againExecute) {
                // 尝试清空缓存池连接，重新初始化连接
                CtAdToolConnectionUtil.init();
                // 再执行一次
                return queryDataByParamsBo(paramsBo, boClazz, false);
            } else {
                throw new WTException(se, CtConstant.DATABASE_EXCEPTION_PREFIX + se.getLocalizedMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (statement != null ) {
                try {
                    statement.close();
                    // 正常关闭的连接才加回连接池中
                    if (connection != null) CtAdToolConnectionUtil.backConn(connection);
                } catch (SQLRecoverableException e) {
                    e.printStackTrace();
                }
            }
        }

        return boList;
    }
    /**
     * 查询物料的OID
     * @param paramsBo
     * @return
     * @throws Exception
     */
    public List<String> queryPartOIds(CtAdToolParamsBo paramsBo) throws Exception {
        return  initMapper().queryPartOIds(paramsBo);
    }

    /**
     * 查询基线的OID
     * @param paramsBo
     * @return
     * @throws Exception
     */
    public List<String> queryBaselineOIds(CtAdToolParamsBo paramsBo) throws Exception {
        return initMapper().queryBaselineOIds(paramsBo);
    }

    /**
     * 查询文档中最大的流水号
     * @param numberPrefix
     * @returnC
     */
    Integer queryDocMaxSerialNumber(String numberPrefix) throws Exception {
        return initMapper().queryDocMaxSerialNumber(numberPrefix);
    }

    /**
     * 根据文档编码和文档名称查询文档
     * @param docNumber 模糊查询
     * @param docName 精确查询
     * @return
     * @throws Exception
     */
    public WTDocument queryDocument(String docNumber, String docName) throws Exception {
        WTDocument document = null;
        QuerySpec querySpec = new QuerySpec(WTDocumentMaster.class);
        querySpec.setAdvancedQueryEnabled(true);
        String masterAlias = querySpec.getFromClause().getAliasAt(0);


        TableColumn numberColumn = new TableColumn(masterAlias, "WTDOCUMENTNUMBER");
        querySpec.appendWhere(new SearchCondition(numberColumn, SearchCondition.LIKE,ConstantExpression.newExpression(docNumber + "%")), new int[]{0});

        TableColumn nameColumn = new TableColumn(masterAlias, "NAME");
        querySpec.appendAnd();
        querySpec.appendWhere(new SearchCondition(nameColumn, SearchCondition.EQUAL, ConstantExpression.newExpression(docName)), new int[]{0});

        QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec) querySpec);
        if (queryResult.hasMoreElements()) {
            WTDocumentMaster documentMaster = (WTDocumentMaster) queryResult.nextElement();
            document = (WTDocument) CtVersionUtil.getLatest(documentMaster);
        }
        return document;
    }

    /**
     * 查询网络中心库数据
     * @param paramsBo
     * @return
     */
    public List<CtCentralLibraryBo> queryCentralLibrary(CtCentralLibraryParamsBo paramsBo) {
        List<CtCentralLibraryBo> boList = null;
        try {
            boList = queryDataByParamsBo(paramsBo, CtCentralLibraryBo.class);
        } catch (Exception e) {
            e.printStackTrace();
            boList = new ArrayList<>();
        }
        return boList;
    }

    /**
     * 查询物料某个IBA属性值
     * @param paramsMap
     * @return
     */
    public List<HashMap<String, Object>> queryPartIbaValue(HashMap<String, Object> paramsMap) {
        return initMapper().queryPartIbaValue(paramsMap);
    }

    @Override
    public boolean insert(CtCentralLibraryBo entity) {
        Integer result = null;
        try {
            result = addDataByBo(entity);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null != result && result >= 1;
    }

    @Override
    public boolean updateById(CtCentralLibraryBo entity) {
        Integer result = null;
        try {
            result = updateDataByBo(entity, "\"MaterialRetrievalCode\"");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null != result && result >= 1;
    }

    public CtCentralLibraryBo selectOneDataByBo(CtCentralLibraryBo itemBo) throws Exception {
        return selectOneDataByBo(itemBo, true);
    }

    public CtCentralLibraryBo selectOneDataByBo(CtCentralLibraryBo itemBo, boolean againExecute) throws Exception {
        CtCentralLibraryParamsBo paramsBo = new CtCentralLibraryParamsBo();
        List<String> ids = new ArrayList<>(1);
        ids.add(itemBo.getMaterialRetrievalCode());
        paramsBo.setIdList(ids);
        paramsBo.setTableName(itemBo.getTableName());
        CtCentralLibraryBo bo = null;
        try {
            List<CtCentralLibraryBo> boList = queryDataByParamsBo(paramsBo, CtCentralLibraryBo.class);
            if (CollectionUtils.isNotEmpty(boList)) {
                bo = boList.get(0);
            }
        }  catch (SQLRecoverableException se) {
            se.printStackTrace();
            System.out.println("selectOneDataByBo -> againExecute >>>>>> " + againExecute);
            if (againExecute) {
                // 尝试清空缓存池连接，重新初始化连接
                CtAdToolConnectionUtil.init();
                // 再执行一次
                return selectOneDataByBo(itemBo, false);
            } else {
                throw new WTException(se, CtConstant.DATABASE_EXCEPTION_PREFIX + se.getLocalizedMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        }
        return bo;
    }

    /**
     * 根据文档编码前缀查询文档
     * @param docNumber 模糊查询
     * @return
     * @throws Exception
     */
    public QueryResult queryDocumentByDocumentNumber(String docNumber, String[] notIncludeNumbers) throws Exception {
        WTDocument document = null;
        QuerySpec querySpec = new QuerySpec(WTDocumentMaster.class);
        querySpec.setAdvancedQueryEnabled(true);
        String masterAlias = querySpec.getFromClause().getAliasAt(0);


        TableColumn numberColumn = new TableColumn(masterAlias, "WTDOCUMENTNUMBER");
        querySpec.appendWhere(new SearchCondition(numberColumn, SearchCondition.LIKE,ConstantExpression.newExpression(docNumber + "%")), new int[]{0});

        if (ArrayUtils.isNotEmpty(notIncludeNumbers)) {
            querySpec.appendAnd();
            querySpec.appendWhere(new SearchCondition(numberColumn, SearchCondition.NOT_IN, new ArrayExpression(notIncludeNumbers)), new int[]{0});
        }

        return PersistenceHelper.manager.find((StatementSpec) querySpec);
    }

    /**
     * 根据文件夹路径模糊查询容器下的文件夹
     * @param folderPath 若只是文件夹名则模糊查询，若全路径则只查询上层文件夹下是模糊查询的文件夹
     * @param container 容器
     * @return
     * @throws Exception
     */
    public Folder queryFolder(String folderPath, WTContainer container) throws Exception {
        Folder folder = null;
        QuerySpec querySpec = new QuerySpec(SubFolder.class);
        querySpec.setAdvancedQueryEnabled(true);
        String subFolderAlias = querySpec.getFromClause().getAliasAt(0);

        String name = null;
        String prefisx = null;
        int lastIndexOf = folderPath.lastIndexOf("/");
        if (lastIndexOf != -1) {
            name = folderPath.substring(lastIndexOf + 1);
            prefisx = folderPath.substring(0, lastIndexOf);
        } else {
            name = folderPath;
        }
        TableColumn nameColumn = new TableColumn(subFolderAlias, "NAME");
        querySpec.appendWhere(new SearchCondition(nameColumn, SearchCondition.LIKE,ConstantExpression.newExpression(name + "%")), new int[]{0});

        querySpec.appendAnd();
        TableColumn containerIdColumn = new TableColumn(subFolderAlias, "IDA3CONTAINERREFERENCE");
        querySpec.appendWhere(new SearchCondition(containerIdColumn, SearchCondition.EQUAL,ConstantExpression.newExpression(CtWTObjectUtil.getId(container))), new int[]{0});

        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);

        while (queryResult.hasMoreElements()){
            SubFolder subFolder = (SubFolder) queryResult.nextElement();
            if (StringUtils.isNotEmpty(prefisx)) {
                String location = subFolder.getLocation();
                if (prefisx.equals(location)) {
                    folder = subFolder;
                    break;
                }
            } else {
                folder = subFolder;
                break;
            }
        }

        return folder;
    }
    
    public <T> Integer updateTsByBo(T bo, String whereColumn,String numAd,String desAd) throws Exception{
            if(bo == null) throw new Exception("Bo对象不能为空！");
            Integer count = 0;

            Connection connection = null;

            // 用于存对象中的ID值
            String condition = null;
            // 用于存储数据库字段值
            List<String> columnList = new ArrayList<>();
            // 用于存储占位符的值
            List<Object> valueList = new ArrayList<>();

            PreparedStatement statement = null;
            try {
                connection = CtAdToolConnectionUtil.get();
                Class<?> boClass = bo.getClass();
                TableName tableName = boClass.getAnnotation(TableName.class);
                String tableNameStr = null;
                if (tableName != null) {
                    tableNameStr = tableName.value();
                } else {
                    Field field = boClass.getDeclaredField("tableName");
                    field.setAccessible(true);
                    Object obj = field.get(bo);
                    if (obj != null) {
                        tableNameStr = obj.toString();
                    }
                }

                if(StringUtils.isEmpty(tableNameStr)){
                    throw new Exception("未指定表名，不执行查询操作！");
                }

//                Field[] declaredFields = boClass.getDeclaredFields();
//                boolean isId = false;
//                for (Field field : declaredFields) {
//                    TableField tableField = field.getAnnotation(TableField.class);
//                    // 数据库字段名
//                    String column = null;
//                    if (tableField != null) {
//                        column = tableField.value();
//                        isId = false;
//                    } else {
//                        TableId tableId = field.getAnnotation(TableId.class);
//                        if (tableId != null) {
//                            column = tableId.value();
//                            isId = true;
//                        }
//                    }
//
//                    if (StringUtils.isEmpty(column)) continue;
//
//                    field.setAccessible(true);
//                    Object obj = field.get(bo);
//                    if (obj != null) {
//                        if(column.equals(whereColumn)){
//                            condition = obj.toString();
//                        } else if (!isId){
//                            columnList.add(column + "=?");
//                            valueList.add(obj);
//                        }
//                    }
//                }
//                if(StringUtils.isEmpty(condition)){
//                    throw new Exception("更新数据的条件" + whereColumn + "不能为空！");
//                }

//                String keyStr = StringUtils.join(columnList, ",");
//                String sql = "update " + tableNameStr + " set " + keyStr + " where " + whereColumn + "=?";
//                String sql = "UPDATE " + tableNameStr + "  SET \"物料替换组编码\"="+"'444aaa;'" + "|| chr(10) ||" + "'yy444bb;' WHERE \"MaterialCode\"='K102010003'";
                String number = "";
                if(StringUtils.isNotEmpty(((CtSubstituteParemBo)bo).getMaterialRetrievalCode())){
                	number = ((CtSubstituteParemBo)bo).getMaterialRetrievalCode();
                }else if(StringUtils.isNotEmpty(((CtSubstituteParemBo)bo).getMaterialCode())){
                	number = ((CtSubstituteParemBo)bo).getMaterialCode();
                }
                if(!StringUtils.isNotEmpty(numAd)){
                	numAd = null;
                }
                if(!StringUtils.isNotEmpty(desAd)){
                	desAd = null;
                }
                String sql = "UPDATE " + tableNameStr + "  SET \"物料替换组编码\"=" + numAd + 
                		", \"物料替换组描述\"=" + desAd
                		+ " WHERE " + whereColumn + "='" + number + "'";
                String isOpen = CtAdToolProperties.getInstance().getStringValue("open.sql.print");
                if ("true".equals(isOpen)) {
                    System.out.println(CtAdToolQuery.class.getName() +  " 更新SQL >>>>>> " + sql);
                    System.out.println(CtAdToolQuery.class.getName() +  " 更新数据 >>>>>> " + JSONObject.toJSONString(valueList));
                    System.out.println(CtAdToolQuery.class.getName() +  " 条件参数 >>>>>> " + condition);
                }

                try {
                    statement = connection.prepareStatement(sql);

//                int index = 1;
//                for(Object value : valueList){
//                    if (value instanceof String) {
//                        statement.setString(index, value.toString());
//                    }else if (value instanceof Date){
//                        Date tempDate = (Date) value;
//                        statement.setDate(index, new java.sql.Date(tempDate.getTime()));
//                    }else {
//                        statement.setObject(index, value);
//                    }
//                    index++;
//                }
//                statement.setString(index, condition);
                    count = statement.executeUpdate();

//                if (count > 0) {
                    connection.commit();
//                }
                } catch (SQLException e) {
                    System.out.println(CtAdToolQuery.class.getName() +  " 更新SQL >>>>>> " + sql);
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
                if (connection != null) connection.rollback();
                throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
            } finally {
                if (statement != null) statement.close();
                if (connection != null) CtAdToolConnectionUtil.backConn(connection);
            }
            return count;
        }
}
