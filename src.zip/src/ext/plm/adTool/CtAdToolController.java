package ext.plm.adTool;

import com.alibaba.fastjson.JSONObject;
import ext.plm.adTool.bo.*;
import ext.plm.common.CtConstant;
import ext.plm.common.CtResApiResult;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtUserUtil;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.DefaultMultipartHttpServletRequest;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * AD集成工具 Controller
 * @auther TanRuoTao
 */
@Controller()
@RequestMapping(value = "/adTool")
public class CtAdToolController {

    @Autowired
    private CtAdToolService ctAdToolService;

    @InitBinder
    protected void init(HttpServletRequest request, ServletRequestDataBinder binder){
        SimpleDateFormat dateFormat = new SimpleDateFormat(CtConstant.DATE_FORMAT_DAY);
        dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    /**
     * 用于验证登录功能
     * @return
     * @throws Exception
     */
    @GetMapping("/login")
    @ResponseBody
    public CtResApiResult testLogin() throws Exception {
        try {
            CtUserUtil.getCurrentUser();
            return CtResApiResult.success("登录成功！");
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("登录失败！");
        }
    }

    /**
     * 获取物料信息
     * @param paramsBo
     * @return
     */
    @GetMapping("/partInfo")
    @ResponseBody
    public CtResApiResult getPartInfo(CtAdToolParamsBo paramsBo) {
        try {
            return CtResApiResult.success(ctAdToolService.getPartInfo(paramsBo));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("查询物料相关信息失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 获取物料关联文档（说明放文档、参考文档）
     * @param oid
     * @return
     */
    @GetMapping("/relationDocs")
    @ResponseBody
    public CtResApiResult getRelationDocs(@RequestParam("oid") String oid) {
        try {
            return CtResApiResult.success(ctAdToolService.getRelationDocs(oid));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("获取关联文档信息失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 压缩文档的主内容和附件（说明放文档、参考文档）
     * @param oids 物料VID，通过英文逗号隔开
     * @return
     */
    @GetMapping("/downloadRelationDocs")
    public void downloadRelationDocs(@RequestParam("oids") String oids,
                                     @RequestParam(value = "isCheckOut", required = false, defaultValue = "false") boolean isCheckOut,
                                     HttpServletRequest request,
                                     HttpServletResponse response) {
        ServletOutputStream outputStream = null;
        try {
            String userAgent = request.getHeader("User-Agent");
            outputStream = response.getOutputStream();
            String fileName = "文档内容压缩包-" + CtDateUtil.getCurrentDate("yyyyMMddHHmmss", "GMT+08:00" ) + ".zip";
            response.setContentType("application/octet-stream");
            if (StringUtils.isNotEmpty(userAgent)) {
                if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                    //ie
                    fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                    //edge
                    fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
                }else {
                    // //firefox、chrome、safari、opera：
                    fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
                }
            }
            response.setCharacterEncoding("GBK");
            response.setContentType("application/octet-stream");
            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
            ctAdToolService.downloadRelationDocs(oids, isCheckOut, response.getOutputStream());
        } catch (Exception e) {
            e.printStackTrace();
            try {
                response.setContentType("application/json;charset=UTF-8");
                CtResApiResult resApiResult = CtResApiResult.fail("压缩文档的主内容和附件失败，后台异常：" + e.getLocalizedMessage());
                IOUtils.write(JSONObject.toJSONString(resApiResult), outputStream, "UTF-8");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } finally {
            try {
                if (outputStream != null) outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 验证PCB物料编码是否存在系统且是否具有编辑权限
     * @return
     */
    @GetMapping("/checkPcbNumber")
    @ResponseBody
    public CtResApiResult checkPcbNumber(HttpServletRequest request) {
        try {
            Map<String, String> paramsMap = new HashMap<>();
            String queryString = request.getQueryString();
            System.out.println("queryString >>>>>>>>> " + queryString);
            String tempKey = "";
            if (StringUtils.isNotEmpty(queryString)) {
                for (String s : queryString.split("&")) {
                    String[] keyValue = s.split("=");
                    if (keyValue.length == 2) {
                        tempKey = keyValue[0];
                        paramsMap.put(keyValue[0], keyValue[1].replace("%26", "&"));
                    } else {
                        boolean isContinue = false;
                        switch (keyValue[0]) {
                            case "pcbNumber":
                            case "version":
                            case "pcbModel":
                                isContinue = true;
                                continue;
                        }
                        if (isContinue || StringUtils.isEmpty(tempKey)) continue;
                        paramsMap.put(tempKey, paramsMap.get(tempKey) + "&" + keyValue[0]);
                    }
                }
            }
            System.out.println("checkPcbNumber paramsMap >>>>>>>>>>>" + JSONObject.toJSONString(paramsMap));
            return CtResApiResult.success(ctAdToolService.checkPcbNumber(paramsMap.get("pcbNumber"), paramsMap.get("version"), paramsMap.get("pcbModel")));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("校验PCB物料失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 校验BOM下的子阶物料信息
     * @param bomPartBoList
     * @return
     */
    @PostMapping("/checkBOM")
    @ResponseBody
    public CtResApiResult checkBOM(@RequestParam("pcbNumber") String pcbNumber,
                                   @RequestParam("innerVersion") String innerVersion,
                                   @RequestBody List<CtBomPartBo> bomPartBoList) {
        try {
            return CtResApiResult.success(ctAdToolService.checkBOM(pcbNumber, innerVersion, bomPartBoList));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("校验BOM失败，后台异常：" + e.getLocalizedMessage());
        }
    }

    /**
     * 获取BOM下的子阶物料信息
     * @param bomPartBoList
     * @return
     */
    @PostMapping("/getBOMData")
    @ResponseBody
    public CtResApiResult getBOMData(@RequestBody List<CtBomPartBo> bomPartBoList) {
        try {
            String message = ctAdToolService.getBOMData(bomPartBoList);
            return CtResApiResult.success(message, bomPartBoList);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("获取BOM数据失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 获取BOM下的子阶物料信息
     * @param bomPartBoList
     * @return
     */
    @PostMapping("/updateBOM")
    @ResponseBody
    public CtResApiResult updateBOM(@RequestParam("pcbNumber") String pcbNumber,
                                    @RequestParam("innerVersion") String innerVersion,
                                    @RequestParam(value = "checkInRemark", required = false) String checkInRemark,
                                    @RequestBody List<CtBomPartBo> bomPartBoList) {
        try {
            String message = ctAdToolService.updateBOM(pcbNumber, innerVersion, bomPartBoList, checkInRemark);
            return CtResApiResult.success(message);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("更新BOM数据失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 文件归档
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/customUpload/fileArchive")
    @ResponseBody
    public CtResApiResult fileArchive(HttpServletRequest httpServletRequest) {
        try {
            if (httpServletRequest instanceof DefaultMultipartHttpServletRequest) {
                DefaultMultipartHttpServletRequest multipartHttpServletRequest = (DefaultMultipartHttpServletRequest) httpServletRequest;
                Map<String, String[]> map = multipartHttpServletRequest.getParameterMap();
                List<MultipartFile> files = multipartHttpServletRequest.getFiles("files");
                ctAdToolService.fileArchive(map, files);
            }
            return CtResApiResult.success("归档成功！");
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("归档失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 获取容器列表
     * @return
     */
    @GetMapping("/containers")
    @ResponseBody
    public CtResApiResult getContainers(CtContainerParamsBo paramsBo) {
        try {
            return CtResApiResult.success(ctAdToolService.getContainers(paramsBo));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("获取容器列表失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 更新网络中心库
     * @param paramsBo
     * @return
     */
    @PutMapping("networkCentralLibrary")
    @ResponseBody
    public CtResApiResult updateCentralLibrary(CtCentralLibraryParamsBo paramsBo) {
        try {
            return CtResApiResult.success(ctAdToolService.updateCentralLibrary(paramsBo));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("更新网络中心库数据失败，后台异常新：" + e.getLocalizedMessage());
        }
    }

    /**
     * 导入更新网络中心库数据
     * @param multipartHttpServletRequest
     * @return
     */
    @PostMapping("/customUpload/importNetworkCentralLibrary")
    @ResponseBody
    public CtResApiResult importNetworkCentralLibrary(DefaultMultipartHttpServletRequest multipartHttpServletRequest) {
        try {
            Map<String, String[]> map = multipartHttpServletRequest.getParameterMap();
            List<MultipartFile> files = multipartHttpServletRequest.getFiles("files");
            return CtResApiResult.success(ctAdToolService.importNetworkCentralLibrary(map, files));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("导入失败，后台异常信息：" + e.getLocalizedMessage());
        }
    }

    /**
     * 下载模板
     * @param templateName 模板名称，带后缀
     * @return
     */
    @GetMapping("/downloadTemplate")
    public void downloadTemplate(@RequestParam("templateName") String templateName,
                                 HttpServletRequest request,
                                 HttpServletResponse response) {
        FileInputStream fileInputStream = null;
        ServletOutputStream outputStream = null;
        try {
            String userAgent = request.getHeader("User-Agent");
            outputStream = response.getOutputStream();
            String fileName = templateName;
            response.setContentType("application/octet-stream");
            if (StringUtils.isNotEmpty(userAgent)) {
                if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                    //ie
                    fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                    //edge
                    fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
                }else {
                    // //firefox、chrome、safari、opera：
                    fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
                }
            }
            response.setCharacterEncoding("UTF-8");
            response.setContentType("application/octet-stream");
            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));

            String templatePath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator + "ext"
                    + File.separator + "plm" + File.separator + "adTool" + File.separator + "config" + File.separator + templateName;

            fileInputStream = new FileInputStream(templatePath);
            IOUtils.copy(fileInputStream, outputStream);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                response.setContentType("application/json;charset=UTF-8");
                CtResApiResult resApiResult = CtResApiResult.fail("下载模板失败，后台异常：" + e.getLocalizedMessage());
                IOUtils.write(JSONObject.toJSONString(resApiResult), outputStream, "UTF-8");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } finally {
            try {
                if (fileInputStream != null) fileInputStream.close();
                if (outputStream != null) outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 更新网络中心库
     * @param paramsBo
     * @return
     */
    @GetMapping("networkCentralLibrary")
    @ResponseBody
    public CtResApiResult getCentralLibrary(CtCentralLibraryParamsBo paramsBo) {
        try {
            return CtResApiResult.success(ctAdToolService.getCentralLibrary(paramsBo));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("获取网络中心库数据失败，后台异常新：" + e.getLocalizedMessage());
        }
    }

    /**
     * 导出网络中心库数据
     * @param paramsBo
     * @return
     */
    @GetMapping("/exportNetworkCentralLibrary")
    public void exportNetworkCentralLibrary(CtCentralLibraryParamsBo paramsBo,
                                            HttpServletRequest request,
                                            HttpServletResponse response) {
        FileInputStream fileInputStream = null;
        ServletOutputStream outputStream = null;
        try {
            String userAgent = request.getHeader("User-Agent");
            outputStream = response.getOutputStream();
            String fileName = "网络中心库_" + System.currentTimeMillis() + ".xlsx";
            response.setContentType("application/octet-stream");
            if (StringUtils.isNotEmpty(userAgent)) {
                if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                    //ie
                    fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
                } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
                    //edge
                    fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
                }else {
                    // //firefox、chrome、safari、opera：
                    fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
                }
            }
            response.setCharacterEncoding("UTF-8");
            response.setContentType("application/octet-stream");
            response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));

            ctAdToolService.exportNetworkCentralLibrary(paramsBo, outputStream);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                response.setContentType("application/json;charset=UTF-8");
                CtResApiResult resApiResult = CtResApiResult.fail("导出网络中心库数据失败，后台异常：" + e.getLocalizedMessage());
                IOUtils.write(JSONObject.toJSONString(resApiResult), outputStream, "UTF-8");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } finally {
            try {
                if (fileInputStream != null) fileInputStream.close();
                if (outputStream != null) outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 更新物料内部版本
     * @param paramsBo
     * @return
     */
    @PostMapping("updatedVersion")
    @ResponseBody
    public CtResApiResult updatedVersion(CtUpdatedVersionParamsBo paramsBo) {
        try {
            String message = ctAdToolService.updatedVersion(paramsBo);
            if (StringUtils.isEmpty(message)) {
                return CtResApiResult.success(message);
            } else {
                return CtResApiResult.fail(message);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("更新物料内部版本失败，后台异常新：" + e.getLocalizedMessage());
        }
    }

    /**
     * 删除网络中心库
     * @param paramsBo
     * @return
     */
    @DeleteMapping("networkCentralLibrary")
    @ResponseBody
    public CtResApiResult deleteCentralLibrary(CtCentralLibraryParamsBo paramsBo) {
        try {
            return CtResApiResult.success(ctAdToolService.deleteCentralLibrary(paramsBo));
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResult.fail("删除网络中心库数据失败，后台异常新：" + e.getLocalizedMessage());
        }
    }
}
