package ext.plm.adTool;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.SCPClient;
import ch.ethz.ssh2.Session;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ptc.core.lwc.server.PersistableAdapter;
import ext.plm.adTool.annotation.CtIbaConfig;
import ext.plm.adTool.bo.CtCentralLibraryBo;
import ext.plm.adTool.bo.CtCentralLibraryParamsBo;
import ext.plm.adTool.bo.CtCreateDocumentBo;
import ext.plm.adTool.config.CtAdToolConstant;
import ext.plm.adTool.config.CtAdToolProperties;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.tool.poi.ref.ExcelColumn;
import ext.plm.util.*;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.springframework.web.multipart.MultipartFile;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeReviewItemLink;
import wt.change2.WTChangeReview;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.folder.Folder;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleServerHelper;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.State;
import wt.occurrence.OccurrenceHelper;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.part.*;
import wt.pom.Transaction;
import wt.query.ConstantExpression;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.TableColumn;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

import java.io.*;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.sql.Timestamp;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class CtAdToolLogic {

    private volatile static CtAdToolLogic instance = null;

    private CtAdToolQuery ctAdToolQuery = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolQuery.class);

    // 支持压缩的文件格式
    private HashSet<String> compressedPackageSet;

    public static CtAdToolLogic getInstance() {
        if (instance == null) {
            synchronized (CtAdToolLogic.class) {
                if (instance == null) {
                    instance = new CtAdToolLogic();
                }
            }
        }
        return instance;
    }

    private CtAdToolLogic() {
        compressedPackageSet = CtAdToolProperties.getInstance().getHashSetValue("compress.format");
    }

    /**
     * 将文件路径转成共享文件目录符合的路径，拆分成文件名和路径
     * @param filePath 文件路径，包括文件名
     * @param fileSeparator 共享目录的文件分隔符
     * @return
     */
    private Map<String, String> convertSharedFilePath(String filePath, String fileSeparator) {
        String path  = filePath.replaceAll("/", "|");
        path = path.replaceAll("\\\\", "|");
        String[] pathArray = path.split("\\|");

        int lastIndex = pathArray.length - 1;
        String fileName = null;
        String targetPath = "";
        for (int i = 0; i < pathArray.length; i++) {
            String itemPath = pathArray[i];
            if (i == lastIndex) {
                fileName = itemPath;
            } else if (StringUtils.isNotEmpty(itemPath)){
                targetPath += itemPath + fileSeparator;
            }
        }
        Map<String, String> resultMap = new HashMap<>(2);
        resultMap.put("fileName", fileName);
        resultMap.put("targetPath", targetPath);
        System.out.println("\r\bresultMap >>>>>> " + JSONObject.toJSONString(resultMap));
        return  resultMap;
    }

    /**
     * 上传文件到文件服务器（Linux环境），SCP形式
     * @param inputStream 文件流
     * @param filePath 文件路径，包括文件名
     * @return
     * @throws Exception
     */
    public void uploadFileToLinux(InputStream inputStream, String filePath) throws FileUploadException{
        if (StringUtils.isEmpty(filePath)) return;
        Connection connection = null;
        Session session = null;

        CtAdToolProperties properties = CtAdToolProperties.getInstance();
        // 共享目录的分隔符
        String fileSeparator = properties.getStringValue("file.separator");
        // 将文件路径拆分
        Map<String, String> map = convertSharedFilePath(filePath, fileSeparator);
        String targetPath = map.get("targetPath");
        String fileName = map.get("fileName");
        try {
            // 获取共享文件服务器的连接新消息
            String[] serverInfo = properties.getStringValue("file." + CtCommonUtil.getHostName()).split("\\|");
            connection = new Connection(serverInfo[0]);
            connection.connect();
            boolean isAuthenticated = connection.authenticateWithPassword(serverInfo[1], serverInfo[2]);
            if (isAuthenticated == false) throw new IOException("认证失败！");

            // 最终的路径
            String finalPath = serverInfo.length == 4 ? fileSeparator + serverInfo[3] : "";

            if (targetPath.startsWith(fileSeparator)) {
                finalPath += targetPath;
            } else  {
                finalPath += fileSeparator + targetPath;
            }
            session = connection.openSession();
            // 若目录不存在则创建目录
            session.execCommand("mkdir -p " + finalPath);

            SCPClient client = new SCPClient(connection);
            byte[] bytes = null;
            // 读取内容
            bytes = IOUtils.toByteArray(inputStream);
            client.put(bytes, fileName, targetPath); //本地文件scp到远程目录
        } catch (Exception e) {
            e.printStackTrace();
            throw new FileUploadException("上传文件["+ fileName +"]到文件服务失败，异常信息：" + e.getLocalizedMessage());
        } finally {
            if (connection != null) connection.close();
            if (session != null) session.close();
        }
    }

    /**
     * 上传文件到文件服务器（Window环境），共享文件目录形式
     * @param inputStream 文件流
     * @param filePath 文件路径，包括文件名
     * @param isDeleteFolder 是否删除最后一层文件夹
     */
    public void uploadFileToWindow(InputStream inputStream, String filePath, boolean isDeleteFolder) throws FileUploadException {
        OutputStream out = null;
        int bufferLen = 1024 * 8;

        CtAdToolProperties properties = CtAdToolProperties.getInstance();
        // 共享目录的分隔符
        String fileSeparator = properties.getStringValue("file.separator");
        // 将文件路径拆分
        Map<String, String> map = convertSharedFilePath(filePath, fileSeparator);
        String targetPath = map.get("targetPath");
        String fileName = map.get("fileName");
        try {
            // 获取共享文件服务器的连接新消息
            String[] serverInfo = properties.getStringValue("file." + CtCommonUtil.getHostName()).split("\\|");
            if (serverInfo == null || serverInfo.length != 4) {
                throw new Exception("未找到文件服务器的连接信息！");
            }
            // 域服务器验证
            NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(serverInfo[0],
                    serverInfo[1], serverInfo[2]);
            String url = "smb://" + serverInfo[0] + fileSeparator + serverInfo[3];
            if (targetPath.startsWith(fileSeparator)) {
                url  += targetPath;
            } else {
                url += fileSeparator + targetPath;
            }
            SmbFile remoteFolder = new SmbFile(url, auth);
            if (!remoteFolder.exists()) {
                remoteFolder.mkdirs();
            } else if (isDeleteFolder) {
                // 删除再新建
                remoteFolder.delete();
                remoteFolder.mkdir();
            }
            if (url.endsWith(fileSeparator)) {
                url += fileName;
            } else {
                url += fileSeparator + fileName;
            }

            SmbFile remoteFile = new SmbFile (url, auth);
            out = new BufferedOutputStream(new SmbFileOutputStream(remoteFile));
            InputStream in = new BufferedInputStream(inputStream);
            byte[] buffer = new byte[bufferLen];
            while ((bufferLen = in.read(buffer)) != -1) {
                out.write(buffer, 0, bufferLen);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new FileUploadException("上传文件["+ fileName +"]到文件服务失败，异常信息：" + e.getLocalizedMessage());
        } finally {
            try {
                if (out != null) out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 上传文件到文件服务器（Window环境），共享文件目录形式
     * @param inputStream 文件流
     * @param filePath 文件路径，包括文件名
     */
    public void uploadFileToWindow(InputStream inputStream, String filePath) throws FileUploadException {
        uploadFileToWindow(inputStream, filePath, false);
    }

    /**
     * 根据物料装载网络中心库BO
     * @param part
     * @return
     * @throws Exception
     */
    public CtCentralLibraryBo loadCentralLibraryBo(WTPart part) throws Exception {
        CtCentralLibraryBo bo = new CtCentralLibraryBo();
        loadCentralLibraryBo(bo, part);
        bo.setTableName(getCentralLibraryTableName(part));
        return bo;
    }

    /**
     * 根据物料装载网络中心库BO
     * @param part
     * @return
     * @throws Exception
     */
    public void loadCentralLibraryBo(CtCentralLibraryBo bo, WTPart part) throws Exception {
        IBAUtility ibaUtility = new IBAUtility(part);

        // 通过反射装载IBA属性值
        Field[] declaredFields = bo.getClass().getDeclaredFields();
        for (Field declaredField : declaredFields) {
            CtIbaConfig ctIbaConfig = declaredField.getAnnotation(CtIbaConfig.class);
            if (ctIbaConfig == null) continue;

            declaredField.setAccessible(true);
            try {
                if (ctIbaConfig.isMultivalued()) {
                    Vector values = ibaUtility.getIBAValues(ctIbaConfig.name());
                    if (CollectionUtils.isNotEmpty(values)) {
                        declaredField.set(bo, StringUtils.join(values, CtAdToolConstant.STRING_SEPARATOR));
                    }
                } else {
                    String value = ibaUtility.getIBAValue(ctIbaConfig.name());
                    if (value == null) value = "";
                    declaredField.set(bo, value);
                }
            } catch (Exception e) {
                System.out.println("IBA属性：" + ctIbaConfig.name() + "不存在系统中！");
            }
        }

        // 物料类型内部名称
        String typeInternalName = TypedUtilityServiceHelper.service.getTypeIdentifier(part).getTypeInternalName();
        if ("com.fhsj.ct_CBB".equals(typeInternalName)) {
            // 物料描述=物料名称
            bo.setMaterialDescription(part.getName());
            // 研发描述=CBB说明
            bo.setDevMaterialDesc(ibaUtility.getIBAValue("ct_itemDescription"));
            // 物料编码
            bo.setMaterialCode(part.getNumber().toLowerCase());
        } else {
            // 物料编码
            bo.setMaterialCode(part.getNumber());
        }

        // 物料状态
        CtAdToolProperties properties = CtAdToolProperties.getInstance();
        String status = properties.getStringValue(part.getLifeCycleState().getDisplay(Locale.CHINA));
        if (StringUtils.isEmpty(status)) {
            // 默认为新建中
            status = "新建中";
        }
        bo.setMaterialStatus(status);
    }

    /**
     * 获取网络中心库的ID并设置到BO中
     * @param part
     * @param bo
     * @return
     */
    public void setCentralLibraryId(WTPart part, CtCentralLibraryBo bo) throws Exception {
        bo.setMaterialRetrievalCode(getCentralLibraryId(part, bo));
    }

    /**
     * 获取网络中心库的ID
     * @param part
     * @return
     */
    public String getCentralLibraryId(WTPart part, CtCentralLibraryBo bo) throws Exception {
        String id = null;
        String materialCode = part.getNumber();
        String tableName = bo.getTableName();
        if (tableName == null) {
            tableName = getCentralLibraryTableName(part);
        }
        if (CtAdToolConstant.LIBRARY_PCB.equals(tableName) || CtAdToolConstant.LIBRARY_CBB.equals(tableName)) {
            IBAUtil ibaUtil = new IBAUtil(part);
            if (CtAdToolConstant.LIBRARY_CBB.equals(tableName)) {
                // 转小写
                materialCode = materialCode.toLowerCase();
            }
            // 物料编码+内部版本
            String actualVersion = ibaUtil.getIBAValue("ct_banci");
            id = StringUtils.isNotEmpty(actualVersion) ? materialCode + "_" + actualVersion : materialCode;
        } else {
            // 因为物料上没有“异形码”IBA属性，所以默认为空
            String heteromorphicCode = null;
            // 物料编码+异形码
            id = StringUtils.isNotEmpty(heteromorphicCode) ? materialCode + "_" + heteromorphicCode : materialCode;
        }
        return id;
    }

    /**
     * 获取网络中心库的表名并设置到BO中
     * @param part
     * @return
     */
    public String getCentralLibraryTableName(WTPart part) throws Exception {
        String typeInternalName = null;
        String tableName = null;
        if (part.getNumber().startsWith("L")) {
            tableName = CtAdToolConstant.LIBRARY_TEMP;
        } else if (part.getNumber().startsWith("S")) {
            tableName = CtAdToolConstant.LIBRARY;
        } else if (part.getNumber().startsWith("10101")) {
            tableName = CtAdToolConstant.LIBRARY_PCB;
        } else {
            try {
                typeInternalName = TypedUtilityServiceHelper.service.getTypeIdentifier(part).getTypeInternalName();
            } catch (WTException e) {
                e.printStackTrace();
                throw new Exception("通过物料：" + part.getNumber() + "获取类型内部名称失败！");
            }

            CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
            tableName = ctAdToolProperties.getStringValue("table." + typeInternalName);
            if (StringUtils.isEmpty(tableName)) {
                String classification = CtPartClfUtil.getClfAttValue(part);
                tableName = ctAdToolProperties.getStringValue("table." + classification);
            }
        }

        if (StringUtils.isEmpty(tableName)) {
            tableName = CtAdToolConstant.LIBRARY;
        }

        return tableName;
    }

    /**
     * 是否压缩文件
     * @return
     */
    public boolean isCompressedPackage(String fileName) {
        if (StringUtils.isEmpty(fileName)) return false;

        int indexOf = fileName.lastIndexOf(".");
        if (indexOf == -1) return false;

        String suffix = fileName.substring(indexOf + 1).toLowerCase();
        return compressedPackageSet.contains(suffix);
    }

    /**
     * 上传文档主要内容到共享目录中
     * @param document
     * @param targetPath
     * @param isDeleteFolder 是否删除最后一层文件夹
     * @throws Exception
     */
    public void uploadPrimaryContentToSharedFolder(WTDocument document, String targetPath, boolean isDeleteFolder) throws WTException {
        InputStream inputStream = null;
        ZipInputStream zipInputStream = null;
        try {
            // 获取主要内容
            QueryResult queryResult = ContentHelper.service.getContentsByRole(document, ContentRoleType.PRIMARY);
            if (queryResult == null || !queryResult.hasMoreElements()) return;

            ApplicationData applicationData = null;
            while (queryResult.hasMoreElements()) {
                Object object = queryResult.nextElement();
                if (object instanceof ApplicationData) {
                    applicationData = (ApplicationData) object;
                    break;
                }
            }
            if (applicationData == null) return;

            String fileName = applicationData.getFileName();
            // 获取文件流
            inputStream = ContentServerHelper.service.findContentStream(applicationData);
            if (inputStream == null) return;

            // 判断文件是否压缩文件
            if (isCompressedPackage(fileName)) {
                // 解压上传到共享目录
                zipInputStream = new ZipInputStream(inputStream, Charset.forName("GBK"));
                ZipEntry zipEntry = zipInputStream.getNextEntry();
                while (zipEntry != null) {
                    if (!zipEntry.isDirectory()) {
                        uploadFileToWindow(zipInputStream, targetPath + File.separator + zipEntry.getName(), isDeleteFolder);
                    }
                    zipInputStream.closeEntry();
                    zipEntry = zipInputStream.getNextEntry();
                }
            } else {
                // 直接将文件上传到共享目录
                uploadFileToWindow(inputStream, targetPath + File.separator + fileName, isDeleteFolder);
            }
        } catch (FileUploadException fe) {
            fe.printStackTrace();
            throw new WTException(fe, fe.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("上传文档：" + document.getNumber() + "的主要内容到共享目录失败，后台异常：" + e.getLocalizedMessage());
        } finally {
            try {
                if (inputStream != null) inputStream.close();
                if (zipInputStream != null) inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 压缩文件中的内容
     * @param document
     * @param contentRoleTypes
     * @param zipOutputStream
     * @throws Exception
     */
    public void compressDocumentContents(WTDocument document,
                                         ContentRoleType[] contentRoleTypes,
                                         ZipOutputStream zipOutputStream,
                                         String pathPrefix) throws Exception {
        if (contentRoleTypes == null || contentRoleTypes.length == 0) return;

//        HashSet compressFormatSet = CtAdToolProperties.getInstance().getHashSetValue("compress.format");
        for (ContentRoleType contentRoleType : contentRoleTypes) {
            QueryResult queryResult = ContentHelper.service.getContentsByRole(document, contentRoleType);
            while (queryResult.hasMoreElements()) {
                Object object = queryResult.nextElement();
                if (object instanceof ApplicationData) {
                    ApplicationData applicationData = (ApplicationData) object;
                    InputStream inputStream = ContentServerHelper.service.findContentStream(applicationData);
                    if (inputStream == null) continue;

                    String fileName = applicationData.getFileName();
//                    if (isCompressedPackage(fileName)) {
//                        //  将压缩文件的名称作为路径存储
//                        String path = pathPrefix + File.separator +  fileName.substring(0, fileName.lastIndexOf("."));
//                        // 处理压缩包
//                        ZipInputStream zipInputStream = new ZipInputStream(inputStream, Charset.forName("GBK"));
//                        ZipEntry nextEntry = zipInputStream.getNextEntry();
//                        while (nextEntry != null) {
//                            ZipEntry itemZipEntry = new ZipEntry(path + File.separator +  nextEntry.getName());
//                            zipOutputStream.putNextEntry(itemZipEntry);
//                            if (!nextEntry.isDirectory()) {
//                                IOUtils.copy(zipInputStream, zipOutputStream);
//                                zipOutputStream.flush();
//                            }
//                            zipOutputStream.closeEntry();
//                            zipInputStream.closeEntry();
//                            nextEntry = zipInputStream.getNextEntry();
//                        }
//                    }

                    String zipEntryName = pathPrefix;
                    if (StringUtils.isNotEmpty(zipEntryName)) {
                        zipEntryName += File.separator;
                    }
                    zipEntryName += fileName;
                    // 处理单个文件
                    ZipEntry zipEntry = new ZipEntry(zipEntryName);
                    zipOutputStream.putNextEntry(zipEntry);
                    IOUtils.copy(inputStream, zipOutputStream);
                    zipOutputStream.closeEntry();
                }
            }
        }
    }

    /**
     * 获取工位
     * @param usageLink
     * @param set 用于存储PartUsesOccurrence对象
     * @return
     * @throws Exception
     */
    public String getUsesOccurrences(WTPartUsageLink usageLink, WTHashSet set) throws Exception {
        // 位号
        String positionNo = "";
        QueryResult usesOccurrencesQS = OccurrenceHelper.service.getUsesOccurrences(usageLink);
        if (usesOccurrencesQS != null && usesOccurrencesQS.size() > 0) {
            List<String> values = new ArrayList<>(usesOccurrencesQS.size());
            while (usesOccurrencesQS.hasMoreElements()) {
                PartUsesOccurrence usesOccurrence = (PartUsesOccurrence) usesOccurrencesQS.nextElement();
                String name = usesOccurrence.getName();
                if (set != null) set.add(usesOccurrence);
                if (StringUtils.isNotEmpty(name)) {
                    values.add(name);
                }
            }
            ReferenceDesignatorSetDelegateFactory rdsFactory = new ReferenceDesignatorSetDelegateFactory();
            ReferenceDesignatorSet rds = rdsFactory.get(values);
            positionNo = StringUtils.join(rds.getExpandedReferenceDesignators(), CtAdToolConstant.STRING_SEPARATOR);
        }
        return positionNo;
    }

    /**
     * 获取工位
     * @param usageLink
     * @return
     * @throws Exception
     */
    public String getUsesOccurrences(WTPartUsageLink usageLink) throws Exception {
        return getUsesOccurrences(usageLink, null);
    }

    /**
     * 检查物料是否可以入网络中心库
     * @return
     * @throws Exception
     */
    public boolean isCanWarehousing(WTPart part) throws Exception {
        boolean isCanWarehousing = false;

        // 过滤视图
        if (!CtConstant.VIEW_DESIGN.equals(part.getViewName())) {
            return false;
        }
        IBAUtil ibaUtil = new IBAUtil(part);
        String materialBuildingSign = ibaUtil.getIBAValue("ct_materialBuildingSign");
        // 物料建库标志为“是”则入库
        return CtAdToolConstant.YES_FLAG.equals(materialBuildingSign);
    }

    /**
     * 创建文档或升级文档的小版本
     * @param bo
     * @param flag  标识，根据文档的某个属性确认是创建还是升小版本
     * @return
     * @throws Exception
     */
    public WTDocument createOrUpgradeDocument(CtCreateDocumentBo bo, String flag) throws Exception{
        WTUser currentUser = bo.getCurrentUser();
        WTDocument document = null;
        if (CtAdToolConstant.UPGRADE_DOC_NAME.equals(flag)) {
            String numberPrefix = bo.getNumber();
            CtAdToolQuery ctAdToolQuery = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolQuery.class);
            document = ctAdToolQuery.queryDocument(numberPrefix, bo.getName());

//            // 是否根据文档名做升版操作
//            if (!bo.isUpgradeByName()) {
//                // 若存在，则无需处理
//                if (document != null) return null;
//            }
        } else {
            document = CtDocUtil.getDocumentByNumber(bo.getNumber());
        }

        // 根据文档名获取文档类型
        String docType = CtAdToolProperties.getInstance().getStringValue("docType." + bo.getName());
        if (StringUtils.isEmpty(docType)) {
            // 则取最初配置的文档类型
            docType = bo.getDocType();
        }
        WTPart relationPart = bo.getRelationPart();
        if (document == null) {
            // 先检查用户是否有创建文档的权限
            /*boolean access = AccessControlHelper.manager.hasAccess(bo.getCurrentUser(), docType,
                    bo.getContainerReference().getDomainRef(), null, AccessPermission.CREATE);
            if (!access) {
                String displayName = TypedUtilityServiceHelper.service.getLocalizedTypeName("com.fhsj.Doc_gcwj", Locale.CHINA);
                throw new WTException("你没有在容器[" + bo.getContainerReference().getName() + "]中没有创建文档【" + displayName + "】的权限！");
            }*/
            WTPrincipal administrator = SessionHelper.manager
                    .getAdministrator();
            WTPrincipal previous = SessionContext
                    .setEffectivePrincipal(administrator);
            // 开始创建文档
            PersistableAdapter persistableAdapter = new PersistableAdapter(docType, null, null);
            persistableAdapter.load("name", "number", "containerReference", "folder.id", "ct_version",
                    "iterationInfo.creator", "iterationInfo.modifier", "ct_materialsnumber", "iterationInfo.note");
            persistableAdapter.set("name", bo.getName());
            persistableAdapter.set("number", bo.getNumber());
            persistableAdapter.set("containerReference", bo.getContainerReference());
            persistableAdapter.set("ct_version", bo.getCtVersion());
            persistableAdapter.set("folder.id", bo.getFolderId());
            persistableAdapter.set("iterationInfo.creator", currentUser);
            persistableAdapter.set("iterationInfo.modifier", currentUser);
            persistableAdapter.set("ct_materialsnumber", relationPart.getNumber());
            persistableAdapter.set("iterationInfo.note", bo.getCheckInRemark());

            document = (WTDocument) persistableAdapter.apply();
            document = (WTDocument) PersistenceHelper.manager.save(document);

            // 将物料与文档关联
            WTPartDescribeLink descriptionLink =  WTPartDescribeLink.newWTPartDescribeLink(relationPart, document);
            PersistenceServerHelper.manager.insert(descriptionLink);
            SessionContext.setEffectivePrincipal(previous);
        } else {
            // 检查文档是否有修改的权限
            /*if (!AccessControlHelper.manager.hasAccess(document, AccessPermission.MODIFY)) {
                throw new WTException("文档处于“" + documentState
                        + "”状态，没有编辑文档["+ document.getNumber() +"]的权限！");
            }*/
            CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
            HashSet ignoreDocTypeSet = ctAdToolProperties.getHashSetValue("ignore.document.type");
            if (!ignoreDocTypeSet.contains(docType)) {
                JSONObject fileArchiveStateConfig = ctAdToolProperties.getFileArchiveStateConfig();
                // 文档编码后缀
                String numberSuffix = bo.getNumber().substring(bo.getNumber().indexOf("_") + 1);
                // 优先根据编码获取
                JSONObject pcbStateObj = (JSONObject) fileArchiveStateConfig.get(numberSuffix);
                // 再根据文档类型获取
                if (pcbStateObj == null) pcbStateObj = (JSONObject) fileArchiveStateConfig.get(docType);

                if (pcbStateObj != null) {
                    String pcbState = bo.getPcbPart().getLifeCycleState().getDisplay(Locale.CHINA);
                    JSONObject docStateObj = (JSONObject) pcbStateObj.get(pcbState);
                    if (docStateObj == null) {
                        // 说明PCB物料状态不符合
                        throw new WTException("PCB料【" + relationPart.getNumber() + "】的状态为“" + pcbState + "”，不允许归档！");
                    }

                    // 再看文档状态是否满足
                    String docState = document.getLifeCycleState().getDisplay(Locale.CHINA);
                    Object object = docStateObj.get(docState);
                    if (object == null) {
                        // 说明文档状态不符合
                        throw new WTException("PCB料【" + relationPart.getNumber() + "】的状态为“" + pcbState
                                + " ——> 文档【" + document.getNumber() + "】的状态为“" + docState + "””，不允许归档！");
                    }

                    String stateFlag = object.toString();
                    if (CtAdToolConstant.FILE_ARCHIVE_REVISE.equals(stateFlag) || CtAdToolConstant.FILE_ARCHIVE_PART_DOC_REVISE.equals(stateFlag)) {
                        // 做修订操作
                        document = (WTDocument) doReviseObject(document, "", true);
                    }
                }
            }

            IBAUtil oldIbaUtil = new IBAUtil(document);
            if (StringUtils.isNotEmpty(bo.getCtVersion()) && !bo.getCtVersion().equals(oldIbaUtil.getIBAValue("ct_version"))) {
                String checkInRemark = bo.getCheckInRemark();
                if (StringUtils.isEmpty(checkInRemark)) {
                    checkInRemark = "用户："+ currentUser.getFullName() +"通过AD工具归档，进行上传主内容并更新内部版本属性值！";
                }
                document = (WTDocument) CtACLUtil.checkout(document, bo.getCheckInRemark());
                document = (WTDocument) CtACLUtil.checkIn(document, bo.getCheckInRemark());
                // 更新内部版本
                IBAUtil newIbaUtil = new IBAUtil(document);
                newIbaUtil.setIBAValue("ct_version", bo.getCtVersion());
                newIbaUtil.updateIBAHolder(document);
            } else {
                String checkInRemark = bo.getCheckInRemark();
                if (StringUtils.isEmpty(checkInRemark)) {
                    checkInRemark = "用户："+ currentUser.getFullName() +"通过AD工具归档，进行上传主内容！";
                }
                document = (WTDocument) CtACLUtil.checkout(document, bo.getCheckInRemark());
                document = (WTDocument) CtACLUtil.checkIn(document, bo.getCheckInRemark());
            }
            // 设置修改人
            CtWTObjectUtil.setModifier(document, currentUser);

            WTPartDescribeLink partDescribeLink = CtPartUtil.getPartDescribeLink(relationPart, document);
            if (partDescribeLink == null) {
                // 主要是处理修订物料的情况
                CtPartUtil.createDescribeLink(relationPart, document);
            }
        }
        return  document;
    }

    /**
     * 上传内容到文档中
     * @param document
     * @param contentRoleType
     * @param fileName
     * @param inputStream
     * @throws Exception
     */
    public void uploadContentToDocument(WTDocument document,
                                        ContentRoleType contentRoleType,
                                        String fileName,
                                        InputStream inputStream) throws Exception {
        try {
            ApplicationData applicationData = null;
            if (ContentRoleType.PRIMARY == contentRoleType) {
                // 先查询文档中是否存在主内容
                QueryResult queryResult = ContentHelper.service.getContentsByRole(document, contentRoleType);
                while (queryResult.hasMoreElements()) {
                    Object object = queryResult.nextElement();
                    if (object instanceof ApplicationData) {
                        applicationData = (ApplicationData) object;
                        break;
                    }
                }
            }

            if (applicationData == null) applicationData = ApplicationData.newApplicationData(document);
            applicationData.setRole(contentRoleType);
            applicationData.setFileName(fileName);
            ContentServerHelper.service.updateContent(document, applicationData,inputStream);
        } catch (Exception e) {
            e.printStackTrace();
            throw new FileUploadException("上传文件：" + fileName + "到文档：" + document.getNumber() + "中失败，异常信息：" + e.getLocalizedMessage());
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
    }

    /**
     * 处理0601文档的文件归档
     * @param pathParamsMap 文件参数Map，key：项目路径下的所有文件名，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0601(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {
        CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
        String docNumberSuffix = createDocumentBo.getDocNumberSuffix();
        String pcbNumber = createDocumentBo.getPcbPart().getNumber();

        if (pathParamsMap.size() >= 1) {
            Map<String, String> suffixMap = new HashMap<>(3);
            suffixMap.put(".pcb", "_001");
            suffixMap.put(".pcbdoc", "_001");
            suffixMap.put(".brd", "_001");

            Iterator<Map.Entry<String, Integer>> iterator = pathParamsMap.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, Integer> item = iterator.next();
                MultipartFile multipartFile = files.get(item.getValue());
                String originalFilename = multipartFile.getOriginalFilename();
                int lastIndexOf = originalFilename.lastIndexOf(".");
                if (lastIndexOf == -1) continue;

                String suffix = originalFilename.substring(lastIndexOf);
                if (!suffixMap.containsKey(suffix.toLowerCase())) continue;

                String value = suffixMap.get(suffix.toLowerCase());
                // 创建文档
                createDocumentBo.setName(ctAdToolProperties.getStringValue(docNumberSuffix + value));
                createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix + value);
                WTDocument docDocument = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
                // 上传主内容
                uploadContentToDocument(docDocument, ContentRoleType.PRIMARY, originalFilename, multipartFile.getInputStream());

                // 将已经归档的文档列表移除
                archiveNumPrefixSet.remove(docNumberSuffix + value);
                // 收集需要添加到基线的文档
                addDocSet.add(docDocument);
                // 将文件信息从Map中移除
                iterator.remove();
            }
        }

        if (pathParamsMap.size() != 0) {
            createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix);
            createDocumentBo.setName(ctAdToolProperties.getStringValue(docNumberSuffix));
            WTDocument document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
            // ZIP压缩包的文件名=PCB编码.PCB型号(版本.YYYYYMMDD)拼版标识yyyymmdd.hhmm.rar
            String zipFileName = createDocumentBo.getCompressName();
            // 打包之后存储路径
            String uploadPath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator
                    + "ext" + File.separator +  "uploadTemp" + File.separator;
            String zipFilePath = uploadPath + File.separator + zipFileName;
            File zipFile = new File(zipFilePath);
            if (zipFile.exists()) {
                zipFile.delete();
                zipFile.createNewFile();
            }
            FileOutputStream fileOutputStream = new FileOutputStream(new File(zipFilePath));
            ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);

            // 压缩
            for (Map.Entry<String, Integer> pathItem : pathParamsMap.entrySet()) {
                MultipartFile multipartFile = files.get(pathItem.getValue());
                // 进行打包操作
                ZipEntry zipEntry = new ZipEntry(pathItem.getKey());
                zipOutputStream.putNextEntry(zipEntry);
                IOUtils.copy( multipartFile.getInputStream(), zipOutputStream);
                zipOutputStream.flush();
                zipOutputStream.closeEntry();
            }
            IOUtils.closeQuietly(zipOutputStream);
            IOUtils.closeQuietly(fileOutputStream);

            uploadContentToDocument(document, ContentRoleType.PRIMARY, zipFileName, new FileInputStream(zipFile));
            // 将已经归档的文档列表移除
            archiveNumPrefixSet.remove(docNumberSuffix);
            // 收集需要添加到基线的文档
            addDocSet.add(document);
        }
    }

    /**
     * 处理0602文档的文件归档
     * @param pathParamsMap 文件参数Map，key：相对于“0602_辅助文件输出”文件夹下的文件路径结构，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0602(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {
        CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
        String docNumberSuffix = createDocumentBo.getDocNumberSuffix();
        String pcbNumber = createDocumentBo.getPcbPart().getNumber();
        WTDocument document = null;
        for (Map.Entry<String, Integer> pathItem : pathParamsMap.entrySet()) {
            MultipartFile multipartFile = files.get(pathItem.getValue());
            String originalFilename = multipartFile.getOriginalFilename();
            int lastIndexOf = originalFilename.lastIndexOf(".");
            String suffix = lastIndexOf != -1 ? originalFilename.substring(lastIndexOf) : "";
            ApplicationData pcbApplicationData = ApplicationData.newApplicationData(document);
            pcbApplicationData.setFileName(originalFilename);
            if (suffix.toLowerCase().equals(".pdf")) {
                if (document == null) {
                    // 0602_001文档编码
                    createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix + "_01");
                    // 0602_001文档名称
                    createDocumentBo.setName(ctAdToolProperties.getStringValue(docNumberSuffix + "_01"));
                    document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
                }
                // 将该文件作为主内容
                uploadContentToDocument(document, ContentRoleType.PRIMARY, originalFilename, multipartFile.getInputStream());
            } else {
                // 处理.pcbdoc、.pcb、.brd文件
                if (suffix.toLowerCase().equals(".pcbdoc")
                        || suffix.toLowerCase().equals(".pcb")
                        || suffix.toLowerCase().equals(".brd")) {
                    // 0602_002文档编码
                    createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix + "_02");
                    // 0602_002文档名称
                    createDocumentBo.setName(ctAdToolProperties.getStringValue(docNumberSuffix + "_02"));
                    WTDocument pcbDocument = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);

                    // 在将.PcbDoc文件放到文档主内容中
                    uploadContentToDocument(pcbDocument, ContentRoleType.PRIMARY, originalFilename, multipartFile.getInputStream());

                    // 将已经归档的文档列表移除
                    archiveNumPrefixSet.remove(docNumberSuffix + "_02");
                    // 收集需要添加到基线的文档
                    addDocSet.add(pcbDocument);
                } else {
                    if (document == null) {
                        // 0602_001文档编码
                        createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix + "_01");
                        // 0602_001文档名称
                        createDocumentBo.setName(ctAdToolProperties.getStringValue(docNumberSuffix + "_01"));
                        document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
                    }
                    // 作为附件
                    uploadContentToDocument(document, ContentRoleType.SECONDARY, originalFilename, multipartFile.getInputStream());
                }
            }
        }

        if (document != null) {
            // 将已经归档的文档列表移除
            archiveNumPrefixSet.remove(docNumberSuffix + "_01");
            // 收集需要添加到基线的文档
            addDocSet.add(document);
        }
    }

    /**
     * 处理0603文档的文件归档
     * @param pathParamsMap 文件参数Map，key：相对于“0603_工程输出”文件夹下所有文件夹的文件路径结构，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0603(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {

        WTPart pcbPart = createDocumentBo.getPcbPart();
        String pcbNumber = pcbPart.getNumber();
        String docNumberSuffix = createDocumentBo.getDocNumberSuffix();

        CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
        if ("0603_002".equals(docNumberSuffix)) {
            Map<String, String> bomFileAndPCBAMap = createDocumentBo.getBomFileAndPCBAMap();
            if (bomFileAndPCBAMap == null || bomFileAndPCBAMap.isEmpty()) return;

            StringBuffer message = null;
            // 已经归档了的文档编码
            String[] handleDocNumbers = new String[bomFileAndPCBAMap.size()];
            int index = 0;
            // 压缩
            for (Map.Entry<String, Integer> pathItem : pathParamsMap.entrySet()) {
                MultipartFile multipartFile = files.get(pathItem.getValue());
                String originalFilename = multipartFile.getOriginalFilename();

                // 获取PCBA料
                String pcbaNumber = bomFileAndPCBAMap.get(originalFilename);
                WTPart pcbaPart = CtPartUtil.getPartByNumber(pcbaNumber, CtConstant.VIEW_DESIGN);
                if (pcbaPart == null) {
                    if (message == null) message = new StringBuffer();
                    message.append("文件：" + originalFilename + "中的PBCA：" + pcbaNumber + "不存在系统中或不存在设计视图！\r\n" );
                    continue;
                }
                IBAUtil ibaUtil = new IBAUtil(pcbaPart);

                // PCB物料编码_0603_002_插件半成品编码
                createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix + "_" + pcbaNumber);
                // EBOM_插件半成品编码_插件半成品型号
                createDocumentBo.setName("EBOM_" + pcbaNumber + "_" + ibaUtil.getIBAValue("ct_model"));
                // 让文档与PCBA料进行关联
                createDocumentBo.setRelationPart(pcbaPart);
                WTDocument document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
                // 不用压缩，直接放到主内容中
                uploadContentToDocument(document, ContentRoleType.PRIMARY, multipartFile.getOriginalFilename(), multipartFile.getInputStream());

                // 创建完恢复成PCB料
                createDocumentBo.setRelationPart(pcbPart);
                handleDocNumbers[index] = createDocumentBo.getNumber();
                // 收集需要添加到基线的文档
                addDocSet.add(document);
            }
            if (message != null) {
                throw new WTException(message.toString().trim());
            }
            // 查询系统中存在的文档，并将其加入基线
            QueryResult queryResult = ctAdToolQuery.queryDocumentByDocumentNumber(pcbNumber + "_" + docNumberSuffix, handleDocNumbers);
            while (queryResult.hasMoreElements()) {
                WTDocumentMaster documentMaster = (WTDocumentMaster) queryResult.nextElement();
                WTDocument document = (WTDocument) CtVersionUtil.getLatest(documentMaster);
                addDocSet.add(document);
            }
            // 将已经归档的文档列表移除
            archiveNumPrefixSet.remove(docNumberSuffix);
        } else {
            createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix);
            createDocumentBo.setName(ctAdToolProperties.getStringValue(docNumberSuffix));
            createDocumentBo.setRelationPart(pcbPart);
            WTDocument document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
            // 打包之后存储路径
            String uploadPath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator
                    + "ext" + File.separator +  "uploadTemp" + File.separator;
            Timestamp partCreateTime = pcbPart.getCreateTimestamp();
            // ZIP压缩包的文件名=文档名.PCB编码.PCB型号(版本.YYYYMMDD)yyyymmdd.hhmm.zip
            String zipFileName = createDocumentBo.getName() + "." + createDocumentBo.getCompressName();
            String zipFilePath = uploadPath + File.separator + zipFileName;
            File zipFile = new File(zipFilePath);
            if (zipFile.exists()) {
                zipFile.delete();
                zipFile.createNewFile();
            }
            FileOutputStream fileOutputStream = new FileOutputStream(new File(zipFilePath));
            ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);

            // 压缩
            for (Map.Entry<String, Integer> pathItem : pathParamsMap.entrySet()) {
                MultipartFile multipartFile = files.get(pathItem.getValue());
                String originalFilename = multipartFile.getOriginalFilename();
                // 进行打包操作
                ZipEntry zipEntry = new ZipEntry(pathItem.getKey());
                zipOutputStream.putNextEntry(zipEntry);
                IOUtils.copy( multipartFile.getInputStream(), zipOutputStream);
                zipOutputStream.flush();
                zipOutputStream.closeEntry();
            }
            IOUtils.closeQuietly(zipOutputStream);
            IOUtils.closeQuietly(fileOutputStream);

            // 上传主要内容
            uploadContentToDocument(document, ContentRoleType.PRIMARY, zipFileName, new FileInputStream(zipFile));
            // 将已经归档的文档列表移除
            archiveNumPrefixSet.remove(docNumberSuffix);
            // 收集需要添加到基线的文档
            addDocSet.add(document);
        }
    }

    /**
     * 处理0604文档的文件归档
     * @param pathParamsMap 文件参数Map，key：相对于“0604_外发光绘文件”文件夹下的文件路径结构，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0604(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {

        String pcbNumber = createDocumentBo.getPcbPart().getNumber();
        CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();

        String makeUp = "";
        if (pathParamsMap.size() >= 1) {
            Map<String, String> suffixMap = new HashMap<>(7);
            suffixMap.put(".doc", "_002");
            suffixMap.put(".docx", "_002");
            suffixMap.put(".xls", "_002");
            suffixMap.put(".xlsx", "_002");
            suffixMap.put(".pcb", "_003");
            suffixMap.put(".pcbdoc", "_003");
            suffixMap.put(".brd", "_003");

            Iterator<Map.Entry<String, Integer>> iterator = pathParamsMap.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, Integer> item = iterator.next();
                MultipartFile multipartFile = files.get(item.getValue());
                String originalFilename = multipartFile.getOriginalFilename();
                int lastIndexOf = originalFilename.lastIndexOf(".");
                if (lastIndexOf == -1) continue;

                String suffix = originalFilename.substring(lastIndexOf);
                if (!suffixMap.containsKey(suffix.toLowerCase())) continue;

                int indexOf = originalFilename.indexOf(".");
                if (indexOf == -1) continue;

                String docName = originalFilename.substring(0, indexOf);
                String docNumberSuffix = ctAdToolProperties.getStringValue(docName);
                if (StringUtils.isEmpty(docNumberSuffix)) continue;

                String value = suffixMap.get(suffix.toLowerCase());
                if ("_003".equals(value)) {
                    // 文件名：PCB拼版.(mxn).PCB编码.PCB型号(版本.YYYYYMMDD)yyyymmdd.hhmm.pcb/pcbdoc/brd
                    String[] split = originalFilename.split("\\.");
                    if (split.length >= 2 && split[1].startsWith("(") && split[1].endsWith(")")) {
                        // 截取拼版的规格
                        makeUp = "拼版" + split[1];
                    }
                }
                // 创建文档
                createDocumentBo.setName(docName);
                createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix);
                WTDocument docDocument = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
                // 上传主内容
                uploadContentToDocument(docDocument, ContentRoleType.PRIMARY, originalFilename, multipartFile.getInputStream());

                // 将已经归档的文档列表移除
                archiveNumPrefixSet.remove(docNumberSuffix);
                // 收集需要添加到基线的文档
                addDocSet.add(docDocument);

                // 将文件信息从Map中移除
                iterator.remove();
            }
        }

        if (pathParamsMap.size() != 0) {
            String docNumberSuffix = createDocumentBo.getDocNumberSuffix();
            docNumberSuffix = docNumberSuffix + "_001";
            String docName = ctAdToolProperties.getStringValue(docNumberSuffix);
            createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix);
            createDocumentBo.setName(docName);
            WTDocument document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
            if (pathParamsMap.size() == 1) {
                // 检查是否压缩文件
                Iterator<Integer> iterator = pathParamsMap.values().iterator();
                Integer index = iterator.next();
                MultipartFile multipartFile = files.get(index);
                if (isCompressedPackage(multipartFile.getOriginalFilename())) {
                    // 若上传的文件是压缩文件，则不压缩
                    // 不用压缩，直接放到主内容中
                    uploadContentToDocument(document, ContentRoleType.PRIMARY, multipartFile.getOriginalFilename(), multipartFile.getInputStream());
                    iterator.remove();
                }
            }
            if (pathParamsMap.size() >= 1) {
                // ZIP压缩包的文件名=外发光绘.PCB编码.PCB型号(版本.YYYYYMMDD)拼版标识yyyymmdd.hhmm.rar
                String zipFileName = null;
                if (StringUtils.isNotEmpty(makeUp)) {
                    String compressName = createDocumentBo.getCompressName();
                    int indexOf = compressName.lastIndexOf(")");
                    zipFileName = createDocumentBo.getName() + "." + compressName.substring(0, indexOf + 1)
                            + makeUp + compressName.substring(indexOf + 1);
                } else {
                    zipFileName = createDocumentBo.getName() + "." + createDocumentBo.getCompressName();
                }
                // 打包之后存储路径
                String uploadPath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator
                        + "ext" + File.separator +  "uploadTemp" + File.separator;
                String zipFilePath = uploadPath + File.separator + zipFileName;
                File zipFile = new File(zipFilePath);
                if (zipFile.exists()) {
                    zipFile.delete();
                    zipFile.createNewFile();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(new File(zipFilePath));
                ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);

                // 压缩
                for (Map.Entry<String, Integer> pathItem : pathParamsMap.entrySet()) {
                    MultipartFile multipartFile = files.get(pathItem.getValue());
                    // 进行打包操作
                    ZipEntry zipEntry = new ZipEntry(pathItem.getKey());
                    zipOutputStream.putNextEntry(zipEntry);
                    IOUtils.copy( multipartFile.getInputStream(), zipOutputStream);
                    zipOutputStream.flush();
                    zipOutputStream.closeEntry();
                }
                IOUtils.closeQuietly(zipOutputStream);
                IOUtils.closeQuietly(fileOutputStream);

                uploadContentToDocument(document, ContentRoleType.PRIMARY, zipFileName, new FileInputStream(zipFile));
            }
            // 将已经归档的文档列表移除
            archiveNumPrefixSet.remove(docNumberSuffix + "_001");
            // 收集需要添加到基线的文档
            addDocSet.add(document);
        }
    }

    /**
     * 处理0605文档的文件归档
     * @param pathParamsMap 文件参数Map，key：相对于“0605_外发钢网文件”文件夹下的文件路径结构，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0605(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {
        String pcbNumber = createDocumentBo.getPcbPart().getNumber();
        CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
        if (pathParamsMap.size() >= 1) {
            Map<String, String> suffixMap = new HashMap<>(4);
            suffixMap.put(".doc", "_002");
            suffixMap.put(".docx", "_002");
            suffixMap.put(".xls", "_002");
            suffixMap.put(".xlsx", "_002");

            Iterator<Map.Entry<String, Integer>> iterator = pathParamsMap.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, Integer> item = iterator.next();
                MultipartFile multipartFile = files.get(item.getValue());
                String originalFilename = multipartFile.getOriginalFilename();
                int lastIndexOf = originalFilename.lastIndexOf(".");
                if (lastIndexOf == -1) continue;

                String suffix = originalFilename.substring(lastIndexOf);
                if (!suffixMap.containsKey(suffix)) continue;

                int indexOf = originalFilename.indexOf(".");
                if (indexOf == -1) continue;

                String docName = originalFilename.substring(0, indexOf);
                String docNumberSuffix = ctAdToolProperties.getStringValue(docName);
                if (StringUtils.isEmpty(docNumberSuffix)) continue;

                // 创建文档
                createDocumentBo.setName(docName);
                createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix);
                WTDocument docDocument = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
                // 上传主内容
                uploadContentToDocument(docDocument, ContentRoleType.PRIMARY, originalFilename, multipartFile.getInputStream());

                // 将已经归档的文档列表移除
                archiveNumPrefixSet.remove(docNumberSuffix);
                // 收集需要添加到基线的文档
                addDocSet.add(docDocument);
                // 将文件信息从Map中移除
                iterator.remove();
            }
        }

        if (pathParamsMap.size() != 0) {
            String docNumberSuffix = createDocumentBo.getDocNumberSuffix();
            docNumberSuffix = docNumberSuffix + "_001";
            String docName = ctAdToolProperties.getStringValue(docNumberSuffix);
            createDocumentBo.setNumber(pcbNumber + "_" + docNumberSuffix);
            createDocumentBo.setName(docName);
            WTDocument document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);

            if (pathParamsMap.size() == 1) {
                // 检查是否压缩文件
                Iterator<Integer> iterator = pathParamsMap.values().iterator();
                Integer index = iterator.next();
                MultipartFile multipartFile = files.get(index);
                if (isCompressedPackage(multipartFile.getOriginalFilename())) {
                    // 若上传的文件是压缩文件，则不压缩
                    // 不用压缩，直接放到主内容中
                    uploadContentToDocument(document, ContentRoleType.PRIMARY, multipartFile.getOriginalFilename(), multipartFile.getInputStream());
                    iterator.remove();
                }
            }
            // 若所剩文件为1个不压缩，否则压缩
            if (pathParamsMap.size() >= 1) {
                // ZIP压缩包的文件名=PCB编码.PCB型号(版本.YYYYMMDD)钢网文件yyyymmdd.hhmm.zip
                String zipFileName = createDocumentBo.getName() + "." + createDocumentBo.getCompressName();
                // 打包之后存储路径
                String uploadPath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator
                        + "ext" + File.separator +  "uploadTemp" + File.separator;
                String zipFilePath = uploadPath + File.separator + zipFileName;
                File zipFile = new File(zipFilePath);
                if (zipFile.exists()) {
                    zipFile.delete();
                    zipFile.createNewFile();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(new File(zipFilePath));
                ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);

                // 压缩
                for (Map.Entry<String, Integer> pathItem : pathParamsMap.entrySet()) {
                    MultipartFile multipartFile = files.get(pathItem.getValue());
                    // 进行打包操作
                    ZipEntry zipEntry = new ZipEntry(pathItem.getKey());
                    zipOutputStream.putNextEntry(zipEntry);
                    IOUtils.copy( multipartFile.getInputStream(), zipOutputStream);
                    zipOutputStream.flush();
                    zipOutputStream.closeEntry();
                }
                IOUtils.closeQuietly(zipOutputStream);
                IOUtils.closeQuietly(fileOutputStream);

                uploadContentToDocument(document, ContentRoleType.PRIMARY, zipFileName, new FileInputStream(zipFile));
            }
            // 将已经归档的文档列表移除
            archiveNumPrefixSet.remove(docNumberSuffix);
            // 收集需要添加到基线的文档
            addDocSet.add(document);
        }
    }

    /**
     * 处理0606文档的文件归档
     * @param pathParamsMap 文件参数Map，key：相对于“0606_PCB EQ及回复文件”文件夹下的文件路径结构，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0606(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {
        // PCB料号
        String pcbNumber = createDocumentBo.getPcbPart().getNumber();
        CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
        for (Map.Entry<String, Integer> pathItem : pathParamsMap.entrySet()) {
            MultipartFile multipartFile = files.get(pathItem.getValue());
            String originalFilename = multipartFile.getOriginalFilename();

            int indexOf = originalFilename.indexOf(".");
            if (indexOf == -1) continue;

            // 文档名称
            String docName = originalFilename.substring(0, indexOf);
            // 根据文档名称找文档编码后缀
            String docNumberSuffix = ctAdToolProperties.getStringValue(docName);
            if (StringUtils.isEmpty(docNumberSuffix)) continue;

            createDocumentBo.setNumber(pcbNumber + "_" +  docNumberSuffix);
            createDocumentBo.setName(docName);

            WTDocument document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
            if (document != null) {
                // 上传主内容
                uploadContentToDocument(document, ContentRoleType.PRIMARY, originalFilename, multipartFile.getInputStream());
                // 收集需要添加到基线的文档
                addDocSet.add(document);
                // 将已经归档的文档列表移除
                archiveNumPrefixSet.remove(docNumberSuffix);
            }
        }
    }

    /**
     * 处理0607文档的文件归档
     * @param pathParamsMap 文件参数Map，key：相对于“0607_内部检查评审文件”文件夹下的文件路径结构，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0607(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {
        fileArchiveBy0606(pathParamsMap, files, addDocSet, archiveNumPrefixSet, createDocumentBo);
    }

    /**
     * 处理0606文档的文件归档
     * @param pathParamsMap 文件参数Map，key：相对于“0608_调试文件”文件夹下的文件路径结构，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0608(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {
        fileArchiveBy0606(pathParamsMap, files, addDocSet, archiveNumPrefixSet, createDocumentBo);
    }

    /**
     * 处理0613文档的文件归档，该文档无需入基线
     * @param pathParamsMap 文件参数Map，key：相对于“0613_焊接附件”文件夹下的文件路径结构，value：上传文件集合的下标
     * @param files 上传文件集合
     * @param addDocSet 需要添加到基线上的文档集合
     * @param archiveNumPrefixSet 需要收集之前归档文档的编码前缀
     * @param createDocumentBo 创建文档BO
     * @throws Exception
     */
    public void fileArchiveBy0613(HashMap<String, Integer> pathParamsMap,
                                  List<MultipartFile> files,
                                  WTHashSet addDocSet,
                                  HashSet<String> archiveNumPrefixSet,
                                  CtCreateDocumentBo createDocumentBo) throws Exception {
        WTPart pcbPart = createDocumentBo.getPcbPart();
        WTUser currentUser = createDocumentBo.getCurrentUser();
        SessionHelper.manager.setAdministrator();
        try {
            // PCB料号
            String pcbNumber = pcbPart.getNumber();
            StringBuffer stringBuffer = new StringBuffer();
            // 若存在相同的文档名则升版的开关
            createDocumentBo.setUpgradeByName(true);
            for (Map.Entry<String, Integer> item : pathParamsMap.entrySet()) {
                MultipartFile multipartFile = files.get(item.getValue());
                // 文件格式：焊接附件.插件半成品编码.插件半成品型号.yyyymmdd.hhmm.xsl/xslx/doc/docx
                String originalFilename = multipartFile.getOriginalFilename();
                String[] split = originalFilename.split("\\.");
                if (split.length < 4) {
                    stringBuffer.append("文件：" + originalFilename + "格式正确，" +
                            "请按【焊接附件.插件半成品编码.插件半成品型号.yyyymmdd.hhmm.xsl/xslx/doc/docx】格式命名文件\r\n");
                    continue;
                }
                WTPart part = CtPartUtil.getPartByNumber(split[1], CtConstant.VIEW_DESIGN);
                if (part == null) {
                    stringBuffer.append("文件名：" + originalFilename + "上的物料：" + split[1]
                            + "不存在PLM系统中或该物料不存在设计视图！\r\n");
                    continue;
                }
                String partState = part.getLifeCycleState().getDisplay(Locale.CHINA);
                CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
                // 先检查物料状态是否需要手动修订
                HashSet needReviseStateSet = ctAdToolProperties.getHashSetValue("need.revise.pcba.state");
                if (needReviseStateSet.contains(partState)) {
                    part = CtAdToolLogic.getInstance().doRevisePart(part);
                } else {
                    // 校验物料状态是否允许修改BON
                    HashSet allowStateSet = ctAdToolProperties.getHashSetValue("allow.update.pcba.bom.state");
                    if (allowStateSet.size() > 0 && !allowStateSet.contains(partState)) {
                        stringBuffer.append("只允许以下物料状态【" + StringUtils.join(allowStateSet, "、")
                                + "】可以文件归档，而插件半成品【" + pcbNumber + "】的状态【" + partState + "】不符合！\r\n");
                    }
                    continue;
                }

                createDocumentBo.setRelationPart(part);
                createDocumentBo.setName(split[0] + "_" + split[1] + "_" + split[2]);
                createDocumentBo.setNumber(pcbNumber + "_" + createDocumentBo.getDocNumberSuffix() + "_" + split[1]);
                WTDocument document = createOrUpgradeDocument(createDocumentBo, CtAdToolConstant.UPGRADE_DOC_NUMBER);
                // 创建完恢复成PCB料
                createDocumentBo.setRelationPart(pcbPart);
                uploadContentToDocument(document, ContentRoleType.PRIMARY, originalFilename, multipartFile.getInputStream());
            }
            if (StringUtils.isNotEmpty(stringBuffer)) {
                throw new WTException(stringBuffer.toString().trim());
            }
        } finally {
            SessionHelper.manager.setPrincipal(currentUser.getName());
        }
    }

    /**
     * 将Excel数据装载到BO
     * @param inputStream Excel文件流
     * @param clazz BO字节类
     * @param fieldRowIndex 字段行，默认从下一行读取数据
     * @param <T>
     * @return
     * @throws Exception
     */
    public <T> List<T> importDataLoadToBo(InputStream inputStream, Class<T> clazz, Integer fieldRowIndex) throws Exception {
        Workbook workbook = null;
        List<T> objectList = null;
        try {
            workbook = WorkbookFactory.create(inputStream);
            Sheet sheet = workbook.getSheetAt(0);

            // 收集所有BO字段，包括父类字段
            Map<String, Field> fieldMap = new HashMap<>();
            Class tempClass = clazz;
            while (tempClass != null) {
                Field[] declaredFields = tempClass.getDeclaredFields();
                for (Field declaredField : declaredFields) {
                    fieldMap.put(declaredField.getName(), declaredField);
                }
                tempClass = tempClass.getSuperclass();
            }

            // 过滤掉Excel中不存在的字段，只保留Excel中的列
            Row fieldRow = sheet.getRow(fieldRowIndex);
            if (fieldRow == null) return null;

            // 获取字段所在列，并存入Map中
            Map<Integer, Field> indexFieldMap = new HashMap<>();
            int lastColIndex = fieldRow.getPhysicalNumberOfCells();
            for (int colIndex = 0; colIndex < lastColIndex; colIndex++) {
                String fieldName = CtExcelReadUtil.getCellValue(sheet, fieldRowIndex, colIndex);
                if (!fieldMap.containsKey(fieldName)) continue;

                indexFieldMap.put(colIndex, fieldMap.get(fieldName));
            }


            int lastRowIndex = sheet.getPhysicalNumberOfRows();
            objectList = new ArrayList<>(lastRowIndex - 1 - fieldRowIndex);
            for (int rowIndex = fieldRowIndex + 1; rowIndex < lastRowIndex; rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) continue;

                T obj = clazz.newInstance();
                for (int colIndex = 0; colIndex < lastColIndex; colIndex++) {
                    Field field = indexFieldMap.get(colIndex);
                    if (field == null) continue;

                    field.setAccessible(true);
                    String cellValue = CtExcelReadUtil.getCellValueNoTrim(sheet, rowIndex, colIndex);
                    if (cellValue == null) cellValue = "";
                    if (field.getType() == String.class) {
                        field.set(obj, cellValue);
                    } else if (field.getType() == Long.class) {
                        field.set(obj, Long.parseLong(cellValue));
                    } else if (field.getType() == Boolean.class) {
                        if ("true".equalsIgnoreCase(cellValue)) {
                            field.set(obj, true);
                        } else if ("false".equalsIgnoreCase(cellValue)) {
                            field.set(obj, false);
                        } else {
                            field.set(obj, Boolean.parseBoolean(cellValue));
                        }
                    } else if (field.getType() == Date.class) {
                        JsonFormat jsonFormat = field.getAnnotation(JsonFormat.class);
                        String format = null;
                        if (jsonFormat == null) {
                            ExcelColumn excelColumn = field.getAnnotation(ExcelColumn.class);
                            if (excelColumn != null) {
                                format = excelColumn.format();
                            }
                        } else {
                            format = jsonFormat.pattern();
                        }
                        if (StringUtils.isNotEmpty(format)) format = CtConstant.DATE_FORMAT;
                        field.set(obj, CtDateUtil.parseStringToDate(cellValue, format));
                    }
                }

                objectList.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            IOUtils.closeQuietly(inputStream);
        }

        return objectList;
    }

    public void exportDataByExcelTemplate(String templatePath, List<?> list, OutputStream outputStream) throws Exception {
        exportDataByExcelTemplate(templatePath, list, outputStream, false);
    }

    /**
     * 根据Excel模板导出数据
     * @param templatePath
     * @param list
     * @param outputStream
     * @param isDeleteFieldRow 是否删除字段行
     * @throws Exception
     */
    public void exportDataByExcelTemplate(String templatePath, List<?> list, OutputStream outputStream, boolean isDeleteFieldRow) throws Exception {
        FileInputStream fileInputStream = null;
        Workbook workbook = null;
        HashMap<String, Integer> colIndexMap = null;
        try {
            fileInputStream = new FileInputStream(templatePath);
            workbook = WorkbookFactory.create(fileInputStream);
            colIndexMap = new HashMap<>();
            Sheet sheet = workbook.getSheetAt(0);
            int rowIndex = sheet.getPhysicalNumberOfRows() - 1;
            Row row = sheet.getRow(rowIndex);

            // 若无数据，则导出空模板
            if (CollectionUtils.isEmpty(list)) {
                if (isDeleteFieldRow) sheet.removeRow(row);
                return;
            }

            // 首先读取每个数据所在的列下标
            for (int colIndex = 0; colIndex < row.getPhysicalNumberOfCells(); colIndex++) {
                Cell cell = row.getCell(colIndex);
                String value = CtExcelReadUtil.getCellFormatValue(cell, row, colIndex);
                if (StringUtils.isNotEmpty(value)) {
                    colIndexMap.put(value, colIndex);
                }
            }

            if (isDeleteFieldRow) {
                // 删除字段行
                sheet.removeRow(row);
            } else {
                // 从下一行开始写入
                rowIndex++;
            }


            // 收集所有BO字段，包括父类字段
            List<Field> fieldsList = new ArrayList<Field>();
            Class clazz = list.get(0).getClass();
            while (clazz != null) {  // 遍历所有父类字节码对象
                Field[] declaredFields = clazz.getDeclaredFields();
                fieldsList.addAll(Arrays.asList(declaredFields));  //将`Filed[]`数组转换为`List<>`然后再将其拼接至`ArrayList`上
                clazz = clazz.getSuperclass();  // 获得父类的字节码对象
            }

            // 执行Excel单元格的写入
            for (Object object : list) {
                for (Field field : fieldsList){
                    Integer colIndex = colIndexMap.get(field.getName());
                    if (colIndex == null) continue;

                    field.setAccessible(true);
                    Object value = field.get(object);
                    if (value == null) continue;

                    String excelValue = "";
                    if (field.getType() == Date.class && value != null){
                        JsonFormat jsonFormat = field.getAnnotation(JsonFormat.class);
                        String format = null;
                        if (jsonFormat == null) {
                            ExcelColumn excelColumn = field.getAnnotation(ExcelColumn.class);
                            if (excelColumn != null) {
                                format = excelColumn.format();
                            }
                        } else {
                            format = jsonFormat.pattern();
                        }
                        if (StringUtils.isNotEmpty(format)) format = CtConstant.DATE_FORMAT;
                        excelValue = CtDateUtil.parseDate((Date) value, format, "GMT+8");
                    }else {
                        excelValue = String.valueOf(value);
                    }
                    if (excelValue == null || "null".equals(excelValue)) continue;

                    Row sheetRow = sheet.getRow(rowIndex);
                    if (!CtFormatUtil.hasContent(sheetRow)){
                        sheetRow=sheet.createRow(rowIndex);
                    }
                    Cell cell = sheetRow.getCell(colIndex);
                    if (cell == null) cell = sheetRow.createCell(colIndex);

                    cell.setCellValue(excelValue);
                }
                rowIndex++;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // 关闭流
            if (workbook != null && outputStream != null) {
                workbook.write(outputStream);
                outputStream.close();
            }
            if (fileInputStream != null) fileInputStream.close();

            workbook = null;
            colIndexMap = null;
        }
    }

    public <T> void  exportDataByExcelTemplate(String templatePath, Map<String, List<T>> mapList, OutputStream outputStream) throws Exception {
        exportDataByExcelTemplate(templatePath, mapList, outputStream, false);
    }

    /**
     * 根据Excel模板导出数据
     * @param templatePath
     * @param mapList key：工作表名，value：工作表对应的数据
     * @param outputStream
     * @param isDeleteFieldRow 是否删除字段行
     * @throws Exception
     */
    public <T> void exportDataByExcelTemplate(String templatePath, Map<String, List<T>> mapList , OutputStream outputStream, boolean isDeleteFieldRow) throws Exception {
        FileInputStream fileInputStream = null;
        Workbook workbook = null;
        HashMap<String, Integer> colIndexMap = null;
        try {
            fileInputStream = new FileInputStream(templatePath);
            workbook = WorkbookFactory.create(fileInputStream);
            colIndexMap = new HashMap<>();

            Sheet sheet = workbook.getSheetAt(0);
            int rowIndex = sheet.getPhysicalNumberOfRows() - 1;
            Row row = sheet.getRow(rowIndex);
            // 首先读取每个数据所在的列下标
            for (int colIndex = 0; colIndex < row.getPhysicalNumberOfCells(); colIndex++) {
                Cell cell = row.getCell(colIndex);
                String value = CtExcelReadUtil.getCellFormatValue(cell, row, colIndex);
                if (StringUtils.isNotEmpty(value)) {
                    colIndexMap.put(value, colIndex);
                }
            }

            System.out.println("colIndexMap >>>>>> " + JSONObject.toJSONString(colIndexMap));
            if (isDeleteFieldRow) {
                // 删除字段行
                sheet.removeRow(row);
            } else {
                // 从下一行开始写入
                rowIndex++;
            }
            // 若无数据，则导出空模板
            if (mapList == null || mapList.isEmpty()) {
                if (isDeleteFieldRow) sheet.removeRow(row);
                return;
            }

            // 收集所有BO字段，包括父类字段
            List<Field> fieldsList = new ArrayList<Field>();
            for (Map.Entry<String, List<T>> item : mapList.entrySet()) {
                // 创建工作表
                Sheet itemSheet = workbook.createSheet(item.getKey());
                // 工作表中的行下标
                int itemRowIndex = 0;
                // 将表头复制到新工作表中
                for (; itemRowIndex < rowIndex; itemRowIndex++) {
                    Row tempRow = sheet.getRow(itemRowIndex);
                    Row itemRow = itemSheet.createRow(itemRowIndex);
                    itemRow.setHeightInPoints(tempRow.getHeightInPoints());
                    for (int colIndex = 0; colIndex < tempRow.getPhysicalNumberOfCells(); colIndex++) {
                        Cell tempCell = tempRow.getCell(colIndex);
                        Cell cell = itemRow.createCell(colIndex);
                        // 设置单元格样式
                        cell.setCellStyle(tempCell.getCellStyle());
                        if (itemRowIndex == 0) {
                            // 设置列宽
                            itemSheet.setColumnWidth(colIndex, sheet.getColumnWidth(colIndex));
                        }
                        CtExcelReadUtil.setExcelCellValue(colIndex, CtExcelReadUtil.getCellValue(sheet, itemRowIndex, colIndex), itemRow);
                    }
                }

                List<?> list = item.getValue();
                if (CollectionUtils.isEmpty(fieldsList)) {
                    Class clazz = list.get(0).getClass();
                    while (clazz != null) {  // 遍历所有父类字节码对象
                        Field[] declaredFields = clazz.getDeclaredFields();
                        fieldsList.addAll(Arrays.asList(declaredFields));  //将`Filed[]`数组转换为`List<>`然后再将其拼接至`ArrayList`上
                        clazz = clazz.getSuperclass();  // 获得父类的字节码对象
                    }
                }

                // 执行Excel单元格的写入
                for (Object object : list) {
                    for (Field field : fieldsList){
                        Integer colIndex = colIndexMap.get(field.getName());
                        if (colIndex == null) continue;

                        field.setAccessible(true);
                        Object value = field.get(object);
                        if (value == null) continue;

                        String excelValue = "";
                        if (field.getType() == Date.class && value != null){
                            JsonFormat jsonFormat = field.getAnnotation(JsonFormat.class);
                            String format = null;
                            if (jsonFormat == null) {
                                ExcelColumn excelColumn = field.getAnnotation(ExcelColumn.class);
                                if (excelColumn != null) {
                                    format = excelColumn.format();
                                }
                            } else {
                                format = jsonFormat.pattern();
                            }
                            if (StringUtils.isNotEmpty(format)) format = CtConstant.DATE_FORMAT;
                            excelValue = CtDateUtil.parseDate((Date) value, format, "GMT+8");
                        }else {
                            excelValue = String.valueOf(value);
                        }
                        if (excelValue == null || "null".equals(excelValue)) continue;

                        Row itemRow = itemSheet.getRow(itemRowIndex);
                        if (!CtFormatUtil.hasContent(itemRow)){
                            itemRow = itemSheet.createRow(itemRowIndex);
                        }
                        Cell cell = itemRow.getCell(colIndex);
                        if (cell == null) cell = itemRow.createCell(colIndex);

                        cell.setCellValue(excelValue);
                    }
                    itemRowIndex++;
                }
            }

            // 将模板中的工作表删除
            workbook.removeSheetAt(workbook.getSheetIndex("Sheet1"));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // 关闭流
            if (workbook != null && outputStream != null) {
                workbook.write(outputStream);
                outputStream.close();
            }
            if (fileInputStream != null) fileInputStream.close();

            workbook = null;
            colIndexMap = null;
        }
    }

    /**
     * 创建审阅对象，并根据受影响对象中的物料添加到网络中心库并生成数据Excel上传到附件中
     * @param associations 所需添加的受影响对象列表
     * @throws Exception
     */
    public void createReviewAndGenerateAttachment(Vector<WTPart> associations) throws Exception {
        String reviewType = CtAdToolProperties.getInstance().getStringValue("review.type");
        String archivePath = CtAdToolProperties.getInstance().getStringValue("review.archive.path");
        if (StringUtils.isEmpty(reviewType)) {
            throw new Exception("CtAdTool.properties文件没有配置review.type的值！");
        }
        if (StringUtils.isEmpty(archivePath)) {
            throw new Exception("CtAdTool.properties文件没有配置review.archive.path的值！");
        }
        if (CollectionUtils.isEmpty(associations)) return;

        Transaction transaction = null;
        WTUser currentUser = (WTUser) CtUserUtil.getCurrentUser();
        // 设置管理员权限
        SessionHelper.manager.setAdministrator();
        try {
            String[] split = archivePath.split("\\|");
            // 获取存储库
            List<Persistable> persistableList = getPersistableByColumnName(WTLibrary.class, "NAMECONTAINERINFO", split[0]);
            if (CollectionUtils.isEmpty(persistableList)) {
                throw new Exception("未从系统中找到存储库名称为[" + split[0] + "]对应的存储库！");
            } else if (persistableList.size() > 1) {
                throw new Exception("系统中存在多个存储库名称为[" + split[0] + "]对应的存储库！");
            }

            String partNumbers = "";
            // 将物料所在网络中心库的信息通过Excel上传到审阅附件中
            List<CtCentralLibraryBo> boList = new ArrayList<>();
            for (Persistable persistable : associations) {
                if (persistable instanceof  WTPart) {
                    WTPart part = (WTPart) persistable;
                    partNumbers += "," + part.getNumber();
                    CtCentralLibraryBo bo = loadCentralLibraryBo(part);
                    setCentralLibraryId(part, bo);
                    Date currentTime = new Date();
                    bo.setCreateTime(currentTime);
                    bo.setModifyTime(currentTime);
                    boList.add(bo);
                }
                partNumbers = partNumbers.substring(1);
            }
            if (StringUtils.isEmpty(partNumbers)) {
                // 说明受影响对象中没有物料，不创建审阅对象
                return;
            }

            transaction = new Transaction();
            transaction.start();

            WTLibrary library = (WTLibrary) persistableList.get(0);
            Folder folder = CtFolderUtil.getFolder(split[1], library);
            PersistableAdapter persistableAdapter = new PersistableAdapter(reviewType, null, null);
            persistableAdapter.load("name", "containerReference", "folder.id", "iterationInfo.creator", "iterationInfo.modifier");
            persistableAdapter.set("name", partNumbers);
            persistableAdapter.set("containerReference", library);
            persistableAdapter.set("folder.id", folder);
            persistableAdapter.set("iterationInfo.creator", currentUser);
            persistableAdapter.set("iterationInfo.modifier", currentUser);

            WTChangeReview changeReview = (WTChangeReview) persistableAdapter.apply();
            changeReview = (WTChangeReview) PersistenceHelper.manager.save(changeReview);

            // 添加受影响对象至审阅中
            ChangeHelper2.service.storeAssociations(ChangeReviewItemLink.class, changeReview, associations);

            String templatePath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator
                    + CtAdToolConstant.TEMPLATE_RELATIVE_PATH + "网络中心库模板.xlsx";
            // 导出文件路径
            String exportPath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator
                    + "ext" + File.separator +  "uploadTemp" + File.separator + partNumbers + ".xlsx";
            FileOutputStream fileOutputStream = new FileOutputStream(exportPath);
            exportDataByExcelTemplate(templatePath, boList, fileOutputStream);

            // 最后将导出文件上传到审阅对象的附件中
            ApplicationData applicationData = ApplicationData.newApplicationData(changeReview);
            applicationData.setRole(ContentRoleType.SECONDARY);
            ContentServerHelper.service.updateContent(changeReview, applicationData, exportPath);

            // 将数据添加到网络中心库
            String failNumbers = "";
            CtAdToolService ctAdToolService = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolService.class);
            for (CtCentralLibraryBo bo : boList) {
                boolean success = ctAdToolService.saveCentralLibrary(bo).contains("成功");
                if (!success) {
                    failNumbers += CtAdToolConstant.STRING_SEPARATOR + bo.getMaterialCode();
                }
            }
            if (StringUtils.isEmpty(failNumbers)) {
                System.out.println("物料：" + partNumbers + "成功添加到网络中心库！");
                if (transaction != null) transaction.commit();
            } else {
                throw new Exception(failNumbers.substring(1) + "等物料添加到网络中心库失败！");
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
            throw new WTException(e, "将物料信息入网络中心库失败，后台异常信息：" + e.getLocalizedMessage());
        } finally {
            SessionHelper.manager.setPrincipal(currentUser.getName());
            transaction = null;
        }
    }

    /**
     * 通过某个字段高级查询所需要的对象
     * @param clazz 对象的类
     * @param columnName 字段名
     * @param columnValue 匹配值，精确匹配
     * @return
     */
    public List<Persistable> getPersistableByColumnName(Class clazz, String columnName, String columnValue) {
        List<Persistable> persistableList = null;
        try {
            QuerySpec querySpec = new QuerySpec(clazz);
            querySpec.setAdvancedQueryEnabled(true);
            String alias = querySpec.getFromClause().getAliasAt(0);
            querySpec.appendWhere(
                    new SearchCondition(
                            new TableColumn(alias, columnName),
                            SearchCondition.EQUAL,
                            ConstantExpression.newExpression(columnValue)),
                    new int[]{0});
            QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
            persistableList = new ArrayList<>(queryResult.size());
            while (queryResult.hasMoreElements()) {
                persistableList.add((Persistable) queryResult.nextElement());
            }
        } catch (Exception e) {
            System.out.println("查询" + clazz.getSimpleName() + "表中的列名=" + columnName + "，值=" + columnValue
                    + "对于的数据失败！");
            e.printStackTrace();
        }
        return persistableList;
    }

    /**
     * 获取逗号拼接的位号
     * @param positionNo
     * @return
     */
    public  String getLatestPositionNo(String positionNo) {
        String latestPositionNo = "";
        if (StringUtils.isNotEmpty(positionNo)) {
            // 2021/10/20 硬件工程师确认最新物料清单的工位是英文逗号+空格
            if (positionNo.contains(", ")) {
                // 最新版物料清单的位号是以英文逗号+空格作为拼接符
                latestPositionNo = positionNo.replaceAll(", ", CtAdToolConstant.STRING_SEPARATOR);
            } else if (positionNo.contains(" ")) {
                // 第一版物料清单的位号是以空格作为拼接符
                latestPositionNo = positionNo.replaceAll(" ", CtAdToolConstant.STRING_SEPARATOR);
            } else {
                // 默认认为是逗号拼接
                latestPositionNo = positionNo;
            }
        }
        return latestPositionNo.trim();
    }

    /**
     * 获取物料信息
     * @param part
     * @return
     */
    public Map<String, String> getPartInfo(WTPart part) {
        Map<String, String> partInfoMap = new HashMap<>();
        if (part == null) return partInfoMap;

        IBAUtil ibaUtil = new IBAUtil(part);
        partInfoMap.put("partNumber", part.getNumber());
        partInfoMap.put("partName", part.getName());
        partInfoMap.put("currentVersion", ibaUtil.getIBAValue("ct_banci"));

        return partInfoMap;
    }

    /**
     * 同步临时库的PLM数据
     * @param part
     * @param libraryStatus 库的状态，若有值则不更新PLM所有属性
     * @throws Exception
     */
    public void syncTempCentralLibrary(WTPart part, String libraryStatus) throws Exception {
        if (part == null) return;

        CtCentralLibraryParamsBo paramsBo = new CtCentralLibraryParamsBo();
        paramsBo.setTableName(CtAdToolConstant.LIBRARY_TEMP);
        paramsBo.setPartNumber(part.getNumber());
        List<CtCentralLibraryBo> boList = ctAdToolQuery.queryCentralLibrary(paramsBo);
        if (CollectionUtils.isEmpty(boList)) return;

        for (CtCentralLibraryBo bo : boList) {
            if (StringUtils.isEmpty(libraryStatus)) {
                // 重新装载PLM属性
                loadCentralLibraryBo(bo, part);
            } else {
                bo.setMaterialStatus(libraryStatus);
            }
            // 更新表数据
            ctAdToolQuery.updateById(bo);
        }
    }

    public void syncTempCentralLibrary(WTPart part) throws Exception {
        syncTempCentralLibrary(part, null);
    }


    /**
     * 修订物料操作
     * @param revisionControlled
     * @param targetState 目标状态
     * @param isEnlargePermissions 是否放大权限
     * @return
     * @throws Exception
     */
    public RevisionControlled doReviseObject(RevisionControlled revisionControlled,
                                             String targetState,
                                             boolean isEnlargePermissions) throws Exception {
        if (revisionControlled == null) return null;

        Boolean flag = null;
        // 放大权限
        if (isEnlargePermissions) {
            flag = SessionServerHelper.manager.setAccessEnforced(false);
        }
        RevisionControlled newRevisionControlled = null;
        try {
            newRevisionControlled = (RevisionControlled) VersionControlHelper.service.newVersion(revisionControlled);
        } catch (Exception e) {
            // 尝试重置生命周期
            State state = revisionControlled.getLifeCycleState();
            LifeCycleManaged lifeCycleManaged = LifeCycleServerHelper.service.doReassign(revisionControlled, revisionControlled.getLifeCycleTemplate());
            LifeCycleServerHelper.service.setState(lifeCycleManaged, state);
            LifeCycleServerHelper.service.doSubmit(lifeCycleManaged);

            newRevisionControlled = (RevisionControlled) VersionControlHelper.service.newVersion(revisionControlled);
        } finally {
            // 恢复权限
            if (flag != null) SessionServerHelper.manager.setAccessEnforced(flag);
        }

        String prefix = "";
        if (revisionControlled instanceof WTPart) {
            WTPart part = (WTPart) revisionControlled;
            prefix = "物料["+ part.getNumber() + "]";
        } else if (revisionControlled instanceof WTDocument) {
            WTDocument document = (WTDocument) revisionControlled;
            prefix = "文档["+ document.getNumber() + "]";
        }
        if (newRevisionControlled == null) {
            throw new WTException(prefix  + "修订失败！");
        } else if (StringUtils.isNotEmpty(targetState)){
            // 设置状态
//            LifeCycleServerHelper.service.setState((LifeCycleManaged) revisionControlled, State.toState(targetState));
            LifeCycleState lifeCycleState =  new LifeCycleState();
            lifeCycleState.setState(State.toState(targetState));
            newRevisionControlled.setState(lifeCycleState);
        }

        newRevisionControlled = (RevisionControlled) PersistenceHelper.manager.save(newRevisionControlled);
        return newRevisionControlled;
    }

    public WTPart doRevisePart(WTPart part) throws Exception {
        return (WTPart) doReviseObject(part, "RDmodification", true);
    }

    /**
     * PCB料入库
     * @param orgPart
     * @param copyPart
     */
    public void pcbWarehousing(WTPart orgPart, WTPart copyPart)  {
        try {
            // 该料若不入PCB库，则直接返回
            if (!CtAdToolConstant.LIBRARY_PCB.equals(getCentralLibraryTableName(orgPart))) return;

            // 再检查物料是否入库
            if (!isCanWarehousing(copyPart)) return;

            // 检查内部版本是否一致
            IBAUtil orgIbaUtil = new IBAUtil(orgPart);
            IBAUtil copyIbaUtil = new IBAUtil(copyPart);
            String orgVersion = orgIbaUtil.getIBAValue("ct_banci");
            String copyVersion = copyIbaUtil.getIBAValue("ct_banci");
            if (orgVersion == null) orgVersion = "";
            if (copyVersion == null) copyVersion = "";
            System.out.println("orgVersion >>>>>>>>> " + orgVersion);
            System.out.println("copyVersion >>>>>>>>> " + copyVersion);
            if (orgVersion.equals(copyVersion)) return;

            CtCentralLibraryBo libraryBo = loadCentralLibraryBo(copyPart);
            setCentralLibraryId(copyPart, libraryBo);
            CtCentralLibraryBo selectBo = ctAdToolQuery.selectOneDataByBo(libraryBo);
            if (selectBo == null) {
                ctAdToolQuery.insert(libraryBo);
            }
        } catch (Exception e) {
            System.out.println("ext.plm.adTool.CtAdToolLogic.addPcbData 物料：" + orgPart.getNumber() + "入库失败！");
            e.printStackTrace();
        }
    }
}
