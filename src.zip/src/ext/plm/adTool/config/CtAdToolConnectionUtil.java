package ext.plm.adTool.config;

import org.apache.commons.collections.CollectionUtils;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * 数据库连接配置信息
 * @author liangzh
 */
public class CtAdToolConnectionUtil {

    private static final List<Connection> pool = new ArrayList<>();
    private static final int POOL_COUNT = 5;

    // 是否正在初始连接
    private volatile static boolean isInitConn = false;

    private CtAdToolConnectionUtil(){

    }

    /**
     * 初始化连接数大小
     */
    static{
        init();
    }


    /**
     * 添加一个连接到池子中,应该考虑最大上限
     * @param conn
     */
    private static void add(Connection conn){
        if(conn != null){
            pool.add(conn);
        }
    }

    /**
     * 移除一个连接
     * @param conn
     */
    private static void remove(Connection conn){
        pool.remove(conn);
    }

    public static void init() {
        if (!isInitConn) {
            synchronized (CtAdToolConnectionUtil.class) {
                if (!isInitConn) {
                    isInitConn = true;
                    System.out.println("ext.plm.adTool.config.CtAdToolConnectionUtil.init");
                    if (CollectionUtils.isNotEmpty(pool)) {
                        // 先清空池
                        pool.clear();
                    }
                    try {
                        Connection connection = null;
                        for (int i = 0; i < POOL_COUNT; i++) {
                            pool.add(getConnection());
                        }
                    } catch (Exception e) {
                        System.out.println("初始化AD工具数据库连接失败，异常信息：" + e.getLocalizedMessage());
                    }
                }
            }
        }
        isInitConn = false;
    }

    /**
     * 获取一个连接,当连接池中的不够用时，新建一个
     */
    public static Connection get() throws Exception {
        Connection conn = null;
        if(!pool.isEmpty()){
            conn = pool.get(0);
            remove(conn);
        }else{
            conn = getConnection();
            add(conn);
        }
        if (conn == null) {
            throw new Exception("获取AD工具数据库连接失败，请联系管理员！");
        }
        return conn;
    }

    /**
     * 使用完毕之后，再放回池子中
     * @return
     */
    public static void backConn(Connection conn){
        add(conn);
    }

    /**
     * 新建一个连接
     * @return
     */
    private static Connection getConnection() throws Exception{
        InetAddress inetAddress = InetAddress.getLocalHost();
        String host = inetAddress.getHostName();
        System.out.println("ext.plm.adTool.config.CtAdToolConnectionUtil.getConnection host >>>>>>> " + host);

        String suffix="";
        if (host.contains("plmlocal")){
            suffix="local";
        }else if ("plmdemo".equals(host)){
            suffix="demo";
        }else if ("plmtest".equals(host)){
            suffix="test";
        }else if (host.contains("plmapp")){
            suffix = "pro";
        }else if (host.contains("plmuat")){
            suffix = "test";
        }
        
        Properties properties = null;
        try {
            properties = new Properties();
            properties.load(new InputStreamReader(CtAdToolConnectionUtil.class.getResourceAsStream("adToolDB-"+suffix+".properties"), StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("获取AD工具数据库连接配置信息失败>>>>>>>>>>>>>"+e.getMessage());
            e.printStackTrace();
        }

        Connection connection = null;
        try {
            Class.forName(properties.get("driverClassName").toString());
            connection= DriverManager.getConnection(properties.get("url").toString(), properties.get("username").toString(),properties.get("password").toString());
            connection.setAutoCommit(false);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("获取AD工具数据库连接失败，异常信息：" + e.getLocalizedMessage());
        }
        return connection;
    }

}
