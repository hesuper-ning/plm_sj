package ext.plm.adTool.config;

public class CtAdToolConstant {

    /**
     * 字符串分隔符
     */
    public static final String STRING_SEPARATOR = ",";

    /**
     * PLM物料更新标识
     */
    public static final String PLM_PART_UPDATE_FLAG = "PLM物料信息";

    /**
     * ERP物料更新标识
     */
    public static final String RRP_PART_UPDATE_FLAG = "PLM物料信息";

    /**
     * 物料建库标志
     */
    public static final String YES_FLAG = "是";

    /**
     * 归档标识
     */
    public static final String ARCHIVE_KEY = "archive.";

    /**
     * 通过文档名升级文档小版本
     */
    public static final String UPGRADE_DOC_NAME = "name";

    /**
     * 通过文档编码升级文档小版本
     */
    public static final String UPGRADE_DOC_NUMBER = "number";

    /**
     * 模板相对路径
     */
    public static final String TEMPLATE_RELATIVE_PATH = "ext/plm/adTool/config/";

    /**
     * 最新的物料清单中的位号拼接符
     */
    public static final String LATEST_POSITION_NO_SEPARATOR = ", ";

    /**
     * 综合库名
     */
    public static final String LIBRARY = "\"ZNetworkCentralLibrary\"";

    /**
     * PCb库名
     */
    public static final String LIBRARY_PCB = "\"ZNetworkCentralLibrary_PCB\"";

    /**
     * 半成品库名
     */
    public static final String LIBRARY_BCP = "\"ZNetworkCentralLibrary_BCP\"";

    /**
     * CBB库名
     */
    public static final String LIBRARY_CBB = "\"ZNetworkCentralLibrary_CBB\"";

    /**
     * 临时库名
     */
    public static final String LIBRARY_TEMP = "\"ZNetworkCentralLibrary_Temp\"";

    /**
     * 文件归档时可编辑操作
     */
    public static final String FILE_ARCHIVE_EDIT = "文档可编辑";

    /**
     * 文件归档时修订操作
     */
    public static final String FILE_ARCHIVE_REVISE = "文档修订编辑";

    /**
     * 文件归档时物料和文档都修订操作
     */
    public static final String FILE_ARCHIVE_PART_DOC_REVISE = "物料修订且文档文档修订";
}
