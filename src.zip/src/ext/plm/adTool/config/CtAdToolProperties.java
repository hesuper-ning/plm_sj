package ext.plm.adTool.config;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Properties;

/**
 * @author TanRuoTao
 */
public class CtAdToolProperties {

	private static volatile CtAdToolProperties instance;

	private Properties properties;

	private JSONObject fileArchiveStateConfig;

	private CtAdToolProperties() {
		initProperties();
		initFileArchiveStateConfig();
	}

	public static CtAdToolProperties getInstance() {
		if (instance == null) {
			synchronized (CtAdToolProperties.class) {
				if (instance == null) {
					instance = new CtAdToolProperties();
				}
			}
		}
		return instance;
	}

	/**
	 * 初始化properties文件
	 */
	private void initProperties() {
		try {
			this.properties = new Properties();
			this.properties.load(new InputStreamReader
					(CtAdToolProperties.class.getResourceAsStream("CtAdTool.properties"), StandardCharsets.UTF_8));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getStringValue(String key) {
		return this.properties.getProperty(key);
	}

	public HashSet getHashSetValue(String key) {
		HashSet<String> resultSet = new HashSet<>(0);
		String value = this.properties.getProperty(key);
		if (StringUtils.isNotEmpty(value)) {
			String[] values = value.split(",");
			for (String item : values) {
				resultSet.add(item);
			}
		}
		return resultSet;
	}

	public void reload() {
		initProperties();
		initFileArchiveStateConfig();
	}

	/**
	 * 初始化文件归档的状态配置
	 */
	private void initFileArchiveStateConfig() {
		try {
			String jsonString = IOUtils.toString(CtAdToolProperties.class.getResourceAsStream("fileArchiveStateConfig.json"), StandardCharsets.UTF_8);
			fileArchiveStateConfig = JSONObject.parseObject(jsonString);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取文件归档的状态配置
	 */
	public JSONObject getFileArchiveStateConfig() {
		return fileArchiveStateConfig;
	}
}
