package ext.plm.adTool;

import com.alibaba.fastjson.JSONObject;
import ext.plm.adTool.bo.CtCentralLibraryBo;
import ext.plm.adTool.config.CtAdToolProperties;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bean.CtBeanService;
import ext.plm.certification.CtCertificationServiceImpl;
import ext.plm.common.CtConstant;
import ext.plm.project.CtProjectLogic;
import ext.plm.util.*;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import wt.doc.WTDocument;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.services.ServiceFactory;
import wt.vc.struct.StructHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Vector;

public class CtAdToolShell implements Serializable, RemoteAccess {
    private static final long serialVersionUID = 1L;

    private  static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);

    public static void main(String[] args) throws Exception {
        String host = args[0];
        if (!RemoteMethodServer.ServerFlag) {
            Class[] cls = { String[].class };
            Object[] obj = { args };
            try {
                RemoteMethodServer rms = RemoteMethodServer.getDefault();
                if ("plm".equals(host)) {
                    rms.setUserName("wcadmin");
                    rms.setPassword("fhsj.com");
                } else if ("demo".equals(host) || "plmtest".equals(host)) {
                    rms.setUserName("wcadmin");
                    rms.setPassword("wcadmin");
                }
                rms.invoke("main", CtAdToolShell.class.getName(), null, cls, obj);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        String methodName = args[1];
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        CtAdToolService ctAdToolService = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolService.class);
        if ("importAdData".equals(methodName)) {
            String partNumber = args[2];
            boolean isCreate = true;
            if (args.length > 3) {
                isCreate = "true".equalsIgnoreCase(args[3]);
            }
            String[] numberArray = partNumber.split(",");
            int success = 0;
            String failNumber = "";
            for (String number : numberArray) {
                WTPart part = CtPartUtil.getPartByNumber(number);
                boolean canWarehousing = ctAdToolLogic.isCanWarehousing(part);
                if (canWarehousing) {
                    if (isCreate) {
                        Vector<WTPart> vector = new Vector<>();
                        vector.add(part);
                        try {
                            ctAdToolLogic.createReviewAndGenerateAttachment(vector);
                            success++;
                        } catch (Exception e) {
                            e.printStackTrace();
                            failNumber += "," + number;
                        }
                    } else {
                        CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                        ctAdToolLogic.setCentralLibraryId(part, bo);
                        System.out.println("bo >>>>>>>> " + JSONObject.toJSONString(bo));
                        String message = ctAdToolService.saveCentralLibrary(bo);
                        if (message.contains("成功")) {
                            success++;
                        } else {
                            failNumber += "," + number;
                        }
                    }
                }
            }
            if (isCreate) {
                System.out.println("创建审阅成功的个数：" + success);
                System.out.println("创建审阅失败的物料编码：" + failNumber);
            } else {
                System.out.println("导入成功的个数：" + success);
                System.out.println("导入失败的物料编码：" + failNumber);
            }
        } else if ("reload".equals(methodName)) {
            CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
            String key = "";
            if (args.length > 2) {
                key = args[2];
            }
            if (StringUtils.isNotEmpty(key)) {
                System.out.println("before >>>>>> " + ctAdToolProperties.getStringValue(key));
            }
            ctAdToolProperties.reload();
            if (StringUtils.isNotEmpty(key)) {
                System.out.println("after >>>>>> " + ctAdToolProperties.getStringValue(key));
            }
        } else if ("updateDocInnerVersion".equals(methodName)) {
            // windchill ext.plm.adTool.CtAdToolShell plm updateDocInnerVersion D:\123.xlsx ct_version
            try {
                StringBuilder message = new StringBuilder();
                File file = new File(args[2]);
                String versionInnerName = args[3];
                Workbook workbook = WorkbookFactory.create(file);
                Sheet sheet = workbook.getSheetAt(0);
                int lastRowIndex = sheet.getPhysicalNumberOfRows();
                System.out.println("lastRowIndex >>>>>>>>> " + lastRowIndex);
                for (int rowIndex = 1; rowIndex < lastRowIndex; rowIndex++) {
                    int rowCount = rowIndex + 1;
                    if (rowCount % 100 == 0) {
                        System.out.println(" >>>>>>> 已经执行到第 " + rowCount + " 了！ >>>>>>>");
                    }
                    if (rowCount == lastRowIndex + 1) {
                        System.out.println(" >>>>>>> 已经执行到最后一行了，行数为 " + rowCount + " ！ >>>>>>>");
                    }
                    String id = CtExcelReadUtil.getCellValue(sheet, rowIndex, 0);
                    String version = CtExcelReadUtil.getCellValue(sheet, rowIndex, 1);
                    String newVersion = null;
                    if (!version.contains(".")) {
                        // 插入点
                        newVersion = version.substring(0, 2) + "." + version.substring(2);
                    } else {
                        newVersion = version;
                    }
                    WTDocument document = (WTDocument) CtWTObjectUtil.getObjectByOid("OR:" + WTDocument.class.getName() + ":" + id);
                    if (document == null) {
                        message.append("第" + rowCount + "行中文档ID：" + id + " ，系统中不存在该文档ID！\r\n");
                        continue;
                    }
                    try {
                        IBAUtil ibaUtil = new IBAUtil(document);
                        ibaUtil.setIBAValue(versionInnerName, newVersion);
                        ibaUtil.updateIBAHolder(document);
                    } catch (Exception e) {
                        e.printStackTrace();
                        message.append("第" + rowCount + "行中文档【" + document.getNumber() + " -> "
                                + CtVersionUtil.getVersionInfo(document) + "】更新属性失败！\r\n");
                        continue;
                    }
                }

                if (StringUtils.isNotEmpty(message)) {
                    System.out.println("开始执行日志输出 >>>>>>>>>>>>>>>>>> ");
                    String logFilePath = CtCommonUtil.getWTHomePath() + File.separator + "logs" + File.separator
                            + "updateDocInnerVersion-"
                            + System.currentTimeMillis() + ".log";
                    File logFile = new File(logFilePath);
                    OutputStream outputStream = new FileOutputStream(logFile);
                    IOUtils.write(message.toString(), outputStream, "UTF-8");
                    IOUtils.closeQuietly(outputStream);
                    System.out.println("结束执行日志输出 >>>>>>>>>>>>>>>>>> ");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if ("getAllProjectHours".equals(methodName)){
            // windchill ext.plm.adTool.CtAdToolShell demo getAllProjectHours
            // windchill ext.plm.adTool.CtAdToolShell plm getAllProjectHours
            /*CtWorkReportServiceImpl bean = CtBeanFactory.newCtBeanFactory().getBean(CtWorkReportServiceImpl.class);
            bean.addOfflineProject();*/
            //beanService.doMethod(CtWorkReportServiceImpl.class, "addOfflineProject", null);
            CtProjectLogic.activityInform();
        }else if ("sendCertfDocExpireNoticeMail".equals(methodName)){
            // windchill ext.plm.adTool.CtAdToolShell demo sendCertfDocExpireNoticeMail
            // windchill ext.plm.adTool.CtAdToolShell plm sendCertfDocExpireNoticeMail
            beanService.doMethod(CtCertificationServiceImpl.class,"sendCertfDocExpireNoticeMail",null);
        }else if ("brushRelationPartDoc".equals(methodName)){
            // windchill ext.plm.adTool.CtAdToolShell demo brushRelationPartDoc /home/物料编码关联错的数据.xlsx
            // windchill ext.plm.adTool.CtAdToolShell plm brushRelationPartDoc /home/物料编码关联错的数据.xlsx
            brushRelationPartDoc(args[2]);
        }
    }

    public static void brushRelationPartDoc(String filePath) throws Exception {
        File file = new File(filePath);
        Workbook workbook = WorkbookFactory.create(file);
        Sheet sheet = workbook.getSheetAt(0);
        for (int rowIndex = 1; rowIndex < sheet.getPhysicalNumberOfRows(); rowIndex++) {
            String docNumber = CtExcelReadUtil.getCellValue(sheet, rowIndex, 0);
            String currentRelationPartNum = CtExcelReadUtil.getCellValue(sheet, rowIndex, 1);
            if (StringUtils.isBlank(docNumber)) continue;

            WTDocument document = CtDocUtil.getDocumentByNumber(docNumber);
            IBAUtil ibaUtil = new IBAUtil(document);
            String relationPartNum = ibaUtil.getIBAValue("ct_materialsnumber");
            if (StringUtils.isNotEmpty(relationPartNum) && !relationPartNum.equals(currentRelationPartNum)) {
                // 说明该值已经发送改变，不做刷新
                continue;
            }

            String newRelationPartNum = docNumber.substring(docNumber.indexOf("_"));
            ibaUtil.setIBAValue("ct_materialsnumber", newRelationPartNum);
            ibaUtil.updateIBAHolder(document);

            // 刷说明部件
            QueryResult queryResult = StructHelper.service.navigateDescribes(document, WTPartDescribeLink.class, false);
            while (queryResult.hasMoreElements()) {
                WTPartDescribeLink partDescribeLink = (WTPartDescribeLink) queryResult.nextElement();
                PersistenceServerHelper.manager.remove(partDescribeLink);
            }

            WTPart relationPart = CtPartUtil.getPartByNumber(newRelationPartNum, CtConstant.VIEW_DESIGN);
            if (relationPart != null) {
                CtPartUtil.createDescribeLink(relationPart, document);
            }

            System.out.println(">>>>>>>>>>>>>>>>> 已经刷完该文档 -> " + docNumber);
        }
    }
}