package ext.plm.adTool.thread;

import ext.plm.adTool.CtAdToolLogic;
import ext.plm.adTool.bo.CtCreateDocumentBo;
import org.springframework.web.multipart.MultipartFile;
import wt.fc.collections.WTArrayList;
import wt.method.MethodContext;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CountDownLatch;

public class CtFileArchiveWork extends Thread{

    private MethodContext methodContext;
    private  String methodName;
    private HashMap<String, Integer> pathParamsMap;
    private List<MultipartFile> files;
    private WTArrayList addDocList;
    private HashSet<String> archiveNumPrefixSet;
    private CtCreateDocumentBo createDocumentBo;
    private CountDownLatch countDownLatch;
    private StringBuffer stringBuffer;

    public CtFileArchiveWork(MethodContext methodContext,
                             String methodName,
                             HashMap<String, Integer> pathParamsMap,
                             List<MultipartFile> files,
                             WTArrayList addDocList,
                             HashSet<String> archiveNumPrefixSet,
                             CtCreateDocumentBo createDocumentBo,
                             CountDownLatch countDownLatch,
                             StringBuffer stringBuffer){

        this.methodContext = methodContext;
        this.methodName = methodName;
        this.pathParamsMap = pathParamsMap;
        this.files = files;
        this.addDocList = addDocList;
        this.archiveNumPrefixSet = archiveNumPrefixSet;
        this.createDocumentBo = createDocumentBo;
        this.countDownLatch = countDownLatch;
    }

    @Override
    public void run() {
        System.out.println("开始执行文件归档功能.......");
        try {
            MethodContext mc = MethodContext.getContext(Thread.currentThread());

            if (mc == null){
                System.out.println(Thread.currentThread().getId()+",注册上下文>>>>>>>>>>>>>>>>>>>>>>>>");
                mc = new MethodContext(methodContext);
            }

            CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
            Method method = ctAdToolLogic.getClass().getMethod(methodName, HashMap.class, List.class, WTArrayList.class, HashSet.class, CtCreateDocumentBo.class);
            try {
                method.invoke(ctAdToolLogic, pathParamsMap, files, addDocList, archiveNumPrefixSet, createDocumentBo);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                throw e;
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                throw e;
            } catch (InvocationTargetException e) {
                e.printStackTrace();
                Throwable throwable = e.getTargetException();
                throw new Exception(throwable.getLocalizedMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            stringBuffer.append("处理：" + methodName + "目录文件归档时发生错误，异常信息：" + e.getLocalizedMessage() + "\r\n");
        }
        countDownLatch.countDown();//工人完成工作，计数器减一
    }
}
