package ext.plm.adTool.thread;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class CtThreadPoolExecutor {

    // 核心线程池大小
    private static final int CORE_POOL_SIZE = 8;
    // 最大线程池大小
    private static final int MAX_POOL_SIZE = 10;
    // 阻塞任务队列大小
    private static final int QUEUE_CAPACITY = 2000;
    // 空闲线程存活时间
    private static final Long KEEP_ALIVE_TIME = 1L;

    public static ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
            CORE_POOL_SIZE,
            MAX_POOL_SIZE,
            KEEP_ALIVE_TIME,
            TimeUnit.SECONDS,
            new ArrayBlockingQueue<Runnable>(QUEUE_CAPACITY),
            new ThreadPoolExecutor.CallerRunsPolicy());

    public static void submit(Runnable runnable) {
        threadPoolExecutor.submit(runnable);
    }
}
