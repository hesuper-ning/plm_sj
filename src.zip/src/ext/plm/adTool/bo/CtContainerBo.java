package ext.plm.adTool.bo;

/**
 * 容器BO
 */
public class CtContainerBo {

    /**
     * 容器OID
     */
    private String oid;

    /**
     * 容器名
     */
    private String name;

    /**
     * 成品编码
     */
    private String finishedMaterialCode;

    /**
     * 容器类型
     */
    private String type;

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFinishedMaterialCode() {
        return finishedMaterialCode;
    }

    public void setFinishedMaterialCode(String finishedMaterialCode) {
        this.finishedMaterialCode = finishedMaterialCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
