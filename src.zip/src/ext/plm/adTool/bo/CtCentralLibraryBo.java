package ext.plm.adTool.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonFormat;
import ext.plm.adTool.annotation.CtIbaConfig;
import wt.part.WTPart;

import java.util.Date;

/**
 * 网络中心库BO
 */
public class CtCentralLibraryBo {

    /**
     * 物料编码+异性码 作为ID
     */
    @TableId(value = "\"MaterialRetrievalCode\"", type = IdType.INPUT)
    private String materialRetrievalCode;

    /**
     * 异形码
     */
    @TableField("\"HeteromorphicCode\"")
    private String heteromorphicCode;

    /**
     * 器件库编码
     */
    @CtIbaConfig(name = "ct_deviceLibraryCode")
    @TableField("\"TemporaryCode\"")
    private String temporaryCode;

    /**
     * 物料类型
     */
    @CtIbaConfig(name = "ct_materialType")
    @TableField("\"MaterialType\"")
    private String materialType;

    /**
     * 旧物料编码
     */
    @CtIbaConfig(name = "ct_oldMaterialCode")
    @TableField("\"旧物料号\"")
    private String oldMaterialCode;

    /**
     * 物料编码
     */
    @TableField("\"MaterialCode\"")
    private String materialCode;

    /**
     * 物料描述
     */
    @CtIbaConfig(name = "ct_Materialdescription")
    @TableField("\"MaterialDescription\"")
    private String materialDescription;

    /**f
     * 优选等级及描述
     */
    @CtIbaConfig(name = "ct_preferredLevel")
    @TableField("\"PriorityDescription\"")
    private String priorityDescription;

    /**
     * 物料组及描述
     */
    @CtIbaConfig(name = "ct_MaterialGAD")
    @TableField("\"MaterialGroupDescription\"")
    private String materialGroupDescription;

    /**
     * PCB封装名称显示值
     */
    @TableField("\"PCBFootprint\"")
    private String pcbFootprint;

    /**
     * 值
     */
    @TableField("\"Value\"")
    private String value;

    /**
     * 电压
     */
    @TableField("\"Voltage\"")
    private String voltage;

    /**
     * 电流
     */
    @TableField("\"Current\"")
    private String current;

    /**
     * 精度
     */
    @TableField("\"Precision\"")
    private String precision;

    /**
     * 高度
     */
    @TableField("\"Height\"")
    private String height;

    /**
     * Value综合
     */
    @TableField("\"Value综合\"")
    private String valueSynthesis;

    /**
     * 综合值
     */
    @TableField("\"ValueIntegrate\"")
    private String valueIntegrate;

    /**
     * 原理图封装名称
     */
    @TableField("\"Library Ref\"")
    private String libraryRef;

    /**
     * 原理图封装路径
     */
    @TableField("\"Library Path\"")
    private String libraryPath;

    /**
     * PCB封装名称
     */
    @TableField("\"Footprint Ref\"")
    private String footprintRef;

    /**
     * PCB封装路径
     */
    @TableField("\"Footprint Path\"")
    private String footprintPath;

    /**
     * PCB封装名称备用
     */
    @TableField("\"Footprint Ref n\"")
    private String footprintRefN;

    /**
     * PCB封装路径备用
     */
    @TableField("\"Footprint Path n\"")
    private String footprintPathN;

    /**
     * 物料规格书链接名称1
     */
    @TableField("\"ComponentLink1Description\"")
    private String componentLink1Description;

    /**
     * 物料规格书链接地址1
     */
    @TableField("\"ComponentLink1URL\"")
    private String componentLink1URL;

    /**
     * 物料规格书链接名称2
     */
    @TableField("\"ComponentLink2Description\"")
    private String componentLink2Description;

    /**
     * 物料规格书链接地址2
     */
    @TableField("\"ComponentLink2URL\"")
    private String componentLink2URL;

    /**
     * 参考资料链接地址
     */
    @TableField("\"HelpURL\"")
    private String helpURL;

    /**
     * 最新版本日期
     */
    @TableField("\"LatestRevisionDate\"")
    private String latestRevisionDate;

    /**
     * 物料建库批号
     */
    @TableField("\"物料建库批号\"")
    private String materialBuildDatabaseBatchNumber;

    /**
     * 焊接项1
     */
    @TableField("\"焊接项\"")
    private String weldingItem;

    /**
     * 焊接项2
     */
    @TableField("\"WeldAssemble\"")
    private String weldAssemble;

    /**
     * 价格
     */
    @TableField("\"Price\"")
    private String price;

    /**
     * 品牌
     */
    @CtIbaConfig(name = "ct_brand")
    @TableField("\"Brand\"")
    private String brand;

    /**
     * 器件安装方式
     */
    @CtIbaConfig(name = "ct_DeviceInstallationMethod")
    @TableField("\"PTH/SMD\"")
    private String pthOrSmd;

    /**
     * 替代物料编码
     */
    @CtIbaConfig(name = "ct_AlternativeMaterialCode")
    @TableField("\"AlternateMaterialCode\"")
    private String alternateMaterialCode;

    /**
     * 替代物料描述
     */
    @CtIbaConfig(name = "ct_AlternativeMaterialDescription")
    @TableField("\"AlternateMaterialDescription\"")
    private String alternateMaterialDesc;

    /**
     * 物料描述（研发）
     */
    @CtIbaConfig(name = "ct_itemDescription")
    @TableField("\"物料描述（研发）\"")
    private String devMaterialDesc;

    /**
     * PLM：备注，表：长文本
     */
    @CtIbaConfig(name = "ct_remark")
    @TableField("\"长文本\"")
    private String longText;

    /**
     * BOM备注
     */
    @TableField("\"备注\"")
    private String bomRemark;

    /**
     * 分数
     */
    @CtIbaConfig(name = "ct_boardFraction")
    @TableField("\"Fraction\"")
    private String fraction;

    /**
     * 3D库名称
     */
    @TableField("\"PCB3D Ref\"")
    private String pcb3DRef;

    /**
     * 3D库路径
     */
    @TableField("\"PCB3D Path\"")
    private String pcb3DPath;

    /**
     * 替代组编号
     */
    @CtIbaConfig(name = "ct_substituteGroupNumber")
    @TableField("\"物料替换组编码\"")
    private String materialReplacementGroupCode;

    /**
     * 物料替代组描述
     */
    @CtIbaConfig(name = "ct_MaterialSubstitutionGroupDescription")
    @TableField("\"物料替换组描述\"")
    private String materialReplacementGroupDesc;

    /**
     * 状态
     */
    @TableField("\"MaterialStatus\"")
    private String materialStatus;

    /**
     * 内部版本
     */
    @CtIbaConfig(name = "ct_banci")
    @TableField("\"ActualVersion\"")
    private String actualVersion;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date createTime;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date modifyTime;

    /**
     * 指定操作的表名
     */
    private String tableName;

    /**
     * 操作的物料
     */
    private WTPart part;

    public String getMaterialRetrievalCode() {
        return materialRetrievalCode;
    }

    public void setMaterialRetrievalCode(String materialRetrievalCode) {
        this.materialRetrievalCode = materialRetrievalCode;
    }

    public String getHeteromorphicCode() {
        return heteromorphicCode;
    }

    public void setHeteromorphicCode(String heteromorphicCode) {
        this.heteromorphicCode = heteromorphicCode;
    }

    public String getTemporaryCode() {
        return temporaryCode;
    }

    public void setTemporaryCode(String temporaryCode) {
        this.temporaryCode = temporaryCode;
    }

    public String getMaterialType() {
        return materialType;
    }

    public void setMaterialType(String materialType) {
        this.materialType = materialType;
    }

    public String getOldMaterialCode() {
        return oldMaterialCode;
    }

    public void setOldMaterialCode(String oldMaterialCode) {
        this.oldMaterialCode = oldMaterialCode;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getMaterialDescription() {
        return materialDescription;
    }

    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    public String getPriorityDescription() {
        return priorityDescription;
    }

    public void setPriorityDescription(String priorityDescription) {
        this.priorityDescription = priorityDescription;
    }

    public String getMaterialGroupDescription() {
        return materialGroupDescription;
    }

    public void setMaterialGroupDescription(String materialGroupDescription) {
        this.materialGroupDescription = materialGroupDescription;
    }

    public String getPcbFootprint() {
        return pcbFootprint;
    }

    public void setPcbFootprint(String pcbFootprint) {
        this.pcbFootprint = pcbFootprint;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public String getCurrent() {
        return current;
    }

    public void setCurrent(String current) {
        this.current = current;
    }

    public String getPrecision() {
        return precision;
    }

    public void setPrecision(String precision) {
        this.precision = precision;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getValueSynthesis() {
        return valueSynthesis;
    }

    public void setValueSynthesis(String valueSynthesis) {
        this.valueSynthesis = valueSynthesis;
    }

    public String getValueIntegrate() {
        return valueIntegrate;
    }

    public void setValueIntegrate(String valueIntegrate) {
        this.valueIntegrate = valueIntegrate;
    }

    public String getLibraryRef() {
        return libraryRef;
    }

    public void setLibraryRef(String libraryRef) {
        this.libraryRef = libraryRef;
    }

    public String getLibraryPath() {
        return libraryPath;
    }

    public void setLibraryPath(String libraryPath) {
        this.libraryPath = libraryPath;
    }

    public String getFootprintRef() {
        return footprintRef;
    }

    public void setFootprintRef(String footprintRef) {
        this.footprintRef = footprintRef;
    }

    public String getFootprintPath() {
        return footprintPath;
    }

    public void setFootprintPath(String footprintPath) {
        this.footprintPath = footprintPath;
    }

    public String getFootprintRefN() {
        return footprintRefN;
    }

    public void setFootprintRefN(String footprintRefN) {
        this.footprintRefN = footprintRefN;
    }

    public String getFootprintPathN() {
        return footprintPathN;
    }

    public void setFootprintPathN(String footprintPathN) {
        this.footprintPathN = footprintPathN;
    }

    public String getComponentLink1Description() {
        return componentLink1Description;
    }

    public void setComponentLink1Description(String componentLink1Description) {
        this.componentLink1Description = componentLink1Description;
    }

    public String getComponentLink1URL() {
        return componentLink1URL;
    }

    public void setComponentLink1URL(String componentLink1URL) {
        this.componentLink1URL = componentLink1URL;
    }

    public String getComponentLink2Description() {
        return componentLink2Description;
    }

    public void setComponentLink2Description(String componentLink2Description) {
        this.componentLink2Description = componentLink2Description;
    }

    public String getComponentLink2URL() {
        return componentLink2URL;
    }

    public void setComponentLink2URL(String componentLink2URL) {
        this.componentLink2URL = componentLink2URL;
    }

    public String getHelpURL() {
        return helpURL;
    }

    public void setHelpURL(String helpURL) {
        this.helpURL = helpURL;
    }

    public String getLatestRevisionDate() {
        return latestRevisionDate;
    }

    public void setLatestRevisionDate(String latestRevisionDate) {
        this.latestRevisionDate = latestRevisionDate;
    }

    public String getMaterialBuildDatabaseBatchNumber() {
        return materialBuildDatabaseBatchNumber;
    }

    public void setMaterialBuildDatabaseBatchNumber(String materialBuildDatabaseBatchNumber) {
        this.materialBuildDatabaseBatchNumber = materialBuildDatabaseBatchNumber;
    }

    public String getWeldingItem() {
        return weldingItem;
    }

    public void setWeldingItem(String weldingItem) {
        this.weldingItem = weldingItem;
    }

    public String getWeldAssemble() {
        return weldAssemble;
    }

    public void setWeldAssemble(String weldAssemble) {
        this.weldAssemble = weldAssemble;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPthOrSmd() {
        return pthOrSmd;
    }

    public void setPthOrSmd(String pthOrSmd) {
        this.pthOrSmd = pthOrSmd;
    }

    public String getAlternateMaterialCode() {
        return alternateMaterialCode;
    }

    public void setAlternateMaterialCode(String alternateMaterialCode) {
        this.alternateMaterialCode = alternateMaterialCode;
    }

    public String getAlternateMaterialDesc() {
        return alternateMaterialDesc;
    }

    public void setAlternateMaterialDesc(String alternateMaterialDesc) {
        this.alternateMaterialDesc = alternateMaterialDesc;
    }

    public String getDevMaterialDesc() {
        return devMaterialDesc;
    }

    public void setDevMaterialDesc(String devMaterialDesc) {
        this.devMaterialDesc = devMaterialDesc;
    }

    public String getLongText() {
        return longText;
    }

    public void setLongText(String longText) {
        this.longText = longText;
    }

    public String getBomRemark() {
        return bomRemark;
    }

    public void setBomRemark(String bomRemark) {
        this.bomRemark = bomRemark;
    }

    public String getPcb3DRef() {
        return pcb3DRef;
    }

    public void setPcb3DRef(String pcb3DRef) {
        this.pcb3DRef = pcb3DRef;
    }

    public String getPcb3DPath() {
        return pcb3DPath;
    }

    public void setPcb3DPath(String pcb3DPath) {
        this.pcb3DPath = pcb3DPath;
    }

    public String getMaterialReplacementGroupCode() {
        return materialReplacementGroupCode;
    }

    public void setMaterialReplacementGroupCode(String materialReplacementGroupCode) {
        this.materialReplacementGroupCode = materialReplacementGroupCode;
    }

    public String getMaterialReplacementGroupDesc() {
        return materialReplacementGroupDesc;
    }

    public void setMaterialReplacementGroupDesc(String materialReplacementGroupDesc) {
        this.materialReplacementGroupDesc = materialReplacementGroupDesc;
    }

    public String getMaterialStatus() {
        return materialStatus;
    }

    public void setMaterialStatus(String materialStatus) {
        this.materialStatus = materialStatus;
    }

    public String getActualVersion() {
        return actualVersion;
    }

    public void setActualVersion(String actualVersion) {
        this.actualVersion = actualVersion;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public WTPart getPart() {
        return part;
    }

    public void setPart(WTPart part) {
        this.part = part;
    }

    public String getFraction() {
        return fraction;
    }

    public void setFraction(String fraction) {
        this.fraction = fraction;
    }

}
