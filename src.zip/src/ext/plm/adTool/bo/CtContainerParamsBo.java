package ext.plm.adTool.bo;

/**
 * 容器BO
 */
public class CtContainerParamsBo {

    /**
     * 容器名
     */
    private String name;

    /**
     * 成品编码
     */
    private String finishedMaterialCode;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFinishedMaterialCode() {
        return finishedMaterialCode;
    }

    public void setFinishedMaterialCode(String finishedMaterialCode) {
        this.finishedMaterialCode = finishedMaterialCode;
    }
}
