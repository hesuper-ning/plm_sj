package ext.plm.adTool.bo;

/**
 * 更新版本的参数BO
 */
public class CtUpdatedVersionParamsBo {

    private String oid;

    /**
     * 新版本
     */
    private String newVersion;

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getNewVersion() {
        return newVersion;
    }

    public void setNewVersion(String newVersion) {
        this.newVersion = newVersion;
    }
}
