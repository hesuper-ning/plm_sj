package ext.plm.adTool.bo;

public class CtPartUsageBo {

    /**
     * Excel行数
     */
    private Integer excelRowCount = 1;

    /**
     * 物料编码
     */
    private String partNumber;

    /**
     * 位号
     */
    private String positionNo;

    /**
     * 分数
     */
    private String fraction;

    /**
     * 数量
     */
    private String quantity;

    /**
     * 描述
     */
    private String description;

    /**
     * BOM备注
     */
    private String bomRemark;

    /**
     * 器件安装方式
     */
    private String pthOrSmd;

    public Integer getExcelRowCount() {
        return excelRowCount;
    }

    public void setExcelRowCount(Integer excelRowCount) {
        this.excelRowCount = excelRowCount;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPositionNo() {
        return positionNo;
    }

    public void setPositionNo(String positionNo) {
        this.positionNo = positionNo;
    }

    public String getFraction() {
        return fraction;
    }

    public void setFraction(String fraction) {
        this.fraction = fraction;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBomRemark() {
        return bomRemark;
    }

    public void setBomRemark(String bomRemark) {
        this.bomRemark = bomRemark;
    }

    public String getPthOrSmd() {
        return pthOrSmd;
    }

    public void setPthOrSmd(String pthOrSmd) {
        this.pthOrSmd = pthOrSmd;
    }

    @Override
    public String toString() {
        return "{" +
                "物料编码='" + partNumber + '\'' +
                ", 位号='" + positionNo + '\'' +
                ", 分数='" + fraction + '\'' +
                ", 数量=" + quantity +
                ", 描述='" + description + '\'' +
                ", BOM备注='" + bomRemark + '\'' +
                '}';
    }
}
