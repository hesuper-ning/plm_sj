package ext.plm.adTool.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;

public class CtSubstituteParemBo {

	/**
	 * 物料编码+异性码 作为ID
	 */
	@TableField(value = "\"MaterialRetrievalCode\"")
	private String materialRetrievalCode;

	/**
	 * 物料编码
	 */
	@TableField(value = "\"MaterialCode\"")
	private String materialCode;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials1\"")
	private String basicMaterials1;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials2\"")
	private String basicMaterials2;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials3\"")
	private String basicMaterials3;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials4\"")
	private String basicMaterials4;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials5\"")
	private String basicMaterials5;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials6\"")
	private String basicMaterials6;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials7\"")
	private String basicMaterials7;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials8\"")
	private String basicMaterials8;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials9\"")
	private String basicMaterials9;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials10\"")
	private String basicMaterials10;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials11\"")
	private String basicMaterials11;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials12\"")
	private String basicMaterials12;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials13\"")
	private String basicMaterials13;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials14\"")
	private String basicMaterials14;

	/**
	 * 基础物料
	 */
	@TableField("\"basicMaterials15\"")
	private String basicMaterials15;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials1\"")
	private String clusterMaterials1;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials2\"")
	private String clusterMaterials2;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials3\"")
	private String clusterMaterials3;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials4\"")
	private String clusterMaterials4;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials5\"")
	private String clusterMaterials5;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials6\"")
	private String clusterMaterials6;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials7\"")
	private String clusterMaterials7;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials8\"")
	private String clusterMaterials8;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials9\"")
	private String clusterMaterials9;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials10\"")
	private String clusterMaterials10;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials11\"")
	private String clusterMaterials11;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials12\"")
	private String clusterMaterials12;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials13\"")
	private String clusterMaterials13;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials14\"")
	private String clusterMaterials14;

	/**
	 * 基础物料
	 */
	@TableField("\"clusterMaterials15\"")
	private String clusterMaterials15;

	@TableField("\"materSubGroupNumber\"")
	private String materSubGroupNumber;

//	@TableField("\"物料替换组编码\"")
//	private String materSubGroupNumber1;
	
	@TableField("\"materSubGroupDes\"")
	private String materSubGroupDes;

//	@TableField("\"物料替换组描述\"")
//	private String materSubGroupDes1;
	
	@TableField("\"replaceMaQuantity\"")
	private String replaceMaQuantity;

	public String getMaterialRetrievalCode() {
		return materialRetrievalCode;
	}

	/**
	 * 指定操作的表名
	 */
	private String tableName;

	public void setMaterialRetrievalCode(String materialRetrievalCode) {
		this.materialRetrievalCode = materialRetrievalCode;
	}

	public String getBasicMaterials1() {
		return basicMaterials1;
	}

	public void setBasicMaterials1(String basicMaterials1) {
		this.basicMaterials1 = basicMaterials1;
	}

	public String getBasicMaterials2() {
		return basicMaterials2;
	}

	public void setBasicMaterials2(String basicMaterials2) {
		this.basicMaterials2 = basicMaterials2;
	}

	public String getBasicMaterials3() {
		return basicMaterials3;
	}

	public void setBasicMaterials3(String basicMaterials3) {
		this.basicMaterials3 = basicMaterials3;
	}

	public String getBasicMaterials4() {
		return basicMaterials4;
	}

	public void setBasicMaterials4(String basicMaterials4) {
		this.basicMaterials4 = basicMaterials4;
	}

	public String getBasicMaterials5() {
		return basicMaterials5;
	}

	public void setBasicMaterials5(String basicMaterials5) {
		this.basicMaterials5 = basicMaterials5;
	}

	public String getBasicMaterials6() {
		return basicMaterials6;
	}

	public void setBasicMaterials6(String basicMaterials6) {
		this.basicMaterials6 = basicMaterials6;
	}

	public String getBasicMaterials7() {
		return basicMaterials7;
	}

	public void setBasicMaterials7(String basicMaterials7) {
		this.basicMaterials7 = basicMaterials7;
	}

	public String getBasicMaterials8() {
		return basicMaterials8;
	}

	public void setBasicMaterials8(String basicMaterials8) {
		this.basicMaterials8 = basicMaterials8;
	}

	public String getBasicMaterials9() {
		return basicMaterials9;
	}

	public void setBasicMaterials9(String basicMaterials9) {
		this.basicMaterials9 = basicMaterials9;
	}

	public String getBasicMaterials10() {
		return basicMaterials10;
	}

	public void setBasicMaterials10(String basicMaterials10) {
		this.basicMaterials10 = basicMaterials10;
	}

	public String getBasicMaterials11() {
		return basicMaterials11;
	}

	public void setBasicMaterials11(String basicMaterials11) {
		this.basicMaterials11 = basicMaterials11;
	}

	public String getBasicMaterials12() {
		return basicMaterials12;
	}

	public void setBasicMaterials12(String basicMaterials12) {
		this.basicMaterials12 = basicMaterials12;
	}

	public String getBasicMaterials13() {
		return basicMaterials13;
	}

	public void setBasicMaterials13(String basicMaterials13) {
		this.basicMaterials13 = basicMaterials13;
	}

	public String getBasicMaterials14() {
		return basicMaterials14;
	}

	public void setBasicMaterials14(String basicMaterials14) {
		this.basicMaterials14 = basicMaterials14;
	}

	public String getBasicMaterials15() {
		return basicMaterials15;
	}

	public void setBasicMaterials15(String basicMaterials15) {
		this.basicMaterials15 = basicMaterials15;
	}

	public String getClusterMaterials1() {
		return clusterMaterials1;
	}

	public void setClusterMaterials1(String clusterMaterials1) {
		this.clusterMaterials1 = clusterMaterials1;
	}

	public String getClusterMaterials2() {
		return clusterMaterials2;
	}

	public void setClusterMaterials2(String clusterMaterials2) {
		this.clusterMaterials2 = clusterMaterials2;
	}

	public String getClusterMaterials3() {
		return clusterMaterials3;
	}

	public void setClusterMaterials3(String clusterMaterials3) {
		this.clusterMaterials3 = clusterMaterials3;
	}

	public String getClusterMaterials4() {
		return clusterMaterials4;
	}

	public void setClusterMaterials4(String clusterMaterials4) {
		this.clusterMaterials4 = clusterMaterials4;
	}

	public String getClusterMaterials5() {
		return clusterMaterials5;
	}

	public void setClusterMaterials5(String clusterMaterials5) {
		this.clusterMaterials5 = clusterMaterials5;
	}

	public String getClusterMaterials6() {
		return clusterMaterials6;
	}

	public void setClusterMaterials6(String clusterMaterials6) {
		this.clusterMaterials6 = clusterMaterials6;
	}

	public String getClusterMaterials7() {
		return clusterMaterials7;
	}

	public void setClusterMaterials7(String clusterMaterials7) {
		this.clusterMaterials7 = clusterMaterials7;
	}

	public String getClusterMaterials8() {
		return clusterMaterials8;
	}

	public void setClusterMaterials8(String clusterMaterials8) {
		this.clusterMaterials8 = clusterMaterials8;
	}

	public String getClusterMaterials9() {
		return clusterMaterials9;
	}

	public void setClusterMaterials9(String clusterMaterials9) {
		this.clusterMaterials9 = clusterMaterials9;
	}

	public String getClusterMaterials10() {
		return clusterMaterials10;
	}

	public void setClusterMaterials10(String clusterMaterials10) {
		this.clusterMaterials10 = clusterMaterials10;
	}

	public String getClusterMaterials11() {
		return clusterMaterials11;
	}

	public void setClusterMaterials11(String clusterMaterials11) {
		this.clusterMaterials11 = clusterMaterials11;
	}

	public String getClusterMaterials12() {
		return clusterMaterials12;
	}

	public void setClusterMaterials12(String clusterMaterials12) {
		this.clusterMaterials12 = clusterMaterials12;
	}

	public String getClusterMaterials13() {
		return clusterMaterials13;
	}

	public void setClusterMaterials13(String clusterMaterials13) {
		this.clusterMaterials13 = clusterMaterials13;
	}

	public String getClusterMaterials14() {
		return clusterMaterials14;
	}

	public void setClusterMaterials14(String clusterMaterials14) {
		this.clusterMaterials14 = clusterMaterials14;
	}

	public String getClusterMaterials15() {
		return clusterMaterials15;
	}

	public void setClusterMaterials15(String clusterMaterials15) {
		this.clusterMaterials15 = clusterMaterials15;
	}

	public String getMaterSubGroupNumber() {
		return materSubGroupNumber;
	}

	public void setMaterSubGroupNumber(String materSubGroupNumber) {
		this.materSubGroupNumber = materSubGroupNumber;
	}

	public String getMaterSubGroupDes() {
		return materSubGroupDes;
	}

	public void setMaterSubGroupDes(String materSubGroupDes) {
		this.materSubGroupDes = materSubGroupDes;
	}

	public String getReplaceMaQuantity() {
		return replaceMaQuantity;
	}

	public void setReplaceMaQuantity(String replaceMaQuantity) {
		this.replaceMaQuantity = replaceMaQuantity;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

//	public String getMaterSubGroupNumber1() {
//		return materSubGroupNumber1;
//	}
//
//	public void setMaterSubGroupNumber1(String materSubGroupNumber1) {
//		this.materSubGroupNumber1 = materSubGroupNumber1;
//	}
//
//	public String getMaterSubGroupDes1() {
//		return materSubGroupDes1;
//	}
//
//	public void setMaterSubGroupDes1(String materSubGroupDes1) {
//		this.materSubGroupDes1 = materSubGroupDes1;
//	}

}
