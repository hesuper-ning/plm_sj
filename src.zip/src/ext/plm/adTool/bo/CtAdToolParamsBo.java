package ext.plm.adTool.bo;

import java.util.HashSet;

public class CtAdToolParamsBo {

    /**
     * PCB型号
     */
    private String pcbModel;

    /**
     * 物料编码
     */
    private String partNumber;

    /**
     * 内部版本
     */
    private String innerVersion;

    /**
     * 查询标识
     * 1：按基线查询
     * 2：按最新版本查询
     * 3：按指定版本查询
     * 4：按所有大版本查询
     * 5：按所有历史版本查询
     */
    private Integer queryFlag;

    /**
     * 文档类型，存储值为0601、0602等
     */
    private HashSet<String> docTypeHashSet;

    public String getPcbModel() {
        return pcbModel;
    }

    public void setPcbModel(String pcbModel) {
        this.pcbModel = pcbModel;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getInnerVersion() {
        return innerVersion;
    }

    public void setInnerVersion(String innerVersion) {
        this.innerVersion = innerVersion;
    }

    public Integer getQueryFlag() {
        return queryFlag;
    }

    public void setQueryFlag(Integer queryFlag) {
        this.queryFlag = queryFlag;
    }

    public HashSet<String> getDocTypeHashSet() {
        return docTypeHashSet;
    }

    public void setDocTypeHashSet(HashSet<String> docTypeHashSet) {
        this.docTypeHashSet = docTypeHashSet;
    }
}
