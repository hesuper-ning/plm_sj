package ext.plm.adTool.bo;

import wt.folder.Folder;
import wt.inf.container.WTContainer;
import wt.org.WTUser;
import wt.part.WTPart;

import java.util.Map;

/**
 * 创建文档所需参数BO
 */
public class CtCreateDocumentBo {

    /**
     * 文件归档类型
     */
    private String fileArchiveType;

    /**
     * 文档类型
     */
    private String docType;

    /**
     * 文档名
     */
    private String name;

    /**
     * 文档编码
     */
    private String number;

    /**
     * 容器
     */
    private WTContainer containerReference;

    /**
     * 内部版本
     */
    private String ctVersion;

    /**
     * PCB型号
     */
    private String model;

    /**
     * 文档目录
     */
    private Folder folderId;

    /**
     * PCB编码
     */
    private WTPart  pcbPart;

    /**
     * 需要跟创建的文档建立关联关系的物料
     */
    private WTPart relationPart;

    /**
     * 创建该文档的当前用户
     */
    private WTUser currentUser;

    /**
     * 是否根据文档名做升版操作
     */
    private boolean upgradeByName;

    /**
     * 文档编码后缀
     */
    private String docNumberSuffix;

    /**
     * BOM清单文件名与PCBA料的Map
     */
    private Map<String, String> bomFileAndPCBAMap;

    /**
     * 压缩名
     */
    private String compressName;

    /**
     * 检入备注信息
     */
    private String checkInRemark;

    public String getFileArchiveType() {
        return fileArchiveType;
    }

    public void setFileArchiveType(String fileArchiveType) {
        this.fileArchiveType = fileArchiveType;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public WTContainer getContainerReference() {
        return containerReference;
    }

    public void setContainerReference(WTContainer containerReference) {
        this.containerReference = containerReference;
    }

    public String getCtVersion() {
        return ctVersion;
    }

    public void setCtVersion(String ctVersion) {
        this.ctVersion = ctVersion;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Folder getFolderId() {
        return folderId;
    }

    public void setFolderId(Folder folderId) {
        this.folderId = folderId;
    }

    public WTPart getPcbPart() {
        return pcbPart;
    }

    public void setPcbPart(WTPart pcbPart) {
        this.pcbPart = pcbPart;
    }

    public WTPart getRelationPart() {
        return relationPart;
    }

    public void setRelationPart(WTPart relationPart) {
        this.relationPart = relationPart;
    }

    public WTUser getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(WTUser currentUser) {
        this.currentUser = currentUser;
    }

    public boolean isUpgradeByName() {
        return upgradeByName;
    }

    public void setUpgradeByName(boolean upgradeByName) {
        this.upgradeByName = upgradeByName;
    }

    public String getDocNumberSuffix() {
        return docNumberSuffix;
    }

    public void setDocNumberSuffix(String docNumberSuffix) {
        this.docNumberSuffix = docNumberSuffix;
    }

    public Map<String, String> getBomFileAndPCBAMap() {
        return bomFileAndPCBAMap;
    }

    public void setBomFileAndPCBAMap(Map<String, String> bomFileAndPCBAMap) {
        this.bomFileAndPCBAMap = bomFileAndPCBAMap;
    }

    public String getCompressName() {
        return compressName;
    }

    public void setCompressName(String compressName) {
        this.compressName = compressName;
    }

    public String getCheckInRemark() {
        return checkInRemark;
    }

    public void setCheckInRemark(String checkInRemark) {
        this.checkInRemark = checkInRemark;
    }
}
