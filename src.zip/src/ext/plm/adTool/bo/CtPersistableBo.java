package ext.plm.adTool.bo;

import com.fasterxml.jackson.annotation.JsonFormat;
import ext.plm.common.CtConstant;

import java.util.Date;

public class CtPersistableBo {

    /**
     * OID
     */
    private String oid;

    /**
     * 类型
     */
    private String type;

    /**
     * 编码
     */
    private String number;

    /**
     * 名称
     */
    private String name;

    /**
     * 内部版本
     */
    private String innerVersion;

    /**
     * 系统版本
     */
    private String version;

    /**
     * 物料版本
     */
    private String partVersion;

    /**
     * 状态
     */
    private String state;

    /**
     * 修改人
     */
    private String modified;

    /**
     * 修改日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = CtConstant.TIMEZONE_FORMAT)
    private Date modifyTime;

    /**
     * 所属产品库名
     */
    private String containerName;

    /**
     * 文件位置
     */
    private String location;

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInnerVersion() {
        return innerVersion;
    }

    public void setInnerVersion(String innerVersion) {
        this.innerVersion = innerVersion;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getPartVersion() {
        return partVersion;
    }

    public void setPartVersion(String partVersion) {
        this.partVersion = partVersion;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getModified() {
        return modified;
    }

    public void setModified(String modified) {
        this.modified = modified;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getContainerName() {
        return containerName;
    }

    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
