package ext.plm.adTool.bo;

import com.fasterxml.jackson.annotation.JsonFormat;
import ext.plm.common.CtConstant;

import java.util.Date;

public class CtDocumentInfoBo {

    /**
     * 文档编号
     */
    private String docNumber;

    /**
     * 文档名称
     */
    private String docName;

    /**
     * 文档版本
     */
    private String docVersion;

    /**
     * 文档状态
     */
    private String docState;

    /**
     * 修改人
     */
    private String modified;

    /**
     * 修改日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = CtConstant.TIMEZONE_FORMAT)
    private Date modifyTime;

    /**
     * 上下文
     */
    private String context;

    /**
     * 位置
     */
    private String location;

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getDocVersion() {
        return docVersion;
    }

    public void setDocVersion(String docVersion) {
        this.docVersion = docVersion;
    }

    public String getDocState() {
        return docState;
    }

    public void setDocState(String docState) {
        this.docState = docState;
    }

    public String getModified() {
        return modified;
    }

    public void setModified(String modified) {
        this.modified = modified;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
