package ext.plm.adTool.bo;

import java.util.List;

public class CtBomPartBo {

    /**
     * 父阶物料编码
     */
    private String parentPartNumber;

    /**
     * 描述
     */
    private String description;

    /**
     * 器件安装方式
     */
    private String pthOrSmd;

    /**
     * 父阶物料所在的文件路径
     */
    private String filePath;

    /**
     * 备注
     */
    private String remark;

    /**
     * 子阶物料
     */
    private List<CtPartUsageBo> subPartList;

    public String getParentPartNumber() {
        return parentPartNumber;
    }

    public void setParentPartNumber(String parentPartNumber) {
        this.parentPartNumber = parentPartNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPthOrSmd() {
        return pthOrSmd;
    }

    public void setPthOrSmd(String pthOrSmd) {
        this.pthOrSmd = pthOrSmd;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<CtPartUsageBo> getSubPartList() {
        return subPartList;
    }

    public void setSubPartList(List<CtPartUsageBo> subPartList) {
        this.subPartList = subPartList;
    }
}
