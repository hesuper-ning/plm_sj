package ext.plm.adTool.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import ext.plm.adTool.annotation.CtCondition;

import java.util.List;

/**
 * 网络中心库参数BO
 */
public class CtCentralLibraryParamsBo {

    @TableField("\"MaterialRetrievalCode\"")
    @CtCondition(condition = "=")
    private List<String> idList;

    /***
     * 物料编码集合
     */
    @TableField("\"MaterialCode\"")
    @CtCondition(condition = "like")
    private List<String> partNumberList;

    /**
     * 物料编码，精确匹配
     */
    @TableField("\"MaterialCode\"")
    @CtCondition(condition = "=")
    private String partNumber;

    /**
     * 更新标识
     */
    private String updateFlags;

    /**
     * 指定操作的表名
     */
    private String tableName;

    /**
     * 指定操作的表名集合
     */
    private List<String> tableNameList;

    /**
     * 排序
     */
    private String orderBy = "\"MaterialRetrievalCode\" ASC";

    /**
     * 是否校验删除数据
     */
    private boolean checkDeleteData;

    public List<String> getIdList() {
        return idList;
    }

    public void setIdList(List<String> idList) {
        this.idList = idList;
    }

    public List<String> getPartNumberList() {
        return partNumberList;
    }

    public void setPartNumberList(List<String> partNumberList) {
        this.partNumberList = partNumberList;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getUpdateFlags() {
        return updateFlags;
    }

    public void setUpdateFlags(String updateFlags) {
        this.updateFlags = updateFlags;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public List<String> getTableNameList() {
        return tableNameList;
    }

    public void setTableNameList(List<String> tableNameList) {
        this.tableNameList = tableNameList;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public boolean isCheckDeleteData() {
        return checkDeleteData;
    }

    public void setCheckDeleteData(boolean checkDeleteData) {
        this.checkDeleteData = checkDeleteData;
    }
}
