package ext.plm.adTool;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import ext.plm.adTool.bo.CtCentralLibraryBo;
import ext.plm.adTool.config.CtAdToolConstant;
import ext.plm.adTool.config.CtAdToolProperties;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.util.CtPartClfUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;

import java.io.File;
import java.util.*;

public class CtAdToolWfPlugin {

    private static CtAdToolQuery ctAdToolQuery = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolQuery.class);
    private static CtAdToolService ctAdToolService = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolService.class);

    /**
     * 同步数据到网络中心库之根据物料
     * @param wtObject
     * @throws WTException
     * @return
     */
    public static Map<String, String> syncNetworkCentralLibrary(WTObject wtObject, String failNumbers) {
        Map<String, String> resultMap = new HashMap<>(2);
        StringBuffer stringBuffer = new StringBuffer();
        List<String> failPartNumList = new ArrayList<>();
        try {
            CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
            if (StringUtils.isNotEmpty(failNumbers)) {
                for (String number : failNumbers.split(CtAdToolConstant.STRING_SEPARATOR)) {
                    WTPart part = CtPartUtil.getPartByNumber(number, CtConstant.VIEW_DESIGN);
                    if (part == null) continue;

                    // 判断物料是否可以入库
                    if (!ctAdToolLogic.isCanWarehousing(part)) continue;

                    try {
                        CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                        ctAdToolLogic.setCentralLibraryId(part, bo);
                        ctAdToolService.saveCentralLibrary(bo);
                    } catch (Exception e) {
                        e.printStackTrace();
                        stringBuffer.append("物料：" + number + "同步数据到网络中心库失败，后台异常为：" + e.getLocalizedMessage() + "\r\n");
                        failPartNumList.add(part.getNumber());
                    }
                }
            } else {
                if (wtObject instanceof WTDocument) {
                    WTDocument document = (WTDocument) wtObject;
                    IBAUtil ibaUtil = new IBAUtil(document);
                    // 获取物料编码
                    String partNumber = ibaUtil.getIBAValue("ct_materialsnumber");
                    WTPart part = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);

                    if (part != null && ctAdToolLogic.isCanWarehousing(part)) {
                        CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                        // 获取异形码
                        String alienCode = ibaUtil.getIBAValue("ct_AlienCode");
                        bo.setHeteromorphicCode(alienCode);
                        ctAdToolLogic.setCentralLibraryId(part, bo);
                        ctAdToolService.saveCentralLibrary(bo);
                    }
                } else if (wtObject instanceof PromotionNotice) {
                    QueryResult queryResult = MaturityHelper.service.getPromotionTargets((PromotionNotice) wtObject);
                    while (queryResult.hasMoreElements()) {
                        Object obj = queryResult.nextElement();
                        if (obj instanceof WTPart) {
                            WTPart part = (WTPart) obj;
                            part = CtPartUtil.getPartByNumber(part.getNumber(), CtConstant.VIEW_DESIGN);
                            if (part == null)  continue;
                            // 判断物料是否可以入库
                            if (!ctAdToolLogic.isCanWarehousing(part)) continue;

                            try {
                                CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                                ctAdToolLogic.setCentralLibraryId(part, bo);
                                ctAdToolService.saveCentralLibrary(bo);
                            } catch (Exception e) {
                                e.printStackTrace();
                                stringBuffer.append("物料：" + part.getNumber() + "同步数据到网络中心库失败，后台异常为："
                                        + e.getLocalizedMessage() + "\r\n");
                                failPartNumList.add(part.getNumber());
                            }
                        }
                    }
                } else if (wtObject instanceof WTPart) {
                    WTPart part = (WTPart) wtObject;
                    part = CtPartUtil.getPartByNumber(part.getNumber(), CtConstant.VIEW_DESIGN);
                    if (part != null && ctAdToolLogic.isCanWarehousing(part)) {
                        CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                        ctAdToolLogic.setCentralLibraryId(part, bo);
                        ctAdToolService.saveCentralLibrary(bo);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            stringBuffer.append("同步数据到网络中心库失败，后台异常为：" + e.getLocalizedMessage());
        }

        resultMap.put("errorMsg", stringBuffer.toString().trim());
        resultMap.put("failNumbers", StringUtils.join(failPartNumList, CtAdToolConstant.STRING_SEPARATOR));
        return resultMap;
    }

    /**
     * 根据物料批量更新网络中心库中使用该物料的数据
     * @param wtObject
     * @param failNumbers 失败的料号
     * @throws WTException
     */
    public static  Map<String, String>  batchSyncNetworkCentralLibrary(WTObject wtObject, String failNumbers) throws WTException {
        Map<String, String> resultMap = new HashMap<>(2);
        StringBuffer stringBuffer = new StringBuffer();
        List<String> failPartNumList = new ArrayList<>();
        try {
            CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();

            if (StringUtils.isNotEmpty(failNumbers)) {
                for (String number : failNumbers.split(CtAdToolConstant.STRING_SEPARATOR)) {
                    WTPart part = CtPartUtil.getPartByNumber(number, CtConstant.VIEW_DESIGN);
                    if (part == null) continue;

                    // 判断物料是否可以入库
                    if (!ctAdToolLogic.isCanWarehousing(part)) continue;

                    try {
                        CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                        bo.setModifyTime(new Date());
                        // 根据编码更新所有表数据
                        Wrapper<CtCentralLibraryBo> wrapper = new EntityWrapper().eq("materialCode", part.getNumber());
                        ctAdToolQuery.update(bo, wrapper);
                    } catch (Exception e) {
                        e.printStackTrace();
                        stringBuffer.append("物料：" + number + "同步数据到网络中心库失败，后台异常为：" + e.getLocalizedMessage() + "\r\n");
                        failPartNumList.add(part.getNumber());
                    }
                }
            } else {
                if (wtObject instanceof  WTPart) {
                    WTPart part = (WTPart) wtObject;
                    part = CtPartUtil.getPartByNumber(part.getNumber(), CtConstant.VIEW_DESIGN);
                    if (part != null && ctAdToolLogic.isCanWarehousing(part)) {
                        CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                        bo.setModifyTime(new Date());
                        // 根据编码更新所有表数据
                        Wrapper<CtCentralLibraryBo> wrapper = new EntityWrapper().eq("materialCode", part.getNumber());
                        ctAdToolQuery.update(bo, wrapper);
                    }
                } else if (wtObject instanceof WTChangeActivity2) {
                    QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((WTChangeActivity2) wtObject);
                    while (queryResult.hasMoreElements()) {
                        Object object = queryResult.nextElement();
                        if (object instanceof WTPart) {
                            WTPart part = (WTPart) object;
                            part = CtPartUtil.getPartByNumber(part.getNumber(), CtConstant.VIEW_DESIGN);
                            if (part == null) continue;
                            if (!ctAdToolLogic.isCanWarehousing(part)) continue;

                            try {
                                CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                                bo.setModifyTime(new Date());
                                // 根据编码更新所有表数据
                                Wrapper<CtCentralLibraryBo> wrapper = new EntityWrapper().eq("materialCode", part.getNumber());
                                ctAdToolQuery.update(bo, wrapper);
                            } catch (Exception e) {
                                e.printStackTrace();
                                stringBuffer.append("物料：" + part.getNumber() + "同步数据到网络中心库失败，后台异常为："
                                        + e.getLocalizedMessage() + "\r\n");
                                failPartNumList.add(part.getNumber());
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            stringBuffer.append("同步数据到网络中心库失败，后台异常为：" + e.getLocalizedMessage());
        }

        resultMap.put("errorMsg", stringBuffer.toString().trim());
        resultMap.put("failNumbers", StringUtils.join(failPartNumList, CtAdToolConstant.STRING_SEPARATOR));
        return resultMap;
    }

    /**
     * 将文件归档到共享目录
     * @param wtObject
     * @return
     */
    public static String fileArchiveToSharedFolder(WTObject wtObject) {
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        CtAdToolProperties properties = CtAdToolProperties.getInstance();
        String message = null;
        try {
            if (wtObject instanceof WTDocument) {
                WTDocument document = (WTDocument) wtObject;
                String typeInternalName = TypedUtilityServiceHelper.service.getTypeIdentifier(document).getTypeInternalName();
                String targetPaht = properties.getStringValue(CtAdToolConstant.ARCHIVE_KEY + typeInternalName);
                // 说明该文档没有指定归档目录，无需处理
                if (StringUtils.isEmpty(targetPaht)) return null;

                IBAUtil ibaUtil = new IBAUtil(document);
                String partNumber = ibaUtil.getIBAValue("ct_materialsnumber");
                WTPart part = CtPartUtil.getPartByNumber(partNumber);;
                String hierarchy = CtPartClfUtil.getClfHierarchy(part);
                if (StringUtils.isNotEmpty(hierarchy)) {
                    String[] categoryArray = hierarchy.split(">");
                    // 从第二个开始
                    for (int i = 1; i < categoryArray.length; i++) {
                        targetPaht += File.separator + categoryArray[i].trim();
                    }
                    targetPaht += File.separator + partNumber + File.separator + partNumber + " " + document.getModifierFullName() + "（ NXP ）";
                    // 将文档主要内容上传到共享目录中
                    ctAdToolLogic.uploadPrimaryContentToSharedFolder(document, targetPaht, false);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            message = e.getLocalizedMessage();
        }
        return message;
    }

    /**
     * 处理CBB文档的主要内容文件归档
     * @param wtObject
     * @throws WTException
     */
    public static void handleCBBArchive(WTObject wtObject) throws WTException {
        WTDocument document = (WTDocument) wtObject;
        IBAUtil ibaUtil = new IBAUtil(document);
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        CtAdToolProperties properties = CtAdToolProperties.getInstance();
        String targetPath = properties.getStringValue("CBB.archive.path");
        targetPath += File.separator + document.getNumber() + File.separator + String.valueOf(ibaUtil.getIBAValue("ct_banci"));
        ctAdToolLogic.uploadPrimaryContentToSharedFolder(document, targetPath, true);
    }
}
