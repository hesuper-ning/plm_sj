package ext.plm.adTool;

import ext.plm.adTool.bo.*;
import org.springframework.web.multipart.MultipartFile;
import wt.part.WTPart;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;

/**
 * AD集成工具接口
 * @auther TanRuoTao
 */
public interface CtAdToolService {

    /**
     * 获取物料信息
     * @param paramsBo
     * @return
     * @throws Exception
     */
    List<CtPersistableBo> getPartInfo(CtAdToolParamsBo paramsBo) throws Exception;

    /**
     * 获取物料关联文档（说明放文档、参考文档）
     * @param oid
     * @return
     * @throws Exception
     */
    List<CtDocumentInfoBo> getRelationDocs(String oid) throws Exception;

    /**
     * 下载关联文档的主内容和附件
     * @param oids 对象OID，通过英文逗号隔开
     * @param isCheckOut 是否检出
     * @param outputStream
     * @throws Exception
     */
    void downloadRelationDocs(String oids, boolean isCheckOut, OutputStream outputStream) throws Exception;

    /**
     * 验证PCB物料编码是否存在系统且是否具有编辑权限
     * @param pcbNumber
     * @return
     * @throws Exception
     */
    String checkPcbNumber(String pcbNumber, String version, String pcbModel) throws Exception;

    /**
     * BOM校验
     * @param pcbNumber PCB料号
     * @param innerVersion 内部型号
     * @param bomPartBoList
     * @return
     * @throws Exception
     */
    String checkBOM(String pcbNumber, String innerVersion, List<CtBomPartBo> bomPartBoList) throws Exception;

    /**
     * 获取BOM下阶物料信息
     * @param bomPartBoList
     * @return
     * @throws Exception
     */
    String getBOMData(List<CtBomPartBo> bomPartBoList) throws Exception;

    /**
     * 更新BOM
     * @param pcbNumber PCB料号
     * @param innerVersion 内部型号
     * @param bomPartBoList
     * @param checkInRemark 检入BOM的备注信息
     * @return
     * @throws Exception
     */
    String updateBOM(String pcbNumber, String innerVersion, List<CtBomPartBo> bomPartBoList, String checkInRemark) throws Exception;

    /**
     * 文件归档
     * @param map
     * @param files
     * @throws Exception
     */
    void fileArchive(Map<String, String[]> map, List<MultipartFile> files) throws Exception;

    /**
     * 获取容器列表
     * @param paramsBo
     * @return
     * @throws Exception
     */
    List<CtContainerBo> getContainers(CtContainerParamsBo paramsBo) throws Exception;

    /**
     * 更新网络中心库数据
     * @param paramsBo
     * @return
     * @throws Exception
     */
    String updateCentralLibrary(CtCentralLibraryParamsBo paramsBo) throws Exception;

    /**
     * 根据唯一ID（物料编码+异形码）来添加或更新网络中心库数据
     * @param bo
     * @throws Exception
     */
    String saveCentralLibrary(CtCentralLibraryBo bo) throws Exception;

    /**
     * 导入更新网络中心库数据
     * @param map
     * @param files
     * @throws Exception
     */
    String importNetworkCentralLibrary(Map<String, String[]> map, List<MultipartFile> files) throws Exception;

    /**
     * 获取网络中心库数据
     * @param paramsBo
     * @return
     * @throws Exception
     */
    List<CtCentralLibraryBo> getCentralLibrary(CtCentralLibraryParamsBo paramsBo) throws Exception;

    /**
     * 导出网络中心库数据
     * @param paramsBo
     * @param outputStream
     * @throws Exception
     */
    void exportNetworkCentralLibrary(CtCentralLibraryParamsBo paramsBo, OutputStream outputStream) throws Exception;

    /**
     * 更新版本
     * @param paramsBo
     * @throws Exception
     */
    String updatedVersion(CtUpdatedVersionParamsBo paramsBo) throws Exception;

    /**
     * 删除网络中心库数据
     * @param paramsBo
     * @return 校验信息
     * @throws Exception
     */
    String deleteCentralLibrary(CtCentralLibraryParamsBo paramsBo) throws Exception;

    /**
     * 处理物料创建时入库情况
     * @param part
     * @throws Exception
     */
    void handlePartCreateWarehousing(WTPart part) throws Exception;

    /**
     * 处理物料修改时入库情况
     * @param part
     * @throws Exception
     */
    void handlePartEditWarehousing(WTPart part) throws Exception;
}
