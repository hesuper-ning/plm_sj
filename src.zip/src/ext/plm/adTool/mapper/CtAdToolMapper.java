package ext.plm.adTool.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.adTool.bo.CtAdToolParamsBo;
import ext.plm.adTool.bo.CtCentralLibraryBo;
import ext.plm.adTool.bo.CtCentralLibraryParamsBo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

@Mapper
public interface CtAdToolMapper extends BaseMapper<CtCentralLibraryBo> {

    /**
     * 查询物料的OID
     * @param paramsBo
     * @return
     */
    List<String> queryPartOIds(CtAdToolParamsBo paramsBo);

    /**
     * 查询基线的OID
     * @param paramsBo
     * @return
     */
    List<String> queryBaselineOIds(CtAdToolParamsBo paramsBo);

    /**
     * 查询文档中最大的流水号
     * @param numberPrefix
     * @return
     */
    Integer queryDocMaxSerialNumber(@Param("numberPrefix") String numberPrefix);

    /**
     * 查询网络中心库数据
     * @param paramsBo
     * @return
     */
    List<CtCentralLibraryBo> queryCentralLibrary(CtCentralLibraryParamsBo paramsBo);

    /**
     * 查询物料某个IBA属性值
     * @param paramsMap
     * @return
     */
    List<HashMap<String, Object>> queryPartIbaValue(HashMap<String, Object> paramsMap);
}
