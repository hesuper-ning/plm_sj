package ext.plm.adTool;

import com.alibaba.fastjson.JSONObject;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.CreateOperationIdentifier;
import com.ptc.windchill.enterprise.library.LibraryListCommand;
import com.ptc.windchill.enterprise.part.commands.PartDocServiceCommand;
import com.ptc.windchill.enterprise.product.ProductListCommand;
import ext.plm.adTool.bo.*;
import ext.plm.adTool.config.CtAdToolConstant;
import ext.plm.adTool.config.CtAdToolProperties;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.config.CtBomConstant;
import ext.plm.common.CtConstant;
import ext.plm.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.enterprise.RevisionControlled;
import wt.fc.*;
import wt.fc.collections.WTHashSet;
import wt.folder.Cabinet;
import wt.folder.CabinetBased;
import wt.folder.Folder;
import wt.inf.container.WTContainer;
import wt.inf.library.WTLibrary;
import wt.lifecycle.State;
import wt.occurrence.OccurrenceHelper;
import wt.org.WTUser;
import wt.part.*;
import wt.pdmlink.PDMLinkProduct;
import wt.pom.Transaction;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.baseline.BaselineHelper;
import wt.vc.baseline.ManagedBaseline;
import wt.vc.wip.WorkInProgressHelper;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipOutputStream;

/**
 * AD集成工具 Service
 *
 * @auther TanRuoTao
 */
@Service
public class CtAdToolServiceImpl implements CtAdToolService {

    @Autowired
    private CtAdToolQuery ctAdToolQuery;

    @Override
    public List<CtPersistableBo> getPartInfo(CtAdToolParamsBo paramsBo) throws Exception {
        if (paramsBo.getQueryFlag() == null) return new ArrayList<>(0);

        List<String> oidList;
        if (paramsBo.getQueryFlag() == 1) {
            // 查询基线
            oidList = ctAdToolQuery.queryBaselineOIds(paramsBo);
        } else {
            // 查询物料
            oidList = ctAdToolQuery.queryPartOIds(paramsBo);
        }

        List<CtPersistableBo> boList = new ArrayList<>(oidList.size());
        for (String oid : oidList) {
            Persistable persistable = null;
            try {
                persistable = CtWTObjectUtil.getObjectByOid(oid);
            } catch (Exception e) {
                // 说明用户查看对象的权限
                continue;
            }
            if (persistable == null) continue;

            if (persistable instanceof WTPart) {
                WTPart part = (WTPart) persistable;
                String partVersion = CtVersionUtil.getVersionInfo(part);
                HashSet<String> docTypeHashSet = paramsBo.getDocTypeHashSet();
                if (CollectionUtils.isNotEmpty(docTypeHashSet)) {
                    // 获取说明方文档
                    QueryResult queryResult = PartDocServiceCommand.getAssociatedDescribeDocuments(part);
                    while (queryResult.hasMoreElements()) {
                        Object object = queryResult.nextElement();
                        if (!(object instanceof WTDocument)) continue;

                        WTDocument document = (WTDocument) object;
                        String documentNumber = document.getNumber();
                        if (!documentNumber.contains("_")) continue;

                        String[] split = documentNumber.split("_");
                        if (split.length < 2) continue;

                        String docType = split[1];
                        if (docTypeHashSet.contains(docType)) {
                            CtPersistableBo bo = loadPersistableBo(document);
                            bo.setPartVersion(partVersion);
                            boList.add(bo);
                        }
                    }
                }
            } else {
                boList.add(loadPersistableBo(persistable));
            }
        }
        return boList;
    }

    @Override
    public List<CtDocumentInfoBo> getRelationDocs(String oid) throws Exception {
        if (StringUtils.isBlank(oid)) return new ArrayList<>(0);

        Persistable persistable = CtWTObjectUtil.getObjectByOid(oid);
        if (persistable == null) return new ArrayList<>(0);
        ;

        List<CtDocumentInfoBo> boList = new ArrayList<>();
        if (persistable instanceof WTPart) {
            WTPart part = (WTPart) persistable;
            // 获取说明方文档
            QueryResult describedDocs = PartDocServiceCommand.getAssociatedDescribeDocuments(part);
            while (describedDocs.hasMoreElements()) {
                WTDocument document = (WTDocument) describedDocs.nextElement();
                boList.add(loadDocumentInfoBo(document));
            }

//            // 获取参考文档
//            QueryResult referencedDocs = PartDocServiceCommand.getAssociatedReferenceDocuments(part);
//            while(describedDocs.hasMoreElements()) {
//                WTDocument document = (WTDocument) describedDocs.nextElement();
//                boList.add(loadDocumentInfoBo(document));
//            }
        } else if (persistable instanceof ManagedBaseline) {
            ManagedBaseline managedBaseline = (ManagedBaseline) persistable;
            QueryResult queryResult = BaselineHelper.service.getBaselineItems(managedBaseline);
            while (queryResult.hasMoreElements()) {
                Object object = queryResult.nextElement();
                if (object instanceof WTDocument) {
                    WTDocument document = (WTDocument) object;
                    boList.add(loadDocumentInfoBo(document));
                }
            }
        } else if (persistable instanceof WTDocument) {
            WTDocument document = (WTDocument) persistable;
            boList.add(loadDocumentInfoBo(document));
        }

        return boList;
    }

    @Override
    public void downloadRelationDocs(String oids, boolean isCheckOut, OutputStream outputStream) throws Exception {
        if (StringUtils.isBlank(oids)) return;

        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        WTUser currentUser = (WTUser) CtUserUtil.getCurrentUser();
        String[] oidArray = oids.split(CtAdToolConstant.STRING_SEPARATOR);
        ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream, Charset.forName("GBK"));
        try {
            ContentRoleType[] types = new ContentRoleType[2];
            types[0] = ContentRoleType.PRIMARY;
            types[1] = ContentRoleType.SECONDARY;

            for (String oid : oidArray) {
                Persistable persistable = CtWTObjectUtil.getObjectByOid(oid);
                if (persistable instanceof WTPart) {
                    WTPart part = (WTPart) persistable;
                    if (part == null) throw new Exception("根据物料VID：" + oid + "未找到该物料！");

                    String pathPrefix = part.getNumber() + "_" + part.getVersionIdentifier().getValue();
                    // 获取说明方文档
                    QueryResult describedDocs = PartDocServiceCommand.getAssociatedDescribeDocuments(part);

                    if (isCheckOut && !CtVersionUtil.existGreaterVersion(part) && !WorkInProgressHelper.isCheckedOut(part)) {
                        CtACLUtil.checkout(part, "用户：" + currentUser.getFullName() + "通过AD工具的“下载并检出”功能，检出该料！");
                    }

                    while (describedDocs.hasMoreElements()) {
                        WTDocument document = (WTDocument) describedDocs.nextElement();
                        // 压缩文档的主内容和附件
                        ctAdToolLogic.compressDocumentContents(document, types, zipOutputStream, pathPrefix);

                        if (isCheckOut && !CtVersionUtil.existGreaterVersion(document) && !WorkInProgressHelper.isCheckedOut(document)) {
                            CtACLUtil.checkout(part, "用户：" + currentUser.getFullName() + "通过AD工具的“下载并检出”功能，检出该文档！");
                        }
                    }

//                    // 获取参考文档
//                    QueryResult referencedDocs = PartDocServiceCommand.getAssociatedReferenceDocuments(part);
//                    while (referencedDocs.hasMoreElements()) {
//                        WTDocument document = (WTDocument) referencedDocs.nextElement();
//                        // 压缩文档的主内容和附件
//                        ctAdToolLogic.compressDocumentContents(document, types, zipOutputStream, pathPrefix);
//
//                        if (isCheckOut && !CtVersionUtil.existGreaterVersion(document) && !WorkInProgressHelper.isCheckedOut(document)) {
//                            CtACLUtil.checkout(document, "用户：" + currentUser.getFullName() + "通过AD工具的“下载并检出”功能，检出该文档！");
//                        }
//                    }
                } else if (persistable instanceof ManagedBaseline) {
                    ManagedBaseline managedBaseline = (ManagedBaseline) persistable;
                    String pathPrefix = managedBaseline.getName();
                    QueryResult queryResult = BaselineHelper.service.getBaselineItems(managedBaseline);
                    while (queryResult.hasMoreElements()) {
                        Object object = queryResult.nextElement();
                        if (object instanceof WTDocument) {
                            WTDocument document = (WTDocument) object;
                            // 压缩文档的主内容和附件
                            ctAdToolLogic.compressDocumentContents(document, types, zipOutputStream, pathPrefix);

                            if (isCheckOut && !CtVersionUtil.existGreaterVersion(document) && !WorkInProgressHelper.isCheckedOut(document)) {
                                CtACLUtil.checkout(document, "用户：" + currentUser.getFullName() + "通过AD工具的“下载并检出”功能，检出该文档！");
                            }
                        }
                    }
                } else if (persistable instanceof WTDocument) {
                    WTDocument document = (WTDocument) persistable;
                    String pathPrefix = "";
                    // 压缩文档的主内容和附件
                    ctAdToolLogic.compressDocumentContents(document, types, zipOutputStream, pathPrefix);

                    if (isCheckOut && !CtVersionUtil.existGreaterVersion(document) && !WorkInProgressHelper.isCheckedOut(document)) {
                        CtACLUtil.checkout(document, "用户：" + currentUser.getFullName() + "通过AD工具的“下载并检出”功能，检出该文档！");
                    }
                }
            }
        } finally {
            zipOutputStream.close();
        }
    }

    @Override
    public String checkPcbNumber(String pcbNumber, String version, String pcbModel) throws Exception {
        WTPart part = CtPartUtil.getPartByNumber(pcbNumber, CtConstant.VIEW_DESIGN);
        if (part == null) {
            return pcbNumber + "：PCB编码不存在系统中或该物料不存在设计视图！";
        }

        String message = "";
        CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();

        // 校验物料类型
        String localizedTypeName = TypedUtilityServiceHelper.service.getLocalizedTypeName(part, Locale.CHINA);
        HashSet typeSet = ctAdToolProperties.getHashSetValue("pcb.part.type");
        if (!typeSet.contains(localizedTypeName)) {
            if (typeSet.size() == 1) {
                message += "PCB物料：" + pcbNumber + "的物料类型不是[" + typeSet.iterator().next() + "]！\r\n";
            } else {
                message += "PCB物料：" + pcbNumber + "的物料类型不是[" + StringUtils.join(typeSet, "、") + "]其中之一！\r\n";
            }
        }

        // 校验分类
        String nodeDisplayName = CtPartClfUtil.getClfNodeDisplayName(part);
        HashSet classificationSet = ctAdToolProperties.getHashSetValue("pcb.part.classification");
        if (!classificationSet.contains(nodeDisplayName)) {
            if (typeSet.size() == 1) {
                message += "PCB物料：" + pcbNumber + "的分类属性值不是[" + classificationSet.iterator().next() + "]！\r\n";
            } else {
                message += "PCB物料：" + pcbNumber + "的分类属性值不是[" + StringUtils.join(classificationSet, "、") + "]其中之一！\r\n";
            }
        }

        IBAUtil ibaUtil = new IBAUtil(part);
        String ctVersion = ibaUtil.getIBAValue("ct_banci");
        if (StringUtils.isEmpty(ctVersion)) ctVersion = "";
        if (StringUtils.isEmpty(version)) version = "";

        if (version.contains(".") || ctVersion.contains(".")) {
            // 将点替换掉
            ctVersion = ctVersion.replace(".", "");
            version = version.replace(".", "");
        }
        if (StringUtils.isNotEmpty(ctVersion) && StringUtils.isNotEmpty(version) && !version.equals(ctVersion)) {
            // 校验版本是否大于等于PLM内部版本
            String ctVersionPrefix = ctVersion.substring(0, 1);
            String versionPrefix = version.substring(0, 1);
            if (ctVersionPrefix.toUpperCase().equals(versionPrefix.toUpperCase())) {
                // 再比较小版本
                String ctVersionSuffix = ctVersion.substring(1);
                String versionSuffix = version.substring(1);
                try {
                    long ctVersionSuffixLong = Long.valueOf(ctVersionSuffix);
                    long versionSuffixLong = Long.valueOf(versionSuffix);
                    if (versionSuffixLong < ctVersionSuffixLong) {
                        message += "PCB物料：" + pcbNumber + "中的内部版本：" + ctVersion + "大于填写的版本：" + version + "请重新填写！\r\n";
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    message += "PCB物料：" + pcbNumber + "中的内部版本：" + ctVersion
                            + "或填写的版本：" + version + "格式不对，V之后的值无法转成数值！\r\n";
                }
            } else {
                message += "PCB物料：" + pcbNumber + "中的内部版本：" + ctVersion + "与填写的版本：" + version + "不一致！\r\n";
            }
        }
        // 型号规格
        String modelSpecification = ibaUtil.getIBAValue("ct_ModelSpecification");
        if (modelSpecification == null) modelSpecification = "";
        if (pcbModel == null) pcbModel = "";
        modelSpecification = modelSpecification.replace("／", "/");
        pcbModel = pcbModel.replace("／", "/");
        if (!modelSpecification.equals(pcbModel)) {
            message += "PCB物料：" + pcbNumber + "中的型号规格：" + modelSpecification + "与填写的PCB型号：" + pcbModel + "不一致！\r\n";
        }

        return message.trim();
    }

    @Override
    public String checkBOM(String pcbNumber, String innerVersion, List<CtBomPartBo> bomPartBoList) throws Exception {
        if (CollectionUtils.isEmpty(bomPartBoList)) return null;

        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        StringBuffer stringBuffer = new StringBuffer();
        for (CtBomPartBo bomPartBo : bomPartBoList) {
            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t>>>>>>> 开始校验 " + bomPartBo.getFilePath()
                    + "BOM文件的" + bomPartBo.getPthOrSmd() + "[" + bomPartBo.getParentPartNumber() + "]数据！ >>>>>>>\r\n");
            String parentPartNumber = bomPartBo.getParentPartNumber();
            WTPart part = CtPartUtil.getPartByNumber(parentPartNumber, CtConstant.VIEW_DESIGN);
            if (part == null) {
                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                        + "文件中的父项物料号：" + parentPartNumber + "不存在PLM系统中或不存在设计视图！\r\n");
                continue;
            }
            if (WorkInProgressHelper.isCheckedOut(part)) {
                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                        + "文件中的父项物料号：" + parentPartNumber + "处于检出状态，不做更新操作！\r\n");
                continue;
            }
            String parentPartState = part.getLifeCycleState().getDisplay(Locale.CHINA);
            CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
            // 先检查物料状态是否需要手动修订
            HashSet needReviseStateSet = ctAdToolProperties.getHashSetValue("need.revise.pcba.state");
            if (needReviseStateSet.contains(parentPartState)) {

            } else {
                // 校验物料状态是否允许修改BON
                HashSet allowStateSet = ctAdToolProperties.getHashSetValue("allow.update.pcba.bom.state");
                if (allowStateSet.size() > 0 && !allowStateSet.contains(parentPartState)) {
                    stringBuffer.append("只允许以下物料状态【" + StringUtils.join(allowStateSet, "、")
                            + "】可以BOM录入，而父项物料【" + parentPartNumber + "】的状态【" + parentPartState + "】不符合！\r\n");
                    continue;
                }
                // 检查物料是否有修改的权限
                if (!AccessControlHelper.manager.hasAccess(part, AccessPermission.MODIFY)) {
                    stringBuffer.append("物料处于“" + parentPartState + "”状态，没有编辑父项物料号["
                            + parentPartNumber + "]的权限！\r\n");
                    continue;
                }
            }

            // 先校验传参中的下阶物料
            List<CtPartUsageBo> subPartList = bomPartBo.getSubPartList();
            // 用于存储传参中的下阶物料
            HashSet<String> childPartNumSet = new HashSet<>(subPartList == null ? 0 : subPartList.size());
            ;
            if (CollectionUtils.isNotEmpty(subPartList)) {
                for (CtPartUsageBo usageBo : subPartList) {
                    String childPartNum = usageBo.getPartNumber();
                    if (StringUtils.isEmpty(childPartNum)) continue;

                    WTPart childPart = CtPartUtil.getPartByNumber(childPartNum, CtConstant.VIEW_DESIGN);
                    if (childPart == null) {
                        stringBuffer.append(simpleDateFormat.format(new Date()) + "\t父项物料号："
                                + parentPartNumber + " 下的子料：" + childPartNum + "不存在PLM系统中！\r\n");
                        continue;
                    }
//                    if (childPartNum.startsWith("10101")) {
//                        // 校验内部版本是否一致
//                        IBAUtil childPartIbaUtil = new IBAUtil(childPart);
//                        String version = childPartIbaUtil.getIBAValue("ct_banci");
//                        if (version == null) version = "";
//                        if (!version.equals(innerVersion)) {
//                            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
//                                    + "文件中的PCB物料号：" + childPartNum + "的内部版本：" + version
//                                    + "与PCB物料的内部版本：" + innerVersion + "本不一致！\r\n");
//                            continue;
//                        }
//                    }
                    WTPartMaster childPartMaster = childPart.getMaster();
                    QueryResult usageLinkQS = PersistenceHelper.manager.find(WTPartUsageLink.class, part, "usedBy", childPartMaster);
                    if (!usageLinkQS.hasMoreElements()) {
                        stringBuffer.append(simpleDateFormat.format(new Date()) + " \t子料：" + childPartNum
                                + "不存父项物料号：" + parentPartNumber + "的结构中！\r\n");
                        continue;
                    }
                    WTPartUsageLink usageLink = (WTPartUsageLink) usageLinkQS.nextElement();

                    //处理分数
                    String quantityStr = usageBo.getQuantity();
                    String fraction = usageBo.getFraction();
                    if(CtFormatUtil.hasContent(fraction)){
                        if(!CtCommonUtil.isFraction(fraction)){
                            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                                    + "文件中第" + usageBo.getExcelRowCount() + "行物料编码：" + usageBo.getPartNumber()
                                    + "分数" +fraction+ "的格式不正确，请调整！\r\n");
                        }
                        if(CtFormatUtil.hasContent(quantityStr)){
                            double d = CtFormatUtil.formatFraction(fraction);
                            if(d != Double.valueOf(quantityStr)){
                                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                                        + "文件中第" + usageBo.getExcelRowCount() + "行物料编码：" + usageBo.getPartNumber()
                                        + "数量与分数转换值有差异，请更新后重试：分数" +fraction+ ",转换数量应为"+ d +"，而不是"+ quantityStr +",请调整！\r\n");
                            }
                        }
                    }

                    // 校验位号
                    String boPositionNo = usageBo.getPositionNo();
                    // 将位号转成最新的格式进行比较
                    boPositionNo = ctAdToolLogic.getLatestPositionNo(boPositionNo);
                    if (StringUtils.isNotEmpty(boPositionNo)) {
                        String[] values = boPositionNo.split(CtAdToolConstant.STRING_SEPARATOR);
                        if (usageBo.getQuantity() != null && values.length != Double.parseDouble(usageBo.getQuantity())) {
                            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                                    + "文件中第" + usageBo.getExcelRowCount() + "行物料编码：" + usageBo.getPartNumber()
                                    + "的数量与位号个数对不上，位号个数：" + values.length + " -> 数量："
                                    + usageBo.getQuantity() + "请检查！\r\n");
                        }
                    }
                    String positionNo = ctAdToolLogic.getUsesOccurrences(usageLink);
                    if (StringUtils.isEmpty(positionNo)) {
                        if (StringUtils.isNotEmpty(boPositionNo)) {
                            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t父项物料号：" + parentPartNumber
                                    + " 下的子料：" + childPartNum + "的位号不一致，文件中位号："
                                    + boPositionNo + "，PLM的位号：为空！！\r\n");

                        }
                    } else if (!positionNo.equals(boPositionNo)) {
                        stringBuffer.append(simpleDateFormat.format(new Date()) + "\t父项物料号：" + parentPartNumber
                                + " 下的子料：" + childPartNum + "的位号不一致，文件中位号："
                                + (StringUtils.isEmpty(boPositionNo) ? "为空" : boPositionNo)
                                + "，PLM的位号：" + positionNo + "！\r\n");
                    }
                    // 校验数量
                    Quantity quantity = usageLink.getQuantity();
                    if (quantity != null) {
                        double amount = quantity.getAmount();
                        if (amount != Double.parseDouble(usageBo.getQuantity())) {
                            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t父项物料号：" + parentPartNumber
                                    + " 下的子料：" + childPartNum + "数量不一致，文件中数量："
                                    + (usageBo.getQuantity() == null ? "为空" : usageBo.getQuantity())
                                    + "，PLM的数量为：" + amount + "！\r\n");
                        }
                    } else if (Double.parseDouble(usageBo.getQuantity()) > 0) {
                        stringBuffer.append(simpleDateFormat.format(new Date()) + "\t父项物料号：" + parentPartNumber
                                + " 下的子料：" + childPartNum + "数量不一致，文件中数量：" + usageBo.getQuantity()
                                + "，PLM的数量为空！\r\n");
                    }
                    // 校验描述
                    if (!childPart.getName().equalsIgnoreCase(usageBo.getDescription())) {
                        stringBuffer.append(simpleDateFormat.format(new Date()) + "\t父项物料号：" + parentPartNumber
                                + " 下的子料：" + childPartNum + "描述不一致，文件中描述"
                                + (usageBo.getDescription() == null ? "为空" : ":" + usageBo.getDescription())
                                + "，PLM的描述为：" + childPart.getName() + "！\r\n");
                    }

                    // 校验BOM备注
                    IBAUtil ibaUtil = new IBAUtil(usageLink);
                    String bomNotes = ibaUtil.getIBAValue("ct_BOMNotes");
                    String bomRemark = usageBo.getBomRemark();
                    if (StringUtils.isBlank(bomRemark)) {
                        if (StringUtils.isNotEmpty(bomNotes)) {
                            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t父项物料号：" + parentPartNumber
                                    + " 下的子料：" + childPartNum + "BOM备注不一致，文件中BOM备注：为空"
                                    + "，PLM的BOM备注为：" + bomNotes + "！\r\n");
                        }
                    } else if (!bomRemark.equals(bomNotes)) {
                        stringBuffer.append(simpleDateFormat.format(new Date()) + "\t父项物料号：" + parentPartNumber
                                + " 下的子料：" + childPartNum + "BOM备注不一致，文件中BOM备注："
                                + bomRemark + "，PLM的BOM备注为：" + (StringUtils.isEmpty(bomNotes) ? "为空" : bomNotes) + "！\r\n");
                    }

                    // 校验器件库安装方式

                    // 收集校验完的物料编码
                    childPartNumSet.add(childPartNum);
                }
            }
            // 获取传参中未存在的且系统中存在的子料
            List<CtPartUsageBo> noExistChildPartBos = loadPartUsageBos(part, childPartNumSet);
            if (CollectionUtils.isNotEmpty(noExistChildPartBos)) {
                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" +
                        bomPartBo.getFilePath() + "文件下不存在以下物料信息：" + noExistChildPartBos.toString() + "\r\n");
            }
            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t>>>>>>> 结束校验 " + bomPartBo.getFilePath()
                    + "BOM文件的" + bomPartBo.getPthOrSmd() + "[" + bomPartBo.getParentPartNumber() + "]数据！ >>>>>>>\r\n");
        }

        return stringBuffer.toString();
    }

    @Override
    public String getBOMData(List<CtBomPartBo> bomPartBoList) throws Exception {
        if (CollectionUtils.isEmpty(bomPartBoList)) return null;

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        StringBuffer stringBuffer = new StringBuffer();
        Iterator<CtBomPartBo> iterator = bomPartBoList.iterator();
        while (iterator.hasNext()) {
            CtBomPartBo bomPartBo = iterator.next();
            String parentPartNumber = bomPartBo.getParentPartNumber();
            WTPart part = CtPartUtil.getPartByNumber(parentPartNumber, CtConstant.VIEW_DESIGN);
            if (part == null) {
                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                        + "文件中的父项物料号：" + parentPartNumber + "不存在PLM系统中或该物料不存在设计视图！\r\n");
                iterator.remove();
                continue;
            }
            // 替换原有参数的下阶物料
            List<CtPartUsageBo> partUsageBos = loadPartUsageBos(part);
            bomPartBo.setSubPartList(partUsageBos);
        }

        return stringBuffer.toString();
    }

    @Override
    public String updateBOM(String pcbNumber, String innerVersion, List<CtBomPartBo> bomPartBoList, String checkInRemark) throws Exception {
        if (CollectionUtils.isEmpty(bomPartBoList)) return null;

        WTUser currentUser = (WTUser) CtUserUtil.getCurrentUser();
        if (StringUtils.isEmpty(checkInRemark)) {
            checkInRemark = "用户：" + currentUser.getFullName() + "通过AD工具的“BOM更新(本地->PLM)”功能，检出该料！";
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        StringBuffer stringBuffer = new StringBuffer();
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();

        Transaction transaction = new Transaction();
        transaction.start();
        try {
            List<WTPart> checkOutParentParts = new ArrayList<>(bomPartBoList.size());
            for (CtBomPartBo bomPartBo : bomPartBoList) {
                String parentPartNumber = bomPartBo.getParentPartNumber();
                WTPart parentPart = CtPartUtil.getPartByNumber(parentPartNumber, CtConstant.VIEW_DESIGN);
                if (parentPart == null) {
                    stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                            + "文件中的父项物料号：" + parentPartNumber + "不存在PLM系统中或不存在设计视图！\r\n");
                    continue;
                }
                if (WorkInProgressHelper.isCheckedOut(parentPart)) {
                    stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                            + "文件中的父项物料号：" + parentPartNumber + "处于检出状态，不做更新操作！\r\n");
                    continue;
                }
                String parentPartState = parentPart.getLifeCycleState().getDisplay(Locale.CHINA);
                CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
                // 先检查物料状态是否需要手动修订
                HashSet needReviseStateSet = ctAdToolProperties.getHashSetValue("need.revise.pcba.state");
                if (needReviseStateSet.contains(parentPartState)) {
                    // 代码修订
                    parentPart = ctAdToolLogic.doRevisePart(parentPart);
                } else {
                    // 校验物料状态是否允许修改BON
                    HashSet allowStateSet = ctAdToolProperties.getHashSetValue("allow.update.pcba.bom.state");
                    if (allowStateSet.size() > 0 && !allowStateSet.contains(parentPartState)) {
                        stringBuffer.append("只允许以下物料状态【" + StringUtils.join(allowStateSet, "、")
                                + "】可以BOM录入，而父项物料【" + parentPartNumber + "】的状态【" + parentPartState + "】不符合！\r\n");
                        continue;
                    }
                    // 检查物料是否有修改的权限
                    if (!AccessControlHelper.manager.hasAccess(parentPart, AccessPermission.MODIFY)) {
                        stringBuffer.append("物料处于“" + parentPartState + "”状态，没有编辑父项物料号["
                                + parentPartNumber + "]的权限！\r\n");
                        continue;
                    }
                }

                // 检出BOM
                parentPart = (WTPart) CtACLUtil.checkout(parentPart, checkInRemark);
                List<CtPartUsageBo> subPartList = bomPartBo.getSubPartList();
                // 2.删除之前原有的下阶物料
                QueryResult queryResult = WTPartHelper.service.getUsesWTPartMasters(parentPart);
                if (queryResult.size() > 0) {
                    WTHashSet deleteLinkSet = new WTHashSet(queryResult.size());
                    while (queryResult.hasMoreElements()) {
                        WTPartUsageLink partUsageLink = (WTPartUsageLink) queryResult.nextElement();
                        deleteLinkSet.add(partUsageLink);
                    }
                    // 批量删除
                    PersistenceServerHelper.manager.remove(deleteLinkSet);
                }

                // 建立新的关联关系
                for (CtPartUsageBo partUsageBo : subPartList) {
                    try {
                        String partNumber = partUsageBo.getPartNumber();
                        WTPart subPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);
                        if ("贴片半成品".equals(bomPartBo.getPthOrSmd())) {
                            // 检查是否存在下阶，若存在则删除，因为确认贴片下不挂子料
                            QueryResult subQueryResult = WTPartHelper.service.getUsesWTPartMasters(subPart);
                            if (subQueryResult.size() > 0) {
                                WTHashSet deleteLinkSet = new WTHashSet(subQueryResult.size());
                                while (subQueryResult.hasMoreElements()) {
                                    WTPartUsageLink partUsageLink = (WTPartUsageLink) subQueryResult.nextElement();
                                    deleteLinkSet.add(partUsageLink);
                                }
                                // 批量删除
                                PersistenceServerHelper.manager.remove(deleteLinkSet);
                            }
                        }
                        if (subPart == null) {
                            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                                    + "文件中的父项物料号：" + parentPartNumber + " >>> 子料：" + partNumber + "不存在PLM中！\r\n");
                            continue;
                        }

//                        if (partNumber.startsWith("10101")) {
//                            // 校验内部版本是否一致
//                            IBAUtil subPartIbaUtil = new IBAUtil(subPart);
//                            String version = subPartIbaUtil.getIBAValue("ct_banci");
//                            if (version == null) version = "";
//                            if (!version.equals(innerVersion)) {
//                                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
//                                        + "文件中的PCB物料号：" + partNumber + "的内部版本：" + version
//                                        + "与PCB物料的内部版本：" + innerVersion + "本不一致！\r\n");
//                                continue;
//                            }
//                        }

                        WTPartUsageLink partUsageLink = WTPartUsageLink.newWTPartUsageLink(parentPart, subPart.getMaster());
                        partUsageLink = (WTPartUsageLink) PersistenceHelper.manager.store(partUsageLink);
                        String boPositionNo = partUsageBo.getPositionNo();
                        // 将位号转成最新的格式进行比较
                        boPositionNo = ctAdToolLogic.getLatestPositionNo(boPositionNo);
                        if (StringUtils.isNotEmpty(boPositionNo)) {
                            // 设置位号
                            String[] values = boPositionNo.split(CtAdToolConstant.STRING_SEPARATOR);
                            if (partUsageBo.getQuantity() != null && values.length != Double.valueOf(partUsageBo.getQuantity())) {
                                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                                        + "文件中第" + partUsageBo.getExcelRowCount() + "行物料编码：" + partUsageBo.getPartNumber()
                                        + "的数量与位号个数对不上，位号个数：" + values.length + " -> 数量：" + partUsageBo.getQuantity()
                                        +  "，请检查！\r\n");
                                continue;
                            }
                            for (String value : values) {
                                PartUsesOccurrence newOccurrence = PartUsesOccurrence.newPartUsesOccurrence(partUsageLink);
                                newOccurrence.setName(value.trim());
                                OccurrenceHelper.service.saveUsesOccurrenceAndData(newOccurrence, null);
                            }
                        }
                        if (partUsageBo.getQuantity() != null) {
                            QuantityUnit quantityUnit = StringUtils.isNotEmpty(partUsageBo.getPositionNo()) ?
                                    QuantityUnit.EA : QuantityUnit.toQuantityUnit("PC");
                            // 设置数量和单位
                            Quantity quantity = Quantity.newQuantity(Double.valueOf(partUsageBo.getQuantity()), quantityUnit);
                            partUsageLink.setQuantity(quantity);
                        }
                        PersistenceHelper.manager.save(partUsageLink);

//                        // 设置BOM备注
                        IBAUtil ibaUtil = new IBAUtil(partUsageLink);
                        ibaUtil.setIBAValue("ct_BOMNotes", partUsageBo.getBomRemark());
                        //设置分数
                        if(CtFormatUtil.hasContent(partUsageBo.getFraction())){
                            ibaUtil.setIBAValue(CtBomConstant.IBA_FRACTION, partUsageBo.getFraction());
                        }
                        ibaUtil.updateIBAHolder(partUsageLink);
                    } catch (Exception e) {
                        e.printStackTrace();
                        stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + bomPartBo.getFilePath()
                                + "文件中第" + partUsageBo.getExcelRowCount() + "行物料编码：" + partUsageBo.getPartNumber()
                                + "录入失败，后台异常信息：" + e.getLocalizedMessage() + "！\r\n");
                    }
                }

                checkOutParentParts.add(parentPart);
            }
            if (StringUtils.isNotEmpty(stringBuffer)) {
                transaction.rollback();
                return stringBuffer.toString();
            } else {
                // 检入BOM
                for (WTPart parentPart : checkOutParentParts) {
                    CtACLUtil.checkIn(parentPart, checkInRemark);
                }
                transaction.commit();
            }
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            if (StringUtils.isNotEmpty(stringBuffer)) {
                return stringBuffer.toString();
            } else {
                throw e;
            }
        } finally {
            transaction = null;
            System.out.println("更新BOM的错误信息：" + stringBuffer.toString());
        }
        return stringBuffer.toString();
    }

    @Override
    public void fileArchive(Map<String, String[]> map, List<MultipartFile> files) throws Exception {
        if (map == null || map.isEmpty()) return;

        WTUser currentUser = (WTUser) CtUserUtil.getCurrentUser();
        CtCreateDocumentBo createDocumentBo = new CtCreateDocumentBo();
        createDocumentBo.setCurrentUser(currentUser);

        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
//        // 设置管理员权限
//        SessionHelper.manager.setAdministrator();
        // 开启事务
        Transaction transaction = new Transaction();
        transaction.start();

        String[] containerOids = map.get("containerOid");
        if (containerOids == null || containerOids.length == 0) return;

        String[] pcbNumbers = map.get("pcbNumber");
        if (pcbNumbers == null || pcbNumbers.length == 0) return;

        String[] versions = map.get("version");
        if (versions == null || versions.length == 0) return;

        // PCB型号
        String[] pcbModels = map.get("pcbModel");
        if (pcbModels == null || pcbModels.length == 0) return;

        // 检入备注
        String pcbCheckInRemark = null;
        String docCheckInRemark = null;
        String[] checkInRemarks = map.get("checkInRemark");
        if (checkInRemarks == null || checkInRemarks.length == 0) {
            pcbCheckInRemark = "用户：" + currentUser.getFullName() + "操作AD工具的“归档”功能升级小版本！";
        } else {
            pcbCheckInRemark = checkInRemarks[0];
            docCheckInRemark = checkInRemarks[0];
        }

        // PCB丝印时间
        String[] pcbSilkScreenTimes = map.get("pcbSilkScreenTime");
        if (pcbSilkScreenTimes == null || pcbSilkScreenTimes.length == 0) return;

        // 是否创建基线，默认创建
        boolean isCreateBaseLine = true;
        if (map.containsKey("createBaseLine") && "false".equals(map.get("createBaseLine")[0])) {
            isCreateBaseLine = false;
        }

        String containerOid = containerOids[0];
        String pcbNumber = pcbNumbers[0];
        String version = versions[0];
        String pcbModel = pcbModels[0];
        if (StringUtils.isNotEmpty(version)) {
            // 将点替换掉
            version = version.replace(".", "");
        }
        String pcbSilkScreenTime = pcbSilkScreenTimes[0];
        StringBuffer stringBuffer = new StringBuffer();
        try {
            String[] bomFileAndPcbaMaps = map.get("bomFileAndPCBAMap");
            Map<String, String> bomFileAndPCBAMap = null;
            try {
                bomFileAndPCBAMap = ArrayUtils.isEmpty(bomFileAndPcbaMaps) ? null : JSONObject.parseObject(bomFileAndPcbaMaps[0], Map.class);
            } catch (Exception e) {
                throw new WTException("bomFileAndPcbaMaps[0] -> " + bomFileAndPcbaMaps[0] + " JSON字符串转Map失败！");
            }

            map.remove("containerOid");
            map.remove("pcbNumber");
            map.remove("version");
            map.remove("bomFileAndPCBAMap");
            map.remove("pcbModel");
            map.remove("pcbSilkScreenTime");
            map.remove("checkInRemark");
            map.remove("createBaseLine");

            WTContainer container = (WTContainer) CtWTObjectUtil.getObjectByOid(containerOid);
            if (container == null) throw new Exception("根据OID：" + containerOid + "获取容器失败！");

            WTPart pcbPart = CtPartUtil.getPartByNumber(pcbNumber, CtConstant.VIEW_DESIGN);
            String newVersion = null;
            if (!version.contains(".")) {
                // 插入点
                newVersion = version.substring(0, 2) + "." + version.substring(2);
            } else {
                newVersion = version;
                version = version.replace(".", "");
            }
            String message = "";
            CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
            int bomFileAndPCBAMapSize = MapUtils.isEmpty(bomFileAndPCBAMap) ? 0 : bomFileAndPCBAMap.size();
            int mapSize = MapUtils.isEmpty(map) ? 0 : map.size();
            System.out.println("fileArchive >>>>>>> isCreateBaseLine=" + isCreateBaseLine + " >>> bomFileAndPCBAMapSize="
                    + bomFileAndPCBAMapSize + " >>> mapSize=" + mapSize);
            if ((isCreateBaseLine && bomFileAndPCBAMapSize != mapSize)
                    || (map.size() == 1 && map.containsKey("0613_焊接附件"))) {
                // 先检查一下PCB料
                message = checkPcbNumber(pcbNumber, version, pcbModel);
                if (StringUtils.isNotEmpty(message)) {
                    throw new Exception(message);
                }

                String pcbPartState = pcbPart.getLifeCycleState().getDisplay(Locale.CHINA);
                // 先检查物料状态是否需要自动修订
                HashSet needReviseStateSet = ctAdToolProperties.getHashSetValue("need.revise.pcba.state");
                if (needReviseStateSet.contains(pcbPartState)) {
                    pcbPart = ctAdToolLogic.doRevisePart(pcbPart);
                }
                // 升版，并更新内部版本
                pcbPart = (WTPart) CtACLUtil.checkout(pcbPart, pcbCheckInRemark);
                IBAUtil ibaUtil = new IBAUtil(pcbPart);
                ibaUtil.setIBAValue("ct_banci", newVersion);
                ibaUtil.updateIBAHolder(pcbPart);
                pcbPart = (WTPart) CtACLUtil.checkIn(pcbPart, pcbCheckInRemark);
            }

            createDocumentBo.setRelationPart(pcbPart);
            String numberAndModel = pcbNumber + "_" + pcbModel;

            // 归档的文件列表
            HashSet<String> archiveNumPrefixSet = ctAdToolProperties.getHashSetValue("archive.document.prefix.list");
            WTHashSet addDocSet = new WTHashSet();

            // 获取归档的根目录
            String rootPath = ctAdToolProperties.getStringValue("hardware.archive.root");
            if (StringUtils.isEmpty(rootPath)) {
                throw new Exception("CtAdTool.properties文件中未配置归档根路径！");
            }

            for (Map.Entry<String, String[]> item : map.entrySet()) {
                try {
                    if (ArrayUtils.isEmpty(item.getValue())) continue;

                    String key = item.getKey();
                    // 取第一个值
                    String value = item.getValue()[0];
                    // 将JSON字符串转成Map，key：打成压缩包的路径，value：文件列表的下标
                    HashMap<String, Integer> pathParamsMap = JSONObject.parseObject(value, HashMap.class);
                    if (pathParamsMap == null || pathParamsMap.isEmpty()) continue;

                    // 获取归档的文档类型和伪子类型编码
                    String propertiesValue = ctAdToolProperties.getStringValue(key);
                    if (StringUtils.isEmpty(propertiesValue)) continue;

                    // 文档类型前缀标识
                    String flag = key.split("_")[0];
                    String docNumberSuffix = flag;

                    String[] split = propertiesValue.split("\\|");
                    // 文档内部名称
                    String docType = split[0];
                    // 方法名
                    String methodName = split[1];
                    if (split.length > 2) {
                        // 伪子类型编码
                        docNumberSuffix += "_" + split[2];
                    }

                    // 拼接压缩包名 = PCB编码.PCB型号.(版本.YYYYYMMDD)yyyymmdd.hhmm.zip
                    String compressName = pcbNumber + "." + pcbModel + "(" + version + "." + pcbSilkScreenTime + ")"
                            + CtDateUtil.getCurrentDate("yyyyMMdd.HHmm", "GMT+8") + ".zip";

                    createDocumentBo.setCompressName(compressName);
                    createDocumentBo.setFileArchiveType(key);
                    createDocumentBo.setDocType(docType);
                    createDocumentBo.setContainerReference(container);
                    createDocumentBo.setModel(pcbModel);
                    createDocumentBo.setDocNumberSuffix(docNumberSuffix);
                    createDocumentBo.setCheckInRemark(docCheckInRemark);
                    createDocumentBo.setBomFileAndPCBAMap(bomFileAndPCBAMap);
                    createDocumentBo.setPcbPart(pcbPart);

                    String folderName = key;
                    String tempFolderName = ctAdToolProperties.getStringValue("folder." + key);
                    if (StringUtils.isNotEmpty(tempFolderName)) {
                        folderName = tempFolderName;
                    }
                    // 目录=根路径/PCB编码 + PCB型号/文件夹名
                    String folderPath = rootPath + "/" + numberAndModel + "/" + folderName;
                    // 先查询该路径下是否存在以该文件夹名开头的文件夹
                    Folder docFolder = ctAdToolQuery.queryFolder(folderPath, container);
                    if (docFolder == null) {
                        // 创建或取该文件夹
                        docFolder = CtFolderUtil.getFolder(folderPath, container);
                    }
                    createDocumentBo.setFolderId(docFolder);
                    createDocumentBo.setCtVersion(newVersion);

                    Method method = ctAdToolLogic.getClass().getMethod(methodName, HashMap.class, List.class, WTHashSet.class, HashSet.class, CtCreateDocumentBo.class);
                    try {
                        method.invoke(ctAdToolLogic, pathParamsMap, files, addDocSet, archiveNumPrefixSet, createDocumentBo);
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                        throw e;
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                        throw e;
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                        Throwable throwable = e.getTargetException();
                        throw new Exception(throwable.getLocalizedMessage());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    stringBuffer.append("处理：" + item.getKey() + "目录文件归档时发生错误，异常信息：" + e.getLocalizedMessage() + "\r\n");
                }
            }

            message = stringBuffer.toString();
            if (StringUtils.isNotEmpty(message)) {
                throw new Exception(message);
            }

            // 若只归档了“0613_焊接附件”文件，则不往下创建基线了，因为该文件与PCB料无关
            if (map.size() == 1 && map.containsKey("0613_焊接附件")) {
                System.out.println("0613_焊接附件文件归档！");
                transaction.commit();
                return;
            }

            // 若不用创建基线，则直接返回
            if (!isCreateBaseLine) {
                System.out.println("isCreateBaseLine >>>>>>> " + isCreateBaseLine);
                transaction.commit();
                return;
            }

            // 将另外非勾选的文件最新版本一并带入到基线中
            for (String numPrefix : archiveNumPrefixSet) {
                if ("0603_002".equals(numPrefix)) {
                    // 根据编码前缀找文档
                    QueryResult queryResult = ctAdToolQuery.queryDocumentByDocumentNumber(pcbNumber + "_" + numPrefix, null);
                    while (queryResult.hasMoreElements()) {
                        WTDocumentMaster documentMaster = (WTDocumentMaster) queryResult.nextElement();
                        WTDocument document = (WTDocument) CtVersionUtil.getLatest(documentMaster);
                        addDocSet.add(document);
                    }
                } else {
                    // 文档编码 = PCB料号+标识
                    String docNumber = pcbNumber + "_" + numPrefix;
                    WTDocument document = CtDocUtil.getDocumentByNumber(docNumber);
                    if (document != null) {
                        addDocSet.add(document);
                    }
                }
            }

            if (addDocSet.size() > 0) {
                // 基线名 = PCB料号+PCB型号+时间轴
                String baseLineName = numberAndModel + "_" + CtDateUtil.getCurrentDate("yyyyMMddHHmmss", "GMT+8");
                // 基线目录 = 根目录/PCB编码+PCB型号
                Folder baseLineFolder = CtFolderUtil.getFolder(rootPath + "/" + pcbNumber + "_" + pcbModel, container);
                // 创建基线
                PersistableAdapter persistableAdapter = new PersistableAdapter("wt.vc.baseline.ManagedBaseline", null, new CreateOperationIdentifier());
                persistableAdapter.load("name", "folder.id", "ct_materialsnumber", "ct_ModelSpecification",
                        "state.state", "creator", "ownership.owner");
                persistableAdapter.set("name", baseLineName);
                persistableAdapter.set("folder.id", baseLineFolder);
                persistableAdapter.set("ct_materialsnumber", pcbNumber);
                persistableAdapter.set("ct_ModelSpecification", pcbModel);
                persistableAdapter.set("state.state", State.RELEASED);
                persistableAdapter.set("creator", currentUser);
                persistableAdapter.set("ownership.owner", currentUser);

                ManagedBaseline managedBaseline = (ManagedBaseline) persistableAdapter.apply();
                managedBaseline = (ManagedBaseline) PersistenceHelper.manager.save(managedBaseline);

                List<Object> removeList = new ArrayList<>();
                // 再次去重
                Map<Long, Object> objMap = new HashMap<>();
                for (Object o : addDocSet) {
                    if (o instanceof ObjectReference) {
                        ObjectReference objectReference = (ObjectReference) o;
                        o = objectReference.getObject();
                    }
                    if (o instanceof RevisionControlled) {
                        RevisionControlled revisionControlled = (RevisionControlled) o;
                        long id = revisionControlled.getMaster().getPersistInfo().getObjectIdentifier().getId();
                        if (objMap.containsKey(id)) {
                            // 将之前出现的移除
                            removeList.add(objMap.get(id));
                        }
                        objMap.put(id, o);
                    }
                }
                if (CollectionUtils.isNotEmpty(removeList)) addDocSet.removeAll(removeList);
                // 将最新归档文档与基线关联
                BaselineHelper.service.addToBaseline(addDocSet, managedBaseline);
            }

            // 事务提交
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            // 事务回滚
            transaction.rollback();

            String localizedMessage = e.getLocalizedMessage();
            if (StringUtils.isNotEmpty(localizedMessage) && localizedMessage.startsWith("处理")) {
                throw e;
            } else {
                String message = stringBuffer.toString();
                if (StringUtils.isNotEmpty(message)) {
                    throw new Exception(message);
                } else {
                    throw e;
                }
            }
        } finally {
            transaction = null;
//            SessionHelper.manager.setPrincipal(currentUser.getName());
        }
    }

    @Override
    public List<CtContainerBo> getContainers(CtContainerParamsBo paramsBo) throws Exception {
        // 获取产品库
        QueryResult productQS = ProductListCommand.getProducts("netmarkets.product.list");
        // 获取存储库
        QueryResult libraryQS = LibraryListCommand.getLibraries("netmarkets.library.list");

        List<CtContainerBo> boList = new ArrayList<>(productQS.size() + libraryQS.size());
        while (productQS.hasMoreElements()) {
            PDMLinkProduct product = (PDMLinkProduct) productQS.nextElement();
            IBAUtil ibaUtil = new IBAUtil(product);
            CtContainerBo bo = new CtContainerBo();
            bo.setOid(CtWTObjectUtil.getOid(product));
            bo.setName(product.getName());
            bo.setFinishedMaterialCode(ibaUtil.getIBAValue("Ct_FinishedMaterialCode"));
            bo.setType("产品库");
            boList.add(bo);
        }
        while (libraryQS.hasMoreElements()) {
            WTLibrary library = (WTLibrary) libraryQS.nextElement();
            CtContainerBo bo = new CtContainerBo();
            bo.setOid(CtWTObjectUtil.getOid(library));
            bo.setName(library.getName());
            bo.setType("存储库");
            boList.add(bo);
        }
        return boList;
    }

    @Override
    public String updateCentralLibrary(CtCentralLibraryParamsBo paramsBo) throws Exception {
        if (CollectionUtils.isEmpty(paramsBo.getPartNumberList()) || StringUtils.isEmpty(paramsBo.getUpdateFlags()))
            return null;

        String[] updateFlags = paramsBo.getUpdateFlags().split(CtAdToolConstant.STRING_SEPARATOR);
        List<CtCentralLibraryBo> boList = getCentralLibrary(paramsBo);

        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        StringBuffer stringBuffer = new StringBuffer();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(CtConstant.DATE_FORMAT);
        for (CtCentralLibraryBo bo : boList) {
            WTPart part = CtPartUtil.getPartByNumber(bo.getMaterialCode().toUpperCase(), CtConstant.VIEW_DESIGN);
            if (part == null) continue;

            for (String updateFlag : updateFlags) {
                if (CtAdToolConstant.PLM_PART_UPDATE_FLAG.equals(updateFlag)) {
                    ctAdToolLogic.loadCentralLibraryBo(bo, part);
                    // 装载PLM属性
                    boolean isSuccess = ctAdToolQuery.updateById(bo);
                    stringBuffer.append(simpleDateFormat.format(new Date()) + "\t" + "物料：" + bo.getMaterialCode()
                            + "更新" + (isSuccess ? "成功" : "失败") + "！\r\n");
                } else if (CtAdToolConstant.RRP_PART_UPDATE_FLAG.equals(updateFlag)) {
                    // TODO 更新ERP物料信息
                }
            }
        }
        return stringBuffer.toString();
    }

    @Override
    public String saveCentralLibrary(CtCentralLibraryBo bo) throws Exception {
        if (StringUtils.isBlank(bo.getMaterialRetrievalCode())) throw new Exception("网络中心库的唯一ID为空！");

        Date currentTime = new Date();
        bo.setModifyTime(currentTime);

//        CtCentralLibraryBo selectOne = null;
//        if (bo.getCreateTime() == null) {
//            selectOne = ctAdToolQuery.selectOneDataByBo(bo);
//        } else {
//            selectOne = bo;
//        }

        CtCentralLibraryBo selectOne = ctAdToolQuery.selectOneDataByBo(bo);
        if (selectOne == null) {
            bo.setCreateTime(currentTime);
            boolean success = ctAdToolQuery.insert(bo);
            return "添加" + (success ? "成功" : "失败");
        } else {
            boolean success = ctAdToolQuery.updateById(bo);
            return "更新" + (success ? "成功" : "失败");
        }
    }

    @Override
    public String importNetworkCentralLibrary(Map<String, String[]> map, List<MultipartFile> files) throws Exception {
        if (CollectionUtils.isEmpty(files)) return "未上传文件！";

        String[] importAlls = map.get("isImportAll");
        boolean isImportAll = ArrayUtils.isEmpty(importAlls) ? false : Boolean.valueOf(importAlls[0]);
        MultipartFile multipartFile = files.get(0);
        InputStream inputStream = multipartFile.getInputStream();
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        List<CtCentralLibraryBo> boList = ctAdToolLogic.importDataLoadToBo(inputStream, CtCentralLibraryBo.class, 2);
        if (CollectionUtils.isEmpty(boList)) return "通过文件：" + multipartFile.getOriginalFilename() + " 未解析到数据！";

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        StringBuffer stringBuffer = new StringBuffer();
        int successCount = 0;
        int failCount = 0;
        int rowCount = 4;
        for (CtCentralLibraryBo bo : boList) {
            String materialRetrievalCode = bo.getMaterialRetrievalCode();

            if (StringUtils.isEmpty(materialRetrievalCode)) materialRetrievalCode = "";
            if (materialRetrievalCode.contains("-")) materialRetrievalCode = materialRetrievalCode.replace("-", "_");

            try {
                if (materialRetrievalCode.startsWith("S")) {
                    bo.setTableName(CtAdToolConstant.LIBRARY);
                } else {
                    String materialCode = bo.getMaterialCode();

                    // 校验编码是否存在
                    WTPart part = CtPartUtil.getPartByNumber(materialCode.toUpperCase(), CtConstant.VIEW_DESIGN);
                    if (part == null) {
                        if (!materialRetrievalCode.startsWith("L")) {
                            stringBuffer.append(simpleDateFormat.format(new Date()) + "\t第 " + rowCount
                                    + " 物料：" + materialCode + "不存在PLM系统中或该物料不存在设计视图！\r\n");
                            failCount++;
                            rowCount++;
                            continue;
                        } else {
                            bo.setTableName(CtAdToolConstant.LIBRARY_TEMP);
                        }
                    } else {
                        if (materialRetrievalCode.startsWith("L")) {
                            bo.setTableName(CtAdToolConstant.LIBRARY_TEMP);
                        } else {
                            bo.setTableName(ctAdToolLogic.getCentralLibraryTableName(part));
                        }

                        if (CtAdToolConstant.LIBRARY_PCB.equals(bo.getTableName()) || CtAdToolConstant.LIBRARY_CBB.equals(bo.getTableName()) ) {
                            // 若物料需要入PCB或CBB库，则校验内部版本是否存在
                            if (StringUtils.isBlank(bo.getActualVersion())) {
                                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t第 " + rowCount
                                        + "PCB或CBB物料：" + materialCode  + "没有填写内部版本值！\r\n");
                                failCount++;
                                rowCount++;
                                continue;
                            }

                            HashMap<String, Object> queryParamsMap = new HashMap<>(2);
                            queryParamsMap.put("ibaName", "ct_banci");
                            queryParamsMap.put("ibaValue", bo.getActualVersion());
                            queryParamsMap.put("partNumber", part.getNumber());
                            queryParamsMap.put("viewName", CtConstant.VIEW_DESIGN);
                            queryParamsMap.put("queryCondition", "queryAllVersion");
                            List<HashMap<String, Object>> mapList = ctAdToolQuery.queryPartIbaValue(queryParamsMap);
                            System.out.println("partNumber：" + part.getNumber() + "，ibaValue：" + bo.getActualVersion() + "，mapList.size：" + mapList.size());
                            if (CollectionUtils.isNotEmpty(mapList)) {
                                // 取最大的物料ID
                                Long maxPartId = null;
                                for (HashMap<String, Object> itemMap : mapList) {
                                    Long partId = Long.valueOf(itemMap.get("PARTID").toString());
                                    if (maxPartId == null) {
                                        maxPartId = partId;
                                    } else if (partId > maxPartId) {
                                        maxPartId = partId;
                                    }
                                }

                                part = (WTPart) CtWTObjectUtil.getObjectByOid("OR:" + WTPart.class.getName() + ":" + maxPartId);
                            } else {
                                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t第 " + rowCount
                                        + "物料：" + materialCode + "不存在内部版本为：" + bo.getActualVersion() + "的信息！\r\n");
                                failCount++;
                                rowCount++;
                                continue;
                            }
                            System.out.println("CtVersionUtil.getVersionInfo(part) >>>>>>>>> " + CtVersionUtil.getVersionInfo(part));
                        }

                        if (!isImportAll) {
                            // 拿PLM属性存储到BO中
                            ctAdToolLogic.loadCentralLibraryBo(bo, part);
                        }
                    }
                }

                String message = saveCentralLibrary(bo);
                if (message.contains("成功")) {
                    successCount++;
                } else {
                    failCount++;
                    stringBuffer.append(simpleDateFormat.format(new Date()) + "\t第 " + rowCount +
                            " 行的唯一ID：" + materialRetrievalCode + " 添加或更新失败\r\n");
                }
            } catch (Exception e) {
                e.printStackTrace();
                failCount++;
                stringBuffer.append(simpleDateFormat.format(new Date()) + "\t第 " + rowCount +
                        " 行的唯一ID：" + materialRetrievalCode + "更新失败，后台异常信息：" + e.getLocalizedMessage() + "\r\n");
            }
            rowCount++;
        }

        String message = stringBuffer.toString().trim() + "\r\n" + simpleDateFormat.format(new Date())
                + "\t一共 " + boList.size() + " 条数据，成功：" + successCount + "条，失败：" + failCount + "条！";
        return message.trim();
    }

    @Override
    public List<CtCentralLibraryBo> getCentralLibrary(CtCentralLibraryParamsBo paramsBo) throws Exception {
        if (CollectionUtils.isEmpty(paramsBo.getPartNumberList())
                && StringUtils.isEmpty(paramsBo.getPartNumber()))
            return new ArrayList<>(0);

        List<CtCentralLibraryBo> boList = null;
        List<String> tableNameList = paramsBo.getTableNameList();
        if (StringUtils.isEmpty(paramsBo.getTableName()) && CollectionUtils.isEmpty(paramsBo.getTableNameList())) {
            // 若没指定表，则默认全部
            CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
            String[] tableNames = ctAdToolProperties.getStringValue("network.central.library.tables").split(CtAdToolConstant.STRING_SEPARATOR);
            tableNameList = Arrays.asList(tableNames);
        }
        if (CollectionUtils.isNotEmpty(tableNameList)) {
            for (String tableName : tableNameList) {
                paramsBo.setTableName(tableName);
                if (boList == null) {
                    boList = ctAdToolQuery.queryDataByParamsBo(paramsBo, CtCentralLibraryBo.class);
                } else {
                    List<CtCentralLibraryBo> tempBoList = ctAdToolQuery.queryDataByParamsBo(paramsBo, CtCentralLibraryBo.class);
                    if (CollectionUtils.isNotEmpty(tempBoList)) {
                        boList.addAll(tempBoList);
                    }
                }
            }
        } else {
            boList = ctAdToolQuery.queryDataByParamsBo(paramsBo, CtCentralLibraryBo.class);
        }
        return boList;
    }

    @Override
    public void exportNetworkCentralLibrary(CtCentralLibraryParamsBo paramsBo, OutputStream outputStream) throws Exception {
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        String templatePath = CtCommonUtil.getWTHomePath() + File.separator + "codebase" + File.separator + CtAdToolConstant.TEMPLATE_RELATIVE_PATH + "网络中心库模板.xlsx";

        CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
        Map<String, List<CtCentralLibraryBo>> mapList = new HashMap<>();
        for (String tableName : paramsBo.getTableNameList()) {
            paramsBo.setTableName(tableName);
            List<CtCentralLibraryBo> boList = ctAdToolQuery.queryCentralLibrary(paramsBo);
            if (CollectionUtils.isEmpty(boList)) continue;

            mapList.put(ctAdToolProperties.getStringValue(tableName), boList);
        }
        ctAdToolLogic.exportDataByExcelTemplate(templatePath, mapList, outputStream);
    }

    @Override
    public String updatedVersion(CtUpdatedVersionParamsBo paramsBo) throws Exception {
        String oid = paramsBo.getOid();
        String newVersion = paramsBo.getNewVersion();
        if (StringUtils.isEmpty(oid) || StringUtils.isEmpty(newVersion)) return "缺少必传oid或newVersion参数！";

        // 校验新版本是否存在系统中
        ReferenceFactory referenceFactory = new ReferenceFactory();
        String partNumber = "";
        Persistable per = referenceFactory.getReference(oid).getObject();
        if (per instanceof WTPart) {
            WTPart part = (WTPart) per;
            partNumber = part.getNumber();
        }
        HashMap<String, Object> queryParamsMap = new HashMap<>(2);
        queryParamsMap.put("ibaName", "ct_banci");
        queryParamsMap.put("ibaValue", newVersion);
        queryParamsMap.put("partNumber", partNumber);
        List<HashMap<String, Object>> mapList = ctAdToolQuery.queryPartIbaValue(queryParamsMap);
        if (CollectionUtils.isNotEmpty(mapList)) {
            String partNumbers = "";
            for (HashMap<String, Object> map : mapList) {
                partNumbers += CtAdToolConstant.STRING_SEPARATOR + map.get("PARTNUMBER").toString();
            }
            return "新版本：" + newVersion + "已经存在[" + partNumbers.substring(1) + "]物料中！";
        }

        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
        String message = "";
        Transaction transaction = new Transaction();
        transaction.start();
        try {
            // 升级小版本
            part = (WTPart) CtACLUtil.checkout(part, "更新版本！");
            part = (WTPart) CtACLUtil.checkIn(part, "更新版本！");

            IBAUtil ibaUtil = new IBAUtil(part);
            ibaUtil.setIBAValue("ct_banci", newVersion);
            ibaUtil.updateIBAHolder(part);

            CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
            if (ctAdToolLogic.isCanWarehousing(part)) {
                CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
                ctAdToolLogic.setCentralLibraryId(part, bo);
                CtCentralLibraryBo newBo = ctAdToolQuery.selectOneDataByBo(bo);
                boolean success = false;
                if (newBo == null) {
                    success = ctAdToolQuery.insert(bo);
                } else {
                    newBo.setActualVersion(newVersion);
                    success = ctAdToolQuery.updateById(bo);
                }

                if (success) {
                    ibaUtil.updateIBAHolder(part);
                } else {
                    message += "添加数据到网络中心库失败，请联系管理员！";
                }
            } else {
                ibaUtil.updateIBAHolder(part);
            }
            transaction.commit();
            transaction = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (transaction != null) transaction.rollback();
        }
        return message;
    }

    @Override
    public String deleteCentralLibrary(CtCentralLibraryParamsBo paramsBo) throws Exception {
        String finalMessage = null;
        if (paramsBo.isCheckDeleteData()) {
            StringBuilder message = new StringBuilder();
            List<CtCentralLibraryBo> boList = null;
            if (CollectionUtils.isNotEmpty(paramsBo.getTableNameList())) {
                List<String> tableNameList = paramsBo.getTableNameList();
                for (String tableName : tableNameList) {
                    paramsBo.setTableName(tableName);
                    if (boList == null) {
                        boList = ctAdToolQuery.queryCentralLibrary(paramsBo);
                    } else {
                        List<CtCentralLibraryBo> tempBoList = ctAdToolQuery.queryCentralLibrary(paramsBo);;
                        boList.addAll(tempBoList);
                    }
                }
            } else {
                boList = ctAdToolQuery.queryCentralLibrary(paramsBo);
            }
            for (CtCentralLibraryBo bo : boList) {
                // 检查物料是否存在
                WTPart part = CtPartUtil.getPartByNumber(bo.getMaterialCode().toUpperCase(), CtConstant.VIEW_DESIGN);
                if (part != null) {
                    message.append("物料【" + bo.getMaterialCode() + "】存在系统中！\r\n");
                }
                if (StringUtils.isNotBlank(bo.getFootprintPath())) {
                    message.append("唯一ID【" + bo.getMaterialRetrievalCode() + "】已经维护了封装数据！\r\n");
                }
            }
            finalMessage = message.toString().trim();
        } else {
            if (CollectionUtils.isNotEmpty(paramsBo.getTableNameList())) {
                List<String> tableNameList = paramsBo.getTableNameList();
                for (String tableName : tableNameList) {
                    paramsBo.setTableName(tableName);
                    ctAdToolQuery.deleteDataByParamsBo(paramsBo);
                }
            } else {
                ctAdToolQuery.deleteDataByParamsBo(paramsBo);
            }
        }
        return finalMessage;
    }

    @Override
    public void handlePartCreateWarehousing(WTPart part) throws Exception {
        System.out.println("ext.plm.adTool.CtAdToolServiceImpl.handlePartCreateWarehousing >>>>> " + part.getNumber());
        String versionInfo = CtVersionUtil.getVersionInfo(part);
        if (!"A.1".equals(versionInfo)) {
            System.out.println("ext.plm.adTool.CtAdToolServiceImpl.handlePartCreateWarehousing 物料："
                    + part.getNumber() + "，版本：" + versionInfo + "，视图：" + part.getViewName());
            return;
        }
        if (WorkInProgressHelper.isWorkingCopy(part)) {
            System.out.println("ext.plm.adTool.CtAdToolServiceImpl.handlePartCreateWarehousing >>>>> isWorkingCopy" + part.getNumber());
            // 不考虑副本情况
            return;
        }
        part = (WTPart) PersistenceHelper.manager.refresh(part);
        // 检查物料是否满足入网络中心库的条件，若满足，则创建审阅对象
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        boolean canWarehousing = ctAdToolLogic.isCanWarehousing(part);
        if (canWarehousing) {
            Vector<WTPart> vector = new Vector<>(1);
            vector.add(part);
            ctAdToolLogic.createReviewAndGenerateAttachment(vector);
        }
    }

    @Override
    public void handlePartEditWarehousing(WTPart part) throws Exception {
        System.out.println("ext.plm.adTool.CtAdToolServiceImpl.handlePartEditWarehousing >>>>> " + part.getNumber());
        part = (WTPart) PersistenceHelper.manager.refresh(part);
        // 检查物料是否满足入网络中心库的条件，若满足，则更新该数据
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        // 只看设计视图
        if (CtConstant.VIEW_DESIGN.equals(part.getViewName()) && ctAdToolLogic.isCanWarehousing(part)) {
            if (ctAdToolQuery == null) {
                ctAdToolQuery = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolQuery.class);
            }
            CtCentralLibraryBo bo = ctAdToolLogic.loadCentralLibraryBo(part);
            ctAdToolLogic.setCentralLibraryId(part, bo);
            CtCentralLibraryBo centralLibraryBo = ctAdToolQuery.selectOneDataByBo(bo);
            if (centralLibraryBo == null) {
                // 创建审阅对象
                Vector<WTPart> vector = new Vector<>(1);
                vector.add(part);
                ctAdToolLogic.createReviewAndGenerateAttachment(vector);
            } else {
                bo.setModifyTime(new Date());
                String tableName = bo.getTableName();
                // 根据表名确认是根据编码还是根据ID更新数据
                if (tableName.equals(CtAdToolConstant.LIBRARY_CBB) || tableName.equals(CtAdToolConstant.LIBRARY_PCB)) {
                    ctAdToolQuery.updateDataByBo(bo, "\"MaterialRetrievalCode\"");
                } else {
                    ctAdToolQuery.updateDataByBo(bo, "\"MaterialCode\"");
                }
                ctAdToolLogic.syncTempCentralLibrary(part);
            }
        }
    }

    /**
     * 装载持久化对象信息BO
     *
     * @param persistable
     * @return
     * @throws Exception
     */
    private CtPersistableBo loadPersistableBo(Persistable persistable) throws Exception {
        if (persistable == null) return null;

        CtPersistableBo bo = new CtPersistableBo();
        String type = null;
        String oid = null;
        String name = null;
        String number = null;
        String innerVersion = null;
        String version = null;
        String state = null;
        String modified = null;
        Date mdifyTime = null;
        String containerName = null;
        String location = null;
        if (persistable instanceof WTPart || persistable instanceof WTPartMaster) {
            WTPart part = null;
            if (persistable instanceof WTPart) {
                part = (WTPart) persistable;
            } else {
                WTPartMaster master = (WTPartMaster) persistable;
                part = (WTPart) CtVersionUtil.getLatest(master);
            }
            type = "物料";
            oid = CtWTObjectUtil.getOid(part);
            name = part.getName();
            number = part.getNumber();
            version = CtVersionUtil.getVersionInfo(part);
            IBAUtil ibaUtil = new IBAUtil(part);
            innerVersion = ibaUtil.getIBAValue("ct_banci");
            state = part.getLifeCycleState().getDisplay(Locale.CHINA);
            modified = part.getModifierFullName();
            mdifyTime = part.getModifyTimestamp();
            containerName = part.getContainerName();
            location = getFolderPath(part);
        } else if (persistable instanceof ManagedBaseline) {
            ManagedBaseline managedBaseline = (ManagedBaseline) persistable;
            type = "基线";
            oid = CtWTObjectUtil.getOid(managedBaseline);
            name = managedBaseline.getName();
            number = managedBaseline.getNumber();
            state = managedBaseline.getLifeCycleState().getDisplay(Locale.CHINA);
            modified = managedBaseline.getCreatorName();
            mdifyTime = managedBaseline.getModifyTimestamp();
            containerName = managedBaseline.getContainerName();
            location = getFolderPath(managedBaseline);
        } else if (persistable instanceof WTDocument) {
            WTDocument document = (WTDocument) persistable;
            type = "文档";
            oid = CtWTObjectUtil.getOid(document);
            name = document.getName();
            number = document.getNumber();
            version = CtVersionUtil.getVersionInfo(document);
            IBAUtil ibaUtil = new IBAUtil(document);
            innerVersion = ibaUtil.getIBAValue("ct_banci");
            state = document.getLifeCycleState().getDisplay(Locale.CHINA);
            modified = document.getModifierFullName();
            mdifyTime = document.getModifyTimestamp();
            containerName = document.getContainerName();
            location = getFolderPath(document);
        }
        bo.setType(type);
        bo.setOid(oid);
        bo.setName(name);
        bo.setNumber(number);
        bo.setInnerVersion(innerVersion);
        bo.setVersion(version);
        bo.setState(state);
        bo.setModified(modified);
        bo.setModifyTime(mdifyTime);
        bo.setContainerName(containerName);
        bo.setLocation(location);
        return bo;
    }

    /**
     * 装载物料信息BO
     *
     * @param document
     * @return
     * @throws Exception
     */
    private CtDocumentInfoBo loadDocumentInfoBo(WTDocument document) throws Exception {
        if (document == null) return null;

        CtDocumentInfoBo bo = new CtDocumentInfoBo();
        bo.setDocNumber(document.getNumber());
        bo.setDocName(document.getName());
        bo.setDocVersion(CtVersionUtil.getVersionInfo(document));
        bo.setDocState(CtWTObjectUtil.getStateDisplay(document));
        bo.setModified(document.getModifierFullName());
        bo.setModifyTime(document.getModifyTimestamp());
        bo.setContext(document.getContainerName());
        bo.setLocation(getFolderPath(document));

        return bo;
    }

    /**
     * 获取目录路径
     *
     * @param cabinetBased
     * @return
     */
    private String getFolderPath(CabinetBased cabinetBased) {
        if (cabinetBased == null) return null;
        String folderPath = cabinetBased.getLocation();
        Persistable persistable = cabinetBased.getCabinetReference().getObject();
        if (persistable instanceof Cabinet) {
            Cabinet cabinet = (Cabinet) persistable;
            String prefix = "/" + cabinet.getName();
            int index = folderPath.indexOf(prefix);
            if (index != -1 && index == 0) {
                folderPath = "/" + cabinet.getContainerDisplayName() + folderPath.substring(prefix.length());
            }
        }
        return folderPath;
    }

    /**
     * 装载下阶物料BO
     *
     * @param parentPart
     * @return
     * @throws Exception
     */
    private List<CtPartUsageBo> loadPartUsageBos(WTPart parentPart, HashSet<String> noLoadPartNumSet) throws Exception {
        // 获取下阶物料
        QueryResult queryResult = WTPartHelper.service.getUsesWTPartMasters(parentPart);
        List<CtPartUsageBo> boList = new ArrayList<>(queryResult.size());
        CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
        while (queryResult.hasMoreElements()) {
            WTPartUsageLink usageLink = (WTPartUsageLink) queryResult.nextElement();
            WTPartMaster childPartMaster = usageLink.getUses();
            if (noLoadPartNumSet != null && noLoadPartNumSet.contains(childPartMaster.getNumber())) {
                continue;
            }
            CtPartUsageBo bo = new CtPartUsageBo();
            bo.setPartNumber(childPartMaster.getNumber());
            Quantity quantity = usageLink.getQuantity();
            if (quantity != null) {
                bo.setQuantity(String.valueOf(quantity.getAmount()));
            }
            // 工位
            bo.setPositionNo(ctAdToolLogic.getUsesOccurrences(usageLink));
            // 物料描述
            bo.setDescription(childPartMaster.getName());
            // BOM备注
            IBAUtil ibaUtil = new IBAUtil(usageLink);
            bo.setBomRemark(ibaUtil.getIBAValue("ct_BOMNotes"));

            WTPart subPart = CtPartUtil.getPartByNumber(childPartMaster.getNumber(), CtConstant.VIEW_DESIGN);
            // 器件库安装方式
            String deviceInstallationMethod = "";
            if (subPart != null) {
                IBAUtil subPartIbaUtil = new IBAUtil(subPart);
                // 物料是否贴片半成品
                deviceInstallationMethod = subPartIbaUtil.getIBAValue("ct_DeviceInstallationMethod");
                bo.setPthOrSmd(deviceInstallationMethod);
            }
            boList.add(bo);

            if ("贴片半成品".equals(deviceInstallationMethod)) {
                // 再收集下一层BOM数据
                WTPart childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster);
                List<CtPartUsageBo> childBoList = loadPartUsageBos(childPart);
                if (CollectionUtils.isNotEmpty(childBoList)) {
                    boList.addAll(childBoList);
                }
            }
        }
        return boList;
    }

    /**
     * 装载下阶物料BO
     *
     * @param parentPart
     * @return
     * @throws Exception
     */
    private List<CtPartUsageBo> loadPartUsageBos(WTPart parentPart) throws Exception {
        return loadPartUsageBos(parentPart, null);
    }
}
