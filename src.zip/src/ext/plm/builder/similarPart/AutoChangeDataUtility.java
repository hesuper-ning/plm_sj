package ext.plm.builder.similarPart;
import ext.plm.util.CtPartUtil;
import wt.fc.ReferenceFactory;
import wt.httpgw.URLFactory;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.Label;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import java.util.Map;
/**
 * @Author: lcd
 * @Date: 2021/8/28 17:53
 * @Description:
 */
public class AutoChangeDataUtility extends DefaultDataUtility {
    @SuppressWarnings("unchecked")
    @Override
    public Object getDataValue(String columnName, Object object, ModelContext modelContext)throws WTException {
//        Map<String, Object> map=(Map<String, Object>)object;
		/*if("changeVersion".equals(columnName)){//换号版本
			StringBuffer resultBuffer=new StringBuffer((String)map.get("sorce_maxversion"));
			resultBuffer.append("."+map.get("sorce_minversion"));
			resultBuffer.append("("+map.get("sorce_viewname")+")");
			Label label=new Label("");
			label.setId(columnName);
			label.setColumnName(AttributeDataUtilityHelper.getColumnName(columnName, object, modelContext));
			label.setValue(resultBuffer.toString());
			return label;
		}else */if("number".equals(columnName)){//编号
            String defaultValue=AttributeDataUtilityHelper.getValue(modelContext, columnName);
//            String number=(WTPart)Object;
            String objInfoUrl=new URLFactory().getBaseHREF()+"app/#ptc1/tcomp/infoPage?oid=";
            try {
                objInfoUrl+=new ReferenceFactory().getReferenceString((WTPart)object);
            } catch (Exception e) {
                e.printStackTrace();
            }
            UrlDisplayComponent urlDisplayComponent = new UrlDisplayComponent(defaultValue, defaultValue, objInfoUrl);
           urlDisplayComponent.setTarget("_blank");
            return urlDisplayComponent;
        }
        return super.getDataValue(columnName, object, modelContext);
    }
}
