package ext.plm.builder.similarPart;
import com.ptc.core.components.util.BeanHelper;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.ICON;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.INFO_ACTION;

import com.ptc.netmarkets.util.beans.NmHelperBean;
import org.springframework.stereotype.Component;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;

/**
 * @Author: lcd
 * @Date: 2021/8/27 10:16
 * @Description:
 */
@ComponentBuilder("CtSimilarPartBuilder")
@Component
public class CtSimilarPartBuilder extends AbstractComponentBuilder {

    @Override
    public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1)
            throws Exception {
        CtSilimilarPartQuery query = new CtSilimilarPartQuery();
        NmHelperBean bean = ((JcaComponentParams) arg1).getHelperBean();

        return query.getSimilarPartList(bean);
    }

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig table = factory.newTableConfig();
        table.setLabel("相似物料列表");
        table.setType("wt.part.WTPart");
        table.addComponent(factory.newColumnConfig(ICON, false));
        table.addComponent(factory.newColumnConfig(INFO_ACTION, false));
        table.addComponent(factory.newColumnConfig("name", "名称", true));
        ColumnConfig col = factory.newColumnConfig("number", "编号", true);
        col.setDataUtilityId("AutoChangeDataUtility");
        table.addComponent(col);
        table.addComponent(factory.newColumnConfig("creator", "创建者", true));
        table.addComponent(factory.newColumnConfig("state", "状态", true));
        table.addComponent(factory.newColumnConfig("containerName", "上下文", true));
        table.addComponent(factory.newColumnConfig("IBA|ct_itemDescription", "研发描述", true));
        table.setSelectable(false);
        return table;
    }
}

