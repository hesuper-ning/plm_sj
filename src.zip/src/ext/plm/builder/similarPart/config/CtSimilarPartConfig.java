package ext.plm.builder.similarPart.config;

import ext.plm.util.CtDocUtil;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.doc.WTDocument;
import wt.session.SessionServerHelper;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
/**
 * @Author: lcd
 * @Date: 2021/8/27 10:20
 * @Description:
 */
public class CtSimilarPartConfig {

    public static HashMap<String, List<String>> map = new HashMap<>();
    public static HashMap<String, List<String>> largeCategoryMap = new HashMap<>();
    public static String version = "";

    static {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            initSimilarPartConfig();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    public static void initSimilarPartConfig() throws Exception {
        InputStream is = null;
        try {
            WTDocument doc = CtDocUtil.getDocumentByNumber("SIMILARPARTCONFIG");

            if(CtFormatUtil.hasContent(version)&&version.equals(doc.getVersionIdentifier().getValue() + "." + doc.getIterationIdentifier().getValue())){
                return;
            }

            version = doc.getVersionIdentifier().getValue() + "." + doc.getIterationIdentifier().getValue();

            map = new HashMap<>();
            largeCategoryMap = new HashMap<>();

            is = CtDocUtil.getInputStreamByDoc(doc);
            XSSFWorkbook workbook = new XSSFWorkbook(is);
            Sheet sheet = workbook.getSheetAt(0);
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                String clfName = CtExcelReadUtil.getCellFormatValue(row.getCell(1), row, 1);
                if(!CtFormatUtil.hasContent(clfName)) {
                    break;
                }
                String atts = CtExcelReadUtil.getCellFormatValue(row.getCell(2), row, 2);
                List<String> attList = Arrays.asList(atts.split(","));
                map.put(clfName, attList);
                //根据大类将小分类进行分类
                if (row.getCell(0) != null && row.getCell(1) != null) {
                    String category = row.getCell(0).getStringCellValue();
                    String item = row.getCell(1).getStringCellValue();
                    // 如果分类已存在于 Map 中，则直接将元素添加到列表中，否则创建新的列表
                    if (largeCategoryMap.containsKey(category)) {
                        largeCategoryMap.get(category).add(item);
                    } else {
                        List<String> itemList = new ArrayList<>();
                        itemList.add(item);
                        largeCategoryMap.put(category, itemList);
                    }
                }



            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                is.close();
            }
        }
    }

}
