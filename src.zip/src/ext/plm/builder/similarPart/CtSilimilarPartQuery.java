package ext.plm.builder.similarPart;
import com.amazonaws.services.dynamodbv2.xspec.S;
import com.ptc.core.command.common.bean.repository.PageMode;
import com.ptc.core.command.common.bean.repository.ResultContainer;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.DisplayOperationIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.WildcardSet;
import com.ptc.core.meta.container.common.AttributeContainerSet;
import com.ptc.core.meta.container.common.AttributeContainerSpec;
import com.ptc.core.meta.container.common.CompositeAttributeContainerSet;
import com.ptc.core.query.command.common.BasicQueryCommand;
import com.ptc.core.query.common.CriteriaHelper;
import com.ptc.netmarkets.util.beans.NmHelperBean;
//import ext.plm.builder.similarPart.config.CtSimilarPartConfig;
import ext.plm.builder.similarPart.config.CtSimilarPartConfig;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtVersionUtil;
import ext.plm.util.CtWTObjectUtil;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.method.MethodContext;
import wt.part.WTPart;
import wt.pom.WTConnection;
import wt.type.ClientTypedUtility;
import com.alibaba.fastjson.JSON;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

/**
 * @Author: lcd
 * @Date: 2021/8/27 10:19
 * @Description:
 */
public class CtSilimilarPartQuery {

    public List<WTPart> getSimilarPartList(NmHelperBean bean) throws Exception {
        List<WTPart> partList = new ArrayList<>();
        Enumeration<String> em = bean.getRequest().getParameterNames();
        String partOid = bean.getRequest().getParameter("oid");
        Persistable objectByOid = CtWTObjectUtil.getObjectByOid(partOid);
        WTPart linkPart=null;
        if(objectByOid instanceof WTPart){
            linkPart=(WTPart)objectByOid;
        }

        HashMap<String, String> map = new HashMap<>();
        String clfName = bean.getNmCommandBean().getTextParameter("null!~objectHandle~partHandle~!_col_fhsj_Classification");
        HashMap textMap = bean.getNmCommandBean().getText();
        for(Object key : textMap.keySet()) {
            if(key.toString().contains("IBA") && key.toString().contains("fhsj_Classification")) {
                clfName = textMap.get(key).toString();
            }
        }

        CtSimilarPartConfig.initSimilarPartConfig();
        if (CtSimilarPartConfig.map.containsKey(clfName)) {
            List<String> attList = CtSimilarPartConfig.map.get(clfName);
            if(attList.size() == 0) {
                return partList;
            }
            while (em.hasMoreElements()) {
                String key = em.nextElement();
                String value = bean.getRequest().getParameter(key);
                for(String att : attList) {
                    if (key.contains("IBA") && key.contains(att) && !key.endsWith("old") && CtFormatUtil.hasContent(value)) {
                        map.put(att, value);
                    }
                }
            }

            if (map.size() != 0) {

                HashMap<String, List<String>> categoryMap = CtSimilarPartConfig.largeCategoryMap;
                System.out.println(">>>jsonToMap"+ JSON.toJSON(categoryMap));
                List<String> classificationList = new ArrayList<>();
                // 通过遍历 HashMap 的值集合，逐个判断 List<String> 是否包含目标字符串
                for (List<String> itemList : categoryMap.values()) {
                    if (itemList.contains(clfName)) {
                        classificationList = itemList;
                    }
                }

                MethodContext methodContext = MethodContext.getContext();
                WTConnection connection = null;
                PreparedStatement statement = null;
                ResultSet rs = null;
                try {
                    int i = 1;
                    if(map.size()!=0){
                        i=map.size()+1;
                    }
                    //根据大类查询小分类相似物料
                    String partNumbers = subclassSqlList(classificationList);
                    connection = (WTConnection) methodContext.getConnection();
                    StringBuilder sql = new StringBuilder();
                    sql.append("SELECT u.IDA2A2")
                            .append(" FROM (")
                            .append("     SELECT x.IDA2A2, count(1) cou")
                            .append("     FROM (")
                            .append("         SELECT t.IDA2A2, t.IDA3VIEW, w.WTPARTNUMBER, w.name, s.name, s.DISPLAYNAME, s2.VALUE2")
                            .append("         FROM WTPARTMASTER w, wtpart t, STRINGDEFINITION s, STRINGVALUE s2, WTVIEW w2")
                            .append("         WHERE 1=1")
                            .append("         AND w.IDA2A2 = t.IDA3MASTERREFERENCE")
                            .append("         AND s.IDA2A2 = s2.IDA3A6")
                            .append("         AND s2.IDA3A4 = t.IDA2A2")
                            .append("         AND t.LATESTITERATIONINFO = 1")
                            .append("         AND t.IDA3VIEW = w2.IDA2A2")
                            .append("         AND w2.NAME = 'Design'")
                            .append("         AND t.VERSIONSORTIDA2VERSIONINFO = (SELECT max(w4.VERSIONSORTIDA2VERSIONINFO) FROM wcadmin.WTPART w4 WHERE w4.IDA3MASTERREFERENCE = t.IDA3MASTERREFERENCE" +
                                    "             AND w4.LATESTITERATIONINFO=1 AND w4.IDA3VIEW=t.IDA3VIEW)")
                            .append("         AND (")
                            .append("             (s.name = 'fhsj_Classification' AND s2.VALUE2 IN ("+partNumbers+"))");


                    for (String key : map.keySet()) {
                        sql.append("             OR (s.name = '"+key+"' AND s2.VALUE2 LIKE '%"+map.get(key)+"%')");
                    }

                    sql.append("         )");
                    sql.append("     ) x");
                    sql.append("     GROUP BY x.IDA2A2");
                    sql.append(" ) u");
                    sql.append(" WHERE u.cou = "+i+"");
                    statement = connection.prepareStatement(sql.toString());
                    rs = statement.executeQuery();
                    while (rs.next()) {
                        String oid = rs.getString(1);
                        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPart:"+oid);
                        if(part==null){
                            continue;
                        }
                        if(CtFormatUtil.hasContent(linkPart)&&linkPart.getNumber().equals(part.getNumber())){
                            continue;
                        }
                        if (!CtVersionUtil.isLatest(part)) {
                            continue;
                        }
                        partList.add(part);
                    }
                } catch (Exception wte) {
                    wte.printStackTrace();
                } finally {
                    try {
                        if (rs != null) {
                            rs.close();
                        }
                        if (statement != null) {
                            statement.close();
                        }
                        if (connection != null && connection.isActive()){
                            connection.release();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return partList;
    }


    /**
     * 处理编码成sql格式
     * @param partNumberList
     * @return
     * @throws Exception
     */
    public static String subclassSqlList(List<String> partNumberList) throws Exception {
        if(null == partNumberList){
            return "";
        }
        StringBuilder partNumberBuilder = new StringBuilder();
        Iterator<String> it = partNumberList.iterator();
        for(String partNumber : partNumberList){
            partNumberBuilder.append("'").append(partNumber).append("',");
        }
        String partNumbers = partNumberBuilder.toString();
        if(partNumbers.endsWith(",")){
            partNumbers = partNumbers.substring(0,partNumbers.lastIndexOf(","));
        }
        return partNumbers;
    }





}