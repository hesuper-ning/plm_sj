package ext.plm.builder.doc;
import com.ptc.mvc.components.*;
import wt.util.WTException;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.ICON;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.INFO_ACTION;
/**
 * @Author: lcd
 * @Date: 2021/11/22 19:19
 * @Description:
 */

@ComponentBuilder("relatedReviewTable")
public class CtRelatedReviewTable extends AbstractComponentBuilder {

    @Override
    public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1)
            throws Exception {
        CtRelatedReviewQuery query = new CtRelatedReviewQuery();
        Object localObject = arg1.getContextObject();
        return query.getRelatedReview(localObject);
    }

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams arg0)
            throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig table = factory.newTableConfig();
        table.setLabel("关联的审阅");
        table.setType("wt.change2.WTChangeReview");
        table.addComponent(factory.newColumnConfig("SCA|displayType", "对象类型", true));
        table.addComponent(factory.newColumnConfig(ICON, false));
        ColumnConfig col = factory.newColumnConfig("name", "名称", true);
        col.setInfoPageLink(true);
        col.setAutoSize(true);
        table.addComponent(col);
        table.addComponent(factory.newColumnConfig(INFO_ACTION, false));
        table.addComponent(factory.newColumnConfig("number", "编号", true));
        table.addComponent(factory.newColumnConfig("creator", "创建者", true));
        table.addComponent(factory.newColumnConfig("state", "状态", true));
        table.addComponent(factory.newColumnConfig("containerName", "上下文", true));
        table.addComponent(factory.newColumnConfig("theCategory", "类别", true));
        /*table.addComponent(factory.newColumnConfig("IBA|Ct_projectNo", "项目编号", false));
        table.addComponent(factory.newColumnConfig("IBA|Ct_projectName", "项目名称", false));
        table.addComponent(factory.newColumnConfig("IBA|Ct_department", "申请部门", false));
        table.addComponent(factory.newColumnConfig("description", "评审说明", true));*/

        table.setSelectable(true);
        return table;

    }
}