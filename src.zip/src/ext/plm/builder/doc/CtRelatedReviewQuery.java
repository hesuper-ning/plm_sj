package ext.plm.builder.doc;
import wt.change2.ChangeReviewItemLink;
import wt.change2.WTChangeReview;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.vc.VersionControlHelper;

import java.util.ArrayList;
import java.util.List;
/**
 * @Author: lcd
 * @Date: 2021/11/22 19:18
 * @Description:
 */

public class CtRelatedReviewQuery {

    public List<WTChangeReview> getRelatedReview(Object obj) throws Exception {
        List<WTChangeReview> reviewList = new ArrayList<>();
        RevisionControlled rc = (RevisionControlled)obj;
        QueryResult qr = VersionControlHelper.service.allIterationsOf(rc.getMaster());
        while (qr.hasMoreElements()) {
            Persistable p = (Persistable)qr.nextElement();
            QuerySpec qs = new QuerySpec(ChangeReviewItemLink.class);
            SearchCondition sc = new SearchCondition(ChangeReviewItemLink.class
                    , "roleBObjectRef.key.id"
                    , SearchCondition.EQUAL, p.getPersistInfo().getObjectIdentifier().getId());
            qs.appendWhere(sc);
            QueryResult linkQr = PersistenceHelper.manager.find(qs);
            while (linkQr.hasMoreElements()) {
                ChangeReviewItemLink link = (ChangeReviewItemLink)linkQr.nextElement();
                WTChangeReview review = (WTChangeReview)link.getRoleAObject();
                reviewList.add(review);
            }
        }
        return reviewList;
    }

}