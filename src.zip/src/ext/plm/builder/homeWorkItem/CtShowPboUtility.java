package ext.plm.builder.homeWorkItem;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtWTObjectUtil;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.change2.WTChangeReview;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionServerHelper;
import wt.type.Typed;
import wt.util.WTException;
import wt.workflow.engine.WfAssignmentEventAudit;
import wt.workflow.engine.WfProcess;

import java.util.ArrayList;
import java.util.Locale;

public class CtShowPboUtility extends AbstractDataUtility {

    public CtShowPboUtility() {

    }

    @Override
    public Object getDataValue(String parameter, Object obj, ModelContext modelContext) throws WTException {
        TextDisplayComponent textdisplaycomponent = new TextDisplayComponent("CtShowPboUtility");
        if (obj instanceof WfAssignmentEventAudit) {
            boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
            try {
                WfAssignmentEventAudit assEvent = (WfAssignmentEventAudit) obj;
                ArrayList<GuiComponent> componentList = new ArrayList<GuiComponent>();
                if(parameter.equals("CtShowPboUtility")){
                    textdisplaycomponent.setValue(getData(assEvent));
                }
                else if(parameter.equals("CtProcessState")){
                    textdisplaycomponent.setValue(getProcessState(assEvent));
                }
                textdisplaycomponent.setCheckXSS(false);
                componentList.add(textdisplaycomponent);
                GUIComponentArray guiComArr = new GUIComponentArray(componentList);
                return guiComArr;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                SessionServerHelper.manager.setAccessEnforced(enforce);
            }
        }
        return textdisplaycomponent;
    }


    public String getData(WfAssignmentEventAudit assEvent) throws Exception {

        long processKey = assEvent.getProcessKey();
        QuerySpec qs = new QuerySpec(WfProcess.class);
        SearchCondition sc = new SearchCondition(WfProcess.class
                , WfProcess.KEY
                , SearchCondition.EQUAL, processKey);
        qs.appendWhere(sc);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        if(qr.hasMoreElements()){
            Object o = qr.nextElement();
            WfProcess process = (WfProcess) o;
            ReferenceFactory rf = new ReferenceFactory();
            Object pbo = process.getBusinessObjectReference(rf).getObject();
            String url = CtCommonUtil.getURL((Persistable) pbo);
            String typeViewName = CtWTObjectUtil.getTypeViewName((Typed) pbo);
            String name = "";
            String number = "";
            if (pbo instanceof WTPart) {
                name =  ((WTPart) pbo).getName();
                number =  ((WTPart) pbo).getNumber();
            } else if (pbo instanceof WTDocument) {
                name = ((WTDocument) pbo).getName();
                number =  ((WTDocument) pbo).getNumber();
            } else if (pbo instanceof PromotionNotice) {
                name = ((PromotionNotice) pbo).getName();
                number =  ((PromotionNotice) pbo).getNumber();
            } else if (pbo instanceof WTChangeRequest2) {
                name = ((WTChangeRequest2) pbo).getName();
                number =  ((WTChangeRequest2) pbo).getNumber();
            }else if (pbo instanceof WTChangeOrder2) {
                name = ((WTChangeOrder2) pbo).getName();
                number =  ((WTChangeOrder2) pbo).getNumber();
            } else if (pbo instanceof WTChangeActivity2) {
                name = ((WTChangeActivity2) pbo).getName();
                number =  ((WTChangeActivity2) pbo).getNumber();
            }else if (pbo instanceof WTChangeReview) {
                name = ((WTChangeReview) pbo).getName();
                number =  ((WTChangeReview) pbo).getNumber();
            }
            return "<a href='"+url+"' >"+typeViewName + " - " + number + "," + name+"</a>";
        }
        return "";
    }

    public String getProcessState(WfAssignmentEventAudit assEvent) throws Exception {

        long processKey = assEvent.getProcessKey();
        QuerySpec qs = new QuerySpec(WfProcess.class);
        SearchCondition sc = new SearchCondition(WfProcess.class
                , WfProcess.KEY
                , SearchCondition.EQUAL, processKey);
        qs.appendWhere(sc);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        if(qr.hasMoreElements()){
            Object o = qr.nextElement();
            WfProcess process = (WfProcess) o;
            ReferenceFactory rf = new ReferenceFactory();
            String processState = process.getState().getLocalizedMessage(Locale.CHINA);
            return processState;
        }
        return "";
    }
}
