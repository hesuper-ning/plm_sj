package ext.plm.builder.homeWorkItem;

import com.ptc.jca.mvc.components.AbstractJcaComponentConfig;
import com.ptc.jca.mvc.components.JcaTableConfig;
import com.ptc.mvc.components.*;
import com.ptc.mvc.util.ClientMessageSource;
import org.springframework.stereotype.Component;
import wt.change2.WTChangeRequest2;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.*;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.workflow.engine.WfAssignmentEventAudit;
import wt.workflow.engine.WfVotingEventAudit;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import java.util.ArrayList;
import java.util.List;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.ICON;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.INFO_ACTION;


@ComponentBuilder("CtAssignmentBuilder")
@Component
public class CtAssignmentBuilder extends AbstractComponentBuilder {

    @Override
    public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1)
            throws Exception {
        long nowUserId = SessionHelper.getPrincipal().getPersistInfo().getObjectIdentifier().getId();
        QuerySpec queryspec = new QuerySpec();
        int a = queryspec.appendClassList(WfAssignmentEventAudit.class, true);
        String WfAssignmentEventAuditAt = queryspec.getFromClause().getAliasAt(a);
        TableColumn a1 = new TableColumn(WfAssignmentEventAuditAt,"IDA3A6");
        TableColumn a2 = new TableColumn(WfAssignmentEventAuditAt,"IDA3B6");
        CompositeWhereExpression andExpression = new CompositeWhereExpression(LogicalOperator.AND);
        andExpression.append(new SearchCondition(a1, "=", new ConstantExpression(nowUserId)));
        andExpression.append(new SearchCondition(a1, "<>", a2));
        queryspec.appendWhere(andExpression, null);
        ClassAttribute cls = new ClassAttribute(WfAssignmentEventAudit.class, WfAssignmentEventAudit.TIMESTAMP);
        queryspec.appendOrderBy(new OrderBy(cls,true));
        QueryResult qs = PersistenceHelper.manager.find(queryspec);
        List<WfAssignmentEventAudit> assignmentEventAuditList = new ArrayList<>();
        System.out.println(qs.size());
        while(qs.hasMoreElements())
        {
            Object[] o = (Object[]) qs.nextElement();
            WfAssignmentEventAudit assignmentEventAudit = (WfAssignmentEventAudit)o[0];
            assignmentEventAuditList.add(assignmentEventAudit);
        }
        return assignmentEventAuditList;
    }

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
        ClientMessageSource messageWorkFlowSource = this.getMessageSource("com.ptc.netmarkets.workflow.workflowResource");
        ComponentConfigFactory var2 = this.getComponentConfigFactory();
        JcaTableConfig var3 = (JcaTableConfig)var2.newTableConfig();
        ((AbstractJcaComponentConfig)var3).setDescriptorProperty("variableRowHeight", true);
        var3.setLabel("我分配给别人的任务");
        var3.setHelpContext("ReassignmentHistoryHelp");
        var3.setShowCount(true);
        var3.setId("taskHistoryTableId");
        ColumnConfig var4 = var2.newColumnConfig("workIcon", true);
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("activityName", true);
        var4.setLabel("任务名称");
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("CtShowPboUtility", "主题", true);
        var4.setDataUtilityId("CtShowPboUtility");
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("originalAssignee", true);
        var4.setLabel(messageWorkFlowSource.getMessage("72"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("newAssignee", true);
        var4.setLabel(messageWorkFlowSource.getMessage("73"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("actionPerformedBy", true);
        var4.setLabel(messageWorkFlowSource.getMessage("88"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("reasonForAction", true);
        var4.setLabel(messageWorkFlowSource.getMessage("89"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("actionPerformedOn", true);
        var4.setLabel(messageWorkFlowSource.getMessage("90"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("CtProcessState", "流程状态", true);
        var4.setDataUtilityId("CtShowPboUtility");
        var3.addComponent(var4);
        return var3;
    }



}