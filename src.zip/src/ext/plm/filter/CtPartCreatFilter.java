package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import com.ptc.netmarkets.util.misc.NmActionServiceHelper;
import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import wt.admin.AdminDomainRef;
import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.folder.Cabinet;
import wt.inf.container.WTContainer;
import wt.inf.library.WTLibrary;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.util.WTException;

import java.util.Locale;

/**
 * @Author: lcd
 * @Date: 2022/4/18 16:46
 * @Description:
 */
public class CtPartCreatFilter  extends DefaultSimpleValidationFilter {
    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.ENABLED;

        String var6 = null;
        boolean isAdmin=false;
        try {
             isAdmin = CtUserUtil.isInGroup(  CtUserUtil.getCurrentUser(), "Administrators");
        } catch (Exception e) {
            e.printStackTrace();
        }
        Persistable obj = uivalidationcriteria.getContextObject().getObject();
        if(obj instanceof Cabinet){
            Cabinet cabinet = (Cabinet) obj;
            WTContainer container = cabinet.getContainer();
            if(container instanceof PDMLinkProduct){
                result=UIValidationStatus.HIDDEN;
            }
        }
        //管理员组下成员不过滤
        if(isAdmin){
            result =  UIValidationStatus.ENABLED;
        }
        return result;
    }
}
