package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.plm.adminTool.configCenter.manager.CtConfigCenterManager;
import ext.plm.adminTool.configCenter.manager.CtPropertyConfig;
import wt.fc.Persistable;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Arrays;
import java.util.List;

/**
 * @Author: lzp
 * @Date: 2024/8/20
 * @Description:
 */
public class CtWorkReportQueueFilter extends DefaultSimpleValidationFilter {
    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.HIDDEN;
        //result = UIValidationStatus.ENABLED;
        try {
            Persistable obj = uivalidationcriteria.getContextObject().getObject();
            WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
            CtPropertyConfig workItemFormConfig = CtConfigCenterManager.getInstance().loadProperty("workReportQueue");
            String configurationInformation = workItemFormConfig.getValue("报工管理员");
            System.out.println("configurationInformation"+configurationInformation);
            List<String> list =  Arrays.asList(configurationInformation.split(","));
            if(list.contains(currentUser.getName())){
                result = UIValidationStatus.ENABLED;
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
