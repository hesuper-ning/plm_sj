package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.plm.common.CtConstant;
import wt.fc.Persistable;
import wt.part.WTPart;

public class CtConvertBomFilter extends DefaultSimpleValidationFilter {
    @Override
    public UIValidationStatus preValidateAction(UIValidationKey uiValidationKey, UIValidationCriteria uiValidationCriteria) {
        UIValidationStatus uiValidationStatus = UIValidationStatus.HIDDEN;
        Persistable persistable = uiValidationCriteria.getContextObject().getObject();
        try{
            if (persistable instanceof WTPart) {
                WTPart part = (WTPart) persistable;

                //只有设计视图才显示
                if(!CtConstant.VIEW_DESIGN.equals(part.getViewName())){
                    return uiValidationStatus;
                }

                //没有M视图才显示
//                WTPart mPart = CtPartUtil.getPartByNumber(part.getNumber(), CtConstant.VIEW_MANUFACTURING);
//                if(null != mPart){
//                    return uiValidationStatus;
//                }

                // 都符合则开启Action
                uiValidationStatus = UIValidationStatus.ENABLED;
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
        return uiValidationStatus;
    }
}
