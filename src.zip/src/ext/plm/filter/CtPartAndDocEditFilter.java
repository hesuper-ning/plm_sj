package ext.plm.filter;

import com.ptc.core.ui.validation.*;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.part.WTPart;

import java.util.Locale;

/**
 * @Author: lcd
 * @Date: 2021/12/20 10:50
 * @Description:
 */
public class CtPartAndDocEditFilter  extends DefaultSimpleValidationFilter {

    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.ENABLED;
        try {
            Persistable obj = uivalidationcriteria.getContextObject().getObject();
            if(obj instanceof WTPart) {
                WTPart part = (WTPart)obj;
                String partNumber = part.getNumber();
                String state = CtWTObjectUtil.getStateDisplay(part, Locale.CHINA);

                String partType = CtWTObjectUtil.getTypeIdentifier(part);


                if("已生效".equals(state)) {
                    if (partType.contains("ct_CBB")) {
                        return UIValidationStatus.ENABLED;
                    }
                    result = UIValidationStatus.HIDDEN;
                }
                if("试产".equals(state)) {
                    result = UIValidationStatus.HIDDEN;
                }
                if("量产".equals(state)) {
                    result = UIValidationStatus.HIDDEN;
                }
                //非管理员，不是打样物料的话，这两个状态要隐藏修订按钮
                boolean isAdmin = CtUserUtil.isInGroup(CtUserUtil.getCurrentUser(), "Administrators");
                if(!isAdmin){
                    if("认证中".equals(state) || "样机".equals(state)){
                        if(!partNumber.endsWith("D01")){
                            result = UIValidationStatus.HIDDEN;
                        }
                    }
                }
            }
            if(obj instanceof WTDocument) {
                WTDocument doc = (WTDocument)obj;
                String state = CtWTObjectUtil.getStateDisplay(doc, Locale.CHINA);
                IBAUtil ibaUtil = new IBAUtil(doc);
                String ct_wdlx = ibaUtil.getIBAValue("ct_wdlx");
                if(CtFormatUtil.hasContent(ct_wdlx)&&"T".equals(ct_wdlx)){
                    result = UIValidationStatus.HIDDEN;
                }

            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
