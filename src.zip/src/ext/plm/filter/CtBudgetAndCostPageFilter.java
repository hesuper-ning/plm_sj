package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import com.ptc.projectmanagement.plan.Plan;
import ext.plm.adminTool.configCenter.manager.CtConfigCenterManager;
import ext.plm.adminTool.configCenter.manager.CtPropertyConfig;
import ext.plm.util.CtProjectUtil;
import ext.plm.util.CtUserUtil;
import wt.fc.Persistable;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.session.SessionHelper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

/**
 * @Author: heqingbo
 * @Date: 2024/12/09
 * @Description:
 */

public class CtBudgetAndCostPageFilter extends DefaultSimpleValidationFilter {

    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.HIDDEN;
        try {
            Persistable persistable = uivalidationcriteria.getContextObject().getObject();
            if (persistable instanceof Plan) {
                Plan plan = (Plan) persistable;
                Project2 project = CtProjectUtil.getProject(plan);
                WTPrincipal p = SessionHelper.manager.getPrincipal();
                String currentUserName = p.getName();
                boolean isAdmin = CtUserUtil.isInGroup(p, "Administrators");
                if(isAdmin || ("youliang.xu").equals(currentUserName)){
                    return UIValidationStatus.ENABLED;
                }

                //从配置中取得角色
                CtPropertyConfig roleConfig = CtConfigCenterManager.getInstance().loadProperty("budgetAndCostReportViewRoleConfig");
                Set<String> roleSet = roleConfig.getKeySet();
                Iterator<String> it = roleSet.iterator();
                while(it.hasNext()){
                    String roleInnerName = it.next();
                    boolean flag = isProjectRoleUser(project, roleInnerName, currentUserName);
                    if(flag){
                        return UIValidationStatus.ENABLED;
                    }
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 获取产品下的用户
     */
    public static boolean isProjectRoleUser(Project2 project, String roleInnerName, String userName) throws Exception {
        if (project != null) {
            ContainerTeam conTeamPdm = ContainerTeamHelper.service.getContainerTeam(project);
            ArrayList enumTeamPdm = conTeamPdm.getAllPrincipalsForTarget(Role.toRole(roleInnerName));
            for (Object object : enumTeamPdm) {
                WTPrincipalReference principal = (WTPrincipalReference) object;
                if(userName.equals(principal.getName())){
                    return true;
                }
            }
        }
        return false;
    }
}

