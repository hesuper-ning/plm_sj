package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.plm.util.CtUserUtil;

/**
 * @Author: heqingbo
 * @Date: 2023/9/22
 * @Description:
 */

public class CtExportPartInfoFilter extends DefaultUIComponentValidator {
    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.HIDDEN;
        try {
            boolean isAdmin = CtUserUtil.isInGroup(  CtUserUtil.getCurrentUser(), "Administrators");
            boolean inGroup = CtUserUtil.isInGroup(  CtUserUtil.getCurrentUser(), "物料属性及关联文档导出用户组");
            //管理员组/物料属性及关联文档导出用户组，下成员不过滤
            if(isAdmin || inGroup){
                result =  UIValidationStatus.ENABLED;
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}