package ext.plm.filter;

import com.ptc.core.ui.validation.*;
import ext.plm.part.CtPartLogic;
import ext.plm.util.CtVersionUtil;
import ext.plm.util.CtWTObjectUtil;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.type.TypedUtilityServiceHelper;

import java.util.Locale;

public class CtProductFilter extends DefaultUIComponentValidator {
    @Override
    public UIValidationResultSet performFullPreValidation(UIValidationKey validationKey,
                                                          UIValidationCriteria validationCriteria, Locale locale) {
        UIValidationResultSet resultSet = new UIValidationResultSet();
        try {
            Persistable obj = validationCriteria.getContextObject().getObject();
            if(obj instanceof WTPart) {
                WTPart part = (WTPart)obj;
                String partNumber = part.getNumber();
                String partType = CtWTObjectUtil.getTypeIdentifier(part);
                //只有具有扩展位的成品才具有新建定制化成品和新建非满载成品的菜单选项
                if(partType.contains("ct_fhsjfinishedproduct") && partNumber.length() > 6) {
                    resultSet.addResult(new UIValidationResult(validationKey,
                            UIValidationStatus.ENABLED));

                } else {
                    resultSet.addResult(new UIValidationResult(validationKey,
                            UIValidationStatus.HIDDEN));
                }
                return resultSet;

            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return resultSet;
    }
}