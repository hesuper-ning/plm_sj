package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;

import ext.plm.util.CtUserUtil;

public class CtDsRequiInfoFilter extends DefaultUIComponentValidator {
	@Override
	public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria) {
		UIValidationStatus result = UIValidationStatus.HIDDEN;
		try {
			boolean isAdmin = CtUserUtil.isInGroup(CtUserUtil.getCurrentUser(), "Administrators");
			boolean inGroup = CtUserUtil.isInGroup(CtUserUtil.getCurrentUser(), "DS需求报表查询组");
			System.out.println("inGroup---->"+inGroup);
			// 管理员组/DS需求报表查询组，下成员不过滤
			if (isAdmin || inGroup) {
//			if (inGroup) {
				result = UIValidationStatus.ENABLED;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
