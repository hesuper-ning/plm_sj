package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;

import ext.plm.common.CtConstant;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.fc.Persistable;
import wt.part.WTPart;

import java.util.Locale;

/**
 * @Author: lzp
 * @Date: 2023/12/14
 * @Description:
 */
public class CtPartReHistoryFilter extends DefaultSimpleValidationFilter {
    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.HIDDEN;
        try {
            Persistable obj = uivalidationcriteria.getContextObject().getObject();
            if(obj instanceof WTPart) {
                WTPart part = (WTPart)obj;
//                String state = CtWTObjectUtil.getStateDisplay(part, Locale.CHINA);
                String partType = CtWTObjectUtil.getTypeIdentifier(part);
                System.out.println("partType-------->" + partType);
                System.out.println(partType.contains(CtEcConstant.Ct_PartType_HalfEndPart));
                if(partType.contains(CtEcConstant.Ct_PartType_HalfEndPart)){
                	result = UIValidationStatus.ENABLED;
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        System.out.println("result------>" + result);
        return result;
    }
}