package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.plm.part.partEcInfo.config.CtPartEcInfoProperties;
import ext.plm.util.CtWTObjectUtil;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.type.Typed;

/**
 * 隐藏按钮：xx对象的xx状态
 */
public class CtHiddenCtPartEcInfoForDocTypeFilter extends DefaultSimpleValidationFilter {

    public CtHiddenCtPartEcInfoForDocTypeFilter() {
    }


    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria) {
        UIValidationStatus uivalidationstatus = UIValidationStatus.ENABLED;
        Persistable persistable = uivalidationcriteria.getContextObject().getObject();
        try {
            if (persistable instanceof WTDocument) {
                String type = CtWTObjectUtil.getLeafTypeIdentifier((Typed) persistable);
                String property = CtPartEcInfoProperties.getProperty(type);
                if (property == null) {
                    uivalidationstatus = UIValidationStatus.HIDDEN;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return uivalidationstatus;
    }
}
