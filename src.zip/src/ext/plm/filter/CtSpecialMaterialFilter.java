package ext.plm.filter;

import com.ptc.core.ui.validation.*;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartClfUtil;
import wt.fc.Persistable;
import wt.part.WTPart;

import java.util.Locale;

public class CtSpecialMaterialFilter extends DefaultUIComponentValidator {
    @Override
    public UIValidationResultSet performFullPreValidation(UIValidationKey validationKey,
                                                          UIValidationCriteria validationCriteria, Locale locale) {
        UIValidationResultSet resultSet = new UIValidationResultSet();
        try {
            Persistable obj = validationCriteria.getContextObject().getObject();
            if(obj instanceof WTPart) {
                WTPart part = (WTPart)obj;
//                String partType = CtWTObjectUtil.getTypeIdentifier(part);
                //获取分类产品的文件地址
                String ClfHierarchyName = CtPartClfUtil.getClfHierarchy(part);
                if (CtFormatUtil.hasContent(ClfHierarchyName)) {
                    if (ClfHierarchyName.contains("原材料")) {

                        resultSet.addResult(new UIValidationResult(validationKey,
                                UIValidationStatus.ENABLED));
                    } else if (ClfHierarchyName.contains("成品")) {
                        String viewName = part.getViewName();
                        if (viewName.equals("Design")) {
                            resultSet.addResult(new UIValidationResult(validationKey,
                                    UIValidationStatus.ENABLED));
                        }
                    } else if (ClfHierarchyName.contains("半成品")) {
                        String viewName = part.getViewName();
                        if (viewName.equals("Design")) {
                            resultSet.addResult(new UIValidationResult(validationKey,
                                    UIValidationStatus.ENABLED));
                        }
                    } else {
                        resultSet.addResult(new UIValidationResult(validationKey,
                                UIValidationStatus.HIDDEN));
                    }
                }
                return resultSet;
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return resultSet;
    }
}