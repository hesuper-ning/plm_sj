package ext.plm.filter;

import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import com.ptc.windchill.enterprise.object.validators.HideForNewObjectInWorkspaceFilter;
import ext.plm.util.CtWTObjectUtil;
import wt.fc.Persistable;
import wt.part.WTPart;

import java.util.Locale;

/**
 * @Author: lcd
 * @Date: 2022/1/19 11:27
 * @Description:
 */
public class CtPsbPartFilter extends HideForNewObjectInWorkspaceFilter {
    public CtPsbPartFilter() {
    }

    public UIValidationStatus preValidateAction(UIValidationKey var1, UIValidationCriteria var2) {
        UIValidationStatus result  = UIValidationStatus.ENABLED;

        System.out.println("执行到这里======");
        try {
            Persistable obj = var2.getContextObject().getObject();
            if(obj instanceof WTPart) {
                WTPart part = (WTPart)obj;
                String state = CtWTObjectUtil.getStateDisplay(part, Locale.CHINA);
                //只有样品/未生效的成品不能编辑
                if("样品/未生效".equals(state)) {
                    result = UIValidationStatus.DISABLED;
                }
                String partType = CtWTObjectUtil.getTypeIdentifier(part);
                String stateDisplay = CtWTObjectUtil.getStateDisplay(part, Locale.CHINA);
                if(partType.contains("ct_fhsjfinishedproduct")||partType.contains("ct_fhsjiallyPreparedProducts")){
                    if("样机".equals(stateDisplay)){
                        result = UIValidationStatus.DISABLED;
                        System.out.println("样机执行到这里======");
                    }
                }else {
                    if("认证中".equals(stateDisplay)){
                        result = UIValidationStatus.DISABLED;
                    }
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
