package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.plm.adTool.config.CtAdToolProperties;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;

import java.util.HashSet;

public class CtUpdatedVersionFilter extends DefaultUIComponentValidator {

    @Override
    public UIValidationStatus preValidateAction(UIValidationKey uiValidationKey, UIValidationCriteria uiValidationCriteria) {
        UIValidationStatus uiValidationStatus = UIValidationStatus.HIDDEN;

        Persistable persistable = uiValidationCriteria.getContextObject().getObject();
        try {
            if (persistable instanceof WTPart) {
                WTPart part = (WTPart) persistable;

                CtAdToolProperties ctAdToolProperties = CtAdToolProperties.getInstance();
                // 校验类型
                String typeInternalName = TypedUtilityServiceHelper.service.getTypeIdentifier(part).getTypeInternalName();
                HashSet typeSet = ctAdToolProperties.getHashSetValue("updatedVersion.action.type");
                if (typeSet.size() > 0 && !typeSet.contains(typeInternalName)) return uiValidationStatus;

                // 校验分类
                HashSet classificationSet = ctAdToolProperties.getHashSetValue("updatedVersion.action.classification");
                IBAUtil ibaUtil = new IBAUtil(part);
                String ibaValue = ibaUtil.getIBAValue("fhsj_Classification");
                // 精确到子分类
                if (classificationSet.size() > 0 && !classificationSet.contains(ibaValue)) return uiValidationStatus;

                // 校验状态
                HashSet statusSet = ctAdToolProperties.getHashSetValue("updatedVersion.action.status");
                String status = part.getLifeCycleState().toString();
                // 精确到子分类
                if (statusSet.size() > 0 && !statusSet.contains(status)) return uiValidationStatus;

                // 都符合则开启Action
                uiValidationStatus = UIValidationStatus.ENABLED;
            }
        } catch (WTException e) {
            try {
                System.out.println("处理Action：" + uiValidationKey + "，对象：" + CtWTObjectUtil.getOid(persistable) + "的过滤失败！");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }


        return uiValidationStatus;
    }
}