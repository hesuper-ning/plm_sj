package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.plm.common.CtConstant;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.util.CtWTObjectUtil;
import wt.fc.Persistable;
import wt.part.WTPart;

/**
 * @Author: heqingbo
 * @Date: 2024/04/15
 * @Description:
 */
public class CtSamplePartFilter extends DefaultSimpleValidationFilter {

    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.HIDDEN;
        try {
            Persistable obj = uivalidationcriteria.getContextObject().getObject();
            if(obj instanceof WTPart) {
                WTPart part = (WTPart)obj;
                //制造视图隐藏按钮
                if(CtConstant.VIEW_MANUFACTURING.equals(part.getViewName())){
                    return UIValidationStatus.HIDDEN;
                }
                String partType = CtWTObjectUtil.getLeafTypeIdentifier(part);
                if(CtEcConstant.Ct_PartType_HalfEndPart.equals(partType) || CtEcConstant.Ct_PartType_EndPart.equals(partType)
                        || part.getNumber().startsWith("101") || part.getNumber().startsWith("K101")){
                    if(!part.getNumber().contains("D")){
                        result = UIValidationStatus.ENABLED;
                    }
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}