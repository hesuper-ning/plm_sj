package ext.plm.filter;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.fc.Persistable;
import wt.part.WTPart;

import java.util.Locale;

/**
 * @Author: lzp
 * @Date: 2023/12/14
 * @Description:
 */
public class CtReplacePartFilter extends DefaultSimpleValidationFilter {

    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.HIDDEN;
        try {
            Persistable obj = uivalidationcriteria.getContextObject().getObject();
            if(obj instanceof WTPart) {
                WTPart part = (WTPart)obj;
                String state = CtWTObjectUtil.getStateDisplay(part, Locale.CHINA);
                IBAUtil ibaUtilReplacePart = new IBAUtil(part);
                String replacePart = ibaUtilReplacePart.getIBAValue("ct_basicmaterial");
                System.out.println("replacePart1"+replacePart);
                if(CtFormatUtil.hasContent(replacePart) && CtPartUtil.isRawPart(part)&&("否".equals(replacePart)||"是".equals(replacePart))){
                    System.out.println("replacePart2"+replacePart);
                    result = UIValidationStatus.ENABLED;
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}