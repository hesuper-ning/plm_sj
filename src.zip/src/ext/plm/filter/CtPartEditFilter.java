package ext.plm.filter;
import com.ptc.core.ui.validation.*;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.util.CtWTObjectUtil;
import wt.fc.Persistable;
import wt.part.WTPart;

import java.util.Locale;

/**
 * @Author: lcd
 * @Date: 2021/12/7 11:06
 * @Description:
 */

public class CtPartEditFilter extends DefaultSimpleValidationFilter {
    @Override
    public UIValidationStatus preValidateAction(UIValidationKey arg0, UIValidationCriteria uivalidationcriteria){
        UIValidationStatus result  = UIValidationStatus.ENABLED;

        try {
            boolean isAdmin = CtUserUtil.isInGroup(  CtUserUtil.getCurrentUser(), "Administrators");
            Persistable obj = uivalidationcriteria.getContextObject().getObject();
            if(obj instanceof WTPart) {
                WTPart part = (WTPart)obj;
                String state = CtWTObjectUtil.getStateDisplay(part, Locale.CHINA);
                //只有样品/未生效的成品不能编辑
                if("样品/未生效".equals(state)) {
                    result = UIValidationStatus.HIDDEN;
                }
                String partType = CtWTObjectUtil.getTypeIdentifier(part);
                String stateDisplay = CtWTObjectUtil.getStateDisplay(part, Locale.CHINA);
                if(partType.contains("ct_fhsjfinishedproduct")||partType.contains("ct_fhsjiallyPreparedProducts")){
                    if("样机".equals(stateDisplay)){
                        result = UIValidationStatus.HIDDEN;
                    }
                }else {
                    if("认证中".equals(stateDisplay)){
                        result = UIValidationStatus.HIDDEN;
                    }
                }
                //管理员组下成员不过滤
                if(isAdmin){
                    result =  UIValidationStatus.ENABLED;
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}