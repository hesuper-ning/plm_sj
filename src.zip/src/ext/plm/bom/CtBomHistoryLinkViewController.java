package ext.plm.bom;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import ext.plm.common.CtResApiResult;
import ext.plm.part.bo.CtPartHistoryLinkViewRefBo;
import ext.plm.part.bo.CtPartViewRefBo;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtWTObjectUtil;
import wt.part.WTPart;

@Controller
@ResponseBody
public class CtBomHistoryLinkViewController {

	static Logger logger = Logger.getLogger(CtBomHistoryLinkViewController.class);

	@Autowired
	private CtBomHistoryViewService ctBomHistoryViewService;
	
	/**
	 * 查询E/M视图物料历史记录
	 * 
	 * @param
	 * @throws Exception
	 */
	@GetMapping(value = "/view/queryPartHistoryLinkViewRef")
	public CtResApiResult<?> queryPartHistoryLinkViewRef(@RequestParam("partOid") String partOid,
			HttpServletRequest request) throws Exception {
		try {
			List<CtPartHistoryLinkViewRefBo> list = new ArrayList<>();
//			String showType = request.getParameter("showType");
//			System.out.println("showType------------->" + showType);
            if(CtFormatUtil.hasContent(partOid)){
                //前台传过来的有可能是vr，也有可能是or，先转成部件对象
                WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(partOid);
                if(null != part){
                    Long oid = part.getPersistInfo().getObjectIdentifier().getId();
                    list = ctBomHistoryViewService.queryPartViewRef(oid);
                }
            }
			return CtResApiResult.success(list);
		} catch (Exception e) {
			logger.error("查询E/M关联历史记录异常:", e);
			return CtResApiResult.fail("查询E/M关联历史记录失败，后台异常信息：\r\n" + e.getLocalizedMessage());
		}
	}
}
