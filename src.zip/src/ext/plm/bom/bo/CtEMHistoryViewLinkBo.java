package ext.plm.bom.bo;

import com.baomidou.mybatisplus.annotations.KeySequence;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

@TableName("ZEMHISTORYVIEWLINK")
@KeySequence(value = "ZEMHISTORYVIEWLINK_SEQ")
public class CtEMHistoryViewLinkBo implements Serializable {

	private static final long serialVersionUID = -8148077081395669937L;
	
	@TableId(value = "id", type = IdType.INPUT)
	private Long id;
	/**
	 * 物料M视图的ida2a2
	 */
	private Long roleA;
	
	private Long vroleA;
	
	private String numberA;
	
	private String versionA; 
	
	private String remarkA;
	/**
	 * 物料E视图的ida2a2
	 */
	private Long roleB;
	
	private Long vroleB;
	
	private String numberB;
	
	private String versionB; 
	
	private String remarkB;
	
	private String changeRecords;
	
	public String getChangeRecords() {
		return changeRecords;
	}

	public void setChangeRecords(String changeRecords) {
		this.changeRecords = changeRecords;
	}

	private String createUser;
	
	private Date createTime;
	
	private String modifyUser;
	
	private Date modifyTime;

	public CtEMHistoryViewLinkBo() {}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRoleA() {
		return roleA;
	}

	public void setRoleA(Long roleA) {
		this.roleA = roleA;
	}

	public Long getRoleB() {
		return roleB;
	}

	public void setRoleB(Long roleB) {
		this.roleB = roleB;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getVroleA() {
		return vroleA;
	}

	public void setVroleA(Long vroleA) {
		this.vroleA = vroleA;
	}

	public String getRemarkA() {
		return remarkA;
	}

	public void setRemarkA(String remarkA) {
		this.remarkA = remarkA;
	}

	public Long getVroleB() {
		return vroleB;
	}

	public void setVroleB(Long vroleB) {
		this.vroleB = vroleB;
	}

	public String getRemarkB() {
		return remarkB;
	}

	public void setRemarkB(String remarkB) {
		this.remarkB = remarkB;
	}


	public String getVersionA() {
		return versionA;
	}

	public void setVersionA(String versionA) {
		this.versionA = versionA;
	}

	public String getVersionB() {
		return versionB;
	}

	public void setVersionB(String versionB) {
		this.versionB = versionB;
	}

	public String getNumberA() {
		return numberA;
	}

	public void setNumberA(String numberA) {
		this.numberA = numberA;
	}

	public String getNumberB() {
		return numberB;
	}

	public void setNumberB(String numberB) {
		this.numberB = numberB;
	}
	
}
