package ext.plm.bom.bo;

import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.mapper.CtEMHistoryViewLinkMapper;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.projectBudget.config.CtProjectBudgetConstant;
import ext.plm.util.CtBomUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import org.apache.commons.lang3.StringUtils;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class CtCompareBo implements Serializable {
	//类型
	private String partType;
	//料号
	private String partNumber;
	//版本
	private String partVersion;
	//研发描述
	private String partDesc;
	//数量
	private String quantity;
	//位号
	private String tagNumber;
	//关联M视图物料
	private String refMNumber;
	//关联E视图物料
	private String refENumber;
	//直接父项
	private String parentNumber;

	public CtCompareBo() {
	}

	public CtCompareBo(WTPartUsageLink link, WTPart part, WTPart parentPart) throws Exception {
		this.partType = CtWTObjectUtil.getTypeViewName(part);
		this.partNumber = part.getNumber();
		this.partVersion = part.getVersionInfo().getIdentifier().getValue()+ "." +
				part.getIterationInfo().getIdentifier().getValue() + "(" + part.getViewName() +")";
		IBAUtil ibaUtil = new IBAUtil(part);
		//研发描述
		this.partDesc = ibaUtil.getIBAValue(CtProjectBudgetConstant.Ct_IBA_PartDesc);
		if(null != parentPart){
			if(null != link){
				if(null != link.getQuantity()){
					DecimalFormat decimalFormat = new DecimalFormat("#0.######");
					this.quantity = decimalFormat.format(link.getQuantity().getAmount());
				}
				this.tagNumber = CtBomUtil.getReferenceDesignator(link);
			}
			this.parentNumber = parentPart.getNumber();
		}
		//查询关联的M视图物料
		String type = CtWTObjectUtil.getLeafTypeIdentifier(part);
		if(CtEcConstant.Ct_PartType_HalfEndPart.equals(type) || CtEcConstant.Ct_PartType_EndPart.equals(type)){
			List<String> addMList = new ArrayList<>();
			List<String> deleteMList = new ArrayList<>();
			CtEMHistoryViewLinkMapper ctEMHistoryViewLinkMapper = CtBeanFactory.newCtBeanFactory().getBean(CtEMHistoryViewLinkMapper.class);
			//设计视图物料
			Long masterId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
			List<CtEMHistoryViewLinkBo> linkList = ctEMHistoryViewLinkMapper.queryHistoryViewLinkByRoleA(masterId);
			for(CtEMHistoryViewLinkBo ctEMHistoryViewLinkBo : linkList){
				String mPartNumber = ctEMHistoryViewLinkBo.getNumberB();
				String operation = ctEMHistoryViewLinkBo.getChangeRecords();
				if(!addMList.contains(mPartNumber) && "关联".equals(operation)){
					addMList.add(mPartNumber);
				}
				if(!deleteMList.contains(mPartNumber) && "断开".equals(operation)){
					deleteMList.add(mPartNumber);
				}
				addMList.removeAll(deleteMList);
			}
			if(addMList.size() > 0){
				this.refMNumber = StringUtils.join(addMList, ",");
			}

			//查询关联的D视图物料
			List<String> addDList = new ArrayList<>();
			List<String> deleteDList = new ArrayList<>();
			List<CtEMHistoryViewLinkBo> linkList2 = ctEMHistoryViewLinkMapper.queryHistoryViewLinkByRoleB(masterId);
			for(CtEMHistoryViewLinkBo ctEMHistoryViewLinkBo : linkList2){
				String dPartNumber = ctEMHistoryViewLinkBo.getNumberA();
				String operation = ctEMHistoryViewLinkBo.getChangeRecords();
				if(!addDList.contains(dPartNumber) && "关联".equals(operation)){
					addDList.add(dPartNumber);
				}
				if(!deleteDList.contains(dPartNumber) && "断开".equals(operation)){
					deleteDList.add(dPartNumber);
				}
				addDList.removeAll(deleteDList);
			}
			if(addDList.size() > 0){
				this.refENumber = StringUtils.join(addDList, ",");
			}
		}
	}

	/**
	 * 通过属性名称取值
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public String getStringValue(String key) throws Exception {
		String result = "";
		Class<?> clazz = CtCompareBo.class;
		Field[] fields = clazz.getDeclaredFields();
		for (Field field : fields) {
			field.setAccessible(true);
			String fieldName = field.getName();
			if(fieldName.equals(key)){
				Object fieldValue = field.get(this);
				if(null != fieldValue){
					result = fieldValue.toString();
				}else{
					result = "";
				}
				break;
			}
		}
		return result;
	}

	/**
	 * 比对两个对象的某个值是否一致
	 * @param a
	 * @param b
	 * @param key
	 * @param key1
	 * @return
	 * @throws Exception
	 */
	public static boolean compareAttribute(CtCompareBo a, CtCompareBo b, String key, String key1) throws Exception {
		String value1 = "";
		if(null != a){
			value1 = a.getStringValue(key);
		}
		String value2 = "";
		if(null != b){
			value2 = b.getStringValue(key1);
		}
		if(CtFormatUtil.hasContent(value1) && CtFormatUtil.hasContent(value2)){
			return value1.toString().equals(value2.toString());
		}else if(!CtFormatUtil.hasContent(value1) && !CtFormatUtil.hasContent(value2)){
			return true;
		}else{
			return false;
		}
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartVersion() {
		return partVersion;
	}

	public void setPartVersion(String partVersion) {
		this.partVersion = partVersion;
	}

	public String getPartDesc() {
		return partDesc;
	}

	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getTagNumber() {
		return tagNumber;
	}

	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	public String getRefMNumber() {
		return refMNumber;
	}

	public void setRefMNumber(String refMNumber) {
		this.refMNumber = refMNumber;
	}

	public String getParentNumber() {
		return parentNumber;
	}

	public void setParentNumber(String parentNumber) {
		this.parentNumber = parentNumber;
	}

	public String getRefENumber() {
		return refENumber;
	}

	public void setRefENumber(String refENumber) {
		this.refENumber = refENumber;
	}
}
