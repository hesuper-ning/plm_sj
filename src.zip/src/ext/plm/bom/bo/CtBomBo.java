package ext.plm.bom.bo;

import ext.plm.tool.poi.ref.ExcelColumn;
import org.springframework.stereotype.Component;

public class CtBomBo {
	// 上阶料号
	@ExcelColumn(index = 0,title = "上阶料号")
	private String fatherPart;

	// 下阶料号
	@ExcelColumn(index = 1,title = "下阶料号")
	private String childPart;

	// 数量
	@ExcelColumn(index = 2,title = "数量")
	private Double bomAmount;

	// 计量单位
	@ExcelColumn(index = 3,title = "单位")
	private String unit;

	// 位号
	@ExcelColumn(index = 4,title = "位号")
	private String fitPlace ="";

	// 备注
	@ExcelColumn(index = 5,title = "remark")
	private String remark ="";

	public String getFatherPart() {
		return fatherPart;
	}

	public void setFatherPart(String fatherPart) {
		this.fatherPart = fatherPart;
	}

	public String getChildPart() {
		return childPart;
	}

	public void setChildPart(String childPart) {
		this.childPart = childPart;
	}

	public Double getBomAmount() {
		return bomAmount;
	}

	public void setBomAmount(Double bomAmount) {
		this.bomAmount = bomAmount;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getFitPlace() {
		return fitPlace;
	}

	public void setFitPlace(String fitPlace) {
		this.fitPlace = fitPlace;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
