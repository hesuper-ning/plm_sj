package ext.plm.bom.bo;

import ext.plm.ec.config.CtEcConstant;
import ext.plm.part.config.CtPartConstant;
import ext.plm.projectBudget.config.CtProjectBudgetConstant;
import ext.plm.util.CtBomUtil;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.part.Quantity;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CtBomSearchViewBo {
	//部件BranchId
	private String partBranchId;
	//部件编号
	private String partNumber;
	//父部件编号
	private String parentPartNumber;
	//部件在BOM中的路径
	private String partPath;
	//目标对象，是按条件查询出来的部件，标识为Y
	private String targetObject;
	//部件名称
	private String partName;
	//内部版本
	private String internalVersion;
	//版本
	private String version;
	//状态
	private String partState;
	//默认单位
	private String defaultUnit;
	//数量
	private String quantity;
	//位号
	private String referenceDesignatorRange;
	//BOM备注
	private String remarks;
	//是否RoHS
	private String isRoHS;
	//创建人
	private String creator;
	//修改人
	private String editor;
	//部件类型
	private String partType;
	//部件url
	private String partUrl;
	//子项 ext树规定的属性
	private List<CtBomSearchViewBo> children = new ArrayList<>();
	//是否展开 ext树规定的属性
    private boolean expanded;
    //是否是叶子节点 ext树规定的属性
    private boolean leaf;
    //节点图标样式 ext树规定的属性
	private String iconCls;

	/**
	 * 带参的构造方法
	 * @param part
	 */
	public CtBomSearchViewBo(WTPart part, CtBomSearchViewBo parentPartBo, WTPartUsageLink usageLink) throws Exception {
		if(null == part){
			return;
		}
		this.partBranchId = part.getBranchIdentifier() + "";
		this.partUrl = CtCommonUtil.getURL(part, part.getNumber());
		this.partNumber = part.getNumber();
		if(null != parentPartBo){
			this.parentPartNumber = parentPartBo.getPartNumber();
			this.partPath = parentPartBo.getPartPath() + "/" + part.getNumber();
		}else{
			this.parentPartNumber = "";
			this.partPath = part.getNumber();
		}
		this.partName = part.getName();
		this.defaultUnit = part.getDefaultUnit().getDisplay(Locale.CHINA);
		StringBuilder versionBuilder = new StringBuilder();
		versionBuilder.append(part.getVersionInfo().getIdentifier().getValue())
				.append(".").append(part.getIterationInfo().getIdentifier().getValue())
				.append("(").append(part.getViewName()).append(")");
		this.version = versionBuilder.toString();
		this.partState = part.getLifeCycleState().getDisplay(Locale.CHINA);
		IBAUtil ibaUtilPart = new IBAUtil(part);
		AttributeDefDefaultView view = ibaUtilPart.getAttributeDefinition(CtProjectBudgetConstant.Ct_IBA_IsRohs);
		if(null != view){
			this.isRoHS = ibaUtilPart.getIBAValue(CtProjectBudgetConstant.Ct_IBA_IsRohs);
		}
		AttributeDefDefaultView banView = ibaUtilPart.getAttributeDefinition(CtPartConstant.IBA_BAN_CI);
		if(null != banView){
			this.internalVersion = ibaUtilPart.getIBAValue(CtPartConstant.IBA_BAN_CI);
		}
		this.creator = part.getCreatorFullName();
		this.editor = part.getModifierFullName();

		//部件使用关系的相关字段
		if(null != usageLink){
			Quantity quantity = usageLink.getQuantity();
			if(null != quantity){
				this.quantity = String.valueOf(quantity.getAmount());
			}
			this.referenceDesignatorRange = CtBomUtil.getReferenceDesignator(usageLink);
			IBAUtil ibaUtilLink = new IBAUtil(usageLink);
			this.remarks = ibaUtilLink.getIBAValue(CtEcConstant.Ct_IBA_bomNotes);
		}
		this.expanded = true;
        this.leaf = false;
		String type = CtWTObjectUtil.getLeafTypeIdentifier(part);
		this.partType = type;
        if(CtEcConstant.Ct_PartType_EndPart.equals(type)){
			//成品的图标
			this.iconCls = "icon-prod";
		}else{
			//部件的图标
			this.iconCls = "icon-part";
		}
	}

	public String getPartBranchId() {
		return partBranchId;
	}

	public void setPartBranchId(String partBranchId) {
		this.partBranchId = partBranchId;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getParentPartNumber() {
		return parentPartNumber;
	}

	public void setParentPartNumber(String parentPartNumber) {
		this.parentPartNumber = parentPartNumber;
	}

	public String getPartPath() {
		return partPath;
	}

	public void setPartPath(String partPath) {
		this.partPath = partPath;
	}

	public String getTargetObject() {
		return targetObject;
	}

	public void setTargetObject(String targetObject) {
		this.targetObject = targetObject;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getInternalVersion() {
		return internalVersion;
	}

	public void setInternalVersion(String internalVersion) {
		this.internalVersion = internalVersion;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getPartState() {
		return partState;
	}

	public void setPartState(String partState) {
		this.partState = partState;
	}

	public String getDefaultUnit() {
		return defaultUnit;
	}

	public void setDefaultUnit(String defaultUnit) {
		this.defaultUnit = defaultUnit;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getReferenceDesignatorRange() {
		return referenceDesignatorRange;
	}

	public void setReferenceDesignatorRange(String referenceDesignatorRange) {
		this.referenceDesignatorRange = referenceDesignatorRange;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getIsRoHS() {
		return isRoHS;
	}

	public void setIsRoHS(String isRoHS) {
		this.isRoHS = isRoHS;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getEditor() {
		return editor;
	}

	public void setEditor(String editor) {
		this.editor = editor;
	}

    public List<CtBomSearchViewBo> getChildren() {
        return children;
    }

    public void setChildren(List<CtBomSearchViewBo> children) {
        this.children = children;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    public boolean isLeaf() {
        return leaf;
    }

    public void setLeaf(boolean leaf) {
        this.leaf = leaf;
    }

	public String getIconCls() {
		return iconCls;
	}

	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getPartUrl() {
		return partUrl;
	}

	public void setPartUrl(String partUrl) {
		this.partUrl = partUrl;
	}
}
