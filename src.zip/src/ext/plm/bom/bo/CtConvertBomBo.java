package ext.plm.bom.bo;

import com.baomidou.mybatisplus.annotations.TableName;

import java.util.Date;

@TableName("ZConvertBom")
public class CtConvertBomBo {
	private String id;
	//流程id
	private Long pnId;
	//部件详情页面，部件的masterId
	private Long masterId;
	//类型
	private String partType;
	//料号
	private String partNumber;
	//研发描述
	private String developDesc;
	//是否已转M视图
	private String convertMView;
	//M视图物料编码
	private String manufacturingNumber;
	//上次是否勾选
	private String lastTimeCheck;
	//不转MBOM说明
	private String illustrate;
	//本次是否转
	private String convertBom;
	//执行状况
	private String implementationStatus;
	//创建人
	private String creator;
	//修改人
	private String editor;
	//创建时间
	private Date createTime;
	//修改时间
	private Date modifyTime;
	//单独作为升级对象的半成品，且无成品引用，则整行数据标记红色
	private String flagRed;

	public CtConvertBomBo() {

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getDevelopDesc() {
		return developDesc;
	}

	public void setDevelopDesc(String developDesc) {
		this.developDesc = developDesc;
	}

	public String getConvertMView() {
		return convertMView;
	}

	public void setConvertMView(String convertMView) {
		this.convertMView = convertMView;
	}

	public String getLastTimeCheck() {
		return lastTimeCheck;
	}

	public void setLastTimeCheck(String lastTimeCheck) {
		this.lastTimeCheck = lastTimeCheck;
	}

	public String getIllustrate() {
		return illustrate;
	}

	public void setIllustrate(String illustrate) {
		this.illustrate = illustrate;
	}

	public String getConvertBom() {
		return convertBom;
	}

	public void setConvertBom(String convertBom) {
		this.convertBom = convertBom;
	}

	public String getImplementationStatus() {
		return implementationStatus;
	}

	public void setImplementationStatus(String implementationStatus) {
		this.implementationStatus = implementationStatus;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getEditor() {
		return editor;
	}

	public void setEditor(String editor) {
		this.editor = editor;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getManufacturingNumber() {
		return manufacturingNumber;
	}

	public void setManufacturingNumber(String manufacturingNumber) {
		this.manufacturingNumber = manufacturingNumber;
	}

	public String getFlagRed() {
		return flagRed;
	}

	public void setFlagRed(String flagRed) {
		this.flagRed = flagRed;
	}

    public Long getPnId() {
        return pnId;
    }

    public void setPnId(Long pnId) {
        this.pnId = pnId;
    }

	public Long getMasterId() {
		return masterId;
	}

	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}
}
