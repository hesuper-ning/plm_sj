package ext.plm.bom.bo;

public class CtExportBomBo {

    /**
     * 层级
     */
    private String seq;

    /**
     * 父阶料编码
     */
    private String fatherPartNum;

    /**
     * 父阶料名称
     */
    private String fatherPartName;

    /**
     * 子阶料编码
     */
    private String childPartNum;

    /**
     * 子阶料名称
     */
    private String childPartName;

    /**
     * 版本
     */
    private String version;

    /**
     * 内部版本
     */
    private String innerVersion;

    /**
     * 状态
     */
    private String status;

    /**
     * 数量
     */
    private String amount;

    /**
     * 位号
     */
    private String fitPlace;

    /**
     * BOM备注
     */
    private String bomRemark;

    /**
     * 是否RoHS
     */
    private String isRohs;

    /**
     * 替代组编号
     */
    private String replaceGroupNum;

    /**
     * 替代组优先级
     */
    private String replaceGroupPriority;

    /**
     * 源
     */
    private String source;

    /**
     * 默认单位
     */
    private String defaultUnit;

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getFatherPartNum() {
        return fatherPartNum;
    }

    public void setFatherPartNum(String fatherPartNum) {
        this.fatherPartNum = fatherPartNum;
    }

    public String getFatherPartName() {
        return fatherPartName;
    }

    public void setFatherPartName(String fatherPartName) {
        this.fatherPartName = fatherPartName;
    }

    public String getChildPartNum() {
        return childPartNum;
    }

    public void setChildPartNum(String childPartNum) {
        this.childPartNum = childPartNum;
    }

    public String getChildPartName() {
        return childPartName;
    }

    public void setChildPartName(String childPartName) {
        this.childPartName = childPartName;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getInnerVersion() {
        return innerVersion;
    }

    public void setInnerVersion(String innerVersion) {
        this.innerVersion = innerVersion;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getFitPlace() {
        return fitPlace;
    }

    public void setFitPlace(String fitPlace) {
        this.fitPlace = fitPlace;
    }

    public String getBomRemark() {
        return bomRemark;
    }

    public void setBomRemark(String bomRemark) {
        this.bomRemark = bomRemark;
    }

    public String getIsRohs() {
        return isRohs;
    }

    public void setIsRohs(String isRohs) {
        this.isRohs = isRohs;
    }

    public String getReplaceGroupNum() {
        return replaceGroupNum;
    }

    public void setReplaceGroupNum(String replaceGroupNum) {
        this.replaceGroupNum = replaceGroupNum;
    }

    public String getReplaceGroupPriority() {
        return replaceGroupPriority;
    }

    public void setReplaceGroupPriority(String replaceGroupPriority) {
        this.replaceGroupPriority = replaceGroupPriority;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDefaultUnit() {
        return defaultUnit;
    }

    public void setDefaultUnit(String defaultUnit) {
        this.defaultUnit = defaultUnit;
    }
}
