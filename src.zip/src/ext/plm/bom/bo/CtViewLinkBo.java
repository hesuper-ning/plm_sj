package ext.plm.bom.bo;

import com.baomidou.mybatisplus.annotations.KeySequence;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

@TableName("ZEMViewLink")
@KeySequence(value = "ZEMViewLink_SEQ")
public class CtViewLinkBo implements Serializable {

	@TableId(value = "id", type = IdType.INPUT)
	private Long id;
	/**
	 * 物料M视图的ida2a2
	 */
	private Long roleA;
	/**
	 * 物料E视图的ida2a2
	 */
	private Long roleB;
	private String createUser;
	private Date createTime;
	private String modifyUser;
	private Date modifyTime;

	public CtViewLinkBo() {}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRoleA() {
		return roleA;
	}

	public void setRoleA(Long roleA) {
		this.roleA = roleA;
	}

	public Long getRoleB() {
		return roleB;
	}

	public void setRoleB(Long roleB) {
		this.roleB = roleB;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
}
