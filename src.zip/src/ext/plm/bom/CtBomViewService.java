package ext.plm.bom;

import ext.plm.bom.bo.CtBomSearchViewBo;
import ext.plm.bom.bo.CtConvertBomBo;
import ext.plm.bom.bo.CtViewLinkBo;
import ext.plm.part.bo.CtPartViewRefBo;
import org.apache.poi.ss.usermodel.Workbook;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;

import java.text.DateFormat;
import java.util.List;
import java.util.Map;

public interface CtBomViewService {

    CtBomSearchViewBo searchBom(String oid, String type, String state, String commonParam) throws Exception;

    Workbook exportFilterBom(String bomData) throws Exception;

    void saveViewLink(CtViewLinkBo bo) throws Exception;

    void deleteViewLink(CtViewLinkBo bo) throws Exception;

    List<CtViewLinkBo> queryViewLinkByManufacturing(Long roleA) throws Exception;

    List<CtPartViewRefBo> queryPartViewRef(Long partOid) throws Exception;

    List<Map<String, String>> searchPart(String partNumber) throws Exception;

    List<Map<String, String>> getSelectNumbers(String partNumber) throws Exception;

    List<CtConvertBomBo> queryConvertBomInfo(Long pnId) throws Exception;

    CtConvertBomBo updateConvertBomBoById(String id, String key, String value) throws Exception;

    CtConvertBomBo updateConvertBomBo(List<CtConvertBomBo> boList, WTPart mPart, DateFormat dataFormat) throws Exception;

    void convertBom(String numbers, PromotionNotice pn, Long masterId) throws Exception;

    List<CtConvertBomBo> queryPartPageConvertBomBo(Long masterId) throws Exception;

    void deleteConvertBomBo(String id) throws Exception;
}
