package ext.plm.bom;

import wt.doc.WTDocument;
import wt.method.RemoteInterface;
import wt.part.WTPart;
import wt.util.WTException;

import java.io.OutputStream;
import java.util.List;

@RemoteInterface
public interface CtBomService {

    void exportBom(OutputStream os, WTPart part, String fileName) throws WTException, Exception;

    void setDesignViewPart(String path) throws Exception;

    void setPartModifyTime() throws Exception;

    void initializeBaselineData() throws Exception;

    List<WTDocument> getAllLastDoc() throws Exception;
}
