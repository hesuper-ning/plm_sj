package ext.plm.bom;

import cn.hutool.core.io.FileUtil;
import ext.plm.bean.CtBeanService;
import ext.plm.bom.config.CtBomConstant;
import ext.plm.common.CtConstant;
import ext.plm.part.CtPartService;
import ext.plm.part.bo.CtMViewExportBo;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.method.MethodContext;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.pom.WTConnection;
import wt.services.ServiceFactory;
import wt.util.WTException;

import java.io.File;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestMain {

    public static CtBomService service = ServiceFactory.getService(CtBomService.class);
    public static void main(String[] args) {
        System.out.println("======TestMain.java 开始调用  " + args[0] + "=============");
        try {
            RemoteMethodServer server = RemoteMethodServer.getDefault();
            if (CtConstant.isLocalEnv() || CtConstant.isTestEnv()) {
                server.setUserName("wcadmin");
                server.setPassword("wcadmin");
            } else if (CtConstant.isPrdEnv()) {
                server.setUserName("wcadmin");
                server.setPassword("fhsj.com");
            }
            if ("insertAssociatedDesignViewPart".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.bom.TestMain insertAssociatedDesignViewPart /home/ptc/Windchill_11.0/Windchill/codebase/exportTemp/viewPart.xlsx
                //刷“关联E/M视图物料”属性
                service.setDesignViewPart(args[1]);
                System.out.println("======刷“关联E/M视图物料”属性完成！=============");
            }else if("setPartModifyTime".equalsIgnoreCase(args[0])){
                //windchill ext.plm.bom.TestMain setPartModifyTime
                //刷物料的修改时间
                service.setPartModifyTime();
                System.out.println("======刷物料的修改时间完成！=============");
            }else if(("initializeBaselineData").equalsIgnoreCase(args[0])){
                //windchill ext.plm.bom.TestMain initializeBaselineData
                //刷物料的修改时间
                service.initializeBaselineData();
                System.out.println("======刷BOM基线历史数据到自建表完成！=============");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
















}
