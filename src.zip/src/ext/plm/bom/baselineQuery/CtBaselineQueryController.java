package ext.plm.bom.baselineQuery;

import com.alibaba.fastjson.JSONObject;
import com.ptc.core.components.util.TimeZoneHelper;
import ext.plm.bom.baselineQuery.bo.CtBaselineBo;
import ext.plm.bom.baselineQuery.service.CtBaselineQueryService;
import ext.plm.bom.baselineQuery.service.CtBaselineQueryServiceImpl;
import ext.plm.common.CtConstant;
import ext.plm.common.CtResApiResult;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import wt.part.WTPart;
import wt.session.SessionServerHelper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@RestController
@RequestMapping("/ext/plm/bom/baselineQuery")
public class CtBaselineQueryController {

    static Logger logger = Logger.getLogger(CtBaselineQueryController.class);
    @Autowired
    private CtBaselineQueryService ctBaselineQueryService;

    /**
     * 按搜索条件搜索使用关系记录
     * @param request
     * @return
     */
    @RequestMapping(value = "/searchUseRelationship", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult searchUseRelationship(HttpServletRequest request) {
        try {
            List<CtBaselineBo> list = new ArrayList<>();
            String oid = request.getParameter("oid");
            String view = request.getParameter("view");
            String version = request.getParameter("version");
            String internalVersion = request.getParameter("internalVersion");
            String date = request.getParameter("date");
            List<String> oidList = new ArrayList<>();
            WTPart part = null;
            if(CtFormatUtil.hasContent(oid)){
                part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
            }
            if(null != part && CtFormatUtil.hasContent(view)){
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                dateFormat.setTimeZone(TimeZoneHelper.getLocalTimeZone());

                if(CtFormatUtil.hasContent(date)){
                    if(date.length() > 10){
                        date = date.substring(0, 10);
                        CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                        oid = ctBaselineQuery.queryCompliesTimeOid(view, part.getNumber(), date);
                        if(CtFormatUtil.hasContent(oid)){
                            oidList.add(oid);
                        }
                    }
                }else if(CtFormatUtil.hasContent(version)){
                    String[] oidArray = version.split(",");
                    for(int i = 0;i < oidArray.length;i++){
                        oidList.add(oidArray[i]);
                    }
                }else if(CtFormatUtil.hasContent(internalVersion)){
                    String[] oidArray = internalVersion.split(",");
                    for(int i = 0;i < oidArray.length;i++){
                        oidList.add(oidArray[i]);
                    }
                }

                for(String oidStr : oidList){
                    String dateStart = "";
                    String dateEnd = "";
                    if(CtFormatUtil.hasContent(date)){
                        dateEnd = date;
                    }
//                    else{
//                        WTPart selectedPart = (WTPart) CtWTObjectUtil.getObjectByOid(oidStr);
//                        if(null != selectedPart){
//                            dateStart = dateFormat.format(selectedPart.getModifyTimestamp());
//                            Date endDate = CtBaselineQueryServiceImpl.getEndDate(selectedPart);
//                            if(null != endDate){
//                                dateEnd = dateFormat.format(endDate);
//                            }
//                        }
//                    }
                    CtBaselineBo ctBaselineBo = ctBaselineQueryService.searchUseRelationship(oidStr, dateStart, dateEnd, view, dateFormat);
                    list.add(ctBaselineBo);
                }
            }
            return CtResApiResult.children(list);
        } catch (Exception e) {
            logger.error("查询物料使用关系记录异常：", e);
            return CtResApiResult.fail( "查询物料使用关系记录异常：" +e.getLocalizedMessage());
        }
    }

    /**
     * 按搜索条件搜索子项变动
     * @param request
     * @return
     */
    @RequestMapping(value = "/searchChildChange", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult searchChildChange(HttpServletRequest request) {
        try {
            List<CtBaselineBo> list = new ArrayList<>();
            String oid = request.getParameter("oid");
            String view = request.getParameter("view");
            String version = request.getParameter("version");
            String date = request.getParameter("date");
            List<String> oidList = new ArrayList<>();
            long startTime = System.currentTimeMillis();
            WTPart part = null;
            if(CtFormatUtil.hasContent(oid)){
                part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
            }
            if(null != part && CtFormatUtil.hasContent(view)){
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                dateFormat.setTimeZone(TimeZoneHelper.getLocalTimeZone());

                if(CtFormatUtil.hasContent(date)){
                    if(date.length() > 10){
                        date = date.substring(0, 10);
                        CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                        oid = ctBaselineQuery.queryCompliesTimeOid(view, part.getNumber(), date);
                        if(CtFormatUtil.hasContent(oid)){
                            oidList.add(oid);
                        }
                    }
                }else if(CtFormatUtil.hasContent(version)){
                    String[] oidArray = version.split(",");
                    for(int i = 0;i < oidArray.length;i++){
                        oidList.add(oidArray[i]);
                    }
                }

                for(String oidStr : oidList){
                    String dateStart = "";
                    String dateEnd = "";
                    if(CtFormatUtil.hasContent(date)){
                        dateEnd = date;
                    }else{
                        WTPart selectedPart = (WTPart) CtWTObjectUtil.getObjectByOid(oidStr);
                        if(null != selectedPart){
                            //dateStart = dateFormat.format(selectedPart.getModifyTimestamp());
                            Date endDate = CtBaselineQueryServiceImpl.getEndDate(selectedPart);
                            if(null != endDate){
                                dateEnd = dateFormat.format(endDate);
                            }
                        }
                    }
                    logger.error(">>>>>>处理参数耗时:" + (System.currentTimeMillis()-startTime));
                    CtBaselineBo ctBaselineBo = ctBaselineQueryService.searchChildChange(oidStr, dateStart, dateEnd, view, dateFormat);
                    list.add(ctBaselineBo);
                }
            }
            return CtResApiResult.children(list);
        } catch (Exception e) {
            logger.error("按搜索条件搜索子项变动异常：", e);
            return CtResApiResult.fail( "按搜索条件搜索子项变动异常：" +e.getLocalizedMessage());
        }
    }

    /**
     * 按搜索条件搜索子项变动(查自建表的BOM数据)
     * @param request
     * @return
     */
    @RequestMapping(value = "/searchChildChange2", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult searchChildChange2(HttpServletRequest request) {
        try {
            List<CtBaselineBo> list = new ArrayList<>();
            String oid = request.getParameter("oid");
            String view = request.getParameter("view");
            String version = request.getParameter("version");
            String date = request.getParameter("date");
            List<String> oidList = new ArrayList<>();
            long startTime = System.currentTimeMillis();
            WTPart part = null;
            if(CtFormatUtil.hasContent(oid)){
                part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
            }
            if(null != part && CtFormatUtil.hasContent(view)){
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                dateFormat.setTimeZone(TimeZoneHelper.getLocalTimeZone());
                if(CtFormatUtil.hasContent(date)){
                    if(date.length() > 10){
                        date = date.substring(0, 10);
                        CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                        oid = ctBaselineQuery.queryTheLastOid(view, part.getNumber(), date);
                        if(CtFormatUtil.hasContent(oid)){
                            oidList.add(oid);
                        }
                    }
                }else if(CtFormatUtil.hasContent(version)){
                    String[] oidArray = version.split(",");
                    for(int i = 0;i < oidArray.length;i++){
                        oidList.add(oidArray[i]);
                    }
                }
                for(String oidStr : oidList){
                    logger.error(">>>>>>处理参数耗时:" + (System.currentTimeMillis()-startTime));
                    CtBaselineBo ctBaselineBo = ctBaselineQueryService.searchChildChange(oidStr, dateFormat);
                    list.add(ctBaselineBo);
                }
            }
            return CtResApiResult.children(list);
        } catch (Exception e) {
            logger.error("按搜索条件搜索子项变动异常：", e);
            return CtResApiResult.fail( "按搜索条件搜索子项变动异常：" +e.getLocalizedMessage());
        }
    }

    /**
     * 按料号和视图查所有版本
     * @param partNumber
     * @param partView
     * @return
     */
    @RequestMapping(value = "/getPartVersion", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult getPartVersion(@RequestParam(value = "partNumber") String partNumber, @RequestParam(value = "partView") String partView) {
        try {
            if(CtFormatUtil.hasContent(partNumber) && CtFormatUtil.hasContent(partView)){
                WTPart part = CtPartUtil.getPartByNumber(partNumber);
                if(null != part){
                    boolean isRawPart = CtPartUtil.isRawPart(part);
                    //原材料只有D视图
                    if(isRawPart){
                        partView = CtConstant.VIEW_DESIGN;
                    }
                }
                CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                return CtResApiResult.success(ctBaselineQuery.getPartVersion(partNumber, partView));
            }else{
                return CtResApiResult.success();
            }
        } catch (Exception e) {
            logger.error("按料号和视图查所有版本异常：", e);
            return CtResApiResult.fail( "按料号和视图查所有版本异常：" +e.getLocalizedMessage());
        }
    }

    /**
     * 按料号和视图查内部版本
     * @param partNumber
     * @param partView
     * @return
     */
    @RequestMapping(value = "/getInternalVersion", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult getInternalVersion(@RequestParam(value = "partNumber") String partNumber, @RequestParam(value = "partView") String partView) {
        try {
            if(CtFormatUtil.hasContent(partNumber) && CtFormatUtil.hasContent(partView)){
                WTPart part = CtPartUtil.getPartByNumber(partNumber);
                if(null != part){
                    boolean isRawPart = CtPartUtil.isRawPart(part);
                    //原材料只有D视图
                    if(isRawPart){
                        partView = CtConstant.VIEW_DESIGN;
                    }
                }
                CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                return CtResApiResult.success(ctBaselineQuery.getInternalVersion(partNumber, partView));
            }else{
                return CtResApiResult.success();
            }
        } catch (Exception e) {
            logger.error("按料号和视图查内部版本异常：", e);
            return CtResApiResult.fail( "按料号和视图查内部版本异常：" +e.getLocalizedMessage());
        }
    }

    /**
     * 按料号和名称模糊查询物料信息
     * @param partNumber
     * @param partName
     * @return
     */
    @RequestMapping(value = "/getPartNumberAndPartName", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult getPartNumberAndPartName(@RequestParam(value = "partNumber") String partNumber, @RequestParam(value = "partName") String partName) {
        try {
            CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
            return CtResApiResult.success(ctBaselineQuery.getPartNumberAndPartName(partNumber, partName));
        } catch (Exception e) {
            logger.error("按料号和视图查内部版本异常：", e);
            return CtResApiResult.fail( "按料号和视图查内部版本异常：" +e.getLocalizedMessage());
        }
    }

    /**
     * 导出“物料使用关系记录”的数据
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/exportUseData", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportUseData(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Workbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "物料使用关系记录-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String bomData = IOUtils.toString(reader);

            //生成需要导出的excel
            workbook = ctBaselineQueryService.exportPageData(bomData, true);
            workbook.write(response.getOutputStream());
        } catch (Exception e) {
            logger.error("导出物料使用关系记录数据异常:", e);
            throw new Exception("导出物料使用关系记录数据异常：" + e.getLocalizedMessage());
        } finally {
            if(null != workbook){
                //workbook.close();
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(inputStreamReader != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

    /**
     * 导出“物料子项变动记录”的数据
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/exportSubItemData", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportSubItemData(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Workbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "物料使用关系记录-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String bomData = IOUtils.toString(reader);

            //生成需要导出的excel
            workbook = ctBaselineQueryService.exportPageData(bomData, false);
            workbook.write(response.getOutputStream());
        } catch (Exception e) {
            logger.error("导出物料使用关系记录数据异常:", e);
            throw new Exception("导出物料使用关系记录数据异常：" + e.getLocalizedMessage());
        } finally {
            if(null != workbook){
                //workbook.close();
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(inputStreamReader != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

    /**
     * 导出基线BOM差异
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/exportBaselineBomDifferent", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportBomDifferent(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        Workbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "";

            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String param = IOUtils.toString(reader);
            fileName = "基线BOM差异-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //生成需要导出的excel
            if(CtFormatUtil.hasContent(param)){
                JSONObject json = JSONObject.parseObject(param);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                dateFormat.setTimeZone(TimeZoneHelper.getLocalTimeZone());
                //左侧参数处理
                CtBaselineBo ctBaselineBoLeft = null;
                String oidLeft = "";
                String dateStartLeft = "";
                String dateEndLeft = "";
                String partNumberLeft = json.getString("partNumberLeft");
                String partViewLeft = json.getString("partViewLeft");
                String partVersionLeft = json.getString("partVersionLeft");
                String partDateLeft = json.getString("partDateLeft");
                List<String> oidList = new ArrayList<>();
                WTPart part = CtPartUtil.getPartByNumber(partNumberLeft);
                if(null != part && CtFormatUtil.hasContent(partViewLeft)){
                    if(CtFormatUtil.hasContent(partDateLeft)){
                        if(partDateLeft.length() > 10){
                            partDateLeft = partDateLeft.substring(0, 10);
                            CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                            String oid = ctBaselineQuery.queryCompliesTimeOid(partViewLeft, part.getNumber(), partDateLeft);
                            if(CtFormatUtil.hasContent(oid)){
                                oidLeft = oid;
                                dateEndLeft = partDateLeft;
                            }
                        }
                    }else if(CtFormatUtil.hasContent(partVersionLeft)){
                        oidLeft = partVersionLeft;
                        WTPart selectedPart = (WTPart) CtWTObjectUtil.getObjectByOid(oidLeft);
                        if(null != selectedPart){
                            dateStartLeft = dateFormat.format(selectedPart.getModifyTimestamp());
                            Date endDate = CtBaselineQueryServiceImpl.getEndDate(selectedPart);
                            if(null != endDate){
                                dateEndLeft = dateFormat.format(endDate);
                            }
                        }
                    }
                    if(CtFormatUtil.hasContent(oidLeft) && CtFormatUtil.hasContent(dateEndLeft)){
                        ctBaselineBoLeft = ctBaselineQueryService.searchChildChange(oidLeft, dateStartLeft, dateEndLeft, partViewLeft, dateFormat);
                    }
                }
                if(null == ctBaselineBoLeft){
                    throw new Exception("根据左侧的条件找不到对应的物料版本！");
                }
                //右侧参数处理
                CtBaselineBo ctBaselineBoRight = null;
                String oidRight = "";
                String dateStartRight = "";
                String dateEndRight = "";
                String partNumberRight = json.getString("partNumberRight");
                String partViewRight = json.getString("partViewRight");
                String partVersionRight = json.getString("partVersionRight");
                String partDateRight = json.getString("partDateRight");
                WTPart partRight = CtPartUtil.getPartByNumber(partNumberRight);
                if(null != partRight && CtFormatUtil.hasContent(partViewRight)){
                    if(CtFormatUtil.hasContent(partDateRight)){
                        if(partDateRight.length() > 10){
                            partDateRight = partDateRight.substring(0, 10);
                            CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                            String oid = ctBaselineQuery.queryCompliesTimeOid(partViewRight, partRight.getNumber(), partDateRight);
                            if(CtFormatUtil.hasContent(oid)){
                                oidRight = oid;
                                dateEndRight = partDateRight;
                            }
                        }
                    }else if(CtFormatUtil.hasContent(partVersionRight)){
                        oidRight = partVersionRight;
                        WTPart selectedPart = (WTPart) CtWTObjectUtil.getObjectByOid(oidRight);
                        if(null != selectedPart){
                            dateStartRight = dateFormat.format(selectedPart.getModifyTimestamp());
                            Date endDate = CtBaselineQueryServiceImpl.getEndDate(selectedPart);
                            if(null != endDate){
                                dateEndRight = dateFormat.format(endDate);
                            }
                        }
                    }
                    if(CtFormatUtil.hasContent(oidRight) && CtFormatUtil.hasContent(dateEndRight)){
                        ctBaselineBoRight = ctBaselineQueryService.searchChildChange(oidRight, dateStartRight, dateEndRight, partViewRight, dateFormat);
                    }
                }
                if(null == ctBaselineBoRight){
                    throw new Exception("根据右侧的条件找不到对应的物料版本！");
                }
                //生成excel
                workbook = ctBaselineQueryService.exportCompareResult(ctBaselineBoLeft, ctBaselineBoRight);
                workbook.write(response.getOutputStream());
            }
        } catch (Exception e) {
            logger.error("导出基线BOM差异异常:", e);
            throw new Exception("导出基线BOM差异异常：" + e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
            if(null != workbook){
                //workbook.close();
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(inputStreamReader != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

    /**
     * 导出基线BOM差异(新)
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/exportBaselineBomDifferent2", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportBomDifferent2(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        Workbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "";

            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String param = IOUtils.toString(reader);
            fileName = "基线BOM差异-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //生成需要导出的excel
            if(CtFormatUtil.hasContent(param)){
                JSONObject json = JSONObject.parseObject(param);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                dateFormat.setTimeZone(TimeZoneHelper.getLocalTimeZone());

                //左侧参数处理
                CtBaselineBo ctBaselineBoLeft = null;
                String oidLeft = "";
                String partNumberLeft = json.getString("partNumberLeft");
                String partViewLeft = json.getString("partViewLeft");
                String partVersionLeft = json.getString("partVersionLeft");
                String partDateLeft = json.getString("partDateLeft");
                WTPart part = CtPartUtil.getPartByNumber(partNumberLeft);
                if(null != part && CtFormatUtil.hasContent(partViewLeft)){
                    if(CtFormatUtil.hasContent(partDateLeft)){
                        if(partDateLeft.length() > 10){
                            partDateLeft = partDateLeft.substring(0, 10);
                            CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                            String oid = ctBaselineQuery.queryTheLastOid(partViewLeft, part.getNumber(), partDateLeft);
                            if(CtFormatUtil.hasContent(oid)){
                                oidLeft = oid;
                            }
                        }
                    }else if(CtFormatUtil.hasContent(partVersionLeft)){
                        oidLeft = partVersionLeft;
                    }
                    if(CtFormatUtil.hasContent(oidLeft)){
                        ctBaselineBoLeft = ctBaselineQueryService.searchChildChange(oidLeft, dateFormat);
                    }
                }
                if(null == ctBaselineBoLeft){
                    throw new Exception("根据左侧的条件找不到对应的物料版本！");
                }
                //右侧参数处理
                CtBaselineBo ctBaselineBoRight = null;
                String oidRight = "";
                String partNumberRight = json.getString("partNumberRight");
                String partViewRight = json.getString("partViewRight");
                String partVersionRight = json.getString("partVersionRight");
                String partDateRight = json.getString("partDateRight");
                WTPart partRight = CtPartUtil.getPartByNumber(partNumberRight);
                if(null != partRight && CtFormatUtil.hasContent(partViewRight)){
                    if(CtFormatUtil.hasContent(partDateRight)){
                        if(partDateRight.length() > 10){
                            partDateRight = partDateRight.substring(0, 10);
                            CtBaselineQuery ctBaselineQuery = new CtBaselineQuery();
                            String oid = ctBaselineQuery.queryTheLastOid(partViewRight, partRight.getNumber(), partDateRight);
                            if(CtFormatUtil.hasContent(oid)){
                                oidRight = oid;
                            }
                        }
                    }else if(CtFormatUtil.hasContent(partVersionRight)){
                        oidRight = partVersionRight;
                    }
                    if(CtFormatUtil.hasContent(oidRight)){
                        ctBaselineBoRight = ctBaselineQueryService.searchChildChange(oidRight, dateFormat);
                    }
                }
                if(null == ctBaselineBoRight){
                    throw new Exception("根据右侧的条件找不到对应的物料版本！");
                }
                //生成excel
                workbook = ctBaselineQueryService.exportCompareResult(ctBaselineBoLeft, ctBaselineBoRight);
                workbook.write(response.getOutputStream());
            }
        } catch (Exception e) {
            logger.error("导出基线BOM差异异常:", e);
            throw new Exception("导出基线BOM差异异常：" + e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
            if(null != workbook){
                //workbook.close();
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(inputStreamReader != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

}
