package ext.plm.bom.baselineQuery.bo;

import java.util.ArrayList;
import java.util.List;

public class CtBaselineBo {
    private String id;
    private String partNumber;//物料编号
    private String partView;//视图
    private String partVersion;//版本
    private String internalVersion;//内部版本
    private String partState;//状态
    private String transitionTime;//版本转变时间
    private String partName;//物料描述
    private String consumption;//用量
    private String unit;//单位
    private String tagNumber;//位号
    private String bomRemarks;//BOM备注
    private Long partOid;//物料ida2a2

    //部件url
    private String partUrl;
    //子项 ext树规定的属性
    private List<CtBaselineBo> children = new ArrayList<>();
    //是否展开 ext树规定的属性
    private boolean expanded;
    //是否是叶子节点 ext树规定的属性
    private boolean leaf;
    //节点图标样式 ext树规定的属性
    private String iconCls;

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof CtBaselineBo){
            CtBaselineBo ctBaselineBo = (CtBaselineBo) obj;
            if(this.partNumber.equals(ctBaselineBo.getPartNumber())){
                return true;
            }
            return false;
        }
        return super.equals(obj);
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartView() {
        return partView;
    }

    public void setPartView(String partView) {
        this.partView = partView;
    }

    public String getPartVersion() {
        return partVersion;
    }

    public void setPartVersion(String partVersion) {
        this.partVersion = partVersion;
    }

    public String getInternalVersion() {
        return internalVersion;
    }

    public void setInternalVersion(String internalVersion) {
        this.internalVersion = internalVersion;
    }

    public String getPartState() {
        return partState;
    }

    public void setPartState(String partState) {
        this.partState = partState;
    }

    public String getTransitionTime() {
        return transitionTime;
    }

    public void setTransitionTime(String transitionTime) {
        this.transitionTime = transitionTime;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getConsumption() {
        return consumption;
    }

    public void setConsumption(String consumption) {
        this.consumption = consumption;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getTagNumber() {
        return tagNumber;
    }

    public void setTagNumber(String tagNumber) {
        this.tagNumber = tagNumber;
    }

    public String getBomRemarks() {
        return bomRemarks;
    }

    public void setBomRemarks(String bomRemarks) {
        this.bomRemarks = bomRemarks;
    }

    public String getPartUrl() {
        return partUrl;
    }

    public void setPartUrl(String partUrl) {
        this.partUrl = partUrl;
    }

    public List<CtBaselineBo> getChildren() {
        return children;
    }

    public void setChildren(List<CtBaselineBo> children) {
        this.children = children;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    public boolean isLeaf() {
        return leaf;
    }

    public void setLeaf(boolean leaf) {
        this.leaf = leaf;
    }

    public String getIconCls() {
        return iconCls;
    }

    public void setIconCls(String iconCls) {
        this.iconCls = iconCls;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getPartOid() {
        return partOid;
    }

    public void setPartOid(Long partOid) {
        this.partOid = partOid;
    }
}
