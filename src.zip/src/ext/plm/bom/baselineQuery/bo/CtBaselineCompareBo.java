package ext.plm.bom.baselineQuery.bo;

import java.util.ArrayList;
import java.util.List;

public class CtBaselineCompareBo {
    private Integer level;//层级
    private String partNumberLeft;//编号
    private String partNameLeft;//名称
    private String partVersionLeft;//版本
    private String partStateLeft;//状态
    private String defaultUnitLeft;//默认单位
    private String quantityLeft;//数量
    private String tagNumberLeft;//位号
    private String bomRemarksLeft;//BOM备注

    private String partNumberRight;//编号
    private String partNameRight;//名称
    private String partVersionRight;//版本
    private String partStateRight;//状态
    private String defaultUnitRight;//默认单位
    private String quantityRight;//数量
    private String tagNumberRight;//位号
    private String bomRemarksRight;//BOM备注
    private List<CtBaselineCompareBo> children = new ArrayList<>();

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getPartNumberLeft() {
        return partNumberLeft;
    }

    public void setPartNumberLeft(String partNumberLeft) {
        this.partNumberLeft = partNumberLeft;
    }

    public String getPartNameLeft() {
        return partNameLeft;
    }

    public void setPartNameLeft(String partNameLeft) {
        this.partNameLeft = partNameLeft;
    }

    public String getPartVersionLeft() {
        return partVersionLeft;
    }

    public void setPartVersionLeft(String partVersionLeft) {
        this.partVersionLeft = partVersionLeft;
    }

    public String getPartStateLeft() {
        return partStateLeft;
    }

    public void setPartStateLeft(String partStateLeft) {
        this.partStateLeft = partStateLeft;
    }

    public String getDefaultUnitLeft() {
        return defaultUnitLeft;
    }

    public void setDefaultUnitLeft(String defaultUnitLeft) {
        this.defaultUnitLeft = defaultUnitLeft;
    }

    public String getQuantityLeft() {
        return quantityLeft;
    }

    public void setQuantityLeft(String quantityLeft) {
        this.quantityLeft = quantityLeft;
    }

    public String getTagNumberLeft() {
        return tagNumberLeft;
    }

    public void setTagNumberLeft(String tagNumberLeft) {
        this.tagNumberLeft = tagNumberLeft;
    }

    public String getBomRemarksLeft() {
        return bomRemarksLeft;
    }

    public void setBomRemarksLeft(String bomRemarksLeft) {
        this.bomRemarksLeft = bomRemarksLeft;
    }

    public String getPartNumberRight() {
        return partNumberRight;
    }

    public void setPartNumberRight(String partNumberRight) {
        this.partNumberRight = partNumberRight;
    }

    public String getPartNameRight() {
        return partNameRight;
    }

    public void setPartNameRight(String partNameRight) {
        this.partNameRight = partNameRight;
    }

    public String getPartVersionRight() {
        return partVersionRight;
    }

    public void setPartVersionRight(String partVersionRight) {
        this.partVersionRight = partVersionRight;
    }

    public String getPartStateRight() {
        return partStateRight;
    }

    public void setPartStateRight(String partStateRight) {
        this.partStateRight = partStateRight;
    }

    public String getDefaultUnitRight() {
        return defaultUnitRight;
    }

    public void setDefaultUnitRight(String defaultUnitRight) {
        this.defaultUnitRight = defaultUnitRight;
    }

    public String getQuantityRight() {
        return quantityRight;
    }

    public void setQuantityRight(String quantityRight) {
        this.quantityRight = quantityRight;
    }

    public String getTagNumberRight() {
        return tagNumberRight;
    }

    public void setTagNumberRight(String tagNumberRight) {
        this.tagNumberRight = tagNumberRight;
    }

    public String getBomRemarksRight() {
        return bomRemarksRight;
    }

    public void setBomRemarksRight(String bomRemarksRight) {
        this.bomRemarksRight = bomRemarksRight;
    }

    public List<CtBaselineCompareBo> getChildren() {
        return children;
    }

    public void setChildren(List<CtBaselineCompareBo> children) {
        this.children = children;
    }
}
