package ext.plm.bom.baselineQuery.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import wt.org.WTUser;
import wt.session.SessionHelper;

import java.util.Date;
import java.util.UUID;

@TableName("ZBomBaselineTable")
public class CtBomBaselineBo {
    @TableId(type = IdType.INPUT)
    @TableField("ID")
    private String id;

    @TableField("PARENTOID")
    private Long parentOid;//父项oid
    @TableField("CHILDOID")
    private Long childOid;//子项oid

    @TableField("PARENTMASTERID")
    private Long parentMasterId;//父项masterId
    @TableField("CHILDMASTERID")
    private Long childMasterId;//子项masterId


    @TableField("CREATETIME")
    private Date createTime;//创建时间

    @TableField("CREATEUSER")
    private String createUser;//创建用户

    @TableField("MODIFYTIME")
    private Date modifyTime;//修改时间

    @TableField("MODIFYUSER")
    private String modifyUser;//修改用户

    public CtBomBaselineBo(){}

    public CtBomBaselineBo(Long parentOid, Long childOid) throws Exception {
        this.id = UUID.randomUUID().toString();
        this.parentOid = parentOid;
        this.childOid = childOid;
        WTUser currentUser = (WTUser) SessionHelper.manager.getPrincipal();
        this.createUser = currentUser.getName();
        this.modifyUser = currentUser.getName();
        this.createTime = new Date();
        this.modifyTime = new Date();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Long getParentOid() {
        return parentOid;
    }

    public void setParentOid(Long parentOid) {
        this.parentOid = parentOid;
    }

    public Long getChildOid() {
        return childOid;
    }

    public void setChildOid(Long childOid) {
        this.childOid = childOid;
    }

    public Long getParentMasterId() {
        return parentMasterId;
    }

    public void setParentMasterId(Long parentMasterId) {
        this.parentMasterId = parentMasterId;
    }

    public Long getChildMasterId() {
        return childMasterId;
    }

    public void setChildMasterId(Long childMasterId) {
        this.childMasterId = childMasterId;
    }
}
