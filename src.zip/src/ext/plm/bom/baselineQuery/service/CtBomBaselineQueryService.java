package ext.plm.bom.baselineQuery.service;

import wt.method.RemoteInterface;

@RemoteInterface
public interface CtBomBaselineQueryService {

}
