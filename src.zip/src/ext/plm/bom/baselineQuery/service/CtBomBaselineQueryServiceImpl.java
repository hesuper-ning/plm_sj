package ext.plm.bom.baselineQuery.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.baselineQuery.bo.CtBomBaselineBo;
import ext.plm.bom.baselineQuery.mapper.CtBomBaselineBoMapper;
import ext.plm.common.CtConstant;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.vc.wip.WorkInProgressHelper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class CtBomBaselineQueryServiceImpl extends ServiceImpl<CtBomBaselineBoMapper, CtBomBaselineBo> implements CtBomBaselineQueryService {
    static Logger logger = Logger.getLogger(CtBomBaselineQueryServiceImpl.class);

    public static List<CtBomBaselineBo> queryLinkByChild(Long childOid) throws Exception {
        EntityWrapper<CtBomBaselineBo> wrapper = new EntityWrapper<>();
        wrapper.and().eq(("childOid"), childOid);
        CtBomBaselineBoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtBomBaselineBoMapper.class);
        return mapper.selectList(wrapper);
    }

    public static List<CtBomBaselineBo> queryLinkByChild(Long childMasterId, Date endDate) throws Exception {
        EntityWrapper<CtBomBaselineBo> wrapper = new EntityWrapper<>();
        wrapper.and().eq(("childMasterId"), childMasterId);
        endDate = CtDateUtil.addDays(endDate, 1);//由于前端选择的日期是0点，所以要查到等于这个日期的数据，还得加1天
        wrapper.and().le(("createTime"), endDate);
        CtBomBaselineBoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtBomBaselineBoMapper.class);
        return mapper.selectList(wrapper);
    }

    public static void saveBomBaselineLink(WTPart parentPart) throws Exception {
        CtBomBaselineBoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtBomBaselineBoMapper.class);
        //保存
        List<CtBomBaselineBo> boList = new ArrayList<>();
        //查询已有
        EntityWrapper<CtBomBaselineBo> wrapper = new EntityWrapper<>();
        Long parentOid = parentPart.getPersistInfo().getObjectIdentifier().getId();
        wrapper.and().eq(("parentOid"), parentOid);
        List<CtBomBaselineBo> list = mapper.selectList(wrapper);
        //如果存过，就不存了
        if(!CtFormatUtil.hasContent(list)){
            addLinks(parentPart, boList, mapper, parentPart.getViewName());
        }
        //保存bom父子项小版本的关系
        for(CtBomBaselineBo bo : boList){
            mapper.insert(bo);
        }
    }

    /**
     * 递归收集BOM下的所有子BOM
     * @param part
     * @param boList
     * @param mapper
     * @param topViewName
     * @throws Exception
     */
    public static void addLinks(WTPart part, List<CtBomBaselineBo> boList, CtBomBaselineBoMapper mapper, String topViewName) throws Exception{
        Long parentOid = part.getPersistInfo().getObjectIdentifier().getId();
        Long parentMasterId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
        QueryResult qr = PersistenceHelper.manager.navigate(part, "uses", WTPartUsageLink.class, false);
        while (qr.hasMoreElements()) {
            WTPartUsageLink partUsageLink = (WTPartUsageLink) qr.nextElement();
            WTPartMaster partMaster = (WTPartMaster) partUsageLink.getUses();
            //WTPart partChild = (WTPart) CtVersionUtil.getLatest(partMaster);
            String childNumber = partMaster.getNumber();
            //按视图取最新版
            WTPart partChild = CtPartUtil.getPartByNumber(childNumber, topViewName);
            if(null == partChild){
                if(CtConstant.VIEW_DESIGN.equals(topViewName)){
                    partChild = CtPartUtil.getPartByNumber(childNumber, CtConstant.VIEW_MANUFACTURING);
                }else{
                    partChild = CtPartUtil.getPartByNumber(childNumber, CtConstant.VIEW_DESIGN);
                }
            }
            if(null == partChild){
                continue;
            }
            //如果是副本，则跳过
            if (WorkInProgressHelper.isWorkingCopy(partChild)) {
                continue;
            }
            Long childOid = partChild.getPersistInfo().getObjectIdentifier().getId();
            Long childMasterId = partChild.getMaster().getPersistInfo().getObjectIdentifier().getId();
            //如果存过这个子项，则跳过
            EntityWrapper<CtBomBaselineBo> wrapper = new EntityWrapper<>();
            wrapper.and().eq(("parentOid"), parentOid).eq("childMasterId", childMasterId);
            List<CtBomBaselineBo> list = mapper.selectList(wrapper);
            if(CtFormatUtil.hasContent(list)){
                continue;
            }
            CtBomBaselineBo bo = new CtBomBaselineBo(parentOid, childOid);
            bo.setParentMasterId(parentMasterId);
            bo.setChildMasterId(childMasterId);
            boList.add(bo);
            //如果存过，就不继续展开存了
            EntityWrapper<CtBomBaselineBo> wrapper2 = new EntityWrapper<>();
            wrapper2.and().eq(("parentOid"), parentOid);
            List<CtBomBaselineBo> list2 = mapper.selectList(wrapper2);
            if(!CtFormatUtil.hasContent(list2)){
                addLinks(partChild, boList, mapper, topViewName);
            }
        }
    }
}

