package ext.plm.bom.baselineQuery.service;

import ext.plm.bom.baselineQuery.bo.CtBaselineBo;
import org.apache.poi.ss.usermodel.Workbook;
import wt.method.RemoteInterface;

import java.text.SimpleDateFormat;

@RemoteInterface
public interface CtBaselineQueryService {
    //查询使用关系
    CtBaselineBo searchUseRelationship(String oid, String dateStart, String dateEnd, String view, SimpleDateFormat dateFormat) throws Exception;
    //查询子项变动
    CtBaselineBo searchChildChange(String oid, String dateStart, String dateEnd, String view, SimpleDateFormat dateFormat) throws Exception;
    //查询子项变动(新)
    CtBaselineBo searchChildChange(String oid, SimpleDateFormat dateFormat) throws Exception;
    //下载页面数据
    Workbook exportPageData(String data, boolean exportParent) throws Exception;
    //导出比对结果
    Workbook exportCompareResult(CtBaselineBo bo1, CtBaselineBo bo2) throws Exception;
}
