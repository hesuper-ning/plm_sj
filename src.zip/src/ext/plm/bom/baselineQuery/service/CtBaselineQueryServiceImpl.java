package ext.plm.bom.baselineQuery.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.bom.baselineQuery.CtBaselineQuery;
import ext.plm.bom.baselineQuery.bo.CtBaselineBo;
import ext.plm.bom.baselineQuery.bo.CtBaselineCompareBo;
import ext.plm.bom.baselineQuery.bo.CtBomBaselineBo;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.part.config.CtPartConstant;
import ext.plm.util.*;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;
import wt.fc.QueryResult;
import wt.part.*;
import wt.util.WTProperties;
import wt.vc.VersionControlHelper;
import wt.vc.struct.StructHelper;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class CtBaselineQueryServiceImpl implements CtBaselineQueryService {
    static Logger logger = Logger.getLogger(CtBaselineQueryServiceImpl.class);

    /**
     * 搜索使用关系记录
     * @param oid
     * @param dateStart
     * @param dateEnd
     * @param view
     * @return
     * @throws Exception
     */
    @Override
    public CtBaselineBo searchUseRelationship(String oid, String dateStart, String dateEnd, String view, SimpleDateFormat dateFormat) throws Exception {
        CtBaselineBo ctBaselineBo = null;
        Date startDate = null;
        Date endDate = null;
        if(CtFormatUtil.hasContent(dateStart)){
            startDate = dateFormat.parse(dateStart);
        }
        if(CtFormatUtil.hasContent(dateEnd)){
            endDate = dateFormat.parse(dateEnd);
        }
        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
        if(null != part){
            ctBaselineBo = getBoByPart(part, dateFormat);
            getParentParts2(part, startDate, endDate, dateFormat, ctBaselineBo, view);
        }
        return ctBaselineBo;
    }

    /**
     * 搜索子项变动
     * @param oid
     * @param dateStart
     * @param dateEnd
     * @param view
     * @return
     * @throws Exception
     */
    @Override
    public CtBaselineBo searchChildChange(String oid, String dateStart, String dateEnd, String view, SimpleDateFormat dateFormat) throws Exception {
        CtBaselineBo ctBaselineBo = null;
        //Date transitionDate = dateFormat.parse(date);
        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
        if(null != part){
            ctBaselineBo = getBoByPart(part, dateFormat);
            long startTime = System.currentTimeMillis();
            //getChildParts(part, transitionDate, dateFormat, ctBaselineBo, view);
            Long parentOid = part.getPersistInfo().getObjectIdentifier().getId();
            CtBaselineQuery query = new CtBaselineQuery();
            getChildParts(parentOid, dateStart, dateEnd, ctBaselineBo, view, query, dateFormat);
            logger.debug(">>>>>>searchChildChange:" + (System.currentTimeMillis()-startTime));
        }
        return ctBaselineBo;
    }

    /**
     * 组装bo数据
     * @param part
     * @return
     * @throws Exception
     */
    public static CtBaselineBo getBoByPart(WTPart part, SimpleDateFormat dateFormat) throws Exception {
        CtBaselineBo ctBaselineBo = new CtBaselineBo();
        ctBaselineBo.setId(UUID.randomUUID().toString());
        ctBaselineBo.setExpanded(true);
        if(null != part){
            ctBaselineBo.setPartOid(part.getPersistInfo().getObjectIdentifier().getId());
            ctBaselineBo.setPartNumber(part.getNumber());//物料编号
            ctBaselineBo.setPartVersion(part.getVersionInfo().getIdentifier().getValue()+"."
                    +part.getIterationInfo().getIdentifier().getValue());//版本
            ctBaselineBo.setPartView(part.getViewName());//视图
            IBAUtil ibaUtil = new IBAUtil(part);
            String internalVersion = ibaUtil.getIBAValue(CtPartConstant.IBA_BAN_CI);
            if(CtFormatUtil.hasContent(internalVersion)){
                ctBaselineBo.setInternalVersion(internalVersion);
            }
            ctBaselineBo.setPartState(part.getLifeCycleState().getDisplay(Locale.CHINA));
            ctBaselineBo.setTransitionTime(dateFormat.format(part.getModifyTimestamp()));
            ctBaselineBo.setPartName(part.getName());
            if(part.isEndItem()){
                //成品的图标
                ctBaselineBo.setIconCls("icon-prod");
            }else{
                //部件的图标
                ctBaselineBo.setIconCls("icon-part");
            }
            String url = CtFormatUtil.getURL(part, part.getNumber());
            ctBaselineBo.setPartUrl(url);
        }
        return ctBaselineBo;
    }

    /**
     * 组装子项bo数据
     * @param qrLink
     * @param part
     * @param dateFormat
     * @return
     * @throws Exception
     */
    public static CtBaselineBo getBoByPartAndLink(WTPartUsageLink qrLink, WTPart part, SimpleDateFormat dateFormat) throws Exception {
        CtBaselineBo ctBaselineBo = getBoByPart(part, dateFormat);
        if(null != qrLink){
            //用量 单位
            Quantity quantity = qrLink.getQuantity();
            if(null != quantity) {
                ctBaselineBo.setUnit(quantity.getUnit().getDisplay(Locale.CHINA));
                ctBaselineBo.setConsumption(String.valueOf(quantity.getAmount()));
            }
            //位号
            String tagNumber = CtBomUtil.getReferenceDesignator2(qrLink);
            ctBaselineBo.setTagNumber(tagNumber);
            //BOM备注
            IBAUtil ibaUtil = new IBAUtil(qrLink);
            String bomNote = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_bomNotes);
            if(CtFormatUtil.hasContent(bomNote)){
                ctBaselineBo.setBomRemarks(bomNote);
            }
        }
        return ctBaselineBo;
    }

    /**
     * 查父项
     * @param childPart
     * @param startDate
     * @param endDate
     * @param dateFormat
     * @param view
     * @throws Exception
     */
    public static void getParentParts(WTPart childPart, Date startDate, Date endDate,
                                      SimpleDateFormat dateFormat, CtBaselineBo ctBaselineBo, String view) throws Exception {
        List<CtBaselineBo> childList = ctBaselineBo.getChildren();
        QueryResult qr = StructHelper.service.navigateUsedBy(childPart.getMaster());
        while (qr.hasMoreElements()) {
            Object obj = qr.nextElement();
            if (obj instanceof WTPart) {
                WTPart part = (WTPart) obj;
//                if(!view.equals(part.getViewName())){
//                    continue;
//                }
                String version = part.getVersionInfo().getIdentifier().getValue()+"."+part.getIterationInfo().getIdentifier().getValue();
                Date formatDate = dateFormat.parse(dateFormat.format(part.getModifyTimestamp()));
                if(null != startDate){
                    if(startDate.getTime() > formatDate.getTime()){
                        continue;
                    }
                }
                if(null != endDate){
                    if(endDate.getTime() < formatDate.getTime()){
                        continue;
                    }
                }
                //装到BO中
                CtBaselineBo parentBo = getBoByPart(part, dateFormat);
                //添加到集合
                addBoToList(view, childList, parentBo);
                //递归
                getParentParts(part, startDate, endDate, dateFormat, parentBo, view);
            }
        }
    }

    /**
     * 查父项
     * @param childPart
     * @param startDate
     * @param endDate
     * @param dateFormat
     * @param view
     * @throws Exception
     */
    public static void getParentParts2(WTPart childPart, Date startDate, Date endDate,
                                       SimpleDateFormat dateFormat, CtBaselineBo ctBaselineBo, String view) throws Exception {
        List<CtBaselineBo> childList = ctBaselineBo.getChildren();
        Long childOid = childPart.getPersistInfo().getObjectIdentifier().getId();
        Long childMasterId = childPart.getMaster().getPersistInfo().getObjectIdentifier().getId();
        List<CtBomBaselineBo> ctBomBaselineBoList = new ArrayList<>();
        if(null != endDate){
            ctBomBaselineBoList = CtBomBaselineQueryServiceImpl.queryLinkByChild(childMasterId, endDate);
        }else{
            ctBomBaselineBoList = CtBomBaselineQueryServiceImpl.queryLinkByChild(childOid);
        }
        for (CtBomBaselineBo bo : ctBomBaselineBoList) {
            Long parentOid = bo.getParentOid();
            WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPart:" + parentOid);
            if(null == part){
                logger.info(">>>>>getParentParts2 无效的物料id:" + parentOid);
                continue;
            }
            //装到BO中
            CtBaselineBo parentBo = getBoByPart(part, dateFormat);
            //添加到集合
            addBoToList(view, childList, parentBo);
            //递归
            getParentParts2(part, startDate, endDate, dateFormat, parentBo, view);
        }
    }

    /**
     * 查子项
     * @param fatherPart
     * @param transitionDate
     * @param dateFormat
     * @param view
     * @throws Exception
     */
    public static void getChildParts(WTPart fatherPart, Date transitionDate,
                                     SimpleDateFormat dateFormat, CtBaselineBo ctBaselineBo, String view) throws Exception {
        List<CtBaselineBo> childList = ctBaselineBo.getChildren();
        long startTime = System.currentTimeMillis();
        QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
        while (qr.hasMoreElements()) {
            WTPartUsageLink qrLink = (WTPartUsageLink) qr.nextElement();
            WTPartMaster childPartMaster = (WTPartMaster) qrLink.getUses();
            QueryResult queryResult = VersionControlHelper.service.allIterationsOf(childPartMaster);
            logger.error(">>>>getChildParts 查所有版本耗时:"+ (System.currentTimeMillis()-startTime));
            while(queryResult.hasMoreElements()) {
                WTPart part = (WTPart) queryResult.nextElement();
                Date formatDate = dateFormat.parse(dateFormat.format(part.getModifyTimestamp()));
                if(transitionDate.getTime() < formatDate.getTime()){
                    continue;
                }
                //装到BO中
                CtBaselineBo parentBo = getBoByPartAndLink(qrLink, part, dateFormat);
                logger.error(">>>>getChildParts 装BO耗时:" + (System.currentTimeMillis()-startTime));
                //添加到集合
                addBoToList(view, childList, parentBo);
                logger.error(">>>>getChildParts 添加到集合耗时:" + (System.currentTimeMillis()-startTime));
                //递归
                getChildParts(part, transitionDate, dateFormat, parentBo, view);
            }
        }
    }

    /**
     * sql优化性能，查符合条件的子项
     * @param parentOid
     * @param dateStart
     * @param dateEnd
     * @param ctBaselineBo
     * @param view
     * @param query
     * @throws Exception
     */
    public static void getChildParts(Long parentOid, String dateStart, String dateEnd, CtBaselineBo ctBaselineBo, String view, CtBaselineQuery query, SimpleDateFormat dateFormat) throws Exception {
        List<CtBaselineBo> childList = ctBaselineBo.getChildren();
        Set<String> childNumberSet = new HashSet<>();//用于记录通过时间条件筛选出来的子项编号
        //往集合里添加符合条件的子项
        query.queryMeetCriteriaChild(parentOid, dateStart, dateEnd, childList, view, dateFormat, childNumberSet);
        //子项没有符合条件的版本，则补上最新版本
        Map<String, Map<String, String>> allChildMap = query.queryMeetCriteriaChild2(parentOid, view);
        for(Map.Entry<String, Map<String, String>> entry : allChildMap.entrySet()){
            if(childNumberSet.contains(entry.getKey())){
                continue;
            }
            Map<String, String> infoMap = entry.getValue();
            String partOid = infoMap.get("partOid");
            String linkOid = infoMap.get("linkOid");
            WTPart childPart = (WTPart) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPart:" + partOid);
            WTPartUsageLink link = (WTPartUsageLink) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPartUsageLink:" + linkOid);
            //装到BO中
            CtBaselineBo parentBo = CtBaselineQueryServiceImpl.getBoByPartAndLink(link, childPart, dateFormat);
            //装入最新版本子项
            childList.add(parentBo);
        }
        //递归
        if(CtFormatUtil.hasContent(childList)){
            for(CtBaselineBo bo : childList){
                getChildParts(bo.getPartOid(), dateStart, dateEnd, bo, view, query, dateFormat);
            }
        }
    }

    /**
     * 添加到集合
     * @param view
     * @param childList
     * @param parentBo
     * @throws Exception
     */
    public static void addBoToList(String view, List<CtBaselineBo> childList, CtBaselineBo parentBo) throws Exception {
        String partNumber = parentBo.getPartNumber();
        boolean needReplace = false;
        boolean has = false;
        Iterator<CtBaselineBo> it = childList.iterator();
        while(it.hasNext()){
            CtBaselineBo bo = it.next();
            if(bo.getPartNumber().equals(partNumber)){
                has = true;
                if(compare(bo, parentBo, view) < 0){
                    needReplace = true;
                    it.remove();
                }
                break;
            }
        }
        if(needReplace || !has){
            childList.add(parentBo);
        }
    }

    /**
     * 比对视图和版本，返回正数时，保留s1
     * @param s1
     * @param s2
     * @param view
     * @return
     */
    public static int compare(CtBaselineBo s1, CtBaselineBo s2, String view) {
        String viewName1 = s1.getPartView();
        String viewName2 = s2.getPartView();
        String[] versionInfo1 = s1.getPartVersion().split("[.]");
        String[] versionInfo2 = s2.getPartVersion().split("[.]");
        String version1 = versionInfo1[0];
        String version2 = versionInfo2[0];
        int iteration1 = Integer.parseInt(versionInfo1[1]);
        int iteration2 = Integer.parseInt(versionInfo2[1]);
        if(viewName1.equals(viewName2)){
            if(version1.equals(version2)){
                return iteration1 - iteration2;
            }else{
                char c1 = version1.charAt(0);
                char c2 = version2.charAt(0);
                int i1 = (int)c1;
                int i2 = (int)c2;
                return i1 - i2;
            }
        }else{
            if(view.equals(viewName1)){
                return 1;
            }
            if(view.equals(viewName2)){
                return -1;
            }
        }
        return 0;
    }

    /**
     * 导出数据
     * @param bomData
     * @return
     * @throws Exception
     */
    @Override
    public Workbook exportPageData(String bomData, boolean exportParent) throws Exception {
        FileInputStream fileInputStream = null;
        Workbook workbook = null;
        try{
            String templateName = "";
            if(exportParent){
                templateName = "物料使用关系记录导出模板.xlsx";
            }else{
                templateName = "物料子项变动记录导出模板.xlsx";
            }
            WTProperties wtProperty = WTProperties.getLocalProperties();
            String path = wtProperty.getProperty("wt.home") + File.separator + "codebase" + File.separator + "ext" + File.separator +
                    "plm" + File.separator + "templates" + File.separator + templateName;

            fileInputStream = new FileInputStream(path);
            workbook = WorkbookFactory.create(fileInputStream);
            Sheet sheet = workbook.getSheetAt(0);
            //处理前端传过来的数据，json字符串转成java对象
            JSONArray parentPartArray = JSONArray.parseArray(bomData);
            Map<String, Integer> rowIndexMap = new HashMap<>();
            rowIndexMap.put("rowIndex", 0);
            for(int i = 0;i < parentPartArray.size();i++){
                JSONObject parentPart = parentPartArray.getJSONObject(i);
                //写入数据
                //行数加1
                rowIndexMap.put("rowIndex", rowIndexMap.get("rowIndex")+1);
                writeRowData(parentPart, sheet, rowIndexMap, 0, exportParent);
            }
        }finally {
            if (null != fileInputStream) {
                fileInputStream.close();
            }
        }
        return workbook;
    }

    /**
     * 导出excel
     * @param parentPart 前端传过来的树形数据
     * @param sheet 工作薄
     * @param rowIndexMap 行数
     * @param level 层次，用于缩进编号，导出能看到树的效果
     * @throws Exception
     */
    public void writeRowData(JSONObject parentPart, Sheet sheet, Map<String, Integer> rowIndexMap, int level, boolean exportParent) throws Exception {
        //写入父项
        writeCellData(parentPart, sheet, rowIndexMap, level, exportParent);
        //子项
        JSONArray childArray = parentPart.getJSONArray("children");
        if(CtFormatUtil.hasContent(childArray)){
            level++;
            for(int i = 0;i < childArray.size();i++){
                //行数加1
                rowIndexMap.put("rowIndex", rowIndexMap.get("rowIndex")+1);
                //递归写入子项
                JSONObject childPart = childArray.getJSONObject(i);
                writeRowData(childPart, sheet, rowIndexMap, level, exportParent);
            }
        }
    }

    /**
     * 单行数据的写入
     * @param part
     * @param sheet
     * @param rowIndexMap
     * @param level
     * @throws Exception
     */
    public void writeCellData(JSONObject part, Sheet sheet, Map<String, Integer> rowIndexMap, int level, boolean exportParent) throws Exception {
        int rowIndex = rowIndexMap.get("rowIndex");
        Row row = sheet.getRow(rowIndex);
        if(null == row){
            row = sheet.createRow(rowIndex);
        }
        //在子项编号前面添加空格，通过这种缩进的方式，展示数形结构
        StringBuilder numberBuilder = new StringBuilder();
        for(int i = 0;i< level;i++){
            numberBuilder.append("    ");
        }
        numberBuilder.append(part.getString("partNumber"));
        //物料编号
        CtExcelReadUtil.setExcelCellValue(0, numberBuilder.toString(), row);
        //视图
        CtExcelReadUtil.setExcelCellValue(1, part.getString("partView"), row);
        //版本
        CtExcelReadUtil.setExcelCellValue(2, part.getString("partVersion"), row);
        //内部版本
        CtExcelReadUtil.setExcelCellValue(3, part.getString("internalVersion"), row);
        //状态
        CtExcelReadUtil.setExcelCellValue(4, part.getString("partState"), row);
        //版本转变时间
        CtExcelReadUtil.setExcelCellValue(5, part.getString("transitionTime"), row);
        //物料描述
        CtExcelReadUtil.setExcelCellValue(6, part.getString("partName"), row);

        //导子项时多几列
        if(!exportParent){
            //用量
            CtExcelReadUtil.setExcelCellValue(7, part.getString("consumption"), row);
            //单位
            CtExcelReadUtil.setExcelCellValue(8, part.getString("unit"), row);
            //位号
            CtExcelReadUtil.setExcelCellValue(9, part.getString("tagNumber"), row);
            //BOM备注
            CtExcelReadUtil.setExcelCellValue(10, part.getString("bomRemarks"), row);
        }
    }

    @Override
    public Workbook exportCompareResult(CtBaselineBo bo1, CtBaselineBo bo2) throws Exception {
        FileInputStream fileInputStream = null;
        Workbook workbook = null;
        try{
            String templateName = "BOM基线记录比较导出模板.xlsx";
            WTProperties wtProperty = WTProperties.getLocalProperties();
            String path = wtProperty.getProperty("wt.home") + File.separator + "codebase" + File.separator + "ext" + File.separator +
                    "plm" + File.separator + "templates" + File.separator + templateName;
            fileInputStream = new FileInputStream(path);
            workbook = WorkbookFactory.create(fileInputStream);
            Sheet sheet = workbook.getSheetAt(0);

            //给用于导出的bo赋值
            CtBaselineCompareBo topBo = setCtBaselineCompareBo(bo1, bo2, 0);
            Map<String, Integer> levelMap = new HashMap<>();
            levelMap.put("level", 0);
            generateCompareBo(bo1, bo2, levelMap, topBo);

            //红色字体
            CellStyle redCellStyle = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setColor(IndexedColors.RED.index);
            redCellStyle.setFont(font);

            //写入表头数据
            //编号
            Row row = sheet.getRow(0);
            if(null == row){
                row = sheet.createRow(0);
            }
            if(compareDifference(bo1.getPartNumber(), bo2.getPartNumber())){
                CtExcelReadUtil.setExcelCellValue(1, bo1.getPartNumber(), row);
                CtExcelReadUtil.setExcelCellValue(10, bo2.getPartNumber(), row);
            }else{
                setExcelCellValue(1, bo1.getPartNumber(), row, redCellStyle);
                setExcelCellValue(10, bo2.getPartNumber(), row, redCellStyle);
            }

            //名称
            row = sheet.getRow(1);
            if(null == row){
                row = sheet.createRow(1);
            }
            if(compareDifference(bo1.getPartName(), bo2.getPartName())){
                CtExcelReadUtil.setExcelCellValue(1, bo1.getPartName(), row);
                CtExcelReadUtil.setExcelCellValue(10, bo2.getPartName(), row);
            }else{
                setExcelCellValue(1, bo1.getPartName(), row, redCellStyle);
                setExcelCellValue(10, bo2.getPartName(), row, redCellStyle);
            }

            //视图
            row = sheet.getRow(2);
            if(null == row){
                row = sheet.createRow(2);
            }
            if(compareDifference(bo1.getPartView(), bo2.getPartView())){
                CtExcelReadUtil.setExcelCellValue(1, bo1.getPartView(), row);
                CtExcelReadUtil.setExcelCellValue(10, bo2.getPartView(), row);
            }else{
                setExcelCellValue(1, bo1.getPartView(), row, redCellStyle);
                setExcelCellValue(10, bo2.getPartView(), row, redCellStyle);
            }

            //版本
            row = sheet.getRow(3);
            if(null == row){
                row = sheet.createRow(3);
            }
            if(compareDifference(bo1.getPartVersion(), bo2.getPartVersion())){
                CtExcelReadUtil.setExcelCellValue(1, bo1.getPartVersion(), row);
                CtExcelReadUtil.setExcelCellValue(10, bo2.getPartVersion(), row);
            }else{
                setExcelCellValue(1, bo1.getPartVersion(), row, redCellStyle);
                setExcelCellValue(10, bo2.getPartVersion(), row, redCellStyle);
            }
            //时间
            row = sheet.getRow(4);
            if(null == row){
                row = sheet.createRow(4);
            }
            if(compareDifference(bo1.getTransitionTime(), bo2.getTransitionTime())){
                CtExcelReadUtil.setExcelCellValue(1, bo1.getTransitionTime(), row);
                CtExcelReadUtil.setExcelCellValue(10, bo2.getTransitionTime(), row);
            }else{
                setExcelCellValue(1, bo1.getTransitionTime(), row, redCellStyle);
                setExcelCellValue(10, bo2.getTransitionTime(), row, redCellStyle);
            }

            //写入数据
            Map<String, Integer> rowIndexMap = new HashMap<>();
            rowIndexMap.put("rowIndex", 7);
            writeCompareRowData(topBo, sheet, rowIndexMap, redCellStyle);
        }finally {
            if (null != fileInputStream) {
                fileInputStream.close();
            }
        }
        return workbook;
    }


    /**
     * bo中的数据写入excel
     * @param topBo
     * @param sheet
     * @param rowIndexMap
     * @param redCellStyle
     * @throws Exception
     */
    public void writeCompareRowData(CtBaselineCompareBo topBo, Sheet sheet, Map<String, Integer> rowIndexMap, CellStyle redCellStyle) throws Exception {
        //写入父项
        writeCompareCellData(topBo, sheet, rowIndexMap, redCellStyle);
        //子项
        List<CtBaselineCompareBo> childList = topBo.getChildren();
        if(CtFormatUtil.hasContent(childList)){
            for(CtBaselineCompareBo childBo : childList){
                //行数加1
                rowIndexMap.put("rowIndex", rowIndexMap.get("rowIndex")+1);
                //递归写入子项
                writeCompareRowData(childBo, sheet, rowIndexMap, redCellStyle);
            }
        }
    }

    /**
     * 单行数据的写入
     * @param bo
     * @param sheet
     * @param rowIndexMap
     * @throws Exception
     */
    public void writeCompareCellData(CtBaselineCompareBo bo, Sheet sheet, Map<String, Integer> rowIndexMap, CellStyle redCellStyle) throws Exception {
        int rowIndex = rowIndexMap.get("rowIndex");
        Row row = sheet.getRow(rowIndex);
        if(null == row){
            row = sheet.createRow(rowIndex);
        }
        //在子项编号前面添加空格，通过这种缩进的方式，展示数形结构
        StringBuilder numberBuilderLeft = new StringBuilder();
        for(int i = 0;i< bo.getLevel();i++){
            numberBuilderLeft.append("    ");
        }
        if(CtFormatUtil.hasContent(bo.getPartNumberLeft())){
            numberBuilderLeft.append(bo.getPartNumberLeft());
        }
        StringBuilder numberBuilderRight = new StringBuilder();
        for(int i = 0;i< bo.getLevel();i++){
            numberBuilderRight.append("    ");
        }
        if(CtFormatUtil.hasContent(bo.getPartNumberRight())){
            numberBuilderRight.append(bo.getPartNumberRight());
        }
        //编号
        if(compareDifference(bo.getPartNumberLeft(), bo.getPartNumberRight())){
            CtExcelReadUtil.setExcelCellValue(0, numberBuilderLeft.toString(), row);
            CtExcelReadUtil.setExcelCellValue(9, numberBuilderRight.toString(), row);
        }else{
            setExcelCellValue(0, numberBuilderLeft.toString(), row, redCellStyle);
            setExcelCellValue(9, numberBuilderRight.toString(), row, redCellStyle);
        }
        //名称
        if(compareDifference(bo.getPartNameLeft(), bo.getPartNameRight())){
            CtExcelReadUtil.setExcelCellValue(1, bo.getPartNameLeft(), row);
            CtExcelReadUtil.setExcelCellValue(10, bo.getPartNameRight(), row);
        }else{
            setExcelCellValue(1, bo.getPartNameLeft(), row, redCellStyle);
            setExcelCellValue(10, bo.getPartNameRight(), row, redCellStyle);
        }
        //版本
        if(compareDifference(bo.getPartVersionLeft(), bo.getPartVersionRight())){
            CtExcelReadUtil.setExcelCellValue(2, bo.getPartVersionLeft(), row);
            CtExcelReadUtil.setExcelCellValue(11, bo.getPartVersionRight(), row);
        }else{
            setExcelCellValue(2, bo.getPartVersionLeft(), row, redCellStyle);
            setExcelCellValue(11, bo.getPartVersionRight(), row, redCellStyle);
        }
        //状态
        if(compareDifference(bo.getPartStateLeft(), bo.getPartStateRight())){
            CtExcelReadUtil.setExcelCellValue(3, bo.getPartStateLeft(), row);
            CtExcelReadUtil.setExcelCellValue(12, bo.getPartStateRight(), row);
        }else{
            setExcelCellValue(3, bo.getPartStateLeft(), row, redCellStyle);
            setExcelCellValue(12, bo.getPartStateRight(), row, redCellStyle);
        }
        //默认单位
        if(compareDifference(bo.getDefaultUnitLeft(), bo.getDefaultUnitRight())){
            CtExcelReadUtil.setExcelCellValue(4, bo.getDefaultUnitLeft(), row);
            CtExcelReadUtil.setExcelCellValue(13, bo.getDefaultUnitRight(), row);
        }else{
            setExcelCellValue(4, bo.getDefaultUnitLeft(), row, redCellStyle);
            setExcelCellValue(13, bo.getDefaultUnitRight(), row, redCellStyle);
        }
        //数量
        if(compareDifference(bo.getQuantityLeft(), bo.getQuantityRight())){
            CtExcelReadUtil.setExcelCellValue(5, bo.getQuantityLeft(), row);
            CtExcelReadUtil.setExcelCellValue(14, bo.getQuantityRight(), row);
        }else{
            setExcelCellValue(5, bo.getQuantityLeft(), row, redCellStyle);
            setExcelCellValue(14, bo.getQuantityRight(), row, redCellStyle);
        }
        //位号
        if(compareDifference(bo.getTagNumberLeft(), bo.getTagNumberRight())){
            CtExcelReadUtil.setExcelCellValue(6, bo.getTagNumberLeft(), row);
            CtExcelReadUtil.setExcelCellValue(15, bo.getTagNumberRight(), row);
        }else{
            setExcelCellValue(6, bo.getTagNumberLeft(), row, redCellStyle);
            setExcelCellValue(15, bo.getTagNumberRight(), row, redCellStyle);
        }
        //BOM备注
        if(compareDifference(bo.getBomRemarksLeft(), bo.getBomRemarksRight())){
            CtExcelReadUtil.setExcelCellValue(7, bo.getBomRemarksLeft(), row);
            CtExcelReadUtil.setExcelCellValue(16, bo.getBomRemarksRight(), row);
        }else{
            setExcelCellValue(7, bo.getBomRemarksLeft(), row, redCellStyle);
            setExcelCellValue(16, bo.getBomRemarksRight(), row, redCellStyle);
        }
    }

    /**
     * 比较值
     * @param value1
     * @param value2
     * @return
     * @throws Exception
     */
    public static boolean compareDifference(String value1, String value2) throws Exception {
        if(null != value1 && null != value2){
            return value1.equals(value2);
        }
        if((null == value1 && null != value2) || (null != value1 && null == value2)){
            return false;
        }
        return true;
    }

    /**
     * 设置excel单元格的值（红色字体样式）
     * @param cellNum
     * @param value
     * @param row
     */
    public static void setExcelCellValue(int cellNum, String value, Row row, CellStyle redCellStyle) {
        Cell cell = row.getCell(cellNum) ;
        if(cell == null){
            cell = row.createCell(cellNum);
        }
        cell.setCellStyle(redCellStyle);
        cell.setCellValue(value);
    }

    /**
     * 生成导出的bo
     * @param bo1
     * @param bo2
     * @param levelMap
     * @return
     * @throws Exception
     */
    public static void generateCompareBo(CtBaselineBo bo1, CtBaselineBo bo2, Map<String, Integer> levelMap, CtBaselineCompareBo compareBo) throws Exception {
        List<CtBaselineCompareBo> childBoList = compareBo.getChildren();
        int level = levelMap.get("level") + 1;
        levelMap.put("level", level);
        List<CtBaselineBo> childListLeft = new ArrayList<>();
        List<CtBaselineBo> childListRight = new ArrayList<>();
        if(null != bo1){
            childListLeft = bo1.getChildren();
        }
        if(null != bo2){
            childListRight = bo2.getChildren();
        }
        //交集 (保留childListLeft和childListRight中都有的元素)
        List<CtBaselineBo> intersection1 = new ArrayList<>(childListLeft);
        intersection1.retainAll(childListRight);
        List<CtBaselineBo> intersection2 = new ArrayList<>(childListRight);
        intersection2.retainAll(childListLeft);
        //右侧的数据放到map中，方便取到同料号的数据
        Map<String, CtBaselineBo> tempMap = new HashMap<>();
        for(CtBaselineBo ctBaselineBoRight : intersection2){
            tempMap.put(ctBaselineBoRight.getPartNumber(), ctBaselineBoRight);
        }
        for(int i = 0;i < intersection1.size();i++){
            CtBaselineBo ctBaselineBo1 = intersection1.get(i);
            CtBaselineBo ctBaselineBo2 = tempMap.get(ctBaselineBo1.getPartNumber());
            CtBaselineCompareBo ctBaselineCompareBo = setCtBaselineCompareBo(ctBaselineBo1, ctBaselineBo2, level);
            childBoList.add(ctBaselineCompareBo);
            //递归
            generateCompareBo(ctBaselineBo1, ctBaselineBo2, levelMap, ctBaselineCompareBo);
        }
        //差集 (在childListLeft中但不在childListRight中)
        List<CtBaselineBo> differenceList1 = new ArrayList<>(childListLeft);
        differenceList1.removeAll(childListRight);
        for(CtBaselineBo leftBo : differenceList1){
            CtBaselineCompareBo ctBaselineCompareBo = setCtBaselineCompareBo(leftBo, null, level);
            childBoList.add(ctBaselineCompareBo);
            //递归
            generateCompareBo(leftBo, null, levelMap, ctBaselineCompareBo);
        }
        //差集 (在childListRight中但不在childListLeft中)
        List<CtBaselineBo> differenceList2 = new ArrayList<>(childListRight);
        differenceList2.removeAll(childListLeft);
        for(CtBaselineBo rightBo : differenceList2){
            CtBaselineCompareBo ctBaselineCompareBo = setCtBaselineCompareBo(null, rightBo, level);
            childBoList.add(ctBaselineCompareBo);
            //递归
            generateCompareBo(null, rightBo, levelMap, ctBaselineCompareBo);
        }
    }

    /**
     * 设值到导出用的bo
     * @param bo1
     * @param bo2
     * @param level
     * @throws Exception
     */
    public static CtBaselineCompareBo setCtBaselineCompareBo(CtBaselineBo bo1, CtBaselineBo bo2, int level) throws Exception {
        CtBaselineCompareBo ctBaselineCompareBo = new CtBaselineCompareBo();
        ctBaselineCompareBo.setLevel(level);
        if(null != bo1){
            ctBaselineCompareBo.setPartNumberLeft(bo1.getPartNumber());
            ctBaselineCompareBo.setPartNameLeft(bo1.getPartName());
            ctBaselineCompareBo.setPartVersionLeft(bo1.getPartVersion());
            ctBaselineCompareBo.setPartStateLeft(bo1.getPartState());
            ctBaselineCompareBo.setDefaultUnitLeft(bo1.getUnit());
            ctBaselineCompareBo.setQuantityLeft(bo1.getConsumption());
            ctBaselineCompareBo.setTagNumberLeft(bo1.getTagNumber());
            ctBaselineCompareBo.setBomRemarksLeft(bo1.getBomRemarks());
        }

        if(null != bo2){
            ctBaselineCompareBo.setPartNumberRight(bo2.getPartNumber());
            ctBaselineCompareBo.setPartNameRight(bo2.getPartName());
            ctBaselineCompareBo.setPartVersionRight(bo2.getPartVersion());
            ctBaselineCompareBo.setPartStateRight(bo2.getPartState());
            ctBaselineCompareBo.setDefaultUnitRight(bo2.getUnit());
            ctBaselineCompareBo.setQuantityRight(bo2.getConsumption());
            ctBaselineCompareBo.setTagNumberRight(bo2.getTagNumber());
            ctBaselineCompareBo.setBomRemarksRight(bo2.getBomRemarks());
        }
        return ctBaselineCompareBo;
    }

    /**
     *
     * @param part
     * @return
     * @throws Exception
     */
    public static Date getEndDate(WTPart part) throws Exception {
        WTPart nextPart = getNextVersion(part);
        if(null != nextPart){
            String version = nextPart.getVersionInfo().getIdentifier().getValue()+"."+nextPart.getIterationInfo().getIdentifier().getValue();
            System.out.println(">>>>>>getEndDate nextPart:" + nextPart.getViewName() + version );
            return nextPart.getModifyTimestamp();
        }
        return new Date();
    }

    /**
     * 获取下一个版本的物料
     * @param part
     * @return
     * @throws Exception
     */
    public static WTPart getNextVersion(WTPart part) throws Exception {
        WTPart nextPart = null;
        QueryResult versionQr = VersionControlHelper.service.allIterationsOf(part.getMaster());
        while (versionQr.hasMoreElements()) {
            WTPart versionObj = (WTPart) versionQr.nextElement();
            if(versionObj.equals(part)){
                break;
            }else{
                if(part.getViewName().equals(versionObj.getViewName())){
                    nextPart = versionObj;
                }
            }
        }
        return nextPart;
    }

    /**
     * 搜索子项变动(新)
     * @param oid
     * @return
     * @throws Exception
     */
    @Override
    public CtBaselineBo searchChildChange(String oid, SimpleDateFormat dateFormat) throws Exception {
        CtBaselineBo ctBaselineBo = null;
        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
        if(null != part){
            ctBaselineBo = getBoByPart(part, dateFormat);
            CtBaselineQuery query = new CtBaselineQuery();
            getChildParts(ctBaselineBo, query, dateFormat);
        }
        return ctBaselineBo;
    }

    /**
     * 递归查子项(新)
     * @param ctBaselineBo
     * @param query
     * @param dateFormat
     * @throws Exception
     */
    public static void getChildParts(CtBaselineBo ctBaselineBo, CtBaselineQuery query, SimpleDateFormat dateFormat) throws Exception {
        query.queryChild(ctBaselineBo, dateFormat);
        List<CtBaselineBo> childList = ctBaselineBo.getChildren();
        for(CtBaselineBo childBo : childList){
            query.queryChild(childBo, dateFormat);
        }
    }

}

