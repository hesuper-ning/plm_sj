package ext.plm.bom.baselineQuery;

import ext.plm.bom.baselineQuery.bo.CtBaselineBo;
import ext.plm.bom.baselineQuery.service.CtBaselineQueryServiceImpl;
import ext.plm.common.CtConstant;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import wt.method.MethodContext;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.*;

public class CtBaselineQuery {
    static Logger logger = Logger.getLogger(CtBaselineQuery.class);

    /**
     * 按物料上次修改日期查询某时间内最新版本的物料id
     * @param viewName
     * @param partNumber
     * @param date
     * @return
     * @throws Exception
     */
    public String queryCompliesTimeOid(String viewName, String partNumber, String date) throws Exception {
        String oid = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT w2.IDA2A2, w2.VERSIONIDA2VERSIONINFO, w2.ITERATIONIDA2ITERATIONINFO FROM WTPART w2, WTPARTMASTER w, WTVIEW w3")
                    .append(" WHERE w2.IDA3MASTERREFERENCE = w.IDA2A2")
                    .append(" AND w2.IDA3VIEW = w3.IDA2A2")
                    .append(" AND w3.NAME = ?")
                    .append(" AND w.WTPARTNUMBER = ?")
                    .append(" AND TO_DATE(TO_CHAR(w2.MODIFYSTAMPA2, 'yyyy-mm-dd'), 'yyyy-mm-dd') <= TO_DATE(?, 'yyyy-mm-dd')")
                    .append(" ORDER BY w2.MODIFYSTAMPA2 DESC");
            logger.debug(">>>sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, viewName);
            statement.setString(2, partNumber);
            statement.setString(3, date);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                oid = "OR:wt.part.WTPart:" + rs.getLong(1);
            }
        } catch (Exception var12) {
            logger.error("按日期查询物料id异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return oid;
    }

    /**
     * 按保存BOM的时间，查询某时间内最新版本的物料id
     * @param viewName
     * @param partNumber
     * @param date
     * @return
     * @throws Exception
     */
    public String queryTheLastOid(String viewName, String partNumber, String date) throws Exception {
        String oid = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.IDA2A2, t.VERSIONIDA2VERSIONINFO, t.ITERATIONIDA2ITERATIONINFO")
                    .append(" FROM ZBOMBASELINETABLE z, wtpart t, WTPARTMASTER w, WTVIEW w2 WHERE 1=1")
                    .append(" AND w2.NAME = ?")
                    .append(" AND t.IDA3VIEW = w2.IDA2A2")
                    .append(" AND z.PARENTMASTERID = w.IDA2A2")
                    .append(" AND w.WTPARTNUMBER = ?")
                    .append(" AND t.IDA3MASTERREFERENCE = w.IDA2A2")
                    .append(" AND t.IDA2A2 = z.PARENTOID")
                    .append(" AND TO_DATE(TO_CHAR(z.CREATETIME, 'yyyy-mm-dd'), 'yyyy-mm-dd') <= TO_DATE(?, 'yyyy-mm-dd')")
                    .append(" ORDER BY t.VERSIONIDA2VERSIONINFO DESC, TO_NUMBER(t.ITERATIONIDA2ITERATIONINFO) DESC");
            logger.debug(">>>sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, viewName);
            statement.setString(2, partNumber);
            statement.setString(3, date);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                oid = "OR:wt.part.WTPart:" + rs.getLong(1);
            }
        } catch (Exception var12) {
            logger.error("按保存BOM的时间，查询某时间内最新版本的物料id异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return oid;
    }

    /**
     * 按料号和视图查所有版本
     * @param viewName
     * @param partNumber
     * @return
     * @throws Exception
     */
    public List<Map<String, String>> getPartVersion(String partNumber, String viewName) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.IDA2A2, t.VERSIONIDA2VERSIONINFO, t.ITERATIONIDA2ITERATIONINFO FROM wtpart t, WTPARTMASTER w, WTVIEW w2")
                    .append(" WHERE t.IDA3MASTERREFERENCE = w.IDA2A2")
                    .append(" AND w2.IDA2A2 = t.IDA3VIEW")
                    .append(" AND w2.NAME = ?")
                    .append(" AND w.WTPARTNUMBER = ?")
                    .append(" ORDER BY t.VERSIONIDA2VERSIONINFO, TO_NUMBER(t.ITERATIONIDA2ITERATIONINFO)");
            logger.debug(">>>sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, viewName);
            statement.setString(2, partNumber);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                String oid = "OR:wt.part.WTPart:" + rs.getLong(1);
                String version = rs.getString(2);
                String iteration = rs.getString(3);
                Map<String, String> map = new HashMap<>();
                map.put("partOid", oid);
                map.put("partVersion", version + "." + iteration);
                list.add(map);
            }
        } catch (Exception var12) {
            logger.error("按日期查询物料id异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return list;
    }

    /**
     * 按料号和视图查所有版本
     * @param viewName
     * @param partNumber
     * @return
     * @throws Exception
     */
    public List<Map<String, String>> getInternalVersion(String partNumber, String viewName) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        Map<String, List<String>> internalVersionMap = new TreeMap<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.IDA2A2, x.VALUE2 FROM WTPARTMASTER w, WTVIEW w2, wtpart t")
                    .append(" LEFT JOIN (")
                    .append(" SELECT s.IDA3A4, s.VALUE2 FROM STRINGVALUE s, STRINGDEFINITION s1 WHERE s.IDA3A6 = s1.IDA2A2 AND s1.NAME = 'ct_banci'")
                    .append(" ) x ON x.IDA3A4 = t.IDA2A2")
                    .append(" WHERE t.IDA3MASTERREFERENCE = w.IDA2A2")
                    .append(" AND w2.IDA2A2 = t.IDA3VIEW")
                    .append(" AND w2.NAME = ?")
                    .append(" AND w.WTPARTNUMBER = ?")
                    .append(" ORDER BY t.MODIFYSTAMPA2");
            logger.debug(">>>getInternalVersion sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, viewName);
            statement.setString(2, partNumber);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                String oid = "OR:wt.part.WTPart:" + rs.getLong(1);
                String internalVersion = rs.getString(2);
                if(CtFormatUtil.hasContent(internalVersion)){
                    List<String> oidList = new ArrayList<>();
                    if(internalVersionMap.containsKey(internalVersion)){
                        oidList = internalVersionMap.get(internalVersion);
                    }else{
                        oidList = new ArrayList<>();
                        internalVersionMap.put(internalVersion, oidList);
                    }
                    oidList.add(oid);
                }
            }
        } catch (Exception var12) {
            logger.error("按日期查询物料id异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        //组装数据
        for(Map.Entry<String, List<String>> entry : internalVersionMap.entrySet()){
            String internalVersion = entry.getKey();
            List<String> idList = entry.getValue();
            Map<String, String> map = new TreeMap<>();
            map.put("partOid", StringUtils.join(idList, ","));
            map.put("internalVersion", internalVersion);
            list.add(map);
        }
        return list;
    }

    /**
     * 按料号和视图查所有版本
     * @param partName
     * @param partNumber
     * @return
     * @throws Exception
     */
    public List<Map<String, String>> getPartNumberAndPartName(String partNumber, String partName) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT wpm.wtpartnumber,wpm.name FROM wtpart wp  ,WTPartMaster wpm  ")
                    .append(" WHERE wp.idA3masterReference = wpm.idA2A2  ")
                    .append(" and wp.LATESTITERATIONINFO = 1 ")
                    .append(" AND wp.VERSIONSORTIDA2VERSIONINFO = (SELECT max(w4.VERSIONSORTIDA2VERSIONINFO) FROM wcadmin.WTPART w4  ")
                    .append(" WHERE w4.IDA3MASTERREFERENCE = wp.IDA3MASTERREFERENCE AND w4.LATESTITERATIONINFO=1 AND w4.IDA3VIEW=wp.IDA3VIEW)")
                    .append(" and  wpm.wtpartnumber like ? ")
                    .append(" and  wpm.name like ? ")
                    .append(" and ROWNUM < 100 ");
            logger.debug(">>>getInternalVersion sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, "%"+partNumber+"%");
            statement.setString(2, "%"+partName+"%");
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                String number = rs.getString(1);
                String name = rs.getString(2);
                Map<String, String> map = new TreeMap<>();
                map.put("partNumber", number);
                map.put("partName", name);
                list.add(map);
            }
        } catch (Exception var12) {
            logger.error("按日期查询物料id异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return list;
    }

    /**
     * 查询符合条件的子项
     * @param parentOid
     * @param dateStart
     * @param dateEnd
     * @return
     * @throws Exception
     */
    public void queryMeetCriteriaChild(Long parentOid, String dateStart, String dateEnd, List<CtBaselineBo> childList, String view, SimpleDateFormat dateFormat
        , Set<String> childNumberSet) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT w2.WTPARTNUMBER , t.VERSIONIDA2VERSIONINFO, t.ITERATIONIDA2ITERATIONINFO, t.IDA2A2, w.IDA2A2")
                    .append(" FROM WTPARTUSAGELINK w, wtpart t ,WTPARTMASTER w2, WTVIEW w3  WHERE  1=1");
            if(CtConstant.VIEW_DESIGN.equals(view)){
                //D视图则直接取D视图的子项
                sql.append(" AND w3.IDA2A2 = t.IDA3VIEW AND w3.NAME = 'Design'");
            }else{
                //M视图则优先取M视图的子项
                sql.append(" AND t.IDA3VIEW = w3.IDA2A2")
                .append(" AND t.IDA3VIEW = (SELECT max(w6.IDA3VIEW) FROM wcadmin.WTPART w6 WHERE w6.IDA3MASTERREFERENCE = t.IDA3MASTERREFERENCE)");
            }
            sql.append(" AND t.IDA3MASTERREFERENCE = w2.IDA2A2")
                    .append(" AND t.IDA3MASTERREFERENCE = w.IDA3B5");
            if(CtFormatUtil.hasContent(dateStart)){
                sql.append(" AND TO_DATE(TO_CHAR(t.MODIFYSTAMPA2, 'yyyy-mm-dd'),'yyyy-mm-dd') >= TO_DATE(?, 'yyyy-mm-dd')");
            }
            if(CtFormatUtil.hasContent(dateEnd)){
                sql.append(" AND TO_DATE(TO_CHAR(t.MODIFYSTAMPA2, 'yyyy-mm-dd'),'yyyy-mm-dd') <= TO_DATE(?, 'yyyy-mm-dd')");
            }
            sql.append(" AND w.IDA3A5 = ?")
            .append(" ORDER BY w2.WTPARTNUMBER DESC, t.VERSIONIDA2VERSIONINFO DESC, TO_NUMBER(t.ITERATIONIDA2ITERATIONINFO) DESC");


            logger.debug(">>>getInternalVersion sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            int paramIndex = 0;
            if(CtFormatUtil.hasContent(dateStart)){
                paramIndex++;
                statement.setString(paramIndex, dateStart);
            }
            if(CtFormatUtil.hasContent(dateEnd)){
                paramIndex++;
                statement.setString(paramIndex, dateEnd);
            }
            paramIndex++;
            statement.setLong(paramIndex, parentOid);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                String number = rs.getString(1);
                //查询做了排序，同料号只取第一条数据
                if(childNumberSet.contains(number)){
                    continue;
                }else{
                    childNumberSet.add(number);
                }
                String partOid = rs.getString(4);
                String linkOid = rs.getString(5);
                WTPart childPart = (WTPart) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPart:" + partOid);
                WTPartUsageLink link = (WTPartUsageLink) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPartUsageLink:" + linkOid);
                //装到BO中
                CtBaselineBo parentBo = CtBaselineQueryServiceImpl.getBoByPartAndLink(link, childPart, dateFormat);
                //装入子项
                childList.add(parentBo);
            }
        } catch (Exception var12) {
            logger.error("查询符合条件的子项异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
    }

    /**
     * 查询所有的子项
     * @param parentOid
     * @return
     * @throws Exception
     */
    public Map<String, Map<String, String>> queryMeetCriteriaChild2(Long parentOid, String view) throws Exception {
        Map<String, Map<String, String>> resultMap = new HashMap<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT w2.WTPARTNUMBER , t.VERSIONIDA2VERSIONINFO, t.ITERATIONIDA2ITERATIONINFO, t.IDA2A2, w.IDA2A2")
                    .append(" FROM WTPARTUSAGELINK w, wtpart t ,WTPARTMASTER w2, WTVIEW w3  WHERE  1=1");
            if(CtConstant.VIEW_DESIGN.equals(view)){
                //D视图则直接取D视图的子项
                sql.append(" AND w3.IDA2A2 = t.IDA3VIEW AND w3.NAME = 'Design'");
            }else{
                //M视图则优先取M视图的子项
                sql.append(" AND t.IDA3VIEW = w3.IDA2A2")
                        .append(" AND t.IDA3VIEW = (SELECT max(w6.IDA3VIEW) FROM wcadmin.WTPART w6 WHERE w6.IDA3MASTERREFERENCE = t.IDA3MASTERREFERENCE)");
            }
            sql.append(" AND t.IDA3MASTERREFERENCE = w2.IDA2A2")
                    .append(" AND t.IDA3MASTERREFERENCE = w.IDA3B5");
            sql.append(" AND w.IDA3A5 = ?")
                    .append(" ORDER BY w2.WTPARTNUMBER DESC, t.VERSIONIDA2VERSIONINFO DESC, TO_NUMBER(t.ITERATIONIDA2ITERATIONINFO) DESC");

            logger.debug(">>>getInternalVersion sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setLong(1, parentOid);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                String number = rs.getString(1);
                String partOid = rs.getString(4);
                String linkOid = rs.getString(5);
                //查询做了排序，同料号只取第一条数据
                if(resultMap.containsKey(number)){
                    continue;
                }else{
                    Map<String, String> map = new HashMap<>();
                    map.put("partOid", partOid);
                    map.put("linkOid", linkOid);
                    resultMap.put(number, map);
                }
            }
        } catch (Exception var12) {
            logger.error("查询所有的子项异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
        return resultMap;
    }

    /**
     * 通过父项oid查子项
     * @param ctBaselineBo
     * @param dateFormat
     * @throws Exception
     */
    public void queryChild(CtBaselineBo ctBaselineBo, SimpleDateFormat dateFormat) throws Exception {
        List<CtBaselineBo> childList = ctBaselineBo.getChildren();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection)context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT CHILDOID, w.IDA2A2 FROM ZBOMBASELINETABLE t, WTPARTUSAGELINK w WHERE 1=1")
                    .append(" AND t.PARENTOID = w.IDA3A5")
                    .append(" AND t.CHILDMASTERID = w.IDA3B5")
                    .append(" AND t.PARENTOID = ?");
            logger.debug(">>>sql==" + sql.toString());
            statement = connection.prepareStatement(sql.toString());
            statement.setLong(1, ctBaselineBo.getPartOid());
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                Long childOid = rs.getLong(1);
                Long linkOid = rs.getLong(2);
                WTPart childPart = (WTPart) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPart:" + childOid);
                WTPartUsageLink link = (WTPartUsageLink) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPartUsageLink:" + linkOid);
                //装到BO中
                CtBaselineBo parentBo = CtBaselineQueryServiceImpl.getBoByPartAndLink(link, childPart, dateFormat);
                //装入子项
                childList.add(parentBo);
            }
        } catch (Exception var12) {
            logger.error("通过父项oid查子项异常：" + var12);
            var12.printStackTrace();
            throw new WTException("后台数据库异常，异常信息：" + var12.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            connection.getConnection().commit();
            if (connection != null && connection.isActive()) {
                connection.release();
            }
        }
    }

}
