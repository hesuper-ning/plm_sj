package ext.plm.bom.baselineQuery.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.bom.baselineQuery.bo.CtBomBaselineBo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CtBomBaselineBoMapper extends BaseMapper<CtBomBaselineBo> {

}
