package ext.plm.bom;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.bo.CtBomSearchViewBo;
import ext.plm.bom.bo.CtConvertBomBo;
import ext.plm.bom.bo.CtEMHistoryViewLinkBo;
import ext.plm.bom.bo.CtViewLinkBo;
import ext.plm.bom.config.CtBomConstant;
import ext.plm.bom.config.CtConvertBomFilterConfig;
import ext.plm.bom.dao.CtConvertBomDao;
import ext.plm.bom.mapper.CtViewLinkMapper;
import ext.plm.common.CtConstant;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.part.CtPartLogic;
import ext.plm.part.bo.CtPartViewRefBo;
import ext.plm.part.config.CtPartConfig;
import ext.plm.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.maturity.PromotionNotice;
import wt.org.WTUser;
import wt.part.*;
import wt.pom.Transaction;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.ClientTypedUtility;
import wt.util.WTAttributeNameIfc;
import wt.util.WTProperties;
import wt.vc.VersionControlHelper;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.wip.WorkInProgressHelper;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class CtBomViewServiceImpl implements CtBomViewService{

    @Resource
    private CtViewLinkMapper ctViewLinkMapper;
    private CtConvertBomDao ctConvertBomDao = CtBeanFactory.newCtBeanFactory().getBean(CtConvertBomDao.class);
    private Logger logger = Logger.getLogger(CtBomViewServiceImpl.class);
    /**
     * 搜索BOM
     * @param oid
     * @param type
     * @param state
     * @param commonParam
     * @return
     * @throws Exception
     */
    @Override
    public CtBomSearchViewBo searchBom(String oid, String type, String state, String commonParam) throws Exception {
        CtBomSearchViewBo bo = null;
        if(!CtFormatUtil.hasContent(oid)){
            return null;
        }
        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
        if(null != part){
            bo = new CtBomSearchViewBo(part, null, null);
            //递归收集BOM下的所有的Part，组装到bo中
            getAllPartsInBOMByView(part, bo, null);

            //按条件筛选数据
            if(CtFormatUtil.hasContent(type) || CtFormatUtil.hasContent(state) || CtFormatUtil.hasContent(commonParam)){
                List<String> pathList = new ArrayList<>();
                Map<String, String> conditionMap = new HashMap<>();
                conditionMap.put("type", type);
                conditionMap.put("state", state);
                conditionMap.put("commonParam", commonParam);

                //根节点也判断一下
                boolean isEligible = filterData(bo, conditionMap);
                if(isEligible){
                    bo.setTargetObject("Y");
                }

                //得出所有符合条件的部件的路径
                getEligiblePath(bo, pathList, conditionMap);

                //遍历bom结构，把不符合的节点移除
                filterBom(bo, pathList);
            }
        }
        return bo;
    }

    /**
     * 筛选BOM
     * @param bo
     * @param pathList
     * @throws Exception
     */
    public void filterBom(CtBomSearchViewBo bo, List<String> pathList) throws Exception {
        List<CtBomSearchViewBo> childList = bo.getChildren();
        boolean isEligible = false;
        Iterator<CtBomSearchViewBo> it = childList.iterator();
        while(it.hasNext()){
            CtBomSearchViewBo childBo = it.next();
            isEligible = isEligible(childBo, pathList);
            if(isEligible){
                if(CtFormatUtil.hasContent(childBo.getChildren())){
                    //递归处理子项的子项
                    filterBom(childBo, pathList);
                }
            }else{
                //移除掉不合格的子项
                it.remove();
            }
        }
    }

    /**
     * 判断当前子项是否合格
     * @param childBo
     * @param pathList
     * @return
     * @throws Exception
     */
    public boolean isEligible(CtBomSearchViewBo childBo, List<String> pathList) throws Exception {
        for(String path : pathList){
            if(path.contains("/" + childBo.getPartNumber() + "/")){
                return true;
            }
        }
        return false;
    }

    /**
     * 筛选出符合条件的数据的路径（因符合条件子项的父项不论是否符合条件，都需要留在树结构中，所以先得到符合条件的路径集合，用于后面匹配去除掉不符合条件的数据）
     * @param bo
     * @return
     * @throws Exception
     */
    public void getEligiblePath(CtBomSearchViewBo bo, List<String> pathList, Map<String, String> conditionMap) throws Exception {
        List<CtBomSearchViewBo> childList = bo.getChildren();
        boolean isEligible = false;
        for(CtBomSearchViewBo childBo : childList){
            isEligible = filterData(childBo, conditionMap);
            if(isEligible){
                pathList.add(childBo.getPartPath()+"/");
                //设置符合条件的标识
                childBo.setTargetObject("Y");
            }
            if(CtFormatUtil.hasContent(childBo.getChildren())){
                //递归筛选子项的子项
                getEligiblePath(childBo, pathList, conditionMap);
            }
        }
    }

    /**
     * 筛选数据
     * @param bo
     * @param conditionMap
     * @return
     * @throws Exception
     */
    public boolean filterData(CtBomSearchViewBo bo, Map<String, String> conditionMap) throws Exception {
        String type = conditionMap.get("type");
        String state = conditionMap.get("state");
        String commonParam = conditionMap.get("commonParam");
        //类型
        if(CtFormatUtil.hasContent(type)){
            boolean inType = false;
            String[] typeArray = type.split(",");
            for(int i = 0;i < typeArray.length;i++){
                if(typeArray[i].equals(bo.getPartType())){
                    inType = true;
                    break;
                }
            }
            if(!inType){
                return false;
            }
        }
        //状态
        if(CtFormatUtil.hasContent(state)){
            boolean inState = false;
            String[] stateArray = state.split(",");
            for(int i = 0;i < stateArray.length;i++){
                if(stateArray[i].equals(bo.getPartState())){
                    inState = true;
                    break;
                }
            }
            if(!inState){
                return false;
            }
        }
        //公共参数
        if(CtFormatUtil.hasContent(commonParam)){
            String upperCase = commonParam.toUpperCase();
            //部件编号
            if(bo.getPartNumber().toUpperCase().contains(upperCase)){
                return true;
            }
            //部件名称
            if(bo.getPartName().toUpperCase().contains(upperCase)){
                return true;
            }
            //内部版本
            if(CtFormatUtil.hasContent(bo.getInternalVersion())
                    && bo.getInternalVersion().toUpperCase().contains(upperCase)){
                return true;
            }
            //版本
            if(CtFormatUtil.hasContent(bo.getVersion())
                    && bo.getVersion().toUpperCase().contains(upperCase)){
                return true;
            }
            //状态
            if(bo.getPartState().toUpperCase().contains(upperCase)){
                return true;
            }
            //默认单位
            if(CtFormatUtil.hasContent(bo.getDefaultUnit())
                    && bo.getDefaultUnit().toUpperCase().contains(upperCase)){
                return true;
            }
            //数量
            if(CtFormatUtil.hasContent(bo.getQuantity())
                    && bo.getQuantity().toUpperCase().contains(upperCase)){
                return true;
            }
            //位号
            if(CtFormatUtil.hasContent(bo.getReferenceDesignatorRange())
                    && bo.getReferenceDesignatorRange().toUpperCase().contains(upperCase)){
                return true;
            }
            //BOM备注
            if(CtFormatUtil.hasContent(bo.getRemarks())
                    && bo.getRemarks().toUpperCase().contains(upperCase)){
                return true;
            }
            //是否RoHS
            if(CtFormatUtil.hasContent(bo.getIsRoHS())
                    && bo.getIsRoHS().toUpperCase().contains(upperCase)){
                return true;
            }
            //创建人
            if(CtFormatUtil.hasContent(bo.getCreator())
                    && bo.getCreator().toUpperCase().contains(upperCase)){
                return true;
            }
            //修改人
            if(CtFormatUtil.hasContent(bo.getEditor())
                    && bo.getEditor().toUpperCase().contains(upperCase)){
                return true;
            }
        }else{
            return true;
        }
        return false;
    }

    /**
     * 递归收集BOM下的所有的Part
     * @param fatherPart
     * @param bo
     * @param selectView
     * @throws Exception
     */
    public void getAllPartsInBOMByView(WTPart fatherPart, CtBomSearchViewBo bo, View selectView) throws Exception{
        WTPartConfigSpec configSpec = null;
        if(selectView==null){
            selectView = ViewHelper.service.getView(fatherPart.getViewName());
        }
        configSpec = WTPartConfigSpec.newWTPartConfigSpec(WTPartStandardConfigSpec.newWTPartStandardConfigSpec(selectView, null));
        QueryResult queryResult = WTPartHelper.service.getUsesWTParts(fatherPart, configSpec);
        while (queryResult.hasMoreElements()) {
            Persistable[] results = (Persistable[]) queryResult.nextElement();
            if (!(results[0] instanceof WTPartUsageLink) || !(results[1] instanceof WTPart)) {
                continue;
            }
            //添加子部件
            WTPartUsageLink usageLink = (WTPartUsageLink) results[0];
            WTPart partSon = (WTPart) results[1];
            CtBomSearchViewBo childBo = new CtBomSearchViewBo(partSon, bo, usageLink);
            List<CtBomSearchViewBo> childBoList = bo.getChildren();
            childBoList.add(childBo);
            getAllPartsInBOMByView(partSon, childBo, selectView);
        }
        if(!CtFormatUtil.hasContent(bo.getChildren())){
            bo.setLeaf(true);
        }
    }

    /**
     * 导出筛选BOM
     * @param bomData
     * @return
     * @throws Exception
     */
    @Override
    public Workbook exportFilterBom(String bomData) throws Exception {
        FileInputStream fileInputStream = null;
        Workbook workbook = null;
        try{
            WTProperties wtProperty = WTProperties.getLocalProperties();
            String path = wtProperty.getProperty("wt.home") + File.separator + "codebase" + File.separator + "ext" + File.separator +
                    "plm" + File.separator + "templates" + File.separator + "筛选视图导出模板.xlsx";

            fileInputStream = new FileInputStream(path);
            workbook = WorkbookFactory.create(fileInputStream);
            Sheet sheet = workbook.getSheetAt(0);
            //处理前端传过来的数据，json字符串转成java对象
            JSONObject parentPart = JSONObject.parseObject(bomData);
            //写入数据
            Map<String, Integer> rowIndexMap = new HashMap<>();
            rowIndexMap.put("rowIndex", 1);
            writeRowData(parentPart, sheet, rowIndexMap, 0);
        }finally {
            if (null != fileInputStream) {
                fileInputStream.close();
            }
        }
        return workbook;
    }

    /**
     * 导出excel
     * @param parentPart 前端传过来的树形数据
     * @param sheet 工作薄
     * @param rowIndexMap 行数
     * @param level 层次，用于缩进编号，导出能看到树的效果
     * @throws Exception
     */
    public void writeRowData(JSONObject parentPart, Sheet sheet, Map<String, Integer> rowIndexMap, int level) throws Exception {
        //写入父项
        writeCellData(parentPart, sheet, rowIndexMap, level);
        //子项
        JSONArray childArray = parentPart.getJSONArray("children");
        if(CtFormatUtil.hasContent(childArray)){
            level++;
            for(int i = 0;i < childArray.size();i++){
                //行数加1
                rowIndexMap.put("rowIndex", rowIndexMap.get("rowIndex")+1);
                //递归写入子项
                JSONObject childPart = childArray.getJSONObject(i);
                writeRowData(childPart, sheet, rowIndexMap, level);
            }
        }
    }

    /**
     * 单行数据的写入
     * @param part
     * @param sheet
     * @param rowIndexMap
     * @param level
     * @throws Exception
     */
    public void writeCellData(JSONObject part, Sheet sheet, Map<String, Integer> rowIndexMap, int level) throws Exception {
        int rowIndex = rowIndexMap.get("rowIndex");
        Row row = sheet.getRow(rowIndex);
        if(null == row){
            row = sheet.createRow(rowIndex);
        }
        //目标对象
        CtExcelReadUtil.setExcelCellValue(0, part.getString("targetObject"), row);
        //在子项编号前面添加空格，通过这种缩进的方式，展示数形结构
        StringBuilder numberBuilder = new StringBuilder();
        for(int i = 0;i< level;i++){
            numberBuilder.append("    ");
        }
        numberBuilder.append(part.getString("partNumber"));
        //编号
        CtExcelReadUtil.setExcelCellValue(1, numberBuilder.toString(), row);
        //名称
        CtExcelReadUtil.setExcelCellValue(2, part.getString("partName"), row);
        //内部版本
        CtExcelReadUtil.setExcelCellValue(3, part.getString("internalVersion"), row);
        //版本
        CtExcelReadUtil.setExcelCellValue(4, part.getString("version"), row);
        //状态
        CtExcelReadUtil.setExcelCellValue(5, part.getString("partState"), row);
        //默认单位
        CtExcelReadUtil.setExcelCellValue(6, part.getString("defaultUnit"), row);
        //数量
        CtExcelReadUtil.setExcelCellValue(7, part.getString("quantity"), row);
        //位号
        CtExcelReadUtil.setExcelCellValue(8, part.getString("referenceDesignatorRange"), row);
        //BOM备注
        CtExcelReadUtil.setExcelCellValue(9, part.getString("remarks"), row);
        //是否RoHS
        CtExcelReadUtil.setExcelCellValue(10, part.getString("isRoHS"), row);
        //创建人
        CtExcelReadUtil.setExcelCellValue(11, part.getString("creator"), row);
        //修改人
        CtExcelReadUtil.setExcelCellValue(12, part.getString("editor"), row);
    }

    /**
     * 模糊查询设计视图最新小版的物料编号
     * @param partNumber
     * @return
     * @throws Exception
     */
    @Override
    public List<Map<String, String>> searchPart(String partNumber) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        QuerySpec querySpec = new QuerySpec(WTPart.class);
        querySpec.appendSearchCondition(new SearchCondition(WTPart.class,WTPart.NUMBER,SearchCondition.LIKE,"%"+partNumber+"%"));

        querySpec.appendOr();
        SearchCondition scName = new SearchCondition(WTPart.class, WTPart.NAME, SearchCondition.LIKE, "%" + partNumber + "%");
        querySpec.appendWhere(scName, new int[]{0});

        SearchCondition scLatestIteration = new SearchCondition(WTPart.class, WTAttributeNameIfc.LATEST_ITERATION, SearchCondition.IS_TRUE);
        querySpec.appendAnd();
        querySpec.appendWhere(scLatestIteration);
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        while(queryResult.hasMoreElements()) {
            Object o = queryResult.nextElement();
            WTPart part = (WTPart) o;
            //只查设计视图的
            if(!part.getViewName().equalsIgnoreCase(CtBomConstant.VIEW_DESIGN)){
                continue;
            }
            String type = CtWTObjectUtil.getLeafTypeIdentifier(part);
            if(!CtEcConstant.Ct_PartType_HalfEndPart.equals(type)){
                continue;
            }
            //组装数据返回
            Map<String, String> map = new HashMap<>();
            map.put("partNumber", part.getNumber());
            String version = part.getVersionInfo().getIdentifier().getValue() + "." + part.getIterationInfo().getIdentifier().getValue();
            map.put("partVersion", version + "(" + part.getViewName() + ")");
            map.put("partName", part.getName());
            map.put("partState", part.getLifeCycleState().getDisplay(Locale.CHINA));
            list.add(map);
        }
        return list;
    }

    /**
     * 查询已选的d视图物料
     * @param partNumber
     * @return
     * @throws Exception
     */
    @Override
    public List<Map<String, String>> getSelectNumbers(String partNumber) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();
        if(!CtFormatUtil.hasContent(partNumber)){
            return list;
        }
        QuerySpec querySpec = new QuerySpec(WTPart.class);
        String[] partNumberArray = partNumber.split(",");
        ArrayExpression partNumbers = new ArrayExpression(partNumberArray);
        ClassAttribute partNumberClassAtt = new ClassAttribute(WTPart.class, WTPart.NUMBER);
        querySpec.appendWhere(new SearchCondition(partNumberClassAtt,SearchCondition.IN, partNumbers), new int[] { 0 });
        SearchCondition scLatestIteration = new SearchCondition(WTPart.class, WTAttributeNameIfc.LATEST_ITERATION, SearchCondition.IS_TRUE);
        querySpec.appendAnd();
        querySpec.appendWhere(scLatestIteration);
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        while(queryResult.hasMoreElements()) {
            Object o = queryResult.nextElement();
            WTPart part = (WTPart) o;
            //只查设计视图的
            if(!part.getViewName().equalsIgnoreCase(CtBomConstant.VIEW_DESIGN)){
                continue;
            }
            String type = CtWTObjectUtil.getLeafTypeIdentifier(part);
            if(!CtEcConstant.Ct_PartType_HalfEndPart.equals(type)){
                continue;
            }
            //组装数据返回
            Map<String, String> map = new HashMap<>();
            map.put("partNumber", part.getNumber());
            String version = part.getVersionInfo().getIdentifier().getValue() + "." + part.getIterationInfo().getIdentifier().getValue();
            map.put("partVersion", version + "(" + part.getViewName() + ")");
            map.put("partName", part.getName());
            map.put("partState", part.getLifeCycleState().getDisplay(Locale.CHINA));
            list.add(map);
        }
        return list;
    }

    /**
     * 保存E/M视图关联关系
     * @param bo
     * @throws Exception
     */
    @Override
    public void saveViewLink(CtViewLinkBo bo) throws Exception {
        ctViewLinkMapper.saveViewLink(bo);
    }

    /**
     * 删除E/M视图关联关系
     * @param bo
     * @throws Exception
     */
    @Override
    public void deleteViewLink(CtViewLinkBo bo) throws Exception {
        ctViewLinkMapper.deleteViewLinkById(bo);
    }

    /**
     * 通过制造视图的物料，查询关联关系
     * @param roleA
     * @return
     * @throws Exception
     */
    @Override
    public List<CtViewLinkBo> queryViewLinkByManufacturing(Long roleA) throws Exception {
        return ctViewLinkMapper.queryViewLinkByRoleA(roleA);
    }

    /**
     * 查询E/M视图物料历史记录
     * @param partOid
     * @return
     * @throws Exception
     */
    @Override
    public List<CtPartViewRefBo> queryPartViewRef(Long partOid) throws Exception {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        List<CtPartViewRefBo> resultList = new ArrayList<>();
        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPart:" + partOid);
        if(null == part){
            return resultList;
        }
        String partNumber = part.getNumber();
        Long masterId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
        List<CtViewLinkBo> linkList = new ArrayList<>();
        if(CtConstant.VIEW_MANUFACTURING.equals(part.getViewName())){
            //制造视图物料
            linkList = ctViewLinkMapper.queryViewLinkByRoleA(masterId);
        }else{
            //设计视图物料
            linkList = ctViewLinkMapper.queryViewLinkByRoleB(masterId);
        }
        if(CtFormatUtil.hasContent(linkList)){
            for(CtViewLinkBo ctViewLinkBo : linkList){
                WTPart refPart = null;
                if(CtConstant.VIEW_MANUFACTURING.equals(part.getViewName())){
                    refPart = CtPartUtil.getPartByMasterId(ctViewLinkBo.getRoleB());
                    if(null == refPart){
                        continue;
                    }
                    refPart = CtPartUtil.getPartByNumber(refPart.getNumber(), CtConstant.VIEW_DESIGN);
                }else{
                    refPart = CtPartUtil.getPartByMasterId(ctViewLinkBo.getRoleA());
                    if(null == refPart){
                        continue;
                    }
                    refPart = CtPartUtil.getPartByNumber(refPart.getNumber(), CtConstant.VIEW_MANUFACTURING);
                }
                if(null == refPart){
                    continue;
                }
                //添加部件的所有版本到集合中
                addPartAllVersion(refPart, resultList, dateFormat);
            }
        }

        //同料号的也要查出来
        if(CtConstant.VIEW_MANUFACTURING.equals(part.getViewName())){
            //制造视图物料
            WTPart dPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);
            //添加部件的所有版本到集合中
            if(null != dPart){
                addPartAllVersion(dPart, resultList, dateFormat);
            }
        }else{
            //设计视图物料
            WTPart mPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
            //添加部件的所有版本到集合中
            if(null != mPart){
                addPartAllVersion(mPart, resultList, dateFormat);
            }
        }

        //把当前物料的所有版本，也添加到集合
        addPartAllVersion(part, resultList, dateFormat);
        return resultList;
    }

    /**
     * 添加部件的所有版本到集合中
     * @param refPart
     * @param resultList
     * @param dateFormat
     * @throws Exception
     */
    public void addPartAllVersion(WTPart refPart, List<CtPartViewRefBo> resultList, SimpleDateFormat dateFormat) throws Exception {
        List<CtPartViewRefBo> refPartBoList = new ArrayList<>();
        QueryResult queryResult = VersionControlHelper.service.allIterationsOf(refPart.getMaster());
        while(queryResult.hasMoreElements()){
            WTPart refPartVersion = (WTPart) queryResult.nextElement();
            //副本不显示
            if(WorkInProgressHelper.isWorkingCopy(refPartVersion)){
                continue;
            }
            //过滤视图
            if(!refPart.getViewName().equals(refPartVersion.getViewName())){
                continue;
            }
            CtPartViewRefBo refBo = getPartViewRefBo(refPartVersion, dateFormat);
            refPartBoList.add(refBo);
        }
        //取倒序
        Collections.reverse(refPartBoList);
        //添加到结果集合中
        resultList.addAll(refPartBoList);
    }

    /**
     * 设置bo属性
     * @param part
     * @param dateFormat
     * @return
     * @throws Exception
     */
    public CtPartViewRefBo getPartViewRefBo(WTPart part, SimpleDateFormat dateFormat) throws Exception {
        CtPartViewRefBo ctPartViewRefBo = new CtPartViewRefBo();
        ctPartViewRefBo.setId(part.getPersistInfo().getObjectIdentifier().getId()+"");
        ctPartViewRefBo.setPartNumber(CtCommonUtil.getURL(part, part.getNumber()));
        String version = CtVersionUtil.getVersionInfo(part);
        ctPartViewRefBo.setPartVersion(version + "(" + part.getViewName() + ")");
        ctPartViewRefBo.setPartState(part.getLifeCycleState().getDisplay(Locale.CHINA));
        ctPartViewRefBo.setModifyUser(part.getModifierFullName());
        ctPartViewRefBo.setCreateTime(dateFormat.format(part.getCreateTimestamp()));
        ctPartViewRefBo.setModifyTime(dateFormat.format(part.getModifyTimestamp()));
        ctPartViewRefBo.setPartNote(part.getIterationNote());
        return ctPartViewRefBo;
    }

    /**
     * 根据流程id查询转BOM数据
     * @param pnId
     * @return
     * @throws Exception
     */
    @Override
    public List<CtConvertBomBo> queryConvertBomInfo(Long pnId) throws Exception {
        List<CtConvertBomBo> boList = ctConvertBomDao.queryConvertBomInfo(pnId);
        //更新“是否已转M视图”字段和“M视图物料编码”
        updateMPartInfo(boList);
        return boList;
    }

    /**
     * 更新“是否已转M视图”字段和“M视图物料编码”
     * @param boList
     * @throws Exception
     */
    public static void updateMPartInfo(List<CtConvertBomBo> boList) throws Exception {
        CtConvertBomDao ctConvertBomDao = CtBeanFactory.newCtBeanFactory().getBean(CtConvertBomDao.class);
        for(CtConvertBomBo bo : boList){
            String partNumber = bo.getPartNumber();
            WTPart part = CtPartUtil.getPartByNumber(partNumber);
            if(null == part){
                continue;
            }
            //是否已转M视图
            WTPart mPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
            if(null == mPart){
                bo.setConvertMView("否");
            }else{
                bo.setConvertMView("是");
            }
            //M视图物料编码
            bo.setManufacturingNumber("");//先初始化
            List<String> mPartNumbers = new ArrayList<>();
            if(null != mPart){
                mPartNumbers.add(mPart.getNumber() + "(" + mPart.getLifeCycleState().getDisplay(Locale.CHINA) +")");
            }
            CtViewLinkMapper ctViewLinkMapper = CtBeanFactory.newCtBeanFactory().getBean(CtViewLinkMapper.class);
            List<CtViewLinkBo> ctViewLinkBos = ctViewLinkMapper.queryViewLinkByRoleB(part.getMaster().getPersistInfo().getObjectIdentifier().getId());
            for(CtViewLinkBo ctViewLinkBo : ctViewLinkBos){
                WTPart aPart = CtPartUtil.getPartByMasterId(ctViewLinkBo.getRoleA());
                if(null == aPart){
                    continue;
                }
                WTPart lastAPart = CtPartUtil.getPartByNumber(aPart.getNumber(), CtConstant.VIEW_MANUFACTURING);
                if(null == lastAPart){
                    continue;
                }
                mPartNumbers.add(lastAPart.getNumber() + "(" + lastAPart.getLifeCycleState().getDisplay(Locale.CHINA) +")");
            }
            if(mPartNumbers.size() > 0){
                bo.setManufacturingNumber(StringUtils.join(mPartNumbers, ","));
            }
            //更新到数据库
            ctConvertBomDao.updateConvertBomInfo(bo);
        }
    }

    /**
     * 根据masterId查询转BOM数据(部件详情页面)
     * @param masterId
     * @return
     * @throws Exception
     */
    @Override
    public List<CtConvertBomBo> queryPartPageConvertBomBo(Long masterId) throws Exception {
        List<CtConvertBomBo> boList = ctConvertBomDao.queryPartPageConvertBomBo(masterId);
        //更新“是否已转M视图”字段和“M视图物料编码”
        updateMPartInfo(boList);
        return boList;
    }

    @Override
    public void deleteConvertBomBo(String id) throws Exception {
        ctConvertBomDao.deleteById(id);
    }

    /**
     * 前端编辑某个字段后，更新数据
     * @param id
     * @param key
     * @param value
     * @return
     * @throws Exception
     */
    @Override
    public CtConvertBomBo updateConvertBomBoById(String id, String key, String value) throws Exception {
        CtConvertBomBo bo = ctConvertBomDao.queryConvertBomInfoById(id);
        if(null == bo){
            return null;
        }
        setObjectValue(bo,key,value);
        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
        bo.setEditor(user.getName());
        bo.setModifyTime(new Date());
        ctConvertBomDao.updateConvertBomInfo(bo);
        return bo;
    }

    /**
     * 反射设置对象值
     * @param o
     * @param key
     * @param value
     * @throws Exception
     */
    public static void setObjectValue(Object o, String key, String value) throws Exception {
        //反射设置属性值
        Field field = o.getClass().getDeclaredField(key);
        field.setAccessible(true);
        String fieldType = field.getType().toString();
        int lastIndex = fieldType.lastIndexOf(".");
        fieldType = fieldType.substring(lastIndex + 1);
        if ("String".equals(fieldType)) {
            field.set(o, value==null? null :value.trim());
        } else if ("Date".equals(fieldType)) {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            Date date = !hasContent(value) ? null : df.parse(value);
            field.set(o, date);
        }
    }

    /**
     *
     * @Description hasContent
     * @param content
     * @return
     */
    public static boolean hasContent(String content) {
        return content != null && !"".equals(content.trim())&&!"null".equalsIgnoreCase(content.trim());
    }

    /**
     * 更新表单数据
     * @param boList
     * @param mPart
     * @return
     * @throws Exception
     */
    @Override
    public CtConvertBomBo updateConvertBomBo(List<CtConvertBomBo> boList, WTPart mPart, DateFormat dataFormat) throws Exception {
        for(CtConvertBomBo bo : boList){
            if(mPart.getNumber().equals(bo.getPartNumber())){
                //是否已转M视图
                bo.setConvertMView("是");
                //M视图物料编码
                String oldMNumber = bo.getManufacturingNumber();
                String mPartInfo = mPart.getNumber() + "(" + mPart.getLifeCycleState().getDisplay(Locale.CHINA) +")";
                if(CtFormatUtil.hasContent(oldMNumber)){
                    bo.setManufacturingNumber(mPartInfo + "," + oldMNumber);
                }else{
                    bo.setManufacturingNumber(mPartInfo);
                }
                //执行状况
                bo.setImplementationStatus("OK " + dataFormat.format(new Date()));
                WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
                bo.setEditor(user.getName());
                bo.setModifyTime(new Date());
                ctConvertBomDao.updateConvertBomInfo(bo);
                return bo;
            }
        }
        return null;
    }

    /**
     * 转MBOM
     * @param numbers
     * @param pn
     * @param masterId
     * @return
     * @throws Exception
     */
    @Override
    public void convertBom(String numbers, PromotionNotice pn, Long masterId) throws Exception {
        Transaction transaction = null;
        Boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        transaction = new Transaction();
        transaction.start();
        try{
            //根据入参，得出需要转bom的物料集合
            String[] numberArray = numbers.split(",");
            List<WTPart> partList = new ArrayList<>();
            WTPart part = null;
            for(int i = 0;i < numberArray.length;i++){
                part = CtPartUtil.getPartByNumber(numberArray[i], CtConstant.VIEW_DESIGN);
                if(null != part){
                    partList.add(part);
                }
            }

            //校验BOM不为空
            StringBuilder msg = new StringBuilder();
            String errorMsg = CtBomLogic.checkBom_isEmpty(partList);
            if (CtFormatUtil.hasContent(errorMsg)) {
                throw new Exception("转BOM视图校验失败！" + errorMsg);
            }
            //校验
            for(WTPart tempPart : partList){
                checkConvertPart(tempPart, msg);
            }
            if(msg.toString().length() > 0){
                throw new Exception("转BOM视图校验失败！" + msg.toString());
            }

            //查询后台数据，得出不转bom的物料集合
            List<String> deletePartList = new ArrayList<>();
            List<CtConvertBomBo> boList = new ArrayList<>();
            List<String> filterList = new ArrayList<>();
            if(null != pn){
                Long pnId = pn.getPersistInfo().getObjectIdentifier().getId();
                boList = ctConvertBomDao.queryConvertBomInfo(pnId);
                for(CtConvertBomBo bo : boList){
                    if("否".equals(bo.getConvertBom())){
                        deletePartList.add(bo.getPartNumber());
                    }
                    //“是否已转M视图”为“是”的物料，不能再转MBOM，过滤掉
                    if("是".equals(bo.getConvertMView())){
                        filterList.add(bo.getPartNumber());
                    }
                }
            }else{
                boList = ctConvertBomDao.queryPartPageConvertBomBo(masterId);
                for(CtConvertBomBo bo : boList){
                    if("否".equals(bo.getConvertBom())){
                        deletePartList.add(bo.getPartNumber());
                    }
                    //“是否已转M视图”为“是”的物料，不能再转MBOM，过滤掉
                    if("是".equals(bo.getConvertMView())){
                        filterList.add(bo.getPartNumber());
                    }
                }
            }

            //选择的物料转M视图
            View view = ViewHelper.service.getView(CtConstant.VIEW_MANUFACTURING);
            //取得配置的需要删除的物料分类
            List<String> clfList = CtConvertBomFilterConfig.getConvertBomFilterConfig();
            DateFormat dataFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
            dataFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
            for(WTPart tempPart : partList){
                //“是否已转M视图”为“是”的物料，不能再转MBOM，过滤掉
                if(filterList.contains(tempPart.getNumber())){
                    continue;
                }
                //有可能在处理子项时已经转成了M视图，过滤存在M视图的物料
                WTPart mPart = CtPartUtil.getPartByNumber(tempPart.getNumber(), CtConstant.VIEW_MANUFACTURING);
                if(mPart != null){
                    continue;
                }
                WTPart revisedPart = (WTPart) ViewHelper.service.newBranchForView(tempPart, view);
                Folder folder =FolderHelper.getFolder(tempPart);
                FolderHelper.assignLocation((FolderEntry) revisedPart, folder);
                revisedPart = (WTPart) PersistenceHelper.manager.save(revisedPart);
                revisedPart = (WTPart) PersistenceHelper.manager.refresh(revisedPart);
                //创建制造视图物料设置为工作中状态
                LifeCycleHelper.service.setLifeCycleState(revisedPart, State.toState(CtConstant.STATE_WORKING));
                revisedPart = (WTPart) PersistenceHelper.manager.refresh(revisedPart);

                //保存“关联E/M视图物料”
                WTPart dPart = CtPartUtil.getPartByNumber(tempPart.getNumber(), CtConstant.VIEW_DESIGN);
                if(dPart != null){
                    CtPartLogic.savePartViewRef(dPart, revisedPart);
                }

                //处理单层子项，转M视图
                createSubPartView(revisedPart, deletePartList, clfList, CtConstant.VIEW_MANUFACTURING, boList, dataFormat);
                //回写信息到表单
                updateConvertBomBo(boList, revisedPart, dataFormat);
            }
            transaction.commit();
            transaction = null ;
        } catch (Exception e) {
            throw e;
        }finally{
            SessionServerHelper.manager.setAccessEnforced(flag);
            if(transaction != null ){
                transaction.rollback();
                transaction = null ;
            }
        }
    }

    /**
     * BOM下阶单层转视图，并且移除掉所有BOM中子件的CCB物料
     * @param part
     * @param deletePartList
     * @param clfList
     * @param viewName
     * @throws Exception
     */
    public void createSubPartView(WTPart part, List<String> deletePartList, List<String> clfList, String viewName,
            List<CtConvertBomBo> boList, DateFormat dataFormat) throws Exception {
        List<WTPart> partsInBOM = new ArrayList<>();
        partsInBOM = CtBomUtil.getPartsInBOMByView(part, null);
        for (WTPart wtPart : partsInBOM) {
            //过滤原材料(1/4开头的)
            //K开头的为基础物料，类型是原材料，也过滤掉
            if(wtPart.getNumber().startsWith("1")||wtPart.getNumber().startsWith("4")
                    ||wtPart.getNumber().startsWith("K1")||wtPart.getNumber().startsWith("K4")){
                continue;
            }
            //过滤掉CBB物料
            if(CtWTObjectUtil.getTypeIdentifier(wtPart).contains("ct_CBB")){
                continue;
            }
            //过滤掉视图一样的
            if(viewName.equals(wtPart.getViewName())){
                continue;
            }
            //过滤存在当前视图的
            WTPart revisedPart = CtPartUtil.getPartByNumber(wtPart.getNumber(), viewName);
            if(revisedPart != null){
                continue;
            }
            //过滤配置中的分类
            String clf = CtPartClfUtil.getClfAttValue(wtPart);
            if(clfList.contains(clf)){
                continue;
            }
            //过滤选否的物料
            if(deletePartList.contains(wtPart.getNumber())){
                continue;
            }

            Folder folder =FolderHelper.getFolder(wtPart);
            View view = ViewHelper.service.getView(viewName);
            revisedPart = (WTPart) ViewHelper.service.newBranchForView(wtPart, view);
            FolderHelper.assignLocation((FolderEntry) revisedPart, folder);
            revisedPart = (WTPart) PersistenceHelper.manager.save(revisedPart);
            revisedPart = (WTPart) PersistenceHelper.manager.refresh(revisedPart);
            //创建制造视图物料设置为工作中状态
            LifeCycleHelper.service.setLifeCycleState(revisedPart, State.toState(CtConstant.STATE_WORKING));
            revisedPart = (WTPart) PersistenceHelper.manager.refresh(revisedPart);

            //保存“关联E/M视图物料”
            CtPartLogic.savePartViewRef(wtPart, revisedPart);
            //添加历史记录
            CtBomHistoryViewService ctBomHistoryViewService = CtBeanFactory.newCtBeanFactory().getBean(CtBomHistoryViewService.class);
            CtEMHistoryViewLinkBo hbo = ctBomHistoryViewService.getCtEMHistoryViewLinkBo(wtPart, revisedPart,"关联");
            ctBomHistoryViewService.saveHistoryViewLink(hbo);
            //回写信息到表单
            updateConvertBomBo(boList, revisedPart, dataFormat);
        }
        //需要删除的BOM中的物料
        removePartInMBom(part, deletePartList, clfList);
    }

    /**
     * 移除MBOM中的物料
     * CBB物料，及配置的分类的物料，“本次是否转”选择“否”的物料
     * @param fatherPart
     * @param deletePartList
     * @param clfList
     * @throws Exception
     */
    public void removePartInMBom(WTPart fatherPart, List<String> deletePartList, List<String> clfList) throws Exception {
        if(fatherPart.getViewName().equals(CtConstant.VIEW_DESIGN)){
            return;
        }
//        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
//        SessionHelper.manager.setAdministrator();
//        try{
            List<WTPart> partsInBOMByView = CtBomUtil.getPartsInBOMByView(fatherPart, null);
            for (WTPart sonPart : partsInBOMByView) {
                String sonType = CtWTObjectUtil.getTypeIdentifier(sonPart);
                String clf = CtPartClfUtil.getClfAttValue(sonPart);
                if(sonType.contains("ct_CBB") || deletePartList.contains(sonPart.getNumber())
                        || clfList.contains(clf)){
                    CtBomUtil.deleteUsageLink(fatherPart, sonPart);
                }
            }
//        }finally {
//            //设置回原用户
//            SessionHelper.manager.setPrincipal(user.getName());
//        }
    }

    /**
     * 校验转MBOM的物料
     * @param part
     * @return
     * @throws Exception
     */
    public void checkConvertPart(WTPart part, StringBuilder msg) throws Exception {
        String partNumber = part.getNumber();
        WTPart mPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
        if (CtFormatUtil.hasContent(mPart)) {
            msg.append("物料" + partNumber + "已存在M视图,请勿重复创建！\r\n");
        }
        //校验BOM下阶物料状态
        String errorMsg = CtBomLogic.checkEtoM_areMaterialsValid(part);
        if (CtFormatUtil.hasContent(errorMsg)) {
            msg.append("转BOM视图校验失败！" + errorMsg + "\r\n");
        }
        String partType = ClientTypedUtility.getExternalTypeIdentifier(part);
        String stateDisplay = CtWTObjectUtil.getStateDisplay(part, Locale.CHINA);
        if(partType.contains(CtPartConfig.getProperty("成品"))){
            if (!stateDisplay.equals("已生效")){
                msg.append("物料" + partNumber + "为成品，成品的BOM只在‘已生效’状态允许创建M视图\r\n");
            }
        }else if(partType.contains(CtPartConfig.getProperty("半成品"))){
            if (!stateDisplay.equals("样机")&&!stateDisplay.equals("已生效")){
                msg.append("物料" + partNumber + "为半成品，半成品的BOM只在‘样机/已生效’状态允许创建M视图\r\n");
            }
        }
    }
}
