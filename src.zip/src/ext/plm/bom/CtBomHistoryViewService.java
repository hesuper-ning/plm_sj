package ext.plm.bom;

import java.text.SimpleDateFormat;
import java.util.List;

import ext.plm.bom.bo.CtEMHistoryViewLinkBo;
import ext.plm.part.bo.CtPartHistoryLinkViewRefBo;
import wt.part.WTPart;

public interface CtBomHistoryViewService {

	CtEMHistoryViewLinkBo getCtEMHistoryViewLinkBo(WTPart partA, WTPart partB,
			String changeRecords) throws Exception;
	
	CtPartHistoryLinkViewRefBo getPartHistoryViewRefBo(WTPart partA, WTPart partB, SimpleDateFormat dateFormat,
			String changeRecords,String numberA,String versionA,String numberB,
			String versionB) throws Exception ;
   
    void saveHistoryViewLink(CtEMHistoryViewLinkBo bo) throws Exception;

    List<CtEMHistoryViewLinkBo> queryViewLinkByManufacturing(Long roleA) throws Exception;

    List<CtPartHistoryLinkViewRefBo> queryPartViewRef(Long partOid) throws Exception;

}
