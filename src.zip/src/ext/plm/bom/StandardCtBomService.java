package ext.plm.bom;

import cn.hutool.core.io.FileUtil;
import com.mysql.cj.protocol.Resultset;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.baselineQuery.bo.CtBomBaselineBo;
import ext.plm.bom.baselineQuery.mapper.CtBomBaselineBoMapper;
import ext.plm.bom.baselineQuery.service.CtBomBaselineQueryServiceImpl;
import ext.plm.bom.config.CtBomConstant;
import ext.plm.common.CtConstant;
import ext.plm.util.*;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.doc.WTDocument;
import wt.fc.IdentityHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.MethodContext;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartMasterIdentity;
import wt.pom.WTConnection;
import wt.services.StandardManager;
import wt.util.WTException;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class StandardCtBomService extends StandardManager implements CtBomService {

    private static final long serialVersionUID = 6165172776780355043L;

    public static StandardCtBomService newStandardCtBomService() throws WTException {
        StandardCtBomService instance = new StandardCtBomService();
        instance.initialize();
        return instance;
    }


    @Override
    public void exportBom(OutputStream os, WTPart part, String fileName) throws WTException, Exception {
        CtBomLogic logic = new CtBomLogic();
        logic.exportBom(os, part,fileName);
    }

    @Override
    public void setDesignViewPart(String path) throws Exception {
        File filePath = new File(path);
        if(filePath == null){
            throw new Exception("路径或文件错误！找不到此路径或文件："+path);
        }
        InputStream is = FileUtil.getInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(is);
        Sheet sheet = workbook.getSheetAt(0);
        List<String> partNumberList = new ArrayList<>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            String partNumber = CtExcelReadUtil.getCellFormatValue(row.getCell(0), row, 0);
            partNumberList.add(partNumber);
        }
        System.out.println(">>>>读取excel完毕，物料编号数量：" + partNumberList.size());
        String state = "";
        for(String partNumber : partNumberList){
            List<WTPart> partList = CtPartUtil.getAllVersionPartByNumber(partNumber);
            if(!CtFormatUtil.hasContent(partList)){
                continue;
            }

            //排序
            sortList(partList);

            //获取M视图A.1版本的前置任务
            WTPart preTaskPart = getPreTask(partList);
            if(null == preTaskPart){
                System.out.println("-----------------没有前置任务版本的料号：" + partNumber);
                continue;
            }

            boolean needSave = false;
            for(WTPart part : partList){
                System.out.println(">>>>物料编号：" + partNumber);
                state = part.getLifeCycleState().getDisplay(Locale.CHINA);
                System.out.println(">>>>物料状态：" + state);
                if(preTaskPart.equals(part) || needSave || CtConstant.VIEW_MANUFACTURING.equals(part.getViewName())){
                    System.out.println(">>>>已刷" + part.getViewName() + " " + part.getVersionInfo().getIdentifier().getValue() + "." + part.getIterationInfo().getIdentifier().getValue());
                    needSave = true;
                    IBAUtil ibaUtil = new IBAUtil(part);
                    ibaUtil.setIBAValue(CtBomConstant.IBA_DESIGN_VIEW_PART, partNumber);
                    ibaUtil.updateIBAHolder(part);
                }
            }
        }
    }

    /**
     * 获取M视图A.1版本的前置任务
     * 物料有M视图的情况下，根据A.1版本M视图的前置任务属性，去确定是那个版本与M视图建立的关联关系
     * @param partList
     * @return
     * @throws Exception
     */
    public static WTPart getPreTask(List<WTPart> partList) throws Exception {
        for(WTPart part : partList){
            if(CtConstant.VIEW_MANUFACTURING.equals(part.getViewName())){
                String version = part.getVersionInfo().getIdentifier().getValue() + "." + part.getIterationInfo().getIdentifier().getValue();
                if("A.1".equals(version)){
                    WTPart prePart = (WTPart) part.getIterationInfo().getPredecessor().getObject();
                    if(null != prePart){
                        System.out.println(">>>>前置任务的版本：" + prePart.getVersionInfo().getIdentifier().getValue() + "." + prePart.getIterationInfo().getIdentifier().getValue());
                    }
                    return prePart;
                }
            }
        }
        return null;
    }

    /**
     * 1.只有样机。样机后的所有版本全部刷。
     * 2.只有已生效。已生效后的所有版本全部刷。
     * 3.样机、已生效都有。刷已生效后面的所有版本。
     * @param partList
     * @return
     * @throws Exception
     */
    public static String getSaveState(List<WTPart> partList) throws Exception {
        String resultState = "";
        String state = "";
        for(WTPart part : partList){
            if(CtConstant.VIEW_DESIGN.equals(part.getViewName())){
                state = part.getLifeCycleState().getDisplay(Locale.CHINA);
                if("已生效".equals(state)){
                    return "已生效";
                }
                if("样机".equals(state)){
                    resultState = "样机";
                }
            }
        }
        return resultState;
    }

    /**
     * 按视图和版本进行排序
     * @param partList
     */
    public static void sortList(List<WTPart> partList) throws Exception {
        //使用自定义排序规则进行排序
        Collections.sort(partList, new Comparator<WTPart>() {
            public int compare(WTPart s1, WTPart s2) {
                String viewName1 = s1.getViewName();
                String viewName2 = s2.getViewName();
                String version1 = s1.getVersionInfo().getIdentifier().getValue();
                String version2 = s2.getVersionInfo().getIdentifier().getValue();
                int iteration1 = Integer.parseInt(s1.getIterationInfo().getIdentifier().getValue());
                int iteration2 = Integer.parseInt(s2.getIterationInfo().getIdentifier().getValue());
                if(viewName1.equals(viewName2)){
                    if(version1.equals(version2)){
                        return iteration1 - iteration2;
                    }else{
                        char c1 = version1.charAt(0);
                        char c2 = version2.charAt(0);
                        int i1 = (int)c1;
                        int i2 = (int)c2;
                        return i1 - i2;
                    }
                }else{
                    if(CtConstant.VIEW_DESIGN.equals(viewName1)){
                        return -1;
                    }
                    if(CtConstant.VIEW_DESIGN.equals(viewName2)){
                        return 1;
                    }
                }
                return 0;
            }
        });
    }

    @Override
    public void setPartModifyTime() throws Exception {
        Map<Long, Long> map = getData();
        WTPart part = null;
        String partOr = "";
        String ecrOr = "";
        Timestamp stamp = null;
        System.out.println(">>>>>setPartModifyTime 开始刷数据！");
        System.out.println(">>>>>setPartModifyTime map" + map.size());
        for (Map.Entry<Long, Long> entry : map.entrySet()) {
            Long partOid = entry.getKey();
            Long ecrOid = entry.getValue();
            partOr = "OR:wt.part.WTPart:" + partOid;
            part = (WTPart) CtWTObjectUtil.getObjectByOid(partOr);
            if(null == part){
                continue;
            }
            String note = part.getIterationNote();
            if(!CtFormatUtil.hasContent(note) || !note.contains("ECR系统自动修订")){
                System.out.println(">>>>>setPartModifyTime 此编号的备注不包含“ECR系统自动修订”：" + part.getNumber());
                continue;
            }
            ecrOr = "OR:wt.change2.WTChangeRequest2:" + ecrOid;
            WTChangeRequest2 ecr = (WTChangeRequest2) CtWTObjectUtil.getObjectByOid(ecrOr);
            if(null == ecr){
                System.out.println(">>>>>setPartModifyTime 找不到ECR：" + note);
                continue;
            }
            QueryResult qrEcn = ChangeHelper2.service.getChangeOrders(ecr);
            if (qrEcn.hasMoreElements()) { //遍历ecn
                WTChangeOrder2 ecn = (WTChangeOrder2) qrEcn.nextElement();
                stamp = ecn.getCreateTimestamp();
            }else{
                System.out.println(">>>>>setPartModifyTime 找不到ECN：" + note);
            }

            try{
                saveAttribute(partOid, stamp);
            }catch(Exception e){
                e.printStackTrace();
                System.out.println(">>>>>setPartModifyTime 更新修改时间失败：" + part.getNumber());
            }
            System.out.println(">>>>>setPartModifyTime 更新修改时间成功：" + part.getNumber());
        }
    }

    public static void saveAttribute(Long oid, Timestamp stamp) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {

            String updateSql = "UPDATE wtpart SET MODIFYSTAMPA2 = ? WHERE IDA2A2 = ?";
            statement = connection.prepareStatement(updateSql);
            statement.setTimestamp(1, stamp);
            statement.setLong(2, oid);
            int updateCount = statement.executeUpdate();
            connection.getConnection().commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null){}
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
    }

    public static Map<Long, Long> getData() throws Exception {
        Map<Long, Long> map = new HashMap<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.IDA2A2,b.IDA2A2 FROM wtpart t")
                    .append(" LEFT JOIN WTPARTMASTER w on t.IDA3MASTERREFERENCE = w.IDA2A2")
                    .append(" LEFT JOIN(SELECT t1.IDA2A2,")
                    .append(" SUBSTR(t1.NOTEITERATIONINFO, INSTR(t1.NOTEITERATIONINFO, '-') + 1, 10) ecrnumber")
                    .append(" FROM wtpart t1")
                    .append(" ) a ON a.IDA2A2 = t.IDA2A2")
                    .append(" LEFT JOIN")
                    .append(" (SELECT wm.NAME, wm.WTCHGREQUESTNUMBER, r.CREATESTAMPA2, r.IDA2A2 FROM WTCHANGEREQUEST2 r , WTCHANGEREQUEST2MASTER wm WHERE 1=1")
                    .append(" AND r.IDA3MASTERREFERENCE = wm.IDA2A2) b ON b.WTCHGREQUESTNUMBER = a.ecrnumber")
                    .append(" WHERE t.NOTEITERATIONINFO LIKE 'ECR系统自动修订-%'");
            statement = connection.prepareStatement(sql.toString());
            ResultSet rs = statement.executeQuery();
            System.out.println(">>>>>getData sql:" + sql.toString());
            while(rs.next()){
                Long partOid = rs.getLong(1);
                Long ecrOid = rs.getLong(2);
                if(CtFormatUtil.hasContent(partOid) && CtFormatUtil.hasContent(ecrOid)){
                    map.put(partOid, ecrOid);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null){
                statement.close();
            }
            if (connection != null && connection.isActive()){
                connection.release();
            }
        }
        System.out.println(">>>>>getData map:" + map.size());
        return map;
    }

    @Override
    public void initializeBaselineData() throws Exception {
        Set<Long> dSet = getAllHasBomLastPart(CtConstant.VIEW_DESIGN);
        Set<Long> mSet = getAllHasBomLastPart(CtConstant.VIEW_MANUFACTURING);
        dSet.addAll(mSet);
        Iterator<Long> it = dSet.iterator();
        CtBomBaselineBoMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtBomBaselineBoMapper.class);
        while(it.hasNext()){
            List<CtBomBaselineBo> boList = new ArrayList<>();
            Long partOid = it.next();
            String or = "OR:wt.part.WTPart:" + partOid;
            WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(or);
            if(null == part){
                continue;
            }
            CtBomBaselineQueryServiceImpl.addLinks(part, boList, mapper, part.getViewName());
            //保存bom父子项小版本的关系
            for(CtBomBaselineBo bo : boList){
                mapper.insert(bo);
            }
            System.out.println(">>>>>BOM基线数据初始化，物料【" + part.getNumber() + "】视图【" +part.getViewName()+"】初始化完毕！");
        }
    }

    /**
     * 查询所有有BOM的最新版父项
     * @return
     * @throws Exception
     */
    public static Set<Long> getAllHasBomLastPart(String viewName) throws Exception {
        Set<Long> set = new HashSet<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT DISTINCT t.IDA2A2 FROM WTPARTUSAGELINK w")
                    .append(" LEFT JOIN wtpart t ON w.IDA3A5 = t.IDA2A2 AND t.LATESTITERATIONINFO = 1")
                    .append(" LEFT JOIN WTVIEW w2 on t.IDA3VIEW = w2.IDA2A2")
                    .append(" WHERE w2.NAME = ?")
                    .append(" AND t.VERSIONSORTIDA2VERSIONINFO = (SELECT max(w4.VERSIONSORTIDA2VERSIONINFO) FROM wcadmin.WTPART w4 WHERE w4.IDA3MASTERREFERENCE = t.IDA3MASTERREFERENCE")
                    .append(" AND w4.LATESTITERATIONINFO=1 AND w4.IDA3VIEW=t.IDA3VIEW)");
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, viewName);
            ResultSet rs = statement.executeQuery();
            System.out.println(">>>>>getAllHasBomLastPart sql:" + sql.toString());
            while(rs.next()){
                Long partOid = rs.getLong(1);
                set.add(partOid);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("数据库异常，请联系管理员！异常信息：" + e.getMessage());
        } finally {
            if (statement != null){
                statement.close();
            }
            if (connection != null && connection.isActive()){
                connection.release();
            }
        }
        return set;
    }

    @Override
    public List<WTDocument> getAllLastDoc() throws Exception {
        List<WTDocument> list = new ArrayList<>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.IDA2A2 FROM WTDOCUMENT t, WTTYPEDEFINITION w, WTTYPEDEFINITIONMASTER w2")
            .append(" WHERE 1=1 AND w.IDA3MASTERREFERENCE = w2.IDA2A2")
            .append(" AND t.LATESTITERATIONINFO = 1")
            .append(" AND t.STATECHECKOUTINFO = 'c/i'")
            .append(" AND t.STATESTATE IN ('INWORK','InChang','RELEASED','CANCELLED','Deactivate')")
            .append(" AND t.VERSIONSORTIDA2VERSIONINFO = (SELECT max(w4.VERSIONSORTIDA2VERSIONINFO) FROM wcadmin.WTDOCUMENT w4")
            .append(" WHERE w4.IDA3MASTERREFERENCE = t.IDA3MASTERREFERENCE AND w4.LATESTITERATIONINFO=1)")
            .append(" AND t.IDA2TYPEDEFINITIONREFERENCE = w.IDA2A2")
            .append(" AND w2.DISPLAYNAMEKEY IN (")
                .append("'com.fhsj.Doc_tssm',")
                .append("'com.fhsj.Doc_cxlct',")
                .append("'com.fhsj.Doc_fj',")
                .append("'com.fhsj.Doc_yjsczjjxt',")
                .append("'com.fhsj.Doc_dbrjydm',")
                .append("'com.fhsj.Doc_dbrjslwj',")
                .append("'com.fhsj.Doc_dbrjzkwj',")
                .append("'com.fhsj.Doc_dbrjzxsjwj',")
                .append("'com.fhsj.Doc_dbrjzcbg',")
                .append("'com.fhsj.Doc_dbrjyzbg',")
                .append("'com.fhsj.Doc_dbrjbbgxjl',")
                .append("'com.fhsj.Doc_dbrjrjzl',")
                .append("'com.fhsj.Doc_dbrjsjsms',")
                .append("'com.fhsj.Doc_gcwj',")
                .append("'com.fhsj.Doc_pcbdb',")
                .append("'com.fhsj.Doc_dxf',")
                .append("'com.fhsj.Doc_wfgwwj',")
                .append("'com.fhsj.Doc_pcbeqwj',")
                .append("'com.fhsj.Doc_zzg',")
                .append("'com.fhsj.Doc_ylthpcbshwj',")
                .append("'com.fhsj.Doc_pcbgyshwj',")
                .append("'com.fhsj.Doc_bomscbg',")
                .append("'com.fhsj.Doc_pcbxhvna',")
                .append("'com.fhsj.Doc_dbyjtsjlwd',")
                .append("'com.fhsj.Doc_dbtszjbg',")
                .append("'com.fhsj.Doc_dbyjtcbg',")
                .append("'com.fhsj.Doc_yjhfxmjdjh',")
                .append("'com.fhsj.Doc_dbyjsjsms',")
                .append("'com.fhsj.Doc_xtldbg',")
                .append("'com.fhsj.Doc_xwlxxsms',")
                .append("'com.fhsj.Doc_dlcsjsyhgbg',")
                .append("'com.fhsj.Doc_zxwtbg',")
                .append("'com.fhsj.Doc_emczgzjbg',")
                .append("'com.fhsj.Doc_yjsccpsysc',")
                .append("'com.fhsj.yjscpyssm',")
                .append("'com.fhsj.Doc_dbrjcsbg',")
                .append("'com.fhsj.Doc_dbrjdycsbg',")
                .append("'com.fhsj.Doc_dbrjcsbgzdcs',")
                .append("'com.fhsj.Doc_rjkfxmjdjh',")
                .append("'com.fhsj.Doc_pcbzbsqb',")
                .append("'com.fhsj.Doc_cjbcpbmhjfj',")
                .append("'com.fhsj.Doc_yfybzzsqd',")
                .append("'com.fhsj.Doc_cpsms',")
                .append("'com.fhsj.Doc_cpsmsyzsm',")
                .append("'com.fhsj.Doc_jssms',")
                .append("'com.fhsj.Doc_slsm',")
                .append("'com.fhsj.Doc_dmysbg',")
                .append("'com.fhsj.Doc_StencilFiles',")
                .append("'com.fhsj.Doc_pbpcbwj',")
                .append("'com.fhsj.Doc_gwzzsmwj',")
                .append("'com.fhsj.Doc_yjscyszz',")
                .append("'com.fhsj.ghyswj',")
                .append("'com.fhsj.Doc_yzbjggysmwj',")
                .append("'com.fhsj.Doc_pcbwlbmcjbcp',")
                .append("'com.fhsj.Doc_idf',")
                .append("'com.fhsj.Doc_xxxx',")
                .append("'com.fhsj.Doc_ExportSTEP',")
                .append("'com.fhsj.Doc_GerberFiles',")
                .append("'com.fhsj.Doc_NCDrillFiles')");
            statement = connection.prepareStatement(sql.toString());
            result = statement.executeQuery();
            while (result.next()) {
                Long ida2a2 = result.getLong(1);
                String docOr = "OR:wt.doc.WTDocument:" + ida2a2;
                WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(docOr);
                list.add(doc);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return list;
    }
}
