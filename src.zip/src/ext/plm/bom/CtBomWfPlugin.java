package ext.plm.bom;

import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtConstant;
import ext.plm.integration.sap.CtSapInterface;
import ext.plm.integration.sap.CtSapLogic;
import ext.plm.integration.sap.bo.CtSapResultBo;
import ext.plm.part.CtPartLogic;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtWorkFlowUtil;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CtBomWfPlugin {


    /**
     * 应用于：样机BOM发布(),试产BOM发布、量产BOM发布流程的 提交任务结点的 完成转变条件
     * BOM发布时，是否有内容、物料状态是否合法、是否有重复物料等校验
     * @param pbo
     * @throws WTException
     */
    public static void checkBOM(WTObject pbo) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            String errorResult = "";

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> bomList = new ArrayList<WTPart>();

            // 获取需要升级状态的所有物料
            boolean hasMPart = false;
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    WTPart part = (WTPart)tmpObj;
                    if(CtConstant.VIEW_MANUFACTURING.equals(part.getViewName())){
                        hasMPart = true;
                        break;
                    }
                    bomList.add(part);
                }
            }

            //有M视图则不检验BOM
            if(hasMPart){
                return;
            }

            // **********验证1： 防止空BOM发布**********//
            String emptyError = CtBomLogic.checkBom_isEmpty(bomList);
            if (CtFormatUtil.hasContent(emptyError)) {
                //整个BOM不合法，不继续检查下阶，先抛出异常
                throw new WTException(emptyError);
            }

            // ******验证2：检验重复物料**********//
            String duplicateError = CtBomLogic.checkBom_duplicateMaterial(bomList);

            if(CtFormatUtil.hasContent(duplicateError)) {
                errorResult +=duplicateError;
            }

            // ******验证3：检验BOM下的物料状态**********//

            String materialInvalidError = CtBomLogic.checkBom_areMaterialsValid(promotionNotice, bomList);

            if (CtFormatUtil.hasContent(materialInvalidError)) {
                errorResult += materialInvalidError;
            }

            // ******验证4：检验替代组与优先级**********//
            String replaceGroupError = CtBomLogic.checkBom_replaceGroup(bomList);
            if (CtFormatUtil.hasContent(replaceGroupError)) {
                errorResult += replaceGroupError;
            }

            //一起抛出异常
            if(CtFormatUtil.hasContent(errorResult)) {
                throw new WTException(errorResult);
            }

        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }

    /**
     * 应用于试产BOM生效流程
     * 应用于：提交结点的”完成任务“转变条件
     * 检查BOM下阶物料的合法性
     * @return 校验结果信息
     * @throws Exception
     */
    @Deprecated
    public static void trail_checkBOM(WTObject pbo) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            String errorResult = "";

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> bomList = new ArrayList<WTPart>();

            // 获取需要升级状态的所有物料
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    bomList.add((WTPart)tmpObj);
                }
            }
            // **********验证1： 防止空BOM发布**********//
            String emptyError = CtBomLogic.checkBom_isEmpty(bomList);
            if (CtFormatUtil.hasContent(emptyError)) {
                //整个BOM不合法，不继续检查下阶，先抛出异常
                throw new WTException(emptyError);
            }

            // ******验证2：检验重复物料**********//
            String duplicateError = CtBomLogic.checkBom_duplicateMaterial(bomList);

            if(CtFormatUtil.hasContent(duplicateError)) {
                errorResult +=duplicateError;
            }

            // ******检验BOM下的物料状态**********//

            String materialInvalidError = CtBomLogic.checkTrialBom_areMaterialsValid(promotionNotice, bomList);

            if (CtFormatUtil.hasContent(materialInvalidError)) {
                errorResult += materialInvalidError;
            }


            //一起抛出异常
            if(CtFormatUtil.hasContent(errorResult)) {
                throw new WTException(errorResult);
            }

        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }


    /**
     * 应用于样机BOM生效流程
     * 应用于：提交结点的”完成任务“转变条件
     * 检查BOM下阶物料的合法性
     * @return 校验结果信息
     * @throws Exception
     */
    @Deprecated
    public static void prototype_checkBOM(WTObject pbo) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            String errorResult = "";

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> bomList = new ArrayList<WTPart>();

            // 获取需要升级状态的所有物料
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    bomList.add((WTPart)tmpObj);
                }
            }

            // **********验证1： 防止空BOM发布**********//
            String emptyError = CtBomLogic.checkBom_isEmpty(bomList);
            if (CtFormatUtil.hasContent(emptyError)) {
                //整个BOM不合法，不继续检查下阶，先抛出异常
                throw new WTException(emptyError);
            }

            // ******验证2：检验重复物料**********//
            String duplicateError = CtBomLogic.checkBom_duplicateMaterial(bomList);

            if(CtFormatUtil.hasContent(duplicateError)) {
                errorResult +=duplicateError;
            }
            // ******检验BOM下的物料状态**********//

            String materialInvalidError = CtBomLogic.checkPrototypeBom_areMaterialsValid(promotionNotice, bomList);

            if (CtFormatUtil.hasContent(materialInvalidError)) {
                errorResult += materialInvalidError;
            }

            //一起抛出异常
            if(CtFormatUtil.hasContent(errorResult)) {
                throw new WTException(errorResult);
            }

        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }


    /**
     * 应用EBOM生效流程
     * 应用于：提交结点的”完成任务“转变条件
     * 检查BOM下阶物料的合法性
     * @return 校验结果信息
     * @throws Exception
     */
    @Deprecated
    public static void EBOM_checkBOM(WTObject pbo) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            String errorResult = "";

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> bomList = new ArrayList<WTPart>();

            // 获取需要升级状态的所有物料
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    bomList.add((WTPart)tmpObj);
                }
            }

            // **********验证1： 防止空BOM发布**********//
            String emptyError = CtBomLogic.checkBom_isEmpty(bomList);
            if (CtFormatUtil.hasContent(emptyError)) {
                //整个BOM不合法，不继续检查下阶，先抛出异常
                throw new WTException(emptyError);
            }

            // ******验证2：检验重复物料**********//
            String duplicateError = CtBomLogic.checkBom_duplicateMaterial(bomList);

            if(CtFormatUtil.hasContent(duplicateError)) {
                errorResult +=duplicateError;
            }

            // ******检验BOM下的物料状态**********//

            String materialInvalidError = CtBomLogic.checkEBom_areMaterialsValid(promotionNotice, bomList);

            if (CtFormatUtil.hasContent(materialInvalidError)) {
                errorResult += materialInvalidError;
            }

            //一起抛出异常
            if(CtFormatUtil.hasContent(errorResult)) {
                throw new WTException(errorResult);
            }

        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }


    /**
     * 应用MBOM生效流程
     * 应用于：提交结点的”完成任务“转变条件
     * 检查BOM下阶物料的合法性
     * @return 校验结果信息
     * @throws Exception
     */
    @Deprecated
    public static void MBOM_checkBOM(WTObject pbo) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            String errorResult = "";

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> bomList = new ArrayList<WTPart>();

            // 获取需要升级状态的所有物料
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    bomList.add((WTPart)tmpObj);
                }
            }

            // **********验证1： 防止空BOM发布**********//
            String emptyError = CtBomLogic.checkBom_isEmpty(bomList);
            if (CtFormatUtil.hasContent(emptyError)) {
                //整个BOM不合法，不继续检查下阶，先抛出异常
                throw new WTException(emptyError);
            }

            // ******验证2：检验重复物料**********//
            String duplicateError = CtBomLogic.checkBom_duplicateMaterial(bomList);

            if(CtFormatUtil.hasContent(duplicateError)) {
                errorResult +=duplicateError;
            }

            // ******检验BOM下的物料状态**********//

            String materialInvalidError = CtBomLogic.checkMBom_areMaterialsValid(promotionNotice, bomList);

            if (CtFormatUtil.hasContent(materialInvalidError)) {
                errorResult += materialInvalidError;
            }

            //一起抛出异常
            if(CtFormatUtil.hasContent(errorResult)) {
                throw new WTException(errorResult);
            }

        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }

    /**
     * 应用原材料生效流程提交
     * 应用于：提交结点的”完成任务“转变条件
     * 检查BOM下阶物料的合法性
     * @return 校验结果信息
     * @throws Exception
     */
    @Deprecated
    public static void material_checkBOM(WTObject pbo) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            String errorResult = "";

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> bomList = new ArrayList<WTPart>();

            // 获取需要升级状态的所有物料
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    bomList.add((WTPart)tmpObj);
                }
            }

            // ******检验BOM下的物料状态**********//


            String materialInvalidError = CtBomLogic.isLinkedMaterialAdmission(promotionNotice, bomList);

            if (CtFormatUtil.hasContent(materialInvalidError)) {
                errorResult += materialInvalidError;
            }

            //一起抛出异常
            if(CtFormatUtil.hasContent(errorResult)) {
                throw new WTException(errorResult);
            }

        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }


    /**

     * 应用于：提交结点的”完成任务“转变条件
     * 检查BOM下阶物料的合法性
     * @return 校验结果信息
     * @throws Exception
     */
    @Deprecated
    public static void EtoM_checkBOM(WTObject pbo) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            String errorResult = "";

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> bomList = new ArrayList<WTPart>();

            // 获取需要升级状态的所有物料
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    bomList.add((WTPart)tmpObj);
                }
            }


            // **********验证1： 防止空BOM发布**********//
            String emptyError = CtBomLogic.checkBom_isEmpty(bomList);
            if (CtFormatUtil.hasContent(emptyError)) {
                //整个BOM不合法，不继续检查下阶，先抛出异常
                throw new WTException(emptyError);
            }

            // ******验证2：检验重复物料**********//
            String duplicateError = CtBomLogic.checkBom_duplicateMaterial(bomList);

            if(CtFormatUtil.hasContent(duplicateError)) {
                errorResult +=duplicateError;
            }
            // ******检验BOM下的物料状态**********//

            String materialInvalidError = CtBomLogic.checkMBom_areMaterialsValid(promotionNotice, bomList);

            if (CtFormatUtil.hasContent(materialInvalidError)) {
                errorResult += materialInvalidError;
            }

            //一起抛出异常
            if(CtFormatUtil.hasContent(errorResult)) {
                throw new WTException(errorResult);
            }

        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }

    /**
     * 应用于BOM发布流程，“SAP BOM集成"表达式
     * 与SAP集成BOM
     * @param pbo
     * @param failedBoms 上次失败的BOM,为json格式 {bom_Number1:'plant1,plant2',bom_Number2:'plant1,plant2'}
     * @param bomType BOM类型，0为样机,1为生产BOM， 2为试产BOM
     * @return  HashMap {errorMsg:多个发送失败的异常信息, failedBoms:失败的物料}， 无异常返回null
     * @throws WTException
     */
    public static HashMap<String,String> createSapBom(WTObject pbo, String failedBoms,String bomType) throws WTException {

        PromotionNotice promotionNotice = (PromotionNotice)pbo;

        String processNo = "升级请求："+promotionNotice.getNumber();
        String newFailedBoms = "";//记录失败物料
        String failedErrorMsg = ""; //记录发送失败的异常信息
        // 创建失败的BOM，按“料号：工厂列表”的map格式
        JSONObject failedBomMap = new JSONObject();

        HashMap<String,String> result = null;
        List<String> plantList = null; //工厂
        boolean continueFlag = false;// 是否续传标志
        JSONObject lastFailedBomMap = null;

        List<WTPart> bomList = new ArrayList<WTPart>();
        try {
            if(CtFormatUtil.hasContent(failedBoms)) {
                // 续传BOM
                continueFlag = true;
                lastFailedBomMap = JSONObject.parseObject(failedBoms);
                for (String bomNumber : lastFailedBomMap.keySet()) {
                    WTPart tmpPart ;
                    if("0".equals(bomType)){
                        tmpPart= CtPartUtil.getPartByNumber(bomNumber, CtConstant.VIEW_DESIGN);
                    }else{
                        tmpPart= CtPartUtil.getPartByNumber(bomNumber, CtConstant.VIEW_MANUFACTURING);
                    }
                    bomList.add(tmpPart);
                }
            }else {
                //第一次, 从升级请求中拿数据
                QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
                while (qr.hasMoreElements()) {
                    Object tmpObj = qr.nextElement();
                    if(tmpObj instanceof WTPart){
                        WTPart part = (WTPart) tmpObj;
                        bomList.add(part);
                    }
                }
            }
            List<String> bomNumList=new ArrayList<>();
            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof WTPart){
                    WTPart part = (WTPart) tmpObj;
                    bomNumList.add(part.getNumber());
                }
            }
            for(WTPart bom: bomList) {

                // ****先确认要发送的工厂
                plantList = new ArrayList<>();
                if (continueFlag) {
                    // 续传从json中拿失败的工厂列表
                    String failedPlants = lastFailedBomMap.getString(bom.getNumber());
                    for (String tmpPlant : failedPlants.split(",")) {
                        plantList.add(tmpPlant);
                    }
                } else {
                    plantList = CtSapLogic.getPlants();
                }

                for (String plant : plantList) {
                    try {
                        // 创建对应的bom
                        CtSapInterface.createSapBOM(processNo, bom, bomType, plant,bomNumList);
                    } catch (Exception e) {
                        // 不抛异常，记录失败的BOM：工厂信息，下次续传
                        String failException = "BOM " + bom.getNumber() + ", 工厂 " + plant
                                + " :" + e.getMessage();
                        failedErrorMsg = CtFormatUtil.combineStr(failedErrorMsg, failException, "\r\n");
                        String plants = "";//收集bom创建异常工厂集合
                        if (failedBomMap.containsKey(bom.getNumber())) {
                            plants = failedBomMap.getString(bom.getNumber());
                        }
                        // 增加失败的工厂记录
                        plants = CtFormatUtil.combineStr(plants, plant);
                        failedBomMap.put(bom.getNumber(), plants);
                    }
                }

            }

        }catch(Exception e) {
            e.printStackTrace();
            throw new WTException(e,"与SAP集成BOM失败，异常信息: "+e.getMessage());
        }

        if (CtFormatUtil.hasContent(failedErrorMsg) || failedBomMap.keySet().size() > 0) {
            result = new HashMap<String,String>();
            result.put("errorMsg", "接口异常信息：\r\n"+failedErrorMsg);
            result.put("failedBoms", failedBomMap.toJSONString());
        }

        return result;
    }

    /**
     * ext.plm.bom.CtBomWfPlugin.checkBOMBindDocument()
     * @param pbo
     * @throws WTException
     */
    public static void checkBOMBindDocument(WTObject pbo) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;
            WfProcess process = CtWorkFlowUtil.getProcessByPbo(pbo);
            String name = process.getTemplate().getName();

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> partList = new ArrayList<WTPart>();

            // 获取需要升级状态的所有物料
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    partList.add((WTPart)tmpObj);
                }
            }

            // ******检验升级状态下的物料绑定的文档**********//


            //是否报错，没有报错就直接通过
            String materialInvalidError = CtBomLogic.checkPartAndDocsBind(partList,name);

            if (CtFormatUtil.hasContent(materialInvalidError)) {
                throw new WTException(materialInvalidError);
            }


        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }

    /**
     * 初始化转MBOM表格数据
     * ext.plm.bom.CtBomWfPlugin.saveConvertBomBo(primaryBusinessObject)
     * @param pbo
     * @throws WTException
     */
    public static void saveConvertBomBo(WTObject pbo) throws Exception {
        try{
            PromotionNotice pn = (PromotionNotice) pbo;
            CtBomLogic.saveConvertBomBo(pn);
        }catch (Exception e) {
            throw new WTException(e, "后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }

    /**
     * 校验转MBOM表格数据--（成品/半成品、试产专用成品）设计BOM生效流程
     * ext.plm.bom.CtBomWfPlugin.checkConvertBomData(primaryBusinessObject)
     * @param pbo
     * @throws WTException
     */
    public static void checkConvertBomData(WTObject pbo) throws Exception {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        try{
            PromotionNotice pn = (PromotionNotice) pbo;
            CtBomLogic.checkConvertBomData(pn);
        }finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
    }

    /**
     * 发送SAP时的校验，提前到提交时和创建升级时
     * ext.plm.bom.CtBomWfPlugin.SapBeforeSendStateCheck(primaryBusinessObject,"0");
     */
    public static void SapBeforeSendStateCheck(WTObject pbo,String bomType) throws WTException {

        try {
            //针对升级流程
            PromotionNotice promotionNotice = (PromotionNotice) pbo;

            QueryResult qr = MaturityHelper.service.getPromotionTargets(promotionNotice);
            List<WTPart> partList = new ArrayList<WTPart>();
            List<String> partNumList = new ArrayList<>();

            // 获取需要升级状态的所有物料
            while (qr.hasMoreElements()) {
                Object tmpObj = qr.nextElement();
                if(tmpObj instanceof  WTPart){
                    partList.add((WTPart)tmpObj);
                    partNumList.add(((WTPart) tmpObj).getNumber());
                }
            }

            //开始校验
            String errorResult = "";
            for (WTPart part : partList) {
                try{
                    if(bomType.equals("0")){
                        //样机BOM不发送下阶未发SAP的物料（因此变更时也走发布接口，需要手动删除SAP中的样机BOM）
                          CtSapLogic.genSapSampleBomItemList(part,partNumList);
                    }else if(bomType.equals("2")){
                        //试产
                         CtSapLogic.genSapTrialBomItemList(part,partNumList);
                    }else if(bomType.equals("1")){
                        //量产
                         CtSapLogic.genSapMassProductionBomItemList(part,partNumList);
                    }
                }catch (Exception e){
                    String failException = "BOM " + part.getNumber() + "  :" + e.getMessage();
                    errorResult = CtFormatUtil.combineStr(errorResult, failException, "\r\n");
                }
            }
            if (errorResult.length()>0){
                throw new WTException("物料状态不符合：\r\n"+errorResult);
            }
        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e,"后台异常，请联系管理员！异常信息：" + e.getMessage());
        }
    }

}
