package ext.plm.bom;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.bo.CtBomSearchViewBo;
import ext.plm.bom.bo.CtConvertBomBo;
import ext.plm.bom.bo.CtEMHistoryViewLinkBo;
import ext.plm.bom.dao.CtConvertBomDao;
import ext.plm.bom.mapper.CtEMHistoryViewLinkMapper;
import ext.plm.common.CtConstant;
import ext.plm.part.bo.CtPartHistoryLinkViewRefBo;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtVersionUtil;
import ext.plm.util.CtWTObjectUtil;
import ext.plm.util.IBAUtil;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartConfigSpec;
import wt.part.WTPartHelper;
import wt.part.WTPartStandardConfigSpec;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;

@Service
public class CtBomHistoryViewServiceImpl implements CtBomHistoryViewService {
	@Resource
	private CtEMHistoryViewLinkMapper ctEMHistoryViewLinkMapper;
	private Logger logger = Logger.getLogger(CtBomHistoryViewServiceImpl.class);

	/**
	 * 筛选BOM
	 * 
	 * @param bo
	 * @param pathList
	 * @throws Exception
	 */
	public void filterBom(CtBomSearchViewBo bo, List<String> pathList) throws Exception {
		List<CtBomSearchViewBo> childList = bo.getChildren();
		boolean isEligible = false;
		Iterator<CtBomSearchViewBo> it = childList.iterator();
		while (it.hasNext()) {
			CtBomSearchViewBo childBo = it.next();
			isEligible = isEligible(childBo, pathList);
			if (isEligible) {
				if (CtFormatUtil.hasContent(childBo.getChildren())) {
					// 递归处理子项的子项
					filterBom(childBo, pathList);
				}
			} else {
				// 移除掉不合格的子项
				it.remove();
			}
		}
	}

	/**
	 * 判断当前子项是否合格
	 * 
	 * @param childBo
	 * @param pathList
	 * @return
	 * @throws Exception
	 */
	public boolean isEligible(CtBomSearchViewBo childBo, List<String> pathList) throws Exception {
		for (String path : pathList) {
			if (path.contains("/" + childBo.getPartNumber() + "/")) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 筛选出符合条件的数据的路径（因符合条件子项的父项不论是否符合条件，都需要留在树结构中，所以先得到符合条件的路径集合，
	 * 用于后面匹配去除掉不符合条件的数据）
	 * 
	 * @param bo
	 * @return
	 * @throws Exception
	 */
	public void getEligiblePath(CtBomSearchViewBo bo, List<String> pathList, Map<String, String> conditionMap)
			throws Exception {
		List<CtBomSearchViewBo> childList = bo.getChildren();
		boolean isEligible = false;
		for (CtBomSearchViewBo childBo : childList) {
			isEligible = filterData(childBo, conditionMap);
			if (isEligible) {
				pathList.add(childBo.getPartPath() + "/");
				// 设置符合条件的标识
				childBo.setTargetObject("Y");
			}
			if (CtFormatUtil.hasContent(childBo.getChildren())) {
				// 递归筛选子项的子项
				getEligiblePath(childBo, pathList, conditionMap);
			}
		}
	}

	/**
	 * 筛选数据
	 * 
	 * @param bo
	 * @param conditionMap
	 * @return
	 * @throws Exception
	 */
	public boolean filterData(CtBomSearchViewBo bo, Map<String, String> conditionMap) throws Exception {
		String type = conditionMap.get("type");
		String state = conditionMap.get("state");
		String commonParam = conditionMap.get("commonParam");
		// 类型
		if (CtFormatUtil.hasContent(type)) {
			boolean inType = false;
			String[] typeArray = type.split(",");
			for (int i = 0; i < typeArray.length; i++) {
				if (typeArray[i].equals(bo.getPartType())) {
					inType = true;
					break;
				}
			}
			if (!inType) {
				return false;
			}
		}
		// 状态
		if (CtFormatUtil.hasContent(state)) {
			boolean inState = false;
			String[] stateArray = state.split(",");
			for (int i = 0; i < stateArray.length; i++) {
				if (stateArray[i].equals(bo.getPartState())) {
					inState = true;
					break;
				}
			}
			if (!inState) {
				return false;
			}
		}
		// 公共参数
		if (CtFormatUtil.hasContent(commonParam)) {
			String upperCase = commonParam.toUpperCase();
			// 部件编号
			if (bo.getPartNumber().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 部件名称
			if (bo.getPartName().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 内部版本
			if (CtFormatUtil.hasContent(bo.getInternalVersion())
					&& bo.getInternalVersion().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 版本
			if (CtFormatUtil.hasContent(bo.getVersion()) && bo.getVersion().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 状态
			if (bo.getPartState().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 默认单位
			if (CtFormatUtil.hasContent(bo.getDefaultUnit()) && bo.getDefaultUnit().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 数量
			if (CtFormatUtil.hasContent(bo.getQuantity()) && bo.getQuantity().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 位号
			if (CtFormatUtil.hasContent(bo.getReferenceDesignatorRange())
					&& bo.getReferenceDesignatorRange().toUpperCase().contains(upperCase)) {
				return true;
			}
			// BOM备注
			if (CtFormatUtil.hasContent(bo.getRemarks()) && bo.getRemarks().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 是否RoHS
			if (CtFormatUtil.hasContent(bo.getIsRoHS()) && bo.getIsRoHS().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 创建人
			if (CtFormatUtil.hasContent(bo.getCreator()) && bo.getCreator().toUpperCase().contains(upperCase)) {
				return true;
			}
			// 修改人
			if (CtFormatUtil.hasContent(bo.getEditor()) && bo.getEditor().toUpperCase().contains(upperCase)) {
				return true;
			}
		} else {
			return true;
		}
		return false;
	}

	/**
	 * 递归收集BOM下的所有的Part
	 * 
	 * @param fatherPart
	 * @param bo
	 * @param selectView
	 * @throws Exception
	 */
	public void getAllPartsInBOMByView(WTPart fatherPart, CtBomSearchViewBo bo, View selectView) throws Exception {
		WTPartConfigSpec configSpec = null;
		if (selectView == null) {
			selectView = ViewHelper.service.getView(fatherPart.getViewName());
		}
		configSpec = WTPartConfigSpec
				.newWTPartConfigSpec(WTPartStandardConfigSpec.newWTPartStandardConfigSpec(selectView, null));
		QueryResult queryResult = WTPartHelper.service.getUsesWTParts(fatherPart, configSpec);
		while (queryResult.hasMoreElements()) {
			Persistable[] results = (Persistable[]) queryResult.nextElement();
			if (!(results[0] instanceof WTPartUsageLink) || !(results[1] instanceof WTPart)) {
				continue;
			}
			// 添加子部件
			WTPartUsageLink usageLink = (WTPartUsageLink) results[0];
			WTPart partSon = (WTPart) results[1];
			CtBomSearchViewBo childBo = new CtBomSearchViewBo(partSon, bo, usageLink);
			List<CtBomSearchViewBo> childBoList = bo.getChildren();
			childBoList.add(childBo);
			getAllPartsInBOMByView(partSon, childBo, selectView);
		}
		if (!CtFormatUtil.hasContent(bo.getChildren())) {
			bo.setLeaf(true);
		}
	}

	/**
	 * 导出excel
	 * 
	 * @param parentPart
	 *            前端传过来的树形数据
	 * @param sheet
	 *            工作薄
	 * @param rowIndexMap
	 *            行数
	 * @param level
	 *            层次，用于缩进编号，导出能看到树的效果
	 * @throws Exception
	 */
	public void writeRowData(JSONObject parentPart, Sheet sheet, Map<String, Integer> rowIndexMap, int level)
			throws Exception {
		// 写入父项
		writeCellData(parentPart, sheet, rowIndexMap, level);
		// 子项
		JSONArray childArray = parentPart.getJSONArray("children");
		if (CtFormatUtil.hasContent(childArray)) {
			level++;
			for (int i = 0; i < childArray.size(); i++) {
				// 行数加1
				rowIndexMap.put("rowIndex", rowIndexMap.get("rowIndex") + 1);
				// 递归写入子项
				JSONObject childPart = childArray.getJSONObject(i);
				writeRowData(childPart, sheet, rowIndexMap, level);
			}
		}
	}

	/**
	 * 单行数据的写入
	 * 
	 * @param part
	 * @param sheet
	 * @param rowIndexMap
	 * @param level
	 * @throws Exception
	 */
	public void writeCellData(JSONObject part, Sheet sheet, Map<String, Integer> rowIndexMap, int level)
			throws Exception {
		int rowIndex = rowIndexMap.get("rowIndex");
		Row row = sheet.getRow(rowIndex);
		if (null == row) {
			row = sheet.createRow(rowIndex);
		}
		// 目标对象
		CtExcelReadUtil.setExcelCellValue(0, part.getString("targetObject"), row);
		// 在子项编号前面添加空格，通过这种缩进的方式，展示数形结构
		StringBuilder numberBuilder = new StringBuilder();
		for (int i = 0; i < level; i++) {
			numberBuilder.append("    ");
		}
		numberBuilder.append(part.getString("partNumber"));
		// 编号
		CtExcelReadUtil.setExcelCellValue(1, numberBuilder.toString(), row);
		// 名称
		CtExcelReadUtil.setExcelCellValue(2, part.getString("partName"), row);
		// 内部版本
		CtExcelReadUtil.setExcelCellValue(3, part.getString("internalVersion"), row);
		// 版本
		CtExcelReadUtil.setExcelCellValue(4, part.getString("version"), row);
		// 状态
		CtExcelReadUtil.setExcelCellValue(5, part.getString("partState"), row);
		// 默认单位
		CtExcelReadUtil.setExcelCellValue(6, part.getString("defaultUnit"), row);
		// 数量
		CtExcelReadUtil.setExcelCellValue(7, part.getString("quantity"), row);
		// 位号
		CtExcelReadUtil.setExcelCellValue(8, part.getString("referenceDesignatorRange"), row);
		// BOM备注
		CtExcelReadUtil.setExcelCellValue(9, part.getString("remarks"), row);
		// 是否RoHS
		CtExcelReadUtil.setExcelCellValue(10, part.getString("isRoHS"), row);
		// 创建人
		CtExcelReadUtil.setExcelCellValue(11, part.getString("creator"), row);
		// 修改人
		CtExcelReadUtil.setExcelCellValue(12, part.getString("editor"), row);
	}

	/**
	 * 保存E/M视图关联关系
	 * 
	 * @param bo
	 * @throws Exception
	 */
	@Override
	public void saveHistoryViewLink(CtEMHistoryViewLinkBo bo) throws Exception {
		ctEMHistoryViewLinkMapper.saveHistoryViewLink(bo);
	}

	/**
	 * 通过制造视图的物料，查询关联关系
	 * 
	 * @param roleA
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<CtEMHistoryViewLinkBo> queryViewLinkByManufacturing(Long roleA) throws Exception {
		return ctEMHistoryViewLinkMapper.queryHistoryViewLinkByRoleA(roleA);
	}

	/**
	 * 查询E/M视图物料历史记录
	 * 
	 * @param partOid
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<CtPartHistoryLinkViewRefBo> queryPartViewRef(Long partOid) throws Exception {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
		List<CtPartHistoryLinkViewRefBo> resultList = new ArrayList<>();
		WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid("OR:wt.part.WTPart:" + partOid);
		if (null == part) {
			return resultList;
		}
		Long masterId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
		List<CtEMHistoryViewLinkBo> linkList = new ArrayList<>();
		if (CtConstant.VIEW_DESIGN.equals(part.getViewName())) {
			// 设计视图物料
			linkList = ctEMHistoryViewLinkMapper.queryHistoryViewLinkByRoleA(masterId);
		} else {
			// 制造视图物料
			linkList = ctEMHistoryViewLinkMapper.queryHistoryViewLinkByRoleB(masterId);
		}
		if (CtFormatUtil.hasContent(linkList)) {
			for (CtEMHistoryViewLinkBo ctEMHistoryViewLinkBo : linkList) {
				Long vrA = ctEMHistoryViewLinkBo.getVroleA();
				WTPart refPartA = null;
				;
				try {
					refPartA = CtPartUtil.getPartByOid(String.valueOf(vrA));
				} catch (Exception e) {

				}
				Long vrB = ctEMHistoryViewLinkBo.getVroleB();
				WTPart refPartB = null;
				try {
					refPartB = CtPartUtil.getPartByOid(String.valueOf(vrB));
				} catch (Exception e) {

				}
				if (CtConstant.VIEW_DESIGN.equals(part.getViewName())) {
					CtPartHistoryLinkViewRefBo bo = getPartHistoryViewRefBo(refPartA, refPartB, dateFormat,
							ctEMHistoryViewLinkBo.getChangeRecords(), ctEMHistoryViewLinkBo.getNumberA() + "",
							ctEMHistoryViewLinkBo.getVersionA(), ctEMHistoryViewLinkBo.getNumberB() + "",
							ctEMHistoryViewLinkBo.getVersionB());
					resultList.add(bo);
				} else {
					CtPartHistoryLinkViewRefBo bo = getPartHistoryViewRefBo(refPartB, refPartA, dateFormat,
							ctEMHistoryViewLinkBo.getChangeRecords(), ctEMHistoryViewLinkBo.getNumberB() + "",
							ctEMHistoryViewLinkBo.getVersionB(), ctEMHistoryViewLinkBo.getNumberA() + "",
							ctEMHistoryViewLinkBo.getVersionA());
					resultList.add(bo);
				}
			}
		}
		return resultList;
	}

	/**
	 * 添加部件的所有版本到集合中
	 * 
	 * @param refPart
	 * @param resultList
	 * @param dateFormat
	 * @throws Exception
	 */
	// public void addPartAllVersion(WTPart refPart,
	// List<CtPartHistoryLinkViewRefBo> resultList, SimpleDateFormat dateFormat)
	// throws Exception {
	// List<CtPartHistoryLinkViewRefBo> refPartBoList = new ArrayList<>();
	// QueryResult queryResult =
	// VersionControlHelper.service.allIterationsOf(refPart.getMaster());
	// while (queryResult.hasMoreElements()) {
	// WTPart refPartVersion = (WTPart) queryResult.nextElement();
	// // 副本不显示
	// if (WorkInProgressHelper.isWorkingCopy(refPartVersion)) {
	// continue;
	// }
	// // 过滤视图
	// if (!refPart.getViewName().equals(refPartVersion.getViewName())) {
	// continue;
	// }
	// CtPartHistoryLinkViewRefBo refBo = getPartViewRefBo(refPartVersion,
	// dateFormat);
	//
	// refPartBoList.add(refBo);
	// }
	// // 取倒序
	// Collections.reverse(refPartBoList);
	// // 添加到结果集合中
	// resultList.addAll(refPartBoList);
	// }

	// /**
	// * 设置bo属性
	// *
	// * @param part
	// * @param dateFormat
	// * @return
	// * @throws Exception
	// */
	// public CtPartLinkViewRefBo getPartViewRefBo(WTPart part, SimpleDateFormat
	// dateFormat) throws Exception {
	// CtPartHistoryLinkViewRefBo ctPartViewRefBo = new
	// CtPartHistoryLinkViewRefBo();
	// ctPartViewRefBo.setId(part.getPersistInfo().getObjectIdentifier().getId()
	// + "");
	// ctPartViewRefBo.setPartNumber(CtCommonUtil.getURL(part,
	// part.getNumber()));
	// String version = CtVersionUtil.getVersionInfo(part);
	// ctPartViewRefBo.setPartVersion(version + "(" + part.getViewName() + ")");
	// ctPartViewRefBo.setPartState(part.getLifeCycleState().getDisplay(Locale.CHINA));
	// ctPartViewRefBo.setModifyUser(part.getModifierFullName());
	// ctPartViewRefBo.setCreateTime(dateFormat.format(part.getCreateTimestamp()));
	// ctPartViewRefBo.setModifyTime(dateFormat.format(part.getModifyTimestamp()));
	// ctPartViewRefBo.setPartNote(part.getIterationNote());
	// return ctPartViewRefBo;
	// }

	/**
	 * 设置bo属性
	 * 
	 * @param part
	 * @param dateFormat
	 * @return
	 * @throws Exception
	 */
	@Override
	public CtPartHistoryLinkViewRefBo getPartHistoryViewRefBo(WTPart partA, WTPart partB, SimpleDateFormat dateFormat,
			String changeRecords, String numberA, String versionA, String numberB, String versionB) throws Exception {
		if (null == dateFormat) {
			dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		}
		CtPartHistoryLinkViewRefBo ctPartViewRefBo = new CtPartHistoryLinkViewRefBo();
		boolean jg = false;
		if (null != partA) {
			ctPartViewRefBo.setIdA(partA.getPersistInfo().getObjectIdentifier().getId() + "");
//			ctPartViewRefBo.setPartANumber(CtCommonUtil.getURL(partA, partA.getNumber()));
			ctPartViewRefBo.setPartANumber(partA.getNumber());
			ctPartViewRefBo.setPartABranchId(partA.getBranchIdentifier()+"");
			String versionA1 = CtVersionUtil.getVersionInfo(partA);
			ctPartViewRefBo.setPartAVersion(versionA1 + "(" + partA.getViewName() + ")");
			ctPartViewRefBo.setPartAState(partA.getLifeCycleState().getDisplay(Locale.CHINA));
			ctPartViewRefBo.setModifyUserA(partA.getModifierFullName());
			ctPartViewRefBo.setCreateTimeA(dateFormat.format(partA.getCreateTimestamp()));
			ctPartViewRefBo.setModifyTimeA(dateFormat.format(partA.getModifyTimestamp()));
			ctPartViewRefBo.setPartANote(partA.getIterationNote());
			// 物料编码+内部版本
			IBAUtil ibaUtil = new IBAUtil(partA);
			try {
				String actualVersion = ibaUtil.getIBAValue("ct_banci");
				ctPartViewRefBo.setInternalVersionA(actualVersion);
			} catch (Exception e) {

			}
		} else {
			ctPartViewRefBo.setPartANumber(numberA);
			ctPartViewRefBo.setPartAVersion(versionA);
			jg = true;
		}
		if (null != partB) {
			ctPartViewRefBo.setIdB(partB.getPersistInfo().getObjectIdentifier().getId() + "");
//			ctPartViewRefBo.setPartBNumber(CtCommonUtil.getURL(partB, partB.getNumber()));
			ctPartViewRefBo.setPartBBranchId(partB.getBranchIdentifier()+"");
			ctPartViewRefBo.setPartBNumber(partB.getNumber());
			String versionB2 = CtVersionUtil.getVersionInfo(partB);
			ctPartViewRefBo.setPartBVersion(versionB2 + "(" + partB.getViewName() + ")");
			ctPartViewRefBo.setPartBState(partB.getLifeCycleState().getDisplay(Locale.CHINA));
			ctPartViewRefBo.setModifyUserB(partB.getModifierFullName());
			ctPartViewRefBo.setCreateTimeB(dateFormat.format(partB.getCreateTimestamp()));
			ctPartViewRefBo.setModifyTimeB(dateFormat.format(partB.getModifyTimestamp()));
			ctPartViewRefBo.setPartBNote(partB.getIterationNote());
			// 物料编码+内部版本
			IBAUtil ibaUtilB = new IBAUtil(partB);
			try {
				String actualVersionB = ibaUtilB.getIBAValue("ct_banci");
				ctPartViewRefBo.setInternalVersionB(actualVersionB);
			} catch (Exception e) {

			}
		} else {
			ctPartViewRefBo.setPartBNumber(numberB);
			ctPartViewRefBo.setPartBVersion(versionB);
			jg = true;
		}
		if (jg) {
			ctPartViewRefBo.setChangeRecords("断开");
		} else {
			ctPartViewRefBo.setChangeRecords(changeRecords);
		}
		return ctPartViewRefBo;
	}

	/**
	 * 更新“是否已转M视图”字段和“M视图物料编码”
	 * 
	 * @param boList
	 * @throws Exception
	 */
	public static void updateMPartInfo(List<CtConvertBomBo> boList) throws Exception {
		CtConvertBomDao ctConvertBomDao = CtBeanFactory.newCtBeanFactory().getBean(CtConvertBomDao.class);
		for (CtConvertBomBo bo : boList) {
			String partNumber = bo.getPartNumber();
			WTPart part = CtPartUtil.getPartByNumber(partNumber);
			if (null == part) {
				continue;
			}
			// 是否已转M视图
			WTPart mPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
			if (null == mPart) {
				bo.setConvertMView("否");
			} else {
				bo.setConvertMView("是");
			}
			// M视图物料编码
			bo.setManufacturingNumber("");// 先初始化
			List<String> mPartNumbers = new ArrayList<>();
			if (null != mPart) {
				mPartNumbers.add(mPart.getNumber() + "(" + mPart.getLifeCycleState().getDisplay(Locale.CHINA) + ")");
			}
			CtEMHistoryViewLinkMapper ctEMHistoryViewLinkMapper = CtBeanFactory.newCtBeanFactory()
					.getBean(CtEMHistoryViewLinkMapper.class);
			List<CtEMHistoryViewLinkBo> CtEMHistoryViewLinkBos = ctEMHistoryViewLinkMapper
					.queryHistoryViewLinkByRoleB(part.getMaster().getPersistInfo().getObjectIdentifier().getId());
			for (CtEMHistoryViewLinkBo CtEMHistoryViewLinkBo : CtEMHistoryViewLinkBos) {
				WTPart aPart = CtPartUtil.getPartByMasterId(CtEMHistoryViewLinkBo.getRoleA());
				if (null == aPart) {
					continue;
				}
				WTPart lastAPart = CtPartUtil.getPartByNumber(aPart.getNumber(), CtConstant.VIEW_MANUFACTURING);
				if (null == lastAPart) {
					continue;
				}
				mPartNumbers.add(
						lastAPart.getNumber() + "(" + lastAPart.getLifeCycleState().getDisplay(Locale.CHINA) + ")");
			}
			if (mPartNumbers.size() > 0) {
				bo.setManufacturingNumber(StringUtils.join(mPartNumbers, ","));
			}
			// 更新到数据库
			ctConvertBomDao.updateConvertBomInfo(bo);
		}
	}

	/**
	 * 反射设置对象值
	 * 
	 * @param o
	 * @param key
	 * @param value
	 * @throws Exception
	 */
	public static void setObjectValue(Object o, String key, String value) throws Exception {
		// 反射设置属性值
		Field field = o.getClass().getDeclaredField(key);
		field.setAccessible(true);
		String fieldType = field.getType().toString();
		int lastIndex = fieldType.lastIndexOf(".");
		fieldType = fieldType.substring(lastIndex + 1);
		if ("String".equals(fieldType)) {
			field.set(o, value == null ? null : value.trim());
		} else if ("Date".equals(fieldType)) {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			Date date = !hasContent(value) ? null : df.parse(value);
			field.set(o, date);
		}
	}

	/**
	 *
	 * @Description hasContent
	 * @param content
	 * @return
	 */
	public static boolean hasContent(String content) {
		return content != null && !"".equals(content.trim()) && !"null".equalsIgnoreCase(content.trim());
	}

	@Override
	public CtEMHistoryViewLinkBo getCtEMHistoryViewLinkBo(WTPart partA, WTPart partB, String changeRecords)
			throws Exception {
		WTUser curUser = (WTUser) SessionHelper.manager.getPrincipal();
		CtEMHistoryViewLinkBo hbo = new CtEMHistoryViewLinkBo();
		hbo.setRoleA(partA.getMaster().getPersistInfo().getObjectIdentifier().getId());
		hbo.setVroleA(partA.getPersistInfo().getObjectIdentifier().getId());
		String versionA = CtVersionUtil.getVersionInfo(partA);
		String versionAC = (versionA + "(" + partA.getViewName() + ")");
		hbo.setNumberA(partA.getNumber());
		hbo.setVersionA(versionAC);
		hbo.setRoleB(partB.getMaster().getPersistInfo().getObjectIdentifier().getId());
		hbo.setVroleB(partB.getPersistInfo().getObjectIdentifier().getId());
		String versionB = CtVersionUtil.getVersionInfo(partB);
		String versionBC = (versionB + "(" + partB.getViewName() + ")");
		hbo.setNumberB(partB.getNumber());
		hbo.setVersionB(versionBC);
		hbo.setChangeRecords(changeRecords);
		hbo.setCreateUser(curUser.getName());
		hbo.setModifyUser(curUser.getName());
		hbo.setCreateTime(new Date());
		hbo.setModifyTime(new Date());
		return hbo;
	}

}
