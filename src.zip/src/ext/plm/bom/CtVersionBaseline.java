package ext.plm.bom;

import ext.plm.bom.config.CtBomConstant;
import ext.plm.part.config.CtPartConstant;
import ext.plm.util.CtBomUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.IBAUtil;
import org.apache.log4j.Logger;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartUsageLink;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.vc.config.ConfigSpec;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.WorkInProgressServiceEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: lzp
 * @Date: 2023/10/30
 * @Description:判断内部版本基线与系统版本基线是否需要修改
 */
public class CtVersionBaseline {
    static Logger logger = Logger.getLogger(CtVersionBaseline.class);
    public static void versionBaseline(WorkInProgressServiceEvent eventObject) throws Exception {
        WTPart oldPart = (WTPart) ((WorkInProgressServiceEvent) eventObject).getOriginalCopy();
        WTPart newPart = (WTPart) ((WorkInProgressServiceEvent) eventObject).getWorkingCopy();

        List<WTPart> getAllSubPartNew = getAllChildrenParts(newPart);
        List<WTPart> getAllSubPartOld = getAllChildrenParts(oldPart);


        for(int i = 0; i<getAllSubPartNew.size(); i++){
            WTPart partNew = getAllSubPartNew.get(i);
            boolean addNew = true;
            //循环旧部件判断与新关联关系相比是否有任意值改变
            for(int j = 0; j<getAllSubPartOld.size(); j++){
                WTPart partOld = getAllSubPartOld.get(j);
                if(partNew.getNumber().equals(partOld.getNumber())){
                    addNew = false;
                    WTPartUsageLink linkNew = CtBomUtil.getUsageLink(newPart,partNew);
                    //WTPartUsageLink linkOld = CtBomUtil.getUsageLink(oldPart,partOld);

                    //String numberNew = CtBomUtil.getBomAmout(linkNew);
                    //String numberOld  = CtBomUtil.getBomAmout(linkOld);

                    //String tagNumberNew = CtBomUtil.getReferenceDesignator(linkNew);
                    //String tagNumberOld  = CtBomUtil.getReferenceDesignator(linkOld);

                    IBAUtil ibaNew = new IBAUtil(linkNew);
                    //IBAUtil ibaOld = new IBAUtil(linkOld);

                    //if(CtFormatUtil.hasContent(numberNew)&&CtFormatUtil.hasContent(numberOld)){
                    //    if(!(numberNew.equals(numberOld))) {
                            String version = partNew.getVersionIdentifier().getValue() + "." + partNew.getIterationIdentifier().getValue();
                            //系统版本基线内部名称
                            ibaNew.setIBAValue(CtBomConstant.VERSION_BASELINE, version);

                            IBAUtil ibaOld1 = new IBAUtil(partNew);
                            //内部版本
                            String banci = ibaOld1.getIBAValue(CtPartConstant.IBA_BAN_CI);
                            if(!CtFormatUtil.hasContent(banci)||"Default".equals(banci)){
                                //内部版本基线
                                ibaNew.setIBAValue(CtBomConstant.CT_BANCI_BASELINE, "");
                            }else {
                                ibaNew.setIBAValue(CtBomConstant.CT_BANCI_BASELINE, banci);
                            }
                    //    }
                    //}
                    //if((CtFormatUtil.hasContent(numberNew)&&!CtFormatUtil.hasContent(numberOld))
                    //        ||(!CtFormatUtil.hasContent(numberNew)&&CtFormatUtil.hasContent(numberOld))){
                    //    String version = partNew.getVersionIdentifier().getValue() + "." + partNew.getIterationIdentifier().getValue();
                    //    ibaNew.setIBAValue("version_baseline", version);
                    //
                    //    IBAUtil ibaOld1 = new IBAUtil(partNew);
                    //    String banci = ibaOld1.getIBAValue("ct_banci");
                    //    ibaNew.setIBAValue("ct_banci_baseline", banci);
                    //}
                    //if(CtFormatUtil.hasContent(tagNumberNew)&&CtFormatUtil.hasContent(tagNumberOld)){
                    //    if(!tagNumberNew.equals(tagNumberOld)) {
                    //        String version = partNew.getVersionIdentifier().getValue() + "." + partNew.getIterationIdentifier().getValue();
                    //        ibaNew.setIBAValue("version_baseline", version);
                    //
                    //        IBAUtil ibaOld1 = new IBAUtil(partNew);
                    //        String banci = ibaOld1.getIBAValue("ct_banci");
                    //        ibaNew.setIBAValue("ct_banci_baseline", banci);
                    //    }
                    //}
                    //if((CtFormatUtil.hasContent(tagNumberNew)&&!CtFormatUtil.hasContent(tagNumberOld))
                    //        ||(!CtFormatUtil.hasContent(tagNumberNew)&&CtFormatUtil.hasContent(tagNumberOld))){
                    //    String version = partNew.getVersionIdentifier().getValue() + "." + partNew.getIterationIdentifier().getValue();
                    //    ibaNew.setIBAValue("version_baseline", version);
                    //
                    //    IBAUtil ibaOld1 = new IBAUtil(partNew);
                    //    String banci = ibaOld1.getIBAValue("ct_banci");
                    //    ibaNew.setIBAValue("ct_banci_baseline", banci);
                    //}
                    ibaNew.updateIBAHolder(linkNew);

                }
            }
            if(addNew){
                //新增部件添加基线
                WTPartUsageLink linkNew = CtBomUtil.getUsageLink(newPart,partNew);
                IBAUtil ibaNew = new IBAUtil(linkNew);
                String version = partNew.getVersionIdentifier().getValue() + "." + partNew.getIterationIdentifier().getValue();
                ibaNew.setIBAValue(CtBomConstant.VERSION_BASELINE, version);
                IBAUtil ibaOld1 = new IBAUtil(partNew);
                String banci = ibaOld1.getIBAValue(CtPartConstant.IBA_BAN_CI);

                if(!CtFormatUtil.hasContent(banci)||"Default".equals(banci)){
                    ibaNew.setIBAValue(CtBomConstant.CT_BANCI_BASELINE, "");
                }else {
                    ibaNew.setIBAValue(CtBomConstant.CT_BANCI_BASELINE, banci);
                }
                ibaNew.updateIBAHolder(linkNew);
            }
        }
    }

    //获取当前部件第一层子部件
    public static ArrayList<WTPart> getAllChildrenParts(WTPart parentPart) throws WTException {
        boolean access = SessionServerHelper.manager.setAccessEnforced(false);
        ArrayList<WTPart> childparts = new ArrayList<WTPart>();
        try {
            ConfigSpec config = new LatestConfigSpec();//最新配置
            QueryResult qr = WTPartHelper.service.getUsesWTParts(parentPart, config);
            while (qr.hasMoreElements()) {
                Persistable[] pts = (Persistable[]) qr.nextElement();
                if ((pts instanceof Persistable[]) && (pts[1] instanceof WTPart)) { //数组0 是link关系对象
                    WTPart childPart = (WTPart) pts[1];
                    childparts.add(childPart);
                }
            }
        } catch (Exception e) {
            logger.error("判断内部版本基线与系统版本基线是否需要修改错误:"+e);
        } finally {
            SessionServerHelper.manager.setAccessEnforced(access);
        }
        return childparts;
    }



}
