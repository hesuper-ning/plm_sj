package ext.plm.bom.dao;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import ext.plm.bom.bo.CtConvertBomBo;
import ext.plm.bom.mapper.CtConvertBomMapper;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class CtConvertBomDao extends ServiceImpl<CtConvertBomMapper, CtConvertBomBo> {

    @Resource
    private CtConvertBomMapper ctConvertBomMapper;

    /**
     * 查询流程中的转bom表格信息
     * @param pnId
     * @return
     * @throws Exception
     */
    public List<CtConvertBomBo> queryConvertBomInfo(Long pnId) throws Exception {
        return ctConvertBomMapper.queryConvertBomInfo(pnId);
    }

    /**
     * 通过id查询转bom数据
     * @param id
     * @return
     * @throws Exception
     */
    public CtConvertBomBo queryConvertBomInfoById(String id) throws Exception {
        return ctConvertBomMapper.queryConvertBomInfoById(id);
    }

    /**
     * 通过流程id和物料编号查bo数据
     * @param pnId
     * @param partNumber
     * @return
     * @throws Exception
     */
    public CtConvertBomBo queryConvertBomBoByPnIdAndNumber(Long pnId, String partNumber) throws Exception {
        return ctConvertBomMapper.queryConvertBomBoByPnIdAndNumber(pnId, partNumber);
    }

    /**
     * 通过物料编号查询流程中的转bom表格信息
     * @param partNumber
     * @return
     * @throws Exception
     */
    public List<CtConvertBomBo> queryConvertBomBoByNumber(String partNumber) throws Exception {
        return ctConvertBomMapper.queryConvertBomBoByNumber(partNumber);
    }

    /**
     * 更新转bom数据
     * @param bo
     * @return
     * @throws Exception
     */
    public void updateConvertBomInfo(CtConvertBomBo bo) throws Exception {
        ctConvertBomMapper.updateConvertBomInfo(bo);
    }

    /**
     * 保存
     * @param bo
     * @throws Exception
     */
    public void saveConvertBomBo(CtConvertBomBo bo) throws Exception {
        ctConvertBomMapper.saveConvertBomBo(bo);
    }

    /**
     * 查询流程中的转bom表格信息
     * @param masterId
     * @return
     * @throws Exception
     */
    public List<CtConvertBomBo> queryPartPageConvertBomBo(Long masterId) throws Exception {
        return ctConvertBomMapper.queryPartPageConvertBomBo(masterId);
    }

}
