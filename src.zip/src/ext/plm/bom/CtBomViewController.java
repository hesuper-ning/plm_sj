package ext.plm.bom;

import com.alibaba.fastjson.JSONObject;
import ext.plm.bom.bo.CtBomSearchViewBo;
import ext.plm.bom.bo.CtConvertBomBo;
import ext.plm.common.CtConstant;
import ext.plm.common.CtResApiResult;
import ext.plm.part.bo.CtPartViewRefBo;
import ext.plm.report.part.CtPartReportHelper;
import ext.plm.util.CtBomUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtWTObjectUtil;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import wt.maturity.PromotionNotice;
import wt.part.WTPart;
import wt.session.SessionServerHelper;
import wt.workflow.work.WorkItem;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@ResponseBody
public class CtBomViewController {

    static Logger logger = Logger.getLogger(CtBomViewController.class);

    @Autowired
    private CtBomViewService ctBomViewService;

    /**
     * 按搜索条件搜索当前物料的BOM
     * @param oid
     * @param type
     * @param state
     * @param commonParam
     * @return
     */
    @RequestMapping(value = "/bom/searchBom", method = {RequestMethod.GET, RequestMethod.POST})
    public CtResApiResult searchBom(String oid, String type, String state, String commonParam) {
        try {
            CtBomSearchViewBo ctBomSearchViewBo = ctBomViewService.searchBom(oid, type, state, commonParam);
            List<CtBomSearchViewBo> list = new ArrayList<>();
            //如果根节点有子项被搜索到，或者自身被搜索到，才需要显示数据
            if(null != ctBomSearchViewBo){
                if(CtFormatUtil.hasContent(type) || CtFormatUtil.hasContent(state) || CtFormatUtil.hasContent(commonParam)){
                    //有参时，要搜索到内容才显示
                    if(ctBomSearchViewBo.getChildren().size() > 0 || "Y".equals(ctBomSearchViewBo.getTargetObject())){
                        list.add(ctBomSearchViewBo);
                    }
                }else{
                    //无参时，也要显示数据
                    list.add(ctBomSearchViewBo);
                }
            }
            return CtResApiResult.children(list);
        } catch (Exception e) {
            logger.error("部件筛选视图搜索异常：", e);
            return CtResApiResult.fail( "搜索失败：" +e.getLocalizedMessage());
        }
    }

    /**
     * 导出筛选视图的数据
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/bom/exportFilterBom", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportFilterBom(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Workbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "筛选视图-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String bomData = IOUtils.toString(reader);

            //生成需要导出的excel
            workbook = ctBomViewService.exportFilterBom(bomData);
            workbook.write(response.getOutputStream());
        } catch (Exception e) {
            logger.error("导出筛选视图的数据异常:", e);
            throw new Exception("导出筛选视图的数据异常：" + e.getLocalizedMessage());
        } finally {
            if(null != workbook){
                //workbook.close();
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(inputStreamReader != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

    /**
     * 搜索设计视图的物料
     * @param
     * @throws Exception
     */
    @GetMapping(value = "/view/searchPart")
    public CtResApiResult searchPart(@RequestParam("partNumber")String partNumber) throws Exception {
        try {
            List<Map<String, String>> list = ctBomViewService.searchPart(partNumber);
            return CtResApiResult.success(list);
        } catch (Exception e) {
            logger.error("搜索设计视图的物料异常:", e);
            return CtResApiResult.fail( "搜索设计视图的物料，后台异常信息：\r\n" +e.getLocalizedMessage());
        }
    }

    /**
     * 查询已选的d视图物料
     * @param
     * @throws Exception
     */
    @GetMapping(value = "/view/getSelectNumbers")
    public CtResApiResult getSelectNumbers(@RequestParam("selectNumbers") String selectNumbers) throws Exception {
        try {
            List<Map<String, String>> list = new ArrayList<>();
            if(!"NA".equals(selectNumbers)){
                list = ctBomViewService.getSelectNumbers(selectNumbers);
            }
            return CtResApiResult.success(list);
        } catch (Exception e) {
            logger.error("查询已选的d视图物料异常:", e);
            return CtResApiResult.fail( "查询已选的d视图物料，后台异常信息：\r\n" +e.getLocalizedMessage());
        }
    }

    /**
     * 查询E/M视图物料历史记录
     * @param
     * @throws Exception
     */
    @GetMapping(value = "/view/queryPartViewRef")
    public CtResApiResult queryPartViewRef(@RequestParam("partOid")String partOid) throws Exception {
        try {
            List<CtPartViewRefBo> list = new ArrayList<>();
            if(CtFormatUtil.hasContent(partOid)){
                //前台传过来的有可能是vr，也有可能是or，先转成部件对象
                WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(partOid);
                if(null != part){
                    Long oid = part.getPersistInfo().getObjectIdentifier().getId();
                    list = ctBomViewService.queryPartViewRef(oid);
                }
            }
            return CtResApiResult.success(list);
        } catch (Exception e) {
            logger.error("查询E/M视图物料历史记录异常:", e);
            return CtResApiResult.fail( "查询E/M视图物料历史记录失败，后台异常信息：\r\n" +e.getLocalizedMessage());
        }
    }

    /**
     * 查询流程的转BOM信息
     * @param
     * @throws Exception
     */
    @GetMapping(value = "/bom/queryConvertBomInfo")
    public CtResApiResult queryConvertBomInfo(@RequestParam("workItemOid")String workItemOid) throws Exception {
        try {
            List<CtConvertBomBo> list = new ArrayList<>();
            wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
            Object object = rf.getReference(workItemOid).getObject();
            if(object instanceof WorkItem){
                //流程节点
                WorkItem workItem = (WorkItem) object;
                Object obj = workItem.getPrimaryBusinessObject().getObject();
                if(obj instanceof PromotionNotice){
                    PromotionNotice pn = (PromotionNotice) obj;
                    list = ctBomViewService.queryConvertBomInfo(pn.getPersistInfo().getObjectIdentifier().getId());
                }
            }else if(object instanceof PromotionNotice){
                PromotionNotice pn = (PromotionNotice) object;
                list = ctBomViewService.queryConvertBomInfo(pn.getPersistInfo().getObjectIdentifier().getId());
            }else{
                //部件页面
                WTPart part = (WTPart) object;
                Long masterId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
                WTPart mPart = CtPartUtil.getPartByNumber(part.getNumber(), CtConstant.VIEW_MANUFACTURING);
                if(null != mPart){
                    //查询没有pnId的，有pnId的是在流程中的
                    list = ctBomViewService.queryPartPageConvertBomBo(masterId);
                }else{
                    list = ctBomViewService.queryPartPageConvertBomBo(masterId);
                    if(CtFormatUtil.hasContent(list)){
                        //上次是否已转
                        boolean isConvert = false;
                        for(CtConvertBomBo bo : list){
                            if(bo.getPartNumber().equals(part.getNumber()) && "是".equals(bo.getConvertMView())){
                                isConvert = true;
                                break;
                            }
                        }
                        //如果已转，就需要删除历史数据
                        if(isConvert){
                            //删除历史的
                            for(CtConvertBomBo bo : list){
                                ctBomViewService.deleteConvertBomBo(bo.getId());
                            }
                            //初始化
                            list = CtBomLogic.saveConvertBomBoPartPage(part);
                        }
                    }else{
                        //初始化
                        list = CtBomLogic.saveConvertBomBoPartPage(part);
                    }
                }
            }
            return CtResApiResult.success(list);
        } catch (Exception e) {
            logger.error("查询流程的转BOM信息:", e);
            return CtResApiResult.fail( "查询流程的转BOM信息：\r\n" +e.getLocalizedMessage());
        }
    }

    /**
     * 根据id更新转BOM表格数据
     * @param id
     * @param key
     * @param value
     * @return
     */
    @PostMapping(value = "/bom/updateConvertBomInfo", produces = "application/json;charset=UTF-8")
    public CtResApiResult updateConvertBomInfo(String id, String key, String value) {
        try {
            return CtResApiResult.success(ctBomViewService.updateConvertBomBoById(id, key, value));
        } catch (Exception e) {
            logger.error("更新转BOM表格数据异常:", e);
            return CtResApiResult.fail("后台异常：" + e.getLocalizedMessage());
        }
    }

    /**
     * 转MBOM功能
     * @param numbers
     * @param workItemOid
     * @return
     */
    @PostMapping(value = "/bom/convertBom", produces = "application/json;charset=UTF-8")
    public CtResApiResult convertBom(String numbers, String workItemOid) {
        try {
            wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
            Object object = rf.getReference(workItemOid).getObject();
            if(object instanceof WorkItem){
                //流程节点
                WorkItem workItem = (WorkItem) object;
                Object obj = workItem.getPrimaryBusinessObject().getObject();
                if(obj instanceof PromotionNotice){
                    PromotionNotice pn = (PromotionNotice) obj;
                    ctBomViewService.convertBom(numbers, pn, null);
                }
            }else{
                //部件页面
                WTPart part = (WTPart) object;
                Long masterId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
                ctBomViewService.convertBom(numbers, null, masterId);
            }
            return CtResApiResult.success();
        } catch (Exception e) {
            logger.error("转MBOM异常:", e);
            return CtResApiResult.fail(e.getLocalizedMessage());
        }
    }

    /**
     * 导出EBOM/MBOM差异
     * @param userAgent
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "bom/exportBomDifferent", method = {RequestMethod.GET, RequestMethod.POST})
    public void exportBomDifferent(@RequestHeader("User-Agent") String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {
        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        SXSSFWorkbook workbook = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader reader = null;
        try {
            String fileName = "";

            //取得body中的参数
            inputStreamReader = new InputStreamReader(request.getInputStream(), "UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String partNumbers = IOUtils.toString(reader);
            String changeRequestId = request.getParameter("changeRequestId");
            fileName = "EBOM和MBOM差异-" + System.currentTimeMillis() + ".xlsx";
            if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
                //ie
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else if (userAgent.toUpperCase().indexOf("Edge") > 0) {
                //edge
                fileName = new String(fileName.getBytes("GBK"), "ISO8859-1");
            } else {
                //firefox、chrome、safari、opera
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            response.setHeader("Content-disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setContentType("application/vnd.ms-excel;charset=utf-8");
            response.setCharacterEncoding("UTF-8");

            //生成需要导出的excel
            if(CtFormatUtil.hasContent(partNumbers)){
                partNumbers = partNumbers.replace("\"", "");
                List<String> partNumberList = CtPartReportHelper.analysisPartNumbers(partNumbers);
                workbook = CtBomLogic.exportBomDifferent(partNumberList, changeRequestId);
                workbook.write(response.getOutputStream());
            }
        } catch (Exception e) {
            logger.error("导出EBOM和MBOM差异异常:", e);
            throw new Exception("导出EBOM和MBOM差异异常：" + e.getLocalizedMessage());
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
            if(null != workbook){
                workbook.dispose();
                //workbook.close();
                workbook = null;
            }
            if(null != reader){
                reader.close();
                reader = null;
            }
            if(null != inputStreamReader){
                inputStreamReader.close();
                inputStreamReader = null;
            }
        }
    }

}
