package ext.plm.bom.config;

import ext.plm.util.CtDocUtil;
import ext.plm.util.CtExcelReadUtil;
import ext.plm.util.CtFormatUtil;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.doc.WTDocument;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author: heqingbo
 * @Date: 2023/12/4
 * @Description:转MBOM过滤电池物料配置
 */
public class CtConvertBomFilterConfig {

    public static List<String> classList = new ArrayList<>();

    public static String version = "";

    static Logger logger = Logger.getLogger(CtConvertBomFilterConfig.class);

    public static List<String> getConvertBomFilterConfig() throws Exception {
        InputStream is = null;
        try {
            WTDocument doc = CtDocUtil.getDocumentByNumber("CONFIG.0001");
            if(null == doc){
                return new ArrayList<>();
            }


            if(CtFormatUtil.hasContent(version)&&version.equals(doc.getVersionIdentifier().getValue() + "." + doc.getIterationIdentifier().getValue())){
                return classList;
            }

            version = doc.getVersionIdentifier().getValue() + "." + doc.getIterationIdentifier().getValue();

            classList = new ArrayList<>();


            is = CtDocUtil.getInputStreamByDoc(doc);

            XSSFWorkbook workbook = new XSSFWorkbook(is);
            Sheet sheet = workbook.getSheetAt(0);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                String internalName = CtExcelReadUtil.getCellFormatValue(row.getCell(0), row, 0);
                if(!CtFormatUtil.hasContent(internalName)) {
                    break;
                }
                classList.add(internalName);
            }
        } catch (Exception e) {
            logger.error("读取转MBOM过滤电池物料配置文件异常:", e);
            e.printStackTrace();
        } finally {
            if (is != null) {
                is.close();
            }
        }
        return classList;
    }

}
