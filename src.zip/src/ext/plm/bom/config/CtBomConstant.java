package ext.plm.bom.config;

public class CtBomConstant {

    /**
     * 分数
     */
    public final static String IBA_FRACTION = "ct_fraction";
    /**
     * 系统版本基线
     */
    public final static String VERSION_BASELINE = "version_baseline";
    /**
     * 内部版本基线
     */
    public final static String CT_BANCI_BASELINE = "ct_banci_baseline";

    /**
     * 设计视图
     */
    public final static String VIEW_DESIGN = "Design";

    /**
     * 关联Design视图物料
     */
    public final static String IBA_DESIGN_VIEW_PART = "Ct_AssociatedDesignViewPart";

}
