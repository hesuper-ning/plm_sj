package ext.plm.bom.config;

import ext.plm.util.CtFormatUtil;

import java.io.InputStreamReader;
import java.util.Properties;


public class CtBomConfig {


	private static Properties loadConfig() throws Exception{
		Properties configProperties = new Properties();
		configProperties.load(new InputStreamReader(
				CtBomConfig.class.getResourceAsStream("CtBomConfig.properties"), "UTF-8"));
		return configProperties;
	}
	
	/**
	 * 查找配置项
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String getProperty(String key) throws Exception{
		Properties configProperties = loadConfig();
		String result = "";
		String property = configProperties.getProperty(key);
		if(CtFormatUtil.hasContent(property)) {
			result = property;
		}
		
		return result;
	}
	
	

}
