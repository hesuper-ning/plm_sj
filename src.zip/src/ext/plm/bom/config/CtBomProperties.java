package ext.plm.bom.config;

import java.io.InputStreamReader;
import java.util.Properties;

import ext.plm.util.CtFormatUtil;
import wt.util.WTException;


public class CtBomProperties {
	
	
	static Properties constantProperties = new Properties();
	
	static {
		try {
			
			constantProperties.load(new InputStreamReader(
					CtBomProperties.class.getResourceAsStream("CtBomConstant.properties"), "UTF-8"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	};
	
	/**
	 * 查找配置项
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String getPropertity(String key) throws Exception{
		
		String result = "";
		String property = constantProperties.getProperty(key);
		if(CtFormatUtil.hasContent(property)) {
			result = property;
		}
		
		return result;
	}
	
	

}
