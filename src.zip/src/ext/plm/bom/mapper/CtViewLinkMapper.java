package ext.plm.bom.mapper;

import ext.plm.bom.bo.CtViewLinkBo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CtViewLinkMapper {

	void saveViewLink(CtViewLinkBo bo) throws Exception;

	List<CtViewLinkBo> queryViewLinkByRoleA(Long roleA) throws Exception;

	List<CtViewLinkBo> queryViewLinkByRoleB(Long roleB) throws Exception;

	void deleteViewLinkById(CtViewLinkBo bo) throws Exception;
}
