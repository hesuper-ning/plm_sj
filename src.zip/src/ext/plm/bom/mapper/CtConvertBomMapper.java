package ext.plm.bom.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.bom.bo.CtConvertBomBo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CtConvertBomMapper extends BaseMapper<CtConvertBomBo> {

    List<CtConvertBomBo> queryConvertBomInfo(Long pnId) throws Exception;

    List<CtConvertBomBo> queryPartPageConvertBomBo(Long masterId) throws Exception;

    CtConvertBomBo queryConvertBomInfoById(@Param("id") String id) throws Exception;

    void updateConvertBomInfo(@Param("bo") CtConvertBomBo bo) throws Exception;

    CtConvertBomBo queryConvertBomBoByPnIdAndNumber(@Param("pnId") Long pnId, @Param("partNumber") String partNumber) throws Exception;

    List<CtConvertBomBo> queryConvertBomBoByNumber(String partNumber) throws Exception;

    void saveConvertBomBo(CtConvertBomBo bo) throws Exception;

}
