package ext.plm.bom.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import ext.plm.bom.bo.CtEMHistoryViewLinkBo;

@Mapper
public interface CtEMHistoryViewLinkMapper {

	void saveHistoryViewLink(CtEMHistoryViewLinkBo bo) throws Exception;

	List<CtEMHistoryViewLinkBo> queryHistoryViewLinkByRoleA(Long roleA) throws Exception;

	List<CtEMHistoryViewLinkBo> queryHistoryViewLinkByRoleB(Long roleB) throws Exception;

	void deleteHistoryViewLinkById(CtEMHistoryViewLinkBo bo) throws Exception;
}
