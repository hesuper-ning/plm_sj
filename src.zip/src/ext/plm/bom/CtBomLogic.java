package ext.plm.bom;

import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson.JSON;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.bo.CtCompareBo;
import ext.plm.bom.bo.CtConvertBomBo;
import ext.plm.bom.bo.CtExportBomBo;
import ext.plm.bom.bo.CtViewLinkBo;
import ext.plm.bom.config.CtBomConfig;
import ext.plm.bom.config.CtBomConstant;
import ext.plm.bom.config.CtConvertBomFilterConfig;
import ext.plm.bom.dao.CtConvertBomDao;
import ext.plm.bom.mapper.CtViewLinkMapper;
import ext.plm.common.CtConstant;
import ext.plm.ec.CtEcService;
import ext.plm.ec.bo.CtChangeItemBo;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.part.CtPartLogic;
import ext.plm.projectBudget.config.CtProjectBudgetConstant;
import ext.plm.promotion.config.CtPromotionConfig;
import ext.plm.tool.poi.CtExportExcelTool;
import ext.plm.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.occurrence.OccurrenceHelper;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.part.*;
import wt.pom.Transaction;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.ClientTypedUtility;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.views.View;
import wt.vc.views.ViewException;
import wt.vc.views.ViewHelper;

import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

public class CtBomLogic {
    private static Logger logger = Logger.getLogger(CtBomLogic.class);

    static Comparator<String> fitPlaceComparator = new Comparator<String>() {
        @Override
        public int compare(String from, String to) {
            if (from == null || to == null)
                return 0;

            char[] fromChars = from.toCharArray();
            char[] toChars = to.toCharArray();
            int maxLen = fromChars.length >= toChars.length ? fromChars.length : toChars.length;
            for (int i = 0; i < maxLen; i++) {
                char fromChar = fromChars.length > i ? fromChars[i] : '0';
                char toChar = toChars.length > i ? toChars[i] : '0';
                if (((fromChar >= 'A' && fromChar <= 'Z') || (fromChar >= 'a' && fromChar <= 'z'))
                        && ((toChar >= 'A' && toChar <= 'Z') || (toChar >= 'a' && toChar <= 'z'))) {
                    // 如果是字母，则直接根据ASCII码比较
                    int diff = (int) fromChar - (int) toChar;
                    if (diff == 0) {
                        // 说明字母一样，继续比较
                        continue;
                    } else {
                        return diff;
                    }
                } else if (((fromChar >= 'A' && fromChar <= 'Z') || (fromChar >= 'a' && fromChar <= 'z'))
                        || ((toChar >= 'A' && toChar <= 'Z') || (toChar >= 'a' && toChar <= 'z'))) {
                    // 如果是字母，则直接根据ASCII码比较，并带字母的排在后面
                    return (int) fromChar - (int) toChar;
                } else {
                    // 处理数值
                    int fromNum = 0;
                    int toNum = 0;
                    try {
                        fromNum = Integer.parseInt(from.substring(i));
                    } catch (NumberFormatException e) {
                        // 说明后面还有字符或特殊字符，则取该符号之前的数值比较
                        int endIndex = fromChars.length - 1;
                        while (endIndex > i) {
                            try {
                                fromNum = Integer.parseInt(from.substring(i, endIndex));
                                break;
                            } catch (NumberFormatException ex) {
                                // 一直循环到可以转成数值
                                continue;
                            }
                        }
                    }
                    try {
                        toNum = Integer.parseInt(to.substring(i));
                    } catch (NumberFormatException e) {
                        // 说明后面还有字符或特殊字符，则取该符号之前的数值比较
                        int endIndex = toChars.length - 1;
                        while (endIndex > i) {
                            try {
                                toNum = Integer.parseInt(to.substring(i, endIndex));
                                break;
                            } catch (NumberFormatException ex) {
                                endIndex --;
                                // 一直循环到可以转成数值
                                continue;
                            }
                        }
                    }
                    return fromNum - toNum;
                }
            }
            return 0;
        }
    };

    /**
     * BOM下阶转视图   并且移除掉所有BOM中子件的CCB物料
     * @param part
     * @throws Exception
     */
    public static void createSubPartView(WTPart part,String viewName) throws Exception{
        Transaction transaction = null;
        Boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
        transaction = new Transaction();
        transaction.start();
        try{
            removeCBBInMbom(part);
            List<WTPart> allPartsInBOM = new ArrayList<>();
            allPartsInBOM = CtBomUtil.getAllPartsInBOM(part,allPartsInBOM);
            for (WTPart wtPart : allPartsInBOM) {
                //过滤原材料(1/4开头的)
                //K开头的为基础物料，类型是原材料，也过滤掉
                if(wtPart.getNumber().startsWith("1")||wtPart.getNumber().startsWith("4")
                        ||wtPart.getNumber().startsWith("K1")||wtPart.getNumber().startsWith("K4")){
                    continue;
                }
                //过滤掉CBB物料
                if(CtWTObjectUtil.getTypeIdentifier(wtPart).contains("ct_CBB"))continue;
                //过滤掉视图一样的
                if(viewName.equals(wtPart.getViewName()))continue;
                //过滤存在当前视图的
                WTPart revisedPart = CtPartUtil.getPartByNumber(wtPart.getNumber(), viewName);
                if(revisedPart != null){
                    continue;
                }

                Folder folder =FolderHelper.getFolder(wtPart);
                View view = ViewHelper.service.getView(viewName);
                revisedPart = (WTPart) ViewHelper.service.newBranchForView(wtPart, view);
                FolderHelper.assignLocation((FolderEntry) revisedPart, folder);
                revisedPart = (WTPart) PersistenceHelper.manager.save(revisedPart);
                revisedPart = (WTPart) PersistenceHelper.manager.refresh(revisedPart);
                //创建制造视图物料设置为工作中状态
                LifeCycleHelper.service.setLifeCycleState(revisedPart, State.toState(CtConstant.STATE_WORKING));
                removeCBBInMbom(revisedPart);

                //保存“关联E/M视图物料”
                CtPartLogic.savePartViewRef(wtPart, revisedPart);
            }
            transaction.commit();
            transaction = null ;
        } catch (ViewException e) {
            e.printStackTrace();
        } catch (WTException e) {
            e.printStackTrace();
        } catch (WTPropertyVetoException e) {
            e.printStackTrace();
        }finally{
            SessionServerHelper.manager.setAccessEnforced(flag);
            if(transaction != null ){
                transaction.rollback();
                transaction = null ;
            }
        }

    }


    /**
     * 检查BOM是否为空
     * @param bomList
     * @return
     * @throws Exception
     */
    public static String checkBom_isEmpty(List<WTPart> bomList) throws Exception{

        String emptyBomErrorMsg = "";
        String emptyBomsStr = "";
        String notEmptyBomsStr = "";
        WTPart tmpBom = null;
        List<WTPart> materials = null;


        for (Iterator<WTPart> ite = bomList.iterator(); ite.hasNext();) {
                tmpBom = ite.next();
                materials = CtBomUtil.getPartsInBOM(tmpBom);
                 IBAUtil ibaUtil = new IBAUtil(tmpBom);
                String ct_materialType = ibaUtil.getIBAValue("ct_materialType");
            String source = tmpBom.getSource().getDisplay(Locale.CHINA);
            if (!"外购".equals(source)&&materials.size() == 0) {
                emptyBomsStr = CtFormatUtil.combineStr(emptyBomsStr, tmpBom.getNumber());
            }
        }

        if(CtFormatUtil.hasContent(emptyBomsStr)){
            emptyBomErrorMsg = "\r\n BOM不能为空，以下BOM不合法:\r\n"+emptyBomsStr;
        }

        return emptyBomErrorMsg;
    }

    /**
     * 检验替代组与优先级
     * @param bomList
     * @return
     * @throws Exception
     */
    public static String checkBom_replaceGroup(List<WTPart> bomList) throws Exception{

        String errorResult = "";
        String invalidReplaceGroupInfo = ""; //不符合规范的替代组
        IBAUtility ibaUtil = null;
        QueryResult qr = null;
        for(WTPart bom:bomList) {
            HashMap<String,String> replaceGroupMap = new HashMap<String,String> ();
            for (qr = PersistenceHelper.manager.navigate(bom, "uses",
                    WTPartUsageLink.class, false); qr.hasMoreElements();) {
                WTPartUsageLink partUsageLink = (WTPartUsageLink) qr
                        .nextElement();
                ibaUtil = new IBAUtility(partUsageLink);
                String replaceGroup = ibaUtil.getIBAValue("ct_substituteGroupNumber");//替代组
                String replacePriority =  ibaUtil.getIBAValue("ct_Alternategrouppriority");//优先级
                if(CtFormatUtil.hasContent(replaceGroup)) {
                    //有替代组情况
                    if(!CtFormatUtil.hasContent(replacePriority)) {
                        //有替代组没优先级
                        WTPartMaster partMaster = (WTPartMaster) partUsageLink.getUses();
                        WTPart childPart = (WTPart) CtVersionUtil.getLatest(partMaster);
                        invalidReplaceGroupInfo = CtFormatUtil.combineStr(invalidReplaceGroupInfo,
                                bom.getNumber()+" 下物料‘"+childPart.getNumber()+"’填写了替代组‘"+replaceGroup+"’但没填写优先级","\r\n");
                    }else {
                        String priorityStr = replaceGroupMap.get(replaceGroup);
                        if(CtFormatUtil.hasContent(priorityStr)) {
                            priorityStr =  CtFormatUtil.combineStr(priorityStr,replacePriority);
                            replaceGroupMap.put(replaceGroup, priorityStr);
                        }else {
                            replaceGroupMap.put(replaceGroup, replacePriority);
                        }
                    }
                }else if(CtFormatUtil.hasContent(replacePriority)) {
                    //有优先级没填写替代组
                    WTPartMaster partMaster = (WTPartMaster) partUsageLink
                            .getUses();
                    WTPart childPart = (WTPart) CtVersionUtil.getLatest(partMaster);
                    invalidReplaceGroupInfo = CtFormatUtil.combineStr(invalidReplaceGroupInfo,
                            bom.getNumber()+"  下物料"+childPart.getNumber()+"填写了优先级但没替代组","\r\n");
                }
            }//~ end of one BOM loop
            //检查是否缺少优先级为1的
            for(String replaceGroup: replaceGroupMap.keySet()) {
                String priorityStr = replaceGroupMap.get(replaceGroup);
                int numberOneCount = 0;//计算优先级为1的数量
                for(String priorityNum :priorityStr.split(",")){
                    if (priorityNum.equals("1")) {
                        numberOneCount++;
                    }
                }
                if(numberOneCount ==0) {
                    invalidReplaceGroupInfo = CtFormatUtil.combineStr(invalidReplaceGroupInfo,
                            bom.getNumber()+" 下替代组’"+replaceGroup+"‘ 缺少优先级为1的主料","\r\n");
                }else if(numberOneCount >1){
                    invalidReplaceGroupInfo = CtFormatUtil.combineStr(invalidReplaceGroupInfo,
                            bom.getNumber()+" 下替代组’"+replaceGroup+"‘ 优先级为1的数量超过1个","\r\n");
                }
            }
        }
        if(CtFormatUtil.hasContent(invalidReplaceGroupInfo)) {
            invalidReplaceGroupInfo = "替代组与优先级检验失败！\r\n"+invalidReplaceGroupInfo;
            errorResult +=invalidReplaceGroupInfo;
        }

        return errorResult;
    }

   /**
     * 检查BOM是否存在重复物料
     * @param bomList
     * @return
     * @throws Exception
     */
    public static String checkBom_duplicateMaterial(List<WTPart> bomList) throws Exception{
        String duplicateError = "";
        for(WTPart bom:bomList) {
            String partType = ClientTypedUtility.getExternalTypeIdentifier(bom);
            partType = partType.substring(partType.lastIndexOf(".")+1);
            String bomDuplicateInfo = CtBomUtil.getBomDuplicateInfo(bom);
            if(CtFormatUtil.hasContent(bomDuplicateInfo)) {
                duplicateError +=bomDuplicateInfo;
            }
        }
        if(CtFormatUtil.hasContent(duplicateError)) {
            duplicateError = "\r\n不允许存在重复物料，以下BOM不合法："+duplicateError;
        }

        return duplicateError;
    }

    /**
     *检查BOM下阶物料状态是否合法
     * (自制原材料也可能包含BOM)
     * @param promotion
     * @return
     * @throws Exception
     */
    public static String checkBom_areMaterialsValid(PromotionNotice promotion, List<WTPart> bomList) throws Exception {
        //该方法作用于物料样机EBOM生效流程，Mbom试产流程，Mbom量产流程提交节点校验
        String targetState = promotion.getMaturityState().getDisplay(Locale.CHINA); //升级目标状态
//        WfProcess process = CtWorkFlowUtil.getProcessByPbo(promotion);
//        String processName = process.getTemplate().getName();
        String errorMsg = "";

        String allow_Material_Valid_States = "";
        if("样机".equals(targetState)){
            allow_Material_Valid_States = CtBomConfig.getProperty("sampleBom_Material_Valid_States");
        }else if("已生效".equals(targetState)){
            allow_Material_Valid_States = CtBomConfig.getProperty("effectBom_Material_Valid_States");
        }else if("试产".equals(targetState)){
            allow_Material_Valid_States = CtBomConfig.getProperty("trailBom_Material_Valid_States");
        }else if("量产".equals(targetState)){
            allow_Material_Valid_States = CtBomConfig.getProperty("productionBom_Material_Valid_States");
        }

        List<String> allowedStateList = new ArrayList<>();
        for(String tmpState : allow_Material_Valid_States.split(",")){
            allowedStateList.add(tmpState);
        }

        List<String> skipPartCheckList = new ArrayList<>(); //同阶发布BOM校验列表
        for (WTPart bom : bomList) {
            skipPartCheckList.add(bom.getNumber());
        }

        for (WTPart bom : bomList) {
            List<WTPart> partsInBOM =new ArrayList<>();
            //样机和已生效找对应D视图BOM校验
            if("样机".equals(targetState)||"已生效".equals(targetState)){
                if(bom.getViewName().equals(CtConstant.VIEW_MANUFACTURING)){
                    throw new Exception("该流程不允许物料M视图发起,请重新选取正确的物料视图发起流程！");
                }
                bom = (WTPart) CtVersionUtil.getLatest(bom.getMaster(),CtConstant.VIEW_DESIGN);
                partsInBOM=CtBomUtil.getPartsInBOMByView(bom,null);//获取下阶bom清单
            }else if("试产".equals(targetState)||"量产".equals(targetState)){
                if(bom.getViewName().equals(CtConstant.VIEW_DESIGN)){
                    throw new Exception("该流程不允许物料D视图发起,请重新选取正确的物料视图发起流程！");
                }
                bom = (WTPart) CtVersionUtil.getLatest(bom.getMaster(),CtConstant.VIEW_MANUFACTURING);
                partsInBOM=CtBomUtil.getPartsInBOMByView(bom,null);//获取下阶bom清单
            }

            for (WTPart tmpPart : partsInBOM) {
                String tmpState = CtWTObjectUtil.getStateDisplay(tmpPart, Locale.CHINA);//获取下阶物料状态

                if (skipPartCheckList.contains(tmpPart.getNumber())) {
                    continue;//同升级对象可以避开状态校验
                }


                boolean invalidFlag = false;
                if (!allowedStateList.contains(tmpState)){
                    invalidFlag = true;
                }else if("认证中".equals(tmpState)&&!"样机".equals(targetState)){
                    //对认证中特殊处理，只有量产BOM不允许认证中，其他允许结构料是认证中状态
                    //增加新逻辑 BOM下阶允许有"认证中"状态物料
//                    if (!CtPartLogic.isStructPart(tmpPart)) {
//                        //非结构料的认证中状态定为非法状态
//                        invalidFlag = true;
//                    }
                }
                //该校验只针对半成品--MBOM
                String type = CtWTObjectUtil.getTypeIdentifier(tmpPart);
                if(type.contains(CtPromotionConfig.getProperty("semiFinishedBomInnerName"))){
                    if(tmpPart.getViewName().equals("Manufacturing")){
                        String trailProperty = CtBomConfig.getProperty("effectMBomToTrail");
                        String[] split = trailProperty.split(",");
                        List<String> list = Arrays.asList(split);
                        String massProperty = CtBomConfig.getProperty("trailMBomToMass");
                        String[] masssplit = massProperty.split(",");
                        List<String> masslist = Arrays.asList(masssplit);
                        if("试产".equals(targetState)&&!list.contains(tmpState)){
                            invalidFlag = true;
                        }else if("量产".equals(targetState)&&!masslist.contains(tmpState)){
                            invalidFlag = true;
                        }
                    }else if("试产".equals(targetState)||"量产".equals(targetState)){
                        errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "  " + tmpState + "【不存在M视图】\r\n";
                        //防止重复报错
                        invalidFlag=false;
                    }
                }
                if(invalidFlag){
                    errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                }
            }//~end of for partsInBOM loop
        }//~ end of for bomList loop

        if (CtFormatUtil.hasContent(errorMsg)) {
            errorMsg = "\r\nBOM检验失败，以下物料状态不符合要求: " + "\r\n" + errorMsg;
        }

        return errorMsg;
    }


    /**
     * 检查试产BOM下阶物料状态是否合法
     * (自制原材料也可能包含BOM)
     *
     * @param bomList
     * @return
     * @throws Exception
     */
    public static String checkTrialBom_areMaterialsValid(PromotionNotice promotion, List<WTPart> bomList) throws Exception {

        String errorMsg = "";
        //试产BOM流程半成品合法状态
        String trailBom_Part_Valid_States = CtBomConfig.getProperty("trailBom_Part_Valid_States");
        //试产BOM流程原材料合法状态
        String trailBom_Material_Valid_States = CtBomConfig.getProperty("trailBom_Material_Valid_States");

        List<String> materialPartTypeList = new ArrayList<>();
        materialPartTypeList.add("ct_fhsjRawMaterialElectronics");
        materialPartTypeList.add("ct_fhsjmarkAccessories");
        materialPartTypeList.add("ct_fhsjRawmaterialstructure");
        materialPartTypeList.add("ct_fhsjGuestFor");
        materialPartTypeList.add("ct_fhsjsoftware");
        materialPartTypeList.add("ct_fhsjSpecialMaterials");


        List<String> skipPartCheckList = new ArrayList<>(); //同阶发布BOM校验列表
        for (WTPart bom : bomList) {
            skipPartCheckList.add(bom.getNumber());
        }

        for (WTPart bom : bomList) {
            bom = (WTPart) CtVersionUtil.getLatest(bom.getMaster());//获取最新版本的物料
            List<WTPart> partsInBOM = CtBomUtil.getPartsInBOM(bom);//获取下阶bom清单

            for (WTPart tmpPart : partsInBOM) {
                String tmpState = CtWTObjectUtil.getStateDisplay(tmpPart, Locale.CHINA);//获取下阶bom清单的物料状态
                String partType = ClientTypedUtility.getExternalTypeIdentifier(tmpPart);//获取下阶bom清单的物料内部类名称
                partType = partType.substring(partType.lastIndexOf(".") + 1);//不加1会带上点导致匹配不上,获取最后的内部名称

                if (skipPartCheckList.contains(tmpPart.getNumber())) {
                    continue;//同升级对象可以避开状态校验
                }
                //试产BOM流程半成品校验逻辑
                if (partType.contains("ct_fhsjiallyPreparedProducts")){
                    if (!trailBom_Part_Valid_States.contains(tmpState)){
                        boolean flag = false;
                        QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                        while (queryResult.hasMoreElements()) {
                            WTPart per = (WTPart) queryResult.nextElement();
                            if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            continue;
                        }
                        //半成品校验,已生效
                        errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                    }
                }else {
                    if (materialPartTypeList.contains(partType)) {
                        if (!trailBom_Material_Valid_States.contains(tmpState)) {
                            boolean flag = false;
                            QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                            while (queryResult.hasMoreElements()) {
                                WTPart per = (WTPart) queryResult.nextElement();
                                if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                    flag = true;
                                    break;
                                }
                            }
                            if (flag) {
                                continue;
                            }

                            //原材料,已生效
                            errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                        }
                    }
                }
            }
        }

        if (CtFormatUtil.hasContent(errorMsg)) {
            errorMsg = "\r\nBOM检验失败，以下物料状态不符合要求: " + "\r\n" + errorMsg;
        }

        return errorMsg;
    }

    /**
     *检查样机BOM下阶物料状态是否合法
     * (自制原材料也可能包含BOM)
     * @param promotion
     * @return
     * @throws Exception
     */
    public static String checkPrototypeBom_areMaterialsValid(PromotionNotice promotion, List<WTPart> bomList) throws Exception {

        String errorMsg = "";
        //试产BOM流程半成品合法状态
        String prototypeBom_Part_Valid_States = CtBomConfig.getProperty("prototypeBom_Part_Valid_States");
        //试产BOM流程原材料合法状态
        String prototypeBom_Material_Valid_States = CtBomConfig.getProperty("prototypeBom_Material_Valid_States");

        List<String> materialPartTypeList = new ArrayList<>();
        materialPartTypeList.add("ct_fhsjRawMaterialElectronics");
        materialPartTypeList.add("ct_fhsjmarkAccessories");
        materialPartTypeList.add("ct_fhsjRawmaterialstructure");
        materialPartTypeList.add("ct_fhsjGuestFor");
        materialPartTypeList.add("ct_fhsjsoftware");
        materialPartTypeList.add("ct_fhsjSpecialMaterials");

        List<String> skipPartCheckList = new ArrayList<>(); //同阶发布BOM校验列表
        for (WTPart bom : bomList) {
            skipPartCheckList.add(bom.getNumber());
        }

        for (WTPart bom : bomList) {
            bom = (WTPart) CtVersionUtil.getLatest(bom.getMaster());//获取最新版本的物料
            List<WTPart> partsInBOM = CtBomUtil.getPartsInBOM(bom);//获取下阶bom清单

            for (WTPart tmpPart : partsInBOM) {
                String tmpState = CtWTObjectUtil.getStateDisplay(tmpPart, Locale.CHINA);//获取下阶bom清单的物料状态
                String partType = ClientTypedUtility.getExternalTypeIdentifier(tmpPart);//获取下阶bom清单的物料内部类名称
                partType = partType.substring(partType.lastIndexOf(".") + 1);//不加1会带上点导致匹配不上,获取最后的内部名称

                if (skipPartCheckList.contains(tmpPart.getNumber())) {
                    continue;//同升级对象可以避开状态校验
                }
                //样机BOM流程半成品校验逻辑
                if (partType.contains("ct_fhsjiallyPreparedProducts")){
                    if (!prototypeBom_Part_Valid_States.contains(tmpState)){
                        boolean flag = false;
                        QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                        while (queryResult.hasMoreElements()) {
                            WTPart per = (WTPart) queryResult.nextElement();
                            if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            continue;
                        }
                        //半成品校验,已生效
                        errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                    }
                }else {
                    if (materialPartTypeList.contains(partType)) {
                        if (!prototypeBom_Material_Valid_States.contains(tmpState)) {
                            boolean flag = false;
                            QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                            while (queryResult.hasMoreElements()) {
                                WTPart per = (WTPart) queryResult.nextElement();
                                if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                    flag = true;
                                    break;
                                }
                            }
                            if (flag) {
                                continue;
                            }

                            //原材料,已生效
                            errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                        }
                    }
                }
            }
        }

        if (CtFormatUtil.hasContent(errorMsg)) {
            errorMsg = "\r\nBOM检验失败，以下物料状态不符合要求: " + "\r\n" + errorMsg;
        }

        return errorMsg;
    }

    /**
     *检查EBOM下阶物料状态是否合法
     * (自制原材料也可能包含BOM)
     * @param promotion
     * @return
     * @throws Exception
     */
    public static String checkEBom_areMaterialsValid(PromotionNotice promotion, List<WTPart> bomList) throws Exception {

        String errorMsg = "";
        //EBOM流程半成品合法状态
        String EBom_Part_Valid_States = CtBomConfig.getProperty("EBom_Part_Valid_States");
        //EBOM流程原材料合法状态
        String EBom_Material_Valid_States = CtBomConfig.getProperty("EBom_Material_Valid_States");
        String[] bomsplit = EBom_Part_Valid_States.split(",");
        String[] split = EBom_Material_Valid_States.split(",");
        List<String> bomlist = Arrays.asList(bomsplit);
        List<String> list = Arrays.asList(split);
        List<String> materialPartTypeList = new ArrayList<>();
        materialPartTypeList.add("ct_fhsjRawMaterialElectronics");
        materialPartTypeList.add("ct_fhsjmarkAccessories");
        materialPartTypeList.add("ct_fhsjRawmaterialstructure");
        materialPartTypeList.add("ct_fhsjGuestFor");
        materialPartTypeList.add("ct_fhsjsoftware");
        materialPartTypeList.add("ct_fhsjSpecialMaterials");

        List<String> skipPartCheckList = new ArrayList<>(); //同阶发布BOM校验列表
        for (WTPart bom : bomList) {
            skipPartCheckList.add(bom.getNumber());
        }

        for (WTPart bom : bomList) {
            bom = (WTPart) CtVersionUtil.getLatest(bom.getMaster(),CtConstant.VIEW_DESIGN);//获取最新版本的物料
            List<WTPart> partsInBOM = CtBomUtil.getPartsInBOM(bom,CtConstant.VIEW_DESIGN);//获取下阶bom清单

            for (WTPart tmpPart : partsInBOM) {
                String tmpState = CtWTObjectUtil.getStateDisplay(tmpPart, Locale.CHINA);//获取下阶bom清单的物料状态
                String partType = ClientTypedUtility.getExternalTypeIdentifier(tmpPart);
                partType = partType.substring(partType.lastIndexOf(".") + 1);//不加1会带上点导致匹配不上,获取最后的内部名称

                if (skipPartCheckList.contains(tmpPart.getNumber())) {
                    continue;//同升级对象可以避开状态校验
                }
                //EBOM流程半成品校验逻辑
                if (partType.contains("ct_fhsjiallyPreparedProducts")){
                    if (!bomlist.contains(tmpState)){
                        boolean flag = false;
                        QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                        while (queryResult.hasMoreElements()) {
                            WTPart per = (WTPart) queryResult.nextElement();
                            if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            continue;
                        }
                        //半成品校验,已生效
                        errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                    }
                }else {
                    if (materialPartTypeList.contains(partType)) {
                        if (!list.contains(tmpState)) {
                            boolean flag = false;
                            QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                            while (queryResult.hasMoreElements()) {
                                WTPart per = (WTPart) queryResult.nextElement();
                                if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                    flag = true;
                                    break;
                                }
                            }
                            if (flag) {
                                continue;
                            }

                            //原材料,已生效
                            errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                        }
                    }
                }
            }
        }

        if (CtFormatUtil.hasContent(errorMsg)) {
            errorMsg = "\r\nBOM检验失败，以下物料状态不符合要求: " + "\r\n" + errorMsg;
        }

        return errorMsg;
    }


    /**
     *检查MBOM下阶物料状态是否合法
     * (自制原材料也可能包含BOM)
     * @param promotion
     * @return
     * @throws Exception
     */
    @Deprecated
    public static String checkMBom_areMaterialsValid(PromotionNotice promotion, List<WTPart> bomList) throws Exception {

        String errorMsg = "";
        //MBOM流程半成品合法状态
        String MBom_Part_Valid_States = CtBomConfig.getProperty("MBom_Part_Valid_States");
        //MBOM流程原材料合法状态
        String MBom_Material_Valid_States = CtBomConfig.getProperty("MBom_Material_Valid_States");

        List<String> materialPartTypeList = new ArrayList<>();
        materialPartTypeList.add("ct_fhsjRawMaterialElectronics"); //原材料（电子）
        materialPartTypeList.add("ct_fhsjmarkAccessories");//原材料（辅料）
        materialPartTypeList.add("ct_fhsjRawmaterialstructure");//原材料（结构）
        materialPartTypeList.add("ct_fhsjGuestFor");//原材料（客供物料）
        materialPartTypeList.add("ct_fhsjsoftware");//原材料（虚拟）
        materialPartTypeList.add("ct_fhsjSpecialMaterials");//原材料（专用物料）

        List<String> skipPartCheckList = new ArrayList<>(); //同阶发布BOM校验列表
        for (WTPart bom : bomList) {
            skipPartCheckList.add(bom.getNumber());
        }

        for (WTPart bom : bomList) {
            bom = (WTPart) CtVersionUtil.getLatest(bom.getMaster());//获取最新版本的物料
            List<WTPart> partsInBOM = CtBomUtil.getPartsInBOM(bom);//获取下阶bom清单

            for (WTPart tmpPart : partsInBOM) {
                String tmpState = CtWTObjectUtil.getStateDisplay(tmpPart, Locale.CHINA);//获取下阶bom清单的物料状态
                String partType = ClientTypedUtility.getExternalTypeIdentifier(tmpPart);//获取下阶bom清单的物料内部类名称
                partType = partType.substring(partType.lastIndexOf(".") + 1);//不加1会带上点导致匹配不上,获取最后的内部名称

                if (skipPartCheckList.contains(tmpPart.getNumber())) {
                    continue;//同升级对象可以避开状态校验
                }
                //MBOM流程半成品校验逻辑
                if (partType.contains("ct_fhsjiallyPreparedProducts")){
                    if (!MBom_Part_Valid_States.contains(tmpState)){
                        boolean flag = false;
                        QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                        while (queryResult.hasMoreElements()) {
                            WTPart per = (WTPart) queryResult.nextElement();
                            if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            continue;
                        }
                        //半成品校验,已生效
                        errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                    }
                }else {
                    if (materialPartTypeList.contains(partType)) {
                        if (!MBom_Material_Valid_States.contains(tmpState)) {
                            boolean flag = false;
                            QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                            while (queryResult.hasMoreElements()) {
                                WTPart per = (WTPart) queryResult.nextElement();
                                if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                    flag = true;
                                    break;
                                }
                            }
                            if (flag) {
                                continue;
                            }

                            //原材料,已生效
                            errorMsg += bom.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n";
                        }
                    }
                }
            }
        }

        if (CtFormatUtil.hasContent(errorMsg)) {
            errorMsg = "\r\nBOM检验失败，以下物料状态不符合要求: " + "\r\n" + errorMsg;
        }

        return errorMsg;
    }



    /**
     *校验是否关联物料承认书
     * @param promotion
     * @return
     * @throws Exception
     */
    public static String isLinkedMaterialAdmission(PromotionNotice promotion, List<WTPart> bomList) throws Exception {

        String errorMsg = "";
        String docType = "";
        String docTypeLastName = "";
        IBAUtil ibaUtil = new IBAUtil(promotion);
        List<String> docList = new ArrayList();
        //获得下阶原材料部件，一个原材料可包含多个相关文档对象
        for (WTPart part : bomList){
            List<WTDocument> documents = CtPartUtil.getDescribeDocs(part);//获得相关对象
            if (documents == null){
                errorMsg += part.getNumber() + "-->"  + "   " + "未关联任何文档对象！" + "\r\n";
                continue;
            }
            for (WTDocument doc : documents){
                docType = ClientTypedUtility.getExternalTypeIdentifier(doc);//获取bom清单的物料内部类名称
                docTypeLastName = docType.substring(docType.lastIndexOf(".") + 1);//不加1会带上点导致匹配不上,获取最后的内部名称
                docList.add(docTypeLastName);
            }

            if (!docList.contains("Doc_csbgg") || !docList.contains("Doc_wlgls") || !docList.contains("Doc_wltp")){
                errorMsg += part.getNumber() + "-->" +  "相关联文档对象不符合物料承认书认证条件" + "\r\n";
                docList.clear();
            }
        }


        if (CtFormatUtil.hasContent(errorMsg)) {
            errorMsg = "\r\nBOM检验失败，以下物料不符合要求: " + "\r\n" + errorMsg;
        }

        return errorMsg;
    }

    public static void checkEtoM_areMaterialsValid(WTPart wtPart,StringBuffer stringBuffer) throws Exception{
        //EtoM流程半成品合法状态
        String EtoM_Part_Valid_States = CtBomConfig.getProperty("EtoM_Part_Valid_States");
        String[] bomsplit = EtoM_Part_Valid_States.split(",");
        List<String> bomlist = Arrays.asList(bomsplit);
        //EtoM流程原材料合法状态
        String EtoM_Material_Valid_States = CtBomConfig.getProperty("EtoM_Material_Valid_States");
        String[] split = EtoM_Material_Valid_States.split(",");
        List<String> list = Arrays.asList(split);
        wtPart = (WTPart) CtVersionUtil.getLatest(wtPart.getMaster());//获取最新版本的物料
        List<WTPart> partsInBOM = CtBomUtil.getPartsInBOMByView(wtPart,null);//获取下阶bom清单
        for (WTPart tmpPart : partsInBOM) {
            String partNumber = tmpPart.getNumber();
            String tmpState = CtWTObjectUtil.getStateDisplay(tmpPart, Locale.CHINA);//获取下阶bom清单的物料状态
            String partType = ClientTypedUtility.getExternalTypeIdentifier(tmpPart);//获取下阶bom清单的物料内部类名称
            partType = partType.substring(partType.lastIndexOf(".") + 1);//不加1会带上点导致匹配不上,获取最后的内部名称

            WTPart manufacturing = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
            if(manufacturing!=null){//过滤已有制造视图
                continue;
            }
            //MBOM流程半成品校验逻辑
            if (partNumber.startsWith("2")){//半成品
                if (!bomlist.contains(tmpState)){
                    boolean flag = false;
                    QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                    while (queryResult.hasMoreElements()) {
                        WTPart per = (WTPart) queryResult.nextElement();
                        if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                            flag = true;
                            break;
                        }
                    }
                    if (flag) {
                        continue;
                    }
                    //半成品校验,已生效
                    stringBuffer.append(wtPart.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n");
                }
            }else {
                if (partNumber.startsWith("1")) {//原材料
                    if (!list.contains(tmpState)) {
                        boolean flag = false;
                        QueryResult queryResult = VersionControlHelper.service.allIterationsOf(tmpPart.getMaster());
                        while (queryResult.hasMoreElements()) {
                            WTPart per = (WTPart) queryResult.nextElement();
                            if ("EFFECTED".equalsIgnoreCase(per.getLifeCycleState().toString())) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            continue;
                        }
                        //原材料,已生效
                        stringBuffer.append(wtPart.getNumber() + "-->" + tmpPart.getNumber() + "   " + tmpState + "\r\n");
                    }
                }
            }
            checkEtoM_areMaterialsValid(tmpPart,stringBuffer);
        }
    }

    /**
     * @param wtPart
     * @return
     * @throws Exception
     */
    public static String checkEtoM_areMaterialsValid(WTPart wtPart) throws Exception {
        StringBuffer stringBuffer = new StringBuffer();
        String errorMsg = "";
        checkEtoM_areMaterialsValid(wtPart,stringBuffer);
        errorMsg = stringBuffer.toString();
        if (CtFormatUtil.hasContent(errorMsg)) {
            errorMsg = "\r\n以下物料状态不符合要求: " + "\r\n" + errorMsg;
        }

        return errorMsg;
    }

    /**
     * 检查部件是否绑定要求的文档
     *
     * @param partList
     * @return
     * @throws Exception
     */
    public static String checkPartAndDocsBind(List<WTPart> partList,String name) throws Exception {
        String errorMsg = "";

        String docType = "";
        String docTypeLastName = "";
        Map<String,WTDocument> docMap = new HashMap<>();
        List<String> docList = new ArrayList<String>();
        List<String> docTypeList = new ArrayList<String>();

        for (WTPart part : partList) {
            String partType = CtWTObjectUtil.getTypeIdentifier(part);
            System.out.println(">>>partType=" + partType);
            List<WTDocument> documents = CtPartUtil.getDescribeDocs(part);//获得相关对象

            if (documents != null) {

                for (WTDocument doc : documents) {
                    docType = ClientTypedUtility.getExternalTypeIdentifier(doc);//获取bom清单的物料内部类名称
                    docTypeLastName = docType.substring(docType.lastIndexOf(".") + 1);//不加1会带上点导致匹配不上,获取最后的内部名称
                    docList.add(docTypeLastName);
                    docMap.put(docTypeLastName,doc);//循环获得文档名

                }
                if (name.contains("试产")) {
                    if (!docList.contains("Doc_csbg") || !docList.contains("Doc_sczjhyjl")) {
                        errorMsg += part.getNumber() + "-->" + "缺少必须的关联文档,'测试报告 ,试产总结会议记录 '" + "\r\n";
                    } else {
                        docTypeList.add("Doc_csbg");
                        docTypeList.add("Doc_sczjhyjl");
                    }
                }else if (name.contains("量产")){
                    if (!docList.contains("Doc_TRpsbgmb") || !docList.contains("Doc_xplscqkb")|| !docList.contains("Doc_xplsczlzkb")
                            || !docList.contains("Doc_scwtdzj")|| !docList.contains("Doc_sczjhyjl")|| !docList.contains("xplscjszkb")) {
                        errorMsg += part.getNumber() + "-->" + "缺少必须的关联文档,'TR评审报告模板,小批量试产情况表,小批量试产质量状况表,试产问题点总结,试产总结会议记录,小批量试产技术状况表'" +"\r\n";
                    } else {
                        docTypeList.add("Doc_TRpsbgmb");
                        docTypeList.add("Doc_xplscqkb");
                        docTypeList.add("Doc_xplsczlzkb");
                        docTypeList.add("Doc_scwtdzj");
                        docTypeList.add("Doc_sczjhyjl");
                        docTypeList.add("xplscjszkb");

                    }
                }


                for (Map.Entry<String, WTDocument> entry : docMap.entrySet()) {
                    if (docTypeList.contains(entry.getKey())){
                        if (entry.getKey().contains("Doc_TRpsbgmb")){
                            IBAUtil ibaUtil = new IBAUtil(entry.getValue());
                            String ct_projectPhase = ibaUtil.getIBAValue("Ct_ProjectPhase");
                            if (!ct_projectPhase.equals("TR6")) {
                                errorMsg += entry.getValue().getName() + ":" + entry.getValue().getNumber() + "的项目阶段不是TR6" + "\r\n";
                            }
                        }else {
                            if (!(CtWTObjectUtil.getStateDisplay(entry.getValue(), Locale.CHINA).equals("已发布"))) {
                                errorMsg += entry.getValue().getName() + ":" + entry.getValue().getNumber() + " 没有发布" + "\r\n";
                            }
                        }
                    }
                }

                docList.clear();


            } else {
                errorMsg += part.getNumber() + "-->" + "   " + "未关联任何文档对象！" + "\r\n";
            }

            if (CtFormatUtil.hasContent(errorMsg) && CtFormatUtil.hasContent(errorMsg.trim())) {
                errorMsg = "\r\n物料生效校验失败，以下物料不符合要求: " + "\r\n" + errorMsg;

            }
        }
        return errorMsg;
    }

    /**
     * EBOM中的物料必须在MBOM中  物料检入时校验
     *
     */
    public static void checkEBOMInMBOM(WTPart part) throws Exception{
        String viewName = part.getViewName();
        Set<String> notInMbom = new HashSet<>();
        List<WTPart> ebom = null;
        List<WTPart> mbom = null;
        if(CtConstant.VIEW_DESIGN.equals(viewName)){//如果当前是E视图物料
            String partNumber = part.getNumber();
            WTPart mPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
            if(mPart!=null){
                ebom = CtBomUtil.getPartsInBOM(part);
                mbom = CtBomUtil.getPartsInBOM(mPart);
            }
        }else if(CtConstant.VIEW_MANUFACTURING.equals(viewName)){//当前为M视图物料
            String partNumber = part.getNumber();
            WTPart ePart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);
            if(ePart!=null){
                 ebom = CtBomUtil.getPartsInBOM(ePart);
                 mbom = CtBomUtil.getPartsInBOM(part);
            }
        }
        List<String> ebomNumbers = ebom.stream().map(wtPart -> wtPart.getNumber()).collect(Collectors.toList());
        List<String> mbomNumbers = mbom.stream().map(wtPart -> wtPart.getNumber()).collect(Collectors.toList());
        for (String ebomNumber : ebomNumbers) {
            if(!mbomNumbers.contains(ebomNumber)){
                notInMbom.add(ebomNumber);
            }
        }
        if(notInMbom!=null&&notInMbom.size()>0){
            throw new Exception("以下子项在EBOM中存在,MBOM中不存在:"+notInMbom);
        }
    }

    /**
     * 以excel格式导出BOM
     *
     * @param os
     * @param part
     * @throws Exception,WTException
     */
    public void exportBom(OutputStream os, WTPart part, String fileName) throws Exception {
        try {
            List<Map> data = getData(part);
            CtExportExcelTool ctExportExcelTool = new CtExportExcelTool(fileName, "BOM_ExportTempate.xlsx");
            ctExportExcelTool.expExcel(data, os, null);
            //流在jsp中执行关闭
//			workBook.write(os);

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("BOM导出失败，请联系管理员！");
        }
    }

    /**
     * 以excel格式导出BOM
     * @param part
     * @param map
     * @throws Exception
     */
    public List<CtExportBomBo> exportBom2(WTPart part, Map<String, List<Map<String, String>>> map) throws Exception {
        try {
            return getData2(part, map);
        } catch (Exception e) {
            logger.error("导出更改后BOM异常：", e);
            throw new WTException("BOM导出失败，请联系管理员！");
        }
    }

    /**
     * 记录BOM信息
     *
     * @param part
     * @throws Exception
     */
    private List<Map> getData(WTPart part) throws Exception {
        List<Map> data = new ArrayList<Map>();
        List<WTPart> bomList = new ArrayList<WTPart>();
        List<String> bomNumberList = new ArrayList();
        CtBomUtil.collectSubBOMs(part, bomList);
        //第一遍循环收集所有带有子项的部件编号
        for (WTPart bom : bomList) {
            String number = bom.getNumber();
            bomNumberList.add(number);
        }
        int i = 1;
        //第二遍循环如果子项的编号 是有子项的就遍历该子项
//        for(WTPart bom:bomList) {
        WTPart bom = bomList.get(0);
        QueryResult newQR = WTPartHelper.service.getUsesWTPartMasters(bomList.get(0));
        //第一层父阶数据
        CtExportBomBo bo = new CtExportBomBo();
        bo.setSeq("1");
        bo.setFatherPartNum(bom.getNumber());
        Map map = (Map) JSON.parse(JSON.toJSON(bo).toString());
        data.add(map);
        while (newQR.hasMoreElements()) {
//                WTPartUsageLink link = (WTPartUsageLink) newQR.nextElement();
//                WTPartMaster master = link.getUses();
//                String childPartNum = master.getNumber();//下阶料号

            reBack(newQR, data, bom, bomNumberList, "1．" + i + "");
            i++;

        }
//        }
        return data;
    }

    /**
     * 记录BOM信息
     * @param part
     * @throws Exception
     */
    private List<CtExportBomBo> getData2(WTPart part, Map<String, List<Map<String, String>>> ecMap) throws Exception {
        List<CtExportBomBo> data = new ArrayList<>();
        String partNumber = part.getNumber();
        int i = 1;
        //第一层父阶数据
        CtExportBomBo bo = new CtExportBomBo();
        bo.setSeq("1");
        bo.setFatherPartNum(partNumber);
        data.add(bo);

        //获取所有子项
        List<WTPart> childPartList = getChildList(part);
        List<Map<String, String>> infoList = ecMap.get(partNumber);
        //增加的子项
        if(null != infoList) {
            for(Map<String, String> infoMap : infoList){
                String changeType = infoMap.get("changeType");
                if ("增加".equals(changeType)) {
                    String childPartAfterNumber = infoMap.get("childPartAfter");
                    WTPart childPart = CtPartUtil.getPartByNumber(childPartAfterNumber, CtConstant.VIEW_MANUFACTURING);
                    if(null == childPart){
                        childPart = CtPartUtil.getPartByNumber(childPartAfterNumber, CtConstant.VIEW_DESIGN);
                    }
                    if(null != childPart){
                        childPartList.add(childPart);
                    }
                }
            }
        }
        for (WTPart childPart : childPartList) {
            reBack2(childPart, data, part, "1．" + i + "", ecMap);
            i++;
        }
        return data;
    }

    /**
     * 获取所有子项
     * @param part
     * @return
     * @throws Exception
     */
    public List<WTPart> getChildList(WTPart part) throws Exception {
        List<WTPart> partList = new ArrayList<>();
        QueryResult newQR = WTPartHelper.service.getUsesWTPartMasters(part);
        while (newQR.hasMoreElements()) {
            WTPartUsageLink partUsageLink = (WTPartUsageLink) newQR.nextElement();
            WTPartMaster childPartMaster = partUsageLink.getUses();
            WTPart childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster);
            partList.add(childPart);
        }
        return partList;
    }

    /**
     * 回溯算法
     * @param newQR bom关联关系
     * @param data 导出到excel的数据
     * @param bom
     * @param bomNumberList
     * @param seq 层级
     * @throws Exception
     * @author lcd
     */
    public  void reBack(QueryResult newQR, List<Map> data,WTPart bom, List<String> bomNumberList,String seq ) throws Exception {
//        while (newQR.hasMoreElements()) {

        CtExportBomBo bo = new CtExportBomBo();
        WTPartUsageLink partUsageLink = (WTPartUsageLink) newQR.nextElement();
        WTPartMaster childPartMaster = partUsageLink.getUses();
        String childPartNum = childPartMaster.getNumber();
        WTPart childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster);
        IBAUtil childPartIbaUtil = new IBAUtil(childPart);
        IBAUtility linkIBAUtility = new IBAUtility(partUsageLink);
        // 层级
        bo.setSeq(seq);
        // 父阶料编码
        bo.setFatherPartNum(bom.getNumber());
        // 父阶料名称
        bo.setFatherPartName(bom.getName());
        // 子阶料编码
        bo.setChildPartNum(childPart.getNumber());
        // 子阶料名称
        bo.setChildPartName(childPart.getName());
        // 版本
        bo.setVersion(CtVersionUtil.getVersionInfo(childPart));
        // 内部版本
        bo.setInnerVersion(childPartIbaUtil.getIBAValue("ct_banci"));
        // 状态
        State childPartStatus = childPart.getLifeCycleState();
        if (childPartStatus != null) {
            bo.setStatus(childPartStatus.getDisplay(Locale.CHINA));
        }
        // 数量
        Quantity quantity = partUsageLink.getQuantity();
        if (quantity != null) {
            //数量,excel会自动处理科学计数法问题
            NumberFormat numberFormat = NumberFormat.getInstance();
            //设置保留多少位小数
            numberFormat.setMaximumFractionDigits(4);
            // 取消科学计数法
            numberFormat.setGroupingUsed(false);
            double amount = quantity.getAmount();
            bo.setAmount(numberFormat.format(quantity.getAmount()));
        }
        // 位号
        bo.setFitPlace(getUsesOccurrences(partUsageLink, 2));
        // BOM备注
        bo.setBomRemark(linkIBAUtility.getIBAValue("ct_BOMNotes"));
        // 是否RoHS
        bo.setIsRohs(childPartIbaUtil.getIBAValue("ct_isRohs"));
        // 替代组编号
        bo.setReplaceGroupNum(linkIBAUtility.getIBAValue("ct_substituteGroupNumber"));
        // 替代组优先级
        bo.setReplaceGroupPriority(linkIBAUtility.getIBAValue("ct_Alternategrouppriority"));
        // 源
        Source source = childPart.getSource();
        if (source != null) {
            bo.setSource(source.getDisplay(Locale.CHINA));
        }
        // 默认单位
        QuantityUnit defaultUnit = childPart.getDefaultUnit();
        if (defaultUnit != null) {
            bo.setDefaultUnit(defaultUnit.getDisplay(Locale.CHINA));
        }
        Map map = (Map) JSON.parse(JSON.toJSON(bo).toString());
        data.add(map);
        if (bomNumberList.contains(childPartNum)) {
            WTPart bom2 = CtPartUtil.getPartByNumber(childPartNum);
            QueryResult qr = WTPartHelper.service.getUsesWTPartMasters(bom2);
            int i = 1;
            while (qr.hasMoreElements()) {
                reBack(qr, data, bom2, bomNumberList, seq + "．" + i + "");
                i++;
            }
        }
//    }
    }

    /**
     * 递归查子项
     * @param childPart
     * @param data
     * @param bom
     * @param seq
     * @param ecMap
     * @throws Exception
     */
    public void reBack2(WTPart childPart, List<CtExportBomBo> data, WTPart bom, String seq, Map<String, List<Map<String, String>>> ecMap) throws Exception {
        if(null == childPart){
            return;
        }
        String childPartNum = "";
        WTPartUsageLink partUsageLink = null;
        if(null != childPart){
            childPartNum = childPart.getNumber();
            partUsageLink = CtBomUtil.getUsageLink(bom, childPart);
        }
        CtExportBomBo bo = new CtExportBomBo();
        List<Map<String, String>> infoList = ecMap.get(bom.getNumber());
        if(null != infoList){
            for(Map<String, String> infoMap : infoList){
                String changeType = infoMap.get("changeType");
                if("删除".equals(changeType)){
                    if(childPartNum.equals(infoMap.get("childPartBefore"))){
                        return;
                    }
                }else{
                    if(childPartNum.equals(infoMap.get("childPartBefore"))){
                        bo.setAmount(infoMap.get("amount"));
                        bo.setBomRemark(infoMap.get("bomRemark"));
                        bo.setInnerVersion(infoMap.get("innerVersion"));
                        bo.setFitPlace(infoMap.get("fitPlace"));
                        break;
                    }
                    if(childPartNum.equals(infoMap.get("childPartAfter"))){
                        bo.setAmount(infoMap.get("amount"));
                        bo.setBomRemark(infoMap.get("bomRemark"));
                        bo.setInnerVersion(infoMap.get("innerVersion"));
                        bo.setFitPlace(infoMap.get("fitPlace"));
                        break;
                    }
                }
            }
        }
        //添加数据
        setBoAttrbute(childPart, partUsageLink, data, seq, bo, bom);

        WTPart bom2 = CtPartUtil.getPartByNumber(childPartNum);
        int i = 1;
        //获取所有子项
        List<WTPart> childPartList = getChildList(bom2);
        List<Map<String, String>> childInfoList = ecMap.get(childPartNum);
        //增加的子项
        if(null != childInfoList) {
            for(Map<String, String> infoMap : childInfoList){
                String changeType = infoMap.get("changeType");
                if ("增加".equals(changeType)) {
                    String childPartAfterNumber = infoMap.get("childPartAfter");
                    WTPart tempPart = CtPartUtil.getPartByNumber(childPartAfterNumber, CtConstant.VIEW_MANUFACTURING);
                    if(null == tempPart){
                        tempPart = CtPartUtil.getPartByNumber(childPartAfterNumber, CtConstant.VIEW_DESIGN);
                    }
                    if(null != tempPart){
                        childPartList.add(tempPart);
                    }
                }
            }
        }
        for (WTPart tempPart : childPartList) {
            reBack2(tempPart, data, bom2, seq + "．" + i + "", ecMap);
            i++;
        }
    }

    /**
     * 设置属性
     * @param childPart
     * @param partUsageLink
     * @param data
     * @param seq
     * @param bo
     * @param bom
     * @throws Exception
     */
    public void setBoAttrbute(WTPart childPart, WTPartUsageLink partUsageLink, List<CtExportBomBo> data, String seq, CtExportBomBo bo, WTPart bom) throws Exception {
        IBAUtil childPartIbaUtil = new IBAUtil(childPart);
        IBAUtility linkIBAUtility = null;
        if(null != partUsageLink){
            linkIBAUtility = new IBAUtility(partUsageLink);
        }
        // 层级
        bo.setSeq(seq);
        // 父阶料编码
        bo.setFatherPartNum(bom.getNumber());
        // 父阶料名称
        bo.setFatherPartName(bom.getName());
        // 子阶料编码
        bo.setChildPartNum(childPart.getNumber());
        // 子阶料名称
        bo.setChildPartName(childPart.getName());
        // 版本
        bo.setVersion(CtVersionUtil.getVersionInfo(childPart));
        // 内部版本
        if(!CtFormatUtil.hasContent(bo.getInnerVersion())){
            bo.setInnerVersion(childPartIbaUtil.getIBAValue("ct_banci"));
        }
        // 状态
        State childPartStatus = childPart.getLifeCycleState();
        if (childPartStatus != null) {
            bo.setStatus(childPartStatus.getDisplay(Locale.CHINA));
        }
        if(null != partUsageLink){
            // 数量
            if(!CtFormatUtil.hasContent(bo.getAmount())){
                Quantity quantity = partUsageLink.getQuantity();
                if (quantity != null) {
                    //数量,excel会自动处理科学计数法问题
                    NumberFormat numberFormat = NumberFormat.getInstance();
                    //设置保留多少位小数
                    numberFormat.setMaximumFractionDigits(4);
                    // 取消科学计数法
                    numberFormat.setGroupingUsed(false);
                    double amount = quantity.getAmount();
                    bo.setAmount(numberFormat.format(quantity.getAmount()));
                }
            }
            // 位号
            if(!CtFormatUtil.hasContent(bo.getFitPlace())){
                bo.setFitPlace(getUsesOccurrences(partUsageLink, 2));
            }
            // BOM备注
            if(!CtFormatUtil.hasContent(bo.getBomRemark())){
                bo.setBomRemark(linkIBAUtility.getIBAValue("ct_BOMNotes"));
            }
            // 是否RoHS
            bo.setIsRohs(childPartIbaUtil.getIBAValue("ct_isRohs"));
            // 替代组编号
            bo.setReplaceGroupNum(linkIBAUtility.getIBAValue("ct_substituteGroupNumber"));
            // 替代组优先级
            bo.setReplaceGroupPriority(linkIBAUtility.getIBAValue("ct_Alternategrouppriority"));
        }
        // 源
        Source source = childPart.getSource();
        if (source != null) {
            bo.setSource(source.getDisplay(Locale.CHINA));
        }
        // 默认单位
        QuantityUnit defaultUnit = childPart.getDefaultUnit();
        if (defaultUnit != null) {
            bo.setDefaultUnit(defaultUnit.getDisplay(Locale.CHINA));
        }
        data.add(bo);
    }

    /**
     * 获取工位
     * @param usageLink
     * @param flag 1：页面上位号的合并值，2：展开值，3：排序，按从小到大排序，优先按字母排序，默认1效果
     * @return
     * @throws Exception
     */
    public String getUsesOccurrences(WTPartUsageLink usageLink, int flag) throws Exception {
        // 位号
        String positionNo = "";
        QueryResult usesOccurrencesQS = OccurrenceHelper.service.getUsesOccurrences(usageLink);
        if (usesOccurrencesQS != null && usesOccurrencesQS.size() > 0) {
            List<String> values = new ArrayList<>(usesOccurrencesQS.size());
            while (usesOccurrencesQS.hasMoreElements()) {
                PartUsesOccurrence usesOccurrence = (PartUsesOccurrence) usesOccurrencesQS.nextElement();
                String name = usesOccurrence.getName();
                if (StringUtils.isNotEmpty(name)) {
                    values.add(name);
                }
            }
            if (flag == 3) {
                Collections.sort(values, fitPlaceComparator);
                positionNo = StringUtils.join(values, ",");
            } else if (flag == 2){
                ReferenceDesignatorSetDelegateFactory rdsFactory = new ReferenceDesignatorSetDelegateFactory();
                ReferenceDesignatorSet rds = rdsFactory.get(values);
                positionNo = StringUtils.join(rds.getExpandedReferenceDesignators(), rds.getSequenceDelimiter());
            } else {
                ReferenceDesignatorSetDelegateFactory rdsFactory = new ReferenceDesignatorSetDelegateFactory();
                ReferenceDesignatorSet rds = rdsFactory.get(values);
                positionNo = rds.getConsolidatedReferenceDesignators();
            }
        }
        return positionNo;
    }

    /**
     * MBOM添加子件校验:1.禁止加入E视图的半成品或E视图的成品
     *                 2.禁止加入CBB物料
     * @param fatherPart
     * @throws Exception
     */
    public static void checkMbomSonPart(WTPart fatherPart)throws Exception{
        String viewName = fatherPart.getViewName();
        if(!CtConstant.VIEW_MANUFACTURING.equals(viewName))return;
        String errorMsg = "";
        List<WTPart> partsInBOMByView = CtBomUtil.getPartsInBOMByView(fatherPart, null);
        for (WTPart sonPart : partsInBOMByView) {
            String partType = CtWTObjectUtil.getTypeIdentifier(sonPart);
            partType = partType.substring(partType.lastIndexOf(".")+1);
            if("ct_CBB".equals(partType)){
                errorMsg+=sonPart.getIdentity()+"\r\n";
            }else if("ct_fhsjiallyPreparedProducts".equals(partType)||"ct_fhsjfinishedproduct".equals(partType)||sonPart.isEndItem()){
                if(sonPart.getViewName().equals(CtConstant.VIEW_DESIGN)){
                    errorMsg+=sonPart.getIdentity()+"\r\n";
                }
            }
        }
        if(CtFormatUtil.hasContent(errorMsg)){
            throw new Exception("MBOM不允许添加CBB物料或E视图的成品/半成品\r\n父件:"+fatherPart.getIdentity()+"以下子件不符合要求:\r\n"+errorMsg);
        }
    }

    /**
     * 移除MBOM中的CBB物料
     * @throws Exception
     */
    public static void removeCBBInMbom(WTPart fatherPart)throws Exception{
        if(fatherPart.getViewName().equals(CtConstant.VIEW_DESIGN))return;
        List<WTPart> partsInBOMByView = CtBomUtil.getPartsInBOMByView(fatherPart, null);
        for (WTPart sonPart : partsInBOMByView) {
            String sonType = CtWTObjectUtil.getTypeIdentifier(sonPart);
            if(sonType.contains("ct_CBB")){
                CtBomUtil.deleteUsageLink(fatherPart, sonPart);
            }
        }
    }

    public static void checkFraction(WTPart fatherPart) throws Exception{
        List<WTPart> allParts = new ArrayList<>();
        CtBomUtil.getAllLeafPartsInBOM(fatherPart, allParts);
        for(WTPart part : allParts){

        }
        IBAUtil ibaUtil = new IBAUtil(fatherPart);
        String fraction = ibaUtil.getIBAValue(CtBomConstant.IBA_FRACTION);
        if(!CtCommonUtil.isFraction(fraction)){

        }
    }

    /**
     * 检入时处理分数相关逻辑
     * @param parentPart
     * @param errorMsg
     * @throws Exception
     */
    public static void dealFraction(WTPart parentPart, Map<String, String> errorMsg) throws Exception {
        boolean var2 = false;
        try{
            var2 = SessionServerHelper.manager.setAccessEnforced(false);
            QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(parentPart);
            while (linkQr.hasMoreElements()) {
                WTPartUsageLink qrLink = (WTPartUsageLink) linkQr.nextElement();
                WTPartMaster childPartMaster = (WTPartMaster) qrLink.getUses();
                WTPart childPart = (WTPart)CtVersionUtil.getLatest(childPartMaster);
                if(null == childPart){
                    continue;
                }
                String childPartNum = childPart.getNumber();

                IBAUtil ibaUtil = new IBAUtil(qrLink);
                String fraction = ibaUtil.getIBAValue(CtBomConstant.IBA_FRACTION);
                if(CtFormatUtil.hasContent(fraction)){
                    //分数转成小数
                    double dosage = CtFormatUtil.formatFraction(fraction);
                    //目前的数量
                    Quantity quantity = qrLink.getQuantity();
                    if(null != quantity){
                        if(dosage != quantity.getAmount()){
                            errorMsg.put(childPartNum, childPartNum + " 分数" + fraction + ",转换数量应为：" + dosage + "\r\n");
                        }
                    }
                }
                dealFraction(childPart, errorMsg);
            }
        }finally {
            SessionServerHelper.manager.setAccessEnforced(var2);
        }

    }

    /**
     * 初始化表格数据
     * @param pn
     * @throws Exception
     */
    public static void saveConvertBomBo(PromotionNotice pn) throws Exception {
        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
        String userName = user.getName();
        QueryResult qr = MaturityHelper.service.getPromotionTargets(pn);
        Long pnId = pn.getPersistInfo().getObjectIdentifier().getId();
        //读取需要过滤的分类配置
        List<String> clfList = CtConvertBomFilterConfig.getConvertBomFilterConfig();
        Set<String> numberSet = new HashSet<>();//用于去重
        while (qr.hasMoreElements()) {
            Object o = qr.nextElement();
            if (o instanceof WTPart) {
                WTPart part = (WTPart) o;
                //初始化转MBOM表格的数据
                if(!numberSet.contains(part.getNumber())){
                    saveConvertBomBo(pnId, part, clfList, userName, true, null);
                    numberSet.add(part.getNumber());
                }

                //升级对象的BOM
                List<WTPart> childPartList = new ArrayList<>();
                CtBomUtil.getAllPartsInBOM(part, childPartList);
                for(WTPart childPart : childPartList){
                    if(!numberSet.contains(childPart.getNumber())){
                        saveConvertBomBo(pnId, childPart, clfList, userName, false, null);
                        numberSet.add(childPart.getNumber());
                    }
                }
            }
        }
    }

    /**
     * 初始化表格数据(物料详情页面)
     * @param part
     * @throws Exception
     */
    public static List<CtConvertBomBo> saveConvertBomBoPartPage(WTPart part) throws Exception {
        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
        String userName = user.getName();
        List<CtConvertBomBo> result = new ArrayList<>();
        //读取需要过滤的分类配置
        List<String> clfList = CtConvertBomFilterConfig.getConvertBomFilterConfig();

        Set<String> numberSet = new HashSet<>();//用于去重
        Long masterId = part.getMaster().getPersistInfo().getObjectIdentifier().getId();
        //初始化转MBOM表格的数据
        CtConvertBomBo bo = saveConvertBomBo(null, part, clfList, userName, true, masterId);
        if(null != bo){
            result.add(bo);
        }
        numberSet.add(part.getNumber());

        //升级对象的BOM
        List<WTPart> childPartList = new ArrayList<>();
        CtBomUtil.getAllPartsInBOM(part, childPartList);
        for(WTPart childPart : childPartList){
            if(!numberSet.contains(childPart.getNumber())){
                bo = saveConvertBomBo(null, childPart, clfList, userName, false, masterId);
                if(null != bo){
                    result.add(bo);
                }
                numberSet.add(childPart.getNumber());
            }
        }
        return result;
    }

    /**
     * 初始化转MBOM表格数据
     * @param pnId 流程id
     * @param part
     * @param clfList
     * @param userName
     * @param masterId
     * @param isUpgradeObject 升级对象
     * @throws Exception
     */
    public static CtConvertBomBo saveConvertBomBo(Long pnId, WTPart part, List<String> clfList, String userName, boolean isUpgradeObject, Long masterId) throws Exception {
        String typeName = CtWTObjectUtil.getTypeViewName(part);
        String partNumber = part.getNumber();
        logger.debug("saveConvertBomBo typeName>>>>>" + typeName);
        //过滤CBB物料
        if(typeName.contains("CBB")){
            return null;
        }
        //过滤配置的物料
        String clf = CtPartClfUtil.getClfAttValue(part);
        logger.debug("saveConvertBomBo clf>>>>>" + clf);
        if(clfList.contains(clf)){
            return null;
        }
        //过滤叶子节点
        QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(part);
        if(linkQr.size() == 0) {
            return null;
        }

        CtConvertBomBo bo = new CtConvertBomBo();
        bo.setId(IdUtil.simpleUUID());
        bo.setPnId(pnId);
        bo.setMasterId(masterId);
        bo.setPartType(typeName);
        bo.setPartNumber(partNumber);
        IBAUtil ibaUtil = new IBAUtil(part);
        //研发描述
        String rdDescription = ibaUtil.getIBAValue(CtProjectBudgetConstant.Ct_IBA_PartDesc);
        if (CtFormatUtil.hasContent(rdDescription)) {
            bo.setDevelopDesc(rdDescription);
        }
        //是否已转M视图
        WTPart mPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
        if(null == mPart){
            bo.setConvertMView("否");
        }else{
            bo.setConvertMView("是");
        }
        //M视图物料编码
        List<String> mPartNumbers = new ArrayList<>();
        if(null != mPart){
            mPartNumbers.add(mPart.getNumber() + "(" + mPart.getLifeCycleState().getDisplay(Locale.CHINA) +")");
        }
        CtViewLinkMapper ctViewLinkMapper = CtBeanFactory.newCtBeanFactory().getBean(CtViewLinkMapper.class);
        List<CtViewLinkBo> ctViewLinkBos = ctViewLinkMapper.queryViewLinkByRoleB(part.getMaster().getPersistInfo().getObjectIdentifier().getId());
        for(CtViewLinkBo ctViewLinkBo : ctViewLinkBos){
            WTPart aPart = CtPartUtil.getPartByMasterId(ctViewLinkBo.getRoleA());
            logger.debug("saveConvertBomBo aPart>>>>>" + aPart);
            if(null == aPart){
                continue;
            }
            WTPart lastAPart = CtPartUtil.getPartByNumber(aPart.getNumber(), CtConstant.VIEW_MANUFACTURING);
            logger.debug("saveConvertBomBo lastAPart>>>>>" + lastAPart);
            if(null == lastAPart){
                continue;
            }
            mPartNumbers.add(lastAPart.getNumber() + "(" + lastAPart.getLifeCycleState().getDisplay(Locale.CHINA) +")");
        }
        if(mPartNumbers.size() > 0){
            bo.setManufacturingNumber(StringUtils.join(mPartNumbers, ","));
        }
        //上次是否勾选
        CtConvertBomDao ctConvertBomDao = CtBeanFactory.newCtBeanFactory().getBean(CtConvertBomDao.class);
        List<CtConvertBomBo> historyBoList = ctConvertBomDao.queryConvertBomBoByNumber(partNumber);
        if(historyBoList.size() > 0){
            for(CtConvertBomBo historyBo : historyBoList){
                if(null != pnId){
                    if(pnId == historyBo.getPnId()){
                        continue;
                    }
                }
                if("是".equals(historyBo.getConvertBom())){
                    bo.setLastTimeCheck("是");
                }else{
                    bo.setLastTimeCheck("否");
                }
                break;
            }
        }else{
            bo.setLastTimeCheck("");
        }
        //这一行是否需要标红色
        if(isUpgradeObject && "半成品".equals(typeName)){
            List<WTPart> parentList = CtBomUtil.getParentParts(part);
            boolean hasEndPart = false;
            for(WTPart parentPart : parentList){
                String leafType = CtWTObjectUtil.getLeafTypeIdentifier(parentPart);
                logger.debug(">>>>>saveConvertBomBo leafType:" + leafType);
                if(CtEcConstant.Ct_PartType_EndPart.equals(leafType)){
                    logger.debug(">>>>>saveConvertBomBo parentPart:" + parentPart.getNumber());
                    hasEndPart = true;
                    break;
                }
            }
            //没被成品父项引用标红
            if(!hasEndPart){
                bo.setFlagRed("Y");
            }
        }
        bo.setCreator(userName);
        bo.setEditor(userName);
        bo.setCreateTime(new Date());
        bo.setModifyTime(new Date());
        ctConvertBomDao.saveConvertBomBo(bo);
        return bo;
    }

    /**
     * 校验转BOM表单数据--（成品/半成品、试产专用成品）设计BOM生效流程
     * @param pn
     * @throws Exception
     */
    public static void checkConvertBomData(PromotionNotice pn) throws Exception {
        CtConvertBomDao ctConvertBomDao = CtBeanFactory.newCtBeanFactory().getBean(CtConvertBomDao.class);
        Long pnId = pn.getPersistInfo().getObjectIdentifier().getId();
        List<CtConvertBomBo> boList = ctConvertBomDao.queryConvertBomInfo(pnId);
        String convertBom = "";
        String illustrate = "";
        String partNumber = "";
        StringBuilder msg = new StringBuilder();
        for(CtConvertBomBo bo : boList){
            if("否".equals(bo.getConvertMView())){
                convertBom = bo.getConvertBom();
                illustrate = bo.getIllustrate();
                partNumber = bo.getPartNumber();
                if(CtFormatUtil.hasContent(convertBom)){
                    if("是".equals(convertBom) && !"是".equals(bo.getConvertMView())){
                        msg.append("料号" + partNumber + "“本次是否转”为是，则需要进行转MBOM操作!\r\n");
                    }
                    if("否".equals(convertBom) && !CtFormatUtil.hasContent(illustrate)){
                        msg.append("料号" + partNumber + "“本次是否转”为否，则“不转MBOM说明”必填!\r\n");
                    }
                }else{
                    msg.append("料号" + partNumber + "未选择“本次是否转”！\r\n");
                }
            }
        }
        if(msg.toString().length() > 0){
            throw new Exception(msg.toString());
        }
    }

    /**
     * 导出所选物料的EBOM/MBOM差异
     * @param partNumberList
     * @return
     * @throws Exception
     */
    public static SXSSFWorkbook exportBomDifferent(List<String> partNumberList, String changeRequestId) throws Exception {
        SXSSFWorkbook workbook = new SXSSFWorkbook();//默认100行，超100行将写入临时文件
        workbook.setCompressTempFiles(false);//是否压缩临时文件，否则写入速度更快，但更占磁盘，但程序最后是会将临时文件删掉的
        //设置样式
        XSSFCellStyle titleCellStyle = (XSSFCellStyle) workbook.createCellStyle();
        titleCellStyle.setBorderBottom(BorderStyle.THIN);
        titleCellStyle.setBorderLeft(BorderStyle.THIN);
        titleCellStyle.setBorderTop(BorderStyle.THIN);
        titleCellStyle.setBorderRight(BorderStyle.THIN);
        titleCellStyle.setAlignment(HorizontalAlignment.CENTER);
        //黑色字体带边框样式
        XSSFCellStyle cellStyle = (XSSFCellStyle) workbook.createCellStyle();
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        //红色字体带边框样式
        XSSFCellStyle redCellStyle = (XSSFCellStyle) workbook.createCellStyle();
        redCellStyle.setBorderBottom(BorderStyle.THIN);
        redCellStyle.setBorderLeft(BorderStyle.THIN);
        redCellStyle.setBorderTop(BorderStyle.THIN);
        redCellStyle.setBorderRight(BorderStyle.THIN);
        //红色字体
        Font font = workbook.createFont();
        font.setColor(IndexedColors.RED.index);
        redCellStyle.setFont(font);
        //黑色字体带边框黄色底色样式
        XSSFCellStyle cellStyle3 = (XSSFCellStyle) workbook.createCellStyle();
        cellStyle3.setBorderBottom(BorderStyle.THIN);
        cellStyle3.setBorderLeft(BorderStyle.THIN);
        cellStyle3.setBorderTop(BorderStyle.THIN);
        cellStyle3.setBorderRight(BorderStyle.THIN);
        XSSFColor myColor = new XSSFColor(new java.awt.Color(255, 255, 0)); //创建自定义颜色
        cellStyle3.setFillForegroundColor(myColor);
        cellStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);  //设置填充类型
        //红色字体带边框黄色底色样式
        XSSFCellStyle cellStyle4 = (XSSFCellStyle) workbook.createCellStyle();
        cellStyle4.setBorderBottom(BorderStyle.THIN);
        cellStyle4.setBorderLeft(BorderStyle.THIN);
        cellStyle4.setBorderTop(BorderStyle.THIN);
        cellStyle4.setBorderRight(BorderStyle.THIN);
        cellStyle4.setFillForegroundColor(myColor);
        cellStyle4.setFillPattern(FillPatternType.SOLID_FOREGROUND);  //设置填充类型
        cellStyle4.setFont(font);
        //查询出需要标底色的物料编号集合
        Set<String> needBackgroundColorNumberList = new HashSet<>();
        if(CtFormatUtil.hasContent(changeRequestId)){
            needBackgroundColorNumberList = getNeedBackgroundColorNumberSet(changeRequestId);
        }

        //读取需要过滤的分类配置
        List<String> clfList = CtConvertBomFilterConfig.getConvertBomFilterConfig();
        for(String partNumber : partNumberList){
            logger.debug("<<<<<exportBomDifferent partNumber" + partNumber);
            Map<String, CtCompareBo> endProductMap = new TreeMap<>();
            Map<String, CtCompareBo> semiFinishedProductsMap = new TreeMap<>();
            Map<String, CtCompareBo> rawMaterialMap = new TreeMap<>();
            Map<String, CtCompareBo> mEndProductMap = new TreeMap<>();
            Map<String, CtCompareBo> mSemiFinishedProductsMap = new TreeMap<>();
            Map<String, CtCompareBo> mRawMaterialMap = new TreeMap<>();
            //处理数据，打平，排序，加总
            WTPart dPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);
            logger.debug("<<<<<exportBomDifferent dPart" + dPart);
            //封装当前物料D视图
            if(null != dPart){
                addPartToMap(null, null, dPart, clfList, endProductMap, semiFinishedProductsMap, rawMaterialMap);
                //封装当前物料D视图的BOM
                handleData(dPart, clfList, endProductMap, semiFinishedProductsMap, rawMaterialMap, dPart.getViewName());
            }
            WTPart mPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
            if(null != mPart){
                //封装当前物料M视图
                addPartToMap(null, null, mPart, clfList, mEndProductMap, mSemiFinishedProductsMap, mRawMaterialMap);
                //封装当前物料M视图的BOM
                handleData(mPart, clfList, mEndProductMap, mSemiFinishedProductsMap, mRawMaterialMap, mPart.getViewName());
            }
            //比对
            boolean isDifferent = compareResult(endProductMap, semiFinishedProductsMap, rawMaterialMap, mEndProductMap, mSemiFinishedProductsMap, mRawMaterialMap);
            Sheet sheet = workbook.createSheet(partNumber+"");
            Row row = null;
            Cell cell = null;
            //写入表头
            writeHead(sheet, titleCellStyle, cellStyle, isDifferent, partNumber);
            Map<String, Integer> rowIndexMap = new HashMap<>();
            rowIndexMap.put("rowIndex", 2);
            //写入成品
            writeContent(sheet, rowIndexMap, cellStyle, redCellStyle, endProductMap, mEndProductMap, needBackgroundColorNumberList, cellStyle3, cellStyle4);
            //写入半成品
            writeContent(sheet, rowIndexMap, cellStyle, redCellStyle, semiFinishedProductsMap, mSemiFinishedProductsMap, needBackgroundColorNumberList, cellStyle3, cellStyle4);
            //写入原材料
            writeContent(sheet, rowIndexMap, cellStyle, redCellStyle, rawMaterialMap, mRawMaterialMap, needBackgroundColorNumberList, cellStyle3, cellStyle4);
        }
        return workbook;
    }

    /**
     * 取得变更表单的数据
     * @param changeRequestId
     * @return
     * @throws Exception
     */
    public static Set<String> getNeedBackgroundColorNumberSet(String changeRequestId) throws Exception {
        Set<String> set = new HashSet<>();
        CtEcService service = ServiceFactory.getService(CtEcService.class);
        List<CtChangeItemBo> resultList = service.getChangeItems(changeRequestId,"ebom");
        List<CtChangeItemBo> resultMList = service.getChangeItems(changeRequestId,"mbom");
        for(CtChangeItemBo ctChangeItemBo : resultList){
            if("增加".equals(ctChangeItemBo.getChangeType()) || "修改".equals(ctChangeItemBo.getChangeType())){
                set.add(ctChangeItemBo.getChildNumberAfter());
            }
        }
        for(CtChangeItemBo ctChangeItemBo : resultMList){
            if("增加".equals(ctChangeItemBo.getChangeType()) || "修改".equals(ctChangeItemBo.getChangeType())){
                set.add(ctChangeItemBo.getChildNumberAfter());
            }
        }
        return set;
    }

    /**
     * 比对结果(用于首行的比对结果显示，SXSSFWorkbook不能在写了第二行再往第一行写入结果，所以要先比个结果出来)
     * @return
     * @throws Exception
     */
    public static boolean compareResult(Map<String, CtCompareBo> endProductMap, Map<String, CtCompareBo> semiFinishedProductsMap, Map<String, CtCompareBo> rawMaterialMap,
            Map<String, CtCompareBo> mEndProductMap, Map<String, CtCompareBo> mSemiFinishedProductsMap, Map<String, CtCompareBo> mRawMaterialMap) throws Exception {
        boolean b = compareProductMap(endProductMap, mEndProductMap);
        if(b){
            return true;
        }
        b = compareProductMap(semiFinishedProductsMap, mSemiFinishedProductsMap);
        if(b){
            return true;
        }
        b = compareProductMap(rawMaterialMap, mRawMaterialMap);
        if(b){
            return true;
        }
        return false;
    }

    /**
     * 比对两个MAP
     * @param map1
     * @param map2
     * @return
     * @throws Exception
     */
    public static boolean compareProductMap(Map<String, CtCompareBo> map1, Map<String, CtCompareBo> map2) throws Exception {
        if(map1.size() != map2.size()){
            return true;
        }
        for(Map.Entry<String, CtCompareBo> entry : map1.entrySet()){
            String partNumber = entry.getKey();
            CtCompareBo bo1 = entry.getValue();
            CtCompareBo bo2 = map2.get(partNumber);
            if(null == bo2){
                return true;
            }else{
                //两个视图的bo都不为空，则比对属性
                boolean isDifferent = compareBoAttribute(bo1, bo2);
                if(isDifferent){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 比对两个
     * @param dBo
     * @param mBo
     * @return
     * @throws Exception
     */
    public static boolean compareBoAttribute(CtCompareBo dBo, CtCompareBo mBo) throws Exception {
        boolean isDifferent = false;
        //类型
        boolean b1 = CtCompareBo.compareAttribute(dBo, mBo, "partType", "partType");
        //料号
        boolean b2 = CtCompareBo.compareAttribute(dBo, mBo, "partNumber", "partNumber");
        //版本
        boolean b3 = CtCompareBo.compareAttribute(dBo, mBo, "partVersion", "partVersion");
        //研发描述
        boolean b4 = CtCompareBo.compareAttribute(dBo, mBo, "partDesc", "partDesc");
        //数量
        boolean b5 = CtCompareBo.compareAttribute(dBo, mBo, "quantity", "quantity");
        //位号
        boolean b6 = CtCompareBo.compareAttribute(dBo, mBo, "tagNumber", "tagNumber");
        //关联M视图物料/关联E视图物料
        //boolean b7 = CtCompareBo.compareAttribute(dBo, mBo, "refMNumber", "refENumber");
        //直接父项
        boolean b8 = CtCompareBo.compareAttribute(dBo, mBo, "parentNumber", "parentNumber");
        //差异
        if(b1 || b2 || b3 || b4 || b5 || b6 || b8){
            isDifferent = true;
        }
        return isDifferent;
    }

    /**
     * 按类型写入excel，为了保证成品-->半成品-->原材料的顺序下，按料号排序
     * @param sheet
     * @param rowIndexMap 记录行下标
     * @param cellStyle
     * @param redCellStyle
     * @param endProductMap 某物料D视图BOM下的成品/半成品/原材料数据
     * @param mEndProductMap 某物料M视图BOM下的成品/半成品/原材料数据
     * @return 是否有差异
     * @throws Exception
     */
    public static boolean writeContent(Sheet sheet, Map<String, Integer> rowIndexMap, CellStyle cellStyle, CellStyle redCellStyle,
            Map<String, CtCompareBo> endProductMap, Map<String, CtCompareBo> mEndProductMap, Set<String> needBackgroundColorNumberList,
                                       CellStyle cellStyle3, CellStyle cellStyle4) throws Exception {
        logger.debug(">>>>>writeContent endProductMap<<<<<" + endProductMap);
        boolean isDifferent = false;
        int rowIndex = 0;
        if(null != rowIndexMap.get("rowIndex")){
            rowIndex = rowIndexMap.get("rowIndex");
        }
        for(Map.Entry<String, CtCompareBo> entry : endProductMap.entrySet()){
            String partNumber = entry.getKey();
            CtCompareBo dBo = entry.getValue();
            CtCompareBo mBo = mEndProductMap.get(partNumber);
            Row row = sheet.createRow(rowIndex);
            boolean b = writeRow(row, cellStyle, redCellStyle, dBo, mBo, needBackgroundColorNumberList, cellStyle3, cellStyle4);
            if(b){
                isDifferent = true;
            }
            //移除M视图匹配上了的
            if(null != mBo){
                mEndProductMap.remove(partNumber);
            }
            rowIndex++;
        }
        //如果还有数据，写入Excel
        if(CtFormatUtil.hasContent(mEndProductMap)){
            for(Map.Entry<String, CtCompareBo> entry : mEndProductMap.entrySet()){
                String partNumber = entry.getKey();
                CtCompareBo mBo = mEndProductMap.get(partNumber);
                Row row = sheet.createRow(rowIndex);
                writeRow(row, cellStyle, redCellStyle, null, mBo, needBackgroundColorNumberList, cellStyle3, cellStyle4);
                rowIndex++;
            }
            isDifferent = true;
        }
        //记录行下标
        rowIndexMap.put("rowIndex", rowIndex);
        return isDifferent;
    }


    /**
     * 写入行数据
     * @param row
     * @param cellStyle
     * @param redCellStyle
     * @param dBo
     * @param mBo
     * @return 这一行的数据是否有差异
     * @throws Exception
     */
    public static boolean writeRow(Row row, CellStyle cellStyle, CellStyle redCellStyle, CtCompareBo dBo, CtCompareBo mBo,
                                   Set<String> needBackgroundColorNumberList, CellStyle cellStyle3, CellStyle cellStyle4) throws Exception {
        boolean isDifferent = false;
        //如果是变更流程表单中的子项，则该行需要设置底色
        String value1 = "";
        if(null != dBo){
            value1 = dBo.getStringValue("partNumber");
        }
        String value2 = "";
        if(null != mBo){
            value2 = mBo.getStringValue("partNumber");
        }
        boolean showBackgroundColor = false;
        if(needBackgroundColorNumberList.contains(value1) || needBackgroundColorNumberList.contains(value2)){
            showBackgroundColor = true;
        }

        //序号
        Cell cell = row.createCell(0);
        if(showBackgroundColor){
            cell.setCellStyle(cellStyle3);
        }else{
            cell.setCellStyle(cellStyle);
        }
        cell.setCellValue((row.getRowNum()-1));

        //类型
        boolean b1 = writeCell(row, cellStyle, redCellStyle, dBo, mBo, "partType", "partType",1, 10, showBackgroundColor, cellStyle3, cellStyle4);
        //料号
        boolean b2 = writeCell(row, cellStyle, redCellStyle, dBo, mBo, "partNumber", "partNumber",2, 11, showBackgroundColor, cellStyle3, cellStyle4);
        //版本
        boolean b3 = writeCell(row, cellStyle, redCellStyle, dBo, mBo, "partVersion", "partVersion",3, 12, showBackgroundColor, cellStyle3, cellStyle4);
        //研发描述
        boolean b4 = writeCell(row, cellStyle, redCellStyle, dBo, mBo, "partDesc", "partDesc",4, 13, showBackgroundColor, cellStyle3, cellStyle4);
        //数量
        boolean b5 = writeCell(row, cellStyle, redCellStyle, dBo, mBo, "quantity", "quantity",5, 14, showBackgroundColor, cellStyle3, cellStyle4);
        //位号
        boolean b6 = writeCell(row, cellStyle, redCellStyle, dBo, mBo, "tagNumber", "tagNumber",6, 15, showBackgroundColor, cellStyle3, cellStyle4);
        //关联M视图物料/关联E视图物料
        boolean b7 = writeCell(row, cellStyle, redCellStyle, dBo, mBo, "refMNumber", "refENumber",7, 16, showBackgroundColor, cellStyle3, cellStyle4);
        //直接父项
        boolean b8 = writeCell(row, cellStyle, redCellStyle, dBo, mBo, "parentNumber", "parentNumber",8, 17, showBackgroundColor, cellStyle3, cellStyle4);
        //差异1
        if(b1 || b2 || b3 || b4 || b5 || b6 || b7 || b8){
            isDifferent = true;
        }
        cell = row.createCell(9);
        if(isDifferent){
            if(showBackgroundColor){
                cell.setCellStyle(cellStyle4);
            }else{
                cell.setCellStyle(redCellStyle);
            }
            cell.setCellValue("是");
        }else{
            if(showBackgroundColor){
                cell.setCellStyle(cellStyle3);
            }else{
                cell.setCellStyle(cellStyle);
            }
            cell.setCellValue("否");
        }
        //差异2
        cell = row.createCell(18);
        if(b2 || b5 || b6){
            if(showBackgroundColor){
                cell.setCellStyle(cellStyle4);
            }else{
                cell.setCellStyle(redCellStyle);
            }
            cell.setCellValue("是");
        }else{
            if(showBackgroundColor){
                cell.setCellStyle(cellStyle3);
            }else{
                cell.setCellStyle(cellStyle);
            }
            cell.setCellValue("否");
        }
        return isDifferent;
    }

    /**
     * 写列数据
     * @param row 行
     * @param cellStyle 样式1
     * @param redCellStyle 红色字体样式
     * @param dBo D视图数据
     * @param mBo M视图数据
     * @param key 字段名
     * @param key1 字段名
     * @param cellIndex1 D视图字段列位置
     * @param cellIndex2 M视图字段列位置
     * @param showBackgroundColor 是否显示背景颜色
     * @param cellStyle3 黑色字黄色底色的样式
     * @param cellStyle4 红色字黄色底色的样式
     * @return 返回该字段数据是否有差异
     * @throws Exception
     */
    public static boolean writeCell(Row row, CellStyle cellStyle, CellStyle redCellStyle, CtCompareBo dBo, CtCompareBo mBo,
            String key, String key1, int cellIndex1, int cellIndex2, boolean showBackgroundColor, CellStyle cellStyle3, CellStyle cellStyle4) throws Exception {
        boolean isDifferent = false;

        String value1 = "";
        if(null != dBo){
            value1 = dBo.getStringValue(key);
        }
        String value2 = "";
        if(null != mBo){
            value2 = mBo.getStringValue(key1);
        }
        logger.debug(">>>>>writeCell value1<<<<<" + value1);
        logger.debug(">>>>>writeCell value2<<<<<" + value2);
        Cell cell = row.createCell(cellIndex1);
        Cell cell1 = row.createCell(cellIndex2);
        if(dBo != null && dBo.compareAttribute(dBo, mBo, key, key1)){
            if(showBackgroundColor){
                cell.setCellStyle(cellStyle3);
                cell1.setCellStyle(cellStyle3);
            }else{
                cell.setCellStyle(cellStyle);
                cell1.setCellStyle(cellStyle);
            }
        }else{
            if(showBackgroundColor){
                cell.setCellStyle(cellStyle4);
                cell1.setCellStyle(cellStyle4);
            }else{
                cell.setCellStyle(redCellStyle);
                cell1.setCellStyle(redCellStyle);
            }
            isDifferent = true;
        }
        if(null != value1){
            cell.setCellValue(value1.toString());
        }else{
            cell.setCellValue("");
        }
        if(null != value2){
            cell1.setCellValue(value2.toString());
        }else{
            cell1.setCellValue("");
        }
        return isDifferent;
    }

    /**
     * 取得数据
     * @param parentPart
     * @param clfList
     * @param endProductMap
     * @param semiFinishedProductsMap
     * @param rawMaterialMap
     * @param viewName
     * @throws Exception
     */
    public static void handleData(WTPart parentPart, List<String> clfList, Map<String, CtCompareBo> endProductMap,
        Map<String, CtCompareBo> semiFinishedProductsMap, Map<String, CtCompareBo> rawMaterialMap, String viewName) throws Exception {
        if(null == parentPart){
            return;
        }
        QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(parentPart);
        while (linkQr.hasMoreElements()) {
            WTPartUsageLink qrLink = (WTPartUsageLink) linkQr.nextElement();
            WTPartMaster childPartMaster = (WTPartMaster) qrLink.getUses();
            String partNumber = childPartMaster.getNumber();
            WTPart childPart = null;
            if(CtConstant.VIEW_DESIGN.equals(viewName)){
                childPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);
            }else{
                childPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
                if(null == childPart){
                    childPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);
                }
            }
            if(null != childPart){
                //物料数据封装到MAP
                addPartToMap(parentPart, qrLink, childPart, clfList, endProductMap, semiFinishedProductsMap, rawMaterialMap);
                //递归
                handleData(childPart, clfList, endProductMap, semiFinishedProductsMap, rawMaterialMap, viewName);
            }
        }
    }

    /**
     * 物料数据封装到MAP
     * @param parentPart
     * @param qrLink
     * @param childPart
     * @param clfList
     * @param endProductMap
     * @param semiFinishedProductsMap
     * @param rawMaterialMap
     * @throws Exception
     */
    public static void addPartToMap(WTPart parentPart, WTPartUsageLink qrLink, WTPart childPart, List<String> clfList, Map<String, CtCompareBo> endProductMap,
            Map<String, CtCompareBo> semiFinishedProductsMap, Map<String, CtCompareBo> rawMaterialMap) throws Exception {
        String partNumber = childPart.getNumber();
        //过滤CBB及配置文件中的分类
        String typeName = CtWTObjectUtil.getTypeViewName(childPart);
        logger.debug(">>>>>addPartToMap typeName" + typeName);
        //过滤CBB物料
        if(typeName.contains("CBB")){
            return;
        }
        //过滤配置的物料
        String clf = CtPartClfUtil.getClfAttValue(childPart);
        logger.debug(">>>>>addPartToMap clf" + clf);
        if(clfList.contains(clf)){
            return;
        }

        //分类型
        CtCompareBo bo = new CtCompareBo(qrLink, childPart, parentPart);
        String partType = CtWTObjectUtil.getTypeIdentifier(childPart);
        logger.debug(">>>>>addPartToMap partType" + partType);
        if(partType.contains(CtEcConstant.Ct_PartType_EndPart)){
            //成品
            if(endProductMap.containsKey(partNumber)){
                //加总
                sumPartData(endProductMap, partNumber, parentPart, qrLink);
            }else{
                endProductMap.put(partNumber, bo);
            }
        }else if(partType.contains(CtEcConstant.Ct_PartType_HalfEndPart)){
            //半成品
            if(semiFinishedProductsMap.containsKey(partNumber)){
                //加总
                sumPartData(semiFinishedProductsMap, partNumber, parentPart, qrLink);
            }else{
                semiFinishedProductsMap.put(partNumber, bo);
            }
        }else{
            //原材料
            if(rawMaterialMap.containsKey(partNumber)){
                //加总
                sumPartData(rawMaterialMap, partNumber, parentPart, qrLink);
            }else{
                rawMaterialMap.put(partNumber, bo);
            }
        }
    }

    /**
     * 料号相同，需要把数量、位号、直接父项汇总
     * @param endProductMap
     * @param partNumber
     * @param parentPart
     * @param link
     * @throws Exception
     */
    public static void sumPartData(Map<String, CtCompareBo> endProductMap, String partNumber, WTPart parentPart, WTPartUsageLink link) throws Exception {
        CtCompareBo bo = endProductMap.get(partNumber);
        if(null != link){
            if(null != link.getQuantity()){
                if(CtFormatUtil.hasContent(bo.getQuantity())){
                    DecimalFormat decimalFormat = new DecimalFormat("#0.######"); // 设置格式化模式为保留六位小数
                    bo.setQuantity(decimalFormat.format(link.getQuantity().getAmount() + Double.parseDouble(bo.getQuantity())));
                }else{
                    bo.setQuantity(link.getQuantity().getAmount()+"");
                }
            }
            String tagNumber = CtBomUtil.getReferenceDesignator(link);
            if(CtFormatUtil.hasContent(tagNumber)){
                if(CtFormatUtil.hasContent(bo.getTagNumber())){
                    Set<String> tagNumberSet = dealTagNumber(bo.getTagNumber(), tagNumber);
                    bo.setTagNumber(StringUtils.join(tagNumberSet, ","));
                }else{
                    bo.setTagNumber(tagNumber);
                }
            }
        }
        if(null != parentPart && CtFormatUtil.hasContent(parentPart.getNumber())){
            if(CtFormatUtil.hasContent(bo.getParentNumber())){
                Set<String> parentPartNumberSet = dealTagNumber(bo.getParentNumber(), parentPart.getNumber());
                bo.setParentNumber(StringUtils.join(parentPartNumberSet, ","));
            }else{
                bo.setParentNumber(parentPart.getNumber());
            }
        }
    }

    /**
     * 将位号、直接父项加总、去重、排序
     * @param old
     * @param current
     * @return
     */
    public static Set<String> dealTagNumber(String old, String current) throws Exception {
        Map<String, String> treeMap = new TreeMap<>();
        String[] oldArray = old.split(",");
        for(int i = 0;i < oldArray.length;i++){
            treeMap.put(oldArray[i], oldArray[i]);
        }
        String[] currentArray = current.split(",");
        for(int i = 0;i < currentArray.length;i++){
            treeMap.put(currentArray[i], currentArray[i]);
        }
        return treeMap.keySet();
    }

    /**
     * 写入头部两行
     * @param sheet
     * @param titleCellStyle
     * @param cellStyle
     * @param isDifferent
     * @param partNumber
     * @throws Exception
     */
    public static void writeHead(Sheet sheet, CellStyle titleCellStyle, CellStyle cellStyle, boolean isDifferent, String partNumber) throws Exception {
        int rowIndex = 0;
        Row row = sheet.createRow(rowIndex);
        for(int i = 0;i <= 8; i++){
            Cell cell = row.createCell(i);
            if(i == 0){
                if(isDifferent){
                    cell.setCellValue("成品EBOM与MBOM一致性：否");
                }else{
                    cell.setCellValue("成品EBOM与MBOM一致性：是");
                }
            }
            cell.setCellStyle(titleCellStyle);
        }
        for(int i = 9;i <= 17; i++){
            Cell cell = row.createCell(i);
            if(i == 9){
                if(isDifferent){
                    cell.setCellValue("不一致成品：" + partNumber);
                }else{
                    cell.setCellValue("不一致成品：无");
                }
            }
            cell.setCellStyle(cellStyle);
        }
        //合并单元格
        CellRangeAddress mergedRegion = new CellRangeAddress(0, 0, 0, 8);
        sheet.addMergedRegion(mergedRegion);
        mergedRegion = new CellRangeAddress(0, 0, 9, 18);
        sheet.addMergedRegion(mergedRegion);

        rowIndex++;
        row = sheet.createRow(rowIndex);
        String[] titleArray = {"序号", "类型", "料号", "版本", "研发描述", "数量", "位号", "关联M视图物料", "直接父项", "差异1",
                "类型", "料号", "版本", "研发描述", "数量", "位号", "关联E视图物料", "直接父项", "差异2(仅物料、位号、数量差异)"};
        for(int i = 0;i < titleArray.length; i++){
            Cell cell = row.createCell(i);
            cell.setCellStyle(cellStyle);
            cell.setCellValue(titleArray[i]);
        }
    }

    /**
     * 校验打样物料不能作为非打样物料的子项(校验单层即可，一样能达到效果)
     * @param fatherPart
     * @throws Exception
     */
    public static void checkBom(WTPart fatherPart) throws Exception {
        WTPrincipal p = SessionHelper.getPrincipal();
        try{
            SessionHelper.manager.setAdministrator();
            QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(fatherPart);
            while (linkQr.hasMoreElements()) {
                WTPartUsageLink qrLink = (WTPartUsageLink) linkQr.nextElement();
                WTPartMaster childPartMaster = (WTPartMaster) qrLink.getUses();
                WTPart childPart = (WTPart)CtVersionUtil.getLatest(childPartMaster);
                if(childPart.getNumber().endsWith("D01") && !fatherPart.getNumber().endsWith("D01")){
                    throw new Exception("打样物料" + childPart.getNumber() + "不能作为非打样物料" + fatherPart.getNumber() + "的子项");
                }
            }
        }finally {
            SessionHelper.manager.setPrincipal(p.getName());
        }
    }

}
