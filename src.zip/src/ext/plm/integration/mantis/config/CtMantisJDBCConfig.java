package ext.plm.integration.mantis.config;


import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CtMantisJDBCConfig {
    private static String driver;
    private static String url;
    private static String user;
    private static String password;
    private static String host;
    private static String port;
    private static String lport;
    private static String rport;
    private static String sessionPassword;
    private static String database;
    private static Session session=null;

    static {
        Properties pro = new Properties();
        try {
            pro.load(new InputStreamReader(
                    CtMantisJDBCConfig.class.getResourceAsStream("JDBC.properties"), "UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }


        url = pro.getProperty("url");
        user = pro.getProperty("user");
        password = pro.getProperty("password");
        driver = pro.getProperty("driver");
        host = pro.getProperty("host");
        port = pro.getProperty("port");
        lport = pro.getProperty("lport");
        rport = pro.getProperty("rport");
        sessionPassword = pro.getProperty("sessionPassword");
        database = pro.getProperty("database");



    }

    public static Connection getConnection() throws Exception {
        Connection conn = null;
        String DB_URL = "jdbc:mysql://localhost:"+lport+"/"+database;
        try {
            Class.forName(driver);
            session = sshGo();
            conn = DriverManager.getConnection(DB_URL,user,password);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("连接远程Mantis失败！异常信息：" + e.getLocalizedMessage());
        }
        return conn;
    }

    /**
     * 通过SSH 通道获取连接
     * @return
     * @throws Exception
     */
    public static Session  sshGo() throws Exception{
        JSch jsch = new JSch();
        Session session = jsch.getSession(user, host, Integer.parseInt(port));
        session.setPassword(sessionPassword);
        session.setConfig("StrictHostKeyChecking", "no");
        session.connect();

        System.out.println("SSH="+session.getServerVersion());//这里打印SSH服务器版本信息
        //本地端口可自己指定一个，这里用11100，
        int assinged_port = session.setPortForwardingL(Integer.parseInt(lport), url, Integer.parseInt(rport));//端口映射 转发  数据库服务器地址url
        System.out.println("assinged_port:" + assinged_port);
        return session;
    }

    public static void close(Statement stmt,Connection conn) throws IOException {
        if(stmt!=null){
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        session.disconnect();
    }

    public static void close(Statement stmt, Connection conn, ResultSet rs){
        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(stmt!=null){
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        session.disconnect();
    }
}
