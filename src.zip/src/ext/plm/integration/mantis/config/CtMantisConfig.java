package ext.plm.integration.mantis.config;

import com.alibaba.fastjson.JSON;
import ext.plm.integration.sap.config.CtSapConfig;
import ext.plm.risk.config.CtRiskProperties;
import ext.plm.util.CtFormatUtil;
import org.springframework.core.io.PathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class CtMantisConfig {

    /**
     * 获取对应part的key值
     *
     * @param key
     * @return
     * @throws Exception
     */
    public static String getProperty(String key) throws Exception {
        Properties docKeyMap = new Properties();
//        docKeyMap.load(new InputStreamReader(
//                CtMantisConfig.class.getResourceAsStream("CtMantisConfig.properties"), "UTF-8"));
        docKeyMap = PropertiesLoaderUtils.loadProperties(new PathResource("/home/ptc/Windchill_11.0/Windchill/codebase/ext/plm/integration/mantis/config/CtMantisConfig.properties"));
        String result = "";
        System.out.println(JSON.toJSON(docKeyMap));
        String property = docKeyMap.getProperty(key);
        if(CtFormatUtil.hasContent(property)) {
            result = property;
        }

        return result;
    }

    //加载配置
    public static Properties loadConfig() throws Exception {
        Properties prop = new Properties();
        prop.load(new InputStreamReader(CtMantisConfig.class
                .getResourceAsStream("CtMantisConfig.properties"), "UTF-8"));
        return prop;
    }

//    //加载属性
//    public static String getProperty(String key) throws Exception{
//        Properties configProperties = loadConfig();
//        String property = configProperties.getProperty(key);
//        return property;
//    }

    /**
     * 按流程活动Key获取当前活动的必填字段
     * @param activityKey
     */
    public static List<String> getList(String activityKey)throws Exception{
        Properties configProperties = loadConfig();

        List<String> result = new ArrayList<String>();
        String attStr =configProperties.getProperty(activityKey);
        if(CtFormatUtil.hasContent(attStr)) {
            String[] requiredAtts = attStr.split(",");
            for(String attKey: requiredAtts) {
                result.add(attKey);
            }
        }

        return result;
    }

}
