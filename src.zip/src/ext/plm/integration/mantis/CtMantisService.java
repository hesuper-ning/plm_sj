package ext.plm.integration.mantis;

import ext.plm.common.CtPageBo;
import ext.plm.integration.mantis.bo.CtMantisBugBo;

import java.util.HashMap;
import java.util.List;

public interface CtMantisService {

    //分页查询
    CtPageBo<CtMantisBugBo> getItems(int page, int limit,CtMantisBugBo bo) throws Exception;

    List<CtMantisBugBo> getAllItems(HashMap<String, String> paramMap) throws Exception;

    //全量更新Mantis集成数据
    void restoreMantisBugs(List<CtMantisBugBo> allBugs) throws Exception;

    //全量更新Mantis集成数据
    void restoreMantisBugs() throws Exception;

    //远程连接Mantis数据库获取全量数据
    List<CtMantisBugBo> getRemoteMantisAllBugs() throws Exception;

    //=================测试方法  开始========================

    void testBatchInsert() throws Exception;


    //=================测试方法  结束========================
}
