package ext.plm.integration.mantis;


import ext.plm.integration.mantis.bo.CtMantisBugBo;
import ext.plm.integration.mantis.config.CtMantisConfig;
import ext.plm.integration.mantis.config.CtMantisJDBCConfig;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtFormatUtil;
import wt.method.MethodContext;
import wt.pom.WTConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;


public class CtMantisQuery {

    /**
     * 获得Bug查询的值
     * @return
     * @throws SQLException
     */
    public List<HashMap<String, String>> getItems(int page,int limit) throws Exception {
        CtMantisConfig config=new CtMantisConfig();

        List<HashMap<String, String>> itemList = new ArrayList<HashMap<String, String>>();
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        int min = (page-1)*limit+1;
        int max = page*limit;
        try {
            String sql = "";
            sql = "SELECT *　FROM (SELECT a.*, ROWNUM rn" +
                    "　FROM ZMantisBugs a)" +
                    "　WHERE rn >= "+min+" AND rn <= "+max;
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();

            while (result.next()) {
                HashMap<String, String> record = new HashMap<String, String>();
                record.put("id",result.getString("id"));
                List<String> bugs = config.getList("MantisBug");
                for (String bug : bugs) {
                    record.put(bug,result.getString(bug));
                }
                itemList.add(record);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (statement != null)
                statement.close();
            // connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return itemList;
    }

    public static void dailyRestoreMantisBugs() throws Exception{

    }

    /**
     * 通过数据库直连Mantis查询数据
     * @return
     * @throws Exception
     */
    public  List<CtMantisBugBo> getMantisData()throws Exception{
        List<CtMantisBugBo> itemList = new ArrayList();
        CtMantisConfig config=new CtMantisConfig();
        Connection connection = CtMantisJDBCConfig.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String restoreDate = CtDateUtil.getCurrentDate("yyyy-MM-dd HH:mm","GMT+8");
            /**
             SELECT bugt.id bugId,proj.name projectName,cate.name bugCategory,fies1.value testType,user1.realname reportUser
             ,user2.realname chargeUser,bugt.priority,bugt.severity,bugt.reproducibility,bugt.version productVersion,bugt.os osVersion
             ,bugt.target_version targetVersion,bugt.fixed_in_version fixedVersion,bugt.date_submitted submitDate,bugt.last_updated lastUpdateDate
             ,bugt.summary,bugt.status,bugt.resolution,bugh.date_modified closeDate,tagt.tag_name tagName
             FROM mantis_bug_table bugt
             LEFT JOIN mantis_project_table proj ON proj.id = bugt.project_id
             LEFT JOIN mantis_custom_field_table fiel ON fiel.NAME = '项目编号'
             LEFT JOIN mantis_custom_field_string_table fies ON fies.field_id = fiel.id AND fies.bug_id = bugt.id
             LEFT JOIN mantis_category_table cate ON cate.id = bugt.category_id
             LEFT JOIN mantis_custom_field_table fiel1 ON fiel1.NAME = '测试类型'
             LEFT JOIN mantis_custom_field_string_table fies1 ON fies1.field_id = fiel1.id AND fies1.bug_id = bugt.id
             LEFT JOIN mantis_user_table user1 ON user1.id = bugt.reporter_id
             LEFT JOIN mantis_user_table user2 ON user2.id = bugt.handler_id
             LEFT JOIN (
             SELECT id, bug_id, max(date_modified) as date_modified
             FROM mantis_bug_history_table WHERE field_name = 'status' AND new_value = '90' GROUP BY bug_id
             )bugh on bugh.bug_id = bugt.id
             LEFT JOIN (
             SELECT btag.bug_id, GROUP_CONCAT( tagta.name ) as tag_name
             FROM mantis_bug_tag_table btag LEFT JOIN mantis_tag_table tagta ON tagta.id = btag.tag_id
             GROUP BY btag.bug_id
             )tagt ON tagt.bug_id= bugt.id
             WHERE 1 = 1
             */
            String sql = "SELECT bugt.id bugId,proj.name projectName,cate.name bugCategory,fies1.value testType,fies.value projectNumber,user1.realname reportUser " +
                    " ,user2.realname chargeUser,bugt.priority,bugt.severity,bugt.reproducibility,bugt.version productVersion,bugt.os osVersion " +
                    " ,bugt.target_version targetVersion,bugt.fixed_in_version fixedVersion,bugt.date_submitted submitDate,bugt.last_updated lastUpdateDate " +
                    " ,bugt.summary,bugt.status,bugt.resolution,bugh.date_modified closeDate,tagt.tag_name tagName" +
                    " FROM mantis_bug_table bugt  " +
                    "  LEFT JOIN mantis_project_table proj ON proj.id = bugt.project_id  " +
                    "  LEFT JOIN mantis_custom_field_table fiel ON fiel.NAME = '项目编号'  " +
                    "  LEFT JOIN mantis_custom_field_string_table fies ON fies.field_id = fiel.id AND fies.bug_id = bugt.id  " +
                    "  LEFT JOIN mantis_category_table cate ON cate.id = bugt.category_id  " +
                    "  LEFT JOIN mantis_custom_field_table fiel1 ON fiel1.NAME = '测试类型'  " +
                    "  LEFT JOIN mantis_custom_field_string_table fies1 ON fies1.field_id = fiel1.id AND fies1.bug_id = bugt.id  " +
                    "  LEFT JOIN mantis_user_table user1 ON user1.id = bugt.reporter_id  " +
                    "  LEFT JOIN mantis_user_table user2 ON user2.id = bugt.handler_id  " +
                    "  LEFT JOIN (   " +
                    "    SELECT id, bug_id, max(date_modified) as date_modified  " +
                    "    FROM mantis_bug_history_table WHERE field_name = 'status' AND new_value = '90' GROUP BY bug_id  " +
                    "  )bugh on bugh.bug_id = bugt.id  " +
                    "  LEFT JOIN (  " +
                    "    SELECT btag.bug_id, GROUP_CONCAT( tagta.name ) as tag_name  " +
                    "    FROM mantis_bug_tag_table btag LEFT JOIN mantis_tag_table tagta ON tagta.id = btag.tag_id   " +
                    "    GROUP BY btag.bug_id   " +
                    "  )tagt ON tagt.bug_id= bugt.id   " +
                    " WHERE 1 = 1 ";
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();

            String dateFormat = "yyyy-MM-dd";
            CtMantisBugBo bugBo = null;
            long longId = 1000;
            while (result.next()) {
                bugBo = new CtMantisBugBo();
                bugBo.setId(longId);
                bugBo.setBugId(result.getString("bugId"));//bug ID
                //时间戳转换
                String submitDateStr = result.getString("submitDate");
                if(CtFormatUtil.hasContent(submitDateStr)){
                    submitDateStr = submitDateStr+"000"; //秒级改毫秒
                    submitDateStr = CtDateUtil.parseDate(submitDateStr,dateFormat);
                }else{
                    submitDateStr = "";
                }
                bugBo.setSubmitDate(submitDateStr);//提交时间

                bugBo.setSummary(result.getString("summary"));//问题描述
                bugBo.setProjectName(result.getString("projectName"));//项目名称
                bugBo.setProjectNumber(result.getString("projectNumber"));//项目名称
                bugBo.setReportUser(result.getString("reportUser"));//报告人
                bugBo.setChargeUser(result.getString("chargeUser"));//处理人
                bugBo.setBugCategory(result.getString("bugCategory"));//分类
                bugBo.setTestType(result.getString("testType"));//测试类型

                //状态码转中文名称
                String statusCode = result.getString("status");
                String statusDisplay = "";
                if(CtFormatUtil.hasContent(statusCode)){
                    statusDisplay = config.getProperty("status-"+statusCode);
                }
                bugBo.setStatus(statusDisplay);//问题状态

                //处理状况转中文名称
                String resolutionCode = result.getString("resolution");
                String resolutionDisplay = "";
                if(CtFormatUtil.hasContent(resolutionCode)){
                    resolutionDisplay = config.getProperty("resolution-"+resolutionCode);
                }
                bugBo.setResolution(resolutionDisplay);//处理状况

                //优先级转中文名称
                String priorityCode = result.getString("priority");
                String priorityDisplay = "";
                if(CtFormatUtil.hasContent(priorityCode)){
                    priorityDisplay = config.getProperty("priority-"+priorityCode);
                }
                bugBo.setPriority(priorityDisplay);//优先级

                //严重等级转中文名称
                String severityCode = result.getString("severity");
                String severityDisplay = "";
                if (CtFormatUtil.hasContent(severityCode)) {
                    severityDisplay = config.getProperty("severity-" + severityCode);
                }
                bugBo.setSeverity(severityDisplay);//严重等级

                //出现频率 reproducibility
                String reproducibilityCode = result.getString("reproducibility");
                String reproducibilityDisplay = "";
                if (CtFormatUtil.hasContent(reproducibilityCode)) {
                    reproducibilityDisplay = config.getProperty("reproducibility-" + reproducibilityCode);
                }
                bugBo.setReproducibility(reproducibilityDisplay);//出现频率

                bugBo.setProductVersion(result.getString("productVersion"));//产品版本
                bugBo.setOsVersion(result.getString("osVersion"));//操作系统版本
                bugBo.setTargetVersion(result.getString("targetVersion"));//目标版本
                bugBo.setFixedVersion(result.getString("fixedVersion"));//修正版本

                //时间戳转换
                String lastUpdateDateStr = result.getString("lastUpdateDate");
                if(CtFormatUtil.hasContent(lastUpdateDateStr)){
                    lastUpdateDateStr = lastUpdateDateStr + "000";//秒转毫秒
                    lastUpdateDateStr = CtDateUtil.parseDate(lastUpdateDateStr,dateFormat);
                }else{
                    lastUpdateDateStr = "";
                }
                bugBo.setLastUpdateDate(lastUpdateDateStr);//最后更新时间
                //时间戳转换
                String closeDateStr = result.getString("closeDate");
                if(CtFormatUtil.hasContent(closeDateStr)){
                    closeDateStr = closeDateStr + "000";//秒转毫秒
                    closeDateStr = CtDateUtil.parseDate(closeDateStr,dateFormat);
                }else{
                    closeDateStr = "";
                }
                bugBo.setCloseDate(closeDateStr);//关闭时间

                bugBo.setTagName(result.getString("tagName"));//标签

                bugBo.setRestoreDate(restoreDate);//更新时间

                itemList.add(bugBo);
                longId ++;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            CtMantisJDBCConfig.close(statement,connection);
        }
        return itemList;
    }



}
