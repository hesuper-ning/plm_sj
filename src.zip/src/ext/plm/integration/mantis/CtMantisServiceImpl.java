package ext.plm.integration.mantis;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import ext.plm.common.CtPageBo;
import ext.plm.integration.mantis.bo.CtMantisBugBo;
import ext.plm.integration.mantis.mapper.CtMantisMapper;
import ext.plm.util.CtDateUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import java.util.*;

@Service
public class CtMantisServiceImpl extends ServiceImpl<CtMantisMapper, CtMantisBugBo> implements CtMantisService {

    @Autowired
    private CtMantisMapper mapper;

    @Override
    public CtPageBo<CtMantisBugBo> getItems(int page, int limit, CtMantisBugBo paramsBo) throws Exception {

        boolean flag = SessionServerHelper.manager.setAccessEnforced(false);//放大权限
        CtPageBo<CtMantisBugBo> pageBo = null;
        boolean whetherFind = false;
        try {
            EntityWrapper<CtMantisBugBo> wrapper = new EntityWrapper<CtMantisBugBo>();
            if (paramsBo != null) {
                if (!StringUtils.isEmpty(paramsBo.getProjectNumber())) {
                    wrapper.and().like("projectNumber", paramsBo.getProjectNumber().trim());
                    whetherFind = true;
                }
                if (!StringUtils.isEmpty(paramsBo.getProjectName())) {
                    wrapper.and().like("projectName", paramsBo.getProjectName());
                    whetherFind = true;
                }
                if (!StringUtils.isEmpty(paramsBo.getStatus())) {
                    wrapper.and().like("status", paramsBo.getStatus());
                    whetherFind = true;
                }
                if (!StringUtils.isEmpty(paramsBo.getSeverity())) {
                    wrapper.and().like("severity", paramsBo.getSeverity());
                    whetherFind = true;
                }
                if (!StringUtils.isEmpty(paramsBo.getTestType())) {
                    wrapper.and().like("testType", paramsBo.getTestType());
                    whetherFind = true;
                }
                if (!StringUtils.isEmpty(paramsBo.getBugCategory())) {
                    wrapper.and().like("bugCategory", paramsBo.getBugCategory());
                    whetherFind = true;
                }
            }


            pageBo = new CtPageBo<>();

            //分页
            if (page != 0 && limit != 0) {
                //有查询的时候都从第一页开始
                if (whetherFind) {
                    page = 1;
                }
                PageHelper.startPage(page, limit);
            }

            List<CtMantisBugBo> bugItems = super.baseMapper.selectList(wrapper);
            List<CtMantisBugBo> bugList = new ArrayList<>();
            long total = bugItems.size();
            if (page != 0 && limit != 0) {
                PageInfo<CtMantisBugBo> pageInfo = new PageInfo<>(bugItems);
                bugList = pageInfo.getList();
                total = pageInfo.getTotal();
            }

            //把分页之后的结果和总数放入pageBo
            pageBo.setResultData(bugList);
            pageBo.setTotal(total);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(flag);
        }
        return pageBo;
    }

    @Override
    public List<CtMantisBugBo> getAllItems(HashMap<String, String> paramMap) throws Exception {
        EntityWrapper<CtMantisBugBo> wrapper = new EntityWrapper<CtMantisBugBo>();

        if (paramMap != null) {
            Set<Map.Entry<String, String>> entries = paramMap.entrySet();
            for (Map.Entry<String, String> entry : entries) {
                String key = entry.getKey();
                String value = entry.getValue();
                if (!StringUtils.isEmpty(value)) {
                    wrapper.and().like(key, value);
                }
            }
        }
        return super.selectList(wrapper);

    }

    /**
     * 重新装载全量Mantis数量
     *
     * @param allBugs
     * @throws Exception
     */
    @Override
    public void restoreMantisBugs(List<CtMantisBugBo> allBugs) throws Exception {
        //清空数据
        mapper.deleteAllData();
        //批量添加
        try {
            for (CtMantisBugBo bo : allBugs) {
                super.insert(bo);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("保存Mantis数据失败！后台异常：" + e.getLocalizedMessage());
        }
    }

    /**
     * 重新装载全量Mantis数量
     *
     * @throws Exception
     */
    @Override
    public void restoreMantisBugs() throws Exception {
        //清空数据
        mapper.deleteAllData();
        //批量添加
        List<CtMantisBugBo> allBugs = getRemoteMantisAllBugs();
        try {
            for (CtMantisBugBo bo : allBugs) {
                super.insert(bo);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("保存Mantis数据失败！后台异常：" + e.getLocalizedMessage());
        }
    }

    //远程连接Mantis数据库获取全量数据
    @Override
    public List<CtMantisBugBo> getRemoteMantisAllBugs() throws Exception {

        CtMantisQuery query = new CtMantisQuery();

        return query.getMantisData();
    }


    //=================测试方法  开始========================
    //样例数据测试批量添加
    @Override
    public void testBatchInsert() throws Exception {

        List<CtMantisBugBo> resultItems = new ArrayList<>();
        int itemNum = 3;
        for (int i = 0; i < itemNum; i++) {
            CtMantisBugBo item = new CtMantisBugBo();
            item.setId(new Long(500 + i));
            item.setBugId("testBug" + i);
            item.setBugCategory("类别" + i);
            item.setSummary("测试问题" + i);
            item.setStatus("状态" + i);
            item.setPriority("优先级" + i);
            item.setChargeUser("用户A");
            item.setReportUser("用户B");
            item.setProjectName("项目名称" + i);
            item.setSubmitDate("2021-01-02");
            item.setLastUpdateDate("2021-11-01");
            item.setSeverity("严重程度" + i);
            item.setResolution("解决方式" + i);
            item.setCloseDate("2021-11-10");
            item.setRestoreDate(CtDateUtil.getCurrentDate());
            resultItems.add(item);
        }
        restoreMantisBugs(resultItems);
    }

//=================测试方法  结束========================

}
