package ext.plm.integration.mantis.bo;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

@TableName("ZMantisBugs")
public class CtMantisBugBo{

    @TableField("id")
    private Long id;

    @TableField("bugId")
    private String bugId; //问题Id

    @TableField("submitDate")
    private String submitDate; //提交时间

    @TableField("summary")
    private String summary; //问题描述

    @TableField("projectName")
    private String projectName; //项目名称

    @TableField("bugCategory")
    private String bugCategory; //分类

    @TableField("testType")
    private String testType; //测试类型

    @TableField("projectNumber")
    private String projectNumber; //处理人

    @TableField("reportUser")
    private String reportUser; //报告人

    @TableField("chargeUser")
    private String chargeUser; //处理人

    @TableField("status")
    private String status; //问题状态

    @TableField("resolution")
    private String resolution; //处理状况

    @TableField("priority")
    private String priority; //优先级

    @TableField("severity")
    private String severity; //严重等级

    @TableField("reproducibility")
    private String reproducibility; //出现频率

    @TableField("productVersion")
    private String productVersion; //产品版本

    @TableField("osVersion")
    private String osVersion; //操作系统版本

    @TableField("targetVersion")
    private String targetVersion; //目标版本

    @TableField("fixedVersion")
    private String fixedVersion; //修正版本

    @TableField("lastUpdateDate")
    private String lastUpdateDate; //最后更新时间

    @TableField("closeDate")
    private String closeDate; //关闭时间

    @TableField("restoreDate")
    private String restoreDate; //重新加载时间

    @TableField("tagName")
    private String tagName; //标签

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBugId() {
        return bugId;
    }

    public void setBugId(String bugId) {
        this.bugId = bugId;
    }

    public String getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(String submitDate) {
        this.submitDate = submitDate;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getReportUser() {
        return reportUser;
    }

    public void setReportUser(String reportUser) {
        this.reportUser = reportUser;
    }

    public String getChargeUser() {
        return chargeUser;
    }

    public void setChargeUser(String chargeUser) {
        this.chargeUser = chargeUser;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getBugCategory() {
        return bugCategory;
    }

    public void setBugCategory(String bugCategory) {
        this.bugCategory = bugCategory;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(String closeDate) {
        this.closeDate = closeDate;
    }

    public String getRestoreDate() {
        return restoreDate;
    }

    public void setRestoreDate(String restoreDate) {
        this.restoreDate = restoreDate;
    }

    public String getTestType() {
        return testType;
    }

    public void setTestType(String testType) {
        this.testType = testType;
    }

    public String getReproducibility() {
        return reproducibility;
    }

    public void setReproducibility(String reproducibility) {
        this.reproducibility = reproducibility;
    }

    public String getProductVersion() {
        return productVersion;
    }

    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public String getTargetVersion() {
        return targetVersion;
    }

    public void setTargetVersion(String targetVersion) {
        this.targetVersion = targetVersion;
    }

    public String getFixedVersion() {
        return fixedVersion;
    }

    public void setFixedVersion(String fixedVersion) {
        this.fixedVersion = fixedVersion;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getProjectNumber() {
        return projectNumber;
    }

    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }
}
