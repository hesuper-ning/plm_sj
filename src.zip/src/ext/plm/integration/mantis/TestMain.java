package ext.plm.integration.mantis;

import ext.plm.bean.CtBeanService;
import ext.plm.problem.CtProblemMgtServiceImpl;
import wt.services.ServiceFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestMain {
    private  static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);
   
    public static void main(String[] args) throws Exception {

        boolean methodExist = true;
//        if("mantis".equalsIgnoreCase(args[0])){
//            //windchill ext.plm.integration.mantis.TestMain mantis
//            List<HashMap<String, String>> getItems =(List<HashMap<String, String>>)beanService.doMethod(CtMantisService.class, "getItems", null);
//            for (HashMap<String, String> getItem : getItems) {
//                for (Map.Entry<String, String> entry : getItem.entrySet()) {
//                    String key = entry.getKey();
//                    String value = entry.getValue();
//                    System.out.println("key = " + key);
//                    System.out.println("value = " + value);
//                }
//            }
//        }else
        System.out.println("======TestMain.java 开始调用  " + args[0] + "=============");
        if("mantisRestore".equalsIgnoreCase(args[0])){
            //全量更新Mantis集成数据
            //windchill ext.plm.integration.mantis.TestMain mantisRestore
            beanService.doMethod(CtMantisService.class, "restoreMantisBugs", null);
        }else if("testDataInsert".equalsIgnoreCase(args[0])){
            //样例数据测试批量添加
            //windchill ext.plm.integration.mantis.TestMain testDataInsert
            beanService.doMethod(CtMantisService.class, "testBatchInsert", null);
        }else {
            methodExist = false;
            System.out.println(">>>方法'"+args[0]+"'不存在！");
        }

        if (methodExist) {
            System.out.println(">>>方法执行结束！");
        }
    }
}
