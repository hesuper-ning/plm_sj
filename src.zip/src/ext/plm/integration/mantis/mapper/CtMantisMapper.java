package ext.plm.integration.mantis.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import ext.plm.integration.mantis.bo.CtMantisBugBo;
import ext.plm.problem.bo.CtProblemMgtBo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface CtMantisMapper extends BaseMapper<CtMantisBugBo> {

    //删除全部
    int deleteAllData();

    //根据条件查询问题共享信息
    List<CtMantisBugBo> getMantisBugItems();

}
