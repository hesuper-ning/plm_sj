package ext.plm.integration.mantis;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import ext.plm.common.CtPageBo;
import ext.plm.common.CtResApiResult;
import ext.plm.integration.mantis.bo.CtMantisBugBo;
import ext.plm.integration.mantis.config.CtMantisConfig;
import ext.plm.problem.bo.CtProblemMgtBo;
import ext.plm.tool.poi.CtExportExcelTool;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtUserUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import wt.org.WTUser;
import wt.util.WTException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.print.Book;
import java.io.PrintWriter;
import java.util.*;

@RestController
public class CtMantisController {

    @Autowired
    private CtMantisService service;

    @RequestMapping(value = "Mantis/getBugItems", method = {RequestMethod.GET, RequestMethod.POST,
            RequestMethod.PUT})
    public void getBugItems(CtMantisBugBo bo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject result = new JSONObject();

        try {
            String page = request.getParameter("page");
            String limit = request.getParameter("limit");

            CtPageBo<CtMantisBugBo> itemList = service.getItems(Integer.parseInt(page), Integer.parseInt(limit),bo);

            String jsonArrStr = JSON.toJSONString(itemList.getResultData());
            JSONArray itemArr = JSONArray.parseArray(jsonArrStr);
            result.put("items", itemArr);
            result.put("totalCount",itemList.getTotal());
            result.put("success", true);
            result.put("msg", "查询成功！");
        }catch (WTException wte){
            wte.printStackTrace();
            result.put("success", false);
            result.put("error", wte.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("error", "查询信息失败！异常信息："+e.getMessage());
        }

        response.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.write(result.toString());
    }

    /**
     * 导出问题数据
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "Mantis/exportMantis",method = {RequestMethod.GET,RequestMethod.POST})
    public void exportProblems(HttpServletRequest request, HttpServletResponse response) throws Exception{
        JSONObject result = new JSONObject();

        try {
        if (!CtUserUtil.isInGroup(CtUserUtil.getCurrentUser(),"bug问题下载白名单")){
            throw new WTException("非授权查询用户，请联系管理员将您添加到'bug问题下载白名单'角色中。");
        }
        String data = request.getParameter("data");
        HashMap<String, String> paramMap = new HashMap<>();
        if(CtFormatUtil.hasContent(data)){
            paramMap = JSON.parseObject(data,HashMap.class);
        }

        List<CtMantisBugBo> resultList = service.getAllItems(paramMap);
        String jsonArrStr = JSON.toJSONString(resultList);
        List<Map> maps = JSONObject.parseArray(jsonArrStr, Map.class);

        String userAgent = request.getHeader("User-Agent");
        String fileName = "bug查询报表_"+System.currentTimeMillis()+".xlsx";

        response.setContentType("application/octet-stream");
        if (userAgent.contains("MSIE") || userAgent.contains("Trident")) {
            //ie
            fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
        } else if(userAgent.toUpperCase().indexOf("Edge") > 0){
            //edge
            fileName = new String(fileName.getBytes("GBK"),"ISO8859-1");
        }else {
            // //firefox、chrome、safari、opera：
            fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
        }
        //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
        response.setHeader("Content-disposition",String.format("attachment; filename=\"%s\"", fileName));
        response.setContentType("application/vnd.ms-excel;charset=utf-8");
        response.setCharacterEncoding("UTF-8");
        CtExportExcelTool exportExcelTool = new CtExportExcelTool(fileName, "bug查询报表导出模板.xlsx");
        exportExcelTool.expExcel(maps,response.getOutputStream());
        } catch (WTException e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("error", e.getMessage());
            response.setContentType("application/json;charset=utf-8");
            response.setCharacterEncoding("utf-8");
            PrintWriter out = response.getWriter();
            out.write(result.toString());
        }
    }


}
