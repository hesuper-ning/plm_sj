package ext.plm.integration.sap.bo;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

public class CtSapBomItemBo implements Serializable {

    private static final long serialVersionUID = 9152902476573309834L;

    @JSONField(name="ITM_OPTYP")
    String ITM_OPTYP; //行修改标识

    @JSONField(name="IDNRK")
    String IDNRK; //下阶物料

    @JSONField(name="MENGE")
    String MENGE; //数量

    @JSONField(name="MEINS")
    String MEINS; //单位

    @JSONField(name="ALPGR")
    String ALPGR; //替代组

    @JSONField(name="ALPRF")
    String ALPRF; //替代优先级

    @JSONField(name="ZZTXT")
    String ZZTXT; //位号长文本

    @JSONField(name="EWAHR")
    String EWAHR; //替代组比例

    @JSONField(name="ZTEXT")
    String ZTEXT; //bom备注

    public String getZTEXT() {
        return ZTEXT;
    }

    public void setZTEXT(String ZTEXT) {
        this.ZTEXT = ZTEXT;
    }

    public String getITM_OPTYP() {
        return ITM_OPTYP;
    }

    public void setITM_OPTYP(String ITM_OPTYP) {
        this.ITM_OPTYP = ITM_OPTYP;
    }

    public String getIDNRK() {
        return IDNRK;
    }

    public void setIDNRK(String IDNRK) {
        this.IDNRK = IDNRK;
    }

    public String getMENGE() {
        return MENGE;
    }

    public void setMENGE(String MENGE) {
        this.MENGE = MENGE;
    }

    public String getMEINS() {
        return MEINS;
    }

    public void setMEINS(String MEINS) {
        this.MEINS = MEINS;
    }

    public String getALPGR() {
        return ALPGR;
    }

    public void setALPGR(String ALPGR) {
        this.ALPGR = ALPGR;
    }

    public String getALPRF() {
        return ALPRF;
    }

    public void setALPRF(String ALPRF) {
        this.ALPRF = ALPRF;
    }

    public String getZZTXT() {
        return ZZTXT;
    }

    public void setZZTXT(String ZZTXT) {
        this.ZZTXT = ZZTXT;
    }

    public String getEWAHR() {
        return EWAHR;
    }

    public void setEWAHR(String EWAHR) {
        this.EWAHR = EWAHR;
    }
}
