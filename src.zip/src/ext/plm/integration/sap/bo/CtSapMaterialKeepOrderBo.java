package ext.plm.integration.sap.bo;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

public class CtSapMaterialKeepOrderBo implements Serializable {

    private static final long serialVersionUID = -553496620533426644L;

    @JSONField(name="BWART")
    String BWART; //移动类型(库存管理), Z03 领料， Z04退料

    @JSONField(name="KOSTL")
    String KOSTL; //成本中心

    @JSONField(name="AUFNR")
    String AUFNR; //订单号

    @JSONField(name="WEMPF")
    String WEMPF; //收货方

    @JSONField(name="WERKS")
    String WERKS; //工厂  (用于明细项）

    @JSONField(name="LGORT")
    String LGORT; //库存地点  (用于明细项）

    @JSONField(name="ZZCRMID")
    String ZZCRMID; //CRM主键 传文档编号后6位，保证唯一即可，回调时要用

    public String getBWART() {
        return BWART;
    }

    public void setBWART(String BWART) {
        this.BWART = BWART;
    }

    public String getKOSTL() {
        return KOSTL;
    }

    public void setKOSTL(String KOSTL) {
        this.KOSTL = KOSTL;
    }

    public String getAUFNR() {
        return AUFNR;
    }

    public void setAUFNR(String AUFNR) {
        this.AUFNR = AUFNR;
    }

    public String getWEMPF() {
        return WEMPF;
    }

    public void setWEMPF(String WEMPF) {
        this.WEMPF = WEMPF;
    }

    public String getWERKS() {
        return WERKS;
    }

    public void setWERKS(String WERKS) {
        this.WERKS = WERKS;
    }

    public String getLGORT() {
        return LGORT;
    }

    public void setLGORT(String LGORT) {
        this.LGORT = LGORT;
    }

    public String getZZCRMID() {
        return ZZCRMID;
    }

    public void setZZCRMID(String ZZCRMID) {
        this.ZZCRMID = ZZCRMID;
    }
}
