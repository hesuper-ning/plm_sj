package ext.plm.integration.sap.bo;

import java.io.Serializable;

public class CtSapResultBo implements Serializable{

    private static final long serialVersionUID = -7019815631506820411L;
    String id;//日志id

    String processNo;//流程编号

    String processType;//接口类型

    String mainObject; //主题对象，如物料编码

    String integrateUrl;//集成url

    String responseCode; //返回码

    String responseMsg; //返回信息

    String errorMsg; //异常信息

    String integrateData;//集成数据

    boolean integrateFlag;//是否成功

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProcessNo() {
        return processNo;
    }

    public void setProcessNo(String processNo) {
        this.processNo = processNo;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseMsg() {
        return responseMsg;
    }

    public void setResponseMsg(String responseMsg) {
        this.responseMsg = responseMsg;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getIntegrateUrl() {
        return integrateUrl;
    }

    public void setIntegrateUrl(String integrateUrl) {
        this.integrateUrl = integrateUrl;
    }

    public String getIntegrateData() {
        return integrateData;
    }

    public void setIntegrateData(String integrateData) {
        this.integrateData = integrateData;
    }

    public boolean getIntegrateFlag() {
        return integrateFlag;
    }

    public void setIntegrateFlag(boolean integrateFlag) {
        this.integrateFlag = integrateFlag;
    }

    public boolean isIntegrateFlag() {
        return integrateFlag;
    }

    public String getProcessType() {
        return processType;
    }

    public void setProcessType(String processType) {
        this.processType = processType;
    }

    public String getMainObject() {
        return mainObject;
    }

    public void setMainObject(String mainObject) {
        this.mainObject = mainObject;
    }
}

