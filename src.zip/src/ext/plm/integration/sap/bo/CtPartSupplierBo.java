package ext.plm.integration.sap.bo;

/**
 * @Author: lzp
 * @Date: 2024/1/9
 * @Description:
 */
public class CtPartSupplierBo {
    //供应商账号
    private String supplierAccountNumber;
    //供应商名称
    private String supplierName;
    //供应商邮件
    private String supplierEmail;
    //物料编码
    private String partNumber;

    public String getSupplierAccountNumber() {
        return supplierAccountNumber;
    }

    public void setSupplierAccountNumber(String supplierAccountNumber) {
        this.supplierAccountNumber = supplierAccountNumber;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierEmail() {
        return supplierEmail;
    }

    public void setSupplierEmail(String supplierEmail) {
        this.supplierEmail = supplierEmail;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    public CtPartSupplierBo(String supplierAccountNumber, String supplierName, String supplierEmail, String partNumber) {
        this.supplierAccountNumber = supplierAccountNumber;
        this.supplierName = supplierName;
        this.supplierEmail = supplierEmail;
        this.partNumber = partNumber;
    }

    public CtPartSupplierBo() {
    }
}
