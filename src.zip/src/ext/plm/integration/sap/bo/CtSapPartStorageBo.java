package ext.plm.integration.sap.bo;

import java.io.Serializable;

public class CtSapPartStorageBo implements Serializable {

    private static final long serialVersionUID = -1108094760331805374L;

    String storage = "0"; //库存数量

    String storageAtMake  = "0"; //在制品数量

    String storageAtPO  = "0"; //采购订单PO数量

    String storageAtPR  = "0"; //在外采购PR数量

    String storageAtMaintain = "0"; //维修周转品数量

    String storageAtSaleOrder = "0"; //销售订单量

    String orderUnit; //采购订单计量单位

    String oneYearShipped = "0";//已发货（一年内）

    String monthlyConsumption = "0";//每月平均耗用量

    boolean numberIsNull = false;//物料号在SAP有没有查到库存记录

    public String getOrderUnit() {
        return orderUnit;
    }

    public void setOrderUnit(String orderUnit) { this.orderUnit = orderUnit; }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public String getStorageAtMake() {
        return storageAtMake;
    }

    public void setStorageAtMake(String storageAtMake) {
        this.storageAtMake = storageAtMake;
    }

    public String getStorageAtPO() {
        return storageAtPO;
    }

    public void setStorageAtPO(String storageAtPO) {
        this.storageAtPO = storageAtPO;
    }

    public String getStorageAtPR() {
        return storageAtPR;
    }

    public void setStorageAtPR(String storageAtPR) {
        this.storageAtPR = storageAtPR;
    }

    public String getStorageAtMaintain() {
        return storageAtMaintain;
    }

    public void setStorageAtMaintain(String storageAtMaintain) {
        this.storageAtMaintain = storageAtMaintain;
    }

    public String getStorageAtSaleOrder() {
        return storageAtSaleOrder;
    }

    public void setStorageAtSaleOrder(String storageAtSaleOrder) {
        this.storageAtSaleOrder = storageAtSaleOrder;
    }

    public String getOneYearShipped() {
        return oneYearShipped;
    }

    public void setOneYearShipped(String oneYearShipped) {
        this.oneYearShipped = oneYearShipped;
    }

    public String getMonthlyConsumption() {
        return monthlyConsumption;
    }

    public void setMonthlyConsumption(String monthlyConsumption) {
        this.monthlyConsumption = monthlyConsumption;
    }

    public boolean getNumberIsNull() {
        return numberIsNull;
    }

    public void setNumberIsNull(boolean numberIsNull) {
        this.numberIsNull = numberIsNull;
    }
}
