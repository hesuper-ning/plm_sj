package ext.plm.integration.sap.bo;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

public class CtSapPartBo implements Serializable {

    private static final long serialVersionUID = 6893520826774207602L;

    @JSONField(name="BISMT")
    String BISMT; //旧物料号

    @JSONField(name="MATNR")
    String MATNR; //物料编号

    @JSONField(name="MTART")
    String MTART; //物料类型

    @JSONField(name="MAKTX")
    String MAKTX; //物料描述

    @JSONField(name="MEINS")
    String MEINS; //基本计量单位

    @JSONField(name="MATKL")
    String MATKL; //物料组

    @JSONField(name="ZMATNE")
    String ZMATNE;//英文描述

    @JSONField(name="ZMATNR")
    String ZMATNR;//物料描述（研发）

    @JSONField(name="ZMAKTX")
    String ZMAKTX;//销售描述

    @JSONField(name="SPART")
    String SPART;//产品组

    @JSONField(name="EXTWG")
    String EXTWG;//外部物料组

    @JSONField(name="ZQCODE")
    String ZQCODE;//器件库编码 选填，板件类必填

    @JSONField(name="ZDIANS")
    String ZDIANS;//控制器点数

    @JSONField(name="ZPROIN")
    String ZPROIN;//产品关键特性

    @JSONField(name="LABOR")
    String LABOR;//优先级

    @JSONField(name="MSTAE")
    String MSTAE;//跨工厂物料状态 2

    @JSONField(name="GROES")
    String GROES;//大小/量纲(体积)

    @JSONField(name="ZEINR")
    String ZEINR;//文档号码(财务税收分类编码)

    @JSONField(name="ZTEXT")
    String ZTEXT;//物料长文本 255

    @JSONField(name="WERKS")
    String WERKS;//工厂 4

    @JSONField(name="VKORG")
    String VKORG;//销售组织 4

    @JSONField(name="VTWEG")
    String VTWEG;//分销渠道 2

    @JSONField(name="DWERK")
    String DWERK;//交货工厂 4

    @JSONField(name="TAXM1")
    String TAXM1;//物料的税分类 1 ？

    @JSONField(name="KTGRM")
    String KTGRM;//科目设置组  2

    @JSONField(name="MTPOS")
    String MTPOS;//项目类别组 4

    @JSONField(name="LADGR")
    String LADGR;//装载组 4

    @JSONField(name="EKGRP")
    String EKGRP;//采购组 3

    @JSONField(name="KAUTB")
    String KAUTB;//标识: "允许自动采购订单" 1

    @JSONField(name="KORDB")
    String KORDB;//标识: 源清单要求  1

    @JSONField(name="ART")
    String ART;//检验类型 8

    @JSONField(name="MAABC")
    String MAABC;//库存ABC标识 1

    @JSONField(name="DISMM")
    String DISMM;//物料需求计划类型(MRP类型) 2

    @JSONField(name="DISPO")
    String DISPO;//物料需求计划控制员  公式计算

    @JSONField(name="DISLS")
    String DISLS;//物料计划内批量程序（批量大小） 2 MB

    @JSONField(name="BSTMI")
    String BSTMI;//最小批量

    @JSONField(name="AUSSS")
    String AUSSS;//装配报废百分比

    @JSONField(name="BSTRF")
    String BSTRF;//采购订单数量的舍入值

    @JSONField(name="BESKZ")
    String BESKZ;//采购类型(获取类型) 1

    @JSONField(name="SOBSL")
    String SOBSL;//特殊采购类型(特殊获取类型) 2

    @JSONField(name="RGEKZ")
    String RGEKZ;//标识：反冲

    @JSONField(name="SCHGT")
    String SCHGT;//指示符：散装物料

    @JSONField(name="LGPRO")
    String LGPRO;//发货存储地点(生产仓储地点) 4

    @JSONField(name="LGFSB")
    String LGFSB;//外部采购的缺省仓储位置(外部采购仓储地点) 4

    @JSONField(name="FHORI")
    String FHORI;//浮动排产时间容余码(计划边际码) 3

    @JSONField(name="DZEIT")
    String DZEIT;//厂内生产时间(自制生产时间)

    @JSONField(name="PLIFZ")
    String PLIFZ;//计划交货时间（天）

    @JSONField(name="WEBAZ")
    String WEBAZ;//以天计的收货处理时间

    @JSONField(name="EISBE")
    String EISBE;//安全库存

    @JSONField(name="STRGR")
    String STRGR;//计划策略组 2

    @JSONField(name="VRMOD")
    String VRMOD;//消耗模式 1

    @JSONField(name="VINT1")
    String VINT1;//消耗期间:逆向 3

    @JSONField(name="VINT2")
    String VINT2;//消耗时期 3

    @JSONField(name="MTVFP")
    String MTVFP;//可用性检查 2

    @JSONField(name="SBDKZ")
    String SBDKZ;//独立/集中标识 1

    @JSONField(name="KAUSF")
    String KAUSF;//组件报废百分比 2

    @JSONField(name="KZAUS")
    String KZAUS;//中止指示符(非连续标识) 1

    @JSONField(name="AUSDT")
    String AUSDT;//中断日期(生效日期)

    @JSONField(name="NFMAT")
    String NFMAT;//后续物料

    @JSONField(name="FEVOR")
    String FEVOR;//生产管理员 3

    @JSONField(name="SFCPF")
    String SFCPF;//生产计划参数文件 6

    @JSONField(name="SERNP")
    String SERNP;//序列号参数文件 4

    @JSONField(name="AUSME")
    String AUSME;//发货单位

    @JSONField(name="BKLAS")
    String BKLAS;//评估类 4

    @JSONField(name="MLAST")
    String MLAST;//物料价格确定: 控制 1

    @JSONField(name="VPRSV")
    String VPRSV;//价格控制指示符 1

    @JSONField(name="STPRS")
    String STPRS;//标准价格 11

    @JSONField(name="VERPR")
    String VERPR;//移动平均价格/周期单价

    @JSONField(name="PEINH")
    String PEINH;//价格单位 5

    @JSONField(name="EKALR")
    String EKALR;//成本估算 1

    @JSONField(name="HKMAT")
    String HKMAT;//物料相关的源 1

    @JSONField(name="PRCTR")
    String PRCTR;// 利润中心 10

    @JSONField(name="REVLV")
    String REVLV;// 版次号 10

    @JSONField(name="ZREVLV")
    String ZREVLV;// 内部版本-无限制

    @JSONField(name="ZMSTA")
    String ZMSTA;//物料状态（中文）

    @JSONField(name="ZCERTREQ")
    String ZCERTREQ;//研发环保认证要求

    @JSONField(name="ZCERTCONF")
    String ZCERTCONF;//环保认证确认

    public String getBISMT() {
        return BISMT;
    }

    public void setBISMT(String BISMT) {
        this.BISMT = BISMT;
    }

    public String getMATNR() {
        return MATNR;
    }

    public void setMATNR(String MATNR) {
        this.MATNR = MATNR;
    }

    public String getMTART() {
        return MTART;
    }

    public void setMTART(String MTART) {
        this.MTART = MTART;
    }

    public String getMAKTX() {
        return MAKTX;
    }

    public void setMAKTX(String MAKTX) {
        this.MAKTX = MAKTX;
    }

    public String getMEINS() {
        return MEINS;
    }

    public void setMEINS(String MEINS) {
        this.MEINS = MEINS;
    }

    public String getMATKL() {
        return MATKL;
    }

    public void setMATKL(String MATKL) {
        this.MATKL = MATKL;
    }

    public String getZMATNE() {
        return ZMATNE;
    }

    public void setZMATNE(String ZMATNE) {
        this.ZMATNE = ZMATNE;
    }

    public String getZMATNR() {
        return ZMATNR;
    }

    public void setZMATNR(String ZMATNR) {
        this.ZMATNR = ZMATNR;
    }

    public String getZMAKTX() {
        return ZMAKTX;
    }

    public void setZMAKTX(String ZMAKTX) {
        this.ZMAKTX = ZMAKTX;
    }

    public String getSPART() {
        return SPART;
    }

    public void setSPART(String SPART) {
        this.SPART = SPART;
    }

    public String getEXTWG() {
        return EXTWG;
    }

    public void setEXTWG(String EXTWG) {
        this.EXTWG = EXTWG;
    }

    public String getZQCODE() {
        return ZQCODE;
    }

    public void setZQCODE(String ZQCODE) {
        this.ZQCODE = ZQCODE;
    }

    public String getZDIANS() {
        return ZDIANS;
    }

    public void setZDIANS(String ZDIANS) {
        this.ZDIANS = ZDIANS;
    }

    public String getZPROIN() {
        return ZPROIN;
    }

    public void setZPROIN(String ZPROIN) {
        this.ZPROIN = ZPROIN;
    }

    public String getLABOR() {
        return LABOR;
    }

    public void setLABOR(String LABOR) {
        this.LABOR = LABOR;
    }

    public String getMSTAE() {
        return MSTAE;
    }

    public void setMSTAE(String MSTAE) {
        this.MSTAE = MSTAE;
    }

    public String getGROES() {
        return GROES;
    }

    public void setGROES(String GROES) {
        this.GROES = GROES;
    }

    public String getZEINR() {
        return ZEINR;
    }

    public void setZEINR(String ZEINR) {
        this.ZEINR = ZEINR;
    }

    public String getZTEXT() {
        return ZTEXT;
    }

    public void setZTEXT(String ZTEXT) {
        this.ZTEXT = ZTEXT;
    }

    public String getWERKS() {
        return WERKS;
    }

    public void setWERKS(String WERKS) {
        this.WERKS = WERKS;
    }

    public String getVKORG() {
        return VKORG;
    }

    public void setVKORG(String VKORG) {
        this.VKORG = VKORG;
    }

    public String getVTWEG() {
        return VTWEG;
    }

    public void setVTWEG(String VTWEG) {
        this.VTWEG = VTWEG;
    }

    public String getDWERK() {
        return DWERK;
    }

    public void setDWERK(String DWERK) {
        this.DWERK = DWERK;
    }

    public String getTAXM1() {
        return TAXM1;
    }

    public void setTAXM1(String TAXM1) {
        this.TAXM1 = TAXM1;
    }

    public String getKTGRM() {
        return KTGRM;
    }

    public void setKTGRM(String KTGRM) {
        this.KTGRM = KTGRM;
    }

    public String getMTPOS() {
        return MTPOS;
    }

    public void setMTPOS(String MTPOS) {
        this.MTPOS = MTPOS;
    }

    public String getLADGR() {
        return LADGR;
    }

    public void setLADGR(String LADGR) {
        this.LADGR = LADGR;
    }

    public String getEKGRP() {
        return EKGRP;
    }

    public void setEKGRP(String EKGRP) {
        this.EKGRP = EKGRP;
    }

    public String getKAUTB() {
        return KAUTB;
    }

    public void setKAUTB(String KAUTB) {
        this.KAUTB = KAUTB;
    }

    public String getKORDB() {
        return KORDB;
    }

    public void setKORDB(String KORDB) {
        this.KORDB = KORDB;
    }

    public String getART() {
        return ART;
    }

    public void setART(String ART) {
        this.ART = ART;
    }

    public String getMAABC() {
        return MAABC;
    }

    public void setMAABC(String MAABC) {
        this.MAABC = MAABC;
    }

    public String getDISMM() {
        return DISMM;
    }

    public void setDISMM(String DISMM) {
        this.DISMM = DISMM;
    }

    public String getDISPO() {
        return DISPO;
    }

    public void setDISPO(String DISPO) {
        this.DISPO = DISPO;
    }

    public String getDISLS() {
        return DISLS;
    }

    public void setDISLS(String DISLS) {
        this.DISLS = DISLS;
    }

    public String getBSTMI() {
        return BSTMI;
    }

    public void setBSTMI(String BSTMI) {
        this.BSTMI = BSTMI;
    }

    public String getAUSSS() {
        return AUSSS;
    }

    public void setAUSSS(String AUSSS) {
        this.AUSSS = AUSSS;
    }

    public String getBSTRF() {
        return BSTRF;
    }

    public void setBSTRF(String BSTRF) {
        this.BSTRF = BSTRF;
    }

    public String getBESKZ() {
        return BESKZ;
    }

    public void setBESKZ(String BESKZ) {
        this.BESKZ = BESKZ;
    }

    public String getSOBSL() {
        return SOBSL;
    }

    public void setSOBSL(String SOBSL) {
        this.SOBSL = SOBSL;
    }

    public String getRGEKZ() {
        return RGEKZ;
    }

    public void setRGEKZ(String RGEKZ) {
        this.RGEKZ = RGEKZ;
    }

    public String getSCHGT() {
        return SCHGT;
    }

    public void setSCHGT(String SCHGT) {
        this.SCHGT = SCHGT;
    }

    public String getLGPRO() {
        return LGPRO;
    }

    public void setLGPRO(String LGPRO) {
        this.LGPRO = LGPRO;
    }

    public String getLGFSB() {
        return LGFSB;
    }

    public void setLGFSB(String LGFSB) {
        this.LGFSB = LGFSB;
    }

    public String getFHORI() {
        return FHORI;
    }

    public void setFHORI(String FHORI) {
        this.FHORI = FHORI;
    }

    public String getDZEIT() {
        return DZEIT;
    }

    public void setDZEIT(String DZEIT) {
        this.DZEIT = DZEIT;
    }

    public String getPLIFZ() {
        return PLIFZ;
    }

    public void setPLIFZ(String PLIFZ) {
        this.PLIFZ = PLIFZ;
    }

    public String getWEBAZ() {
        return WEBAZ;
    }

    public void setWEBAZ(String WEBAZ) {
        this.WEBAZ = WEBAZ;
    }

    public String getEISBE() {
        return EISBE;
    }

    public void setEISBE(String EISBE) {
        this.EISBE = EISBE;
    }

    public String getSTRGR() {
        return STRGR;
    }

    public void setSTRGR(String STRGR) {
        this.STRGR = STRGR;
    }

    public String getVRMOD() {
        return VRMOD;
    }

    public void setVRMOD(String VRMOD) {
        this.VRMOD = VRMOD;
    }

    public String getVINT1() {
        return VINT1;
    }

    public void setVINT1(String VINT1) {
        this.VINT1 = VINT1;
    }

    public String getVINT2() {
        return VINT2;
    }

    public void setVINT2(String VINT2) {
        this.VINT2 = VINT2;
    }

    public String getMTVFP() {
        return MTVFP;
    }

    public void setMTVFP(String MTVFP) {
        this.MTVFP = MTVFP;
    }

    public String getSBDKZ() {
        return SBDKZ;
    }

    public void setSBDKZ(String SBDKZ) {
        this.SBDKZ = SBDKZ;
    }

    public String getKAUSF() {
        return KAUSF;
    }

    public void setKAUSF(String KAUSF) {
        this.KAUSF = KAUSF;
    }

    public String getKZAUS() {
        return KZAUS;
    }

    public void setKZAUS(String KZAUS) {
        this.KZAUS = KZAUS;
    }

    public String getAUSDT() {
        return AUSDT;
    }

    public void setAUSDT(String AUSDT) {
        this.AUSDT = AUSDT;
    }

    public String getNFMAT() {
        return NFMAT;
    }

    public void setNFMAT(String NFMAT) {
        this.NFMAT = NFMAT;
    }

    public String getFEVOR() {
        return FEVOR;
    }

    public void setFEVOR(String FEVOR) {
        this.FEVOR = FEVOR;
    }

    public String getSFCPF() {
        return SFCPF;
    }

    public void setSFCPF(String SFCPF) {
        this.SFCPF = SFCPF;
    }

    public String getSERNP() {
        return SERNP;
    }

    public void setSERNP(String SERNP) {
        this.SERNP = SERNP;
    }

    public String getAUSME() {
        return AUSME;
    }

    public void setAUSME(String AUSME) {
        this.AUSME = AUSME;
    }

    public String getBKLAS() {
        return BKLAS;
    }

    public void setBKLAS(String BKLAS) {
        this.BKLAS = BKLAS;
    }

    public String getMLAST() {
        return MLAST;
    }

    public void setMLAST(String MLAST) {
        this.MLAST = MLAST;
    }

    public String getVPRSV() {
        return VPRSV;
    }

    public void setVPRSV(String VPRSV) {
        this.VPRSV = VPRSV;
    }

    public String getSTPRS() {
        return STPRS;
    }

    public void setSTPRS(String STPRS) {
        this.STPRS = STPRS;
    }

    public String getVERPR() {
        return VERPR;
    }

    public void setVERPR(String VERPR) {
        this.VERPR = VERPR;
    }

    public String getPEINH() {
        return PEINH;
    }

    public void setPEINH(String PEINH) {
        this.PEINH = PEINH;
    }

    public String getEKALR() {
        return EKALR;
    }

    public void setEKALR(String EKALR) {
        this.EKALR = EKALR;
    }

    public String getHKMAT() {
        return HKMAT;
    }

    public void setHKMAT(String HKMAT) {
        this.HKMAT = HKMAT;
    }

    public String getPRCTR() {
        return PRCTR;
    }

    public void setPRCTR(String PRCTR) {
        this.PRCTR = PRCTR;
    }

    public String getREVLV() {
        return REVLV;
    }

    public void setREVLV(String REVLV) {
        this.REVLV = REVLV;
    }

    public String getZREVLV() {
        return ZREVLV;
    }

    public void setZREVLV(String ZREVLV) {
        this.ZREVLV = ZREVLV;
    }

    public String getZMSTA() {
        return ZMSTA;
    }

    public void setZMSTA(String ZMSTA) {
        this.ZMSTA = ZMSTA;
    }

    public String getZCERTREQ() {
        return ZCERTREQ;
    }

    public void setZCERTREQ(String ZCERTREQ) {
        this.ZCERTREQ = ZCERTREQ;
    }

    public String getZCERTCONF() {
        return ZCERTCONF;
    }

    public void setZCERTCONF(String ZCERTCONF) {
        this.ZCERTCONF = ZCERTCONF;
    }
}
