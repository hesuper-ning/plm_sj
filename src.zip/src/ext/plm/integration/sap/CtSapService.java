package ext.plm.integration.sap;

import ext.plm.integration.sap.bo.CtSapPartBo;
import ext.plm.integration.sap.bo.CtSapPartStorageBo;
import ext.plm.supplier.bo.CtSupplierInfoBo;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtSapService {

    //后台触发创建部件
    String createPart(String partNumber)throws Exception;

    //后台触发停用部件
    String disablePart(String partNumber)throws Exception;

    //后台触发更新BOM
    void updateBom(String name,String bomNumber,String design,String processNo,String ecnNumber,String bomType,String plant)throws Exception;

    //查物料库存
    String getPartStorage(String partNumber) throws Exception;

    //查物料库存
    CtSapPartStorageBo getPartStorageBo(String partNumber) throws Exception;

    //查物料成本
    String queryPartCost(String partNumber) throws Exception;

    //查BOM
    String queryBOM(String partNumber,String startDate) throws Exception;

    //全量更新供应商
    String restoreSapSupplier() throws Exception;

    //按名称或编号获取供应商列表
    List<CtSupplierInfoBo> getSuppliers(String param) throws Exception;

    //按名称或编号查找单个供应商
    CtSupplierInfoBo getSupplier(String numberOrName) throws Exception;



    //====================测试部分==================================

    //测试创建伪造部件
    String createFakePart(CtSapPartBo partBo)throws Exception;

    //测试创建伪造BOM
    String createFakeBOM(String bomNumber,String bomType)throws Exception;

    //测试创建伪造ECN
    String createFakeECN(String ecnNumber,String ecnDesc,String ecnReason,String effectTime)throws Exception;

    //测试创建伪造预留单
    String createFakeMaterialKeepOrder(String orderType,String projectNumber)throws Exception;


}
