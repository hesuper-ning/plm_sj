package ext.plm.integration.sap;

import ext.plm.common.CtResApiResult;
import ext.plm.risk.riskCommon.CtResApiResultRisk;
import ext.plm.supplier.bo.CtSupplierInfoBo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CtSapController {

    @Autowired
    private CtSapService service;

    /**
     * 按名称或编号搜索供应商列表，要求搜索参数至少2个字符
     *
     * @throws Exception
     */
    @RequestMapping(value = "/sap/getSupplierList", method = {RequestMethod.GET})
    public CtResApiResult getSuppliers(@RequestParam("query") String query) throws Exception {
        try {
            List<CtSupplierInfoBo> itemList = service.getSuppliers(query);

            return CtResApiResultRisk.success(itemList);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResultRisk.fail("获取数据库信息失败，后台异常信息：\r\n" + e.getLocalizedMessage(), null);
        }
    }

    /**
     * 按名称或编号获取单个供应商
     *
     * @throws Exception
     */
    @RequestMapping(value = "/sap/getSupplier", method = {RequestMethod.GET})
    public CtResApiResult getSupplier(@RequestParam("query") String numberOrName) throws Exception {
        try {
            CtSupplierInfoBo bo = service.getSupplier(numberOrName);

            return CtResApiResultRisk.success(bo);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResultRisk.fail("获取数据库信息失败，后台异常信息：\r\n" + e.getLocalizedMessage(), null);
        }
    }

}

