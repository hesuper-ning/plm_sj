package ext.plm.integration.sap;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.Environment;
import com.sap.conn.jco.rt.DefaultStructure;

import ext.plm.common.CtConstant;
import ext.plm.integration.sap.bo.CtSapBomItemBo;
import ext.plm.integration.sap.bo.CtSapMaterialKeepOrderBo;
import ext.plm.integration.sap.bo.CtSapPartBo;
import ext.plm.integration.sap.bo.CtSapResultBo;
import ext.plm.integration.sap.config.CtSapConfig;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.IBAUtil;
import wt.projmgmt.admin.Project2;
import wt.util.WTException;

/**
 * 与接口连接相关的代码归于此类中，CtSapInterface调用此类进行数据传输
 */
public class CtSapAccess {

    //此logger已指向独立日志文件，如”SAP-1909241037-2808-log4j.log"
    static Logger logger = Logger.getLogger(CtSapAccess.class);

    /**
     * 连接SAP，获取JCoDestination对象
     *
     * @return
     * @throws RuntimeException
     */
    public JCoDestination getJCoDestination() throws RuntimeException {
        JCoDestination destination = null;
        try {
            if (Environment.isDestinationDataProviderRegistered()) {
                destination = JCoDestinationManager.getDestination("ABAP_AS");
            } else {
                CtSapConfig sapConstant = new CtSapConfig();
                Properties prop = sapConstant.loadProperties();
                Environment.registerDestinationDataProvider(sapConstant);
                sapConstant.changePropertiesForABAP_AS(prop);
                destination = JCoDestinationManager.getDestination("ABAP_AS");
                logger.info(">>>集成地址："+prop.getProperty("jco.client.ashost"));
            }
            if (destination == null) {
                throw new RuntimeException("连接SAP的连接为null！");
            }
            destination.getRepository().clear();//清理缓存
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("ERROR：连接SAP接口失败,请联系管理员");
        }
        return destination;
    }

    //================================部件 开始=====================================================
    /**
     * 创建或修改Part
     *
     * @param bo 修改BO对象
     * @param updateFlag 修改标识， I,U,D
     * @return 接口返回结果
     * @throws Exception
     */
    public CtSapResultBo createOrUpdateSapPart(CtSapPartBo bo,String updateFlag) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();
        
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String createPart = CtSapConfig.PART_CREATE_UPDATE;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(createPart);

            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            input.setValue("LV_FLAG",updateFlag); //更新标识

            //视图标识（全打上X)
            DefaultStructure viewData = (DefaultStructure) input.getValue("LV_VIEWTYPE");
            viewData.setValue("ZBASIC","X");
            //只有创建时需要拓展视图需要带上X，更新不许带X
            if("I".equals(updateFlag)){
                viewData.setValue("ZSALES","X");
                viewData.setValue("ZPURCHASE","X");
                viewData.setValue("ZQUALITY","X");
                viewData.setValue("ZMRP","X");
                viewData.setValue("ZWORK_SCHED","X");
                viewData.setValue("ZCOST_ACCOUNT","X");
                viewData.setValue("ZSTORAGE","X");
            }



            DefaultStructure iDataParam = (DefaultStructure) input.getValue("LV_VIEWDATA");
            // 循环添加 I_DATA 组件值
            Field[] fields = bo.getClass().getDeclaredFields();
            for (Field field : fields) {
                // 因SAP属性值都是大写，需转换
                String name = field.getName().toUpperCase();
                if(name.equalsIgnoreCase("serialVersionUID")){
                    continue;//跳过序列化字段
                }
                field.setAccessible(true); // 私有属性必须设置访问权限
                Object resultValue = field.get(bo);
                if (CtFormatUtil.hasContent(resultValue)) {
                    iDataParam.setValue(name, resultValue);
                } else {
                    iDataParam.setValue(name, "");
                }
            }

            // 执行
            function.execute(destination);

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println(bo.getMATNR()+">>>SAP返回集成物料信息标记=" + returnType + "，信息=" + returnMsg);

            resultBo.setResponseCode(returnType);
            if (returnType.equalsIgnoreCase("S")) {
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg("物料接口成功!"+returnMsg);
            } else {
                resultBo.setIntegrateFlag(false);
                resultBo.setResponseMsg("物料接口失败!");
                resultBo.setErrorMsg("错误码：" + returnType + ",SAP返回信息：" + returnMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }

    /**
     * 物料停用接口
     * @param partNumber
     * @return
     * @throws Exception
     */
    public CtSapResultBo disableSapPart(String partNumber) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取到SAP的函数
            String disablePart = CtSapConfig.PART_DISABLE;
            JCoFunction function = destination.getRepository().getFunction(disablePart);

            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            input.setValue("LV_MATNR",partNumber); //物料编码

            // 执行
            function.execute(destination);

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");

            resultBo.setResponseCode(returnType);
            if (returnType.equalsIgnoreCase("S")) {
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg("物料停用成功!"+returnMsg);
            } else {
                resultBo.setIntegrateFlag(false);
                resultBo.setResponseMsg("物料停用失败!");
                resultBo.setErrorMsg("错误码：" + returnType + ",SAP返回信息：" + returnMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }


    /**
     * 查询物料信息
     * @param partNumber
     * @return
     * @throws Exception
     */
    public CtSapResultBo queryPartInfo(String partNumber) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "S"; //SAP端不返回接口状态，只能当成功
        try {
            destination.ping();
            // 获取函数名称
            String queryPart = CtSapConfig.PART_QUERY;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(queryPart);

            //物料号
            JCoParameterList input = function.getImportParameterList();
            input.setValue("LV_MATNR",partNumber);


            // 执行
            function.execute(destination);

            JCoTable  storeTable = function.getTableParameterList().getTable("LV_VIEWDATA");//物料查询结果
            JSONArray storeArray = new JSONArray();
            for(int i = 0; i < storeTable.getNumRows(); i++){
                storeTable.setRow(i);
                JSONObject resultJson = new JSONObject();
                String number = storeTable.getValue("MATNR").toString();//物料编号
                number = number.replaceAll("^(0+)", "");//去掉前面的0
                resultJson.put("partNumber",number);//部件编码

                resultJson.put("partName",storeTable.getValue("MAKTX")); //名称
                resultJson.put("state",storeTable.getValue("MSTAE")); //跨工厂状态
                resultJson.put("unit",storeTable.getValue("MEINS")); //单位1
                resultJson.put("costPrice",storeTable.getValue("STPRS")); //物料成本价
                resultJson.put("buyPrice",storeTable.getValue("VERPR")); //采购价格
                resultJson.put("priceFlag",storeTable.getValue("VPRSV")); //价格控制符
                storeArray.add(resultJson);
            }

            if(storeArray.size() >1){
                logger.info(">>>注意：物料'"+partNumber+"'查询到的结果信息有"+storeArray.size()+"条，只取第一条结果！");
            }

            System.out.println(partNumber+">>>>查询物料信息 = " + storeArray.toJSONString());

            // 获取返回信息 (注：查询接口，SAP不返回接口状态）
          /*  JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println(">>>SAP返回查询物料结果=" + returnType + "，信息=" + returnMsg);

            if (!"S".equalsIgnoreCase(returnType)) {
                resultBo.setErrorMsg(returnMsg); //存异常信息
            }
            */

            resultBo.setResponseCode(returnType);
            resultBo.setIntegrateFlag(true);
            resultBo.setResponseMsg(storeArray.toJSONString()); //返回信息用于放查询结果json

        } catch (Exception e) {
            //不抛异常，只存异常
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }

    /**
     * 查询库存信息
     * @param partNumber
     * @return
     * @throws Exception
     */
    public CtSapResultBo queryPartStorage(String partNumber) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String queryPartStorage = CtSapConfig.PART_STORAGE_QUERY;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(queryPartStorage);

            //物料号
            JCoParameterList input = function.getImportParameterList();
            input.setValue("L_MATNR",partNumber);

            // 执行
            function.execute(destination);

            JCoTable  storeTable = function.getTableParameterList().getTable("I_OUT");//查询结果
            JSONArray storeArray = new JSONArray();
            for(int i = 0; i < storeTable.getNumRows(); i++){
                storeTable.setRow(i);
                JSONObject resultJson = new JSONObject();
                resultJson.put("storage",storeTable.getValue("MENGE1"));//
                resultJson.put("storageAtMake",storeTable.getValue("MENGE2")); //在制品数量
                resultJson.put("storageAtMaintain",storeTable.getValue("MENGE3")); //维修周转品数量
                resultJson.put("storageAtSaleOrder",storeTable.getValue("MENGE4")); //销售订单量
                resultJson.put("storageAtPO",storeTable.getValue("MENGE5")); //采购订单PO数量
                resultJson.put("storageAtPR",storeTable.getValue("MENGE6")); //在外采购PR数量
                resultJson.put("oneYearShipped",storeTable.getValue("MENGE7")); //已发货（一年内）
                resultJson.put("monthlyConsumption",storeTable.getValue("MENGE8")); //每月平均耗用量
                resultJson.put("orderUnit",storeTable.getValue("BSTME")); //采购订单计量单位
                storeArray.add(resultJson);
            }

            System.out.println(partNumber+">>>>物料成本查询信息 = " + storeArray.toJSONString());

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println(">>>SAP返回查询库存结果=" + returnType + "，信息=" + returnMsg);

            resultBo.setResponseCode(returnType);
            if (!"S".equalsIgnoreCase(returnType)) {
                resultBo.setErrorMsg("物料库存查询失败！SAP返回信息："+returnMsg); //存异常信息
                resultBo.setIntegrateFlag(false);
            }else{
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg(storeArray.toJSONString()); //返回信息用于放查询结果json
            }

        } catch (Exception e) {
            //不抛异常，只存异常
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }

    /**
     * 查询物料成本 (废弃，改为从物料信息中查询)
//     * @param partNumber
     * @return
     * @throws Exception
     */
    @Deprecated
    /*public CtSapResultBo queryPartCost(String partNumber) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String queryPartCost = CtSapConfig.PART_COST_QUERY;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(queryPartCost);

            //查询参数：BOM编码
            JCoTable  bomTable = function.getTableParameterList().getTable("SMATNR");
            bomTable.appendRow();
            bomTable.setValue("SIGN","I"); //固定值
            bomTable.setValue("OPTION","EQ");//固定值
            bomTable.setValue("LOW",partNumber);//物料编码

            // 执行
            function.execute(destination);

            JCoTable  storeTable = function.getTableParameterList().getTable("OT_COST");//查询结果
            JSONArray storeArray = new JSONArray();
            for(int i = 0; i < storeTable.getNumRows(); i++){
                storeTable.setRow(i);
                JSONObject resultJson = new JSONObject();
                resultJson.put("partNumber",storeTable.getValue("MATNR"));//部件编码
                resultJson.put("partName",storeTable.getValue("MAKTX")); //名称
                resultJson.put("priceDuration",storeTable.getValue("BWKEY")); //估价范围
                resultJson.put("accountCode",storeTable.getValue("KADKY")); //成本核算日期 (码)
                resultJson.put("cost",storeTable.getValue("ZZCOST")); //合计成本
                storeArray.add(resultJson);
            }

            System.out.println(partNumber+">>>>物料成本查询信息 = " + storeArray.toJSONString());

            // 获取返回信息
            DefaultStructure returnTable = (DefaultStructure)function.getExportParameterList().getValue("OV_RETURN");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println(">>>SAP返回物料成本结果=" + returnType + "，信息=" + returnMsg);

            resultBo.setResponseCode(returnType);
            if (!"S".equalsIgnoreCase(returnType)) {
                resultBo.setErrorMsg("物料成本查询失败！SAP返回信息："+returnMsg); //存异常信息
                resultBo.setIntegrateFlag(false);
            }else{
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg(storeArray.toJSONString()); //返回信息用于放查询结果json
            }

        } catch (Exception e) {
            //不抛异常，只存异常
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }*/

    //================================部件 结束=====================================================

    //================================BOM 开始=====================================================

    /**
     * BOM 创建更新操作
     * @param bomHeadInfoMap  key包含（bomNumber:BOM编码，updateFlag：更改标识， ecnNumber：变更编号，unit:单位，bomType:bom类型，plant：工厂）
     * @param bomItems
     * @return
     * @throws Exception
     */
    public CtSapResultBo createOrUpdateSapBom(Map<String,String> bomHeadInfoMap, List<CtSapBomItemBo> bomItems) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        String bomNumber = bomHeadInfoMap.get("bomNumber");
        String plant =  bomHeadInfoMap.get("plant");//工厂
        String bomType = bomHeadInfoMap.get("bomType");//bom类型
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String bomAccessMethod = CtSapConfig.BOM_CREATE_UPDATE;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(bomAccessMethod);

            String updateFlag = bomHeadInfoMap.get("updateFlag");
            if (!CtFormatUtil.hasContent(updateFlag)) {
                throw new WTException("BOM 更新标识缺失！请联系管理员检查！");
            }
            // BOM 头信息
            JCoParameterList input = function.getImportParameterList();
            DefaultStructure bomHeadInfo = (DefaultStructure) input.getValue("IV_HEAD");
            bomHeadInfo.setValue("OPTYP",updateFlag); //更新标识

            bomHeadInfo.setValue("MATNR",bomNumber); //物料编号
            bomHeadInfo.setValue("WERKS",plant); //工厂
            bomHeadInfo.setValue("STLAN",bomType); //BOM 用途
            bomHeadInfo.setValue("STLAL","01"); //备选物料清单
            bomHeadInfo.setValue("STLST","01"); //BOM 状态 01为生效
            bomHeadInfo.setValue("BMENG","1000"); //基本数量,默认为1000
            bomHeadInfo.setValue("BMEIN",bomHeadInfoMap.get("unit")); //基本数量的计量单位
            //只在创建BOM时给有效起始日期
            if("I".equalsIgnoreCase(updateFlag)){
                String currentDate = CtDateUtil.getCurrentDate("yyyyMMdd", "GMT+8"); //日期格式20210914
                bomHeadInfo.setValue("DATUV",currentDate); //有效起始日期
                logger.info(">>>有效起始日期:"+currentDate);
            }
            bomHeadInfo.setValue("AENNR",bomHeadInfoMap.get("ecnNumber")); //更改编号

            // 获取组件 IT_ITEM
            JCoTable itemTable = function.getTableParameterList().getTable("IT_ITEM");

            // 循环添加组件值
            for (CtSapBomItemBo bo : bomItems) {
                itemTable.appendRow();
                Field[] fields = bo.getClass().getDeclaredFields();
                for (Field field : fields) {
                    // 因SAP属性值都是大写，需转换
                    String name = field.getName().toUpperCase();
                    if(name.equalsIgnoreCase("serialVersionUID")){
                        continue;//跳过序列化字段
                    }
                    field.setAccessible(true); // 私有属性必须设置访问权限
                    Object resultValue = field.get(bo);
                    if (CtFormatUtil.hasContent(resultValue)) {
                        itemTable.setValue(name.toUpperCase(), resultValue.toString());
                    } else {
                        itemTable.setValue(name.toUpperCase(), "");
                    }
                }
            }

            // 执行
            function.execute(destination);

            // 获取返回信息
            DefaultStructure returnTable  = (DefaultStructure)function.getExportParameterList().getValue("OV_RETURN");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println("SAP返回BOM操作信息标记=" + returnType + "，信息=" + returnMsg);

            resultBo.setResponseCode(returnType);
            if (returnType.equalsIgnoreCase("S")) {
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg("BOM接口成功!");
            } else {
                resultBo.setIntegrateFlag(false);
                resultBo.setErrorMsg(returnMsg);
                throw new WTException(">>>SAP_Failed!BOM接口失败!错误码：" + returnType + ",SAP返回信息：" + returnMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }


    /**
     * BOM查询接口
     * @param bomNumber  编号
     * @param bomUsage    bom用途
     * @param multiLevel 是否查多阶
     * @return
     * @throws Exception
     */
    public CtSapResultBo queryBOM(String bomNumber,String bomUsage,boolean multiLevel) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String bomQuery = CtSapConfig.BOM_QUERY;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(bomQuery);


            //查询参数：日期等
            JCoParameterList input = function.getImportParameterList();

            input.setValue("P_MATNR",bomNumber); //物料编码
            input.setValue("P_STLAN", bomUsage);//BOM用途
            if(multiLevel){
                input.setValue("P_RB02", "X");
            }else{
                input.setValue("P_RB02", "");
            }
            input.setValue("P_STLST", "01");//BOM状态
            input.setValue("P_WERKS", "1001R");//工厂


            // 执行
            function.execute(destination);

            JCoTable  storeTable = function.getTableParameterList().getTable("OT_BOM");//BOM查询结果
            JSONArray storeArray = new JSONArray();
            for(int i = 0; i < storeTable.getNumRows(); i++){
                storeTable.setRow(i);
                JSONObject resultJson = new JSONObject();
                resultJson.put("level",storeTable.getValue("STUFE"));//层级
                String partNumber = storeTable.getValue("MATNR").toString();//物料编号
                String number = storeTable.getValue("MATNR").toString();//物料编号
                number = number.replaceAll("^(0+)", "");//去掉前面的0
                resultJson.put("partNumber",partNumber);
                resultJson.put("partName",storeTable.getValue("MAKTX"));//物料描述
                resultJson.put("factory",storeTable.getValue("WERKS"));//工厂
                resultJson.put("bomUsage",storeTable.getValue("STLAN"));//BOM用途
                resultJson.put("unit",storeTable.getValue("MEINS"));//单位
                resultJson.put("amount",storeTable.getValue("MENGE"));//数量
                resultJson.put("price",storeTable.getValue("PRICE"));//单价  >>> BOM材料实际成本
                resultJson.put("zPrice",storeTable.getValue("ZPRICE"));//金额 >>> BOM材料标准成本
                resultJson.put("cPrice",storeTable.getValue("CPRICE"));//最新采购单位成本 >>>BOM材料采购价格
                resultJson.put("mPrice",storeTable.getValue("MUFEE"));//制造成本 >>> BOM制造成本
                resultJson.put("storage",storeTable.getValue("BMENG"));//确认的数量>>>可用库存
                resultJson.put("childNumber",storeTable.getValue("IDNRK"));//子件编码
                storeArray.add(resultJson);
            }

            System.out.println(bomNumber+">>>>查询BOM信息 = " + storeArray.toJSONString());

            // 获取返回信息
            DefaultStructure returnTable = (DefaultStructure)function.getExportParameterList().getValue("OV_RETURN");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println(">>>SAP返回BOM查询结果=" + returnType + "，信息=" + returnMsg);

            if (!"S".equalsIgnoreCase(returnType)) {
                resultBo.setErrorMsg(returnMsg); //存异常信息
                resultBo.setIntegrateFlag(false);
            }else{
                resultBo.setResponseCode(returnType);
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg(storeArray.toJSONString()); //返回信息用于放查询结果json
            }

        } catch (Exception e) {
            //不抛异常，只存异常
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }

    //================================BOM 结束=====================================================

    //================================ECN 开始=====================================================

    /**
     * 创建ECN
     * @param ecnNumber
     * @param ecnParamMap  其他参数值放这里, key包含（ecnDesc：更改描述， ecnReason：更改原因）
     * @return
     * @throws Exception
     */
    public CtSapResultBo createECN(String ecnNumber, Map<String,String> ecnParamMap) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        logger.info(">>>Create ECN=" + ecnNumber);
        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String ecnMethod = CtSapConfig.ECN_CREATE;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(ecnMethod);

            // BOM 头信息
            JCoParameterList input = function.getImportParameterList();
            DefaultStructure ecnInfo = (DefaultStructure) input.getValue("IS_AENNR");
            ecnInfo.setValue("CHANGE_NO",ecnNumber); //变更编号
            ecnInfo.setValue("STATUS","01"); //状态  01 为生效
            String effectDate = ecnParamMap.get("effectDate");//生效日期
            if(!CtFormatUtil.hasContent(effectDate)){
                String currentDate = CtDateUtil.getCurrentDate("yyyyMMdd", "GMT+8"); //日期格式20210914
                effectDate = currentDate;
            }

            ecnInfo.setValue("VALID_FROM",effectDate); //开始自日期
            ecnInfo.setValue("DESCRIPT",ecnParamMap.get("ecnDesc")); //更改号描述
            ecnInfo.setValue("REASON_CHG",ecnParamMap.get("ecnReason")); //更改原因

            // 执行
            function.execute(destination);

            // 获取返回信息
            DefaultStructure returnTable  = (DefaultStructure)function.getExportParameterList().getValue("OV_RETURN");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println("SAP返回创建ECN标记=" + returnType + "，信息=" + returnMsg);

            resultBo.setResponseCode(returnType);
            if (returnType.equalsIgnoreCase("S")) {
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg("BOM接口成功!");
            } else {
                resultBo.setIntegrateFlag(false);
                resultBo.setResponseMsg(returnMsg);
                throw new WTException(">>>SAP_Failed!BOM接口失败!错误码：" + returnType + ",SAP返回信息：" + returnMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }


    //================================ECN 结束=====================================================

    //================================预留单 开始=====================================================

    /**
     * 创建领料预留单
     * @param orderBo
     * @param materialItems 物料明细项 key包含（partNumber：物料号，amount：数量）
     * @return
     * @throws Exception
     */
    public CtSapResultBo createMaterialKeepOrder(CtSapMaterialKeepOrderBo orderBo, List<Map<String,String>> materialItems) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();


        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        logger.info(">>>物料预留单 Head=" + JSON.toJSON(orderBo));
        logger.info(">>>物料预留单 Items=" + JSON.toJSON(materialItems));
        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String materialOrderMethod = CtSapConfig.MATERIAL_ORDER;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(materialOrderMethod);

            // BOM 头信息
            JCoParameterList input = function.getImportParameterList();
            input.setValue("LV_FLAG","I"); //标识，固定为新增 I

            //头参数 LV_HEADER
            DefaultStructure bomHeadInfo = (DefaultStructure) input.getValue("LV_HEADER");
            bomHeadInfo.setValue("BWART",orderBo.getBWART()); //移动类型
            bomHeadInfo.setValue("KOSTL",orderBo.getKOSTL()); //成本中心
            bomHeadInfo.setValue("AUFNR",orderBo.getAUFNR()); //订单号
            bomHeadInfo.setValue("WEMPF",orderBo.getWEMPF()); //需求人的全名
            bomHeadInfo.setValue("ZZCRMID",orderBo.getZZCRMID()); //CRM主键

            // 获取组件 LT_ITEM
            JCoTable itemTable = function.getTableParameterList().getTable("LT_ITEM");

            // 循环添加组件值
            for (Map<String,String> itemMap : materialItems) {
                itemTable.appendRow();
                itemTable.setValue("MATNR",itemMap.get("partNumber")); //物料编号
                itemTable.setValue("WERKS",orderBo.getWERKS()); //工厂
                itemTable.setValue("LGORT",itemMap.get("lgort")); //库存地点
                itemTable.setValue("ERFMG",itemMap.get("amount")); //数量
                itemTable.setValue("ZTEL",itemMap.get("ZTEL"));
                itemTable.setValue("WEMPF",itemMap.get("WEMPF"));//需求人的工号
            }

            // 执行
            function.execute(destination);

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println("SAP返回创建预留单标记=" + returnType + "，信息=" + returnMsg);

            resultBo.setResponseCode(returnType);
            if (returnType.equalsIgnoreCase("S")) {
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg(returnMsg);
            } else {
                resultBo.setIntegrateFlag(false);
                resultBo.setErrorMsg(returnMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }

    //================================预留单 结束=====================================================


    //================================供应商 开始=====================================================

    /**
     * 查询供应商信息
     * @return
     * @throws Exception
     */
    public CtSapResultBo querySupplierInfo() throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String querySupplier = CtSapConfig.SUPPLIER_QUERY;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(querySupplier);

            // 执行
            function.execute(destination);

            JCoTable  storeTable = function.getTableParameterList().getTable("I_OUT");//查询结果
            JSONArray storeArray = new JSONArray();
            for(int i = 0; i < storeTable.getNumRows(); i++){
                storeTable.setRow(i);
                JSONObject resultJson = new JSONObject();
                String supplierCode = storeTable.getValue("LIFNR").toString();//供应商编号
                if(CtFormatUtil.hasContent(supplierCode)&&supplierCode.startsWith("0000")){
                    supplierCode = supplierCode.substring(4);//去除编码前4位的0
                }

                resultJson.put("supplierCode",supplierCode);//供应商编号
                resultJson.put("supplierName",storeTable.getValue("NAME")); //供应商名称
                resultJson.put("supplierEmail",storeTable.getValue("EMAIL")); //供应商邮件
                storeArray.add(resultJson);
            }

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println(">>>SAP返回查询供应商结果=" + returnType + "，信息=" + returnMsg+",数量="+storeArray.size());

            resultBo.setResponseCode(returnType);
            if (!"S".equalsIgnoreCase(returnType)) {
                resultBo.setErrorMsg("供应商查询失败！SAP返回信息："+returnMsg); //存异常信息
                resultBo.setIntegrateFlag(false);
            }else{
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg(storeArray.toJSONString()); //返回信息用于放查询结果json
            }

        } catch (Exception e) {
            //不抛异常，只存异常
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }

    //================================供应商 结束=====================================================

    //================================创建项目编号 开始=====================================================

    /**
     * 创建项目编号
     * @param pro
     * @return
     * @throws Exception
     */
    public CtSapResultBo genOrUpdateProjectNumber(Project2 pro,String ProNum,String flag,String endTime) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();
        CtSapQuery qr = new CtSapQuery();

        String name = pro.getName();
        IBAUtil ibaUtil = new IBAUtil(pro);
        String applicant=pro.getCreator().getName();
        String responPeople=ibaUtil.getIBAValue("Ct_ProjectLeaderWatch");
        if(CtConstant.isPrdEnv()){
            //用户登录名转工号
            if(CtFormatUtil.hasContent(responPeople)&&!responPeople.equals("Administrator")){
                responPeople= qr.getNoByLoginName(responPeople);
            }
            if(CtFormatUtil.hasContent(applicant)&&!applicant.equals("Administrator")){
                applicant= qr.getNoByLoginName(applicant);
            }
        }
        String Ct_MissionStatementID=ibaUtil.getIBAValue("Ct_MissionStatementID");
        String ct_FinishDate=ibaUtil.getIBAValue("ct_FinishDate");
        if(CtFormatUtil.hasContent(endTime)){
            ct_FinishDate=endTime;
        }
        Timestamp createTimestamp = pro.getCreateTimestamp();
        SimpleDateFormat format =  new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
        Long time=new Long(createTimestamp.getTime());
        String startDate="";
        String endDate="";
        if(CtFormatUtil.hasContent(Ct_MissionStatementID)){
            long parse = Date.parse(Ct_MissionStatementID);
             startDate = format.format(parse);
        }
        if(CtFormatUtil.hasContent(ct_FinishDate)){
            long parse = Date.parse(ct_FinishDate);
            endDate = format.format(parse);
        }
        String applicantDate = format.format(time);
        logger.info(">>>集成信息："+"LV_AUFNR(项目编号)："+ProNum+", LV_KTEXT(项目名称):"+name
                +",LV_PERSON_RESP(负责人):"+responPeople+", LV_APPLICANT(申请人):"+applicant
                +",LV_APPLICANT_DATE(申请日期):"+applicantDate+", LV_STARTDATE(工作开始):"+startDate
                +", LV_CFLAG(标识):"+flag +", LV_ENDDATE(标识):"+endDate);
//        Date date=format.parse(d);
        //LV_PERSON_RESP  负责人
        //LV_APPLICANT 申请人
        //LV_APPLICANT_DATE 申请日期
        //LV_STARTDATE 工作开始
        //LV_ENDDATE 工作结束
        //LV_CFLAG 创建还是修改 创建传I  更新传U
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String genProjectNumber = CtSapConfig.PROJECT_NUMBER;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(genProjectNumber);

            //物料号
            JCoParameterList input = function.getImportParameterList();
            input.setValue("LV_AUFNR",ProNum);
            input.setValue("LV_KTEXT",name);
            input.setValue("LV_PERSON_RESP",responPeople);
            input.setValue("LV_APPLICANT",applicant);
            input.setValue("LV_APPLICANT_DATE",applicantDate);
            input.setValue("LV_STARTDATE",startDate);
            input.setValue("LV_ENDDATE",endDate);
            input.setValue("LV_CFLAG",flag);

            // 执行
            function.execute(destination);


            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            logger.info(">>>项目编号集成信息=" + returnType + "，信息=" + returnMsg);

            resultBo.setResponseCode(returnType);
            if (!"S".equalsIgnoreCase(returnType)) {
                resultBo.setErrorMsg("项目编号集成失败！SAP返回信息："+returnMsg); //存异常信息
                resultBo.setIntegrateFlag(false);
            }else{
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg(returnType); //返回信息用于放查询结果json
            }

        } catch (Exception e) {
            //不抛异常，只存异常
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }

    /**
     * 创建项目编号
     * @param map
     * @return
     * @throws Exception
     */
    public CtSapResultBo genProjectNumber(Map<String,String> map, String ProNum, String flag) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();
        //LV_PERSON_RESP  负责人
        //LV_APPLICANT 申请人
        //LV_APPLICANT_DATE 申请日期
        //LV_STARTDATE 工作开始
        //LV_ENDDATE 工作结束
        //LV_EXIST 创建还是修改 创建传I  更新传U
        String name = map.get("LV_KTEXT");
        String responPeople=map.get("LV_PERSON_RESP");
        String applicant=map.get("LV_PERSON_RESP");
        String startDate=map.get("LV_STARTDATE");
        String endDate=map.get("LV_ENDDATE");
        String applicantDate=map.get("LV_APPLICANT_DATE");
        logger.info(">>>集成信息："+"LV_AUFNR(项目编号):"+ProNum+", LV_KTEXT(项目名称):"+name
                +",LV_PERSON_RESP(负责人):"+responPeople+", LV_APPLICANT(申请人):"+applicant
                +",LV_APPLICANT_DATE(申请日期):"+applicantDate+", LV_STARTDATE(申请人):"+startDate
                +", LV_EXIST(标识):"+flag+", LV_ENDDATE(结束日期):"+endDate);
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String genProjectNumber = CtSapConfig.PROJECT_NUMBER;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(genProjectNumber);

            //物料号
            JCoParameterList input = function.getImportParameterList();
            input.setValue("LV_AUFNR",ProNum);
            input.setValue("LV_KTEXT",name);
            input.setValue("LV_PERSON_RESP",responPeople);
            input.setValue("LV_APPLICANT",applicant);
            input.setValue("LV_STARTDATE",startDate);
            input.setValue("LV_APPLICANT_DATE",applicantDate);
            input.setValue("LV_ENDDATE",endDate);
            input.setValue("LV_CFLAG",flag);

            // 执行
            function.execute(destination);


            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            System.out.println(">>>项目编号集成信息=" + returnType + "，信息=" + returnMsg);

            resultBo.setResponseCode(returnType);
            if (!"S".equalsIgnoreCase(returnType)) {
                resultBo.setErrorMsg("项目编号集成失败！SAP返回信息："+returnMsg); //存异常信息
                resultBo.setIntegrateFlag(false);
            }else{
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg(returnType); //返回信息用于放查询结果json
            }

        } catch (Exception e) {
            //不抛异常，只存异常
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }

    //================================创建项目编号 结束=====================================================


    //===============================根据物料编号查询供应商 开始========================================
    /**
     * 料编号查询供应商
     * @return
     * @throws Exception
     */
    public CtSapResultBo querySupplierInfoByPartNumber(String partNumber) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String querySupplier = CtSapConfig.AGENT_QUERY;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(querySupplier);
            JCoParameterList input = function.getImportParameterList();
            input.setValue("LV_MATNR",partNumber);

            // 执行
            function.execute(destination);

            JCoTable  storeTable = function.getTableParameterList().getTable("I_OUT");//查询结果
            JSONArray storeArray = new JSONArray();

            for(int i = 0; i < storeTable.getNumRows(); i++) {
                storeTable.setRow(i);
                JSONObject resultJson = new JSONObject();
                resultJson.put("supplierAccountNumber", storeTable.getValue("LIFNR")); //供应商账号
                resultJson.put("supplierName", storeTable.getValue("NAME")); //供应商名称
                resultJson.put("supplierEmail", storeTable.getValue("EMAIL")); //供应商邮件
                resultJson.put("partNumber", storeTable.getValue("MATNR")); //物料编码
                storeArray.add(resultJson);
            }

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("LT_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");

            logger.info(">>>项目编号集成信息=" + returnType + "，信息=" + returnMsg+"查询结果"+storeArray.toJSONString());

            //System.out.println(">>>SAP!!!!!!!!!!!!!返回查询供应商结果=" + returnType + "，信息=" + returnMsg+",数量="+storeArray.size()
            //+"查询结果"+storeArray.toJSONString());

            resultBo.setResponseCode(returnType);
            //S 成功,E 错误,W 警告,I 信息,A 中断
            if (!"S".equalsIgnoreCase(returnType)) {
                resultBo.setErrorMsg("供应商查询失败！SAP返回信息："+returnMsg); //存异常信息
                resultBo.setIntegrateFlag(false);
            }else{
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg(storeArray.toJSONString()); //返回信息用于放查询结果json
            }

        } catch (Exception e) {
            //不抛异常，只存异常
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
        }

        return resultBo;
    }
    //===============================根据物料编号查询供应商  结束========================================

    /**
     * 通过工单编号查询工单数量
     * @param moNumber 工单号
     * @return
     * @throws Exception
     */
    public Map<String, String> queryQuantityByMo(String moNumber) throws Exception {
        Map<String, String> map = new HashMap<>();
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        String quantity = "";
        try {
            destination.ping();
            // 获取函数名称
            String queryQuantity = CtSapConfig.ZMM_PLM_007;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(queryQuantity);

            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            input.setValue("IV_AUFNR", moNumber); //工单编号

            // 执行
            function.execute(destination);

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("ET_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            if (!"S".equalsIgnoreCase(returnType)) {
                throw new Exception(moNumber + "MO数量查询失败！SAP返回信息："+returnMsg); //存异常信息
            }else{
                JCoStructure jCoStructure = function.getExportParameterList().getStructure("EV_AUFNR");
                BigDecimal bigDecimal = (BigDecimal) jCoStructure.getValue("MENGE");
                String status = (String) jCoStructure.getValue("STATUS");
                quantity = bigDecimal.toString();
                map.put("status", status);
                map.put("quantity", quantity);
                System.out.println(moNumber+">>>SAP返回集成MO工单数量=" + quantity);
            }
        } catch (Exception e) {
            logger.info("通过工单编号查询工单数量异常：", e);
            throw e;
        }
        return map;
    }

    /**
     * 通过PO查询物料信息
     * @param po
     * @return
     * @throws Exception
     */
    public JSONArray queryPartsByPo(String po) throws Exception {
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        JSONArray storeArray = new JSONArray();
        String returnType = "E";
        String quantity = "";
        try {
            destination.ping();
            // 获取函数名称
            String queryQuantity = CtSapConfig.ZMM_PLM_007;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(queryQuantity);

            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            input.setValue("IV_EBELN", po); //po单号

            // 执行
            function.execute(destination);

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("ET_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            if (!"S".equalsIgnoreCase(returnType)) {
                throw new Exception(po + "PO单数据查询失败！SAP返回信息："+returnMsg); //存异常信息
            }else{
                JCoTable  storeTable = function.getTableParameterList().getTable("ET_EBELN");//物料查询结果
                for(int i = 0; i < storeTable.getNumRows(); i++){
                    storeTable.setRow(i);
                    JSONObject resultJson = new JSONObject();
                    String number = storeTable.getValue("MATNR").toString();//物料编号
                    number = number.replaceAll("^(0+)", "");//去掉前面的0
                    resultJson.put("partNumber",number);//部件编码

                    resultJson.put("partVersion",storeTable.getValue("REVLV")); //内部版本
                    resultJson.put("supplierNumber",storeTable.getValue("LIFNR")); //供应商编码
                    resultJson.put("supplierName",storeTable.getValue("NAME1")); //供应商名称
                    storeArray.add(resultJson);
                }
                System.out.println(po + ">>>SAP返回集成PO物料信息=" + storeArray.toJSONString());
            }
        } catch (Exception e) {
            logger.info("通过PO查询物料信息异常：", e);
            throw e;
        }
        return storeArray;
    }

    /**
     * 通过PR查询物料信息
     * @param pr
     * @return
     * @throws Exception
     */
    public JSONArray queryPartsByPr(String pr) throws Exception {
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        JSONArray storeArray = new JSONArray();
        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String queryQuantity = CtSapConfig.ZMM_PLM_007;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(queryQuantity);

            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            input.setValue("IV_BANFN", pr); //pr

            // 执行
            function.execute(destination);

            // 获取返回信息
            JCoTable returnTable = function.getTableParameterList().getTable("ET_RET2");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            if (!"S".equalsIgnoreCase(returnType)) {
                throw new Exception(pr + "PR单数据查询失败！SAP返回信息："+returnMsg); //存异常信息
            }else{
                JCoTable  storeTable = function.getTableParameterList().getTable("ET_BANFN");//物料查询结果
                for(int i = 0; i < storeTable.getNumRows(); i++){
                    storeTable.setRow(i);
                    JSONObject resultJson = new JSONObject();
                    String number = storeTable.getValue("MATNR").toString();//物料编号
                    number = number.replaceAll("^(0+)", "");//去掉前面的0
                    resultJson.put("partNumber",number);//部件编码

                    resultJson.put("partVersion",storeTable.getValue("REVLV")); //内部版本
                    resultJson.put("supplierNumber",storeTable.getValue("LIFNR")); //供应商编码
                    resultJson.put("supplierName",storeTable.getValue("NAME1")); //供应商名称
                    storeArray.add(resultJson);
                }
                System.out.println(pr + ">>>SAP返回集成PR物料信息=" + storeArray.toJSONString());
            }
        } catch (Exception e) {
            logger.info("通过PR查询物料信息异常：", e);
            throw e;
        }
        return storeArray;
    }

    //===============================发送替代关系到SAP  开始========================================

    /**
     * 判断集群物料在SAP是否存在
     * @param
     * @param
     * @return
     * @throws Exception
     */
    public boolean doesItExistSGM(String substitutionGroupMaterial) throws Exception {
        boolean partDoesItExist = false;
        // 获取连接对象
        JCoDestination destination = getJCoDestination();
        try {

            // 获取函数名称
            String bomAccessMethod = CtSapConfig.ZPP_PLM_006;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(bomAccessMethod);
            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            input.setValue("IV_MATNR", substitutionGroupMaterial); //物料编号
            input.setValue("IV_STLAN", "Z"); //物料编号
            // 执行
            function.execute(destination);
            // 获取返回信息

            //// 获取返回信息
            //DefaultStructure returnTable  = (DefaultStructure)function.getExportParameterList().getValue("OV_RETURN");
            //returnType = (String) returnTable.getValue("TYPE");

            JCoParameterList jCoStructure = function.getExportParameterList();
            String partDoesItExistValue = (String)jCoStructure.getValue("EV_CODE");

            System.out.println("jCoStructure=====>"+jCoStructure.toString());
            System.out.println("partDoesItExistValue======>"+partDoesItExistValue);

            if("S".equals(partDoesItExistValue)){
                partDoesItExist = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return partDoesItExist;
    }


    /**
     * 发送替代关系到SAP
     * @param
     * @param
     * @return
     * @throws Exception
     */
    public CtSapResultBo substitutionRelationshipToSAP(List<String> colonys, List<List<String>> foundations) throws Exception {
        CtSapResultBo resultBo = new CtSapResultBo();

        // 获取当前时间
        LocalDateTime now = LocalDateTime.now();
        // 定义日期时间的格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        // 格式化当前时间为字符串
        String formattedDateTime = now.format(formatter);
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {

            // 获取函数名称
            String bomAccessMethod = CtSapConfig.BOM_CREATE_UPDATE;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(bomAccessMethod);

            // BOM 头信息
            JCoParameterList input = function.getImportParameterList();
            DefaultStructure bomHeadInfo = (DefaultStructure) input.getValue("IV_HEAD");


            bomHeadInfo.setValue("OPTYP",colonys.get(0)); //新建I，更新U，删除D，必填
            bomHeadInfo.setValue("MATNR","000000000"+colonys.get(1)); //物料号，带前导零，必填
            bomHeadInfo.setValue("WERKS","1001"); //工厂，必填
            bomHeadInfo.setValue("STLAN","Z"); //BOM用途默认Z，必填
            bomHeadInfo.setValue("STLAL","01"); //默认，必填
            bomHeadInfo.setValue("STLST","0"); //默认，必填
            bomHeadInfo.setValue("BMENG","1.000"); //默认1，基础数量必填
            bomHeadInfo.setValue("BMEIN",colonys.get(2)); //单位，必填
            bomHeadInfo.setValue("DATUV",formattedDateTime); //有效期开始，必填
            bomHeadInfo.setValue("ZISTD","X"); //是否存在替代关系

            // 获取组件 IT_ITEM
            JCoTable itemTable = function.getTableParameterList().getTable("IT_ITEM");
            for(int i = 0; i<foundations.size(); i++){
                List<String> list = foundations.get(i);
                itemTable.appendRow();
                itemTable.setValue("ITM_OPTYP", list.get(0));//新建I，更新U，删除D，必填
                itemTable.setValue("POSNR", "0010");//项目号，必填
                itemTable.setValue("IDNRK", list.get(1));//替代料编码，带前导零，必填
                itemTable.setValue("MENGE", "1.000");//替代料数量，必填
                itemTable.setValue("MEINS", list.get(2));//替代料单位，必填
                //itemTable.setValue("ZISTD",""); //是否存在替代关系
                if(CtFormatUtil.hasContent(list.get(3))){
                    if("是".equals(list.get(3))) {
                        itemTable.setValue("ZTDFLAG", "X");//是否主料
                    }else {
                        itemTable.setValue("ZTDFLAG", "");
                    }
                }else {
                    itemTable.setValue("ZTDFLAG", "");//是否主料
                }
            }


            // 执行
            function.execute(destination);

            // 获取返回信息
            DefaultStructure returnTable  = (DefaultStructure)function.getExportParameterList().getValue("OV_RETURN");
            returnType = (String) returnTable.getValue("TYPE");
            String returnMsg = (String) returnTable.getValue("MESSAGE");
            logger.info("SAP返回BOM操作信息标记=" + returnType + "，信息=" + returnMsg);
            resultBo.setResponseCode(returnType);
            //S 成功,E 错误,W 警告,I 信息,A 中断
            if (returnType.equalsIgnoreCase("S")) {
                resultBo.setIntegrateFlag(true);
                resultBo.setResponseMsg("BOM接口成功!");
            } else {
                resultBo.setIntegrateFlag(false);
                resultBo.setErrorMsg(returnMsg);
                if(!(returnMsg.contains("BOM不存在")&&"D".equals(colonys.get(0)))){
                    throw new WTException(">>>SAP_Failed!BOM接口失败!错误码：" + returnType + ",SAP返回信息：" + returnMsg);
                }
            }
        } catch (Exception e) {
            logger.info("发送替代关系到SAP异常：", e);
            e.printStackTrace();
            resultBo.setResponseCode(returnType);
            resultBo.setErrorMsg(e.getMessage());
            throw e;
        }

        return resultBo;
    }

    //===============================发送替代关系到SAP  结束========================================

    /**
     * 最小包装量 、采购计量单位 、采购周期（天）、研发环保认证要求、环保认证确认、来料方式等字段推给sap
     * @param list
     * @throws Exception
     */
    public void sendPartAttribute(List<Map<String, String>> list) throws Exception {
        String price = "";
        // 获取连接对象
        JCoDestination destination = getJCoDestination();
        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String queryQuantity = CtSapConfig.ZMM_PLM_009;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(queryQuantity);

            // 获取输入参数列表
            JCoTable itemTable = function.getTableParameterList().getTable("IT_DATA");
            for(Map<String, String> map : list){
                itemTable.appendRow();
                itemTable.setValue("MATNR", map.get("MATNR"));//物料编号
                itemTable.setValue("LIFNR", map.get("LIFNR"));//供应商编号
                itemTable.setValue("MINPQ", map.get("MINPQ"));//最小包装量
                itemTable.setValue("PMUNIT", map.get("PMUNIT"));//采购计量单位
                itemTable.setValue("PCYCLE", map.get("PCYCLE"));//采购周期（天）
                itemTable.setValue("CERTREQ", map.get("CERTREQ"));//研发环保认证要求
                itemTable.setValue("CERTCONF", map.get("CERTCONF"));//环保认证确认
                itemTable.setValue("INMETHOD", map.get("INMETHOD"));//来料方式

                itemTable.setValue("TEMPB", map.get("TEMPB"));//温度条件01/02
                itemTable.setValue("PROFL", map.get("PROFL"));//危险货物标识参数文件001/G00/G0P/GP0/GPP
                itemTable.setValue("MAXLZ", map.get("MAXLZ"));//最大存储期间--传数字
                itemTable.setValue("LZEIH", "MON");//最大存储期间单位 D/MON/H/WK/S/MIN/年
            }
            // 执行
            function.execute(destination);



            // 获取返回信息
            JCoStructure returnStructure = function.getExportParameterList().getStructure("EV_RETURN");
            returnType = (String) returnStructure.getValue("TYPE");
            String returnMsg = (String) returnStructure.getValue("MESSAGE");
            if (!"S".equalsIgnoreCase(returnType)) {
                throw new Exception("物料属性推给sap失败！SAP返回信息："+returnMsg); //存异常信息
            }else{
                System.out.println(">>>SAP返回集成物料属性推送sap信息成功！");
            }
        } catch (Exception e) {
            logger.info("物料属性推给sap异常：", e);
            throw e;
        }
    }

    /**
     * 通过物料编号、供应商名称查询价格
     * @param partNumber
     * @param supplierNumber
     * @return
     * @throws Exception
     */
    public String queryPrice(String partNumber, String supplierNumber) throws Exception {
        String price = "";
        // 获取连接对象
        JCoDestination destination = getJCoDestination();
        String returnType = "E";
        try {
            destination.ping();
            // 获取函数名称
            String queryQuantity = CtSapConfig.ZMM_PLM_008;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(queryQuantity);

            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            DefaultStructure headInfo = (DefaultStructure) input.getValue("IV_DATA");
            headInfo.setValue("MATNR", partNumber);
            headInfo.setValue("LIFNR", supplierNumber);

            // 执行
            function.execute(destination);

            // 获取返回信息
            JCoStructure returnStructure = function.getExportParameterList().getStructure("EV_RETURN");
            returnType = (String) returnStructure.getValue("TYPE");
            String returnMsg = (String) returnStructure.getValue("MESSAGE");
            if (!"S".equalsIgnoreCase(returnType)) {
                //throw new Exception("通过物料编号、供应商名称查询价格失败！SAP返回信息："+returnMsg); //存异常信息
                price = "NA";
            }else{
                JCoStructure priceStructure = function.getExportParameterList().getStructure("EV_DATA");
                BigDecimal bigDecimal = (BigDecimal) priceStructure.getValue("NETPR");
                price = bigDecimal.toString();
                System.out.println(">>>SAP返回集成价格信息=" + price);
            }
        } catch (Exception e) {
            logger.info("通过物料编号、供应商名称查询价格异常：", e);
            throw e;
        }
        return price;
    }

    //===============================查询物料是否在SAP存在  开始========================================
    /**
     * 查询物料是否在SAP存在
     * @param
     * @param
     * @return
     * @throws Exception
     */
    public Boolean queryPartDoesItExist(String partNumber) throws Exception {
        boolean partDoesItExist = false;
        // 获取连接对象
        JCoDestination destination = getJCoDestination();

        String returnType = "E";
        try {

            // 获取函数名称
            String bomAccessMethod = CtSapConfig.ZMM_PLM_010;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(bomAccessMethod);
            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            input.setValue("IV_MATNR", partNumber); //物料编号
            // 执行
            function.execute(destination);


            // 获取返回信息
            JCoParameterList jCoStructure = function.getExportParameterList();
            String partDoesItExistValue = (String)jCoStructure.getValue("SUBRC");

            if("0".equals(partDoesItExistValue)){
                partDoesItExist = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return partDoesItExist;
    }

    //===============================查询物料是否在SAP存在  结束========================================

    /**
     * 发送删除预留单号
     * @param
     * @param
     * @return
     * @throws Exception
     */
	public CtSapResultBo delMaterialDocumentNumber(String materialDocNumber) throws Exception {
		CtSapResultBo resultBo = new CtSapResultBo();
		// 获取连接对象
		JCoDestination destination = getJCoDestination();

		String returnType = "E";
		try {

			// 获取函数名称
			String bomAccessMethod = CtSapConfig.ZSD_CRM_011;
			// 获取到SAP的函数
			JCoFunction function = destination.getRepository().getFunction(bomAccessMethod);
			// 获取输入参数列表
			JCoParameterList input = function.getImportParameterList();
			input.setValue("IV_RSNUM", materialDocNumber);
			// DefaultStructure bomHeadInfo = (DefaultStructure)
			// input.getValue("LV_HEADER");
			// bomHeadInfo.setValue("RSNUM", materialDocNumber); // 预留单号
			// 执行
			function.execute(destination);

			// 获取返回信息
			JCoStructure returnStructure = function.getExportParameterList().getStructure("EV_RETURN");
			returnType = (String) returnStructure.getValue("TYPE");
			String returnMsg = (String) returnStructure.getValue("MESSAGE");
			// 获取返回信息
			System.out.println(materialDocNumber + ">>>SAP返回删除预留单标记=" + returnType + "，信息=" + returnMsg);

			resultBo.setResponseCode(returnType);
			if (returnType.equalsIgnoreCase("S")) {
				resultBo.setIntegrateFlag(true);
				resultBo.setResponseMsg(returnMsg);
			} else {
				resultBo.setIntegrateFlag(false);
				resultBo.setResponseMsg("删除预留单号失败!");
				resultBo.setErrorMsg(returnMsg);
			}
		} catch (Exception e) {
			logger.info("发送删除预留单号异常：", e);
			throw e;
		}

		return resultBo;
	}

    /**
     * 传物料的物料状态给SAP
     * @param
     * @param
     * @return
     * @throws Exception
     */
    public void sendPartState(String partNumber, String partState) throws Exception {
        // 获取连接对象
        JCoDestination destination = getJCoDestination();
        try {
            // 获取函数名称
            String bomAccessMethod = CtSapConfig.ZMM_PLM_013;
            // 获取到SAP的函数
            JCoFunction function = destination.getRepository().getFunction(bomAccessMethod);
            // 获取输入参数列表
            JCoParameterList input = function.getImportParameterList();
            input.setValue("IV_MATNR", partNumber); //物料编号
            input.setValue("IV_ZMSTA", partState); //物料状态
            // 执行
            function.execute(destination);

            // 获取返回信息
            JCoStructure returnStructure = function.getExportParameterList().getStructure("EV_RETURN");
            String returnType = (String) returnStructure.getValue("TYPE");
            String returnMsg = (String) returnStructure.getValue("MESSAGE");
            if (!"S".equalsIgnoreCase(returnType)) {
                throw new Exception("物料状态推给sap失败！SAP返回信息："+returnMsg); //存异常信息
            }else{
                System.out.println(">>>SAP返回集成物料状态推送sap信息成功！");
            }
        } catch (Exception e) {
            logger.info("物料状态推给sap异常：", e);
            throw e;
        }
    }

}
