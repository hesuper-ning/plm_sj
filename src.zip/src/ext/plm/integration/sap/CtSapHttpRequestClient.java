package ext.plm.integration.sap;

import cn.restcloud.framework.client.okhttp.auth.TrustAllCerts;
import cn.restcloud.framework.core.util.ExceptionUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;
import okhttp3.OkHttpClient.Builder;
import org.apache.log4j.Logger;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class CtSapHttpRequestClient {
    static Logger logger = Logger.getLogger(CtSapHttpRequestClient.class);
    private static Gson gson = new GsonBuilder().create(); //null bean转json null值不输出
    private String host="https://api.sz-sanjiang.com/app"; //服务器地址
    private String loginUrl=host+"/rest/core/auth/login"; //登录地址无需修改
    private final MediaType HttpJSONMediaType = MediaType.parse("application/json; charset=utf-8");
    public String token=""; //登录成功后的token
    private Date tokenCreatTime=null; //token的生成时间，超过一定时后用来重新刷新token
    private int tokenExpiresNum=24; //24小时后重新刷新token
    private String userId="plm"; //在API平台中注册的帐号
    private String password="@!sz-sanjiang!@PLM20240911"; //帐号的密码,,可用md5进行加密一次

    public static void main(String[] args) {
        CtSapHttpRequestClient httpRequest=new CtSapHttpRequestClient();
        String url=httpRequest.host+"undefined";
        try {
            HashMap<String,String> postParamsMap = new HashMap<>();
            postParamsMap.put("IV_BUKRS", "1100");
            postParamsMap.put("IV_AUART", "");
            postParamsMap.put("IV_ORDERTPYE", "");
            url = "http://apitest.sz-sanjiang.com/app/route/con/sap/ZFICO_GETIORDER";
            String body=httpRequest.post(url, postParamsMap);
            System.out.println(body);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public CtSapHttpRequestClient() {
        try{
            logger.debug("-----CtSapHttpRequestClient userId:" + this.userId);
            logger.debug("-----CtSapHttpRequestClient password:" + this.password);
            this.getToken(this.userId,this.password); //登录
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public OkHttpClient getOkHttpClient(boolean isHttps) {
        Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(120000, TimeUnit.MILLISECONDS); //最大超时时间
        builder.readTimeout(120000, TimeUnit.MILLISECONDS);
        if(isHttps){
            //增加ssl支持
            builder.sslSocketFactory(createSSLSocketFactory());
            builder.hostnameVerifier(new HostnameVerifier(){
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
        }
        OkHttpClient client=builder.build();
        return client;
    }

    /**
     * get提交方式
     * @param url
     * @return
     * @throws Exception
     */
    public String get(String url) throws Exception {
        Request request = new Request.Builder().addHeader("identitytoken", this.token).url(url).build();
        Response response = getOkHttpClient(true).newCall(request).execute();
        return response.body().string();
    }

    /**
     * post提交方式
     * @param url
     * @param postParamsMap
     * @return
     * @throws Exception
     */
    public String post(String url, HashMap<String,String> postParamsMap) throws Exception {
        //使用键值对的方式提交
        FormBody.Builder builder = new FormBody.Builder();
        for (String key : postParamsMap.keySet()) {
            builder.add(key, postParamsMap.get(key));//追加表单信息
        }
        RequestBody formBody = builder.build();
        logger.debug("-----CtSapHttpRequestClient token:" + this.token);
        Request request = new Request.Builder().addHeader("identitytoken", this.token).url(url).post(formBody).build();
        Response response = getOkHttpClient(true).newCall(request).execute();
        return response.body().string();
    }

    //传body获取数据
    public String postByBody(String url, String json) throws Exception {
        // 创建MediaType对象，指定JSON类型
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        // 创建 RequestBody 对象
        RequestBody formBody = RequestBody.create(JSON, json);

        Request request = new Request.Builder().addHeader("identitytoken", this.token).url(url).post(formBody).build();
        Response response = getOkHttpClient(true).newCall(request).execute();
        return response.body().string();
    }

    /**
     * 登录获取token
     * @return
     * @throws Exception
     */
    public void getToken(String userId,String password){
        logger.debug("-----CtSapHttpRequestClient getToken:" + this.token);
        if(!this.token.equals("")) {
            //如果已经登录不再登录,要看token是否已经过期,如果已过期需要重新获取
            Date nowDate=new Date();
            Calendar specialDate = Calendar.getInstance();
            specialDate.setTime(nowDate);
            specialDate.add(Calendar.HOUR, -tokenExpiresNum); //当前时间往前推指 定的小时数
            Long between = (specialDate.getTime().getTime() - this.tokenCreatTime.getTime());
            logger.debug("-----CtSapHttpRequestClient tokenCreatTime:" + this.tokenCreatTime.getTime());
            logger.debug("-----CtSapHttpRequestClient between:" + between);
            if(between<0) { //如果往前推的时间小于token创建时间则在有效期内
                return;
            }
        }
        String tokenJson="";
        try {
            //使用键值对提交的方式
            password = RSAUtils.encryptByPublicKey("MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhIcq1BLO0UYnQ2Z/w1oiW65K8ktIRit8BvkDdOwQQ3wG4FmNPa2rHCRkfHe+0/wllYrLeYHn4DLn3rjT/6Cds++9UlpE8BP+3pxmJ2OB472fHpPwO3GxdQUi5T1JIBSEJdPQOv71oTJI2/R2IuKPk3lFEcIUgiQXlQX91+ODtG5XRVO+mmgBxZIf26JYEUAEfJ7OV1Df/f8/daSF9UD+m6AxywJ9AKAEB+41PYMwnVd0/492ODtQGAxplER2HTyAFJd1HBDZOvU+uUh285dSNMayVGLpipO2/pGm1VrW9bdGw1yeRP7Z6ObJoNbrxJm+1zd1Du37wpQbu97A6qT/qQIDAQAB", password);
            Map<String,String> postParamsMap=new HashMap<String,String>();
            postParamsMap.put("userName", userId);
            postParamsMap.put("password", password);
            logger.debug("-----CtSapHttpRequestClient userName:" + userId);
            logger.debug("-----CtSapHttpRequestClient password:" + password);
            logger.debug("-----CtSapHttpRequestClient loginUrl:" + this.loginUrl);
            FormBody.Builder builder = new FormBody.Builder();
            for (String key : postParamsMap.keySet()) {
                builder.add(key, postParamsMap.get(key));//追加表单信息
            }
            RequestBody formBody = builder.build();
            Request request = new Request.Builder().url(this.loginUrl).post(formBody).build();
            Response response = getOkHttpClient(true).newCall(request).execute();
            tokenJson=response.body().string();  //登录成功返回token
            HashMap<String, String> tokenMap = gson.fromJson(tokenJson, new TypeToken<HashMap<String, String>>() {}.getType());
            String state=tokenMap.get("state");
            if(state!=null && state.equals("false")) {
                System.out.println("系统登录失败"+tokenJson);
            }else {
                this.token=tokenMap.get("identitytoken");
                this.tokenCreatTime=new Date();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 创建ssl socket工厂
     * @return
     */
    private static SSLSocketFactory createSSLSocketFactory() {
        SSLSocketFactory ssfFactory = null;
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new TrustAllCerts()}, new SecureRandom());
            ssfFactory = sc.getSocketFactory();
        } catch (Exception e) {
            ExceptionUtil.log(e);
        }
        return ssfFactory;
    }

}
