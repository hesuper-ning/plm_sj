package ext.plm.integration.sap;

import ext.plm.common.CtConstant;
import ext.plm.integration.sap.bo.*;
import ext.plm.supplier.bo.CtSupplierInfoBo;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtPartUtil;
import org.springframework.stereotype.Service;
import wt.part.WTPart;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CtSapServiceImpl implements CtSapService{


    /**
     * 查询物料库存
     * @param partNumber
     * @return
     * @throws Exception
     */
    @Override
    public String getPartStorage(String partNumber) throws Exception {
        return CtSapInterface.getPartTotalStorage(partNumber);
    }

    /**
     * 查询物料库存
     * @param partNumber
     * @return
     * @throws Exception
     */
    @Override
    public CtSapPartStorageBo getPartStorageBo(String partNumber) throws Exception {
        return CtSapInterface.getPartStorage(partNumber);
    }



    //==================== 后台触发集成接口 开始========================

    @Override
    public String createPart(String partNumber) throws Exception {

        String processNO = "后台触发物料创建！"+CtDateUtil.getCurrentDate();
        WTPart part = CtPartUtil.getPartByNumber(partNumber);
        if(part == null){
            throw new Exception("物料编码'"+partNumber+"'不存在！");
        }
        CtSapResultBo sapResult = CtSapInterface.createSapPart(processNO, part);
        return "执行结果：状态码："+sapResult.getResponseCode()+"|信息："+sapResult.getErrorMsg();

    }

    @Override
    public String disablePart(String partNumber) throws Exception {
        String processNO = "后台触发物料停用！"+CtDateUtil.getCurrentDate();
        WTPart part = CtPartUtil.getPartByNumber(partNumber);
        if(part == null){
            throw new Exception("物料编码'"+partNumber+"'不存在！");
        }
        CtSapResultBo sapResult = CtSapInterface.disableSapPart(processNO, part);
        return "执行结果：状态码："+sapResult.getResponseCode()+"|信息："+sapResult.getErrorMsg();
    }

    @Override
    public String restoreSapSupplier() throws Exception {
        List<CtSupplierInfoBo> supplierList = CtSapInterface.getSupplierInfo();
        System.out.println("查询供应商数量 = " + supplierList.size());
        CtSapQuery query = new CtSapQuery();
        query.restoreSupplierInfo(supplierList);
        return "更新成功！";
    }

    //==================== 后台触发集成接口 结束========================

    //==================== SAP配置信息读取 开始========================

    @Override
    public List<CtSupplierInfoBo> getSuppliers(String param) throws Exception {
        CtSapQuery query = new CtSapQuery();

        return query.getSuppliers(param);
    }

    @Override
    public CtSupplierInfoBo getSupplier(String numberOrName) throws Exception {
        CtSapQuery query = new CtSapQuery();
        return query.getSupplierByNameOrNumber(numberOrName);
    }

    //==================== SAP配置信息读取 结束========================

    //==================== 接口测试方法 开始========================
    /**
     * 测试创建伪造部件
     * @param partBo
     * @return
     * @throws Exception
     */
    @Override
    public String createFakePart(CtSapPartBo partBo) throws Exception {
        String processNO = "后台测试伪造Part";
        CtSapResultBo resultBo = CtSapInterface.createOrUpdateSapPart(processNO,partBo,"I");
        return resultBo.getResponseCode()+"|"+resultBo.getResponseMsg()+"|异常：>>>"+resultBo.getErrorMsg();
    }



    /**
     * 测试创建伪造BOM
     * @param bomNumber
     * @param bomType
     * @return
     * @throws Exception
     */
    @Override
    public String createFakeBOM(String bomNumber,String bomType) throws Exception {
        String processNO = "后台测试伪造BOM";

        String plant = "1001";
        //组装头信息
        Map<String,String> bomHeadInfoMap = new HashMap<>();
        bomHeadInfoMap.put("bomNumber", bomNumber);
        bomHeadInfoMap.put("updateFlag", "I");  //更新标识， I 添加， U 更新
        bomHeadInfoMap.put("unit", "ST"); //单位
        bomHeadInfoMap.put("ecnNumber", ""); //创建不需要ECN
        bomHeadInfoMap.put("bomType", bomType);
        bomHeadInfoMap.put("plant", plant);

        List<CtSapBomItemBo> bomItems = genFakeBomItems();

        CtSapResultBo resultBo = CtSapInterface.createSapBOM(bomHeadInfoMap,bomItems);
        return resultBo.getResponseCode()+"|"+resultBo.getResponseMsg()+"|异常：>>>"+resultBo.getErrorMsg();
    }

    @Override
    public String queryBOM(String partNumber, String bomUsage) throws Exception {
        return CtSapInterface.queryBOM(partNumber,bomUsage);
    }

    @Override
    public String queryPartCost(String partNumber) throws Exception {
        return CtSapInterface.queryPartCost(partNumber);
    }

    /**
     * 创建伪造BOM数据
     * @return
     * @throws Exception
     */
    public static List<CtSapBomItemBo> genFakeBomItems() throws Exception{

        List<CtSapBomItemBo> bomItemList = new ArrayList<>();

        CtSapBomItemBo bomItem1 = new CtSapBomItemBo();
        bomItem1.setITM_OPTYP("I");
        bomItem1.setIDNRK("130020132");//下阶物料
        bomItem1.setMENGE("1");//数量
        bomItem1.setMEINS("ST");//单位
        bomItem1.setZZTXT("C1,C2,C5");
        bomItemList.add(bomItem1);

        CtSapBomItemBo bomItem2 = new CtSapBomItemBo();
        bomItem2.setITM_OPTYP("I");
        bomItem2.setIDNRK("134010215");//下阶物料
        bomItem2.setMENGE("1");//数量
        bomItem2.setMEINS("ST");//单位
        bomItem2.setALPGR("A1"); //替代组
        bomItem2.setALPRF("1");//替代优先级
        bomItemList.add(bomItem2);

        CtSapBomItemBo bomItem3 = new CtSapBomItemBo();
        bomItem3.setITM_OPTYP("I");
        bomItem3.setIDNRK("134020087");//下阶物料
        bomItem3.setMENGE("1");//数量
        bomItem3.setMEINS("ST");//单位
        bomItem3.setALPGR("A1"); //替代组
        bomItem3.setALPRF("2");//替代优先级
        bomItemList.add(bomItem3);

        return bomItemList;
    }

    @Override
    public String createFakeECN(String ecnNumber,String ecnDesc,String ecnReason,String effectTime) throws Exception {

        Map<String, String> ecnParamMap = new HashMap<>();
        ecnParamMap.put("ecnDesc",ecnDesc);
        ecnParamMap.put("ecnReason", ecnReason);
        ecnParamMap.put("effectDate", effectTime);
        CtSapAccess access = new CtSapAccess();
        CtSapResultBo resultBo = access.createECN(ecnNumber,ecnParamMap);
        return resultBo.getResponseCode()+"|>>>"+resultBo.getResponseMsg()+"|>>>"+resultBo.getErrorMsg();
    }

    /**
     * 创建伪造 预留单
     * @param orderType
     * @param projectNumber
     * @return
     * @throws Exception
     */
    @Override
    public String createFakeMaterialKeepOrder(String orderType,String projectNumber) throws Exception{

        //表单头信息
        CtSapMaterialKeepOrderBo orderBo = new CtSapMaterialKeepOrderBo();
        orderBo.setBWART(orderType); //移动类型(库存管理), Z03 领料， Z04退料
        orderBo.setKOSTL("1000280000"); //成本中心
        orderBo.setWERKS("1001");//工厂  (用于明细项）
        orderBo.setLGORT("0008");//库存地点  (用于明细项）
        orderBo.setAUFNR(projectNumber); //订单号 对应项目编码
        orderBo.setWEMPF("002028"); //收货方 002028
        orderBo.setZZCRMID("000101"); //CRM主键


        //物料明细项
        List<Map<String, String>> items = new ArrayList<>();
        Map<String, String> item1 = new HashMap<>();
        item1.put("partNumber","130020132");
        item1.put("amount","100");
        items.add(item1);

        Map<String, String> item2 = new HashMap<>();
        item2.put("partNumber","134010215");
        item2.put("amount","200");
        items.add(item2);


        String processNO = "后台测试伪造预留单"+CtDateUtil.getCurrentDate();
        CtSapResultBo resultBo = CtSapInterface.createMaterialKeepOrder(orderBo,items,processNO);
        return resultBo.getResponseCode()+"|返回信息："+resultBo.getResponseMsg()+"|异常信息："+resultBo.getErrorMsg();
    }
    @Override
    public void updateBom(String name,String bomNumber,String design,String processNo,String ecnNumber,String bomType,String plant) throws Exception{
//        String bomNumber = args[1];
//        String design = args[2];
//        String processNo = args[3];
//        String ecnNumber = args[4];
//        String bomType = args[5];
//        String plant = args[6];
        WTPart partByNumber ;
        if(design.equals("M")){
            partByNumber= CtPartUtil.getPartByNumber(bomNumber, CtConstant.VIEW_MANUFACTURING);
        }else {
            partByNumber= CtPartUtil.getPartByNumber(bomNumber,CtConstant.VIEW_DESIGN);
        }
        CtSapInterface in = new CtSapInterface();
//        CtSapResultBo sapResultBo = in.changeSapBOM(processNo,ecnNumber,partByNumber,bomType,plant);
    }

    //==================== 接口测试方法 开始========================
}
