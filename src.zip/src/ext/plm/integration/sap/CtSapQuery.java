package ext.plm.integration.sap;

import ext.plm.common.CtConstant;
import ext.plm.integration.sap.bo.CtSapResultBo;
import ext.plm.supplier.bo.CtSupplierInfoBo;
import ext.plm.util.CtDateUtil;
import ext.plm.util.CtFormatUtil;
import wt.method.MethodContext;
import wt.pom.Transaction;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CtSapQuery {

    /**
     * 存储集成信息
     * @param ctSapInfoBo
     * @return
     * @throws Exception
     */
    public boolean insertSapInfoToDb(CtSapResultBo ctSapInfoBo) throws Exception {
        MethodContext methodcontext = MethodContext.getContext();
        WTConnection wtconn = (WTConnection) methodcontext.getConnection();
        PreparedStatement pstm = null;
        boolean result = true;
        ResultSet rs = null;
        try {
            String sql = "";
            //insert into ZSAP_INFO(id,processNo,integrateUrl,integrateData,integrateResponseInfo,integrateResponseCode,integrateFlag,integrateTime,processType,mainObject)
            // values(ZSAP_INFO_seq.NEXTVAL,'test','test','test','test','test','test',to_Date('2020-12-14 12:01','yyyy-mm-dd hh24:mi'),'Part','1108-00001-01')
            sql = "insert into ZSAP_INFO(id,processNo,integrateUrl,integrateData,integrateResponseInfo,integrateResponseCode,integrateFlag,integrateTime,processType,mainObject)"
                    + " values(ZSAP_INFO_seq.NEXTVAL,?,?,?,?,?,?,to_Date(?,'yyyy-mm-dd hh24:mi'),?,?)";
            pstm = wtconn.prepareStatement(sql);
            pstm.setString(1, ctSapInfoBo.getProcessNo());
            pstm.setString(2, ctSapInfoBo.getIntegrateUrl());// 集成URL
            String integrateData = ctSapInfoBo.getIntegrateData();
            if(integrateData!=null && integrateData.length() >4000){
                integrateData = integrateData.substring(0,3900);
                integrateData = integrateData + "...(超长截断，完整数据请查看log)";
            }
            pstm.setString(3, integrateData);// 集成数据
            pstm.setString(4, ctSapInfoBo.getIntegrateFlag()==true? ctSapInfoBo.getResponseMsg(): ctSapInfoBo.getErrorMsg());// 集成返回结果
            pstm.setString(5, ctSapInfoBo.getResponseCode());// 集成状态码
            pstm.setString(6, ctSapInfoBo.getIntegrateFlag()+"");// 是否成功
            String currentDate = CtDateUtil.getCurrentDate("yyyy-MM-dd HH:mm", "GMT+8");
            pstm.setString(7,currentDate);
            pstm.setString(8,ctSapInfoBo.getProcessType());
            pstm.setString(9,ctSapInfoBo.getMainObject());
            pstm.execute();
            pstm.close();
        } catch (Exception e) {
            // result=false;
            e.printStackTrace();
            throw e;
        } finally {
            if (pstm != null)
                pstm.close();
            wtconn.getConnection().commit();
            if (wtconn != null && wtconn.isActive())
                wtconn.release();
            // methodcontext.clearConnection();
        }
        return result;
    }

    /**
     * 按名称或编号获取供应商列表
     * @param param 查询参数，要求大于等于2个字符
     * @return
     * @throws Exception
     */
    public List<CtSupplierInfoBo> getSuppliers(String param) throws Exception{

        MethodContext context = MethodContext.getContext();
        WTConnection wtConn = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<CtSupplierInfoBo> supplierList = new ArrayList<>();
        //要求查询参数大于等于2个字符
        if(!CtFormatUtil.hasContent(param)||param.length() <2){
            return supplierList;
        }
        try {
            String sql = "select supplierCode,supplierName,supplierEmail,userName from ZSupplierInfo "
                    +" where (supplierCode like ? or supplierName like ?) "
                    +" order by supplierCode";
            statement = wtConn.prepareStatement(sql);
            statement.setString(1,"%"+param+"%");
            statement.setString(2,"%"+param+"%");
            resultSet = statement.executeQuery();
            while (resultSet.next()){
                CtSupplierInfoBo supplier = new CtSupplierInfoBo();
                supplier.setSupplierCode(resultSet.getString("supplierCode"));
                supplier.setSupplierName(resultSet.getString("supplierName"));
                supplier.setSupplierEmail(resultSet.getString("supplierEmail"));
                supplier.setUserName(resultSet.getString("userName"));
                supplierList.add(supplier);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (resultSet != null)
                resultSet.close();
            if (statement != null)
                statement.close();
            if (wtConn != null && wtConn.isActive())
                wtConn.release();
        }
        return supplierList;
    }

    /**
     * 按名称或编号查找单个供应商
     * @param nameOrNumber
     * @return
     * @throws Exception
     */
    public CtSupplierInfoBo getSupplierByNameOrNumber(String nameOrNumber) throws Exception{

        MethodContext context = MethodContext.getContext();
        WTConnection wtConn = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        CtSupplierInfoBo supplier = null;

        try {
            String sql = "select supplierCode,supplierName,supplierEmail,userName from ZSupplierInfo "
                    +" where (supplierCode = ? or supplierName = ?) "
                    +" order by supplierCode";
            statement = wtConn.prepareStatement(sql);
            statement.setString(1,nameOrNumber);
            statement.setString(2,nameOrNumber);
            resultSet = statement.executeQuery();
            while (resultSet.next()){
                supplier = new CtSupplierInfoBo();
                supplier.setSupplierCode(resultSet.getString("supplierCode"));
                supplier.setSupplierName(resultSet.getString("supplierName"));
                supplier.setSupplierEmail(resultSet.getString("supplierEmail"));
                supplier.setUserName(resultSet.getString("userName"));
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (resultSet != null)
                resultSet.close();
            if (statement != null)
                statement.close();
            if (wtConn != null && wtConn.isActive())
                wtConn.release();
        }
        return supplier;
    }

    /**
     * 重新存储SAP供应商信息
     * @param supplierList
     * @return
     * @throws Exception
     */
    public boolean restoreSupplierInfo(List<CtSupplierInfoBo> supplierList) throws Exception {
        MethodContext methodcontext = MethodContext.getContext();
        WTConnection wtconn = (WTConnection) methodcontext.getConnection();
        PreparedStatement pstm = null;
        boolean result = true;
        ResultSet rs = null;
        Transaction ts = null;
        try {
            ts = new Transaction();
            ts.start();
            //先执行删除
            String delSql = "truncate table ZSupplierInfo";
            pstm = wtconn.prepareStatement(delSql);
            pstm.execute();
            pstm.close();

            //执行添加
            String sql = "";
            sql = "insert into ZSupplierInfo(id,supplierCode,supplierName,supplierEmail,userName,updateTime)"
                    + " values(?,?,?,?,?,to_Date(?,'yyyy-mm-dd hh24:mi'))";
            int index = 10000;
            for (CtSupplierInfoBo bo : supplierList) {
                index ++;
                pstm = wtconn.prepareStatement(sql);
                pstm.setString(1, index + "");
                pstm.setString(2, bo.getSupplierCode());
                pstm.setString(3, bo.getSupplierName());
                pstm.setString(4, bo.getSupplierEmail());
                pstm.setString(5, bo.getUserName());
                String currentDate = CtDateUtil.getCurrentDate("yyyy-MM-dd HH:mm", "GMT+8");
                pstm.setString(6, currentDate);
                pstm.execute();
                pstm.close();
            }
            ts.commit();
            ts = null;

        } catch (Exception e) {
            // result=false;
            e.printStackTrace();
            throw e;
        } finally {
            if(ts != null) ts.rollback();
            if (pstm != null)
                pstm.close();
            wtconn.getConnection().commit();
            if (wtconn != null && wtconn.isActive())
                wtconn.release();

            // methodcontext.clearConnection();
        }
        return result;
    }

    /**
     * 按名称或编号获取供应商列表
     * @param loginName 查询参数，要求大于等于2个字符
     * @return
     * @throws Exception
     */
    public String  getNoByLoginName(String loginName) throws Exception{
        MethodContext context = MethodContext.getContext();
        WTConnection wtConn = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String no="";
        try {
            String sql = "select no from ZHRPERSON where LOGINNAME=?";
            statement = wtConn.prepareStatement(sql);
            statement.setString(1,loginName);
            resultSet = statement.executeQuery();
            while (resultSet.next()){
                no=resultSet.getString("no");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (resultSet != null)
                resultSet.close();
            if (statement != null)
                statement.close();
            if (wtConn != null && wtConn.isActive())
                wtConn.release();
        }
        return no;
    }
    
}
