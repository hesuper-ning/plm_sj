package ext.plm.integration.sap;

import ext.plm.adminTool.configCenter.manager.CtConfigCenterManager;
import ext.plm.adminTool.configCenter.manager.CtPropertyConfig;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.integration.sap.bo.CtSapBomItemBo;
import ext.plm.integration.sap.bo.CtSapPartBo;
import ext.plm.integration.sap.config.CtSapConfig;
import ext.plm.part.CtPartExtendService;
import ext.plm.part.bo.CtPartExtendInfo;
import ext.plm.part.config.CtPartConfig;
import ext.plm.util.*;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.part.*;
import wt.util.WTException;

import java.util.*;

public class CtSapLogic {

    /**
     * 获取SAP物料所需信息
     * @param part
     * @param createFlag 判断是否创建新物料，是的话必须要能查找到PLM物料视图数据，否的话为变更情况，历史数据无法查找到PLM视图数据
     * @param isDefaultState （1）第一次同步物料接口，状态默认“变更中”
     * （2）再同步BOM接口
     * （3）最后再同步物料接口，优先取“M视图物料的生命周期状态”
     * @return
     * @throws Exception
     */
    public static CtSapPartBo genSapPartBo(WTPart part,boolean createFlag, boolean isDefaultState) throws Exception{

        CtPartExtendInfo partExtendInfo ;
        partExtendInfo = CtBeanFactory.newCtBeanFactory().getBean(CtPartExtendService.class).getPartBoByPartNum(part.getNumber());
        if(createFlag&&partExtendInfo == null){
            //创建时不允许找不到物料
            throw new WTException("物料'" + part.getNumber() + "'在PLM中查找不到扩展视图数据！");
        }


        CtSapPartBo sapPartBo = new CtSapPartBo();

        IBAUtility ibaUtil = new IBAUtility(part);


        //旧物料号 ct_oldMaterialCode -> BISMT
        String oldMaterialCode = ibaUtil.getIBAValue("ct_oldMaterialCode");
        sapPartBo.setBISMT(oldMaterialCode);

        //物料编号
        sapPartBo.setMATNR(part.getNumber());

        //物料状态
        String partState = part.getLifeCycleState().getDisplay(Locale.CHINA);
        if(isDefaultState){
            //默认发“变更中”
            partState = "变更中";
        }
        CtPropertyConfig partStateConfig = CtConfigCenterManager.getInstance().loadProperty("SAPMaterialStatusMapping");
        String partStateCode = partStateConfig.getValue(partState);
        if(CtFormatUtil.hasContent(partStateCode)){
            sapPartBo.setZMSTA(partStateCode);
        }else{
            throw new WTException("物料状态“" + partState + "”在配置中心“发SAP物料状态与编号映射配置”中找不到对应的编号！");
        }

        //物料类型 ct_materialType -> MTART
        String materialType = ibaUtil.getIBAValue("ct_materialType");
        sapPartBo.setMTART(materialType);

        //基本计量单位
        String sapUnit = alignSapUnit(part.getDefaultUnit().toString());
        sapPartBo.setMEINS(sapUnit);

        //物料描述 40 name -> MAKTX
        String partName = part.getName();
        sapPartBo.setMAKTX(partName);

        //英文描述, 使用部件名称
        sapPartBo.setZMATNE(partName);

        //物料描述（研发） ct_itemDescription -> ZMATNR
        String partFullDescription = ibaUtil.getIBAValue("ct_itemDescription");
        sapPartBo.setZMATNR(partFullDescription);

        //物料长文本  255 ct_remark -> ZTEXT
        String longText = ibaUtil.getIBAValue("ct_remark");
        sapPartBo.setZTEXT(longText);


        //物料组 ct_MaterialGAD ->MATKL
        String materialGAD = ibaUtil.getIBAValue("ct_MaterialGAD");
        if(CtFormatUtil.hasContent(materialGAD)){
            //物料组是下划线分隔
            materialGAD = materialGAD.split("_")[0];
        }else{
            materialGAD = "";
        }
        sapPartBo.setMATKL(materialGAD);



        //销售描述  ct_salesDescription -> ZMAKTX
        String salesDescription = ibaUtil.getIBAValue("ct_salesDescription");
        sapPartBo.setZMAKTX(salesDescription);

        //产品组 ct_productGroup -> SPART
        String productGroup = ibaUtil.getIBAValue("ct_productGroup");
        sapPartBo.setSPART(productGroup);

        //外部物料组 ct_wbwlzjms -> EXTWG
        String  wbwlzjms= ibaUtil.getIBAValue("ct_wbwlzjms");
        sapPartBo.setEXTWG(alignNeedSplitValue(wbwlzjms));


        //器件库编码 选填，板件类必填 ct_deviceLibraryCode ->ZQCODE
        String  deviceLibraryCode= ibaUtil.getIBAValue("ct_deviceLibraryCode");
        sapPartBo.setZQCODE(deviceLibraryCode);

        //点数 	 ct_controllerPoints -> ZDIANS
        String controllerPoints = ibaUtil.getIBAValue("ct_controllerPoints");
        sapPartBo.setZDIANS(controllerPoints);

        //产品关键特性 ct_Keyfeaturesoftheproduct ->ZPROIN
        //String  keyFeature= ibaUtil.getIBAValue("ct_Productfeaturedescription");
        //sapPartBo.setZPROIN(keyFeature);

        //优选 ct_preferredLevel -> LABOR
        String preferredLevel = ibaUtil.getIBAValue("ct_preferredLevel");
        sapPartBo.setLABOR(alignNeedSplitValue(preferredLevel));

        //跨工厂物料状态 2 ct_CrossFactoryStatus -> MSTAE
        String  crossFactoryStatus= ibaUtil.getIBAValue("ct_CrossFactoryStatus");
        sapPartBo.setMSTAE(crossFactoryStatus);

        //大小/量纲(体积)  ct_volume ->	GROES
        String volume = ibaUtil.getIBAValue("ct_volume");
        sapPartBo.setGROES(volume);

        //文档号码(财务税收分类编码) ct_TaxClassificationCode -> ZEINR
        String  taxClassificationCode= ibaUtil.getIBAValue("ct_TaxClassificationCode");
        sapPartBo.setZEINR(taxClassificationCode);

        //工厂 4 , 固定传1001，由SAP端扩展其他工厂
        sapPartBo.setWERKS("1001");

        //版本长描述--对应文档内部版本
        String version = ibaUtil.getIBAValue("ct_version");
        //版次号  根据物料‘内部版本’字段 例V1.0 传 10  V2.1 传 21
        String versionInfo = ibaUtil.getIBAValue("ct_banci");
        versionInfo=tranVersion(versionInfo);
        sapPartBo.setZREVLV(version);
        sapPartBo.setREVLV(versionInfo);
        //研发环保认证要求
        String rdEnvCertRequirements = ibaUtil.getIBAValue("ct_Environmental");
        if(CtFormatUtil.hasContent(rdEnvCertRequirements)){
            String env = CtSapConfig.ENVIRONMENT_PROTECTION_MAP.get(rdEnvCertRequirements);
            if(CtFormatUtil.hasContent(env)){
                sapPartBo.setZCERTREQ(env);
            }else{
                throw new Exception("研发环保认证要求【" + rdEnvCertRequirements +"】不在SAP映射关系中，请检查！");
            }
        }
        //环保认证确认
        String ct_isRohs = ibaUtil.getIBAValue("ct_isRohs");
        if(CtFormatUtil.hasContent(ct_isRohs)){
            String rohs = CtSapConfig.ENVIRONMENT_PROTECTION_MAP.get(ct_isRohs);
            if(CtFormatUtil.hasContent(rohs)){
                sapPartBo.setZCERTCONF(rohs);
            }else{
                throw new Exception("环保认证确认【" + ct_isRohs +"】不在SAP映射关系中，请检查！");
            }
        }

        //=====================以下属性来自物料扩展视图表单====================================

        //历史数据允许不用扩展视图
        if(partExtendInfo != null){
            //销售组织 4 saleOrganization -> VKORG
            String  saleOrganization= partExtendInfo.getSaleOrganization();
            saleOrganization="";
            sapPartBo.setVKORG(alignNeedSplitValue(saleOrganization));

            //分销渠道 2 channels -> VTWEG
            String  channels= partExtendInfo.getChannels();
            channels="";
            sapPartBo.setVTWEG(alignNeedSplitValue(channels));

            //交货工厂 4  deliveryFactory -> DWERK
            String  deliveryFactory= partExtendInfo.getDeliveryFactory();
            deliveryFactory="";
            sapPartBo.setDWERK(deliveryFactory);

            //税分类 1 taxType -> TAXM1
            String  taxType= partExtendInfo.getTaxType();
            taxType="";
            sapPartBo.setTAXM1(alignNeedSplitValue(taxType));


            //科目设置组  2 subjectGroup -> KTGRM
            String  subjectGroup= partExtendInfo.getSubjectGroup();
            subjectGroup="";
            sapPartBo.setKTGRM(subjectGroup);

            //项目类别组 4  projectTypeGroup -> MTPOS
            String projectTypeGroup = partExtendInfo.getProjectTypeGroup();
            projectTypeGroup="";
            sapPartBo.setMTPOS(alignNeedSplitValue(projectTypeGroup));

            //装载组 4 loadGroup -> LADGR
            String  loadGroup= partExtendInfo.getLoadGroup();
            loadGroup="";
            sapPartBo.setLADGR(alignNeedSplitValue(loadGroup));

            //采购组 3 purchaseGroup -> EKGRP
            String purchaseGroup = partExtendInfo.getPurchaseGroup();
            sapPartBo.setEKGRP(purchaseGroup);

            //标识: "允许自动采购订单" 1 autoBuyList -> KAUTB   为真时值为 X
            String  autoBuyList= partExtendInfo.getAutoBuyList();
            if("启用".equals(autoBuyList)){
                sapPartBo.setKAUTB("X");
            }else{
                sapPartBo.setKAUTB("");
            }

            //标识: 源清单要求  1 sourceList -> KORDB  为真时值为 X
            String  sourceList= partExtendInfo.getSourceList();
            sapPartBo.setKORDB(alignNeedSplitValue(sourceList));

            //检验类型 8  checkType -> ART
            String  checkType= partExtendInfo.getCheckType();
            sapPartBo.setART(alignNeedSplitValue(checkType));


            //库存ABC标识 1  stockLogo -> MAABC
            String  stockLogo= partExtendInfo.getStockLogo();
            sapPartBo.setMAABC(alignNeedSplitValue(stockLogo));

            //MRP类型 2 mrpType -> DISMM
            String  mrpType= partExtendInfo.getMrpType();
            sapPartBo.setDISMM(alignNeedSplitValue(mrpType));

            //物料需求计划控制员  mrpController -> DISPO
            String mrpController = partExtendInfo.getMrpController();
            sapPartBo.setDISPO(alignNeedSplitValue(mrpController));


            //物料计划内批量程序（批量大小） 2 lotSize -> DISLS
            String lotSize = partExtendInfo.getLotSize();
            sapPartBo.setDISLS(alignNeedSplitValue(lotSize));


            //最小批量 miniLot ->  BSTMI
            String miniLot = partExtendInfo.getMiniLot();
            sapPartBo.setBSTMI(miniLot);

            //装配报废百分比 assemblyScrap -> AUSSS
            String assemblyScrap = partExtendInfo.getAssemblyScrap();
            sapPartBo.setAUSSS(assemblyScrap);

            //采购订单数量的舍入值 rounding -> BSTRF
            String rounding = partExtendInfo.getRounding();
            sapPartBo.setBSTRF(rounding);

            //采购类型(获取类型) 1  acquisitionType -> BESKZ
            String acquisitionType = partExtendInfo.getAcquisitionType();
            sapPartBo.setBESKZ(acquisitionType);

            //特殊采购类型(特殊获取类型) 2 specialType  -> SOBSL
            String specialType = partExtendInfo.getSpecialType();
            sapPartBo.setSOBSL(alignNeedSplitValue(specialType));

            //标识：反冲  goLogo -> RGEKZ
            String goLogo = partExtendInfo.getGoLogo();
            if("不反冲".equals(goLogo)){
                sapPartBo.setRGEKZ("");
            }else if("一直反冲".equals(goLogo)){
                sapPartBo.setRGEKZ("1");
            }else {
                throw new WTException("反冲标识只允许值'不反冲'或'一直反冲',当前值：" + goLogo);
            }

            //指示符：散装物料 bulkPart  -> SCHGT
            String bulkPart = partExtendInfo.getBulkPart();
            sapPartBo.setSCHGT(alignNeedSplitValue(bulkPart));

            //发货存储地点(生产仓储地点) 4 productionLocation -> LGPRO
            String productionLocation = partExtendInfo.getProductionLocation();
            sapPartBo.setLGPRO(alignNeedSplitValue(productionLocation));

            //外部采购的缺省仓储位置(外部采购仓储地点) 4  outBuyStorageLocation -> LGFSB
            String outBuyStorageLocation = partExtendInfo.getOutBuyStorageLocation();
            sapPartBo.setLGFSB(alignNeedSplitValue(outBuyStorageLocation));

            //浮动排产时间容余码(计划边际码) 3  planMarginalCode -> FHORI
            String planMarginalCode = partExtendInfo.getPlanMarginalCode();
            sapPartBo.setFHORI(alignNeedSplitValue(planMarginalCode));

            //厂内生产时间(自制生产时间) selfProductionTime -> DZEIT
            String selfProductionTime = partExtendInfo.getSelfProductionTime();
            sapPartBo.setDZEIT(selfProductionTime);

            //计划交货时间（天） planDeliveryTime ->  PLIFZ
            String planDeliveryTime = partExtendInfo.getPlanDeliveryTime();
            sapPartBo.setPLIFZ(planDeliveryTime);

            //收货处理时间 receiptTime -> WEBAZ
            String receiptTime = partExtendInfo.getReceiptTime();
            sapPartBo.setWEBAZ(receiptTime);

            //安全库存 safeStock -> EISBE
            String safeStock = partExtendInfo.getSafeStock();
            sapPartBo.setEISBE(safeStock);

            //计划策略组 2 policyGroup  ->  STRGR
            String policyGroup = partExtendInfo.getPolicyGroup();
            sapPartBo.setSTRGR(alignNeedSplitValue(policyGroup));


            //消耗模式 1 consumptionPattern -> VRMOD
            String consumptionPattern = partExtendInfo.getConsumptionPattern();
            sapPartBo.setVRMOD(consumptionPattern);

            //消耗期间:逆向 3 reverseConsumption -> VINT1
            String reverseConsumption = partExtendInfo.getReverseConsumption();
            sapPartBo.setVINT1(reverseConsumption);

            //消耗时期 3 periodConsumption -> VINT2
            String periodConsumption = partExtendInfo.getPeriodConsumption();
            sapPartBo.setVINT2(periodConsumption);

            //可用性检查2  availabilityCheck -> MTVFP
            String availabilityCheck = partExtendInfo.getAvailabilityCheck();
            sapPartBo.setMTVFP(availabilityCheck);

            //独立/集中标识 1 independentLogo -> SBDKZ
            String independentLogo = partExtendInfo.getIndependentLogo();
            sapPartBo.setSBDKZ(independentLogo);

            //组件报废百分比 2 bomScrap  -> KAUSF
            String bomScrap = partExtendInfo.getBomScrap();
            sapPartBo.setKAUSF(bomScrap);

            //中止指示符(非连续标识) 1  discontinueLogo -> KZAUS
            String discontinueLogo = partExtendInfo.getDiscontinueLogo();
            sapPartBo.setKZAUS(alignNeedSplitValue(discontinueLogo));

            //中断日期(生效日期) effectiveTime -> AUSDT
            Date effectiveTime = partExtendInfo.getEffectiveTime();
            if(CtFormatUtil.hasContent(effectiveTime)){
                sapPartBo.setAUSDT(CtDateUtil.parseDate(effectiveTime,"yyyy-MM-dd HH:mm:ss"));
            }else{
                sapPartBo.setAUSDT("");
            }

            //后续物料 subsequentPart -> NFMAT
            String subsequentPart = partExtendInfo.getSubsequentPart();
            sapPartBo.setNFMAT(subsequentPart);

            //生产管理员 3  productionManager -> FEVOR
            String productionManager = partExtendInfo.getProductionManager();
            sapPartBo.setFEVOR(productionManager);

            //生产计划参数文件 6 productionPlanList -> SFCPF
            String productionPlanList = partExtendInfo.getProductionPlanList();
            sapPartBo.setSFCPF(productionPlanList);

            //序列号参数文件 4  numberList -> SERNP
            String numberList = partExtendInfo.getNumberList();
            sapPartBo.setSERNP(alignNeedSplitValue(numberList));

            //发货单位 unitCode -> MINBE
            String unitCode = partExtendInfo.getUnitCode();
            sapPartBo.setAUSME(unitCode);

            //评估类 4 accessType -> BKLAS
            String accessType = partExtendInfo.getAccessType();
            sapPartBo.setBKLAS(accessType);

            //价格控制指示符 1 priceControl -> VPRSV
            String priceControl = partExtendInfo.getPriceControl();
            sapPartBo.setVPRSV(alignNeedSplitValue(priceControl));

            //标准价格 11 standardPrice -> STPRS
            String standardPrice = partExtendInfo.getStandardPrice();
            sapPartBo.setSTPRS(standardPrice);

            //移动平均价格/周期单价  priceMoving -> VERPR
            String priceMoving = partExtendInfo.getPriceMoving();
            sapPartBo.setVERPR(priceMoving);

            //价格单位 5 priceUnit -> PEINH
            String priceUnit = partExtendInfo.getPriceUnit();
            sapPartBo.setPEINH(priceUnit);

            //成本估算 1  costEstimation -> EKALR
            String costEstimation = partExtendInfo.getCostEstimation();
            sapPartBo.setEKALR(costEstimation);

            //物料相关的源 1 partSource -> HKMAT
            String partSource = partExtendInfo.getPartSource();
            sapPartBo.setHKMAT(partSource);

            // 利润中心 10 profitCenter -> PRCTR
            String profitCenter = partExtendInfo.getProfitCenter();
            sapPartBo.setPRCTR(profitCenter);
        }

        return sapPartBo;
    }

    /**
     * 根据需求转化单位
     * @param plmUnit
     * @return
     * @throws Exception
     */
    public static String alignSapUnit(String plmUnit) throws Exception{
        String sapUnit = plmUnit.toUpperCase();

        switch (sapUnit){
            case "EA" :
                sapUnit = "ST";
                break;
            case "PC" :
                sapUnit = "ST";
                break;
            case "TONG" :
                sapUnit = "TN1";
                break;
            case "SQ_M" :
                sapUnit = "平方";
                break;
            case "SQUARE" :
                sapUnit = "平方米";
                break;
            case "JUAN" :
                sapUnit = "JU1";
                break;
            case "TIAO" :
                sapUnit = "TI1";
                break;
            case "CU_M" :
                sapUnit = "立方米";
                break;
            case "PING" :
                sapUnit = "BOT";
                break;
            case "PI" :
                sapUnit = "PI1";
                break;
            case "GE" :
                sapUnit = "EA";
                break;
            case "TAI" :
                sapUnit = "TA1";
                break;
            case "PAC" :
                sapUnit = "PAK";
                break;
            default:
                break;
        }

//        //EA 转 ST
//        if("EA".equalsIgnoreCase(plmUnit)){
//            sapUnit = "ST";
//        }
//        //PC 转 ST
//        if("PC".equalsIgnoreCase(plmUnit)){
//            sapUnit = "ST";
//        }
//        //桶（TONG）转TN1
//        if("TONG".equalsIgnoreCase(plmUnit)){
//            sapUnit = "TN1";
//        }

        return sapUnit;
    }

    //========================开始  BOM 部分===========================

    /**
     * 组装SAP BOM 下阶
     * @param bomPart
     * @return
     * @throws Exception
     */
    public static List<CtSapBomItemBo> genSapMassProductionBomItemList(WTPart bomPart,List<String> bomList) throws Exception{
        List<CtSapBomItemBo> bomItems = new ArrayList<>();
        //找当前BOM视图对应的下阶 D->D   M->M
        List<WTPart> partsInBOMByView = CtBomUtil.getPartsInBOMByView(bomPart, null);
        //增加下阶物料状态校验
        String msg="";
        String property = CtSapConfig.getProperty("trial_to_mass");
        String[] split = property.split(",");
        List<String> list = Arrays.asList(split);
        for (WTPart childPart : partsInBOMByView) {
            String partType = CtWTObjectUtil.getTypeIdentifier(childPart);
            partType = partType.substring(partType.lastIndexOf("|")+1);
            //成品半成品标识
            boolean flag= partType.equals(CtPartConfig.getProperty("半成品"));
            String state = CtWTObjectUtil.getStateDisplay(childPart, Locale.CHINA);
            //--过滤同一流程下的物料
            if(flag&&state.equals("已生效")&&!bomList.contains(childPart.getNumber())){
                msg = CtFormatUtil.combineStr(msg,bomPart.getNumber()+"-->"+childPart.getNumber()+":【"+state+"】");
            }
            if(!list.contains(state)&&!bomList.contains(childPart.getNumber())){
                msg = CtFormatUtil.combineStr(msg,bomPart.getNumber()+"-->"+childPart.getNumber()+":【"+state+"】");
            }
            WTPartUsageLink usageLink=CtBomUtil.getUsageLink(bomPart,childPart);
            CtSapBomItemBo bomItemBo =  genSapBomItemBo(usageLink);
            bomItems.add(bomItemBo);
        }
        if(CtFormatUtil.hasContent(msg)){
            throw new Exception(msg);
        }

        return bomItems;
    }
    /**
     * 组装SAP BOM 下阶
     * @param bomPart
     * @return
     * @throws Exception
     */
    public static List<CtSapBomItemBo> genSapTrialBomItemList(WTPart bomPart,List<String> bomList) throws Exception{
        List<CtSapBomItemBo> bomItems = new ArrayList<>();
//        QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(bomPart);
        //找当前BOM视图对应的下阶 D->D   M->M
        List<WTPart> partsInBOMByView = CtBomUtil.getPartsInBOMByView(bomPart, null);
        //增加下阶物料状态校验
        String msg="";
        String property = CtSapConfig.getProperty("effect_to_trial");
        String[] split = property.split(",");
        List<String> list = Arrays.asList(split);
        for (WTPart wtPart : partsInBOMByView) {
            String state = CtWTObjectUtil.getStateDisplay(wtPart, Locale.CHINA);
            if(!list.contains(state)&&!bomList.contains(wtPart.getNumber())){
                msg = CtFormatUtil.combineStr(msg,bomPart.getNumber()+"-->"+wtPart.getNumber()+":【"+state+"】");
            }
            WTPartUsageLink usageLink=CtBomUtil.getUsageLink(bomPart,wtPart);
            CtSapBomItemBo bomItemBo =  genSapBomItemBo(usageLink);
            bomItems.add(bomItemBo);
        }
        if(CtFormatUtil.hasContent(msg)){
            throw new Exception(msg);
        }

        return bomItems;
    }

    /**
     * 组装样机BOM下阶
     * 逻辑：允许发送的物料状态：1.认证中,样机,已生效,停用中,停用 2.认证中且属性“物料承认前发SAP”为否的物料
     * @param bomPart
     * @return
     * @throws Exception
     */
    public static List<CtSapBomItemBo> genSapSampleBomItemList(WTPart bomPart,List<String> bomList) throws Exception{
        List<CtSapBomItemBo> bomItems = new ArrayList<>();
//        QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(bomPart);
        //找当前BOM视图对应的下阶 D->D   M->M
        List<WTPart> partsInBOMByView = CtBomUtil.getPartsInBOMByView(bomPart, null);
        //增加下阶物料状态校验
        String msg="";
        String property = CtSapConfig.getProperty("creat_to_prototype");
        String[] split = property.split(",");
        List<String> list = Arrays.asList(split);
        for (WTPart wtPart : partsInBOMByView) {
            String state = CtWTObjectUtil.getStateDisplay(wtPart, Locale.CHINA);
            if(!list.contains(state)&&!bomList.contains(wtPart.getNumber())){
                msg = CtFormatUtil.combineStr(msg,bomPart.getNumber()+"-->"+wtPart.getNumber()+":【"+state+"】");
            }
            WTPartUsageLink usageLink=CtBomUtil.getUsageLink(bomPart,wtPart);
            CtSapBomItemBo bomItemBo =  genSapBomItemBo(usageLink);
            bomItems.add(bomItemBo);
        }
        if(CtFormatUtil.hasContent(msg)){
            throw new Exception(msg);
        }


        return bomItems;
    }

    /**
     * 组装  BOMItem BO
     * @param usageLink
     * @return
     * @throws Exception
     */
    public static CtSapBomItemBo genSapBomItemBo(WTPartUsageLink usageLink) throws Exception{
        IBAUtility ibaUtil = new IBAUtility(usageLink);

        WTPartMaster childPartMaster = (WTPartMaster) usageLink.getUses();
        WTPart childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster);
        WTPart fatherPart = (WTPart) usageLink.getUsedBy();
        String number = fatherPart.getNumber();
        CtSapBomItemBo bomItemBo = new CtSapBomItemBo();

        bomItemBo.setITM_OPTYP("I");//默认为添加，其他情况可在bo生成后修改此值

        //子项物料编码
        bomItemBo.setIDNRK(childPart.getNumber());

        //数量
        Quantity quantity = usageLink.getQuantity();
        //BOM基础数量默认为1000，下阶物料数量放大1000倍
        double amount;
        if(!number.startsWith("39")){
            amount = quantity.getAmount()*1000;
        }else{
            amount = quantity.getAmount();
        }

        String amoutString=amount+"";
        String value="";
        if(amoutString.contains(".")){
            String substring = amoutString.substring(amoutString.indexOf("."));
            value=amoutString;
            if(substring.length()>3){
                java.text.DecimalFormat df =new java.text.DecimalFormat("#.000");
                value= df.format(amount);
            }
        }else {
            value=amoutString;
        }
        bomItemBo.setMENGE(value);


        //组件单位--2021/12/28修改集成sap bom 根据业务需求发送
        //        String bomUnit = quantity.getUnit().toString();
        String bomUnit =  childPart.getDefaultUnit().toString();
        bomItemBo.setMEINS(alignSapUnit(bomUnit));

        //位号
        String fitPlace = CtBomUtil.getReferenceDesignator(usageLink);
        bomItemBo.setZZTXT(fitPlace);

        //替代组 ct_substituteGroupNumber  -> ALPGR
        String replaceGroup = ibaUtil.getIBAValue("ct_substituteGroupNumber");
        bomItemBo.setALPGR(replaceGroup);

        //替代优先级  ct_Alternategrouppriority -> ALPRF
        String replacePriority = ibaUtil.getIBAValue("ct_Alternategrouppriority");
        bomItemBo.setALPRF(replacePriority);

        //替代组比例   ct_possuse -> EWAHR
        String replace = ibaUtil.getIBAValue("ct_possuse");
        bomItemBo.setEWAHR(replace);

        //替代组比例   ct_possuse -> EWAHR
        String bomRemark = ibaUtil.getIBAValue("ct_BOMNotes");
        bomItemBo.setZTEXT(bomRemark);

        return bomItemBo;
    }
    /**
     * 收集优先级 替代组
     */
    //{
    //“A1”:{1,2,3}
    //“A2”:{1,3,4}
    // }
    public static void collectData(String replaceGroup, int pri,  Map<String,List<Integer>> map){
        List<Integer> list = map.get(replaceGroup);
        if(!CtFormatUtil.hasContent(list)){
            list=new ArrayList<>();
        }
        list.add(pri);

        map.put(replaceGroup, list);

    }
    /**
     * 处理数据
     */
    //{
    //“A1”:{1,2,3}
    //“A2”:{1,3,4}
    // }
    public static void calculateNumber(Map<String,List<Integer>> map, Map<String, Map<String, String>> calculateMap){
        for (String s : map.keySet()) {
            List<Integer> integers = map.get(s);
            Map<String, String> priMap=new HashMap<>();
            int size = integers.size();
            int i = 100 / size;
            int res = 100 - size*i;
            //从小到大自动排序
            Collections.sort(integers);
            for (Integer integer : integers) {
                if(res>0){
                    priMap.put(integer+"",i+1+"");
                }else {
                    priMap.put(integer+"",i+"");
                }
                res--;
            }
            calculateMap.put(s, priMap);
        }
    }
    /**
     * 属性替代组比率
     * @param bom
     */
    public static void toReRefreshReplaceGroup(WTPart bom) throws Exception {
        QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(bom);
        QueryResult linkQr2 = WTPartHelper.service.getUsesWTPartMasters(bom);
        Map<String,List<Integer>> map=new HashMap<>();
        Map<String,Set<Integer>> justOneMap=new HashMap<>();
        Map<String, Map<String, String>> calculateMap=new HashMap<>();
        String msg="";
        // 第一遍计算
        while (linkQr.hasMoreElements()) {
            Set<Integer> integers=new HashSet<>();
            WTPartUsageLink link =(WTPartUsageLink)linkQr.nextElement();
            IBAUtility ibaUtility = new IBAUtility(link);
            WTPartMaster childPartMaster = (WTPartMaster) link.getUses();
            WTPart childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster);
            //替代组
            String ct_substituteGroupNumber = ibaUtility.getIBAValue("ct_substituteGroupNumber");
            //优先级
            String ct_Alternategrouppriority = ibaUtility.getIBAValue("ct_Alternategrouppriority");
            if(!CtFormatUtil.hasContent(ct_substituteGroupNumber))continue;
            try {
                int i = Integer.parseInt(ct_Alternategrouppriority);
                integers = justOneMap.get(ct_substituteGroupNumber);
                if(CtFormatUtil.hasContent(integers)){
                    if(integers.contains(i)){
                        msg=CtFormatUtil.combineStr(msg,childPart.getNumber(),",");
                    }else{
                        integers.add(i);
                        justOneMap.put(ct_substituteGroupNumber,integers);
                    }
                }else{
                    integers=new HashSet<>();
                    integers.add(i);
                    justOneMap.put(ct_substituteGroupNumber,integers);
                }

                //收集数据
                collectData(ct_substituteGroupNumber, i,map);
            } catch (NumberFormatException e) {
                msg=CtFormatUtil.combineStr(msg,childPart.getNumber(),",");
            }
        }
        if(CtFormatUtil.hasContent(msg)){
            throw new Exception(bom.getNumber()+"下物料优先级存在问题:"+msg);
        }
        calculateNumber(map, calculateMap);
        // 第二遍刷新数据
        while (linkQr2.hasMoreElements()) {
            WTPartUsageLink link =(WTPartUsageLink)linkQr2.nextElement();
            IBAUtility ibaUtility = new IBAUtility(link);
            WTPartMaster childPartMaster = (WTPartMaster) link.getUses();
            WTPart childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster);
            //替代组
            String ct_substituteGroupNumber = ibaUtility.getIBAValue("ct_substituteGroupNumber");
            //优先级
            String ct_Alternategrouppriority = ibaUtility.getIBAValue("ct_Alternategrouppriority");
            if(CtFormatUtil.hasContent(ct_substituteGroupNumber)){
                Map<String, String> map1 = calculateMap.get(ct_substituteGroupNumber);
                String s = map1.get(ct_Alternategrouppriority);
                ibaUtility.setIBAValue("ct_possuse",s);
                ibaUtility.updateAttributeContainer((IBAHolder) link);
                IBAUtility.updateIBAHolder((IBAHolder) link);
            }else{
//                ibaUtility.setIBAValue("ct_possuse","");
                ibaUtility.removeAttribute("ct_possuse");
                ibaUtility.updateAttributeContainer((IBAHolder) link);
                IBAUtility.updateIBAHolder((IBAHolder) link);
            }

        }
    }




    /**
     * 组装修改SAP BOM
     * @param bom
     */
    public static List<CtSapBomItemBo> genSapChangeBomItemList(WTPart bom, String bomType, List<String> bomNumList) throws Exception {
        QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(bom);
        Enumeration[] bomDifference = CtBomUtil.genBomDifference(bom);
        List<CtSapBomItemBo> bomItems = new ArrayList<CtSapBomItemBo>();

        //增加下阶物料状态校验
        String msg="";
        String property="";
        if(bomType.equals("2")){
            property=CtSapConfig.getProperty("effect_to_trial");
        }else if(bomType.equals("1")){
            property=CtSapConfig.getProperty("trial_to_mass");
        }else if(bomType.equals("0")){
            property=CtSapConfig.getProperty("update_to_prototype");
        }else{
            throw new Exception("该流程没有配置对应的BOM合法变更类型抬头");
        }
        String[] split = property.split(",");
        List<String> list = Arrays.asList(split);
        if(!CtFormatUtil.hasContent(list)){
            throw new Exception("集成抛转子阶配置文件加载失败,或配置文件key对应value被删除");
        }
        while (linkQr.hasMoreElements()) {
//            PartUsageInfo pui = (PartUsageInfo) bomDifference[0].nextElement();
            WTPartUsageLink link =(WTPartUsageLink)linkQr.nextElement();
            WTPartMaster childPartMaster = (WTPartMaster) link.getUses();
            WTPart childPart;
            if("0".equals(bomType)){
                childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster,CtConstant.VIEW_DESIGN);
            }else {
                //1 2 均为试产量产变更，优先找M视图
                childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster, CtConstant.VIEW_MANUFACTURING);
                if(!CtFormatUtil.hasContent(childPart) ){
                    childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster,CtConstant.VIEW_DESIGN);
                }
            }
            String state = CtWTObjectUtil.getStateDisplay(childPart, Locale.CHINA);
//            String ClfHierarchyName = CtPartClfUtil.getClfHierarchy(childPart);
            String partType = CtWTObjectUtil.getTypeIdentifier(childPart);
            partType = partType.substring(partType.lastIndexOf("|")+1);
            //成品半成品标识
            boolean flag= partType.equals(CtPartConfig.getProperty("半成品"));
            //试产量产流程，半成品 成品下阶都不允许 半成品为已生效
            if(!"0".equals(bomType)&&flag&&state.equals("已生效")){
                msg = CtFormatUtil.combineStr(msg,bom.getNumber()+"-->"+childPart.getNumber()+":【"+state+"】","\r\n");
            }
            if(!list.contains(state)&&!bomNumList.contains(childPart.getNumber())){
                msg = CtFormatUtil.combineStr(msg,bom.getNumber()+"-->"+childPart.getNumber()+":【"+state+"】","\r\n");
            }
        }
        if(CtFormatUtil.hasContent(msg)){
            throw new Exception(msg);
        }


        // 删除
        while (bomDifference[1].hasMoreElements()) {
            PartUsageInfo pui = (PartUsageInfo) bomDifference[1].nextElement();
            WTPartUsageLink link = pui.getPartUsageLink();
            // 开始组装Item BO
            CtSapBomItemBo itemBo = genSapBomItemBo(link);
            itemBo.setITM_OPTYP("D"); //删除标识 D
            bomItems.add(itemBo);
        }

        // 添加
        while (bomDifference[0].hasMoreElements()) {
            PartUsageInfo pui = (PartUsageInfo) bomDifference[0].nextElement();
            WTPartUsageLink link = pui.getPartUsageLink();
            // 开始组装Item BO
            CtSapBomItemBo itemBo = genSapBomItemBo(link);
            itemBo.setITM_OPTYP("I"); //删除标识 I
            bomItems.add(itemBo);
        }

        // 修改
        while (bomDifference[2].hasMoreElements()) {
            PartUsageInfo pui = (PartUsageInfo) bomDifference[2].nextElement();
            WTPartUsageLink link = pui.getPartUsageLink();
            // 开始组装Item BO
            CtSapBomItemBo itemBo = genSapBomItemBo(link);
            itemBo.setITM_OPTYP("U"); //更新标识
            bomItems.add(itemBo);
        }

//        //特殊逻辑：为满足更换SAP BOM基数，要求第一次变更（版本为B）时将未变化项也作为更新项发送给SAP，目的是将SAP的下阶数量替换过来
//        if(bom.getVersionIdentifier().getValue().equals("B")&&bomDifference.length>3) {
//            // 未变动项
//            while (bomDifference[3].hasMoreElements()) {
//                PartUsageInfo pui = (PartUsageInfo) bomDifference[3].nextElement();
//                WTPartUsageLink link = pui.getPartUsageLink();
//                // 开始组装Item BO
//                CtSapBomItemBo itemBo = genSapBomItemBo(link);
//                itemBo.setITM_OPTYP("U"); //更新标识
//                bomItems.add(itemBo);
//            }
//        }

        return bomItems;
    }
    /**
     * 组装修改SAP BOM
     * @param bom
     */
    public static List<CtSapBomItemBo> genSapHistoryChangeBomItemList(WTPart bom,String bomType, List<String> bomNumList) throws Exception {
        QueryResult linkQr = WTPartHelper.service.getUsesWTPartMasters(bom);
        List<CtSapBomItemBo> bomItems = new ArrayList<CtSapBomItemBo>();
        //增加下阶物料状态校验
        String msg="";
        String property ;
        if(bomType.equals("2")){
            property=CtSapConfig.getProperty("effect_to_trial");
        }else if(bomType.equals("1")){
            property=CtSapConfig.getProperty("trial_to_mass");
        }else if(bomType.equals("0")){
            property=CtSapConfig.getProperty("update_to_prototype");
        }else{
            throw new Exception("该流程没有到配置对应的BOM合法变更类型抬头");
        }
        String[] split = property.split(",");
        List<String> list = Arrays.asList(split);
        // 添加
        while (linkQr.hasMoreElements()) {
//            PartUsageInfo pui = (PartUsageInfo) bomDifference[0].nextElement();
            WTPartUsageLink link =(WTPartUsageLink)linkQr.nextElement();
            WTPartMaster childPartMaster = (WTPartMaster) link.getUses();
            WTPart childPart;
            if("0".equals(bomType)){
                childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster,CtConstant.VIEW_DESIGN);
            }else {
                //1 2 均为试产量产变更，优先找M视图
                childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster, CtConstant.VIEW_MANUFACTURING);
                if(!CtFormatUtil.hasContent(childPart) ){
                    childPart = (WTPart) CtVersionUtil.getLatest(childPartMaster,CtConstant.VIEW_DESIGN);
                }
            }
            String state = CtWTObjectUtil.getStateDisplay(childPart, Locale.CHINA);
//            String ClfHierarchyName = CtPartClfUtil.getClfHierarchy(childPart);
            String partType = CtWTObjectUtil.getTypeIdentifier(childPart);
            partType = partType.substring(partType.lastIndexOf("|")+1);
            //成品半成品标识
            boolean flag= partType.equals(CtPartConfig.getProperty("半成品"));
            //试产量产流程，半成品 成品下阶都不允许 半成品为已生效--过滤同一流程下的物料
            if(!"0".equals(bomType)&&flag&&state.equals("已生效")){
                msg = CtFormatUtil.combineStr(msg,bom.getNumber()+"-->"+childPart.getNumber()+":【"+state+"】","\r\n");
            }
            if(!list.contains(state)&&!bomNumList.contains(childPart.getNumber())){
                msg = CtFormatUtil.combineStr(msg,bom.getNumber()+"-->"+childPart.getNumber()+":【"+state+"】","\r\n");
            }

            // 开始组装Item BO
            CtSapBomItemBo itemBo = genSapBomItemBo(link);
            itemBo.setITM_OPTYP("I"); //添加标识 I
            bomItems.add(itemBo);

        }
        if(CtFormatUtil.hasContent(msg)){
            throw new Exception(msg);
        }


        return bomItems;
    }

    //=========================结束 BOM 部分============================

    /**
     * 获取配置的工厂
     * @return
     * @throws Exception
     */
    public static List<String> getPlants() throws Exception{

        List<String> plantList = new ArrayList<>();
        String plantStr = CtSapConfig.getProperty("plants");
        if(!CtFormatUtil.hasContent(plantStr)){
            throw new WTException("无法找到工厂配置，请联系管理员检查CtSapConfig.properties");
        }
        for(String plant: plantStr.split(",")){
            plantList.add(plant);
        }
        return  plantList;
    }

    /**
     * 对用“-”分隔内部值和显示值的字符串，截取“-"前面的内部值
     * @param orgValue
     * @return
     * @throws Exception
     */
    private static String alignNeedSplitValue(String orgValue) throws Exception{
        String alignedValue = "";
        if(CtFormatUtil.hasContent(orgValue)){
            alignedValue = orgValue.split("-")[0];
            //下拉项是空或无字样的，用空传值
            if("空".equals(alignedValue)||"无".equals(alignedValue)){
                alignedValue = "";
            }
        }else{
            alignedValue = "";
        }
        return  alignedValue.trim();
    }

    /**
     * 将V1.2转成12
     * @param version
     * @return
     * @throws Exception
     */
    private static String tranVersion(String version)throws Exception{
        if(CtFormatUtil.hasContent(version)){
            version= version.replace("V", "");
            version= version.replace(".", "");
        }
        return version;
    }

}
