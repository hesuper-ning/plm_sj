package ext.plm.integration.sap;

import com.alibaba.fastjson.JSON;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bean.CtBeanService;
import ext.plm.common.CtConstant;
import ext.plm.integration.hr.mapper.CtHrMapper;
import ext.plm.integration.sap.bo.CtSapBomItemBo;
import ext.plm.integration.sap.bo.CtSapPartBo;
import ext.plm.integration.sap.bo.CtSapPartStorageBo;
import ext.plm.integration.sap.bo.CtSapResultBo;
import ext.plm.oaFlow.softwareBurning.bo.CtChipTypeBo;
import ext.plm.oaFlow.softwareBurning.config.CtSoftwareBurningDaoMapper;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtProjectUtil;
import ext.plm.util.CtUserUtil;
import ext.plm.workReport.CtWorkReportItemService;
import wt.fc.QueryResult;
import wt.method.RemoteMethodServer;
import wt.org.WTUser;
import wt.part.Quantity;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartUsageLink;
import wt.projmgmt.admin.Project2;
import wt.services.ServiceFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestMain {

    private  static CtSapService service = ServiceFactory.getService(CtSapService.class);
    private  static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);

    public static void main(String[] args) {
        System.out.println("======TestMain.java 开始调用  " + args[0] + "=============");
        try {
            RemoteMethodServer server = RemoteMethodServer.getDefault();
            if(CtConstant.isLocalEnv()||CtConstant.isTestEnv()){
                server.setUserName("wcadmin");
                server.setPassword("wcadmin");
            }

            if ("createPart".equalsIgnoreCase(args[0])) {
                //通过后台创建物料（会查找物料表单中填写的数据)
                //windchill ext.plm.integration.sap.TestMain createPart 30174401
                String partNumber = args[1];
                Object[] params = new Object[1];
                params[0] = partNumber;
                Object resultObj = beanService.doMethod(CtSapService.class,"createPart",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if ("disablePart".equalsIgnoreCase(args[0])) {
                //停用物料
                //windchill ext.plm.integration.sap.TestMain disablePart 30174401
                String partNumber = args[1];
                Object[] params = new Object[1];
                params[0] = partNumber;
                Object resultObj = beanService.doMethod(CtSapService.class,"disablePart",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if ("restoreSupplier".equalsIgnoreCase(args[0])) {
                //重新加载供应商信息
                //windchill ext.plm.integration.sap.TestMain restoreSupplier
                Object resultObj = beanService.doMethod(CtSapService.class,"restoreSapSupplier",null);
                System.out.println(">>>result="+resultObj.toString());
            }else if ("createFakePart".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain createFakePart 30174401
                String partNumber = args[1];
                CtSapPartBo partBo = genFakePart(partNumber);
                Object[] params = new Object[1];
                params[0] = partBo;
                Object resultObj = beanService.doMethod(CtSapService.class,"createFakePart",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if ("createFakeBOM".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain createFakeBOM 30174401 0
                String bomNumber = args[1];
                String bomType = args[2];
                Object[] params = new Object[2];
                params[0] = bomNumber;
                params[1] =bomType;
                Object resultObj = beanService.doMethod(CtSapService.class,"createFakeBOM",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if ("createFakeECN".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain createFakeECN TEST-123
                String ecnNumber = args[1];
                String ecnDesc = args[2];
                String ecnReason = args[3];
                String effectTime = args[4];
                Object[] params = new Object[4];
                params[0] = ecnNumber;
                params[1] = ecnDesc;
                params[2] = ecnReason;
                params[3] = effectTime;
                Object resultObj = beanService.doMethod(CtSapService.class,"createFakeECN",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if ("createFakeMaterialKeepOrder".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain createFakeMaterialKeepOrder Z03 100022000999
                String orderType = args[1];
                String projectNumber = args[2];//订单号 对应项目编码
                Object[] params = new Object[2];
                params[0] = orderType;
                params[1] = projectNumber;
                Object resultObj = beanService.doMethod(CtSapService.class,"createFakeMaterialKeepOrder",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if("partStorage".equalsIgnoreCase(args[0])) {
                //查询物料库存 30028800 116020003 30069200 102010038
                //windchill ext.plm.integration.sap.TestMain partStorage 102010038
                Object[] params = new Object[1];
                String partNumber = args[1];
                params[0] = partNumber;
                Object resultObj = beanService.doMethod(CtSapService.class,"getPartStorageBo",params);
                CtSapPartStorageBo bo = (CtSapPartStorageBo) resultObj;
                System.out.println(">>>result= 库存："+ bo.getStorage()+",在制品数量 ："+bo.getStorageAtMake()
                +",PO:"+bo.getStorageAtPO()+",PR:"+bo.getStorageAtPR()+",Maintain:"+bo.getStorageAtMaintain()
                +",SaleOrder:"+bo.getStorageAtSaleOrder());
            }else if("partCost".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain partCost 101010014
                Object[] params = new Object[1];
                String partNumber = args[1];
                params[0] = partNumber;
                Object resultObj = beanService.doMethod(CtSapService.class,"queryPartCost",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if("bomQuery".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain bomQuery 30174402 20210915
                Object[] params = new Object[2];
                String partNumber = args[1];
                String bomUsage = args[2];
                params[0] = partNumber;
                params[1] = bomUsage;
                Object resultObj = beanService.doMethod(CtSapService.class,"queryBOM",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if("test".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain test 30174402 20210915
                System.out.println("===========CtHrMapper");
                String partNumber = args[1];
                CtHrMapper service = CtBeanFactory.newCtBeanFactory().getBean(CtHrMapper.class);
                String sumHourByMasterId = service.getDeptName("24124");
                System.out.println("sumHourByMasterId===="+sumHourByMasterId);
//                List<CtChipTypeBo> resultList = new ArrayList<>();
//                resultList = mapper.getChipTypeItems(partNumber);
//                System.out.println("===JSON.toJSONString(resultList)=="+JSON.toJSONString(resultList));
            }else if("genProjectNumber".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain genProjectNumber 30174402 20210915
                System.out.println("===========genProjectNumber");
                String projectNumber = args[1];
                Map<String,String> map=new HashMap<>();
                map.put("LV_KTEXT","测试项目名称");
                map.put("LV_PERSON_RESP","负责人wcadmin");
                map.put("LV_APPLICANT","申请人wcadmin");
                map.put("LV_APPLICANT_DATE","2022-01-23 23:59:59");
                map.put("LV_STARTDATE","2022-01-24 23:59:59");
                map.put("LV_ENDDATE","2022-01-25 23:59:59");
                CtSapAccess access = new CtSapAccess();
                CtSapResultBo sapResultBo = access.genProjectNumber(map,projectNumber,"I");
                System.out.println("JSON===="+JSON.toJSONString(sapResultBo));
            }else if("updateBom".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.sap.TestMain updateBom 30174402 d processNo ecnNumber bomType plant
                System.out.println("======开始执行更新BOM======");
               beanService.doMethod(CtSapService.class,"updateBom",args);
//                Object resultObj = service.updateBom(CtSapService.class,"updateBom",args);
                System.out.println("======更新成功======");
            }else{
                System.out.println("输入有误，没有此项功能："+args[0]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void test()throws Exception{

        String integrateData = "";
        while (integrateData.length() <4500){
            integrateData += "0123456789abcdefghij";
        }
        if(integrateData!=null && integrateData.length() >4000){
            integrateData = integrateData.substring(0,3900);
            integrateData = integrateData + "...(超长截断，完整数据查看log)";
        }
        System.out.println("integrateData = " + integrateData);
    }


    /**
     * 伪造Part数据
     * @return
     * @throws Exception
     */
    public static CtSapPartBo genFakePart(String partNumber) throws Exception{

        CtSapPartBo sapPartBo = new CtSapPartBo();
        sapPartBo.setBISMT("test0001");//旧物料号
        sapPartBo.setMATNR(partNumber);//物料编号 30174401
        sapPartBo.setMTART("Z030");//物料类型
        sapPartBo.setMAKTX("测试物料,"+partNumber);//物料描述
        sapPartBo.setMEINS(CtSapLogic.alignSapUnit("tong"));//基本计量单位
        sapPartBo.setMATKL("002011000");//物料组
        sapPartBo.setZMATNE("Test EN desc"+partNumber);//英文描述
        sapPartBo.setZMATNR("物料描述（研发）"+partNumber);//物料描述（研发）
        sapPartBo.setZMAKTX("销售描述"+partNumber);//销售描述
        sapPartBo.setSPART("06");//产品组
        sapPartBo.setEXTWG("外部物料组");//外部物料组
        sapPartBo.setZQCODE("");//器件库编码 选填，板件类必填
        sapPartBo.setZDIANS("324");//控制器点数
        sapPartBo.setZPROIN("产品关键特性");//产品关键特性
        sapPartBo.setLABOR("A");//优先级
        sapPartBo.setMSTAE("98");//跨工厂物料状态 2
        sapPartBo.setGROES("大小量纲");//大小/量纲(体积)
        sapPartBo.setZEINR("109025301");//文档号码(财务税收分类编码)
        sapPartBo.setZTEXT("物料长文本");//物料长文本 255
        sapPartBo.setWERKS("1001");//工厂 4
        sapPartBo.setVKORG("1001");//销售组织 4
        sapPartBo.setVTWEG("10");//分销渠道 2
        sapPartBo.setDWERK("1001");//交货工厂 4
        sapPartBo.setTAXM1("1");//税分类 1
        sapPartBo.setKTGRM("01");//科目设置组  2
        sapPartBo.setMTPOS("NORM");//项目类别组 4
        sapPartBo.setLADGR("0001");//装载组 4
        sapPartBo.setEKGRP("101");//采购组 3
        sapPartBo.setKAUTB("X");//标识: "允许自动采购订单" 1
        sapPartBo.setKORDB("X");//标识: 源清单要求  1
        sapPartBo.setART("");//检验类型 8
        sapPartBo.setMAABC("A");//库存ABC标识 1
        sapPartBo.setDISMM("PD");//MRP类型 2
        sapPartBo.setDISPO("P01");//物料需求计划控制员  公式计算
        sapPartBo.setDISLS("MB");//物料计划内批量程序（批量大小） 2
        sapPartBo.setBSTMI("");//最小批量
        sapPartBo.setAUSSS("0.21");//装配报废百分比
        sapPartBo.setBSTRF("0.21");//采购订单数量的舍入值
        sapPartBo.setBESKZ("");//采购类型(获取类型) 1
        sapPartBo.setSOBSL("");//特殊采购类型(特殊获取类型) 2
        sapPartBo.setRGEKZ("");//标识：反冲
        sapPartBo.setSCHGT("");//指示符：散装物料
        sapPartBo.setLGPRO("1001");//发货存储地点(生产仓储地点) 4
        sapPartBo.setLGFSB("1001");//外部采购的缺省仓储位置(外部采购仓储地点) 4
        sapPartBo.setFHORI("000");//浮动排产时间容余码(计划边际码) 3
        sapPartBo.setDZEIT("100");//厂内生产时间(自制生产时间)
        sapPartBo.setPLIFZ("30");//计划交货时间（天）
        sapPartBo.setWEBAZ("10");//以天计的收货处理时间
        sapPartBo.setEISBE("50000");//安全库存
        sapPartBo.setSTRGR("50");//计划策略组 2
        sapPartBo.setVRMOD("2");//消耗模式 1
        sapPartBo.setVINT1("999");//消耗期间:逆向 3
        sapPartBo.setVINT2("999");//消耗时期 3
        sapPartBo.setMTVFP("");//可用性检查 2
        sapPartBo.setSBDKZ("");//独立/集中标识 1 无
        sapPartBo.setKAUSF("0.13");//组件报废百分比 2
        sapPartBo.setKZAUS("");//中止指示符(非连续标识) 1
        sapPartBo.setAUSDT("2022-01-01");//中断日期(生效日期)
        sapPartBo.setNFMAT("");//后续物料
        sapPartBo.setFEVOR("");//生产管理员 3  公式计算
        sapPartBo.setSFCPF("");//生产计划参数文件 6 公式计算
        sapPartBo.setSERNP("");//序列号参数文件 4  选填
        sapPartBo.setAUSME("");//发货单位
        sapPartBo.setBKLAS("7920");//评估类 4
        sapPartBo.setMLAST("S");//物料价格确定: 控制 1
        sapPartBo.setVPRSV("S");//价格控制指示符 1
        sapPartBo.setSTPRS("10");//标准价格 11
        sapPartBo.setVERPR("10.5");//移动平均价格/周期单价
        sapPartBo.setPEINH("1");//价格单位 5
        sapPartBo.setEKALR("X");//成本估算 1
        sapPartBo.setHKMAT("X");//物料相关的源 1
        sapPartBo.setPRCTR("1000712000");// 利润中心 10

        return sapPartBo;
    }





}
