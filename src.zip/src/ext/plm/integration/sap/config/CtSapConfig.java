package ext.plm.integration.sap.config;

import com.sap.conn.jco.ext.DestinationDataEventListener;
import com.sap.conn.jco.ext.DestinationDataProvider;
import ext.plm.common.CtConstant;
import wt.util.WTException;

import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class CtSapConfig implements DestinationDataProvider {

    public static final String ProcessType_Create_Part = "Create Part"; //物料接口类型
    public static final String ProcessType_Disable_Part = "Disable Part"; //物料接口类型
    public static final String ProcessType_Update_Part = "Update Part"; //物料接口类型
    public static final String ProcessType_Create_BOM = "Create BOM";//创建BOM接口类型
    public static final String ProcessType_Change_BOM = "Update BOM";//更新BOM接口类型
    public static final String ProcessType_Create_KeepOrder = "Create KeepOrder";//创建预留单

    // 创建更改PART 函数名称
    public static final String PART_CREATE_UPDATE = "ZMM_PLM_001";

    //物料停用接口
    public static final String PART_DISABLE = "ZMM_PLM_001_DELETE";

    // 查询 PART 函数名称 （物料成本STPRS，采购价格VERPR）
    public static final String PART_QUERY = "ZMM_PLM_002";

    //物料库存查询
    public static final String PART_STORAGE_QUERY = "ZMM_PLM_003";

    // 物料成本查询 函数名称
    //public static final String PART_COST_QUERY = "ZFICO_PLM_001";

    // 创建BOM 函数名称
    public static final String BOM_CREATE_UPDATE = "ZPP_PLM_002";

    //判断集群物料在SAP是否存在
    public static final String ZPP_PLM_006 = "ZPP_PLM_006";

    // 查询BOM 函数名称
    public static final String BOM_QUERY = "ZPP_PLM_004";

    // 创建ECN 函数名称
    public static final String ECN_CREATE = "ZPP_PLM_003";

    // 创建领料/退料 预留单 函数名称
    public static final String MATERIAL_ORDER = "ZSD_CRM_011";

    //供应商查询
    public static final String SUPPLIER_QUERY = "ZMM_PLM_004";

    //集成项目编号
    public static final String PROJECT_NUMBER = "ZMM_PLM_005";

    //供应商/代理商
    public static final String AGENT_QUERY = "ZMM_PLM_006";

    //ZMM_PLM_007-PO/PR/MO查询
    public static final String ZMM_PLM_007 = "ZMM_PLM_007";

    //查询物料是否在SAP存在
    public static final String ZMM_PLM_010 = "ZMM_PLM_010";

    //通过物料编号、供应商编号查询价格
    public static final String ZMM_PLM_008 = "ZMM_PLM_008";

    //最小包装、采购单位、采购周期、研发环保认证要求、环保认证确认、来料方式推给sap
    public static final String ZMM_PLM_009 = "ZMM_PLM_009";

    public static final String ZSD_CRM_011 = "ZMM_PLM_011";  //"ZSD_CRM_011";

    //物料状态维护接口
    public static final String ZMM_PLM_013= "ZMM_PLM_013";

    //查询项目信息接口
    public static final String ZFICO_GETIORDER_TEST="http://apitest.sz-sanjiang.com/app/route/con/sap/v1/zfico_getiorder";
    public static final String ZFICO_GETIORDER_PRD="https://api.sz-sanjiang.com/app/route/con/sap/v1/zfico_getiorder";

    //查询仓位接口
    public static final String ZSD_CRM_DICC_TEST="http://apitest.sz-sanjiang.com/app/route/con/sap/v1/zsd_crm_dicc";
    public static final String ZSD_CRM_DICC_PRD="https://api.sz-sanjiang.com/app/route/con/sap/v1/zsd_crm_dicc";

    //查询产品成本
    public static final String ZFM_PLM_MM100_TEST="https://apitest.sz-sanjiang.com/app/sap/zfm_plm_mm100";
    public static final String ZFM_PLM_MM100_PRD="https://api.sz-sanjiang.com/app/sap/zfm_plm_mm100";

    //查询产品实际生产数量
    public static final String ZFM_PLM_PP100_TEST="http://apitest.sz-sanjiang.com/app/route/con/sap/zfm_plm_pp100";
    public static final String ZFM_PLM_PP100_PRD="https://api.sz-sanjiang.com/app/route/con/sap/zfm_plm_pp100";

    //查询供应商
    public static final String ZFM_PLM_MM106_TEST="http://apitest.sz-sanjiang.com/app/route/con/sap/zfm_plm_mm106";
    public static final String ZFM_PLM_MM106_PRD="https://api.sz-sanjiang.com/app/route/con/sap/zfm_plm_mm106";

    private DestinationDataEventListener eL;

    private Properties ABAP_AS_properties;

    private Properties sapConfig; //通用配置信息

    //加载配置
    public static Properties loadConfig() throws Exception {
        Properties prop = new Properties();
        prop.load(new InputStreamReader(CtSapConfig.class
                .getResourceAsStream("CtSapConfig.properties"), "UTF-8"));
        return prop;
    }

    //加载属性
    public static String getProperty(String key) throws Exception{
        Properties configProperties = loadConfig();
        String property = configProperties.getProperty(key);
        return property;
    }


    /**
     * 获取sap 连接信息
     *
     * @return
     * @throws Exception
     */
    public static Properties loadProperties() throws Exception {
        Properties prop = new Properties();
        if (CtConstant.isLocalEnv()) {

            prop.load(new InputStreamReader(CtSapConfig.class
                    .getResourceAsStream("CtSapConnection_test.properties"), "UTF-8"));
        } else if (CtConstant.isTestEnv()) {

            prop.load(new InputStreamReader(CtSapConfig.class
                    .getResourceAsStream("CtSapConnection_test.properties"), "UTF-8"));
        } else if (CtConstant.isPrdEnv()) {

            prop.load(new InputStreamReader(CtSapConfig.class
                    .getResourceAsStream("CtSapConnection_prd.properties"), "UTF-8"));
        } else {
            throw new WTException("无法确定当前的PLM环境，无法选择SAP对接系统！请检查host!");
        }
        return prop;
    }

    public Properties getDestinationProperties(String destinationName) {
        if (destinationName.equals("ABAP_AS") && ABAP_AS_properties != null) {
            return ABAP_AS_properties;
        } else {
            return null;
        }
    }

    public void setDestinationDataEventListener(DestinationDataEventListener eventListener) {
        this.eL = eventListener;
    }

    public boolean supportsEvents() {
        return true;
    }

    public void changePropertiesForABAP_AS(Properties properties) {
        if (properties == null) {
            eL.deleted("ABAP_AS");
            ABAP_AS_properties = null;
        } else {
            if (ABAP_AS_properties != null && !ABAP_AS_properties.equals(properties))
                eL.updated("ABAP_AS");
            ABAP_AS_properties = properties;
        }
    }

    /**
     * 获取SAP连接地址
     * @return
     * @throws Exception
     */
    public static String getSapHost() throws Exception{
        return loadProperties().getProperty("jco.client.ashost");
    }

    /**
     * 发SAP环保属性映射关系
     */
    public static final Map<String, String> ENVIRONMENT_PROTECTION_MAP = new HashMap<>();
    static{
        ENVIRONMENT_PROTECTION_MAP.put("RoHS+REACH", "01");
        ENVIRONMENT_PROTECTION_MAP.put("RoHS", "02");
        ENVIRONMENT_PROTECTION_MAP.put("REACH", "03");
        ENVIRONMENT_PROTECTION_MAP.put("无", "04");
    }
}
