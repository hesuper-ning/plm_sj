package ext.plm.integration.sap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.ec.CtEcQuery;
import ext.plm.ec.config.CtEcConstant;
import ext.plm.finance.bo.CtSapProductCostBo;
import ext.plm.integration.sap.bo.*;
import ext.plm.integration.sap.config.CtSapConfig;
import ext.plm.newec.helper.CtECRApprovalRecordsHelper;
import ext.plm.project.autocode.CtProjectAutoCodeHelper;
import ext.plm.project.autocode.bo.CtProjectNumberBo;
import ext.plm.project.autocode.dao.CtProjectNumberDAO;
import ext.plm.supplier.bo.CtSupplierInfoBo;
import ext.plm.util.*;
import org.apache.log4j.Logger;
import wt.change2.WTChangeRequest2;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.projmgmt.admin.Project2;
import wt.util.WTException;

import java.util.*;

/**
 * 此类作为集成接口的入口
 */
public class CtSapInterface {

    public static Logger logger = Logger.getLogger(CtSapInterface.class);

    //==============================开始  Part 部分====================================================

    /**
     * 创建物料
     *
     * @param processNo 流程编码，如“升级请求：0001”
     * @param part
     * @return
     * @throws Exception
     */
    public static CtSapResultBo createSapPart(String processNo, WTPart part) throws Exception {

        String partNumber = part.getNumber();
        logger.info("----------------------------------------------------");
        logger.info(">>>开始创建物料：" + partNumber + "," + CtVersionUtil.getVersionInfo(part));
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {

            CtSapPartBo partBo = CtSapLogic.genSapPartBo(part, true, false);

            String createFlag = "I";
            sapResultBo = createOrUpdateSapPart(processNo, partBo, createFlag);
            sapResultBo.setProcessType(CtSapConfig.ProcessType_Create_Part);
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！物料创建PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            CtSapQuery query = new CtSapQuery();
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！物料已创建！");
            CtSapQuery query = new CtSapQuery();
            try {
                //保存日志中间表,只保存成功的
                query.insertSapInfoToDb(sapResultBo);
            } catch (Exception e) {
                //日志保存失败不抛异常，只后台打印信息
                System.out.println("保存日志信息失败，不影响接口执行，不抛异常！");
                String SapResultBoJson = JSONObject.toJSONString(sapResultBo);
                System.out.println(">>>>SapResultBoJson=" + SapResultBoJson);
                e.printStackTrace();
            }
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }

    /**
     * 停用SAP物料
     *
     * @param processNo
     * @param part
     * @return
     * @throws Exception
     */
    public static CtSapResultBo disableSapPart(String processNo, WTPart part) throws Exception {

        String partNumber = part.getNumber();
        logger.info("----------------------------------------------------");
        logger.info(">>>开始停用物料：" + partNumber + "," + CtVersionUtil.getVersionInfo(part));
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {
            CtSapAccess sapAccess = new CtSapAccess();
            sapResultBo = sapAccess.disableSapPart(partNumber);
            //补充信息并保存至日志表
            sapResultBo.setProcessType(CtSapConfig.ProcessType_Disable_Part);
            sapResultBo.setProcessNo(processNo);
            sapResultBo.setIntegrateUrl(CtSapConfig.getSapHost());
            sapResultBo.setIntegrateData(partNumber);
            sapResultBo.setMainObject(partNumber);
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！物料停用PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            CtSapQuery query = new CtSapQuery();
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>物料停用成功！");
            CtSapQuery query = new CtSapQuery();
            try {
                //保存日志中间表,只保存成功的
                query.insertSapInfoToDb(sapResultBo);
            } catch (Exception e) {
                //日志保存失败不抛异常，只后台打印信息
                System.out.println("保存日志信息失败，不影响接口执行，不抛异常！");
                String SapResultBoJson = JSONObject.toJSONString(sapResultBo);
                System.out.println(">>>>SapResultBoJson=" + SapResultBoJson);
                e.printStackTrace();
            }
        } else {
            String failedInfo = sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }

    /**
     * 更新物料
     *
     * @param processNo 流程编码，如“升级请求：0001”
     * @param part
     * @return
     * @throws Exception
     */
    public static CtSapResultBo updateSapPart(String processNo, WTPart part, boolean isDefaultState) throws Exception {

        String partNumber = part.getNumber();
        logger.info("----------------------------------------------------");
        logger.info(">>>开始更新物料：" + partNumber + "," + CtVersionUtil.getVersionInfo(part));
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {
            CtSapPartBo partBo = CtSapLogic.genSapPartBo(part, false, isDefaultState);

            String createFlag = "U";
            sapResultBo = createOrUpdateSapPart(processNo, partBo, createFlag);
            sapResultBo.setProcessType(CtSapConfig.ProcessType_Update_Part);
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！物料更新PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            CtSapQuery query = new CtSapQuery();
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！物料已更新！");
            CtSapQuery query = new CtSapQuery();
            try {
                //保存日志中间表,只保存成功的
                query.insertSapInfoToDb(sapResultBo);
            } catch (Exception e) {
                //日志保存失败不抛异常，只后台打印信息
                System.out.println("保存日志信息失败，不影响接口执行，不抛异常！");
                String SapResultBoJson = JSONObject.toJSONString(sapResultBo);
                System.out.println(">>>>SapResultBoJson=" + SapResultBoJson);
                e.printStackTrace();
            }
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }


    /**
     * 创建物料
     *
     * @param processNo  流程编码，如“升级请求：0001”
     * @param partBo
     * @param updateFlag 修改标识， I,U,D
     * @return
     * @throws Exception
     */
    public static CtSapResultBo createOrUpdateSapPart(String processNo, CtSapPartBo partBo, String updateFlag) throws Exception {


        String partJson = JSON.toJSON(partBo).toString();
        logger.info(">>>物料信息=" + partJson);
        CtSapAccess access = new CtSapAccess();
        CtSapResultBo sapResultBo = access.createOrUpdateSapPart(partBo, updateFlag);

        //补充信息并保存至日志表
        sapResultBo.setProcessNo(processNo);
        sapResultBo.setIntegrateUrl(CtSapConfig.getSapHost());
        sapResultBo.setIntegrateData(partJson);
        sapResultBo.setMainObject(partBo.getMATNR());

        return sapResultBo;
    }


    /**
     * 查询SAP物料库存（单一库存，多库存请用另外一个返回storageBo方法）
     *
     * @param partNumber
     * @return
     * @throws Exception
     */
    public static String getPartTotalStorage(String partNumber) throws Exception {

        String partStorage = "0";
        try {
            CtSapAccess access = new CtSapAccess();
            CtSapResultBo sapResultBo = access.queryPartInfo(partNumber);

            String resultInfo = sapResultBo.getResponseMsg();

            JSONArray array = JSONArray.parseArray(resultInfo);
            if (array.size() > 0) {
                JSONObject jsonObject = (JSONObject) array.get(0);
                partStorage = jsonObject.getString("storage");
            }

            if (!sapResultBo.getResponseCode().equalsIgnoreCase("S")) {
                throw new WTException("查询物料库存失败! SAP返回信息：" + sapResultBo.getErrorMsg());
            }
        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("查询物料库存失败!PLM端异常：" + e.getLocalizedMessage());
        }

        return partStorage;
    }

    /**
     * 查询物料库存、在制品数量等
     *
     * @param partNumber
     * @return
     * @throws Exception
     */
    public static CtSapPartStorageBo getPartStorage(String partNumber) throws Exception {

        CtSapPartStorageBo sapPartStorageBo = new CtSapPartStorageBo();
        try {
            CtSapAccess access = new CtSapAccess();
            CtSapResultBo sapResultBo = access.queryPartStorage(partNumber);
            System.out.println("===sapResultBo====" + JSON.toJSONString(sapResultBo));
            String resultInfo = sapResultBo.getResponseMsg();

            JSONArray array = JSONArray.parseArray(resultInfo);
            if (CtFormatUtil.hasContent(array) && array.size() > 0) {
                JSONObject jsonObject = (JSONObject) array.get(0);
                String partStorage = jsonObject.getString("storage");
                sapPartStorageBo.setStorage(partStorage);
                String partStorageAtMake = jsonObject.getString("storageAtMake");//在制品数量
                sapPartStorageBo.setStorageAtMake(partStorageAtMake);

                String partStorageAtPO = jsonObject.getString("storageAtPO");//采购订单PO数量
                sapPartStorageBo.setStorageAtPO(partStorageAtPO);

                String partStorageAtPR = jsonObject.getString("storageAtPR");//在外采购PR数量
                sapPartStorageBo.setStorageAtPR(partStorageAtPR);

                String partStorageAtMaintain = jsonObject.getString("storageAtMaintain");//维修周转品数量
                sapPartStorageBo.setStorageAtMaintain(partStorageAtMaintain);

                String partStorageAtSaleOrder = jsonObject.getString("storageAtSaleOrder");//销售订单量
                sapPartStorageBo.setStorageAtSaleOrder(partStorageAtSaleOrder);

                String orderUnit = jsonObject.getString("orderUnit");//采购订单计量单位
                sapPartStorageBo.setOrderUnit(orderUnit);

                String oneYearShipped = jsonObject.getString("oneYearShipped");//已发货（一年内）
                sapPartStorageBo.setOneYearShipped(oneYearShipped);

                String monthlyConsumption = jsonObject.getString("monthlyConsumption");//每月平均耗用量
                sapPartStorageBo.setMonthlyConsumption(monthlyConsumption);
            }

            if (!sapResultBo.getResponseCode().equalsIgnoreCase("S")) {
                String errorMsg = sapResultBo.getErrorMsg();
                if (errorMsg.contains("物料号不存在")) {
                    sapPartStorageBo.setNumberIsNull(true);
                } else {
                    throw new WTException("查询物料库存失败! SAP返回信息：" + errorMsg);
                }
            }
        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("查询物料库存失败!PLM端异常：" + e.getLocalizedMessage());
        }

        return sapPartStorageBo;
    }

    /**
     * 查询物料成本
     *
     * @param partNumber
     * @return JSON格式 {'costPrice':成本价格, 'buyPrice':采购价格,'priceFlag':价格标识符}
     * @throws Exception
     */
    public static String queryPartCost(String partNumber) throws Exception {

        JSONObject costResult = new JSONObject();
        try {
            CtSapAccess access = new CtSapAccess();
            CtSapResultBo sapResultBo = access.queryPartInfo(partNumber);
            String resultInfo = sapResultBo.getResponseMsg();

            JSONArray array = JSONArray.parseArray(resultInfo);
            if (array.size() > 0) {
                JSONObject jsonObject = (JSONObject) array.get(0);
                costResult.put("costPrice", jsonObject.getString("costPrice"));
                costResult.put("buyPrice", jsonObject.getString("buyPrice"));
                costResult.put("priceFlag", jsonObject.getString("priceFlag"));
            } else {
                //查不到，但接口没异常，给0
                costResult.put("costPrice", "0");
                costResult.put("buyPrice", "0");
                costResult.put("priceFlag", "查询无结果");
            }

            if (!sapResultBo.getResponseCode().equalsIgnoreCase("S")) {
                throw new WTException("查询物料成本失败! SAP返回信息：" + sapResultBo.getErrorMsg());
            }
        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("查询物料成本失败!PLM端异常：" + e.getLocalizedMessage());
        }
        return costResult.toJSONString();
    }

    //==============================结束  Part 部分====================================================

    //==============================开始  BOM 部分====================================================


    /**
     * 创建 BOM
     *
     * @param processNo
     * @param bomPart
     * @param bomType   BOM类型，1为生产BOM， 2为试产BOM
     * @param plant     工厂
     * @return
     * @throws Exception
     */
    public static CtSapResultBo createSapBOM(String processNo, WTPart bomPart, String bomType, String plant, List<String> bomList) throws Exception {

        String bomNumber = bomPart.getNumber();
        logger.info("----------------------------------------------------");
        logger.info(">>>开始创建BOM：" + bomNumber + "," + CtVersionUtil.getVersionInfo(bomPart) + "," + plant);
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {
            String createFlag = "I";
            //组装头信息
            Map<String, String> bomHeadInfoMap = new HashMap<>();
            bomHeadInfoMap.put("bomNumber", bomNumber);
            bomHeadInfoMap.put("updateFlag", createFlag);  //更新标识， I 添加， U 更新
            String unit = bomPart.getDefaultUnit().toString();
            unit = CtSapLogic.alignSapUnit(unit);
            bomHeadInfoMap.put("unit", unit); //单位
            bomHeadInfoMap.put("ecnNumber", ""); //创建不需要ECN
            bomHeadInfoMap.put("bomType", bomType);
            bomHeadInfoMap.put("plant", plant);
            String bomHeadInfo = JSON.toJSON(bomHeadInfoMap).toString();
            logger.info(">>>创建 BOM Head：" + bomHeadInfo);
            //刷新替代组比例
            CtSapLogic.toReRefreshReplaceGroup(bomPart);
            List<CtSapBomItemBo> bomItems = null;
            if (bomType.equals("0")) {
                //样机BOM不发送下阶未发SAP的物料（因此变更时也走发布接口，需要手动删除SAP中的样机BOM）
                bomItems = CtSapLogic.genSapSampleBomItemList(bomPart, bomList);
            } else if (bomType.equals("2")) {
                //试产
                bomItems = CtSapLogic.genSapTrialBomItemList(bomPart, bomList);
            } else if (bomType.equals("1")) {
                //量产
                bomItems = CtSapLogic.genSapMassProductionBomItemList(bomPart, bomList);
            }

            String bomItemInfo = ((JSONArray) JSON.toJSON(bomItems)).toJSONString();
            logger.info(">>>创建 BOMItems：" + bomItemInfo);

            sapResultBo = createSapBOM(bomHeadInfoMap, bomItems);

            //补充信息
            sapResultBo.setProcessNo(processNo);
            sapResultBo.setIntegrateData(bomHeadInfo + "|" + bomItemInfo);
            sapResultBo.setProcessType(CtSapConfig.ProcessType_Create_BOM);
            sapResultBo.setMainObject(bomPart.getNumber());
            sapResultBo.setIntegrateUrl(CtSapConfig.getSapHost());
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！BOM创建PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            CtSapQuery query = new CtSapQuery();
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！BOM已创建！");
            CtSapQuery query = new CtSapQuery();
            try {
                //保存日志中间表,只保存成功的
                query.insertSapInfoToDb(sapResultBo);
            } catch (Exception e) {
                //日志保存失败不抛异常，只后台打印信息
                System.out.println("保存日志信息失败，不影响接口执行，不抛异常！");
                String SapResultBoJson = JSONObject.toJSONString(sapResultBo);
                System.out.println(">>>>SapResultBoJson=" + SapResultBoJson);
                e.printStackTrace();
            }
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }

    /**
     * 创建 BOM
     *
     * @param bomHeadInfoMap key包含（bomNumber:BOM编码，updateFlag：更改标识， ecnNumber：变更编号，unit:单位，bomType:bom类型，plant：工厂）
     * @param bomItems
     * @return
     * @throws Exception
     */
    public static CtSapResultBo createSapBOM(Map<String, String> bomHeadInfoMap, List<CtSapBomItemBo> bomItems) throws Exception {
        CtSapAccess access = new CtSapAccess();
        CtSapResultBo sapResultBo = access.createOrUpdateSapBom(bomHeadInfoMap, bomItems);
        return sapResultBo;
    }


    /**
     * 更新 BOM
     *
     * @param processNo
     * @param ecnNumber
     * @param bomPart
     * @param bomType   BOM类型，1为生产BOM， 2为试产BOM
     * @param plant     工厂
     * @return
     * @throws Exception
     */
    public static CtSapResultBo changeSapBOM(String processNo, String ecnNumber, WTPart bomPart, String bomType, String plant, List<String> bomNumList) throws Exception {
        IBAUtil ibaUtil = new IBAUtil(bomPart);
        String bomNumber = bomPart.getNumber();
        logger.info("----------------------------------------------------");
        logger.info(">>>开始更新BOM：" + bomNumber + "," + CtVersionUtil.getVersionInfo(bomPart) + "," + plant + ">>>ECN:" + ecnNumber);
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {

            String ct_historicaldata = ibaUtil.getIBAValue("ct_historicaldata");
            String createFlag = "I";

            //组装头信息
            Map<String, String> bomHeadInfoMap = new HashMap<>();
            bomHeadInfoMap.put("bomNumber", bomNumber);
            bomHeadInfoMap.put("updateFlag", "U");  //更新标识， I 添加， U 更新
            String unit = bomPart.getDefaultUnit().toString();
            unit = CtSapLogic.alignSapUnit(unit);
            bomHeadInfoMap.put("unit", unit); //单位
            bomHeadInfoMap.put("ecnNumber", ecnNumber);
            bomHeadInfoMap.put("bomType", bomType);
            bomHeadInfoMap.put("plant", plant);
            String bomHeadInfo = JSON.toJSON(bomHeadInfoMap).toString();
            logger.info(">>>更新 BOM Head：" + bomHeadInfo);
            //刷新替代组比例
            CtSapLogic.toReRefreshReplaceGroup(bomPart);
            //特殊逻辑处理,处理sap历史数据扩倍问题
            List<CtSapBomItemBo> bomItems = new ArrayList<>();
            if (CtFormatUtil.hasContent(ct_historicaldata) && "是".equals(ct_historicaldata.trim())) {
                bomItems = CtSapLogic.genSapHistoryChangeBomItemList(bomPart, bomType, bomNumList);
            } else {
                bomItems = CtSapLogic.genSapChangeBomItemList(bomPart, bomType, bomNumList);
            }
            String bomItemInfo = ((JSONArray) JSON.toJSON(bomItems)).toJSONString();
            logger.info(">>>更新 BOMItems：" + bomItemInfo);

            sapResultBo = changeSapBOM(bomHeadInfoMap, bomItems);

            //补充信息
            sapResultBo.setProcessNo(processNo);
            sapResultBo.setIntegrateData(bomHeadInfo + "|" + bomItemInfo);
            sapResultBo.setProcessType(CtSapConfig.ProcessType_Change_BOM);
            sapResultBo.setMainObject(bomPart.getNumber());
            sapResultBo.setIntegrateUrl(CtSapConfig.getSapHost());
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！BOM更新PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            CtSapQuery query = new CtSapQuery();
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！BOM更新成功！");

            CtSapQuery query = new CtSapQuery();
            try {
                //保存日志中间表,只保存成功的
                query.insertSapInfoToDb(sapResultBo);
            } catch (Exception e) {
                //日志保存失败不抛异常，只后台打印信息
                System.out.println("保存日志信息失败，不影响接口执行，不抛异常！");
                String SapResultBoJson = JSONObject.toJSONString(sapResultBo);
                System.out.println(">>>>SapResultBoJson=" + SapResultBoJson);
                e.printStackTrace();
            }
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }

    /**
     * 更新 BOM
     *
     * @param processNo
     * @param ecnNumber
     * @param bomPart
     * @param bomType   BOM类型，1为生产BOM， 2为试产BOM
     * @param plant     工厂
     * @return
     * @throws Exception
     */
    public static CtSapResultBo changeSapBOM2(String processNo, String ecnNumber, WTPart bomPart, String bomType, String plant, List<String> bomNumList) throws Exception {
        IBAUtil ibaUtil = new IBAUtil(bomPart);
        String bomNumber = bomPart.getNumber();
        logger.info("----------------------------------------------------");
        logger.info(">>>开始更新BOM：" + bomNumber + "," + CtVersionUtil.getVersionInfo(bomPart) + "," + plant + ">>>ECN:" + ecnNumber);
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {

            //组装头信息
            Map<String, String> bomHeadInfoMap = new HashMap<>();
            bomHeadInfoMap.put("bomNumber", bomNumber);
            bomHeadInfoMap.put("updateFlag", "U");  //更新标识， I 添加， U 更新
            String unit = bomPart.getDefaultUnit().toString();
            unit = CtSapLogic.alignSapUnit(unit);
            bomHeadInfoMap.put("unit", unit); //单位
            bomHeadInfoMap.put("ecnNumber", ecnNumber);
            bomHeadInfoMap.put("bomType", bomType);
            bomHeadInfoMap.put("plant", plant);
            String bomHeadInfo = JSON.toJSON(bomHeadInfoMap).toString();
            logger.info(">>>更新 BOM Head：" + bomHeadInfo);
            //刷新替代组比例
            CtSapLogic.toReRefreshReplaceGroup(bomPart);
            //特殊逻辑处理,处理sap历史数据扩倍问题
            List<CtSapBomItemBo> bomItems = new ArrayList<>();

            bomItems = CtSapLogic.genSapHistoryChangeBomItemList(bomPart, bomType, bomNumList);

            String bomItemInfo = ((JSONArray) JSON.toJSON(bomItems)).toJSONString();
            logger.info(">>>更新 BOMItems：" + bomItemInfo);

            sapResultBo = changeSapBOM(bomHeadInfoMap, bomItems);

            //补充信息
            sapResultBo.setProcessNo(processNo);
            sapResultBo.setIntegrateData(bomHeadInfo + "|" + bomItemInfo);
            sapResultBo.setProcessType(CtSapConfig.ProcessType_Change_BOM);
            sapResultBo.setMainObject(bomPart.getNumber());
            sapResultBo.setIntegrateUrl(CtSapConfig.getSapHost());
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！BOM更新PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            CtSapQuery query = new CtSapQuery();
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！BOM更新成功！");

            CtSapQuery query = new CtSapQuery();
            try {
                //保存日志中间表,只保存成功的
                query.insertSapInfoToDb(sapResultBo);
            } catch (Exception e) {
                //日志保存失败不抛异常，只后台打印信息
                System.out.println("保存日志信息失败，不影响接口执行，不抛异常！");
                String SapResultBoJson = JSONObject.toJSONString(sapResultBo);
                System.out.println(">>>>SapResultBoJson=" + SapResultBoJson);
                e.printStackTrace();
            }
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }

    /**
     * 更新 BOM
     *
     * @param bomHeadInfoMap key包含（bomNumber:BOM编码，updateFlag：更改标识， ecnNumber：变更编号，unit:单位，bomType:bom类型，plant：工厂）
     * @param bomItems
     * @return
     * @throws Exception
     */
    public static CtSapResultBo changeSapBOM(Map<String, String> bomHeadInfoMap, List<CtSapBomItemBo> bomItems) throws Exception {

        CtSapAccess access = new CtSapAccess();
        CtSapResultBo sapResultBo = access.createOrUpdateSapBom(bomHeadInfoMap, bomItems);
        return sapResultBo;
    }

    /**
     * 查询BOM
     *
     * @param partNumber
     * @param bomUsage
     * @return
     * @throws Exception
     */
    public static String queryBOM(String partNumber, String bomUsage) throws Exception {

        CtSapAccess access = new CtSapAccess();
        CtSapResultBo sapResultBo = access.queryBOM(partNumber, bomUsage, false);
        return sapResultBo.getResponseCode() + "|" + sapResultBo.getErrorMsg() + "|查询结果：" + sapResultBo.getResponseMsg();
    }


    //==============================结束  BOM 部分====================================================

    //==============================开始  ECN 部分====================================================


    /**
     * 创建 ECN
     *
     * @param part
     * @return
     * @throws Exception
     */
    public static CtSapResultBo createSapECN(WTPart part, String ecnNumber) throws Exception {

        logger.info("----------------------------------------------------");
        logger.info(">>>开始创建ECN：" + ecnNumber);
        logger.info(">>>物料自身流程：" + part.getNumber());
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {
            Date date = new Date();
            String format = CtDateUtil.parseDate(date, "yyyyMMdd", "GMT+8");
            CtSapAccess access = new CtSapAccess();
            Map<String, String> ecnMap = new HashMap<>();
            ecnMap.put("ecnDesc", "样机BOM");  //更改描述
            ecnMap.put("ecnReason", "样机BOM"); //更改原因
            ecnMap.put("effectDate", format); //生效时间

            sapResultBo = access.createECN(ecnNumber, ecnMap);
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！ECN创建PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！ECN已创建！");
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }

    /**
     * 创建 ECN
     *
     * @param ecr
     * @return
     * @throws Exception
     */
    public static CtSapResultBo createSapECN(WTChangeRequest2 ecr, String processNo) throws Exception {

        logger.info("----------------------------------------------------");
        logger.info(">>>开始创建ECN：" + ecr.getNumber());
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {

            CtSapAccess access = new CtSapAccess();

            ReferenceFactory rf = new ReferenceFactory();
            String changeRequestId = rf.getReferenceString(ecr);
            String ecrType = CtWTObjectUtil.getLeafTypeIdentifier(ecr);

            String ecnDesc = "";
            String ecnReason = "";
            String effectDate = "";
            if(ecrType.equals(CtEcConstant.Ct_EcrType_ProductionEC)){
                //旧的变更
                CtEcQuery query = new CtEcQuery();
                ecnDesc = query.getAttributeValue(changeRequestId, "head_changeDesc");
                ecnReason = query.getAttributeValue(changeRequestId, "head_changeReason");
                effectDate = query.getAttributeValue(changeRequestId, "mCaMCM_bomChangeEffectTime");//BOM更改生效时间
            }else{
                //新的变更
                ecnReason = CtECRApprovalRecordsHelper.getAttributeValue(changeRequestId, "changeReason");
                ecnDesc = ecnReason;
                effectDate = CtECRApprovalRecordsHelper.getAttributeValue(changeRequestId, "materialControlFeedback");//BOM更改生效时间
            }
            if (CtFormatUtil.hasContent(effectDate) && effectDate.length() >= 10) {
                effectDate = effectDate.substring(0, 10); //截断只有年月日，例“2021-11-24”
                effectDate = effectDate.replaceAll("-", ""); //转换成“yyyyMMdd”格式，例“20211124”
            }

            Map<String, String> ecnMap = new HashMap<>();
            //PLM这边将更改原因与更改描述合并为更改原因描述，同步为SAP那边两个字段
            ecnMap.put("ecnDesc", ecnDesc);  //更改描述
            ecnMap.put("ecnReason", ecnReason); //更改原因
            ecnMap.put("effectDate", effectDate); //生效时间

            sapResultBo = access.createECN(ecr.getNumber(), ecnMap);
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！ECN创建PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！ECN已创建！");
        } else {
            String errorMsg = sapResultBo.getErrorMsg();
            //变更单号已存在的时候,代表同一个ECR下面,吞异常
            if (CtFormatUtil.hasContent(errorMsg) && errorMsg.contains("更改号") && errorMsg.contains("已经存在")) {
                String failedInfo = ">>>代码跳过失败节点！ECN创建SAP端异常信息：" + errorMsg;
                logger.info(failedInfo);
            } else {
                String failedInfo = ">>>失败！" + errorMsg;
                System.out.println(failedInfo);
                logger.info(failedInfo);
                throw new WTException(failedInfo);//Sap端异常
            }
        }
        return sapResultBo;
    }

    /**
     * 创建 ECN
     *
     * @param ecr
     * @return
     * @throws Exception
     */
    public static CtSapResultBo createSapECN(Map<String, String> ecr, String processNo) throws Exception {

        logger.info("----------------------------------------------------");
        logger.info(">>>开始创建ECN：" + ecr.get("number"));
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {

            CtSapAccess access = new CtSapAccess();

            ReferenceFactory rf = new ReferenceFactory();
            String ecnDesc = ecr.get("ecnDesc");
            String ecnReason = ecr.get("ecnReason");
            String effectDate = ecr.get("effectDate");
            if (CtFormatUtil.hasContent(effectDate) && effectDate.length() >= 10) {
                effectDate = effectDate.substring(0, 10); //截断只有年月日，例“2021-11-24”
                effectDate = effectDate.replaceAll("-", ""); //转换成“yyyyMMdd”格式，例“20211124”
            }

            Map<String, String> ecnMap = new HashMap<>();
            ecnMap.put("ecnDesc", ecnDesc);  //更改描述
            ecnMap.put("ecnReason", ecnReason); //更改原因
            ecnMap.put("effectDate", effectDate); //生效时间

            sapResultBo = access.createECN(ecr.get("number"), ecnMap);
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！ECN创建PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！ECN已创建！");
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }

    //==============================结束  ECN 部分====================================================


    //================================预留单 开始=====================================================


    /**
     * 创建 预留单
     *
     * @param orderBo       单据头信息
     * @param materialItems 物料明细项 key包含（partNumber：物料号，amount：数量）
     * @param processNo     流程号
     * @return
     * @throws Exception
     */
    public static CtSapResultBo createMaterialKeepOrder(CtSapMaterialKeepOrderBo orderBo, List<Map<String, String>> materialItems, String processNo) throws Exception {

        logger.info("----------------------------------------------------");
        logger.info(">>>开始创建预留单：" + orderBo.getBWART() + "|" + orderBo.getAUFNR());
        logger.info(">>>预留单信息" + JSON.toJSONString(orderBo) + ">>>materialItems:" + JSON.toJSONString(materialItems));
        logger.info(">>>流程：" + processNo);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {

            CtSapAccess access = new CtSapAccess();
            sapResultBo = access.createMaterialKeepOrder(orderBo, materialItems);
            String headJson = ((JSONObject) JSON.toJSON(orderBo)).toJSONString();
            String itemJson = ((JSONArray) JSON.toJSON(materialItems)).toJSONString();
            sapResultBo.setIntegrateData(headJson + ">>>" + itemJson);
            sapResultBo.setMainObject("MaterialKeepOrder");
            sapResultBo.setProcessNo(processNo);
            sapResultBo.setProcessType(CtSapConfig.ProcessType_Create_KeepOrder);
            sapResultBo.setIntegrateUrl(CtSapConfig.getSapHost());
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！预留单创建PLM端异常信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            CtSapQuery query = new CtSapQuery();
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            throw new WTException(failedInfo); //PLM端收集数据异常
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！预留单已创建！");
            CtSapQuery query = new CtSapQuery();
            try {
                //保存日志中间表,只保存成功的
                query.insertSapInfoToDb(sapResultBo);
            } catch (Exception e) {
                //日志保存失败不抛异常，只后台打印信息
                System.out.println("保存日志信息失败，不影响接口执行，不抛异常！");
                String SapResultBoJson = JSONObject.toJSONString(sapResultBo);
                System.out.println(">>>>SapResultBoJson=" + SapResultBoJson);
                e.printStackTrace();
            }
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }
        return sapResultBo;
    }

    //================================预留单 结束=====================================================

    //================================供应商 开始=====================================================

    /**
     * 查询全量供应商
     *
     * @return
     * @throws Exception
     */
    public static List<CtSupplierInfoBo> getSupplierInfo() throws Exception {

        List<CtSupplierInfoBo> supplierList = new ArrayList<>();
        try {
            CtSapAccess access = new CtSapAccess();
            CtSapResultBo sapResultBo = access.querySupplierInfo();

            if (!sapResultBo.getResponseCode().equalsIgnoreCase("S")) {
                throw new WTException(sapResultBo.getErrorMsg());
            }

            String resultInfo = sapResultBo.getResponseMsg();

            JSONArray array = JSONArray.parseArray(resultInfo);
            CtSupplierInfoBo supplierBo = null;
            for (int i = 0; i < array.size(); i++) {
                JSONObject jsonObject = (JSONObject) array.get(i);
                supplierBo = new CtSupplierInfoBo();
                String supplierCode = jsonObject.getString("supplierCode");//供应商编号
                supplierBo.setSupplierCode(supplierCode);
                supplierBo.setUserName(supplierCode);//用编号做用户名

                String supplierName = jsonObject.getString("supplierName");//供应商名称
                supplierBo.setSupplierName(supplierName);

                String supplierEmail = jsonObject.getString("supplierEmail");//供应商邮件
                supplierBo.setSupplierEmail(supplierEmail);

                supplierList.add(supplierBo);
            }
        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("查询供应商失败!PLM端异常：" + e.getLocalizedMessage());
        }

        return supplierList;
    }


    //================================供应商 结束=====================================================
    //================================项目编码 开始=====================================================

    /**
     * 创建 项目编号
     *
     * @param project 项目
     * @return
     * @throws Exception
     */
    public static CtSapResultBo genProjectNumber(Project2 project, String proNum) throws Exception {

        logger.info("----------------------------------------------------");
        logger.info(">>>开始创建项目编号：" + proNum);
        CtSapResultBo sapResultBo = new CtSapResultBo();

        try {

            CtSapAccess access = new CtSapAccess();
            sapResultBo = access.genOrUpdateProjectNumber(project, proNum, "I", "");
            String errorMsg = sapResultBo.getErrorMsg();
            //如果是订单号已存在问题自动累加，吞异常
            if (CtFormatUtil.hasContent(errorMsg)) {
                if (errorMsg.contains("订单") && errorMsg.contains("已存在")) {
                    String suffix = proNum.substring(proNum.length() - 3);
                    String prefix = proNum.substring(0, proNum.length() - 3);
                    //回溯，如果是订单号已存在报错往上+1继续传sap
                    suffix = CtProjectAutoCodeHelper.getInstance().incrementSerialNumber(suffix);
                    genProjectNumber(project, prefix + suffix);
                } else {
                    throw new WTException(errorMsg); //PLM端收集数据异常
                }
            } else {
                project = (Project2) PersistenceHelper.manager.refresh(project);
                if (!project.getProjectNumber().equals(proNum)) {
                    project.setProjectNumber(proNum);
                    project = (Project2) PersistenceHelper.manager.save(project);
                    //更新完编码插入到中间表
                    CtProjectNumberDAO ctProjectNumberDAO = CtBeanFactory.newCtBeanFactory().getBean(CtProjectNumberDAO.class);
                    CtProjectNumberBo ctProjectNumberBo = new CtProjectNumberBo(project.getPersistInfo().getObjectIdentifier().getId(), proNum);
                    ctProjectNumberDAO.insertRecord(ctProjectNumberBo);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            String failedInfo = ">>>失败！创建项目编号失败信息：" + e.getLocalizedMessage();
            logger.info(failedInfo);
            sapResultBo.setErrorMsg(failedInfo);
            sapResultBo.setIntegrateFlag(false);
            if (failedInfo.contains("remote")) {
                failedInfo = failedInfo + "\n\r【SAP集成接口异常，请联系PLM系统管理员及ERP系统管理员处理】";
            }

            throw new WTException(failedInfo); //PLM端收集数据异常

        }
        return sapResultBo;
    }

    /**
     * 更新项目编号
     *
     * @param pro 项目
     * @return
     * @throws Exception
     */
    public static CtSapResultBo updateProjectNumber(Project2 pro, String endTime) throws Exception {

        logger.info("----------------------------------------------------");
        logger.info(">>>开始集成项目结束时间：" + pro.getProjectNumber());
        CtSapResultBo sapResultBo = new CtSapResultBo();
        CtSapAccess access = new CtSapAccess();
        sapResultBo = access.genOrUpdateProjectNumber(pro, pro.getProjectNumber(), "U", endTime);
        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>成功！项目结束时间集成完成！");
        } else {
            String failedInfo = ">>>失败！" + sapResultBo.getErrorMsg();
            System.out.println(failedInfo);
            logger.info(failedInfo);
            throw new WTException(failedInfo);//Sap端异常
        }

        return sapResultBo;
    }


    //================================项目编码 结束=====================================================


    //================================根据物料编码查询供应商 开始=====================================================

    /**
     * 物料编码查询供应商
     *
     * @return
     * @throws Exception
     */
    public static List<CtPartSupplierBo> querySupplierInfoByPartNumber(String partNumber) throws Exception {

        List<CtPartSupplierBo> supplierList = new ArrayList<>();
        try {
            CtSapAccess access = new CtSapAccess();
            CtSapResultBo sapResultBo = access.querySupplierInfoByPartNumber(partNumber);

            if (!sapResultBo.getResponseCode().equalsIgnoreCase("S")) {
                return supplierList;
                //throw new WTException(sapResultBo.getErrorMsg());
            }
            CtPartSupplierBo supplierBo = null;
            String resultInfo = sapResultBo.getResponseMsg();
            JSONArray array = JSONArray.parseArray(resultInfo);
            for (int i = 0; i < array.size(); i++) {
                JSONObject jsonObject = (JSONObject) array.get(i);
                supplierBo = new CtPartSupplierBo();

                String supplierCode = jsonObject.getString("supplierAccountNumber");//供应商编号
                supplierBo.setSupplierAccountNumber(supplierCode);

                String supplierName = jsonObject.getString("supplierName");//供应商名称
                supplierBo.setSupplierName(supplierName);

                String supplierEmail = jsonObject.getString("supplierEmail");//供应商邮件
                supplierBo.setSupplierEmail(supplierEmail);

                String partNumberSAP = jsonObject.getString("partNumber");//物料编号
                supplierBo.setPartNumber(partNumberSAP);
                supplierList.add(supplierBo);
            }


        } catch (WTException wte) {
            wte.printStackTrace();
            throw wte;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("查询供应商失败!PLM端异常：" + e.getLocalizedMessage());
        }

        return supplierList;
    }

    //================================根据物料编码查询供应商 结束=====================================================

    /**
     * 通过工单编号查询工单数量
     *
     * @param mo
     * @return
     * @throws Exception
     */
    public static Map<String, String> queryQuantityByMo(String mo) throws Exception {
        logger.info("----------------------------------------------------");
        logger.info(">>>开始集成 工单号：" + mo);
        Map<String, String> map = new HashMap<>();
        String quantity = "";
        try {
            CtSapAccess access = new CtSapAccess();
            map = access.queryQuantityByMo(mo);
            logger.info(">>>成功！通过工单编号查询工单数量集成完成！" + quantity);
        } catch (Exception e) {
            logger.info(">>>通过工单编号查询工单数量失败！", e);
            throw e;
        }
        return map;
    }

    /**
     * 通过po查询物料信息
     *
     * @param po
     * @return
     * @throws Exception
     */
    public static JSONArray queryPartsByPo(String po) throws Exception {
        logger.info("----------------------------------------------------");
        logger.info(">>>开始集成 po：" + po);
        JSONArray jsonArray = new JSONArray();
        try {
            CtSapAccess access = new CtSapAccess();
            jsonArray = access.queryPartsByPo(po);
            logger.info(">>>成功！通过po查询物料信息集成完成！" + jsonArray.toJSONString());
        } catch (Exception e) {
            logger.info(">>>通过po查询物料信息失败！", e);
            throw e;
        }
        return jsonArray;
    }

    /**
     * 通过pr查询物料信息
     *
     * @param pr
     * @return
     * @throws Exception
     */
    public static JSONArray queryPartsByPr(String pr) throws Exception {
        logger.info("----------------------------------------------------");
        logger.info(">>>开始集成 pr：" + pr);
        JSONArray jsonArray = new JSONArray();
        try {
            CtSapAccess access = new CtSapAccess();
            jsonArray = access.queryPartsByPr(pr);
            logger.info(">>>成功！通过pr查询物料信息集成完成！" + jsonArray.toJSONString());
        } catch (Exception e) {
            logger.info(">>>通过pr查询物料信息失败！", e);
            throw e;
        }
        return jsonArray;
    }

    /**
     * 根据物料编号和供应商获取价格
     *
     * @param partNumber
     * @param supplierNumber
     * @return
     * @throws Exception
     */
    public static String queryPrice(String partNumber, String supplierNumber) throws Exception {
        String price = "";
        logger.info("----------------------------------------------------");
        logger.info(">>>开始集成获取价格：物料编号：" + partNumber + "供应商：" + supplierNumber);
        try {
            CtSapAccess access = new CtSapAccess();
            price = access.queryPrice(partNumber, supplierNumber);
            logger.info(">>>成功！根据物料编号和供应商获取价格完成！" + price);
        } catch (Exception e) {
            logger.info(">>>根据物料编号和供应商获取价格失败！", e);
            throw e;
        }
        return price;
    }

    /**
     * 最小包装量 、采购计量单位 、采购周期（天）、研发环保认证要求、环保认证确认、来料方式推给sap
     *
     * @param list
     * @return
     * @throws Exception
     */
    public static void sendPartAttribute(List<Map<String, String>> list) throws Exception {
        logger.info("----------------------------------------------------");
        if (CtFormatUtil.hasContent(list)) {
            for (Map<String, String> map : list) {
                logger.info(">>>开始集成推物料属性给sap" + map);
            }
        }
        try {
            CtSapAccess access = new CtSapAccess();
            access.sendPartAttribute(list);
            logger.info(">>>成功！推物料属性给sap成功！");
        } catch (Exception e) {
            logger.info(">>>推物料属性给sap失败！", e);
            throw e;
        }
    }

    /**
     * 删除预留单号
     * @param number
     * @return
     * @throws Exception
     */
    public static CtSapResultBo delMaterialDocumentNumber(String number) throws Exception {
        logger.info("----------------------------------------------------");
        logger.info(">>>开始删除预留单号：预留单号为：" + number);
        CtSapResultBo sapResultBo = new CtSapResultBo();
        try {
            CtSapAccess access = new CtSapAccess();
            sapResultBo = access.delMaterialDocumentNumber(number);
        } catch (Exception e) {
            logger.info(">>>删除预留单号失败！", e);
            throw e;
        }

        if (sapResultBo.getIntegrateFlag()) {
            logger.info(">>>删除预留单号成功！");
        } else {
            String failedInfo = sapResultBo.getErrorMsg();
            logger.info(">>>失败！" + failedInfo);
            throw new WTException(failedInfo);// Sap端异常
        }
        return sapResultBo;
    }

    /**
     * 物料状态发SAP
     * @param partNumber
     * @param partStateCode
     * @throws Exception
     */
    public static void sendPartState(String partNumber, String partStateCode) throws Exception {
        try {
            CtSapAccess access = new CtSapAccess();
            access.sendPartState(partNumber, partStateCode);
            logger.info(">>>成功！推物料状态给sap成功！");
        } catch (Exception e) {
            logger.info(">>>推物料状态给sap失败！", e);
            throw e;
        }
    }

    /**
     * 通过名称模糊查询查询项目
     * @throws Exception
     */
    public static List<String> getProjectInfo(String key) throws Exception {
        List<String> projectNameList = new ArrayList<>();
        CtSapHttpRequestClient httpRequest = new CtSapHttpRequestClient();
        String url = "";
        if(CtConstant.isPrdEnv()){
            url = CtSapConfig.ZFICO_GETIORDER_PRD;
        }else{
            url = CtSapConfig.ZFICO_GETIORDER_TEST;
        }
        try {
            logger.info(">>>通过名称模糊查询查询项目 url：" + url);
            HashMap<String,String> postParamsMap = new HashMap<>();
            postParamsMap.put("IV_BUKRS", "");
            postParamsMap.put("IV_AUART", "");
            postParamsMap.put("IV_ORDERTPYE", "");

            String body = httpRequest.post(url, postParamsMap);
            JSONObject json = JSONObject.parseObject(body);
            JSONArray array = json.getJSONArray("LT_ORDER");
            String projectName = "";
            for(int i = 0;i < array.size();i++){
                JSONObject projectJson = array.getJSONObject(i);
                //projectNumber = projectJson.getString("AUFNR");
                projectName = projectJson.getString("KTEXT");
                if(CtFormatUtil.hasContent(key)){
                    if(projectName.contains(key)){
                        projectNameList.add(projectName);
                    }
                }else{
                    projectNameList.add(projectName);
                }
            }
            return projectNameList;
        } catch (Exception e) {
            logger.info("集成项目信息异常：", e);
            throw e;
        }
    }

    /**
     * 通过公司编号、项目名称查项目编号
     * @param companyCode
     * @param projectName
     * @return
     * @throws Exception
     */
    public static String getProjectNumberByName(String projectName, String companyCode) throws Exception {
        String projectNumber = "";
        CtSapHttpRequestClient httpRequest = new CtSapHttpRequestClient();
        String url = "";
        if(CtConstant.isPrdEnv()){
            url = CtSapConfig.ZFICO_GETIORDER_PRD;
        }else{
            url = CtSapConfig.ZFICO_GETIORDER_TEST;
        }
        try {
            logger.info(">>>通过公司编号、项目名称查项目编号 url：" + url);
            logger.info(">>>通过公司编号、项目名称查项目编号 companyCode：" + companyCode);
            logger.info(">>>通过公司编号、项目名称查项目编号 projectName：" + projectName);
            HashMap<String,String> postParamsMap = new HashMap<>();
            postParamsMap.put("IV_BUKRS", companyCode);
            postParamsMap.put("IV_AUART", "");
            postParamsMap.put("IV_ORDERTPYE", "");

            String body = httpRequest.post(url, postParamsMap);
            logger.info(">>>通过公司编号、项目名称查项目编号 body：" + body);
            JSONObject json = JSONObject.parseObject(body);
            JSONArray array = json.getJSONArray("LT_ORDER");
            String sapProjectName = "";
            for(int i = 0;i < array.size();i++){
                JSONObject projectJson = array.getJSONObject(i);
                sapProjectName = projectJson.getString("KTEXT");
                if(projectName.equals(sapProjectName)){
                    projectNumber = projectJson.getString("AUFNR");
                    break;
                }
            }
        } catch (Exception e) {
            logger.info("集成项目信息异常：", e);
            throw e;
        }
        return projectNumber;
    }

    /**
     * 通过工厂编号查询可用仓位
     * @param factoryNumber
     * @return
     * @throws Exception
     */
    public static List<String> getWarehouseByFactory(String factoryNumber) throws Exception {
        List<String> warehouseList = new ArrayList<>();
        CtSapHttpRequestClient httpRequest = new CtSapHttpRequestClient();
        String url = "";
        if(CtConstant.isPrdEnv()){
            url = CtSapConfig.ZSD_CRM_DICC_PRD;
        }else{
            url = CtSapConfig.ZSD_CRM_DICC_TEST;
        }
        try {
            logger.info(">>>通过工厂编号查询可用仓位 url：" + url);
            logger.info(">>>通过工厂编号查询可用仓位 factoryNumber：" + factoryNumber);
            if(!CtFormatUtil.hasContent(factoryNumber)){
                throw new Exception("查询仓位，工厂编号不能为空！");
            }
            HashMap<String,String> postParamsMap = new HashMap<>();
            postParamsMap.put("IV_KEY", "18");

            String body = httpRequest.post(url, postParamsMap);
            JSONObject json = JSONObject.parseObject(body);
            JSONArray array = json.getJSONArray("IT_T001L");
            String factory = "";
            String warehouseNumber = "";
            String warehouseName = "";
            for(int i = 0;i < array.size();i++){
                JSONObject warehouseJson = array.getJSONObject(i);
                factory = warehouseJson.getString("WERKS");
                warehouseNumber = warehouseJson.getString("LGORT");
                warehouseName = warehouseJson.getString("LGOBE");
                if(factoryNumber.equals(factory) && CtFormatUtil.hasContent(warehouseNumber) && CtFormatUtil.hasContent(warehouseName)){
                    warehouseList.add(warehouseNumber + "_" + warehouseName);
                }
            }
            logger.info(">>>通过工厂编号查询可用仓位warehouseList:" + warehouseList.size());
        } catch (Exception e) {
            logger.info("集成仓位信息异常：", e);
            throw e;
        }
        return warehouseList;
    }

    /**
     * 通过公司编号查项目编号
     * @param companyCode
     * @return
     * @throws Exception
     */
    public static List<String> getProjectNumberByCompanyCode(String companyCode) throws Exception {
        List<String> list = new ArrayList<>();
        CtSapHttpRequestClient httpRequest = new CtSapHttpRequestClient();
        String url = "";
        if(CtConstant.isPrdEnv()){
            url = CtSapConfig.ZFICO_GETIORDER_PRD;
        }else{
            url = CtSapConfig.ZFICO_GETIORDER_TEST;
        }
        try {
            HashMap<String,String> postParamsMap = new HashMap<>();
            postParamsMap.put("IV_BUKRS", companyCode);
            postParamsMap.put("IV_AUART", "");
            postParamsMap.put("IV_ORDERTPYE", "");

            String body = httpRequest.post(url, postParamsMap);
            JSONObject json = JSONObject.parseObject(body);
            JSONArray array = json.getJSONArray("LT_ORDER");
            String sapProjectName = "";
            for(int i = 0;i < array.size();i++){
                JSONObject projectJson = array.getJSONObject(i);
                sapProjectName = projectJson.getString("KTEXT");
                //System.out.println("sapProjectName======>"+sapProjectName);
                //System.out.println("projectJson.getString(\"AUFNR\")======>"+projectJson.getString("AUFNR"));
                list.add(projectJson.getString("AUFNR"));
            }
        } catch (Exception e) {
            logger.info("集成项目信息异常：", e);
            throw e;
        }
        return list;
    }

    /**
     * 通过物料编号查询成本数据
     * @throws Exception
     */
    public static List<CtSapProductCostBo> getProductCost(String projectNumber, String productNumber) throws Exception {
        List<CtSapProductCostBo> boList = new ArrayList<>();
        CtSapHttpRequestClient httpRequest = new CtSapHttpRequestClient();
        String url = "";
        if(CtConstant.isPrdEnv()){
            url = CtSapConfig.ZFM_PLM_MM100_PRD;
        }else{
            url = CtSapConfig.ZFM_PLM_MM100_TEST;
        }
        try {
            logger.info(">>>通过物料编号查询成本数据 url：" + url);
            HashMap<String,String> postParamsMap = new HashMap<>();
            postParamsMap.put("IS_MATNR", productNumber);
            postParamsMap.put("IS_WERKS", "1001");

            String body = httpRequest.post(url, postParamsMap);
            JSONObject json = JSONObject.parseObject(body);
            JSONArray array = json.getJSONArray("ET_OUT");
            if(array.size() > 0){
                for(int i = 0;i < array.size();i++){
                    JSONObject jsonObject = array.getJSONObject(i);
                    CtSapProductCostBo bo = new CtSapProductCostBo();
                    bo.setProjectNumber(projectNumber);
                    bo.setProductNumber(productNumber);
                    bo.setPartNumber(jsonObject.getString("MATERIAL"));
                    int quantity = jsonObject.getInteger("QUANTITY");
                    int unit = jsonObject.getInteger("CO_AREA_CURRENCY_PRICE_UNIT");
                    Float price = jsonObject.getFloat("CCODE_CURRENCY_TOTAL_PRICE");
                    bo.setQuantity(quantity);
                    bo.setTotalPrice(((price/unit)*(quantity/100)));
                    boList.add(bo);
                }
            }
            return boList;
        } catch (Exception e) {
            logger.info("集成成本数据异常：", e);
            throw e;
        }
    }

    /**
     * 通过物料编号查询实际成本、实际生产数量
     * @throws Exception
     */
    public static List<Map<String, String>> getProductionQuantity(String productNumber) throws Exception {
        List<Map<String, String>> resultList = new ArrayList<>();
        CtSapHttpRequestClient httpRequest = new CtSapHttpRequestClient();
        String url = "";
        if(CtConstant.isPrdEnv()){
            url = CtSapConfig.ZFM_PLM_PP100_PRD;
        }else{
            url = CtSapConfig.ZFM_PLM_PP100_TEST;
        }
        try {
            logger.info(">>>通过物料编号查询实际成本、实际生产数量 url：" + url);
            HashMap<String,String> postParamsMap = new HashMap<>();
            postParamsMap.put("IS_MATNR", productNumber);
            postParamsMap.put("IS_WERKS", "1001");

            String body = httpRequest.post(url, postParamsMap);
            JSONObject json = JSONObject.parseObject(body);
            JSONArray array = json.getJSONArray("ET_OUT");
            if(array.size() > 0){
                for(int i = 0;i < array.size();i++){
                    JSONObject jsonObject = array.getJSONObject(i);
                    String partNumber = jsonObject.getString("MATNR");
                    if(!productNumber.equals(partNumber)){
                        continue;
                    }
                    Map<String, String> map = new HashMap<>();
                    map.put("actualQuantity", jsonObject.getString("GWEMG"));
                    map.put("actualCost", jsonObject.getString("ISTKOST_G"));
                    map.put("takeQuantity", jsonObject.getString("ZJHSL"));
                    String sapNumber = jsonObject.getString("HERKU");
                    if(CtFormatUtil.hasContent(sapNumber)){
                        String[] numberInfo = sapNumber.split("/");
                        if(numberInfo.length == 2){
                            map.put("partNumber", numberInfo[1]);
                            resultList.add(map);
                        }
                    }
                }
            }
            return resultList;
        } catch (Exception e) {
            logger.info("通过物料编号查询实际成本、实际生产数量异常：", e);
            throw e;
        }
    }

    public static String getSupplierInfo(String partNumberS) throws Exception {
        //System.out.println("getSupplierInfo=======>"+partNumberS);
        logger.info("查询供应商物料编码：" + partNumberS);
        String value = "";
        CtSapHttpRequestClient httpRequest = new CtSapHttpRequestClient();
        String url = "";
        if(CtConstant.isPrdEnv()){
            url = CtSapConfig.ZFM_PLM_MM106_PRD;
        }else{
            url = CtSapConfig.ZFM_PLM_MM106_TEST;
        }

        // 将字符串拆分为数组
        String[] matnrArray = partNumberS.split(",");

        // 创建主 JSON 对象
        JsonObject requestBody = new JsonObject();
        requestBody.addProperty("in", "body");

        // 创建 IT_MATNR 数组
        JsonArray itMatnrArray = new JsonArray();

        // 遍历拆分后的数组，创建每个 IT_MATNR 对象
        for (String matnr : matnrArray) {
            JsonObject item = new JsonObject();
            item.addProperty("in", "body");
            item.addProperty("MATNR", matnr);
            item.addProperty("TYPE", "");
            item.addProperty("MESSAGE", "");
            itMatnrArray.add(item);
        }

        // 将数组设置到主对象
        requestBody.add("IT_MATNR", itMatnrArray);

        // 将 JSON 对象转换为字符串
        String jsonString = requestBody.toString();

        try {
            value = httpRequest.postByBody(url, jsonString);
        } catch (Exception e) {
            logger.info("查询供应商信息异常：", e);
            throw e;
        }
        logger.info("查询供应商返回信息：" + partNumberS);
        return value;
    }

}
