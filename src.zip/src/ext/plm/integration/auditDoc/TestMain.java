package ext.plm.integration.auditDoc;

import ext.plm.integration.auditDoc.config.CtUrlProperties;
import wt.method.RemoteMethodServer;

public class TestMain {

    public static void main(String[] args) {
        System.out.println("======TestMain.java 开始调用  " + args[0] + "=============");
        RemoteMethodServer server = RemoteMethodServer.getDefault();

        try {
            if ("testCreateDoc".equals(args[0])) {
                // windchill ext.plm.integration.auditDoc.TestMain testCreateDoc 478447 A-1202-00001-01
            }else if("getSyncFileUrl".equals(args[0])){
                // windchill ext.plm.integration.auditDoc.TestMain getSyncFileUrl
                CtUrlProperties.getSyncFileUrl();
            }else if("sendDelFileRequest".equals(args[0])){
                CtAuditDocLogic.sendDelFileRequest(args[1],args[2]);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
