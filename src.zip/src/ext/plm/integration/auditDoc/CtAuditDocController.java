package ext.plm.integration.auditDoc;

import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtVersionUtil;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import wt.doc.WTDocument;
import wt.pom.Transaction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

@Controller
public class CtAuditDocController {
    /**
     * 将服务器A中文档中文件保存到服务器B
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "auditDoc/syncFileUrl", method = {
            RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT })
    public void syncFileUrl(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        Transaction transaction = new Transaction();
        transaction.start();
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        List<FileItem> items = new ArrayList();
        //获取请求中流 集合
        items = upload.parseRequest(request);
        try{
            //存放请求数据
            Map<String,Object> map = new HashMap<>();
            Iterator<FileItem> iterator = items.iterator();
            while(iterator.hasNext()){
                FileItem fileItem = iterator.next();
                if (fileItem.isFormField()) {
                    // 普通文本框的值
                    map.put(fileItem.getFieldName(), fileItem.getString("UTF-8"));
                }else{
                    map.put(fileItem.getFieldName(), fileItem);
                }
            }
            String docFolder = map.get("docFolder").toString();
            String docNumber = map.get("docNumber").toString();
            String docName = map.get("docName").toString();
            String docType = map.get("docType").toString();
            Object docVersion = map.get("docVersion");
            String promotionType = map.get("promotionType").toString();
            Object obj = map.get("fileSize");
            //获取主文件内容
            FileItem masterItem = (FileItem) map.get("masterFile");
            //获取附件内容
            List<FileItem> fileItemList = new ArrayList<>();
            if(CtFormatUtil.hasContent(obj)){
                Integer fileSize = Integer.valueOf(map.get("fileSize").toString());
                for(int i=0;i<fileSize;i++){
                    FileItem attachment = (FileItem) map.get("attachment"+i);
                    fileItemList.add(attachment);
                }
            }

            if(CtFormatUtil.hasContent(docFolder) && CtFormatUtil.hasContent(docNumber) && CtFormatUtil.hasContent(docName) && CtFormatUtil.hasContent(docType)
                && CtFormatUtil.hasContent(promotionType)){
                //判断文件夹是否存在 不存在创建 并判断该文档是否存在 并判断promotionType值 update 则直接更新 promote 升小版本
                WTDocument  doc = CtAuditDocLogic.copyDocumentToTarget(docNumber,docName,docFolder,docType,promotionType,docVersion);
                //设置文档主内容
                if(CtFormatUtil.hasContent(masterItem)){
                    CtAuditDocLogic.setDocContents(doc,masterItem);
                }
                //设置文档附件
                if(CtFormatUtil.hasContent(fileItemList)){
                    CtAuditDocLogic.setDocAttachment(doc,fileItemList);
                }
                String versionInfo = CtVersionUtil.getVersionInfo(doc);
                response.setStatus(200);
                response.setHeader("version",versionInfo);
            }else{
                //缺少必要参数
                response.sendError(404,"请求中缺失必要的参数！");
            }
            transaction.commit();
            transaction=null;
        }catch (Exception e){
            e.printStackTrace();
            response.sendError(500,"服务器错误:"+e.getLocalizedMessage());
        }finally {
            if(transaction!=null){
                transaction.rollback();
            }
        }
        response.setContentType("text/html;charset=UTF-8");
    }

    /**
     * 将服务器B中文档的所有主内容和附件删除
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "auditDoc/delFileUrl", method = {
            RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT })
    public void delFileUrl(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        Transaction transaction = new Transaction();
        transaction.start();
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        List<FileItem> items = new ArrayList();
        //获取请求中流 集合
        items = upload.parseRequest(request);
        try{
            //存放请求数据
            Map<String,Object> map = new HashMap<>();
            Iterator<FileItem> iterator = items.iterator();
            while(iterator.hasNext()){
                FileItem fileItem = iterator.next();
                if (fileItem.isFormField()) {
                    // 普通文本框的值
                    map.put(fileItem.getFieldName(), fileItem.getString("UTF-8"));
                }else{
                    map.put(fileItem.getFieldName(), fileItem);
                }
            }
            String docNumber = map.get("docNumber").toString();

            if(CtFormatUtil.hasContent(docNumber) ){
                CtAuditDocLogic.delDocContentAndAttachment(docNumber);
                response.setStatus(200);
            }else{
                //缺少必要参数
                response.sendError(404,"请求中缺失必要的参数！");
            }
            transaction.commit();
            transaction=null;
        }catch (Exception e){
            e.printStackTrace();
            response.sendError(500,"服务器错误:"+e.getLocalizedMessage());
        }finally {
            if(transaction!=null){
                transaction.rollback();
            }
        }
        response.setContentType("text/html;charset=UTF-8");
    }
}
