package ext.plm.integration.auditDoc;

import ext.plm.common.CtConstant;
import ext.plm.integration.auditDoc.bo.CtAuditResultBo;
import wt.method.MethodContext;
import wt.pom.Transaction;
import wt.pom.WTConnection;
import wt.util.WTException;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CtAuditDocQuery {

    /**
     * 获取序列值
     *
     * @return 序列值
     * @throws Exception
     */
    public String getZWorkHoursSequence() throws Exception {
        String nextSeq = "";
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String sql = "select sequence_ZWorkHours.nextval nextSeq from dual";
            statement = connection.prepareStatement(sql);
            result = statement.executeQuery();

            while (result.next()) {
                nextSeq = result.getString("nextSeq");
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(CtConstant.DATABASE_EXCEPTION_PREFIX + e.getMessage());
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return nextSeq;
    }
    /**
     * 新增流程审核信息
     *
     * @param bo
     * @throws Exception
     */
    public String insertAudit(CtAuditResultBo bo) throws Exception {
        MethodContext context = MethodContext.getContext();
        WTConnection connection = (WTConnection) context.getConnection();
        PreparedStatement statement = null;
        Transaction ts = null;
        String nextSeq = null;
        try {
            ts = new Transaction();
            ts.start();

            String sql = "insert into ZAudit_INFO(id,docNumber,docBranchID,version,url,interfaceCall,statusCode," +
                    "requestData,errorMsg,sendTime) values(?,?,?,?,?,?,?,?,?,?)";
            nextSeq = getZWorkHoursSequence();
            statement = connection.prepareStatement(sql);
            statement.setString(1, nextSeq);
            statement.setString(2, bo.getDocNumber());
            statement.setString(3, bo.getDocBranchID());
            statement.setString(4, bo.getVersion());
            statement.setString(5, bo.getUrl());
            statement.setString(6, bo.getInterfaceCall());
            statement.setInt(7, bo.getStatusCode());
            statement.setString(8, bo.getRequestData());
            statement.setString(9, bo.getErrorMsg());
            statement.setDate(10, bo.getSendTime() == null? null:new Date(bo.getSendTime().getTime()));
            statement.execute();

            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException(e, CtConstant.DATABASE_EXCEPTION_PREFIX + e.getLocalizedMessage());
        } finally {
            if (ts != null)
                ts.rollback();
            if (statement != null)
                statement.close();
            connection.getConnection().commit();
            if (connection != null && connection.isActive())
                connection.release();
        }
        return nextSeq;
    }
}
