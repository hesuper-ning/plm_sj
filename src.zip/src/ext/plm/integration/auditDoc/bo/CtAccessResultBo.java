package ext.plm.integration.auditDoc.bo;


import java.io.Serializable;

public class CtAccessResultBo implements Serializable {
    private static final long serialVersionUID = 1353248629249266240L;

    String responseCode; //返回码

    String responseMsg; //返回信息,存放返回的完整信息

    String errorMsg; //异常信息，可以是从返回信息里过滤筛选后的异常信息

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseMsg() {
        return responseMsg;
    }

    public void setResponseMsg(String responseMsg) {
        this.responseMsg = responseMsg;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

}
