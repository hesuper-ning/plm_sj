package ext.plm.integration.auditDoc.bo;

import java.io.Serializable;
import java.util.Date;

public class CtAuditResultBo implements Serializable {
    private static final long serialVersionUID = 1353248629249266240L;

    private String id;
    private String docNumber;
    private String docBranchID;
    private String version;//版本
    private String url; //请求url
    private String interfaceCall;//接口是否调用 标志
    private int statusCode;//状态码
    private String requestData;//请求参数 Json
    private String errorMsg; //失败原因
    private Date sendTime; //发送时间

    public CtAuditResultBo() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public String getDocBranchID() {
        return docBranchID;
    }

    public void setDocBranchID(String docBranchID) {
        this.docBranchID = docBranchID;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getInterfaceCall() {
        return interfaceCall;
    }

    public void setInterfaceCall(String interfaceCall) {
        this.interfaceCall = interfaceCall;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getRequestData() {
        return requestData;
    }

    public void setRequestData(String requestData) {
        this.requestData = requestData;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
