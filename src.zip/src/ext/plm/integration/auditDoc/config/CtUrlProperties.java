package ext.plm.integration.auditDoc.config;

import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

public class CtUrlProperties {
    /**
     * 获取对应part的key值
     *
     * @param key
     * @return
     * @throws Exception
     */
    public static String getProperties(String key) throws Exception {
        Properties docKeyMap = new Properties();
        docKeyMap.load(new InputStreamReader(
                CtUrlProperties.class.getResourceAsStream("CtUrl.properties"), "UTF-8"));
        String docTemplate = docKeyMap.getProperty(key);
        return docTemplate;
    }

    public static String getSyncFileUrl() {
        String host="";
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            host =inetAddress.getHostName(); //获取本地的主机名
        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String syncFileUrl="";
//        if(host.equalsIgnoreCase("plmlocal") || host.equalsIgnoreCase("plmdev.mect.com")
//            || host.equalsIgnoreCase("plmtest.mect.com")){
//            syncFileUrl= "http://plmdemo1.mect.com/Windchill/ptc1/auditDoc/syncFileUrl";
//        }
        if(host.equalsIgnoreCase("mci.mect.com") ||host.equalsIgnoreCase("plmlocal")
                || host.equalsIgnoreCase("plmdemo.fhsj.com/")){
            syncFileUrl= "http://127.0.0.1/Windchill/ptc1/auditDoc/syncFileUrl";
            //syncFileUrl= "http://doc.mect.com/Windchill/ptc1/auditDoc/syncFileUrl";
        }
        System.out.println(">>>>>>>host:"+host);
        System.out.println(">>>>>>>syncFileUrl 应审接口："+syncFileUrl);
        return syncFileUrl;
    }

    public static String getDelFileUrl() {
        String host="";
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            host =inetAddress.getHostName(); //获取本地的主机名
        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String delFileUrl="";
//        if(host.equalsIgnoreCase("plmlocal") || host.equalsIgnoreCase("plmdev.mect.com")
//            || host.equalsIgnoreCase("plmtest.mect.com")){
//            syncFileUrl= "http://plmdemo1.mect.com/Windchill/ptc1/auditDoc/delFileUrl";
//        }
        if(host.equalsIgnoreCase("mci.mect.com") ||host.equalsIgnoreCase("plmlocal")){
            delFileUrl= "http://plmlocal.mect.com/Windchill/ptc1/auditDoc/delFileUrl";
        }
        System.out.println(">>>>>>>host:"+host);
        System.out.println(">>>>>>>delFileUrl 应审接口："+delFileUrl);
        return delFileUrl;
    }
}
