package ext.plm.integration.auditDoc.config;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;

import java.io.IOException;


public class HttpClientConfig {

    /**
     * 定义编码格式 UTF-8
     */
    public static final String URL_PARAM_DECODECHARSET_UTF8 = "UTF-8";

    /**
     * 定义编码格式 GBK
     */
    public static final String URL_PARAM_DECODECHARSET_GBK = "GBK";

    private static final String URL_PARAM_CONNECT_FLAG = "&";

    private static final String EMPTY = "";

    private static MultiThreadedHttpConnectionManager connectionManager = null;

    private static int connectionTimeOut = 250000;

    private static int socketTimeOut = 25000;

    private static int maxConnectionPerHost = 20;

    private static int maxTotalConnections = 20;

    public static HttpClient client;

    static{
        connectionManager = new MultiThreadedHttpConnectionManager();
        connectionManager.getParams().setConnectionTimeout(connectionTimeOut);
        connectionManager.getParams().setSoTimeout(socketTimeOut);
        connectionManager.getParams().setDefaultMaxConnectionsPerHost(maxConnectionPerHost);
        connectionManager.getParams().setMaxTotalConnections(maxTotalConnections);
        client = new HttpClient(connectionManager);
    }

    /**
     * POST方式提交数据
     * @param url
     * 			待请求的URL
     * @param charset
     * 			编码
     * @return
     * 			响应结果
     * @throws IOException
     * 			IO异常
     */
    public static String URLPost(String url, String charset,String params){

        String response = EMPTY;
        PostMethod postMethod = null;
        try {
            postMethod = new PostMethod(url);
            postMethod.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=" + charset);
            //执行postMethod
            int statusCode = client.executeMethod(postMethod);
            if(statusCode == HttpStatus.SC_OK) {//响应200
                response = postMethod.getResponseBodyAsString();
                //读取内容
                byte[] responseBody = postMethod.getResponseBody();
                //处理内容
                String data = new String(responseBody);
                System.out.println(data);
            }else{
                //调用接口失败

            }
        }catch(HttpException e){

            e.printStackTrace();
        }catch(IOException e){

            e.printStackTrace();
        }finally{
            if(postMethod != null){
                postMethod.releaseConnection();
                postMethod = null;
            }
        }

        return response;
    }

    /**
     * GET方式提交数据
     * @param url
     * 			待请求的URL
     * @param params
     * 			要提交的数据
     * @param charset
     * 			编码
     * @return
     * 			响应结果
     * @throws IOException
     * 			IO异常
     */
    public static String URLGet(String url, String params, String charset){

        String response = EMPTY;
        GetMethod getMethod = null;
        StringBuffer totalURL = new StringBuffer(EMPTY);

        if(totalURL.indexOf("?") == -1) {
            totalURL.append(url).append("?").append(params);
        } else {
            totalURL.append(url).append("&").append(params);
        }

        try {
            getMethod = new GetMethod(totalURL.toString());
            getMethod.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=" + charset);
            //跳过验证登录  一定要加这句
            getMethod.setRequestHeader("Authorization", "Basic d2NhZG1pbjp3Y2FkbWlu");
            int statusCode = client.executeMethod(getMethod);
            if(statusCode == HttpStatus.SC_OK) {

                response = getMethod.getResponseBodyAsString();
                //读取内容
                byte[] responseBody = getMethod.getResponseBody();
                //处理内容
                String data = new String(responseBody);
                System.out.println(data);
//                OutputStream os = new FileOutputStream("D:\\1.pdf");
//                os.write(responseBody);
                System.out.println("文件处理成功!");
                System.out.println(response);
            }else{
                System.out.println("statusCode========="+statusCode);
            }
        }catch(HttpException e){

            e.printStackTrace();
        }catch(IOException e){

            e.printStackTrace();
        }finally{
            if(getMethod != null){
                getMethod.releaseConnection();
                getMethod = null;
            }
        }

        return response;
    }


}
