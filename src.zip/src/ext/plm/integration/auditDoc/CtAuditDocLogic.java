package ext.plm.integration.auditDoc;

import com.alibaba.fastjson.JSONObject;
import com.ptc.core.lwc.server.PersistableAdapter;
import ext.plm.integration.auditDoc.bo.CtAuditResultBo;
import ext.plm.integration.auditDoc.config.CtUrlProperties;
import ext.plm.util.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import wt.content.*;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;

import javax.validation.constraints.NotNull;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CtAuditDocLogic {

    /**
     * ext.plm.integration.auditDoc.CtAuditDocLogic#sendDelFileRequest(java.lang.String, java.lang.String)
     * 调用删除应审库接口，根据传入文档编号删除对应应审库的主内容和附件
     * @param docNumber
     * @param docBranchID 流程标识
     * @throws Exception
     */
    public static void sendDelFileRequest(@NotNull String docNumber,String docBranchID)throws Exception{
        CtAuditResultBo ctAuditResultBo = new CtAuditResultBo();
        ctAuditResultBo.setDocNumber(docNumber);
        ctAuditResultBo.setDocBranchID(docBranchID);
        String newDateString = CtDateUtil.newDateString("yyyy-MM-dd HH:mm:ss", "GMT+8");
        java.util.Date date = CtDateUtil.parseStringToDate(newDateString, "yyyy-MM-dd HH:mm:ss");
        ctAuditResultBo.setSendTime(date);

        try{
            if(!CtFormatUtil.hasContent(docNumber)){
                throw new Exception("传入的docNumber（文档编号）参数为空!");
            }
            //获取httpClient
            HttpClient client = HttpClients.createDefault();
            //获取URL基础路径
            String urlPath= CtUrlProperties.getDelFileUrl();
            HttpPost httpPost = new HttpPost(urlPath);
            //跳过登录验证
            httpPost.setHeader("Authorization","Basic d2NhZG1pbjp3Y2FkbWlu");
            //构建MultipartEntityBuilder
            MultipartEntityBuilder builder = MultipartEntityBuilder.create().setMode(HttpMultipartMode.RFC6532);;
            //请求中存放参数,文件
            //存放参数
            builder.addTextBody("docNumber",docNumber, ContentType.create("text/plain", Consts.UTF_8));
            //构建成功,后放入Post
            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);
            HttpResponse response =null;
            //发送请求
            if(CtFormatUtil.hasContent(httpPost)){
                response = client.execute(httpPost);
            }else {
                throw new WTException("发送httpPost请求异常，请联系管理员！！");
            }

            //组装请求参数json 放入数据库
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("docNumber",docNumber);
            String jsonString = jsonObject.toJSONString();
            ctAuditResultBo.setRequestData(jsonString);
            ctAuditResultBo.setUrl(urlPath);
            ctAuditResultBo.setInterfaceCall("是");

            HttpEntity responseEntity = response.getEntity();
            if(responseEntity != null){
                int statusCode = response.getStatusLine().getStatusCode();
                ctAuditResultBo.setStatusCode(statusCode);
                String resData = EntityUtils.toString(responseEntity,Charset.forName("UTF-8"));
                ctAuditResultBo.setErrorMsg(resData);
            }

        }catch (Exception e){
            ctAuditResultBo.setInterfaceCall("否");
            ctAuditResultBo.setErrorMsg(e.getLocalizedMessage());
            throw e;
        }finally {
            CtAuditDocQuery ctAuditDocQuery = new CtAuditDocQuery();
            //ctAuditDocQuery.insertAudit(ctAuditResultBo);
        }
    }

    /**
     * 向另一台服务器发送同步文件接口请求
     * @param docBranchID 流程标识
     * @param docNumber 文档编号
     * @param masterFileData pdf文件
     * @param attachmentFileList 附件列表
     * @param promotionType 服务B 文档不升版更新主内容/附件 还是升版更新主内容/附件
     * @throws Exception
     */
    public static void sendSyncFileRequest(@NotNull String docBranchID,@NotNull String docNumber,File masterFileData,List<File> attachmentFileList,@NotNull String promotionType) throws Exception{
        CtAuditResultBo ctAuditResultBo = new CtAuditResultBo();
        ctAuditResultBo.setDocNumber(docNumber);
        ctAuditResultBo.setDocBranchID(docBranchID);
        String newDateString = CtDateUtil.newDateString("yyyy-MM-dd HH:mm:ss", "GMT+8");
        java.util.Date date = CtDateUtil.parseStringToDate(newDateString, "yyyy-MM-dd HH:mm:ss");
        ctAuditResultBo.setSendTime(date);
        try{
            if(!promotionType.equals("update") && !promotionType.equals("promote")){
                throw new WTException("promotionType 值不合法！！！");
            }

            //如果masterFileData 和 附件都不包含pdf文件 不发送请求
            if(!CtFormatUtil.hasContent(masterFileData) && !CtFormatUtil.hasContent(attachmentFileList)){
                throw new Exception("没有可发送的文件");
            }

            //先判断是否为EPMDocument 在判断是否为WTDocument
            WTContainer container = null;//判断属于哪个存储库
            String containerName = null; //库名
            String docPath = null; //例如：/Default/test001/测试创建文档
            String docName = null;
            //04-12新添加版本信息
            String docVersion = null;
            EPMDocument epmDocument = CtEPMDocUtil.getEPMDocumentByNumber(docNumber);
            if(CtFormatUtil.hasContent(epmDocument)){
                container = epmDocument.getContainer();
                containerName = epmDocument.getContainerName();
                docPath = epmDocument.getFolderPath();
                docName = epmDocument.getName();
                IBAUtil ibaUtil = new IBAUtil(epmDocument);
                docVersion = ibaUtil.getIBAValue("mkt_banben");
                /*if(!CtFormatUtil.hasContent(docVersion)) {
                    docVersion = CtVersionUtil.getVersionInfo(epmDocument);
                }*/
            }else{
                WTDocument document = CtDocUtil.getDocumentByNumber(docNumber);
                if(!CtFormatUtil.hasContent(document)){
                    throw new WTException("文档编号不合法，无法获取到对应文档");
                }else {
                    container = document.getContainer();
                    containerName = document.getContainerName();
                    docPath = document.getFolderPath();
                    docName = document.getName();
                    IBAUtil ibaUtil = new IBAUtil(document);
                    docVersion = ibaUtil.getIBAValue("mkt_banben");
                    /*if(!CtFormatUtil.hasContent(docVersion)) {
                        docVersion = CtVersionUtil.getVersionInfo(document);
                    }*/
                }
            }
            //组装发送请求的必要参数
            String containerType = null;
            if(container instanceof PDMLinkProduct){
                containerType = "产品库";
            }else if(container instanceof WTLibrary){
                containerType ="存储库";
            }else if(container instanceof Project2){
                containerType ="项目库";
            }

            String docFolder = null; // 文档路径 路径规则 /产品库||项目库||存储库/容器名称/文档真实路径
            docPath = docPath.substring(0,docPath.lastIndexOf("/"));
            docPath = docPath.substring(8,docPath.length()); //将/default截取
            docFolder = "/Default/"+containerType+"/"+containerName+docPath;

            //新增业务 取消了文档类型的种类 使用最顶层的即可 wt.doc.WTDocument
            String docType = "wt.doc.WTDocument";
            //组装数据
            Map<String,String> docMap=new HashMap<>();
            docMap.put("docFolder",docFolder);
            docMap.put("docNumber",docNumber);
            docMap.put("docName",docName);
            docMap.put("docType",docType);
            docMap.put("docVersion",docVersion);
            docMap.put("promotionType",promotionType);
            sendHttpPost(ctAuditResultBo,docMap,attachmentFileList,masterFileData);
        }catch (Exception e){
            ctAuditResultBo.setInterfaceCall("否");
            ctAuditResultBo.setErrorMsg(e.getLocalizedMessage());
            CtAuditDocQuery ctAuditDocQuery = new CtAuditDocQuery();
            //ctAuditDocQuery.insertAudit(ctAuditResultBo);
            throw e;
        }
    }

    /**
     * 设置文档内容
     */
    public static void setDocContents(WTDocument doc,FileItem fileItem) throws Exception {
        boolean boldaccess = SessionServerHelper.manager.isAccessEnforced();
        try{
            InputStream isPrimary = fileItem.getInputStream();
            SessionServerHelper.manager.setAccessEnforced(false);
            ApplicationData content = CtDocUtil.getPrimaryContent(doc);
            if(CtFormatUtil.hasContent(content)){
                ContentServerHelper.service.deleteContent(doc, content);// 刪除主對象
            }
            //刷新并锁定doc 需要进行事务管理 否则会出现错误
            PersistenceHelper.manager.lockAndRefresh(doc);
            //更新 主内容 流
            if (doc != null) {
                ApplicationData applicationdata = ApplicationData
                        .newApplicationData(doc);
                applicationdata.setRole(ContentRoleType.PRIMARY);
                if (applicationdata != null && isPrimary != null) {
                    /**
                     * 2021/7/19 新增逻辑 主内容中文件名称需要和文档名称保持一致
                     */
                    String docName = doc.getName();
                    String fileName = fileItem.getName();
                    String suffix = fileName.substring(fileName.lastIndexOf("."));
                    applicationdata.setFileName(docName+suffix);
                    applicationdata.setFileSize(fileItem.getSize());
                    applicationdata = ContentServerHelper.service.updateContent(doc, applicationdata, isPrimary);
                    PersistenceHelper.manager.save(applicationdata);
                    ContentServerHelper.service.updateHolderFormat(doc);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            throw e;
        }finally {
            SessionServerHelper.manager.setAccessEnforced(boldaccess);
        }
    }

    /**
     * 移动文件到对应位置
     * @param docNumber
     * @param docName
     * @param docFolder
     * @Param docType
     * @Param promotionType
     * @return
     */
    public static WTDocument copyDocumentToTarget(String docNumber, String docName, String docFolder, String docType,String promotionType,Object docVersion) throws Exception {
        boolean boldaccess = SessionServerHelper.manager.isAccessEnforced();
        WTDocument document = null;
        try {
            SessionServerHelper.manager.setAccessEnforced(false);
            String wtcontainerName = CtUrlProperties.getProperties("wtcontainerName");
            //2021-6-9 新增逻辑 从原服务器中体系库中的文件放入 应审服务器的体系库中 通过docFolder 截取库名称
            //docFolder实例："/Default/存储库/体系库/test/***"
            int z = docFolder.indexOf("/", 1);
            int i = docFolder.indexOf("/", 9);
            int j = docFolder.indexOf("/", 13);
            String containerName = docFolder.substring(i + 1, j);
            String[] split = wtcontainerName.split(",");
            if("体系库".equals(containerName)){
                wtcontainerName = split[1];
                docFolder = docFolder.substring(0, z) + docFolder.substring(j);
            }else{
                wtcontainerName = split[0];
            }

            WTContainer wtContainer = CtCommonUtil.getContainerByName(wtcontainerName);
            document = CtDocUtil.getDocumentByNumber(docNumber);
            if(CtFormatUtil.hasContent(wtContainer)){
                //判断是否存在文件夹 不存在建立
                Folder folder = CtFolderUtil.getFolder(docFolder, wtContainer);
                //判断对象是否存在 存在迁移 然后设置当前版本废弃 ,升小版本
                if(CtFormatUtil.hasContent(document)){
                    String folderPath = document.getFolderPath();
                    folderPath = folderPath.substring(0,folderPath.lastIndexOf("/"));
                    if(!folderPath.equals(docFolder) || !wtcontainerName.equals(document.getContainerName())){
                        CtFolderUtil.moveWTObjectLocation(document, folder);
                    }
                    document = (WTDocument) PersistenceHelper.manager.refresh(document);
                    IBAUtil ibaUtil = new IBAUtil(document);
                    if (CtFormatUtil.hasContent(docVersion)){
                        ibaUtil.setIBAValue("mkt_banben",docVersion.toString());
                        ibaUtil.updateIBAHolder(document);
                    }
                    //新增逻辑 2021/3/30 根据promotionType值判断document是否需要升版
                    if("promote".equals(promotionType)){
                        LifeCycleHelper.service.setLifeCycleState(document, State.toState("OBSOLESCENCE"));
                        CtDocUtil.checkOut(document,"同步签名下发文档pdf");
                        document = (WTDocument) WorkInProgressHelper.service.checkin(document,
                                "同步签名下发文档pdf");
                        LifeCycleHelper.service.setLifeCycleState(document, State.toState("EFFECTED"));
                        document = (WTDocument) PersistenceHelper.manager.refresh(document);
                    }
                }else{
                    //创建一个文档
                    PersistableAdapter docObj = new PersistableAdapter(docType,
                            null, null);
                    docObj.load("name");
                    docObj.set("name", docName);
                    docObj.load("number");
                    docObj.set("number", docNumber);
                    document = (WTDocument) docObj.apply();
                    //文档移动到
                    FolderHelper.assignFolder(document, folder);
                    document = (WTDocument) PersistenceHelper.manager.store(document);
                    document = (WTDocument) PersistenceHelper.manager.refresh(document);
                    IBAUtil ibaUtil = new IBAUtil(document);
                    if (CtFormatUtil.hasContent(docVersion)){
                        ibaUtil.setIBAValue("mkt_banben",docVersion.toString());
                        ibaUtil.updateIBAHolder(document);
                    }
                    LifeCycleHelper.service.setLifeCycleState(document, State.toState("EFFECTED"));
                }
            }else{
                throw new WTException("配置文件中定义的存储库不存在");
            }
        }catch (Exception e){
            e.printStackTrace();
            throw e;
        }finally {
            SessionServerHelper.manager.setAccessEnforced(boldaccess);
        }
        return document;
    }

    //获取附件列表
    public static List<ApplicationData> getAttachments(WTDocument document)throws Exception{
        List<ApplicationData> contentList = new ArrayList<>();
        if(document != null) {
            // 单个主要内容  ContentRoleType.PRIMARY  附件 ContentRoleType.SECONDARY
            QueryResult qr = ContentHelper.service.getContentsByRole(document, ContentRoleType.SECONDARY);
            while(qr !=null && qr.hasMoreElements()){
                ContentItem item = (ContentItem) qr.nextElement();
                if (item instanceof ApplicationData) {
                    ApplicationData appData = (ApplicationData)item;
                    contentList.add(appData);
                }
            }
        }
        return contentList;
    }

    /**
     * 发送httpPost请求
     * @param docMap
     * @param attachmentFileList
     * @param masterFileData
     * @Param promotionType
     * @throws Exception
     */
    public static void sendHttpPost(CtAuditResultBo ctAuditResultBo, Map<String,String> docMap, List<File> attachmentFileList, File masterFileData) throws Exception{
        try{

            String docFolder =docMap.get("docFolder");
            String docNumber= docMap.get("docNumber");
            String docName=docMap.get("docName");
            String docType=docMap.get("docType");
            String docVersion=docMap.get("docVersion");
            String promotionType= docMap.get("promotionType");
            //获取httpClient
            HttpClient client = HttpClients.createDefault();
            //获取URL基础路径
            String urlPath= CtUrlProperties.getSyncFileUrl();
            HttpPost httpPost = new HttpPost(urlPath);
            //跳过登录验证
            httpPost.setHeader("Authorization","Basic d2NhZG1pbjp3Y2FkbWlu");
            //构建MultipartEntityBuilder
            MultipartEntityBuilder builder = MultipartEntityBuilder.create().setMode(HttpMultipartMode.RFC6532);;
            //请求中存放参数,文件
            //存放参数
            builder.addTextBody("docFolder",docFolder,ContentType.create("text/plain", Consts.UTF_8));
            builder.addTextBody("docNumber",docNumber,ContentType.create("text/plain", Consts.UTF_8));
            builder.addTextBody("docName",docName,ContentType.create("text/plain", Consts.UTF_8));
            builder.addTextBody("docType",docType,ContentType.create("text/plain", Consts.UTF_8));
            if (CtFormatUtil.hasContent(docVersion)) {
                builder.addTextBody("docVersion", docVersion, ContentType.create("text/plain", Consts.UTF_8));
            }
            builder.addTextBody("fileSize", String.valueOf(attachmentFileList.size()),ContentType.create("text/plain", Consts.UTF_8));
            builder.addTextBody("promotionType",promotionType,ContentType.create("text/plain",Consts.UTF_8));
            //存放主文件
            if(CtFormatUtil.hasContent(masterFileData)){
                builder.addBinaryBody("masterFile",masterFileData,ContentType.MULTIPART_FORM_DATA,masterFileData.getName());
            }
            //存放附件
            if(CtFormatUtil.hasContent(attachmentFileList)){
                for(int i=0;i<attachmentFileList.size();i++){
                    File attachment = attachmentFileList.get(i);
                    builder.addBinaryBody("attachment"+i,attachment,ContentType.MULTIPART_FORM_DATA,attachment.getName());
                }
            }

            //构建成功,后放入Post
            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);
            HttpResponse response =null;
            //发送请求
            if(CtFormatUtil.hasContent(httpPost)){
                response = client.execute(httpPost);
            }else {
               throw new WTException("发送httpPost请求异常，请联系管理员！！");
            }

            //组装请求参数json 放入数据库
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("docFolder",docFolder);
            jsonObject.put("docNumber",docNumber);
            jsonObject.put("docName",docName);
            jsonObject.put("docType",docType);
            jsonObject.put("promotionType",promotionType);
            jsonObject.put("docVersion",docVersion);
            jsonObject.put("attachments","File类型");
            jsonObject.put("masterFileData","File类型");
            String jsonString = jsonObject.toJSONString();
            ctAuditResultBo.setRequestData(jsonString);
            ctAuditResultBo.setUrl(urlPath);
            ctAuditResultBo.setInterfaceCall("是");

            HttpEntity responseEntity = response.getEntity();
            if(responseEntity != null){
                int statusCode = response.getStatusLine().getStatusCode();
                ctAuditResultBo.setStatusCode(statusCode);
                if(statusCode == 200){
                    Header version = response.getLastHeader("version");
                    ctAuditResultBo.setVersion(version.getValue());
                }else{
                    String resData = EntityUtils.toString(responseEntity,Charset.forName("UTF-8"));
                    ctAuditResultBo.setErrorMsg(resData);
                }
            }
            CtAuditDocQuery ctAuditDocQuery = new CtAuditDocQuery();
            //ctAuditDocQuery.insertAudit(ctAuditResultBo);
        }catch (Exception e){
            e.printStackTrace();
            throw e;
        }

    }

    /**
     * 设置文档附件
     * @param fileItemList
     */
    public static void setDocAttachment(WTDocument doc , List<FileItem> fileItemList) throws Exception {
        boolean boldaccess = SessionServerHelper.manager.isAccessEnforced();
        try{
            SessionServerHelper.manager.setAccessEnforced(false);
            //删除 所有内容
            List<ApplicationData> attachments = getAttachments(doc);
            if(CtFormatUtil.hasContent(attachments)){
                for(ApplicationData attachment : attachments){
                    ContentServerHelper.service.deleteContent(doc, attachment);// 刪除内容
                }
            }
            for(FileItem fileItem : fileItemList){
                doc = (WTDocument) PersistenceHelper.manager.refresh(doc);
                InputStream is = fileItem.getInputStream();
                ApplicationData applicationdata = ApplicationData
                        .newApplicationData(doc);
                applicationdata.setRole(ContentRoleType.SECONDARY);
                applicationdata.setFileName(fileItem.getName());
                applicationdata.setFileSize(fileItem.getSize());
                applicationdata = ContentServerHelper.service.updateContent(doc, applicationdata, is);
                PersistenceHelper.manager.save(applicationdata);
                ContentServerHelper.service.updateHolderFormat(doc);
                if(is != null){
                    is.close();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            throw e;
        }finally {
            SessionServerHelper.manager.setAccessEnforced(boldaccess);
        }
    }

    /**
     * 根据文档编号删除所有版本的主内容和附件
     * @param docNumber
     */
    public static void delDocContentAndAttachment(String docNumber) throws Exception {
        boolean boldaccess = SessionServerHelper.manager.isAccessEnforced();
        SessionServerHelper.manager.setAccessEnforced(false);
        try{
            WTDocument document = CtDocUtil.getDocumentByNumber(docNumber);
            if(!CtFormatUtil.hasContent(document)){
                throw new Exception("应审库中不存在编号为："+docNumber+"对应的文档");
            }

            QueryResult queryResult = VersionControlHelper.service.allIterationsOf(document.getMaster());
            while (queryResult.hasMoreElements()){
                WTDocument doc = (WTDocument)queryResult.nextElement();
                //删除主内容
                ApplicationData content = CtDocUtil.getPrimaryContent(doc);
                if(CtFormatUtil.hasContent(content)){
                    ContentServerHelper.service.deleteContent(doc, content);// 刪除主對象
                }

                //删除附件
                List<ApplicationData> attachments = getAttachments(doc);
                if(CtFormatUtil.hasContent(attachments)){
                    for(ApplicationData attachment : attachments){
                        ContentServerHelper.service.deleteContent(doc, attachment);// 刪除内容
                    }
                }
            }

        }catch (Exception e){
            e.printStackTrace();
            throw e;
        }finally {
            SessionServerHelper.manager.setAccessEnforced(boldaccess);
        }
    }
}
