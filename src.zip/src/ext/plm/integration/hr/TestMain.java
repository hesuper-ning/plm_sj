package ext.plm.integration.hr;

import cn.hutool.core.io.file.FileReader;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.hjsj.webservice.HrwebservicePortTypeProxy;
import ext.plm.bean.CtBeanService;
import ext.plm.common.CtConstant;
import ext.plm.part.CtPartService;
import ext.plm.project.CtProjectLogic;
import ext.plm.util.CtCommonUtil;
import wt.method.RemoteMethodServer;
import wt.services.ServiceFactory;

public class TestMain {

    private  static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);
    public static CtPartService service = ServiceFactory.getService(CtPartService.class);
    public static void main(String[] args) {
        System.out.println("======TestMain.java 开始调用  " + args[0] + "=============");
        try {
            RemoteMethodServer server = RemoteMethodServer.getDefault();
            if(CtConstant.isLocalEnv()||CtConstant.isTestEnv()){

                server.setUserName("wcadmin");
                server.setPassword("wcadmin");
            }

            if ("userInfo".equalsIgnoreCase(args[0])) {
                //测试hr接口返回 的信息类型和数量
                //windchill ext.plm.integration.hr.TestMain userInfo
                testGetUserInfo();
            }else if("readFile".equalsIgnoreCase(args[0])){
                //通过获取到的HR 信息json文件抓取数据
                //windchill ext.plm.integration.hr.TestMain readFile
                testReadHrJson();
            }else if("addAll".equalsIgnoreCase(args[0])){
                //通过获取到的HR 掉用接口抓取数据
                //windchill ext.plm.integration.hr.TestMain addAll
                JSONArray objects = testGetUserInfo();
                addAll(objects);
            }else if("addDept".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain addDept
                addDept();
            }else if("addPerson".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain addPerson
                addPerson();
            }else if ("show".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain show
                show();
            }else if ("testGetDept".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain testGetDept
                testGetDept("王奕明");
            }else if ("clear".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain clear
                clear();
            }else if ("resetHrInfo".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain resetHrInfo
                resetHrInfo();
            }else if ("createMPartView".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain createMPartView
                service.createMPartView(args[1]);
            }else if ("createMPartView".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain updateDViewState
                service.updateDViewState(args[1]);
            }else if ("activityInform".equalsIgnoreCase(args[0])){
                //windchill ext.plm.integration.hr.TestMain activityInform
                CtProjectLogic.activityInform();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 创建m视图
     * @return
     * @throws Exception
     */
    public static void createMPartView(String path) throws  Exception{
        service.createMPartView(path);
    }

    /**
     * 修改d视图状态
     * @return
     * @throws Exception
     */
    public static void updateDViewState(String path) throws  Exception{
        service.updateDViewState(path);
    }

    /**
     * 测试hr接口返回 的信息类型和数量
     * @return
     * @throws Exception
     */
    public static JSONArray testGetUserInfo() throws Exception{

        String hrTestUrl ="";
        if(CtConstant.isLocalEnv()){
            hrTestUrl = "http://172.30.10.113:8080/hrwebservice_inter/services/hrwebservice";
        }else if(CtConstant.isTestEnv()){
            hrTestUrl = "http://172.30.10.113:8080/hrwebservice_inter/services/hrwebservice";
        }else if(CtConstant.isPrdEnv()){
            hrTestUrl = "http://172.30.10.94/hrwebservice/services/hrwebservice";
        } else{
            throw new Exception("该系统环境没有配置,请确定当前环境");
        }
        System.out.println("调用"+hrTestUrl+"---"+CtCommonUtil.getHostName());
        HrwebservicePortTypeProxy proxy = new HrwebservicePortTypeProxy();
        proxy.setEndpoint(hrTestUrl);

        String jsonArrStr = proxy.searchOrgInfo("");//传空获取全部信息
        System.out.println(">>>"+jsonArrStr.substring(0,1000));
        JSONArray allArray = JSON.parseArray(jsonArrStr);
        System.out.println(">>>size="+allArray.size());
        return allArray;
    }

    /**
     * 通过获取到的HR 信息json文件抓取数据
     * @return
     * @throws Exception
     */
    public static JSONArray testReadHrJson() throws  Exception{

        FileReader reader = new FileReader("ext/plm/integration/hr/hr.txt");
        String jsonArrStr = reader.readString();
        System.out.println(">>>"+jsonArrStr.substring(0,1000));
        JSONArray allArray = JSON.parseArray(jsonArrStr);
        System.out.println(">>>size="+allArray.size());
        return allArray;
    }

    public static void addAll(JSONArray jsonArray){
        Object a[] = {jsonArray};

        try {
            beanService.doMethod(CtHrService.class,"addAll",a);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("添加基本信息异常");
        }
    }

    public static void addDept(){
        try {
            beanService.doMethod(CtHrService.class,"addDepartment",null);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("添加部门异常");
        }
    }

    public static void addPerson(){
        try {
            beanService.doMethod(CtHrService.class,"addPerson",null);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("添加员工异常");
        }
    }
    public static void clear(){
        try {
            beanService.doMethod(CtHrService.class,"clearAllInfo",null);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("删除数据异常");
        }
    }
    public static void resetHrInfo(){
        try {
            beanService.doMethod(CtHrService.class,"resetHrInfo",null);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("重置数据异常");
        }
    }

    public static void show(){
        try {
            beanService.doMethod(CtHrService.class,"getDeptTree",null);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("部门tree展示异常");
        }
    }

    public static void testGetDept(String s){
        try {
            String[] sa = new String[1];
            sa[0] = s;
            String getPersonInfo = (String) beanService.doMethod(CtHrLogic.class,"getDepartmentNameByUserName",sa);
            System.out.println(getPersonInfo);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("部门tree展示异常");
        }
    }
}
