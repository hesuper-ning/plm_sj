package ext.plm.integration.hr;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.integration.hr.bo.CtHrPersonBo;

import java.util.HashMap;
import java.util.List;

public interface CtHrService {
    //添加基础表
    void addAll(JSONArray array)throws Exception;

    //插入部门表
    void addDepartment()throws Exception;

    //插入员工
    void addPerson()throws Exception;

    //清空所有hr信息
    void clearAllInfo() throws Exception;

    List<HashMap<String,String>> getAllPerson() throws Exception;

    //查询部门tree
    JSONObject getDeptTree()throws Exception;

    //根据id获取所负责的部门
    HashMap<String, String> getChargeDept(String rawId) throws Exception;

    //根据loginName获取用户信息
    CtHrPersonBo getPersonByNo(String no) throws Exception;
    //根据loginNameList获取用户信息
    List<CtHrPersonBo> getPersonByLoginNameList(List loginNameList) throws Exception;
    //根据loginName获取用户信息
    CtHrPersonBo getPersonByRealNo(String no) throws Exception;

    //重置hr信息
    void resetHrInfo() throws Exception;

}
