package ext.plm.integration.hr;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.bean.CtBeanFactory;
import ext.plm.integration.hr.bo.*;
import ext.plm.integration.hr.mapper.CtHrMapper;
import ext.plm.util.CtFormatUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import wt.pom.Transaction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

@Service
public class CtHrServiceImpl implements CtHrService {

    //@Autowired
    private CtHrMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtHrMapper.class);

    /**
     * 添加基础表
     *
     * @param array 所有信息json
     */
    @Override
    public void addAll(JSONArray array) throws Exception {


        for (Object o : array) {
            JSONObject object = (JSONObject) o;
            if (object.get("type").equals("dept")) {

                CtHrDepartmentRawBo departmentRawBo = new CtHrDepartmentRawBo();
                departmentRawBo.setIsAvailable(object.getString("isAvailable"));
                departmentRawBo.setName(object.getString("name"));
                departmentRawBo.setNo(object.getString("no"));
                departmentRawBo.setParent(object.getString("parent"));
                departmentRawBo.setRawOrder(object.getString("order"));
                departmentRawBo.setRawId(object.getString("id"));

                mapper.addDepartmentRaw(departmentRawBo);
            } else if (object.get("type").equals("post")) {

                CtHrPostRawBo ctHrPostRawBo = new CtHrPostRawBo();
                ctHrPostRawBo.setIsAvailable(object.getString("isAvailable"));
                ctHrPostRawBo.setName(object.getString("name"));
                ctHrPostRawBo.setNo(object.getString("no"));
                ctHrPostRawBo.setParent(object.getString("parent"));
                ctHrPostRawBo.setRawOrder(object.getString("order"));
                ctHrPostRawBo.setRawId(object.getString("id"));

                mapper.addPostRawBo(ctHrPostRawBo);
            } else if (object.get("type").equals("person")) {

                CtHrPersonRawBo ctHrPersonRawBo = new CtHrPersonRawBo();
                ctHrPersonRawBo.setIsAvailable(object.getString("isAvailable"));
                ctHrPersonRawBo.setName(object.getString("name"));
                ctHrPersonRawBo.setNo(object.getString("no"));
                ctHrPersonRawBo.setParent(object.getString("parent"));
                ctHrPersonRawBo.setRawOrder(object.getString("order"));
                ctHrPersonRawBo.setRawId(object.getString("id"));
                ctHrPersonRawBo.setEmail(object.getString("email"));
                ctHrPersonRawBo.setLoginName(object.getString("loginName"));
                ctHrPersonRawBo.setMobileNo(object.getString("mobileNo"));
                String posts = object.getString("posts");
                posts.replace(']', ' ');
                posts.replace('[', ' ');
                ctHrPersonRawBo.setPosts(posts);
                ctHrPersonRawBo.setSex(object.getString("sex"));
                ctHrPersonRawBo.setWorkPhone(object.getString("workPhone"));

                mapper.addPersonRaw(ctHrPersonRawBo);
            }
        }
    }

    /**
     * 添加部门信息
     */
    @Override
    public void addDepartment() throws Exception {
        List<CtHrDepartmentRawBo> departmentRaw = mapper.getDepartmentRaw();

        for (CtHrDepartmentRawBo rawBo : departmentRaw) {
            List<CtHrDepartmentRawBo> subDept = new ArrayList<>();
            //获取子级部门名称及编号
            subDept = getSubDept(rawBo.getRawId(), subDept);

            String subIds = "";
            String subNames = "";

            for (CtHrDepartmentRawBo bo : subDept) {

                String rawid = bo.getRawId();
                String name = bo.getName();
                subNames = CtFormatUtil.combineStr(subNames, name);
                subIds = CtFormatUtil.combineStr(subIds, rawid);
            }


            //组装BO
            CtHrDepartmentBo ctHrDepartmentBo = new CtHrDepartmentBo();
            ctHrDepartmentBo.setName(rawBo.getName());
            ctHrDepartmentBo.setRawId(rawBo.getRawId());
            ctHrDepartmentBo.setNo(rawBo.getNo());
            ctHrDepartmentBo.setParent(rawBo.getParent());
            ctHrDepartmentBo.setSubIds(subIds);
            ctHrDepartmentBo.setSubNames(subNames);
            ctHrDepartmentBo.setRawOrder(rawBo.getRawOrder());

            mapper.addDepartment(ctHrDepartmentBo);
        }
    }

    /**
     * 递归查询子部门
     *
     * @param rawId     上级部门id
     * @param rawBoList 子部门集合
     * @return
     * @throws Exception
     */
    public List<CtHrDepartmentRawBo> getSubDept(String rawId, List<CtHrDepartmentRawBo> rawBoList) throws Exception {
        if (!rawId.equals("E123AF2625A24DAEBEF94833C5B23CF3")) {//排除泛海三江根节点
            if (CtFormatUtil.hasContent(rawId)) {
                List<CtHrDepartmentRawBo> rawBos = mapper.getDepartmentRawByRawIds(rawId);

                for (int i = 0; i < rawBos.size(); i++) {
                    rawBoList.add(rawBos.get(i));
                }

                if (CtFormatUtil.hasContent(rawBos)) {
                    for (int i = 0; i < rawBos.size(); i++) {
                        getSubDept(rawBos.get(i).getRawId(), rawBoList);
                    }
                }
            }
        }
        return rawBoList;
    }

    /**
     * 查出部门tree
     *
     * @return
     * @throws Exception
     */
    public JSONObject getDeptTree() throws Exception {
        JSONObject object = new JSONObject();
        System.out.println("01010101010101010101010101011010");
        //获取所有部门信息
        List<CtHrDepartmentBo> departmentBos = mapper.getDept();

        JSONArray objects = new JSONArray();
        for (CtHrDepartmentBo departmentBo : departmentBos) {
            JSONArray jsonArray = new JSONArray();
            if (CtFormatUtil.hasContent(departmentBo.getSubIds())) {
                String[] split = departmentBo.getSubIds().split(",");
                for (String id : split) {
                    jsonArray = getDeptSubNode(id, departmentBo.getRawId(), jsonArray);
                }
                JSONObject object1 = new JSONObject();
                object1.put("wid", departmentBo.getRawId());
                object1.put("name", departmentBo.getName());
                object1.put("expanded", true);
                object1.put("children", jsonArray);
                objects.add(object1);
            }
        }

        //String jsonString = JSON.toJSONString(objects, SerializerFeature.DisableCircularReferenceDetect);


        object.put("wid", "root");
        object.put("name", "电子股份有限公司");
        object.put("expanded", true);
        object.put("children", objects);

        System.out.println(">>>>>objectTree" + object.toJSONString());
        return object;
    }


    @Override
    public HashMap<String, String> getChargeDept(String rawId) throws Exception {
        return mapper.getChargeDept(rawId);
    }

    @Override
    public CtHrPersonBo getPersonByNo(String no) throws Exception {
        try {
            return mapper.getPersonByNo(no);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("存在脏数据,请联系管理员清理");
        }
    }
    @Override
    public List<CtHrPersonBo> getPersonByLoginNameList(List loginNameList) throws Exception {
        try {
            return mapper.getPersonByLoginNameList(loginNameList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("存在脏数据,请联系管理员清理");
        }
    }
    @Override
    public CtHrPersonBo getPersonByRealNo(String no) throws Exception {
        try {
            return mapper.getPersonByRealNo(no);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("存在脏数据,请联系管理员清理");
        }
    }

    /**
     * 递归查询子部门
     *
     * @param id       子部门id
     * @param fatherId 上级部门id
     * @return
     */
    public JSONArray getDeptSubNode(String id, String fatherId, JSONArray jsonArray) throws Exception {
        //获取子部门
        CtHrDepartmentBo bo = mapper.getDeptByRawIdAndFatherId(id, fatherId);
        if (CtFormatUtil.hasContent(bo)) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("wid", bo.getRawId());
            jsonObject.put("name", bo.getName());
            jsonObject.put("expanded", true);

            if (CtFormatUtil.hasContent(bo.getSubIds())) {
                String[] split = bo.getSubIds().split(",");
                for (String rid : split) {
                    getDeptSubNode(rid, bo.getRawId(), jsonArray);
                }
                jsonObject.put("children", jsonObject);
                jsonArray.add(jsonObject);
            } else {
                jsonArray.add(jsonObject);
            }

        }
        return jsonArray;
    }

    /**
     * 添加员工表
     *
     * @throws Exception
     */
    @Override
    public void addPerson() throws Exception {
        //获取所有员工
        List<CtHrPersonRawBo> personRaw = mapper.getPersonRaw();
        CtHrPersonRawBo ctHrPersonRawBo1 = new CtHrPersonRawBo();
        ctHrPersonRawBo1.setName("wcadmin");
        ctHrPersonRawBo1.setRawId("Administrator");
        ctHrPersonRawBo1.setLoginName("Administrator");
        ctHrPersonRawBo1.setNo("Administrator");
        ctHrPersonRawBo1.setPosts("[A0D2A0082887431C91D3BD9A064C196C,]");
        ctHrPersonRawBo1.setIsAvailable("true");
        ctHrPersonRawBo1.setParent("A2F8176EED6249B39EE07911E0801057");
        personRaw.add(ctHrPersonRawBo1);
        for (CtHrPersonRawBo ctHrPersonRawBo : personRaw) {

            if (ctHrPersonRawBo.getIsAvailable().equals("false"))continue;

            //获取对应的部门
            String deptName = "";
            if (CtFormatUtil.hasContent(ctHrPersonRawBo.getParent())) {
                deptName = mapper.getDeptName(ctHrPersonRawBo.getParent());
            }
            //获取对应的职位
            String posts = "";
            String[] split = ctHrPersonRawBo.getPosts().split(",");
            for (String post : split) {
                post = post.replace("[", " ");
                post = post.replace("]", " ");
                if (CtFormatUtil.hasContent(post)) {
                    Set<String> postNames = mapper.getPostName(post.trim());
                    for (String postName : postNames) {
                        posts += postName + ",";
                    }
                }
            }
            if (CtFormatUtil.hasContent(posts)) {
                posts = posts.substring(0, posts.length() - 1);
            }
            //组装Bo
            CtHrPersonBo ctHrPersonBo = new CtHrPersonBo();
            BeanUtils.copyProperties(ctHrPersonRawBo, ctHrPersonBo);
            ctHrPersonBo.setPostNames(posts);
            ctHrPersonBo.setDepartmentName(deptName);

            mapper.addPerson(ctHrPersonBo);
        }
    }

    @Override
    public void clearAllInfo() throws Exception {
        String[] strings = {"ZHrDepartmentRaw", "ZHrPostRaw", "ZHrPersonRaw", "ZHrDepartment", "ZHrPerson"};

        //mapper.delSequence();
        //mapper.createSequence();
        for (String string : strings) {
            mapper.clearAllInfo(string);
        }


    }

    @Override
    public List<HashMap<String, String>> getAllPerson() throws Exception {
        List<HashMap<String, String>> resultList = new ArrayList<HashMap<String, String>>();
        List<CtHrPersonBo> persons = mapper.getPerson();

        HashMap<String, String> tmpMap = null;
        for (CtHrPersonBo person : persons) {
            tmpMap = new HashMap<String, String>();
            tmpMap.put("userFullName", person.getName());
            tmpMap.put("no", person.getLoginName());
            tmpMap.put("userNo", person.getNo());
            resultList.add(tmpMap);
        }

        return resultList;
    }


    @Override
    public void resetHrInfo() throws Exception {
        JSONArray hrJSONInfo = CtHrLogic.getHrJSONInfo();
        //开启事务
        Transaction ts = new Transaction();
        try {
            ts.start();
            //先清空列表
            clearAllInfo();

            //添加
            addAll(hrJSONInfo);

            addDepartment();

            addPerson();
            ts.commit();
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (ts != null) {
                ts.rollback();
                ts = null;
            }
        }
    }


}
