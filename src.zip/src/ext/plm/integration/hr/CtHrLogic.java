package ext.plm.integration.hr;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.hjsj.webservice.HrwebservicePortTypeProxy;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.integration.hr.bo.CtHrPersonBo;
import ext.plm.integration.hr.mapper.CtHrMapper;
import org.springframework.stereotype.Component;
import wt.util.WTException;

import java.util.HashMap;
import java.util.List;

@Component
public class CtHrLogic {

    private static CtHrMapper mapper = CtBeanFactory.newCtBeanFactory().getBean(CtHrMapper.class);



    /**
     * 根据登录编号获取用户信息
     * @param no
     * @return  用户信息
     */
    public static CtHrPersonBo getPersonByNo(String no) throws Exception {
        CtHrPersonBo personBo = mapper.getPersonByNo(no);
        if(personBo == null){
            throw new WTException("当前用户'"+no+"'未能查找到HR部门信息，请先集成或更新HR用户部门信息！");
        }
        return mapper.getPersonByNo(no);
    }

    public static List<CtHrPersonBo> getPerson()throws Exception{
        return mapper.getPerson();
    }

    /**
     * 获取用户信息
     * @param workNumber
     * @param postName
     * @param deptName
     * @param personNames
     * @return
     * @throws Exception
     */
    public static List<CtHrPersonBo> getPersonByNoOrPost(String workNumber, String[] deptName,String[] postName,List<String> personNames)throws Exception{
        return mapper.getPersonByNoOrPost(workNumber,deptName,postName,personNames);
    }


    /**
     * 获取所有部门名称
     * @return
     */
    public static List<HashMap<String,String>> getAllDept(){
        return mapper.getAllDept();
    }

    /**
     * 获取所有岗位名称
     * @return
     */
    public static List<HashMap<String,String>> getAllPost(){
        return mapper.getAllPost();
    }

    /**
     * 根据部门名称获取部门编号
     * @param deptName 部门名称
     * @return
     */
    public static String getDeptNoByName(String deptName){
        return mapper.getDeptNoByName(deptName);
    }

    public static JSONArray getHrJSONInfo() throws Exception{
        String hrTestUrl ="";
        if(CtConstant.isLocalEnv()){
            hrTestUrl = "http://172.30.10.113:8080/hrwebservice_inter/services/hrwebservice";
        }else if(CtConstant.isTestEnv()){
            hrTestUrl = "http://172.30.10.113:8080/hrwebservice_inter/services/hrwebservice";
        }else if(CtConstant.isPrdEnv()){
            hrTestUrl = "http://172.30.10.94/hrwebservice/services/hrwebservice";
        } else{
            throw new Exception("该系统环境没有配置,请确定当前环境");
        }


        HrwebservicePortTypeProxy proxy = new HrwebservicePortTypeProxy();
        proxy.setEndpoint(hrTestUrl);

        String jsonArrStr = proxy.searchOrgInfo("");//传空获取全部信息
        System.out.println(">>>"+jsonArrStr.substring(0,1000));
        JSONArray allArray = JSON.parseArray(jsonArrStr);
        System.out.println(">>>size="+allArray.size());
        return allArray;
    }


}
