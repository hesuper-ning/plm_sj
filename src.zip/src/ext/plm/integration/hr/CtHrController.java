package ext.plm.integration.hr;

import ext.plm.common.CtResApiResult;
import ext.plm.integration.hr.bo.CtHrPersonBo;
import ext.plm.risk.riskCommon.CtResApiResultRisk;
import ext.plm.util.CtFormatUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

@RestController
public class CtHrController {

    @Autowired
    private CtHrService service;

    /**
     * 获取所有员工
     *
     * @throws Exception
     */
    @RequestMapping(value = "/hr/getAllUser", method = {RequestMethod.GET})
    public CtResApiResult getDataByBranchId() throws Exception {
        try {
            List<HashMap<String,String>> itemList = service.getAllPerson();


            return CtResApiResultRisk.success(itemList);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResultRisk.fail("获取数据库信息失败，后台异常信息：\r\n" + e.getLocalizedMessage(), null);
        }
    }

    /**
     * 根据no获取用户部门
     *
     * @throws Exception
     */
    @RequestMapping(value = "/hr/getDeptName", method = {RequestMethod.GET,RequestMethod.POST})
    public CtResApiResult getDept(@RequestParam("no") String no) throws Exception {
        try {
            CtHrPersonBo person = service.getPersonByNo(no);
            String departmentName = "";
            if(CtFormatUtil.hasContent(person)){
                departmentName = person.getDepartmentName();

            }
            return CtResApiResultRisk.success(departmentName);
        } catch (Exception e) {
            e.printStackTrace();
            return CtResApiResultRisk.fail("获取部门名称失败，后台异常信息：\r\n" + e.getLocalizedMessage(), null);
        }
    }
}

