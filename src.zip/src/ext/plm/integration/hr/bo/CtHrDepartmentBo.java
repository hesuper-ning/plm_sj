package ext.plm.integration.hr.bo;

import com.baomidou.mybatisplus.annotations.KeySequence;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

@TableName("ZHrDepartment")
@KeySequence("ZHr_seq")
public class CtHrDepartmentBo {
    @TableId(value = "ID", type = IdType.INPUT)
    Long id;
    @TableField("RAWID")
    String rawId;
    @TableField("NAME")
    String name;
    @TableField("NO")
    String no;
    @TableField("RAWORDER")
    String rawOrder;
    @TableField("PARENT")
    String parent;
    @TableField("SUBIDS")
    String subIds;
    @TableField("SUBNAMES")
    String subNames;

    public CtHrDepartmentBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRawId() {
        return rawId;
    }

    public void setRawId(String rawId) {
        this.rawId = rawId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getRawOrder() {
        return rawOrder;
    }

    public void setRawOrder(String rawOrder) {
        this.rawOrder = rawOrder;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getSubIds() {
        return subIds;
    }

    public void setSubIds(String subIds) {
        this.subIds = subIds;
    }

    public String getSubNames() {
        return subNames;
    }

    public void setSubNames(String subNames) {
        this.subNames = subNames;
    }

    @Override
    public String toString() {
        return "CtHrDepartmentBo{" +
                "id=" + id +
                ", rawId='" + rawId + '\'' +
                ", name='" + name + '\'' +
                ", no='" + no + '\'' +
                ", rawOrder='" + rawOrder + '\'' +
                ", parent='" + parent + '\'' +
                ", subIds='" + subIds + '\'' +
                ", subNames='" + subNames + '\'' +
                '}';
    }
}
