package ext.plm.integration.hr.bo;

import com.baomidou.mybatisplus.annotations.KeySequence;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

@TableName("ZHrPerson")
@KeySequence("ZHr_seq")
public class CtHrPersonBo {
    @TableId(value = "ID", type = IdType.INPUT)
    Long id;
    @TableField("RAWID")
    String rawId;
    @TableField("NAME")
    String name;
    @TableField("LOGINNAME")
    String loginName;
    @TableField("SEX")
    String sex;
    @TableField("EMAIL")
    String email;
    @TableField("MOBILENO")
    String mobileNo;
    @TableField("POSTS")
    String posts;
    @TableField("POSTNAMES")
    String postNames;
    @TableField("WORKPHONE")
    String workPhone;
    @TableField("NO")
    String no;
    @TableField("RAWORDER")
    String rawOrder;
    @TableField("PARENT")
    String parent;
    @TableField("DEPARTMENTNAME")
    String departmentName;

    public CtHrPersonBo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRawId() {
        return rawId;
    }

    public void setRawId(String rawId) {
        this.rawId = rawId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getPosts() {
        return posts;
    }

    public void setPosts(String posts) {
        this.posts = posts;
    }

    public String getWorkPhone() {
        return workPhone;
    }

    public void setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getRawOrder() {
        return rawOrder;
    }

    public void setRawOrder(String rawOrder) {
        this.rawOrder = rawOrder;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getPostNames() {
        return postNames;
    }

    public void setPostNames(String postNames) {
        this.postNames = postNames;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    @Override
    public String toString() {
        return "CtHrPersonBo{" +
                "id=" + id +
                ", rawId='" + rawId + '\'' +
                ", name='" + name + '\'' +
                ", loginName='" + loginName + '\'' +
                ", sex='" + sex + '\'' +
                ", email='" + email + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                ", posts='" + posts + '\'' +
                ", postNames='" + postNames + '\'' +
                ", workPhone='" + workPhone + '\'' +
                ", no='" + no + '\'' +
                ", rawOrder='" + rawOrder + '\'' +
                ", parent='" + parent + '\'' +
                ", departmentName='" + departmentName + '\'' +
                '}';
    }
}
