package ext.plm.integration.hr;

public class CtHrQuery {

}
