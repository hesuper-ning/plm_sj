package ext.plm.integration.hr.mapper;

import ext.plm.integration.hr.bo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

@Mapper
public interface CtHrMapper {
   //添加Raw部门
   void addDepartmentRaw(CtHrDepartmentRawBo departmentRawBo)throws Exception ;
   //获取所有部门信息
   List<CtHrDepartmentRawBo> getDepartmentRaw()throws Exception ;
   //根据rawId获取子级部门根据信息
   List<CtHrDepartmentRawBo> getDepartmentRawByRawId(@Param("rawId") String rawId)throws Exception ;
   List<CtHrDepartmentRawBo> getDepartmentRawByRawIds(@Param("rawId") String rawId)throws Exception ;
   //添加部门
   void addDepartment(CtHrDepartmentBo departmentBo)throws Exception ;

   //添加Raw员工
   void addPersonRaw(CtHrPersonRawBo personRaw)throws Exception ;

   //添加员工
   void addPerson(CtHrPersonBo person)throws Exception ;

   //获取所有员工信息
   List<CtHrPersonBo> getPerson()throws Exception ;
   //获取有填写日报员工信息
   List<CtHrPersonBo> getHaveDatePerson()throws Exception ;
   List<CtHrPersonBo> getPersonByNoOrPost(@Param("no") String no, @Param("deptName") String[] deptName, @Param("postName") String[] postName, @Param("personNames") List<String> personNames) throws Exception;
   //获取所有员工信息
   List<CtHrPersonRawBo> getPersonRaw()throws Exception ;
   //添加职位
   void addPostRawBo(CtHrPostRawBo postRawBo)throws Exception ;

   //获取对应的职位名称
   Set<String> getPostName(@Param("rawId") String rawId)throws Exception ;

   //获取对应的部门名称
   String getDeptName(@Param("rawId") String rawId)throws Exception ;

   //获取所有部门
   List<CtHrDepartmentBo> getDept()throws Exception ;

   //根据rawId以及父级id获取部门信息
   CtHrDepartmentBo getDeptByRawIdAndFatherId(@Param("rawId") String rawId, @Param("fatherId") String fatherId)throws Exception ;


   //根据no获取用户信息
   CtHrPersonBo getPersonByNo(@Param("no") String no)throws Exception ;

   //根据loginNameList获取用户信息
   List<CtHrPersonBo> getPersonByLoginNameList(@Param("loginNameList") List loginNameList)throws Exception ;

   //根据no获取用户信息
   CtHrPersonBo getPersonByRealNo(@Param("no") String no)throws Exception ;

   //获取管理部门
   HashMap<String,String> getChargeDept(@Param("rawId") String rawId)throws Exception ;

   //根据部门名称获取部门编号
   String getDeptNoByName(@Param("deptName") String deptName);

    void clearAllInfo(@Param("tableName") String tableName);

   //获取所有部门名称
   List<HashMap<String, String>> getAllDept();
   //获取所有岗位名称
   List<HashMap<String, String>> getAllPost();
}
