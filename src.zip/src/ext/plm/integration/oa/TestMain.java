package ext.plm.integration.oa;

import ext.plm.bean.CtBeanService;
import ext.plm.common.CtConstant;
import wt.method.RemoteMethodServer;
import wt.services.ServiceFactory;

public class TestMain {

    //private  static CtSapService service = ServiceFactory.getService(CtSapService.class);
    private  static CtBeanService beanService = ServiceFactory.getService(CtBeanService.class);

    public static void main(String[] args) {
        System.out.println("======TestMain.java 开始调用  " + args[0] + "=============");
        try {
            RemoteMethodServer server = RemoteMethodServer.getDefault();
            if(CtConstant.isLocalEnv()||CtConstant.isTestEnv()){
                server.setUserName("wcadmin");
                server.setPassword("wcadmin");
            }

            if ("testUploadFile".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.oa.TestMain testUploadFile abcd
                Object[] params = new Object[1];
                params[0] = args[1];
                Object resultObj = beanService.doMethod(CtOaService.class,"testInvokeUploadFileUrl",params);
                System.out.println(">>>result="+resultObj.toString());
            }else if ("testCreateProblem".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.oa.TestMain testCreateProblem

                Object resultObj = beanService.doMethod(CtOaService.class,"testInvokeCreateProblem",null);
                System.out.println(">>>result="+resultObj.toString());
            } else if ("testInvokeSampleApply".equalsIgnoreCase(args[0])) {
                //测试启动OA样品承认流程
                //windchill ext.plm.integration.oa.TestMain testInvokeSampleApply
                //testInvokeSampleApply();
            } else if ("testCreateDoc".equalsIgnoreCase(args[0])) {
                //windchill ext.plm.integration.oa.TestMain testCreateDoc
                //testInvokeSampleApply();
                Object[] params = new Object[1];
                params[0] = args[1];
                Object resultObj = beanService.doMethod(CtOaService.class,"testCreateDoc",params);
                System.out.println(">>>result="+resultObj.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  /*  public static void testInvokeSampleApply() throws Exception{

        IPLMKmReviewWebserviceProxy proxy = new IPLMKmReviewWebserviceProxy();
        KmReviewParamterForm form = new KmReviewParamterForm();
        *//*formDate.setDocContent("文档内容");
        formDate.setDocSubject("文档标题1");
        formDate.setFdTemplateId("1111");
        formDate.setFormValues("{'akey':'bbbb'}");
        formDate.setDocStatus("10");*//*
        form.setFdTemplateId("164c5b452132b9ff2d4f1c74476a8013");
        form.setDocCreator("{\"PersonNo\": \"005210\"}");



        String formValues = "{\"fd_35bc5f80259488\":" + "[\"" + "171be8f11ef93f843cf08844faea27fd"
                + "\"]"
                + ",\"fd_35bc5f8552156e\":" + "\"" + "业务单元一" + "\""
                //+ ",\"fd_39c12a52b13d8e\":" + "\"" + "技术支持工程师" + "\""
                + ",\"fd_person_no\":" + "\"" + "003761" + "\""
                + ",\"fd_35bc5fe973c7b6\":" + "\"" + "66" + "\""
                + ",\"fd_35bc5fec00b074\":" + "\"" + "rxdtfygvubhinjmk"
                + "\""
                + ",\"fd_35bc604443640c\":" + "\"" + "2021-01-01" + "\""
                + ",\"fd_contract_num\":" + "\"" + "7" + "\""
                + ",\"fd_3600d5f0f26a38\":" + "\"" + "005" + "\""

                + ",\"fd_360025b06b5226\":" + "\"" + "女" + "\""
                + ",\"fd_366178be35c85a\":" + "\"" + "2019-08-22" + "\""
                + ",\"fd_366178d4681ec6\":" + "\"" + "大专" + "\""
                + ",\"fd_36617915fa886e\":" + "\"" + "机电一体化技术" + "\""
                + "}";

        // 流程参数
        //String flowParam = "{auditNode:\"请审核\", futureNodeId:\"N7\", changeNodeHandlers:[\"N7:1183b0b84ee4f581bba001c47a78b2d9;131d019fbac792eab0f0a684c8a8d0ec\"]}";
       // form.setFlowParam(flowParam);
        //formDate.set
        String result = proxy.addReview(form);
        System.out.println("result = " + result);
    }
*/




}
