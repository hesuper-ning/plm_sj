package ext.plm.integration.oa;

import ext.plm.problem.bo.CtProblemMgtBo;
import org.springframework.web.multipart.MultipartFile;
import wt.method.RemoteInterface;

import java.util.List;

@RemoteInterface
public interface CtOaService {

     //接收OA传递过来的问题
     void createPlmProblem(List<CtProblemMgtBo> problemInfoList) throws Exception;

     //接收OA传递的物料承认文档
     void createPlmPartDocs(List<MultipartFile> multipartFileList) throws Exception;

     //=============测试方法===========================
     //测试上传文件
     String  testInvokeUploadFileUrl(String param1) throws Exception;
     //测试问题管理接口
     String testInvokeCreateProblem() throws Exception;
     //测试问题管理接口
     String testCreateDoc(String partNumber) throws Exception;
     //软件物料
     String getSoftwareMaterials(String partNumber) throws Exception;

}
