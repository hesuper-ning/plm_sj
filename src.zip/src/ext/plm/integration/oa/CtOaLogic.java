package ext.plm.integration.oa;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtConstant;
import ext.plm.integration.oa.config.CtOaProperties;
import ext.plm.tool.doc.CtDocCreateTool;
import ext.plm.tool.doc.bo.CtDocCreateBo;
import ext.plm.util.*;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.CharArrayBuffer;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.springframework.web.multipart.MultipartFile;
import wt.doc.WTDocument;
import wt.httpgw.URLFactory;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.util.WTException;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CtOaLogic {


    //此logger已指向独立日志文件，如”OA-1909241037-2808-log4j.log"
    static Logger logger = Logger.getLogger(CtOaLogic.class);


    /**
     * 通过OA传过来的信息创建稳定那个
     * @param docInfo  文件信息json
     * @param primaryFileName 主文件
     * @param attachFileNames 附件
     * @throws Exception
     */
    public void creatPlmDocByOa(String docInfo, String primaryFileName, String attachFileNames) throws Exception {

        Map<String,String> map = (Map<String,String>)JSON.parse(docInfo);
        String docName = map.get("docName");
        String oaDocType = map.get("docType");
        String docUser = map.get("docUser");
        String docType= CtOaProperties.getProperty(oaDocType);
        if(!CtFormatUtil.hasContent(docType)){
            throw new Exception("没有在配置文件中找到与之对应的文档类型'"+oaDocType+"',请检查文件‘CtOaConstant.properties’");
        }
        WTUser user = CtUserUtil.getUserByAccountName(docUser);
        String processNumber = map.get("processNumber");
        String partNumber = map.get("partNumber");
        String moldNumber = map.get("moldNumber"); //模具编号
        String sealNumber = map.get("sealNumber"); //封样编号

        //创建文档
        CtDocCreateBo docCreateBo = new CtDocCreateBo();
        WTPart part = CtPartUtil.getPartByNumber(partNumber);
        //物料升个小版本
        part = (WTPart) CtACLUtil.checkout(part, "OA集成物料承认数据！");
        part = (WTPart) CtACLUtil.checkIn(part, "OA集成物料承认数据！");
        if(!CtFormatUtil.hasContent(part)){
            throw new Exception("该物料编号"+partNumber+"不存在,请检查物料编号");
        }



        String folderPath = part.getFolderPath();
        //创建的文档和对应的物料同一个库
        docCreateBo.setContainer(part.getContainer());
        docCreateBo.setDocType(docType);
        docCreateBo.setDocName(docName);
        docCreateBo.setCreateUser(user);
        docCreateBo.setPrimaryFileName(primaryFileName);
        docCreateBo.setPrimaryFilePath(getOaTempFilePath());
        //附件
        if(CtFormatUtil.hasContent(attachFileNames)){
            String[] split = attachFileNames.split("\\*");
            String attachmentName="";
            for (String s : split) {
                //换成分号分隔
                attachmentName = CtFormatUtil.combineStr(attachmentName, s, ";");
            }
            docCreateBo.setAttachmentFileNames(attachmentName);
            docCreateBo.setAttachmentPath(getOaTempFilePath());
        }
        if(part.getContainerName().contains("A01_物料&BOM")){
            docCreateBo.setFolderPath("/Default"+"/物料认证资料");

        }else {
            docCreateBo.setFolderPath(folderPath);
        }
        docCreateBo.setLifeCycleStateInnerName(CtConstant.STATE_RELEASED);//状态为“已发布”

        WTDocument doc = CtDocCreateTool.createDoc(docCreateBo);
        //文档属性赋值
        IBAUtil ibaUtil = new IBAUtil(doc);
        ibaUtil.setIBAValue("ct_processNumber",processNumber);
        ibaUtil.setIBAValue("ct_materialsnumber",partNumber);
        ibaUtil.updateIBAHolder(doc);
        //创建说明关系
        CtPartUtil.createDescribeLink(part,doc);

        //更新物料模具编号、封样编号属性

        try {
            IBAUtil partIba = new IBAUtil(part);
            partIba.setIBAValue("ct_Sealnumber", sealNumber);
            partIba.setIBAValue("ct_moldSizeCode", moldNumber);
            partIba.updateIBAHolder(part);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WTException("物料'" + part.getNumber() + "'修改属性模具编号、封样编号失败！");
        }
    }

    //获取OA临时文件夹，放在Windchill/temp/oaFile下
    public static String getOaTempFilePath() throws Exception{
        String folderPath = CtCommonUtil.getWTHomePath()+ File.separator+"temp"+ File.separator+"oaFile"+File.separator;
        return folderPath;
    }

    /**
     * 将主副文件信息合并，创建临时文件，并检查参数合法性
     * @param multipartFileList
     * @return Map 第一层map的 key为物料编码 （不同物料编码会创建各自的类型相同的文档）；第二层map为一个物料的多个文档，key只有两种，文件类型及
     * @throws Exception
     */
    public static Map<String,Map<String,String>> collectMergedFileInfo(List<MultipartFile> multipartFileList)throws Exception {
        String paramCheckError = ""; //参数不合法异常

        Map<String,Map<String,String>> mergedPartFileMap=new HashMap<>();
        for (MultipartFile file : multipartFileList) {
            String oneFileError = "";
            System.out.println(">>fileName="+file.getName()+">>>"+file.getOriginalFilename());
            String docInfo=file.getOriginalFilename();

            String folderPath = getOaTempFilePath();
            File folder = new File(folderPath);
            if (!folder.exists()) {
                folder.mkdirs();
            }

            String fileName = file.getName();
            file.transferTo(new File(folderPath+fileName));
            //一次性传多个文件，但是文件之间有主内容和附件之分

            Map<String,String> jsonMap = (Map<String,String>) JSON.parse(docInfo);
            String docType = jsonMap.get("docType");
            String partNumber = jsonMap.get("partNumber");
            //getOriginalFilename有\会报错，docName 改为传默认值，plm这边用fileName做docName
            jsonMap.put("docName",file.getName());
            docInfo=JSON.toJSONString(jsonMap);
            //先进行文件参数校验
            if(!CtFormatUtil.hasContent(partNumber)){
                oneFileError = CtFormatUtil.combineStr(oneFileError,"物料编码不能为空","\r\n");
            }
            String docUser = jsonMap.get("docUser");
            if(!CtFormatUtil.hasContent(docUser)){
                oneFileError = CtFormatUtil.combineStr(oneFileError,"文档创建人不能为空","\r\n");
            }
            WTUser user = CtUserUtil.getUserByAccountName(docUser);
            if(!CtFormatUtil.hasContent(user)){
                oneFileError = CtFormatUtil.combineStr(oneFileError,"文档创建人账户'"+docUser+"'在PLM不存在","\r\n");
            }
            WTPart part = CtPartUtil.getPartByNumber(partNumber);
            if(!CtFormatUtil.hasContent(part)){
                oneFileError = CtFormatUtil.combineStr(oneFileError,"物料编码'"+partNumber+"'在PLM不存在","\r\n");
            }

            //开始按物料编码维度合并文件信息

            Map<String,String> onePartFilesMap = null; //相同物料编码下的多个文件，key为文件类型
            if(mergedPartFileMap.containsKey(partNumber)){
                onePartFilesMap = mergedPartFileMap.get(partNumber);
            }else{
                onePartFilesMap = new HashMap<>();
            }

            //true 为附件，默认为主文件
            boolean isAttachFile=false;
            if(docType.contains("-")){
                isAttachFile=true;
                docType = docType.substring(0,docType.indexOf("-"));
            }
            if(!CtFormatUtil.hasContent(onePartFilesMap.get(docType))){
                onePartFilesMap.put(docType,fileName);
            }else {
                String s = onePartFilesMap.get(docType);
                //主文件默认放在第一个
                if(isAttachFile){
                    s+="*"+fileName;
                }else {
                    s=fileName+"*"+s;
                }
                onePartFilesMap.put(docType,s);
            }
            if(!isAttachFile){
                //只需要将主文件的信息放入map，用文件类型+_docInfo 为key
                onePartFilesMap.put(docType+"_docInfo",docInfo);
            }


            if (CtFormatUtil.hasContent(oneFileError)) {
                oneFileError = partNumber+"|"+jsonMap.get("docType")+"|存在错误：\r\n"+oneFileError;
                paramCheckError = CtFormatUtil.combineStr(paramCheckError, oneFileError, "\r\n");
            }

            mergedPartFileMap.put(partNumber, onePartFilesMap);

        }

        if (CtFormatUtil.hasContent(paramCheckError)) {
            throw new WTException("传入参数有误，请检查！\r\n" + paramCheckError);
        }

        return mergedPartFileMap;
    }


    //===============测试部分 开始===============================

    /**
     * 测试调用传送文件接口
     * @param docInfo
     * @return
     * @throws Exception
     */
    public static String testInvokeFileUploadUrl(String docInfo) throws Exception{
        //获取httpClient
        HttpClient client = HttpClients.createDefault();
        //获取URL基础路径
        URLFactory urlFactory = new URLFactory();
        HttpPost httpPost=null;
        String urlPath = "";
        if(CtConstant.isLocalEnv()){
            urlPath = "http://plmlocal.fhsj.com/Windchill/ptc1/customUpload/importPartFile";
             httpPost = new HttpPost(urlPath);
            httpPost.setHeader("Authorization","Basic d2NhZG1pbjp3Y2FkbWlu");

        }else if(CtConstant.isTestEnv()){
            urlPath = "http://plmdemo.fhsj.com:8885/Windchill/ptc1/customUpload/importPartFile";
            httpPost = new HttpPost(urlPath);
            httpPost.setHeader("Authorization","Basic d2NhZG1pbjp3Y2FkbWlu");

        }else if(CtConstant.isPrdEnv()){
            urlPath = "http://plm.fhsjdz.com/Windchill/ptc1/customUpload/importPartFile";
            httpPost = new HttpPost(urlPath);
            httpPost.setHeader("Authorization","Basic d2NhZG1pbjpmaHNqLmNvbQ==");

        }
        if(!CtFormatUtil.hasContent(urlPath)){
            throw new WTException("无法定位环境来获取Url");
        }

        System.out.println(">>>urlPath="+urlPath);
        String filePath1 = CtCommonUtil.getWTHomePath()+ File.separator+"cancel.png";
        String filePath2 = CtCommonUtil.getWTHomePath()+ File.separator+"cart.png";
        System.out.println(">>filePath1="+filePath1);
        File file1 = new File(filePath1);
        File file2 = new File(filePath2);
        //跳过登录验证
        //构建MultipartEntityBuilder
        MultipartEntityBuilder builder = MultipartEntityBuilder.create().setMode(HttpMultipartMode.RFC6532);
        builder.addTextBody("docInfo",docInfo, ContentType.create("text/plain", Consts.UTF_8));
//{"docName":"材质SGS报告.pdf","docType":"fd_39f8e26e3dd59e","docUser":"chang.zhou1","processNumber":"181b7659416f1ed96bf8443401595161","sealNumber":"FYZ-2208-1-50","partNumber":"123010022","moldNumber":"-"}

        String infoMes="{\"docName\":\"testDocName3\",\"docType\":\"fd_39f8e1e9b2f3b8\",\"docUser\":\"wcadmin\",\"processNumber\":\"12000\",\"partNumber\":\"102010001\"}";
        String infoMes2="{\"docName\":\"testDocName4\",\"docType\":\"fd_39f8e195ac7c2e-1233\",\"docUser\":\"wcadmin\",\"processNumber\":\"2222\",\"partNumber\":\"102010001\"}";
        builder.addBinaryBody("cancel.png",file1,ContentType.MULTIPART_FORM_DATA,infoMes);
        builder.addBinaryBody("cart.png",file2,ContentType.MULTIPART_FORM_DATA,infoMes2);
        //构建成功,后放入Post
        HttpEntity entity = builder.build();
        httpPost.setEntity(entity);
        HttpResponse response =null;
        //发送请求
        response = client.execute(httpPost);
        String resultCode = response.getStatusLine().getStatusCode()+"";
        System.out.println(">>>response="+resultCode);

        String responseResult = EntityUtils.toString(response.getEntity(),"utf-8");
        JSONObject result = (JSONObject) JSONObject.parse(responseResult);
        String status = result.getString("status");
        System.out.println("status = " + status);
        String message = result.getString("message");
        System.out.println("message = " + message);

        return status+"|"+message;
    }

    /**
     * 测试问题创建接口
     * @return
     * @throws Exception
     */
    public static String testInvokePlmProblemUrl() throws Exception{
        //获取httpClient
        HttpClient client = HttpClients.createDefault();
        //获取URL基础路径
        URLFactory urlFactory = new URLFactory();
        String urlPath = "";
        if(CtConstant.isLocalEnv()){
            urlPath = "http://plmlocal.fhsj.com/Windchill/ptc1/oa/createPlmProblem";
        }else if(CtConstant.isTestEnv()){
            urlPath = "http://plmdemo.fhsj.com:8885/Windchill/ptc1/oa/createPlmProblem";
        }
        if(!CtFormatUtil.hasContent(urlPath)){
            throw new WTException("无法定位环境来获取Url");
        }

        JSONArray problemList = new JSONArray();
        JSONObject aProblem = new JSONObject();
        aProblem.put("OANumber","OA-001");
        aProblem.put("description","问题A");
        aProblem.put("problemTerritory","软件");
        aProblem.put("problemSource","工艺");
        problemList.add(aProblem);

        String problemInfo = JSON.toJSONString(problemList);

        System.out.println(">>>urlPath="+urlPath);
        HttpPost httpPost = new HttpPost(urlPath);

        //跳过登录验证
        httpPost.setHeader("Authorization","Basic d2NhZG1pbjp3Y2FkbWlu");

        List<NameValuePair> pairs = new ArrayList<NameValuePair>();
        pairs.add(new BasicNameValuePair("problemInfo",problemInfo));
        pairs.add(new BasicNameValuePair("plmProductName","测试产品库"));
        pairs.add(new BasicNameValuePair("oaProcessId","1235"));

        httpPost.setEntity(new UrlEncodedFormEntity(pairs, "UTF-8"));
        HttpResponse response =null;
        //发送请求
        response = client.execute(httpPost);
        String resultCode = response.getStatusLine().getStatusCode()+"";
        System.out.println(">>>response="+resultCode);
        HttpEntity entity = response.getEntity();
        String entityStr = entityToString(entity);
        System.out.println(">>>entityStr="+entityStr);

        String responseResult = EntityUtils.toString(response.getEntity(),"utf-8");

        JSONObject result = (JSONObject) JSONObject.parse(responseResult);
        String status = result.getString("status");
        System.out.println("status = " + status);
        String message = result.getString("message");
        System.out.println("message = " + message);

        return status+"|"+message;
    }

    /**
     * 解析参数
     * @param entity
     * @return
     * @throws IOException
     */
    private static String entityToString(HttpEntity entity) throws IOException {
        String result = null;
        if (entity != null) {
            long lenth = entity.getContentLength();
            if (lenth != -1 && lenth < 2048) {
                result = EntityUtils.toString(entity, "UTF-8");
            } else {
                InputStreamReader reader1 = new InputStreamReader(entity.getContent(), "UTF-8");
                CharArrayBuffer buffer = new CharArrayBuffer(2048);
                char[] tmp = new char[1024];
                int l;
                while ((l = reader1.read(tmp)) != -1) {
                    buffer.append(tmp, 0, l);
                }
                result = buffer.toString();
            }
        }
        return result;
    }

    /**
     * 测试方法
     * @return
     * @throws IOException
     */
    public static String testCreateDoc(String partNumber) throws Exception {
        System.out.println("======partNumber"+partNumber);
        String result = null;
        //创建文档
        CtDocCreateBo docCreateBo = new CtDocCreateBo();
        WTPart part = CtPartUtil.getPartByNumber(partNumber);
        if(!CtFormatUtil.hasContent(part)){
            throw new Exception("该物料编号"+partNumber+"不存在,请检查物料编号");
        }
        //物料升个小版本
        part = (WTPart) CtACLUtil.checkout(part, "OA集成物料承认数据！");
        part = (WTPart) CtACLUtil.checkIn(part, "OA集成物料承认数据！");

        String folderPath = part.getFolderPath();
        //创建的文档和对应的物料同一个库
        docCreateBo.setContainer(part.getContainer());
        docCreateBo.setDocType("com.fhsj.Doc_wltp");
        docCreateBo.setDocName("docName");
        WTUser user=CtUserUtil.getUserByAccountName("wcadmin");
        if(!CtFormatUtil.hasContent(user)){
            user=CtUserUtil.getUserByDisplayName("wcadmin");
        }
        docCreateBo.setCreateUser(user);
        docCreateBo.setPrimaryFileName("cart.png");
        docCreateBo.setPrimaryFilePath(getOaTempFilePath());
        if(part.getContainerName().contains("A01_物料&BOM")){
            docCreateBo.setFolderPath("/Default"+"/物料认证资料");
        }else {
            docCreateBo.setFolderPath(folderPath);
        }
        docCreateBo.setLifeCycleStateInnerName(CtConstant.STATE_RELEASED);//状态为“已发布”

        WTDocument doc = CtDocCreateTool.createDoc(docCreateBo);
        return result;
    }

    //===============测试部分 结束===============================

    /**
     * 根据单号查询OA系统委托测试单
     * @param fdNumber
     * @throws Exception
     */
    public JSONObject getEntrustedTestingForm(String fdNumber) throws Exception {
        JSONObject result = null;
        CloseableHttpClient client = HttpClientBuilder.create().build();

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("fdNumber", fdNumber);
        String url = "https://home.fhsjdz.com/exterapi/plm/testinfo";
        HttpPost post = new HttpPost(url);
        String unicodeString = toUnicodeString(jsonObject.toJSONString());
        HttpEntity entity = new StringEntity(unicodeString, "UTF-8");
        post.setEntity(entity);
        post.setHeader("Content-Type", "application/json;charset=UTF-8");

        HttpResponse response = client.execute(post);
        StatusLine statusLine = response.getStatusLine();
        //请求状态码
        int statusCode = statusLine.getStatusCode();
        logger.debug(">>>>>>>>>>>statusCode = " + statusCode);
        if (200 != statusCode) {
            logger.error("查询OA系统委托测试单：" + statusLine.getReasonPhrase());
            throw new Exception("查询OA系统委托测试单：" + statusLine.getReasonPhrase());
        }
        String responseResult = EntityUtils.toString(response.getEntity(), "utf-8");
        logger.error("查询OA系统委托测试单返回的数据>>>>>>>>" + responseResult);
        if (CtFormatUtil.hasContent(responseResult)) {
            result = (JSONObject) JSONObject.parse(responseResult);
        }
        return result;
    }

    /**
     * 转Unicode编码
     * @param s
     * @return
     */
    private static String toUnicodeString(String s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0 && c <= 255) {
                sb.append(c);
            } else {
                String s1 = Integer.toHexString(c);
                while (s1.length() < 4) {
                    s1 = "0" + s1;
                }
                sb.append("\\u" + s1);
            }
        }
        return sb.toString();
    }
}
