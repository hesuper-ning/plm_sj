package ext.plm.integration.oa;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import ext.plm.common.CtResApiResult;
import ext.plm.problem.bo.CtProblemMgtBo;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.DefaultMultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Controller
public class CtOaController {

    //此logger已指向独立日志文件，如”OA-1909241037-2808-log4j.log"
    static Logger logger = Logger.getLogger(CtOaServiceImpl.class);

    @Autowired
    private CtOaService service;

    /**
     * 开放给OA接口： 接收OA传递的物料承认文件
     * @param docInfo
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/customUpload/importPartFile",method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT} )
    @ResponseBody
    public CtResApiResult importPartFile( @RequestParam("docInfo") String  docInfo
            , HttpServletRequest request, HttpServletResponse response){

        try {
            //ctPriceService.importChangePrice(multipartFile,docBranchId);
            DefaultMultipartHttpServletRequest multiPartRequest = null;
            if(request instanceof DefaultMultipartHttpServletRequest){
                multiPartRequest = (DefaultMultipartHttpServletRequest)request;
            }else{
                throw new Exception("接口调用形式不正确，无法正确获取文件！请联系管理员检查！");
            }
            MultiValueMap<String, MultipartFile> multiFileMap = multiPartRequest.getMultiFileMap();
            System.out.println(">>>oa file number:"+multiFileMap.keySet().size());
            List<Map<String,String>> list=new ArrayList<>();
            Date day=new Date();
            SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
            String format = df.format(day);
            String msg="";
            List<MultipartFile> multipartFileAllList = new ArrayList<>();
            for(String filekey : multiFileMap.keySet()){
                System.out.println(">>>OA 承认书传递文件key:"+filekey);
                List<MultipartFile> multipartFileList = multiFileMap.get(filekey);
                //key一般用一个，有多个就合并list
                multipartFileAllList.addAll(multipartFileList);
            }
            //创建对应文档
            service.createPlmPartDocs(multipartFileAllList);

            return CtResApiResult.success();
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 发布给OA接口：将OA问题传递给PLM
     * @param request
     * @return
     */
    @RequestMapping(value = "/oa/createPlmProblem",method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT} )
    @ResponseBody
    public CtResApiResult createPlmProblem(HttpServletRequest request){

        try {
            String problemInfo = request.getParameter("problemInfo");
            logger.info("1-集成信息："+problemInfo);
            if (!problemInfo.equals("[]")) {
                JSONArray jsonArray = JSONArray.parseArray(problemInfo);

                List<CtProblemMgtBo> problemList = JSONObject.parseArray(jsonArray.toJSONString(), CtProblemMgtBo.class);

                service.createPlmProblem(problemList);
            }

            return CtResApiResult.success();
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }

    /**
     * 发布给OA接口：将OA问题传递给PLM
     * @param request
     * @return
     */
    @RequestMapping(value = "/oa/getSoftwareMaterials",method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT} )
    @ResponseBody
    public CtResApiResult getSoftwareMaterials(HttpServletRequest request){

        try {
            String materialNumber = request.getParameter("materialNumber");
            logger.info("1-集成信息："+materialNumber);
            String  msg = "";
            if (!materialNumber.equals("[]") || StringUtils.isNotBlank(materialNumber)) {
                msg = service.getSoftwareMaterials(materialNumber);
            }
            logger.info("msg------------------------->"+  msg );
            return CtResApiResult.success(msg);
        }catch (Exception e){
            e.printStackTrace();
            return CtResApiResult.fail(e.getMessage());
        }
    }
}
