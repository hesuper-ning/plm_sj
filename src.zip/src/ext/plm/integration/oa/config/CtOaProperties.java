package ext.plm.integration.oa.config;

import ext.plm.mobileWorkReport.config.CtMobileWorkReportProperties;
import ext.plm.util.CtFormatUtil;
import org.springframework.stereotype.Component;

import java.io.InputStreamReader;
import java.util.Properties;

/**
 * @Author: lcd
 * @Date: 2021/9/17 16:17
 * @Description:
 */
public class CtOaProperties {

    static Properties ctOaProperties = new Properties();

    static {
        try {

            ctOaProperties.load(new InputStreamReader(
                    CtOaProperties.class.getResourceAsStream("CtOaConstant.properties"), "UTF-8"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    };

    /**
     * 查找配置项
     * @param key
     * @return
     * @throws Exception
     */
    public static String getProperty(String key) throws Exception{
        String result = "";
        String property = ctOaProperties.getProperty(key);
        if(CtFormatUtil.hasContent(property)) {
            result = property;
        }
        return result;
    }


}
