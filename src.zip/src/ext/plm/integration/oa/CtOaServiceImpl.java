package ext.plm.integration.oa;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import ext.plm.bean.CtBeanFactory;
import ext.plm.common.CtConstant;
import ext.plm.part.config.CtPartConstant;
import ext.plm.problem.CtProblemMgtService;
import ext.plm.problem.CtProblemVerifyServiceImpl;
import ext.plm.problem.bo.CtProblemMgtBo;
import ext.plm.problem.bo.CtProblemVerifyBo;
import ext.plm.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import wt.inf.container.WTContainer;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.vc.views.View;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class CtOaServiceImpl implements  CtOaService{

    //此logger已指向独立日志文件，如”OA-1909241037-2808-log4j.log"
    static Logger logger = Logger.getLogger(CtOaServiceImpl.class);


    @Autowired
    private CtProblemMgtService problemMgtService;


    /**
     * 创建PLM问题
     * @param problemInfoList
     * @throws Exception
     */
    @Override
    public void createPlmProblem(List<CtProblemMgtBo> problemInfoList) throws Exception {

        Transaction ts = new Transaction();
        try {
            logger.info("-----------------------------------------------------");
            CtProblemMgtBo problemMgtBo = null;
            if(problemInfoList.size() >0){
                problemMgtBo = problemInfoList.get(0);
                logger.info(">>>开始集成OA问题,OA编号："+problemMgtBo.getOaNumber());
                logger.info("2-集成信息："+JSON.toJSONString(problemInfoList));
            }else {
                logger.info("无数据传输");
                throw  new WTException("无数据传输");
            }

            ts.start();
            CtProblemVerifyServiceImpl verifyService = CtBeanFactory.newCtBeanFactory().getBean(CtProblemVerifyServiceImpl.class);

            List<CtProblemVerifyBo> verifyBos = new ArrayList<>();
            String territory = "";
            WTUser user = null;
            for (CtProblemMgtBo bo : problemInfoList) {


                CtProblemMgtBo mgtBo = problemInfoList.get(0);

                user = CtUserUtil.getUserByAccountName(bo.getCharger());
                //获取子问题信息
                CtProblemVerifyBo verifyBo = new CtProblemVerifyBo();
                verifyBo.setProblemTerritory(bo.getProblemTerritory());
                verifyBo.setUndertaker(user.getFullName());
                verifyBo.setOptimizeStrategy(bo.getOptimizeStrategy());
                verifyBo.setPlanFinishDate(bo.getPlanFinishDate());
                verifyBo.setIsAssign("YES");
                verifyBos.add(verifyBo);
                bo.setCharger(user.getFullName());
                territory = CtFormatUtil.combineStr(territory, bo.getProblemTerritory());
                if (bo.getProblemTerritory().equals("软件")){
                    mgtBo.setSoftwareCharger(bo.getCharger());
                }
                else if (bo.getProblemTerritory().equals("硬件")){
                    mgtBo.setHardwareCharger(bo.getCharger());

                }
                else if (bo.getProblemTerritory().equals("工艺")){
                    mgtBo.setCraftCharger(bo.getCharger());

                }
                else if (bo.getProblemTerritory().equals("结构")){
                    mgtBo.setFabricCharger(bo.getCharger());

                }
                else if (bo.getProblemTerritory().equals("测试")){
                    mgtBo.setTestCharger(bo.getCharger());

                }
                else if (bo.getProblemTerritory().equals("质量")){
                    mgtBo.setQualityCharger(bo.getCharger());

                }
                else if (bo.getProblemTerritory().equals("采购")){
                    mgtBo.setPurchaseCharger(bo.getCharger());

                }
                else if (bo.getProblemTerritory().equals("制造")){
                    mgtBo.setMakeCharger(bo.getCharger());

                }
                else if (bo.getProblemTerritory().equals("市场")){
                    mgtBo.setBazaarCharger(bo.getCharger());

                }
                else if (bo.getProblemTerritory().equals("其他")){
                    mgtBo.setElseCharger(bo.getCharger());
                }
            }


            CtProblemMgtBo mgtBo = problemInfoList.get(0);

            //获取产品库

            String partNumber = mgtBo.getEndPartNumber();

            WTPart part = CtPartUtil.getPartByNumber(partNumber);
            if(part == null){
                throw  new WTException("产品编码错误，PLM中不存在此编码:"+partNumber);
            }

            WTContainer container = part.getContainer();
            String containerOid = CtWTObjectUtil.getOid(container);
            System.out.println(">>>containerOid = " + containerOid);
            mgtBo.setContainerId(containerOid);
            //mgtBo.setContainerId("OR:wt.pdmlink.PDMLinkProduct:74254");

            mgtBo.setProblemTerritory(territory);
            mgtBo.setProblemStatus("已解决");

            //获取显示名称
            user = CtUserUtil.getUserByAccountName(mgtBo.getCreator());
            mgtBo.setCreator(user.getFullName());

            CtProblemMgtBo bo = problemMgtService.saveProblem(mgtBo);

            verifyService.addVerify(bo.getProblemNumber());

            for (CtProblemVerifyBo verifyBo : verifyBos) {
                verifyService.update(verifyBo,new EntityWrapper<CtProblemVerifyBo>().eq("DocBranchId",bo.getProblemNumber()).and().eq("problemTerritory",verifyBo.getProblemTerritory()));
            }

            ts.commit();
            logger.info(">>>OA问题集成成功！");
            ts = null;
        } catch (Exception e) {
            e.printStackTrace();
            logger.info(">>>OA问题集成失败！异常信息："+e.getMessage());
            throw new WTException("创建PLM问题接口失败！异常信息：" + e.getLocalizedMessage());
        } finally {
            if(ts != null){
                ts.rollback();
            }
        }

    }


    /**
     * 接收OA传递的物料承认文档
     * @param multipartFileList
     * @throws Exception
     */
    @Override
    public void createPlmPartDocs(List<MultipartFile> multipartFileList) throws Exception {

        Transaction transaction = null;
        try {
            //合并主文件和附件信息
            Map<String, Map<String, String>> mergedPartFileMap = CtOaLogic.collectMergedFileInfo(multipartFileList);
            logger.info("----------------------------------------------");
            logger.info(">>>开始接收OA传入物料承认文档,物料数量："+mergedPartFileMap.keySet().size());
            CtOaLogic ctOaLogic = new CtOaLogic();

            transaction = new Transaction();
            transaction.start();
            for (String partNumber: mergedPartFileMap.keySet()) {
                Map<String, String> onePartMergedFileMap = mergedPartFileMap.get(partNumber);

                //按文件类型遍历
                for (String key : onePartMergedFileMap.keySet()) {
                    if (key.contains("docInfo")){
                        //遍历时只遍历文件类型key，文件信息用key+_docInfo获取
                        continue;
                    }
                    String docInfo = onePartMergedFileMap.get(key + "_docInfo");
                    if (!CtFormatUtil.hasContent(docInfo)) {
                        throw new WTException(partNumber + "下的文件类型'" + key + "'的文件信息收集出错！");
                    }
                    String filePath = onePartMergedFileMap.get(key);
                    logger.info(">>>创建文件："+filePath);
                    logger.info(">>>文件信息：" + docInfo);
                    String[] split = filePath.split("\\*");
                    if(split.length==1){
                        //只有主内容的情况
                        ctOaLogic.creatPlmDocByOa( docInfo,  filePath, "");
                    }else if(split.length>1){
                        //有附件的情况
                        String attachmentPath = filePath.substring(filePath.indexOf("*")+1);
                        ctOaLogic.creatPlmDocByOa( docInfo,  split[0], attachmentPath);
                    }else {
                        throw new Exception(partNumber + "下的文件类型'" + key + "'的文件路径收集出错！");
                    }
                }
            }
            transaction.commit();;
            transaction = null;
            logger.info(">>>文档接收完成！");
        } catch (Exception e) {
            e.printStackTrace();
            logger.info(">>>文档接收异常！异常信息："+e.getLocalizedMessage());
            throw new WTException("接收OA传递的物料承认文档！异常信息：" + e.getLocalizedMessage());
//            throw e;
        }finally {
            if(transaction != null){
                transaction.rollback();
            }
        }

        //清理临时 文件,2天以上的删除
        File tempFolder = new File(CtOaLogic.getOaTempFilePath());
        if(tempFolder.exists()){
            CtFileUtil.deleteFileByTime(tempFolder,2*24*3600*1000);
        }

    }

    //=============测试方法 开始===========================
    /**
     * 测试调用文件传递接口
     * @param param1
     * @return
     * @throws Exception
     */
    @Override
    public String testInvokeUploadFileUrl(String param1) throws Exception {

        return CtOaLogic.testInvokeFileUploadUrl(param1);
    }

    @Override
    public String testInvokeCreateProblem() throws Exception {
        return  CtOaLogic.testInvokePlmProblemUrl();
    }

    @Override
    public String testCreateDoc(String partNumber) throws Exception {
        return  CtOaLogic.testCreateDoc( partNumber);
    }

    @Override
    public String getSoftwareMaterials(String partNumberStr) throws Exception {
        JSONArray localJSONArray = new JSONArray();
        String[] materialNumArr = partNumberStr.split(",");
        for(String partNumber : materialNumArr){
            WTPart wtPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_MANUFACTURING);
            if(null == wtPart){
                wtPart = CtPartUtil.getPartByNumber(partNumber, CtConstant.VIEW_DESIGN);
            }
            if(null == wtPart){
                logger.info(">>>物料为空---》"+partNumber);
                continue;
            }
//            List<WTPart> partsInBOM = CtBomUtil.getPartsInBOMByView(wtPart, null);//获取下阶bom清单
            List<WTPart> partsInBOM = new ArrayList<WTPart>();
            CtBomUtil.getAllPartsInBOMByView(wtPart,partsInBOM,null);
//        StringBuilder sb = new StringBuilder("");
            for (WTPart tmpPart : partsInBOM) {
                JSONObject localJSONObject = new JSONObject();
                String partType = CtWTObjectUtil.getTypeIdentifier(tmpPart);
                System.out.println(">>>partType=" + partType);
                String partTypeLastName = partType.substring(partType.lastIndexOf(".") + 1);
                System.out.println(">>>partTypeLastName=" + partTypeLastName);
//                IBAUtil ibaUtil = new IBAUtil(wtPart);
//                String clfName = ibaUtil.getIBAValue("fhsj_Classification");
                System.out.println(partNumber + "---->139>>>partType=" + tmpPart.getNumber() + "<-------->" + partTypeLastName);
                System.out.println(partNumber + "<----->" + ("ct_fhsjsoftware".equalsIgnoreCase(partTypeLastName) && (tmpPart.getNumber().startsWith("13901")||tmpPart.getNumber().startsWith("13902")||tmpPart.getNumber().startsWith("13903")
                        ||tmpPart.getNumber().startsWith("13905"))));
                if ("ct_fhsjsoftware".equalsIgnoreCase(partTypeLastName) && (tmpPart.getNumber().startsWith("13901")||tmpPart.getNumber().startsWith("13902")||tmpPart.getNumber().startsWith("13903")
                        ||tmpPart.getNumber().startsWith("13905"))) {
               /* if(StringUtils.isNotBlank(sb.toString())){
                    sb.append(",").append(tmpPart.getNumber());
                }else {
                    sb.append(tmpPart.getNumber());
                }*/
                    System.out.println( partNumber + "<-------->" + tmpPart.getNumber());
                    localJSONObject.put("materialNumber",partNumber);
                    localJSONObject.put("matercode",tmpPart.getNumber());
                    IBAUtil ibaUtiltmp = new IBAUtil(tmpPart);
                    String partDesc = ibaUtiltmp.getIBAValue(CtPartConstant.IBA_MATERIAL_DESCRIPTION);
                    localJSONObject.put("matertext",partDesc);
                    localJSONArray.put(localJSONObject);
                }
            }
        }

        return localJSONArray.toJSONString();
    }
    //=============测试方法 结束===========================

}
