package ext.plm.listener;

import com.ptc.projectmanagement.plan.PlanActivity;
import ext.plm.adTool.CtAdToolLogic;
import ext.plm.adTool.CtAdToolQuery;
import ext.plm.adTool.CtAdToolService;
import ext.plm.adTool.bo.CtCentralLibraryBo;
import ext.plm.adTool.bo.CtCentralLibraryParamsBo;
import ext.plm.adTool.config.CtAdToolProperties;
import ext.plm.bean.CtBeanFactory;
import ext.plm.bom.CtBomLogic;
import ext.plm.bom.CtVersionBaseline;
import ext.plm.bom.baselineQuery.service.CtBomBaselineQueryServiceImpl;
import ext.plm.common.CtConstant;
import ext.plm.doc.CtDocLogic;
import ext.plm.doc.CtDocMaterialsNumber;
import ext.plm.mobileWorkReport.CtMobileWorkReportLogic;
import ext.plm.newec.helper.CtECRApprovalRecordsHelper;
import ext.plm.part.CtMovePartFolder;
import ext.plm.part.CtPartLogic;
import ext.plm.sampleConfirmation.CtSampleConfirmationFunction;
import ext.plm.sjlistener.SjCheckBomRoHS;
import ext.plm.temporaryTechnicalChanges.CtTemporaryChangesProcessFunction;
import ext.plm.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.workspaces.EPMWorkspaceManagerEvent;
import wt.events.KeyedEvent;
import wt.events.KeyedEventListener;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManagerEvent;
import wt.fc.collections.WTKeyedMap;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleServiceEvent;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.ownership.OwnershipServiceEvent;
import wt.part.WTPart;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.VersionControlServiceEvent;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.WorkInProgressServiceEvent;
import wt.workflow.engine.WfEngineHelper;
import wt.workflow.engine.WfEngineServerHelper;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WorkItem;
import wt.workflow.work.WorkItemLink;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.*;

//import ext.plm.bom.CtVersionBaseline;
//import ext.plm.doc.CtDocMaterialsNumber;
public class StandardCtListenerService extends StandardManager implements CtListenerService, Serializable {

	private static final long serialVersionUID = 2185048357843364116L;

	private static final String CLASSNAME = StandardCtListenerService.class.getName();

	
	private KeyedEventListener listener;

	@Override
	public String getConceptualClassname() {
		return CLASSNAME;
	}

	public static StandardCtListenerService newStandardCtListenerService() throws WTException {
		StandardCtListenerService instance = new StandardCtListenerService();
		instance.initialize();
		return instance;
	}

	@Override
	protected void performStartupProcess() throws ManagerException {
		
		listener = new CtListenerEventListener(this.getConceptualClassname());
		
//		wt.ownership.OwnershipServiceEvent/POST_CHANGEOWNER
		getManagerService().addEventListener(listener,
				WorkInProgressServiceEvent.generateEventKey(WorkInProgressServiceEvent.POST_CHECKIN));
		getManagerService().addEventListener(listener, 
				PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_STORE));
		
		 getManagerService().addEventListener(listener, 
				 PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_MODIFY));

		 getManagerService().addEventListener(listener,
				 PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_DELETE));

		getManagerService().addEventListener(listener,
				PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.UPDATE));
		getManagerService().addEventListener(listener,
				PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.INSERT));
		
		getManagerService().addEventListener(listener, 
				VersionControlServiceEvent.generateEventKey(VersionControlServiceEvent.NEW_VERSION));

		getManagerService().addEventListener(listener,
				LifeCycleServiceEvent.generateEventKey(LifeCycleServiceEvent.STATE_CHANGE));
		getManagerService().addEventListener(listener,
				OwnershipServiceEvent.generateEventKey(OwnershipServiceEvent.POST_CHANGEOWNER));

		getManagerService().addEventListener(listener,
				EPMWorkspaceManagerEvent.generateEventKey(EPMWorkspaceManagerEvent.POST_WORKSPACE_CHECKIN));
	}

	class CtListenerEventListener extends ServiceEventListenerAdapter {

		public CtListenerEventListener(String manager_name) {
			super(manager_name);
		}

		@Override
		public void notifyVetoableEvent(Object eve) throws Exception {
			if (!(eve instanceof KeyedEvent))
				return;

			KeyedEvent eventObject = (KeyedEvent) eve;
			
			if (eventObject instanceof WorkInProgressServiceEvent) {
				WorkInProgressServiceEvent event = (WorkInProgressServiceEvent) eve;
				//注意：POST_CHECKIN在创建时不生效，只在编辑检入点确定时生效,而且获取的值是页面编辑之前的值，不适合做编辑时的校验
				if (eventObject.getEventType().equals(
						WorkInProgressServiceEvent.POST_CHECKIN)) {
					Object obj = event.getEventTarget();
					if(obj instanceof WTPart) {
						String errorMsg = "";
						WTPart part = (WTPart)obj;
						String number = part.getNumber();
						String viewName = part.getViewName();
						part = CtPartUtil.getPartByNumber(number,viewName);
                        // 2026-06-05 lvtian 添加BOM结构环保属性校验
                        // 由于检入监听事件 在系统中获取到的是检入前的版本 故需要根据部件编号和视图在系统中找到最新版本对象
                        SjCheckBomRoHS.checkBomRoHS(part);
						ArrayList<WTPart> checkPartList = new ArrayList<>();
						checkPartList.add(part);
						//校验BOM子阶不能重复
						errorMsg += CtBomLogic.checkBom_duplicateMaterial(checkPartList);
						if(CtFormatUtil.hasContent(errorMsg)){
							throw new Exception("检入失败:"+errorMsg);
						}
						WTPart originalCopy =(WTPart)event.getOriginalCopy();
						//监听试产物料M视图是否有改动
						boolean b = CtPartLogic.checkWhetherChange(originalCopy, part);
						if(b){
							throw new Exception("检入失败:试产物料检入时不允许编辑物料属性以及BOM结构!");
						}
						//检入时按物料描述规则更新到研发描述
						CtPartLogic.genPartDesc(part);
                        //lzp start
                        CtDocMaterialsNumber.modifyDocMaterialsNumber(event);
						CtPartLogic.changePartName(event);
						//CtVersionBaseline.versionBaseline(event);
						//lzp end

						CtAdToolLogic.getInstance().pcbWarehousing(originalCopy, part);

						CtBomLogic.checkMbomSonPart(part);//MBOM子件合法性校验

                        //heqingbo 处理分数start
                        part = (WTPart) PersistenceHelper.manager.refresh(part);
                        Map<String, String> msgMap = new TreeMap<>();
                        CtBomLogic.dealFraction(part, msgMap);
                        if (msgMap.size() > 0) {
                            StringBuilder msg = new StringBuilder();
                            for (Map.Entry<String, String> entry : msgMap.entrySet()) {
                                msg.append(entry.getValue());
                            }
                            throw new Exception("以下物料的数量与分数转换值有差异，请更新后重试（按照编码的升序进行展示）：\r\n" + msg.toString());
                        }
                        //heqingbo 处理分数end

                        //2023/11/21 校验10101印制板，拼板分数数量必须为分数start
                        CtPartLogic.checkBoardFraction(part);
                        //2023/11/21 校验10101印制板，拼板分数数量必须为分数end

                        //2024/04/17 校验打样物料不能作为非打样物料的子项start
                        CtBomLogic.checkBom(part);
                        //2023/04/17 校验打样物料不能作为非打样物料的子项end

                        //保存关联Design视图物料
                        WTUser curUser = (WTUser) SessionHelper.manager.getPrincipal();
                        CtPartLogic.saveDesignPart(part, originalCopy, null, curUser,true);

                        //保存BOM基线
                        CtBomBaselineQueryServiceImpl.saveBomBaselineLink(part);

                        CtAdToolService ctAdToolService = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolService.class);
                        ctAdToolService.handlePartEditWarehousing(part);
                    } else if (obj instanceof WTDocument) {
                        //lzp start
                        CtDocLogic.modifyRemarks(event);
                        //lzp end
                    }
                    return;
                }
            }

            if (eventObject instanceof PersistenceManagerEvent) {
                PersistenceManagerEvent event = (PersistenceManagerEvent) eve;
                //注意： POST_STORE创建时生效，但在编辑时是检出时生效（非检入时生效）
                if (eventObject.getEventType().equals(PersistenceManagerEvent.POST_STORE)) {
                    Object obj = event.getEventTarget();
                    if (obj instanceof WTPart) {
                        WTPart part = (WTPart) obj;

                        ////lzp 修订之后更新文档关联关系
                        //CtPartLogic.updateAssociationRelationships(part);
                        ////lzp

                        //生成物料编号
                        String versionInfo = CtVersionUtil.getVersionInfo(part);
                        String viewName = part.getViewName();
                        System.out.println("======viewName" + viewName + "=====versionInfo====" + versionInfo);
                        boolean workingCopy = WorkInProgressHelper.isWorkingCopy(part);
                        System.out.println("======workingCopy" + workingCopy);
                        if ("A.1".equals(versionInfo) && !workingCopy && CtFormatUtil.hasContent(viewName)) {
                            WTPart dPart = CtPartUtil.getPartByNumber(part.getNumber(), CtConstant.VIEW_DESIGN);
                            if ((CtConstant.VIEW_MANUFACTURING.equals(viewName) && null == dPart) || CtConstant.VIEW_DESIGN.equals(viewName)) {
                                //检入时按物料描述规则更新到研发描述
                                CtPartLogic.genPartDesc(part);
                                CtPartLogic.genPartNumberInListener(part);
                                CtMovePartFolder.moveFolder(part);
                            }
                        }

                        //2023/11/21 校验10101印制板，拼板分数数量必须为分数start
                        CtPartLogic.checkBoardFraction(part);
                        //2023/11/21 校验10101印制板，拼板分数数量必须为分数end

                        //保存BOM基线
                        CtBomBaselineQueryServiceImpl.saveBomBaselineLink(part);

					}else if(obj instanceof WTDocument) {
						WTDocument doc = (WTDocument) obj;
						//移动文档
						CtDocLogic.moveFolder(doc);
						boolean workingCopy = WorkInProgressHelper.isWorkingCopy(doc);
						String versionInfo = CtVersionUtil.getVersionInfo(doc);
						//标准文件流水号生成
						if("A.1".equals(versionInfo)&& !workingCopy){
							CtDocLogic.genStandardNumber(doc);
						}
					}
					return ;
				//	POST_MODIFY , 编辑时点击保存或检入生效
				}else if(eventObject.getEventType().equals(PersistenceManagerEvent.POST_MODIFY)) {
					Object obj = event.getEventTarget();
					if(obj instanceof WTPart) {
						WTPart part =(WTPart)obj;

						//检入时按研发描述规则更新到研发描述
						//lzp start
						CtPartLogic.genPartDesc(part);
						//lzp end

						//部件检入时校验EBOM中的物料是否在MBOM中  暂时不加此校验
						//CtBomLogic.checkEBOMInMBOM(part);
					}else if(obj instanceof WTDocument) {

					}else if(obj instanceof PlanActivity) {

					}
				}else if(eventObject.getEventType().equals(PersistenceManagerEvent.POST_DELETE)) {
					Object obj = event.getEventTarget();
					if(obj instanceof PlanActivity) {
					}
				}else if(eventObject.getEventType().equals(PersistenceManagerEvent.UPDATE)) {
					Object obj = event.getEventTarget();
					if (obj instanceof WorkItem){
						WorkItem workItem = (WorkItem) obj;
						if (!workItem.canSetupParticipants()&&!workItem.isComplete()){
							
						}
					}
				} else if (eventObject.getEventType().equals(PersistenceManagerEvent.INSERT)) {
					Object obj = eventObject.getEventTarget();
					if (obj instanceof WorkItemLink) {
						WorkItemLink workItemLink = (WorkItemLink) obj;
						WorkItem workItem = workItemLink.getWorkItem();
						CtMobileWorkReportLogic.sendMsgToDingTalk(workItem);
					}
				}

            }

            if (eventObject instanceof VersionControlServiceEvent) {
                VersionControlServiceEvent event = (VersionControlServiceEvent) eve;
                if (eventObject.getEventType().equals(
                        VersionControlServiceEvent.NEW_VERSION)) {
                    Object obj = event.getEventTarget();
                    if (obj instanceof WTPart) {
                        WTPart part = (WTPart) obj;
                        //打样物料修订时，设置状态为“创建中”
                        String partNumber = part.getNumber();
                        if(partNumber.endsWith("D01")){
                            String versionInfo = part.getVersionInfo().getIdentifier().getValue();
                            boolean workingCopy = WorkInProgressHelper.isWorkingCopy(part);
                            if(!"A".equals(versionInfo) && !workingCopy){
                                //删除修订时起的多余的流程
                                WTPrincipal currentPrincipal = SessionHelper.getPrincipal();
                                SessionHelper.manager.setAdministrator();//设置管理员权限
                                try{
                                    LifeCycleHelper.service.setLifeCycleState(part, State.toState("create"));
                                    WfProcess process = CtWorkFlowUtil.getProcessByPbo(part);
                                    if(process!=null){
                                        WfEngineHelper.service.deleteProcess(process);
                                    }
                                }finally {
                                    if(null != currentPrincipal){
                                        SessionHelper.manager.setPrincipal(currentPrincipal.getName());// 改session
                                    }
                                }
                            }
                        }

                        //保存BOM基线
                        CtBomBaselineQueryServiceImpl.saveBomBaselineLink(part);
                    } else if (obj instanceof WTDocument) {
                        WTDocument doc = (WTDocument) obj;
                        WTDocument preDoc = (WTDocument) CtVersionUtil.getPreviousVersion(doc.getMaster());
                        if (CtFormatUtil.hasContent(preDoc)) {
                            CtDocLogic.updateDocRefLink(doc, preDoc);
                        }
                        //修改状态设置临时权限
//						CtSoftwareBurningLogic.listenSetDownload(doc, "newVersion");
					}
					return ;
				}
			}

			if (eventObject instanceof LifeCycleServiceEvent) {
				LifeCycleServiceEvent event = (LifeCycleServiceEvent) eve;
				if (eventObject.getEventType().equals(LifeCycleServiceEvent.STATE_CHANGE)) {
					Object obj = event.getEventTarget();
					if(obj instanceof WTPart) {
						WTPart part = (WTPart) obj ;
						CtAdToolLogic ctAdToolLogic = CtAdToolLogic.getInstance();
						if (!ctAdToolLogic.isCanWarehousing(part)) return;

						String state = part.getLifeCycleState().getDisplay(Locale.CHINA);
						String libraryStatus = CtAdToolProperties.getInstance().getStringValue(state);
						if (StringUtils.isEmpty(libraryStatus)) return;

						try {
							// 跟库中数据比较
							CtAdToolService ctAdToolService = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolService.class);
							CtCentralLibraryParamsBo paramsBo = new CtCentralLibraryParamsBo();
							paramsBo.setPartNumber(part.getNumber());
							String tableName = ctAdToolLogic.getCentralLibraryTableName(part);
							paramsBo.setTableName(tableName);
							List<CtCentralLibraryBo> boList = ctAdToolService.getCentralLibrary(paramsBo);
							if (CollectionUtils.isEmpty(boList)) return;

							CtCentralLibraryBo bo = boList.get(0);
							if (!libraryStatus.equals(bo.getMaterialStatus())) {
								CtAdToolQuery ctAdToolQuery = CtBeanFactory.newCtBeanFactory().getBean(CtAdToolQuery.class);
								for (CtCentralLibraryBo itemBo : boList) {
									ctAdToolLogic.loadCentralLibraryBo(itemBo, part);
									itemBo.setTableName(tableName);
									itemBo.setModifyTime(new Date());// 做更新操作
									ctAdToolQuery.updateById(itemBo);
									ctAdToolLogic.syncTempCentralLibrary(part, libraryStatus);
								}
							}
						} catch (Exception e) {
							System.out.println("更新物料：" + part.getNumber() + " 在AD库的状态【" + libraryStatus + "】失败！");
							e.printStackTrace();
						}
					}else if(obj instanceof WTDocument){
						WTDocument doc = (WTDocument) obj ;
						//修改状态设置临时权限
//						CtSoftwareBurningLogic.listenSetDownload(doc, "changeState");


					}
				}
			}

            if (eventObject instanceof OwnershipServiceEvent) {
                OwnershipServiceEvent event = (OwnershipServiceEvent) eve;
                System.out.println(event);
                if (event.getEventType().equals(OwnershipServiceEvent.POST_CHANGEOWNER)) {
                    Object obj = event.getEventTarget();
                    Timestamp time = new Timestamp(System.currentTimeMillis());
                    System.out.println("执行了任务逾期队列逾期【时间：" + time + "】" + "===流程名");
                    //任务重新委派时发送通知
                    if (obj instanceof WorkItem) {
                        WorkItem workItem = (WorkItem) obj;
                        //lzp start生产紧急协调单更改表单人员为被委派人员
                        CtTemporaryChangesProcessFunction.delegate(workItem);
                        CtECRApprovalRecordsHelper.delegate(workItem);
                        CtSampleConfirmationFunction.delegate(workItem);
                        //lzp end
                        CtMobileWorkReportLogic.sendMsgToDingTalk(workItem);
                    }
                    return;
                }
            }

			if (eventObject instanceof EPMWorkspaceManagerEvent) {
				EPMWorkspaceManagerEvent event = (EPMWorkspaceManagerEvent) eve;
				if (eventObject.getEventType().equals(
						EPMWorkspaceManagerEvent.POST_WORKSPACE_CHECKIN)) {
					Object targetObject = event.getEventTarget();
					if (targetObject instanceof WTKeyedMap) {
						WTKeyedMap keyedMap = (WTKeyedMap) targetObject;
						for (Object key : keyedMap.keySet()) {
							ObjectReference objRef = (ObjectReference) key;
							Persistable persistable = objRef.getObject();
							if (persistable instanceof EPMDocument) {
								EPMDocument epmDoc = (EPMDocument) persistable;
								String number = epmDoc.getNumber();
								IBAUtil epmIbaUtil = new IBAUtil(epmDoc);
								String epmCadName = epmDoc.getCADName();
								if (epmCadName.contains(".DRW") || epmCadName.contains(".drw")) {
									EPMDocument epmDocument = CtEPMDocUtil.get3Dby2D(epmDoc);
									if (epmDocument != null) {
										IBAUtil ibaUtil = new IBAUtil(epmDocument);
										String ct_gbCode = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_gbCode"))) {
											ct_gbCode = ibaUtil.getIBAValue("ct_gbCode");
										}
										epmIbaUtil.setIBAValue("ct_gbCode", ct_gbCode);//国标代号
										String ct_isRohs = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_isRohs"))) {
											ct_isRohs = ibaUtil.getIBAValue("ct_isRohs");
										}
										epmIbaUtil.setIBAValue("ct_isRohs", ct_isRohs);//是否RoHS
										String ct_material = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_material"))) {
											ct_material = ibaUtil.getIBAValue("ct_material");
										}
										epmIbaUtil.setIBAValue("ct_material", ct_material);//材质
										String ct_Materialname = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_Materialname"))) {
											ct_Materialname = ibaUtil.getIBAValue("ct_Materialname");
										}
										epmIbaUtil.setIBAValue("ct_Materialname", ct_Materialname);//物料名称
										String ct_ME_VERSION = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_ME_VERSION"))) {
											ct_ME_VERSION = ibaUtil.getIBAValue("ct_ME_VERSION");
										}
										epmIbaUtil.setIBAValue("ct_ME_VERSION", ct_ME_VERSION);//结构内部版本
										String Ct_PART_NUMBER = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("Ct_PART_NUMBER"))) {
											Ct_PART_NUMBER = ibaUtil.getIBAValue("Ct_PART_NUMBER");
										}
										epmIbaUtil.setIBAValue("Ct_PART_NUMBER", Ct_PART_NUMBER);//物料编号
										String ct_PROD_NAME = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_productName"))) {
											ct_PROD_NAME = ibaUtil.getIBAValue("ct_productName");
										}
										epmIbaUtil.setIBAValue("ct_productName", ct_PROD_NAME);//产品名称
										String ct_productModel = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_productModel"))) {
											ct_productModel = ibaUtil.getIBAValue("ct_productModel");
										}
										epmIbaUtil.setIBAValue("ct_productModel", ct_productModel);//产品型号
										String ct_sfcjwfg = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_sfcjwf"))) {
											ct_sfcjwfg = ibaUtil.getIBAValue("ct_sfcjwf");
										}
										epmIbaUtil.setIBAValue("ct_sfcjwf", ct_sfcjwfg);//是否曾经外发过
										String ct_specification = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_specification"))) {
											ct_specification = ibaUtil.getIBAValue("ct_specification");
										}
										epmIbaUtil.setIBAValue("ct_specification", ct_specification);//规格
										String ct_surfaceTreatment = "";
										if(CtFormatUtil.hasContent(ibaUtil.getIBAValue("ct_surfaceTreatment"))) {
											ct_surfaceTreatment = ibaUtil.getIBAValue("ct_surfaceTreatment");
										}
										epmIbaUtil.setIBAValue("ct_surfaceTreatment", ct_surfaceTreatment);//表面处理
										epmIbaUtil.updateIBAHolder(epmDoc);
									}
								}
							}
						}
					}
				}
			}
		}
	}

}
