package ext.plm.listener;

public interface CtListenerService {

}
