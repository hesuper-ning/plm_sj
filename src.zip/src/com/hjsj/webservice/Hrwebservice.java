/**
 * Hrwebservice.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.hjsj.webservice;

public interface Hrwebservice extends javax.xml.rpc.Service {
    public String gethrwebserviceHttpPortAddress();

    public com.hjsj.webservice.HrwebservicePortType gethrwebserviceHttpPort() throws javax.xml.rpc.ServiceException;

    public com.hjsj.webservice.HrwebservicePortType gethrwebserviceHttpPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
