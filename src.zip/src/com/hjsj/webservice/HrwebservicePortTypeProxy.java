package com.hjsj.webservice;

public class HrwebservicePortTypeProxy implements HrwebservicePortType {
  private String _endpoint = null;
  private HrwebservicePortType hrwebservicePortType = null;
  
  public HrwebservicePortTypeProxy() {
    _initHrwebservicePortTypeProxy();
  }
  
  public HrwebservicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initHrwebservicePortTypeProxy();
  }
  
  private void _initHrwebservicePortTypeProxy() {
    try {
      hrwebservicePortType = (new HrwebserviceLocator()).gethrwebserviceHttpPort();
      if (hrwebservicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)hrwebservicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)hrwebservicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (hrwebservicePortType != null)
      ((javax.xml.rpc.Stub)hrwebservicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public HrwebservicePortType getHrwebservicePortType() {
    if (hrwebservicePortType == null)
      _initHrwebservicePortTypeProxy();
    return hrwebservicePortType;
  }
  
  public String sendProcInfo(String in0, String in1) throws java.rmi.RemoteException{
    if (hrwebservicePortType == null)
      _initHrwebservicePortTypeProxy();
    return hrwebservicePortType.sendProcInfo(in0, in1);
  }
  
  public String searchOrgInfo(String in0) throws java.rmi.RemoteException{
    if (hrwebservicePortType == null)
      _initHrwebservicePortTypeProxy();
    return hrwebservicePortType.searchOrgInfo(in0);
  }
  
  
}