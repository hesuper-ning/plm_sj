/**
 * HrwebserviceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.hjsj.webservice;

public class HrwebserviceLocator extends org.apache.axis.client.Service implements Hrwebservice {

    public HrwebserviceLocator() {
    }


    public HrwebserviceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public HrwebserviceLocator(String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for hrwebserviceHttpPort
    private String hrwebserviceHttpPort_address = "http://172.30.10.113:8080/hrwebservice_inter/services/hrwebservice";

    public String gethrwebserviceHttpPortAddress() {
        return hrwebserviceHttpPort_address;
    }

    // The WSDD service name defaults to the port name.
    private String hrwebserviceHttpPortWSDDServiceName = "hrwebserviceHttpPort";

    public String gethrwebserviceHttpPortWSDDServiceName() {
        return hrwebserviceHttpPortWSDDServiceName;
    }

    public void sethrwebserviceHttpPortWSDDServiceName(String name) {
        hrwebserviceHttpPortWSDDServiceName = name;
    }

    public com.hjsj.webservice.HrwebservicePortType gethrwebserviceHttpPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(hrwebserviceHttpPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return gethrwebserviceHttpPort(endpoint);
    }

    public com.hjsj.webservice.HrwebservicePortType gethrwebserviceHttpPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.hjsj.webservice.HrwebserviceHttpBindingStub _stub = new com.hjsj.webservice.HrwebserviceHttpBindingStub(portAddress, this);
            _stub.setPortName(gethrwebserviceHttpPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void sethrwebserviceHttpPortEndpointAddress(String address) {
        hrwebserviceHttpPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.hjsj.webservice.HrwebservicePortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.hjsj.webservice.HrwebserviceHttpBindingStub _stub = new com.hjsj.webservice.HrwebserviceHttpBindingStub(new java.net.URL(hrwebserviceHttpPort_address), this);
                _stub.setPortName(gethrwebserviceHttpPortWSDDServiceName());
                return _stub;
            }
        }
        catch (Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("hrwebserviceHttpPort".equals(inputPortName)) {
            return gethrwebserviceHttpPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://webservice.hjsj.com", "hrwebservice");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://webservice.hjsj.com", "hrwebserviceHttpPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(String portName, String address) throws javax.xml.rpc.ServiceException {
        
if ("hrwebserviceHttpPort".equals(portName)) {
            sethrwebserviceHttpPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
