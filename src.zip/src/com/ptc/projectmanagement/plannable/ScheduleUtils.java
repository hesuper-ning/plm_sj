//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.projectmanagement.plannable;

import com.ptc.projectmanagement.plan.Plannable;
import com.ptc.windchill.gantt2.common.WorkCalendar;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import org.apache.log4j.Logger;
import wt.log4j.LogR;
import wt.org.TimeZoneHelper;
import wt.org.WTPrincipal;
import wt.projmgmt.util.CalendarHelper;
import wt.session.SessionHelper;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTMessage;

public class ScheduleUtils {
    private static final Logger logger;
    private static final String PLANNABLE_RESOURCE = "com.ptc.projectmanagement.plannable.plannableResource";
    private static final int VAR_DAY_OF_MONTH = 5;
    private static final int VAR_HOUR_OF_DAY = 11;
    private static final int VAR_MINUTE = 12;
    private static final int VAR_SECOND = 13;
    private static final int DAY_START_HOUR;
    private static final int DAY_END_HOUR;
    private static final int LUNCH_START_TIME;
    private static final int LUNCH_END_TIME;
    private static final DateFormat df_DD_MM_YYYY;
    private static final long SECOND_MILLISECONDS = 1000L;
    private static final long MINUTE_MILLISECONDS = 60000L;
    private static final long HOUR_MILLISECONDS = 3600000L;
    private static final long DAY_MILLISECONDS;
    private WorkingCalendarConfig workCalendarConfig;
    public static int TIME_RESOLUTION;
    public static long ONE_HOUR;
    public static long INCREMENT_UNIT;
    private static WTPrincipal systemCalendarOwner;

    public ScheduleUtils() {
    }

    public ScheduleUtils(WorkingCalendarConfig var1) {
        this.workCalendarConfig = var1;
    }

    private static WTPrincipal getSystemCalendarOwner() throws WTException {
        if (systemCalendarOwner == null) {
            systemCalendarOwner = SessionHelper.manager.getAdministrator();
        }

        return systemCalendarOwner;
    }

    public boolean isWorkingTime(Date var1, TimeZone var2) throws WTException {
        Calendar var3 = Calendar.getInstance(var2);
        var3.setTime(var1);
        int var4 = var3.get(TIME_RESOLUTION);
        boolean var5 = !CalendarHelper.isNonWorking((WTPrincipal)null, var1, var2);
        boolean var6 = var4 > WorkingCalendarConfig.DAY_START && var4 <= WorkingCalendarConfig.DAY_END;
        boolean var7 = var4 < WorkingCalendarConfig.LUNCH_START || var4 >= WorkingCalendarConfig.LUNCH_END;
        return var5 && var6 && var7;
    }

    public static Timestamp getWorkDayFloor(Timestamp var0, TimeZone var1) throws WTException {
        if (var1 == null) {
            var1 = TimeZoneHelper.getTimeZone();
        }

        Calendar var2 = Calendar.getInstance(var1);
        if (var0 == null) {
            var0 = new Timestamp(var2.getTime().getTime());
        }

        var2.setTime(var0);
        var2.set(var2.get(1), var2.get(2), var2.get(5), WorkingCalendarConfig.DAY_START, 0, 0);
        var2.set(14, 0);
        adjustNonWorkingDays(var2, (WorkingCalendarConfig)null, var1);
        Timestamp var3 = new Timestamp(var2.getTimeInMillis());
        return var3;
    }

    public static Timestamp getWorkDayBase(Timestamp var0, TimeZone var1) throws WTException {
        if (var1 == null) {
            var1 = TimeZoneHelper.getTimeZone();
        }

        Calendar var2 = Calendar.getInstance(var1);
        if (var0 == null) {
            var0 = new Timestamp(var2.getTime().getTime());
        }

        var2.setTime(var0);
        var2.set(var2.get(1), var2.get(2), var2.get(5), WorkingCalendarConfig.DAY_END, 0, 0);
        var2.set(14, 0);
        Timestamp var3 = new Timestamp(var2.getTimeInMillis());
        return var3;
    }

    public static Timestamp addWorkingDuration(Date var0, long var1) throws WTException {
        TimeZone var3 = WTContext.getContext().getTimeZone();
        return new Timestamp(addWorkingDuration(var0, var1, var3).getTime());
    }

    public static Timestamp addWorkingDuration(Date var0, long var1, WorkCalendar var3) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("Considering the timezone from WTContext");
        }

        TimeZone var4 = WTContext.getContext().getTimeZone();
        return new Timestamp(addWorkingDuration(var0, var1, var4).getTime());
    }

    public static Timestamp addWorkingDuration(Date var0, long var1, TimeZone var3) throws WTException {
        boolean var4 = logger.isDebugEnabled();
        if (var4) {
            logger.debug("=>addWorkingDuration: dStartDate=" + var0 + " lDuration=" + var1);
        }

        if (var1 == 0L) {
            return new Timestamp(var0.getTime());
        } else {
            Calendar var5 = Calendar.getInstance(var3);
            var5.setTime(var0);
            adjustStartDate(var5, var3);
            Calendar var6 = Calendar.getInstance(var3);
            var6.setTime(var5.getTime());
            long var7 = var1 / DAY_MILLISECONDS;
            long var9 = var1 % DAY_MILLISECONDS;
            long var11 = var9 / 3600000L;
            long var13 = var9 % 3600000L;
            long var15 = var13 / 60000L;
            long var17 = var13 % 60000L;
            long var19 = var17 / 1000L;
            if (var4) {
                logger.debug("addWorkingDuration: days=" + var7 + " hours=" + var11 + " mins=" + var15 + " secs" + var19);
            }

            addDaysToDate(var6, var7, var3);
            if (var4) {
                logger.debug("addWorkingDuration: added days to end date:" + var6.getTime());
            }

            addHoursToDate(var6, var11, var3);
            if (var4) {
                logger.debug("addWorkingDuration: added hours to end date:" + var6.getTime());
            }

            addMinutesToDate(var6, var15, var3);
            if (var4) {
                logger.debug("addWorkingDuration: added mins to end date:" + var6.getTime());
            }

            addSecondsToDate(var6, var19);
            if (var4) {
                logger.debug("addWorkingDuration: added secs to end date:" + var6.getTime());
            }

            int var21 = var6.get(13);
            int var22 = var6.get(12);
            int var23 = var6.get(11);
            if (var22 == 0 && var21 == 0 && var6.get(11) == LUNCH_END_TIME) {
                var6.set(11, LUNCH_START_TIME);
            }

            if (var23 == DAY_START_HOUR && var22 == 0 && var21 == 0) {
                adjustEndDateForDayStart(var6, var3);
            }

            if (var4) {
                logger.debug("<= addWorkingDuration- return:" + var6.getTime());
            }

            return new Timestamp(var6.getTimeInMillis());
        }
    }

    public static Calendar adjustNonWorkingDays(Calendar var0, WorkingCalendarConfig var1) throws WTException {
        return adjustNonWorkingDays(var0, var1, TimeZoneHelper.getTimeZone());
    }

    public static Calendar adjustNonWorkingDays(Calendar var0, WorkingCalendarConfig var1, TimeZone var2) {
        return adjustNonWorkingDays(var0, var1, var2, false);
    }

    public static Calendar adjustNonWorkingDays(Calendar var0, WorkingCalendarConfig var1, TimeZone var2, boolean var3) {
        boolean var4 = true;
        byte var5 = 24;
        int var6 = 0;
        boolean var7 = logger.isDebugEnabled();
        if (var7) {
            logger.debug("Date to be processed:" + var0.getTime());
        }

        do {
            if (var2 == null) {
                var2 = TimeZone.getDefault();
            }

            try {
                if (CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var2)) {
                    if (var3) {
                        var0.add(11, -var5);
                    } else {
                        var0.add(11, var5 - var0.get(11));
                        var0.add(11, WorkingCalendarConfig.DAY_START);
                    }

                    ++var6;
                } else {
                    var4 = false;
                }
            } catch (WTException var9) {
                logger.error("Error occured while adusting non-working days.");
                var9.printStackTrace();
            }
        } while(var4);

        if (var7) {
            logger.debug("Total Non-Working Days adjusted=" + var6 + ". Final date after adjusting non working days: " + var0.getTime());
        }

        return var0;
    }

    /** @deprecated */
    @Deprecated
    public static int getDayOfWeek(Date var0) {
        Calendar var1 = Calendar.getInstance();
        var1.setTime(var0);
        return var1.get(7);
    }

    public static long calculateWorkingDuration(Date var0, Date var1, TimeZone var2, WorkingCalendarConfig var3) throws WTException {
        boolean var4 = logger.isDebugEnabled();
        if (var4) {
            logger.debug("=>calculating working duration for startDate=" + var0 + " ; endDate=" + var1);
        }

        Calendar var5 = Calendar.getInstance(var2);
        Calendar var6 = Calendar.getInstance(var2);
        var5.setTime(var0);
        var6.setTime(var1);
        return calculateWorkingDuration(var5, var6, var2);
    }

    public static long calculateWorkingDuration(Date var0, Date var1, TimeZone var2, WorkingCalendarConfig var3, String var4) throws WTException {
        boolean var5 = logger.isDebugEnabled();
        if (var5) {
            logger.debug("=>calculating working duration for startDate=" + var0 + " ; endDate=" + var1);
        }

        Calendar var6 = Calendar.getInstance(var2);
        Calendar var7 = Calendar.getInstance(var2);
        var6.setTime(var0);
        var7.setTime(var1);
        return calculateWorkingDuration(var6, var7, var2, var4);
    }

    public static long calculateWorkingDuration(Calendar var0, Calendar var1, TimeZone var2) throws WTException {
        return calculateWorkingDuration((Calendar)var0, (Calendar)var1, var2, (String)null);
    }

    public static long calculateWorkingDuration(Calendar var0, Calendar var1, TimeZone var2, String var3) throws WTException {
        boolean var4 = logger.isDebugEnabled();
        if (var1.before(var0)) {
            logger.error("...\t'finishDate':" + var1.getTime() + "is falling before 'startDate':" + var0.getTime());
            if (null == var3) {
                throw new WTException(WTMessage.getLocalizedMessage("com.ptc.projectmanagement.plannable.plannableResource", "INVALID_FINISH_DATE_BEFORE_START_GENERIC", (Object[])null, SessionHelper.getLocale()));
            } else {
                Object[] var11 = new Object[]{var3};
                throw new WTException(WTMessage.getLocalizedMessage("com.ptc.projectmanagement.plannable.plannableResource", "INVALID_FINISH_DATE_BEFORE_START", var11, SessionHelper.getLocale()));
            }
        } else if (var0.equals(var1)) {
            if (var4) {
                logger.debug("<= calculateWorkingDuration: startDate & endDate are equal..return 0");
            }

            return 0L;
        } else {
            long var5;
            if (isStartAndFinishOnSameDay(var0, var1)) {
                var5 = getDayDuration(var0, var1, var2);
                if (var4) {
                    logger.debug("<= calculateWorkingDuration: startDate & endDate falls on same day..durationMills=" + var5);
                }

                return var5;
            } else {
                var5 = getStartDateMilliSecondsAndAdjustToWorkingDay(var0, var2);
                if (!var0.equals(var1) && !var0.after(var1)) {
                    long var7 = getEndDateMilliSecondsAndAdjustToWorkingDay(var1, var2);
                    long var9;
                    if (isStartAndFinishOnSameDay(var0, var1)) {
                        var9 = getDayDuration(var0, var1, var2);
                        if (var4) {
                            logger.debug("<= calculateWorkingDuration: After adjusting start date, startDate & endDate falls on same day..durationMills=" + var9);
                        }

                        return var9;
                    } else {
                        updateCalendar(var0, DAY_START_HOUR, 0, 0, 1);
                        updateCalendar(var1, DAY_END_HOUR, 0, 0, -1);
                        var9 = getWorkingDays(var0, var1, var2);
                        if (var4) {
                            logger.debug("calculateWorkingDuration: days :" + var9 + "  startDateMills:" + var5 + " ednDateMills:" + var7);
                            logger.debug("<= calculateWorkingDuration: duration in mills = " + (var9 * DAY_MILLISECONDS + var5 + var7));
                        }

                        return var9 * DAY_MILLISECONDS + var5 + var7;
                    }
                } else {
                    if (var4) {
                        logger.debug("<= calculateWorkingDuration: After adjusting start date, it is equal or after endDate...return 0");
                    }

                    return 0L;
                }
            }
        }
    }

    public static boolean isStartAndFinishOnSameDay(Calendar var0, Calendar var1) {
        return var0.get(5) == var1.get(5) && var0.get(2) == var1.get(2) && var0.get(1) == var1.get(1);
    }

    /** @deprecated */
    @Deprecated
    public static boolean isWorkingBorderStart(Date var0, TimeZone var1, WorkingCalendarConfig var2) {
        Calendar var3 = Calendar.getInstance(var1);
        var3.setTime(var0);
        int var4 = var3.get(TIME_RESOLUTION);
        return var4 == WorkingCalendarConfig.DAY_START || var4 == WorkingCalendarConfig.LUNCH_END;
    }

    /** @deprecated */
    @Deprecated
    public static boolean isWorkingInstance(Date var0, TimeZone var1, WorkingCalendarConfig var2) throws WTException {
        boolean var3 = logger.isDebugEnabled();
        Calendar var4 = Calendar.getInstance(var1);
        var4.setTime(var0);
        int var5 = var4.get(TIME_RESOLUTION);
        if (var3) {
            logger.debug("Checking if '" + var0 + "' is working instance for Timezone '" + var1 + "'.");
        }

        if (CalendarHelper.isNonWorking((WTPrincipal)null, var4.getTime(), var1)) {
            return false;
        } else {
            return var5 >= WorkingCalendarConfig.DAY_START && var5 <= WorkingCalendarConfig.DAY_END;
        }
    }

    public static WorkingCalendarConfig getWorkingCalendarConfig(Plannable var0) {
        WorkingCalendarConfig var1 = new WorkingCalendarConfig(var0);
        if (var0 instanceof Rootable) {
            var1 = new WorkingCalendarConfig(var0);
            Rootable var2 = (Rootable)var0;
            BaseCalendarType var3 = var2.getBaseCalendar();
            if (BaseCalendarType.STANDARD.equals(var3)) {
                var1 = getStandardCalendar(var0);
            }
        }

        return var1;
    }

    public static WorkingCalendarConfig getStandardCalendar(Plannable var0) {
        WorkingCalendarConfig var1 = new WorkingCalendarConfig(var0);
        var1.setDayStartHour(WorkingCalendarConfig.DAY_START);
        var1.setWorkingHoursPerDay(WorkingCalendarConfig.TOTAL_WORKING_MINS / 60);
        return var1;
    }

    public static Timestamp getPreviousWorkingDayStart(Date var0, TimeZone var1) {
        boolean var2 = logger.isDebugEnabled();
        var0.setTime(getPreviousWorkingDay(var0, var1).getTime());
        Calendar var3 = Calendar.getInstance(var1);
        var3.setTime(var0);
        var3.set(11, WorkingCalendarConfig.DAY_START);
        var3.clear(12);
        var3.clear(13);
        var3.clear(14);
        var0.setTime(var3.getTime().getTime());
        Timestamp var4 = new Timestamp(var3.getTimeInMillis());
        if (var2) {
            logger.debug(var4.toString());
        }

        return var4;
    }

    public static Timestamp getPreviousWorkingDayEnd(Date var0, TimeZone var1) {
        boolean var2 = logger.isDebugEnabled();
        var0.setTime(getPreviousWorkingDay(var0, var1).getTime());
        Calendar var3 = Calendar.getInstance(var1);
        var3.setTime(var0);
        var3.set(11, WorkingCalendarConfig.DAY_END);
        var3.clear(12);
        var3.clear(13);
        var3.clear(14);
        var0.setTime(var3.getTime().getTime());
        Timestamp var4 = new Timestamp(var3.getTimeInMillis());
        if (var2) {
            logger.debug(var4.toString());
        }

        return var4;
    }

    public static Timestamp getPreviousWorkingDay(Date var0, TimeZone var1) {
        Calendar var2 = Calendar.getInstance(var1);
        var2.setTime(var0);
        var2.add(5, -1);

        try {
            if (CalendarHelper.isNonWorking((WTPrincipal)null, var2.getTime(), var1)) {
                var2.add(5, -1);
            }
        } catch (WTException var4) {
            var4.printStackTrace();
        }

        Timestamp var3 = new Timestamp(var2.getTimeInMillis());
        return var3;
    }

    private static long getWorkingDays(Calendar var0, Calendar var1, TimeZone var2) throws WTException {
        long var3;
        for(var3 = 0L; var0.before(var1); var0.add(5, 1)) {
            boolean var5 = !CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var2);
            if (var5) {
                ++var3;
            }
        }

        return var3;
    }

    private static long getStartDateMilliSecondsAndAdjustToWorkingDay(Calendar var0, TimeZone var1) throws WTException {
        boolean var2 = false;
        boolean var3 = false;
        boolean var4 = false;
        boolean var5 = moveStartDateToWorkingDay(var0, var1);
        if (!var5) {
            if (var0.get(11) >= DAY_END_HOUR) {
                updateCalendar(var0, DAY_START_HOUR, 0, 0, 1);
            } else if (var0.get(11) < DAY_START_HOUR) {
                updateCalendar(var0, DAY_START_HOUR, 0, 0, 0);
            } else if (var0.get(11) == LUNCH_START_TIME) {
                updateCalendar(var0, LUNCH_END_TIME, 0, 0, 0);
                var2 = true;
                var3 = true;
            }

            moveStartDateToWorkingDay(var0, var1);
            if (var0.get(11) >= LUNCH_END_TIME) {
                var2 = true;
            }
        }

        int var8;
        if (var2) {
            var8 = DAY_END_HOUR - var0.get(11);
        } else {
            var8 = DAY_END_HOUR - var0.get(11) - (LUNCH_END_TIME - LUNCH_START_TIME);
        }

        int var6 = var0.get(12);
        if (!var3 && var6 != 0) {
            --var8;
            var6 = 60 - var6;
        }

        int var7 = var0.get(13);
        if (var7 != 0) {
            --var6;
            var7 = 60 - var7;
        }

        return (long)var8 * 3600000L + (long)var6 * 60000L + (long)var7 * 1000L;
    }

    private static long getEndDateMilliSecondsAndAdjustToWorkingDay(Calendar var0, TimeZone var1) throws WTException {
        boolean var2 = false;
        boolean var3 = false;
        boolean var4 = moveEndtDateToWorkingDay(var0, var1);
        if (!var4) {
            if (var0.get(11) >= DAY_END_HOUR) {
                updateCalendar(var0, DAY_END_HOUR, 0, 0, 0);
            } else if (var0.get(11) < DAY_START_HOUR) {
                updateCalendar(var0, DAY_END_HOUR, 0, 0, -1);
            } else if (var0.get(11) == LUNCH_START_TIME) {
                updateCalendar(var0, LUNCH_START_TIME, 0, 0, 0);
                var2 = true;
            }

            moveEndtDateToWorkingDay(var0, var1);
            if (var0.get(11) <= LUNCH_START_TIME) {
                var2 = true;
            }
        }

        int var7;
        if (var2) {
            var7 = var0.get(11) - DAY_START_HOUR;
        } else {
            var7 = var0.get(11) - DAY_START_HOUR - (LUNCH_END_TIME - LUNCH_START_TIME);
        }

        int var5 = var0.get(12);
        int var6 = var0.get(13);
        return (long)var7 * 3600000L + (long)var5 * 60000L + (long)var6 * 1000L;
    }

    private static long getDayDuration(Calendar var0, Calendar var1, TimeZone var2) throws WTException {
        boolean var3 = false;
        boolean var4 = false;
        if (CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var2)) {
            return 0L;
        } else {
            if (var0.get(11) < DAY_START_HOUR) {
                updateCalendar(var0, DAY_START_HOUR, 0, 0, 0);
            } else if (var0.get(11) == LUNCH_START_TIME) {
                updateCalendar(var0, LUNCH_END_TIME, 0, 0, 0);
                var3 = true;
            }

            if (var1.get(11) >= DAY_END_HOUR) {
                updateCalendar(var1, DAY_END_HOUR, 0, 0, 0);
            } else if (var1.get(11) == LUNCH_START_TIME) {
                updateCalendar(var1, LUNCH_START_TIME, 0, 0, 0);
                var3 = true;
            }

            if (var0.get(11) >= LUNCH_END_TIME || var1.get(11) <= LUNCH_START_TIME) {
                var3 = true;
            }

            if (var1.get(11) < var0.get(11)) {
                return 0L;
            } else {
                int var11;
                if (var3) {
                    var11 = var1.get(11) - var0.get(11);
                } else {
                    var11 = var1.get(11) - var0.get(11) - (LUNCH_END_TIME - LUNCH_START_TIME);
                }

                int var5 = var0.get(12);
                int var6 = var1.get(12);
                boolean var7 = false;
                int var12;
                if (var5 > var6) {
                    --var11;
                    var12 = 60 - var5 + var6;
                } else {
                    var12 = var6 - var5;
                }

                int var8 = var0.get(13);
                int var9 = var1.get(13);
                boolean var10 = false;
                int var13;
                if (var8 > var9) {
                    --var12;
                    var13 = 60 - var8 + var9;
                } else {
                    var13 = var9 - var8;
                }

                return (long)var11 * 3600000L + (long)var12 * 60000L + (long)var13 * 1000L;
            }
        }
    }

    private static void adjustStartDate(Calendar var0, TimeZone var1) throws WTException {
        boolean var2 = moveStartDateToWorkingDay(var0, var1);
        if (!var2) {
            if (var0.get(11) >= DAY_END_HOUR) {
                updateCalendar(var0, DAY_START_HOUR, 0, 0, 1);
            }

            if (var0.get(11) < DAY_START_HOUR) {
                updateCalendar(var0, DAY_START_HOUR, 0, 0, 0);
            }

            if (var0.get(11) == LUNCH_START_TIME) {
                updateCalendar(var0, LUNCH_END_TIME, 0, 0, 0);
            }

            moveStartDateToWorkingDay(var0, var1);
        }

    }

    private static Calendar addDaysToDate(Calendar var0, long var1, TimeZone var3) throws WTException {
        if(var1 > 0L) {
            while(var1 > 0L) {
                var0.add(5, 1);

                while(CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var3)) {
                    var0.add(5, 1);
                }

                --var1;
            }
        } else {
            while(var1 < 0L) {
                var0.add(5, -1);

                while(CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var3)) {
                    var0.add(5, -1);
                }

                ++var1;
            }
        }
        return var0;
    }

    private static Calendar addHoursToDate(Calendar var0, long var1, TimeZone var3) throws WTException {
        while(var1 > 0L) {
            if (var0.get(11) == LUNCH_START_TIME) {
                var0.set(11, LUNCH_END_TIME);
            } else if (var0.get(11) == DAY_END_HOUR) {
                var0.set(11, DAY_START_HOUR);
                var0.add(5, 1);

                while(CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var3)) {
                    var0.add(5, 1);
                }
            }

            var0.add(11, 1);
            --var1;
        }

        return var0;
    }

    private static Calendar addMinutesToDate(Calendar var0, long var1, TimeZone var3) throws WTException {
        var0.add(12, (int)var1);
        if (var0.get(11) == LUNCH_START_TIME) {
            var0.set(11, LUNCH_END_TIME);
        } else if (var0.get(11) == DAY_END_HOUR) {
            var0.set(11, DAY_START_HOUR);
            var0.add(5, 1);

            while(CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var3)) {
                var0.add(5, 1);
            }
        }

        return var0;
    }

    private static Calendar addSecondsToDate(Calendar var0, long var1) {
        var0.add(13, (int)var1);
        return var0;
    }

    private static void adjustEndDateForDayStart(Calendar var0, TimeZone var1) throws WTException {
        if (var0.get(11) == DAY_START_HOUR) {
            var0.set(11, DAY_END_HOUR);
            var0.add(5, -1);
        }

        while(CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var1)) {
            var0.add(5, -1);
        }

    }

    private static boolean moveStartDateToWorkingDay(Calendar var0, TimeZone var1) throws WTException {
        boolean var2;
        for(var2 = false; CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var1); var2 = true) {
            updateCalendar(var0, DAY_START_HOUR, 0, 0, 1);
        }

        return var2;
    }

    private static boolean moveEndtDateToWorkingDay(Calendar var0, TimeZone var1) throws WTException {
        boolean var2;
        for(var2 = false; CalendarHelper.isNonWorking((WTPrincipal)null, var0.getTime(), var1); var2 = true) {
            updateCalendar(var0, DAY_END_HOUR, 0, 0, -1);
        }

        return var2;
    }

    private static void updateCalendar(Calendar var0, int var1, int var2, int var3, int var4) {
        var0.set(11, var1);
        var0.set(12, var2);
        var0.set(13, var3);
        if (var4 != 0) {
            var0.add(5, var4);
        }

    }

    static {
        DAY_START_HOUR = WorkingCalendarConfig.DAY_START;
        DAY_END_HOUR = WorkingCalendarConfig.DAY_END;
        LUNCH_START_TIME = WorkingCalendarConfig.LUNCH_START;
        LUNCH_END_TIME = WorkingCalendarConfig.LUNCH_END;
        df_DD_MM_YYYY = new SimpleDateFormat("dd-MM-yyyy");
        DAY_MILLISECONDS = (long)WorkingCalendarConfig.TOTAL_WORKING_MINS * 60000L;

        try {
            logger = LogR.getLogger(ScheduleUtils.class.getName());
        } catch (Exception var1) {
            throw new ExceptionInInitializerError(var1);
        }

        TIME_RESOLUTION = 11;
        ONE_HOUR = 3600000L;
        INCREMENT_UNIT = ONE_HOUR;
        systemCalendarOwner = null;
    }
}
