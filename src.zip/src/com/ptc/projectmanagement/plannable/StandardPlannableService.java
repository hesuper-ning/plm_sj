//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.projectmanagement.plannable;

import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.OidHelper;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.server.impl.LogicalIdentifierMapEntry;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.productplantemplates.ProductPlanTemplate;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.projectmanagement.assignment.AssignmentHelper;
import com.ptc.projectmanagement.assignment.ResourceAssignment;
import com.ptc.projectmanagement.assignment.WorkTrackable;
import com.ptc.projectmanagement.assignment.baseline.BaselinedResourceAssignment;
import com.ptc.projectmanagement.assignment.resource.PlanResource;
import com.ptc.projectmanagement.assignment.resource.baseline.BaselinedPlanResource;
import com.ptc.projectmanagement.cost.CostHelper;
import com.ptc.projectmanagement.cost.CostTrackable;
import com.ptc.projectmanagement.deliverable.PlanDeliverable;
import com.ptc.projectmanagement.deliverable.PlanDeliverableLink;
import com.ptc.projectmanagement.deliverable.baseline.BaselinedPlanDeliverable;
import com.ptc.projectmanagement.history.ActivityHistoryRecord;
import com.ptc.projectmanagement.ilog.gantt.GanttModelUtility;
import com.ptc.projectmanagement.ilog.ganttmodel.GanttModelSaveUtility;
import com.ptc.projectmanagement.ilog.ganttmodel.GanttModelScheduleUtility;
import com.ptc.projectmanagement.plan.*;
import com.ptc.projectmanagement.plan.baseline.BaselinedPlan;
import com.ptc.projectmanagement.plan.baseline.BaselinedPlanActivity;
import com.ptc.projectmanagement.plan.ilog.PlanWorkingHourHandler;
import com.ptc.projectmanagement.plan.processors.PlanIndentProcessor;
import com.ptc.projectmanagement.plannable.resultProcessors.UpcomingScheduledPlannablesResultProcessor;
import com.ptc.projectmanagement.uoot.RequirementPlannableLink;
import com.ptc.projectmanagement.util.AdminUtils;
import com.ptc.projectmanagement.util.PasteActionUtil;
import com.ptc.projectmanagement.util.PlannableUtils;
import com.ptc.projectmanagement.util.ProcessorUtils;
import com.ptc.windchill.baseserver.util.Lists;
import com.ptc.windchill.gantt2.common.GanttCriticalPathCalculator;
import com.ptc.windchill.gantt2.common.GanttDataModel;
import com.ptc.windchill.gantt2.common.GanttSchedulingManager;
import com.ptc.windchill.history.HistoryRecordLink;
import com.ptc.windchill.history.HistoryRecordable;
import com.ptc.windchill.history.HistoryResolutionProcessor;
import com.ptc.windchill.history.HistoryServiceTransactionListener;
import org.apache.log4j.Logger;
import wt.access.AccessControlServerHelper;
import wt.admin.AdminDomainRef;
import wt.events.KeyedEvent;
import wt.fc.*;
import wt.fc.collections.*;
import wt.htmlutil.TemplateName;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.notify.NotificationHelper;
import wt.notify.TemplateEmailNotification;
import wt.notify.WTDistributionList;
import wt.org.TimeZoneHelper;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.ownership.Ownable;
import wt.ownership.OwnershipHelper;
import wt.ownership.OwnershipServerHelper;
import wt.pds.PartialResultException;
import wt.pom.Transaction;
import wt.projmgmt.DeadlineSupportable;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.admin.ProjectState;
import wt.query.*;
import wt.query.KeywordExpression.Keyword;
import wt.queue.MethodArgument;
import wt.queue.QueueHelper;
import wt.queue.ScheduleQueue;
import wt.queue.ScheduleQueueEntry;
import wt.scheduler.PersistantArg;
import wt.scheduler.ScheduleItem;
import wt.scheduler.ScheduleMethodArg;
import wt.scheduler.SchedulingHelper;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;
import wt.vc.VersionReference;
import wt.workflow.forum.DiscussionPosting;
import wt.workflow.forum.ForumUtil;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

public class StandardPlannableService extends StandardManager implements PlannableService, Serializable {
    private static final String RESOURCE = "com.ptc.projectmanagement.plannable.plannableResource";
    private static final String PLAN_RESOURCE = "com.ptc.projectmanagement.plan.planResource";
    private static final String CLASSNAME = StandardPlannableService.class.getName();
    private static String NOTIFICATION_SENDER = "";
    private static final String location = "plan/planActivityNotification";
    private static final String deadline = "plan/EPPdeadlineNotification";
    private static final String DELIVERABLE_DEADLINE_PASSED = "plan/EPPDeliverableDeadlineNotification";
    public static final String AFTER = "after";
    public static final String BEFORE = "before";
    public static final String AFTERDEADLINE = "After";
    public static final String BEFOREDEADLINE = "Before";
    public static final String SCHEDULEENTRY_ID_SEP = ":";
    public static final String DAYS_SEPARATOR = "__";
    public static final String EPP_QUEUE = "EPPQueue";
    public static final String INVOKE_METHOD = "handleDeadLineSchedulingEventAfterOrBefore";
    public static final String INVOKE_METHOD_DELIVERABLE = "handleDeliverableDeadLineSchedulingEvent";
    public static final String INVOKE_METHOD_PLANNABLE_DEADLINE = "handleDeadLineSchedulingEvent";
    public static final String CALCULATE_CRITICAL_PATH;
    public static final int CREATE_SCHEDULEDPLANNABLES_ITEMS_LIMIT;
    private static final int DELETE_SCHEDULEDPLANNABLES_ITEMS_LIMIT;
    private static final Logger logger;
    private static final String ROLL_UP_DELIVERABLES_TO_MILESTONE = "rollUpDeliverablesToMilestone";
    public static final int SCHEDULEITEM_GRACE_PERIOD = 29000;
    public static final String PROCESSED_EVENT = "ProcessedEvent";
    public static final String DEADLINE_HEALTH_STATUS_AUTO_MODE_ACTIVITIES = "DeadlineAndHealthStatusAutoModeActivities";
    public static final String HEALTH_STATUS_AUTO_MODE_ACTIVITIES = "HealthStatusAutoModeActivities";
    public static final String DEADLINE_AUTO_MODE_ACTIVITIES = "DeadlineAutoModeActivities";
    public static final String SKIP_UPDATE_OBJECTS_FROM_IMPORT = "SKIP_UPDATE_OBJECTS_FROM_IMPORT";
    public static final String INPROCESS_STATE = "INPROCESS";
    public static final boolean filterOnServerSide;

    public StandardPlannableService() {
    }

    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public static StandardPlannableService newStandardPlannableService() throws WTException {
        StandardPlannableService var0 = new StandardPlannableService();
        var0.initialize();
        return var0;
    }

    public int getNextLineNumber(Plannable var1) throws WTException {
        int var2 = this.getMaxLineNumber(var1);
        return var2 + 1;
    }

    public Plannable addPlannable(Plannable var1, Plannable var2) throws WTException {
        Rootable var3 = this.isRoot(var2) ? (Rootable) var2 : var2.getRoot();

        try {
            var1.setParent(var2);
            var1.setRoot(var3);
            var1.setContainerReference(var2.getContainerReference());
            if (var1 instanceof AbstractPlanActivity) {
                ((AbstractPlanActivity) var1).setDomainRef(AdminUtils.getAdministrativeSystemDomainRef(var2.getContainerReference()));
            }

            if (!var2.isSummary()) {
                var2.setSummary(true);
                var2 = (Plannable) PersistenceHelper.manager.save(var2);
            }
        } catch (WTPropertyVetoException var5) {
            throw new WTException(var5);
        }

        var1 = (Plannable) PersistenceHelper.manager.save(var1);
        return var1;
    }

    public boolean isRoot(Plannable var1) throws WTException {
        boolean var2 = false;
        if (var1.getRoot() == null) {
            var2 = true;
        }

        return var2;
    }

    public WTCollection getAllPlannables(Plannable var1, boolean var2) throws WTException {
        QuerySpec var3 = this.getAllPlannables(var1);
        QueryResult var4 = PersistenceHelper.manager.find(var3);
        WTArrayList var5 = new WTArrayList();
        if (var2) {
            var5.add(var1);
        }

        var5.addAll(var4);
        return var5;
    }

    public WTCollection getAllPlannables(Plannable var1, int var2) throws WTException {
        QuerySpec var3 = this.getAllPlannables(var1);
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(Plannable.class, "lineNumber", ">=", var2));
        QueryResult var4 = PersistenceHelper.manager.find(var3);
        WTArrayList var5 = new WTArrayList();
        var5.addAll(var4);
        return var5;
    }

    public WTCollection getAllPlannables(Plannable var1, int var2, int var3) throws WTException {
        QuerySpec var4 = this.getAllPlannables(var1);
        var4.appendAnd();
        var4.appendWhere(new SearchCondition(Plannable.class, "lineNumber", ">=", var2));
        var4.appendAnd();
        var4.appendWhere(new SearchCondition(Plannable.class, "lineNumber", "<=", var3));
        QueryResult var5 = PersistenceHelper.manager.find(var4);
        WTArrayList var6 = new WTArrayList();
        var6.addAll(var5);
        return var6;
    }

    public Plannable getPlannableByLineNumber(Plannable var1, int var2) throws WTException {
        return this.getPlannableByLineNumber(var1, var2, true);
    }

    private Plannable getPlannableByLineNumber(Plannable var1, int var2, boolean var3) throws WTException {
        QuerySpec var4 = new QuerySpec();
        var4.appendClassList(Plannable.class, true);
        SearchCondition var5 = new SearchCondition(Plannable.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var4.appendWhere(var5, new int[]{0});
        var4.appendAnd();
        SearchCondition var6 = new SearchCondition(Plannable.class, "lineNumber", "=", var2);
        var4.appendWhere(var6, new int[]{0});
        QueryResult var7 = PersistenceHelper.manager.find(var4);
        WTArrayList var8 = new WTArrayList();
        var8.addAll(var7);
        ArrayList var9 = new ArrayList(var8.persistableCollection());
        Plannable var10 = null;
        if (var9.size() != 1 && var3) {
            Object[] var11 = new Object[]{String.valueOf(var2)};
            throw new WTException("com.ptc.projectmanagement.plannable.plannableResource", "INVALID_PLANNABLE_LINENUMBER", var11);
        } else {
            if (var9 != null && var9.size() > 0) {
                var10 = (Plannable) var9.get(0);
            }

            return var10;
        }
    }

    public ArrayList getPrecedenceConstraints(Plannable var1) throws WTException {
        WTCollection var2 = this.listPrecedenceConstraintsBySuccessor(var1);
        ArrayList var3 = new ArrayList(var2.persistableCollection());
        return var3;
    }

    public ArrayList getPrecedenceConstraints(Plannable var1, boolean var2) throws WTException {
        WTCollection var3 = this.listPrecedenceConstraintsBySuccessor(var1, var2);
        ArrayList var4 = new ArrayList(var3.persistableCollection());
        return var4;
    }

    public ArrayList<Integer> getConverterAddedPrecedenceConstraints(Plannable var1) throws WTException {
        ArrayList var2 = new ArrayList();
        ArrayList var3 = this.getPrecedenceConstraints(var1, true);
        if (var3 != null) {
            Iterator var4 = var3.iterator();

            while (var4.hasNext()) {
                PrecedenceConstraint var5 = (PrecedenceConstraint) var4.next();
                Duration var6 = var5.getScheduleOffset();
                if (var6 != null && DurationFormat.CONVERTED.equals(var6.getDurationFormat())) {
                    var2.add(var5.getPredecessor().getLineNumber());
                }
            }
        }

        return var2;
    }

    public QueryResult getPlanObjectsForAssignmentsTable(Plan var1, Class var2, WTPrincipal var3, Boolean var4, Boolean var5, Boolean var6, Boolean var7, Object var8) throws WTException, WTPropertyVetoException {
        if (logger.isDebugEnabled()) {
            logger.debug("=> StandardPlannableService.getPlanObjectsForAssignmentsTable: \n plan = " + var1 + "\n objectClass = " + var2 + "\n principal = " + var3 + "\n openAssignments = " + var4 + "\n assignedToPrincipal = " + var5 + "\n isOverDue = " + var6 + "\n tmpObject = " + var8);
        }

        Object var9 = null;
        SearchCondition var10 = new SearchCondition(PlanActivity.class, "containerReference.key.id", "=", var1.getContainer().getPersistInfo().getObjectIdentifier().getId());
        SearchCondition var11 = new SearchCondition(Plannable.class, "lineNumber", "<>", 0);
        QueryResult var12 = null;
        QuerySpec var13;
        if (var2.equals(PlanActivity.class)) {
            if (var4 != null) {
                SearchCondition var19;
                QuerySpec var20;
                SearchCondition var21;
                QuerySpec var22;
                QueryResult var23;
                if (!var4) {
                    var19 = new SearchCondition(var2, "plannableState", "=", PlannableState.COMPLETED);
                    var20 = this.getQuerySpecForClosedActivities(var3, var5, var7, var10, var11, var19);
                    var12 = PersistenceHelper.manager.find(var20);
                    var21 = new SearchCondition(var2, "percentWorkComplete", "=", 100.0D);
                    var22 = this.getQuerySpecForClosedActivities(var3, var5, var7, var10, var11, var21);
                    var23 = PersistenceHelper.manager.find(var22);
                    var12.append(var23.getObjectVectorIfc());
                } else {
                    var19 = new SearchCondition(PlanActivity.class, "plannableState", "=", PlannableState.INPROCESS);
                    var20 = this.getQuerySpecForOpenActivities(var3, var5, var7, var10, var11, var19);
                    var12 = PersistenceHelper.manager.find(var20);
                    var21 = new SearchCondition(var2, "percentWorkComplete", true, new AttributeRange(0, 99));
                    var22 = this.getQuerySpecForOpenActivities(var3, var5, var7, var10, var11, var21);
                    var23 = PersistenceHelper.manager.find(var22);
                    var12.append(var23.getObjectVectorIfc());
                }

                return var12;
            } else {
                var13 = this.getCommonClosedQuerySpec(var10, var11);
                this.addAssignedToCritiera(PlanActivity.class, var3, var5, var13);
                this.addIsDiscussedCriteria(PlanActivity.class, var7, var13);
                return PersistenceHelper.manager.find(var13);
            }
        } else if (!var2.equals(PlanDeliverable.class)) {
            return null;
        } else {
            var13 = new QuerySpec(var2);
            var13.setAdvancedQueryEnabled(true);
            var13.appendWhere(new SearchCondition(PlanDeliverable.class, "containerReference.key", "=", this.getOid(var1.getContainer())), new int[]{0});
            if (var4 != null && var4) {
                var13.appendAnd();
                SearchCondition var14 = new SearchCondition(var2, "percentComplete", true, new AttributeRange(0, 99));
                var13.appendWhere(var14);
                var13.appendAnd();
                var13.appendOpenParen();
                Timestamp var15 = new Timestamp(Calendar.getInstance().getTime().getTime());
                SearchCondition var16 = new SearchCondition(var2, "startDate", "<=", var15);
                var13.appendWhere(var16);
                var13.appendOr();
                Timestamp var17 = new Timestamp(0L);
                SearchCondition var18 = new SearchCondition(var2, "startDate", "IS NULL", var17);
                var13.appendWhere(var18);
                var13.appendCloseParen();
            } else if (var4 != null && !var4) {
                var13.appendAnd();
                var13.appendWhere(new SearchCondition(var2, "percentComplete", "=", Double.parseDouble("100")), 0);
            }

            this.addAssignedToCritiera(var2, var3, var5, var13);
            this.addIsDiscussedCriteria(var2, var7, var13);
            if (logger.isDebugEnabled()) {
                logger.debug("=> StandardPlannableService.getPlanObjectsForAssignmentsTable: Query is " + var13);
            }

            return PersistenceHelper.manager.find(var13);
        }
    }

    public QuerySpec getQuerySpecForOpenActivities(WTPrincipal var1, Boolean var2, Boolean var3, SearchCondition var4, SearchCondition var5, SearchCondition var6) throws QueryException, WTException {
        QuerySpec var7 = this.getCommonOpenQuerySpec(var4, var5);
        var7.appendAnd();
        var7.appendWhere(var6, new int[]{0});
        this.addAssignedToCritiera(PlanActivity.class, var1, var2, var7);
        this.addIsDiscussedCriteria(PlanActivity.class, var3, var7);
        return var7;
    }

    public QuerySpec getQuerySpecForClosedActivities(WTPrincipal var1, Boolean var2, Boolean var3, SearchCondition var4, SearchCondition var5, SearchCondition var6) throws QueryException, WTException {
        QuerySpec var7 = this.getCommonClosedQuerySpec(var4, var5);
        var7.appendAnd();
        var7.appendWhere(var6, new int[]{0});
        this.addAssignedToCritiera(PlanActivity.class, var1, var2, var7);
        this.addIsDiscussedCriteria(PlanActivity.class, var3, var7);
        return var7;
    }

    public void addIsDiscussedCriteria(Class var1, Boolean var2, QuerySpec var3) throws WTException, QueryException {
        if (var2 != null && var2) {
            SearchCondition var4 = this.getSCForisDiscussed(var2, var1);
            var3.appendAnd();
            var3.appendWhere(var4, new int[]{0});
        }

    }

    public void addAssignedToCritiera(Class var1, WTPrincipal var2, Boolean var3, QuerySpec var4) throws WTException, QueryException {
        if (var3 != null) {
            SearchCondition var5 = this.getSCAssignedToPrincipal(var3, var2, var1);
            var4.appendAnd();
            var4.appendWhere(var5, new int[]{0});
        }

    }

    public QuerySpec getCommonClosedQuerySpec(SearchCondition var1, SearchCondition var2) throws QueryException {
        QuerySpec var3 = new QuerySpec(PlanActivity.class);
        var3.setAdvancedQueryEnabled(true);
        var3.appendWhere(var1, new int[]{0});
        var3.appendAnd();
        var3.appendWhere(var2, new int[]{0});
        return var3;
    }

    public QuerySpec getCommonOpenQuerySpec(SearchCondition var1, SearchCondition var2) throws QueryException {
        QuerySpec var3 = new QuerySpec(PlanActivity.class);
        int var4 = var3.appendClassList(Plan.class, false);
        var3.setAdvancedQueryEnabled(true);
        var3.appendWhere(var1, new int[]{0});
        var3.appendAnd();
        var3.appendWhere(var2, new int[]{0});
        var3.appendAnd();
        SearchCondition var5 = new SearchCondition(Plan.class, "thePersistInfo.theObjectIdentifier.id", Plannable.class, "rootReference.key.id");
        var3.appendWhere(var5, new int[]{var4, 0});
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(PlanActivity.class, "startDate", "<=", new Timestamp(System.currentTimeMillis())), new int[]{0});
        return var3;
    }

    public PrecedenceConstraint addPrecedenceConstraint(Plannable var1, Plannable var2, PrecedenceType var3) throws WTException {
        try {
            PrecedenceConstraint var4 = PrecedenceConstraint.newPrecedenceConstraint(var1, var2);
            var4.setPrecedenceType(var3);
            var4 = (PrecedenceConstraint) PersistenceHelper.manager.save(var4);
            return var4;
        } catch (WTPropertyVetoException var5) {
            throw new WTException(var5);
        }
    }

    public boolean arePrecedenceConstraintsValid(ArrayList var1) throws WTException {
        if (var1 != null && !var1.isEmpty()) {
            for (int var2 = 0; var2 < var1.size(); ++var2) {
                PrecedenceConstraint var3 = (PrecedenceConstraint) var1.get(var2);
                boolean var4 = PrecedenceConstraint.isPrecedenceConstraintValid(var3);
                if (!var4) {
                    return false;
                }
            }

            return true;
        } else {
            return true;
        }
    }

    public ArrayList addPrecedenceConstraints(ArrayList var1) throws WTException {
        if (var1 == null) {
            return null;
        } else {
            for (int var2 = 0; var2 < var1.size(); ++var2) {
                PrecedenceConstraint var3 = (PrecedenceConstraint) var1.get(var2);
                var3 = (PrecedenceConstraint) PersistenceHelper.manager.save(var3);
            }

            return var1;
        }
    }

    public LinkedHashMap getAllPlanPrecedenceConstraints(Plannable var1) throws WTException {
        WTCollection var2 = this.listAllPlanPrecedenceConstraints(var1);
        ArrayList var3 = new ArrayList(var2.persistableCollection());
        LinkedHashMap var4 = new LinkedHashMap();

        for (int var5 = 0; var5 < var3.size(); ++var5) {
            PrecedenceConstraint var6 = (PrecedenceConstraint) var3.get(var5);
            ArrayList var7 = (ArrayList) var4.get(var6.getSuccessor());
            if (var7 == null) {
                var7 = new ArrayList();
                var7.add(var6);
                var4.put(var6.getSuccessor(), var7);
            } else {
                var7.add(var6);
            }
        }

        return var4;
    }

    public WTSet deleteAllPlanPrecedenceConstraints(Plannable var1) throws WTException {
        WTCollection var2 = this.listAllPlanPrecedenceConstraints(var1);
        WTHashSet var3 = new WTHashSet(var2);
        return PersistenceHelper.manager.delete(var3);
    }

    public WTSet deletePrecedenceConstraintsBySuccessor(Plannable var1) throws WTException {
        return this.deletePrecedenceConstraintsBySuccessor(var1, false);
    }

    public WTSet deletePrecedenceConstraintsBySuccessor(Plannable var1, boolean var2) throws WTException {
        WTCollection var3 = null;
        if (var2) {
            var3 = this.listPrecedenceConstraintsBySuccessor(var1);
        } else {
            var3 = this.listPrecedenceConstraintsBySuccessor(var1, true);
        }

        WTHashSet var4 = new WTHashSet(var3);
        return PersistenceHelper.manager.delete(var4);
    }

    public WTSet deletePrecedenceConstraintsByPredecessor(Plannable var1) throws WTException {
        WTCollection var2 = this.listPrecedenceConstraintsByPredecessor(var1);
        WTHashSet var3 = new WTHashSet(var2);
        return PersistenceHelper.manager.delete(var3);
    }

    public WTSet deletePrecedenceConstraintsForPlannable(Plannable var1) throws WTException {
        WTCollection var2 = this.listPrecedenceConstraintsIncludingPlannable(var1);
        WTHashSet var3 = new WTHashSet(var2);
        return PersistenceHelper.manager.delete(var3);
    }

    public WTSet deletePrecedenceConstraintsForPlannables(WTCollection var1) throws WTException {
        WTHashSet var2 = new WTHashSet();
        var2.addAll(var1);
        WTHashSet var3 = new WTHashSet();
        new WTHashSet();
        Iterator var5 = var2.persistableIterator();

        while (var5.hasNext()) {
            WTSet var4 = PlannableHelper.service.deletePrecedenceConstraintsForPlannable((Plannable) var5.next());
            var3.addAll(var4);
        }

        return var3;
    }

    public void propagateSchedule(Plannable var1) throws WTException {
        Project2 project = (Project2) var1.getContainer();
        PersistableAdapter adapter = new PersistableAdapter(project, null, null, null);
        adapter.load("Ct_CreateProjectFlag");
        Object flag = adapter.get("Ct_CreateProjectFlag");
        if (flag != null && (boolean) flag) {
            throw new WTException("此操作不被允许, 请联系管理员");
        }
        Locale var2 = SessionHelper.getLocale();
        logger.debug("User performing the propagateSchedule " + SessionHelper.getPrincipal());
        synchronized (var1) {
            logger.debug("Locking the plan for propagateSchedule " + var1);
            GanttDataModel var4 = (new GanttModelUtility()).createGanttModel(var1, false, var2);
            PlanWorkingHourHandler var5 = (PlanWorkingHourHandler) GanttSchedulingManager.getWorkingHourHandler(var4);
            if (var5 != null) {
                var5.createDurationCache();
            }

            var4 = GanttModelScheduleUtility.scheduleGanttModel(var4, true);
            if ("true".equalsIgnoreCase(CALCULATE_CRITICAL_PATH)) {
                GanttCriticalPathCalculator var6 = new GanttCriticalPathCalculator();
                boolean var7 = true;
                var6.calculate(var4, var7);
            } else {
                logger.debug("skipping critical path calculation");
            }

            if (var5 != null) {
                var5.destroyDurationCache();
            }

            GanttModelSaveUtility.updatePersistables(var4);
            logger.debug("Releasing the lock for the plan after propagateSchedule " + var1);
        }
    }

    public WTCollection listAllPlanPrecedenceConstraints(Plannable var1) throws WTException {
        if (var1 == null) {
            return new WTArrayList();
        } else {
            QuerySpec var2 = new QuerySpec();
            int var3 = var2.appendClassList(Plannable.class, false);
            int var4 = var2.appendClassList(PrecedenceConstraint.class, true);
            SearchCondition var5 = new SearchCondition(Plannable.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
            var2.appendWhere(var5, new int[]{0});
            var2.appendJoin(var4, "predecessor", var3);
            ClassAttribute var6 = new ClassAttribute(Plannable.class, "lineNumber");
            var2.appendOrderBy(new OrderBy(var6, false), new int[]{var3});
            QueryResult var7 = PersistenceHelper.manager.find(var2);
            WTArrayList var8 = new WTArrayList();
            var8.addAll(var7);
            return var8;
        }
    }

    public WTCollection listPrecedenceConstraintsBySuccessor(Plannable var1) throws WTException {
        return this.listPrecedenceConstraintsBySuccessor(var1, false);
    }

    public WTCollection listPrecedenceConstraintsBySuccessor(Plannable var1, boolean var2) throws WTException {
        boolean var3 = SessionServerHelper.manager.setAccessEnforced(false);

        WTArrayList var11;
        try {
            QuerySpec var4 = new QuerySpec();
            int var5 = var4.appendClassList(PrecedenceConstraint.class, true);
            int var6 = var4.appendClassList(Plannable.class, false);
            SearchCondition var7 = new SearchCondition(PrecedenceConstraint.class, "roleAObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
            var4.appendWhere(var7, var5);
            if (var2) {
                var4.appendAnd();
                SearchCondition var8 = new SearchCondition(Plannable.class, "lineNumber", "<>", 0);
                var4.appendWhere(var8, var6);
            }

            var4.appendJoin(var5, "predecessor", var6);
            ClassAttribute var15 = new ClassAttribute(Plannable.class, "lineNumber");
            var4.appendOrderBy(new OrderBy(var15, false), new int[]{var6});
            QueryResult var9 = PersistenceHelper.manager.find(var4);
            WTArrayList var10 = new WTArrayList();
            var10.addAll(var9);
            var11 = var10;
        } finally {
            SessionServerHelper.manager.setAccessEnforced(var3);
        }

        return var11;
    }

    public WTCollection listPrecedenceConstraintsByPredecessor(Plannable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PrecedenceConstraint.class, true);
        SearchCondition var4 = new SearchCondition(PrecedenceConstraint.class, "roleBObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var2.appendWhere(var4, var3);
        ClassAttribute var5 = new ClassAttribute(PrecedenceConstraint.class, "thePersistInfo.theObjectIdentifier.id");
        var2.appendOrderBy(new OrderBy(var5, false), new int[]{var3});
        QueryResult var6 = PersistenceHelper.manager.find(var2);
        WTArrayList var7 = new WTArrayList();
        var7.addAll(var6);
        return var7;
    }

    public WTCollection listPrecedenceConstraintsIncludingPlannable(Plannable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PrecedenceConstraint.class, true);
        SearchCondition var4 = new SearchCondition(PrecedenceConstraint.class, "roleBObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var2.appendWhere(var4, var3);
        var2.appendOr();
        SearchCondition var5 = new SearchCondition(PrecedenceConstraint.class, "roleAObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var2.appendWhere(var5, var3);
        ClassAttribute var6 = new ClassAttribute(PrecedenceConstraint.class, "thePersistInfo.theObjectIdentifier.id");
        var2.appendOrderBy(new OrderBy(var6, false), new int[]{var3});
        QueryResult var7 = PersistenceHelper.manager.find(var2);
        WTArrayList var8 = new WTArrayList();
        var8.addAll(var7);
        return var8;
    }

    protected void performStartupProcess() throws ManagerException {
        super.performStartupProcess();
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                if (true) return;
                PersistenceManagerEvent var2 = (PersistenceManagerEvent) var1;
                WTCollection var3 = (WTCollection) var2.getEventTarget();
                WTCollection var4 = var3.subCollection(PlanActivity.class, true);
                var4 = StandardPlannableService.this.removeBaselinedObjects(var4);
                ArrayList var5 = new ArrayList();
                HashMap var6 = new HashMap();
                String var12;
                if (!var4.isEmpty()) {
                    Rootable var7 = null;
                    Iterator var8 = var4.persistableIterator();

                    while (var8.hasNext()) {
                        PlanActivity var9 = (PlanActivity) var8.next();
                        if (var7 == null) {
                            var7 = var9.getRoot();
                        }

                        if (var7 != null) {
                            ObjectIdentifier var10 = PersistenceHelper.getObjectIdentifier(var9);
                            String var11 = PersistenceHelper.getObjectIdentifier(var7).toString();
                            var12 = var10.toString();
                            String var13 = var11 + ":" + var12;
                            String var14 = var11 + var12;
                            var6.put(var13, var14);
                            var5.add(var13);
                        }
                    }
                }

                Iterator var36;
                boolean var43;
                if (var5.size() > 0) {
                    ScheduleQueue var31 = StandardPlannableService.this.getQueueAfterBypassingAccessControl();
                    HashMap var32 = StandardPlannableService.this.areEntriesExistsInQueue(var31, var5);
                    var36 = var5.iterator();

                    while (var36.hasNext()) {
                        String var38 = (String) var36.next();
                        ScheduleQueueEntry var41 = (ScheduleQueueEntry) var32.get(var38);
                        if (var41 != null) {
                            AccessControlServerHelper.disableNotAuthorizedAudit();
                            var43 = SessionServerHelper.manager.setAccessEnforced(false);

                            try {
                                QueueHelper.manager.deleteEntry(var31, var41);
                            } finally {
                                SessionServerHelper.manager.setAccessEnforced(var43);
                                AccessControlServerHelper.reenableNotAuthorizedAudit();
                            }
                        } else {
                            var12 = (String) var6.get(var38);
                            StandardPlannableService.this.removeSchedItemsWithItemName(var12);
                        }
                    }
                }

                WTCollection var33 = var3.subCollection(PlanDeliverable.class, true);
                var33 = StandardPlannableService.this.removeBaselinedObjects(var33);
                if (!var33.isEmpty()) {
                    ScheduleQueue var34 = StandardPlannableService.this.getQueueAfterBypassingAccessControl();
                    var36 = var33.persistableIterator();
                    Boolean var39 = (Boolean) MethodContext.getContext().get("isDeliDeleteFromTasksOrActInfo");
                    Plan var42 = null;
                    var43 = false;
                    boolean var45 = false;
                    WTHashSet var46 = new WTHashSet();
                    WTArrayList var15 = new WTArrayList();

                    label376:
                    while (true) {
                        PlanDeliverable var16;
                        do {
                            if (!var36.hasNext()) {
                                if (!var46.isEmpty()) {
                                    StandardPlannableService.logger.debug("\t@@ Total linkedActivities = " + var46.size() + "");
                                    PersistenceHelper.manager.delete(var46);
                                    MethodContext.getContext().remove("isDeliDeleteFromTasks");
                                }

                                MethodContext.getContext().put("rollUpDeliverablesToMilestone", var15);
                                break label376;
                            }

                            var16 = (PlanDeliverable) var36.next();
                            if (var42 == null) {
                                Hierarchical var17 = var16.getParent();
                                if (var17 instanceof Plan) {
                                    var42 = (Plan) var17;
                                } else if (var17 instanceof PlanActivity) {
                                    var42 = (Plan) ((PlanActivity) var17).getRoot();
                                }

                                if (var42 != null) {
                                    var43 = PlannableUtils.isDeleteLinkedDeliverableOrActivity(var42.getContainerReference());
                                    var45 = var42.isLinkDeliverable();
                                }
                            }

                            ObjectIdentifier var47 = PersistenceHelper.getObjectIdentifier(var16);
                            String var18 = var16 + "".trim();
                            ScheduleQueueEntry var19 = StandardPlannableService.this.isEntryExistsInQueue(var34, var18);
                            if (var19 != null) {
                                AccessControlServerHelper.disableNotAuthorizedAudit();
                                boolean var20 = SessionServerHelper.manager.setAccessEnforced(false);

                                try {
                                    QueueHelper.manager.deleteEntry(var34, var19);
                                } finally {
                                    SessionServerHelper.manager.setAccessEnforced(var20);
                                    AccessControlServerHelper.reenableNotAuthorizedAudit();
                                }
                            }

                            List var48 = StandardPlannableService.this.getOldDeliverableEntryExistsInQueue(var34, var47);
                            if (!var48.isEmpty()) {
                                DeleteListListener var21 = new DeleteListListener(var48);
                                Transaction.addTransactionListener(var21);
                            }
                        } while (!var45);

                        WTCollection var49 = PlannableHelper.service.getPlanDeliverableLinks(var16);
                        Iterator var22 = var49.persistableIterator();

                        while (var22.hasNext()) {
                            PlanDeliverableLink var23 = (PlanDeliverableLink) var22.next();
                            PlanActivity var24 = var23.getPlanActivity();
                            if (var45 && var24.isMilestone()) {
                                var15.add(var24);
                            }

                            if (Boolean.TRUE.equals(var39) && var43) {
                                var46.add(var23.getPlanActivity());
                            }
                        }
                    }
                }

                Boolean var35 = (Boolean) MethodContext.getContext().get("SKIP_DELETE_LISTENER");
                if (var35 == null || var35.equals(Boolean.FALSE)) {
                    WTCollection var37 = var3.subCollection(Plannable.class, true);
                    var37 = StandardPlannableService.this.removeBaselinedObjects(var37);
                    PlannableHelper.service.deletePrecedenceConstraintsForPlannables(var37);
                    Iterator var40 = var37.persistableIterator();

                    while (var40.hasNext()) {
                        Plannable var44 = (Plannable) var40.next();
                        AssignmentHelper.service.deleteAllAssignmentsForPlannable(var44);
                        StandardPlannableService.this.changeDeliverableParent(var44);
                    }
                }

                StandardPlannableService.this.fixPlanTemplateTypeIdentities(var3);
            }
        }, PersistenceManagerEvent.generateEventKey("PRE_DELETE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                if (true) return;
                WTCollection var2 = (WTCollection) MethodContext.getContext().get("rollUpDeliverablesToMilestone");
                if (var2 != null && var2.size() > 0) {
                    try {
                        ProcessorUtils.rollUpDeliverablesToMilestone(var2);
                    } catch (WTPropertyVetoException var20) {
                        StandardPlannableService.logger.error("DeleteMilestone : Exception while rolling up Deliverables to Milestone: " + var20);
                    }

                    MethodContext.getContext().remove("rollUpDeliverablesToMilestone");
                }

                PersistenceManagerEvent var3 = (PersistenceManagerEvent) var1;
                WTCollection var4 = (WTCollection) var3.getEventTarget();
                WTCollection var5 = var4.subCollection(Iterated.class, true);
                WTCollection var7;
                ArrayList var9;
                Iterator var10;
                Iterator var15;
                if (!var5.isEmpty()) {
                    WTValuedMap var6 = StandardPlannableService.this.getFirstIterations(var5);
                    var7 = StandardPlannableService.this.getDeliverablestoRemoveSubjectLink(var5);
                    WTArrayList var8 = new WTArrayList();
                    var9 = new ArrayList();
                    var10 = var5.persistableCollection().iterator();

                    label156:
                    while (true) {
                        long var13;
                        do {
                            Iterated var12;
                            do {
                                do {
                                    do {
                                        Object var11;
                                        do {
                                            do {
                                                if (!var10.hasNext()) {
                                                    if (!var8.isEmpty()) {
                                                        PersistenceHelper.manager.save(var8);
                                                    }
                                                    break label156;
                                                }

                                                var11 = var10.next();
                                            } while (var11 == null);
                                        } while (!(var11 instanceof Iterated));

                                        var12 = (Iterated) var11;
                                        var13 = var12.getBranchIdentifier();
                                    } while (var9.contains(var13));
                                } while (var6.get(var12.getPersistInfo().getObjectIdentifier()) != null);
                            } while (var7 == null);
                        } while (var7.size() <= 0);

                        var15 = var7.persistableCollection().iterator();

                        while (var15.hasNext()) {
                            Object var16 = var15.next();

                            try {
                                ((PlanDeliverable) var16).setSubject((VersionReference) null);
                                var8.add(var16);
                            } catch (WTPropertyVetoException var19) {
                                StandardPlannableService.logger.debug("Error while updating the subject of deliverable " + var16 + " Exception == " + var19.getMessage());
                                throw new WTException(var19.getLocalizedMessage());
                            }
                        }

                        var9.add(var13);
                    }
                }

                Boolean var22 = (Boolean) MethodContext.getContext().get("SKIP_DELETE_LISTENER");
                if (var22 == null || var22.equals(Boolean.FALSE)) {
                    var7 = var4.subCollection(Plannable.class, true);
                    var7 = StandardPlannableService.this.removeBaselinedObjects(var7);

                    try {
                        Rootable var23 = null;
                        var9 = new ArrayList();
                        var10 = var7.persistableIterator();
                        HashSet var24 = new HashSet();
                        WTHashSet var25 = new WTHashSet();

                        Hierarchical var32;
                        while (var10.hasNext()) {
                            Plannable var26 = (Plannable) var10.next();
                            Rootable var14 = null;
                            if (var26.getRoot() instanceof Rootable) {
                                var14 = var26.getRoot();
                            }

                            if (var26.isSummary()) {
                                WTCollection var28 = StandardPlannableService.this.getImmediateChildren(var26);
                                Iterator var31 = var28.iterator();

                                while (var31.hasNext()) {
                                    ObjectReference var17 = (ObjectReference) var31.next();
                                    Plannable var18 = (Plannable) var17.getObject();
                                    var18.setParentReference((ObjectReference) null);
                                    var25.add(var18);
                                }
                            }

                            if (var23 != null && !var23.equals(var14)) {
                                throw new ManagerException(WTMessage.getLocalizedMessage("com.ptc.projectmanagement.plannable.plannableResource", "19", (Object[]) null));
                            }

                            var23 = var14;
                            var9.add(var26.getLineNumber());
                            if (var14 != null && var14 instanceof Plan) {
                                ObjectReference var30 = var26.getParentReference();
                                if (var30 != null && !var7.contains(var30)) {
                                    var32 = var26.getParent();
                                    if (var32 != null) {
                                        var24.add(var32);
                                    }
                                }
                            }
                        }

                        if (!var25.isEmpty()) {
                            PersistenceHelper.manager.delete(var25);
                        }

                        if (var9.isEmpty()) {
                            return;
                        }

                        if (var23 != null && PersistenceHelper.isPersistent(var23) && var23 instanceof Plan) {
                            int var27 = StandardPlannableService.this.getLowerLineNumber(var9);
                            WTCollection var29 = StandardPlannableService.this.getAllPlannables((Plannable) var23, var27);
                            StandardPlannableService.this.reorderAndStorePlannableLineNumbers(var29, var27);
                            //PlannableHelper.service.propagateSchedule((Plannable)var23);
                            StandardPlannableService.this.updateSummaryFlags((Plannable) var23);
                    /*        if (!var24.isEmpty() && var23 instanceof Scheduleable) {
                                var15 = var24.iterator();

                                while(var15.hasNext()) {
                                    var32 = (Hierarchical)var15.next();
                                    var32 = (Hierarchical)PersistenceHelper.manager.refresh(var32);
                                    AssignmentHelper.service.rollUpEffort((WorkTrackable)var32);
                                    CostHelper.service.rollUpCost((CostTrackable)var32);
                                    var32 = (Hierarchical)PersistenceHelper.manager.refresh(var32);
                                    HealthStatusHelper.service.rollUpStatus((Scheduleable)var32);
                                }
                            }*/
                        }
                    } catch (WTPropertyVetoException var21) {
                        throw new ManagerException(var21.getMessage());
                    }
                }

            }
        }, PersistenceManagerEvent.generateEventKey("POST_DELETE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                WTArrayList var2 = (WTArrayList) ((ProjectManagementEvent) var1).getEventTarget();
                WTCollection var3 = var2.subCollection(Plannable.class);
                Iterator var4 = var3.persistableIterator();

                while (true) {
                    Object var5;
                    do {
                        if (!var4.hasNext()) {
                            return;
                        }

                        var5 = var4.next();
                    } while (!(var5 instanceof Plannable));

                    Plannable var6 = (Plannable) var5;
                    StandardPlannableService.logger.trace("StandardPlannableService: PLANACTIVITY_STATE_CHANGE event listened for = " + var6);
                    if (var6 instanceof PlanActivity) {
                        WTPrincipal var7 = OwnershipHelper.getReadOnlyOwner((Ownable) var6);
                        PlanActivity var8 = (PlanActivity) var6;
                        if (var7 != null && PlannableUtils.isOwnerStateChangeNotifications(var8.getContainerReference())) {
                            StandardPlannableService.sendNotification(var6);
                        }
                    }

                    WTCollection var10 = AssignmentHelper.service.getResourceAssignments(var6);
                    Iterator var11 = var10.persistableIterator();

                    while (var11.hasNext()) {
                        ResourceAssignment var9 = (ResourceAssignment) var11.next();
                        PlannableUtils.sendResourceNotification(var9);
                    }

                    StandardPlannableService.this.completePlannablesWithNoDuration(var6);
                }
            }
        }, ProjectManagementEvent.generateEventKey(ProjectManagementEvent.class, "PLANACTIVITY_STATE_CHANGE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                ProjectManagementEvent var2 = (ProjectManagementEvent) var1;
                WTCollection var3 = (WTCollection) var2.getEventTarget();
                Plan var4 = null;
                Iterator var5 = var3.persistableIterator();

                while (var5.hasNext()) {
                    Object var6 = var5.next();
                    if (var6 instanceof Plan) {
                        var4 = (Plan) var6;
                        boolean var7 = SessionServerHelper.manager.setAccessEnforced(false);

                        try {
                            StandardPlannableService.this.createDummyMilestone(var4);
                            ScheduleQueue var8 = (ScheduleQueue) QueueHelper.manager.getQueue("EPPQueue", ScheduleQueue.class);
                            if (var8 == null) {
                                var8 = QueueHelper.manager.createScheduleQueue("EPPQueue", true);
                            }
                        } catch (WTPropertyVetoException var12) {
                            var12.printStackTrace();
                        } finally {
                            SessionServerHelper.manager.setAccessEnforced(var7);
                        }
                    }
                }

            }
        }, ProjectManagementEvent.generateEventKey(ProjectManagementEvent.class, "NEW_PLAN"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                WTArrayList var2 = (WTArrayList) ((ProjectManagementEvent) var1).getEventTarget();
                WTCollection var3 = var2.subCollection(Plannable.class);
                Iterator var4 = var3.persistableIterator();
                PlanActivity var5 = null;

                while (var4.hasNext()) {
                    Object var6 = var4.next();
                    if (var6 instanceof PlanActivity) {
                        var5 = (PlanActivity) var6;
                    }
                }

                WTCollection var10 = var2.subCollection(PlanDeliverable.class);
                Iterator var7 = var10.persistableIterator();
                PlanDeliverable var8 = null;

                while (var7.hasNext()) {
                    Object var9 = var7.next();
                    if (var9 instanceof PlanDeliverable) {
                        var8 = (PlanDeliverable) var9;
                    }
                }

                if (StandardPlannableService.logger.isTraceEnabled()) {
                    StandardPlannableService.logger.trace("   StandardPlannableService: event listened = ");
                }

                if (var5 != null) {
                    StandardPlannableService.this.schedulePlannablesDeadLine(var5.getRoot(), var5);
                    if (var5.getDeadline() != null) {
                        if (var5.getAfterDeadline() > 0) {
                            PlannableHelper.service.schedulePlannablesDeadLineAfter(var5.getRoot(), var5);
                        }

                        if (var5.getBeforeDeadline() > 0) {
                            PlannableHelper.service.schedulePlannablesDeadLineBefore(var5.getRoot(), var5);
                        }
                    }
                }

                if (var8 != null) {
                    StandardPlannableService.this.scheduleDeliverablesDeadLine((Rootable) null, var8);
                    if (var8.getDeadline() != null) {
                        if (var8.getAfterDeadline() > 0) {
                            PlannableHelper.service.scheduleDeliverablesDeadLineAfter((Rootable) null, var8);
                        }

                        if (var8.getBeforeDeadline() > 0) {
                            PlannableHelper.service.scheduleDeliverablesDeadLineBefore((Rootable) null, var8);
                        }
                    }
                }

            }
        }, ProjectManagementEvent.generateEventKey(ProjectManagementEvent.class, "EPP_DEADLINE_CHANGE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                WTArrayList var2 = (WTArrayList) ((ProjectManagementEvent) var1).getEventTarget();
                WTCollection var3 = var2.subCollection(Plannable.class);
                Iterator var4 = var3.persistableIterator();

                while (true) {
                    Plannable var6;
                    PlanActivity var8;
                    do {
                        WTPrincipal var7;
                        do {
                            do {
                                do {
                                    Object var5;
                                    do {
                                        if (!var4.hasNext()) {
                                            return;
                                        }

                                        var5 = var4.next();
                                    } while (!(var5 instanceof Plannable));

                                    var6 = (Plannable) var5;
                                    StandardPlannableService.logger.trace("StandardPlannableService: EPP_OWNER_CHANGE event listened for = " + var6);
                                } while (!(var6 instanceof PlanActivity));

                                var7 = OwnershipHelper.getReadOnlyOwner((Ownable) var6);
                                var8 = (PlanActivity) var6;
                            } while (var7 == null);
                        } while (!PlannableUtils.isOwnerStateChangeNotifications(var8.getContainerReference()));
                    } while (!var8.isInProcess() && !var8.isSuspended());

                    StandardPlannableService.sendNotification(var6);
                }
            }
        }, ProjectManagementEvent.generateEventKey(ProjectManagementEvent.class, "EPP_OWNER_CHANGE"));
        StandardPlannableService.PlannableHistoryResolutionListener var1 = new StandardPlannableService.PlannableHistoryResolutionListener(this.getConceptualClassname());
        this.getManagerService().addEventListener(var1, ProjectManagementEvent.generateEventKey("EPP_STATUS_CHANGE"));
        this.getManagerService().addEventListener(var1, ProjectManagementEvent.generateEventKey("EPP_PERCENT_CHANGE"));
        this.getManagerService().addEventListener(var1, ProjectManagementEvent.generateEventKey("EPP_DEADLINE_CHANGE"));
        this.getManagerService().addEventListener(var1, ProjectManagementEvent.generateEventKey("PLANACTIVITY_STATE_CHANGE"));
        this.getManagerService().addEventListener(var1, ProjectManagementEvent.generateEventKey("EPP_FINISH_CHANGE"));
    }

    public PlanActivity createDummyMilestone(Plan var1) throws WTException, WTPropertyVetoException {
        PlanActivity var2 = (PlanActivity) this.getPlannableByLineNumber(var1, 0, false);
        if (var2 == null) {
            Duration var3 = new Duration();
            var3.setMillis(0L);
            var3.setDurationFormat(DurationFormat.HOURS);
            var2 = PlanActivity.newPlanActivity(var1.getContainerReference());
            var2.setRoot(var1);
            var2.setLineNumber(0);
            var2.setMilestone(true);
            var2.setName(var1.getName());
            var2.setStartDate(var1.getStartDate());
            var2.setFinishDate(var1.getStartDate());
            PlannableState var4 = PlannableState.SCHEDULED;
            var2.setPlannableState(var4);
            var2.setTotalEffort(var3);
            var2.setDoneEffort(var3);
            var2.setRemainingEffort(var3);
            var2.setPercentWorkComplete(100.0D);
            var2.setConstraintType(DateConstraint.ASAP);
            var2 = (PlanActivity) this.addPlannable(var2, var1);
        }

        return var2;
    }

    public void reorderPlannables(Plannable var1, List var2, Plannable var3) throws WTException, WTPropertyVetoException {
        ArrayList var4 = new ArrayList(var2);
        int var5 = var3.getLineNumber();
        int var6 = this.getLowerLineNumber(var4, var5);
        int var7 = this.getHigherLineNumber(var4, var5);
        WTCollection var8 = this.getAllPlannables(var1, var6, var7);
        WTArrayList var9 = new WTArrayList(var8);
        WTArrayList var10 = new WTArrayList();

        int var11;
        for (var11 = 0; var11 < var4.size(); ++var11) {
            int var12 = (Integer) var4.get(var11) - var6;
            ObjectReference var13 = (ObjectReference) var9.get(var12);
            var10.add(var13);
        }

        var9.removeAll(var10);
        var11 = var9.indexOf(var3);
        var9.addAll(var11, var10);
        this.reorderAndStorePlannableLineNumbers(var9, var6);
    }

    public void reorderPlannablesBelow(Plannable var1, List var2, Plannable var3) throws WTException, WTPropertyVetoException {
        ArrayList var4 = new ArrayList(var2);
        Rootable var5 = var3.getRoot();
        int var6 = 0;
        Plannable var7 = null;
        ArrayList var8 = new ArrayList();
        if (var3.isSummary()) {
            var8.addAll(this.getLineNumbersOfAllChildren(var3));
            if (var4 != null) {
                var6 = (Integer) var8.get(var8.size() - 1) + 1;
            }
        } else {
            var6 = var3.getLineNumber() + 1;
        }

        Plannable var9 = null;
        if (var5 instanceof Plannable) {
            var9 = (Plannable) var5;
        }

        if (var6 > 0) {
            var7 = PlannableHelper.service.getPlannableByLineNumber(var9, var6);
        }

        int var10 = this.getLowerLineNumber(var4, var6);
        int var11 = this.getHigherLineNumber(var4, var6);
        WTCollection var12 = this.getAllPlannables(var1, var10, var11);
        WTArrayList var13 = new WTArrayList(var12);
        WTArrayList var14 = new WTArrayList();

        int var15;
        for (var15 = 0; var15 < var4.size(); ++var15) {
            int var16 = (Integer) var4.get(var15) - var10;
            ObjectReference var17 = (ObjectReference) var13.get(var16);
            var14.add(var17);
        }

        var13.removeAll(var14);
        var15 = var13.indexOf(var7);
        if (var15 == -1) {
            var15 = 0;
        }

        var13.addAll(var15, var14);
        this.reorderAndStorePlannableLineNumbers(var13, var10);
    }

    public WTCollection getImmediateChildren(Plannable var1) throws WTException {
        return this.getImmediateChildren(var1, false);
    }

    public WTCollection getImmediateChildren(Plannable var1, boolean var2) throws WTException {
        WTArrayList var3 = new WTArrayList();
        QuerySpec var4 = new QuerySpec();
        var4.appendClassList(Plannable.class, true);
        ObjectIdentifier var5 = PersistenceHelper.getObjectIdentifier(var1);
        SearchCondition var6 = new SearchCondition(Plannable.class, "parentReference.key", "=", var5);
        var4.appendWhere(var6, new int[]{0, 1});
        if (var2) {
            var4.appendAnd();
            var4.appendWhere(new SearchCondition(Plannable.class, "lineNumber", "<>", 0));
        }

        ClassAttribute var7 = new ClassAttribute(Plannable.class, "lineNumber");
        var4.appendOrderBy(new OrderBy(var7, false), new int[]{0});
        var3.addAll(PersistenceHelper.manager.find(var4));
        return var3;
    }

    public boolean isImmediateChildrenInprocess(Plannable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        var2.setAdvancedQueryEnabled(true);
        int var3 = var2.appendClassList(Plannable.class, false);
        ObjectIdentifier var4 = PersistenceHelper.getObjectIdentifier(var1);
        SearchCondition var5 = new SearchCondition(Plannable.class, "parentReference.key", "=", var4);
        var2.appendSelect(SQLFunction.newSQLFunction("COUNT", Keyword.COLUMN_WILDCARD.newKeywordExpression()), false);
        var2.appendWhere(var5, new int[]{var3});
        var2.appendAnd();
        var2.appendWhere(new SearchCondition(Plannable.class, "plannableState", "=", "INPROCESS"), new int[]{0});
        QueryResult var6 = PersistenceServerHelper.manager.query(var2);
        return ((Number) ((Object[]) ((Object[]) var6.nextElement()))[0]).intValue() != 0;
    }

    public WTCollection getAllChildren(Plannable var1) throws WTException {
        WTCollection var2 = this.getImmediateChildren(var1);
        Iterator var3 = var2.persistableIterator();
        WTArrayList var4 = new WTArrayList();

        while (var3.hasNext()) {
            Plannable var5 = (Plannable) var3.next();
            var4.add(var5);
            if (var5.isSummary()) {
                var4.addAll(this.getAllChildren(var5));
            }
        }

        return var4;
    }

    public Plannable changeParentPlannable(Plannable var1, Plannable var2) throws WTException {
        boolean var3 = false;
        if (var2 instanceof PlanActivity) {
            PlanActivity var4 = (PlanActivity) var2;
            Plan var5 = (Plan) var4.getRoot();
            var3 = var5.isLinkDeliverable();
        }

        if (var3 && var2.isMilestone()) {
            Locale var11 = SessionHelper.getLocale();
            Object[] var12 = new Object[]{var2.getName()};
            String var6 = WTMessage.getLocalizedMessage("com.ptc.projectmanagement.plan.planResource", "MILESTONE_TO_SUMMARY_ACTIVITY_NOT_ALLOWED", var12, var11);
            throw new WTException(var6);
        } else {
            Plannable var9 = var1.getParentPlannable();

            try {
                var1.setParent(var2);
            } catch (WTPropertyVetoException var8) {
                throw new WTException(var8);
            }

            var1 = (Plannable) PersistenceHelper.manager.save(var1);
            var9 = this.calculateSummaryFlag(var9);
            this.calculateSummaryFlag(var2);
            if (!var9.isSummary() && ((WorkTrackable) var9).getTotalEffort() != null) {
                try {
                    Duration var10 = new Duration();
                    var10.setDurationFormat(DurationFormat.MINUTES);
                    ((WorkTrackable) var9).setTotalEffort(var10);
                    ((WorkTrackable) var9).setRemainingEffort(var10);
                    ((WorkTrackable) var9).setDoneEffort(var10);
                    ((WorkTrackable) var9).setPercentWorkComplete(0.0D);
                    var9.setDuration(ProcessorUtils.getDuration(1.0D, DurationFormat.DAYS.toString()));
                    var9 = (Plannable) PersistenceHelper.manager.save(var9);
                    var9 = (Plannable) PersistenceHelper.manager.refresh(var9);
                } catch (WTPropertyVetoException var7) {
                    throw new WTException(var7);
                }
            }

            return var1;
        }
    }

    public WTCollection changeParentPlannable(WTCollection var1, Plannable var2) throws WTException {
        Iterator var3 = var1.persistableIterator();
        ArrayList var4 = new ArrayList();

        try {
            while (var3.hasNext()) {
                Plannable var5 = (Plannable) var3.next();
                var4.add(var5.getParentPlannable());
                var5.setParent(var2);
            }

            var1 = PersistenceHelper.manager.save(var1);
            Iterator var12 = var4.iterator();

            while (var12.hasNext()) {
                Plannable var6 = (Plannable) var12.next();
                var6.setSummary(this.getImmediateChildren(var6).size() > 0);
            }

            boolean var13 = SessionServerHelper.manager.setAccessEnforced(false);

            try {
                PersistenceHelper.manager.save(new WTArrayList(var4));
            } finally {
                SessionServerHelper.manager.setAccessEnforced(var13);
            }

            return var1;
        } catch (WTPropertyVetoException var11) {
            throw new WTException(var11);
        }
    }

    public WTCollection getSummaryActivities(Plannable var1, boolean var2) throws WTException {
        Class var5 = Plannable.class;
        boolean var6 = false;
        if (var1 instanceof Plan) {
            var5 = PlanActivity.class;
            var6 = true;
        }

        QuerySpec var7 = new QuerySpec();
        int var8 = var7.appendClassList(var5, true);
        if (var6) {
            var7.setAdvancedQueryEnabled(true);

            try {
                var7.setDescendantsIncluded(false, var8);
            } catch (WTPropertyVetoException var14) {
                logger.error("Error while seting DescendantsIncluded to false" + var14.getMessage());
                var14.printStackTrace();
            }
        }

        SearchCondition var9 = new SearchCondition(var5, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var7.appendWhere(var9, new int[]{var8});
        var7.appendAnd();
        var7.appendWhere(new SearchCondition(var5, "summary", "TRUE"));
        if (var2) {
            QuerySpec var10 = new QuerySpec();
            int var11 = var10.appendClassList(var5, false);
            var10.appendSelectAttribute("parentReference.key.id", var11, false);

            try {
                var10.setDescendantsIncluded(false, var11);
            } catch (WTPropertyVetoException var13) {
                var13.printStackTrace();
            }

            var10.appendWhere(var9, new int[]{var11});
            var7.appendAnd();
            var7.appendWhere(new SearchCondition(new ClassAttribute(var5, "thePersistInfo.theObjectIdentifier.id"), "NOT IN", new SubSelectExpression(var10)));
        }

        QueryResult var15 = PersistenceHelper.manager.find(var7);
        WTArrayList var16 = new WTArrayList();
        var16.addAll(var15);
        return var16;
    }

    public void movePlannables(WTCollection var1, Plannable var2, boolean var3) throws WTException {
        this.movePlannables(var1, var2, var3, false, (FormResult) null);
    }

    public void movePlannables(WTCollection var1, Plannable var2, boolean var3, boolean var4, FormResult var5) throws WTException {
        WTHashSet var6 = new WTHashSet();
        var6.add(var2.getParentPlannable());
        Rootable var7 = var2.getRoot();
        Plannable var8 = null;
        if (var7 instanceof Plannable) {
            var8 = (Plannable) var7;
        }

        Plannable var9 = var2.getParentPlannable();
        PasteActionUtil.validatePredecessorSuccessor(var1, var2, true);
        ArrayList var10 = new ArrayList();
        ArrayList var11 = new ArrayList();
        Iterator var12 = var1.persistableIterator();

        try {
            for (; var12.hasNext(); var10.add(((ObjectReference) var1.iterator().next()).getObject())) {
                Plannable var13 = (Plannable) var12.next();
                var11.add(var13.getLineNumber());
                var6.add(var13.getParentPlannable());
                if (var13.isSummary()) {
                    var11.addAll(this.getLineNumbersOfAllChildren(var13));
                }
            }

            this.changeParentPlannable(var1, var9);
            if (var3) {
                this.reorderPlannablesBelow(var8, var11, var2);
                var10.set(0, PersistenceHelper.manager.refresh((Persistable) var10.get(0)));
                if (var4) {
                    PlanIndentProcessor var17 = new PlanIndentProcessor();
                    NmOid var14 = NmOid.newNmOid(var7.getPersistInfo().getObjectIdentifier());
                    NmCommandBean var15 = new NmCommandBean();
                    var15.setPageOid(var14);
                    var17.indentActivities(var5, var10, var15, false);
                }
            } else {
                this.reorderPlannables(var8, var11, var2);
            }
        } catch (WTPropertyVetoException var16) {
            throw new WTException(var16);
        }

        this.propagateSchedule(var8);
        this.rollUpEffortFromChildrenList(var6);
        rollUpCostFromChildrenList(var1);
    }

    public PrecedenceConstraint getAnyPrecedenceConstraintBetweenActivities(Plannable var1, Plannable var2) throws WTException {
        QuerySpec var3 = new QuerySpec();
        int var4 = var3.appendClassList(PrecedenceConstraint.class, true);
        var3.appendOpenParen();
        SearchCondition var5 = new SearchCondition(PrecedenceConstraint.class, "roleAObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var3.appendWhere(var5, var4);
        var3.appendAnd();
        SearchCondition var6 = new SearchCondition(PrecedenceConstraint.class, "roleBObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var2).getId());
        var3.appendWhere(var6, var4);
        var3.appendCloseParen();
        var3.appendOr();
        var3.appendOpenParen();
        SearchCondition var7 = new SearchCondition(PrecedenceConstraint.class, "roleBObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var3.appendWhere(var7, var4);
        var3.appendAnd();
        SearchCondition var8 = new SearchCondition(PrecedenceConstraint.class, "roleAObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var2).getId());
        var3.appendWhere(var8, var4);
        var3.appendCloseParen();
        QueryResult var9 = PersistenceHelper.manager.find(var3);
        WTArrayList var10 = new WTArrayList();
        var10.addAll(var9);
        ArrayList var11 = new ArrayList(var10.persistableCollection());
        PrecedenceConstraint var12 = null;
        if (var11.size() == 1) {
            var12 = (PrecedenceConstraint) var11.get(0);
        }

        return var12;
    }

    public PrecedenceConstraint getPrecedenceConstraintBetweenActivities(Plannable var1, Plannable var2) throws WTException {
        QuerySpec var3 = new QuerySpec();
        int var4 = var3.appendClassList(PrecedenceConstraint.class, true);
        SearchCondition var5 = new SearchCondition(PrecedenceConstraint.class, "roleAObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var3.appendWhere(var5, var4);
        var3.appendAnd();
        SearchCondition var6 = new SearchCondition(PrecedenceConstraint.class, "roleBObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var2).getId());
        var3.appendWhere(var6, var4);
        QueryResult var7 = PersistenceHelper.manager.find(var3);
        WTArrayList var8 = new WTArrayList();
        var8.addAll(var7);
        ArrayList var9 = new ArrayList(var8.persistableCollection());
        PrecedenceConstraint var10 = null;
        if (var9.size() == 1) {
            var10 = (PrecedenceConstraint) var9.get(0);
        }

        return var10;
    }

    public PlanDeliverable getDeliverable(Plannable var1) throws WTException {
        PlanDeliverable var2 = null;
        QuerySpec var3 = new QuerySpec();
        var3.appendClassList(PlanDeliverable.class, true);
        SearchCondition var4 = new SearchCondition(PlanDeliverable.class, "parentReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var3.appendWhere(var4, new int[]{0});
        QueryResult var5 = PersistenceHelper.manager.find(var3);
        WTArrayList var6 = new WTArrayList();
        var6.addAll(var5);

        for (Iterator var7 = var6.persistableIterator(); var7.hasNext(); var2 = (PlanDeliverable) var7.next()) {
        }

        return var2;
    }

    public WTCollection getPlannablesOrDeliverablesLinksForContainer(WTContainerRef var1, boolean var2) throws WTException {
        boolean var3 = !var2;
        QuerySpec var4 = new QuerySpec();
        int var5 = var4.appendClassList(PlanActivity.class, var3);
        int var6 = var4.appendClassList(PlanDeliverableLink.class, var2);
        var4.appendWhere(new SearchCondition(PlanActivity.class, "containerReference.key", "=", PersistenceHelper.getObjectIdentifier(var1.getObject())), new int[]{0});
        var4.appendJoin(var6, "roleAObject", var5);
        QueryResult var7 = PersistenceHelper.manager.find(var4);
        WTArrayList var8 = new WTArrayList();
        var8.addAll(var7);
        return var8;
    }

    public WTCollection getDeliverables(Plannable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PlanDeliverable.class, true);
        int var4 = var2.appendClassList(PlanDeliverableLink.class, false);
        SearchCondition var5 = new SearchCondition(PlanDeliverableLink.class, "roleAObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var2.appendWhere(var5, var4);
        var2.appendJoin(var4, "planDeliverable", var3);
        ClassAttribute var6 = new ClassAttribute(PlanDeliverable.class, "name");
        var2.appendOrderBy(new OrderBy(var6, false), new int[]{var3});
        QueryResult var7 = PersistenceHelper.manager.find(var2);
        WTArrayList var8 = new WTArrayList();
        var8.addAll(var7);
        return var8;
    }

    public WTCollection getDeliverables(HashSet<Long> var1) throws WTException {
        long[] var2 = new long[var1.size()];
        int var3 = 0;

        for (Iterator var4 = var1.iterator(); var4.hasNext(); ++var3) {
            Long var5 = (Long) var4.next();
            var2[var3] = var5;
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Total activities for deliverables" + var2.length);
        }

        QuerySpec var11 = new QuerySpec();
        int var12 = var11.appendClassList(PlanDeliverable.class, true);
        int var6 = var11.appendClassList(PlanDeliverableLink.class, false);
        SearchCondition var7 = new SearchCondition(PlanDeliverableLink.class, "roleAObjectRef.key.id", var2);
        var11.appendWhere(var7, new int[]{var6});
        var11.appendJoin(var6, "planDeliverable", var12);
        ClassAttribute var8 = new ClassAttribute(PlanDeliverable.class, "name");
        var11.appendOrderBy(new OrderBy(var8, false), new int[]{var12});
        QueryResult var9 = PersistenceHelper.manager.find(var11);
        WTArrayList var10 = new WTArrayList();
        var10.addAll(var9);
        return var10;
    }

    public WTCollection getPlanDeliverableLinks(PlanDeliverable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PlanDeliverableLink.class, true);
        SearchCondition var4 = new SearchCondition(PlanDeliverableLink.class, "roleBObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var2.appendWhere(var4, var3);
        ClassAttribute var5 = new ClassAttribute(PlanDeliverableLink.class, "thePersistInfo.theObjectIdentifier.id");
        var2.appendOrderBy(new OrderBy(var5, false), new int[]{var3});
        QueryResult var6 = PersistenceHelper.manager.find(var2);
        WTArrayList var7 = new WTArrayList();
        var7.addAll(var6);
        return var7;
    }

    public WTCollection getPlanDeliverableLinks(PlanActivity var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PlanDeliverableLink.class, true);
        SearchCondition var4 = new SearchCondition(PlanDeliverableLink.class, "roleAObjectRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId());
        var2.appendWhere(var4, var3);
        ClassAttribute var5 = new ClassAttribute(PlanDeliverableLink.class, "thePersistInfo.theObjectIdentifier.id");
        var2.appendOrderBy(new OrderBy(var5, false), new int[]{var3});
        QueryResult var6 = PersistenceHelper.manager.find(var2);
        WTArrayList var7 = new WTArrayList();
        var7.addAll(var6);
        return var7;
    }

    public WTCollection getPlannableLinkedWithDeliverable(WTContainerRef var1, boolean var2) throws WTException {
        QuerySpec var3 = new QuerySpec();
        int var4 = var3.appendClassList(PlanActivity.class, true);
        int var5 = var3.appendClassList(PlanDeliverableLink.class, false);
        var3.appendWhere(new SearchCondition(PlanActivity.class, "containerReference.key", "=", PersistenceHelper.getObjectIdentifier(var1.getObject())), new int[]{0});
        if (var2) {
            var3.appendAnd();
            var3.appendWhere(new SearchCondition(PlanActivity.class, "milestone", "FALSE"), new int[]{0});
        }

        var3.appendJoin(var5, "roleAObject", var4);
        QueryResult var6 = PersistenceHelper.manager.find(var3);
        WTArrayList var7 = new WTArrayList();
        var7.addAll(var6);
        return var7;
    }

    public QueryResult getPlanObjectsForHomeAssignmentsTable(WTPrincipal var1, Class var2, Boolean var3, Boolean var4, Boolean var5, Integer var6, Boolean var7, Object var8) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("=> StandardPlannableService.getPlanObjectsForHomeAssignmentsTable: \n principal = " + var1 + "\n openAssignments = " + var3 + "\n isOverDue = " + var4 + "\n isOverviewPage = " + var5 + "\n queryLimit = " + var6 + "\n tmpObject = " + var8);
        }

        QuerySpec var9 = new QuerySpec(var2);
        var9.setAdvancedQueryEnabled(true);
        if (var6 != null && var6 > 0) {
            var9.setQueryLimit(var6);
        }

        SearchCondition var10 = this.getSCAssignedToPrincipal(new Boolean(true), var1, var2);
        var9.appendWhere(var10, new int[]{0});
        SearchCondition var11;
        if (var7 != null) {
            var11 = this.getSCForisDiscussed(var7, var2);
            var9.appendAnd();
            var9.appendWhere(var11, new int[]{0});
        }

        var11 = null;
        QueryResult var14;
        if (var2.equals(PlanActivity.class)) {
            var14 = this.getAllPlanActivities(var9, var3, var1, var5);
        } else if (var2.equals(PlanDeliverable.class)) {
            if (filterOnServerSide) {
                var14 = this.getAllPlanDeliverables(var9, var3, var1, var5, var7, var6);
            } else {
                var14 = this.getAllPlanDeliverables(var9, var3, var1, var5);
            }
        } else {
            if (var5) {
                OrderBy var12 = this.getOrderByCreateTimeStampSC(var2);
                var9.appendOrderBy(var12, new int[]{0});
            }

            if (logger.isDebugEnabled()) {
                logger.debug("=> getPlanObjectsForHomeAssignmentsTable: Query is - " + var9);
            }

            try {
                var14 = PersistenceHelper.manager.find(var9);
            } catch (PartialResultException var13) {
                var14 = var13.getQueryResult();
            }
        }

        if (logger.isDebugEnabled()) {
            logger.debug("=> getPlanObjectsForHomeAssignmentsTable: Query result size " + var14.size());
        }

        return var14;
    }

    private QueryResult getAllPlanDeliverables(QuerySpec var1, Boolean var2, WTPrincipal var3, Boolean var4) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("=> getAllPlanDeliverables : IN... QuerySpec - " + var1);
        }

        if (var4) {
            OrderBy var5 = this.getOrderByCreateTimeStampSC(PlanDeliverable.class);
            var1.appendOrderBy(var5, new int[]{0});
        }

        QueryResult var26 = new QueryResult();
        QueryResult var6 = null;

        try {
            var6 = PersistenceHelper.manager.find(var1);
        } catch (PartialResultException var25) {
            var6 = var25.getQueryResult();
        }

        Vector var7 = var6.getObjectVectorIfc().getVector();
        ObjectVector var8 = new ObjectVector();
        Iterator var9 = var7.iterator();

        while (true) {
            while (true) {
                PlanDeliverable var10;
                label168:
                do {
                    while (true) {
                        while (true) {
                            do {
                                if (!var9.hasNext()) {
                                    var26.append(var8);
                                    if (logger.isDebugEnabled()) {
                                        logger.debug("=> getAllPlanDeliverables : OUT... Query result size " + var26.size());
                                    }

                                    return var26;
                                }

                                var10 = (PlanDeliverable) var9.next();
                            } while (var8.contains(var10));

                            if (var2 != null) {
                                if (Boolean.TRUE.equals(var2)) {
                                    continue label168;
                                }

                                if (var10.getPercentComplete() == 100.0D) {
                                    var8.addElement(var10);
                                }
                            } else {
                                var8.addElement(var10);
                            }
                        }
                    }
                } while (var10.getPercentComplete() == 100.0D);

                boolean var11 = false;
                boolean var12 = false;
                boolean var13 = false;
                PlanActivity var14 = null;
                boolean var15 = SessionServerHelper.manager.setAccessEnforced(false);

                try {
                    Plan var16 = (Plan) var10.getParentReference().getObject();
                    var12 = var16.isAutoExecution();
                    var13 = var16.isInProcess();
                    WTCollection var17 = ProcessorUtils.getActivities(var10);
                    if (!var17.isEmpty()) {
                        Iterator var18 = var17.persistableIterator();
                        Object var19 = var18.next();
                        if (var19 instanceof PlanActivity) {
                            var14 = (PlanActivity) var19;
                            Plan var20 = (Plan) var14.getRoot();
                            if (var20 != null) {
                                var11 = var20.isLinkDeliverable();
                                var12 = var20.isAutoExecution();
                            }
                        }
                    }
                } finally {
                    SessionServerHelper.manager.setAccessEnforced(var15);
                }

                if (var11 && var12) {
                    logger.debug("Checking State of the Activity associated to deliverable " + var10.getName());
                    if (PlannableState.INPROCESS.equals(var14.getPlannableState())) {
                        var8.addElement(var10);
                    }
                } else {
                    logger.debug("Checking Start date of deliverable " + var10.getName());
                    Timestamp var27 = new Timestamp(System.currentTimeMillis());
                    if (var10.getStartDate() != null) {
                        if (!var10.getStartDate().after(var27)) {
                            var8.addElement(var10);
                        }
                    } else {
                        logger.debug("No/Null Start date of deliverable " + var10.getName());
                        var8.addElement(var10);
                    }
                }
            }
        }
    }

    private QueryResult getAllPlanDeliverables(QuerySpec var1, Boolean var2, WTPrincipal var3, Boolean var4, Boolean var5, Integer var6) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("=> getAllPlanDeliverables : IN... QuerySpec - " + var1);
        }

        QueryResult var7 = null;
        if (var2 != null) {
            if (var2) {
                try {
                    var7 = this.getOpenAssignmentPlanDeliverables(var3, var4, var5, var6);
                } catch (WTPropertyVetoException var15) {
                    var15.printStackTrace();
                }

                return var7;
            }

            var1.appendAnd();
            var1.appendWhere(new SearchCondition(PlanDeliverable.class, "percentComplete", "=", 100.0D), new int[]{0});
        }

        if (var4) {
            OrderBy var8 = this.getOrderByCreateTimeStampSC(PlanDeliverable.class);
            var1.appendOrderBy(var8, new int[]{0});
        }

        QueryResult var17 = new QueryResult();
        ObjectVector var9 = new ObjectVector();
        QueryResult var10 = null;

        try {
            if (logger.isDebugEnabled()) {
                logger.debug("Final value of QuerySpec" + var1);
            }

            var10 = PersistenceHelper.manager.find(var1);
        } catch (PartialResultException var16) {
            var10 = var16.getQueryResult();
        }

        Vector var11 = var10.getObjectVectorIfc().getVector();
        PlanDeliverable var12 = null;
        Iterator var13 = var11.iterator();

        while (var13.hasNext()) {
            Object var14 = var13.next();
            if (var14 instanceof PlanDeliverable) {
                var12 = (PlanDeliverable) var14;
            } else if (var14 instanceof Persistable[]) {
                var12 = (PlanDeliverable) ((Persistable[]) ((Persistable[]) var14))[0];
            }

            if (!var9.contains(var12)) {
                var9.addElement(var12);
            }
        }

        var17.append(var9);
        if (logger.isDebugEnabled()) {
            logger.debug("=> getAllPlanDeliverables : OUT... Query result size " + var17.size());
        }

        return var17;
    }

    private QueryResult getOpenAssignmentPlanDeliverables(WTPrincipal var1, Boolean var2, Boolean var3, Integer var4) throws WTException, WTPropertyVetoException {
        QuerySpec var5 = this.getNotAssociatedDeliverableSpec(var3, var1);
        QuerySpec var6 = this.getAssociatedDeliverableSpec(var3, var1);
        CompoundQuerySpec var7 = new CompoundQuerySpec();
        var7.setSetOperator(SetOperator.UNION);
        var7.setAdvancedQueryEnabled(true);
        var7.addComponent(var5);
        var7.addComponent(var6);
        QueryResult var8 = new QueryResult();
        ObjectVector var9 = new ObjectVector();
        QueryResult var10 = null;

        try {
            if (logger.isDebugEnabled()) {
                logger.debug("Final value of main QuerySpec - " + var7);
            }

            var10 = PersistenceServerHelper.manager.query(var7);
        } catch (PartialResultException var15) {
            var10 = var15.getQueryResult();
        }

        Vector var11 = var10.getObjectVectorIfc().getVector();
        PlanDeliverable var12 = null;
        Iterator var13 = var11.iterator();

        while (var13.hasNext()) {
            Object var14 = var13.next();
            if (var14 instanceof PlanDeliverable) {
                var12 = (PlanDeliverable) var14;
            } else if (var14 instanceof Persistable[]) {
                var12 = (PlanDeliverable) ((Persistable[]) ((Persistable[]) var14))[0];
            }

            if (!var9.contains(var12)) {
                var9.addElement(var12);
            }
        }

        var8.append(var9);
        if (logger.isDebugEnabled()) {
            logger.debug("=> getOpenPlanDeliverables : OUT... Query result size " + var8.size());
        }

        return var8;
    }

    private QuerySpec getNotAssociatedDeliverableSpec(Boolean var1, WTPrincipal var2) throws WTPropertyVetoException, WTException {
        QuerySpec var3 = new QuerySpec();
        var3.setAdvancedQueryEnabled(true);
        int var4 = var3.appendClassList(PlanDeliverable.class, true);
        var3.setDescendantsIncluded(false, var4);
        SearchCondition var5 = this.getSCAssignedToPrincipal(Boolean.TRUE, var2, PlanDeliverable.class);
        var3.appendWhere(var5, new int[]{var4});
        if (var1 != null) {
            int var6 = var3.appendClassList(DiscussionPosting.class, false);
            SearchCondition var7 = this.getSCForisDiscussed(var1, PlanDeliverable.class);
            var3.appendAnd();
            var3.appendWhere(var7, new int[]{var4, var6});
        }

        var3.appendAnd();
        var3.appendWhere(new SearchCondition(PlanDeliverable.class, "percentComplete", "<>", Double.parseDouble("100")), new int[]{var4});
        var3.appendAnd();
        var3.appendOpenParen();
        Timestamp var8 = new Timestamp(0L);
        var3.appendWhere(new SearchCondition(PlanDeliverable.class, "startDate", "IS NULL", var8));
        var3.appendOr();
        var3.appendWhere(new SearchCondition(PlanDeliverable.class, "startDate", "<=", new Timestamp(System.currentTimeMillis())));
        var3.appendCloseParen();
        var3.appendAnd();
        QuerySpec var9 = this.getPlanDeliverableQuerySpecRoleB();
        var3.appendWhere(new SearchCondition(new ClassAttribute(PlanDeliverable.class, "thePersistInfo.theObjectIdentifier.id"), "NOT IN", new SubSelectExpression(var9)));
        if (logger.isDebugEnabled()) {
            logger.debug("Not Associated Query - " + var3);
        }

        return var3;
    }

    private QuerySpec getAssociatedDeliverableSpec(Boolean var1, WTPrincipal var2) throws WTPropertyVetoException, WTException {
        QuerySpec var3 = new QuerySpec();
        var3.setAdvancedQueryEnabled(true);
        int var4 = var3.appendClassList(PlanDeliverable.class, true);
        var3.setDescendantsIncluded(false, var4);
        int var5 = var3.appendClassList(Plan.class, false);
        var3.setDescendantsIncluded(false, var5);
        int var6 = var3.appendClassList(PlanDeliverableLink.class, false);
        var3.setDescendantsIncluded(false, var6);
        int var7 = var3.appendClassList(PlanActivity.class, false);
        var3.setDescendantsIncluded(false, var7);
        SearchCondition var8 = this.getSCAssignedToPrincipal(Boolean.TRUE, var2, PlanDeliverable.class);
        var3.appendWhere(var8, new int[]{var4});
        if (var1 != null) {
            int var9 = var3.appendClassList(DiscussionPosting.class, false);
            SearchCondition var10 = this.getSCForisDiscussed(var1, PlanDeliverable.class);
            var3.appendAnd();
            var3.appendWhere(var10, new int[]{var4, var9});
        }

        var3.appendAnd();
        var3.appendWhere(new SearchCondition(PlanDeliverable.class, "percentComplete", "<>", Double.parseDouble("100")), new int[]{var4});
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(PlanDeliverable.class, "parentReference.key.id", Plan.class, "thePersistInfo.theObjectIdentifier.id"), new int[]{var4, var5});
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(PlanActivity.class, "parentReference.key.id", Plan.class, "thePersistInfo.theObjectIdentifier.id"), new int[]{var7, var5});
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(PlanDeliverable.class, "thePersistInfo.theObjectIdentifier.id", PlanDeliverableLink.class, "roleBObjectRef.key.id"), new int[]{var4, var6});
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(PlanActivity.class, "thePersistInfo.theObjectIdentifier.id", PlanDeliverableLink.class, "roleAObjectRef.key.id"), new int[]{var7, var6});
        var3.appendAnd();
        var3.appendOpenParen();
        Timestamp var11 = new Timestamp(0L);
        var3.appendWhere(new SearchCondition(PlanDeliverable.class, "startDate", "IS NULL", var11));
        var3.appendOr();
        var3.appendWhere(new SearchCondition(PlanDeliverable.class, "startDate", "<=", new Timestamp(System.currentTimeMillis())));
        var3.appendCloseParen();
        var3.appendAnd();
        var3.appendOpenParen();
        var3.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "autoExecution"), "=", new ConstantExpression(false)), new int[]{var5});
        var3.appendOr();
        var3.appendOpenParen();
        var3.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "autoExecution"), "=", new ConstantExpression(true)), new int[]{var5});
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "linkDeliverable"), "=", new ConstantExpression(false)), new int[]{var5});
        var3.appendCloseParen();
        var3.appendOr();
        var3.appendOpenParen();
        var3.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "autoExecution"), "=", new ConstantExpression(true)), new int[]{var5});
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "linkDeliverable"), "=", new ConstantExpression(true)), new int[]{var5});
        var3.appendAnd();
        var3.appendWhere(new SearchCondition(PlanActivity.class, "plannableState", "=", "INPROCESS"), new int[]{var7});
        var3.appendCloseParen();
        var3.appendCloseParen();
        if (logger.isDebugEnabled()) {
            logger.debug("Associated Query - " + var3);
        }

        return var3;
    }

    private QuerySpec getPlanDeliverableQuerySpecRoleB() throws QueryException {
        QuerySpec var1 = new QuerySpec();
        int var2 = var1.appendClassList(PlanDeliverableLink.class, false);
        var1.appendSelectAttribute("roleBObjectRef.key.id", var2, false);
        if (logger.isDebugEnabled()) {
            logger.debug("inner QuerySpec - " + var1);
        }

        return var1;
    }

    private QueryResult getAllPlanActivities(QuerySpec var1, Boolean var2, WTPrincipal var3, Boolean var4) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("=> getAllPlanActivities : IN... QuerySpec - " + var1);
        }

        if (var2 != null) {
            int var5;
            if (!var2) {
                var5 = var1.appendFrom(new ClassViewExpression(Plan.class));
                var1.appendAnd();
                var1.appendWhere(new SearchCondition(PlanActivity.class, "rootReference.key.id", Plan.class, "thePersistInfo.theObjectIdentifier.id"), new int[]{0, var5});
                var1.appendAnd();
                var1.appendOpenParen();
                var1.appendOpenParen();
                var1.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "autoExecution"), "=", new ConstantExpression(true)), new int[]{var5});
                var1.appendAnd();
                var1.appendWhere(new SearchCondition(PlanActivity.class, "plannableState", "=", "COMPLETED"), new int[]{0});
                var1.appendCloseParen();
                var1.appendOr();
                var1.appendOpenParen();
                var1.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "autoExecution"), "=", new ConstantExpression(false)), new int[]{var5});
                var1.appendAnd();
                var1.appendWhere(new SearchCondition(PlanActivity.class, "percentWorkComplete", "=", 100.0D), new int[]{0});
                var1.appendCloseParen();
                var1.appendCloseParen();
            } else {
                var5 = var1.appendFrom(new ClassViewExpression(Plan.class));
                var1.appendAnd();
                var1.appendWhere(new SearchCondition(PlanActivity.class, "rootReference.key.id", Plan.class, "thePersistInfo.theObjectIdentifier.id"), new int[]{0, var5});
                var1.appendAnd();
                var1.appendOpenParen();
                var1.appendOpenParen();
                var1.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "autoExecution"), "=", new ConstantExpression(true)), new int[]{var5});
                var1.appendAnd();
                var1.appendWhere(new SearchCondition(PlanActivity.class, "plannableState", "=", "INPROCESS"), new int[]{0});
                var1.appendCloseParen();
                var1.appendOr();
                var1.appendOpenParen();
                var1.appendWhere(new SearchCondition(new ClassAttribute(Plan.class, "autoExecution"), "=", new ConstantExpression(false)), new int[]{var5});
                var1.appendAnd();
                var1.appendWhere(new SearchCondition(PlanActivity.class, "percentWorkComplete", "<>", Double.parseDouble("100")), new int[]{0});
                var1.appendCloseParen();
                var1.appendCloseParen();
                var1.appendAnd();
                var1.appendWhere(new SearchCondition(PlanActivity.class, "startDate", "<=", new Timestamp(System.currentTimeMillis())));
            }
        }

        if (var4) {
            OrderBy var17 = this.getOrderByCreateTimeStampSC(PlanActivity.class);
            var1.appendOrderBy(var17, new int[]{0});
        }

        QueryResult var18 = new QueryResult();
        ObjectVector var6 = new ObjectVector();
        QueryResult var7 = null;
        boolean var8 = SessionServerHelper.manager.setAccessEnforced(false);

        try {
            logger.debug("Final value of QuerySpec - " + var1);
            var7 = PersistenceHelper.manager.find(var1);
        } catch (PartialResultException var15) {
            var7 = var15.getQueryResult();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(var8);
        }

        Vector var9 = var7.getObjectVectorIfc().getVector();
        PlanActivity var10 = null;
        Iterator var11 = var9.iterator();

        while (var11.hasNext()) {
            Object var12 = var11.next();
            if (var12 instanceof PlanActivity) {
                var10 = (PlanActivity) var12;
            } else if (var12 instanceof Persistable[]) {
                var10 = (PlanActivity) ((Persistable[]) ((Persistable[]) var12))[0];
            }

            if (!var6.contains(var10)) {
                var6.addElement(var10);
            }
        }

        var18.append(var6);
        if (logger.isDebugEnabled()) {
            logger.debug("=> getAllPlanActivities : OUT... Query result size " + var18.size());
        }

        return var18;
    }

    private OrderBy getOrderByCreateTimeStampSC(Class var1) throws QueryException {
        boolean var2 = true;
        ClassAttribute var3 = new ClassAttribute(var1, "thePersistInfo.createStamp");
        OrderBy var4 = new OrderBy(var3, var2);
        return var4;
    }

    public WTCollection getWTUserOwnedPlannables(WTContainerRef var1, WTUser var2) throws WTException {
        long var3 = ((ObjectIdentifier) var1.getKey()).getId();
        QuerySpec var5 = new QuerySpec();
        int var6 = var5.appendClassList(PlanActivity.class, true);
        SearchCondition var7 = new SearchCondition(PlanActivity.class, "containerReference.key.id", "=", var3);
        var5.appendWhere(var7, new int[]{0});
        if (var2 != null) {
            var5.appendAnd();
            var5.appendWhere(OwnershipHelper.getSearchCondition(PlanActivity.class, var2, true), new int[]{0});
        }

        ClassAttribute var8 = new ClassAttribute(PlanActivity.class, "name");
        var5.appendOrderBy(new OrderBy(var8, false), new int[]{var6});
        QueryResult var9 = PersistenceHelper.manager.find(var5);
        return new WTArrayList(var9);
    }

    public WTCollection getWTUserOwnedPlannables(Rootable var1, WTUser var2) throws WTException {
        QuerySpec var3 = new QuerySpec();
        int var4 = var3.appendClassList(PlanActivity.class, true);
        SearchCondition var5 = new SearchCondition(PlanActivity.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var3.appendWhere(var5, new int[]{0});
        if (var2 != null) {
            var3.appendAnd();
            var3.appendWhere(OwnershipHelper.getSearchCondition(PlanActivity.class, var2, true), new int[]{0});
        }

        ClassAttribute var6 = new ClassAttribute(PlanActivity.class, "name");
        var3.appendOrderBy(new OrderBy(var6, false), new int[]{var4});
        QueryResult var7 = PersistenceHelper.manager.find(var3);
        return new WTArrayList(var7);
    }

    public WTCollection changeOwnershipOfPlannables(WTContainerRef var1, WTUser var2, WTUser var3) throws WTException {
        WTCollection var4 = this.getWTUserOwnedPlannables(var1, var3);
        if (var2 != null) {
            OwnershipServerHelper.service.changeOwnership(var4, var2, true);
            Iterator var5 = var4.persistableIterator();

            while (var5.hasNext()) {
                PlanActivity var6 = (PlanActivity) var5.next();
                PlanHelper.service.dispatchEvent("EPP_OWNER_CHANGE", var6);
            }
        }

        return var4;
    }

    public WTCollection changeOwnershipOfPlannables(Rootable var1, WTUser var2, WTUser var3) throws WTException {
        WTCollection var4 = this.getWTUserOwnedPlannables(var1, var3);
        if (var2 != null) {
            OwnershipServerHelper.service.changeOwnership(var4, var2, true);
            Iterator var5 = var4.persistableIterator();

            while (var5.hasNext()) {
                PlanActivity var6 = (PlanActivity) var5.next();
                PlanHelper.service.dispatchEvent("EPP_OWNER_CHANGE", var6);
            }
        }

        return var4;
    }

    public WTCollection getImmediateCriticalChildren(Plannable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        var2.appendClassList(Plannable.class, true);
        ObjectIdentifier var3 = PersistenceHelper.getObjectIdentifier(var1);
        SearchCondition var4 = new SearchCondition(Plannable.class, "parentReference.key", "=", var3);
        var2.appendWhere(var4, new int[]{0});
        var2.appendAnd();
        SearchCondition var5 = new SearchCondition(Plannable.class, "critical", "TRUE");
        var2.appendWhere(var5, new int[]{0});
        ClassAttribute var6 = new ClassAttribute(Plannable.class, "lineNumber");
        var2.appendOrderBy(new OrderBy(var6, false), new int[]{0});
        WTArrayList var7 = new WTArrayList();
        var7.addAll(PersistenceHelper.manager.find(var2));
        return var7;
    }

    public WTCollection getLeafCriticalActivitiesOfPlan(Plan var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        var2.appendClassList(PlanActivity.class, true);
        ObjectIdentifier var3 = PersistenceHelper.getObjectIdentifier(var1);
        SearchCondition var4 = new SearchCondition(PlanActivity.class, "rootReference.key", "=", var3);
        var2.appendWhere(var4, new int[]{0});
        var2.appendAnd();
        SearchCondition var5 = new SearchCondition(Plannable.class, "critical", "TRUE");
        var2.appendWhere(var5, new int[]{0});
        var2.appendAnd();
        SearchCondition var6 = new SearchCondition(Plannable.class, "summary", "FALSE");
        var2.appendWhere(var6, new int[]{0});
        WTArrayList var7 = new WTArrayList();
        var7.addAll(PersistenceHelper.manager.find(var2));
        return var7;
    }

    public void showInTimeline(WTCollection var1, boolean var2) throws WTException {
        Iterator var3 = var1.persistableIterator();

        try {
            while (var3.hasNext()) {
                PlanActivity var4 = (PlanActivity) var3.next();
                var4.setShowInTimeline(var2);
            }

            var1 = PersistenceHelper.manager.save(var1);
        } catch (WTPropertyVetoException var5) {
            throw new WTException(var5);
        }
    }

    public WTCollection getAllRenderrableTimelineActivities(Rootable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        var2.appendClassList(PlanActivity.class, true);
        SearchCondition var3 = new SearchCondition(PlanActivity.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var2.appendWhere(var3, new int[]{0});
        var2.appendAnd();
        SearchCondition var4 = new SearchCondition(PlanActivity.class, "showInTimeline", "TRUE");
        var2.appendWhere(var4, new int[]{0});
        ClassAttribute var5 = new ClassAttribute(PlanActivity.class, "lineNumber");
        var2.appendOrderBy(new OrderBy(var5, false), new int[]{0});
        WTArrayList var6 = new WTArrayList();
        var6.addAll(PersistenceServerHelper.manager.query(var2));
        return var6;
    }

    public WTCollection getWTUserOwnedDeliverables(WTContainer var1, WTUser var2) throws WTException {
        QuerySpec var3 = new QuerySpec();
        int var4 = var3.appendClassList(PlanDeliverable.class, true);
        SearchCondition var5 = new SearchCondition(PlanDeliverable.class, "containerReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var3.appendWhere(var5, new int[]{0});
        if (var2 != null) {
            var3.appendAnd();
            var3.appendWhere(OwnershipHelper.getSearchCondition(PlanDeliverable.class, var2, true), new int[]{0});
        }

        ClassAttribute var6 = new ClassAttribute(PlanDeliverable.class, "name");
        var3.appendOrderBy(new OrderBy(var6, false), new int[]{var4});
        QueryResult var7 = PersistenceHelper.manager.find(var3);
        return new WTArrayList(var7);
    }

    public WTCollection changeOwnershipOfDeliverables(WTContainer var1, WTUser var2, WTUser var3) throws WTException {
        WTCollection var4 = this.getWTUserOwnedDeliverables(var1, var3);
        if (var2 != null) {
            OwnershipServerHelper.service.changeOwnership(var4, var2, true);
            Iterator var5 = var4.persistableIterator();

            while (var5.hasNext()) {
                PlanDeliverable var6 = (PlanDeliverable) var5.next();
                PlanHelper.service.dispatchEvent("EPP_OWNER_CHANGE", var6);
            }
        }

        return var4;
    }

    public PlanDeliverable changeDeliverableParent(Plannable var1) throws WTException {
        PlanDeliverable var2 = null;
        if (var1 != null) {
            var2 = this.getDeliverable(var1);

            try {
                if (var2 != null) {
                    var2.setParent((Hierarchical) var1.getRoot());
                    var2 = (PlanDeliverable) PersistenceHelper.manager.save(var2);
                }
            } catch (WTPropertyVetoException var4) {
                var4.printStackTrace();
            }
        }

        return var2;
    }

    public QueryResult getDeliverables(Persistable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        var2.appendClassList(PlanDeliverable.class, true);
        SearchCondition var3 = new SearchCondition(PlanDeliverable.class, "subject.key.branchId", "=", ((Iterated) var1).getBranchIdentifier());
        var2.appendWhere(var3, new int[]{0});
        QueryResult var4 = PersistenceServerHelper.manager.query(var2);
        return var4;
    }

    private List<Integer> getLineNumbersOfAllChildren(Plannable var1) throws WTException {
        ArrayList var2 = new ArrayList();
        if (var1.isSummary()) {
            WTCollection var3 = this.getAllChildren(var1);
            Iterator var4 = var3.persistableIterator();

            while (var4.hasNext()) {
                Plannable var5 = (Plannable) var4.next();
                var2.add(var5.getLineNumber());
            }
        }

        return var2;
    }

    public Plannable calculateSummaryFlag(Plannable var1) throws WTException {
        var1 = (Plannable) PersistenceHelper.manager.refresh(var1);
        WTCollection var2 = this.getImmediateChildren(var1);

        try {
            var1.setSummary(var2.size() > 0);
        } catch (WTPropertyVetoException var8) {
            throw new WTException(var8);
        }

        boolean var3 = SessionServerHelper.manager.setAccessEnforced(false);

        try {
            var1 = (Plannable) PersistenceHelper.manager.save(var1);
        } finally {
            SessionServerHelper.manager.setAccessEnforced(var3);
        }

        return var1;
    }

    protected int getMaxLineNumber(Plannable var1) throws WTException {
        int var2 = 0;
        QuerySpec var3 = new QuerySpec();
        var3.setAdvancedQueryEnabled(true);
        int var4 = var3.appendClassList(Plannable.class, false);
        ClassAttribute var5 = new ClassAttribute(Plannable.class, "lineNumber");
        var3.appendSelect(SQLFunction.newSQLFunction("MAX", var5), new int[]{var4}, false);
        var3.appendWhere(new SearchCondition(Plannable.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1)), new int[]{var4});
        QueryResult var6 = PersistenceServerHelper.manager.query(var3);

        while (var6.hasMoreElements()) {
            Object[] var7 = (Object[]) ((Object[]) var6.nextElement());
            if (var7[0] != null) {
                BigDecimal var8 = (BigDecimal) var7[0];
                if (var8.intValue() > var2) {
                    var2 = var8.intValue();
                }
            }
        }

        return var2;
    }

    protected QuerySpec getAllPlannables(Plannable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        var2.appendClassList(Plannable.class, true);
        SearchCondition var3 = new SearchCondition(Plannable.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        ClassAttribute var4 = new ClassAttribute(Plannable.class, "lineNumber");
        var2.appendWhere(var3, new int[]{0});
        var2.appendOrderBy(new OrderBy(var4, false), new int[]{0});
        return var2;
    }

    public WTArrayList getAllActivitiesWithDummyPrecConstraints(Plan var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        var2.appendClassList(PlanActivity.class, true);
        SearchCondition var3 = new SearchCondition(Plannable.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        ClassAttribute var4 = new ClassAttribute(Plannable.class, "lineNumber");
        var2.appendWhere(var3, new int[]{0});
        SearchCondition var5 = new SearchCondition(PlanActivity.class, "constraintType", "=", DateConstraint.SNET);
        var2.appendAnd();
        var2.appendWhere(var5, new int[]{0});
        var2.appendOrderBy(new OrderBy(var4, false), new int[]{0});
        QueryResult var6 = PersistenceHelper.manager.find(var2);
        WTArrayList var7 = new WTArrayList();
        var7.addAll(var6);
        return var7;
    }

    public void reorderAndStorePlannableLineNumbers(WTCollection var1, int var2) throws WTException, WTPropertyVetoException {
        Iterator var3 = var1.persistableIterator();

        while (var3.hasNext()) {
            Plannable var4 = (Plannable) var3.next();

            try {
                var4.setLineNumber(var2);
                ++var2;
            } catch (WTPropertyVetoException var6) {
                throw new WTException(var6);
            }
        }

        PersistenceHelper.manager.save(var1);
    }

    public int getLowerLineNumber(ArrayList<Integer> var1) {
        int var2;
        if (var1.isEmpty()) {
            var2 = -1;
        } else {
            Collections.sort(var1);
            var2 = (Integer) var1.get(0);
        }

        return var2;
    }

    public int getLowerLineNumber(ArrayList<Integer> var1, int var2) {
        int var3 = this.getLowerLineNumber(var1);
        return var3 < var2 ? var3 : var2;
    }

    public int getHigherLineNumber(ArrayList<Integer> var1, int var2) {
        if (var1.isEmpty()) {
            return var2;
        } else {
            Collections.sort(var1);
            int var3 = (Integer) var1.get(var1.size() - 1);
            return var3 > var2 ? var3 : var2;
        }
    }

    private void rollUpEffortFromChildrenList(WTCollection var1) throws WTException {
        Iterator var2 = var1.persistableIterator();

        while (var2.hasNext()) {
            Plannable var3 = (Plannable) var2.next();
            if (((WorkTrackable) var3).getTotalEffort() != null) {
                var3 = (Plannable) PersistenceHelper.manager.refresh(var3);
                var3 = (Plannable) AssignmentHelper.service.rollUpEffort((WorkTrackable) var3);
            }
        }

    }

    public static void rollUpCostFromChildrenList(WTCollection var0) throws WTException {
        Iterator var1 = var0.persistableIterator();

        while (var1.hasNext()) {
            Plannable var2 = (Plannable) var1.next();
            if (var2 instanceof Plannable) {
                CostHelper.service.rollUpCost((CostTrackable) var2);
            }
        }

    }

    public void updateSummaryFlags(Plannable var1) throws WTException, WTPropertyVetoException {
        WTCollection var2 = this.getSummaryActivities(var1, true);

        Plannable var4;
        for (Iterator var3 = var2.persistableIterator(); var3.hasNext(); var4 = (Plannable) PersistenceHelper.manager.save(var4)) {
            var4 = (Plannable) var3.next();
            var4.setSummary(false);
            if (!var4.isSummary()) {
                Duration var5 = Duration.newDuration();
                var5.setDurationFormat(DurationFormat.HOURS);
                ((WorkTrackable) var4).setTotalEffort(var5);
            }
        }

    }

    public void resetPlanDetails(Plan var1) throws WTException, WTPropertyVetoException {
        if (var1 != null) {
            Duration var2 = Duration.newDuration();
            var1.setFinishDate(var1.getStartDate());
            var1.setDuration(var2);
            var1.setTotalEffort(var2);
            var1.setDoneEffort(var2);
            var1.setRemainingEffort(var2);
            var1.setHealthStatusType(HealthStatusType.getHealthStatusTypeDefault());
            var1.setHealthStatusDescription("");
            var1.setTotalCost(var1.getFixedCost());
            var1.setPercentWorkComplete(0.0D);
            PersistenceHelper.manager.save(var1);
        }

    }

    public AdminDomainRef getAdministrativeDomainRef(WTContainerRef var1) throws WTException {
        return AdminUtils.getAdministrativeDomainRef(var1);
    }

    private ObjectIdentifier getOid(Object var1) {
        return var1 == null ? null : PersistenceHelper.getObjectIdentifier((Persistable) var1);
    }

    private SearchCondition getSCAssignedToPrincipal(Boolean var1, WTPrincipal var2, Class var3) throws WTException {
        boolean var4 = false;
        if (var1) {
            var4 = true;
        }

        SearchCondition var5 = OwnershipHelper.getSearchCondition(var3, var2, var4);
        return var5;
    }

    private SearchCondition getSCForisDiscussed(Boolean var1, Class var2) throws WTException {
        return ForumUtil.getSCForIsDiscussed(var1, var2);
    }

    public static void throwActivityEvents(HashMap<String, PlanActivity> var0, WTCollection var1) throws WTException, WTPropertyVetoException {
        if (var1 != null && var0 != null) {
            WTArrayList var2 = new WTArrayList();
            WTArrayList var3 = new WTArrayList();
            WTArrayList var4 = new WTArrayList();
            WTArrayList var5 = new WTArrayList();
            WTArrayList var6 = new WTArrayList();
            WTArrayList var7 = new WTArrayList();
            WTArrayList var8 = new WTArrayList();
            Iterator var9 = var1.persistableIterator();

            while (true) {
                PlanActivity var10;
                PlanActivity var12;
                do {
                    String var11;
                    do {
                        if (!var9.hasNext()) {
                            MethodContext var15 = MethodContext.getContext();
                            if (var15 != null) {
                                HashMap var16 = var15.get("ProcessedEvent") != null ? (HashMap) var15.get("ProcessedEvent") : new HashMap();
                                if (!var2.isEmpty()) {
                                    var16.put("EPP_PERCENT_CHANGE", var2);
                                    PlanHelper.service.dispatchMultiEvent("EPP_PERCENT_CHANGE", var2);
                                    var15.put("ProcessedEvent", var16);
                                }

                                if (!var3.isEmpty()) {
                                    var16.put("EPP_FINISH_CHANGE", var3);
                                    PlanHelper.service.dispatchMultiEvent("EPP_FINISH_CHANGE", var3);
                                    var15.put("ProcessedEvent", var16);
                                }

                                if (!var4.isEmpty()) {
                                    var16.put("EPP_RISK_CHANGE", var4);
                                    PlanHelper.service.dispatchMultiEvent("EPP_RISK_CHANGE", var4);
                                    var15.put("ProcessedEvent", var16);
                                }

                                if (!var5.isEmpty()) {
                                    var16.put("EPP_STATUS_CHANGE", var5);
                                    PlanHelper.service.dispatchMultiEvent("EPP_STATUS_CHANGE", var5);
                                    var15.put("ProcessedEvent", var16);
                                }

                                if (!var6.isEmpty()) {
                                    var16.put("EPP_OWNER_CHANGE", var6);
                                    PlanHelper.service.dispatchMultiEvent("EPP_OWNER_CHANGE", var6);
                                    var15.put("ProcessedEvent", var16);
                                }

                                if (!var7.isEmpty()) {
                                    var16.put("EPP_DEADLINE_CHANGE", var7);
                                    PlanHelper.service.dispatchMultiEvent("EPP_DEADLINE_CHANGE", var7);
                                    var15.put("ProcessedEvent", var16);
                                }

                                if (!var8.isEmpty()) {
                                    var16.put("PLANACTIVITY_STATE_CHANGE", var8);
                                    PlanHelper.service.dispatchMultiEvent("PLANACTIVITY_STATE_CHANGE", var8);
                                    var15.put("ProcessedEvent", var16);
                                    return;
                                }
                            }

                            return;
                        }

                        var10 = (PlanActivity) var9.next();
                        var11 = PersistenceHelper.getObjectIdentifier(var10).getStringValue();
                    } while (!var0.containsKey(var11));

                    var12 = (PlanActivity) var0.get(var11);
                    if (var12.getPercentWorkComplete() != var10.getPercentWorkComplete()) {
                        var2.add(var10);
                    }

                    if (var12.getFinishDate() == null && var10.getFinishDate() != null || var12.getFinishDate() != null && !var12.getFinishDate().equals(var10.getFinishDate())) {
                        var3.add(var10);
                    }

                    RiskType var13 = var10.getRiskType();
                    if (var13 == null) {
                        var13 = RiskType.getRiskTypeDefault();
                    }

                    if (!var13.equals(var12.getRiskType())) {
                        var4.add(var10);
                    }

                    HealthStatusType var14 = var10.getHealthStatusType();
                    if (var14 == null) {
                        var14 = HealthStatusType.getHealthStatusTypeDefault();
                    }

                    if (!var14.equals(var12.getHealthStatusType())) {
                        var5.add(var10);
                    }

                    if (var12.getOwnership() == null && var10.getOwnership() != null || var12.getOwnership() != null && var10.getOwnership() == null || var12.getOwnership() != null && var10.getOwnership() != null && !var12.getOwnership().getOwner().equals(var10.getOwnership().getOwner())) {
                        var6.add(var10);
                    }

                    if (var12.getDeadline() == null && var10.getDeadline() != null || var12.getDeadline() != null && !var12.getDeadline().equals(var10.getDeadline())) {
                        var7.add(var10);
                    }
                } while ((var12.getPlannableState() != null || var10.getPlannableState() == null) && (var12.getPlannableState() == null || var12.getPlannableState().equals(var10.getPlannableState())));

                var8.add(var10);
            }
        }
    }

    public Plannable rollUpPlannableState(Plannable var1) throws WTException {
        Plannable var2 = var1.getParentPlannable();
        if (var2 instanceof PlanActivity) {
            this.setPlannableState(var1, var2);
            if (!(var2.getParentPlannable() instanceof Plan)) {
                this.rollUpPlannableState(var2);
            } else {
                this.setPlannableState(var2, var2.getParentPlannable());
            }
        } else if (var2 instanceof Plan) {
            this.setPlannableState(var1, var2);
        } else if (var2 == null && var1 instanceof Plan) {
            this.rollupStateFromChildren(var1, var1);
        }

        return var1;
    }

    private void setPlannableState(Plannable var1, Plannable var2) throws WTException {
        try {
            if (PlannableState.INPROCESS.equals(var1.getPlannableState()) && !PlannableState.INPROCESS.equals(var2.getPlannableState())) {
                if (PlannableState.SCHEDULED.equals(var2.getPlannableState())) {
                    PlanHelper.service.dispatchEvent("PLANACTIVITY_STATE_CHANGE", var2);
                    if (var2 instanceof PlanActivity && PlannableUtils.isRefreshRequiredAfterDispatchEvent((PlanActivity) var2)) {
                        var2 = (Plannable) PersistenceHelper.manager.refresh(var2);
                    }
                }

                var2.setPlannableState(PlannableState.INPROCESS);
                var2.setActualStartDate(var2.getStartDate());
                var2 = (Plannable) PersistenceHelper.manager.save(var2);
            } else if (PlannableState.COMPLETED.equals(var1.getPlannableState())) {
                this.rollupStateFromChildren(var1, var2);
            }

        } catch (WTPropertyVetoException var4) {
            throw new WTException(var4);
        }
    }

    /**
     * @deprecated
     */
    @Deprecated
    public void rollupStateFromChildren(Plannable var1, Plannable var2) throws WTException {
        boolean var3 = true;
        Timestamp var4 = null;

        try {
            WTCollection var5 = this.getImmediateChildren(var2);
            var2 = (Plannable) PersistenceHelper.manager.refresh(var2);
            if (var5 != null && var5.size() >= 1) {
                Iterator var6 = var5.persistableIterator();

                label57:
                while (true) {
                    while (true) {
                        if (!var6.hasNext() || !var3) {
                            break label57;
                        }

                        Plannable var7 = (Plannable) var6.next();
                        if (!PlannableState.COMPLETED.equals(var7.getPlannableState())) {
                            var3 = false;
                        } else {
                            Timestamp var8 = var7.getActualFinishDate();
                            if (var4 == null || var8 != null && var8.after(var4)) {
                                var4 = var8;
                            }
                        }
                    }
                }
            }

            Timestamp var12;
            if (var3) {
                var2.setPlannableState(PlannableState.COMPLETED);
                if (var4 != null) {
                    logger.debug("Set rolled up finish date and adjust Duration.");
                    var2.setFinishDate(var4);
                    var12 = var2.getActualStartDate();
                    if (!var4.before(var12)) {
                        WorkingCalendarConfig var13 = new WorkingCalendarConfig(var2);
                        long var14 = ScheduleUtils.calculateWorkingDuration(var12, var4, TimeZoneHelper.getTimeZone(), var13);
                        Duration var10 = var2.getDuration();
                        if (var10 != null) {
                            var10.setMillis(var14);
                        }
                    }
                }

                var2.setActualFinishDate(var2.getFinishDate());
                var2 = (Plannable) PersistenceHelper.manager.save(var2);
            } else if (PlannableState.INPROCESS != var2.getPlannableState()) {
                if (PlannableState.SCHEDULED == var2.getPlannableState()) {
                    var12 = ProcessorUtils.getAdjustedCurrentTime((Plan) var1.getRoot(), new Date());
                    var2.setActualStartDate(var12);
                    var2.setStartDate(var12);
                } else {
                    var2.setActualFinishDate((Timestamp) null);
                }

                var2.setPlannableState(PlannableState.INPROCESS);
                var2 = (Plannable) PersistenceHelper.manager.save(var2);
            }

        } catch (WTPropertyVetoException var11) {
            logger.debug("Error while rolling up the state for the parent " + var2.getName() + "  Exception  == " + var11.getMessage());
            var11.printStackTrace();
            throw new WTException(var11);
        }
    }

    public Rootable schedulePlannables(Rootable var1) throws WTException {
        SessionContext var2 = SessionContext.newContext();
        SessionHelper.manager.setAdministrator();

        try {
            if (var1 != null) {
                String var3 = PersistenceHelper.getObjectIdentifier(var1).toString();
                Enumeration var4 = this.getSchedItemsWithItemName(var3);
                ArrayList var5 = Collections.list(var4);
                Iterator var6 = var5.iterator();
                HashMap var7 = new HashMap();

                ScheduleItem var8;
                for (var8 = null; var6.hasNext(); var7.put(var8.getItemName(), var8)) {
                    Object var9 = var6.next();
                    if (var9 instanceof ScheduleItem) {
                        var8 = (ScheduleItem) var9;
                    } else {
                        var8 = (ScheduleItem) ((Object[]) ((Object[]) var9))[0];
                    }
                }

                WTCollection var26 = getNextImmediateActivitiesToStart((Plannable) var1);
                Timestamp var10 = ProcessorUtils.getAdjustedCurrentTime((Plan) var1, new Date());
                Iterator var11 = var26.persistableIterator();

                while (true) {
                    while (true) {
                        Plannable var12;
                        String var14;
                        boolean var15;
                        while (true) {
                            String var13;
                            do {
                                do {
                                    do {
                                        do {
                                            if (!var11.hasNext()) {
                                                return var1;
                                            }

                                            var12 = (Plannable) var11.next();
                                            var13 = null;
                                            if (var12 instanceof PlanActivity) {
                                                var13 = PersistenceHelper.getObjectIdentifier(var12).toString();
                                            }
                                        } while (var13 == null);
                                    } while ("".equals(var3));
                                } while (!PlannableState.SCHEDULED.equals(var12.getPlannableState()));
                            } while (var10.after(var12.getStartDate()));

                            var14 = var3 + var13;
                            var15 = false;
                            if (var7.containsKey(var14)) {
                                var8 = (ScheduleItem) var7.get(var14);
                                if (var12.getStartDate() != null && var12.getStartDate().equals(var8.getNextTime())) {
                                    continue;
                                }

                                var15 = true;
                                break;
                            }

                            var8 = new ScheduleItem();
                            break;
                        }

                        var8.setItemName(var14);
                        var8.setQueueName("EPPQueue");
                        var8.setNextTime(var12.getStartDate());
                        var8.setStartDate(var12.getStartDate());
                        var8.setPeriodicity(1L);
                        var8.setToBeRun(1L);
                        var8.setDomainRef(((PlanActivity) var12).getDomainRef());
                        var8.setMethod("com.ptc.projectmanagement.plannable.StandardPlannableService", "handleSchedulingEvent");
                        ScheduleMethodArg[] var16 = new ScheduleMethodArg[1];
                        PersistantArg var17 = PersistantArg.newPersistantArg();
                        ObjectReference var18 = ObjectReference.newObjectReference((PlanActivity) var12);
                        var17.setSequenceNumber(0);
                        var17.setArgRef(var18);
                        var16[0] = var17;
                        if (var15) {
                            var8 = SchedulingHelper.service.modifyItem(var8);
                        } else {
                            try {
                                SchedulingHelper.service.addItem(var8, var16);
                            } catch (Exception var24) {
                                if (var24.getCause() instanceof WTPropertyVetoException) {
                                    if (logger.isDebugEnabled()) {
                                        logger.debug("StandardPlannableService.SchedulePlannables:- WTPropertyVetoException occurred while adding schedule item, since the nexttime set for the schedule item is few seconds far away from system current time. So adding 29000 miliseconds to the nexttime of schedule item and invoking addItem again.");
                                    }

                                    Timestamp var20 = new Timestamp(var8.getStartDate().getTime() + 29000L);
                                    var8.setNextTime(var20);
                                    SchedulingHelper.service.addItem(var8, var16);
                                }
                            }
                        }
                    }
                }
            }
        } finally {
            SessionContext.setContext(var2);
        }

        return var1;
    }

    public Rootable schedulePlannablesDeadLine(Rootable var1, PlanActivity var2) throws WTException {
        return this.schedulePlannablesDeadLine(var1, var2, false);
    }

    private Rootable schedulePlannablesDeadLine(Rootable var1, PlanActivity var2, boolean var3) throws WTException {
        logger.trace("StandardPlannableService.schedulePlannablesDeadLine ::: Creating the scheduleItem for object " + var2);
        SessionContext var4 = SessionContext.newContext();
        MethodContext var5 = MethodContext.getContext();
        SessionHelper.manager.setAdministrator();
        WTPrincipal var6 = SessionHelper.manager.getAdministrator();
        ScheduleQueueEntry var7 = null;
        boolean var8 = false;

        try {
            if (var1 == null) {
                var1 = var2.getRoot();
            }

            if (var1 != null) {
                ObjectIdentifier var9 = PersistenceHelper.getObjectIdentifier(var2);
                String var10 = PersistenceHelper.getObjectIdentifier(var1).toString();
                String var11 = var9.toString();
                String var12 = var10 + ":" + var11;
                Boolean var13 = (Boolean) var5.get("SKIP_UPDATE_OBJECTS_FROM_IMPORT");
                if (var13 != null) {
                    var3 = var13;
                }

                if (!var3) {
                    this.removeSchedItemsWithItemName(var12);
                }

                logger.trace("Removing the scheduleItem with id :::" + var12);
                if (var11 != null && !"".equals(var10) && var2.getDeadline() != null && !var2.getDeadline().before(new Date())) {
                    ScheduleQueue var14 = this.getQueueAfterBypassingAccessControl();
                    if (!var3) {
                        var7 = this.isEntryExistsInQueue(var14, var12);
                    }

                    Class[] var15 = new Class[]{ObjectIdentifier.class, String.class};
                    Object[] var16 = new Object[]{var9, var12};
                    Timestamp var17 = new Timestamp(var2.getDeadline().getTime());
                    if (var7 != null) {
                        this.updateScheduleQueueEntry(var14, var7, var17, var15, var16);
                        var8 = true;
                    }

                    if (!var8) {
                        this.addQueueEntryCollection(var6, "handleDeadLineSchedulingEvent", CLASSNAME, var15, var16, var17, var14, var3);
                    }
                }
            }
        } finally {
            SessionContext.setContext(var4);
        }

        return var1;
    }

    public static void handleDeadLineSchedulingEvent(ObjectIdentifier var0, String var1) throws WTException {
        NmOid var2 = NmOid.newNmOid(var0);
        PlanActivity var3 = new PlanActivity();
        if (var2 != null) {
            Object var4 = var2.getRefObject();
            if (var4 instanceof PlanActivity) {
                var3 = (PlanActivity) var4;
            }
        }

        sendDeadlineNotification(var3, false);
    }

    public static void handleSchedulingEvent(PlanActivity var0) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("handleSchedulingEvent() ::: IN ");
        }

        try {
            if (logger.isDebugEnabled()) {
                logger.debug("Checking if it can be started... :" + var0);
            }

            Plan var2 = (Plan) var0.getRoot();
            if (var2 == null || !var2.isInProcess()) {
                logger.debug("Plan is not in INPROCESS state. Plan state is " + var2.getPlannableState());
                return;
            }

            ProcessorUtils var3 = new ProcessorUtils(var2);
            String var4 = PersistenceHelper.getObjectIdentifier(var2).toString();
            var3.resetPredecessorsMap();
            Timestamp var5 = ProcessorUtils.getAdjustedCurrentTime((Plan) var0.getRoot(), new Date());
            WTCollection var6 = getEligibleActivitiesToStart(var2);
            if (!var6.contains(var0)) {
                var6.add(var0);
            }

            Iterator var7 = var6.persistableIterator();

            while (true) {
                if (!var7.hasNext()) {
                    var2 = (Plan) PlannableHelper.service.schedulePlannables(var2);
                    break;
                }

                Object var1 = (Plannable) var7.next();
                Plannable var8 = (Plannable) ((Plannable) var1).getParent();
                Timestamp var9 = var8.getStartDate();
                if (var0.isScheduled()) {
                    boolean var10 = var3.isActivityReadyToStart(var0);
                    if (!var5.before(((Plannable) var1).getStartDate()) && (PlannableState.INPROCESS.equals(var8.getPlannableState()) || !var9.after(var5) && var10)) {
                        if (((Plannable) var1).isSummary()) {
                            logger.debug("plannable is Summary activity");
                            boolean var11 = true;
                            WTCollection var12 = PlannableHelper.service.getImmediateChildren((Plannable) var1, true);
                            if (var12 != null && var12.size() >= 1) {
                                var11 = false;
                                Iterator var13 = var12.persistableIterator();

                                while (var13.hasNext() && !var11) {
                                    PlanActivity var14 = (PlanActivity) var13.next();
                                    if (var3.isActivityReadyToStart(var14)) {
                                        var11 = true;
                                        var1 = var3.startActivityAndAssignments(var14);
                                        PlanHelper.service.dispatchEvent("PLANACTIVITY_STATE_CHANGE", var14);
                                        if (PlannableUtils.isRefreshRequiredAfterDispatchEvent(var14)) {
                                            var14 = (PlanActivity) PersistenceHelper.manager.refresh(var14);
                                        }

                                        PlannableHelper.service.rollUpPlannableState(var14);
                                    }
                                }
                            }

                            if (!var11) {
                                logger.debug("isStarted == " + var11);
                                continue;
                            }
                        }

                        if (PlannableState.SCHEDULED.equals(((Plannable) var1).getPlannableState()) && ProcessorUtils.isPlannableReadyToStart((Plannable) var1, true)) {
                            ((Plannable) var1).setPlannableState(PlannableState.INPROCESS);
                            ((Plannable) var1).setActualStartDate(var5);
                            Timestamp var18 = ((Plannable) var1).getStartDate();
                            if (var5.after(var18)) {
                                logger.debug("The activity : " + ((Plannable) var1).getName() + " is getting started at : " + var5 + " which is after its scheduled time : " + var18);
                                logger.debug("This change would need rescheduling of its successors. Hence, invoke the 'Reschedule Plan' action to reschedule the plan : " + var2.getName());
                                ((Plannable) var1).setStartDate(var5);
                                if (var0.isMFO()) {
                                    Duration var19 = Duration.newDuration();
                                    WorkingCalendarConfig var21 = new WorkingCalendarConfig(var0);
                                    var19.setMillis(ScheduleUtils.calculateWorkingDuration(var0.getStartDate(), var0.getFinishDate(), TimeZoneHelper.getTimeZone(), var21, var0.getName()));
                                    var0.setDuration(var19);
                                    logger.debug("Start Date updated, So Setting Duration accordingly");
                                } else {
                                    Timestamp var20 = ScheduleUtils.addWorkingDuration(((Plannable) var1).getStartDate(), ((Plannable) var1).getDuration().getMillis());
                                    ((Plannable) var1).setFinishDate(var20);
                                }
                            }

                            Plannable var16 = (Plannable) PersistenceHelper.manager.save((Persistable) var1);
                            var16 = PlannableHelper.service.rollUpPlannableState(var16);
                            PlanHelper.service.dispatchEvent("PLANACTIVITY_STATE_CHANGE", var16);
                            if (var16 instanceof PlanActivity && PlannableUtils.isRefreshRequiredAfterDispatchEvent((PlanActivity) var16)) {
                                PlanActivity var17 = (PlanActivity) PersistenceHelper.manager.refresh(var16);
                            }
                        }
                    } else {
                        logger.debug("Parent '" + var8.getName() + "' may not be in INPROCESS state. Parent state is " + var8.getPlannableState());
                        logger.debug("parentStart:- " + var9 + ", currentTime:- " + var5);
                        logger.debug("is activity '" + var0.getName() + "' ready to start :- " + var10);
                    }
                }
            }
        } catch (WTPropertyVetoException var15) {
            var15.printStackTrace();
            throw new WTException(var15);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("handleSchedulingEvent() ::: OUT ");
        }

    }

    public WTCollection getAllPlannables(Plannable var1, PlannableState var2) throws WTException {
        return this.getAllPlannables(var1, var2, false);
    }

    public WTCollection getAllPlannables(Plannable var1, PlannableState var2, boolean var3) throws WTException {
        QuerySpec var4 = new QuerySpec();
        var4.appendClassList(Plannable.class, true);
        SearchCondition var5 = new SearchCondition(Plannable.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var4.appendWhere(var5, new int[]{0});
        var4.appendAnd();
        SearchCondition var6 = new SearchCondition(Plannable.class, "plannableState", "=", var2);
        var4.appendWhere(var6, new int[]{0});
        ClassAttribute var7 = new ClassAttribute(Plannable.class, "lineNumber");
        var4.appendOrderBy(new OrderBy(var7, var3), new int[]{0});
        QueryResult var8 = PersistenceHelper.manager.find(var4);
        WTArrayList var9 = new WTArrayList();
        var9.addAll(var8);
        return var9;
    }

    public void removeSchedItemsWithItemName(String var1) throws WTException {
        SessionContext var2 = SessionContext.newContext();
        SessionHelper.manager.setAdministrator();

        ScheduleItem var5;
        try {
            for (Enumeration var3 = this.getSchedItemsWithItemName(var1); var3.hasMoreElements(); SchedulingHelper.service.removeItem(var5)) {
                Object var4 = var3.nextElement();
                var5 = null;
                if (var4 instanceof ScheduleItem) {
                    var5 = (ScheduleItem) var4;
                } else {
                    var5 = (ScheduleItem) ((Object[]) ((Object[]) var4))[0];
                }
            }
        } finally {
            SessionContext.setContext(var2);
        }

    }

    public Enumeration getSchedItemsWithItemName(String var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        var2.appendClassList(ScheduleItem.class, true);
        SearchCondition var3 = new SearchCondition(ScheduleItem.class, "itemName", "LIKE", var1 + "%");
        var2.appendWhere(var3, new int[]{0});
        Enumeration var4 = SchedulingHelper.service.getScheduleItems(var2);
        return var4;
    }

    private static void sendNotification(Plannable var0) throws WTException {
        PlanActivity var1 = (PlanActivity) var0;
        WTPrincipal var2 = var1.getOwnership().getOwner().getPrincipal();
        WTDistributionList var3 = new WTDistributionList();
        var3.addPrincipal(var2);
        TemplateEmailNotification var4 = new TemplateEmailNotification(var3);
        ProjectManagementNotificationProcessor var5 = new ProjectManagementNotificationProcessor();
        var5.setContextObj(var1);
        var4.setTemplateProcessor(var5);
        var4.setSubjectResource("com.ptc.projectmanagement.plan.planResource");
        Plan var6 = (Plan) var1.getRoot();
        boolean var7 = false;
        if ((!var6.isAutoExecution() || !var1.isScheduled()) && !var1.isInProcess()) {
            if (var1.isSuspended()) {
                var4.setSubjectMessageKey("ACTIVITY_NOTIFICATION_STATE_SUSPENDED");
                var7 = true;
            }
        } else {
            var4.setSubjectMessageKey("ACTIVITY_NOTIFICATION_STATE_STARTED");
            var7 = true;
        }

        if (var7) {
            var4.setTemplate(TemplateName.getWindchill("plan/planActivityNotification"));
            Object[] var8 = new Object[]{var1.getContainerName(), var1.getName() == null ? " " : var1.getName()};
            var4.setSubjectInserts(var8);
            var4.setSender(NOTIFICATION_SENDER);
            NotificationHelper.manager.send(var4);
            if (logger.isTraceEnabled()) {
                logger.trace("   StandardPlannableService: sendNotification mthd ");
            }

        }
    }

    private static void sendDeadlineNotification(Plannable var0, boolean var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.trace(CLASSNAME + ".sendDeadlineNotification() : IN ");
        }

        PlanActivity var2 = (PlanActivity) var0;
        if (var2.getPercentWorkComplete() != 100.0D && shouldNotify(var2)) {
            if (logger.isDebugEnabled()) {
                logger.trace(" Sending Missed Deadline Notification...");
            }

            PlanHelper.service.dispatchEvent("EPP_MISSED_DEADLINE", var2);
            if (var2.getOwnership() != null && var2.getOwnership().getOwner() != null && var2.getOwnership().getOwner().getPrincipal() != null) {
                WTPrincipal var3 = var2.getOwnership().getOwner().getPrincipal();
                WTDistributionList var4 = new WTDistributionList();
                var4.addPrincipal(var3);
                TemplateEmailNotification var5 = new TemplateEmailNotification(var4);
                ProjectManagementNotificationProcessor var6 = new ProjectManagementNotificationProcessor();
                var6.setContextObj(var2);
                var5.setTemplateProcessor(var6);
                var5.setSubjectResource("com.ptc.projectmanagement.plan.planResource");
                String var7 = "DEADLINE_PASSED";
                if (var1) {
                    var7 = "DEADLINE_APPROACHING";
                }

                var5.setSubjectMessageKey(var7);
                var5.setTemplate(TemplateName.getWindchill("plan/EPPdeadlineNotification"));
                Object[] var8 = new Object[]{var2.getContainerName(), var2.getName()};
                var5.setSubjectInserts(var8);
                var5.setSender(NOTIFICATION_SENDER);
                NotificationHelper.manager.send(var5);
            }

            if (logger.isDebugEnabled()) {
                logger.trace(CLASSNAME + ".sendDeadlineNotification() : OUT ");
            }
        }

    }

    public PlanActivity getDummyMilestoneForPlan(Plan var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.trace(CLASSNAME + ".getDummyMilestoneForPlan() : IN ");
        }

        PlanActivity var2 = (PlanActivity) this.getPlannableByLineNumber(var1, 0, false);
        if (var2 == null) {
            try {
                var2 = PlannableHelper.service.createDummyMilestone(var1);
            } catch (WTPropertyVetoException var4) {
                new WTException(var4);
            }
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Dummy Milestone =  " + var2);
        }

        if (logger.isDebugEnabled()) {
            logger.debug(CLASSNAME + ".getDummyMilestoneForPlan() : OUT ");
        }

        return var2;
    }

    public PrecedenceConstraint getDummyPrecedenceConstraintForActivity(PlanActivity var1) throws WTException {
        PlanActivity var2 = this.getDummyMilestoneForPlan((Plan) var1.getRoot());
        return this.getPrecedenceConstraintBetweenActivities(var1, var2);
    }

    public PrecedenceConstraint createDummyPrecedenceConstraintForActivity(PlanActivity var1, PlanActivity var2, long var3) throws WTException, WTPropertyVetoException {
        return this.createDummyPrecedenceConstraintForActivity(var1, var2, var3, true);
    }

    public PrecedenceConstraint createDummyPrecedenceConstraintForActivity(PlanActivity var1, PlanActivity var2, long var3, boolean var5) throws WTException, WTPropertyVetoException {
        PrecedenceConstraint var6 = PrecedenceConstraint.newPrecedenceConstraint(var1, var2);
        var6.setPrecedenceType(PrecedenceType.SS);
        Duration var7 = new Duration();
        var7.setMillis(var3);
        var7.setDurationFormat(DurationFormat.MINUTES);
        var6.setScheduleOffset(var7);
        if (var5) {
            var6 = (PrecedenceConstraint) PersistenceHelper.manager.save(var6);
        }

        return var6;
    }

    public Rootable schedulePlannablesDeadLineAfter(Rootable var1, PlanActivity var2) throws WTException {
        return this.schedulePlannablesDeadLineAfterOrBefore(var1, var2, true);
    }

    public Rootable schedulePlannablesDeadLineBefore(Rootable var1, PlanActivity var2) throws WTException {
        return this.schedulePlannablesDeadLineAfterOrBefore(var1, var2, false);
    }

    private Rootable schedulePlannablesDeadLineAfterOrBefore(Rootable var1, PlanActivity var2, boolean var3) throws WTException {
        return this.schedulePlannablesDeadLineAfterOrBefore(var1, var2, var3, false);
    }

    private Rootable schedulePlannablesDeadLineAfterOrBefore(Rootable var1, PlanActivity var2, boolean var3, boolean var4) throws WTException {
        ScheduleQueueEntry var5 = null;
        WTPrincipal var6 = SessionHelper.manager.getAdministrator();
        WTPrincipal var7 = SessionContext.setEffectivePrincipal(var6);
        long var8 = 86400000L;
        MethodContext var10 = MethodContext.getContext();
        boolean var11 = false;
        String var12 = PersistenceHelper.getObjectIdentifier(var1) + ":" + PersistenceHelper.getObjectIdentifier(var2) + ":";

        try {
            if (var2 != null && var2.getDeadline() != null) {
                ScheduleQueue var13 = this.getQueueAfterBypassingAccessControl();
                Timestamp var14 = var2.getDeadline();
                long var15 = 0L;
                if (var3) {
                    var15 = (long) var2.getAfterDeadline() * var8;
                    var12 = var12 + "After";
                } else {
                    var15 = (long) (-1 * var2.getBeforeDeadline()) * var8;
                    var12 = var12 + "Before";
                }

                Boolean var17 = (Boolean) var10.get("SKIP_UPDATE_OBJECTS_FROM_IMPORT");
                if (var17 != null) {
                    var4 = var17;
                }

                if (!var4) {
                    var5 = this.isEntryExistsInQueue(var13, var12);
                }

                var14 = new Timestamp(var14.getTime() + var15);
                Class[] var18 = new Class[]{ObjectIdentifier.class, Boolean.TYPE, Integer.TYPE, Integer.TYPE, Timestamp.class, String.class};
                Object[] var19 = new Object[]{PersistenceHelper.getObjectIdentifier(var2), var3, var2.getBeforeDeadline(), var2.getAfterDeadline(), new Timestamp(var2.getDeadline().getTime()), var12};
                if (var5 != null) {
                    var11 = true;
                    this.updateScheduleQueueEntry(var13, var5, var14, var18, var19);
                }

                if (!var14.before(new Date()) && !var11) {
                    this.addQueueEntryCollection(var6, "handleDeadLineSchedulingEventAfterOrBefore", CLASSNAME, var18, var19, var14, var13, var4);
                }
            }
        } finally {
            SessionContext.setEffectivePrincipal(var7);
        }

        return var1;
    }

    public void removeScheduleEntry(Rootable var1, PlanActivity var2) throws WTException {
        SessionContext var3 = SessionContext.newContext();
        String var4 = PersistenceHelper.getObjectIdentifier(var1) + ":" + PersistenceHelper.getObjectIdentifier(var2) + ":";
        SessionHelper.manager.setAdministrator();

        try {
            if (var2 != null && var2.getDeadline() != null) {
                ScheduleQueue var5 = this.getQueueAfterBypassingAccessControl();
                String var6 = var4 + "Before";
                String var7 = var4 + "After";
                ScheduleQueueEntry var8 = null;
                Enumeration var9 = this.getScheduleQueueEntries(var5);
                if (var9 != null) {
                    while (true) {
                        String var15;
                        do {
                            MethodArgument var13;
                            Object var14;
                            do {
                                Vector var11;
                                do {
                                    do {
                                        Persistable var10;
                                        do {
                                            if (!var9.hasMoreElements()) {
                                                return;
                                            }

                                            var10 = (Persistable) var9.nextElement();
                                        } while (!(var10 instanceof ScheduleQueueEntry));

                                        var8 = (ScheduleQueueEntry) var10;
                                        var11 = var8.getArgs();
                                    } while (var11 == null);
                                } while (var11.size() <= 0);

                                int var12 = var11.size();
                                var13 = (MethodArgument) var11.get(var12 - 1);
                                var14 = var13.getObject();
                            } while (!(var14 instanceof String));

                            var15 = (String) var13.getObject();
                        } while (!var15.equalsIgnoreCase(var6) && !var15.equalsIgnoreCase(var7));

                        QueueHelper.manager.deleteEntry(var5, var8);
                    }
                }
            }
        } finally {
            SessionContext.setContext(var3);
        }

    }

    private void updateScheduleQueueEntryCollection(ScheduleQueue var1) throws WTException {
        Enumeration var2 = QueueHelper.manager.queueEntries(var1);
        PlannableUtils.setScheduleQueueEntries(var2);
    }

    private void addQueueEntryCollection(WTPrincipal var1, String var2, String var3, Class[] var4, Object[] var5, Timestamp var6, ScheduleQueue var7, boolean var8) throws WTException {
        var7.addEntry(var1, var2, CLASSNAME, var4, var5, var6);
        if (!var8) {
            this.updateScheduleQueueEntryCollection(var7);
        } else {
            logger.debug("Added Entry but not scheduled/persisted");
        }

    }

    public static void handleDeadLineSchedulingEventAfterOrBefore(ObjectIdentifier var0, boolean var1, int var2, int var3, Timestamp var4, String var5) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug(CLASSNAME + ".handleDeadLineSchedulingEventAfterOrBefore() : IN");
        }

        if (var0 == null) {
            if (logger.isDebugEnabled()) {
                logger.debug("objId == " + var0 + "\t Skipping...");
            }

        } else {
            NmOid var6 = NmOid.newNmOid(var0);
            if (var6 == null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("nmoid == " + var6 + "\t Skipping...");
                }

            } else {
                Object var7 = var6.getRefObject();
                if (var7 instanceof PlanActivity) {
                    PlanActivity var8 = (PlanActivity) var7;
                    if (logger.isDebugEnabled()) {
                        logger.debug(" Processing Notification for Activity == " + var8);
                    }

                    if (var8.getPercentWorkComplete() != 100.0D && var4.equals(var8.getDeadline()) && shouldNotify(var8)) {
                        if (var1 && var3 == var8.getAfterDeadline()) {
                            if (logger.isDebugEnabled()) {
                                logger.debug(" Send After Deadline Notification for Activity...");
                            }

                            PlanHelper.service.dispatchEvent("EPP_DEADLINE_AFTER", var8);
                            sendDeadlineNotification(var8, !var1);
                        } else if (!var1 && var2 == var8.getBeforeDeadline()) {
                            if (logger.isDebugEnabled()) {
                                logger.debug(" Send Before Deadline Notification for Activity...");
                            }

                            PlanHelper.service.dispatchEvent("EPP_DEADLINE_BEFORE", var8);
                            sendDeadlineNotification(var8, !var1);
                        }
                    }
                } else if (var7 instanceof PlanDeliverable) {
                    PlanDeliverable var9 = (PlanDeliverable) var7;
                    if (logger.isDebugEnabled()) {
                        logger.debug(" Processing Notification for Deliverable == " + var9);
                    }

                    if (var9.getPercentComplete() != 100.0D && var4.equals(var9.getDeadline()) && shouldNotify(var9)) {
                        if (var1 && var3 == var9.getAfterDeadline()) {
                            PlanHelper.service.dispatchEvent("EPP_DEADLINE_AFTER", var9);
                            sendDeliverableDeadlineNotification(var9);
                            if (logger.isDebugEnabled()) {
                                logger.debug(" Sent After Deadline Notification for Deliverable...");
                            }
                        } else if (!var1 && var2 == var9.getBeforeDeadline()) {
                            PlanHelper.service.dispatchEvent("EPP_DEADLINE_BEFORE", var9);
                            sendDeliverableDeadlineNotification(var9);
                            if (logger.isDebugEnabled()) {
                                logger.debug(" Sent Before Deadline Notification for Deliverable...");
                            }
                        }
                    }
                }

                if (logger.isDebugEnabled()) {
                    logger.debug(CLASSNAME + ".handleDeadLineSchedulingEventAfterOrBefore() : OUT ");
                }

            }
        }
    }

    private static boolean shouldNotify(DeadlineSupportable var0) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug(CLASSNAME + ".shouldNotify() : IN");
        }

        if (var0 == null) {
            if (logger.isDebugEnabled()) {
                logger.debug(" Object is null ! := " + var0 + " \t Indicate that notfication should not be sent.");
            }

            return false;
        } else {
            WTContainer var1 = ((WTContained) var0).getContainer();
            if (var1 == null) {
                if (logger.isDebugEnabled()) {
                    logger.debug(" Container is not available... possible corruption ! := " + var1 + " \t Indicate that notfication should not be sent. ");
                }

                return false;
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug(" Container := " + var1);
                }

                boolean var2 = false;
                ProjectState var3 = ProjectState.RUNNING;
                if (var1 instanceof Project2) {
                    var3 = ProjectState.getProjectState(((Project2) var1).getCtmState());
                    if (logger.isDebugEnabled()) {
                        logger.debug("State of Container Project := " + var3);
                    }

                    var2 = ProjectState.RUNNING.equals(var3) || ProjectState.DEFINED.equals(var3);
                    if (logger.isDebugEnabled()) {
                        logger.debug(" shouldNotify := " + var2);
                    }
                } else {
                    var2 = true;
                }

                if (var2) {
                    Plan var4 = null;
                    if (var0 instanceof PlanActivity) {
                        var4 = (Plan) ((PlanActivity) var0).getRoot();
                        if (logger.isDebugEnabled()) {
                            logger.debug(" Plan := " + var4);
                        }

                        var2 = var4.isAutoExecution() ? !var4.isSuspended() && !var4.isCompleted() : true;
                    } else if (var0 instanceof PlanDeliverable) {
                        var2 = true;
                    }
                }

                if (logger.isDebugEnabled()) {
                    logger.debug(CLASSNAME + ".shouldNotify() : OUT ");
                }

                return var2;
            }
        }
    }

    public Rootable scheduleDeliverablesDeadLine(Rootable var1, PlanDeliverable var2) throws WTException {
        WTPrincipal var3 = SessionHelper.manager.getAdministrator();
        WTPrincipal var4 = SessionContext.setEffectivePrincipal(var3);
        ScheduleQueueEntry var5 = null;
        boolean var6 = false;
        String var7 = var2 + "".trim();
        ObjectIdentifier var8 = PersistenceHelper.getObjectIdentifier(var2);

        try {
            if (var2 != null && var2.getDeadline() != null) {
                ScheduleQueue var9 = this.getQueueAfterBypassingAccessControl();
                var5 = this.isEntryExistsInQueue(var9, var7);
                if (var5 == null) {
                    List var10 = this.getOldDeliverableEntryExistsInQueue(var9, var8);
                    if (!var10.isEmpty()) {
                        DeleteListListener var11 = new DeleteListListener(var10);
                        Transaction.addTransactionListener(var11);
                    }
                }

                Class[] var16 = new Class[]{ObjectIdentifier.class, Timestamp.class, String.class};
                Object[] var17 = new Object[]{var8, var2.getDeadline(), var7};
                Timestamp var12 = var2.getDeadline();
                if (var5 != null) {
                    this.updateScheduleQueueEntry(var9, var5, var12, var16, var17);
                    var6 = true;
                }

                if (!var12.before(new Date()) && !var6) {
                    var9.addEntry(var3, "handleDeliverableDeadLineSchedulingEvent", CLASSNAME, var16, var17, var12);
                    this.updateScheduleQueueEntryCollection(var9);
                }
            }
        } finally {
            SessionContext.setEffectivePrincipal(var4);
        }

        return var1;
    }

    public static void handleDeliverableDeadLineSchedulingEvent(ObjectIdentifier var0, Timestamp var1, String var2) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug(CLASSNAME + ".handleDeliverableDeadLineSchedulingEvent() : IN");
        }

        if (var0 != null) {
            NmOid var3 = NmOid.newNmOid(var0);
            if (var3 != null) {
                Object var4 = var3.getRefObject();
                if (var4 instanceof PlanDeliverable) {
                    PlanDeliverable var5 = (PlanDeliverable) var4;
                    if (var5.getPercentComplete() != 100.0D && var1.equals(var5.getDeadline()) && shouldNotify(var5)) {
                        PlanHelper.service.dispatchEvent("EPP_MISSED_DEADLINE", var5);
                        sendDeliverableDeadlineNotification(var5);
                    }
                }
            }
        }

        if (logger.isDebugEnabled()) {
            logger.debug(CLASSNAME + ".handleDeliverableDeadLineSchedulingEvent() : OUT");
        }

    }

    private static void sendDeliverableDeadlineNotification(PlanDeliverable var0) throws WTException {
        if (var0.getOwnership() != null && var0.getOwnership().getOwner() != null && var0.getOwnership().getOwner().getPrincipal() != null) {
            WTPrincipal var2 = var0.getOwnership().getOwner().getPrincipal();
            WTDistributionList var3 = new WTDistributionList();
            var3.addPrincipal(var2);
            TemplateEmailNotification var4 = new TemplateEmailNotification(var3);
            ProjectManagementNotificationProcessor var5 = new ProjectManagementNotificationProcessor();
            var5.setContextObj(var0);
            var4.setTemplateProcessor(var5);
            var4.setSubjectResource("com.ptc.projectmanagement.plan.planResource");
            var4.setSubjectMessageKey("DEADLINE_PASSED");
            var4.setTemplate(TemplateName.getWindchill("plan/EPPDeliverableDeadlineNotification"));
            Object[] var6 = new Object[]{var0.getContainerName(), var0.getName()};
            var4.setSubjectInserts(var6);
            var4.setSender(NOTIFICATION_SENDER);
            NotificationHelper.manager.send(var4);
            if (logger.isTraceEnabled()) {
                logger.trace("   StandardPlannableService: sendDeliverableDeadlineNotification mthd ");
            }
        }

    }

    public Rootable scheduleDeliverablesDeadLineAfter(Rootable var1, PlanDeliverable var2) throws WTException {
        return this.scheduleDeliverablesDeadLineAfterOrBefore(var1, var2, true);
    }

    public Rootable scheduleDeliverablesDeadLineBefore(Rootable var1, PlanDeliverable var2) throws WTException {
        return this.scheduleDeliverablesDeadLineAfterOrBefore(var1, var2, false);
    }

    private Rootable scheduleDeliverablesDeadLineAfterOrBefore(Rootable var1, PlanDeliverable var2, boolean var3) throws WTException {
        WTPrincipal var4 = SessionHelper.manager.getAdministrator();
        WTPrincipal var5 = SessionContext.setEffectivePrincipal(var4);
        long var6 = 86400000L;
        ScheduleQueueEntry var8 = null;
        String var9 = var2 + ":";
        boolean var10 = false;

        try {
            if (var2 != null && var2.getDeadline() != null) {
                ScheduleQueue var11 = this.getQueueAfterBypassingAccessControl();
                long var12 = 0L;
                if (var3) {
                    var12 = (long) var2.getAfterDeadline() * var6;
                    var9 = var9 + "After";
                } else {
                    var12 = (long) (-1 * var2.getBeforeDeadline()) * var6;
                    var9 = var9 + "Before";
                }

                var8 = this.isEntryExistsInQueue(var11, var9);
                Class[] var14 = new Class[]{ObjectIdentifier.class, Boolean.TYPE, Integer.TYPE, Integer.TYPE, Timestamp.class, String.class};
                Object[] var15 = new Object[]{PersistenceHelper.getObjectIdentifier(var2), var3, var2.getBeforeDeadline(), var2.getAfterDeadline(), var2.getDeadline(), var9};
                Timestamp var16 = var2.getDeadline();
                var16 = new Timestamp(var16.getTime() + var12);
                if (var8 != null) {
                    this.updateScheduleQueueEntry(var11, var8, var16, var14, var15);
                    var10 = true;
                }

                if (!var16.before(new Date()) && !var10) {
                    var11.addEntry(var4, "handleDeadLineSchedulingEventAfterOrBefore", CLASSNAME, var14, var15, var16);
                    this.updateScheduleQueueEntryCollection(var11);
                }
            }
        } finally {
            SessionContext.setEffectivePrincipal(var5);
        }

        return var1;
    }

    private void completePlannablesWithNoDuration(Plannable var1) throws WTException {
        if (var1 instanceof PlanActivity) {
            PlanActivity var2 = (PlanActivity) var1;
            Plan var3 = (Plan) var2.getRoot();
            if (var3.isAutoExecution() && !var2.isMilestone() && var2.getDuration().getMillis() == 0L && PlannableState.INPROCESS.equals(var2.getPlannableState())) {
                try {
                    Timestamp var4 = ProcessorUtils.getAdjustedCurrentTime(var3, new Date());
                    var2.setPercentWorkComplete(100.0D);
                    var2.setRemainingEffort(Duration.newDuration());
                    var2.setFinishDate(var4);
                    var2.setActualFinishDate(var2.getFinishDate());
                    var2.setPlannableState(PlannableState.COMPLETED);
                    var2 = (PlanActivity) PersistenceHelper.manager.save(var2);
                    WTCollection var5 = AssignmentHelper.service.getResourceAssignments(var2);

                    ResourceAssignment var7;
                    for (Iterator var6 = var5.persistableIterator(); var6.hasNext(); var7 = (ResourceAssignment) PersistenceHelper.manager.save(var7)) {
                        var7 = (ResourceAssignment) var6.next();
                        var7.setPercentWorkComplete(100.0D);
                        var7.setRemainingEffort(Duration.newDuration());
                        var7.setFinishDate(var4);
                        var7.setActualFinishDate(var7.getFinishDate());
                    }

                    var2 = (PlanActivity) PlannableHelper.service.rollUpPlannableState(var2);
                    if (var3.isLinkDeliverable()) {
                        WTCollection var12 = PlannableHelper.service.getPlanDeliverableLinks(var2);
                        if (var12.size() > 0) {
                            Iterator var8 = var12.persistableIterator();

                            while (var8.hasNext()) {
                                PlanDeliverableLink var9 = (PlanDeliverableLink) var8.next();
                                PlanDeliverable var10 = var9.getPlanDeliverable();
                                var10.setPercentComplete(100.0D);
                                var10 = (PlanDeliverable) PersistenceHelper.manager.save(var10);
                                PlanHelper.service.dispatchEvent("EPP_PERCENT_CHANGE", var10);
                            }
                        }
                    }

                    PlanHelper.service.dispatchEvent("PLANACTIVITY_STATE_CHANGE", var2);
                    boolean var13 = PlannableUtils.isRefreshRequiredAfterDispatchEvent(var2);
                    if (var13) {
                        var2 = (PlanActivity) PersistenceHelper.manager.refresh(var2);
                    }

                    PlanHelper.service.dispatchEvent("EPP_PERCENT_CHANGE", var2);
                    if (var13) {
                        var2 = (PlanActivity) PersistenceHelper.manager.refresh(var2);
                    }
                } catch (WTPropertyVetoException var11) {
                    var11.printStackTrace();
                }
            }
        }

    }

    public WTCollection getRequirementPlannableLinks(Mastered var1) throws WTException {
        return this.getRequirementPlannableLinksCommon(var1);
    }

    public WTCollection getRequirementPlannableLinks(Plannable var1) throws WTException {
        return this.getRequirementPlannableLinksCommon(var1);
    }

    private WTCollection getRequirementPlannableLinksCommon(Object var1) throws QueryException, WTException {
        Mastered var2 = null;
        Plannable var3 = null;
        String var4 = null;
        Object var5 = null;
        if (var1 instanceof Mastered) {
            var2 = (Mastered) var1;
            var4 = "roleAObjectRef.key.id";
            var5 = var2;
        } else if (var1 instanceof Plannable) {
            var3 = (Plannable) var1;
            var4 = "roleBObjectRef.key.id";
            var5 = var3;
        }

        QuerySpec var6 = new QuerySpec();
        int var7 = var6.appendClassList(RequirementPlannableLink.class, true);
        SearchCondition var8 = new SearchCondition(RequirementPlannableLink.class, var4, "=", PersistenceHelper.getObjectIdentifier((Persistable) var5).getId());
        var6.appendWhere(var8, var7);
        ClassAttribute var9 = new ClassAttribute(RequirementPlannableLink.class, "thePersistInfo.theObjectIdentifier.id");
        var6.appendOrderBy(new OrderBy(var9, false), new int[]{var7});
        QueryResult var10 = PersistenceHelper.manager.find(var6);
        WTArrayList var11 = new WTArrayList();
        var11.addAll(var10);
        return var11;
    }

    public WTCollection getRequirementPlannableLinks(ArrayList var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        ArrayList var3 = new ArrayList();
        int var4 = var2.appendClassList(RequirementPlannableLink.class, true);
        Iterator var5 = var1.iterator();

        while (var5.hasNext()) {
            Plannable var6 = (Plannable) var5.next();
            var3.add(var6.getPersistInfo().getObjectIdentifier().getId());
        }

        SearchCondition var9 = new SearchCondition(new ClassAttribute(RequirementPlannableLink.class, "roleBObjectRef.key.id"), "IN", new ArrayExpression(var3.toArray()));
        var2.appendSearchCondition(var9);
        QueryResult var7 = PersistenceHelper.manager.find(var2);
        WTArrayList var8 = new WTArrayList();
        var8.addAll(var7);
        return var8;
    }

    public WTArrayList getAssociatedActivities(WTArrayList var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        ArrayList var3 = new ArrayList();
        WTArrayList var4 = new WTArrayList();
        int var5 = var2.appendClassList(RequirementPlannableLink.class, true);
        Iterator var6 = var1.iterator();

        while (var6.hasNext()) {
            Plannable var7 = (Plannable) ((ObjectReference) var6.next()).getObject();
            var3.add(var7.getPersistInfo().getObjectIdentifier().getId());
        }

        SearchCondition var11 = new SearchCondition(new ClassAttribute(RequirementPlannableLink.class, "roleBObjectRef.key.id"), "IN", new ArrayExpression(var3.toArray()));
        var2.appendSearchCondition(var11);
        QueryResult var8 = PersistenceHelper.manager.find(var2);

        while (var8.hasMoreElements()) {
            Object var9 = var8.nextElement();
            RequirementPlannableLink var10 = (RequirementPlannableLink) ((Object[]) ((Object[]) var9))[0];
            var4.add(var10.getPlannable());
        }

        return var4;
    }

    private ScheduleQueueEntry isEntryExistsInQueue(ScheduleQueue var1, String var2) throws WTException {
        ScheduleQueueEntry var3 = null;
        boolean var4 = false;
        Enumeration var5 = this.getScheduleQueueEntries(var1);
        if (var5 != null) {
            while (var5.hasMoreElements()) {
                Persistable var6 = (Persistable) var5.nextElement();
                if (var6 instanceof ScheduleQueueEntry) {
                    var3 = (ScheduleQueueEntry) var6;
                    Vector var7 = var3.getArgs();
                    if (var7 != null && var7.size() > 0) {
                        int var8 = var7.size();
                        MethodArgument var9 = (MethodArgument) var7.get(var8 - 1);
                        Object var10 = var9.getObject();
                        if (var10 instanceof String) {
                            String var11 = (String) var9.getObject();
                            if (var11.equalsIgnoreCase(var2)) {
                                var4 = true;
                                break;
                            }
                        }
                    }
                }
            }
        }

        return var4 ? var3 : null;
    }

    private HashMap<String, ScheduleQueueEntry> areEntriesExistsInQueue(ScheduleQueue var1, List<String> var2) throws WTException {
        HashMap var3 = new HashMap();
        if (var2 == null) {
            return var3;
        } else {
            ScheduleQueueEntry var4 = null;
            Enumeration var5 = this.getScheduleQueueEntries(var1);
            if (var5 != null) {
                while (var5.hasMoreElements()) {
                    Persistable var6 = (Persistable) var5.nextElement();
                    if (var6 instanceof ScheduleQueueEntry) {
                        var4 = (ScheduleQueueEntry) var6;
                        Vector var7 = var4.getArgs();
                        if (var7 != null && var7.size() > 0) {
                            int var8 = var7.size();
                            MethodArgument var9 = (MethodArgument) var7.get(var8 - 1);
                            Object var10 = var9.getObject();
                            if (var10 instanceof String) {
                                String var11 = (String) var9.getObject();
                                if (var2.contains(var11)) {
                                    var3.put(var11, var4);
                                }
                            }
                        }
                    }
                }
            }

            return var3;
        }
    }

    private Enumeration getScheduleQueueEntries(ScheduleQueue var1) throws WTException {
        Enumeration var2 = PlannableUtils.getScheduleQueueEntries();
        if (var2 == null || !var2.hasMoreElements()) {
            boolean var3 = SessionServerHelper.manager.setAccessEnforced(false);

            try {
                var2 = QueueHelper.manager.queueEntries(var1);
            } finally {
                SessionServerHelper.manager.setAccessEnforced(var3);
            }

            PlannableUtils.setScheduleQueueEntries(var2);
        }

        return var2;
    }

    private List getOldDeliverableEntryExistsInQueue(ScheduleQueue var1, ObjectIdentifier var2) throws WTException {
        WTArrayList var5 = new WTArrayList();
        Enumeration var6 = this.getScheduleQueueEntries(var1);
        if (var6 != null) {
            while (var6.hasMoreElements()) {
                Persistable var7 = (Persistable) var6.nextElement();
                if (var7 instanceof ScheduleQueueEntry) {
                    ScheduleQueueEntry var3 = (ScheduleQueueEntry) var7;
                    Vector var8 = var3.getArgs();
                    if (var8 != null && var8.size() > 0) {
                        int var9 = var8.size();
                        MethodArgument var10 = (MethodArgument) var8.get(0);
                        Object var11 = var10.getObject();
                        if (var11 instanceof ObjectIdentifier) {
                            ObjectIdentifier var12 = (ObjectIdentifier) var10.getObject();
                            if (var12.equals(var2)) {
                                boolean var4 = true;
                                var5.add(var3);
                            }
                        }
                    }
                }
            }
        }

        return var5;
    }

    private ScheduleQueueEntry updateScheduleQueueEntry(ScheduleQueue var1, ScheduleQueueEntry var2, Timestamp var3, Class[] var4, Object[] var5) throws WTException {
        try {
            var2.setScheduleTime(new Timestamp(var3.getTime()));
            Vector var6 = new Vector(var4.length);

            for (int var7 = 0; var7 < var4.length; ++var7) {
                var6.addElement(new MethodArgument(var4[var7], var5[var7]));
            }

            var2.setEntryArgs(var6);
            QueueHelper.manager.updateQueueEntry(var1, var2);
        } catch (WTPropertyVetoException var8) {
            var8.printStackTrace();
        }

        return var2;
    }

    public WTCollection listDeliverablesForContainer(Plannable var1) throws WTException {
        Object var2 = null;
        QuerySpec var3 = new QuerySpec();
        var3.appendClassList(PlanDeliverable.class, true);
        SearchCondition var4 = new SearchCondition(PlanDeliverable.class, "parentReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var3.appendWhere(var4, new int[]{0});
        QueryResult var5 = PersistenceHelper.manager.find(var3);
        WTArrayList var6 = new WTArrayList();
        var6.addAll(var5);
        return var6;
    }

    protected WTValuedMap getFirstIterations(WTCollection var1) throws WTException {
        WTValuedHashMap var2 = new WTValuedHashMap(var1.size());
        QueryResult var3 = VersionControlHelper.service.iterationsOf(var1, Iterated.class, true);

        Iterated var5;
        Iterated var6;
        label34:
        for (Iterator var4 = var1.persistableIterator(); var4.hasNext(); var2.put(var5, var6)) {
            var5 = (Iterated) var4.next();
            var6 = null;
            var3.reset();

            while (true) {
                Iterated var7;
                do {
                    do {
                        if (!var3.hasMoreElements()) {
                            continue label34;
                        }

                        var7 = (Iterated) var3.nextElement();
                    } while (var7.getBranchIdentifier() != var5.getBranchIdentifier());
                } while (var6 != null && !var7.getIterationInfo().getIdentifier().getSeries().lessThan(var6.getIterationInfo().getIdentifier().getSeries()));

                var6 = var7;
            }
        }

        return var2;
    }

    public WTCollection getDeliverablestoRemoveSubjectLink(WTCollection var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        ArrayList var3 = new ArrayList();
        var2.appendClassList(PlanDeliverable.class, true);
        Iterator var4 = var1.iterator();

        while (var4.hasNext()) {
            Object var5 = var4.next();
            if (var5 instanceof ObjectReference) {
                Persistable var6 = ((ObjectReference) var5).getObject();
                if (var6 instanceof Iterated) {
                    var3.add(((Iterated) var6).getBranchIdentifier());
                }
            } else if (var5 instanceof Iterated) {
                var3.add(((Iterated) var5).getBranchIdentifier());
            }
        }

        SearchCondition var7 = new SearchCondition(new ClassAttribute(PlanDeliverable.class, "subject.key.branchId"), "IN", new ArrayExpression(var3.toArray()));
        var2.appendWhere(var7, new int[]{0});
        QueryResult var8 = PersistenceServerHelper.manager.query(var2);
        WTArrayList var9 = new WTArrayList();
        var9.addAll(var8);
        return var9;
    }

    private ScheduleQueue getQueueAfterBypassingAccessControl() throws WTException {
        ScheduleQueue var1 = null;
        boolean var2 = SessionServerHelper.manager.setAccessEnforced(false);

        try {
            var1 = (ScheduleQueue) QueueHelper.manager.getQueue("EPPQueue", ScheduleQueue.class);
            if (var1 == null) {
                var1 = QueueHelper.manager.createScheduleQueue("EPPQueue", true);
            }
        } finally {
            SessionServerHelper.manager.setAccessEnforced(var2);
        }

        return var1;
    }

    public void rewirePredecessors(ArrayList<PlanActivity> var1) {
        logger.info("rewirePredecessors - IN");
        HashMap var2 = this.listPrecedenceConstraintsBySuccessors(var1);
        if (!var2.isEmpty()) {
            HashMap var3 = this.listSuccessorActivitiesByPredecessors(var1);
            if (!var3.isEmpty()) {
                try {
                    this.addPrecedenceConstraintsToSuccessors(var2, var3);
                } catch (WTException var5) {
                    System.out.println(var5.getMessage());
                    if (logger.isDebugEnabled()) {
                        var5.printStackTrace();
                    }
                }
            }
        }

        logger.info("rewirePredecessors - OUT");
    }

    private HashMap listPrecedenceConstraintsBySuccessors(ArrayList<PlanActivity> var1) {
        logger.debug("listPrecedenceConstraintsBySuccessors -- IN");
        HashMap var2 = new HashMap();
        HashSet var3 = new HashSet();
        long[] var4 = new long[var1.size()];
        int var5 = 0;
        Iterator var6 = var1.iterator();

        while (var6.hasNext()) {
            PlanActivity var7 = (PlanActivity) var6.next();
            var4[var5++] = PersistenceHelper.getObjectIdentifier(var7).getId();
            var3.add(var7);
        }

        try {
            QuerySpec var20 = new QuerySpec();
            int var21 = var20.appendClassList(PrecedenceConstraint.class, true);
            int var8 = var20.appendClassList(Plannable.class, true);
            ClassAttribute var9 = new ClassAttribute(PrecedenceConstraint.class, "roleAObjectRef.key.id");
            SearchCondition var10 = new SearchCondition(var9, "IN", new ArrayExpression(var4));
            var20.appendWhere(var10, var21);
            var20.appendJoin(var21, "successor", var8);
            ClassAttribute var11 = new ClassAttribute(Plannable.class, "lineNumber");
            var20.appendOrderBy(new OrderBy(var11, false), new int[]{var8});

            PlanActivity var16;
            ArrayList var17;
            for (QueryResult var12 = PersistenceServerHelper.manager.query(var20); var12.hasMoreElements(); var2.put(var16, var17)) {
                Object[] var13 = (Object[]) ((Object[]) var12.nextElement());
                PrecedenceConstraint var14 = (PrecedenceConstraint) var13[0];
                PlanActivity var15 = (PlanActivity) var14.getPredecessor();
                var16 = (PlanActivity) var13[1];
                logger.debug("successor :" + var16.getName() + " predecessor:" + var15.getName());
                var17 = (ArrayList) var2.get(var16);
                if (var17 == null) {
                    var17 = new ArrayList();
                }

                if (!var3.contains(var15)) {
                    var17.add(var14);
                    logger.debug("Adding predecessor :" + var15.getName() + " to list for successor :" + var16.getName());
                } else {
                    logger.debug("Check backward for predecessor " + var15.getName() + " as this too being deleted");
                    ArrayList var18 = (ArrayList) var2.get(var15);
                    if (var18 != null) {
                        var17.addAll(var18);
                    }
                }
            }
        } catch (WTException var19) {
            logger.error(var19.getMessage());
            if (logger.isDebugEnabled()) {
                var19.printStackTrace();
            }
        }

        logger.debug("listPrecedenceConstraintsBySuccessors -- OUT");
        return var2;
    }

    private HashMap listSuccessorActivitiesByPredecessors(ArrayList<PlanActivity> var1) {
        HashMap var2 = new HashMap();
        HashSet var3 = new HashSet();
        long[] var4 = new long[var1.size()];
        int var5 = 0;
        Iterator var6 = var1.iterator();

        while (var6.hasNext()) {
            PlanActivity var7 = (PlanActivity) var6.next();
            var4[var5++] = PersistenceHelper.getObjectIdentifier(var7).getId();
            var3.add(var7);
        }

        try {
            QuerySpec var19 = new QuerySpec();
            int var20 = var19.appendClassList(PrecedenceConstraint.class, true);
            int var8 = var19.appendClassList(Plannable.class, true);
            ClassAttribute var9 = new ClassAttribute(PrecedenceConstraint.class, "roleBObjectRef.key.id");
            SearchCondition var10 = new SearchCondition(var9, "IN", new ArrayExpression(var4));
            var19.appendWhere(var10, var20);
            var19.appendJoin(var20, "predecessor", var8);
            ClassAttribute var11 = new ClassAttribute(Plannable.class, "lineNumber");
            var19.appendOrderBy(new OrderBy(var11, false), new int[]{var8});
            QueryResult var12 = PersistenceServerHelper.manager.query(var19);

            while (var12.hasMoreElements()) {
                Object[] var13 = (Object[]) ((Object[]) var12.nextElement());
                PrecedenceConstraint var14 = (PrecedenceConstraint) var13[0];
                PlanActivity var15 = (PlanActivity) var14.getSuccessor();
                if (!var3.contains(var15)) {
                    PlanActivity var16 = (PlanActivity) var13[1];
                    ArrayList var17 = (ArrayList) var2.get(var16);
                    if (var17 == null) {
                        var17 = new ArrayList();
                    }

                    var17.add(var15);
                    logger.debug("Considering successor :" + var15.getName() + " for predecessor" + var16.getName());
                    var2.put(var16, var17);
                } else {
                    logger.debug("Skipping successor :" + var15.getName() + " as this is too being deleted");
                }
            }
        } catch (WTException var18) {
            logger.error(var18.getMessage());
            if (logger.isDebugEnabled()) {
                var18.printStackTrace();
            }
        }

        return var2;
    }

    private void addPrecedenceConstraintsToSuccessors(HashMap<PlanActivity, ArrayList<PrecedenceConstraint>> var1, HashMap<PlanActivity, ArrayList<PlanActivity>> var2) throws WTException {
        logger.info("addPrecedenceConstraintsToSuccessors - IN : Adding the predecessors of activity being deleted to all it's successors ");
        WTArrayList var3 = new WTArrayList();
        logger.debug("No of activities being deleted : " + var1.keySet().size());
        Iterator var4 = var1.keySet().iterator();

        while (true) {
            ArrayList var6;
            ArrayList var7;
            do {
                do {
                    if (!var4.hasNext()) {
                        if (!var3.isEmpty()) {
                            PersistenceHelper.manager.save(var3);
                        }

                        logger.info("addPrecedenceConstraintsToSuccessors - OUT ");
                        return;
                    }

                    PlanActivity var5 = (PlanActivity) var4.next();
                    logger.debug("Processing activity :" + var5.getName());
                    var6 = (ArrayList) var2.get(var5);
                    var7 = (ArrayList) var1.get(var5);
                } while (var7 == null);
            } while (var6 == null);

            logger.debug("No of predecessors :" + var7.size() + " No of successors :" + var6.size());
            Iterator var8 = var7.iterator();

            while (var8.hasNext()) {
                PrecedenceConstraint var9 = (PrecedenceConstraint) var8.next();
                Plannable var10 = var9.getPredecessor();
                PrecedenceType var11 = var9.getPrecedenceType();
                Duration var12 = var9.getScheduleOffset();
                Iterator var13 = var6.iterator();

                while (var13.hasNext()) {
                    PlanActivity var14 = (PlanActivity) var13.next();
                    PrecedenceConstraint var15 = PrecedenceConstraint.newPrecedenceConstraint(var14, var10);
                    if (!PrecedenceConstraint.isPrecedenceConstraintDuplicate(var15)) {
                        try {
                            var15.setPrecedenceType(var11);
                            var15.setScheduleOffset(var12);
                        } catch (WTPropertyVetoException var17) {
                            if (logger.isDebugEnabled()) {
                                var17.printStackTrace();
                            }
                        }

                        var3.add(var15);
                    }
                }
            }
        }
    }

    public Map<Scheduleable, ActivityHistoryRecord> getHistoryRecordsForPlan(Plan var1) throws WTException {
        logger.debug("getHistoryRecordsForPlan() - IN, plan=" + var1);
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(HistoryRecordLink.class, true);
        int var4 = var2.appendClassList(PlanActivity.class, false);
        var2.appendWhere(new SearchCondition(PlanActivity.class, "rootReference.key.id", "=", PersistenceHelper.getObjectIdentifier(var1).getId()), new int[]{var4});
        var2.appendAnd();
        var2.appendWhere(new SearchCondition(HistoryRecordLink.class, "roleAObjectRef.key.id", PlanActivity.class, "thePersistInfo.theObjectIdentifier.id"), new int[]{var3, var4});
        logger.debug("\t@@ querySpec = " + var2.toString());
        QueryResult var5 = PersistenceServerHelper.manager.query(var2);
        WTArrayList var6 = new WTArrayList();
        var6.addAll(var5);
        HashMap var7 = new HashMap();
        Iterator var8 = var6.persistableCollection().iterator();

        while (var8.hasNext()) {
            Object var9 = var8.next();
            HistoryRecordLink var10 = (HistoryRecordLink) var9;
            HistoryRecordable var11 = var10.getHistoryRecordable();
            if (var11 instanceof PlanActivity) {
                PlanActivity var12 = (PlanActivity) var11;
                WTArrayList var17;
                if (var7.containsKey(var12)) {
                    WTCollection var13 = (WTCollection) var7.get(var12);
                    if (var13 != null) {
                        var13.add(var10.getHistoryRecord());
                    } else {
                        var17 = new WTArrayList();
                        var17.add(var10.getHistoryRecord());
                    }
                } else {
                    var17 = new WTArrayList();
                    var17.add(var10.getHistoryRecord());
                    var7.put(var12, var17);
                }
            }
        }

        HashMap var14 = new HashMap();
        Iterator var15 = var7.keySet().iterator();

        while (var15.hasNext()) {
            PlanActivity var16 = (PlanActivity) var15.next();
            var14.put(var16, new ActivityHistoryRecord(var16, (WTCollection) var7.get(var16)));
        }

        logger.debug("getHistoryRecordsForPlan() - OUT, activityHistoryRecords size = " + var14.size());
        return var14;
    }

    private WTCollection removeBaselinedObjects(WTCollection var1) throws WTException {
        WTHashSet var2 = new WTHashSet();
        if (var1 != null && var1.size() > 0) {
            WTObject var3 = null;
            Iterator var4 = var1.persistableIterator();

            while (var4.hasNext()) {
                var3 = (WTObject) var4.next();
                if (!(var3 instanceof BaselinedPlan) && !(var3 instanceof BaselinedPlanActivity) && !(var3 instanceof BaselinedPlanDeliverable) && !(var3 instanceof BaselinedPlanResource) && !(var3 instanceof BaselinedResourceAssignment)) {
                    var2.add(var3);
                }
            }
        }

        return var2;
    }

    public void resumeSuccessors(Plan var1) throws WTException, WTPropertyVetoException {
        ProcessorUtils var2 = new ProcessorUtils(var1);
        Timestamp var3 = var2.getAdjustedCurrentTime();
        LinkedHashMap var4 = AssignmentHelper.service.getAllResourceAssignments(var1);
        WTArrayList var5 = new WTArrayList();
        WTCollection var6 = PlannableHelper.service.getAllPlannables(var1, PlannableState.SCHEDULED, true);
        HashMap var7 = new HashMap();
        var2.resetPredecessorsMap();
        var2.createAndResetActivitiesStartFlagMap();
        Iterator var8 = var6.iterator();

        while (true) {
            Plannable var10;
            boolean var11;
            PlanActivity var25;
            while (true) {
                PlanActivity var23;
                if (!var8.hasNext()) {
                    WTCollection var18 = CollectionsHelper.manager.refresh(var5);
                    PersistenceHelper.manager.save(var18);
                    WTCollection var19 = PlannableHelper.service.getAllPlannables(var1, PlannableState.INPROCESS, true);
                    Iterator var20 = var19.iterator();

                    while (var20.hasNext()) {
                        Object var22 = var20.next();
                        Plannable var24 = (Plannable) ((ObjectReference) var22).getObject();
                        if (var24 instanceof PlanActivity) {
                            var23 = (PlanActivity) var24;
                            if (var23.getParent() instanceof PlanActivity) {
                                var25 = (PlanActivity) var23.getParent();
                                if (!var25.isInProcess()) {
                                    this.startParentPlannable(var25);
                                }
                            }
                        }
                    }

                    var1 = (Plan) PersistenceHelper.manager.refresh(var1);
                    if (!var1.isCompleted()) {
                        logger.debug("Rolling up the state to update the plan state...");
                        var1 = (Plan) PlannableHelper.service.rollUpPlannableState(var1);
                    }

                    logger.debug("Total updated ResourceAssignments= " + var18.size() + ".\tScheduling Activities, this is to create schedule items in EPPQueue");
                    var1 = (Plan) PlannableHelper.service.schedulePlannables(var1);
                    return;
                }

                Object var9 = var8.next();
                var10 = (Plannable) ((ObjectReference) var9).getObject();
                if (var10 instanceof PlanActivity && ProcessorUtils.hasMFOPassedStartDate((PlanActivity) var10)) {
                    Locale var21 = SessionHelper.getLocale();
                    var23 = (PlanActivity) var10;
                    WTContainerRef var26 = var23.getContainerReference();
                    String var28 = ProcessorUtils.getUserFormattedDate(new Timestamp(var23.getConstraintDate().getTime()), var21, var26, SessionHelper.getPrincipal());
                    String[] var30 = new String[]{var23.getName(), var28};
                    String var32 = WTMessage.getLocalizedMessage("com.ptc.projectmanagement.ilog.ilogResource", "MFO_FINISH_BEYOND_CONSTRAINT_DATE_ERROR_MESSAGE", var30, var21);
                    throw new WTException(var32);
                }

                var11 = false;
                if (!var10.isSummary()) {
                    break;
                }

                if (var7.containsKey(var10)) {
                    var11 = true;
                    var10 = (Plannable) PersistenceHelper.manager.refresh(var10);
                    break;
                }
            }

            Timestamp var12 = var10.getStartDate();
            if (var11 || !var12.after(var3) && var2.isActivityReadyToStart(var10)) {
                int var13 = var10.getLineNumber();
                if (var13 != 0) {
                    var10.setPlannableState(PlannableState.INPROCESS);
                    var10.setStartDate(var3);
                    var10.setActualStartDate(var3);
                    Plannable var14 = var10.getParentPlannable();
                    if (var14 != null && !(var14 instanceof Plan)) {
                        var7.put(var14, true);
                    }

                    if (!var10.isSummary()) {
                        PlanActivity var15 = PlannableHelper.service.getDummyMilestoneForPlan(var1);
                        Timestamp var16 = var15.getStartDate();
                        Long var17 = var3.getTime() - var16.getTime();
                        if (var17 > 0L) {
                            var17 = ScheduleUtils.calculateWorkingDuration(var16, var3, TimeZoneHelper.getTimeZone(), ScheduleUtils.getWorkingCalendarConfig(var10));
                            PlannableHelper.service.createDummyPrecedenceConstraintForActivity((PlanActivity) var10, var15, var17);
                        }
                    }
                }

                if (var4.containsKey(var10)) {
                    ArrayList var27 = (ArrayList) var4.get(var10);
                    Iterator var29 = var27.iterator();

                    while (var29.hasNext()) {
                        ResourceAssignment var31 = (ResourceAssignment) var29.next();
                        var31.setActualStartDate(var3);
                        var31.setStartDate(var3);
                        var5.add(var31);
                    }
                }

                var10 = (Plannable) PersistenceHelper.manager.save(var10);
                PlanHelper.service.dispatchEvent("PLANACTIVITY_STATE_CHANGE", var10);
                if (var10 instanceof PlanActivity && PlannableUtils.isRefreshRequiredAfterDispatchEvent((PlanActivity) var10)) {
                    var10 = (Plannable) PersistenceHelper.manager.refresh(var10);
                }
            }

            if (var10.getParent() instanceof PlanActivity) {
                var25 = (PlanActivity) var10.getParent();
                if (var25.isCompleted()) {
                    this.startParentPlannable(var25);
                }
            }
        }
    }

    private void startParentPlannable(Plannable var1) throws WTException, WTPropertyVetoException {
        WTCollection var2 = PlannableHelper.service.getImmediateChildren(var1);
        Timestamp var3 = new Timestamp((new Date()).getTime());
        Iterator var4 = var2.iterator();

        while (true) {
            PlanActivity var7;
            do {
                Plannable var6;
                do {
                    if (!var4.hasNext()) {
                        ArrayList var8 = PlannableHelper.service.getPrecedenceConstraints(var1, false);

                        for (int var9 = 0; var9 < var8.size(); ++var9) {
                            PrecedenceConstraint var11 = (PrecedenceConstraint) var8.get(var9);
                            PersistenceHelper.manager.delete(var11);
                        }

                        ProcessorUtils var10 = new ProcessorUtils(var1.getRoot());
                        if (var10.isActivityReadyToStart(var1)) {
                            var1 = (Plannable) PersistenceHelper.manager.refresh(var1);
                            var1.setActualStartDate(var3);
                            var1.setStartDate(var3);
                            var1.setPlannableState(PlannableState.INPROCESS);
                            if (var1.getActualFinishDate() != null) {
                                var1.setActualFinishDate((Timestamp) null);
                            }

                            if (logger.isDebugEnabled()) {
                                logger.debug("Starting parent since it's one of the child is started :" + var1.getName());
                            }

                            ((PlanActivity) var1).setConstraintType(DateConstraint.ASAP);
                            ((PlanActivity) var1).setConstraintDate((Timestamp) null);
                            var1 = (Plannable) PersistenceHelper.manager.save(var1);
                            PlanHelper.service.dispatchEvent("PLANACTIVITY_STATE_CHANGE", var1);
                            if (var1 instanceof PlanActivity && PlannableUtils.isRefreshRequiredAfterDispatchEvent((PlanActivity) var1)) {
                                var1 = (Plannable) PersistenceHelper.manager.refresh(var1);
                            }

                            if (var1.getParentPlannable() != null && !PlannableState.INPROCESS.equals(var1.getParentPlannable().getPlannableState())) {
                                this.startParentPlannable(var1.getParentPlannable());
                            }
                        }

                        return;
                    }

                    Object var5 = var4.next();
                    var6 = (Plannable) ((ObjectReference) var5).getObject();
                } while (!(var6 instanceof PlanActivity));

                var7 = (PlanActivity) var6;
            } while (!var7.isInProcess() && !var7.isCompleted());

            if (var3.after(var7.getActualStartDate())) {
                var3 = var7.getActualStartDate();
            }
        }
    }

    public QueryResult getDeliverablesForPlan(Plan var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("=> StandardPlannableService.getDeliverablesForPlan:\n\tplan = " + var1);
        }

        QuerySpec var2 = new QuerySpec(PlanDeliverable.class);
        var2.setAdvancedQueryEnabled(true);
        var2.appendWhere(new SearchCondition(PlanDeliverable.class, "parentReference.key", "=", this.getOid(var1)), new int[]{0});
        if (logger.isDebugEnabled()) {
            logger.debug("=> StandardPlannableService.getDeliverablesForPlan: Query is " + var2);
        }

        return PersistenceHelper.manager.find(var2);
    }

    private void fixPlanTemplateTypeIdentities(WTCollection var1) throws WTException {
        logger.debug("Enter => fixPlanTemplateTypeIdentities(WTCollection).");
        Iterator var2 = var1.iterator();
        ArrayList var8 = new ArrayList();

        while (true) {
            while (true) {
                Persistable var4;
                do {
                    Object var3;
                    do {
                        if (!var2.hasNext()) {
                            if (!var8.isEmpty()) {
                                this.fixPlanTemplateTypeIdentities((List) var8);
                            }

                            logger.debug("Exit => fixPlanTemplateTypeIdentities(WTCollection).");
                            return;
                        }

                        var3 = var2.next();
                    } while (!(var3 instanceof ObjectReference));

                    var4 = ((ObjectReference) var3).getObject();
                } while (!(var4 instanceof LogicalIdentifierMapEntry));

                String var5 = ((LogicalIdentifierMapEntry) var4).getLogicalIdentifier();
                String var6 = TypedUtility.getPersistedType(var5);
                if (var6 != null && var6.contains("com.ptc.projectmanagement.plan.Plan")) {
                    String var7 = TypedUtility.getExternalTypeIdentifier(var6);
                    if (var7.startsWith("WCTYPE|")) {
                        var7 = var7.substring(7);
                    }

                    if (!"com.ptc.projectmanagement.plan.Plan".equals(var7)) {
                        var8.add(var7);
                    }
                } else if (logger.isDebugEnabled()) {
                    logger.debug("persistedType: " + var6 + ". Ignoring and continuing.");
                }
            }
        }
    }

    private void fixPlanTemplateTypeIdentities(List<String> var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("Enter => fixPlanTemplateTypeIdentities(List<String>).");
            logger.debug("typeIdentifiers: " + var1);
        }

        QuerySpec var2 = new QuerySpec(ProductPlanTemplate.class);
        ClassAttribute var3 = new ClassAttribute(ProductPlanTemplate.class, "typeIdentity");
        SearchCondition var4 = new SearchCondition(var3, "IN", new ArrayExpression(var1.toArray()));
        var2.appendWhere(var4, new int[]{0});
        if (logger.isDebugEnabled()) {
            logger.debug("qs: " + var2);
        }

        QueryResult var5 = PersistenceHelper.manager.find(var2);

        while (var5.hasMoreElements()) {
            ProductPlanTemplate var6 = (ProductPlanTemplate) var5.nextElement();
            String var7 = var6.getTypeIdentity();
            if (logger.isDebugEnabled()) {
                logger.debug("typeIdentity: " + var7);
            }

            TypeIdentifier var9 = TypedUtility.getTypeIdentifier(var7);
            TypeIdentifier var10 = TypedUtility.getSupertype(var9);

            String var8;
            for (var8 = var10.getTypename(); var1.contains(var8); var8 = var10.getTypename()) {
                var10 = TypedUtility.getSupertype(var10);
            }

            try {
                if (logger.isDebugEnabled()) {
                    logger.debug("Setting typeIdentity to: " + var8);
                }

                var6.setTypeIdentity(var8);
                var6 = (ProductPlanTemplate) PersistenceHelper.manager.save(var6);
            } catch (WTPropertyVetoException var12) {
                logger.error("Exception while setting typeIdentity on plan template: " + var6);
            } catch (WTException var13) {
                logger.error("Exception while saving the modified plan template: " + var6);
            }
        }

        logger.debug("Exit => fixPlanTemplateTypeIdentities(List<String>).");
    }

    public QuerySpec getEligiblePlansActivitiesForTrackNewWorkQuerySpec(QuerySpec var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("IN getEligiblePlansActivitiesForTrackNewWorkQuerySpec . QuerySpec" + var1);
        }

        WTUser var2 = (WTUser) SessionHelper.getPrincipal();
        if (logger.isDebugEnabled()) {
            logger.debug("loggedInUser" + var2.getName());
        }

        int var3 = var1.appendClassList(ResourceAssignment.class, false);
        int var4 = var1.appendClassList(PlanResource.class, false);
        int var5 = var1.getFromClause().getPosition(PlanActivity.class);
        SearchCondition var6 = new SearchCondition(ResourceAssignment.class, "roleBObjectRef.key.id", PlanActivity.class, "thePersistInfo.theObjectIdentifier.id");
        var1.appendWhere(var6, new int[]{var3, var5});
        var1.appendAnd();
        SearchCondition var7 = new SearchCondition(ResourceAssignment.class, "roleAObjectRef.key.id", PlanResource.class, "thePersistInfo.theObjectIdentifier.id");
        var1.appendWhere(var7, new int[]{var3, var4});
        var1.appendAnd();
        SearchCondition var8 = new SearchCondition(PlanActivity.class, "hasDeliverable", "TRUE");
        var1.appendWhere(var8, new int[]{var5});
        var1.appendAnd();
        SearchCondition var9 = new SearchCondition(PlanResource.class, "principalRef.key.id", "=", PersistenceHelper.getObjectIdentifier(var2).getId());
        var1.appendWhere(var9, new int[]{var4});
        var1.appendAnd();
        SearchCondition var10 = new SearchCondition(PlanActivity.class, "percentWorkComplete", "<>", 100.0D);
        var1.appendWhere(var10, new int[]{var5});
        if (logger.isDebugEnabled()) {
            logger.debug("OUT getEligiblePlansActivitiesForTrackNewWorkQuerySpec . QuerySpec" + var1);
        }

        return var1;
    }

    public WTCollection getEligiblePlansActivitiesForTrackNewWork(String var1) throws WTException {
        NmOid var2 = NmOid.newNmOid(var1);
        Plan var3 = (Plan) var2.getRefObject();
        boolean var4 = var3.isAutoExecution();
        QuerySpec var5 = new QuerySpec();
        int var6 = var5.appendClassList(PlanActivity.class, true);
        var5 = this.getEligiblePlansActivitiesForTrackNewWorkQuerySpec(var5);
        var5.appendAnd();
        SearchCondition var7 = new SearchCondition(PlanActivity.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var3));
        var5.appendWhere(var7, new int[]{var6});
        if (var4) {
            var5.appendAnd();
            SearchCondition var8 = new SearchCondition(PlanActivity.class, "plannableState", "=", PlannableState.INPROCESS);
            var5.appendWhere(var8, new int[]{var6});
        }

        if (logger.isDebugEnabled()) {
            logger.debug("getQueryForActivityPickerForTrackNewWork: querySpec : " + var5);
        }

        QueryResult var10 = PersistenceHelper.manager.find(var5);
        WTArrayList var9 = new WTArrayList();
        var9.addAll(var10);
        return var9;
    }

    public long[] getPlanActivitiesForNewActivity(String var1) throws WTException {
        int var2 = 0;
        NmOid var3 = NmOid.newNmOid(var1);
        Plan var4 = (Plan) var3.getRefObject();
        QuerySpec var5 = new QuerySpec();
        int var6 = var5.appendClassList(PlanActivity.class, false);
        ClassAttribute var7 = new ClassAttribute(PlanActivity.class, "thePersistInfo.theObjectIdentifier.id");
        var5.appendSelect(var7, new int[]{var6}, false);
        SearchCondition var8 = new SearchCondition(PlanActivity.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var4));
        var5.appendWhere(var8, new int[]{var6});
        var5.appendAnd();
        SearchCondition var9 = new SearchCondition(PlanActivity.class, "lineNumber", "<>", new Integer(0));
        var5.appendWhere(var9, new int[]{var6});
        if (logger.isDebugEnabled()) {
            logger.debug("getQueryForActivityPickerForNewActivity: querySpec : " + var5);
        }

        QueryResult var10 = PersistenceHelper.manager.find(var5);
        int var11 = var10.getObjectVectorIfc().getVector().size();
        Enumeration var12 = var10.getObjectVectorIfc().getVector().elements();
        Object var13 = null;
        if (var11 == 0) {
            return new long[0];
        } else {
            Object[] var14;
            long[] var15;
            for (var15 = new long[var11]; var12.hasMoreElements(); var15[var2++] = ((BigDecimal) var14[0]).longValue()) {
                var14 = (Object[]) ((Object[]) var12.nextElement());
            }

            return var15;
        }
    }

    private static WTCollection getNextImmediateActivitiesToStart(Plannable var0) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("getNextImmediateActivitiesToStart() ::: IN");
        }

        QuerySpec var1 = new QuerySpec();
        var1.setAdvancedQueryEnabled(true);
        int var2 = var1.appendClassList(PlanActivity.class, true);
        SearchCondition var3 = new SearchCondition(Plannable.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var0));
        var1.appendWhere(var3, new int[]{var2});
        var1.appendAnd();
        SearchCondition var4 = new SearchCondition(Plannable.class, "plannableState", "=", PlannableState.SCHEDULED);
        var1.appendWhere(var4, new int[]{var2});
        var1.appendAnd();
        new Timestamp(System.currentTimeMillis());
        SearchCondition var6 = new SearchCondition(PlanActivity.class, "startDate", ">=", new Timestamp(System.currentTimeMillis()));
        var1.appendWhere(var6, new int[]{var2});
        ClassAttribute var7 = new ClassAttribute(PlanActivity.class, "startDate");
        var1.appendOrderBy(new OrderBy(var7, false), new int[]{var2});
        UpcomingScheduledPlannablesResultProcessor var8 = new UpcomingScheduledPlannablesResultProcessor();
        if (logger.isDebugEnabled()) {
            logger.debug("query to get next set of earliest activities to start ::: " + var1);
        }

        PersistenceHelper.manager.find(var1, var8);
        WTArrayList var9 = new WTArrayList();
        var9.addAll(var8.getPlannables());
        if (logger.isDebugEnabled()) {
            logger.debug("Total number of earliest activities to start ::: " + var9.size());
        }

        if (logger.isDebugEnabled()) {
            logger.debug("getNextImmediateActivitiesToStart() ::: OUT");
        }

        return var9;
    }

    private static WTCollection getEligibleActivitiesToStart(Plannable var0) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("getEligibleActivitiesToStart() ::: IN");
        }

        QuerySpec var1 = new QuerySpec();
        int var2 = var1.appendClassList(PlanActivity.class, true);
        SearchCondition var3 = new SearchCondition(PlanActivity.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var0));
        var1.appendWhere(var3, new int[]{var2});
        var1.appendAnd();
        SearchCondition var4 = new SearchCondition(PlanActivity.class, "plannableState", "=", PlannableState.SCHEDULED);
        var1.appendWhere(var4, new int[]{var2});
        var1.appendAnd();
        Timestamp var7 = null;
        if (var0.getStartDate() != null) {
            var7 = new Timestamp(var0.getStartDate().getTime());
        } else {
            var7 = new Timestamp(System.currentTimeMillis() - 86400000L);
        }

        Timestamp var8 = new Timestamp(System.currentTimeMillis() + 86400000L);
        SearchCondition var9 = new SearchCondition(PlanActivity.class, "startDate", true, new AttributeRange(var7, var8));
        var1.appendWhere(var9, new int[]{var2});
        if (logger.isDebugEnabled()) {
            logger.debug("QuerySpec to start activities NOW == " + var1);
        }

        QueryResult var10 = PersistenceHelper.manager.find(var1);
        WTArrayList var11 = new WTArrayList();
        var11.addAll(var10);
        if (logger.isDebugEnabled()) {
            logger.debug("Total Activities to start NOW == " + var11.size());
        }

        if (logger.isDebugEnabled()) {
            logger.debug("getEligibleActivitiesToStart() ::: OUT");
        }

        return var11;
    }

    private static Enumeration getStaleSchedItemsWithItemName(String var0) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("getStaleSchedItemsWithItemName() ::: IN");
        }

        Object var1 = null;
        QuerySpec var2 = new QuerySpec();
        var2.appendClassList(ScheduleItem.class, true);
        var2.setQueryLimit(DELETE_SCHEDULEDPLANNABLES_ITEMS_LIMIT);
        if (logger.isDebugEnabled()) {
            logger.debug("DELETE_SCHEDULEDPLANNABLES_ITEMS_LIMIT = " + DELETE_SCHEDULEDPLANNABLES_ITEMS_LIMIT);
        }

        SearchCondition var3 = new SearchCondition(ScheduleItem.class, "itemName", "LIKE", var0 + "%");
        var2.appendWhere(var3, new int[]{0});

        try {
            var1 = SchedulingHelper.service.getScheduleItems(var2);
        } catch (PartialResultException var5) {
            var1 = var5.getQueryResult();
            logger.debug(var5);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("getStaleSchedItemsWithItemName() ::: OUT");
        }

        return (Enumeration) var1;
    }

    private static void removeStaleSchedItemsWithItemName(String var0) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("removeStaleSchedItemsWithItemName() ::: IN");
        }

        SessionContext var1 = SessionContext.newContext();
        SessionHelper.manager.setAdministrator();

        ScheduleItem var4;
        try {
            for (Enumeration var2 = getStaleSchedItemsWithItemName(var0); var2.hasMoreElements(); SchedulingHelper.service.removeItem(var4)) {
                Object var3 = var2.nextElement();
                var4 = null;
                if (var3 instanceof ScheduleItem) {
                    var4 = (ScheduleItem) var3;
                } else {
                    var4 = (ScheduleItem) ((Object[]) ((Object[]) var3))[0];
                }
            }
        } finally {
            SessionContext.setContext(var1);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("removeStaleSchedItemsWithItemName() ::: OUT");
        }

    }

    private QuerySpec getLeafActivitiesQuerySpec(Plannable var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PlanActivity.class, true);
        ObjectIdentifier var4 = PersistenceHelper.getObjectIdentifier(var1);
        String var5 = null;
        if (var1 instanceof Plan) {
            var5 = "rootReference.key";
        } else {
            var5 = "parentReference.key";
        }

        SearchCondition var6 = new SearchCondition(PlanActivity.class, var5, "=", var4);
        var2.appendWhere(var6, new int[]{var3});
        var2.appendAnd();
        SearchCondition var7 = new SearchCondition(Plannable.class, "summary", "FALSE");
        var2.appendWhere(var7, new int[]{var3});
        return var2;
    }

    public WTCollection getLeafActivitiesForSummary(Plannable var1) throws WTException {
        QuerySpec var2 = this.getLeafActivitiesQuerySpec(var1);
        WTArrayList var3 = new WTArrayList();
        var3.addAll(PersistenceHelper.manager.find(var2));
        return var3;
    }

    public HashMap<String, WTArrayList> getScheduledDeliverablesWithAutomaticCalculationMode(Plannable var1) throws WTException {
        HashMap var2 = new HashMap();
        WTArrayList var3 = new WTArrayList();
        var3.add(var1);
        WTKeyedHashMap var4 = this.getScheduleDeliverableLeafActivitiesForSummary(var3);
        WTArrayList var5 = new WTArrayList();
        WTArrayList var6 = new WTArrayList();
        WTArrayList var7 = new WTArrayList();
        if (var4 != null && var4.size() > 0) {
            WTArrayList var8 = (WTArrayList) var4.get(ObjectReference.newObjectReference(var1));
            Iterator var9 = var8.persistableIterator();

            label52:
            while (true) {
                while (true) {
                    if (!var9.hasNext()) {
                        break label52;
                    }

                    PlanActivity var10 = (PlanActivity) var9.next();
                    if (var10.isStatusUpdateModeAutomatic() && var10.isDeadlineCalculationModeAutomatic()) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("Activity which is eligible for Deadline & Health Status recalculation: " + var10);
                        }

                        var5.add(var10);
                    } else if (var10.isStatusUpdateModeAutomatic()) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("Activity which is eligible for Health Status recalculation: " + var10);
                        }

                        var6.add(var10);
                    } else if (var10.isDeadlineCalculationModeAutomatic()) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("Activity which is eligible for Deadline recalculation: " + var10);
                        }

                        var7.add(var10);
                    }
                }
            }
        }

        if (!var5.isEmpty()) {
            var2.put("DeadlineAndHealthStatusAutoModeActivities", var5);
        }

        if (!var6.isEmpty()) {
            var2.put("HealthStatusAutoModeActivities", var6);
        }

        if (!var7.isEmpty()) {
            var2.put("DeadlineAutoModeActivities", var7);
        }

        return var2;
    }

    public void invokeCalculateDeadlineAndHealthStatusForAutoModeActivities(HashMap<String, WTArrayList> var1) throws WTException, WTPropertyVetoException {
        if (var1.containsKey("DeadlineAndHealthStatusAutoModeActivities")) {
            EPPCustomEventHandlerHelper.service.calculateDeadlineAndHealthStatus((WTCollection) var1.get("DeadlineAndHealthStatusAutoModeActivities"), (Object) null);
        }

        if (var1.containsKey("HealthStatusAutoModeActivities")) {
            EPPCustomEventHandlerHelper.service.calculateHealthStatus((WTCollection) var1.get("HealthStatusAutoModeActivities"), (Object) null);
        }

        if (var1.containsKey("DeadlineAutoModeActivities")) {
            EPPCustomEventHandlerHelper.service.calculateDeadline((WTCollection) var1.get("DeadlineAutoModeActivities"), (Object) null);
        }

    }

    public WTKeyedHashMap getScheduleDeliverableLeafActivitiesForSummary(WTCollection var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("getScheduleDeliverableLeafActivitiesForSummary() ::: IN");
        }

        WTKeyedHashMap var2 = new WTKeyedHashMap();
        int var3 = 0;
        int var4 = 0;
        if (var1 != null && var1.isEmpty()) {
            return var2;
        } else {
            long[] var5 = new long[var1.subCollection(PlanActivity.class, true).size()];
            long[] var6 = new long[var1.subCollection(Plan.class, true).size()];
            if (logger.isDebugEnabled()) {
                logger.debug("Size of summary activities collection" + var5);
                logger.debug("Size of plan collection" + var6);
            }

            Persistable var7 = null;
            Iterator var8 = var1.persistableIterator();

            while (var8.hasNext()) {
                var7 = (Persistable) var8.next();
                if (var7 instanceof Plan) {
                    var6[var4++] = PersistenceHelper.getObjectIdentifier(var7).getId();
                } else {
                    var5[var3++] = PersistenceHelper.getObjectIdentifier(var7).getId();
                }
            }

            QuerySpec var9 = new QuerySpec();
            var9.setAdvancedQueryEnabled(true);
            int var10 = var9.appendClassList(PlanActivity.class, true);
            String var11 = "rootReference.key.id";
            String var12 = "parentReference.key.id";
            SearchCondition var13 = new SearchCondition(Plannable.class, "summary", "FALSE");
            var9.appendWhere(var13, new int[]{var10});
            var9.appendAnd();
            SearchCondition var14 = new SearchCondition(PlanActivity.class, "hasDeliverable", "TRUE");
            var9.appendWhere(var14, new int[]{0});
            var9.appendAnd();
            SearchCondition var15 = new SearchCondition(PlanActivity.class, "percentWorkComplete", "<>", 100.0D);
            var9.appendWhere(var15, new int[]{0});
            var9.appendAnd();
            var9.appendOpenParen();
            SearchCondition var16;
            if (var6.length > 0) {
                var16 = new SearchCondition(new ClassAttribute(PlanActivity.class, var11), "IN", new ArrayExpression(var6));
                var9.appendWhere(var16, new int[]{var10});
                if (var5.length > 0) {
                    var9.appendOr();
                }
            }

            if (var5.length > 0) {
                var16 = new SearchCondition(new ClassAttribute(PlanActivity.class, var12), "IN", new ArrayExpression(var5));
                var9.appendWhere(var16, new int[]{var10});
            }

            var9.appendCloseParen();
            QueryResult var21 = PersistenceServerHelper.manager.query(var9);
            new ObjectReference();
            new WTArrayList();
            new WTArrayList();

            while (var21.hasMoreElements()) {
                PlanActivity var20 = (PlanActivity) ((Persistable[]) ((Persistable[]) var21.nextElement()))[0];
                ObjectReference var17 = var20.getRootReference();
                if (var1.contains(var17)) {
                    WTArrayList var18 = (WTArrayList) var2.get(var17);
                    if (var18 == null) {
                        var18 = new WTArrayList();
                    }

                    if (logger.isDebugEnabled()) {
                        logger.debug("Leaf activities for Plan: " + var20);
                    }

                    var18.add(var20);
                    var2.put(var20.getRootReference(), var18);
                }

                var17 = var20.getParentReference();
                if (var1.contains(var17)) {
                    WTArrayList var19 = (WTArrayList) var2.get(var17);
                    if (var19 == null) {
                        var19 = new WTArrayList();
                    }

                    if (logger.isDebugEnabled()) {
                        logger.debug("Leaf activities for Summary: " + var20);
                    }

                    var19.add(var20);
                    var2.put(var20.getParentReference(), var19);
                }
            }

            if (logger.isDebugEnabled()) {
                logger.debug("getScheduleDeliverableLeafActivitiesForSummary() ::: OUT");
            }

            return var2;
        }
    }

    public WTKeyedHashMap getSummaryActivities(WTCollection var1) throws WTException {
        logger.debug("StandardPlannableService.getSummaryActivities ::: START");
        long[] var2 = new long[var1.size()];
        List var3 = null;
        if (var1 != null && var1.size() > 0) {
            var3 = Lists.toList(var1);
            var2 = PlannableUtils.getOids(var3);
        }

        logger.debug("activityOids = " + var2);
        QuerySpec var4 = new QuerySpec();
        var4.setAdvancedQueryEnabled(true);
        int var5 = var4.appendClassList(PlanActivity.class, false);
        var4.appendSelectAttribute("thePersistInfo.theObjectIdentifier.id", var5, false);
        int var6 = var4.appendClassList(PlanActivity.class, true);
        SearchCondition var7 = new SearchCondition(PlanActivity.class, "parentReference.key.id", PlanActivity.class, "thePersistInfo.theObjectIdentifier.id");
        var4.appendWhere(var7, new int[]{var5, var6});
        var4.appendAnd();
        SearchCondition var8 = new SearchCondition(new ClassAttribute(PlanActivity.class, "thePersistInfo.theObjectIdentifier.id"), "IN", new ArrayExpression(var2));
        var4.appendWhere(var8, new int[]{var5});
        QueryResult var9 = PersistenceServerHelper.manager.query(var4);
        WTKeyedHashMap var10 = new WTKeyedHashMap();
        Enumeration var11 = var9.getEnumeration();

        while (var11.hasMoreElements()) {
            Object[] var12 = (Object[]) ((Object[]) var11.nextElement());
            logger.debug("StandardPlannableService.getSummaryActivities ::: row = " + var12[0].toString() + "::" + var12[1]);
            var10.put(ObjectIdentifier.newObjectIdentifier(PlanActivity.class.getName(), (new BigDecimal(var12[0].toString())).longValue()), (PlanActivity) var12[1]);
        }

        logger.debug("StandardPlannableService.getSummaryActivities ::: END");
        return var10;
    }

    public WTKeyedHashMap getParentPlannables(WTCollection var1) throws WTException {
        boolean var2 = logger.isDebugEnabled();
        if (var2) {
            logger.debug("getParentPlannables() : IN");
        }

        WTKeyedHashMap var3 = new WTKeyedHashMap();
        HashMap var4 = new HashMap();
        Iterator var5 = var1.persistableIterator();

        while (var5.hasNext()) {
            Object var6 = var5.next();
            if (var6 instanceof Persistable) {
                var4.put(((Persistable) var6).getPersistInfo().getObjectIdentifier().getId(), ((Persistable) var6).getPersistInfo().getObjectIdentifier());
            }
        }

        if (var2) {
            logger.debug("idObjectChildMap = " + var4);
        }

        QuerySpec var12 = getQuerySpecForParentPlannables(var4);
        if (var2) {
            logger.debug("querySpec = " + var12);
        }

        QueryResult var7 = PersistenceServerHelper.manager.query(var12);

        Hierarchical var10;
        for (ObjectIdentifier var8 = null; var7.hasMoreElements(); var3.put(var8, var10)) {
            Object[] var9 = (Object[]) ((Object[]) var7.nextElement());
            var10 = (Hierarchical) var9[0];
            if (var2) {
                logger.debug("parentObj = " + var10);
            }

            BigDecimal var11 = (BigDecimal) var9[1];
            if (var2) {
                logger.debug("childId = " + var11);
            }

            var8 = (ObjectIdentifier) var4.get(var11.longValue());
            if (var2) {
                logger.debug("childObject = " + var8);
            }
        }

        if (var2) {
            logger.debug("getParentPlannables() : OUT");
        }

        return var3;
    }

    private static QuerySpec getQuerySpecForParentPlannables(HashMap var0) throws QueryException {
        boolean var1 = logger.isDebugEnabled();
        if (var1) {
            logger.debug("getQuerySpecForParentPlannables() : IN ");
        }

        if (var1) {
            logger.debug("idObjectChildMap = " + var0 + "\t size = " + var0.size());
        }

        QuerySpec var2 = new QuerySpec();
        var2.setAdvancedQueryEnabled(true);
        int var3 = var2.appendClassList(Hierarchical.class, true);
        int var4 = var2.appendClassList(Hierarchical.class, false);
        var2.appendSelectAttribute("thePersistInfo.theObjectIdentifier.id", var4, false);
        SearchCondition var5 = new SearchCondition(Hierarchical.class, "thePersistInfo.theObjectIdentifier.id", Hierarchical.class, "parentReference.key.id");
        var2.appendWhere(var5, new int[]{var3, var4});
        var2.appendAnd();
        SearchCondition var6 = new SearchCondition(new ClassAttribute(PlanActivity.class, "thePersistInfo.theObjectIdentifier.id"), "IN", new ArrayExpression(var0.keySet().toArray()));
        var2.appendWhere(var6, new int[]{var4});
        if (var1) {
            logger.debug("getQuerySpecForParentPlannables() : OUT ");
        }

        return var2;
    }

    public WTKeyedHashMap getChildActivities(WTCollection var1, HashSet<String> var2, HashSet<PlannableState> var3) throws WTException {
        boolean var4 = logger.isDebugEnabled();
        if (var4) {
            logger.debug("getChildActivities() : IN ");
        }

        WTKeyedHashMap var5 = new WTKeyedHashMap();
        if (var1 != null && var1.isEmpty()) {
            if (logger.isDebugEnabled()) {
                logger.debug("parentCollection is Empty ");
            }

            return var5;
        } else {
            HashMap var6 = new HashMap();
            new ObjectIdentifier();
            Iterator var8 = var1.persistableIterator();

            while (var8.hasNext()) {
                Object var9 = var8.next();
                if (var9 instanceof Persistable) {
                    ObjectIdentifier var7 = ((Persistable) var9).getPersistInfo().getObjectIdentifier();
                    if (logger.isDebugEnabled()) {
                        logger.debug("objectIdentifier  = " + var7);
                    }

                    var6.put(var7.getId(), var7);
                }
            }

            if (logger.isDebugEnabled()) {
                logger.debug("idObjectParentMap()  = " + var6 + "\t size = " + var6.size());
            }

            QuerySpec var18 = getQuerySpecChildren(var1, var3);
            if (logger.isDebugEnabled()) {
                logger.debug("querySpec  = " + var18);
            }

            QueryResult var10 = PersistenceHelper.manager.find(var18);
            if (logger.isDebugEnabled()) {
                logger.debug("parentChildResult  = " + var10.size());
            }

            new WTArrayList();
            new ObjectIdentifier();

            WTArrayList var11;
            ObjectIdentifier var12;
            for (Hierarchical var13 = null; var10.hasMoreElements(); var5.put(var12, var11)) {
                var11 = new WTArrayList();
                Object[] var14 = (Object[]) ((Object[]) var10.nextElement());
                var13 = (Hierarchical) var14[0];
                TypeIdentifier var15 = OidHelper.getTypeIdentifier(var13);
                String var16 = var15.getTypeInternalName();
                if (logger.isDebugEnabled()) {
                    logger.debug("childObject = " + var13 + "\t type" + var16);
                }

                BigDecimal var17 = (BigDecimal) var14[1];
                if (logger.isDebugEnabled()) {
                    logger.debug("parentId = " + var17);
                }

                var12 = (ObjectIdentifier) var6.get(var17.longValue());
                if (logger.isDebugEnabled()) {
                    logger.debug("parentObjectIdentifier = " + var12);
                }

                if (var2 == null || var2.isEmpty() || var2.contains(var16)) {
                    var11 = (WTArrayList) var5.get(var12);
                    if (var11 == null) {
                        var11 = new WTArrayList();
                    }

                    var11.add(var13);
                    if (logger.isDebugEnabled()) {
                        logger.debug("childObject = " + var13);
                    }
                }
            }

            if (logger.isDebugEnabled()) {
                logger.debug("parentChildMap() =  " + var5 + "\t size = " + var5.size());
            }

            if (logger.isDebugEnabled()) {
                logger.debug("getChildActivities() : OUT ");
            }

            return var5;
        }
    }

    private static QuerySpec getQuerySpecChildren(WTCollection var0, HashSet<PlannableState> var1) throws QueryException {
        if (logger.isDebugEnabled()) {
            logger.debug("getQuerySpecChildren() : IN ");
        }

        QuerySpec var2 = new QuerySpec();
        var2.setAdvancedQueryEnabled(true);
        int var3 = var2.appendClassList(Plannable.class, true);
        var2.appendSelectAttribute("parentReference.key.id", var3, false);
        SearchCondition var4 = new SearchCondition(new ClassAttribute(Plannable.class, "parentReference.key.id"), "IN", new ArrayExpression(var0.toIdArray()));
        var2.appendWhere(var4, new int[]{var3});
        var2.appendAnd();
        var2.appendWhere(new SearchCondition(Plannable.class, "lineNumber", "<>", 0), new int[]{var3});
        if (logger.isDebugEnabled()) {
            logger.debug("plannableStates =  " + var1);
        }

        if (var1 != null && !var1.isEmpty()) {
            if (logger.isDebugEnabled()) {
                logger.debug("appending plannable state criteria =  ");
            }

            ArrayList var5 = new ArrayList();
            String var6 = "";
            Iterator var7 = var1.iterator();

            while (var7.hasNext()) {
                var6 = var7.next().toString();
                var5.add(var6);
                if (logger.isDebugEnabled()) {
                    logger.debug("appending plannable state criteria =  " + var6);
                }
            }

            SearchCondition var8 = new SearchCondition(new ClassAttribute(Plannable.class, "plannableState"), "IN", new ArrayExpression(var5.toArray(new String[var5.size()])));
            var2.appendAnd();
            var2.appendWhere(var8, new int[]{var3});
        }

        if (logger.isDebugEnabled()) {
            logger.debug("querySpec() =  " + var2);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("getQuerySpecChildren() : OUT ");
        }

        return var2;
    }

    public HashMap<Long, WTCollection> getMapOfDeliverablesLinkedWithActivitiesForContainer(WTContainer var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PlanActivity.class, false);
        int var4 = var2.appendClassList(PlanDeliverable.class, true);

        try {
            var2.setDescendantsIncluded(false, var4);
        } catch (WTPropertyVetoException var12) {
            logger.error("Error while seting DescendantsIncluded to false" + var12.getMessage());
            var12.printStackTrace();
        }

        int var5 = var2.appendClassList(PlanDeliverableLink.class, false);
        var2.appendSelectAttribute("roleAObjectRef.key.id", var5, false);
        var2.appendWhere(new SearchCondition(PlanActivity.class, "containerReference.key", "=", PersistenceHelper.getObjectIdentifier(var1)), new int[]{0});
        var2.appendJoin(var5, "roleAObject", var3);
        var2.appendJoin(var5, "roleBObject", var4);
        QueryResult var6 = PersistenceHelper.manager.find(var2);
        HashMap var7 = new HashMap();

        while (var6.hasMoreElements()) {
            Object[] var8 = (Object[]) ((Object[]) var6.nextElement());
            PlanDeliverable var9 = (PlanDeliverable) var8[0];
            BigDecimal var10 = (BigDecimal) var8[1];
            Object var11 = (WTCollection) var7.get(var10.longValue());
            if (var11 == null) {
                var11 = new WTHashSet();
            }

            ((WTCollection) var11).add(var9);
            var7.put(var10.longValue(), var11);
        }

        return var7;
    }

    public HashMap<Long, WTCollection> getMapOfDeliverablesLinkedWithActivitiesForBaselinedPlan(BaselinedPlan var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(BaselinedPlanActivity.class, false);
        int var4 = var2.appendClassList(BaselinedPlanDeliverable.class, true);
        int var5 = var2.appendClassList(PlanDeliverableLink.class, false);
        var2.appendSelectAttribute("roleAObjectRef.key.id", var5, false);
        var2.appendWhere(new SearchCondition(BaselinedPlanActivity.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1)), new int[]{0});
        var2.appendJoin(var5, "roleAObject", var3);
        var2.appendJoin(var5, "roleBObject", var4);
        QueryResult var6 = PersistenceHelper.manager.find(var2);
        HashMap var7 = new HashMap();

        while (var6.hasMoreElements()) {
            Object[] var8 = (Object[]) ((Object[]) var6.nextElement());
            BaselinedPlanDeliverable var9 = (BaselinedPlanDeliverable) var8[0];
            BigDecimal var10 = (BigDecimal) var8[1];
            Object var11 = (WTCollection) var7.get(var10.longValue());
            if (var11 == null) {
                var11 = new WTHashSet();
            }

            ((WTCollection) var11).add(var9);
            var7.put(var10.longValue(), var11);
        }

        return var7;
    }

    public HashMap<Long, WTCollection> getMapOfDeliverablesLinkedWithActivitiesForPlan(Plan var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PlanActivity.class, false);
        int var4 = var2.appendClassList(PlanDeliverable.class, true);

        try {
            var2.setDescendantsIncluded(false, var4);
        } catch (WTPropertyVetoException var12) {
            logger.error("Error while seting DescendantsIncluded to false" + var12.getMessage());
            var12.printStackTrace();
        }

        int var5 = var2.appendClassList(PlanDeliverableLink.class, false);
        var2.appendSelectAttribute("roleAObjectRef.key.id", var5, false);
        var2.appendWhere(new SearchCondition(PlanActivity.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1)), new int[]{0});
        var2.appendJoin(var5, "roleAObject", var3);
        var2.appendJoin(var5, "roleBObject", var4);
        QueryResult var6 = PersistenceHelper.manager.find(var2);
        HashMap var7 = new HashMap();

        while (var6.hasMoreElements()) {
            Object[] var8 = (Object[]) ((Object[]) var6.nextElement());
            PlanDeliverable var9 = (PlanDeliverable) var8[0];
            BigDecimal var10 = (BigDecimal) var8[1];
            Object var11 = (WTCollection) var7.get(var10.longValue());
            if (var11 == null) {
                var11 = new WTHashSet();
            }

            ((WTCollection) var11).add(var9);
            var7.put(var10.longValue(), var11);
        }

        return var7;
    }

    static {
        logger = LogR.getLogger(CLASSNAME);

        try {
            WTProperties var0 = WTProperties.getLocalProperties();
            NOTIFICATION_SENDER = var0.getProperty("wt.notify.notificationSenderEmail");
            CALCULATE_CRITICAL_PATH = var0.getProperty("wt.projmgmt.plan.calculateCriticalPath", "true");
            CREATE_SCHEDULEDPLANNABLES_ITEMS_LIMIT = var0.getProperty("com.ptc.projectmanagement.plannable.createScheduledPlannableItems.limit", 2);
            DELETE_SCHEDULEDPLANNABLES_ITEMS_LIMIT = var0.getProperty("com.ptc.projectmanagement.plannable.deleteScheduledPlannableItems.limit", 10);
            filterOnServerSide = var0.getProperty("com.ptc.projectmanagement.filterOnServerSide", false);
        } catch (Throwable var1) {
            if (logger.isDebugEnabled()) {
                logger.error("Error initializing " + StandardPlannableService.class.getName(), var1);
                logger.debug(var1.getLocalizedMessage(), var1);
            }

            throw new ExceptionInInitializerError(var1);
        }
    }

    class PlannableHistoryResolutionListener extends ServiceEventListenerAdapter {
        public PlannableHistoryResolutionListener(String var2) {
            super(var2);
        }

        public void notifyVetoableEvent(Object var1) throws Exception {
            if (var1 instanceof KeyedEvent) {
                KeyedEvent var2 = (KeyedEvent) var1;
                if (Transaction.getCurrentTransaction() != null) {
                    HistoryServiceTransactionListener.getTransactionListener().addOtherEvent(var2);
                } else {
                    HistoryResolutionProcessor.processEvent(var2);
                }
            }

        }
    }
}
