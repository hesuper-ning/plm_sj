//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.projectmanagement.assignment.resource;

import com.ptc.netmarkets.product.NmProductHelper;
import com.ptc.netmarkets.project.NmProjectHelper;
import com.ptc.projectmanagement.assignment.*;
import com.ptc.projectmanagement.assignment.resource.baseline.BaselinedPlanResource;
import com.ptc.projectmanagement.cost.CostHelper;
import com.ptc.projectmanagement.cost.CostTrackable;
import com.ptc.projectmanagement.plan.*;
import com.ptc.projectmanagement.plannable.PlannableHelper;
import com.ptc.projectmanagement.plannable.Rootable;
import com.ptc.projectmanagement.plannable.ScheduleUtils;
import com.ptc.projectmanagement.util.AccessControlUtils;
import com.ptc.projectmanagement.util.AdminUtils;
import com.ptc.projectmanagement.util.PlannableUtils;
import com.ptc.projectmanagement.util.ResourceUtils;
import org.apache.log4j.Logger;
import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.events.KeyedEvent;
import wt.fc.*;
import wt.fc.collections.*;
import wt.fc.delete.DeleteHelper;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.team.*;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.notify.WTDistributionList;
import wt.org.*;
import wt.ownership.OwnershipException;
import wt.ownership.OwnershipServerHelper;
import wt.pdmlink.PDMLinkProduct;
import wt.pom.Transaction;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.execution.ProjectPlan;
import wt.query.*;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.team.StandardTeamService;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;

import java.io.Serializable;
import java.util.*;
import java.util.Map.Entry;

public class StandardResourceService extends StandardManager implements ResourceService, Serializable {
    private static final long serialVersionUID = 1L;
    private static final String RESOURCE = "com.ptc.projectmanagement.assignment.resource.resourceResource";
    private static final String CLASSNAME = StandardResourceService.class.getName();
    private static final Logger log;
    private static final String ROLE_GROUPS_REMOVED_FROM_TEAM = "ROLE_GROUPS_REMOVED_FROM_TEAM";

    public StandardResourceService() {
    }

    /**
     * @deprecated
     */
    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public static StandardResourceService newStandardResourceService() throws WTException {
        StandardResourceService var0 = new StandardResourceService();
        var0.initialize();
        return var0;
    }

    public WTCollection getResources(WTContainerRef var1) throws WTException {
        QuerySpec var2 = this.getResourcesQuerySpec(var1, true);
        QueryResult var3 = PersistenceHelper.manager.find(var2);
        WTArrayList var4 = new WTArrayList();
        var4.addAll(var3);
        return var4;
    }

    /**
     * @deprecated
     */
    @Deprecated
    public WTCollection getResources(Rootable var1) throws WTException {
        return this.getResources(((WTContained) var1).getContainerReference());
    }

    private QuerySpec getResourcesQuerySpec(WTContainerRef var1, boolean var2) throws QueryException, WTException {
        QuerySpec var3 = new QuerySpec();
        int var4 = var3.appendClassList(PlanResource.class, true);
        if (var2) {
            try {
                var3.setDescendantsIncluded(false, var4);
            } catch (WTPropertyVetoException var9) {
                log.debug("getResources:- Error occurred while getting resources for container..");
                throw new WTException(var9);
            }
        }

        long var5 = ((ObjectIdentifier) var1.getKey()).getId();
        SearchCondition var7 = new SearchCondition(Resourceable.class, "containerReference.key.id", "=", var5);
        var3.appendWhere(var7, new int[]{0});
        ClassAttribute var8 = new ClassAttribute(Resourceable.class, "name");
        var3.appendOrderBy(new OrderBy(var8, false), new int[]{var4});
        return var3;
    }

    /**
     * @deprecated
     */
    @Deprecated
    private QuerySpec getResourcesQuerySpec(Rootable var1) throws QueryException, WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(Resourceable.class, true);
        long var4 = ((ObjectIdentifier) ((WTContained) var1).getContainerReference().getKey()).getId();
        SearchCondition var6 = new SearchCondition(Resourceable.class, "containerReference.key.id", "=", var4);
        var2.appendWhere(var6, new int[]{0});
        ClassAttribute var7 = new ClassAttribute(Resourceable.class, "name");
        var2.appendOrderBy(new OrderBy(var7, false), new int[]{var3});
        return var2;
    }

    public WTCollection getAssignableResources(WTContainerRef var1, Resourceable var2) throws WTException {
        QuerySpec var3 = this.getResourcesQuerySpec(var1, true);
        var3.appendAnd();
        SearchCondition var4 = new SearchCondition(Resourceable.class, "thePersistInfo.theObjectIdentifier", "<>", PersistenceHelper.getObjectIdentifier(var2));
        var3.appendWhere(var4, new int[]{0});
        QueryResult var5 = PersistenceHelper.manager.find(var3);
        WTArrayList var6 = new WTArrayList();
        var6.addAll(var5);
        return var6;
    }

    /**
     * @deprecated
     */
    @Deprecated
    public WTCollection getAssignableResources(Rootable var1, Resourceable var2) throws WTException {
        QuerySpec var3 = this.getResourcesQuerySpec(var1);
        var3.appendAnd();
        SearchCondition var4 = new SearchCondition(Resourceable.class, "thePersistInfo.theObjectIdentifier", "<>", PersistenceHelper.getObjectIdentifier(var2));
        var3.appendWhere(var4, new int[]{0});
        QueryResult var5 = PersistenceHelper.manager.find(var3);
        WTArrayList var6 = new WTArrayList();
        var6.addAll(var5);
        return var6;
    }

    public PlanResource createResource(String var1, WTContainerRef var2) throws WTException {
        PlanResource var3 = PlanResource.newPlanResource(var2);

        try {
            var3.setName(var1);
        } catch (WTPropertyVetoException var5) {
            throw new WTException(var5);
        }

        var3.setDomainRef(AdminUtils.getAdministrativeSystemDomainRef(var3.getContainerReference()));
        var3 = (PlanResource) this.saveResourceable(var3);
        return var3;
    }

    public Resourceable addResource(Resourceable var1, WTContainerRef var2) throws WTException {
        ((PlanResource) var1).setDomainRef(AdminUtils.getAdministrativeSystemDomainRef(var2));
        return var1;
    }

    /**
     * @deprecated
     */
    @Deprecated
    public Resourceable addResource(Resourceable var1, Rootable var2) throws WTException {
        try {
            ((PlanResource) var1).setDomainRef(AdminUtils.getAdministrativeSystemDomainRef(var1.getContainerReference()));
            var1.setRoot(var2);
            return var1;
        } catch (WTPropertyVetoException var4) {
            throw new WTException(var4);
        }
    }

    public WTCollection addResources(WTCollection var1, WTContainerRef var2) throws WTException {
        WTHashSet var3 = new WTHashSet();

        Resourceable var6;
        for (Iterator var4 = var1.iterator(); var4.hasNext(); var3.add(var6)) {
            ObjectReference var5 = (ObjectReference) var4.next();
            var6 = (Resourceable) var5.getObject();

            try {
                var6.setContainerReference(var2);
                ((PlanResource) var6).setDomainRef(AdminUtils.getAdministrativeSystemDomainRef(var6.getContainerReference()));
            } catch (WTPropertyVetoException var8) {
                throw new WTException(var8);
            }
        }

        return var3;
    }

    /**
     * @deprecated
     */
    @Deprecated
    public WTCollection addResources(WTCollection var1, Rootable var2) throws WTException {
        WTHashSet var3 = new WTHashSet();

        Resourceable var6;
        for (Iterator var4 = var1.iterator(); var4.hasNext(); var3.add(var6)) {
            ObjectReference var5 = (ObjectReference) var4.next();
            var6 = (Resourceable) var5.getObject();
            WTContainerRef var7 = ((Plannable) var2).getContainerReference();

            try {
                var6.setContainerReference(var7);
                ((PlanResource) var6).setDomainRef(AdminUtils.getAdministrativeSystemDomainRef(var6.getContainerReference()));
                var6.setRoot(var2);
            } catch (WTPropertyVetoException var9) {
                throw new WTException(var9);
            }
        }

        return var3;
    }

    private void createResourceInContainer(WTContainerRef var1, WTUser var2) throws WTException {
        boolean var3 = log.isDebugEnabled();
        Transaction var4 = new Transaction();
        boolean var5 = SessionServerHelper.manager.setAccessEnforced(false);

        try {
            var4.start();
            if (this.getResources((WTContainerRef) var1, (WTPrincipal) var2, ResourceUserType.WINDCHILL_USER).size() == 0) {
                this.createResource((WTPrincipal) var2, var1);
                if (var3) {
                    log.debug("createResourceInProject...Created plan resource for wtUser:" + var2.getName() + ", plan name: " + var1.getName());
                }
            }

            var4.commit();
            var4 = null;
        } finally {
            SessionServerHelper.manager.setAccessEnforced(var5);
            if (var4 != null) {
                var4.rollback();
            }

        }

    }

    protected void performStartupProcess() throws ManagerException {
        //luojb custom

        //注释OOTB资源变化的监听
        if (true) return;

        super.performStartupProcess();
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("Entered PRE_DELETE listener.");
                }

                Boolean var2 = (Boolean) MethodContext.getContext().get("SKIP_DELETE_LISTENER");
                if (var2 == null || var2.equals(Boolean.FALSE)) {
                    PersistenceManagerEvent var3 = (PersistenceManagerEvent) var1;
                    WTCollection var4 = (WTCollection) var3.getEventTarget();
                    WTCollection var5 = var4.subCollection(Resourceable.class, true);
                    ArrayList var6 = new ArrayList(var5.persistableCollection());
                    WTHashSet var7 = new WTHashSet();
                    HashMap var8 = new HashMap();
                    WTContainerRef var9 = null;
                    Object var10 = null;

                    Resourceable var12;
                    PlanResource var14;
                    for (int var11 = 0; var11 < var6.size(); ++var11) {
                        var12 = (Resourceable) var6.get(var11);
                        if (StandardResourceService.log.isDebugEnabled()) {
                            StandardResourceService.log.debug("Resource Name: " + var12.getName() + " Resource Object: " + var12);
                        }

                        if (!(var12 instanceof BaselinedPlanResource)) {
                            WTCollection var13 = AssignmentHelper.service.getResourceAssignments(var12);
                            var7.addAll(var13);
                            if (var12 instanceof PlanResource) {
                                var14 = (PlanResource) var12;
                                if (var14.isGroupResource() || var14.isRoleResource()) {
                                    var9 = var14.getContainerReference();
                                    var10 = (WTCollection) var8.get(var9);
                                    if (var10 == null) {
                                        var10 = new WTArrayList();
                                        var8.put(var9, var10);
                                    }

                                    ((WTCollection) var10).add(var14.getPrincipalRef().getObject());
                                }
                            }
                        }
                    }

                    if (StandardResourceService.log.isDebugEnabled()) {
                        StandardResourceService.log.debug("containerRef2groups: " + var8);
                    }

                    if (!var8.isEmpty()) {
                        WTCollection var30 = null;
                        Iterator var31 = var8.keySet().iterator();

                        while (var31.hasNext()) {
                            var9 = (WTContainerRef) var31.next();
                            var30 = AssignmentHelper.service.getAssignmentsForAssignmentGroups((WTCollection) var8.get(var9), var9);
                            if (var30 != null && !var30.isEmpty()) {
                                var7.addAll(var30);
                            }
                        }
                    }

                    if (StandardResourceService.log.isDebugEnabled()) {
                        StandardResourceService.log.debug("matchingAssignments: " + var7);
                    }

                    if (var7.size() > 0) {
                        MethodContext.getContext().put("hasAssignments", Boolean.TRUE);
                    }

                    HashMap var32 = new HashMap();
                    var12 = null;
                    Iterator var34 = var7.persistableIterator();

                    PlanActivity var15;
                    while (var34.hasNext()) {
                        ResourceAssignment var35 = (ResourceAssignment) var34.next();
                        if (StandardResourceService.log.isDebugEnabled()) {
                            StandardResourceService.log.debug("tempAssgn: " + var35);
                        }

                        if (var35.isAcceptedAssignment()) {
                            if (StandardResourceService.log.isDebugEnabled()) {
                                StandardResourceService.log.debug("Accepted Pool Assignment found. Converting to standard assignment.");
                            }

                            var35 = StandardResourceService.this.convertToStandardAssignment(var35);
                            var35 = (ResourceAssignment) PersistenceHelper.manager.save(var35);
                        } else {
                            var15 = (PlanActivity) var35.getPlannable();
                            boolean var16 = AccessControlUtils.hasModifyAccess(var15);
                            if (!var16) {
                                throw new WTException(new WTMessage("com.ptc.projectmanagement.assignment.resource.resourceResource", "NO_ACCESS_TO_PLANACTIVITY_ERROR", (Object[]) null));
                            }

                            long var17 = 0L;
                            long var19 = 0L;
                            long var21 = 0L;
                            if (var35.getTotalEffort() != null) {
                                var17 = var35.getTotalEffort().getMillis();
                            }

                            if (var35.getDoneEffort() != null) {
                                var19 = var35.getDoneEffort().getMillis();
                            }

                            if (var35.getRemainingEffort() != null) {
                                var21 = var35.getRemainingEffort().getMillis();
                            }

                            if (StandardResourceService.log.isDebugEnabled()) {
                                StandardResourceService.log.debug("assignmentTotalWorkDurationValue: " + var17 + ", assignmentActualWorkDurationValue: " + var19 + ", deleteAssignmentRemainingWork: " + var21);
                            }

                            PersistenceHelper.manager.delete(var35);
                            ActivityInfo var33 = (ActivityInfo) var32.get(var15);
                            if (var33 == null) {
                                var33 = StandardResourceService.this.new ActivityInfo(var15);
                                var32.put(var15, var33);
                            }

                            var33.addRemainingWork(var21);
                            var33.addActualWork(var19);
                            var33.addTotalWork(var17);
                        }
                    }

                    if (!var32.isEmpty()) {
                        var14 = null;
                        var15 = null;
                        Iterator var38 = var32.entrySet().iterator();

                        while (true) {
                            while (var38.hasNext()) {
                                Entry var39 = (Entry) var38.next();
                                PlanActivity var36 = (PlanActivity) var39.getKey();
                                ActivityInfo var37 = (ActivityInfo) var39.getValue();
                                TaskType var18 = var36.getTaskType();
                                boolean var40 = var36.isEffortDriven();
                                long var20 = 0L;
                                if (var36.getDoneEffort() != null) {
                                    var20 = var36.getDoneEffort().getMillis();
                                }

                                if (StandardResourceService.log.isDebugEnabled()) {
                                    StandardResourceService.log.debug("Activity: " + var36 + ", taskType: " + var18 + ", isEffortDriven: " + var40 + ", taskActualWorkDurationValue: " + var20);
                                }

                                long var24;
                                try {
                                    Duration var22 = new Duration();
                                    WTCollection var23 = AssignmentHelper.service.getResourceAssignments(var36);
                                    if (!var23.isEmpty()) {
                                        if (var36.getDoneEffort() != null) {
                                            var22.setDurationFormat(var36.getDoneEffort().getDurationFormat());
                                        }

                                        var24 = var20 - var37.getActualWorkForDeletedAssignments();
                                        var22.setMillis(var24);
                                        var36.setDoneEffort(var22);
                                    }

                                    var36 = (PlanActivity) PersistenceHelper.manager.save(var36);
                                } catch (WTPropertyVetoException var29) {
                                    var29.printStackTrace();
                                }

                                if (var40) {
                                    var36 = (PlanActivity) AssignmentHelper.service.distributeAdditionalWork(var36, var37.getRemainingWorkForDeletedAssignments(), var37.getActualWorkForDeletedAssignments());
                                    if (!TaskType.FIXED_WORK.equals(var18) && !TaskType.FIXED_UNITS.equals(var18)) {
                                        if (TaskType.FIXED_DURATION.equals(var18)) {
                                            var36 = (PlanActivity) AssignmentHelper.service.calculateUnits(var36);
                                        }
                                    } else {
                                        var36 = (PlanActivity) AssignmentHelper.service.calculateDuration(var36);
                                    }

                                    var36 = (PlanActivity) AssignmentHelper.service.calculatePercentWorkComplete(var36);
                                    var36 = (PlanActivity) PersistenceHelper.manager.save(var36);
                                    var36 = (PlanActivity) AssignmentHelper.service.rollUpEffort(var36);
                                } else {
                                    long var41 = 0L;
                                    if (var36.getTotalEffort() != null) {
                                        var41 = var36.getTotalEffort().getMillis();
                                    }

                                    var24 = var41 - var37.getTotalWorkForDeletedAssignments();
                                    Duration var26 = new Duration();

                                    try {
                                        if (var36.getTotalEffort() != null) {
                                            var26.setDurationFormat(var36.getTotalEffort().getDurationFormat());
                                        }

                                        var26.setMillis(var24);
                                        var36.setTotalEffort(var26);
                                        var36 = (PlanActivity) PersistenceHelper.manager.save(var36);
                                        var36 = (PlanActivity) AssignmentHelper.service.calculatePercentWorkComplete(var36);
                                        var36 = (PlanActivity) AssignmentHelper.service.rollUpEffort(var36);
                                        var36 = (PlanActivity) CostHelper.service.rollUpCost(var36);
                                    } catch (WTPropertyVetoException var28) {
                                        var28.printStackTrace();
                                    }
                                }
                            }

                            return;
                        }
                    }
                }

            }
        }, PersistenceManagerEvent.generateEventKey("PRE_DELETE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                WTCollection var2 = (WTCollection) ((KeyedEvent) var1).getEventTarget();
                WTCollection var3 = var2.subCollection(WTPrincipal.class, true);
                if (var3 != null && var3.size() > 0) {
                    boolean var4 = StandardResourceService.log.isDebugEnabled();
                    if (var4) {
                        StandardResourceService.log.debug("IN notifyVetoableMultiObjectEvent : PersistenceManagerEvent.POST_STORE");
                    }

                    Iterator var5 = var3.persistableIterator();

                    while (true) {
                        WTUser var7;
                        QueryResult var11;
                        do {
                            WTPrincipal var6;
                            do {
                                if (!var5.hasNext()) {
                                    if (var4) {
                                        StandardResourceService.log.debug("OUT notifyVetoableMultiObjectEvent : PersistenceManagerEvent.POST_STORE");
                                    }

                                    return;
                                }

                                var6 = (WTPrincipal) var5.next();
                            } while (!(var6 instanceof WTUser));

                            var7 = (WTUser) var6;
                            if (var4) {
                                StandardResourceService.log.debug("notifyVetoableMultiObjectEvent : PersistenceManagerEvent.POST_STORE...trying to create plan resource for wtUser:" + var7.getName());
                            }

                            Enumeration var8 = NmProjectHelper.findProjects(var7);

                            while (var8.hasMoreElements()) {
                                WTContainerRef var9 = WTContainerRef.newWTContainerRef((Project2) var8.nextElement());
                                if (var9 != null) {
                                    StandardResourceService.this.createResourceInContainer(var9, var7);
                                }
                            }

                            var11 = NmProductHelper.findProducts(var7, 256);
                        } while (var11 == null);

                        while (var11.hasMoreElements()) {
                            WTContainerRef var10 = WTContainerRef.newWTContainerRef((PDMLinkProduct) var11.nextElement());
                            if (var10 != null) {
                                StandardResourceService.this.createResourceInContainer(var10, var7);
                            }
                        }
                    }
                }
            }
        }, PersistenceManagerEvent.generateEventKey("POST_STORE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                KeyedEvent var2 = (KeyedEvent) var1;
                WTArrayList var3 = (WTArrayList) var2.getEventTarget();
                ContainerTeam var4 = (ContainerTeam) ((ContainerTeamReference) var3.get(0)).getObject();
                List var5 = ContainerTeamHelper.service.findContainersForTeam(var4);
                ContainerTeamServiceMultiObjectEvent var6 = (ContainerTeamServiceMultiObjectEvent) var1;
                WTList var7 = var6.getUsers();
                boolean var8 = SessionServerHelper.manager.setAccessEnforced(false);

                try {
                    int var9 = 0;

                    for (int var10 = var5.size(); var9 < var10; ++var9) {
                        ContainerTeamManaged var11 = (ContainerTeamManaged) var5.get(var9);
                        if (var11 instanceof Project2 && !(((Project2) var11).getProjectPlan() instanceof ProjectPlan) || var11 instanceof PDMLinkProduct) {
                            Transaction var12 = new Transaction();
                            WTContainerRef var13 = WTContainerRef.newWTContainerRef(var11);
                            if (var13 != null) {
                                try {
                                    var12.start();
                                    int var14 = 0;

                                    for (int var15 = var7.size(); var14 < var15; ++var14) {
                                        WTUser var16 = (WTUser) ((ObjectReference) var7.get(var14)).getObject();
                                        WTArrayList var17 = (WTArrayList) StandardResourceService.this.getResources((WTContainerRef) var13, (WTPrincipal) var16, ResourceUserType.WINDCHILL_USER);
                                        if (var17.size() == 0) {
                                            StandardResourceService.this.createResource((WTPrincipal) var16, var13);
                                        } else {
                                            Iterator var18 = var17.persistableIterator();
                                            if (var18.hasNext()) {
                                                PlanResource var19 = (PlanResource) var18.next();
                                                if (var19.getPersistInfo().getMarkForDelete() != 0L) {
                                                    DeleteHelper.manager.restoreMarkForDelete(var19);
                                                }
                                            }
                                        }
                                    }

                                    var12.commit();
                                    var12 = null;
                                } finally {
                                    if (var12 != null) {
                                        var12.rollback();
                                    }

                                }
                            }
                        }
                    }
                } finally {
                    SessionServerHelper.manager.setAccessEnforced(var8);
                }

            }
        }, ContainerTeamServiceMultiObjectEvent.generateEventKey("ADD_MEMBER"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(StandardTeamService.class.getName()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("StandardResourceService : notifyVetoableMultiObjectEvent :" + var1);
                }

                KeyedEvent var2 = (KeyedEvent) var1;
                WTArrayList var3 = (WTArrayList) var2.getEventTarget();
                ContainerTeam var4 = (ContainerTeam) ((ContainerTeamReference) var3.get(0)).getObject();
                WTList var5 = ((ContainerTeamServiceMultiObjectEvent) var1).getRemovedUsers();
                WTPrincipal var6 = SessionHelper.getPrincipal();
                boolean var7 = var5.contains(var6);
                if (!var7) {
                    AccessControlHelper.manager.checkAccess(var4, AccessPermission.MODIFY);
                }

                List var8 = ContainerTeamHelper.service.findContainersForTeam(var4);
                WTUser var9 = null;
                ObjectIdentifier var10 = null;
                boolean var11 = SessionServerHelper.manager.setAccessEnforced(false);

                try {
                    for (int var12 = 0; var12 < var8.size(); ++var12) {
                        ContainerTeamManaged var13 = (ContainerTeamManaged) var8.get(var12);
                        WTGroup var15 = var13.getAdministrators();
                        var10 = var13.getPersistInfo().getObjectIdentifier();
                        if (!var7 && OrganizationServicesHelper.manager.isMember(var15, var6)) {
                            var9 = (WTUser) var6;
                        } else {
                            Enumeration var16 = var15.members();

                            while (var16.hasMoreElements() && var9 == null) {
                                WTUser var17 = (WTUser) var16.nextElement();
                                if (!var17.equals(var6)) {
                                    var9 = var17;
                                }
                            }
                        }

                        long[] var23 = this.getOidsOfRemovedUsers(var5);
                        Collection var24 = this.getPlansAssociatedWithRemovedUsers(var10, var23);
                        this.changeOwner(var24, var9);
                    }
                } catch (WTException var21) {
                    if (StandardResourceService.log.isDebugEnabled()) {
                        StandardResourceService.log.debug("Error while replacing plan(s) owner with other owner");
                    }

                    throw var21;
                } finally {
                    SessionServerHelper.manager.setAccessEnforced(var11);
                }

            }

            private void changeOwner(Collection<Rootable> var1, WTUser var2) throws OwnershipException, WTException {
                WTArrayList var3 = new WTArrayList(var1.size());
                Iterator var4 = var1.iterator();

                while (var4.hasNext()) {
                    Rootable var5 = (Rootable) var4.next();
                    Plan var6 = (Plan) var5;
                    OwnershipServerHelper.service.changeOwner(var6, var2, false);
                    var3.add(var6);
                }

                if (!var3.isEmpty()) {
                    PersistenceServerHelper.manager.update(var3);
                }

            }

            private Collection<Rootable> getPlansAssociatedWithRemovedUsers(ObjectIdentifier var1, long[] var2) throws WTException {
                QuerySpec var3 = new QuerySpec();
                int var4 = var3.appendClassList(Plan.class, true);
                var3.appendWhere(new SearchCondition(Plan.class, "holder.key", "=", var1), new int[]{var4});
                var3.appendAnd();
                SearchCondition var5 = new SearchCondition(new ClassAttribute(Plan.class, "ownership.owner.key.id"), "IN", new ArrayExpression(var2));
                var3.appendWhere(var5, new int[]{var4});
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("Query Spec : " + var3);
                }

                PlanResultProcessor var6 = new PlanResultProcessor();
                PersistenceServerHelper.manager.query(var3, var6);
                return var6.getResult();
            }

            private long[] getOidsOfRemovedUsers(WTList var1) {
                long[] var2 = new long[var1.size()];
                int var3 = 0;

                for (Iterator var4 = var1.iterator(); var4.hasNext(); ++var3) {
                    Object var5 = var4.next();
                    long var6 = ((ObjectIdentifier) ((ObjectReference) var5).getKey()).getId();
                    var2[var3] = var6;
                }

                return var2;
            }
        }, ContainerTeamServiceMultiObjectEvent.generateEventKey("REMOVE_MEMBER"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                ProjectManagementEvent var2 = (ProjectManagementEvent) var1;
                WTCollection var3 = (WTCollection) var2.getEventTarget();
                Plan var4 = null;
                Iterator var5 = var3.persistableIterator();

                while (true) {
                    Object var6;
                    do {
                        if (!var5.hasNext()) {
                            return;
                        }

                        var6 = var5.next();
                    } while (!(var6 instanceof Plan));

                    var4 = (Plan) var6;
                    Transaction var7 = null;
                    boolean var8 = SessionServerHelper.manager.setAccessEnforced(false);

                    try {
                        var7 = new Transaction();
                        var7.start();
                        if (var4.getContainer() instanceof Project2) {
                            WTUser var9 = (WTUser) SessionHelper.manager.getPrincipal();
                            WTArrayList var10 = (WTArrayList) StandardResourceService.this.getResources((WTContainerRef) var4.getContainerReference(), (WTPrincipal) var9, ResourceUserType.WINDCHILL_USER);
                            if (var10.size() == 0) {
                                StandardResourceService.this.createResource((WTPrincipal) var9, var4.getContainerReference());
                            }

                            WTContainer var11 = var4.getContainer();
                            ContainerTeam var12 = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged) var11);
                            Vector var13 = var12.getRoles();
                            StandardResourceService.log.debug("Project team roles created from project template : " + var13);
                            WTArrayList var14 = new WTArrayList();
                            int var15 = 0;

                            for (int var16 = var13.size(); var15 < var16; ++var15) {
                                Role var17 = (Role) var13.get(var15);
                                WTGroup var18 = ContainerTeamHelper.service.findContainerTeamGroup(var12, "roleGroups", var17.toString());
                                if (StandardResourceService.this.getResources((WTContainerRef) var4.getContainerReference(), (WTPrincipal) var18, ResourceUserType.WINDCHILL_TEAM_ROLE).size() == 0) {
                                    PlanResource var19 = PlanResource.newPlanResource(var4.getContainerReference());
                                    var19.setPrincipalRef(WTPrincipalReference.newWTPrincipalReference(var18));
                                    var19.setUserType(ResourceUserType.WINDCHILL_TEAM_ROLE);
                                    var19.setName(var18.getPrincipalDisplayIdentifier());
                                    var19 = (PlanResource) StandardResourceService.this.addResource(var19, (WTContainerRef) var4.getContainerReference());
                                    var14.add(var19);
                                }
                            }

                            PersistenceHelper.manager.save(var14);
                        } else if (var4.getContainer() instanceof PDMLinkProduct) {
                            ContainerTeam var27 = ContainerTeamHelper.service.getContainerTeam((PDMLinkProduct) var4.getContainer());
                            Vector var28 = var27.getMembers();
                            WTCollection var29 = StandardResourceService.getWtUsersWhoseResourcesNeedsToCreate(var4, var28);
                            Iterator var30 = var29.iterator();

                            while (var30.hasNext()) {
                                Object var31 = var30.next();
                                if (var31 instanceof ObjectReference) {
                                    ObjectReference var32 = (ObjectReference) var31;
                                    WTUser var33 = (WTUser) var32.getObject();
                                    StandardResourceService.this.createResource((WTPrincipal) var33, var4.getContainerReference());
                                }
                            }
                        }

                        var7.commit();
                        var7 = null;
                    } catch (WTPropertyVetoException var24) {
                        throw new WTException(var24);
                    } catch (WTException var25) {
                        var25.printStackTrace();
                    } finally {
                        if (var7 != null) {
                            var7.rollback();
                        }

                        SessionServerHelper.manager.setAccessEnforced(var8);
                    }
                }
            }
        }, KeyedEvent.generateEventKey(ProjectManagementEvent.class, "NEW_PLAN"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getName()) {
            public void notifyVetoableEvent(Object var1) throws WTException {
                KeyedEvent var2 = (KeyedEvent) var1;
                Object var3 = var2.getEventTarget();
                ContainerTeam var4 = (ContainerTeam) var3;
                StandardResourceService.log.debug("Listener for Remove/Replace Member START");
                List var5 = ContainerTeamHelper.service.findContainersForTeam(var4);

                try {
                    int var6 = 0;

                    for (int var7 = var5.size(); var6 < var7; ++var6) {
                        ContainerTeamManaged var8 = (ContainerTeamManaged) var5.get(var6);
                        if (var8 instanceof Project2 && !(((Project2) var8).getProjectPlan() instanceof ProjectPlan) || var8 instanceof PDMLinkProduct) {
                            WTContainerRef var9 = WTContainerRef.newWTContainerRef(var8);
                            if (var9 != null) {
                                ArrayList var10 = new ArrayList();
                                ContainerTeamServiceEvent var11 = (ContainerTeamServiceEvent) var1;
                                WTUser var12 = var11.getUser();
                                WTUser var13 = var11.getRemovedUser();
                                WTArrayList var14 = (WTArrayList) StandardResourceService.this.getResources((WTContainerRef) var9, (WTPrincipal) var12, ResourceUserType.WINDCHILL_USER);
                                WTCollection var15 = StandardResourceService.this.getResources((WTContainerRef) var9, (WTPrincipal) var13, ResourceUserType.WINDCHILL_USER);
                                Iterator var16 = var15.persistableIterator();
                                PlanResource var17 = null;
                                ArrayList var18 = new ArrayList();

                                while (var16.hasNext()) {
                                    var18.add((PlanResource) var16.next());
                                }

                                boolean var19 = SessionServerHelper.manager.setAccessEnforced(false);

                                Iterator var20;
                                try {
                                    if (var14.size() == 0) {
                                        var17 = StandardResourceService.this.createResource((WTPrincipal) var12, var9);
                                    } else {
                                        var20 = var14.persistableIterator();
                                        if (var20.hasNext()) {
                                            var17 = (PlanResource) var20.next();
                                            if (var17.getPersistInfo().getMarkForDelete() != 0L) {
                                                DeleteHelper.manager.restoreMarkForDelete(var17);
                                            }
                                        }
                                    }
                                } finally {
                                    SessionServerHelper.manager.setAccessEnforced(var19);
                                }

                                if (var18 != null && var18.size() > 0) {
                                    var20 = var18.iterator();

                                    while (var20.hasNext()) {
                                        PlanResource var21 = (PlanResource) var20.next();
                                        StandardResourceService.log.debug("Resource being removed :" + var21);
                                        if (var21.getPrincipalRef() != null) {
                                            StandardResourceService.log.debug("Related User :" + var21.getPrincipalRef().getDisplayName());
                                        }

                                        StandardResourceService.log.debug("New Resource :" + var17);
                                        WTCollection var22 = AssignmentHelper.service.getResourceAssignments(var21);
                                        Iterator var23 = var22.persistableIterator();
                                        boolean var24 = false;
                                        boolean var25 = false;

                                        while (true) {
                                            while (var23.hasNext()) {
                                                ResourceAssignment var26 = (ResourceAssignment) var23.next();
                                                StandardResourceService.log.debug("Processing assignment " + var26);
                                                if (var26.isPoolAssignment()) {
                                                    var25 = true;
                                                } else {
                                                    WTCollection var27 = AssignmentHelper.service.getResourceAssignments(var26.getPlannable(), var17);
                                                    Iterator var28 = var27.persistableIterator();
                                                    Transaction var29 = new Transaction();

                                                    try {
                                                        var29.start();
                                                        synchronized (var26) {
                                                            var26 = (ResourceAssignment) PersistenceHelper.manager.refresh(var26);
                                                            if (var26.getRemainingEffort() != null && var26.getRemainingEffort().getMillis() > 0L) {
                                                                if (var28.hasNext()) {
                                                                    ResourceAssignment var31 = (ResourceAssignment) var28.next();
                                                                    StandardResourceService.log.debug("Updating the assignment " + var31 + " for new resource");
                                                                    AssignmentHelper.updateExistingAssignmentForNewResource(var26, var31);
                                                                    PlanActivity var32 = (PlanActivity) var31.getPlannable();
                                                                    if (var32.isInProcess()) {
                                                                        var10.add(var31);
                                                                    }
                                                                } else {
                                                                    var26.setResource(var17);
                                                                    var26 = (ResourceAssignment) PersistenceHelper.manager.save(var26);
                                                                    StandardResourceService.log.debug("Updating the assignment to be " + var26);
                                                                    PlanActivity var66 = (PlanActivity) var26.getPlannable();
                                                                    if (var66.isInProcess()) {
                                                                        var10.add(var26);
                                                                    }
                                                                }
                                                            } else {
                                                                var24 = true;
                                                                StandardResourceService.log.debug("Assignment : " + var26.getPlannable().getName() + "-" + var26.getResource().getName() + " is Complete; skipping this resource");
                                                            }
                                                        }

                                                        var29.commit();
                                                        var29 = null;
                                                    } catch (Exception var57) {
                                                        StandardResourceService.log.error(var57.getMessage());
                                                        throw new WTException(var57);
                                                    } finally {
                                                        if (var29 != null) {
                                                            var29.rollback();
                                                        }

                                                    }
                                                }
                                            }

                                            StandardResourceService.rollUpCost(var17);
                                            if (!var25) {
                                                boolean var65 = SessionServerHelper.manager.setAccessEnforced(false);

                                                try {
                                                    if (!var24) {
                                                        PersistenceHelper.manager.delete(var21);
                                                    } else {
                                                        DeleteHelper.manager.markForDelete(var21);
                                                    }
                                                } finally {
                                                    SessionServerHelper.manager.setAccessEnforced(var65);
                                                }
                                            }
                                            break;
                                        }
                                    }
                                }

                                WTCollection var60 = StandardResourceService.this.getResources((WTContainerRef) var9, (WTPrincipal) var13, ResourceUserType.OTHER);
                                Iterator var61 = var60.persistableIterator();

                                while (var61.hasNext()) {
                                    PlanResource var62 = (PlanResource) var61.next();
                                    var62.setPrincipalRef(WTPrincipalReference.newWTPrincipalReference(var12));
                                }

                                var60 = PersistenceHelper.manager.save(var60);
                                PlannableHelper.service.changeOwnershipOfPlannables(var9, var12, var13);
                                PlannableHelper.service.changeOwnershipOfDeliverables(var8, var12, var13);
                                PlanHelper.service.propagateScheduleForAllPlans(var9);
                                Iterator var63 = var10.iterator();

                                while (var63.hasNext()) {
                                    ResourceAssignment var64 = (ResourceAssignment) var63.next();
                                    var64 = (ResourceAssignment) PersistenceHelper.manager.refresh(var64);
                                    PlannableUtils.sendResourceNotification(var64);
                                }
                            }
                        }
                    }
                } catch (WTPropertyVetoException var59) {
                    throw new WTException(var59.getLocalizedMessage(SessionHelper.getLocale()));
                }

                StandardResourceService.log.debug("Listener for Remove/Replace Member END");
            }
        }, KeyedEvent.generateEventKey(ContainerTeamServiceEvent.class, "REPLACE_MEMBER"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                Boolean var2 = (Boolean) MethodContext.getContext().get("SKIP_DELETE_LISTENER");
                if (var2 == null || var2.equals(Boolean.FALSE)) {
                    PersistenceManagerEvent var3 = (PersistenceManagerEvent) var1;
                    WTCollection var4 = (WTCollection) var3.getEventTarget();
                    WTCollection var5 = var4.subCollection(Resourceable.class, true);
                    var5 = StandardResourceService.this.removeBaselinedResources(var5);
                    ArrayList var6 = new ArrayList(var5.persistableCollection());
                    Plannable var7 = null;

                    for (int var8 = 0; var8 < var6.size(); ++var8) {
                        PlanResource var9 = (PlanResource) var6.get(var8);
                        if (var9.getRoot() instanceof Plannable) {
                            var7 = (Plannable) var9.getRoot();
                            break;
                        }
                    }

                    Boolean var13 = (Boolean) MethodContext.getContext().get("hasAssignments");
                    if (var7 != null && Boolean.TRUE.equals(var13)) {
                        PlannableHelper.service.propagateSchedule(var7);
                        WTCollection var14 = PlannableHelper.service.getAllPlannables(var7, false);
                        ArrayList var10 = new ArrayList(var14.persistableCollection());

                        for (int var11 = 0; var11 < var10.size(); ++var11) {
                            Plannable var12 = (Plannable) var10.get(var11);
                            var12 = (Plannable) CostHelper.service.rollUpCostForPlannable((CostTrackable) var12);
                        }
                    }
                }

            }
        }, PersistenceManagerEvent.generateEventKey("POST_DELETE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableEvent(Object var1) throws WTException {
                KeyedEvent var2 = (KeyedEvent) var1;
                ContainerTeam var3 = (ContainerTeam) var2.getEventTarget();
                List var4 = ContainerTeamHelper.service.findContainersForTeam(var3);
                ContainerTeamServiceEvent var5 = (ContainerTeamServiceEvent) var1;
                ArrayList var6 = var5.getRoles();
                int var7 = 0;

                for (int var8 = var4.size(); var7 < var8; ++var7) {
                    ContainerTeamManaged var9 = (ContainerTeamManaged) var4.get(var7);
                    if (var9 instanceof Project2 && !(((Project2) var9).getProjectPlan() instanceof ProjectPlan) || var9 instanceof PDMLinkProduct) {
                        boolean var10 = SessionServerHelper.manager.setAccessEnforced(false);

                        try {
                            if (var9 != null) {
                                Transaction var11 = new Transaction();

                                try {
                                    var11.start();
                                    int var12 = 0;

                                    for (int var13 = var6.size(); var12 < var13; ++var12) {
                                        Role var14 = (Role) var6.get(var12);
                                        WTGroup var15 = ContainerTeamHelper.service.findContainerTeamGroup(var3, "roleGroups", var14.toString());
                                        WTContainerRef var16 = WTContainerRef.newWTContainerRef(var9);
                                        if (StandardResourceService.this.getResources((WTContainerRef) var16, (WTPrincipal) var15, ResourceUserType.WINDCHILL_TEAM_ROLE).size() == 0) {
                                            PlanResource var17 = PlanResource.newPlanResource(var16);
                                            var17.setPrincipalRef(WTPrincipalReference.newWTPrincipalReference(var15));
                                            var17.setUserType(ResourceUserType.WINDCHILL_TEAM_ROLE);
                                            var17.setName(var15.getPrincipalDisplayIdentifier());
                                            var17 = (PlanResource) StandardResourceService.this.addResource(var17, (WTContainerRef) var16);
                                            var17 = (PlanResource) PersistenceHelper.manager.save(var17);
                                        }
                                    }

                                    var11.commit();
                                    var11 = null;
                                } catch (WTPropertyVetoException var26) {
                                    var26.printStackTrace();
                                } finally {
                                    if (var11 != null) {
                                        var11.rollback();
                                    }

                                }
                            }
                        } finally {
                            SessionServerHelper.manager.setAccessEnforced(var10);
                        }
                    }
                }

            }
        }, ContainerTeamServiceEvent.generateEventKey("ADD_ROLE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableEvent(Object var1) throws WTException {
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("Entered REMOVE_ROLE listener");
                }

                KeyedEvent var2 = (KeyedEvent) var1;
                ContainerTeam var3 = (ContainerTeam) var2.getEventTarget();
                List var4 = ContainerTeamHelper.service.findContainersForTeam(var3);
                ContainerTeamServiceEvent var5 = (ContainerTeamServiceEvent) var1;
                ArrayList var6 = var5.getRoles();
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("team: " + var3 + ", containers: " + var4 + ", roleList: " + var6);
                }

                if (var6 != null && !var6.isEmpty()) {
                    int var7 = 0;

                    for (int var8 = var4.size(); var7 < var8; ++var7) {
                        ContainerTeamManaged var9 = (ContainerTeamManaged) var4.get(var7);
                        if (var9 instanceof Project2 && !(((Project2) var9).getProjectPlan() instanceof ProjectPlan) || var9 instanceof PDMLinkProduct) {
                            WTCollection var10 = (WTCollection) MethodContext.getContext().get("ROLE_GROUPS_REMOVED_FROM_TEAM");
                            if (var10 != null) {
                                try {
                                    if (StandardResourceService.log.isDebugEnabled()) {
                                        StandardResourceService.log.debug("plan: " + var9.getName() + ", removedRoleGroups: " + var10);
                                    }

                                    if (var10 == null || var10.isEmpty() || var10.size() != var6.size()) {
                                        throw new WTException("Mismatch between removed roles and collected groups. Please investigate.");
                                    }

                                    Role var11 = null;
                                    WTGroup var12 = null;
                                    boolean var13 = false;
                                    int var14 = 0;

                                    while (var14 < var6.size()) {
                                        var13 = false;
                                        var11 = (Role) var6.get(var14);
                                        Iterator var15 = var10.persistableIterator();

                                        while (true) {
                                            if (var15.hasNext()) {
                                                var12 = (WTGroup) var15.next();
                                                if (!var11.toString().equals(var12.getName())) {
                                                    continue;
                                                }

                                                var13 = true;
                                            }

                                            if (!var13) {
                                                throw new WTException("Group for the removed role not found. Please investigate.");
                                            }

                                            ++var14;
                                            break;
                                        }
                                    }
                                } finally {
                                    MethodContext.getContext().remove("ROLE_GROUPS_REMOVED_FROM_TEAM");
                                }

                                StandardResourceService.this.processRemoveGroupFromTeam(WTContainerRef.newWTContainerRef(var9), var10, ResourceUserType.WINDCHILL_TEAM_ROLE);
                            }
                        }
                    }
                }

            }
        }, ContainerTeamServiceEvent.generateEventKey("REMOVE_ROLE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableEvent(Object var1) throws WTException {
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("Entered PRE_DISABLE listener");
                }

                OrganizationServicesEvent var2 = (OrganizationServicesEvent) var1;
                Persistable var3 = (Persistable) var2.getEventTarget();
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("target: " + var3);
                }

                if (var3 instanceof WTGroup && ((WTGroup) var3).isInternal()) {
                    StandardResourceService.this.processPreDisableEvent((WTGroup) var3);
                }

            }
        }, OrganizationServicesEvent.generateEventKey("PRE_DISABLE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableEvent(Object var1) throws WTException {
                KeyedEvent var2 = (KeyedEvent) var1;
                var2.getEventTarget();
            }
        }, OrganizationServicesEvent.generateEventKey("ADD"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableEvent(Object var1) throws WTException {
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("Entered MEMBERSHIP_CHANGE listener.");
                }

                OrganizationServicesEvent var2 = (OrganizationServicesEvent) var1;
                String var3 = var2.getChangeType();
                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("changeType: " + var3);
                }

                if (var3.equals("ADD") || var3.equals("REMOVE")) {
                    Object var4 = var2.getEventTarget();
                    if (var4 instanceof WTGroup) {
                        WTGroup var5 = (WTGroup) var4;
                        WTCollection var6 = var2.getMemberRefs();
                        if (StandardResourceService.log.isDebugEnabled()) {
                            StandardResourceService.log.debug("targetGroup: " + var5 + ", memberRefs: " + var6);
                        }

                        WTCollection var7 = StandardResourceService.this.getParentGroups(var5);
                        var7.add(var5);
                        WTCollection var8 = AssignmentHelper.service.getGroupAssignments(var7);
                        Map var9 = StandardResourceService.this.groupAssignmentsByType(var8);
                        if (StandardResourceService.log.isDebugEnabled()) {
                            StandardResourceService.log.debug("type2assignments: " + var9);
                        }

                        WTCollection var10 = null;
                        WTCollection var11 = null;
                        WTCollection var12 = null;
                        if (var9 != null && !var9.isEmpty()) {
                            var10 = (WTCollection) var9.get(ResourceAssignmentType.SHARED);
                            var11 = (WTCollection) var9.get(ResourceAssignmentType.BULK);
                            var12 = (WTCollection) var9.get(ResourceAssignmentType.POOL);
                        }

                        if (StandardResourceService.log.isDebugEnabled()) {
                            StandardResourceService.log.debug("sharedAssignments: " + var10 + "\nbulkAssignments: " + var11 + "\npoolAssignments: " + var12);
                        }

                        WTArrayList var13 = new WTArrayList();
                        WTPrincipal var16;
                        if (var6 != null && !var6.isEmpty()) {
                            Iterator var14 = var6.iterator();

                            label951:
                            while (true) {
                                while (true) {
                                    WTPrincipalReference var15;
                                    do {
                                        do {
                                            if (!var14.hasNext()) {
                                                break label951;
                                            }

                                            var15 = (WTPrincipalReference) var14.next();
                                        } while (var15 == null);
                                    } while (var15.getPrincipal() == null);

                                    var16 = var15.getPrincipal();
                                    if (var16 instanceof WTUser) {
                                        var13.add(var16);
                                    } else if (var16 instanceof WTGroup) {
                                        Enumeration var17 = OrganizationServicesHelper.manager.members((WTGroup) var16, true);

                                        while (var17.hasMoreElements()) {
                                            var13.add(var17.nextElement());
                                        }
                                    }
                                }
                            }
                        }

                        if (StandardResourceService.log.isDebugEnabled()) {
                            StandardResourceService.log.debug("allUsers: " + var13);
                        }

                        Transaction var34 = null;

                        try {
                            var34 = new Transaction();
                            var34.start();
                            WTContainer var36;
                            if (var3.equals("ADD")) {
                                if (StandardResourceService.log.isDebugEnabled()) {
                                    StandardResourceService.log.debug("Processing ADD event.");
                                }

                                Iterator var40;
                                if (!var13.isEmpty()) {
                                    WTArrayList var37 = new WTArrayList();
                                    var16 = null;
                                    ResourceAssignment var38;
                                    WTDistributionList var42;
                                    Iterator var44;
                                    if (var10 != null && !var10.isEmpty()) {
                                        var40 = var10.persistableIterator();

                                        while (var40.hasNext()) {
                                            var38 = (ResourceAssignment) var40.next();
                                            var37.addAll(StandardResourceService.this.createSharedAssignmentDetails(var38, var13));
                                            var42 = new WTDistributionList();
                                            var44 = var13.persistableIterator();

                                            while (var44.hasNext()) {
                                                var42.addPrincipal((WTPrincipal) var44.next());
                                            }

                                            PlannableUtils.sendResourceNotification(var38, var42);
                                        }
                                    }

                                    if (!var37.isEmpty()) {
                                        PersistenceHelper.manager.save(var37);
                                    }

                                    if (var11 != null && !var11.isEmpty()) {
                                        var40 = var11.persistableIterator();

                                        while (var40.hasNext()) {
                                            AssignmentHelper.service.handleAddMemberForBulkAssignment((ResourceAssignment) var40.next(), var13);
                                        }
                                    }

                                    if (var12 != null && !var12.isEmpty()) {
                                        var40 = var12.persistableIterator();

                                        label852:
                                        while (true) {
                                            do {
                                                if (!var40.hasNext()) {
                                                    break label852;
                                                }

                                                var38 = (ResourceAssignment) var40.next();
                                            } while (!var38.isPotentialAssignment());

                                            var42 = new WTDistributionList();
                                            var44 = var13.persistableIterator();

                                            while (var44.hasNext()) {
                                                var42.addPrincipal((WTPrincipal) var44.next());
                                            }

                                            PlannableUtils.sendResourceNotification(var38, var42);
                                        }
                                    }
                                }

                                if (var5.isInternal()) {
                                    var36 = var5.getContainer();
                                    if (var36 instanceof ContainerTeamManaged && (var36 instanceof Project2 && !(((Project2) var36).getProjectPlan() instanceof ProjectPlan) || var36 instanceof PDMLinkProduct)) {
                                        boolean var41 = SessionServerHelper.manager.setAccessEnforced(false);

                                        try {
                                            if (var36 != null && var6 != null && !var6.isEmpty()) {
                                                var40 = var6.iterator();

                                                while (var40.hasNext()) {
                                                    WTPrincipalReference var43 = (WTPrincipalReference) var40.next();
                                                    if (var43 != null && var43.getPrincipal() != null) {
                                                        WTPrincipal var45 = var43.getPrincipal();
                                                        if (var45 instanceof WTGroup && !((WTGroup) var45).isInternal()) {
                                                            WTContainerRef var46 = WTContainerRef.newWTContainerRef(var36);
                                                            if (StandardResourceService.this.getResources(var46, var45, ResourceUserType.WINDCHILL_GROUP).size() == 0) {
                                                                if (StandardResourceService.log.isDebugEnabled()) {
                                                                    StandardResourceService.log.debug("Creating group resource for: " + var45);
                                                                }

                                                                PlanResource var21 = ResourceHelper.service.createResource(var45, var46);

                                                                try {
                                                                    var21.setUserType(ResourceUserType.WINDCHILL_GROUP);
                                                                    var21 = (PlanResource) PersistenceHelper.manager.save(var21);
                                                                } catch (WTPropertyVetoException var31) {
                                                                    throw new WTException(var31);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } finally {
                                            SessionServerHelper.manager.setAccessEnforced(var41);
                                        }
                                    }
                                }
                            } else if (var3.equals("REMOVE")) {
                                if (StandardResourceService.log.isDebugEnabled()) {
                                    StandardResourceService.log.debug("Processing REMOVE event.");
                                }

                                if (!var13.isEmpty()) {
                                    Iterator var35;
                                    if (var11 != null && !var11.isEmpty()) {
                                        var35 = var11.persistableIterator();

                                        while (var35.hasNext()) {
                                            AssignmentHelper.service.handleRemoveMemberForBulkAssignment((ResourceAssignment) var35.next(), var13);
                                        }
                                    }

                                    if (var10 != null && !var10.isEmpty()) {
                                        var35 = var10.persistableIterator();

                                        while (var35.hasNext()) {
                                            AssignmentHelper.service.handleRemoveMemberForSharedAssignment((ResourceAssignment) var35.next(), var13);
                                        }
                                    }
                                }

                                if (var5.isInternal()) {
                                    var36 = var5.getContainer();
                                    if (var36 instanceof ContainerTeamManaged && (var36 instanceof Project2 && !(((Project2) var36).getProjectPlan() instanceof ProjectPlan) || var36 instanceof PDMLinkProduct) && var36 != null && var6 != null && !var6.isEmpty()) {
                                        var16 = null;
                                        WTArrayList var39 = new WTArrayList();
                                        ContainerTeam var18 = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged) var36);
                                        WTArrayList var19 = new WTArrayList(var18.getMembers());
                                        Iterator var20 = var6.persistableIterator();

                                        while (var20.hasNext()) {
                                            var16 = (WTPrincipal) var20.next();
                                            if (var16 instanceof WTGroup && !var19.contains(var16)) {
                                                var39.add(var16);
                                            }
                                        }

                                        StandardResourceService.this.processRemoveGroupFromTeam(WTContainerRef.newWTContainerRef(var36), var39, ResourceUserType.WINDCHILL_GROUP);
                                    }
                                }
                            }

                            var34.commit();
                            var34 = null;
                        } finally {
                            if (var34 != null) {
                                var34.rollback();
                            }

                        }
                    }
                }

                if (StandardResourceService.log.isDebugEnabled()) {
                    StandardResourceService.log.debug("Exiting MEMBERSHIP_CHANGE listener.");
                }

            }
        }, OrganizationServicesEvent.generateEventKey("MEMBERSHIP_CHANGE"));
        this.getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object var1) throws WTException {
                OrganizationServicesEvent var2 = (OrganizationServicesEvent) var1;
                Object var3 = var2.getEventTarget();
                if (var3 != null && var3 instanceof WTCollection) {
                    boolean var4 = SessionServerHelper.manager.setAccessEnforced(false);

                    try {
                        WTCollection var5 = StandardResourceService.this.getResources((WTCollection) var3);
                        if (var5 != null && !var5.isEmpty()) {
                            PlanResource var6 = null;
                            WTArrayList var7 = new WTArrayList();
                            Iterator var8 = var5.persistableIterator();

                            while (var8.hasNext()) {
                                var6 = (PlanResource) var8.next();
                                if (var6.isUserResource()) {
                                    try {
                                        var6.setUserType(ResourceUserType.OTHER);
                                    } catch (WTPropertyVetoException var13) {
                                        throw new WTException(var13);
                                    }

                                    var7.add(var6);
                                }
                            }

                            if (!var7.isEmpty()) {
                                PersistenceHelper.manager.save(var7);
                            }
                        }
                    } finally {
                        SessionServerHelper.manager.setAccessEnforced(var4);
                    }
                }

            }
        }, OrganizationServicesEvent.generateEventKey("POST_DISABLE"));
    }

    public PlanResource createResource(WTPrincipal var1, WTContainerRef var2) throws WTException {
        PlanResource var3 = PlanResource.newPlanResource(var2);

        try {
            if (var1 instanceof WTUser) {
                var3.setName(((WTUser) var1).getFullName());
                var3.setUserType(ResourceUserType.WINDCHILL_USER);
            } else {
                var3.setName(var1.getName());
            }

            var3.setPrincipalRef(WTPrincipalReference.newWTPrincipalReference(var1));
        } catch (WTPropertyVetoException var5) {
            throw new WTException(var5);
        }

        var3.setDomainRef(AdminUtils.getAdministrativeSystemDomainRef(var3.getContainerReference()));
        var3 = (PlanResource) this.saveResourceable(var3);
        return var3;
    }

    public PlanResource createResource(WTPrincipal var1, WTContainerRef var2, String var3, ResourceUserType var4) throws WTException {
        PlanResource var5 = PlanResource.newPlanResource(var2);

        try {
            var5.setName(var3);
            var5.setUserType(var4);
            var5.setPrincipalRef(WTPrincipalReference.newWTPrincipalReference(var1));
        } catch (WTPropertyVetoException var7) {
            throw new WTException(var7);
        }

        var5 = (PlanResource) this.addResource(var5, (WTContainerRef) var2);
        return var5;
    }

    public WTCollection getResources(WTUser var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        int var3 = var2.appendClassList(PlanResource.class, true);
        SearchCondition var4 = new SearchCondition(PlanResource.class, "principalRef.key", "=", PersistenceHelper.getObjectIdentifier(var1));
        var2.appendWhere(var4, new int[]{0});
        ClassAttribute var5 = new ClassAttribute(PlanResource.class, "name");
        var2.appendOrderBy(new OrderBy(var5, false), new int[]{var3});
        QueryResult var6 = PersistenceHelper.manager.find(var2);
        WTArrayList var7 = new WTArrayList();
        var7.addAll(var6);
        return var7;
    }

    public WTCollection getResources(WTCollection var1) throws WTException {
        WTArrayList var2 = new WTArrayList();
        if (var1 != null && !var1.isEmpty()) {
            QuerySpec var3 = new QuerySpec();
            int var4 = var3.appendClassList(PlanResource.class, true);
            long[] var5 = ResourceUtils.extractDbIds(var1);
            SearchCondition var6 = new SearchCondition(new ClassAttribute(PlanResource.class, "principalRef.key.id"), "IN", new ArrayExpression(var5));
            var3.appendWhere(var6, new int[]{var4});
            ClassAttribute var7 = new ClassAttribute(PlanResource.class, "name");
            var3.appendOrderBy(new OrderBy(var7, false), new int[]{var4});
            QueryResult var8 = PersistenceHelper.manager.find(var3);
            var2.addAll(var8);
        }

        return var2;
    }

    public WTCollection getAllUsers(boolean var1, boolean var2) throws WTException {
        QuerySpec var3 = new QuerySpec(WTUser.class);
        boolean var4 = false;
        if (var1) {
            var3.appendWhere(new SearchCondition(new ClassAttribute(WTUser.class, "internal"), "FALSE"), new int[]{0});
            var4 = true;
        }

        if (var2) {
            if (var4) {
                var3.appendAnd();
            }

            var3.appendWhere(new SearchCondition(new ClassAttribute(WTUser.class, "disabled"), "FALSE"), new int[]{0});
        }

        QueryResult var5 = PersistenceHelper.manager.find(var3);
        WTArrayList var6 = new WTArrayList();
        var6.addAll(var5);
        return var6;
    }

    public WTCollection getContainerGroups(boolean var1, boolean var2, WTCollection var3) throws WTException {
        QuerySpec var4 = new QuerySpec(WTGroup.class);
        boolean var5 = false;
        if (var1) {
            var4.appendWhere(new SearchCondition(new ClassAttribute(WTGroup.class, "internal"), "FALSE"), new int[]{0});
            var5 = true;
        }

        if (var2) {
            if (var5) {
                var4.appendAnd();
            }

            var4.appendWhere(new SearchCondition(new ClassAttribute(WTGroup.class, "disabled"), "FALSE"), new int[]{0});
        }

        if (var3 != null && !var3.isEmpty()) {
            var4.appendAnd();
            long[] var6 = ResourceUtils.extractDbIds(var3);
            var4.appendWhere(new SearchCondition(new ClassAttribute(WTGroup.class, "containerReference.key.id"), "IN", new ArrayExpression(var6)), new int[]{0});
        }

        QueryResult var8 = PersistenceServerHelper.manager.query(var4);
        WTArrayList var7 = new WTArrayList();
        var7.addAll(var8);
        return var7;
    }

    public WTCollection getResources(WTContainerRef var1, WTPrincipal var2, ResourceUserType var3) throws WTException {
        QuerySpec var4 = this.getResourcesQuerySpec(var1, true);
        var4.appendAnd();
        SearchCondition var5 = new SearchCondition(PlanResource.class, "principalRef.key", "=", PersistenceHelper.getObjectIdentifier(var2));
        var4.appendWhere(var5, new int[]{0});
        var4.appendAnd();
        SearchCondition var6 = new SearchCondition(PlanResource.class, "userType", "=", var3);
        var4.appendWhere(var6, new int[]{0});
        QueryResult var7 = PersistenceServerHelper.manager.query(var4);
        return new WTArrayList(var7);
    }

    /**
     * @deprecated
     */
    @Deprecated
    public WTCollection getResources(Rootable var1, WTPrincipal var2, ResourceUserType var3) throws WTException {
        QuerySpec var4 = this.getResourcesQuerySpec(var1);
        var4.appendAnd();
        SearchCondition var5 = new SearchCondition(PlanResource.class, "principalRef.key", "=", PersistenceHelper.getObjectIdentifier(var2));
        var4.appendWhere(var5, new int[]{0});
        var4.appendAnd();
        SearchCondition var6 = new SearchCondition(PlanResource.class, "userType", "=", var3);
        var4.appendWhere(var6, new int[]{0});
        QueryResult var7 = PersistenceServerHelper.manager.query(var4);
        return new WTArrayList(var7);
    }

    public WTCollection getResources(WTContainerRef var1, WTCollection var2, ResourceUserType var3) throws WTException {
        WTArrayList var4 = new WTArrayList();
        if (var1 != null && var2 != null && !var2.isEmpty()) {
            QuerySpec var5 = this.getResourcesQuerySpec(var1, true);
            var5.appendAnd();
            long[] var6 = ResourceUtils.extractDbIds(var2);
            SearchCondition var7 = new SearchCondition(new ClassAttribute(PlanResource.class, "principalRef.key.id"), "IN", new ArrayExpression(var6));
            var5.appendWhere(var7, new int[]{0});
            if (var3 != null) {
                var5.appendAnd();
                SearchCondition var8 = new SearchCondition(PlanResource.class, "userType", "=", var3);
                var5.appendWhere(var8, new int[]{0});
            }

            QueryResult var9 = PersistenceServerHelper.manager.query(var5);
            var4.addAll(var9);
        }

        return var4;
    }

    /**
     * @deprecated
     */
    @Deprecated
    public WTCollection getResources(Rootable var1, WTCollection var2, ResourceUserType var3) throws WTException {
        WTArrayList var4 = new WTArrayList();
        if (var1 != null && var2 != null && !var2.isEmpty()) {
            QuerySpec var5 = new QuerySpec();
            int var6 = var5.appendClassList(Resourceable.class, true);
            SearchCondition var7 = new SearchCondition(Resourceable.class, "rootReference.key", "=", PersistenceHelper.getObjectIdentifier(var1));
            var5.appendWhere(var7, new int[]{0});
            var5.appendAnd();
            long[] var8 = ResourceUtils.extractDbIds(var2);
            SearchCondition var9 = new SearchCondition(new ClassAttribute(PlanResource.class, "principalRef.key.id"), "IN", new ArrayExpression(var8));
            var5.appendWhere(var9, new int[]{0});
            if (var3 != null) {
                var5.appendAnd();
                SearchCondition var10 = new SearchCondition(PlanResource.class, "userType", "=", var3);
                var5.appendWhere(var10, new int[]{0});
            }

            ClassAttribute var12 = new ClassAttribute(PlanResource.class, "name");
            var5.appendOrderBy(new OrderBy(var12, false), new int[]{var6});
            QueryResult var11 = PersistenceServerHelper.manager.query(var5);
            var4.addAll(var11);
        }

        return var4;
    }

    public WTCollection findUserWithFullName(String var1) throws WTException {
        WTCollection var2 = this.getAllUsers(true, true);
        WTArrayList var3 = new WTArrayList();
        if (var2 != null) {
            Iterator var4 = var2.persistableIterator();

            while (true) {
                WTUser var5;
                String var6;
                String var7;
                do {
                    if (!var4.hasNext()) {
                        return var3;
                    }

                    var5 = (WTUser) var4.next();
                    var6 = var5.getFullName();
                    var7 = var6.replaceAll(",", "");
                } while (!var6.equals(var1) && !var7.equals(var1));

                var3.add(var5);
            }
        } else {
            return var3;
        }
    }

    public WTCollection findUserWithFullNameIncludeDeleted(String var1) throws WTException {
        WTCollection var2 = this.getAllUsers(true, false);
        WTArrayList var3 = new WTArrayList();
        if (var2 != null) {
            Iterator var4 = var2.persistableIterator();

            while (true) {
                WTUser var5;
                String var6;
                String var8;
                do {
                    if (!var4.hasNext()) {
                        return var3;
                    }

                    var5 = (WTUser) var4.next();
                    var6 = var5.getFullName();
                    String var7 = WTMessage.getLocalizedMessage("wt.access.accessResource", "22", (Object[]) null, SessionHelper.getLocale()).toLowerCase().trim();
                    if (var6.indexOf(var7) > 0) {
                        var6 = var6.substring(0, var6.indexOf(var7)).trim();
                    }

                    var8 = var6.replaceAll(",", "");
                } while (!var6.equals(var1) && !var8.equals(var1));

                var3.add(var5);
            }
        } else {
            return var3;
        }
    }

    public WTCollection synchronizeResources(WTContainerRef var1, List<ResourceUserType> var2) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("Entered synchronizeResources. plan: " + var1 + ", userTypeList: " + var2);
        }

        Object var3 = new WTArrayList();
        if (var1 != null && var2 != null && !var2.isEmpty()) {
            WTContainer var4 = var1.getReferencedContainer();
            ContainerTeam var5 = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged) var4);
            if (var5 == null) {
                throw new WTException("Container team not found");
            }

            WTHashSet var6 = new WTHashSet();
            WTCollection var7 = this.collectUsersAndGroups(var5, var2);
            if (!var7.isEmpty()) {
                var6.addAll(var7);
            }

            WTCollection var8 = this.collectRoleGroups(var5, var2);
            if (!var8.isEmpty()) {
                var6.addAll(var8);
            }

            if (log.isDebugEnabled()) {
                log.debug("team: " + var5 + ", usersAndGroups: " + var7 + ", roleGroups: " + var8);
            }

            WTCollection var9 = null;
            boolean var10 = SessionServerHelper.manager.setAccessEnforced(false);

            try {
                var9 = ResourceHelper.service.getResources(var1, var6, (ResourceUserType) null);
            } finally {
                SessionServerHelper.manager.setAccessEnforced(var10);
            }

            WTCollection var11 = this.getPrincipalsWithMissingResource(var6, var9);
            if (log.isDebugEnabled()) {
                log.debug("existingResources: " + var9 + ", principalsWithMissingResources: " + var11);
            }

            if (!var11.isEmpty()) {
                WTPrincipal var12 = null;
                String var13 = null;
                ResourceUserType var14 = null;
                PlanResource var15 = null;
                Iterator var16 = var11.persistableIterator();

                while (var16.hasNext()) {
                    var12 = (WTPrincipal) var16.next();
                    if (var12 instanceof WTUser) {
                        var13 = ((WTUser) var12).getFullName();
                        var14 = ResourceUserType.WINDCHILL_USER;
                    } else if (var12 instanceof WTGroup) {
                        if (var8.contains(var12)) {
                            var13 = var12.getPrincipalDisplayIdentifier();
                            var14 = ResourceUserType.WINDCHILL_TEAM_ROLE;
                        } else {
                            var13 = var12.getName();
                            var14 = ResourceUserType.WINDCHILL_GROUP;
                        }
                    }

                    var15 = ResourceHelper.service.createResource(var12, var1, var13, var14);
                    ((WTCollection) var3).add(var15);
                }

                if (!((WTCollection) var3).isEmpty()) {
                    var3 = PersistenceHelper.manager.save((WTCollection) var3);
                }
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("Exiting synchronizeResources. newResources: " + var3);
        }

        return (WTCollection) var3;
    }

    protected Resourceable saveResourceable(Resourceable var1) throws WTException {
        return (PlanResource) PersistenceHelper.manager.save(var1);
    }

    private static void rollUpCost(PlanResource var0) throws WTException, WTPropertyVetoException {
        WTCollection var1 = AssignmentHelper.service.getResourceAssignments(var0);
        Iterator var2 = var1.persistableIterator();

        while (var2.hasNext()) {
            ResourceAssignment var3 = (ResourceAssignment) var2.next();
            var3 = (ResourceAssignment) CostHelper.calculateAssignmentCost(var3);
            CostHelper.rollUpCost(var3);
            CostHelper.calculateResourceCost(var3);
        }

    }

    private static ResourceAssignment handleReplaceExistAssignment(ResourceAssignment var0, ResourceAssignment var1) throws WTException, WTPropertyVetoException {
        Duration var2 = var0.getTotalEffort();
        var2.setMillis(var2.getMillis() + var1.getRemainingEffort().getMillis());
        var0.setTotalEffort(var2);
        PlanActivity var3 = (PlanActivity) var0.getPlannable();
        TaskType var4 = var3.getTaskType();
        if (!TaskType.FIXED_UNITS.equals(var4) && !TaskType.FIXED_WORK.equals(var4)) {
            var0 = AssignmentHelper.service.calculateAssignmentUnits(var0, false);
        } else {
            var0 = AssignmentHelper.service.calculateAssignmentDuration(var0, false);
        }

        var0 = (ResourceAssignment) PersistenceHelper.manager.save(var0);
        var0 = AssignmentHelper.service.calculateAssignmentDuration(var0, false);
        var0.setFinishDate(ScheduleUtils.addWorkingDuration(var0.getStartDate(), var0.getDuration().getMillis()));
        var0 = (ResourceAssignment) AssignmentHelper.service.calculatePercentWorkComplete(var0);
        var0 = (ResourceAssignment) PersistenceHelper.manager.save(var0);
        return var0;
    }

    private static WTCollection getWtUsersWhoseResourcesNeedsToCreate(Rootable var0, Vector var1) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("getWtUsersWhoseResourcesNeedsToCreate In: team member size:" + var1.size());
        }

        ArrayList var2 = new ArrayList();
        WTHashSet var3 = new WTHashSet();
        if (var1 != null && var1.size() == 0) {
            return var3;
        } else {
            for (int var4 = 0; var4 < var1.size(); ++var4) {
                WTPrincipal var5 = ((WTPrincipalReference) var1.elementAt(var4)).getPrincipal();
                if (var5 instanceof WTUser) {
                    WTUser var6 = (WTUser) var5;
                    var3.add(var6);
                    var2.add(new Long(PersistenceHelper.getObjectIdentifier(var6).getId()));
                }
            }

            if (var2.size() != 0) {
                StandardResourceService var12 = newStandardResourceService();
                QuerySpec var13 = var12.getResourcesQuerySpec(((WTContained) var0).getContainerReference(), true);
                var13.appendAnd();
                SearchCondition var14 = new SearchCondition(new ClassAttribute(PlanResource.class, "principalRef.key.id"), "IN", new ArrayExpression(var2.toArray()));
                var13.appendWhere(var14, new int[]{0});
                if (log.isDebugEnabled()) {
                    log.debug("getWtUsersWhoseResourcesNeedsToCreate : Query spec :" + var13);
                }

                QueryResult var7 = PersistenceHelper.manager.find(var13);
                WTArrayList var8 = new WTArrayList(var7);
                Iterator var9 = var8.persistableIterator();

                while (var9.hasNext()) {
                    PlanResource var10 = (PlanResource) var9.next();
                    WTPrincipal var11 = var10.getPrincipalRef() != null ? var10.getPrincipalRef().getPrincipal() : null;
                    if (var11 != null && var3.contains(var11)) {
                        var3.remove(var11);
                        if (log.isDebugEnabled()) {
                            log.debug("getWtUsersWhoseResourcesNeedsToCreate : removed user as resource was already created" + var11);
                        }
                    }
                }
            }

            if (log.isDebugEnabled()) {
                log.debug("getWtUsersWhoseResourcesNeedsToCreate Out: wtUsers size:" + var3.size());
            }

            return var3;
        }
    }

    private WTCollection removeBaselinedResources(WTCollection var1) throws WTException {
        WTHashSet var2 = new WTHashSet();
        if (var1 != null && var1.size() > 0) {
            WTObject var3 = null;
            Iterator var4 = var1.persistableIterator();

            while (var4.hasNext()) {
                var3 = (WTObject) var4.next();
                if (!(var3 instanceof BaselinedPlanResource)) {
                    var2.add(var3);
                }
            }
        }

        return var2;
    }

    private WTCollection createSharedAssignmentDetails(ResourceAssignment var1, WTCollection var2) throws WTException {
        WTArrayList var3 = new WTArrayList();
        WTUser var4 = null;

        SharedAssignmentDetails var6;
        for (Iterator var5 = var2.persistableIterator(); var5.hasNext(); var3.add(var6)) {
            var4 = (WTUser) var5.next();
            var6 = AssignmentHelper.service.getSharedAssignmentDetail(var1, var4);
            if (var6 == null) {
                var6 = SharedAssignmentDetails.newSharedAssignmentDetail(var1, WTPrincipalReference.newWTPrincipalReference(var4));
            } else {
                try {
                    var6.setActive(true);
                } catch (WTPropertyVetoException var8) {
                    throw new WTException(var8);
                }
            }
        }

        return var3;
    }

    private void processRemoveGroupFromTeam(WTContainerRef var1, WTCollection var2, ResourceUserType var3) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("Entered processRemoveGroupFromTeam.\nallGroups: " + var2);
        }

        if (!var2.isEmpty()) {
            WTCollection var4 = this.getResources(var1, var2, var3);
            WTCollection var5 = AssignmentHelper.service.getAssignmentsForAssignmentGroups(var2, var1);
            if (log.isDebugEnabled()) {
                log.debug("allGroupResources: " + var4 + "\nallGroupAssignments: " + var5);
            }

            WTHashSet var6 = new WTHashSet();
            Transaction var7 = null;
            boolean var8 = SessionServerHelper.manager.setAccessEnforced(false);

            try {
                var7 = new Transaction();
                var7.start();
                if (var5 != null && !var5.isEmpty()) {
                    PlanResource var9 = null;
                    ResourceAssignment var10 = null;
                    Object var11 = null;
                    WTKeyedHashMap var12 = new WTKeyedHashMap();

                    Iterator var13;
                    for (var13 = var5.persistableIterator(); var13.hasNext(); ((WTCollection) var11).add(var10)) {
                        var10 = (ResourceAssignment) var13.next();
                        if (var10.isAcceptedAssignment()) {
                            var9 = this.getMatchingResource(var4, var10.getAssignmentGroup());
                        } else {
                            var9 = (PlanResource) var10.getResource();
                        }

                        var11 = (WTCollection) var12.get(var9);
                        if (var11 == null) {
                            var11 = new WTHashSet();
                            var12.put(var9, var11);
                        }
                    }

                    if (log.isDebugEnabled()) {
                        log.debug("resource2assignments: " + var12);
                    }

                    var13 = var4.persistableIterator();

                    label166:
                    while (true) {
                        while (true) {
                            if (!var13.hasNext()) {
                                break label166;
                            }

                            var9 = (PlanResource) var13.next();
                            WTCollection var17 = (WTCollection) var12.get(var9);
                            if (var17 != null && !var17.isEmpty()) {
                                this.reassignGroupAssignments(var9, SessionHelper.getPrincipal(), var1, var17);
                            } else {
                                var6.add(var9);
                            }
                        }
                    }
                } else {
                    var6.addAll(var4);
                }

                if (log.isDebugEnabled()) {
                    log.debug("resourcesToDelete: " + var6);
                }

                if (!var6.isEmpty()) {
                    PersistenceHelper.manager.delete(var6);
                }

                var7.commit();
                var7 = null;
            } finally {
                if (var7 != null) {
                    var7.rollback();
                }

                SessionServerHelper.manager.setAccessEnforced(var8);
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("Exiting processRemoveGroupFromTeam.");
        }

    }

    private PlanResource getMatchingResource(WTCollection var1, WTPrincipalReference var2) throws WTException {
        if (var2 != null && var1 != null) {
            PlanResource var3 = null;
            Iterator var4 = var1.persistableIterator();

            while (var4.hasNext()) {
                var3 = (PlanResource) var4.next();
                if (var2.equals(var3.getPrincipalRef())) {
                    return var3;
                }
            }
        }

        return null;
    }

    private void reassignGroupAssignments(PlanResource var1, WTPrincipal var2, WTContainerRef var3, WTCollection var4) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("Enetered reassignGroupAssignments. \n\tgroupResource: " + var1 + ", newUser: " + var2 + ", groupAssignments: " + var4);
        }

        if (var4 != null && !var4.isEmpty()) {
            ArrayList var5 = new ArrayList();
            WTCollection var6 = this.getResources(var3, var2, ResourceUserType.WINDCHILL_USER);
            PlanResource var7 = null;
            if (var6 != null && !var6.isEmpty()) {
                var7 = (PlanResource) var6.persistableIterator().next();
            } else {
                boolean var8 = SessionServerHelper.manager.setAccessEnforced(false);

                try {
                    var7 = this.createResource(var2, var3);
                } finally {
                    SessionServerHelper.manager.setAccessEnforced(var8);
                }
            }

            Iterator var44 = var4.persistableIterator();
            boolean var9 = false;

            while (var44.hasNext()) {
                ResourceAssignment var10 = (ResourceAssignment) var44.next();
                if (log.isDebugEnabled()) {
                    log.debug("Processing assignment " + var10);
                }

                WTCollection var11 = AssignmentHelper.service.getResourceAssignments(var10.getPlannable(), var7);
                Iterator var12 = var11.persistableIterator();
                Transaction var13 = new Transaction();

                try {
                    var13.start();
                    synchronized (var10) {
                        var10 = (ResourceAssignment) PersistenceHelper.manager.refresh(var10);
                        if (var10.getRemainingEffort() != null && var10.getRemainingEffort().getMillis() > 0L) {
                            if (var10.isSharedAssignment() || var10.isBulkAssignment()) {
                                WTHashSet var15 = new WTHashSet();
                                var15.addAll(AssignmentHelper.service.getSharedAssignmentDetails(var10));
                                if (!var15.isEmpty()) {
                                    PersistenceHelper.manager.delete(var15);
                                }
                            }

                            if (var12.hasNext()) {
                                ResourceAssignment var48 = (ResourceAssignment) var12.next();
                                if (log.isDebugEnabled()) {
                                    log.debug("Updating the assignment " + var48 + " for new resource");
                                }

                                AssignmentHelper.updateExistingAssignmentForNewResource(var10, var48);
                                PlanActivity var16 = (PlanActivity) var48.getPlannable();
                                if (var16.isInProcess()) {
                                    var5.add(var48);
                                }
                            } else {
                                var10 = this.convertToStandardAssignment(var10);
                                var10.setResource(var7);
                                var10 = (ResourceAssignment) PersistenceHelper.manager.save(var10);
                                if (log.isDebugEnabled()) {
                                    log.debug("Updating the assignment to be " + var10);
                                }

                                PlanActivity var49 = (PlanActivity) var10.getPlannable();
                                if (var49.isInProcess()) {
                                    var5.add(var10);
                                }
                            }
                        } else if (!var10.isAcceptedAssignment()) {
                            var9 = true;
                            if (log.isDebugEnabled()) {
                                log.debug("Assignment : " + var10.getPlannable().getName() + "-" + var10.getResource().getName() + " is Complete; skipping this resource");
                            }
                        }
                    }

                    var13.commit();
                    var13 = null;
                } catch (Exception var42) {
                    log.error(var42.getMessage());
                    throw new WTException(var42);
                } finally {
                    if (var13 != null) {
                        var13.rollback();
                    }

                }
            }

            try {
                rollUpCost(var7);
            } catch (WTPropertyVetoException var39) {
                throw new WTException(var39);
            }

            boolean var45 = SessionServerHelper.manager.setAccessEnforced(false);

            try {
                if (!var9) {
                    PersistenceHelper.manager.delete(var1);
                } else {
                    DeleteHelper.manager.markForDelete(var1);
                }
            } finally {
                SessionServerHelper.manager.setAccessEnforced(var45);
            }

            PlanHelper.service.propagateScheduleForAllPlans(var3);
            Iterator var46 = var5.iterator();

            while (var46.hasNext()) {
                ResourceAssignment var47 = (ResourceAssignment) var46.next();
                var47 = (ResourceAssignment) PersistenceHelper.manager.refresh(var47);
                PlannableUtils.sendResourceNotification(var47);
            }
        }

    }

    private ResourceAssignment convertToStandardAssignment(ResourceAssignment var1) throws WTException {
        if (var1 != null) {
            try {
                var1.setAssignmentType(ResourceAssignmentType.SINGLE);
                var1.setAssignmentState((ResourceAssignmentState) null);
                var1.setAssignmentGroup((WTPrincipalReference) null);
            } catch (WTPropertyVetoException var3) {
                throw new WTException(var3);
            }
        }

        return var1;
    }

    private void processPreDisableEvent(WTGroup var1) {
        if (var1.isInternal()) {
            Object var2 = null;
            if (MethodContext.getContext().get("ROLE_GROUPS_REMOVED_FROM_TEAM") == null) {
                var2 = new WTHashSet();
            } else {
                var2 = (WTCollection) MethodContext.getContext().get("ROLE_GROUPS_REMOVED_FROM_TEAM");
            }

            ((WTCollection) var2).add(var1);
            MethodContext.getContext().put("ROLE_GROUPS_REMOVED_FROM_TEAM", var2);
        }

    }

    private WTCollection collectUsersAndGroups(ContainerTeam var1, List<ResourceUserType> var2) throws WTException {
        WTArrayList var3 = new WTArrayList();
        if (var2.contains(ResourceUserType.WINDCHILL_USER) || var2.contains(ResourceUserType.WINDCHILL_GROUP)) {
            Vector var4 = var1.getMembers();
            WTArrayList var5 = new WTArrayList();
            WTArrayList var6 = new WTArrayList();
            WTPrincipal var7 = null;
            Iterator var8;
            if (var4 != null && !var4.isEmpty()) {
                var8 = var4.iterator();

                while (var8.hasNext()) {
                    var7 = ((WTPrincipalReference) var8.next()).getPrincipal();
                    if (var7 instanceof WTUser) {
                        var5.add(var7);
                    } else if (var7 instanceof WTGroup) {
                        var6.add(var7);
                    }
                }
            }

            if (var2.contains(ResourceUserType.WINDCHILL_USER)) {
                var8 = null;
                Iterator var9 = var6.persistableIterator();

                while (true) {
                    if (!var9.hasNext()) {
                        var3.addAll(var5);
                        break;
                    }

                    WTGroup var11 = (WTGroup) var9.next();
                    Enumeration var10 = OrganizationServicesHelper.manager.members(var11, true);

                    while (var10.hasMoreElements()) {
                        var5.add(var10.nextElement());
                    }
                }
            }

            if (var2.contains(ResourceUserType.WINDCHILL_GROUP)) {
                var3.addAll(var6);
            }
        }

        return var3;
    }

    private WTCollection collectRoleGroups(ContainerTeam var1, List<ResourceUserType> var2) throws WTException {
        Role var3 = null;
        WTGroup var4 = null;
        WTArrayList var5 = new WTArrayList();
        if (var2.contains(ResourceUserType.WINDCHILL_TEAM_ROLE)) {
            Vector var6 = var1.getRoles();
            if (var6 != null && !var6.isEmpty()) {
                Iterator var7 = var6.iterator();

                while (var7.hasNext()) {
                    var3 = (Role) var7.next();
                    var4 = ContainerTeamHelper.service.findContainerTeamGroup(var1, "roleGroups", var3.toString());
                    var5.add(var4);
                }
            }
        }

        return var5;
    }

    private WTCollection getPrincipalsWithMissingResource(WTCollection var1, WTCollection var2) throws WTException {
        if (var2 != null && !var2.isEmpty()) {
            WTArrayList var3 = new WTArrayList();
            WTValuedHashMap var4 = new WTValuedHashMap();
            PlanResource var5 = null;
            Iterator var6 = var2.persistableIterator();

            while (var6.hasNext()) {
                var5 = (PlanResource) var6.next();
                var4.put(var5.getPrincipalRef(), var5);
            }

            var6 = null;
            Iterator var7 = var1.persistableIterator();

            while (var7.hasNext()) {
                WTPrincipal var8 = (WTPrincipal) var7.next();
                if (var4.get(var8) == null) {
                    var3.add(var8);
                }
            }

            return var3;
        } else {
            return var1;
        }
    }

    private WTCollection getParentGroups(WTGroup var1) throws WTException {
        WTHashSet var2 = new WTHashSet();
        if (var1 != null) {
            Enumeration var3 = var1.parentGroups(true);

            for (WTPrincipalReference var4 = null; var3.hasMoreElements(); var2.add(var4)) {
                var4 = (WTPrincipalReference) var3.nextElement();
                if (log.isDebugEnabled()) {
                    log.debug("parentRef: " + var4);
                }
            }
        }

        return var2;
    }

    private Map<ResourceAssignmentType, WTCollection> groupAssignmentsByType(WTCollection var1) throws WTException {
        HashMap var2 = null;
        if (var1 != null && !var1.isEmpty()) {
            var2 = new HashMap();
            ResourceAssignment var3 = null;
            ResourceAssignmentType var4 = null;
            Object var5 = null;

            for (Iterator var6 = var1.persistableIterator(); var6.hasNext(); ((WTCollection) var5).add(var3)) {
                var3 = (ResourceAssignment) var6.next();
                var4 = var3.getAssignmentType();
                var5 = (WTCollection) var2.get(var4);
                if (var5 == null) {
                    var5 = new WTArrayList();
                    var2.put(var4, var5);
                }
            }
        }

        return var2;
    }

    static {
        try {
            log = LogR.getLogger(StandardResourceService.class.getName());
        } catch (Exception var1) {
            throw new ExceptionInInitializerError(var1);
        }
    }

    private class ActivityInfo {
        private PlanActivity activity;
        private long remainingWorkForDeletedAssignments = 0L;
        private long actualWorkForDeletedAssignments = 0L;
        private long totalWorkForDeletedAssignments = 0L;

        public ActivityInfo(PlanActivity var2) {
            this.activity = var2;
        }

        void addRemainingWork(long var1) {
            this.remainingWorkForDeletedAssignments += var1;
        }

        long getRemainingWorkForDeletedAssignments() {
            return this.remainingWorkForDeletedAssignments;
        }

        void addActualWork(long var1) {
            this.actualWorkForDeletedAssignments += var1;
        }

        long getActualWorkForDeletedAssignments() {
            return this.actualWorkForDeletedAssignments;
        }

        void addTotalWork(long var1) {
            this.totalWorkForDeletedAssignments += var1;
        }

        long getTotalWorkForDeletedAssignments() {
            return this.totalWorkForDeletedAssignments;
        }

        public boolean equals(Object var1) {
            return var1 == null ? false : var1.equals(this.activity);
        }
    }
}
