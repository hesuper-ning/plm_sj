/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.projectmanagement.plan;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.projectmanagement.plan.planResource")
public final class planResource_zh_CN extends WTListResourceBundle {
    /**
     * Entry Content
     **/
    @RBEntry("计划")
    public static final String PLAN = "PLAN";
    
    @RBEntry("计划:")
    @RBComment("Plan label on Create/Edit Deliverable step1")
    public static final String PLAN_1 = "PLAN_1";

    @RBEntry("计划")
    @RBComment("Title for the Plans table.")
    public static final String PLANS_TITLE = "PLANS_TITLE";

    @RBEntry("基线化计划")
    public static final String BASELINED_PLAN = "BASELINED_PLAN";

    @RBEntry("操作")
    @RBComment("Actions available on the row object")
    public static final String ACTIONS_TITLE = "ACTIONS_TITLE";

    @RBEntry("PBO 类型")
    @RBComment("Object type icon of the primary object of the workitem")
    public static final String PBO_TYPEICON_TITLE = "PBO_TYPEICON_TITLE";

    @RBEntry("无效的工期\n这不是一个有效的工期，或者它在此字段的范围之外。\n请参照以下格式输入: 4 工时 (或 4 工时),12 工作日 (或 12 工作日)")
    @RBComment("This is the generic MS project error message for invalid duration entries")
    public static final String INVALID_DURATIONFORMAT_ERROR = "INVALID_DURATIONFORMAT_ERROR";

    @RBEntry("前置任务字段包括一个无效的提前/延迟值。")
    @RBComment("This is the error message for invalid lead/lag entries")
    public static final String INVALID_LEADLAGFORMAT_ERROR = "INVALID_LEADLAGFORMAT_ERROR";

    @RBEntry("无效的工时\n这不是一个有效的工时，或者它在此字段的范围之外。\n请参照以下格式输入工时: 4 工时 (或 4 工时),12 工作日 (或 12 工作日)")
    @RBComment("This is the error message for invalid work entries")
    public static final String INVALID_WORKFORMAT_ERROR = "INVALID_WORKFORMAT_ERROR";

    @RBEntry("这不是一个有效的工期，或者它在此字段的范围之外。  \n工期不得少于 1 分钟。")
    @RBComment("This is the generic MS project error message for invalid duration entries.  Anything less than 1 minute is not allowed.")
    public static final String DURATIONFORMAT_OUT_OF_BOUNDS_ERROR = "DURATIONFORMAT_OUT_OF_BOUNDS_ERROR";

    @RBEntry("对于活动之间的关系，类型只能为正整数。")
    @RBComment("This is the generic MS project error message for invalid predecessor IDs")
    public static final String INVALID_PREDECESSORID_ERROR = "INVALID_PREDECESSORID_ERROR";

    @RBEntry("前置任务格式或约束无效。")
    @RBComment("This is the generic MS project error message for invalid precedence constraint entries")
    public static final String INVALID_PRECEDENCEFORMAT_ERROR = "INVALID_PRECEDENCEFORMAT_ERROR";

    @RBEntry("\n前置任务关系必须采用以下格式: \n  <前置任务 ID#><相关性类型> \n如果包括提前和延迟，则采用以下格式:\n  <前置任务 ID#><相关性类型><+ 或 -><持续时间> \n请勿在值之间加入空格。例如: 3FS+1.5工作日 或 18SS-5工时")
    @RBComment("This is to provide an example on how the predecessor should be defined.")
    public static final String INVALID_PRECEDENCEFORMAT_ERROR_INFO = "INVALID_PRECEDENCEFORMAT_ERROR_INFO";

    @RBEntry("必须指定相关性类型。要包括相关性类型，请使用格式: <前置任务 ID#><相关性类型><+ 或 -><持续时间> \n请勿在值之间加入空格。例如: 3FS+1.5工作日 或 18SS-5工时")
    @RBComment("This is the error that is displayed when the user enters lead/lag info without specifying the precedence constraint type")
    public static final String INVALID_PRECEDENCEFORMAT_LEADLAGERROR = "INVALID_PRECEDENCEFORMAT_LEADLAGERROR";

    @RBEntry("ID")
    @RBComment("Label for ID")
    public static final String ID = "ID";

    @RBEntry("基线 ID")
    @RBComment("Label for Baseline ID")
    public static final String BASELINE_ID = "BASELINE_ID";

    @RBEntry("修改者")
    @RBComment(" Label for Modified By")
    public static final String MODIFIED_BY = "MODIFIED_BY";

    @RBEntry("属性")
    @RBComment(" Header for Attributes table")
    public static final String ATTRIBUTE_TABLE_NAME = "ATTRIBUTE_TABLE_NAME";

    @RBEntry("前置任务")
    @RBComment(" Label for Predecessor table")
    public static final String PREDECESSOR = "PREDECESSOR";

    @RBEntry("名称")
    @RBComment(" Label for Activity Name")
    public static final String NAME = "NAME";

    @RBEntry("类型")
    @RBComment(" Label for Activity precedence type")
    public static final String TYPE = "TYPE";

    @RBEntry("估计开始时间")
    @RBComment(" Label for Activity Start")
    public static final String ACTIVITY_START = "ACTIVITY_START";

    @RBEntry("估计基线开始")
    @RBComment(" Label for Baseline Activity Start")
    public static final String BASELINE_ACTIVITY_START = "BASELINE_ACTIVITY_START";

    @RBEntry("估计开始时间差异")
    @RBComment(" Label for Activity Start Variance")
    public static final String ACTIVITY_START_VARIANCE = "ACTIVITY_START_VARIANCE";

    @RBEntry("估计完成时间")
    @RBComment(" Label for Activity Finish")
    public static final String ACTIVITY_FINISH = "ACTIVITY_FINISH";

    @RBEntry("估计基线完成")
    @RBComment(" Label for Baseline Activity Finish")
    public static final String BASELINE_ACTIVITY_FINISH = "BASELINE_ACTIVITY_FINISH";

    @RBEntry("估计完成时间差异")
    @RBComment(" Label for Activity Finish Variance")
    public static final String ACTIVITY_FINISH_VARIANCE = "ACTIVITY_FINISH_VARIANCE";

    @RBEntry("实际开始时间")
    @RBComment(" Label for Activity ActualStart")
    public static final String ACTIVITY_ACTUALSTART = "ACTIVITY_ACTUALSTART";

    @RBEntry("基线实际开始")
    @RBComment(" Label for Baseline Activity ActualStart")
    public static final String BASELINE_ACTIVITY_ACTUALSTART = "BASELINE_ACTIVITY_ACTUALSTART";

    @RBEntry("实际完成时间")
    @RBComment(" Label for Activity ActualFinish")
    public static final String ACTIVITY_ACTUALFINISH = "ACTIVITY_ACTUALFINISH";

    @RBEntry("基线实际完成")
    @RBComment(" Label for Baseline Activity ActualFinish")
    public static final String BASELINE_ACTIVITY_ACTUALFINISH = "ACTIVITY_BASELINE_ACTUALFINISH";

    @RBEntry("资源")
    @RBComment(" Label for resources")
    public static final String RESOURCES = "RESOURCES";

    @RBEntry("基线单位")
    @RBComment(" Label for assigned baseline resource units")
    public static final String BASELINE_UNITS = "BASELINE_UNITS";

    @RBEntry("单位")
    @RBComment(" Label for assigned resource units")
    public static final String UNITS = "UNITS";

    @RBEntry("工时")
    @RBComment("Label for Work")
    public static final String WORK = "WORK";

    @RBEntry("实际工时")
    @RBComment("Label for Work")
    public static final String ACTUALWORK = "ACTUALWORK";

    @RBEntry("基线实际工时")
    @RBComment("Label for Work")
    public static final String BASELINE_ACTUALWORK = "BASELINE_ACTUALWORK";

    @RBEntry("剩余工时")
    @RBComment("Label for Work")
    public static final String REMAININGWORK = "REMAININGWORK";

    @RBEntry("基线剩余工时")
    @RBComment("Label for Baseline Remaining Work")
    public static final String BASELINE_REMAININGWORK = "BASELINE_REMAININGWORK";

    @RBEntry("剩余工时差异")
    @RBComment("Label for Remaining Work Variance")
    public static final String REMAININGWORK_VARIANCE = "REMAININGWORK_VARIANCE";

    @RBEntry("完工率")
    @RBComment("Label for Work")
    public static final String PERCENTWORKCOMPLETE = "PERCENTWORKCOMPLETE";

    @RBEntry("基线工时完成百分比")
    @RBComment("Label for Baseline % Work Complete")
    public static final String BASELINE_PERCENTWORKCOMPLETE = "BASELINE_PERCENTWORKCOMPLETE";

    @RBEntry("完工率差异")
    @RBComment("Label for % Work Complete Variance")
    public static final String PERCENTWORKCOMPLETE_VARIANCE = "PERCENTWORKCOMPLETE_VARIANCE";

    @RBEntry("必须指定工期。")
    public static final String NO_DURATION_SPECIFIED = "NO_DURATION_SPECIFIED";

    @RBEntry("延迟")
    @RBComment(" Label for Activity precedence lead or lag value")
    public static final String LEAD_LAG = "LEAD_LAG";

    @RBEntry("导入计划")
    @RBComment(" Label for Import Plan Wizard")
    public static final String IMPORT_WIZARD_TITLE = "IMPORT_WIZARD_TITLE";

    @RBEntry("错误报告")
    @RBComment(" Label for error report Wizard")
    public static final String ERROR_WIZARD_TITLE = "ERROR_WIZARD_TITLE";

    @RBEntry("项目计划文件")
    @RBComment(" Label for Project Plan File")
    public static final String NATIVE_FILE = "NATIVE_FILE";

    @RBEntry("(例如: .mpp)")
    @RBComment(" Label for Native file Type")
    public static final String NATIVE_FILE_TYPE = "NATIVE_FILE_TYPE";

    @RBEntry("导入模式")
    @RBComment(" Label for Import Mode")
    public static final String FILE_IMPORTMODE = "FILE_IMPORTMODE";

    @RBEntry("导入文件时出错。")
    @RBComment(" File Import Error")
    public static final String FILE_IMPORT_ERROR = "FILE_IMPORT_ERROR";

    @RBEntry("新建活动")
    @RBComment(" Title for Create Activity Wizard")
    public static final String CREATE_ACTIVITY_WIZARD_TITLE = "CREATE_ACTIVITY_WIZARD_TITLE";

    @RBEntry("活动名称")
    @RBComment(" Label for Activity Name")
    public static final String ACTIVITY_NAME = "ACTIVITY_NAME";

    @RBEntry("估计开始时间")
    @RBComment(" Label for Estimated Start")
    public static final String ESTIMATE_START = "ESTIMATE_START";

    @RBEntry("估计完成时间")
    @RBComment(" Label for Estimated Finish")
    public static final String ESTIMATE_FINISH = "ESTIMATE_FINISH";

    @RBEntry("工期")
    @RBComment(" Label for Duration")
    public static final String ESTIMATE_DURATION = "ESTIMATE_DURATION";

    @RBEntry("前置任务")
    @RBComment(" Label for Predecessors")
    public static final String PRECEDENCE_CONSTRAINT = "PRECEDENCE_CONSTRAINT";

    @RBEntry("编辑活动")
    @RBComment(" Title for Edit Activity Wizard")
    public static final String EDIT_ACTIVITY_WIZARD_TITLE = "EDIT_ACTIVITY_WIZARD_TITLE";

    @RBEntry("工期")
    @RBComment(" Duration Column Label")
    public static final String ACTIVITY_DURATION = "ACTIVITY_DURATION";

    @RBEntry("基线工期")
    @RBComment(" Duration Column Label")
    public static final String BASELINE_DURATION = "BASELINE_DURATION";

    @RBEntry("工期差异")
    @RBComment(" Duration Column Label")
    public static final String DURATION_VARIANCE = "DURATION_VARIANCE";

    @RBEntry("前置任务")
    @RBComment(" Predecessor Column Label")
    public static final String ACTIVITY_PREDECESSOR = "ACTIVITY_PREDECESSOR";

    @RBEntry("汇总活动")
    @RBComment(" Object type displayed on Info page of Activity")
    public static final String SUMMARY_ACTIVITY = "SUMMARY_ACTIVITY";

    @RBEntry("活动")
    @RBComment(" Object type displayed on Info page of Activity")
    public static final String ACTIVITY = "ACTIVITY";

    @RBEntry("里程碑")
    @RBComment(" Object type displayed on Info page of Activity")
    public static final String MILESTONE = "MILESTONE";

    @RBEntry("将活动标记为里程碑")
    @RBComment("Mark the Activity as Milestone")
    public static final String MARK_AS_MILESTONE = "MARK_AS_MILESTONE";

    @RBEntry("任务类型")
    @RBComment(" Task type displayed on Info page of Activity")
    public static final String TASK_TYPE = "TASK_TYPE";

    @RBEntry("任务类型 (活动)")
    @RBComment(" Label for Task Type (Activity) Column")
    public static final String TASK_TYPE_ACTIVITY = "TASK_TYPE_ACTIVITY";

    @RBEntry("基线任务类型")
    @RBComment(" Baseline Task type displayed on Info page of Activity")
    public static final String BASELINE_TASK_TYPE = "BASELINE_TASK_TYPE";

    @RBEntry("投入比导向")
    @RBComment(" Effort driven value displayed on Info page header of Activity")
    public static final String EFFORT_DRIVEN = "EFFORT_DRIVEN";

    @RBEntry("基线投入比导向")
    @RBComment(" Baseline Effort driven value displayed on Info page header of Activity")
    public static final String BASELINE_EFFORT_DRIVEN = "BASELINE_EFFORT_DRIVEN";

    @RBEntry("固定单位")
    @RBComment(" Fixed Units Task type displayed on Info page header of Activity")
    public static final String FIXED_UNITS = "FIXED_UNITS";

    @RBEntry("固定工时")
    @RBComment(" Fixed Work Task type displayed on Info page header of Activity")
    public static final String FIXED_WORK = "FIXED_WORK";

    @RBEntry("固定工期")
    @RBComment(" Fixed Duration Task type displayed on Info page header of Activity")
    public static final String FIXED_DURATION = "FIXED_DURATION";

    @RBEntry("请只选择一行。")
    @RBComment("Javascript error message shown when user selects multiple rows")
    public static final String INVALID_PASTE_LOCATION_TOO_MANY = "INVALID_PASTE_LOCATION_TOO_MANY";

    @RBEntry("请先选择一行。")
    @RBComment("Javascript error message shown when user selects no rows")
    public static final String INVALID_PASTE_LOCATION_NONE = "INVALID_PASTE_LOCATION_NONE";

    @RBEntry("无效操作。不能在计划节点之上粘贴。请选择该节点以下的行。")
    @RBComment("Javascript error message shown when user selects the plan row")
    public static final String INVALID_PASTE_LOCATION_PLAN_SELECTED = "INVALID_PASTE_LOCATION_PLAN_SELECTED";

    @RBEntry("无效操作。不支持在多个计划之间剪切、复制和粘贴。")
    @RBComment("Plan object's owning plan does not match with the plan object at the paste target location")
    public static final String INVALID_PLAN_OBJECT_IN_MOVE = "INVALID_PLAN_OBJECT_IN_MOVE";

    @RBEntry("无效操作。剪贴板操作中不能包括计划节点。")
    @RBComment("In Paste action if one of the objects selected in the cut or copy action before the paste action is a plan object then this error message is thrown since plan can not be pasted.")
    public static final String PLAN_ROW_MOVE_ERROR = "PLAN_ROW_MOVE_ERROR";

    @RBEntry("无效操作。不能删除计划节点。")
    @RBComment("In Delete action if one of the objects selected is a plan object then this error message is thrown since plan can not be deleted.")
    public static final String PLAN_ROW_DELETE_ERROR = "PLAN_ROW_DELETE_ERROR";

    @RBEntry("无效操作。不能将计划节点降级。")
    @RBComment("In indent action if one of the objects selected is Plan then this error message is thrown since plan can not be indented.")
    public static final String PLAN_ROW_INDENT_ERROR = "PLAN_ROW_INDENT_ERROR";

    @RBEntry("'{0}' 是汇总活动。删除该活动将删除其所有子活动。\n要继续，请单击“确定”。")
    @RBComment(" Single summary activity delete confirmation.")
    public static final String SINGLE_SUMMARY_DELETE_CONFIRMATION = "SINGLE_SUMMARY_DELETE_CONFIRMATION";

    @RBEntry("某些选定活动是汇总活动。删除这些汇总活动将删除其所有子活动。\n要继续，请单击“确定”。")
    @RBComment(" More than one Summary Activity delete confirmation.")
    public static final String MULTI_SUMMARY_DELETE_CONFIRMATION = "MULTI_SUMMARY_DELETE_CONFIRMATION";

    @RBEntry("汇总活动与其子活动之间不能存在前置任务关系。如果继续，前置依存关系将被移除。\n要继续并移除无效相关性，请单击“确定”。")
    @RBComment("A summary activity cannot be linked to one of its child activities.  To cancel this operation, click Cancel.  To continue and remove the invalid dependency, click Ok.")
    public static final String MOVE_ACTIVITY_CONFIRMATION = "MOVE_ACTIVITY_CONFIRMATION";
    
    @RBEntry("此操作会将以下活动移至“正在处理”状态，并移除所有开始日期和前置任务约束: {0}。这些更改将在计划恢复时生效。 \n单击“确定”继续。")
    @RBComment("A summary activity is SCHEDULED and user trys to paste SUSPENDED activity in this summary then we are starting the summary when plan resumed.")
    public static final String REMOVE_DATE_PREDECESSOR_CONSTRAINTS_CONFIRMATION = "REMOVE_DATE_PREDECESSOR_CONSTRAINTS_CONFIRMATION";

    @RBEntry("计划开始")
    @RBComment(" Label for plan start on info page")
    public static final String PLAN_START = "PLAN_START";

    @RBEntry("开始时间")
    @RBComment(" Label for default plan start")
    public static final String PLAN_DEFAULT_START = "PLAN_DEFAULT_START";

    @RBEntry("完成时间")
    @RBComment(" Label for plan finish on info page")
    public static final String PLAN_FINISH = "PLAN_FINISH";

    @RBEntry("工期")
    @RBComment(" Label for plan duration on info page")
    public static final String PLAN_DURATION = "PLAN_DURATION";

    @RBEntry("日历")
    @RBComment("Label for plan calendar on info page")
    public static final String CALENDAR = "CALENDAR";

    @RBEntry("编辑计划")
    @RBComment(" Title for Edit Plan Wizard")
    public static final String EDIT_PLAN_WIZARD_TITLE = "EDIT_PLAN_WIZARD_TITLE";

    @RBEntry("计划名称")
    @RBComment(" Label for Plan Name")
    public static final String PLAN_NAME = "PLAN_NAME";

    @RBEntry("(计算的)")
    @RBComment(" Value for Auto Calculated textfield")
    public static final String AUTO_CALCULATED = "AUTO_CALCULATED";

    @RBEntry("条目")
    @RBComment(" Value for Entry View")
    public static final String VIEW_ENTRY = "VIEW_ENTRY";

    @RBEntry("条目视图")
    @RBComment(" Description for Entry View")
    public static final String VIEW_ENTRY_DESC = "VIEW_ENTRY_DESC";

    @RBEntry("使用关系")
    @RBComment(" Value for Usage View")
    public static final String VIEW_USAGE = "VIEW_USAGE";

    @RBEntry("使用关系视图")
    @RBComment(" Description for Usage View")
    public static final String VIEW_USAGE_DESC = "VIEW_USAGE_DESC";

    @RBEntry("工时")
    @RBComment(" Value for Work View")
    public static final String VIEW_WORK = "VIEW_WORK";

    @RBEntry("基线工时")
    @RBComment(" Value for Baseline Work")
    public static final String BASELINE_WORK = "BASELINE_WORK";

    @RBEntry("工时差异")
    @RBComment(" Value for Work Variance")
    public static final String WORK_VARIANCE = "WORK_VARIANCE";

    @RBEntry("对象类型")
    @RBComment(" Value for Object Type")
    public static final String SOFT_TYPE = "SOFT_TYPE";
    
    @RBEntry("计划的执行控制")
    @RBComment(" Value for Execution Control Of Plan")
    public static final String EXECUTION_CONTROL_OF_PLAN = "EXECUTION_CONTROL_OF_PLAN";
    
    @RBEntry("版本")
    public static final String VERSION = "VERSION";
    

    @RBEntry("工时视图")
    @RBComment(" Description for Work View")
    public static final String VIEW_WORK_DESC = "VIEW_WORK_DESC";

    @RBEntry("成本")
    @RBComment(" Value for Cost View")
    public static final String VIEW_COST = "VIEW_COST";

    @RBEntry("成本视图")
    @RBComment(" Description for Cost View")
    public static final String VIEW_COST_DESC = "VIEW_COST_DESC";

    @RBEntry("汇总")
    @RBComment(" Value for Summary View")
    public static final String VIEW_SUMMARY = "VIEW_SUMMARY";

    @RBEntry("汇总视图")
    @RBComment(" Description for Summary View")
    public static final String VIEW_SUMMARY_DESC = "VIEW_SUMMARY_DESC";

    @RBEntry("跟踪")
    @RBComment("Value for Tracking View")
    public static final String VIEW_TRACKING = "VIEW_TRACKING";

    @RBEntry("跟踪视图")
    @RBComment("Description for Tracking View")
    public static final String VIEW_TRACKING_DESC = "VIEW_TRACKING_DESC";

    @RBEntry("基线比较")
    @RBComment("Value for Baseline Compare View")
    public static final String VIEW_BASELINE_COMPARE = "VIEW_BASELINE_COMPARE";

    @RBEntry("基线比较视图")
    @RBComment("Description for Baseline Compare View")
    public static final String VIEW_BASELINE_COMPARE_DESC = "VIEW_BASELINE_COMPARE_DESC";

    @RBEntry("全部")
    @RBComment("Name of the only view relevant for the Plans table.")
    public static final String VIEW_ALL = "VIEW_ALL";

    @RBEntry("所有视图")
    @RBComment("Description for the only view relevant for the Plans table.")
    public static final String VIEW_ALL_DESC = "VIEW_ALL_DESC";

    @RBEntry("否")
    @RBComment(" Value for Effort Driven")
    public static final String NO = "NO";

    @RBEntry("是")
    @RBComment(" Value for Effort Driven")
    public static final String YES = "YES";

    @RBEntry("货币符号")
    @RBComment("Currency Symbol")
    public static final String CURRENCY_SYMBOL = "CURRENCY_SYMBOL";

    @RBEntry("设置默认货币符号。")
    @RBComment("Description for a preference,shown in description column in Preferences table")
    public static final String CURRENCY_SYMBOL_DESC = "CURRENCY_SYMBOL_DESC";


    @RBEntry("此首选项设置“项目计划”页面上使用的默认货币符号。项目经理可以在以后通过编辑计划自定义该值。<br>在该字段中输入符号可设置新的默认值。初始默认值为 $。")
    @RBComment("Description for a preference,shown in description column in Preferences table")
    public static final String CURRENCY_SYMBOL_DESC_LONG = "CURRENCY_SYMBOL_DESC_LONG";

    @RBEntry("货币符号放置")
    @RBComment("Currency Placement")
    public static final String CURRENCY_PLACEMENT = "CURRENCY_PLACEMENT";

    @RBEntry("设置默认货币符号放置。")
    @RBComment("Description for a preference,shown in description column in Preferences table")
    public static final String CURRENCY_PLACEMENT_DESC = "CURRENCY_PLACEMENT_DESC";

    @RBEntry("此首选项确定货币符号相对于成本金额的默认放置位置。项目经理可以在以后通过编辑计划自定义该值。<br>默认值为<b>前</b>。")
    @RBComment("Description for a preference,shown in description column in Preferences table")
    public static final String CURRENCY_PLACEMENT_DESC_LONG = "CURRENCY_PLACEMENT_DESC_LONG";

    @RBEntry("货币小数位数")
    @RBComment("Currency Decimal Digits")
    public static final String CURRENCY_DECIMAL_DIGITS = "CURRENCY_DECIMAL_DIGITS";

    @RBEntry("设置成本金额使用的默认小数位数。")
    @RBComment("Currency Decimal Digits")
    public static final String CURRENCY_DECIMAL_DIGITS_DESC = "CURRENCY_DECIMAL_DIGITS_DESC";

    @RBEntry("此首选项确定显示计划成本时使用的默认小数位数。项目经理可以在以后通过编辑计划自定义该值。<br>可选的值为 0、1 或 2。例如，如果成本是 25 美元:<ul><li>0 = 25</li><li>1 = 25.0</li><li>2 = 25.00</li></ul> 默认值为 0。")
    @RBComment("Currency Decimal Digits")
    public static final String CURRENCY_DECIMAL_DIGITS_DESC_LONG = "CURRENCY_DECIMAL_DIGITS_DESC_LONG";

    @RBEntry("前")
    @RBComment("'Before' refers to the default placement of the currency symbol.")
    public static final String BEFORE_PREF_CHOICE = "BEFORE_PREF_CHOICE";

    @RBEntry("后")
    @RBComment("'After' refers to the default placement of the currency symbol.")
    public static final String AFTER_PREF_CHOICE = "AFTER_PREF_CHOICE";


    @RBEntry("前加空格")
    @RBComment("'Before' refers to the default placement of the currency symbol.")
    public static final String BRFORE_WITH_SPACE_PREF_CHOICE = "BEFORE_WITH_SPACE_PREF_CHOICE";

    @RBEntry("后加空格")
    @RBComment("'After' refers to the default placement of the currency symbol.")
    public static final String AFTER_WITH_SPACE_PREF_CHOICE = "AFTER_WITH_SPACE_PREF_CHOICE";

    @RBEntry("0")
    @RBComment("ZERO_PREF_CHOICE")
    public static final String ZERO_PREF_CHOICE = "ZERO_PREF_CHOICE";

    @RBEntry("1")
    @RBComment("ONE_PREF_CHOICE")
    public static final String ONE_PREF_CHOICE = "ONE_PREF_CHOICE";

    @RBEntry("2")
    @RBComment("TWO_PREF_CHOICE")
    public static final String TWO_PREF_CHOICE = "TWO_PREF_CHOICE";

    @RBEntry("成本")
    @RBComment("Label for Cost")
    public static final String TOTAL_COST = "TOTAL_COST";

    @RBEntry("基线成本")
    @RBComment("Label for Baseline Cost")
    public static final String BASELINE_TOTAL_COST = "BASELINE_TOTAL_COST";

    @RBEntry("成本差异")
    @RBComment("Label for Cost Variance")
    public static final String TOTAL_COST_VARIANCE = "TOTAL_COST_VARIANCE";

    @RBEntry("固定成本")
    @RBComment("Label for Fixed Cost")
    public static final String FIXED_COST = "FIXED_COST";

    @RBEntry("基线固定成本")
    @RBComment("Label for Baseline Fixed Cost")
    public static final String BASELINE_FIXED_COST = "BASELINE_FIXED_COST";

    @RBEntry("总成本")
    @RBComment("Label for Total Cost")
    public static final String PLAN_TOTAL_COST = "PLAN_TOTAL_COST";

    @RBEntry("所有者")
    @RBComment("Lable for Owner")
    public static final String ACTIVITY_OWNER = "ACTIVITY_OWNER";

    @RBEntry("所有者")
    @RBComment("Lable for Owner")
    public static final String PLAN_OWNER = "PLAN_OWNER";
    
    @RBEntry("基线所有者")
    @RBComment("Lable for Baseline Owner")
    public static final String BASELINE_ACTIVITY_OWNER = "BASELINE_ACTIVITY_OWNER";

    @RBEntry("仅项目成员")
    public static final String PROJECT_PRIVATE = "PROJECT_PRIVATE";

    @RBEntry("仅项目群成员")
    public static final String PROGRAM_PRIVATE = "PROGRAM_PRIVATE";

    @RBEntry("无效的值。请输入一个介于 0 和 100 之间的数字。")
    public static final String TRACK_ACTIVITY_WORK_JS_VALIDATION_PERCENT_ERROR = "TRACK_ACTIVITY_WORK_JS_VALIDATION_PERCENT_ERROR";

    @RBEntry("一旦应用这些更改，一个或多个资源所记录的实际工时将大于其已安排工时。\n“实际工时”值必须小于等于“已安排工时”值。\n要继续并减少“实际工时”值以匹配新的“已安排工时”值，请单击“确定”。")
    public static final String SCHEDULE_WORK_CHANGE_WARNING_ACTIVITY = "SCHEDULE_WORK_CHANGE_WARNING_ACTIVITY";

    @RBEntry("分配资源")
    @RBComment("To assign resources to an Activity")
    public static final String ASSIGN_RESOURCE_TITLE = "ASSIGN_RESOURCE_TITLE";

    /**
     * Column titles for New Plan Project Tasks/My Tasks
     **/
    @RBEntry("项目工作分配")
    public static final String PROJECT_ASSIGNMENTS = "PROJECT_ASSIGNMENTS";

    @RBEntry("已重新分配")
    @RBComment("Reassigned icon of the row object")
    public static final String REASSIGNED_TITLE = "REASSIGNED_TITLE";

    @RBEntry("已接受")
    @RBComment("View accepted tasks.")
    public static final String ACCEPTED = "ACCEPTED";

    @RBEntry("已委派")
    @RBComment("View delegated tasks.")
    public static final String DELEGATED = "DELEGATED";

    @RBEntry("名称")
    @RBComment("Display name of the row object")
    public static final String NAME_TITLE = "NAME_TITLE";

    @RBEntry("主题")
    public static final String SUBJECT_TITLE = "SUBJECT_TITLE";

    @RBEntry("状态")
    @RBComment("The lifecycle state of the subject business object")
    public static final String SUBJECT_STATE_TITLE = "SUBJECT_STATE_TITLE";

    @RBEntry("已分配")
    @RBComment("The date (year-month-day) the work was assigned")
    public static final String ASSIGNED_DATE_TITLE = "ASSIGNED_DATE_TITLE";

    @RBEntry("所有者")
    public static final String OWNER_TITLE = "OWNER_TITLE";

    @RBEntry("角色")
    public static final String ROLE_TITLE = "ROLE_TITLE";

    @RBEntry("完成")
    @RBComment("The percentage of the task which is complete")
    public static final String PERCENT_DONE_TITLE = "PERCENT_DONE_TITLE";

    @RBEntry("创建者")
    public static final String CREATED_BY_TITLE = "CREATED_BY_TITLE";

    @RBEntry("最后期限")
    public static final String DEADLINE_COLUMN_LBL = "DEADLINE_COLUMN_LBL";

    @RBEntry("基线期限")
    public static final String BASELINE_DEADLINE_COLUMN_LBL = "BASELINE_DEADLINE_COLUMN_LBL";

    @RBEntry("上下文")
    @RBComment("The name of the containing project or product")
    public static final String CONTEXT_TITLE = "CONTEXT_TITLE";

    @RBEntry("任务")
    @RBComment("Display name of the assignments table")
    public static final String ASSIGNMENT_TABLE_TITLE = "ASSIGNMENT_TABLE_TITLE";

    @RBEntry("状况")
    @RBComment("The health status of the task")
    public static final String HEALTH_STATUS_TITLE = "HEALTH_STATUS_TITLE";

    /**
     * drop down view list
     **/
    @RBEntry("打开")
    public static final String VIEW_OPEN_WORK = "VIEW_OPEN_WORK";

    @RBEntry("可交付结果")
    public static final String VIEW_MY_DELIVERABLES = "VIEW_MY_DELIVERABLES";

    @RBEntry("计划工作分配")
    public static final String VIEW_MY_PLANASSIGNMENTS = "VIEW_MY_PLANASSIGNMENTS";

    @RBEntry("里程碑")
    public static final String VIEW_MY_MILESTONES = "VIEW_MY_MILESTONES";

    @RBEntry("活动")
    public static final String VIEW_MY_ACTIVITIES = "VIEW_MY_ACTIVITIES";

    @RBEntry("打开")
    public static final String VIEW_OPEN = "VIEW_OPEN";

    @RBEntry("按截止日期的未结项")
    public static final String VIEW_OPEN_WORK_BY_DUE_DATE = "VIEW_OPEN_WORK_BY_DUE_DATE";

    @RBEntry("工作流任务")
    public static final String VIEW_MY_TASKS = "VIEW_MY_TASKS";

    @RBEntry("已分配给我的")
    public static final String VIEW_WORKITEMS_I_OWN = "VIEW_WORKITEMS_I_OWN";

    @RBEntry("已关闭")
    public static final String VIEW_CLOSED_WORK = "VIEW_CLOSED_WORK";

    @RBEntry("全部")
    public static final String VIEW_ALL_WORKITEMS = "VIEW_ALL_WORKITEMS";

    @RBEntry("所有措施项")
    public static final String VIEW_ACTION_ITEMS = "VIEW_ACTION_ITEMS";

    @RBEntry("我拥有的措施项")
    public static final String VIEW_MY_ACTION_ITEMS = "VIEW_MY_ACTION_ITEMS";

    @RBEntry("我拥有的打开措施项")
    public static final String VIEW_MY_OPEN_ACTION_ITEMS = "VIEW_MY_OPEN_ACTION_ITEMS";

    @RBEntry("我创建的措施项")
    public static final String VIEW_CREATED_ACTION_ITEMS = "VIEW_CREATED_ACTION_ITEMS";

    @RBEntry("我创建的开启措施项")
    public static final String VIEW_CREATED_OPEN_ACTION_ITEMS = "VIEW_CREATED_OPEN_ACTION_ITEMS";

    @RBEntry("所有开启的措施项")
    public static final String VIEW_OPEN_ACTION_ITEMS = "VIEW_OPEN_ACTION_ITEMS";

    @RBEntry("所有计划可交付结果")
    public static final String VIEW_PLANDELIVERABLES = "VIEW_PLANDELIVERABLES";

    @RBEntry("差异报告")
    public static final String VIEW_PLANDELIVERABLES_VARIANCE = "VIEW_PLANDELIVERABLES_VARIANCE";

    @RBEntry("所有计划活动")
    public static final String VIEW_PLANACTIVITIES = "VIEW_PLANACTIVITIES";

    @RBEntry("所有计划工作分配")
    public static final String VIEW_PLANASSIGNMENTS = "VIEW_PLANASSIGNMENTS";

    @RBEntry("已讨论")
    public static final String DISCUSSED = "DISCUSSED";

    @RBEntry("已逾期")
    @RBComment("View overdue tasks.")
    public static final String ISOVERDUE = "ISOVERDUE";

    @RBEntry("分配给我")
    @RBComment("View assignments owned by me.")
    public static final String ISASSIGNEDTOME = "ISASSIGNEDTOME";

    @RBEntry("未完成的工作分配")
    @RBComment("View uncompleted assignments.")
    public static final String OPENASSIGNMENTS = "OPENASSIGNMENTS";

    @RBEntry("由我创建")
    @RBComment("View assignments created by me.")
    public static final String ISCREATEDBYME = "ISCREATEDBYME";

    @RBEntry("任务类型")
    @RBComment("Specify work type.")
    public static final String TASKTYPE = "TASKTYPE";

    @RBEntry("已重新分配")
    @RBComment("Tooltip/Description for icon representing whether a task has been reassigned.")
    public static final String REASSIGNED = "REASSIGNED";

    @RBEntry("(多个)")
    @RBComment("Used in Assignments and Action Items tables when an Action Item has multiple subjects.")
    public static final String MULTIPLE = "MULTIPLE";

    @RBEntry("基线状况")
    @RBComment("Baseline Health Status Label")
    public static final String BASELINE_HEALTH_STATUS_LABEL = "BASELINE_HEALTH_STATUS_LABEL";

    @RBEntry("状况")
    @RBComment("Health Status Label")
    public static final String HEALTH_STATUS_LABEL = "HEALTH_STATUS_LABEL";

    @RBEntry("状况 (活动)")
    @RBComment("Label for Status (Activity) Column")
    public static final String HEALTH_STATUS_ACTIVITY_LABEL = "HEALTH_STATUS_ACTIVITY_LABEL";

    @RBEntry("工作负责人状况")
    @RBComment("Assignee Health Status Label")
    public static final String ASSIGNEE_HEALTH_STATUS_LABEL = "ASSIGNEE_HEALTH_STATUS_LABEL";

    @RBEntry("状况说明")
    @RBComment("Health Status Description Label")
    public static final String HEALTH_STATUS_DESCRIPTION_LABEL = "HEALTH_STATUS_DESCRIPTION_LABEL";

    @RBEntry("状况说明 (活动)")
    @RBComment("Label for Status Description (Activity) Column")
    public static final String HEALTH_STATUS_DESCRIPTION_ACTIVITY_LABEL = "HEALTH_STATUS_DESCRIPTION_ACTIVITY_LABEL";

    @RBEntry("基线状态说明")
    @RBComment("Baseline Health Status Description Label")
    public static final String BASELINE_HEALTH_STATUS_DESCRIPTION_LABEL = "BASELINE_HEALTH_STATUS_DESCRIPTION_LABEL";

    @RBEntry("风险")
    @RBComment("Risk Label")
    public static final String RISK_TYPE = "RISK_TYPE";

    @RBEntry("风险类型")
    @RBComment("Risk Type Label")
    public static final String RISK_TYPE_LABEL = "RISK_TYPE_LABEL";

    @RBEntry("基线风险")
    @RBComment("Baseline Risk Label")
    public static final String BASELINE_RISK_TYPE = "BASELINE_RISK_TYPE";

    @RBEntry("风险说明")
    @RBComment("Risk Description Label")
    public static final String RISK_DESCRIPTION = "RISK_DESCRIPTION";

    @RBEntry("基线风险说明")
    @RBComment("Baseline Risk Description Label")
    public static final String BASELINE_RISK_DESCRIPTION = "BASELINE_RISK_DESCRIPTION";

    @RBEntry("关键状态")
    @RBComment("Critical Status Label")
    public static final String CRITICAL_STATUS = "CRITICAL_STATUS";

    @RBEntry("关键")
    @RBComment("Critical Label")
    public static final String CRITICAL = "CRITICAL";

    @RBEntry("基线关键")
    @RBComment("Baseline Critical Label")
    public static final String BASELINE_CRITICAL = "BASELINE_CRITICAL";

    @RBEntry("项目计划")
    @RBComment("Project Planning Preference Label")
    public static final String PROJECT_PLANNING = "PROJECT_PLANNING";

    @RBEntry("日期显示格式")
    @RBComment("Date Display Format Preference Label")
    public static final String DATE_DISPLAY_FORMAT = "DATE_DISPLAY_FORMAT";

    @RBEntry("指定在项目计划中显示日期的格式。")
    @RBComment("Date Display Format Description")
    public static final String DATE_DISPLAY_FORMAT_DESC = "DATE_DISPLAY_FORMAT_DESC";

    @RBEntry("指定在项目计划中显示日期的格式。")
    @RBComment("Date Display Format Long Description")
    public static final String DATE_DISPLAY_FORMAT_LONG_DESC = "DATE_DISPLAY_FORMAT_LONG_DESC";

    @RBEntry("工作分配")
    @RBComment("RESOURCE ASSIGNMENT")
    public static final String ASSIGNMENT = "ASSIGNMENT";

    @RBEntry("打开“跟踪工时”窗口")
    @RBComment(" Tooltip shown on on Plan table for Track Work Wizard")
    public static final String ASSIGNMENT_TOOLTIP = "ASSIGNMENT_TOOLTIP";

    @RBEntry("编辑时间表")
    @RBComment("Title for Edit Timeline Wizard")
    public static final String EDIT_TIMELINE_WIZARD_TITLE = "EDIT_TIMELINE_WIZARD_TITLE";

    @RBEntry("时间表")
    @RBComment("Title for Timeline")
    public static final String TIMELINE_TITLE = "TIMELINE_TITLE";

    @RBEntry("查找活动")
    @RBComment("Label to dispay in activity pickers")
    public static final String ACTIVITY_PICKER_LABEL = "ACTIVITY_PICKER_LABEL";

    @RBEntry("编辑选定活动")
    @RBComment("Edit Selected Objects")
    public static final String EDIT_MULTI_ACTIVITY_WIZ_TITLE = "EDIT_MULTI_ACTIVITY_WIZ_TITLE";

    @RBEntry("创建多个活动")
    @RBComment(" Create Multiple Activity Wizard")
    public static final String CREATE_MULTIPLE_ACTIVITY_TITLE = "CREATE_MULTIPLE_ACTIVITY_TITLE";

    @RBEntry("名称")
    @RBComment(" Label for Activity Name in create multiple activities screen")
    public static final String MULTIPLE_ACTIVITIES_COLUMN_NAME = "MULTIPLE_ACTIVITIES_COLUMN_NAME";

    @RBEntry("已完成")
    @RBComment("label/tool-tip for the activity which is completed 100%")
    public static final String COMPLETED = "COMPLETED";

    @RBEntry("查找所有者")
    @RBComment("Title for Owner picker")
    public static final String OWNER_PICKER_TITLE = "OWNER_PICKER_TITLE";

    @RBEntry("查找用户")
    @RBComment("Title for User picker")
    public static final String USER_PICKER_TITLE = "USER_PICKER_TITLE";

    @RBEntry("查找组")
    @RBComment("Title for Group picker")
    public static final String GROUP_PICKER_TITLE = "GROUP_PICKER_TITLE";

    @RBEntry("查找团队角色")
    @RBComment("Title for Role picker")
    public static final String ROLE_PICKER_TITLE = "ROLE_PICKER_TITLE";

    @RBEntry("您没有访问该对象的权限，或者对象不存在。")
    public static final String OBJECT_GONE = "OBJECT_GONE";

    @RBEntry("清除")
    @RBComment("This is the label for the picker Clear button")
    public static final String PICKER_CLEAR_BUTTON_LABLE = "PICKER_CLEAR_BUTTON_LABLE";

    @RBEntry("固定成本应为数值。")
    @RBComment("Fixed Cost should be numeric")
    public static final String FIXED_COST_ERROR = "FIXED_COST_ERROR";
    
    @RBEntry("固定成本不能为空白。")
    @RBComment("Fixed Cost should not be blank")
    public static final String FIXED_COST_BLANK_ERROR = "FIXED_COST_BLANK_ERROR";
    
    @RBEntry("工期")
    @RBComment(" Label for Duration column displayed for multiple activity create")
    public static final String MULTIPLE_ESTIMATE_DURATION = "MULTIPLE_ESTIMATE_DURATION";

    @RBEntry("<p>确定")
    @RBComment("For MSP EPP Plug In")
    public static final String IMPORT_SUCCESS = "IMPORT_SUCCESS";

    @RBEntry("已上载文件缺失。")
    @RBComment("For MSP EPP Plug In")
    public static final String IMPORT_FILE_NOT_FOUND = "IMPORT_FILE_NOT_FOUND";

    @RBEntry("无请求。")
    @RBComment("For MSP EPP Plug In")
    public static final String IMPORT_NO_REQUEST = "IMPORT_NO_REQUEST";

    @RBEntry("无导入模式可用。")
    @RBComment("For MSP EPP Plug In")
    public static final String IMPORT_NO_IMPORTMODE = "IMPORT_NO_IMPORTMODE";

    @RBEntry("无效的提前期。输入的提前期将导致项目开始日期提前。")
    @RBComment("Error when we specify the lead time causing the project Start date to go before the original Project start date")
    public static final String INVALID_LEAD_ERROR = "INVALID_LEAD_ERROR";

    @RBEntry("{0} 的活动 {1} 已开始。")
    @RBComment("Notification to show that the activity(activity name) for project / product (project / product name) has been started.")
    public static final String ACTIVITY_NOTIFICATION_STATE_STARTED = "ACTIVITY_NOTIFICATION_STATE_STARTED";

    @RBEntry("{0} 的活动 {1} 已暂停。")
    @RBComment("Notification to show that the activity(activity name) for project / product (project / product name) has been suspended.")
    public static final String ACTIVITY_NOTIFICATION_STATE_SUSPENDED = "ACTIVITY_NOTIFICATION_STATE_SUSPENDED";

    @RBEntry("项目名称")
    @RBComment(" Label for Project Name")
    public static final String PROJECT_NAME = "PROJECT_NAME";

    @RBEntry("跟踪工时")
    @RBComment(" Label for Track Work")
    public static final String TRACK_WORK = "TRACK_WORK";

    @RBEntry("完成")
    @RBComment("Label to denote link for Complete Activity / Assignment")
    public static final String COMPLETE = "COMPLETE";

    @RBEntry("编辑")
    @RBComment("Label to denote link Edit Activity / Assignment")
    public static final String EDIT = "EDIT";

    @RBEntry("接受")
    @RBComment(" Label for Accept")
    public static final String ACCEPT = "ACCEPT";

    @RBEntry("状态")
    @RBComment(" Label for State Column")
    public static final String PLANNABLE_STATE = "PLANNABLE_STATE";

    @RBEntry("状态 (活动)")
    @RBComment(" Label for State (Activity) Column")
    public static final String PLANNABLE_STATE_ACTIVITY = "PLANNABLE_STATE_ACTIVITY";

    @RBEntry("基线状态")
    @RBComment(" Label for Baseline State Column")
    public static final String BASELINE_PLANNABLE_STATE = "BASELINE_PLANNABLE_STATE";

    @RBEntry("说明")
    @RBComment("Label Description for the Plannable object")
    public static final String PLANNABLE_DESCRIPTION = "PLANNABLE_DESCRIPTION";

    @RBEntry("基线说明")
    @RBComment("Label Baseline Description for the Plannable object")
    public static final String BASELINE_PLANNABLE_DESCRIPTION = "BASELINE_PLANNABLE_DESCRIPTION";

    @RBEntry("已取消")
    @RBComment("Value of Cancelled PlannableState")
    public static final String CANCELLED = "CANCELLED";

    @RBEntry("无效的完成百分比值。请输入一个介于 0 和 100 之间的数字。")
    @RBComment("The Percentage complete value for deliverable")
    public static final String DEL_PERCOMPLETE_VALIDATION_ERROR = "DEL_PERCOMPLETE_VALIDATION_ERROR";

    @RBEntry("活动通知")
    @RBComment(" Label for Activity Notification")
    public static final String ACTIVITY_NOTIFICATION = "ACTIVITY_NOTIFICATION";

    @RBEntry("查找可交付结果")
    @RBComment("Label to dispay in Deliverable pickers")
    public static final String DELIVERABLE_PICKER_LABEL = "DELIVERABLE_PICKER_LABEL";

    @RBEntry("由于启用了“将可交付结果与项目活动链接”，因此里程碑 \"{0}\" 不能为“汇总活动”。")
    @RBComment("In \"Link deliverables with project activities,\" Milestone cannot be a Summary Activity")
    public static final String MILESTONE_TO_SUMMARY_ACTIVITY_NOT_ALLOWED = "MILESTONE_TO_SUMMARY_ACTIVITY_NOT_ALLOWED";

    @RBEntry("可交付结果")
    @RBComment("Label for Deliverable search table")
    public static final String DELIVERABLE_TABLE_LABEL = "DELIVERABLE_TABLE_LABEL";

    @RBEntry("默认可交付结果视图")
    @RBComment("Label for Deliverable search table view name")
    public static final String DELIVERABLE_TABLE_VIEW_NAME = "DELIVERABLE_TABLE_VIEW_NAME";

    @RBEntry("默认可交付结果搜索表格视图")
    @RBComment("Description for Deliverable search table view")
    public static final String DELIVERABLE_TABLE_VIEW_DESC = "DELIVERABLE_TABLE_VIEW_DESC";

    @RBEntry("项目计划")
    @RBComment("Label for Project Plan search table")
    public static final String PROJECT_PLAN_TABLE_LABEL = "PROJECT_PLAN_TABLE_LABEL";

    @RBEntry("默认项目计划视图")
    @RBComment("Label for Project Plan search table view name")
    public static final String PROJECT_PLAN_TABLE_VIEW_NAME = "PROJECT_PLAN_TABLE_VIEW_NAME";

    @RBEntry("默认项目计划搜索表格视图")
    @RBComment("Description for Project Plan search table view")
    public static final String PROJECT_PLAN_TABLE_VIEW_DESC = "PROJECT_PLAN_TABLE_VIEW_DESC";

    @RBEntry("详细信息")
    @RBComment("Details Tab for the Plan info page")
    public static final String PLANINFODETAILSTAB = "object.planInfo_detailstab.description";

    @RBEntry("计划活动")
    @RBComment("Label for Plan Activity search table")
    public static final String PLAN_ACTIVITY_TABLE_LABEL = "PLAN_ACTIVITY_TABLE_LABEL";

    @RBEntry("默认计划活动视图")
    @RBComment("Label for Plan Activity search table view name")
    public static final String PLAN_ACTIVITY_TABLE_VIEW_NAME = "PLAN_ACTIVITY_TABLE_VIEW_NAME";

    @RBEntry("默认计划活动搜索表格视图")
    @RBComment("Description for Plan Activity search table view")
    public static final String PLAN_ACTIVITY_TABLE_VIEW_DESC = "PLAN_ACTIVITY_TABLE_VIEW_DESC";

    @RBEntry("计划资源")
    @RBComment("Label for Plan Resource search table")
    public static final String PLAN_RESOURCE_TABLE_LABEL = "PLAN_RESOURCE_TABLE_LABEL";

    @RBEntry("默认计划资源视图")
    @RBComment("Label for Plan Resource search table view name")
    public static final String PLAN_RESOURCE_TABLE_VIEW_NAME = "PLAN_RESOURCE_TABLE_VIEW_NAME";

    @RBEntry("默认计划资源搜索表格视图")
    @RBComment("Description for Plan Resource search table view")
    public static final String PLAN_RESOURCE_TABLE_VIEW_DESC = "PLAN_RESOURCE_TABLE_VIEW_DESC";

    @RBEntry("资源分配")
    @RBComment("Label for Resource Assignment search table")
    public static final String RESOURCE_ASSIGNMENT_TABLE_LABEL = "RESOURCE_ASSIGNMENT_TABLE_LABEL";

    @RBEntry("默认资源分配视图")
    @RBComment("Label for Resource Assignment search table view name")
    public static final String RESOURCE_ASSIGNMENT_TABLE_VIEW_NAME = "RESOURCE_ASSIGNMENT_TABLE_VIEW_NAME";

    @RBEntry("默认资源分配搜索表格视图")
    @RBComment("Description for Resource Assignment search table view")
    public static final String RESOURCE_ASSIGNMENT_TABLE_VIEW_DESC = "RESOURCE_ASSIGNMENT_TABLE_VIEW_DESC";

    @RBEntry("隐藏项目群")
    @RBComment("Display Name for Hide Program Preference")
    public static final String HIDE_PROGRAM_TAB = "HIDE_PROGRAM_TAB";

    @RBEntry("确定在导航器中是隐藏还是显示项目群。")
    @RBComment("Description for Hide Program Preference")
    public static final String HIDE_PROGRAM_TAB_DESC = "HIDE_PROGRAM_TAB_DESC";

    @RBEntry("该首选项用来确定在导航器中是隐藏还是显示项目群。此首选项的默认值为“是”，即在导航器中隐藏项目群。要在导航器中显示项目群，需将该首选项的值更改为“否”。")
    @RBComment("Long Description for Hide Program Preference")
    public static final String HIDE_PROGRAM_TAB_LONG_DESC = "HIDE_PROGRAM_TAB_LONG_DESC";

    @RBEntry(" ")
    @RBComment("A localized 'Space', to separate two different words.")
    public static final String SPACE = "SPACE";

    @RBEntry("详细信息")
    @RBComment("Details Tab for the PlanActivity info page")
    public static final String ACTIVITYINFODETAILSTAB = "object.activityInfo_detailstab.description";

    @RBEntry("相关对象")
    @RBComment("Related Objects Tab for the PlanActivity info page")
    public static final String ACTIVITYINFORELATEDOBJECTS="object.activityInfo_relatedObjectsTab.description";

    @RBEntry("计划活动属性布局")
    @RBComment("Plan Activity Attribute Layouts")
    public static final String PLANACTIVITY_ATTRIBUTE_LAYOUT = "PLANACTIVITY_ATTRIBUTE_LAYOUT";

    @RBEntry("基线化计划属性布局")
    @RBComment("Baselined Plan Attribute Layouts")
    public static final String BASELINED_PLAN_ATTRIBUTE_LAYOUT = "BASELINED_PLAN_ATTRIBUTE_LAYOUT";

    @RBEntry("基线化计划活动属性布局")
    @RBComment("Baselined Plan Activity Attribute Layouts")
    public static final String BASELINED_PLANACTIVITY_ATTRIBUTE_LAYOUT = "BASELINED_PLANACTIVITY_ATTRIBUTE_LAYOUT";

    @RBEntry("自动")
    @RBComment("The Execution control of plan associated to this activity")
    public static final String EXECCONTROLPLAN_AUTOMATIC="EXECCONTROLPLAN_AUTOMATIC";

    @RBEntry("手动")
    @RBComment("The Execution control of plan associated to this activity")
    public static final String EXECCONTROLPLAN_MANUAL="EXECCONTROLPLAN_MANUAL";

    @RBEntry("计划可交付结果属性布局")
    @RBComment("Plan Deliverable Attribute Layouts")
    public static final String PLANDELIVERABLE_ATTRIBUTE_LAYOUT = "PLANDELIVERABLE_ATTRIBUTE_LAYOUT";

    @RBEntry("基线化计划可交付结果属性布局")
    @RBComment("Baselined Plan Deliverable Attribute Layouts")
    public static final String BASELINED_PLANDELIVERABLE_ATTRIBUTE_LAYOUT = "BASELINED_PLANDELIVERABLE_ATTRIBUTE_LAYOUT";

    @RBEntry("确定要完成 \"{0}\"?")
    @RBComment("Plan Activity Finish Confirmation Message")
    public static final String PLANACTIVITY_FINISH_CONFIRMATION = "PLANACTIVITY_FINISH_CONFIRMATION";

    @RBEntry("确定要完成 \"{0}\"?")
    @RBComment("Plan Assignment Finish Confirmation Message")
    public static final String PLANASSIGNMENT_FINISH_CONFIRMATION = "PLANASSIGNMENT_FINISH_CONFIRMATION";

    @RBEntry("'{0}' 具有影响其开始日期的前置任务关系。如果手动开始该活动，将删除前置任务关系。\n要继续，请单击“确定”。")
    @RBComment(" Activity predecessor delete confirmation.")
    public static final String ACTIVITY_START_PREDECESSOR_DELETE = "ACTIVITY_START_PREDECESSOR_DELETE";

    @RBEntry("约束日期")
    @RBComment(" Label for Constraint Date Column")
    public static final String PLANNABLE_CONSTRAINT_DATE = "PLANNABLE_CONSTRAINT_DATE";

    @RBEntry("基线约束日期")
    @RBComment(" Label for Baseline Constraint Date Column")
    public static final String BASELINE_PLANNABLE_CONSTRAINT_DATE = "BASELINE_PLANNABLE_CONSTRAINT_DATE";

    @RBEntry("约束类型")
    @RBComment(" Label for Constraint Type Column")
    public static final String PLANNABLE_CONSTRAINT_TYPE = "PLANNABLE_CONSTRAINT_TYPE";

    @RBEntry("基线约束类型")
    @RBComment(" Label for Baseline Constraint Type Column")
    public static final String BASELINE_PLANNABLE_CONSTRAINT_TYPE = "BASELINE_PLANNABLE_CONSTRAINT_TYPE";

    @RBEntry("超过最后期限通知 - {0} : {1}。")
    @RBComment(" Label for Deadline Notification")
    public static final String DEADLINE_PASSED = "DEADLINE_PASSED";

    @RBEntry("最后期限通知")
    @RBComment(" Label for Deadline Notification subject")
    public static final String DEADLINE_NOTIFICATION = "DEADLINE_NOTIFICATION";

    @RBEntry("每次使用成本")
    @RBComment("Label for Cost per Use")
    public static final String COST_PER_USE = "COST_PER_USE";

    @RBEntry("资源")
    @RBComment("Label for Resource")
    public static final String RESOURCE = "RESOURCE";

    @RBEntry("活动的最后期限不能早于开始日期。")
    @RBComment(" Label for Deadline before start date")
    public static final String DEADLINE_BEFORE_START ="DEADLINE_BEFORE_START";

    @RBEntry("行 {0} 的活动的最后期限不能早于开始日期。")
    @RBComment(" Label for Deadline before start date")
    public static final String MULTIDEADLINE_BEFORE_START ="MULTIDEADLINE_BEFORE_START";

    @RBEntry("最后期限通告之后")
    @RBComment(" Label for After Deadline Notification subject")
    public static final String DEADLINE_AFTER_NOTIFICATION = "DEADLINE_AFTER_NOTIFICATION";

    @RBEntry("最后期限通告之前")
    @RBComment(" Label for Before Deadline Notification subject")
    public static final String DEADLINE_BEFORE_NOTIFICATION = "DEADLINE_BEFORE_NOTIFICATION";

    @RBEntry("接近最后期限通知 - {0} : {1}。")
    @RBComment(" Label for Before Deadline Notification")
    public static final String DEADLINE_APPROACHING = "DEADLINE_APPROACHING";

    @RBEntry("{0} - {1} 已超过最后期限。")
    @RBComment(" Label for After Deadline Notification")
    public static final String DEADLINE_AFTER = "DEADLINE_AFTER";

    @RBEntry("识别事件")
    @RBComment("Label for Identify Events Step")
    public static final String IDENTIFY_EVENTS = "IDENTIFY_EVENTS";

    @RBEntry("项目说明")
    @RBComment(" Label for Project Description")
    public static final String PROJECT_DESCRIPTION = "PROJECT_DESCRIPTION";

    @RBEntry("项目所有者")
    @RBComment(" Label for Project Owner")
    public static final String PROJECT_OWNER = "PROJECT_OWNER";

    @RBEntry("组织")
    @RBComment(" Label for Organization")
    public static final String PROJECT_ORGANIZATION = "PROJECT_ORGANIZATION";

    @RBEntry("天 (最后期限之后)。")
    @RBComment("Label for Deadline After")
    public static final String DEADLINE_AFTER_LABEL= "DEADLINE_AFTER_LABEL";

    @RBEntry("天 (最后期限之前)。")
    @RBComment("Label for Deadline Before")
    public static final String DEADLINE_BEFORE_LABEL= "DEADLINE_BEFORE_LABEL";

    @RBEntry("通知最后期限")
    @RBComment("Label for Deadline Notification")
    public static final String CREATE_DEADLINE_NOTIFICATION_WIZARD_TITLE= "CREATE_DEADLINE_NOTIFICATION_WIZARD_TITLE";

    @RBEntry("无效的天数。\n请输入一个介于 0 和 100 之间的值。")
    @RBComment("This is the error message for invalid deadline no: of days")
    public static final String INVALID_DEADLINE_DAYS = "INVALID_DEADLINE_DAYS";

    @RBEntry("我的任务")
    @RBComment("Display name of the home assignments table")
    public static final String HOME_ASSIGNMENT_TABLE_TITLE = "HOME_ASSIGNMENT_TABLE_TITLE";

    @RBEntry("上次操作")
    @RBComment("Last action Column name")
    public static final String LASTACTION_TITLE = "LASTACTION_TITLE";

    @RBEntry("在 Microsoft Project 中，估计开始/完成日期将随实际开始/完成日期更新")
    @RBComment("Warning message while exporting the plan to Microsoft Project")
    public static final String WARNING_EXPORT_ESTDATESCHANGETOACTUALDATES="WARNING_EXPORT_ESTDATESCHANGETOACTUALDATES";

    @RBEntry("项目群完成及健康状况")
    @RBComment("The Preference whether to calculate the Program's Completion Status & Health Status either from its Plan or from the Projects in Network.")
    public static final String ROLLUPBYPROJECTS = "ROLLUPBYPROJECT";

    @RBEntry("确定如何度量项目群状况。")
    @RBComment("Description for the Rollup By Projects Preference")
    public static final String ROLLUPBYPROJECTS_DESC = "ROLLUPBYPROJECTS_DESC";

    @RBEntry("此首选项确定如何计算项目群状况。如果设置为“是”，则项目群完成及健康状况从该项目群的计划计算得出。如果设置为“否”，则将从项目群网络中各个项目的状况累计得出。<br> 默认值为“是”。")
    @RBComment("Description for the Rollup By Projects Preference")
    public static final String ROLLUPBYPROJECTS_LONG_DESC = "ROLLUPBYPROJECTS_LONG_DESC";

    @RBEntry("项目")
    @RBComment(" Label for related project column")
    public static final String RELATED_PROJECT = "RELATED_PROJECT";

    @RBEntry("资源单位")
    @RBComment("The Resource allocation percentage of the activity resources")
    public static final String PLANRESOURCEALLOCATION = "PLANRESOURCEALLOCATION";

    @RBEntry("活动 '{0}' 有相关的需求，不能升级。")
    @RBComment(" Error message to be displayed when user tries to outdent an activity which is related to a Requirement")
    public static final String REQUIREMENT_RELATED_ACTIVITY_OUTDENT_ERROR = "REQUIREMENT_RELATED_ACTIVITY_OUTDENT_ERROR";

    @RBEntry("活动 '{0}' 有相关的需求，不能降级。")
    @RBComment(" Error message to be displayed when user tries to outdent an activity which is related to a Requirement")
    public static final String REQUIREMENT_RELATED_ACTIVITY_INDENT_ERROR = "REQUIREMENT_RELATED_ACTIVITY_INDENT_ERROR";

    @RBEntry("编辑计划对象")
    @RBComment("Edit plan objects wizard header label")
    public static final String EDIT_PLAN_OBJECTS = "EDIT_PLAN_OBJECTS";

    @RBEntry("讨论")
    @RBComment("Disscussion column in plan table")
    public static final String PLANNABLE_DISCUSSED = "PLANNABLE_DISCUSSED";

    @RBEntry("需求")
    @RBComment("Requirement option in Customize view manager")
    public static final String RELATED_REQUIREMENT = "RELATED_REQUIREMENT";

    @RBEntry("查看需求信息")
    @RBComment(" Tooltip shown on Plan table for the requirement associated with an activity")
    public static final String ACT_REQUIREMENT_TOOLTIP = "ACT_REQUIREMENT_TOOLTIP";

    @RBEntry("关联活动")
    @RBComment("Label for wizard for associating an existing activity to a Requirement")
    public static final String ASSOCIATE_ACTIVITIES = "ASSOCIATE_ACTIVITIES";

    @RBEntry("选择项目和里程碑前，无法选择活动。")
    @RBComment("Error message to be displayed if user click on activity picker before selecting project or milestone while assigning activity to a Requirement")
    public static final String ASSOCIATE_ACTIVITIES_MISSING_INPUT_ERROR = "ASSOCIATE_ACTIVITIES_MISSING_INPUT_ERROR";

    @RBEntry("不为关联选择活动时无法保存。")
    @RBComment("Error message to be displayed if user tries save operation before selecting selecting activities while assigning activity to a Requirement")
    public static final String ASSOCIATE_ACTIVITIES_MISSING_ACTIVITIES_ERROR = "ASSOCIATE_ACTIVITIES_MISSING_ACTIVITIES_ERROR";

    @RBEntry("为产品启用“创建计划”")
    @RBComment("Display Name for Show Create Plan action for Product")
    public static final String SHOW_CREATE_PRODUCT_PLAN_ACTION = "SHOW_CREATE_PRODUCT_PLAN_ACTION";

    @RBEntry("确定是否为产品启用“创建计划”操作。")
    @RBComment("Description for Show Create Plan action for Product")
    public static final String SHOW_CREATE_PRODUCT_PLAN_ACTION_DESC = "SHOW_CREATE_PRODUCT_PLAN_ACTION_DESC";

    @RBEntry("此首选项确定产品<b>详细信息</b>页面上的<b>操作</b>菜单中是否显示<b>创建计划</b>操作。选择“是”显示，选择“否”隐藏。<br>默认值为“是”。")
    @RBComment("Long Description for Show Create Plan action for Product")
    public static final String SHOW_CREATE_PRODUCT_PLAN_ACTION_LONG_DESC = "SHOW_CREATE_PRODUCT_PLAN_ACTION_LONG_DESC";

    @RBEntry("计划属性布局")
    @RBComment("Plan Attribute Layouts")
    public static final String PLAN_ATTRIBUTE_LAYOUT = "PLAN_ATTRIBUTE_LAYOUT";

    @RBEntry("您是 {0} 组的成员。通过共享分配，该组已被分配到以下活动: {1}。")
    @RBComment("Message on notification for shared assignment with a group - part 1")
    public static final String ACTIVITY_NOTIFICATION_HEADER_SHARED_ASSIGNMENT_WITH_GROUP = "ACTIVITY_NOTIFICATION_HEADER_SHARED_ASSIGNMENT_WITH_GROUP";

    @RBEntry("您是 {0} 角色的成员。通过共享分配，该角色已被分配到以下活动: {1}。")
    @RBComment("Message on notification for shared assignment with a role - part 1")
    public static final String ACTIVITY_NOTIFICATION_HEADER_SHARED_ASSIGNMENT_WITH_ROLE = "ACTIVITY_NOTIFICATION_HEADER_SHARED_ASSIGNMENT_WITH_ROLE";

    @RBEntry("您是 {0} 组的成员。通过成批分配，该组已被分配到以下活动: {1}。")
    @RBComment("Message on notification for bulk assignment with a group - part 1")
    public static final String ACTIVITY_NOTIFICATION_HEADER_BULK_ASSIGNMENT_WITH_GROUP = "ACTIVITY_NOTIFICATION_HEADER_BULK_ASSIGNMENT_WITH_GROUP";

    @RBEntry("您是 {0} 角色的成员。通过成批分配，该角色已被分配到以下活动: {1}。")
    @RBComment("Message on notification for bulk assignment with a role - part 1")
    public static final String ACTIVITY_NOTIFICATION_HEADER_BULK_ASSIGNMENT_WITH_ROLE = "ACTIVITY_NOTIFICATION_HEADER_BULK_ASSIGNMENT_WITH_ROLE";

    @RBEntry("您是 {0} 组的成员。通过合用分配，该组已被分配到以下活动: {1}。")
    @RBComment("Message on notification for pool assignment with a group - part 1")
    public static final String ACTIVITY_NOTIFICATION_HEADER_POOL_ASSIGNMENT_WITH_GROUP = "ACTIVITY_NOTIFICATION_HEADER_POOL_ASSIGNMENT_WITH_GROUP";

    @RBEntry("您是 {0} 角色的成员。通过合用分配，该角色已被分配到以下活动: {1}。")
    @RBComment("Message on notification for pool assignment with a role - part 1")
    public static final String ACTIVITY_NOTIFICATION_HEADER_POOL_ASSIGNMENT_WITH_ROLE = "ACTIVITY_NOTIFICATION_HEADER_POOL_ASSIGNMENT_WITH_ROLE";

    @RBEntry("使用 {0} 操作来接受此工作分配。")
    @RBComment("Notification option for accept action")
    public static final String ACTIVITY_NOTIFICATION_OPTION_ACCEPT = "ACTIVITY_NOTIFICATION_OPTION_ACCEPT";

    @RBEntry("新建计划基线")
    @RBComment("Title for Create Baseline Wizard")
    public static final String CREATE_BASELINE_WIZARD_TITLE = "CREATE_BASELINE_WIZARD_TITLE";

    @RBEntry("基线名称")
    @RBComment("Label for Plan Baseline Name")
    public static final String PLAN_BASELINE_NAME = "PLAN_BASELINE_NAME";

    @RBEntry("基线说明")
    @RBComment("Label for Plan Baseline Description")
    public static final String PLAN_BASELINE_DESCRIPTION = "PLAN_BASELINE_DESCRIPTION";

    @RBEntry("计划基线")
    @RBComment("Plan Baselines Table Title")
    public static final String PLAN_BASELINES_TITLE = "PLAN_BASELINES_TITLE";

    @RBEntry("活动基线")
    @RBComment("Activity Baselines table title")
    public static final String ACTIVITY_BASELINES_TITLE = "ACTIVITY_BASELINES_TITLE";

    @RBEntry("资源基线")
    @RBComment("Resource Baselines table title")
    public static final String RESOURCE_BASELINES_TITLE = "RESOURCE_BASELINES_TITLE";

    @RBEntry("工作分配基线")
    @RBComment("Assignment Baselines table title")
    public static final String ASSIGNMENT_BASELINES_TITLE = "ASSIGNMENT_BASELINES_TITLE";

    @RBEntry("可交付结果基线")
    @RBComment("Deliverable Baselines table title")
    public static final String DELIVERABLE_BASELINES_TITLE = "DELIVERABLE_BASELINES_TITLE";

    @RBEntry("活动")
    @RBComment("Label for Plan Baseline 'Active' attribute")
    public static final String PLAN_BASELINE_ACTIVE = "PLAN_BASELINE_ACTIVE";

    @RBEntry("基线创建时间")
    @RBComment("Label for Plan Baseline 'Create Timestamp' attribute")
    public static final String PLAN_BASELINE_CREATED_ON = "PLAN_BASELINE_CREATED_ON";

    @RBEntry("基线创建者")
    @RBComment("Label for Plan Baseline 'Created By' attribute")
    public static final String PLAN_BASELINE_CREATED_BY = "PLAN_BASELINE_CREATED_BY";

    @RBEntry("开始日期")
    @RBComment("Label for Plan Baseline 'Start Date' attribute")
    public static final String PLAN_BASELINE_START_DATE = "PLAN_BASELINE_START_DATE";

    @RBEntry("完成日期")
    @RBComment("Label for Plan Baseline 'Finish Date' attribute")
    public static final String PLAN_BASELINE_FINISH_DATE = "PLAN_BASELINE_FINISH_DATE";

    @RBEntry("工时")
    @RBComment("Label for Plan Baseline 'Effort' attribute")
    public static final String PLAN_BASELINE_EFFORT = "PLAN_BASELINE_EFFORT";

    @RBEntry("工期")
    @RBComment("Label for Plan Baseline 'Duration' attribute")
    public static final String PLAN_BASELINE_DURATION = "PLAN_BASELINE_DURATION";

    @RBEntry("比较")
    @RBComment("Label for Compare action")
    public static final String EPP_COMPARE_DESCRIPTION = "object.plan_menubar_actions_compare.description";

    @RBEntry("比较")
    @RBComment("Tooltip for Compare action")
    public static final String EPP_COMPARE_TOOLTIP = "object.plan_menubar_actions_compare.tooltip";

    @RBEntry("活动基线")
    @RBComment("Tooltip for Active Baseline")
    public static final String ACTIVE_BASELINE_TOOLTIP = "ACTIVE_BASELINE_TOOLTIP";

    @RBEntry("比较")
    @RBComment(" Value for Compare View")
    public static final String VIEW_COMPARE = "VIEW_COMPARE";

    @RBEntry("比较视图")
    @RBComment(" Description for Compare View")
    public static final String VIEW_COMPARE_DESC = "VIEW_COMPARE_DESC";

    @RBEntry("计划基线")
    public static final String PLAN_BASELINES = "PLAN_BASELINES";

    @RBEntry("活动基线")
    public static final String ACTIVITY_BASELINES = "ACTIVITY_BASELINES";

    @RBEntry("可交付结果基线")
    public static final String DELIVERABLE_BASELINES = "DELIVERABLE_BASELINES";

    @RBEntry("工作分配基线")
    public static final String ASSIGNMENT_BASELINES = "ASSIGNMENT_BASELINES";

    @RBEntry("资源基线")
    public static final String RESOURCE_BASELINES = "RESOURCE_BASELINES";

    @RBEntry("实际工时差异")
    @RBComment("Label for Work Variance")
    public static final String ACTUALWORK_VARIANCE = "ACTUALWORK_VARIANCE";

    @RBEntry("差异报告")
    @RBComment("Value for Variance Report View")
    public static final String VIEW_VARIANCE_REPORT = "VIEW_VARIANCE_REPORT";

    @RBEntry("差异报告视图")
    @RBComment("Description for Variance Report View")
    public static final String VIEW_VARIANCE_REPORT_DESC = "VIEW_VARIANCE_REPORT_DESC";

    @RBEntry("您为此操作选择了多个基线计划，只能选择一个基线计划。")
    @RBComment("The exception is thrown when more than one baseline plans are selected")
    public static final String MULTIPLE_BASELINE_PLAN_SELECTED_ERROR = "MULTIPLE_BASELINE_PLAN_SELECTED_ERROR";

    @RBEntry("完成百分比")
    @RBComment("The percentage of the task which is complete")
    public static final String PERCENT_COMPLETE_TITLE = "PERCENT_COMPLETE_TITLE";

    @RBEntry("基线完成百分比")
    @RBComment("The percentage of the task which is complete in Baseline")
    public static final String BASELINE_PERCENT_COMPLETE_TITLE = "BASELINE_PERCENT_COMPLETE_TITLE";

    @RBEntry("无效操作。不能删除选定计划对象。")
    @RBComment("Current Plan Object Can Not Be Deleted. \nPlease Deselect The Current Plan Object And Try Again")
    public static final String CURRENT_PLAN_SELECTED_ERROR = "CURRENT_PLAN_SELECTED_ERROR";

    @RBEntry("接受的资源分配")
    @RBComment("Tooltip for Accepted Resource Assignment")
    public static final String ACCEPTED_ASSIGNMENT_TOOLTIP = "ACCEPTED_ASSIGNMENT_TOOLTIP";

    @RBEntry("资源")
    @RBComment("Shared Assignment Resources table title")
    public static final String SHARED_ASSIGNMENT_RESOURCES_TITLE = "SHARED_ASSIGNMENT_RESOURCES_TITLE";

    @RBEntry("无法修改此活动的实际工时，因为未接受合用分配。")
    @RBComment("The actual work for this activity cannot be modified because it has only unaccepted pool assignments label")
    public static final String ACTIVITY_TRACK_WORK_ERROR_MESSAGE = "ACTIVITY_TRACK_WORK_ERROR_MESSAGE";

    @RBEntry("组")
    @RBComment("The assignment group")
    public static final String ASSIGNMENT_GROUP = "ASSIGNMENT_GROUP";

    @RBEntry("工作分配类型")
    @RBComment("The assignment type")
    public static final String ASSIGNMENT_TYPE = "ASSIGNMENT_TYPE";

    @RBEntry("无法完成 '{0}'，因为它有至少一个未接受的合用分配。")
    @RBComment("The activity cannot be completed because it has atleast one unaccepted pool assignments label")
    public static final String ACTIVITY_COMPLETE_ERROR_MESSAGE = "ACTIVITY_COMPLETE_ERROR_MESSAGE";

    @RBEntry("无法完成活动“{0}”，因为该活动具有“最新修订版本”跟踪策略，并且与已 PDM 检出的可交付结果的主题相关联。请 PDM 检入此主题，然后尝试完成该活动。")
    @RBComment("The activity cannot be completed because it is an activity with tracking policy as 'Latest Revision' and is associated with a subject of deliverable which is PDM Checked out. Please PDM check in the subject and try to complete the activity.")
    public static final String ACTIVITY_COMPLETE_ERROR_MESSAGE_WHEN_SUBJECT_ISPDMCHECKEDOUT = "ACTIVITY_COMPLETE_ERROR_MESSAGE_WHEN_SUBJECT_ISPDMCHECKEDOUT";
    
    @RBEntry("当前计划")
    @RBComment("Baseline name for current plan object")
    public static final String BASELINE_NAME_OF_CURRENT_PLAN = "BASELINE_NAME_OF_CURRENT_PLAN";

    @RBEntry("未选择基线。请首先选择一个基线。")
    @RBComment("A baseline have to be selected.")
    public static final String SELECT_BASELINED_PLAN_ERROR = "SELECT_BASELINED_PLAN_ERROR";

    @RBEntry("选定基线已经在活动基线中。")
    @RBComment("The selected baselined is already active.")
    public static final String SET_AS_ACTIVE_BASELINE_ERROR = "SET_AS_ACTIVE_BASELINE_ERROR";

    @RBEntry("您没有必需的权限来删除部分选定对象。")
    @RBComment("Error message when user tries to delete the Resource Assignement for which he does not have access to.")
    public static final String RESOURCEASSIGNMENT_UNAUTHORIZED_ACCESS = "RESOURCEASSIGNMENT_UNAUTHORIZED_ACCESS";

    @RBEntry("'{0}' 不处于运行状态，因此无法更新。")
    @RBComment("Error message when mentioned plannable(milestone) is being updated from customized API and it is not in INPROCESS state.")
    public static final String MILESTONE_IS_NOT_RUNNING = "MILESTONE_IS_NOT_RUNNING";

    @RBEntry("常规")
    @RBComment("Title for General step of activity wizards")
    public static final String ACTIVITY_WIZARD_GENERAL = "ACTIVITY_WIZARD_GENERAL";

    @RBEntry("高级")
    @RBComment("Title for Advanced step of activity wizards")
    public static final String ACTIVITY_WIZARD_ADVANCED = "ACTIVITY_WIZARD_ADVANCED";

    @RBEntry("保留实际工时")
    @RBComment("Name of a preference definition")
    public static final String KEEP_ACTUALWORK_PREF_NAME = "KEEP_ACTUALWORK_PREF_NAME";

    @RBEntry("控制完成时是否保留实际工时。")
    @RBComment("Description for a preference, shown in description column in Preferences table")
    public static final String KEEP_ACTUALWORK_PREF_DESC = "KEEP_ACTUALWORK_PREF_DESC";

    @RBEntry("此首选项控制在用户手动完成工作分配或活动时保留<b>实际工时</b>值还是<b>估计工时</b>值。<br> 将此首选项设置为“是”将保留<b>实际工时</b>值。完工时，<b>估计工时</b>值将设置为等于实际工时。<br>将此首选项设置为“否”将保留<b>估计工时</b>值。完工时，<b>实际工时</b>值将设置为等于估计工时。<br> 默认值为“否”。")
    @RBComment("Long description for a preference, shown in Set Preference dialog")
    public static final String KEEP_ACTUALWORK_PREF_LONG_DESC = "KEEP_ACTUALWORK_PREF_LONG_DESC";

    @RBEntry("无效操作。不能从“任务”表格中删除活动、资源或资源分配。")
    @RBComment("Info Message when user selects any of these objects which should not be directly deleted from Task table.")
    public static final String PLANTASKTABLE_UNSUPPORTED_OJBECTS_DELETION_ERROR = "PLANTASKTABLE_UNSUPPORTED_OJBECTS_DELETION_ERROR";

    @RBEntry("“固定工期”任务类型的工期更改")
    @RBComment("Name of a preference definition")
    public static final String DURATION_CHANGE_FOR_FIXED_DURATION = "DURATION_CHANGE_FOR_FIXED_DURATION";

    @RBEntry("确定当修改“固定工期”活动时哪些排程变量保持不变。")
    @RBComment("Description for a preference, shown in description column in Preferences table")
    public static final String DURATION_CHANGE_FOR_FIXED_DURATION_DESC = "DURATION_CHANGE_FOR_FIXED_DURATION_DESC";

    @RBEntry("如果对“固定工期”任务类型的活动修改工期，则在重新计算排程时必须将工时和资源单位其中之一作为常量。此首选项控制哪个变量保持不变。<br>选择<b>更新单位</b>将保留工时值。选择<b>更新工时</b>将保留资源单位值。<br>默认值为“更新工时”。")
    @RBComment("Long description for a preference, shown in Set Preference dialog")
    public static final String DURATION_CHANGE_FOR_FIXED_DURATION_LONG_DESC = "DURATION_CHANGE_FOR_FIXED_DURATION_LONG_DESC";

    @RBEntry("更新工时")
    @RBComment("Choice for a preference")
    public static final String UPDATE_WORK_PREF_CHOICE = "UPDATE_WORK_PREF_CHOICE";

    @RBEntry("更新单位")
    @RBComment("Choice for a preference")
    public static final String UPDATE_UNITS_PREF_CHOICE = "UPDATE_UNITS_PREF_CHOICE";

    @RBEntry("此工作分配的实际工时为零。确定要继续?")
    @RBComment("Warning message when we try to complete the resource assignment having zero actual work.")
    public static final String WARNING_ASSIGNMENT_HAS_ZEROACTUALWORK = "WARNING_ASSIGNMENT_HAS_ZEROACTUALWORK";

    @RBEntry("默认资源分配")
    @RBComment("Name of a preference definition")
    public static final String CREATE_DEFAULT_RESOURCE_ASSIGNMENT = "CREATE_DEFAULT_RESOURCE_ASSIGNMENT";

    @RBEntry("控制是否可以在未分配资源的情况下创建活动。")
    @RBComment("Description for a preference, shown in description column in Preferences table")
    public static final String CREATE_DEFAULT_RESOURCE_ASSIGNMENT_DESC = "CREATE_DEFAULT_RESOURCE_ASSIGNMENT_DESC";

    @RBEntry("控制默认情况下新活动是否包括资源分配:<ul><li>是 – 如果没有明确地将资源分配到活动，则在默认情况下活动所有者会收到资源分配。如果没有所有者被明确地分配到活动，则自动将活动创建者添加为资源。</li><li>否 – 可以在未分配资源的情况下创建活动。</li></ul> 默认值为“否”。")
    @RBComment("Long description for a preference, shown in Set Preference dialog")
    public static final String CREATE_DEFAULT_RESOURCE_ASSIGNMENT_LONG_DESC = "CREATE_DEFAULT_RESOURCE_ASSIGNMENT_LONG_DESC";

    @RBEntry("此工作分配的实际工时为零。确定要继续?")
    @RBComment("Warning message when we try to complete the activity having zero actual work.")
    public static final String WARNING_ACTIVITY_HAS_ZEROACTUALWORK = "WARNING_ACTIVITY_HAS_ZEROACTUALWORK";

    @RBEntry("状态更改通告")
    @RBComment("Name of a preference definition")
    public static final String SEND_OWNER_STATE_CHANGE_NOTIFICATIONS = "SEND_OWNER_STATE_CHANGE_NOTIFICATIONS";

    @RBEntry("控制是否将状态更改通告发送至活动所有者。")
    @RBComment("Description for a preference, shown in description column in Preferences table")
    public static final String SEND_OWNER_STATE_CHANGE_NOTIFICATIONS_DESC = "SEND_OWNER_STATE_CHANGE_NOTIFICATIONS_DESC";

    @RBEntry("控制是否在活动执行状态变化时发送通告给活动所有者。选择“是”将发送通告。选择“否”将不发送通告。<br>默认值为“是”。")
    @RBComment("Long description for a preference, shown in Set Preference dialog")
    public static final String SEND_OWNER_STATE_CHANGE_NOTIFICATIONS_LONG_DESC = "SEND_OWNER_STATE_CHANGE_NOTIFICATIONS_LONG_DESC";

    @RBEntry("您已被指定为以下活动的资源: {0}。")
    @RBComment("Message on notification for assignment - part 1")
    public static final String ACTIVITY_NOTIFICATION_HEADER_RESOURCE = "ACTIVITY_NOTIFICATION_HEADER_RESOURCE";

    @RBEntry("您已被指定为以下活动的所有者: {0}。")
    @RBComment("Message on notification for assignment - part 1")
    public static final String ACTIVITY_NOTIFICATION_HEADER_OWNER = "ACTIVITY_NOTIFICATION_HEADER_OWNER";

    @RBEntry("此活动<b>已启动</b>")
    @RBComment("Message to show that activity has been started")
    public static final String ACTIVITY_NOTIFICATION_HEADER_STATE_STARTED = "ACTIVITY_NOTIFICATION_HEADER_STATE_STARTED";

    @RBEntry("此活动<b>已暂停</b>")
    @RBComment("Message to show that activity has been suspended")
    public static final String ACTIVITY_NOTIFICATION_HEADER_STATE_SUSPENDED = "ACTIVITY_NOTIFICATION_HEADER_STATE_SUSPENDED";

    @RBEntry("使用 {0} 来更新您的状况和进度。")
    @RBComment("Notification option for track work action")
    public static final String ACTIVITY_NOTIFICATION_OPTION_TRACK_WORK = "ACTIVITY_NOTIFICATION_OPTION_TRACK_WORK";

    @RBEntry("使用 {0} 来完成此工作分配。")
    @RBComment("Notification option for complete action")
    public static final String ACTIVITY_NOTIFICATION_OPTION_COMPLETE = "ACTIVITY_NOTIFICATION_OPTION_COMPLETE";

    @RBEntry("使用 {0} 来修改此工作分配。")
    @RBComment("Notification option for edit action")
    public static final String ACTIVITY_NOTIFICATION_OPTION_EDIT = "ACTIVITY_NOTIFICATION_OPTION_EDIT";

    @RBEntry("已开始")
    @RBComment("denotes the 'In Process' state of the Activity in the notification email")
    public static final String NOTIFICATION_ACTIVITY_STARTED = "NOTIFICATION_ACTIVITY_STARTED";

    @RBEntry("已暂停")
    @RBComment("denotes the 'Suspended' state of the Activity in the notification email")
    public static final String NOTIFICATION_ACTIVITY_SUSPENDED = "NOTIFICATION_ACTIVITY_SUSPENDED";

    @RBEntry("剩余工时")
    @RBComment("Label for remaining work on the assignment in the notification email")
    public static final String NOTIFICATION_ASSIGNMENT_REMAINING_WORK = "NOTIFICATION_ASSIGNMENT_REMAINING_WORK";

    @RBEntry("此活动存在以下资源分配:")
    @RBComment("Part of the header to indicate the assignments for the activity")
    public static final String NOTIFICATION_ACTIVITY_ASSIGNMENTS = "NOTIFICATION_ACTIVITY_ASSIGNMENTS";

    @RBEntry("相关对象可交付结果表格显示")
    @RBComment("Name of the preference to denote whether to show Classic or EPP deliverable table or both")
    public static final String SHOW_EPP_CLASSIC_DELIVERABLE_TABLE = "SHOW_EPP_CLASSIC_DELIVERABLE_TABLE";

    @RBEntry("控制可交付结果表格是否出现在“相关对象”选项卡中。")
    @RBComment("Preference short description to denote whether to show Classic or EPP deliverable tables or both")
    public static final String SHOW_EPP_CLASSIC_DELIVERABLE_TABLE_DESC = "SHOW_EPP_CLASSIC_DELIVERABLE_TABLE_DESC";

    @RBEntry("控制在信息页面中显示对象的相关可交付结果时，所显示的可交付结果表格是“典型”或“增强型项目计划”(EPP)，或是两者均显示。如果设为“仅典型”，则只显示“典型”可交付结果。如果设为“仅 EPP”，则只显示 EPP 可交付结果。如果设为“两者”，则在两个表格中分别显示“典型”和 EPP 可交付结果。")
    @RBComment("Preference long description to denote whether to show Classic or EPP deliverable tables or both")
    public static final String SHOW_EPP_CLASSIC_DELIVERABLE_TABLE_LONG_DESC = "SHOW_EPP_CLASSIC_DELIVERABLE_TABLE_LONG_DESC";

    @RBEntry("仅 EPP")
    @RBComment("Preference text to denote whether to show EPP deliverable table only")
    public static final String SHOW_EPP_DELIVERABLE_TABLE_ONLY_PREF_CHOICE = "SHOW_EPP_DELIVERABLE_TABLE_ONLY_PREF_CHOICE";

    @RBEntry("仅典型")
    @RBComment("Preference text to denote whether to show Classic deliverable table only")
    public static final String SHOW_CLASSIC_DELIVERABLE_TABLE_ONLY_PREF_CHOICE = "SHOW_CLASSIC_DELIVERABLE_TABLE_ONLY_PREF_CHOICE";

    @RBEntry("两者")
    @RBComment("Preference text to denote whether to show both Classic and EPP deliverable tables")
    public static final String SHOW_CLASSIC_AND_EPP_DELIVERABLE_TABLES_PREF_CHOICE = "SHOW_CLASSIC_AND_EPP_DELIVERABLE_TABLES_PREF_CHOICE";

    @RBEntry("此活动没有资源分配。")
    @RBComment("Message to render in notification email sent to owner when there is no resource assignments available for the activity")
    public static final String RESOURCEASSIGNMENTS_NOT_AVAILABLE = "RESOURCEASSIGNMENTS_NOT_AVAILABLE";

    @RBEntry("您是以下汇总活动的所有者: {0}。")
    @RBComment("Message to render in notification of summary activity for owner")
    public static final String SUMMARY_ACTIVITY_NOTIFICATION_HEADER_OWNER = "SUMMARY_ACTIVITY_NOTIFICATION_HEADER_OWNER";

    @RBEntry("此活动存在以下子活动:")
    @RBComment("Message to render in the notification email for owner")
    public static final String SUMMARY_ACTIVITY_CHILDREN_AVAILABLE = "SUMMARY_ACTIVITY_CHILDREN_AVAILABLE";

    @RBEntry("使用 {0} 来更新此活动。")
    @RBComment("Notification option for edit action")
    public static final String EDIT_ACTIVITY_NOTIFICATION_OPTION = "EDIT_ACTIVITY_NOTIFICATION_OPTION";

    @RBEntry("使用 {0} 来更新此活动的状况和进度。")
    @RBComment("Notification option for track work action")
    public static final String TRACK_WORK_ACTIVITY_NOTIFICATION_OPTION = "TRACK_WORK_ACTIVITY_NOTIFICATION_OPTION";

    @RBEntry("使用 {0} 来完成此活动。")
    @RBComment("Notification option for complete action")
    public static final String COMPLETE_ACTIVITY_NOTIFICATION_OPTION = "COMPLETE_ACTIVITY_NOTIFICATION_OPTION";

    @RBEntry("清除状况说明历史记录")
    @RBComment("Label for a check box which decides whether to clear status description history or not.")
    public static final String LABEL_CLEAR_HEALTH_STATUS_DESCRIPTION = "LABEL_CLEAR_HEALTH_STATUS_DESCRIPTION";

    @RBEntry("资源单位不能为空白。")
    @RBComment("Message to be shown when while creating activity the Resource Units are blank.")
    public static final String RESOURCE_UNITS_BLANK = "RESOURCE_UNITS_BLANK";

    @RBEntry("默认活动约束类型")
    @RBComment("Name of a preference definition")
    public static final String PREF_DEFAULT_CONSTRAINT_TYPE = "PREF_DEFAULT_CONSTRAINT_TYPE";

    @RBEntry("指定创建新活动时默认使用的约束类型。")
    @RBComment("Description for a preference, shown in description column in Preferences table")
    public static final String PREF_DEFAULT_CONSTRAINT_TYPE_DESC = "PREF_DEFAULT_CONSTRAINT_TYPE_DESC";

    @RBEntry("指定创建新活动时默认选定的约束类型。此首选项的初始值为“尽快”。")
    @RBComment("Long description for a preference, shown in Set Preference dialog")
    public static final String PREF_DEFAULT_CONSTRAINT_TYPE_LONG_DESC = "PREF_DEFAULT_CONSTRAINT_TYPE_LONG_DESC";

    @RBEntry("尽快")
    @RBComment("Choice for a preference")
    public static final String ASAP_PREF_CHOICE = "ASAP_PREF_CHOICE";

    @RBEntry("开始时间不早于")
    @RBComment("Choice for a preference")
    public static final String SNET_PREF_CHOICE = "SNET_PREF_CHOICE";

    @RBEntry("越晚越好")
    @RBComment("Choice for a preference")
    public static final String ALAP_PREF_CHOICE = "ALAP_PREF_CHOICE";

    @RBEntry("必须完成于")
    @RBComment("Choice for a preference")
    public static final String MFO_PREF_CHOICE = "MFO_PREF_CHOICE";

    @RBEntry("删除链接的可交付结果或活动")
    @RBComment("Name of a preference definition")
    public static final String PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY = "PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY";

    @RBEntry("指定是否在删除可交付结果的链接活动时删除该可交付结果，以及执行对应的反向操作。")
    @RBComment("Description for a preference, shown in description column in Preferences table")
    public static final String PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY_DESC = "PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY_DESC";

    @RBEntry("此首选项仅在启用<b>将可交付结果与项目活动链接</b>选项时应用。<br><ul><li>是 -- 在删除链接了可交付结果的活动时，链接的可交付结果也会被删除。同样，在删除链接了活动的可交付结果时，链接的活动也会被删除。系统会对以上情况显示警告消息。</li><li>否 -- 在删除链接了可交付结果的活动时，链接的可交付结果不受影响。在删除链接了活动的可交付结果时，链接的活动不受影响。</li></ul><br>默认值为“否”。")
    @RBComment("Long description for a preference, shown in Set Preference dialog")
    public static final String PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY_LONG_DESC = "PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY_LONG_DESC";

    @RBEntry("此活动链接到一个可交付结果。链接的可交付结果也将被删除。\n\n单击“确定”继续。")
    @RBComment("Warning message when activity which has linked deliverable is being deleted.")
    public static final String CONF_DELETE_LINKED_DELIVERABLE = "CONF_DELETE_LINKED_DELIVERABLE";

    @RBEntry("此可交付结果链接到一个活动。链接的活动也将被删除。\n\n单击“确定”继续。")
    @RBComment("Warning message when activity which has linked deliverable is being deleted.")
    public static final String CONF_DELETE_LINKED_ACTIVITY = "CONF_DELETE_LINKED_ACTIVITY";

    @RBEntry("一个或多个活动链接到可交付结果。链接的可交付结果也将被删除。\n\n单击“确定”继续。")
    @RBComment("Warning message when activity which has linked deliverable is being deleted.")
    public static final String CONF_MULTI_DELETE_LINKED_DELIVERABLE = "CONF_MULTI_DELETE_LINKED_DELIVERABLE";

    @RBEntry("一个或多个可交付结果链接到活动。链接的活动也将被删除。\n\n单击“确定”继续。")
    @RBComment("Warning message when activity which has linked deliverable is being deleted.")
    public static final String CONF_MULTI_DELETE_LINKED_ACTIVITY = "CONF_MULTI_DELETE_LINKED_ACTIVITY";

    @RBEntry("行号")
    @RBComment("Column name on Home Tasks")
    public static final String LINE_NUMBER = "LINE_NUMBER";

    @RBEntry("已重新安排活动。")
    @RBComment("Confirmation message for the user to indicate activities have been rescheduled.")
    public static final String SCHEDULE_RECALCULATED_SUCCESS = "SCHEDULE_RECALCULATED_SUCCESS";

    @RBEntry("尚未重新安排活动。")
    @RBComment("Confirmation message for the user to indicate activities have not been rescheduled.")
    public static final String SCHEDULE_RECALCULATED_FAILURE = "SCHEDULE_RECALCULATED_FAILURE";

    @RBEntry("选定活动包括一个或多个链接到可交付结果的汇总活动。\n\n删除汇总活动会删除其所有子活动。如果汇总活动链接到可交付结果，链接的可交付结果也会被删除。\n\n单击“确定”继续。")
    @RBComment("Warning message when summary activities which has linked deliverable are being deleted.")
    public static final String CONF_MULTI_SUMMARY_DELETE_LINKED_DELIVERABLE = "CONF_MULTI_SUMMARY_DELETE_LINKED_DELIVERABLE";

    @RBEntry("'{0}' 是汇总活动并且链接到一个可交付结果。删除该活动会删除其所有子活动及其链接的可交付结果。\n\n单击“确定”继续。")
    @RBComment("Warning message when summary activity which has linked deliverable is being deleted.")
    public static final String CONF_SINGLE_SUMMARY_DELETE_LINKED_DELIVERABLE = "CONF_SINGLE_SUMMARY_DELETE_LINKED_DELIVERABLE";

    @RBEntry("选定活动包括一个或多个汇总活动以及一个或多个链接到可交付结果的活动。\n\n删除汇总活动会删除其所有子活动。如果所删除的活动链接到可交付结果，链接的可交付结果也会被删除。\n\n单击“确定”继续。")
    @RBComment("Warning message when activity which has linked deliverable along with one or more summary activities is being deleted.")
    public static final String CONF_MULTI_DELETE_LINKED_DELIVERABLE_WITH_SUMMARY = "CONF_MULTI_DELETE_LINKED_DELIVERABLE_WITH_SUMMARY";

    @RBEntry("选定活动包括一个或多个链接到可交付结果的活动以及一个或多个链接到可交付结果的汇总活动。\n\n如果所删除的活动链接到可交付结果，链接的可交付结果也会被删除。\n\n删除汇总活动会删除其所有子活动。如果汇总活动链接到可交付结果，链接的可交付结果也会被删除。\n\n单击“确定”继续。")
    @RBComment("Warning message when activity which has linked deliverable along with one or more summary activities with linked deliverable are being deleted.")
    public static final String CONF_MULTI_DELETE_LINKED_DELIVERABLE_WITH_SUMMARY_LINKED_DELIVERABLE = "CONF_MULTI_DELETE_LINKED_DELIVERABLE_WITH_SUMMARY_LINKED_DELIVERABLE";

    @RBEntry("容器为空或无效。")
    @RBComment("Error message shown when system tries checking if the user is member of guest user of the given container and the container itself is null.")
    public static final String NULL_CONTAINER_ERROR_MESSAGE = "NULL_CONTAINER_ERROR_MESSAGE";

    @RBEntry("此操作还会更改活动所有者。\n 单击“确定”将继续。")
    @RBComment("In Linked deliverable project, while creating deliverable, owner change will be in sync with activity.")
    public static final String CHANGE_ACTIVITY_OWNER = "CHANGE_ACTIVITY_OWNER";

    @RBEntry("此操作将移除活动所有者。\n 单击“确定”将继续。")
    @RBComment("In Linked deliverable project, while creating deliverable, owner change will be in sync with activity.")
    public static final String REMOVE_ACTIVITY_OWNER = "REMOVE_ACTIVITY_OWNER";

    @RBEntry("不能为 '{0}' 类型的资源创建单一分配")
    @RBComment("Error message shown when user tries to create either a Single assignment with Group/Role resources.")
    public static final String CREATE_SINGLE_ASSIGNMENT_WITH_MULTI_USER_RESOURCE_ERROR = "CREATE_SINGLE_ASSIGNMENT_WITH_MULTI_USER_RESOURCE_ERROR";

    @RBEntry("不能为 '{0}' 类型的资源创建共享分配")
    @RBComment("Error message shown when user tries to create either a Shared assignment with User/Other resource.")
    public static final String CREATE_SHARED_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR = "CREATE_SHARED_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR";

    @RBEntry("不能为 '{0}' 类型的资源创建成批分配")
    @RBComment("Error message shown when user tries to create either a Bulk assignment with User/Other resource.")
    public static final String CREATE_BULK_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR = "CREATE_BULK_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR";

    @RBEntry("不能为 '{0}' 类型的资源创建合用分配")
    @RBComment("Error message shown when user tries to create either a Pool assignment with User/Other resource.")
    public static final String CREATE_POOL_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR = "CREATE_POOL_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR";

    @RBEntry("导出计划模板")
    public static final String EXPORT_PLAN_TEMPLATE_TITLE = "EXPORT_PLAN_TEMPLATE_TITLE";

    @RBEntry("从现有计划 {0} 导出计划模板")
    public static final String EXPORT_PLAN_TEMPLATE_DESCRIPTION = "EXPORT_PLAN_TEMPLATE_DESCRIPTION";

    @RBEntry("导出计划模板")
    public static final String EXPORT_PLAN_TEMPLATE_LABEL = "EXPORT_PLAN_TEMPLATE_LABEL";

    @RBEntry("{0} 模板")
    @RBComment("A space was added between the insert and \"Template\"")
    public static final String DEFAULT_EXPORT_OR_SAVE_AS_PLAN_TEMPLATE_NAME = "DEFAULT_EXPORT_OR_SAVE_AS_PLAN_TEMPLATE_NAME";

    @RBEntry("计划名称:")
    public static final String EXPORT_OR_SAVE_AS_PLAN_LABEL = "EXPORT_OR_SAVE_AS_PLAN_LABEL";

    @RBEntry("{0}")
    @RBPseudo(false)
    public static final String EXPORT_OR_SAVE_AS_PLAN_NAME = "EXPORT_OR_SAVE_AS_PLAN_NAME";

    @RBEntry("计划模板名称:")
    public static final String EXPORT_OR_SAVE_AS_PLAN_NAME_LABEL = "EXPORT_OR_SAVE_AS_PLAN_NAME_LABEL";

    @RBEntry("选择要复制到新计划的对象:")
    public static final String SELECT_ITEMS_TO_COPY_TO_PLAN = "SELECT_ITEMS_TO_COPY_TO_PLAN";

    @RBEntry("说明:")
    public static final String PLAN_TEMPLATE_DESCRIPTION = "PLAN_TEMPLATE_DESCRIPTION";

    @RBEntry("计划活动")
    public static final String PLAN_ACTIVITIES = "PLAN_ACTIVITIES";

    @RBEntry("可交付结果")
    public static final String PLAN_DELIVERABLES = "PLAN_DELIVERABLES";

    @RBEntry("资源分配")
    public static final String RESOURCE_ASSIGNMENTS = "RESOURCE_ASSIGNMENTS";

    @RBEntry("已分配的资源")
    public static final String ASSIGNED_RESOURCES = "ASSIGNED_RESOURCES";

    @RBEntry("未分配的资源")
    public static final String UNASSIGNED_RESOURCES = "UNASSIGNED_RESOURCES";

    @RBEntry("请输入名称。")
    public static final String NAME_REQUIRED = "NAME_REQUIRED";

    @RBEntry("说明太长")
    public static final String ERROR_LONG_DESC = "ERROR_LONG_DESC";

    @RBEntry("另存为计划模板")
    public static final String SAVE_AS_PLAN_TEMPLATE_TITLE = "SAVE_AS_PLAN_TEMPLATE_TITLE";

    @RBEntry("通过复制现有计划 {0} 来创建新的计划模板")
    public static final String SAVE_AS_PLAN_TEMPLATE_DESCRIPTION = "SAVE_AS_PLAN_TEMPLATE_DESCRIPTION";

    @RBEntry("另存为计划模板")
    public static final String SAVE_AS_PLAN_TEMPLATE_LABEL = "SAVE_AS_PLAN_TEMPLATE_LABEL";

    @RBEntry("正在创建计划...")
    @RBComment("Message displayed while plan is being created.")
    public static final String CREATING_PLAN = "CREATING_PLAN";

    @RBEntry("选择了无效的对象。此操作对于一个或多个选定对象无效。")
    public static final String INVALID_OBJECT_SELECTION_ERROR = "INVALID_OBJECT_SELECTION_ERROR";

    @RBEntry("将活动标记为可交付结果")
    @RBComment("Mark the Activity as Deliverable")
    public static final String MARK_ACTIVITY_AS_DELIVERABLE = "MARK_ACTIVITY_AS_DELIVERABLE";

    @RBEntry("跟踪策略")
    public static final String TRACKING_POLICY = "TRACKING_POLICY";

    @RBEntry("可交付结果")
    @RBComment("Title for scheduled deliverable step of activity wizards")
    public static final String ACTIVITY_WIZARD_DELIVERABLE = "ACTIVITY_WIZARD_DELIVERABLE";

    @RBEntry("已统计成本")
    @RBComment("Label for the attribute holding the rolled up cost.")
    public static final String ROLLED_UP_COST = "ROLLED_UP_COST";

    @RBEntry("排程")
    @RBComment("Title for Structure tree table on the Plans information page")
    public static final String SCHEDULE = "SCHEDULE";

    @RBEntry("计划名称 \"{0}\" 在容器 \"{1}\" 中不是唯一。")
    @RBComment("Message displayed when plan name is unique in container")
    public static final String NON_UNIQUE_PLAN_NAME = "NON_UNIQUE_PLAN_NAME";
    
    @RBEntry("具有可交付结果")
    @RBComment("Label for attribute to appear on the comparison report")
    public static final String HAS_DELIVERABLE = "Has Deliverable";

    @RBEntry("必须输入名称的值")
    @RBComment("Message displayed when plan name null or empty")
    public static final String PLAN_NAME_RESQUIRED = "PLAN_NAME_RESQUIRED";

    @RBEntry("必须输入所有者的值")
    @RBComment("Message displayed when plan owner null or empty")
    public static final String PLAN_OWNER_RESQUIRED = "PLAN_OWNER_RESQUIRED";
    
    @RBEntry("您没有权限移除以下对象:\n{0}")
    @RBComment("Warning message when user tries to remove selected PlanActivity(ScheduledDeliverable) objects for which user does not have access to.")
    public static final String SCHEDULEDDELIVERABLE_UNAUTHORIZED_ACCESS = "SCHEDULEDDELIVERABLE_UNAUTHORIZED_ACCESS";
    
    @RBEntry("不能对已完成的对象执行此操作:\n{0}")
    @RBComment("Warning message when user tries to remove completed PlanActivity (ScheduledDeliverable) objects.")
    public static final String COMPLETED_SCHEDULEDDELIVERABLE_SELECTED = "COMPLETED_SCHEDULEDDELIVERABLE_SELECTED";
    
    @RBEntry("是否继续处理剩余的选定对象?")
    @RBComment("Confirmation message to continue when user is prompted with warning message.")
    public static final String CONFIRMATION_SHOULD_CONTINUE = "CONFIRMATION_SHOULD_CONTINUE";
    
    @RBEntry("没有剩余的对象需要移除。")
    @RBComment("Confirmation message to continue when user is prompted with warning message.")
    public static final String INFO_NO_MORE_OBJECTS_TO_REMOVE = "INFO_NO_MORE_OBJECTS_TO_REMOVE";
  
    @RBEntry("此上下文中没有符合条件的计划。您必须有一个手动计划，或一个状态为“正在进行”的自动计划。而且您必须已分配到该计划的可交付结果活动: {0}。")
    @RBComment("An alert message which the user is notified with when there are no eligible plans available to invoke Track New Work action.")
    public static final String NO_ELIGIBLE_PLANS_PRESENT_FOR_TRACK_NEW_WORK = "NO_ELIGIBLE_PLANS_PRESENT_FOR_TRACK_NEW_WORK";
    
    @RBEntry("此活动没有符合条件的计划。您必须具备手动计划，或状态为“已安排”、“正在进行”或“已暂停”的自动计划。")
    @RBComment("An alert message which the user is notified with when there are no eligible plans available to invoke New Plan Activity action.")
    public static final String NO_ELIGIBLE_PLANS_PRESENT_FOR_NEW_PLAN_ACTIVITY = "NO_ELIGIBLE_PLANS_PRESENT_FOR_NEW_PLAN_ACTIVITY";
    
    @RBEntry("You have selected invalid objects for this operation.")
    @RBComment("An alert message which the user is notified with when user does not have access to selected object's parent container.")
    public static final String INVALID_OBJECTS_SELECTED = "INVALID_OBJECTS_SELECTED";

    @RBEntry("请选择两个基线对象进行比较。")
    @RBComment("Please Select Two Object To Be Compared.")
    public static final String COMPARE_OBJECT_ERROR = "COMPARE_OBJECT_ERROR";
}

