//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.projectmanagement.plan.baseline;

import com.ptc.core.components.util.OidHelper;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.projectmanagement.assignment.AssignmentHelper;
import com.ptc.projectmanagement.assignment.ResourceAssignment;
import com.ptc.projectmanagement.assignment.SharedAssignmentDetails;
import com.ptc.projectmanagement.assignment.baseline.BaselinedAssignmentDetails;
import com.ptc.projectmanagement.assignment.baseline.BaselinedResourceAssignment;
import com.ptc.projectmanagement.assignment.resource.PlanResource;
import com.ptc.projectmanagement.assignment.resource.baseline.BaselinedPlanResource;
import com.ptc.projectmanagement.deliverable.PlanDeliverable;
import com.ptc.projectmanagement.deliverable.PlanDeliverableLink;
import com.ptc.projectmanagement.deliverable.baseline.BaselinedPlanDeliverable;
import com.ptc.projectmanagement.plan.Hierarchical;
import com.ptc.projectmanagement.plan.Plan;
import com.ptc.projectmanagement.plan.PlanActivity;
import com.ptc.projectmanagement.plan.Plannable;
import com.ptc.projectmanagement.plannable.PlannableHelper;
import com.ptc.projectmanagement.plannable.PrecedenceConstraint;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Set;
import org.apache.log4j.Logger;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTPrincipalReference;
import wt.pom.Transaction;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.services.ManagerException;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtility;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class StandardBaselineService extends StandardManager implements BaselineService, Serializable {
    private static final String CLASSNAME = StandardBaselineService.class.getName();
    private static final Logger logger;

    public StandardBaselineService() {
    }

    public String getConceptualClassname() {
        return CLASSNAME;
    }

    public static StandardBaselineService newStandardBaselineService() throws WTException {
        StandardBaselineService var0 = new StandardBaselineService();
        var0.initialize();
        return var0;
    }

    protected void performStartupProcess() throws ManagerException {
        super.performStartupProcess();
        PlannableExternalTypeValidator.init();
    }

    public BaselinedPlan createPlanBaseline(Plan var1, String var2, String var3) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("StandardBaselineService : Inside createBaselinedPlan()");
        }

        BaselinedPlan var4 = null;
        Object var5 = new WTArrayList();
        WTArrayList var6 = new WTArrayList();
        WTArrayList var7 = new WTArrayList();
        WTArrayList var8 = new WTArrayList();
        WTArrayList var9 = new WTArrayList();
        WTArrayList var10 = new WTArrayList();
        ArrayList var11 = new ArrayList();
        HashMap var12 = new HashMap();
        HashMap var13 = new HashMap();
        HashMap var14 = new HashMap();
        HashMap var15 = new HashMap();
        Transaction var16 = null;

        try {
            var16 = new Transaction();
            var16.start();
            var4 = this.createMappedBaseLinedPlanAndCopyAllAttributes(var1, var2, var3);
            WTCollection var17 = PlannableHelper.service.getAllPlannables(var1, false);
            Iterator var18 = var17.iterator();

            Object var19;
            BaselinedPlanActivity var21;
            while(var18.hasNext()) {
                var19 = var18.next();
                PlanActivity var20 = (PlanActivity)((ObjectReference)var19).getObject();
                var21 = this.createBaselinedPlanActivity(var4, var20, var14);
                var21.setLineNumber(var20.getLineNumber());
                ((WTCollection)var5).add(var21);
                var15.put(var20.getLineNumber(), var20);
            }

            if (!((WTCollection)var5).isEmpty()) {
                var5 = PersistenceHelper.manager.modify((WTCollection)var5);
            }

            var18 = ((WTCollection)var5).iterator();

            while(var18.hasNext()) {
                var19 = var18.next();
                BaselinedPlanActivity var47 = (BaselinedPlanActivity)((ObjectReference)var19).getObject();
                var14.put(var47.getLineNumber(), var47);
            }

            WTArrayList var43 = new WTArrayList();
            Set var44 = var14.keySet();
            Iterator var45 = var44.iterator();

            label292:
            while(var45.hasNext()) {
                Integer var48 = (Integer)var45.next();
                var21 = (BaselinedPlanActivity)var14.get(var48);
                PlanActivity var22 = (PlanActivity)var15.get(var48);
                AttributeCopierUtility.copyAttributeValues(AttributeCopierUtility.ACTIVITY_ATTRIBUTES, var22, var21);
                Object var23 = null;
                if (var22.getParent() instanceof Plan) {
                    var23 = var4;
                } else {
                    int var24 = ((PlanActivity)var22.getParent()).getLineNumber();
                    var23 = (Hierarchical)var14.get(var24);
                }

                var21.setParent((Hierarchical)var23);
                var43.add(var21);
                WTCollection var49 = PlannableHelper.service.getDeliverables(var22);
                Iterator var25 = var49.iterator();

                while(var25.hasNext()) {
                    Object var26 = var25.next();
                    PlanDeliverable var27 = (PlanDeliverable)((ObjectReference)var26).getObject();
                    BaselinedPlanDeliverable var28 = null;
                    if (var12.size() > 0 && var12.containsKey(var27)) {
                        var28 = (BaselinedPlanDeliverable)var12.get(var27);
                    } else {
                        var28 = this.createBaselinedPlanDeliverable(var27, var4);
                        var6.add(var28);
                    }

                    var12.put(var27, var28);
                    PlanDeliverableLink var29 = PlanDeliverableLink.newPlanDeliverableLink(var21, var28);
                    var7.add(var29);
                }

                WTCollection var50 = AssignmentHelper.service.getResourceAssignments(var22);
                Iterator var51 = var50.iterator();

                while(true) {
                    BaselinedResourceAssignment var31;
                    ResourceAssignment var53;
                    do {
                        if (!var51.hasNext()) {
                            continue label292;
                        }

                        Object var52 = var51.next();
                        var53 = (ResourceAssignment)((ObjectReference)var52).getObject();
                        PlanResource var54 = (PlanResource)var53.getResource();
                        BaselinedPlanResource var30 = null;
                        if (var13.size() > 0 && var13.containsKey(var54)) {
                            var30 = (BaselinedPlanResource)var13.get(var54);
                        } else {
                            var30 = this.createBaselinedPlanResource(var54, var4);
                            var30.setRootReference(ObjectReference.newObjectReference(var4));
                            var8.add(var30);
                        }

                        var13.put(var54, var30);
                        var31 = this.createBaselinedResourceAssignment(var53, var30, var21);
                        var9.add(var31);
                    } while(!var53.isSharedAssignment() && !var53.isBulkAssignment());

                    WTArrayList var32 = AssignmentHelper.service.getSharedAssignmentDetails(var53);
                    Iterator var33 = var32.iterator();

                    while(var33.hasNext()) {
                        Object var34 = var33.next();
                        SharedAssignmentDetails var35 = (SharedAssignmentDetails)((ObjectReference)var34).getObject();
                        WTPrincipalReference var36 = var35.getMemberResource();
                        BaselinedAssignmentDetails var37 = this.createBaselinedResourceAssignmentDetail(var35, var31, var36);
                        var10.add(var37);
                    }
                }
            }

            ArrayList var46 = this.createPrecedenceConstraint(var1, var14);
            if (var46 != null) {
                var11.addAll(var46);
            }

            PersistenceHelper.manager.save(var4);
            if (!var43.isEmpty()) {
                PersistenceHelper.manager.save(var43);
            }

            if (!var6.isEmpty()) {
                PersistenceHelper.manager.save(var6);
                PersistenceHelper.manager.save(var7);
            }

            if (!var8.isEmpty()) {
                PersistenceHelper.manager.save(var8);
            }

            if (!var9.isEmpty()) {
                PersistenceHelper.manager.save(var9);
            }

            if (!var10.isEmpty()) {
                PersistenceHelper.manager.save(var10);
            }

            if (!var11.isEmpty()) {
                PlannableHelper.service.addPrecedenceConstraints(var11);
            }

            var16.commit();
            var16 = null;
        } catch (WTPropertyVetoException var41) {
            logger.error(var41);
            throw new WTException(var41.getLocalizedMessage(SessionHelper.getLocale()));
        } finally {
            if (var16 != null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("StandardBaselineService.createPlanBaseline : Rollback transaction");
                }

                var16.rollback();
            }

        }

        return var4;
    }

    private BaselinedPlanActivity createBaselinedPlanActivity(BaselinedPlan var1, PlanActivity var2, HashMap<Integer, BaselinedPlanActivity> var3) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("StandardBaselineService : Inside createBaselinedPlanActivity()");
        }

        Locale var4 = WTContext.getContext().getLocale();
        ObjectReference var5 = ObjectReference.newObjectReference(var2);
        WTContainerRef var6 = var2.getContainerReference();
        TypeIdentifier var7 = OidHelper.getTypeIdentifier(var2);
        TypeIdentifier var8 = BaselinedTypeHandleHelper.getTargetBaselinedType(var7);
        if (logger.isDebugEnabled()) {
            logger.debug("sourceActivity   " + var2);
            logger.debug("sourceTypeIdentifier   " + var7);
            logger.debug("targetMappedTypeIdentifier   " + var8);
        }

        BaselinedPlan var9 = var1;
        BaselinedPlanActivity var10 = null;

        try {
            var10 = BaselinedPlanActivity.newBaselinedPlanActivity(var9, (Hierarchical)null, var5);
            var10.setDomainRef(var2.getDomainRef());
            var10.setContainerReference(var6);
            TypeDefinitionReference var11 = TypedUtility.getTypeDefinitionReference(var8.getTypeInternalName());
            var10.setTypeDefinitionReference(var11);
            var10 = (BaselinedPlanActivity)PersistenceHelper.manager.save(var10);
        } catch (Exception var13) {
            logger.error("Exception while creating baselined plan activity..", var13);
            throw new WTException(var13);
        }

        PersistableAdapter var14 = new PersistableAdapter(var10, var8.getTypeInternalName(), var4, new UpdateOperationIdentifier());
        AttributeCopierUtility.copyIBAValues(var2, var14, AttributeCopierUtility.BASELINEDACTIVITY_ATTRIBUTES);
        BaselinedPlanActivity var12 = (BaselinedPlanActivity)var14.apply();
        if (logger.isDebugEnabled()) {
            logger.debug("baselinedActivity   " + var12);
        }

        return var12;
    }

    private BaselinedPlanDeliverable createBaselinedPlanDeliverable(PlanDeliverable var1, BaselinedPlan var2) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("StandardBaselineService : Inside createBaselinedPlanDeliverable()");
        }

        BaselinedPlanDeliverable var3 = BaselinedPlanDeliverable.newBaselinedPlanDeliverable(var2, ObjectReference.newObjectReference(var1));
        AttributeCopierUtility.copyAttributeValues(AttributeCopierUtility.DELIVERABLE_ATTRIBUTES, var1, var3);
        AttributeCopierUtility.copyIBAValues(var1, var3);
        return var3;
    }

    private BaselinedPlanResource createBaselinedPlanResource(PlanResource var1, BaselinedPlan var2) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("StandardBaselineService : Inside createBaselinedPlanResource()");
        }

        BaselinedPlanResource var3 = BaselinedPlanResource.newBaselinedPlanResource(var2, ObjectReference.newObjectReference(var1));
        AttributeCopierUtility.copyAttributeValues(AttributeCopierUtility.RESOURCE_ATTRIBUTES, var1, var3);
        return var3;
    }

    private BaselinedAssignmentDetails createBaselinedResourceAssignmentDetail(SharedAssignmentDetails var1, BaselinedResourceAssignment var2, WTPrincipalReference var3) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("StandardBaselineService : Inside createBaselinedResourceAssignment()");
        }

        BaselinedAssignmentDetails var4 = BaselinedAssignmentDetails.newBaselinedAssignmentDetail(var2, ObjectReference.newObjectReference(var1), var3);
        AttributeCopierUtility.copyAttributeValues(AttributeCopierUtility.ASSIGNMENT_DETAIL_ATTRIBUTES, var1, var4);
        return var4;
    }

    private BaselinedResourceAssignment createBaselinedResourceAssignment(ResourceAssignment var1, BaselinedPlanResource var2, BaselinedPlanActivity var3) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("StandardBaselineService : Inside createBaselinedResourceAssignment()");
        }

        BaselinedResourceAssignment var4 = BaselinedResourceAssignment.newBaselinedResourceAssignment(var2, var3, ObjectReference.newObjectReference(var1));
        AttributeCopierUtility.copyAttributeValues(AttributeCopierUtility.ASSIGNMENT_ATTRIBUTES, var1, var4);
        return var4;
    }

    private ArrayList createPrecedenceConstraint(Plan var1, HashMap<Integer, BaselinedPlanActivity> var2) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("StandardBaselineService : Inside createPrecedenceConstraint()");
        }
        ArrayList list = new ArrayList();
        PrecedenceConstraint var3 = null;

        try {
            LinkedHashMap var4 = PlannableHelper.service.getAllPlanPrecedenceConstraints(var1);
            ArrayList var5 = new ArrayList(var4.values());
            Iterator var6 = var5.iterator();

            while(var6.hasNext()) {
                ArrayList var7 = (ArrayList)var6.next();
                Iterator var9 = var7.iterator();

                while(var9.hasNext()) {
                    PrecedenceConstraint var10 = (PrecedenceConstraint)var9.next();
                    PlanActivity var12 = (PlanActivity)var10.getPredecessor();
                    PlanActivity var13 = (PlanActivity)var10.getSuccessor();
                    int var14 = var12.getLineNumber();
                    int var15 = var13.getLineNumber();
                    BaselinedPlanActivity var16 = (BaselinedPlanActivity)var2.get(var14);
                    BaselinedPlanActivity var17 = (BaselinedPlanActivity)var2.get(var15);
                    var3 = PrecedenceConstraint.newPrecedenceConstraint(var17, var16);
                    var3.setPrecedenceType(var10.getPrecedenceType());
                    var3.setScheduleOffset(var10.getScheduleOffset());
                    list.add(var3);
                }
            }

            return list;
        } catch (WTPropertyVetoException var18) {
            logger.error(var18);
            throw new WTException(var18.getLocalizedMessage(SessionHelper.getLocale()));
        }
    }

    public WTCollection getAllBaselines(ObjectReference var1) throws WTException {
        QuerySpec var2 = this.getAllBaselinesQuerySpec(var1);
        QueryResult var3 = PersistenceHelper.manager.find(var2);
        WTArrayList var4 = new WTArrayList();
        var4.addAll(var3);
        return var4;
    }

    private QuerySpec getAllBaselinesQuerySpec(ObjectReference var1) throws WTException {
        QuerySpec var2 = new QuerySpec();
        Class var3 = null;
        ClassAttribute var4 = null;
        if (var1.getObject() instanceof Baselineable) {
            var1 = ((Baselineable)var1.getObject()).getCurrentObjectRef();
        }

        Class var5 = var1.getObject().getClass();
        if (var5.equals(Plan.class)) {
            var3 = BaselinedPlan.class;
            var4 = new ClassAttribute(BaselinedPlan.class, "baselineId");
        } else if (var5.equals(PlanActivity.class)) {
            var3 = BaselinedPlanActivity.class;
            var4 = new ClassAttribute(BaselinedPlanActivity.class, "thePersistInfo.createStamp");
        } else if (var5.equals(PlanResource.class)) {
            var3 = BaselinedPlanResource.class;
            var4 = new ClassAttribute(BaselinedPlanResource.class, "thePersistInfo.createStamp");
        } else if (var5.equals(ResourceAssignment.class)) {
            var3 = BaselinedResourceAssignment.class;
            var4 = new ClassAttribute(BaselinedResourceAssignment.class, "thePersistInfo.createStamp");
        } else if (var5.equals(PlanDeliverable.class)) {
            var3 = BaselinedPlanDeliverable.class;
            var4 = new ClassAttribute(BaselinedPlanDeliverable.class, "thePersistInfo.createStamp");
        }

        int var6 = var2.appendClassList(var3, true);
        SearchCondition var7 = new SearchCondition(var3, "currentObjectReference.key", "=", (ObjectIdentifier)var1.getKey());
        var2.appendWhere(var7, new int[]{var6});
        var2.appendOrderBy(new OrderBy(var4, true), new int[]{var6});
        return var2;
    }

    public int getMaxPlanBaselineId(ObjectReference var1) throws WTException {
        QuerySpec var2 = this.getMaxPlanBaselineIdQuerySpec(var1);
        QueryResult var3 = PersistenceServerHelper.manager.query(var2);
        if (var3.hasMoreElements()) {
            BigDecimal var4 = (BigDecimal)((Object[])((Object[])var3.nextElement()))[0];
            return var4 != null ? var4.intValue() : 0;
        } else {
            return 0;
        }
    }

    private QuerySpec getMaxPlanBaselineIdQuerySpec(ObjectReference var1) throws WTException {
        Class var2 = BaselinedPlan.class;
        QuerySpec var3 = new QuerySpec();
        var3.setAdvancedQueryEnabled(true);
        int var4 = var3.appendClassList(var2, false);
        ClassAttribute var5 = new ClassAttribute(var2, "baselineId");
        SQLFunction var6 = SQLFunction.newSQLFunction("MAX", var5);

        try {
            var6.setColumnAlias("maxId");
        } catch (WTPropertyVetoException var8) {
            throw new WTException(var8);
        }

        var3.appendSelect(var6, new int[]{var4}, false);
        SearchCondition var7 = new SearchCondition(var2, "currentObjectReference.key", "=", (ObjectIdentifier)var1.getKey());
        var3.appendWhere(var7, new int[]{var4});
        return var3;
    }

    public BaselinedPlan getActiveBaseline(ObjectReference var1) throws WTException {
        BaselinedPlan var2 = null;
        WTArrayList var3 = (WTArrayList)this.getAllBaselines(var1);
        if (var3 != null && var3.size() > 0) {
            BaselinedPlan var4 = null;
            Iterator var5 = var3.persistableIterator();

            while(var5.hasNext()) {
                var4 = (BaselinedPlan)var5.next();
                if (var4.isActive()) {
                    var2 = var4;
                    break;
                }
            }

            if (var2 == null) {
                var2 = (BaselinedPlan)var3.persistableIterator().next();
            }
        }

        return var2;
    }

    public boolean isActiveBaseline(BaselinedPlan var1) throws WTException {
        if (var1 != null) {
            BaselinedPlan var2 = this.getActiveBaseline(var1.getCurrentObjectReference());
            if (var1.equals(var2)) {
                return true;
            }
        }

        return false;
    }

    public void setAsActiveBaseline(BaselinedPlan var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("setAsActiveBaseline::baselinedPlan is  - " + var1);
        }

        if (var1 != null) {
            try {
                BaselinedPlan var2 = BaselineHelper.service.getActiveBaseline(var1.getCurrentObjectReference());
                if (logger.isDebugEnabled()) {
                    logger.debug("setAsActiveBaseline::currentActiveBaseline is  - " + var2);
                }

                WTArrayList var3 = new WTArrayList();
                if (var2 != null && var2.isActive()) {
                    var2.setActive(false);
                    var3.add(var2);
                }

                var1.setActive(true);
                var3.add(var1);
                PersistenceHelper.manager.save(var3);
            } catch (WTPropertyVetoException var4) {
                throw new WTException(var4);
            }
        }

    }

    public void unsetAsActiveBaseline(BaselinedPlan var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("unsetAsActiveBaseline::baselinedPlan is  - " + var1);
        }

        if (var1 != null && var1.isActive()) {
            try {
                var1.setActive(false);
                PersistenceHelper.manager.save(var1);
            } catch (WTPropertyVetoException var3) {
                throw new WTException(var3);
            }
        }

    }

    public void setLatestBaselineAsActive(Plan var1) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("setLatestBaselineAsActive::plan is  - " + var1);
        }

        if (var1 != null) {
            try {
                BaselinedPlan var2 = BaselineHelper.service.getActiveBaseline(ObjectReference.newObjectReference(var1));
                if (var2 != null && var2.isActive()) {
                    var2.setActive(false);
                    PersistenceHelper.manager.save(var2);
                }
            } catch (WTPropertyVetoException var3) {
                throw new WTException(var3);
            }
        }

    }

    public void deleteBaselines(WTCollection var1) throws WTException {
        if (var1 != null && var1.size() > 0) {
            WTHashSet var2 = new WTHashSet();
            BaselinedPlan var3 = null;

            label84:
            for(Iterator var4 = var1.persistableIterator(); var4.hasNext(); var2.add(var3)) {
                var3 = (BaselinedPlan)var4.next();
                if (logger.isDebugEnabled()) {
                    logger.debug("deleteBaseline::Deleting baseline - " + var3);
                }

                WTCollection var5 = PlannableHelper.service.getAllPlannables(var3, false);
                if (var5 != null && var5.size() > 0) {
                    LinkedHashMap var6 = PlannableHelper.service.getAllPlanPrecedenceConstraints(var3);
                    Collection var7 = var6.values();
                    Iterator var8 = var7.iterator();

                    while(var8.hasNext()) {
                        ArrayList var9 = (ArrayList)var8.next();
                        if (var9 != null && var9.size() > 0) {
                            var2.addAll(var9);
                        }
                    }

                    var8 = null;
                    Iterator var17 = var5.persistableIterator();

                    while(true) {
                        WTCollection var18;
                        do {
                            do {
                                if (!var17.hasNext()) {
                                    var2.addAll(var5);
                                    continue label84;
                                }

                                BaselinedPlanActivity var16 = (BaselinedPlanActivity)var17.next();
                                WTCollection var10 = PlannableHelper.service.getDeliverables(var16);
                                BaselinedPlanDeliverable var11 = null;
                                if (var10 != null && var10.size() > 0) {
                                    Iterator var12 = var10.persistableIterator();

                                    while(var12.hasNext()) {
                                        var11 = (BaselinedPlanDeliverable)var12.next();
                                        var2.addAll(PlannableHelper.service.getPlanDeliverableLinks(var11));
                                    }

                                    var2.addAll(var10);
                                }

                                var18 = AssignmentHelper.service.getResourceAssignments(var16);
                            } while(var18 == null);
                        } while(var18.size() <= 0);

                        var2.addAll(var18);
                        BaselinedResourceAssignment var13 = null;
                        BaselinedPlanResource var14 = null;
                        Iterator var15 = var18.persistableIterator();

                        while(var15.hasNext()) {
                            var13 = (BaselinedResourceAssignment)var15.next();
                            var14 = (BaselinedPlanResource)var13.getResource();
                            var2.add(var14);
                        }
                    }
                }
            }

            PersistenceHelper.manager.delete(var2);
        }

    }

    protected Plannable savePlannable(Plannable var1) throws WTException {
        return (Plannable)PersistenceHelper.manager.store(var1);
    }

    BaselinedPlan createMappedBaseLinedPlanAndCopyAllAttributes(Plan var1, String var2, String var3) throws WTException {
        Locale var4 = WTContext.getContext().getLocale();
        ObjectReference var5 = ObjectReference.newObjectReference(var1);
        WTContainerRef var6 = var1.getContainerReference();
        TypeIdentifier var7 = OidHelper.getTypeIdentifier(var1);
        TypeIdentifier var8 = BaselinedTypeHandleHelper.getTargetBaselinedType(var7);
        if (logger.isDebugEnabled()) {
            logger.debug("sourcePlan   " + var1);
            logger.debug("sourceTypeIdentifier   " + var7);
            logger.debug("targetMappedTypeIdentifier   " + var8);
        }

        BaselinedPlan var9 = null;

        try {
            var9 = BaselinedPlan.newBaselinedPlan(var2, var5, var6);
            var9.setDomainRef(var1.getDomainRef());
            TypeDefinitionReference var10 = TypedUtility.getTypeDefinitionReference(var8.getTypeInternalName());
            var9.setTypeDefinitionReference(var10);
            var9 = (BaselinedPlan)PersistenceHelper.manager.store(var9);
        } catch (Exception var12) {
            logger.error("Exception while creating baselined plan..", var12);
            throw new WTException(var12);
        }

        PersistableAdapter var13 = new PersistableAdapter(var9, var8.getTypeInternalName(), var4, new UpdateOperationIdentifier());
        AttributeCopierUtility.copyIBAValues(var1, var13, AttributeCopierUtility.BASELINEDPLAN_ATTRIBUTES);
        var13.set("baselineDescription", var3);
        var13.apply();
        BaselinedPlan var11 = (BaselinedPlan)PersistenceHelper.manager.modify(var9);
        if (logger.isDebugEnabled()) {
            logger.debug("targetBaselinedPlan   " + var11);
            logger.debug("targetTypeIdentifier   " + OidHelper.getTypeIdentifier(var11));
        }

        AttributeCopierUtility.copyAttributeValues(AttributeCopierUtility.PLAN_ATTRIBUTES, var1, var11);
        return var11;
    }

    static {
        logger = LogR.getLogger(CLASSNAME);
    }
}
