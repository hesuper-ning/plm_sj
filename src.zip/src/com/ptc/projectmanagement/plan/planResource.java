//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.projectmanagement.plan;

import wt.util.resource.*;

@RBUUID("com.ptc.projectmanagement.plan.planResource")
public final class planResource extends WTListResourceBundle {
    @RBEntry("Plan")
    public static final String PLAN = "PLAN";
    @RBEntry("Plan:")
    public static final String PLAN_1 = "PLAN_1";
    @RBEntry("Plans")
    public static final String PLANS_TITLE = "PLANS_TITLE";
    @RBEntry("Baselined Plan")
    public static final String BASELINED_PLAN = "BASELINED_PLAN";
    @RBEntry("Actions")
    public static final String ACTIONS_TITLE = "ACTIONS_TITLE";
    @RBEntry("PBO Type")
    public static final String PBO_TYPEICON_TITLE = "PBO_TYPEICON_TITLE";
    @RBEntry("Invalid duration. \nThis is not a valid duration or it is outside the range for this field. \nFor example, enter a format such as: 4 hours (or 4hrs), 12 days (or 12d)")
    public static final String INVALID_DURATIONFORMAT_ERROR = "INVALID_DURATIONFORMAT_ERROR";
    @RBEntry("Predecessor field includes an invalid lead/lag value.")
    public static final String INVALID_LEADLAGFORMAT_ERROR = "INVALID_LEADLAGFORMAT_ERROR";
    @RBEntry("Invalid work. \nThis is not a valid value or it is outside the range for this field. \nFor example, enter a work value such as: 4 hours (or 4hrs), 12 days (or 12d)")
    public static final String INVALID_WORKFORMAT_ERROR = "INVALID_WORKFORMAT_ERROR";
    @RBEntry("This is not a valid duration or it is outside the range for this field. \nA duration cannot be less than 1 minute.")
    public static final String DURATIONFORMAT_OUT_OF_BOUNDS_ERROR = "DURATIONFORMAT_OUT_OF_BOUNDS_ERROR";
    @RBEntry("Type only positive, whole numbers for relationships between activities.")
    public static final String INVALID_PREDECESSORID_ERROR = "INVALID_PREDECESSORID_ERROR";
    @RBEntry("Invalid predecessor format or constraint.")
    public static final String INVALID_PRECEDENCEFORMAT_ERROR = "INVALID_PRECEDENCEFORMAT_ERROR";
    @RBEntry("\nPrecedence relationships must follow the format: \n  <Predecessor ID#><Dependency type> \nIf including a lead or lag:\n  <Predecessor ID#><Dependency type><+ or -><duration> \nDo not include spaces between values. For example: 3FS+1.5day or 18SS-5hrs")
    public static final String INVALID_PRECEDENCEFORMAT_ERROR_INFO = "INVALID_PRECEDENCEFORMAT_ERROR_INFO";
    @RBEntry("You must specify a dependency type. To include a dependency type, use the format: <Predecessor ID#><Dependency type><+ or -><duration> \nDo not include spaces between values. For example: 3FS+1.5day or 18SS-5hrs")
    public static final String INVALID_PRECEDENCEFORMAT_LEADLAGERROR = "INVALID_PRECEDENCEFORMAT_LEADLAGERROR";
    @RBEntry("ID")
    public static final String ID = "ID";
    @RBEntry("Baseline ID")
    public static final String BASELINE_ID = "BASELINE_ID";
    @RBEntry("Modified By")
    public static final String MODIFIED_BY = "MODIFIED_BY";
    @RBEntry("Attributes")
    public static final String ATTRIBUTE_TABLE_NAME = "ATTRIBUTE_TABLE_NAME";
    @RBEntry("Predecessors")
    public static final String PREDECESSOR = "PREDECESSOR";
    @RBEntry("Name")
    public static final String NAME = "NAME";
    @RBEntry("Type")
    public static final String TYPE = "TYPE";
    @RBEntry("Estimated Start")
    public static final String ACTIVITY_START = "ACTIVITY_START";
    @RBEntry("Estimated Baseline Start")
    public static final String BASELINE_ACTIVITY_START = "BASELINE_ACTIVITY_START";
    @RBEntry("Estimated Start Variance")
    public static final String ACTIVITY_START_VARIANCE = "ACTIVITY_START_VARIANCE";
    @RBEntry("Estimated Finish")
    public static final String ACTIVITY_FINISH = "ACTIVITY_FINISH";
    @RBEntry("Estimated Baseline Finish")
    public static final String BASELINE_ACTIVITY_FINISH = "BASELINE_ACTIVITY_FINISH";
    @RBEntry("Estimated Finish Variance")
    public static final String ACTIVITY_FINISH_VARIANCE = "ACTIVITY_FINISH_VARIANCE";
    @RBEntry("Actual Start")
    public static final String ACTIVITY_ACTUALSTART = "ACTIVITY_ACTUALSTART";
    @RBEntry("Baseline Actual Start")
    public static final String BASELINE_ACTIVITY_ACTUALSTART = "BASELINE_ACTIVITY_ACTUALSTART";
    @RBEntry("Actual Finish")
    public static final String ACTIVITY_ACTUALFINISH = "ACTIVITY_ACTUALFINISH";
    @RBEntry("Baseline Actual Finish")
    public static final String BASELINE_ACTIVITY_ACTUALFINISH = "ACTIVITY_BASELINE_ACTUALFINISH";
    @RBEntry("Resources")
    public static final String RESOURCES = "RESOURCES";
    @RBEntry("Baseline Units")
    public static final String BASELINE_UNITS = "BASELINE_UNITS";
    @RBEntry("Units")
    public static final String UNITS = "UNITS";
    @RBEntry("Work")
    public static final String WORK = "WORK";
    @RBEntry("Actual Work")
    public static final String ACTUALWORK = "ACTUALWORK";
    @RBEntry("Baseline Actual Work")
    public static final String BASELINE_ACTUALWORK = "BASELINE_ACTUALWORK";
    @RBEntry("Remaining Work")
    public static final String REMAININGWORK = "REMAININGWORK";
    @RBEntry("Baseline Remaining Work")
    public static final String BASELINE_REMAININGWORK = "BASELINE_REMAININGWORK";
    @RBEntry("Remaining Work Variance")
    public static final String REMAININGWORK_VARIANCE = "REMAININGWORK_VARIANCE";
    @RBEntry("% Work Complete")
    public static final String PERCENTWORKCOMPLETE = "PERCENTWORKCOMPLETE";
    @RBEntry("Baseline % Work Complete")
    public static final String BASELINE_PERCENTWORKCOMPLETE = "BASELINE_PERCENTWORKCOMPLETE";
    @RBEntry("% Work Complete Variance")
    public static final String PERCENTWORKCOMPLETE_VARIANCE = "PERCENTWORKCOMPLETE_VARIANCE";
    @RBEntry("You must define a duration.")
    public static final String NO_DURATION_SPECIFIED = "NO_DURATION_SPECIFIED";
    @RBEntry("Lag")
    public static final String LEAD_LAG = "LEAD_LAG";
    @RBEntry("Import Plan")
    public static final String IMPORT_WIZARD_TITLE = "IMPORT_WIZARD_TITLE";
    @RBEntry("Error Report")
    public static final String ERROR_WIZARD_TITLE = "ERROR_WIZARD_TITLE";
    @RBEntry("Project Plan File")
    public static final String NATIVE_FILE = "NATIVE_FILE";
    @RBEntry("(Example: .mpp)")
    public static final String NATIVE_FILE_TYPE = "NATIVE_FILE_TYPE";
    @RBEntry("Import Mode")
    public static final String FILE_IMPORTMODE = "FILE_IMPORTMODE";
    @RBEntry("Error when importing file")
    public static final String FILE_IMPORT_ERROR = "FILE_IMPORT_ERROR";
    @RBEntry("New Activity")
    public static final String CREATE_ACTIVITY_WIZARD_TITLE = "CREATE_ACTIVITY_WIZARD_TITLE";
    @RBEntry("Activity Name")
    public static final String ACTIVITY_NAME = "ACTIVITY_NAME";
    @RBEntry("Estimated Start")
    public static final String ESTIMATE_START = "ESTIMATE_START";
    @RBEntry("Estimated Finish")
    public static final String ESTIMATE_FINISH = "ESTIMATE_FINISH";
    @RBEntry("Duration")
    public static final String ESTIMATE_DURATION = "ESTIMATE_DURATION";
    @RBEntry("Predecessors")
    public static final String PRECEDENCE_CONSTRAINT = "PRECEDENCE_CONSTRAINT";
    @RBEntry("Edit Activity")
    public static final String EDIT_ACTIVITY_WIZARD_TITLE = "EDIT_ACTIVITY_WIZARD_TITLE";
    @RBEntry("Duration")
    public static final String ACTIVITY_DURATION = "ACTIVITY_DURATION";
    @RBEntry("Baseline Duration")
    public static final String BASELINE_DURATION = "BASELINE_DURATION";
    @RBEntry("Duration Variance")
    public static final String DURATION_VARIANCE = "DURATION_VARIANCE";
    @RBEntry("Predecessor")
    public static final String ACTIVITY_PREDECESSOR = "ACTIVITY_PREDECESSOR";
    @RBEntry("Summary Activity")
    public static final String SUMMARY_ACTIVITY = "SUMMARY_ACTIVITY";
    @RBEntry("Activity")
    public static final String ACTIVITY = "ACTIVITY";
    @RBEntry("Milestone")
    public static final String MILESTONE = "MILESTONE";
    @RBEntry("Mark activity as milestone")
    public static final String MARK_AS_MILESTONE = "MARK_AS_MILESTONE";
    @RBEntry("Task Type")
    public static final String TASK_TYPE = "TASK_TYPE";
    @RBEntry("Task Type (Activity)")
    public static final String TASK_TYPE_ACTIVITY = "TASK_TYPE_ACTIVITY";
    @RBEntry("Baseline Task Type")
    public static final String BASELINE_TASK_TYPE = "BASELINE_TASK_TYPE";
    @RBEntry("Effort Driven")
    public static final String EFFORT_DRIVEN = "EFFORT_DRIVEN";
    @RBEntry("Baseline Effort Driven")
    public static final String BASELINE_EFFORT_DRIVEN = "BASELINE_EFFORT_DRIVEN";
    @RBEntry("Fixed Units")
    public static final String FIXED_UNITS = "FIXED_UNITS";
    @RBEntry("Fixed Work")
    public static final String FIXED_WORK = "FIXED_WORK";
    @RBEntry("Fixed Duration")
    public static final String FIXED_DURATION = "FIXED_DURATION";
    @RBEntry("Only select one row.")
    public static final String INVALID_PASTE_LOCATION_TOO_MANY = "INVALID_PASTE_LOCATION_TOO_MANY";
    @RBEntry("First select one row.")
    public static final String INVALID_PASTE_LOCATION_NONE = "INVALID_PASTE_LOCATION_NONE";
    @RBEntry("Invalid action. You cannot paste above the Plan node. Select a lower row.")
    public static final String INVALID_PASTE_LOCATION_PLAN_SELECTED = "INVALID_PASTE_LOCATION_PLAN_SELECTED";
    @RBEntry("Invalid action. Cut, copy, and paste is not supported between multiple plans.")
    public static final String INVALID_PLAN_OBJECT_IN_MOVE = "INVALID_PLAN_OBJECT_IN_MOVE";
    @RBEntry("Invalid action. The Plan node cannot be included in clipboard actions.")
    public static final String PLAN_ROW_MOVE_ERROR = "PLAN_ROW_MOVE_ERROR";
    @RBEntry("Invalid action. The Plan node cannot be deleted.")
    public static final String PLAN_ROW_DELETE_ERROR = "PLAN_ROW_DELETE_ERROR";
    @RBEntry("Invalid action. The Plan node cannot be indented.")
    public static final String PLAN_ROW_INDENT_ERROR = "PLAN_ROW_INDENT_ERROR";
    @RBEntry(" '{0}' is a summary activity.  Deleting it will delete all its child activities as well. \nTo continue, click OK.")
    public static final String SINGLE_SUMMARY_DELETE_CONFIRMATION = "SINGLE_SUMMARY_DELETE_CONFIRMATION";
    @RBEntry("Some of the selected activities are summary activities.  Deleting these summary activities will delete all of their child activities as well. \nTo continue, click OK.")
    public static final String MULTI_SUMMARY_DELETE_CONFIRMATION = "MULTI_SUMMARY_DELETE_CONFIRMATION";
    @RBEntry("Predecessor relationships are not allowed between a summary activity and its child activities. If you continue, the precedence dependency will be removed.\nTo continue and remove the invalid dependency, click OK.")
    public static final String MOVE_ACTIVITY_CONFIRMATION = "MOVE_ACTIVITY_CONFIRMATION";
    @RBEntry("This action will move the following activity to the In Process state and remove any start date or predecessor constraints: {0}. These changes will take effect when the plan is resumed. \nClick OK to continue.")
    public static final String REMOVE_DATE_PREDECESSOR_CONSTRAINTS_CONFIRMATION = "REMOVE_DATE_PREDECESSOR_CONSTRAINTS_CONFIRMATION";
    @RBEntry("Plan Start")
    public static final String PLAN_START = "PLAN_START";
    @RBEntry("Start")
    public static final String PLAN_DEFAULT_START = "PLAN_DEFAULT_START";
    @RBEntry("Finish")
    public static final String PLAN_FINISH = "PLAN_FINISH";
    @RBEntry("Duration")
    public static final String PLAN_DURATION = "PLAN_DURATION";
    @RBEntry("Calendar")
    public static final String CALENDAR = "CALENDAR";
    @RBEntry("Edit Plan")
    public static final String EDIT_PLAN_WIZARD_TITLE = "EDIT_PLAN_WIZARD_TITLE";
    @RBEntry("Plan Name")
    public static final String PLAN_NAME = "PLAN_NAME";
    @RBEntry("(Calculated)")
    public static final String AUTO_CALCULATED = "AUTO_CALCULATED";
    @RBEntry("Entry")
    public static final String VIEW_ENTRY = "VIEW_ENTRY";
    @RBEntry("Entry View")
    public static final String VIEW_ENTRY_DESC = "VIEW_ENTRY_DESC";
    @RBEntry("Usage")
    public static final String VIEW_USAGE = "VIEW_USAGE";
    @RBEntry("Usage View")
    public static final String VIEW_USAGE_DESC = "VIEW_USAGE_DESC";
    @RBEntry("Work")
    public static final String VIEW_WORK = "VIEW_WORK";
    @RBEntry("Baseline Work")
    public static final String BASELINE_WORK = "BASELINE_WORK";
    @RBEntry("Work Variance")
    public static final String WORK_VARIANCE = "WORK_VARIANCE";
    @RBEntry("Object Type")
    public static final String SOFT_TYPE = "SOFT_TYPE";
    @RBEntry("Execution Control Of Plan")
    public static final String EXECUTION_CONTROL_OF_PLAN = "EXECUTION_CONTROL_OF_PLAN";
    @RBEntry("Version")
    public static final String VERSION = "VERSION";
    @RBEntry("Work View")
    public static final String VIEW_WORK_DESC = "VIEW_WORK_DESC";
    @RBEntry("Cost")
    public static final String VIEW_COST = "VIEW_COST";
    @RBEntry("Cost View")
    public static final String VIEW_COST_DESC = "VIEW_COST_DESC";
    @RBEntry("Summary")
    public static final String VIEW_SUMMARY = "VIEW_SUMMARY";
    @RBEntry("Summary View")
    public static final String VIEW_SUMMARY_DESC = "VIEW_SUMMARY_DESC";
    @RBEntry("Tracking")
    public static final String VIEW_TRACKING = "VIEW_TRACKING";
    @RBEntry("Tracking View")
    public static final String VIEW_TRACKING_DESC = "VIEW_TRACKING_DESC";
    @RBEntry("Baseline Compare")
    public static final String VIEW_BASELINE_COMPARE = "VIEW_BASELINE_COMPARE";
    @RBEntry("Baseline Compare View")
    public static final String VIEW_BASELINE_COMPARE_DESC = "VIEW_BASELINE_COMPARE_DESC";
    @RBEntry("All")
    public static final String VIEW_ALL = "VIEW_ALL";
    @RBEntry("All View")
    public static final String VIEW_ALL_DESC = "VIEW_ALL_DESC";
    @RBEntry("No")
    public static final String NO = "NO";
    @RBEntry("Yes")
    public static final String YES = "YES";
    @RBEntry("Currency Symbol")
    public static final String CURRENCY_SYMBOL = "CURRENCY_SYMBOL";
    @RBEntry("Sets the default currency symbol.")
    public static final String CURRENCY_SYMBOL_DESC = "CURRENCY_SYMBOL_DESC";
    @RBEntry("This preference sets the currency symbol that is used by default on project planning pages. Project managers can later customize this value by editing the plan. <br> Enter a symbol in the field to set a new default value. The initial default is $.")
    public static final String CURRENCY_SYMBOL_DESC_LONG = "CURRENCY_SYMBOL_DESC_LONG";
    @RBEntry("Currency Placement")
    public static final String CURRENCY_PLACEMENT = "CURRENCY_PLACEMENT";
    @RBEntry("Sets the default currency placement.")
    public static final String CURRENCY_PLACEMENT_DESC = "CURRENCY_PLACEMENT_DESC";
    @RBEntry("This preference determines the default placement of the currency symbol in relation to the cost amount. Project managers can later customize this value by editing the plan. <br> The default value is <b>Before</b>.")
    public static final String CURRENCY_PLACEMENT_DESC_LONG = "CURRENCY_PLACEMENT_DESC_LONG";
    @RBEntry("Currency Decimal Digits")
    public static final String CURRENCY_DECIMAL_DIGITS = "CURRENCY_DECIMAL_DIGITS";
    @RBEntry("Sets the default decimal fraction to use in cost amounts.")
    public static final String CURRENCY_DECIMAL_DIGITS_DESC = "CURRENCY_DECIMAL_DIGITS_DESC";
    @RBEntry("This preference determines the default number of decimal digits that are displayed for planning costs. Project managers can later customize this value by editing the plan. <br>Possible values are 0, 1, or 2. For example, if the cost is twenty-five dollars:<ul><li>0 = 25</li><li>1 = 25.0</li><li>2 = 25.00</li></ul> The default value is 0.")
    public static final String CURRENCY_DECIMAL_DIGITS_DESC_LONG = "CURRENCY_DECIMAL_DIGITS_DESC_LONG";
    @RBEntry("Before")
    public static final String BEFORE_PREF_CHOICE = "BEFORE_PREF_CHOICE";
    @RBEntry("After")
    public static final String AFTER_PREF_CHOICE = "AFTER_PREF_CHOICE";
    @RBEntry("Before with space")
    public static final String BRFORE_WITH_SPACE_PREF_CHOICE = "BEFORE_WITH_SPACE_PREF_CHOICE";
    @RBEntry("After with space")
    public static final String AFTER_WITH_SPACE_PREF_CHOICE = "AFTER_WITH_SPACE_PREF_CHOICE";
    @RBEntry("0")
    public static final String ZERO_PREF_CHOICE = "ZERO_PREF_CHOICE";
    @RBEntry("1")
    public static final String ONE_PREF_CHOICE = "ONE_PREF_CHOICE";
    @RBEntry("2")
    public static final String TWO_PREF_CHOICE = "TWO_PREF_CHOICE";
    @RBEntry("Cost")
    public static final String TOTAL_COST = "TOTAL_COST";
    @RBEntry("Baseline Cost")
    public static final String BASELINE_TOTAL_COST = "BASELINE_TOTAL_COST";
    @RBEntry("Cost Variance")
    public static final String TOTAL_COST_VARIANCE = "TOTAL_COST_VARIANCE";
    @RBEntry("Fixed Cost")
    public static final String FIXED_COST = "FIXED_COST";
    @RBEntry("Baseline Fixed Cost")
    public static final String BASELINE_FIXED_COST = "BASELINE_FIXED_COST";
    @RBEntry("Total Cost")
    public static final String PLAN_TOTAL_COST = "PLAN_TOTAL_COST";
    @RBEntry("Owner")
    public static final String ACTIVITY_OWNER = "ACTIVITY_OWNER";
    @RBEntry("Owner")
    public static final String PLAN_OWNER = "PLAN_OWNER";
    @RBEntry("Baseline Owner")
    public static final String BASELINE_ACTIVITY_OWNER = "BASELINE_ACTIVITY_OWNER";
    @RBEntry("Project Members Only")
    public static final String PROJECT_PRIVATE = "PROJECT_PRIVATE";
    @RBEntry("Program Members Only")
    public static final String PROGRAM_PRIVATE = "PROGRAM_PRIVATE";
    @RBEntry("Invalid value. Enter a number from 0 to 100.")
    public static final String TRACK_ACTIVITY_WORK_JS_VALIDATION_PERCENT_ERROR = "TRACK_ACTIVITY_WORK_JS_VALIDATION_PERCENT_ERROR";
    @RBEntry("Once these changes are applied, one or more resources will have tracked more actual work completed than their scheduled work. \nThe Actual Work value must be less than or equal to Scheduled Work.\nTo continue and reduce Actual Work values to align with the new Scheduled Work values, click OK.")
    public static final String SCHEDULE_WORK_CHANGE_WARNING_ACTIVITY = "SCHEDULE_WORK_CHANGE_WARNING_ACTIVITY";
    @RBEntry("Assign Resources")
    public static final String ASSIGN_RESOURCE_TITLE = "ASSIGN_RESOURCE_TITLE";
    @RBEntry("Project Assignments")
    public static final String PROJECT_ASSIGNMENTS = "PROJECT_ASSIGNMENTS";
    @RBEntry("Reassigned")
    public static final String REASSIGNED_TITLE = "REASSIGNED_TITLE";
    @RBEntry("Accepted")
    public static final String ACCEPTED = "ACCEPTED";
    @RBEntry("Delegated")
    public static final String DELEGATED = "DELEGATED";
    @RBEntry("Name")
    public static final String NAME_TITLE = "NAME_TITLE";
    @RBEntry("Subject")
    public static final String SUBJECT_TITLE = "SUBJECT_TITLE";
    @RBEntry("State")
    public static final String SUBJECT_STATE_TITLE = "SUBJECT_STATE_TITLE";
    @RBEntry("Assigned")
    public static final String ASSIGNED_DATE_TITLE = "ASSIGNED_DATE_TITLE";
    @RBEntry("Owner")
    public static final String OWNER_TITLE = "OWNER_TITLE";
    @RBEntry("Role")
    public static final String ROLE_TITLE = "ROLE_TITLE";
    @RBEntry("Done")
    public static final String PERCENT_DONE_TITLE = "PERCENT_DONE_TITLE";
    @RBEntry("Created By")
    public static final String CREATED_BY_TITLE = "CREATED_BY_TITLE";
    @RBEntry("Deadline")
    public static final String DEADLINE_COLUMN_LBL = "DEADLINE_COLUMN_LBL";
    @RBEntry("Baseline Deadline")
    public static final String BASELINE_DEADLINE_COLUMN_LBL = "BASELINE_DEADLINE_COLUMN_LBL";
    @RBEntry("Context")
    public static final String CONTEXT_TITLE = "CONTEXT_TITLE";
    @RBEntry("Tasks")
    public static final String ASSIGNMENT_TABLE_TITLE = "ASSIGNMENT_TABLE_TITLE";
    @RBEntry("Status")
    public static final String HEALTH_STATUS_TITLE = "HEALTH_STATUS_TITLE";
    @RBEntry("Open")
    public static final String VIEW_OPEN_WORK = "VIEW_OPEN_WORK";
    @RBEntry("Deliverables")
    public static final String VIEW_MY_DELIVERABLES = "VIEW_MY_DELIVERABLES";
    @RBEntry("Plan Assignments")
    public static final String VIEW_MY_PLANASSIGNMENTS = "VIEW_MY_PLANASSIGNMENTS";
    @RBEntry("Milestones")
    public static final String VIEW_MY_MILESTONES = "VIEW_MY_MILESTONES";
    @RBEntry("Activities")
    public static final String VIEW_MY_ACTIVITIES = "VIEW_MY_ACTIVITIES";
    @RBEntry("Open")
    public static final String VIEW_OPEN = "VIEW_OPEN";
    @RBEntry("Open by Due Date")
    public static final String VIEW_OPEN_WORK_BY_DUE_DATE = "VIEW_OPEN_WORK_BY_DUE_DATE";
    @RBEntry("Workflow Tasks")
    public static final String VIEW_MY_TASKS = "VIEW_MY_TASKS";
    @RBEntry("Assigned to Me")
    public static final String VIEW_WORKITEMS_I_OWN = "VIEW_WORKITEMS_I_OWN";
    @RBEntry("Closed")
    public static final String VIEW_CLOSED_WORK = "VIEW_CLOSED_WORK";
    @RBEntry("All")
    public static final String VIEW_ALL_WORKITEMS = "VIEW_ALL_WORKITEMS";
    @RBEntry("All Action Items")
    public static final String VIEW_ACTION_ITEMS = "VIEW_ACTION_ITEMS";
    @RBEntry("Action Items Owned by Me")
    public static final String VIEW_MY_ACTION_ITEMS = "VIEW_MY_ACTION_ITEMS";
    @RBEntry("Open Action Items Owned by Me")
    public static final String VIEW_MY_OPEN_ACTION_ITEMS = "VIEW_MY_OPEN_ACTION_ITEMS";
    @RBEntry("Action Items Created by Me")
    public static final String VIEW_CREATED_ACTION_ITEMS = "VIEW_CREATED_ACTION_ITEMS";
    @RBEntry("Open Action Items Created by Me")
    public static final String VIEW_CREATED_OPEN_ACTION_ITEMS = "VIEW_CREATED_OPEN_ACTION_ITEMS";
    @RBEntry("All Open Action Items")
    public static final String VIEW_OPEN_ACTION_ITEMS = "VIEW_OPEN_ACTION_ITEMS";
    @RBEntry("All Plan Deliverables")
    public static final String VIEW_PLANDELIVERABLES = "VIEW_PLANDELIVERABLES";
    @RBEntry("Variance Report")
    public static final String VIEW_PLANDELIVERABLES_VARIANCE = "VIEW_PLANDELIVERABLES_VARIANCE";
    @RBEntry("All Plan Activities")
    public static final String VIEW_PLANACTIVITIES = "VIEW_PLANACTIVITIES";
    @RBEntry("All Plan Assignments")
    public static final String VIEW_PLANASSIGNMENTS = "VIEW_PLANASSIGNMENTS";
    @RBEntry("Discussed")
    public static final String DISCUSSED = "DISCUSSED";
    @RBEntry("Is Overdue")
    public static final String ISOVERDUE = "ISOVERDUE";
    @RBEntry("Is Assigned to Me")
    public static final String ISASSIGNEDTOME = "ISASSIGNEDTOME";
    @RBEntry("Open Assignments")
    public static final String OPENASSIGNMENTS = "OPENASSIGNMENTS";
    @RBEntry("Is Created by Me")
    public static final String ISCREATEDBYME = "ISCREATEDBYME";
    @RBEntry("Task Type")
    public static final String TASKTYPE = "TASKTYPE";
    @RBEntry("Reassigned")
    public static final String REASSIGNED = "REASSIGNED";
    @RBEntry("(multiple)")
    public static final String MULTIPLE = "MULTIPLE";
    @RBEntry("Baseline Status")
    public static final String BASELINE_HEALTH_STATUS_LABEL = "BASELINE_HEALTH_STATUS_LABEL";
    @RBEntry("Status")
    public static final String HEALTH_STATUS_LABEL = "HEALTH_STATUS_LABEL";
    @RBEntry("Status (Activity)")
    public static final String HEALTH_STATUS_ACTIVITY_LABEL = "HEALTH_STATUS_ACTIVITY_LABEL";
    @RBEntry("Assignee Status")
    public static final String ASSIGNEE_HEALTH_STATUS_LABEL = "ASSIGNEE_HEALTH_STATUS_LABEL";
    @RBEntry("Status Description")
    public static final String HEALTH_STATUS_DESCRIPTION_LABEL = "HEALTH_STATUS_DESCRIPTION_LABEL";
    @RBEntry("Status Description (Activity)")
    public static final String HEALTH_STATUS_DESCRIPTION_ACTIVITY_LABEL = "HEALTH_STATUS_DESCRIPTION_ACTIVITY_LABEL";
    @RBEntry("Baseline Status Description")
    public static final String BASELINE_HEALTH_STATUS_DESCRIPTION_LABEL = "BASELINE_HEALTH_STATUS_DESCRIPTION_LABEL";
    @RBEntry("Risk")
    public static final String RISK_TYPE = "RISK_TYPE";
    @RBEntry("Risk Type")
    public static final String RISK_TYPE_LABEL = "RISK_TYPE_LABEL";
    @RBEntry("Baseline Risk")
    public static final String BASELINE_RISK_TYPE = "BASELINE_RISK_TYPE";
    @RBEntry("Risk Description")
    public static final String RISK_DESCRIPTION = "RISK_DESCRIPTION";
    @RBEntry("Baseline Risk Description")
    public static final String BASELINE_RISK_DESCRIPTION = "BASELINE_RISK_DESCRIPTION";
    @RBEntry("Critical Status")
    public static final String CRITICAL_STATUS = "CRITICAL_STATUS";
    @RBEntry("Critical")
    public static final String CRITICAL = "CRITICAL";
    @RBEntry("Baseline Critical")
    public static final String BASELINE_CRITICAL = "BASELINE_CRITICAL";
    @RBEntry("Project Planning")
    public static final String PROJECT_PLANNING = "PROJECT_PLANNING";
    @RBEntry("Date Display Format")
    public static final String DATE_DISPLAY_FORMAT = "DATE_DISPLAY_FORMAT";
    @RBEntry("Specifies the format for displaying dates in project plans.")
    public static final String DATE_DISPLAY_FORMAT_DESC = "DATE_DISPLAY_FORMAT_DESC";
    @RBEntry("Specifies the format for displaying dates in project plans.")
    public static final String DATE_DISPLAY_FORMAT_LONG_DESC = "DATE_DISPLAY_FORMAT_LONG_DESC";
    @RBEntry("Assignment")
    public static final String ASSIGNMENT = "ASSIGNMENT";
    @RBEntry("Open the Track Work window")
    public static final String ASSIGNMENT_TOOLTIP = "ASSIGNMENT_TOOLTIP";
    @RBEntry("Edit Timeline")
    public static final String EDIT_TIMELINE_WIZARD_TITLE = "EDIT_TIMELINE_WIZARD_TITLE";
    @RBEntry("Timeline")
    public static final String TIMELINE_TITLE = "TIMELINE_TITLE";
    @RBEntry("Find Activities")
    public static final String ACTIVITY_PICKER_LABEL = "ACTIVITY_PICKER_LABEL";
    @RBEntry("Edit Selected Activities")
    public static final String EDIT_MULTI_ACTIVITY_WIZ_TITLE = "EDIT_MULTI_ACTIVITY_WIZ_TITLE";
    @RBEntry("Create Multiple Activities")
    public static final String CREATE_MULTIPLE_ACTIVITY_TITLE = "CREATE_MULTIPLE_ACTIVITY_TITLE";
    @RBEntry("Name")
    public static final String MULTIPLE_ACTIVITIES_COLUMN_NAME = "MULTIPLE_ACTIVITIES_COLUMN_NAME";
    @RBEntry("Completed")
    public static final String COMPLETED = "COMPLETED";
    @RBEntry("Find Owner")
    public static final String OWNER_PICKER_TITLE = "OWNER_PICKER_TITLE";
    @RBEntry("Find User")
    public static final String USER_PICKER_TITLE = "USER_PICKER_TITLE";
    @RBEntry("Find Group")
    public static final String GROUP_PICKER_TITLE = "GROUP_PICKER_TITLE";
    @RBEntry("Find Team Role")
    public static final String ROLE_PICKER_TITLE = "ROLE_PICKER_TITLE";
    @RBEntry("You do not have access to this object or it does not exist.")
    public static final String OBJECT_GONE = "OBJECT_GONE";
    @RBEntry("Clear")
    public static final String PICKER_CLEAR_BUTTON_LABLE = "PICKER_CLEAR_BUTTON_LABLE";
    @RBEntry("Fixed Cost should be numeric.")
    public static final String FIXED_COST_ERROR = "FIXED_COST_ERROR";
    @RBEntry("Fixed Cost should not be blank.")
    public static final String FIXED_COST_BLANK_ERROR = "FIXED_COST_BLANK_ERROR";
    @RBEntry("Duration")
    public static final String MULTIPLE_ESTIMATE_DURATION = "MULTIPLE_ESTIMATE_DURATION";
    @RBEntry("<p>OK")
    public static final String IMPORT_SUCCESS = "IMPORT_SUCCESS";
    @RBEntry("Uploaded file is missing.")
    public static final String IMPORT_FILE_NOT_FOUND = "IMPORT_FILE_NOT_FOUND";
    @RBEntry("No Request.")
    public static final String IMPORT_NO_REQUEST = "IMPORT_NO_REQUEST";
    @RBEntry("No Import Mode available.")
    public static final String IMPORT_NO_IMPORTMODE = "IMPORT_NO_IMPORTMODE";
    @RBEntry("Invalid lead time. The lead time entered would force the Project Start Date to an earlier date.")
    public static final String INVALID_LEAD_ERROR = "INVALID_LEAD_ERROR";
    @RBEntry("Activity {1} for {0} has been started.")
    public static final String ACTIVITY_NOTIFICATION_STATE_STARTED = "ACTIVITY_NOTIFICATION_STATE_STARTED";
    @RBEntry("Activity {1} for {0} has been suspended.")
    public static final String ACTIVITY_NOTIFICATION_STATE_SUSPENDED = "ACTIVITY_NOTIFICATION_STATE_SUSPENDED";
    @RBEntry("Project Name")
    public static final String PROJECT_NAME = "PROJECT_NAME";
    @RBEntry("Track Work")
    public static final String TRACK_WORK = "TRACK_WORK";
    @RBEntry("Complete")
    public static final String COMPLETE = "COMPLETE";
    @RBEntry("Edit")
    public static final String EDIT = "EDIT";
    @RBEntry("Accept")
    public static final String ACCEPT = "ACCEPT";
    @RBEntry("State")
    public static final String PLANNABLE_STATE = "PLANNABLE_STATE";
    @RBEntry("State (Activity)")
    public static final String PLANNABLE_STATE_ACTIVITY = "PLANNABLE_STATE_ACTIVITY";
    @RBEntry("Baseline State")
    public static final String BASELINE_PLANNABLE_STATE = "BASELINE_PLANNABLE_STATE";
    @RBEntry("Description")
    public static final String PLANNABLE_DESCRIPTION = "PLANNABLE_DESCRIPTION";
    @RBEntry("Baseline Description")
    public static final String BASELINE_PLANNABLE_DESCRIPTION = "BASELINE_PLANNABLE_DESCRIPTION";
    @RBEntry("Cancelled")
    public static final String CANCELLED = "CANCELLED";
    @RBEntry("Invalid percent complete value. Enter a number between 0 and 100.")
    public static final String DEL_PERCOMPLETE_VALIDATION_ERROR = "DEL_PERCOMPLETE_VALIDATION_ERROR";
    @RBEntry("Activity Notification")
    public static final String ACTIVITY_NOTIFICATION = "ACTIVITY_NOTIFICATION";
    @RBEntry("Find Deliverables")
    public static final String DELIVERABLE_PICKER_LABEL = "DELIVERABLE_PICKER_LABEL";
    @RBEntry("Milestone \"{0}\" cannot be a summary activity because \"Link deliverables with project activities\" is enabled.")
    public static final String MILESTONE_TO_SUMMARY_ACTIVITY_NOT_ALLOWED = "MILESTONE_TO_SUMMARY_ACTIVITY_NOT_ALLOWED";
    @RBEntry("Deliverable")
    public static final String DELIVERABLE_TABLE_LABEL = "DELIVERABLE_TABLE_LABEL";
    @RBEntry("Default Deliverable View")
    public static final String DELIVERABLE_TABLE_VIEW_NAME = "DELIVERABLE_TABLE_VIEW_NAME";
    @RBEntry("Default Deliverable Search Table View")
    public static final String DELIVERABLE_TABLE_VIEW_DESC = "DELIVERABLE_TABLE_VIEW_DESC";
    @RBEntry("Project Plan")
    public static final String PROJECT_PLAN_TABLE_LABEL = "PROJECT_PLAN_TABLE_LABEL";
    @RBEntry("Default Project Plan View")
    public static final String PROJECT_PLAN_TABLE_VIEW_NAME = "PROJECT_PLAN_TABLE_VIEW_NAME";
    @RBEntry("Default Project Plan Search Table View")
    public static final String PROJECT_PLAN_TABLE_VIEW_DESC = "PROJECT_PLAN_TABLE_VIEW_DESC";
    @RBEntry("Details")
    public static final String PLANINFODETAILSTAB = "object.planInfo_detailstab.description";
    @RBEntry("Plan Activity")
    public static final String PLAN_ACTIVITY_TABLE_LABEL = "PLAN_ACTIVITY_TABLE_LABEL";
    @RBEntry("Default Plan Activity View")
    public static final String PLAN_ACTIVITY_TABLE_VIEW_NAME = "PLAN_ACTIVITY_TABLE_VIEW_NAME";
    @RBEntry("Default Plan Activity Search Table View")
    public static final String PLAN_ACTIVITY_TABLE_VIEW_DESC = "PLAN_ACTIVITY_TABLE_VIEW_DESC";
    @RBEntry("Plan Resource")
    public static final String PLAN_RESOURCE_TABLE_LABEL = "PLAN_RESOURCE_TABLE_LABEL";
    @RBEntry("Default Plan Resource View")
    public static final String PLAN_RESOURCE_TABLE_VIEW_NAME = "PLAN_RESOURCE_TABLE_VIEW_NAME";
    @RBEntry("Default Plan Resource Search Table View")
    public static final String PLAN_RESOURCE_TABLE_VIEW_DESC = "PLAN_RESOURCE_TABLE_VIEW_DESC";
    @RBEntry("Resource Assignment")
    public static final String RESOURCE_ASSIGNMENT_TABLE_LABEL = "RESOURCE_ASSIGNMENT_TABLE_LABEL";
    @RBEntry("Default Resource Assignment View")
    public static final String RESOURCE_ASSIGNMENT_TABLE_VIEW_NAME = "RESOURCE_ASSIGNMENT_TABLE_VIEW_NAME";
    @RBEntry("Default Resource Assignment Search Table View")
    public static final String RESOURCE_ASSIGNMENT_TABLE_VIEW_DESC = "RESOURCE_ASSIGNMENT_TABLE_VIEW_DESC";
    @RBEntry("Hide Program")
    public static final String HIDE_PROGRAM_TAB = "HIDE_PROGRAM_TAB";
    @RBEntry("Determines if programs are hidden or shown in the Navigator.")
    public static final String HIDE_PROGRAM_TAB_DESC = "HIDE_PROGRAM_TAB_DESC";
    @RBEntry("This preference determines whether programs are hidden or shown in the Navigator. The default value for this preference is Yes, programs are hidden in the Navigator. To show programs in the Navigator, change the preference value to No.")
    public static final String HIDE_PROGRAM_TAB_LONG_DESC = "HIDE_PROGRAM_TAB_LONG_DESC";
    @RBEntry(" ")
    public static final String SPACE = "SPACE";
    @RBEntry("Details")
    public static final String ACTIVITYINFODETAILSTAB = "object.activityInfo_detailstab.description";
    @RBEntry("Related Objects")
    public static final String ACTIVITYINFORELATEDOBJECTS = "object.activityInfo_relatedObjectsTab.description";
    @RBEntry("Plan Activity Attribute Layouts")
    public static final String PLANACTIVITY_ATTRIBUTE_LAYOUT = "PLANACTIVITY_ATTRIBUTE_LAYOUT";
    @RBEntry("Baselined Plan Attribute Layouts")
    public static final String BASELINED_PLAN_ATTRIBUTE_LAYOUT = "BASELINED_PLAN_ATTRIBUTE_LAYOUT";
    @RBEntry("Baselined Plan Activity Attribute Layouts")
    public static final String BASELINED_PLANACTIVITY_ATTRIBUTE_LAYOUT = "BASELINED_PLANACTIVITY_ATTRIBUTE_LAYOUT";
    @RBEntry("Automatic")
    public static final String EXECCONTROLPLAN_AUTOMATIC = "EXECCONTROLPLAN_AUTOMATIC";
    @RBEntry("Manual")
    public static final String EXECCONTROLPLAN_MANUAL = "EXECCONTROLPLAN_MANUAL";
    @RBEntry("Plan Deliverable Attribute Layouts")
    public static final String PLANDELIVERABLE_ATTRIBUTE_LAYOUT = "PLANDELIVERABLE_ATTRIBUTE_LAYOUT";
    @RBEntry("Baselined Plan Deliverable Attribute Layouts")
    public static final String BASELINED_PLANDELIVERABLE_ATTRIBUTE_LAYOUT = "BASELINED_PLANDELIVERABLE_ATTRIBUTE_LAYOUT";
    @RBEntry("Are you sure you want to complete \"{0}\" ?")
    public static final String PLANACTIVITY_FINISH_CONFIRMATION = "PLANACTIVITY_FINISH_CONFIRMATION";
    @RBEntry("Are you sure you want to complete \"{0}\" ?")
    public static final String PLANASSIGNMENT_FINISH_CONFIRMATION = "PLANASSIGNMENT_FINISH_CONFIRMATION";
    @RBEntry(" '{0}' has predecessor relationships that affect its start date. If you manually start this activity, the predecessor relationships will be deleted. \nClick OK to continue.")
    public static final String ACTIVITY_START_PREDECESSOR_DELETE = "ACTIVITY_START_PREDECESSOR_DELETE";
    @RBEntry("Constraint Date")
    public static final String PLANNABLE_CONSTRAINT_DATE = "PLANNABLE_CONSTRAINT_DATE";
    @RBEntry("Baseline Constraint Date")
    public static final String BASELINE_PLANNABLE_CONSTRAINT_DATE = "BASELINE_PLANNABLE_CONSTRAINT_DATE";
    @RBEntry("Constraint Type")
    public static final String PLANNABLE_CONSTRAINT_TYPE = "PLANNABLE_CONSTRAINT_TYPE";
    @RBEntry("Baseline Constraint Type")
    public static final String BASELINE_PLANNABLE_CONSTRAINT_TYPE = "BASELINE_PLANNABLE_CONSTRAINT_TYPE";
    @RBEntry("Overdue deadline notification for {0} : {1}.")
    public static final String DEADLINE_PASSED = "DEADLINE_PASSED";
    @RBEntry("Deadline Notification")
    public static final String DEADLINE_NOTIFICATION = "DEADLINE_NOTIFICATION";
    @RBEntry("Cost Per Use")
    public static final String COST_PER_USE = "COST_PER_USE";
    @RBEntry("Resource")
    public static final String RESOURCE = "RESOURCE";
    @RBEntry("Deadline date for an activity cannot be earlier than its start date.")
    public static final String DEADLINE_BEFORE_START = "DEADLINE_BEFORE_START";
    @RBEntry("Deadline date for an activity at row {0} cannot be earlier than its start date.")
    public static final String MULTIDEADLINE_BEFORE_START = "MULTIDEADLINE_BEFORE_START";
    @RBEntry("After Deadline Notification")
    public static final String DEADLINE_AFTER_NOTIFICATION = "DEADLINE_AFTER_NOTIFICATION";
    @RBEntry("Before Deadline Notification")
    public static final String DEADLINE_BEFORE_NOTIFICATION = "DEADLINE_BEFORE_NOTIFICATION";
    @RBEntry("Approaching deadline notification for {0} : {1}.")
    public static final String DEADLINE_APPROACHING = "DEADLINE_APPROACHING";
    @RBEntry("{0} - {1} passed deadline.")
    public static final String DEADLINE_AFTER = "DEADLINE_AFTER";
    @RBEntry("Identify Events")
    public static final String IDENTIFY_EVENTS = "IDENTIFY_EVENTS";
    @RBEntry("Project Description")
    public static final String PROJECT_DESCRIPTION = "PROJECT_DESCRIPTION";
    @RBEntry("Project Owner")
    public static final String PROJECT_OWNER = "PROJECT_OWNER";
    @RBEntry("Organization")
    public static final String PROJECT_ORGANIZATION = "PROJECT_ORGANIZATION";
    @RBEntry("Day(s) After Deadline.")
    public static final String DEADLINE_AFTER_LABEL = "DEADLINE_AFTER_LABEL";
    @RBEntry("Day(s) Before Deadline.")
    public static final String DEADLINE_BEFORE_LABEL = "DEADLINE_BEFORE_LABEL";
    @RBEntry("Notify Deadline")
    public static final String CREATE_DEADLINE_NOTIFICATION_WIZARD_TITLE = "CREATE_DEADLINE_NOTIFICATION_WIZARD_TITLE";
    @RBEntry("Invalid number of days. \nEnter a value between 0 and 100.")
    public static final String INVALID_DEADLINE_DAYS = "INVALID_DEADLINE_DAYS";
    @RBEntry("My Tasks")
    public static final String HOME_ASSIGNMENT_TABLE_TITLE = "HOME_ASSIGNMENT_TABLE_TITLE";
    @RBEntry("Last Action")
    public static final String LASTACTION_TITLE = "LASTACTION_TITLE";
    @RBEntry("In Microsoft Project, the Estimated Start/Finish Dates will be updated with Actual Start/Finish Dates")
    public static final String WARNING_EXPORT_ESTDATESCHANGETOACTUALDATES = "WARNING_EXPORT_ESTDATESCHANGETOACTUALDATES";
    @RBEntry("Program Completion and Health Status")
    public static final String ROLLUPBYPROJECTS = "ROLLUPBYPROJECT";
    @RBEntry("Determines how program status is measured.")
    public static final String ROLLUPBYPROJECTS_DESC = "ROLLUPBYPROJECTS_DESC";
    @RBEntry("This preference determines how the program status is calculated. If set to Yes, the program's completion and health status is calculated from its plan. If set to No, the status is rolled up from the status of the projects in the program's network. <br> The default value is Yes.")
    public static final String ROLLUPBYPROJECTS_LONG_DESC = "ROLLUPBYPROJECTS_LONG_DESC";
    @RBEntry("Project")
    public static final String RELATED_PROJECT = "RELATED_PROJECT";
    @RBEntry("Resource Units")
    public static final String PLANRESOURCEALLOCATION = "PLANRESOURCEALLOCATION";
    @RBEntry("Activity '{0}' has a related requirement; cannot be outdented. ")
    public static final String REQUIREMENT_RELATED_ACTIVITY_OUTDENT_ERROR = "REQUIREMENT_RELATED_ACTIVITY_OUTDENT_ERROR";
    @RBEntry("Activity '{0}' has a related requirement; cannot be indented.")
    public static final String REQUIREMENT_RELATED_ACTIVITY_INDENT_ERROR = "REQUIREMENT_RELATED_ACTIVITY_INDENT_ERROR";
    @RBEntry("Edit Plan Objects")
    public static final String EDIT_PLAN_OBJECTS = "EDIT_PLAN_OBJECTS";
    @RBEntry("Discussion")
    public static final String PLANNABLE_DISCUSSED = "PLANNABLE_DISCUSSED";
    @RBEntry("Requirement")
    public static final String RELATED_REQUIREMENT = "RELATED_REQUIREMENT";
    @RBEntry("View requirement information")
    public static final String ACT_REQUIREMENT_TOOLTIP = "ACT_REQUIREMENT_TOOLTIP";
    @RBEntry("Associate Activities")
    public static final String ASSOCIATE_ACTIVITIES = "ASSOCIATE_ACTIVITIES";
    @RBEntry("Cannot select activities before selecting project and milestone.")
    public static final String ASSOCIATE_ACTIVITIES_MISSING_INPUT_ERROR = "ASSOCIATE_ACTIVITIES_MISSING_INPUT_ERROR";
    @RBEntry("Cannot save without selecting activities for association.")
    public static final String ASSOCIATE_ACTIVITIES_MISSING_ACTIVITIES_ERROR = "ASSOCIATE_ACTIVITIES_MISSING_ACTIVITIES_ERROR";
    @RBEntry("Enable Create Plan for Product")
    public static final String SHOW_CREATE_PRODUCT_PLAN_ACTION = "SHOW_CREATE_PRODUCT_PLAN_ACTION";
    @RBEntry("Determines if the Create Plan action is enabled for products.")
    public static final String SHOW_CREATE_PRODUCT_PLAN_ACTION_DESC = "SHOW_CREATE_PRODUCT_PLAN_ACTION_DESC";
    @RBEntry("This preference determines whether the <b>Create Plan</b> action is available from the <b>Actions</b> menu on a product <b>Details</b> page. Select Yes to enable; select No to hide. <br>The default value for this preference is Yes.")
    public static final String SHOW_CREATE_PRODUCT_PLAN_ACTION_LONG_DESC = "SHOW_CREATE_PRODUCT_PLAN_ACTION_LONG_DESC";
    @RBEntry("Plan Attribute Layouts")
    public static final String PLAN_ATTRIBUTE_LAYOUT = "PLAN_ATTRIBUTE_LAYOUT";
    @RBEntry("You are a member of the {0} group. This group has been assigned to the following activity using a shared assignment: {1}. ")
    public static final String ACTIVITY_NOTIFICATION_HEADER_SHARED_ASSIGNMENT_WITH_GROUP = "ACTIVITY_NOTIFICATION_HEADER_SHARED_ASSIGNMENT_WITH_GROUP";
    @RBEntry("You are a member of the {0} role. This role has been assigned to the following activity using a shared assignment: {1}. ")
    public static final String ACTIVITY_NOTIFICATION_HEADER_SHARED_ASSIGNMENT_WITH_ROLE = "ACTIVITY_NOTIFICATION_HEADER_SHARED_ASSIGNMENT_WITH_ROLE";
    @RBEntry("You are a member of the {0} group. This group has been assigned to the following activity using a bulk assignment: {1}. ")
    public static final String ACTIVITY_NOTIFICATION_HEADER_BULK_ASSIGNMENT_WITH_GROUP = "ACTIVITY_NOTIFICATION_HEADER_BULK_ASSIGNMENT_WITH_GROUP";
    @RBEntry("You are a member of the {0} role. This role has been assigned to the following activity using a bulk assignment: {1}. ")
    public static final String ACTIVITY_NOTIFICATION_HEADER_BULK_ASSIGNMENT_WITH_ROLE = "ACTIVITY_NOTIFICATION_HEADER_BULK_ASSIGNMENT_WITH_ROLE";
    @RBEntry("You are a member of the {0} group. This group has been assigned to the following activity using a pool assignment: {1}. ")
    public static final String ACTIVITY_NOTIFICATION_HEADER_POOL_ASSIGNMENT_WITH_GROUP = "ACTIVITY_NOTIFICATION_HEADER_POOL_ASSIGNMENT_WITH_GROUP";
    @RBEntry("You are a member of the {0} role. This role has been assigned to the following activity using a pool assignment: {1}. ")
    public static final String ACTIVITY_NOTIFICATION_HEADER_POOL_ASSIGNMENT_WITH_ROLE = "ACTIVITY_NOTIFICATION_HEADER_POOL_ASSIGNMENT_WITH_ROLE";
    @RBEntry("Use the {0} action to accept this assignment.")
    public static final String ACTIVITY_NOTIFICATION_OPTION_ACCEPT = "ACTIVITY_NOTIFICATION_OPTION_ACCEPT";
    @RBEntry("New Plan Baseline")
    public static final String CREATE_BASELINE_WIZARD_TITLE = "CREATE_BASELINE_WIZARD_TITLE";
    @RBEntry("Baseline Name")
    public static final String PLAN_BASELINE_NAME = "PLAN_BASELINE_NAME";
    @RBEntry("Baseline Description")
    public static final String PLAN_BASELINE_DESCRIPTION = "PLAN_BASELINE_DESCRIPTION";
    @RBEntry("Plan Baselines")
    public static final String PLAN_BASELINES_TITLE = "PLAN_BASELINES_TITLE";
    @RBEntry("Activity Baselines")
    public static final String ACTIVITY_BASELINES_TITLE = "ACTIVITY_BASELINES_TITLE";
    @RBEntry("Resource Baselines")
    public static final String RESOURCE_BASELINES_TITLE = "RESOURCE_BASELINES_TITLE";
    @RBEntry("Assignment Baselines")
    public static final String ASSIGNMENT_BASELINES_TITLE = "ASSIGNMENT_BASELINES_TITLE";
    @RBEntry("Deliverable Baselines")
    public static final String DELIVERABLE_BASELINES_TITLE = "DELIVERABLE_BASELINES_TITLE";
    @RBEntry("Active")
    public static final String PLAN_BASELINE_ACTIVE = "PLAN_BASELINE_ACTIVE";
    @RBEntry("Baseline Created On")
    public static final String PLAN_BASELINE_CREATED_ON = "PLAN_BASELINE_CREATED_ON";
    @RBEntry("Baseline Created By")
    public static final String PLAN_BASELINE_CREATED_BY = "PLAN_BASELINE_CREATED_BY";
    @RBEntry("Start")
    public static final String PLAN_BASELINE_START_DATE = "PLAN_BASELINE_START_DATE";
    @RBEntry("Finish")
    public static final String PLAN_BASELINE_FINISH_DATE = "PLAN_BASELINE_FINISH_DATE";
    @RBEntry("Work")
    public static final String PLAN_BASELINE_EFFORT = "PLAN_BASELINE_EFFORT";
    @RBEntry("Duration")
    public static final String PLAN_BASELINE_DURATION = "PLAN_BASELINE_DURATION";
    @RBEntry("Compare")
    public static final String EPP_COMPARE_DESCRIPTION = "object.plan_menubar_actions_compare.description";
    @RBEntry("Compare")
    public static final String EPP_COMPARE_TOOLTIP = "object.plan_menubar_actions_compare.tooltip";
    @RBEntry("Active Baseline")
    public static final String ACTIVE_BASELINE_TOOLTIP = "ACTIVE_BASELINE_TOOLTIP";
    @RBEntry("Compare")
    public static final String VIEW_COMPARE = "VIEW_COMPARE";
    @RBEntry("Compare View")
    public static final String VIEW_COMPARE_DESC = "VIEW_COMPARE_DESC";
    @RBEntry("Plan Baselines")
    public static final String PLAN_BASELINES = "PLAN_BASELINES";
    @RBEntry("Activity Baselines")
    public static final String ACTIVITY_BASELINES = "ACTIVITY_BASELINES";
    @RBEntry("Deliverable Baselines")
    public static final String DELIVERABLE_BASELINES = "DELIVERABLE_BASELINES";
    @RBEntry("Assignment Baselines")
    public static final String ASSIGNMENT_BASELINES = "ASSIGNMENT_BASELINES";
    @RBEntry("Resource Baselines")
    public static final String RESOURCE_BASELINES = "RESOURCE_BASELINES";
    @RBEntry("Actual Work Variance")
    public static final String ACTUALWORK_VARIANCE = "ACTUALWORK_VARIANCE";
    @RBEntry("Variance Report")
    public static final String VIEW_VARIANCE_REPORT = "VIEW_VARIANCE_REPORT";
    @RBEntry("Variance Report View")
    public static final String VIEW_VARIANCE_REPORT_DESC = "VIEW_VARIANCE_REPORT_DESC";
    @RBEntry("You have selected multiple baseline plans for this operation, select one baseline plan.")
    public static final String MULTIPLE_BASELINE_PLAN_SELECTED_ERROR = "MULTIPLE_BASELINE_PLAN_SELECTED_ERROR";
    @RBEntry("Percent Complete")
    public static final String PERCENT_COMPLETE_TITLE = "PERCENT_COMPLETE_TITLE";
    @RBEntry("Baseline Percent Complete")
    public static final String BASELINE_PERCENT_COMPLETE_TITLE = "BASELINE_PERCENT_COMPLETE_TITLE";
    @RBEntry("Invalid action. The selected plan object cannot be deleted.")
    public static final String CURRENT_PLAN_SELECTED_ERROR = "CURRENT_PLAN_SELECTED_ERROR";
    @RBEntry("Accepted Resource Assignment")
    public static final String ACCEPTED_ASSIGNMENT_TOOLTIP = "ACCEPTED_ASSIGNMENT_TOOLTIP";
    @RBEntry("Resources")
    public static final String SHARED_ASSIGNMENT_RESOURCES_TITLE = "SHARED_ASSIGNMENT_RESOURCES_TITLE";
    @RBEntry("The actual work for this activity cannot be modified because no pool assignments have been accepted.")
    public static final String ACTIVITY_TRACK_WORK_ERROR_MESSAGE = "ACTIVITY_TRACK_WORK_ERROR_MESSAGE";
    @RBEntry("Group")
    public static final String ASSIGNMENT_GROUP = "ASSIGNMENT_GROUP";
    @RBEntry("Assignment Type")
    public static final String ASSIGNMENT_TYPE = "ASSIGNMENT_TYPE";
    @RBEntry("'{0}' cannot be completed because it has at least one unaccepted pool assignment.")
    public static final String ACTIVITY_COMPLETE_ERROR_MESSAGE = "ACTIVITY_COMPLETE_ERROR_MESSAGE";
    @RBEntry("'{0}' cannot be completed because it is an activity with tracking policy as 'Latest Revision' and is associated with a subject of deliverable which is PDM Checked out. Please PDM check in the subject and try to complete the activity.")
    public static final String ACTIVITY_COMPLETE_ERROR_MESSAGE_WHEN_SUBJECT_ISPDMCHECKEDOUT = "ACTIVITY_COMPLETE_ERROR_MESSAGE_WHEN_SUBJECT_ISPDMCHECKEDOUT";
    @RBEntry("Current Plan")
    public static final String BASELINE_NAME_OF_CURRENT_PLAN = "BASELINE_NAME_OF_CURRENT_PLAN";
    @RBEntry("No baseline is selected. Select a baseline first.")
    public static final String SELECT_BASELINED_PLAN_ERROR = "SELECT_BASELINED_PLAN_ERROR";
    @RBEntry("The selected baseline is already the active baseline.")
    public static final String SET_AS_ACTIVE_BASELINE_ERROR = "SET_AS_ACTIVE_BASELINE_ERROR";
    @RBEntry("You do not have necessary authorization to delete some of the selected objects.")
    public static final String RESOURCEASSIGNMENT_UNAUTHORIZED_ACCESS = "RESOURCEASSIGNMENT_UNAUTHORIZED_ACCESS";
    @RBEntry("'{0}' is not in the Running state and therefore cannot be updated.")
    public static final String MILESTONE_IS_NOT_RUNNING = "MILESTONE_IS_NOT_RUNNING";
    @RBEntry("General")
    public static final String ACTIVITY_WIZARD_GENERAL = "ACTIVITY_WIZARD_GENERAL";
    @RBEntry("Advanced")
    public static final String ACTIVITY_WIZARD_ADVANCED = "ACTIVITY_WIZARD_ADVANCED";
    @RBEntry("Keep Actual Work")
    public static final String KEEP_ACTUALWORK_PREF_NAME = "KEEP_ACTUALWORK_PREF_NAME";
    @RBEntry("Controls whether actual work is preserved upon completion.")
    public static final String KEEP_ACTUALWORK_PREF_DESC = "KEEP_ACTUALWORK_PREF_DESC";
    @RBEntry("This preference controls whether the <b>Actual Work</b> value or the <b>Estimated Work</b> value is preserved when a user manually completes an assignment or activity. <br> Set this preference to Yes to preserve the <b>Actual Work</b> value. Upon completion, the <b>Estimated Work</b> value is set equal to the actual work. <br> Set this preference to No to preserve the <b>Estimated Work</b> value. Upon completion, the <b>Actual Work</b> value is set equal to the estimated work.<br> The default value is No.")
    public static final String KEEP_ACTUALWORK_PREF_LONG_DESC = "KEEP_ACTUALWORK_PREF_LONG_DESC";
    @RBEntry("Invalid action. You cannot delete activities, resources, or resource assignments from the Tasks table.")
    public static final String PLANTASKTABLE_UNSUPPORTED_OJBECTS_DELETION_ERROR = "PLANTASKTABLE_UNSUPPORTED_OJBECTS_DELETION_ERROR";
    @RBEntry("Duration Change for Fixed Duration Task Type")
    public static final String DURATION_CHANGE_FOR_FIXED_DURATION = "DURATION_CHANGE_FOR_FIXED_DURATION";
    @RBEntry("Determines which scheduling variable remains constant when a Fixed Duration activity is modified.")
    public static final String DURATION_CHANGE_FOR_FIXED_DURATION_DESC = "DURATION_CHANGE_FOR_FIXED_DURATION_DESC";
    @RBEntry("If you modify the duration of an activity that has the Fixed Duration task type, then either the work or the resource units must serve as a constant when recalculating the schedule. This preference controls which variable remains fixed. <br>Select <b>Update Units</b> to preserve the work values. Select <b>Update Work</b> to preserve the resource unit values. <br>The default value is Update Work.")
    public static final String DURATION_CHANGE_FOR_FIXED_DURATION_LONG_DESC = "DURATION_CHANGE_FOR_FIXED_DURATION_LONG_DESC";
    @RBEntry("Update Work")
    public static final String UPDATE_WORK_PREF_CHOICE = "UPDATE_WORK_PREF_CHOICE";
    @RBEntry("Update Units")
    public static final String UPDATE_UNITS_PREF_CHOICE = "UPDATE_UNITS_PREF_CHOICE";
    @RBEntry("This assignment has zero actual work. Are you sure you want to continue?")
    public static final String WARNING_ASSIGNMENT_HAS_ZEROACTUALWORK = "WARNING_ASSIGNMENT_HAS_ZEROACTUALWORK";
    @RBEntry("Default Resource Assignments")
    public static final String CREATE_DEFAULT_RESOURCE_ASSIGNMENT = "CREATE_DEFAULT_RESOURCE_ASSIGNMENT";
    @RBEntry("Controls whether an activity can be created without assigned resources.")
    public static final String CREATE_DEFAULT_RESOURCE_ASSIGNMENT_DESC = "CREATE_DEFAULT_RESOURCE_ASSIGNMENT_DESC";
    @RBEntry("Controls whether new activities include a resource assignment by default:<ul><li>Yes--If no resources are explicitly assigned to an activity, then the activity owner receives the resource assignment by default. If no owner has been explicitly assigned to the activity, then the activity creator is automatically added as the resource.</li><li>No--Activities can be created without an assigned resource.</li></ul> The default value is No.")
    public static final String CREATE_DEFAULT_RESOURCE_ASSIGNMENT_LONG_DESC = "CREATE_DEFAULT_RESOURCE_ASSIGNMENT_LONG_DESC";
    @RBEntry("This assignment has zero actual work. Are you sure you want to continue?")
    public static final String WARNING_ACTIVITY_HAS_ZEROACTUALWORK = "WARNING_ACTIVITY_HAS_ZEROACTUALWORK";
    @RBEntry("State Change Notifications")
    public static final String SEND_OWNER_STATE_CHANGE_NOTIFICATIONS = "SEND_OWNER_STATE_CHANGE_NOTIFICATIONS";
    @RBEntry("Controls whether state change notifications are sent to activity owners.")
    public static final String SEND_OWNER_STATE_CHANGE_NOTIFICATIONS_DESC = "SEND_OWNER_STATE_CHANGE_NOTIFICATIONS_DESC";
    @RBEntry("Controls whether a notification is sent to activity owners when the execution state of an activity changes. Select Yes to send a notification. Select No to disable notifications.<br>The default value is Yes. ")
    public static final String SEND_OWNER_STATE_CHANGE_NOTIFICATIONS_LONG_DESC = "SEND_OWNER_STATE_CHANGE_NOTIFICATIONS_LONG_DESC";
    @RBEntry("You have been assigned as a resource to the following activity: {0}. ")
    public static final String ACTIVITY_NOTIFICATION_HEADER_RESOURCE = "ACTIVITY_NOTIFICATION_HEADER_RESOURCE";
    @RBEntry("You have been assigned as the owner of the following activity: {0}. ")
    public static final String ACTIVITY_NOTIFICATION_HEADER_OWNER = "ACTIVITY_NOTIFICATION_HEADER_OWNER";
    @RBEntry("This activity has been <b>started</b>")
    public static final String ACTIVITY_NOTIFICATION_HEADER_STATE_STARTED = "ACTIVITY_NOTIFICATION_HEADER_STATE_STARTED";
    @RBEntry("This activity has been <b>suspended</b>")
    public static final String ACTIVITY_NOTIFICATION_HEADER_STATE_SUSPENDED = "ACTIVITY_NOTIFICATION_HEADER_STATE_SUSPENDED";
    @RBEntry("Use {0} to update your status and progress.")
    public static final String ACTIVITY_NOTIFICATION_OPTION_TRACK_WORK = "ACTIVITY_NOTIFICATION_OPTION_TRACK_WORK";
    @RBEntry("Use {0} to complete this assignment.")
    public static final String ACTIVITY_NOTIFICATION_OPTION_COMPLETE = "ACTIVITY_NOTIFICATION_OPTION_COMPLETE";
    @RBEntry("Use {0} to modify this assignment.")
    public static final String ACTIVITY_NOTIFICATION_OPTION_EDIT = "ACTIVITY_NOTIFICATION_OPTION_EDIT";
    @RBEntry("Started")
    public static final String NOTIFICATION_ACTIVITY_STARTED = "NOTIFICATION_ACTIVITY_STARTED";
    @RBEntry("Suspended")
    public static final String NOTIFICATION_ACTIVITY_SUSPENDED = "NOTIFICATION_ACTIVITY_SUSPENDED";
    @RBEntry("Remaining Work")
    public static final String NOTIFICATION_ASSIGNMENT_REMAINING_WORK = "NOTIFICATION_ASSIGNMENT_REMAINING_WORK";
    @RBEntry("The following resource assignments exist for this activity:")
    public static final String NOTIFICATION_ACTIVITY_ASSIGNMENTS = "NOTIFICATION_ACTIVITY_ASSIGNMENTS";
    @RBEntry("Related Objects Deliverables Table Display")
    public static final String SHOW_EPP_CLASSIC_DELIVERABLE_TABLE = "SHOW_EPP_CLASSIC_DELIVERABLE_TABLE";
    @RBEntry("Controls which Deliverables tables appear under the Related Objects tab.")
    public static final String SHOW_EPP_CLASSIC_DELIVERABLE_TABLE_DESC = "SHOW_EPP_CLASSIC_DELIVERABLE_TABLE_DESC";
    @RBEntry("Controls whether the Classic deliverables table, the Enhanced Project Planning (EPP) deliverables table or both tables are displayed when an object's related deliverables are displayed on its information page. When this is set to 'Classic Only', only the Classic deliverables are displayed. When this is set to 'EPP Only, only the EPP deliverables are displayed. When this is set to 'Both', both Classic and EPP deliverables are displayed in two separate tables.")
    public static final String SHOW_EPP_CLASSIC_DELIVERABLE_TABLE_LONG_DESC = "SHOW_EPP_CLASSIC_DELIVERABLE_TABLE_LONG_DESC";
    @RBEntry("EPP Only")
    public static final String SHOW_EPP_DELIVERABLE_TABLE_ONLY_PREF_CHOICE = "SHOW_EPP_DELIVERABLE_TABLE_ONLY_PREF_CHOICE";
    @RBEntry("Classic Only")
    public static final String SHOW_CLASSIC_DELIVERABLE_TABLE_ONLY_PREF_CHOICE = "SHOW_CLASSIC_DELIVERABLE_TABLE_ONLY_PREF_CHOICE";
    @RBEntry("Both")
    public static final String SHOW_CLASSIC_AND_EPP_DELIVERABLE_TABLES_PREF_CHOICE = "SHOW_CLASSIC_AND_EPP_DELIVERABLE_TABLES_PREF_CHOICE";
    @RBEntry("This activity does not have any resource assignments.")
    public static final String RESOURCEASSIGNMENTS_NOT_AVAILABLE = "RESOURCEASSIGNMENTS_NOT_AVAILABLE";
    @RBEntry("You are the owner of the following summary activity: {0}. ")
    public static final String SUMMARY_ACTIVITY_NOTIFICATION_HEADER_OWNER = "SUMMARY_ACTIVITY_NOTIFICATION_HEADER_OWNER";
    @RBEntry("The following child activities exist for this activity:")
    public static final String SUMMARY_ACTIVITY_CHILDREN_AVAILABLE = "SUMMARY_ACTIVITY_CHILDREN_AVAILABLE";
    @RBEntry("Use {0} to update this activity.")
    public static final String EDIT_ACTIVITY_NOTIFICATION_OPTION = "EDIT_ACTIVITY_NOTIFICATION_OPTION";
    @RBEntry("Use {0} to update status and progress for this activity.")
    public static final String TRACK_WORK_ACTIVITY_NOTIFICATION_OPTION = "TRACK_WORK_ACTIVITY_NOTIFICATION_OPTION";
    @RBEntry("Use {0} to complete this activity.")
    public static final String COMPLETE_ACTIVITY_NOTIFICATION_OPTION = "COMPLETE_ACTIVITY_NOTIFICATION_OPTION";
    @RBEntry("Clear status description history")
    public static final String LABEL_CLEAR_HEALTH_STATUS_DESCRIPTION = "LABEL_CLEAR_HEALTH_STATUS_DESCRIPTION";
    @RBEntry("Resource Units should not be blank.")
    public static final String RESOURCE_UNITS_BLANK = "RESOURCE_UNITS_BLANK";
    @RBEntry("Default Activity Constraint Type")
    public static final String PREF_DEFAULT_CONSTRAINT_TYPE = "PREF_DEFAULT_CONSTRAINT_TYPE";
    @RBEntry("Specifies the constraint type that is used by default when creating a new activity.")
    public static final String PREF_DEFAULT_CONSTRAINT_TYPE_DESC = "PREF_DEFAULT_CONSTRAINT_TYPE_DESC";
    @RBEntry("Specifies the constraint type that is selected by default when creating a new activity. The initial value for this preference is \"As Soon As Possible\".")
    public static final String PREF_DEFAULT_CONSTRAINT_TYPE_LONG_DESC = "PREF_DEFAULT_CONSTRAINT_TYPE_LONG_DESC";
    @RBEntry("As Soon As Possible")
    public static final String ASAP_PREF_CHOICE = "ASAP_PREF_CHOICE";
    @RBEntry("Start No Earlier Than")
    public static final String SNET_PREF_CHOICE = "SNET_PREF_CHOICE";
    @RBEntry("As Late As Possible")
    public static final String ALAP_PREF_CHOICE = "ALAP_PREF_CHOICE";
    @RBEntry("Must Finish On")
    public static final String MFO_PREF_CHOICE = "MFO_PREF_CHOICE";
    @RBEntry("Delete Linked Deliverable or Activity")
    public static final String PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY = "PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY";
    @RBEntry("Specifies whether to delete a deliverable when its linked activity is deleted and vice-versa.")
    public static final String PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY_DESC = "PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY_DESC";
    @RBEntry("This preference only applies when the <b>Link deliverables with project activities</b> option is enabled. <br><ul><li>Yes - When you delete an activity with a linked deliverable, the linked deliverable is deleted as well. The same behavior applies when deleting a deliverable with a linked activity. A warning message appears.</li><li>No - When you delete an activity with a linked deliverable, the deliverable is unaffected. If you delete a deliverable with a linked activity, the activity is unaffected.</li></ul><br>The default value is No.")
    public static final String PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY_LONG_DESC = "PREF_DELETE_LINKED_DELIVERABLE_OR_ACTIVITY_LONG_DESC";
    @RBEntry("This activity is linked to a deliverable. The linked deliverable will also be deleted. \n\nClick OK to continue.")
    public static final String CONF_DELETE_LINKED_DELIVERABLE = "CONF_DELETE_LINKED_DELIVERABLE";
    @RBEntry("This deliverable is linked to an activity.  The linked activity will also be deleted. \n\nClick OK to continue.")
    public static final String CONF_DELETE_LINKED_ACTIVITY = "CONF_DELETE_LINKED_ACTIVITY";
    @RBEntry("One or more of the activities have linked deliverables. The linked deliverables will also be deleted. \n\nClick OK to continue.")
    public static final String CONF_MULTI_DELETE_LINKED_DELIVERABLE = "CONF_MULTI_DELETE_LINKED_DELIVERABLE";
    @RBEntry("One or more of the deliverables have linked activities. The linked activities will also be deleted. \n\nClick OK to continue.")
    public static final String CONF_MULTI_DELETE_LINKED_ACTIVITY = "CONF_MULTI_DELETE_LINKED_ACTIVITY";
    @RBEntry("Line Number")
    public static final String LINE_NUMBER = "LINE_NUMBER";
    @RBEntry("Activities have been rescheduled.")
    public static final String SCHEDULE_RECALCULATED_SUCCESS = "SCHEDULE_RECALCULATED_SUCCESS";
    @RBEntry("Activities have not been rescheduled.")
    public static final String SCHEDULE_RECALCULATED_FAILURE = "SCHEDULE_RECALCULATED_FAILURE";
    @RBEntry("The selected activities include one or more summary activities that have a linked deliverable. \n\nWhen you delete a summary activity, you will delete all of its child activities. If the summary activity has a linked deliverable, you will delete the linked deliverable as well. \n\nClick OK to continue.")
    public static final String CONF_MULTI_SUMMARY_DELETE_LINKED_DELIVERABLE = "CONF_MULTI_SUMMARY_DELETE_LINKED_DELIVERABLE";
    @RBEntry("'{0}' is a summary activity and it has a linked deliverable.  Deleting it will delete its linked deliverable and all of its child activities. \n\nClick OK to continue.")
    public static final String CONF_SINGLE_SUMMARY_DELETE_LINKED_DELIVERABLE = "CONF_SINGLE_SUMMARY_DELETE_LINKED_DELIVERABLE";
    @RBEntry("The selected activities include one or more summary activities and one or more activities with a linked deliverable. \n\nWhen you delete a summary activity, you will delete all of its child activities. When you delete an activity with a linked deliverable, you will delete the linked deliverable as well. \n\nClick OK to continue.")
    public static final String CONF_MULTI_DELETE_LINKED_DELIVERABLE_WITH_SUMMARY = "CONF_MULTI_DELETE_LINKED_DELIVERABLE_WITH_SUMMARY";
    @RBEntry("The selected activities include one or more activities with a linked deliverable and one or more summary activities with a linked deliverable. \n\nWhen you delete an activity with a linked deliverable, you will delete the linked deliverable as well. \n\nWhen you delete a summary activity, you will delete all of its child activities. If the summary activity has a linked deliverable, you will delete the linked deliverable as well. \n\nClick OK to continue.")
    public static final String CONF_MULTI_DELETE_LINKED_DELIVERABLE_WITH_SUMMARY_LINKED_DELIVERABLE = "CONF_MULTI_DELETE_LINKED_DELIVERABLE_WITH_SUMMARY_LINKED_DELIVERABLE";
    @RBEntry("Null or invalid container.")
    public static final String NULL_CONTAINER_ERROR_MESSAGE = "NULL_CONTAINER_ERROR_MESSAGE";
    @RBEntry("This action will also change the activity owner.\n Press Ok to continue.")
    public static final String CHANGE_ACTIVITY_OWNER = "CHANGE_ACTIVITY_OWNER";
    @RBEntry("This action will remove the activity owner.\n Press Ok to continue.")
    public static final String REMOVE_ACTIVITY_OWNER = "REMOVE_ACTIVITY_OWNER";
    @RBEntry("Single assignment cannot be created for '{0}' type of resource")
    public static final String CREATE_SINGLE_ASSIGNMENT_WITH_MULTI_USER_RESOURCE_ERROR = "CREATE_SINGLE_ASSIGNMENT_WITH_MULTI_USER_RESOURCE_ERROR";
    @RBEntry("Shared assignment cannot be created for '{0}' type of resource")
    public static final String CREATE_SHARED_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR = "CREATE_SHARED_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR";
    @RBEntry("Bulk assignment cannot be created for '{0}' type of resource")
    public static final String CREATE_BULK_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR = "CREATE_BULK_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR";
    @RBEntry("Pool assignment cannot be created for '{0}' type of resource")
    public static final String CREATE_POOL_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR = "CREATE_POOL_ASSIGNMENT_WITH_USER_OR_OTHER_RESOURCE_ERROR";
    @RBEntry("Export Plan Template")
    public static final String EXPORT_PLAN_TEMPLATE_TITLE = "EXPORT_PLAN_TEMPLATE_TITLE";
    @RBEntry("Export a plan template from existing plan {0}")
    public static final String EXPORT_PLAN_TEMPLATE_DESCRIPTION = "EXPORT_PLAN_TEMPLATE_DESCRIPTION";
    @RBEntry("Export Plan Template")
    public static final String EXPORT_PLAN_TEMPLATE_LABEL = "EXPORT_PLAN_TEMPLATE_LABEL";
    @RBEntry("{0} Template")
    public static final String DEFAULT_EXPORT_OR_SAVE_AS_PLAN_TEMPLATE_NAME = "DEFAULT_EXPORT_OR_SAVE_AS_PLAN_TEMPLATE_NAME";
    @RBEntry("Plan Name:")
    public static final String EXPORT_OR_SAVE_AS_PLAN_LABEL = "EXPORT_OR_SAVE_AS_PLAN_LABEL";
    @RBEntry("{0}")
    @RBPseudo(false)
    public static final String EXPORT_OR_SAVE_AS_PLAN_NAME = "EXPORT_OR_SAVE_AS_PLAN_NAME";
    @RBEntry("Plan Template Name:")
    public static final String EXPORT_OR_SAVE_AS_PLAN_NAME_LABEL = "EXPORT_OR_SAVE_AS_PLAN_NAME_LABEL";
    @RBEntry("Select the objects to be copied to the new plan:")
    public static final String SELECT_ITEMS_TO_COPY_TO_PLAN = "SELECT_ITEMS_TO_COPY_TO_PLAN";
    @RBEntry("Description:")
    public static final String PLAN_TEMPLATE_DESCRIPTION = "PLAN_TEMPLATE_DESCRIPTION";
    @RBEntry("Plan Activities")
    public static final String PLAN_ACTIVITIES = "PLAN_ACTIVITIES";
    @RBEntry("Deliverables")
    public static final String PLAN_DELIVERABLES = "PLAN_DELIVERABLES";
    @RBEntry("Resource Assignments")
    public static final String RESOURCE_ASSIGNMENTS = "RESOURCE_ASSIGNMENTS";
    @RBEntry("Assigned Resources")
    public static final String ASSIGNED_RESOURCES = "ASSIGNED_RESOURCES";
    @RBEntry("Unassigned Resources")
    public static final String UNASSIGNED_RESOURCES = "UNASSIGNED_RESOURCES";
    @RBEntry("Please enter a name.")
    public static final String NAME_REQUIRED = "NAME_REQUIRED";
    @RBEntry("Description is too long")
    public static final String ERROR_LONG_DESC = "ERROR_LONG_DESC";
    @RBEntry("Save as Plan Template")
    public static final String SAVE_AS_PLAN_TEMPLATE_TITLE = "SAVE_AS_PLAN_TEMPLATE_TITLE";
    @RBEntry("Create a new plan template by copying existing plan {0}")
    public static final String SAVE_AS_PLAN_TEMPLATE_DESCRIPTION = "SAVE_AS_PLAN_TEMPLATE_DESCRIPTION";
    @RBEntry("Save as plan Template")
    public static final String SAVE_AS_PLAN_TEMPLATE_LABEL = "SAVE_AS_PLAN_TEMPLATE_LABEL";
    @RBEntry("Creating Plan...")
    public static final String CREATING_PLAN = "CREATING_PLAN";
    @RBEntry("Invalid objects selected. This action is not valid for one or more selected objects.")
    public static final String INVALID_OBJECT_SELECTION_ERROR = "INVALID_OBJECT_SELECTION_ERROR";
    @RBEntry("Mark activity as deliverable")
    public static final String MARK_ACTIVITY_AS_DELIVERABLE = "MARK_ACTIVITY_AS_DELIVERABLE";
    @RBEntry("Tracking policy")
    public static final String TRACKING_POLICY = "TRACKING_POLICY";
    @RBEntry("Deliverables")
    public static final String ACTIVITY_WIZARD_DELIVERABLE = "ACTIVITY_WIZARD_DELIVERABLE";
    @RBEntry("Rolled up Cost")
    public static final String ROLLED_UP_COST = "ROLLED_UP_COST";
    @RBEntry("Schedule")
    public static final String SCHEDULE = "SCHEDULE";
    @RBEntry("Plan name '{0}' is not unique in container '{1}'.")
    public static final String NON_UNIQUE_PLAN_NAME = "NON_UNIQUE_PLAN_NAME";
    @RBEntry("Has Deliverable")
    public static final String HAS_DELIVERABLE = "Has Deliverable";
    @RBEntry("You must enter a value for Name")
    public static final String PLAN_NAME_RESQUIRED = "PLAN_NAME_RESQUIRED";
    @RBEntry("You must enter a value for owner")
    public static final String PLAN_OWNER_RESQUIRED = "PLAN_OWNER_RESQUIRED";
    @RBEntry("You do not have the necessary authorization to remove the following:\n{0}")
    public static final String SCHEDULEDDELIVERABLE_UNAUTHORIZED_ACCESS = "SCHEDULEDDELIVERABLE_UNAUTHORIZED_ACCESS";
    @RBEntry("This operation cannot be performed on completed objects:\n{0}")
    public static final String COMPLETED_SCHEDULEDDELIVERABLE_SELECTED = "COMPLETED_SCHEDULEDDELIVERABLE_SELECTED";
    @RBEntry("Do you want to continue with the remaining selected objects?")
    public static final String CONFIRMATION_SHOULD_CONTINUE = "CONFIRMATION_SHOULD_CONTINUE";
    @RBEntry("There are no objects remaining to remove.")
    public static final String INFO_NO_MORE_OBJECTS_TO_REMOVE = "INFO_NO_MORE_OBJECTS_TO_REMOVE";
    @RBEntry("There are no eligible plans in this context. You must have a manual plan, or an automatic plan that is in the In-Process state. You must also already be assigned to a deliverable activity within that plan: {0}.")
    public static final String NO_ELIGIBLE_PLANS_PRESENT_FOR_TRACK_NEW_WORK = "NO_ELIGIBLE_PLANS_PRESENT_FOR_TRACK_NEW_WORK";
    @RBEntry("There are no eligible plans for this activity. You must have a manual plan, or an automatic plan that is in the Scheduled, In-Process, or Suspended state.")
    public static final String NO_ELIGIBLE_PLANS_PRESENT_FOR_NEW_PLAN_ACTIVITY = "NO_ELIGIBLE_PLANS_PRESENT_FOR_NEW_PLAN_ACTIVITY";
    @RBEntry("You have selected invalid objects for this operation.")
    public static final String INVALID_OBJECTS_SELECTED = "INVALID_OBJECTS_SELECTED";
    @RBEntry("Please Select Two Object To Be Compared.。")
    public static final String COMPARE_OBJECT_ERROR = "COMPARE_OBJECT_ERROR";

    public planResource() {
    }
}
