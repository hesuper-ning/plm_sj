//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.projectmanagement.ilog;

import com.ptc.core.htmlcomp.components.TableViewUtils;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.netmarkets.project.NmProjectHelper;
import com.ptc.projectmanagement.assignment.ResourceAssignment;
import com.ptc.projectmanagement.plan.*;
import com.ptc.projectmanagement.plannable.Rootable;
import com.ptc.projectmanagement.util.ProcessorUtils;
import com.ptc.windchill.gantt2.common.ConstraintCycleChecker;
import com.ptc.windchill.gantt2.common.GanttActivity;
import com.ptc.windchill.gantt2.common.GanttDataModel;
import com.ptc.windchill.gantt2.common.GanttSchedulingManager;
import com.ptc.windchill.gantt2.common.GanttTransferableItem;
import com.ptc.windchill.gantt2.common.WorkingHourHandler;
import com.ptc.windchill.gantt2.server.GanttDataDelegateFactory;
import com.ptc.windchill.gantt2.server.GanttDataHelper;
import ext.project.util.CtProjectUtil;
import ilog.views.gantt.IlvActivity;
import ilog.views.gantt.IlvTimeInterval;
import ilog.views.util.IlvProductUtil;
import java.io.File;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import org.apache.log4j.Logger;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.CollectionContainsStaleException;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.delete.DeleteHelper;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.pom.DeadlockDetectedException;
import wt.pom.ObjectIsStaleException;
import wt.pom.Transaction;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;

public class StandardILogService extends StandardManager implements ILogService, Serializable {
    private static String PLANNABLE_RESOURCE = "com.ptc.projectmanagement.plannable.plannableResource";
    private static final String CLASSNAME = StandardILogService.class.getName();
    private static final Logger log;
    private static File TMP_DIR;
    private static final String TMP_FILE_PREFIX = "ilog-tmp-";
    protected GanttDataDelegateFactory ganttDataDelegateFactory = new GanttDataDelegateFactory();

    public StandardILogService() {
    }

    public static String getClassName() {
        return CLASSNAME;
    }

    public static StandardILogService newStandardILogService() throws WTException {
        StandardILogService var0 = new StandardILogService();
        var0.initialize();
        return var0;
    }

    /** @deprecated */
    @Deprecated
    public Plannable getPlan(String var1) throws WTException {
        boolean var2 = false;
        Plan var3 = null;

        try {
            var2 = SessionServerHelper.manager.setAccessEnforced(false);
            ReferenceFactory var4 = new ReferenceFactory();
            ObjectReference var5 = (ObjectReference)var4.getReference(var1);
            var3 = (Plan)PlanHelper.service.getDefaultPlan(var5);
        } catch (Exception var9) {
            System.out.println("Exception::::" + var9);
        } finally {
            SessionServerHelper.manager.setAccessEnforced(var2);
        }

        return var3;
    }

    public void updatePersistables(GanttDataModel var1) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("updatePersistables() IN :::");
        }

        WTCollection var2 = this.getPersistables(var1);
        if (log.isDebugEnabled()) {
            log.debug("Calling updatePersistablesConcurrently() :::");
        }

        this.updatePersistablesConcurrently(var1, var2);
        if (log.isDebugEnabled()) {
            log.debug("updatePersistablesConcurrently() Succefully Completed :::");
        }

        MethodContext var3 = MethodContext.getContext();
        WTArrayList var4 = var1.getStartDateChangeActivities();
        boolean var5 = var3.get("CreateActivityFlag") != null ? (Boolean)var3.get("CreateActivityFlag") : false;
        if (var3 != null && var1 != null && var4 != null && !var4.isEmpty() && !var5) {
            HashMap var6 = var3.get("ProcessedEvent") != null ? (HashMap)var3.get("ProcessedEvent") : new HashMap();
            var6.put("EPP_START_DATE_CHANGE", var4);
            PlanHelper.service.dispatchMultiEvent("EPP_START_DATE_CHANGE", var4);
            var3.put("ProcessedEvent", var6);
        }

        if (log.isDebugEnabled()) {
            log.debug("updatePersistables() OUT :::");
        }

    }

    private void updatePersistablesConcurrently(GanttDataModel var1, WTCollection var2) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("updatePersistablesConcurrently() IN :::" + var2.size());
        }

        if (var2 != null && !var2.isEmpty()) {
            boolean var5 = true;
            Transaction var6 = new Transaction();

            try {
                var6.start();
                Transaction var7 = new Transaction();

                try {
                    var7.start();
                    var7.setSavepoint();
                    if (log.isDebugEnabled()) {
                        log.debug("Save Point created for updatePersistablesConcurrently() :::");
                    }

                    boolean var8 = SessionServerHelper.manager.setAccessEnforced(false);

                    try {
                        PersistenceHelper.manager.modify(var2);
                    } finally {
                        SessionServerHelper.manager.setAccessEnforced(var8);
                    }

                    if (log.isDebugEnabled()) {
                        log.debug("persisted all the objects in the list for updatePersistablesConcurrently() :::");
                    }

                    var7.commit();
                    var7 = null;
                } catch (ObjectIsStaleException var35) {
                    if (log.isDebugEnabled()) {
                        log.debug("ObjectIsStaleException occured in updateWithinTransaction(). Ignoring this exception for now. \n Now Retrying...");
                    }

                    if (log.isDebugEnabled()) {
                        log.debug(var35.getMessage());
                    }

                    MethodContext.getContext().put("PROPAGATESCHEDULE_CONCURRENT_UPDATE_EXCEPTION", var35);
                    var5 = false;
                } catch (DeadlockDetectedException var36) {
                    if (log.isDebugEnabled()) {
                        log.debug("DeadlockDetectedException occured in updateWithinTransaction(). Ignoring this exception for now. \n Now Retrying...");
                    }

                    if (log.isDebugEnabled()) {
                        log.debug(var36.getMessage());
                    }

                    MethodContext.getContext().put("PROPAGATESCHEDULE_CONCURRENT_UPDATE_EXCEPTION", var36);
                    var5 = false;
                } catch (CollectionContainsStaleException var37) {
                    if (log.isDebugEnabled()) {
                        log.debug("CollectionContainsStaleException occured in updateWithinTransaction(). Ignoring this exception for now. \n Now Retrying...");
                    }

                    if (log.isDebugEnabled()) {
                        log.debug(var37.getMessage());
                    }

                    MethodContext.getContext().put("PROPAGATESCHEDULE_CONCURRENT_UPDATE_EXCEPTION", var37);
                    var5 = false;
                } finally {
                    if (var7 != null) {
                        var7.rollback();
                        var7 = null;
                        var5 = false;
                    }

                }

                var6.commit();
                var6 = null;
                if (log.isDebugEnabled()) {
                    log.debug("Outer Transaction is commited...updatePersistablesConcurrently()");
                }

                if (log.isDebugEnabled()) {
                    log.debug(" updatePersistablesConcurrently() : isTransactionSuccessful == > " + var5);
                }

                int var41 = 0;
                if (!var5) {
                    WTCollection var9 = this.getPersistables(var1);
                    Integer var10 = (Integer)MethodContext.getContext().get("PROPAGATE_RETRY_COUNT");
                    if (log.isDebugEnabled()) {
                        log.debug("updatePersistablesConcurrently() : iterationCount == >" + var10);
                    }

                    if (var10 == null) {
                        MethodContext.getContext().put("PROPAGATE_RETRY_COUNT", new Integer(1));
                    } else {
                        var41 = var10;
                        if (log.isDebugEnabled()) {
                            log.debug("NmProjectHelper.RETRY_ATTEMPTS_NUMBER == " + NmProjectHelper.RETRY_ATTEMPTS_NUMBER);
                        }

                        if (var41++ <= NmProjectHelper.RETRY_ATTEMPTS_NUMBER) {
                            MethodContext.getContext().put("PROPAGATE_RETRY_COUNT", var41);
                        } else {
                            if (log.isDebugEnabled()) {
                                log.debug("updatePersistablesConcurrently cannot be completed successfully. ReThrowing Exception == >");
                            }

                            if (MethodContext.getContext().get("PROPAGATESCHEDULE_CONCURRENT_UPDATE_EXCEPTION") != null) {
                                WTException var11 = (WTException)MethodContext.getContext().get("PROPAGATESCHEDULE_CONCURRENT_UPDATE_EXCEPTION");
                                throw var11;
                            }
                        }
                    }

                    if (log.isDebugEnabled()) {
                        log.debug("updatePersistablesConcurrently ::: Retrying once again. Retry Number == >" + var41);
                    }

                    this.updatePersistablesConcurrently(var1, var9);
                }
            } catch (WTException var39) {
                if (log.isDebugEnabled()) {
                    log.debug("updatePersistablesConcurrently ::: Some other exception has occured. Throwing Exception");
                }

                var39.printStackTrace();
                throw new WTException(var39);
            } finally {
                if (var6 != null) {
                    var6.rollback();
                    var6 = null;
                }

                MethodContext.getContext().remove("PROPAGATE_RETRY_COUNT");
                MethodContext.getContext().remove("PROPAGATESCHEDULE_CONCURRENT_UPDATE_EXCEPTION");
                if (log.isDebugEnabled()) {
                    log.debug("updatePersistablesConcurrently ::: Removed PROPAGATE_RETRY_COUNT from MethodContext");
                }

            }
        }

        if (log.isDebugEnabled()) {
            log.debug("updateWithinTransaction OUT :::");
        }

    }

    public WTCollection getPersistables(GanttDataModel var1) throws WTException {
        ReferenceFactory var2 = new ReferenceFactory();
        WTArrayList var3 = new WTArrayList();
        HashMap var4 = new HashMap();
        HashMap var5 = new HashMap();
        ArrayList var6 = new ArrayList();
        Iterator var7 = var1.activityPreorderIterator();

        while(var7.hasNext()) {
            IlvActivity var8 = (IlvActivity)var7.next();
            if (log.isDebugEnabled()) {
                log.debug("updatePersistables: act name: " + var8.getName());
            }

            if (var8 instanceof GanttActivity && ((GanttActivity)var8).getProperty("UUID") != null) {
                GanttActivity var9 = (GanttActivity)var8;
                if (var9.isMFO()) {
                    Calendar var10 = Calendar.getInstance();
                    var10.setTime(var9.getEndTime());
                    var10.set(13, 0);
                    if (!var9.getConstraintDate().equals(var10.getTime())) {
                        Locale var20 = SessionHelper.getLocale();
                        WTContainerRef var22 = var9.getContainerRef();
                        String var23 = ProcessorUtils.getUserFormattedDate(new Timestamp(var9.getConstraintDate().getTime()), var20, var22, SessionHelper.getPrincipal());
                        String[] var24 = new String[]{var9.getName(), var23};
                        String var25 = WTMessage.getLocalizedMessage("com.ptc.projectmanagement.ilog.ilogResource", "MFO_FINISH_BEYOND_CONSTRAINT_DATE_ERROR_MESSAGE", var24, var20);
                        throw new WTException(var25);
                    }
                }

                if (needsUpdate(var9)) {
                    TypeInstanceIdentifier var18 = var9.getTii();
                    var6.add(var18);
                    String var11 = var18.getPersistenceIdentifier();
                    WTReference var12 = var2.getReference(var11);
                    if (var12 != null) {
                        Persistable var13 = var12.getObject();
                        boolean var14 = false;
                        if (var13 != null && var13 instanceof ResourceAssignment) {
                            Persistable var15 = ((ResourceAssignment)var13).getRoleAObject();
                            log.debug("skipping to add resource,which is marked for deletion");
                            var14 = DeleteHelper.isMarkedForDelete(var15);
                        }

                        if (!var14) {
                            var3.add(var12);
                        }
                    }

                    var4.put(var18, var9);
                    var5.put(var12, var9);
                }
            }
        }

        Iterator var16 = var3.persistableIterator();

        while(var16.hasNext()) {
            Persistable var17 = (Persistable)var16.next();
            if (log.isDebugEnabled()) {
                log.debug("updatePersistables: persistable: " + var17);
            }

            ObjectReference var19 = ObjectReference.newObjectReference(var17);
            GanttActivity var21 = (GanttActivity)var5.get(var19);
            this.updatePersistable(var17, var21, var1);
        }

        if (log.isDebugEnabled()) {
            log.debug("Modified size: " + var3.size());
        }

        return var3;
    }

    public GanttDataModel createGanttModel(Rootable var1, boolean var2) throws WTException {
        GanttDataModel var3 = null;
        if (var1 instanceof Plannable) {
            var3 = this.createGanttModel((Plannable)var1, var2);
        }

        return var3;
    }

    public GanttDataModel createGanttModel(Plannable var1, boolean var2) throws WTException {
        Locale var3 = SessionHelper.getLocale();
        return this.createGanttModel(var1, var2, var3);
    }

    public GanttDataModel createGanttModel(Plannable var1, boolean var2, Locale var3) throws WTException {
        GanttDataModel var4 = null;
        TypeInstanceIdentifier var6 = TypeIdentifierUtility.getTypeInstanceIdentifier(var1);
        GanttTransferableItem var7 = new GanttTransferableItem();
        Timestamp var8 = var1.getStartDate();
        Timestamp var9 = null;
        if (var1 instanceof Plan) {
            var9 = ((Plan)var1).getDefaultStart();
        }

        var9 = var9 == null ? var8 : var9;
        Date var11;
        if (var1 != null && var9 != null) {
            Date var10 = new Date(var9.getTime());
            var7.getUserProperties().put("default_start_time", var10);
            if (var1 instanceof Plan && ((Plan)var1).isScheduledBackward()) {
                var11 = new Date(((Plan)var1).getFinishDate().getTime());
                var7.getUserProperties().put("PROJECT_FINISH_DATE", var11);
            }
        }

        var7.setItemTii(var6);
        ArrayList var21 = new ArrayList();
        var21.add(var7);
        var11 = null;
        Rootable var22;
        if (var1 instanceof Rootable) {
            var22 = (Rootable)var1;
        } else {
            var22 = var1.getRoot();
        }

        WorkingHourHandler var12 = this.getWorkingHourHandler(var22);
        var4 = (GanttDataModel)GanttDataHelper.ganttService.getILogGanttModel(var21, var12, var3);
        if (var4.getRootActivity() instanceof GanttActivity) {
            GanttActivity var13 = (GanttActivity)var4.getRootActivity();
            if (var1 instanceof Rootable) {
                var22 = (Rootable)var1;
                String var14 = "projectmanagement.plan.view";
                String var15 = TableViewUtils.getCurrentViewKey(var14);
                var13.setProperty("PLAN_LIST_VIEW", var15);
            } else {
                var22 = var1.getRoot();
            }

            if (var12 != null) {
                var13.setProperty("WORKING_HOUR_HANDLER", var12);
            }
        }

        if (var2) {
            log.debug("Iterating through each gantt activity in the gantt model and setting the time interval based on start date of the gantt activity");

            GanttActivity var24;
            for(Iterator var23 = var4.activityPreorderIterator(); var23.hasNext(); log.debug("Time Interval of gantt activity " + var24.getName() + " : " + var24.getTimeInterval())) {
                var24 = (GanttActivity)var23.next();
                long var25 = var24.getWorkingDuration() == null ? 0L : var24.getWorkingDuration().getMillis();
                WorkingHourHandler var17 = GanttSchedulingManager.getWorkingHourHandler(var4);
                Date var18 = (Date)var24.getProperty("start_date");
                log.debug("Start Date of gantt activity " + var24.getName() + " : " + var18);
                IlvTimeInterval var19 = var24.getTimeInterval();
                if (var17 != null) {
                    if (var18 != null) {
                        Date var20 = var17.addWorkingDuration(var18, var25, var24.getWorkCalendar());
                        var24.setTimeInterval(new IlvTimeInterval(var18, var20));
                    }
                } else if (var18 != null) {
                    var24.setTimeInterval(new IlvTimeInterval(var18, var19.getDuration()));
                }
            }
        }

        return var4;
    }

    protected void updatePersistable(Persistable var1, GanttActivity var2, GanttDataModel var3) throws WTException {
        if (!(var1 instanceof Scheduleable)) {
            System.out.println(" persistable not scheduleable: " + var1);
        } else {
            Scheduleable var4 = (Scheduleable)var1;
            Date var5 = (Date)var2.getProperty("ORIG_START");
            Date var6 = (Date)var2.getProperty("ORIG_FINISH");
            Long var7 = (Long)var2.getProperty("ORIG_DURATION");
            Date var8 = var2.getStartTime();
            Date var9 = var2.getEndTime();
            boolean var10 = Boolean.valueOf(String.valueOf(var2.getProperty("critical")));
            WorkingHourHandler var11 = GanttSchedulingManager.getWorkingHourHandler(var3);
            Long var12 = var2.getDuration().getMillis();
            if (var11 != null) {
                var12 = var2.getWorkingDuration().getMillis();
            }

            if (log.isDebugEnabled()) {
                log.debug("updatePersistable before changing - Scheduleable: " + var4);
                log.debug("    Start: " + var4.getStartDate());
                log.debug("    Finish: " + var4.getFinishDate());
                log.debug("    Duration: " + var4.getDuration().getMillis());
                log.debug("updatePersistable before changing - GanttActivity: ");
                log.debug("    newStart: " + var8);
                log.debug("    newFinish: " + var9);
                log.debug("    newDuration: " + var12);
            }
            /** custom start **/
            if (var4 instanceof Plannable) {
                Plannable activity = (Plannable) var4;
                if(activity.getStartDate() != null) {
                    var8 = activity.getStartDate();
                    var9 = activity.getFinishDate();
                    try {
                        int durationDays = CtProjectUtil.getDurationByStateAndFinishTime(activity.getStartDate(), activity.getFinishDate());
                        Duration duration = ProcessorUtils.getDuration(durationDays, DurationFormat.DAYS.toString());
                        activity.setDuration(duration);
                        var12 = activity.getDuration().getMillis();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            /** custom end **/
            try {
                Timestamp var13;
                Timestamp var14;
                if (var9 != null && var6 != null && var9.getTime() != var6.getTime() || var9 != null && var6 == null) {
                    var13 = new Timestamp(var9.getTime());
                    var4.setFinishDate(var13);
                    var14 = var4.getActualFinishDate();
                    if (var14 != null) {
                        var4.setActualFinishDate(var13);
                    }
                }

                if (var8 != null && var5 != null && var8.getTime() != var5.getTime() || var8 != null && var5 == null) {
                    if (var1 instanceof PlanActivity) {
                        var3.setStartDateChangeActivities((PlanActivity)var1);
                    }

                    var13 = new Timestamp(var8.getTime());
                    var4.setStartDate(var13);
                    var14 = var4.getActualStartDate();
                    if (var14 != null) {
                        if (var1 instanceof PlanActivity) {
                            Timestamp var15 = null;
                            Plan var16 = null;
                            PlanActivity var17 = (PlanActivity)var1;

                            try {
                                var16 = (Plan)var17.getRoot();
                                var15 = ProcessorUtils.getAdjustedCurrentTime(var16, new Date());
                            } catch (WTException var19) {
                                log.error("updatePersistable : Exception while getting ProcessorUtils.getAdjustedCurrentTime ", var19);
                            }

                            if (var16 != null && !var16.isAutoExecution()) {
                                var4.setActualStartDate(var13);
                            } else if (var15 != null && var13.after(var15)) {
                                if (var17.isSummary()) {
                                    if (log.isDebugEnabled()) {
                                        log.debug("Reverting state of the Summary activity to SCHEDULED since it's actual start date is going in future :" + var17.getName() + " , new start date: " + var13);
                                    }

                                    var4.setActualStartDate((Timestamp)null);
                                    var17.setPlannableState(PlannableState.SCHEDULED);
                                } else if (var4.getActualStartDate() != null) {
                                    var4.setStartDate(var4.getActualStartDate());
                                    if (log.isDebugEnabled()) {
                                        log.debug("Instead of updating 'actual start date', reset 'start date' to actual start date : " + var17.getName() + " , new start date: " + var13);
                                    }
                                }
                            } else {
                                var4.setActualStartDate(var13);
                            }
                        } else {
                            var4.setActualStartDate(var13);
                        }
                    }
                }

                if (var12 != null && var7 != null && var12 != var7 || var12 != null && var7 == null) {
                    Duration var21 = var4.getDuration();
                    if (var21 == null) {
                        var21 = Duration.newDuration();
                    }

                    var21.setMillis(var12);
                    var4.setDuration(var21);
                }

                var4.setCritical(var10);
                if (log.isDebugEnabled()) {
                    log.debug("updatePersistable after changing: " + var4);
                    log.debug("    Start: " + var4.getStartDate());
                    log.debug("    Finish: " + var4.getFinishDate());
                    log.debug("    Duration: " + var4.getDuration().getMillis());
                }

            } catch (WTPropertyVetoException var20) {
                throw new WTException(var20);
            }
        }
    }

    protected static boolean needsUpdate(GanttActivity var0) {
        boolean var1 = false;
        Date var2 = (Date)var0.getProperty("ORIG_START");
        Date var3 = (Date)var0.getProperty("ORIG_FINISH");
        Date var4 = var0.getStartTime();
        Date var5 = var0.getEndTime();
        if (var5 != null && var3 != null && var5.getTime() != var3.getTime() || var5 != null && var3 == null) {
            var1 = true;
        } else if (var4 != null && var2 != null && var4.getTime() != var2.getTime() || var4 != null && var2 == null) {
            var1 = true;
        }

        boolean var6 = (Boolean)var0.getProperty("CRITICAL");
        boolean var7 = (Boolean)var0.getProperty("critical");
        if (var6 != var7) {
            var1 = true;
        }

        if (log.isDebugEnabled()) {
            log.debug(" needsUpdate: " + var1);
        }

        return var1;
    }

    protected WorkingHourHandler getWorkingHourHandler(Rootable var1) {
        WorkingHourHandler var2 = null;
        if (var1 != null) {
            var2 = this.ganttDataDelegateFactory.getWorkingHourHandler(var1);
        }

        return var2;
    }

    public static void checkCycle(GanttDataModel var0) throws WTException {
        ConstraintCycleChecker var1 = new ConstraintCycleChecker();
        boolean var2 = var1.checkCycle(var0);
        if (var2) {
            throw new WTException(PLANNABLE_RESOURCE, "3", (Object[])null);
        }
    }

    static {
        try {
            IlvProductUtil.registerApplication("ProjectLink-Windchill");
            log = LogR.getLogger(getClassName());
            WTProperties var0 = WTProperties.getLocalProperties();
            String var1 = var0.getProperty("wt.temp");
            if (var1 != null) {
                TMP_DIR = new File(var1);
            } else {
                TMP_DIR = null;
            }

        } catch (Exception var2) {
            throw new ExceptionInInitializerError(var2);
        }
    }
}
