//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.wvs.client.beans;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.wvs.client.beans.messageResource")
public final class messageResource_zh_CN extends WTListResourceBundle {
    @RBEntry("Windchill 可视化")
    public static final String WINDCHILL_VISUALIZATION = "1001";
    @RBEntry("帮助")
    public static final String HELP = "1002";
    @RBEntry("可视化")
    public static final String VISUALIZATION = "1003";
    @RBEntry("关闭")
    public static final String WINDOW_CLOSE = "1004";
    @RBEntry("取消")
    public static final String WINDOW_CANCEL = "1005";
    @RBEntry("确定")
    public static final String WINDOW_OK = "1006";
    @RBEntry("学习")
    public static final String LEARN = "1007";
    @RBEntry("缩略图")
    public static final String THUMBNAIL = "1009";
    @RBEntry("类型")
    public static final String TYPE = "1010";
    @RBEntry("编号")
    public static final String NUMBER = "1011";
    @RBEntry("名称")
    public static final String NAME = "1012";
    @RBEntry("版本")
    public static final String VERSION = "1013";
    @RBEntry("小版本")
    public static final String ITERATION = "1014";
    @RBEntry("操作")
    public static final String ACTIONS = "1015";
    @RBEntry("首选项")
    public static final String PREFERENCES = "1016";
    @RBEntry("不被支持")
    public static final String NOTSUPPORTED = "1017";
    @RBEntry("Creo View 客户端版当前不支持查阅该数据")
    public static final String NOTSUPPORTED_DESCRIPTION = "1018";
    @RBEntry("Creo View 客户端版当前不支持查看批注和序列")
    public static final String NOTSUPPORTED_DESCRIPTION1 = "1019";
    @RBEntry("UNIX 当前不支持 Creo View 客户端版")
    public static final String NOTSUPPORTED_DESCRIPTION2 = "1020";
    @RBEntry("Creo View 客户端版当前不支持批量打印工具")
    public static final String NOTSUPPORTED_DESCRIPTION3 = "1021";
    @RBEntry("Creo View 客户端版当前不能在 Netscape 6 浏览器上使用")
    public static final String NOTSUPPORTED_DESCRIPTION4 = "1022";
    @RBEntry("尚未安装 Creo View 客户端版。")
    public static final String PVLITE_NOT_INSTALLED = "1023";
    @RBEntry("真")
    public static final String TRUE = "1030";
    @RBEntry("假")
    public static final String FALSE = "1031";
    @RBEntry("是")
    public static final String YES = "1032";
    @RBEntry("否")
    public static final String NO = "1033";
    @RBEntry("应用")
    public static final String WINDOW_APPLY = "1034";
    @RBEntry("(安全信息)")
    public static final String SECURED_INFORMATION = "1035";
    @RBEntry("&lt;  Windchill")
    public static final String GOTO_WINDCHILL = "1101";
    @RBEntry("主页")
    public static final String HOME = "1102";
    @RBEntry("共享的根")
    public static final String CLIPBOARD = "1103";
    @RBEntry("WVS 作业监视器")
    public static final String PUBLISH_MONITOR = "1104";
    @RBEntry("管理器")
    public static final String ADMINISTRATOR = "1105";
    @RBEntry("协作")
    public static final String COLLABORATION = "1106";
    @RBEntry("搜索:")
    public static final String QUERY_SEARCH_ON = "1201";
    @RBEntry("编号:")
    public static final String QUERY_NUMBER = "1202";
    @RBEntry("名称:")
    public static final String QUERY_NAME = "1203";
    @RBEntry("视图:")
    public static final String QUERY_VIEW = "1204";
    @RBEntry("版本:")
    public static final String QUERY_VERSION = "1205";
    @RBEntry("类型:")
    public static final String QUERY_TYPE = "1206";
    @RBEntry("源:")
    public static final String QUERY_SOURCE = "1207";
    @RBEntry("状态:")
    public static final String QUERY_STATE = "1208";
    @RBEntry("团队:")
    public static final String QUERY_PROJECT = "1209";
    @RBEntry("文件柜:")
    public static final String QUERY_CABINET = "1210";
    @RBEntry("小版本:")
    public static final String QUERY_ITERATIONS = "1211";
    @RBEntry("最新")
    public static final String QUERY_LATEST = "1212";
    @RBEntry("全部")
    public static final String QUERY_ALL = "1213";
    @RBEntry("长列表:")
    public static final String QUERY_LONG_LIST = "1214";
    @RBEntry("文档类型:")
    public static final String QUERY_DOC_TYPE = "1215";
    @RBEntry("所有者应用程序:")
    public static final String QUERY_OWNER_APP = "1216";
    @RBEntry("作者应用程序:")
    public static final String QUERY_AUTHOR_APP = "1217";
    @RBEntry("排序方式:")
    public static final String SORT_BY = "1218";
    @RBEntry("关键字:")
    public static final String QUERY_KEYWORD = "1219";
    @RBEntry("说明:")
    public static final String QUERY_DESCRIPTION = "1220";
    @RBEntry("部件")
    public static final String QUERY_PART = "1231";
    @RBEntry("CAD 文档")
    public static final String QUERY_CAD_DOCUMENT = "1232";
    @RBEntry("文档")
    public static final String QUERY_DOCUMENT = "1233";
    @RBEntry("产品配置")
    public static final String QUERY_PRODUCT_CONFIGURATION = "1234";
    @RBEntry("产品实例")
    public static final String QUERY_PRODUCT_INSTANCE = "1235";
    @RBEntry("配置名称:")
    public static final String QUERY_CONFIGURATION_NAME = "1236";
    @RBEntry("产品编号:")
    public static final String QUERY_PRODUCT_NUMBER = "1237";
    @RBEntry("产品名称:")
    public static final String QUERY_PRODUCT_NAME = "1238";
    @RBEntry("序列号:")
    public static final String QUERY_SERIAL_NUMBER = "1239";
    @RBEntry("搜索")
    public static final String QUERY_SEARCH = "1241";
    @RBEntry("可视化未启用")
    public static final String VIS_NOT_ENABLED = "1301";
    @RBEntry("您可以查看上面的 {0} Creo View 徽标吗?")
    public static final String CAN_YOU_SEE = "1302";
    @RBEntry("请{0}单击此处{1}以安装 Creo View")
    public static final String CLICK_HERE = "1303";
    @RBEntry("好像未安装 Creo View")
    public static final String PV_NOT_INSTALLED = "1305";
    @RBEntry("已安装 Creo View ActiveX control ，但还未安装 Creo View 客户端")
    public static final String PV_ONLY_OCX_INSTALLED = "1306";
    @RBEntry(" Creo View 安装")
    public static final String DOWNLOAD_PRODUCTVIEW = "1401";
    @RBEntry("欢迎访问 Creo View 安装页面")
    public static final String DOWNLOAD_WELCOME = "1402";
    @RBEntry("好像您正在使用一个平台，该平台上没有可用 Creo View 下载。请联系您的系统管理员。")
    public static final String DOWNLOAD_IT_APEARS = "1403";
    @RBEntry("欢迎访问 {0} 的 Creo View 安装页面")
    public static final String DOWNLOAD_WELCOME_FOR = "1404";
    @RBEntry("您的浏览器已被检验，它显示您未安装 Creo View。")
    public static final String DOWNLOAD_BROWSER_CHECKED = "1405";
    @RBEntry("如果您是第一次使用 Windchill 可视化，您需要安装 Creo View。")
    public static final String DOWNLOAD_FIRST_TIME_USER = "1406";
    @RBEntry("请按下列6个步骤执行安装。")
    public static final String DOWNLOAD_SIX_STEPS = "1407";
    @RBEntry("请在开始之前，查阅整个步骤。")
    public static final String DOWNLOAD_REVIEW_STEPS = "1408";
    @RBEntry("下载 Creo View 安装程序 {0}  ")
    public static final String DOWNLOAD_CLICK_HERE = "1409";
    @RBEntry("当 Internet Explorer 问您想要在该文件上做什么时，请选择 \"在它的当前位置运行该程序\"。")
    public static final String DOWNLOAD_WHEN_IE = "1410";
    @RBEntry("Creo View 安装程序将下载并自动启动。")
    public static final String DOWNLOAD_START_AUTOMATICALLY = "1411";
    @RBEntry("在 Internet Explorer 上选取一个文件夹保存安装程序。")
    public static final String DOWNLOAD_FOLDER_IE = "1412";
    @RBEntry("选取一个文件夹，浏览器可以在其中保存安装程序。")
    public static final String DOWNLOAD_FOLDER_NS = "1413";
    @RBEntry("运行安装程序 (双击文件名)。")
    public static final String DOWNLOAD_RUN_SETUP_WIN = "1414";
    @RBEntry("解压缩安装程序(将文件解压缩 和 untar 文件至一个目录)")
    public static final String DOWNLOAD_RUN_SETUP_UNIX = "1415";
    @RBEntry("遵循安装程序内的说明来完成安装。")
    public static final String DOWNLOAD_FOLLOW_DIRECTIONS = "1416";
    @RBEntry("安装完成之后，单击{0}此处{1}，在您的浏览器中注册 Creo View。")
    public static final String DOWNLOAD_AFTER_SETUP = "1417";
    @RBEntry("Creo View 可以开始工作。")
    public static final String DOWNLOAD_PRODUCTVIEW_READY = "1418";
    @RBEntry("在您的系统管理员的指导下完成安装。")
    public static final String DOWNLOAD_FOLLOW_DIRECTIONS_UNIX = "1419";
    @RBEntry("尚未下载用于您的平台的 Creo View，请联系您的系统管理员")
    public static final String DOWNLOAD_NO_PRODUCTVIEW = "1420";
    @RBEntry("请在安装完毕之后，重新启动您的浏览器。")
    public static final String DOWNLOAD_AFTER_SETUP_RESTART = "1421";
    @RBEntry("可视化 - 完成 Creo View 升级")
    public static final String DOWNLOAD_FINISH_TITLE = "1431";
    @RBEntry("完成 Creo View 升级")
    public static final String DOWNLOAD_FINISH_HEADING = "1432";
    @RBEntry("感谢您抽出时间升级到最新版本的 Creo View。")
    public static final String DOWNLOAD_FINISH_THANK_YOU = "1433";
    @RBEntry("当安装程序完成之后， Creo View 可以开始使用。")
    public static final String DOWNLOAD_FINISH_COMPLETE = "1434";
    @RBEntry("其他下载")
    public static final String DOWNLOAD_ADDITIONAL_DOWNLOADS = "1435";
    @RBEntry("完成")
    public static final String DOWNLOAD_DONE = "1436";
    @RBEntry("已安装")
    public static final String DOWNLOAD_INSTALLED = "1437";
    @RBEntry("安装失败 - 出错代码 {0}。{1} 包含已下载文件和日志文件")
    public static final String DOWNLOAD_INSTALLATION_FAILED = "1438";
    @RBEntry("{0} 个文件，{1}Mb")
    public static final String DOWNLOAD_FILES = "1440";
    @RBEntry("此平台不支持安装 Creo View。")
    public static final String DOWNLOAD_PVLITE_NOT_SUPPORTED = "1442";
    @RBEntry("Creo View 客户端")
    public static final String DOWNLOAD_PVLITE = "1443";
    @RBEntry("AutoCAD 查看器")
    public static final String DOWNLOAD_AUTOCAD = "1444";
    @RBEntry("下载帮助文件")
    public static final String DOWNLOAD_HELP_FILES = "1445";
    @RBEntry("语言")
    public static final String DOWNLOAD_LANGUAGES = "1446";
    @RBEntry("英语")
    public static final String DOWNLOAD_ENGLISH = "1447";
    @RBEntry("日语")
    public static final String DOWNLOAD_JAPANESE = "1448";
    @RBEntry("法语")
    public static final String DOWNLOAD_FRENCH = "1449";
    @RBEntry("韩语")
    public static final String DOWNLOAD_KOREAN = "1450";
    @RBEntry("德语")
    public static final String DOWNLOAD_GERMAN = "1451";
    @RBEntry("繁体中文")
    public static final String DOWNLOAD_CHINESE_TRADITIONAL = "1452";
    @RBEntry("意大利语")
    public static final String DOWNLOAD_ITALIAN = "1453";
    @RBEntry("简体中文")
    public static final String DOWNLOAD_CHINESE_SIMPLIFIED = "1454";
    @RBEntry("西班牙语")
    public static final String DOWNLOAD_SPANISH = "1455";
    @RBEntry("安装目录")
    public static final String DOWNLOAD_INSTALLATION_DIRECTORY = "1456";
    @RBEntry("下载大小")
    public static final String DOWNLOAD_SIZE = "1457";
    @RBEntry("下载进度")
    public static final String DOWNLOAD_PROGRESS = "1458";
    @RBEntry("正在安装")
    public static final String DOWNLOAD_INSTALLING = "1459";
    @RBEntry("安装")
    public static final String DOWNLOAD_INSTALL = "1460";
    @RBEntry("取消")
    public static final String DOWNLOAD_CANCEL = "1461";
    @RBEntry("重新安装")
    public static final String DOWNLOAD_REINSTALL = "1462";
    @RBEntry("升级")
    public static final String DOWNLOAD_UPGRADE = "1463";
    @RBEntry("完整安装程序的下载位置")
    public static final String DOWNLOAD_DOWNLOAD_FROM = "1464";
    @RBEntry("此处")
    public static final String DOWNLOAD_HERE = "1465";
    @RBEntry("如果下载和安装失败则可执行此操作。.exe 文件可以自动运行，也可以先下载，稍后再运行。")
    public static final String DOWNLOAD_MSI_FILE = "1466";
    @RBEntry("安装 Creo View 客户端")
    public static final String DOWNLOAD_INSTALL_PVLITE = "1467";
    @RBEntry("安装 Creo View Standard")
    public static final String DOWNLOAD_INSTALL_STANDARD = "1468";
    @RBEntry("安装已完成")
    public static final String DOWNLOAD_INSTALLATION_FINISHED = "1469";
    @RBEntry("选项")
    public static final String DOWNLOAD_OPTIONS = "1470";
    @RBEntry("单击此处可下载完整安装程序")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM = "1471";
    @RBEntry("俄语")
    public static final String DOWNLOAD_RUSSIAN = "1472";
    @RBEntry("导入筛选器")
    public static final String DOWNLOAD_IMPORTFILTERS = "1473";
    @RBEntry("许可证位置")
    public static final String LICENSE_LOCATION = "1474";
    @RBEntry("葡萄牙语 (巴西)")
    public static final String DOWNLOAD_PORTUGUESE_BRAZILIAN = "1475";
    @RBEntry("安装 Creo View ECAD")
    public static final String DOWNLOAD_INSTALL_PVECAD = "1480";
    @RBEntry("下载 Creo View ECAD")
    public static final String DOWNLOAD_PRODUCTVIEW_ECAD = "1481";
    @RBEntry("Creo View ECAD Compare")
    public static final String DOWNLOAD_PVECADCOMPARE = "1482";
    @RBEntry("Creo View ECAD Validate")
    public static final String DOWNLOAD_PVVALIDATE = "1483";
    @RBEntry("欢迎访问 {0} 的 Creo View ECAD 安装页面")
    public static final String DOWNLOAD_ECAD_WELCOME_FOR = "1484";
    @RBEntry("单击此处可下载附加 Creo View ECAD 适配器安装程序")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_ECAD_ADAPTERS_FROM = "1485";
    @RBEntry("结果 - CAD 文档")
    public static final String RESULTS_CAD_DOCUMENTS = "1501";
    @RBEntry("结果 - 部件")
    public static final String RESULTS_PARTS = "1502";
    @RBEntry("结果 - 文档")
    public static final String RESULTS_DOCUMENTS = "1503";
    @RBEntry("结果 - 未知类型")
    public static final String RESULTS_UNKNOWN_TYPE = "1504";
    @RBEntry("{2}:{0}  - {1}")
    public static final String RESULTS_OF = "1505";
    @RBEntry("上一页")
    public static final String RESULTS_PREVIOUS = "1506";
    @RBEntry("下一页")
    public static final String RESULTS_NEXT = "1507";
    @RBEntry("全部")
    public static final String RESULTS_All = "1508";
    @RBEntry("添加至剪贴板")
    public static final String RESULTS_COPY_ALL = "1509";
    @RBEntry("全部添加到剪贴板")
    public static final String RESULTS_COPY_ALL_TIP = "1510";
    @RBEntry("全部删除")
    public static final String RESULTS_DELETE_ALL = "1511";
    @RBEntry("全部删除")
    public static final String RESULTS_DELETE_ALL_TIP = "1512";
    @RBEntry("显示所有缩略图")
    public static final String RESULTS_SHOW_ALL_THUMBNAILS = "1513";
    @RBEntry("显示所有缩略图")
    public static final String RESULTS_SHOW_ALL_THUMBNAILS_TIP = "1514";
    @RBEntry("结果 - 产品实例")
    public static final String RESULTS_PRODUCT_INSTANCES = "1515";
    @RBEntry("结果 - 产品配置")
    public static final String RESULTS_PRODUCT_CONFIGURATIONS = "1516";
    @RBEntry("类型")
    public static final String RESULTS_DOC_TYPE = "1521";
    @RBEntry("所有者应用程序:")
    public static final String RESULTS_OWNER_APP = "1522";
    @RBEntry("作者应用程序:")
    public static final String RESULTS_AUTHOR_APP = "1523";
    @RBEntry("状态")
    public static final String RESULTS_STATE = "1524";
    @RBEntry("视图")
    public static final String RESULTS_VIEW = "1525";
    @RBEntry("类型")
    public static final String RESULTS_TYPE = "1526";
    @RBEntry("源")
    public static final String RESULTS_SOURCE = "1527";
    @RBEntry("生命周期")
    public static final String RESULTS_LIFECYCLE = "1528";
    @RBEntry("团队")
    public static final String RESULTS_PROJECT = "1529";
    @RBEntry("位置")
    public static final String RESULTS_LOCATION = "1530";
    @RBEntry("说明")
    public static final String RESULTS_DESCRIPTION = "1531";
    @RBEntry("删除")
    public static final String RESULTS_DELETE_TIP = "1532";
    @RBEntry("显示缩略图")
    public static final String RESULTS_SHOW_THUMBNAIL_TIP = "1533";
    @RBEntry("隐藏缩略图")
    public static final String RESULTS_HIDE_THUMBNAIL_TIP = "1534";
    @RBEntry("配置名称")
    public static final String RESULTS_CONFIGURATION_NAME = "1535";
    @RBEntry("序列号")
    public static final String RESULTS_SERIAL_NUMBER = "1536";
    @RBEntry("产品编号")
    public static final String RESULTS_PRODUCT_NUMBER = "1537";
    @RBEntry("产品名称")
    public static final String RESULTS_PRODUCT_NAME = "1538";
    @RBEntry("可视化集合")
    public static final String CB_TITLE = "1601";
    @RBEntry("可视化集合")
    public static final String CB_HEADING = "1602";
    @RBEntry("全部打开")
    public static final String CB_VIEW_ALL = "1603";
    @RBEntry("在 Creo View 中全部打开")
    public static final String CB_VIEW_ALL_TIP = "1604";
    @RBEntry("全部移除")
    public static final String CB_DELETE_ALL = "1605";
    @RBEntry("从可视化集合全部移除")
    public static final String CB_DELETE_ALL_TIP = "1606";
    @RBEntry("自可视化集合内移除")
    public static final String CB_DELETE_TIP = "1607";
    @RBEntry("全部打印")
    public static final String CB_PRINT_ALL = "1608";
    @RBEntry("通过 Creo View 全部批量打印")
    public static final String CB_PRINT_ALL_TIP = "1609";
    @RBEntry("表示名称")
    public static final String CB_REP_NAME_HEADING = "1610";
    @RBEntry("选定项不是可视项")
    public static final String CB_NOTHING_VIEWABLE = "1611";
    @RBEntry("表示")
    public static final String REP_TITLE = "1701";
    @RBEntry("{0} 的表示 ")
    public static final String REP_HEADING = "1702";
    @RBEntry("新建表示")
    public static final String REP_CREATE = "1703";
    @RBEntry("新建表示")
    public static final String REP_CREATE_TIP = "1704";
    @RBEntry("名称")
    public static final String REP_NAME = "1705";
    @RBEntry("说明")
    public static final String REP_DESCRIPTION = "1706";
    @RBEntry("其他详细信息")
    public static final String REP_CONFIG_SPEC = "1707";
    @RBEntry("创建日期")
    public static final String REP_DATE_CREATED = "1708";
    @RBEntry("刷新列表")
    public static final String REP_REFRESH = "1709";
    @RBEntry("刷新表示列表")
    public static final String REP_REFRESH_TIP = "1710";
    @RBEntry("从剪贴板粘贴")
    public static final String REP_PASTE = "1711";
    @RBEntry("从剪贴板粘贴表示")
    public static final String REP_PASTE_TIP = "1712";
    @RBEntry("全部复制到剪贴板")
    public static final String REP_COPY_ALL = "1713";
    @RBEntry("全部复制到剪贴板")
    public static final String REP_COPY_ALL_TIP = "1714";
    @RBEntry("为重新发布设置表示")
    public static final String REP_SENT_REPUBLISH = "1715";
    @RBEntry("无法发送表示供重新发布")
    public static final String REP_FAILED_REPUBLISH = "1716";
    @RBEntry("说明方表示")
    public static final String REP_DESCRIBED_BY = "1717";
    @RBEntry("粘贴选择对象")
    public static final String REP_PASTE_SELECT = "1718";
    @RBEntry("从剪贴板粘贴选择对象")
    public static final String REP_PASTE_SELECT_TIP = "1719";
    @RBEntry("已发布")
    public static final String VIEW_ALREADY_PUBLISHED = "1801";
    @RBEntry("发送至发布器")
    public static final String VIEW_SENT_TO_PUBLISHER = "1802";
    @RBEntry("批量打印")
    public static final String VIEW_BATCHPRINT = "1803";
    @RBEntry("Creo View")
    public static final String VIEW_PRODUCTVIEW = "1804";
    @RBEntry("正在加载...")
    public static final String VIEW_LOADING = "1805";
    @RBEntry("为作业状况选择 {0}WVS 作业监视器{1} ")
    public static final String VIEW_PUBLISH_MONITOR = "1806";
    @RBEntry("参加协作")
    public static final String VIEW_JOIN_COLLAB = "1807";
    @RBEntry("主机协作")
    public static final String VIEW_HOST_COLLAB = "1808";
    @RBEntry("可视化数据已过期")
    public static final String VIEW_OOD_TITLE = "1809";
    @RBEntry("被 {0} 标记的可视化数据 {1} 已过期")
    public static final String VIEW_OOD_MESSAGE = "1810";
    @RBEntry("{0} 继续 {1} 查看操作")
    public static final String VIEW_OOD_CONTINUE = "1811";
    @RBEntry("不发布已经标注的数据")
    public static final String MARKED_NOT_PUBLISHABLE = "1812";
    @RBEntry("不进行发布操作")
    public static final String NO_PUBLISHING = "1813";
    @RBEntry("可视浏览")
    public static final String VIEW_VISUAL_NAVIGATION = "1814";
    @RBEntry("您将要关闭“可视浏览查看器”窗口。")
    public static final String VIEW_EXIT_VISUAL_NAVIGATION = "1815";
    @RBEntry("已过期的详细信息")
    public static final String VIEW_OODDET_TITLE = "1850";
    @RBEntry("表示 {0} 的已过期详细信息")
    public static final String VIEW_OODDET_HEADING = "1851";
    @RBEntry("记录表示已过期的对象")
    public static final String VIEW_OODDET_OBJECTS = "1852";
    @RBEntry("正在启动 Creo View 客户端")
    public static final String STARTING_CREO_VIEW_CLIENT = "1853";
    @RBEntry("注意: 必须以已进行身份验证的同一用户对客户端进行身份验证。")
    public static final String CLIENT_AUTHENTICATE_SAME_USER = "1854";
    @RBEntry("可视化数据被标记为已过期。继续查看?")
    public static final String VIEW_OOD_MESSAGE_AND_CONTINUE = "1855";
    @RBEntry("已过期的详细信息...")
    public static final String VIEW_OODDET_BUTTON = "1856";
    @RBEntry("帮助")
    public static final String HLP_TITLE = "1901";
    @RBEntry("可视化帮助")
    public static final String HLP_HEADING = "1902";
    @RBEntry("图标定义")
    public static final String HLP_ICON_DEF = "1903";
    @RBEntry("图标")
    public static final String HLP_ICON = "1904";
    @RBEntry("说明")
    public static final String HLP_DESCRIPTION = "1905";
    @RBEntry("启动 Creo View")
    public static final String HLP_ICON_PV = "1906";
    @RBEntry("为了在 Creo View 中查看，可调用发布器处理数据")
    public static final String HLP_ICON_PUBLISH = "1907";
    @RBEntry("将数据添加至剪贴板")
    public static final String HLP_ICON_CLIP = "1908";
    @RBEntry("启动 Creo View 批量打印")
    public static final String HLP_ICON_PRINT = "1909";
    @RBEntry("显示 Creo View 表示表格")
    public static final String HLP_ICON_REP = "1910";
    @RBEntry("删除数据")
    public static final String HLP_ICON_DEL = "1911";
    @RBEntry("指明默认表示显示在列表和特性页面")
    public static final String HLP_ICON_DEFAULT = "1912";
    @RBEntry("将该表示设为默认")
    public static final String HLP_ICON_MAKE_DEFAULT = "1913";
    @RBEntry("显示 Creo View 注释和组的表格")
    public static final String HLP_ICON_MARKUP = "1914";
    @RBEntry("显示缩略图图像")
    public static final String HLP_ICON_DISPLAY_THUMBNAIL = "1915";
    @RBEntry("隐藏缩略图图像")
    public static final String HLP_ICON_HIDE_THUMBNAIL = "1916";
    @RBEntry("锁定注释或组")
    public static final String HLP_ICON_LOCK_MARKUP = "1917";
    @RBEntry("解锁注释或组")
    public static final String HLP_ICON_UNLOCK_MARKUP = "1918";
    @RBEntry("您可以从{0}此处{1}访问 Creo View 教程")
    public static final String HLP_TUTORIAL = "1931";
    @RBEntry("WVS 作业监视器")
    public static final String MON_TITLE = "2001";
    @RBEntry("自动刷新")
    public static final String MON_REFRESH = "2002";
    @RBEntry("{0} 的发布作业汇总")
    public static final String MON_SUMMARY_HEADING_FOR = "2010";
    @RBEntry("发布作业汇总")
    public static final String MON_SUMMARY_HEADING = "2011";
    @RBEntry("删除所有队列条目")
    public static final String MON_SUMMARY_DELETE_ALL_TIP = "2012";
    @RBEntry("全部删除")
    public static final String MON_SUMMARY_DELETE_ALL = "2013";
    @RBEntry("删除所有已完成的队列条目")
    public static final String MON_SUMMARY_DELETE_COMPLETED_TIP = "2014";
    @RBEntry("删除已完成的队列条目")
    public static final String MON_SUMMARY_DELETE_COMPLETED = "2015";
    @RBEntry("删除所有已完成的队列条目")
    public static final String MON_SUMMARY_DELETE_SUCCESSFUL_TIP = "2016";
    @RBEntry("删除成功")
    public static final String MON_SUMMARY_DELETE_SUCCESSFUL = "2017";
    @RBEntry("刷新列表")
    public static final String MON_SUMMARY_REFRESH_LIST = "2018";
    @RBEntry("刷新作业汇总列表")
    public static final String MON_SUMMARY_REFRESH_LIST_TIP = "2019";
    @RBEntry("发布统计信息")
    public static final String MON_SUMMARY_STATISTICS = "2020";
    @RBEntry("发布统计汇总信息")
    public static final String MON_SUMMARY_STATISTICS_TIP = "2021";
    @RBEntry("发布作业详细信息")
    public static final String MON_JOB_HEADING = "2051";
    @RBEntry("刷新")
    public static final String MON_JOB_REFRESH_LIST = "2052";
    @RBEntry("刷新作业详细信息")
    public static final String MON_JOB_REFRESH_LIST_TIP = "2053";
    @RBEntry("仅显示失败的")
    public static final String MON_ONLY_FAILED_JOBS = "2054";
    @RBEntry("作业统计信息")
    public static final String MON_STAT_HEADING = "2060";
    @RBEntry("{0} 的作业统计信息")
    public static final String MON_STAT_HEADING_FOR = "2061";
    @RBEntry("工作汇总统计信息")
    public static final String MON_STAT_SUMMARY_HEADING = "2062";
    @RBEntry("{0} 的工作汇总统计信息")
    public static final String MON_STAT_SUMMARY_HEADING_FOR = "2063";
    @RBEntry("筛选依据:")
    public static final String MON_STAT_FILTER_ON = "2064";
    @RBEntry("作业提交日期")
    public static final String MON_STAT_FILTER_SUBMIT = "2065";
    @RBEntry("作业开始日期")
    public static final String MON_STAT_FILTER_START = "2066";
    @RBEntry("作业结束日期")
    public static final String MON_STAT_FILTER_END = "2067";
    @RBEntry("开始日期:")
    public static final String MON_STAT_FROM_DATE = "2068";
    @RBEntry("截止日期:")
    public static final String MON_STAT_TO_DATE = "2069";
    @RBEntry("显示汇总统计信息")
    public static final String MON_STAT_DISPLAY_SUMMARY = "2070";
    @RBEntry("保存统计信息")
    public static final String MON_STAT_SAVE_CSV = "2071";
    @RBEntry("将特定阶段的作业统计信息另存为 CSV 文件")
    public static final String MON_STAT_SAVE_CSV_TIP = "2072";
    @RBEntry("创作应用程序")
    public static final String MON_STAT_DATA_TYPE = "2073";
    @RBEntry("工作器类型")
    public static final String MON_STAT_WORKER_TYPE = "2074";
    @RBEntry("作业总计")
    public static final String MON_STAT_TOTAL_JOBS = "2075";
    @RBEntry("成功的作业")
    public static final String MON_STAT_SUCCESSFUL_JOBS = "2076";
    @RBEntry("失败的作业")
    public static final String MON_STAT_FAILED_JOBS = "2077";
    @RBEntry("% 作业成功")
    public static final String MON_STAT_PERCENT_SUCCESSFUL_JOBS = "2078";
    @RBEntry("% 作业失败")
    public static final String MON_STAT_PERCENT_FAILED_JOBS = "2079";
    @RBEntry("工作器利用率")
    public static final String MON_STAT_WORKER_UTILIZATION = "2080";
    @RBEntry("工作器名称")
    public static final String MON_STAT_WORKER_NAME = "2081";
    @RBEntry("忙碌时间")
    public static final String MON_STAT_BUSY_TIME = "2082";
    @RBEntry("新建表示")
    public static final String CR_TITLE = "2101";
    @RBEntry("表示 \"{0}\"已经存在。")
    public static final String CR_ALREADY_EXISTS = "2102";
    @RBEntry("新建表示")
    public static final String CR_HEADING = "2103";
    @RBEntry("步骤")
    public static final String CR_STEPS = "2104";
    @RBEntry("输入表示详细信息")
    public static final String CR_SPECIFY_NAME = "2105";
    @RBEntry("设置 EPM 配置规范")
    public static final String CR_SET_CONFIG_SPEC = "2106";
    @RBEntry("选取结构类型")
    public static final String CR_SET_STRUCTURE_TYPE = "2107";
    @RBEntry("确认选择")
    public static final String CR_REVIEW_OPTIONS = "2108";
    @RBEntry("汇总")
    public static final String CR_COMPLETE = "2109";
    @RBEntry("完成")
    public static final String CR_FINISH = "2110";
    @RBEntry("取消")
    public static final String CR_CANCEL = "2111";
    @RBEntry("下一页 ")
    public static final String CR_NEXT = "2112";
    @RBEntry(" 上一页")
    public static final String CR_BACK = "2113";
    @RBEntry("提交发布作业")
    public static final String CR_SUBMIT_PUBLISH_JOB = "2114";
    @RBEntry("关闭")
    public static final String CR_CLOSE = "2115";
    @RBEntry("选取输入源")
    public static final String CR_SPECIFY_EDZ = "2116";
    @RBEntry("请输入表示的名称和说明，确认新的表示是否要作为默认表示。")
    public static final String CR_NAME_HEADING = "2121";
    @RBEntry("名称:")
    public static final String CR_NAME = "2122";
    @RBEntry("说明:")
    public static final String CR_DESCRIPTION = "2123";
    @RBEntry("设为默认表示")
    public static final String CR_SET_AS_DEFAULT = "2124";
    @RBEntry("设置 EPM 配置规范，用于创建表示。设置完成时，请单击 \"下一页\" 按钮，该设置将自动作为默认设置用于所有新表示，这些表示是在该会话内通过用户界面创建的。")
    public static final String CR_CS_HEADING = "2131";
    @RBEntry("最新")
    public static final String CR_CS_LATEST = "2132";
    @RBEntry("基线")
    public static final String CR_CS_BASELINE = "2133";
    @RBEntry("生命周期")
    public static final String CR_CS_LIFECYCLE = "2134";
    @RBEntry("入夹")
    public static final String CR_CS_FOLDERED = "2135";
    @RBEntry("有效性")
    public static final String CR_CS_EFFECTIVITY = "2136";
    @RBEntry("默认值")
    public static final String CR_CS_DEFAULT = "2137";
    @RBEntry("原存储")
    public static final String CR_CS_AS_STORED = "2138";
    @RBEntry("若要创建表示，指定 {0} 是可选的。")
    public static final String CR_STRUCT_HEADING1 = "2140";
    @RBEntry("选取结构类型，用于创建表示。")
    public static final String CR_STRUCT_HEADING = "2141";
    @RBEntry("仅 EPM")
    public static final String CR_STRUCT_EPM_ONLY = "2142";
    @RBEntry("EPM 加其他部件(默认部件配置规范)")
    public static final String CR_STRUCT_EPM_PLUS_PARTS = "2143";
    @RBEntry("选取输入源，用于创建表示。")
    public static final String CR_EDZ_HEADING = "2144";
    @RBEntry("本机文件名:")
    public static final String CR_EDZ_NAME = "2145";
    @RBEntry("生成缩略图")
    public static final String CR_GENERATE_THUMBNAIL = "2146";
    @RBEntry("(例如，PVZ、ZIP、JAR、OL、PLT、HPGL、DWG、DXF、CC、CCZ 或 CAD 文件)")
    public static final String CR_EDZ_TYPES = "2147";
    @RBEntry("上载文件 ...")
    public static final String CR_UPLOADING_FILE = "2148";
    @RBEntry("请选择一个文件来创建表示")
    public static final String CR_NO_FILE_SPECIFIED = "2149";
    @RBEntry("请选择一个带有可用扩展名的文件")
    public static final String CR_INVALID_EXTENSION = "2150";
    @RBEntry("请审阅您已经作出的选择")
    public static final String CR_REVIEW_HEADING = "2151";
    @RBEntry("名称:")
    public static final String CR_REVIEW_NAME = "2152";
    @RBEntry("说明:")
    public static final String CR_REVIEW_DESCRIPTION = "2153";
    @RBEntry("默认值:")
    public static final String CR_REVIEW_DEFAULT = "2154";
    @RBEntry("配置规范:")
    public static final String CR_REVIEW_CONFIG_SPEC = "2155";
    @RBEntry("结构类型:")
    public static final String CR_REVIEW_STRUCT_TYPE = "2156";
    @RBEntry("无")
    public static final String CR_STRUCT_NONE = "2157";
    @RBEntry("仅限部件(默认部件配置规范)")
    public static final String CR_STRUCT_PART_ONLY = "2158";
    @RBEntry("部件和 EPM")
    public static final String CR_STRUCT_PART_AND_EPM = "2159";
    @RBEntry("将作业提交给发布器以创建新的表示 {0}")
    public static final String CR_JOB_SUBMITTED = "2161";
    @RBEntry("请求中缺少表单字段 \"文件名\"")
    public static final String CR_FILENAME_FIELD_MISSING = "2162";
    @RBEntry("丢失可表示对象参考 (会话已经超时连接了吗?)")
    public static final String CR_OBJREF_MISSING = "2163";
    @RBEntry("未上载文件数据，文件不能为零长度或者不存在。")
    public static final String CR_ZERO_SIZE_FILE = "2164";
    @RBEntry("部件结构 (默认的配置规范)")
    public static final String CR_PART_STRUCTURE = "2165";
    @RBEntry("本机数据")
    public static final String CR_CONVERTED_DATA = "2166";
    @RBEntry("CAD 类型 / 名称:")
    public static final String CR_CAD_TYPE_NAME = "2167";
    @RBEntry("如果在 ZIP 或JAR 文件内含有多个 CAD 文件，则必须指定顶级 CAD 文件的名称。{0} 如果  ZIP 或 JAR 文件内只包含一个 CAD 文件， 则可选择“确定”以继续操作。")
    public static final String CR_CAD_SPECIFY_TOP_LEVEL = "2168";
    @RBEntry("剪贴板 (表示/可视项 {0}、注释和组 {1})")
    public static final String CR_CLIPBOARD = "2169";
    @RBEntry("文档内容:")
    public static final String CR_DOCUMENT_CONTENT = "2170";
    @RBEntry("文档内不包含任何可发布的文件")
    public static final String CR_NO_DOCUMENT_FILE_SPECIFIED = "2171";
    @RBEntry("可以通过 {0} 发布监视器 {1} 监视该作业的进度。")
    public static final String CR_JOB_SUBMITTED1 = "2172";
    @RBEntry("部件结构 (指定的配置规范)")
    public static final String CR_PART_STRUCTURE_CONFIG_SPEC = "2173";
    @RBEntry("作为定位装配发布")
    public static final String CR_PUBLISH_AS_POS_ASSY = "2174";
    @RBEntry("不作为定位装配发布")
    public static final String CR_DO_NOT_PUBLISH_AS_POS_ASSY = "2175";
    @RBEntry("作为扩展定位装配发布")
    public static final String CR_PUBLISH_AS_XPOS_ASSY = "2176";
    @RBEntry("不作为扩展定位装配发布")
    public static final String CR_DO_NOT_PUBLISH_AS_XPOS_ASSY = "2177";
    @RBEntry("作为不同的扩展定位装配发布")
    public static final String CR_PUBLISH_AS_DIFFERENT_XPOS_ASSY = "2178";
    @RBEntry("注释和组")
    public static final String MARKUP_TITLE = "2201";
    @RBEntry("注释和组 - {0}")
    public static final String MARKUP_HEADING = "2202";
    @RBEntry("全部删除")
    public static final String MARKUP_DELETE = "2203";
    @RBEntry("删除所有注释和组")
    public static final String MARKUP_DELETE_TIP = "2204";
    @RBEntry("名称")
    public static final String MARKUP_NAME = "2205";
    @RBEntry("说明")
    public static final String MARKUP_DESCRIPTION = "2206";
    @RBEntry("锁定者")
    public static final String MARKUP_LOCKEDBY = "2207";
    @RBEntry("所有者")
    public static final String MARKUP_OWNER = "2208";
    @RBEntry("上次修改时间")
    public static final String MARKUP_LAST_UPDATED = "2209";
    @RBEntry("类型")
    public static final String MARKUP_TYPE = "2210";
    @RBEntry("刷新列表")
    public static final String MARKUP_REFRESH = "2211";
    @RBEntry("刷新注释和组列表")
    public static final String MARKUP_REFRESH_TIP = "2212";
    @RBEntry("注释")
    public static final String MARKUP_ANNOTATION = "2213";
    @RBEntry("批注")
    public static final String MARKUP_MARKUP = "2214";
    @RBEntry("未知")
    public static final String MARKUP_UNKNOWN = "2215";
    @RBEntry("表示")
    public static final String MARKUP_REPRESENTATIONS = "2216";
    @RBEntry("从剪贴板粘贴")
    public static final String MARKUP_PASTE = "2217";
    @RBEntry("从剪贴板粘贴注释 / 组")
    public static final String MARKUP_PASTE_TIP = "2218";
    @RBEntry("全部复制到剪贴板")
    public static final String MARKUP_COPY_ALL = "2219";
    @RBEntry("将所有注释 / 组复制至剪贴板")
    public static final String MARKUP_COPY_ALL_TIP = "2220";
    @RBEntry("副本转发")
    public static final String MARKUP_COPYFORWARD = "2221";
    @RBEntry("不转发副本")
    public static final String MARKUP_NO_COPYFORWARD = "2222";
    @RBEntry("粘贴选择对象")
    public static final String MARKUP_PASTE_SELECT = "2223";
    @RBEntry("从剪贴板粘贴选择对象")
    public static final String MARKUP_PASTE_SELECT_TIP = "2224";
    @RBEntry("保存表示")
    public static final String SAVE_ZIP_TITLE = "2301";
    @RBEntry("保存表示")
    public static final String SAVE_ZIP_HEADING = "2302";
    @RBEntry("包括注释和组")
    public static final String SAVE_ZIP_INCLUDE_ANNOTATIONS = "2303";
    @RBEntry("文件类型:")
    public static final String SAVE_ZIP_FILE_TYPE = "2304";
    @RBEntry("ZIP/PVZ/EDZ")
    @RBPseudo(false)
    public static final String SAVE_ZIP_TYPE_ZIP = "2305";
    @RBEntry("JAR")
    @RBPseudo(false)
    public static final String SAVE_ZIP_TYPE_JAR = "2306";
    @RBEntry("保存 ...")
    public static final String SAVE_ZIP_SAVE = "2307";
    @RBEntry("确定是否要保存这个表示")
    public static final String SAVE_ZIP_HOW_SAVE = "2308";
    @RBEntry("将表示另存为一个文件")
    public static final String SAVE_ZIP_AS_FILE = "2309";
    @RBEntry("将表示保存为一个链接")
    public static final String SAVE_ZIP_AS_LINK = "2310";
    @RBEntry("请指定保存文件的格式")
    public static final String SAVE_ZIP_SPECIFY_FORMAT = "2311";
    @RBEntry("您要使用哪一种格式的链接来开启表示法？")
    public static final String SAVE_ZIP_LINK_WHICH_FORMAT = "2312";
    @RBEntry("显示为一个活动超链接")
    public static final String SAVE_ZIP_LINK_ACTIVE = "2313";
    @RBEntry("显示为文本字段内的文本")
    public static final String SAVE_ZIP_LINK_TEXT = "2314";
    @RBEntry("在主体内生成一个带有超链接的电子邮件")
    public static final String SAVE_ZIP_LINK_EMAIL = "2315";
    @RBEntry("若要复制下列链接，请单击鼠标器的右键，自显示的残单内选取复制操作")
    public static final String SAVE_ZIP_LINK_ACTIVE_HEADING = "2316";
    @RBEntry("在 Creo View 中打开表示 {0} ")
    public static final String SAVE_ZIP_LINK_ACTIVE_MSG = "2317";
    @RBEntry("若要复制下列链接，在文本字段内选择文本，使用系统的复制/粘贴功能")
    public static final String SAVE_ZIP_LINK_TEXT_HEADING = "2318";
    @RBEntry("选择下列链接，默认的电子邮件应用程序将会启动一个窗口，以结束电子邮件的撰写")
    public static final String SAVE_ZIP_LINK_EMAIL_HEADING = "2319";
    @RBEntry("电子邮件链接至表示 {0}")
    public static final String SAVE_ZIP_LINK_EMAIL_MSG = "2320";
    @RBEntry("管理")
    public static final String ADMIN_TITLE = "8001";
    @RBEntry("管理任务 ")
    public static final String ADMIN_HEADING = "8002";
    @RBEntry("工作器代理监视器")
    public static final String ADMIN_CAD_AGENT = "8003";
    @RBEntry("发布安排程序")
    public static final String ADMIN_SCHEDULER = "8004";
    @RBEntry("关闭")
    public static final String ADMIN_CLOSE = "8005";
    @RBEntry("发布和缩略图管理")
    public static final String ADMIN_VETO = "8006";
    @RBEntry("由 Creo View 配置管理的服务器")
    public static final String ADMIN_PVCONFIG = "8007";
    @RBEntry("此上下文已具有配置。一个上下文只允许有一个配置。")
    public static final String ADMIN_MULTIPLE_CONFIG_WARNING = "ADMIN_MULTIPLE_CONFIG_WARNING";
    @RBEntry("工作器代理管理")
    public static final String CAD_TITLE = "8101";
    @RBEntry("配置")
    public static final String CAD_CONFIGURE = "8102";
    @RBEntry("关闭")
    public static final String CAD_CLOSE = "8103";
    @RBEntry("工作器代理管理")
    public static final String CAD_HEADING = "8104";
    @RBEntry("全部启动")
    public static final String CAD_START_ALL = "8105";
    @RBEntry("启动所有工作器")
    public static final String CAD_START_ALL_TIP = "8106";
    @RBEntry("全部停止")
    public static final String CAD_STOP_ALL = "8107";
    @RBEntry("停止所有工作器和工作器监视器")
    public static final String CAD_STOP_ALL_TIP = "8108";
    @RBEntry("重新加载")
    public static final String CAD_RELOAD = "8109";
    @RBEntry("重新加载工作器代理配置文件")
    public static final String CAD_RELOAD_TIP = "8110";
    @RBEntry("工作器")
    public static final String CAD_WORKER = "8111";
    @RBEntry("状况")
    public static final String CAD_STATUS = "8112";
    @RBEntry("操作")
    public static final String CAD_ACTION = "8113";
    @RBEntry("作业")
    public static final String CAD_JOB = "8114";
    @RBEntry("数量")
    public static final String CAD_NUMBER = "8115";
    @RBEntry("日期")
    public static final String CAD_DATE = "8116";
    @RBEntry("工作器代理返回了错误")
    public static final String CAD_ERROR = "8117";
    @RBEntry("自动刷新")
    public static final String CAD_AUTO_REFRESH = "8118";
    @RBEntry("忙碌,打开,关闭,可用,启动失败")
    public static final String CAD_STATES = "8119";
    @RBEntry("启动工作器")
    public static final String CAD_START = "8120";
    @RBEntry("停止工作器")
    public static final String CAD_STOP = "8121";
    @RBEntry("可执行文件未设置")
    public static final String CAD_EXE_NOT_SET = "CAD_EXE_NOT_SET";
    @RBEntry("可执行文件不安全")
    public static final String CAD_EXE_NOT_SAFE = "CAD_EXE_NOT_SAFE";
    @RBEntry("代理或工作器")
    public static final String CAD_AGENTWORKER = "8122";
    @RBEntry("在线")
    public static final String CAD_ONLINE = "8123";
    @RBEntry("使工作器离线")
    public static final String CAD_MAKE_OFFLINE = "8124";
    @RBEntry("使工作器在线")
    public static final String CAD_MAKE_ONLINE = "8125";
    @RBEntry("刷新列表")
    public static final String CAD_REFRESH = "8126";
    @RBEntry("刷新工作器列表")
    public static final String CAD_REFRESH_TIP = "8127";
    @RBEntry("测试工作器")
    public static final String CAD_TEST_WORKER = "8128";
    @RBEntry("工作器测试")
    public static final String CAD_TEST_TITLE = "8129";
    @RBEntry("开始工作器测试")
    public static final String CAD_TEST_START = "8130";
    @RBEntry("工作器测试已完成，但有错误")
    public static final String CAD_TEST_ERROR = "8131";
    @RBEntry("工作器测试已完成")
    public static final String CAD_TEST_END = "8132";
    @RBEntry("查看工作器日志文件")
    public static final String CAD_LOG_WORKER = "8133";
    @RBEntry("工作器日志文件")
    public static final String CAD_LOG_TITLE = "8134";
    @RBEntry("工作器 {1} 的工作器日志文件 {0}")
    public static final String CAD_LOG_HEADING = "8135";
    @RBEntry("工作器日志文件")
    public static final String CAD_LOGFILES_TITLE = "8136";
    @RBEntry("工作器 {0} 的日志文件")
    public static final String CAD_LOGFILES_HEADING = "8137";
    @RBEntry("刷新列表")
    public static final String CAD_LOGFILES_REFRESH = "8138";
    @RBEntry("刷新日志文件列表")
    public static final String CAD_LOGFILES_REFRESH_TIP = "8139";
    @RBEntry("日志文件")
    public static final String CAD_LOGFILES_FILE = "8140";
    @RBEntry("文件大小")
    public static final String CAD_LOGFILES_SIZE = "8141";
    @RBEntry("创建时间")
    public static final String CAD_LOGFILES_ATIME = "8142";
    @RBEntry("上次修改时间")
    public static final String CAD_LOGFILES_MTIME = "8143";
    @RBEntry("不可用")
    public static final String CAD_NOT_AVAILABLE = "8144";
    @RBEntry("启动详细工作器")
    public static final String CAD_START_IN_DEBUG = "8145";
    @RBEntry("启动工作器监视器")
    public static final String CAD_STOP_MONITOR = "8146";
    @RBEntry("排程作业")
    public static final String SCH_TITLE = "8201";
    @RBEntry("关闭")
    public static final String SCH_CLOSE = "8202";
    @RBEntry("已安排作业")
    public static final String SCH_LIST_HEADING = "8203";
    @RBEntry("队列")
    public static final String SCH_QUEUE = "8204";
    @RBEntry("名称")
    public static final String SCH_NAME = "8205";
    @RBEntry("说明")
    public static final String SCH_DESCRIPTION = "8206";
    @RBEntry("开始日期")
    public static final String SCH_START_DATE = "8207";
    @RBEntry("下一个日期")
    public static final String SCH_NEXT_DATE = "8208";
    @RBEntry("将要运行")
    public static final String SCH_TO_BE_RUN = "8209";
    @RBEntry("计数")
    public static final String SCH_COUNT = "8210";
    @RBEntry("频率")
    public static final String SCH_FREQUENCY = "8211";
    @RBEntry("类")
    public static final String SCH_CLASS = "8212";
    @RBEntry("方法")
    public static final String SCH_METHOD = "8213";
    @RBEntry("作业")
    public static final String SCH_PUBLISH = "8214";
    @RBEntry("完毕,一次,完成,日,小时,分钟")
    public static final String SCH_STATES = "8215";
    @RBEntry("已完成")
    public static final String SCH_STATES_COMPLETED = "8215A";
    @RBEntry("完成")
    public static final String SCH_STATES_DONE = "8215B";
    @RBEntry("已安排 {0} 的作业")
    public static final String SCH_LIST_HEADING_FOR = "8216";
    @RBEntry("{0} 的排程作业")
    public static final String SCH_HEADING_FOR = "8220";
    @RBEntry("排程作业")
    public static final String SCH_HEADING = "8221";
    @RBEntry("队列:")
    public static final String SCH_IN_QUEUE = "8222";
    @RBEntry("名称:")
    public static final String SCH_IN_NAME = "8223";
    @RBEntry("说明:")
    public static final String SCH_IN_DESCRIPTION = "8224";
    @RBEntry("作业:")
    public static final String SCH_IN_PUBLISH = "8225";
    @RBEntry("开始作业:")
    public static final String SCH_IN_START = "8226";
    @RBEntry("年")
    public static final String SCH_IN_YEAR = "8227";
    @RBEntry("月")
    public static final String SCH_IN_MONTH = "8228";
    @RBEntry("日")
    public static final String SCH_IN_DAY = "8229";
    @RBEntry("时")
    public static final String SCH_IN_HOUR = "8230";
    @RBEntry("分")
    public static final String SCH_IN_MINUTES = "8231";
    @RBEntry("立刻")
    public static final String SCH_IN_IMMEDIATE = "8233";
    @RBEntry("作业频率:")
    public static final String SCH_IN_FREQUENCY = "8234";
    @RBEntry("只一次")
    public static final String SCH_IN_ONCE = "8235";
    @RBEntry("排程")
    public static final String SCH_IN_SCHEDULE = "8236";
    @RBEntry("关闭")
    public static final String SCH_IN_CLOSE = "8237";
    @RBEntry("在")
    public static final String SCH_IN_ON = "8238";
    @RBEntry("每")
    public static final String SCH_IN_EVERY = "8239";
    @RBEntry("选择任务")
    public static final String SCH_SELECT_TASK = "8240";
    @RBEntry("必须指定频率")
    public static final String SCH_SPECIFY_FREQUENCY = "8241";
    @RBEntry("必须指定有效的频率天数")
    public static final String SCH_SPECIFY_VALID_DAY = "8242";
    @RBEntry("指定的日期无效")
    public static final String SCH_INVALID_DATE = "8243";
    @RBEntry("必须指定一个名称")
    public static final String SCH_SPECIFY_NAME = "8244";
    @RBEntry("天")
    public static final String SCH_IN_EVERY_DAY = "8245";
    @RBEntry("时")
    public static final String SCH_IN_EVERY_HOUR = "8246";
    @RBEntry("分")
    public static final String SCH_IN_EVERY_MINUTES = "8247";
    @RBEntry("只创建日志文件")
    public static final String SCH_LOG_FILE_ONLY = "8248";
    @RBEntry("状况")
    public static final String SCH_CURRENT_STATUS = "8249";
    @RBEntry("刷新列表")
    public static final String SCH_REFRESH = "8250";
    @RBEntry("刷新已安排作业列表")
    public static final String SCH_REFRESH_TIP = "8251";
    @RBEntry("排程作业日志")
    public static final String SCH_JOB_LOG = "8252";
    @RBEntry("上下文")
    public static final String SCH_CONTAINER = "8253";
    @RBEntry("作业类型:")
    public static final String SCH_IN_JOB_TYPE = "8254";
    @RBEntry("使用最新小版本:")
    public static final String CLASH_DEFINITION_LATEST = "8255";
    @RBEntry("干涉检测定义:")
    public static final String CLASH_DEFINITION_PICKER = "8256";
    @RBEntry("删除早于以下时间的作业:")
    public static final String DELETE_COMPLETE_JOBS_DAYS_PICKER = "8259";
    @RBEntry("请输入一个有效的数。")
    public static final String VALIDATE_DELETE_COMPLETE_JOBS_DAYS_PICKER = "8260";
    @RBEntry("天")
    public static final String DAYS = "8261";
    @RBEntry("搜索")
    public static final String CLASH_DEFINITION_PICKER_BUTTON = "8257";
    @RBEntry("请在提交前选择一个干涉检测定义")
    public static final String CLASH_DEFINITION_PICKER_VALIDATOR = "8258";
    @RBEntry("协作会话")
    public static final String COLLAB_TITLE = "8301";
    @RBEntry("可视协作会话")
    public static final String COLLAB_HEADING = "8302";
    @RBEntry("启动会话")
    public static final String COLLAB_CREATE = "8303";
    @RBEntry("启动新的可视协作会话")
    public static final String COLLAB_CREATE_TIP = "8304";
    @RBEntry("刷新列表")
    public static final String COLLAB_REFRESH = "8305";
    @RBEntry("刷新可视协作会话列表")
    public static final String COLLAB_REFRESH_TIP = "8306";
    @RBEntry("会话所有者")
    public static final String COLLAB_OWNER = "8307";
    @RBEntry("用户")
    public static final String COLLAB_USERS = "8308";
    @RBEntry("说明")
    public static final String COLLAB_DESCRIPTION = "8309";
    @RBEntry("服务器字符串")
    public static final String COLLAB_STRING = "8310";
    @RBEntry("清除主管的")
    public static final String COLLAB_CLEAR_ACTIVE = "8311";
    @RBEntry("从 Windchill 会话中清除主管的可视协作。")
    public static final String COLLAB_CLEAR_ACTIVE_TIP = "8312";
    @RBEntry("您正在主持一个可视协作会话，加载 Creo View 的数据将被共享。")
    public static final String COLLAB_WARNING = "8313";
    @RBEntry("启动协作会话")
    public static final String COLLAB_NEW_TITLE = "8401";
    @RBEntry("启动可视协作会话")
    public static final String COLLAB_NEW_HEADING = "8402";
    @RBEntry("说明:")
    public static final String COLLAB_NEW_DESCRIPTION = "8403";
    @RBEntry("密码:")
    public static final String COLLAB_NEW_PASS = "8404";
    @RBEntry("确认密码:")
    public static final String COLLAB_NEW_CONFIRM_PASS = "8405";
    @RBEntry("确定")
    public static final String COLLAB_NEW_OK = "8406";
    @RBEntry("取消")
    public static final String COLLAB_NEW_CANCEL = "8407";
    @RBEntry("密码不同，请重新输入。")
    public static final String COLLAB_NEW_UNMATCHED_PASS = "8408";
    @RBEntry(" % 字符不能用于说明或密码。")
    public static final String COLLAB_NEW_NO_PERCENT = "8409";
    @RBEntry("启动一个新的协作会话，指定说明和密码是可选操作。")
    public static final String COLLAB_NEW_SUBHEADING = "8410";
    @RBEntry("启动协作会话的操作失败。请向管理员查询，确认在系统内已经安装和配置了协作代理。")
    public static final String COLLAB_FAILED_TO_START = "8411";
    @RBEntry("确定")
    public static final String UL_OK = "8501";
    @RBEntry("取消")
    public static final String UL_CANCEL = "8502";
    @RBEntry("更新位置")
    public static final String UL_UPDATE_LOCATION = "8503";
    @RBEntry("无法完成定位，您可能需要关闭浏览器窗口")
    public static final String UL_UPDATE_COMPLETE = "8504";
    @RBEntry("复制/粘贴的位置字符串来自 Creo View '位置' 特性值")
    public static final String UL_COPY_PASTE = "8505";
    @RBEntry("重新生成缩略图:")
    public static final String UL_REGENERATE_THUMBNAIL = "8506";
    @RBEntry("正在保存...")
    public static final String UL_SAVING = "8507";
    @RBEntry("发布和缩略图管理")
    public static final String VETO_TITLE = "8601";
    @RBEntry("发布和缩略图管理")
    public static final String VETO_HEADING = "8602";
    @RBEntry("关闭")
    public static final String VETO_CLOSE = "8603";
    @RBEntry("添加")
    public static final String VETO_ADD = "8604";
    @RBEntry("编号:")
    public static final String VETO_NUMBER = "8605";
    @RBEntry("名称:")
    public static final String VETO_NAME = "8606";
    @RBEntry("查找")
    public static final String VETO_FIND = "8607";
    @RBEntry("仅禁止缩略图的创建")
    public static final String VETO_THUMBNAIL_ONLY = "8608";
    @RBEntry("发布受控制的对象")
    public static final String VETO_LIST_HEADING = "8609";
    @RBEntry("编号")
    public static final String VETO_LIST_NUMBER = "8610";
    @RBEntry("名称")
    public static final String VETO_LIST_NAME = "8611";
    @RBEntry("版本")
    public static final String VETO_LIST_VERSION = "8612";
    @RBEntry("控制类型")
    public static final String VETO_LIST_TYPE = "8613";
    @RBEntry("发布")
    public static final String VETO_LIST_TYPE_PUBLISH = "8614";
    @RBEntry("缩略图")
    public static final String VETO_LIST_TYPE_THUMBNAIL = "8615";
    @RBEntry("删除发布控制")
    public static final String VETO_DELETE_TIP = "8616";
    @RBEntry("说明:")
    public static final String VETO_DESCRIPTION = "8617";
    @RBEntry("说明")
    public static final String VETO_LIST_DESCRIPTION = "8618";
    @RBEntry("全部")
    public static final String VETO_LIST_ALL = "8619";
    @RBEntry("未添加发布控制 (检查编号)")
    public static final String VETO_NO_ADD = "8620";
    @RBEntry("为 {0} 发布受控制的对象")
    public static final String VETO_LIST_HEADING_FOR = "8621";
    @RBEntry("{0} 的发布和缩略图管理")
    public static final String VETO_HEADING_FOR = "8622";
    @RBEntry("搜索...")
    public static final String VETO_BROWSE = "8623";
    @RBEntry("搜索 CAD 文档")
    public static final String VETO_SEARCH_CAD = "8624";
    @RBEntry("在 {0} 内搜索 CAD 文档 / 动态文档")
    public static final String VETO_SEARCH_CAD_FOR = "8625";
    @RBEntry("搜索")
    public static final String VETO_SEARCH = "8627";
    @RBEntry("未找到对象")
    public static final String VETO_SEARCH_NO_ITEMS_FOUND = "8628";
    @RBEntry("上下文")
    public static final String VETO_LIST_CONTAINER = "8629";
    @RBEntry("定位装配")
    public static final String VETO_LIST_TYPE_POSASSY = "8630";
    @RBEntry("作为定位装配发布")
    public static final String VETO_POSASSY = "8631";
    @RBEntry("禁止发布")
    public static final String VETO_PUBLISH = "8632";
    @RBEntry("未添加发布控制 (检查 CAD 文档是否可以作为定位装配发布)")
    public static final String VETO_NO_ADD_POSASSY = "8633";
    @RBEntry("未添加发布控制 (检查 CAD 文档是否可以作为扩展定位装配发布)")
    public static final String VETO_NO_ADD_EXED_POSASSY = "8633B";
    @RBEntry("扩展定位装配 [{0}]")
    public static final String VETO_LIST_TYPE_XPOSASSY = "8634";
    @RBEntry("作为扩展定位装配发布")
    public static final String VETO_XPOSASSY = "8635";
    @RBEntry("未能添加发布控制，必须针对扩展定位装配指定 CAD 表单名。")
    public static final String VETO_NO_ADD_XPOSASSY = "8636";
    @RBEntry("Creo View 配置")
    public static final String PVCONFIG_TITLE = "8701";
    @RBEntry("{0} 的 Creo View 配置")
    public static final String PVCONFIG_LIST_HEADING = "8702";
    @RBEntry("创建配置")
    public static final String PVCONFIG_NEW = "8703";
    @RBEntry("创建一个新的 Creo View 配置")
    public static final String PVCONFIG_NEW_TIP = "8704";
    @RBEntry("配置类型")
    public static final String PVCONFIG_NAME = "8705";
    @RBEntry("上下文")
    public static final String PVCONFIG_CONTEXT = "8706";
    @RBEntry("删除  Creo View  配置")
    public static final String PVCONFIG_DELETE_CONFIG_TIP = "8707";
    @RBEntry("{0} 文件")
    public static final String PVCONFIG_CONTENT_LIST_HEADING = "8708";
    @RBEntry("将文件添加至配置")
    public static final String PVCONFIG_NEW_FILE = "8709";
    @RBEntry("将新文件添加至配置")
    public static final String PVCONFIG_NEW_FILE_TIP = "8710";
    @RBEntry("文件名")
    public static final String PVCONFIG_FILE_NAME = "8711";
    @RBEntry("将文件自配置内删除")
    public static final String PVCONFIG_DELETE_CONTENT_TIP = "8712";
    @RBEntry("添加新文件")
    public static final String PVCONFIG_NEW_FILE_HEADING = "8713";
    @RBEntry("取消")
    public static final String PVCONFIG_CANCEL = "8714";
    @RBEntry("添加文件")
    public static final String PVCONFIG_ADD_FILE = "8715";
    @RBEntry("创建")
    public static final String PVCONFIG_CREATE = "8716";
    @RBEntry("请求中缺少表单字段 \"文件名\"")
    public static final String PVCONFIG_FILENAME_FIELD_MISSING = "8717";
    @RBEntry("缺少 WVSConfigurationTemplate 对象参考")
    public static final String PVCONFIG_OBJREF_MISSING = "8718";
    @RBEntry("请选择一个要添加至配置的文件")
    public static final String PVCONFIG_NO_FILE_SPECIFIED = "8719";
    @RBEntry("添加文件至配置的操作失败")
    public static final String PVCONFIG_FAILED_TO_ADD_FILE = "8720";
    @RBEntry("未上载文件数据，文件不能为零长度或者不存在。")
    public static final String PVCONFIG_ZERO_SIZE_FILE = "8721";
    @RBEntry("在该配置内，一个带有同样名称的文件已经存在")
    public static final String PVCONFIG_ALREADY_FILE = "8722";
    @RBEntry("文件名:")
    public static final String PVCONFIG_INPUT_FILE_NAME = "8723";
    @RBEntry("文件大小")
    public static final String PVCONFIG_FILE_SIZE = "8724";
    @RBEntry("配置类型:")
    public static final String PVCONFIG_INPUT_NAME = "8725";
    @RBEntry("创建新配置")
    public static final String PVCONFIG_CREATE_NEW = "8726";
    @RBEntry("默认类型")
    public static final String PVCONFIG_DEFAULT_TYPE = "8727";
    @RBEntry("在该配置内没有文件")
    public static final String PVCONFIG_NO_FILES = "8728";
    @RBEntry("为 {0} 创建新配置")
    public static final String PVCONFIG_CREATE_NEW_FOR = "8729";
    @RBEntry("文件")
    public static final String PVCONFIG_CONTENT_LIST_TITLE = "8730";
    @RBEntry("该上下文没有配置")
    public static final String PVCONFIG_NO_CONFIGS = "8731";
    @RBEntry("可以选择指定类型，如果用户具备所查看对象的修改权限，该选项即可提供一个不同的配置。请参见特性 \"productview.modifyconfigtype\"。")
    public static final String PVCONFIG_INPUT_NAME_HEADING = "8732";
    @RBEntry("可指定单个文件，也可指定包含一组文件的单个 zip/jar 文件。")
    public static final String PVCONFIG_INPUT_FILE_NAME_HEADING = "8733";
    @RBEntry("操作系统为Windows10、Windows11 ，请下载安装程序")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM_NEW = "8734";
    @RBEntry("操作系统为Windows7 ，请下载安装程序")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM_NEWCX = "8735";
    @RBEntry(".exe 文件可以自动运行，也可以先下载，稍后再运行。")
    public static final String DOWNLOAD_MSI_FILE_NEW = "8736";
    public messageResource_zh_CN() {
    }
}
