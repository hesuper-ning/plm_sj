//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.wvs.client.beans;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.wvs.client.beans.messageResource")
public final class messageResource extends WTListResourceBundle {
    @RBEntry("Windchill Visualization")
    public static final String WINDCHILL_VISUALIZATION = "1001";
    @RBEntry("Help")
    public static final String HELP = "1002";
    @RBEntry("Visualization")
    public static final String VISUALIZATION = "1003";
    @RBEntry("Close")
    public static final String WINDOW_CLOSE = "1004";
    @RBEntry("Cancel")
    public static final String WINDOW_CANCEL = "1005";
    @RBEntry("OK")
    public static final String WINDOW_OK = "1006";
    @RBEntry("Learn")
    public static final String LEARN = "1007";
    @RBEntry("Thumbnail")
    public static final String THUMBNAIL = "1009";
    @RBEntry("Type")
    public static final String TYPE = "1010";
    @RBEntry("Number")
    public static final String NUMBER = "1011";
    @RBEntry("Name")
    public static final String NAME = "1012";
    @RBEntry("Version")
    public static final String VERSION = "1013";
    @RBEntry("Iteration")
    public static final String ITERATION = "1014";
    @RBEntry("Actions")
    public static final String ACTIONS = "1015";
    @RBEntry("Preferences")
    public static final String PREFERENCES = "1016";
    @RBEntry("Not Supported")
    public static final String NOTSUPPORTED = "1017";
    @RBEntry("Creo View Client Edition currently does not support the viewing of this data")
    public static final String NOTSUPPORTED_DESCRIPTION = "1018";
    @RBEntry("Creo View Client Edition currently does not support the viewing of Markups and Sequences")
    public static final String NOTSUPPORTED_DESCRIPTION1 = "1019";
    @RBEntry("Creo View Client Edition currently is not supported on UNIX")
    public static final String NOTSUPPORTED_DESCRIPTION2 = "1020";
    @RBEntry("Creo View Client Edition currently does not support the batch print facility")
    public static final String NOTSUPPORTED_DESCRIPTION3 = "1021";
    @RBEntry("Creo View Client Edition currently is not available when using a Netscape 6 browser")
    public static final String NOTSUPPORTED_DESCRIPTION4 = "1022";
    @RBEntry("Creo View Client Edition has not been installed.")
    public static final String PVLITE_NOT_INSTALLED = "1023";
    @RBEntry("True")
    public static final String TRUE = "1030";
    @RBEntry("False")
    public static final String FALSE = "1031";
    @RBEntry("Yes")
    public static final String YES = "1032";
    @RBEntry("No")
    public static final String NO = "1033";
    @RBEntry("Apply")
    public static final String WINDOW_APPLY = "1034";
    @RBEntry("(Secured information)")
    public static final String SECURED_INFORMATION = "1035";
    @RBEntry("&lt;Windchill")
    public static final String GOTO_WINDCHILL = "1101";
    @RBEntry("Home")
    public static final String HOME = "1102";
    @RBEntry("Shared root")
    public static final String CLIPBOARD = "1103";
    @RBEntry("WVS Job Monitor")
    public static final String PUBLISH_MONITOR = "1104";
    @RBEntry("Administrator")
    public static final String ADMINISTRATOR = "1105";
    @RBEntry("Collaboration")
    public static final String COLLABORATION = "1106";
    @RBEntry("Search on:")
    public static final String QUERY_SEARCH_ON = "1201";
    @RBEntry("Number:")
    public static final String QUERY_NUMBER = "1202";
    @RBEntry("Name:")
    public static final String QUERY_NAME = "1203";
    @RBEntry("View:")
    public static final String QUERY_VIEW = "1204";
    @RBEntry("Version:")
    public static final String QUERY_VERSION = "1205";
    @RBEntry("Type:")
    public static final String QUERY_TYPE = "1206";
    @RBEntry("Source:")
    public static final String QUERY_SOURCE = "1207";
    @RBEntry("State:")
    public static final String QUERY_STATE = "1208";
    @RBEntry("Team:")
    public static final String QUERY_PROJECT = "1209";
    @RBEntry("Cabinet:")
    public static final String QUERY_CABINET = "1210";
    @RBEntry("Iterations:")
    public static final String QUERY_ITERATIONS = "1211";
    @RBEntry("Latest")
    public static final String QUERY_LATEST = "1212";
    @RBEntry("All")
    public static final String QUERY_ALL = "1213";
    @RBEntry("Long list:")
    public static final String QUERY_LONG_LIST = "1214";
    @RBEntry("Doc type:")
    public static final String QUERY_DOC_TYPE = "1215";
    @RBEntry("Owner app:")
    public static final String QUERY_OWNER_APP = "1216";
    @RBEntry("Author app:")
    public static final String QUERY_AUTHOR_APP = "1217";
    @RBEntry("Sort by:")
    public static final String SORT_BY = "1218";
    @RBEntry("Keyword:")
    public static final String QUERY_KEYWORD = "1219";
    @RBEntry("Description:")
    public static final String QUERY_DESCRIPTION = "1220";
    @RBEntry("Part")
    public static final String QUERY_PART = "1231";
    @RBEntry("CAD Document")
    public static final String QUERY_CAD_DOCUMENT = "1232";
    @RBEntry("Document")
    public static final String QUERY_DOCUMENT = "1233";
    @RBEntry("Product Configuration")
    public static final String QUERY_PRODUCT_CONFIGURATION = "1234";
    @RBEntry("Product Instance")
    public static final String QUERY_PRODUCT_INSTANCE = "1235";
    @RBEntry("Config name:")
    public static final String QUERY_CONFIGURATION_NAME = "1236";
    @RBEntry("Product number:")
    public static final String QUERY_PRODUCT_NUMBER = "1237";
    @RBEntry("Product name:")
    public static final String QUERY_PRODUCT_NAME = "1238";
    @RBEntry("Serial number:")
    public static final String QUERY_SERIAL_NUMBER = "1239";
    @RBEntry("Search")
    public static final String QUERY_SEARCH = "1241";
    @RBEntry("Visualization is Not Enabled")
    public static final String VIS_NOT_ENABLED = "1301";
    @RBEntry("Can you see the {0} Creo View logo above?")
    public static final String CAN_YOU_SEE = "1302";
    @RBEntry("{0}Click here{1} to install Creo View")
    public static final String CLICK_HERE = "1303";
    @RBEntry("It appears that Creo View is not installed")
    public static final String PV_NOT_INSTALLED = "1305";
    @RBEntry("The Creo View ActiveX control is installed, but not the Creo View client")
    public static final String PV_ONLY_OCX_INSTALLED = "1306";
    @RBEntry(" Creo View Installation")
    public static final String DOWNLOAD_PRODUCTVIEW = "1401";
    @RBEntry("Welcome to the Creo View Installation Page")
    public static final String DOWNLOAD_WELCOME = "1402";
    @RBEntry("It appears that you are using a platform that has no Creo View download available, please contact your system administrator")
    public static final String DOWNLOAD_IT_APEARS = "1403";
    @RBEntry("Welcome to the Creo View installation page for {0}")
    public static final String DOWNLOAD_WELCOME_FOR = "1404";
    @RBEntry("Your browser was checked, and it appears that Creo View is not installed.")
    public static final String DOWNLOAD_BROWSER_CHECKED = "1405";
    @RBEntry("If you are a first time Windchill Visualization user, you need to install Creo View.")
    public static final String DOWNLOAD_FIRST_TIME_USER = "1406";
    @RBEntry("Follow the six steps below to perform the installation.")
    public static final String DOWNLOAD_SIX_STEPS = "1407";
    @RBEntry("Please review all the steps before you begin.")
    public static final String DOWNLOAD_REVIEW_STEPS = "1408";
    @RBEntry("Download the Creo View setup program {0}")
    public static final String DOWNLOAD_CLICK_HERE = "1409";
    @RBEntry("When Internet Explorer asks you what you want to do with this file, select \"Run this program from its current location\".")
    public static final String DOWNLOAD_WHEN_IE = "1410";
    @RBEntry("The Creo View setup program will download and start automatically.")
    public static final String DOWNLOAD_START_AUTOMATICALLY = "1411";
    @RBEntry("Choose a folder where Internet Explorer can save the setup program.")
    public static final String DOWNLOAD_FOLDER_IE = "1412";
    @RBEntry("Choose a folder where the browser can save the setup program.")
    public static final String DOWNLOAD_FOLDER_NS = "1413";
    @RBEntry("Run the setup program (double-click on the file).")
    public static final String DOWNLOAD_RUN_SETUP_WIN = "1414";
    @RBEntry("Extract files from the setup program (uncompress and untar the file to a directory)")
    public static final String DOWNLOAD_RUN_SETUP_UNIX = "1415";
    @RBEntry("Follow the directions in the setup program to complete the installation.")
    public static final String DOWNLOAD_FOLLOW_DIRECTIONS = "1416";
    @RBEntry("After setup is complete, register Creo View with your browser by clicking {0}here{1}.")
    public static final String DOWNLOAD_AFTER_SETUP = "1417";
    @RBEntry("Creo View is now ready to use.")
    public static final String DOWNLOAD_PRODUCTVIEW_READY = "1418";
    @RBEntry("Follow your system administrators directions to complete the installation.")
    public static final String DOWNLOAD_FOLLOW_DIRECTIONS_UNIX = "1419";
    @RBEntry("No Creo View download has been made available for your platform, please contact your system administrator")
    public static final String DOWNLOAD_NO_PRODUCTVIEW = "1420";
    @RBEntry("After setup is complete, restart your browser.")
    public static final String DOWNLOAD_AFTER_SETUP_RESTART = "1421";
    @RBEntry("Visualization - Finish Creo View Upgrade")
    public static final String DOWNLOAD_FINISH_TITLE = "1431";
    @RBEntry("Finish Creo View Upgrade")
    public static final String DOWNLOAD_FINISH_HEADING = "1432";
    @RBEntry("Thank you for taking the time to upgrade to the latest version of Creo View.")
    public static final String DOWNLOAD_FINISH_THANK_YOU = "1433";
    @RBEntry("When the setup program completes, Creo View is ready to use.")
    public static final String DOWNLOAD_FINISH_COMPLETE = "1434";
    @RBEntry("Additional Downloads")
    public static final String DOWNLOAD_ADDITIONAL_DOWNLOADS = "1435";
    @RBEntry("Done")
    public static final String DOWNLOAD_DONE = "1436";
    @RBEntry("Installed")
    public static final String DOWNLOAD_INSTALLED = "1437";
    @RBEntry("Installation Failed - errorCode {0}. {1} contains downloaded files and log file")
    public static final String DOWNLOAD_INSTALLATION_FAILED = "1438";
    @RBEntry("{0} Files {1}Mb")
    public static final String DOWNLOAD_FILES = "1440";
    @RBEntry("Installation of Creo View is not supported on this platform.")
    public static final String DOWNLOAD_PVLITE_NOT_SUPPORTED = "1442";
    @RBEntry("Creo View Client")
    public static final String DOWNLOAD_PVLITE = "1443";
    @RBEntry("AutoCAD Viewers")
    public static final String DOWNLOAD_AUTOCAD = "1444";
    @RBEntry("Download Help Files")
    public static final String DOWNLOAD_HELP_FILES = "1445";
    @RBEntry("Languages")
    public static final String DOWNLOAD_LANGUAGES = "1446";
    @RBEntry("English")
    public static final String DOWNLOAD_ENGLISH = "1447";
    @RBEntry("Japanese")
    public static final String DOWNLOAD_JAPANESE = "1448";
    @RBEntry("French")
    public static final String DOWNLOAD_FRENCH = "1449";
    @RBEntry("Korean")
    public static final String DOWNLOAD_KOREAN = "1450";
    @RBEntry("German")
    public static final String DOWNLOAD_GERMAN = "1451";
    @RBEntry("Chinese Traditional")
    public static final String DOWNLOAD_CHINESE_TRADITIONAL = "1452";
    @RBEntry("Italian")
    public static final String DOWNLOAD_ITALIAN = "1453";
    @RBEntry("Chinese Simplified")
    public static final String DOWNLOAD_CHINESE_SIMPLIFIED = "1454";
    @RBEntry("Spanish")
    public static final String DOWNLOAD_SPANISH = "1455";
    @RBEntry("Installation Directory")
    public static final String DOWNLOAD_INSTALLATION_DIRECTORY = "1456";
    @RBEntry("Download Size")
    public static final String DOWNLOAD_SIZE = "1457";
    @RBEntry("Download Progress")
    public static final String DOWNLOAD_PROGRESS = "1458";
    @RBEntry("Installing")
    public static final String DOWNLOAD_INSTALLING = "1459";
    @RBEntry("Install")
    public static final String DOWNLOAD_INSTALL = "1460";
    @RBEntry("Cancel")
    public static final String DOWNLOAD_CANCEL = "1461";
    @RBEntry("ReInstall")
    public static final String DOWNLOAD_REINSTALL = "1462";
    @RBEntry("Upgrade")
    public static final String DOWNLOAD_UPGRADE = "1463";
    @RBEntry("A complete installer can be downloaded from")
    public static final String DOWNLOAD_DOWNLOAD_FROM = "1464";
    @RBEntry("here")
    public static final String DOWNLOAD_HERE = "1465";
    @RBEntry("This can be used if the download and installation fails. The .exe file may be run automatically or downloaded and run at a later date.")
    public static final String DOWNLOAD_MSI_FILE = "1466";
    @RBEntry("Install Creo View Client")
    public static final String DOWNLOAD_INSTALL_PVLITE = "1467";
    @RBEntry("Install Creo View Standard")
    public static final String DOWNLOAD_INSTALL_STANDARD = "1468";
    @RBEntry("Installation Finished")
    public static final String DOWNLOAD_INSTALLATION_FINISHED = "1469";
    @RBEntry("Options")
    public static final String DOWNLOAD_OPTIONS = "1470";
    @RBEntry("Click here to download a complete installer")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM = "1471";
    @RBEntry("Russian")
    public static final String DOWNLOAD_RUSSIAN = "1472";
    @RBEntry("Import Filters")
    public static final String DOWNLOAD_IMPORTFILTERS = "1473";
    @RBEntry("License Location")
    public static final String LICENSE_LOCATION = "1474";
    @RBEntry("Portuguese (Brazil)")
    public static final String DOWNLOAD_PORTUGUESE_BRAZILIAN = "1475";
    @RBEntry("Install Creo View ECAD")
    public static final String DOWNLOAD_INSTALL_PVECAD = "1480";
    @RBEntry("Download Creo View ECAD")
    public static final String DOWNLOAD_PRODUCTVIEW_ECAD = "1481";
    @RBEntry("Creo View ECAD Compare")
    public static final String DOWNLOAD_PVECADCOMPARE = "1482";
    @RBEntry("Creo View ECAD Validate")
    public static final String DOWNLOAD_PVVALIDATE = "1483";
    @RBEntry("Welcome to the Creo View ECAD Installation page for {0}")
    public static final String DOWNLOAD_ECAD_WELCOME_FOR = "1484";
    @RBEntry("Click here to download the additional Creo View ECAD Adapters installer ")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_ECAD_ADAPTERS_FROM = "1485";
    @RBEntry("Results - CAD Documents")
    public static final String RESULTS_CAD_DOCUMENTS = "1501";
    @RBEntry("Results - Parts")
    public static final String RESULTS_PARTS = "1502";
    @RBEntry("Results - Documents")
    public static final String RESULTS_DOCUMENTS = "1503";
    @RBEntry("Results - Unknown Type")
    public static final String RESULTS_UNKNOWN_TYPE = "1504";
    @RBEntry("{0}-{1} of {2}")
    public static final String RESULTS_OF = "1505";
    @RBEntry("Previous")
    public static final String RESULTS_PREVIOUS = "1506";
    @RBEntry("Next")
    public static final String RESULTS_NEXT = "1507";
    @RBEntry("All")
    public static final String RESULTS_All = "1508";
    @RBEntry("Add to Clipboard")
    public static final String RESULTS_COPY_ALL = "1509";
    @RBEntry("Add All to Clipboard")
    public static final String RESULTS_COPY_ALL_TIP = "1510";
    @RBEntry("Delete all")
    public static final String RESULTS_DELETE_ALL = "1511";
    @RBEntry("Delete all")
    public static final String RESULTS_DELETE_ALL_TIP = "1512";
    @RBEntry("Show all thumbnails")
    public static final String RESULTS_SHOW_ALL_THUMBNAILS = "1513";
    @RBEntry("Show all thumbnails")
    public static final String RESULTS_SHOW_ALL_THUMBNAILS_TIP = "1514";
    @RBEntry("Results - Product Instances")
    public static final String RESULTS_PRODUCT_INSTANCES = "1515";
    @RBEntry("Results - Product Configurations")
    public static final String RESULTS_PRODUCT_CONFIGURATIONS = "1516";
    @RBEntry("Type")
    public static final String RESULTS_DOC_TYPE = "1521";
    @RBEntry("Owner App")
    public static final String RESULTS_OWNER_APP = "1522";
    @RBEntry("Author App")
    public static final String RESULTS_AUTHOR_APP = "1523";
    @RBEntry("State")
    public static final String RESULTS_STATE = "1524";
    @RBEntry("View")
    public static final String RESULTS_VIEW = "1525";
    @RBEntry("Type")
    public static final String RESULTS_TYPE = "1526";
    @RBEntry("Source")
    public static final String RESULTS_SOURCE = "1527";
    @RBEntry("Lifecycle")
    public static final String RESULTS_LIFECYCLE = "1528";
    @RBEntry("Team")
    public static final String RESULTS_PROJECT = "1529";
    @RBEntry("Location")
    public static final String RESULTS_LOCATION = "1530";
    @RBEntry("Description")
    public static final String RESULTS_DESCRIPTION = "1531";
    @RBEntry("Delete")
    public static final String RESULTS_DELETE_TIP = "1532";
    @RBEntry("Show thumbnail")
    public static final String RESULTS_SHOW_THUMBNAIL_TIP = "1533";
    @RBEntry("Hide thumbnail")
    public static final String RESULTS_HIDE_THUMBNAIL_TIP = "1534";
    @RBEntry("Configuration Name")
    public static final String RESULTS_CONFIGURATION_NAME = "1535";
    @RBEntry("Serial Number")
    public static final String RESULTS_SERIAL_NUMBER = "1536";
    @RBEntry("Product Number")
    public static final String RESULTS_PRODUCT_NUMBER = "1537";
    @RBEntry("Product Name")
    public static final String RESULTS_PRODUCT_NAME = "1538";
    @RBEntry("Visualization Collection")
    public static final String CB_TITLE = "1601";
    @RBEntry("Visualization Collection")
    public static final String CB_HEADING = "1602";
    @RBEntry("Open all")
    public static final String CB_VIEW_ALL = "1603";
    @RBEntry("Open all in Creo View")
    public static final String CB_VIEW_ALL_TIP = "1604";
    @RBEntry("Remove all")
    public static final String CB_DELETE_ALL = "1605";
    @RBEntry("Remove all from visualization collection")
    public static final String CB_DELETE_ALL_TIP = "1606";
    @RBEntry("Remove from visualization collection")
    public static final String CB_DELETE_TIP = "1607";
    @RBEntry("Print all")
    public static final String CB_PRINT_ALL = "1608";
    @RBEntry("Batch print all with Creo View")
    public static final String CB_PRINT_ALL_TIP = "1609";
    @RBEntry("Representation Name")
    public static final String CB_REP_NAME_HEADING = "1610";
    @RBEntry("No Selected Items are Viewable")
    public static final String CB_NOTHING_VIEWABLE = "1611";
    @RBEntry("Representations")
    public static final String REP_TITLE = "1701";
    @RBEntry("Representations for {0}")
    public static final String REP_HEADING = "1702";
    @RBEntry("New Representation")
    public static final String REP_CREATE = "1703";
    @RBEntry("New Representation")
    public static final String REP_CREATE_TIP = "1704";
    @RBEntry("Name")
    public static final String REP_NAME = "1705";
    @RBEntry("Description")
    public static final String REP_DESCRIPTION = "1706";
    @RBEntry("Additional Details")
    public static final String REP_CONFIG_SPEC = "1707";
    @RBEntry("Date Created")
    public static final String REP_DATE_CREATED = "1708";
    @RBEntry("Refresh list")
    public static final String REP_REFRESH = "1709";
    @RBEntry("Refresh representation list")
    public static final String REP_REFRESH_TIP = "1710";
    @RBEntry("Paste from Clipboard")
    public static final String REP_PASTE = "1711";
    @RBEntry("Paste Representations from Clipboard")
    public static final String REP_PASTE_TIP = "1712";
    @RBEntry("Copy All to Clipboard")
    public static final String REP_COPY_ALL = "1713";
    @RBEntry("Copy All to Clipboard")
    public static final String REP_COPY_ALL_TIP = "1714";
    @RBEntry("Sent representation for republishing")
    public static final String REP_SENT_REPUBLISH = "1715";
    @RBEntry("Failed to send representation for republishing")
    public static final String REP_FAILED_REPUBLISH = "1716";
    @RBEntry("Described By Representations")
    public static final String REP_DESCRIBED_BY = "1717";
    @RBEntry("Paste Selection")
    public static final String REP_PASTE_SELECT = "1718";
    @RBEntry("Paste Selection from Clipboard")
    public static final String REP_PASTE_SELECT_TIP = "1719";
    @RBEntry("Already Published")
    public static final String VIEW_ALREADY_PUBLISHED = "1801";
    @RBEntry("Sent To Publisher")
    public static final String VIEW_SENT_TO_PUBLISHER = "1802";
    @RBEntry("BatchPrint")
    public static final String VIEW_BATCHPRINT = "1803";
    @RBEntry("Creo View")
    public static final String VIEW_PRODUCTVIEW = "1804";
    @RBEntry("Loading...")
    public static final String VIEW_LOADING = "1805";
    @RBEntry("Select {0}WVS Job Monitor{1} for job status")
    public static final String VIEW_PUBLISH_MONITOR = "1806";
    @RBEntry("Join Collaboration")
    public static final String VIEW_JOIN_COLLAB = "1807";
    @RBEntry("Host Collaboration")
    public static final String VIEW_HOST_COLLAB = "1808";
    @RBEntry("Visualization Data Out Of Date")
    public static final String VIEW_OOD_TITLE = "1809";
    @RBEntry("This Visualization data is {0}marked out of date{1}")
    public static final String VIEW_OOD_MESSAGE = "1810";
    @RBEntry("{0}Continue{1} to View")
    public static final String VIEW_OOD_CONTINUE = "1811";
    @RBEntry("Data marked not to be published")
    public static final String MARKED_NOT_PUBLISHABLE = "1812";
    @RBEntry("No publishing will take place")
    public static final String NO_PUBLISHING = "1813";
    @RBEntry("Visual Navigation")
    public static final String VIEW_VISUAL_NAVIGATION = "1814";
    @RBEntry("You are closing the Visual Navigation Viewer window.")
    public static final String VIEW_EXIT_VISUAL_NAVIGATION = "1815";
    @RBEntry("Out Of Date Details")
    public static final String VIEW_OODDET_TITLE = "1850";
    @RBEntry("Out Of Date Details for Representation {0}")
    public static final String VIEW_OODDET_HEADING = "1851";
    @RBEntry("Objects recorded as marking this Representation out of date")
    public static final String VIEW_OODDET_OBJECTS = "1852";
    @RBEntry("Starting Creo View Client")
    public static final String STARTING_CREO_VIEW_CLIENT = "1853";
    @RBEntry("ATTENTION: Must authenticate client using the same authenticated Windchill user.")
    public static final String CLIENT_AUTHENTICATE_SAME_USER = "1854";
    @RBEntry("This Visualization data is marked out of date. Continue to view?")
    public static final String VIEW_OOD_MESSAGE_AND_CONTINUE = "1855";
    @RBEntry("Out Of Date Details...")
    public static final String VIEW_OODDET_BUTTON = "1856";
    @RBEntry("Help")
    public static final String HLP_TITLE = "1901";
    @RBEntry("Visualization Help")
    public static final String HLP_HEADING = "1902";
    @RBEntry("Icon Definitions")
    public static final String HLP_ICON_DEF = "1903";
    @RBEntry("Icon")
    public static final String HLP_ICON = "1904";
    @RBEntry("Description")
    public static final String HLP_DESCRIPTION = "1905";
    @RBEntry("Launches Creo View")
    public static final String HLP_ICON_PV = "1906";
    @RBEntry("Invokes the Publisher to process data for viewing in Creo View")
    public static final String HLP_ICON_PUBLISH = "1907";
    @RBEntry("Adds Data to the Clipboard")
    public static final String HLP_ICON_CLIP = "1908";
    @RBEntry("Launches Creo View batch Print")
    public static final String HLP_ICON_PRINT = "1909";
    @RBEntry("Displays the table of Creo View Representations")
    public static final String HLP_ICON_REP = "1910";
    @RBEntry("Deletes the data")
    public static final String HLP_ICON_DEL = "1911";
    @RBEntry("Indicates the default Representation shown on listings and property pages")
    public static final String HLP_ICON_DEFAULT = "1912";
    @RBEntry("Makes this Representation the default")
    public static final String HLP_ICON_MAKE_DEFAULT = "1913";
    @RBEntry("Displays the table of Creo View annotations and groups")
    public static final String HLP_ICON_MARKUP = "1914";
    @RBEntry("Displays the thumbnail image")
    public static final String HLP_ICON_DISPLAY_THUMBNAIL = "1915";
    @RBEntry("Hides the thumbnail image")
    public static final String HLP_ICON_HIDE_THUMBNAIL = "1916";
    @RBEntry("Locks the annotation or group")
    public static final String HLP_ICON_LOCK_MARKUP = "1917";
    @RBEntry("Un-locks the annotation or group")
    public static final String HLP_ICON_UNLOCK_MARKUP = "1918";
    @RBEntry("Creo View Tutorials may be accessed from {0}here{1}")
    public static final String HLP_TUTORIAL = "1931";
    @RBEntry("WVS Job Monitor")
    public static final String MON_TITLE = "2001";
    @RBEntry("Automatic refresh")
    public static final String MON_REFRESH = "2002";
    @RBEntry("Publish Job Summary for {0}")
    public static final String MON_SUMMARY_HEADING_FOR = "2010";
    @RBEntry("Publish Job Summary")
    public static final String MON_SUMMARY_HEADING = "2011";
    @RBEntry("Delete all queue entries")
    public static final String MON_SUMMARY_DELETE_ALL_TIP = "2012";
    @RBEntry("Delete all")
    public static final String MON_SUMMARY_DELETE_ALL = "2013";
    @RBEntry("Delete all completed queue entries")
    public static final String MON_SUMMARY_DELETE_COMPLETED_TIP = "2014";
    @RBEntry("Delete completed")
    public static final String MON_SUMMARY_DELETE_COMPLETED = "2015";
    @RBEntry("Delete all successfully completed queue entries")
    public static final String MON_SUMMARY_DELETE_SUCCESSFUL_TIP = "2016";
    @RBEntry("Delete successful")
    public static final String MON_SUMMARY_DELETE_SUCCESSFUL = "2017";
    @RBEntry("Refresh list")
    public static final String MON_SUMMARY_REFRESH_LIST = "2018";
    @RBEntry("Refresh job summary list")
    public static final String MON_SUMMARY_REFRESH_LIST_TIP = "2019";
    @RBEntry("Publishing statistics")
    public static final String MON_SUMMARY_STATISTICS = "2020";
    @RBEntry("Publishing statistics summary information")
    public static final String MON_SUMMARY_STATISTICS_TIP = "2021";
    @RBEntry("Publish Job Details")
    public static final String MON_JOB_HEADING = "2051";
    @RBEntry("Refresh")
    public static final String MON_JOB_REFRESH_LIST = "2052";
    @RBEntry("Refresh job detail information")
    public static final String MON_JOB_REFRESH_LIST_TIP = "2053";
    @RBEntry("Only show failed")
    public static final String MON_ONLY_FAILED_JOBS = "2054";
    @RBEntry("Job Statistics")
    public static final String MON_STAT_HEADING = "2060";
    @RBEntry("Job Statistics for {0}")
    public static final String MON_STAT_HEADING_FOR = "2061";
    @RBEntry("Job Summary Statistics")
    public static final String MON_STAT_SUMMARY_HEADING = "2062";
    @RBEntry("Job Summary Statistics for {0}")
    public static final String MON_STAT_SUMMARY_HEADING_FOR = "2063";
    @RBEntry("Filter on:")
    public static final String MON_STAT_FILTER_ON = "2064";
    @RBEntry("Job Submit Date")
    public static final String MON_STAT_FILTER_SUBMIT = "2065";
    @RBEntry("Job Start Date")
    public static final String MON_STAT_FILTER_START = "2066";
    @RBEntry("Job End Date")
    public static final String MON_STAT_FILTER_END = "2067";
    @RBEntry("From Date:")
    public static final String MON_STAT_FROM_DATE = "2068";
    @RBEntry("To Date:")
    public static final String MON_STAT_TO_DATE = "2069";
    @RBEntry("Display Summary Statistics")
    public static final String MON_STAT_DISPLAY_SUMMARY = "2070";
    @RBEntry("Save statistics")
    public static final String MON_STAT_SAVE_CSV = "2071";
    @RBEntry("Save job statistics for specified period as CSV file")
    public static final String MON_STAT_SAVE_CSV_TIP = "2072";
    @RBEntry("Authoring Application")
    public static final String MON_STAT_DATA_TYPE = "2073";
    @RBEntry("Worker Type")
    public static final String MON_STAT_WORKER_TYPE = "2074";
    @RBEntry("Total Jobs")
    public static final String MON_STAT_TOTAL_JOBS = "2075";
    @RBEntry("Successful Jobs")
    public static final String MON_STAT_SUCCESSFUL_JOBS = "2076";
    @RBEntry("Failed Jobs")
    public static final String MON_STAT_FAILED_JOBS = "2077";
    @RBEntry("% Successful Jobs")
    public static final String MON_STAT_PERCENT_SUCCESSFUL_JOBS = "2078";
    @RBEntry("% Failed Jobs")
    public static final String MON_STAT_PERCENT_FAILED_JOBS = "2079";
    @RBEntry("Worker Utilization")
    public static final String MON_STAT_WORKER_UTILIZATION = "2080";
    @RBEntry("Worker Name")
    public static final String MON_STAT_WORKER_NAME = "2081";
    @RBEntry("Busy Time")
    public static final String MON_STAT_BUSY_TIME = "2082";
    @RBEntry("New Representation")
    public static final String CR_TITLE = "2101";
    @RBEntry("Representation \"{0}\" Already Exists")
    public static final String CR_ALREADY_EXISTS = "2102";
    @RBEntry("New Representation")
    public static final String CR_HEADING = "2103";
    @RBEntry("Steps")
    public static final String CR_STEPS = "2104";
    @RBEntry("Enter representation details")
    public static final String CR_SPECIFY_NAME = "2105";
    @RBEntry("Set EPM configuration specification")
    public static final String CR_SET_CONFIG_SPEC = "2106";
    @RBEntry("Choose structure type")
    public static final String CR_SET_STRUCTURE_TYPE = "2107";
    @RBEntry("Confirm choices")
    public static final String CR_REVIEW_OPTIONS = "2108";
    @RBEntry("Summary")
    public static final String CR_COMPLETE = "2109";
    @RBEntry("Finish")
    public static final String CR_FINISH = "2110";
    @RBEntry("Cancel")
    public static final String CR_CANCEL = "2111";
    @RBEntry("Next ")
    public static final String CR_NEXT = "2112";
    @RBEntry(" Back")
    public static final String CR_BACK = "2113";
    @RBEntry("Submit Publish Job")
    public static final String CR_SUBMIT_PUBLISH_JOB = "2114";
    @RBEntry("Close")
    public static final String CR_CLOSE = "2115";
    @RBEntry("Choose input source")
    public static final String CR_SPECIFY_EDZ = "2116";
    @RBEntry("Enter the name and description of the representation.  Choose whether or not the new representation should become the default representation.")
    public static final String CR_NAME_HEADING = "2121";
    @RBEntry("Name:")
    public static final String CR_NAME = "2122";
    @RBEntry("Description:")
    public static final String CR_DESCRIPTION = "2123";
    @RBEntry("Set as default representation")
    public static final String CR_SET_AS_DEFAULT = "2124";
    @RBEntry("Set the EPM configuration specification to use for creating the representation.  Once set, by pressing \"Next\", this will be the default for any new Representations created from the user interface in this session.")
    public static final String CR_CS_HEADING = "2131";
    @RBEntry("Latest")
    public static final String CR_CS_LATEST = "2132";
    @RBEntry("Baseline")
    public static final String CR_CS_BASELINE = "2133";
    @RBEntry("Lifecycle")
    public static final String CR_CS_LIFECYCLE = "2134";
    @RBEntry("Foldered")
    public static final String CR_CS_FOLDERED = "2135";
    @RBEntry("Effectivity")
    public static final String CR_CS_EFFECTIVITY = "2136";
    @RBEntry("Default")
    public static final String CR_CS_DEFAULT = "2137";
    @RBEntry("As Stored")
    public static final String CR_CS_AS_STORED = "2138";
    @RBEntry("Optionally specify the {0} to create the representation for.")
    public static final String CR_STRUCT_HEADING1 = "2140";
    @RBEntry("Choose the type of structure to create the representation for.")
    public static final String CR_STRUCT_HEADING = "2141";
    @RBEntry("EPM only")
    public static final String CR_STRUCT_EPM_ONLY = "2142";
    @RBEntry("EPM plus additional parts (default part config spec)")
    public static final String CR_STRUCT_EPM_PLUS_PARTS = "2143";
    @RBEntry("Choose the input source to create the representation from.")
    public static final String CR_EDZ_HEADING = "2144";
    @RBEntry("Local file name:")
    public static final String CR_EDZ_NAME = "2145";
    @RBEntry("Generate thumbnail")
    public static final String CR_GENERATE_THUMBNAIL = "2146";
    @RBEntry("(for example, PVZ, ZIP, JAR, OL, PLT, HPGL, DWG, DXF, CC, CCZ, or a CAD file)")
    public static final String CR_EDZ_TYPES = "2147";
    @RBEntry("Uploading File ...")
    public static final String CR_UPLOADING_FILE = "2148";
    @RBEntry("Please select a file to create the Representation from")
    public static final String CR_NO_FILE_SPECIFIED = "2149";
    @RBEntry("Please select a file with a valid extension")
    public static final String CR_INVALID_EXTENSION = "2150";
    @RBEntry("Please review the choices that you have made")
    public static final String CR_REVIEW_HEADING = "2151";
    @RBEntry("Name:")
    public static final String CR_REVIEW_NAME = "2152";
    @RBEntry("Description:")
    public static final String CR_REVIEW_DESCRIPTION = "2153";
    @RBEntry("Default:")
    public static final String CR_REVIEW_DEFAULT = "2154";
    @RBEntry("Config spec:")
    public static final String CR_REVIEW_CONFIG_SPEC = "2155";
    @RBEntry("Structure type:")
    public static final String CR_REVIEW_STRUCT_TYPE = "2156";
    @RBEntry("None")
    public static final String CR_STRUCT_NONE = "2157";
    @RBEntry("Part only (default part config spec)")
    public static final String CR_STRUCT_PART_ONLY = "2158";
    @RBEntry("Part and EPM")
    public static final String CR_STRUCT_PART_AND_EPM = "2159";
    @RBEntry("Job submitted to publisher to create new representation {0}")
    public static final String CR_JOB_SUBMITTED = "2161";
    @RBEntry("form field \"fileName\" missing from request")
    public static final String CR_FILENAME_FIELD_MISSING = "2162";
    @RBEntry("Representable Object Reference missing (session timed out?)")
    public static final String CR_OBJREF_MISSING = "2163";
    @RBEntry("No file data uploaded, file could be zero size or not exist")
    public static final String CR_ZERO_SIZE_FILE = "2164";
    @RBEntry("Part structure (default config spec)")
    public static final String CR_PART_STRUCTURE = "2165";
    @RBEntry("Local data")
    public static final String CR_CONVERTED_DATA = "2166";
    @RBEntry("CAD type/name:")
    public static final String CR_CAD_TYPE_NAME = "2167";
    @RBEntry("Top level CAD file name in ZIP or JAR file must be specified if ZIP or JAR file contains multiple CAD files.{0}Select OK to continue if ZIP or JAR contains only a single CAD file.")
    public static final String CR_CAD_SPECIFY_TOP_LEVEL = "2168";
    @RBEntry("Clipboard (Representations/Viewables {0}, Annotations and Groups {1})")
    public static final String CR_CLIPBOARD = "2169";
    @RBEntry("Document content:")
    public static final String CR_DOCUMENT_CONTENT = "2170";
    @RBEntry("Document does not contain any publishable files")
    public static final String CR_NO_DOCUMENT_FILE_SPECIFIED = "2171";
    @RBEntry("You can monitor the progress of this job with the {0}WVS Job Monitor{1}.")
    public static final String CR_JOB_SUBMITTED1 = "2172";
    @RBEntry("Part structure (specified config spec)")
    public static final String CR_PART_STRUCTURE_CONFIG_SPEC = "2173";
    @RBEntry("Publish as Positioning Assembly")
    public static final String CR_PUBLISH_AS_POS_ASSY = "2174";
    @RBEntry("Do not publish as Positioning Assembly")
    public static final String CR_DO_NOT_PUBLISH_AS_POS_ASSY = "2175";
    @RBEntry("Publish as Extended Positioning Assembly")
    public static final String CR_PUBLISH_AS_XPOS_ASSY = "2176";
    @RBEntry("Do not publish as Extended Positioning Assembly")
    public static final String CR_DO_NOT_PUBLISH_AS_XPOS_ASSY = "2177";
    @RBEntry("Publish as Different Extended Positioning Assembly")
    public static final String CR_PUBLISH_AS_DIFFERENT_XPOS_ASSY = "2178";
    @RBEntry("Annotations and Groups")
    public static final String MARKUP_TITLE = "2201";
    @RBEntry("Annotations and Groups for {0}")
    public static final String MARKUP_HEADING = "2202";
    @RBEntry("Delete all")
    public static final String MARKUP_DELETE = "2203";
    @RBEntry("Delete all annotations and groups")
    public static final String MARKUP_DELETE_TIP = "2204";
    @RBEntry("Name")
    public static final String MARKUP_NAME = "2205";
    @RBEntry("Description")
    public static final String MARKUP_DESCRIPTION = "2206";
    @RBEntry("Locked By")
    public static final String MARKUP_LOCKEDBY = "2207";
    @RBEntry("Owner")
    public static final String MARKUP_OWNER = "2208";
    @RBEntry("Last Modified")
    public static final String MARKUP_LAST_UPDATED = "2209";
    @RBEntry("Type")
    public static final String MARKUP_TYPE = "2210";
    @RBEntry("Refresh list")
    public static final String MARKUP_REFRESH = "2211";
    @RBEntry("Refresh annotations and groups list")
    public static final String MARKUP_REFRESH_TIP = "2212";
    @RBEntry("Annotation")
    public static final String MARKUP_ANNOTATION = "2213";
    @RBEntry("Markup")
    public static final String MARKUP_MARKUP = "2214";
    @RBEntry("Unknown")
    public static final String MARKUP_UNKNOWN = "2215";
    @RBEntry("Representations")
    public static final String MARKUP_REPRESENTATIONS = "2216";
    @RBEntry("Paste from Clipboard")
    public static final String MARKUP_PASTE = "2217";
    @RBEntry("Paste annotations/groups from Clipboard")
    public static final String MARKUP_PASTE_TIP = "2218";
    @RBEntry("Copy All to Clipboard")
    public static final String MARKUP_COPY_ALL = "2219";
    @RBEntry("Copy all annotations/groups to Clipboard")
    public static final String MARKUP_COPY_ALL_TIP = "2220";
    @RBEntry("copy forward")
    public static final String MARKUP_COPYFORWARD = "2221";
    @RBEntry("no copy forward")
    public static final String MARKUP_NO_COPYFORWARD = "2222";
    @RBEntry("Paste Selection")
    public static final String MARKUP_PASTE_SELECT = "2223";
    @RBEntry("Paste Selection from Clipboard")
    public static final String MARKUP_PASTE_SELECT_TIP = "2224";
    @RBEntry("Save Representation")
    public static final String SAVE_ZIP_TITLE = "2301";
    @RBEntry("Save Representation")
    public static final String SAVE_ZIP_HEADING = "2302";
    @RBEntry("Include annotations and groups")
    public static final String SAVE_ZIP_INCLUDE_ANNOTATIONS = "2303";
    @RBEntry("File type:")
    public static final String SAVE_ZIP_FILE_TYPE = "2304";
    @RBEntry("ZIP/PVZ/EDZ")
    @RBPseudo(false)
    public static final String SAVE_ZIP_TYPE_ZIP = "2305";
    @RBEntry("JAR")
    @RBPseudo(false)
    public static final String SAVE_ZIP_TYPE_JAR = "2306";
    @RBEntry("Save ...")
    public static final String SAVE_ZIP_SAVE = "2307";
    @RBEntry("Choose how you would like to save this Representation")
    public static final String SAVE_ZIP_HOW_SAVE = "2308";
    @RBEntry("Save the Representation as a file")
    public static final String SAVE_ZIP_AS_FILE = "2309";
    @RBEntry("Save a link to the Representation")
    public static final String SAVE_ZIP_AS_LINK = "2310";
    @RBEntry("Specify the format in which to save the file")
    public static final String SAVE_ZIP_SPECIFY_FORMAT = "2311";
    @RBEntry("Which format would you like the link to open the Representaiton in?")
    public static final String SAVE_ZIP_LINK_WHICH_FORMAT = "2312";
    @RBEntry("Display as an active hyperlink")
    public static final String SAVE_ZIP_LINK_ACTIVE = "2313";
    @RBEntry("Display as text in a textfield")
    public static final String SAVE_ZIP_LINK_TEXT = "2314";
    @RBEntry("Generate an email with the hyperlink in the body")
    public static final String SAVE_ZIP_LINK_EMAIL = "2315";
    @RBEntry("To copy the link below, click your right mouse button and choose the copy action from the menu display")
    public static final String SAVE_ZIP_LINK_ACTIVE_HEADING = "2316";
    @RBEntry("Open Representation {0} in Creo View")
    public static final String SAVE_ZIP_LINK_ACTIVE_MSG = "2317";
    @RBEntry("To copy the link below, highlight the text in the textfield and use your computers copy/paste functions")
    public static final String SAVE_ZIP_LINK_TEXT_HEADING = "2318";
    @RBEntry("Select the link below, and your default e-mail application should launch a window to finish composing the e-mail")
    public static final String SAVE_ZIP_LINK_EMAIL_HEADING = "2319";
    @RBEntry("E-mail link to Representation {0}")
    public static final String SAVE_ZIP_LINK_EMAIL_MSG = "2320";
    @RBEntry("Administration")
    public static final String ADMIN_TITLE = "8001";
    @RBEntry("Administration Tasks")
    public static final String ADMIN_HEADING = "8002";
    @RBEntry("Worker Agent Monitor")
    public static final String ADMIN_CAD_AGENT = "8003";
    @RBEntry("Publish Scheduler")
    public static final String ADMIN_SCHEDULER = "8004";
    @RBEntry("Close")
    public static final String ADMIN_CLOSE = "8005";
    @RBEntry("Publish and Thumbnail Control")
    public static final String ADMIN_VETO = "8006";
    @RBEntry("Server Controlled Configuration of Creo View")
    public static final String ADMIN_PVCONFIG = "8007";
    @RBEntry("This context already has a configuration.  Only one configuration per context is allowed.")
    public static final String ADMIN_MULTIPLE_CONFIG_WARNING = "ADMIN_MULTIPLE_CONFIG_WARNING";
    @RBEntry("Worker Agent Administration")
    public static final String CAD_TITLE = "8101";
    @RBEntry("Configure")
    public static final String CAD_CONFIGURE = "8102";
    @RBEntry("Close")
    public static final String CAD_CLOSE = "8103";
    @RBEntry("Worker Agent Administration")
    public static final String CAD_HEADING = "8104";
    @RBEntry("Start all")
    public static final String CAD_START_ALL = "8105";
    @RBEntry("Start all workers")
    public static final String CAD_START_ALL_TIP = "8106";
    @RBEntry("Stop all")
    public static final String CAD_STOP_ALL = "8107";
    @RBEntry("Stop all workers and worker monitors")
    public static final String CAD_STOP_ALL_TIP = "8108";
    @RBEntry("Reload")
    public static final String CAD_RELOAD = "8109";
    @RBEntry("Reload Worker Agent configuration file")
    public static final String CAD_RELOAD_TIP = "8110";
    @RBEntry("Worker")
    public static final String CAD_WORKER = "8111";
    @RBEntry("Status")
    public static final String CAD_STATUS = "8112";
    @RBEntry("Actions")
    public static final String CAD_ACTION = "8113";
    @RBEntry("Job")
    public static final String CAD_JOB = "8114";
    @RBEntry("Number")
    public static final String CAD_NUMBER = "8115";
    @RBEntry("Date")
    public static final String CAD_DATE = "8116";
    @RBEntry("Worker Agent Returned Error")
    public static final String CAD_ERROR = "8117";
    @RBEntry("Automatic refresh")
    public static final String CAD_AUTO_REFRESH = "8118";
    @RBEntry("Busy,On,Off,Available,Fails to Start")
    public static final String CAD_STATES = "8119";
    @RBEntry("Start worker")
    public static final String CAD_START = "8120";
    @RBEntry("Stop worker")
    public static final String CAD_STOP = "8121";
    @RBEntry("Executable not Set")
    public static final String CAD_EXE_NOT_SET = "CAD_EXE_NOT_SET";
    @RBEntry("Executable not Safe")
    public static final String CAD_EXE_NOT_SAFE = "CAD_EXE_NOT_SAFE";
    @RBEntry("Agent or Worker")
    public static final String CAD_AGENTWORKER = "8122";
    @RBEntry("On-Line")
    public static final String CAD_ONLINE = "8123";
    @RBEntry("Make worker off-line")
    public static final String CAD_MAKE_OFFLINE = "8124";
    @RBEntry("Make worker on-line")
    public static final String CAD_MAKE_ONLINE = "8125";
    @RBEntry("Refresh list")
    public static final String CAD_REFRESH = "8126";
    @RBEntry("Refresh worker list")
    public static final String CAD_REFRESH_TIP = "8127";
    @RBEntry("Test worker")
    public static final String CAD_TEST_WORKER = "8128";
    @RBEntry("Worker Test")
    public static final String CAD_TEST_TITLE = "8129";
    @RBEntry("Starting worker test")
    public static final String CAD_TEST_START = "8130";
    @RBEntry("Worker test completed, with error")
    public static final String CAD_TEST_ERROR = "8131";
    @RBEntry("Worker test completed")
    public static final String CAD_TEST_END = "8132";
    @RBEntry("View worker log files")
    public static final String CAD_LOG_WORKER = "8133";
    @RBEntry("Worker Log File")
    public static final String CAD_LOG_TITLE = "8134";
    @RBEntry("Worker Log File {0} for Worker {1}")
    public static final String CAD_LOG_HEADING = "8135";
    @RBEntry("Worker Log Files")
    public static final String CAD_LOGFILES_TITLE = "8136";
    @RBEntry("Log Files for Worker {0}")
    public static final String CAD_LOGFILES_HEADING = "8137";
    @RBEntry("Refresh list")
    public static final String CAD_LOGFILES_REFRESH = "8138";
    @RBEntry("Refresh list of log files")
    public static final String CAD_LOGFILES_REFRESH_TIP = "8139";
    @RBEntry("Log File")
    public static final String CAD_LOGFILES_FILE = "8140";
    @RBEntry("File Size")
    public static final String CAD_LOGFILES_SIZE = "8141";
    @RBEntry("Created")
    public static final String CAD_LOGFILES_ATIME = "8142";
    @RBEntry("Last Modified")
    public static final String CAD_LOGFILES_MTIME = "8143";
    @RBEntry("Not Available")
    public static final String CAD_NOT_AVAILABLE = "8144";
    @RBEntry("Start verbose workers")
    public static final String CAD_START_IN_DEBUG = "8145";
    @RBEntry("Stop worker monitor")
    public static final String CAD_STOP_MONITOR = "8146";
    @RBEntry("Schedule Job")
    public static final String SCH_TITLE = "8201";
    @RBEntry("Close")
    public static final String SCH_CLOSE = "8202";
    @RBEntry("Scheduled Jobs")
    public static final String SCH_LIST_HEADING = "8203";
    @RBEntry("Queue")
    public static final String SCH_QUEUE = "8204";
    @RBEntry("Name")
    public static final String SCH_NAME = "8205";
    @RBEntry("Description")
    public static final String SCH_DESCRIPTION = "8206";
    @RBEntry("Start Date")
    public static final String SCH_START_DATE = "8207";
    @RBEntry("Next Date")
    public static final String SCH_NEXT_DATE = "8208";
    @RBEntry("To Be Run")
    public static final String SCH_TO_BE_RUN = "8209";
    @RBEntry("Count")
    public static final String SCH_COUNT = "8210";
    @RBEntry("Frequency")
    public static final String SCH_FREQUENCY = "8211";
    @RBEntry("Class")
    public static final String SCH_CLASS = "8212";
    @RBEntry("Method")
    public static final String SCH_METHOD = "8213";
    @RBEntry("Job")
    public static final String SCH_PUBLISH = "8214";
    @RBEntry("Done,Once,Completed,Day,Hour,Min")
    public static final String SCH_STATES = "8215";
    @RBEntry("Completed")
    public static final String SCH_STATES_COMPLETED = "8215A";
    @RBEntry("Done")
    public static final String SCH_STATES_DONE = "8215B";
    @RBEntry("Scheduled Jobs for {0}")
    public static final String SCH_LIST_HEADING_FOR = "8216";
    @RBEntry("Schedule Job for {0}")
    public static final String SCH_HEADING_FOR = "8220";
    @RBEntry("Schedule Job")
    public static final String SCH_HEADING = "8221";
    @RBEntry("Queue:")
    public static final String SCH_IN_QUEUE = "8222";
    @RBEntry("Name:")
    public static final String SCH_IN_NAME = "8223";
    @RBEntry("Description:")
    public static final String SCH_IN_DESCRIPTION = "8224";
    @RBEntry("Job:")
    public static final String SCH_IN_PUBLISH = "8225";
    @RBEntry("Start job:")
    public static final String SCH_IN_START = "8226";
    @RBEntry("Year")
    public static final String SCH_IN_YEAR = "8227";
    @RBEntry("Month")
    public static final String SCH_IN_MONTH = "8228";
    @RBEntry("Day")
    public static final String SCH_IN_DAY = "8229";
    @RBEntry("Hour")
    public static final String SCH_IN_HOUR = "8230";
    @RBEntry("Minute")
    public static final String SCH_IN_MINUTES = "8231";
    @RBEntry("Immediately")
    public static final String SCH_IN_IMMEDIATE = "8233";
    @RBEntry("Job frequency:")
    public static final String SCH_IN_FREQUENCY = "8234";
    @RBEntry("Once")
    public static final String SCH_IN_ONCE = "8235";
    @RBEntry("Schedule")
    public static final String SCH_IN_SCHEDULE = "8236";
    @RBEntry("Close")
    public static final String SCH_IN_CLOSE = "8237";
    @RBEntry("On")
    public static final String SCH_IN_ON = "8238";
    @RBEntry("Every")
    public static final String SCH_IN_EVERY = "8239";
    @RBEntry("Select a task")
    public static final String SCH_SELECT_TASK = "8240";
    @RBEntry("A frequency must be specified")
    public static final String SCH_SPECIFY_FREQUENCY = "8241";
    @RBEntry("A valid frequency day count must be specified")
    public static final String SCH_SPECIFY_VALID_DAY = "8242";
    @RBEntry("Date specified is not valid")
    public static final String SCH_INVALID_DATE = "8243";
    @RBEntry("A Name must be specified")
    public static final String SCH_SPECIFY_NAME = "8244";
    @RBEntry("Day")
    public static final String SCH_IN_EVERY_DAY = "8245";
    @RBEntry("Hour")
    public static final String SCH_IN_EVERY_HOUR = "8246";
    @RBEntry("Minute")
    public static final String SCH_IN_EVERY_MINUTES = "8247";
    @RBEntry("Only create log file")
    public static final String SCH_LOG_FILE_ONLY = "8248";
    @RBEntry("Status")
    public static final String SCH_CURRENT_STATUS = "8249";
    @RBEntry("Refresh list")
    public static final String SCH_REFRESH = "8250";
    @RBEntry("Refresh scheduled jobs list")
    public static final String SCH_REFRESH_TIP = "8251";
    @RBEntry("Schedule Job Log")
    public static final String SCH_JOB_LOG = "8252";
    @RBEntry("Context")
    public static final String SCH_CONTAINER = "8253";
    @RBEntry("Job Type:")
    public static final String SCH_IN_JOB_TYPE = "8254";
    @RBEntry("Use Latest Iteration:")
    public static final String CLASH_DEFINITION_LATEST = "8255";
    @RBEntry("Interference Detection Definition:")
    public static final String CLASH_DEFINITION_PICKER = "8256";
    @RBEntry("Delete jobs older than:")
    public static final String DELETE_COMPLETE_JOBS_DAYS_PICKER = "8259";
    @RBEntry("Enter in a valid number.")
    public static final String VALIDATE_DELETE_COMPLETE_JOBS_DAYS_PICKER = "8260";
    @RBEntry("days.")
    public static final String DAYS = "8261";
    @RBEntry("Search")
    public static final String CLASH_DEFINITION_PICKER_BUTTON = "8257";
    @RBEntry("Select a Interference Detection Definition before submitting")
    public static final String CLASH_DEFINITION_PICKER_VALIDATOR = "8258";
    @RBEntry("Collaboration Sessions")
    public static final String COLLAB_TITLE = "8301";
    @RBEntry("Visual Collaboration Sessions")
    public static final String COLLAB_HEADING = "8302";
    @RBEntry("Start session")
    public static final String COLLAB_CREATE = "8303";
    @RBEntry("Start new visual collaboration session")
    public static final String COLLAB_CREATE_TIP = "8304";
    @RBEntry("Refresh list")
    public static final String COLLAB_REFRESH = "8305";
    @RBEntry("Refresh visual collaboration session list")
    public static final String COLLAB_REFRESH_TIP = "8306";
    @RBEntry("Session Owner")
    public static final String COLLAB_OWNER = "8307";
    @RBEntry("Users")
    public static final String COLLAB_USERS = "8308";
    @RBEntry("Description")
    public static final String COLLAB_DESCRIPTION = "8309";
    @RBEntry("Server String")
    public static final String COLLAB_STRING = "8310";
    @RBEntry("Clear hosted")
    public static final String COLLAB_CLEAR_ACTIVE = "8311";
    @RBEntry("Clear hosted visual collaboration from Windchill session")
    public static final String COLLAB_CLEAR_ACTIVE_TIP = "8312";
    @RBEntry("You are Hosting a visual collaboration session, data loaded into Creo View will be shared")
    public static final String COLLAB_WARNING = "8313";
    @RBEntry("Start Collaboration Session")
    public static final String COLLAB_NEW_TITLE = "8401";
    @RBEntry("Start Visual Collaboration Session")
    public static final String COLLAB_NEW_HEADING = "8402";
    @RBEntry("Description:")
    public static final String COLLAB_NEW_DESCRIPTION = "8403";
    @RBEntry("Password:")
    public static final String COLLAB_NEW_PASS = "8404";
    @RBEntry("Confirm password:")
    public static final String COLLAB_NEW_CONFIRM_PASS = "8405";
    @RBEntry("OK")
    public static final String COLLAB_NEW_OK = "8406";
    @RBEntry("Cancel")
    public static final String COLLAB_NEW_CANCEL = "8407";
    @RBEntry("The passwords are different. Please re-enter them.")
    public static final String COLLAB_NEW_UNMATCHED_PASS = "8408";
    @RBEntry("The % character in not permitted in Description or Password.")
    public static final String COLLAB_NEW_NO_PERCENT = "8409";
    @RBEntry("Start a new collaboration session. Optionally specify a description and password.")
    public static final String COLLAB_NEW_SUBHEADING = "8410";
    @RBEntry("Collaboration session failed to start. Check with the system administrator that the collaboration agent has been installed and configured.")
    public static final String COLLAB_FAILED_TO_START = "8411";
    @RBEntry("OK")
    public static final String UL_OK = "8501";
    @RBEntry("Cancel")
    public static final String UL_CANCEL = "8502";
    @RBEntry("Update Location")
    public static final String UL_UPDATE_LOCATION = "8503";
    @RBEntry("Update location complete, you may close the browser window")
    public static final String UL_UPDATE_COMPLETE = "8504";
    @RBEntry("Copy/paste location string from Creo View 'location' property value")
    public static final String UL_COPY_PASTE = "8505";
    @RBEntry("Regenerate thumbnail:")
    public static final String UL_REGENERATE_THUMBNAIL = "8506";
    @RBEntry("Saving...")
    public static final String UL_SAVING = "8507";
    @RBEntry("Publish and Thumbnail Control")
    public static final String VETO_TITLE = "8601";
    @RBEntry("Publish and Thumbnail Control")
    public static final String VETO_HEADING = "8602";
    @RBEntry("Close")
    public static final String VETO_CLOSE = "8603";
    @RBEntry("Add")
    public static final String VETO_ADD = "8604";
    @RBEntry("Number:")
    public static final String VETO_NUMBER = "8605";
    @RBEntry("Name:")
    public static final String VETO_NAME = "8606";
    @RBEntry("Find")
    public static final String VETO_FIND = "8607";
    @RBEntry("Prohibit thumbnail creation only")
    public static final String VETO_THUMBNAIL_ONLY = "8608";
    @RBEntry("Publish Controlled Objects")
    public static final String VETO_LIST_HEADING = "8609";
    @RBEntry("Number")
    public static final String VETO_LIST_NUMBER = "8610";
    @RBEntry("Name")
    public static final String VETO_LIST_NAME = "8611";
    @RBEntry("Version")
    public static final String VETO_LIST_VERSION = "8612";
    @RBEntry("Control Type")
    public static final String VETO_LIST_TYPE = "8613";
    @RBEntry("Publish")
    public static final String VETO_LIST_TYPE_PUBLISH = "8614";
    @RBEntry("Thumbnail")
    public static final String VETO_LIST_TYPE_THUMBNAIL = "8615";
    @RBEntry("Delete publish control")
    public static final String VETO_DELETE_TIP = "8616";
    @RBEntry("Description:")
    public static final String VETO_DESCRIPTION = "8617";
    @RBEntry("Description")
    public static final String VETO_LIST_DESCRIPTION = "8618";
    @RBEntry("ALL")
    public static final String VETO_LIST_ALL = "8619";
    @RBEntry("Publish control not added (check number)")
    public static final String VETO_NO_ADD = "8620";
    @RBEntry("Publish Controlled Objects for {0}")
    public static final String VETO_LIST_HEADING_FOR = "8621";
    @RBEntry("Publish and Thumbnail Control for {0}")
    public static final String VETO_HEADING_FOR = "8622";
    @RBEntry("Search ...")
    public static final String VETO_BROWSE = "8623";
    @RBEntry("Search CAD Documents")
    public static final String VETO_SEARCH_CAD = "8624";
    @RBEntry("Search CAD Documents / Dynamic Documents in {0}")
    public static final String VETO_SEARCH_CAD_FOR = "8625";
    @RBEntry("Search")
    public static final String VETO_SEARCH = "8627";
    @RBEntry("No Objects Found")
    public static final String VETO_SEARCH_NO_ITEMS_FOUND = "8628";
    @RBEntry("Context")
    public static final String VETO_LIST_CONTAINER = "8629";
    @RBEntry("Positioning Assembly")
    public static final String VETO_LIST_TYPE_POSASSY = "8630";
    @RBEntry("Publish as Positioning Assembly")
    public static final String VETO_POSASSY = "8631";
    @RBEntry("Prohibit publishing")
    public static final String VETO_PUBLISH = "8632";
    @RBEntry("Publish control not added (check that CAD document can be published as a positioning assembly)")
    public static final String VETO_NO_ADD_POSASSY = "8633";
    @RBEntry("Publish control not added (check that CAD document can be published as a extended positioning assembly)")
    public static final String VETO_NO_ADD_EXED_POSASSY = "8633B";
    @RBEntry("Extended Positioning Assembly [{0}]")
    public static final String VETO_LIST_TYPE_XPOSASSY = "8634";
    @RBEntry("Publish as Extended Positioning Assembly")
    public static final String VETO_XPOSASSY = "8635";
    @RBEntry("Publish control not added, CAD form name must be specified for an extended positioning assembly.")
    public static final String VETO_NO_ADD_XPOSASSY = "8636";
    @RBEntry("Creo View Configurations")
    public static final String PVCONFIG_TITLE = "8701";
    @RBEntry("Creo View Configurations for {0}")
    public static final String PVCONFIG_LIST_HEADING = "8702";
    @RBEntry("Create configuration")
    public static final String PVCONFIG_NEW = "8703";
    @RBEntry("Create a new Creo View configuration")
    public static final String PVCONFIG_NEW_TIP = "8704";
    @RBEntry("Configuration Type")
    public static final String PVCONFIG_NAME = "8705";
    @RBEntry("Context")
    public static final String PVCONFIG_CONTEXT = "8706";
    @RBEntry("Delete Creo View configuration")
    public static final String PVCONFIG_DELETE_CONFIG_TIP = "8707";
    @RBEntry("Files for {0}")
    public static final String PVCONFIG_CONTENT_LIST_HEADING = "8708";
    @RBEntry("Add file to configuration")
    public static final String PVCONFIG_NEW_FILE = "8709";
    @RBEntry("Add new file to configuration")
    public static final String PVCONFIG_NEW_FILE_TIP = "8710";
    @RBEntry("File Name")
    public static final String PVCONFIG_FILE_NAME = "8711";
    @RBEntry("Delete file from configuration")
    public static final String PVCONFIG_DELETE_CONTENT_TIP = "8712";
    @RBEntry("Add New File")
    public static final String PVCONFIG_NEW_FILE_HEADING = "8713";
    @RBEntry("Cancel")
    public static final String PVCONFIG_CANCEL = "8714";
    @RBEntry("Add File")
    public static final String PVCONFIG_ADD_FILE = "8715";
    @RBEntry("Create")
    public static final String PVCONFIG_CREATE = "8716";
    @RBEntry("form field \"fileName\" missing from request")
    public static final String PVCONFIG_FILENAME_FIELD_MISSING = "8717";
    @RBEntry("WVSConfigurationTemplate Object Reference missing")
    public static final String PVCONFIG_OBJREF_MISSING = "8718";
    @RBEntry("Please select a file to add to configuration")
    public static final String PVCONFIG_NO_FILE_SPECIFIED = "8719";
    @RBEntry("Failed to add file to configuration")
    public static final String PVCONFIG_FAILED_TO_ADD_FILE = "8720";
    @RBEntry("No file data uploaded, file could be zero size or not exist")
    public static final String PVCONFIG_ZERO_SIZE_FILE = "8721";
    @RBEntry("A file of the same name already exists on this configuration")
    public static final String PVCONFIG_ALREADY_FILE = "8722";
    @RBEntry("File name:")
    public static final String PVCONFIG_INPUT_FILE_NAME = "8723";
    @RBEntry("File Size")
    public static final String PVCONFIG_FILE_SIZE = "8724";
    @RBEntry("Configuration type:")
    public static final String PVCONFIG_INPUT_NAME = "8725";
    @RBEntry("Create New Configuration")
    public static final String PVCONFIG_CREATE_NEW = "8726";
    @RBEntry("Default Type")
    public static final String PVCONFIG_DEFAULT_TYPE = "8727";
    @RBEntry("No files in this configuration")
    public static final String PVCONFIG_NO_FILES = "8728";
    @RBEntry("Create New Configuration for {0}")
    public static final String PVCONFIG_CREATE_NEW_FOR = "8729";
    @RBEntry("Files")
    public static final String PVCONFIG_CONTENT_LIST_TITLE = "8730";
    @RBEntry("No configurations for this context")
    public static final String PVCONFIG_NO_CONFIGS = "8731";
    @RBEntry("A type can optionally be specified, which can be used to provide a different configuration when a user has modify access to the object being viewed.  See property \"productview.modifyconfigtype\".")
    public static final String PVCONFIG_INPUT_NAME_HEADING = "8732";
    @RBEntry("A single file can be specified, or a zip/jar file containing a set of files.")
    public static final String PVCONFIG_INPUT_FILE_NAME_HEADING = "8733";
    @RBEntry("If the operating system is Windows10 or Windows11, please download the installation program")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM_NEW = "8734";
    @RBEntry("The operating system is Windows7, please download the installation program")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM_NEWCX = "8735";
    @RBEntry("The .exe file may be run automatically or downloaded and run at a later date.")
    public static final String DOWNLOAD_MSI_FILE_NEW = "8736";
    public messageResource() {
    }
}
