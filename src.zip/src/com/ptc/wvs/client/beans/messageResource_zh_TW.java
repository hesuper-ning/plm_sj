//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.wvs.client.beans;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.wvs.client.beans.messageResource")
public final class messageResource_zh_TW extends WTListResourceBundle {
    @RBEntry("Windchill 視覺化")
    public static final String WINDCHILL_VISUALIZATION = "1001";
    @RBEntry("說明")
    public static final String HELP = "1002";
    @RBEntry("視覺化")
    public static final String VISUALIZATION = "1003";
    @RBEntry("關閉")
    public static final String WINDOW_CLOSE = "1004";
    @RBEntry("取消")
    public static final String WINDOW_CANCEL = "1005";
    @RBEntry("確定")
    public static final String WINDOW_OK = "1006";
    @RBEntry("小教室")
    public static final String LEARN = "1007";
    @RBEntry("縮圖")
    public static final String THUMBNAIL = "1009";
    @RBEntry("類型")
    public static final String TYPE = "1010";
    @RBEntry("編號")
    public static final String NUMBER = "1011";
    @RBEntry("名稱")
    public static final String NAME = "1012";
    @RBEntry("版本")
    public static final String VERSION = "1013";
    @RBEntry("版序")
    public static final String ITERATION = "1014";
    @RBEntry("動作")
    public static final String ACTIONS = "1015";
    @RBEntry("偏好設定")
    public static final String PREFERENCES = "1016";
    @RBEntry("不受支援")
    public static final String NOTSUPPORTED = "1017";
    @RBEntry("Creo View Client Edition 目前不支援此資料的檢視")
    public static final String NOTSUPPORTED_DESCRIPTION = "1018";
    @RBEntry("Creo View Client Edition 目前不支援標示和序列號的檢視")
    public static final String NOTSUPPORTED_DESCRIPTION1 = "1019";
    @RBEntry("Creo View Client Edition 目前不支援 UNIX")
    public static final String NOTSUPPORTED_DESCRIPTION2 = "1020";
    @RBEntry("Creo View Client Edition 目前不支援批次列印設備")
    public static final String NOTSUPPORTED_DESCRIPTION3 = "1021";
    @RBEntry("Creo View Client Edition 目前無法與 Netscape 6 版瀏覽器並用")
    public static final String NOTSUPPORTED_DESCRIPTION4 = "1022";
    @RBEntry("尚未安裝 Creo View Client Edition。")
    public static final String PVLITE_NOT_INSTALLED = "1023";
    @RBEntry("真")
    public static final String TRUE = "1030";
    @RBEntry("假")
    public static final String FALSE = "1031";
    @RBEntry("是")
    public static final String YES = "1032";
    @RBEntry("否")
    public static final String NO = "1033";
    @RBEntry("套用")
    public static final String WINDOW_APPLY = "1034";
    @RBEntry("(安全資訊)")
    public static final String SECURED_INFORMATION = "1035";
    @RBEntry("&lt;Windchill")
    public static final String GOTO_WINDCHILL = "1101";
    @RBEntry("首頁")
    public static final String HOME = "1102";
    @RBEntry("共用根")
    public static final String CLIPBOARD = "1103";
    @RBEntry("WVS 工作監視器")
    public static final String PUBLISH_MONITOR = "1104";
    @RBEntry("管理員")
    public static final String ADMINISTRATOR = "1105";
    @RBEntry("協同合作")
    public static final String COLLABORATION = "1106";
    @RBEntry("搜尋:")
    public static final String QUERY_SEARCH_ON = "1201";
    @RBEntry("編號:")
    public static final String QUERY_NUMBER = "1202";
    @RBEntry("名稱:")
    public static final String QUERY_NAME = "1203";
    @RBEntry("檢視:")
    public static final String QUERY_VIEW = "1204";
    @RBEntry("版本:")
    public static final String QUERY_VERSION = "1205";
    @RBEntry("類型:")
    public static final String QUERY_TYPE = "1206";
    @RBEntry("來源:")
    public static final String QUERY_SOURCE = "1207";
    @RBEntry("狀態:")
    public static final String QUERY_STATE = "1208";
    @RBEntry("小組:")
    public static final String QUERY_PROJECT = "1209";
    @RBEntry("檔案櫃:")
    public static final String QUERY_CABINET = "1210";
    @RBEntry("版序:")
    public static final String QUERY_ITERATIONS = "1211";
    @RBEntry("最新")
    public static final String QUERY_LATEST = "1212";
    @RBEntry("全部")
    public static final String QUERY_ALL = "1213";
    @RBEntry("完整清單:")
    public static final String QUERY_LONG_LIST = "1214";
    @RBEntry("文件類型:")
    public static final String QUERY_DOC_TYPE = "1215";
    @RBEntry("擁有者應用程式:")
    public static final String QUERY_OWNER_APP = "1216";
    @RBEntry("編寫應用程式:")
    public static final String QUERY_AUTHOR_APP = "1217";
    @RBEntry("排序依據:")
    public static final String SORT_BY = "1218";
    @RBEntry("關鍵字:")
    public static final String QUERY_KEYWORD = "1219";
    @RBEntry("描述:")
    public static final String QUERY_DESCRIPTION = "1220";
    @RBEntry("零件")
    public static final String QUERY_PART = "1231";
    @RBEntry("CAD 文件")
    public static final String QUERY_CAD_DOCUMENT = "1232";
    @RBEntry("文件")
    public static final String QUERY_DOCUMENT = "1233";
    @RBEntry("產品組態")
    public static final String QUERY_PRODUCT_CONFIGURATION = "1234";
    @RBEntry("產品實例")
    public static final String QUERY_PRODUCT_INSTANCE = "1235";
    @RBEntry("組態名稱:")
    public static final String QUERY_CONFIGURATION_NAME = "1236";
    @RBEntry("產品編號:")
    public static final String QUERY_PRODUCT_NUMBER = "1237";
    @RBEntry("產品名稱:")
    public static final String QUERY_PRODUCT_NAME = "1238";
    @RBEntry("序號:")
    public static final String QUERY_SERIAL_NUMBER = "1239";
    @RBEntry("搜尋")
    public static final String QUERY_SEARCH = "1241";
    @RBEntry("未啟用視覺化")
    public static final String VIS_NOT_ENABLED = "1301";
    @RBEntry("您可以看到上面的 {0} Creo View 標誌嗎?")
    public static final String CAN_YOU_SEE = "1302";
    @RBEntry("{0}按一下這裡{1} 來安裝 Creo View")
    public static final String CLICK_HERE = "1303";
    @RBEntry("看起來還未安裝 Creo View")
    public static final String PV_NOT_INSTALLED = "1305";
    @RBEntry("Creo View ActiveX 控制已安裝，但 Creo View Client 尚未安裝")
    public static final String PV_ONLY_OCX_INSTALLED = "1306";
    @RBEntry(" Creo View 安裝")
    public static final String DOWNLOAD_PRODUCTVIEW = "1401";
    @RBEntry("歡迎使用 Creo View 安裝頁面")
    public static final String DOWNLOAD_WELCOME = "1402";
    @RBEntry("看起來您使用的平台還沒有下載 Creo View，請洽系統管理員")
    public static final String DOWNLOAD_IT_APEARS = "1403";
    @RBEntry("歡迎使用 {0} 的 Creo View 安裝頁面")
    public static final String DOWNLOAD_WELCOME_FOR = "1404";
    @RBEntry("已檢查過您的瀏覽器，看起來還未安裝 Creo View。")
    public static final String DOWNLOAD_BROWSER_CHECKED = "1405";
    @RBEntry("如果您是 Windchill 視覺化的初次使用者，則必須安裝 Creo View。")
    public static final String DOWNLOAD_FIRST_TIME_USER = "1406";
    @RBEntry("遵照下列六個步驟去執行安裝。")
    public static final String DOWNLOAD_SIX_STEPS = "1407";
    @RBEntry("開始之前先重新檢視全部步驟。")
    public static final String DOWNLOAD_REVIEW_STEPS = "1408";
    @RBEntry("下載 Creo View 安裝程式: {0}")
    public static final String DOWNLOAD_CLICK_HERE = "1409";
    @RBEntry("當 Internet Explorer 詢問您要如何處理這個檔案時，請選取「從目前所在位置執行這個程式」。")
    public static final String DOWNLOAD_WHEN_IE = "1410";
    @RBEntry("Creo View 安裝程式將自動下載及啟動。")
    public static final String DOWNLOAD_START_AUTOMATICALLY = "1411";
    @RBEntry("選擇 Internet Explorer 可儲存安裝程式的資料夾。")
    public static final String DOWNLOAD_FOLDER_IE = "1412";
    @RBEntry("選擇瀏覽器可儲存安裝程式的資料夾。")
    public static final String DOWNLOAD_FOLDER_NS = "1413";
    @RBEntry("執行安裝程式 (連按兩下檔案)。")
    public static final String DOWNLOAD_RUN_SETUP_WIN = "1414";
    @RBEntry("從安裝程式將檔案解壓縮 (將檔案解壓縮到一個目錄)")
    public static final String DOWNLOAD_RUN_SETUP_UNIX = "1415";
    @RBEntry("遵照安裝程式的指示完成安裝。")
    public static final String DOWNLOAD_FOLLOW_DIRECTIONS = "1416";
    @RBEntry("安裝完成之後，按一下{0}這裡{1}，在瀏覽器註冊 Creo View。")
    public static final String DOWNLOAD_AFTER_SETUP = "1417";
    @RBEntry("Creo View 現已備妥可供使用。")
    public static final String DOWNLOAD_PRODUCTVIEW_READY = "1418";
    @RBEntry("遵照系統管理員的指示完成安裝。")
    public static final String DOWNLOAD_FOLLOW_DIRECTIONS_UNIX = "1419";
    @RBEntry("平台上沒有Creo View 下載檔案，請洽系統管理員。")
    public static final String DOWNLOAD_NO_PRODUCTVIEW = "1420";
    @RBEntry("設定完成後，請重新啟動瀏覽器。")
    public static final String DOWNLOAD_AFTER_SETUP_RESTART = "1421";
    @RBEntry("視覺化 - 完成 Creo View 升級")
    public static final String DOWNLOAD_FINISH_TITLE = "1431";
    @RBEntry("完成 Creo View 升級")
    public static final String DOWNLOAD_FINISH_HEADING = "1432";
    @RBEntry("謝謝您撥冗升級 Creo View 最新版本。")
    public static final String DOWNLOAD_FINISH_THANK_YOU = "1433";
    @RBEntry("安裝程式完成後，即可開始使用 Creo View。")
    public static final String DOWNLOAD_FINISH_COMPLETE = "1434";
    @RBEntry("其他下載")
    public static final String DOWNLOAD_ADDITIONAL_DOWNLOADS = "1435";
    @RBEntry("完成")
    public static final String DOWNLOAD_DONE = "1436";
    @RBEntry("已安裝")
    public static final String DOWNLOAD_INSTALLED = "1437";
    @RBEntry("安裝失敗 - 錯誤代碼 {0}。{1} 內含已下載的檔案和記錄檔")
    public static final String DOWNLOAD_INSTALLATION_FAILED = "1438";
    @RBEntry("{0} 檔案 {1}Mb")
    public static final String DOWNLOAD_FILES = "1440";
    @RBEntry("此平台不支援Creo View 的安裝。")
    public static final String DOWNLOAD_PVLITE_NOT_SUPPORTED = "1442";
    @RBEntry("Creo View Client")
    public static final String DOWNLOAD_PVLITE = "1443";
    @RBEntry("AutoCAD 檢視器")
    public static final String DOWNLOAD_AUTOCAD = "1444";
    @RBEntry("下載說明檔")
    public static final String DOWNLOAD_HELP_FILES = "1445";
    @RBEntry("語言")
    public static final String DOWNLOAD_LANGUAGES = "1446";
    @RBEntry("英文")
    public static final String DOWNLOAD_ENGLISH = "1447";
    @RBEntry("日文")
    public static final String DOWNLOAD_JAPANESE = "1448";
    @RBEntry("法文")
    public static final String DOWNLOAD_FRENCH = "1449";
    @RBEntry("韓文")
    public static final String DOWNLOAD_KOREAN = "1450";
    @RBEntry("德文")
    public static final String DOWNLOAD_GERMAN = "1451";
    @RBEntry("繁體中文")
    public static final String DOWNLOAD_CHINESE_TRADITIONAL = "1452";
    @RBEntry("義大利文")
    public static final String DOWNLOAD_ITALIAN = "1453";
    @RBEntry("簡體中文")
    public static final String DOWNLOAD_CHINESE_SIMPLIFIED = "1454";
    @RBEntry("西班牙文")
    public static final String DOWNLOAD_SPANISH = "1455";
    @RBEntry("安裝目錄")
    public static final String DOWNLOAD_INSTALLATION_DIRECTORY = "1456";
    @RBEntry("下載大小")
    public static final String DOWNLOAD_SIZE = "1457";
    @RBEntry("下載進度")
    public static final String DOWNLOAD_PROGRESS = "1458";
    @RBEntry("正在安裝")
    public static final String DOWNLOAD_INSTALLING = "1459";
    @RBEntry("安裝")
    public static final String DOWNLOAD_INSTALL = "1460";
    @RBEntry("取消")
    public static final String DOWNLOAD_CANCEL = "1461";
    @RBEntry("重新安裝")
    public static final String DOWNLOAD_REINSTALL = "1462";
    @RBEntry("升級")
    public static final String DOWNLOAD_UPGRADE = "1463";
    @RBEntry("完整的安裝程式可從下列位置下載")
    public static final String DOWNLOAD_DOWNLOAD_FROM = "1464";
    @RBEntry("此處")
    public static final String DOWNLOAD_HERE = "1465";
    @RBEntry("下載和安裝失敗時，這會非常有用。.exe 檔案可自動執行，也可以下載後以後再執行。")
    public static final String DOWNLOAD_MSI_FILE = "1466";
    @RBEntry("安裝 Creo View Client")
    public static final String DOWNLOAD_INSTALL_PVLITE = "1467";
    @RBEntry("安裝Creo View Standard")
    public static final String DOWNLOAD_INSTALL_STANDARD = "1468";
    @RBEntry("安裝完成")
    public static final String DOWNLOAD_INSTALLATION_FINISHED = "1469";
    @RBEntry("選項")
    public static final String DOWNLOAD_OPTIONS = "1470";
    @RBEntry("按一下此處以下載完整的安裝程式")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM = "1471";
    @RBEntry("俄文")
    public static final String DOWNLOAD_RUSSIAN = "1472";
    @RBEntry("匯入篩選器")
    public static final String DOWNLOAD_IMPORTFILTERS = "1473";
    @RBEntry("授權位置")
    public static final String LICENSE_LOCATION = "1474";
    @RBEntry("葡萄牙文 (巴西)")
    public static final String DOWNLOAD_PORTUGUESE_BRAZILIAN = "1475";
    @RBEntry("安裝 Creo View ECAD")
    public static final String DOWNLOAD_INSTALL_PVECAD = "1480";
    @RBEntry("下載  Creo View ECAD")
    public static final String DOWNLOAD_PRODUCTVIEW_ECAD = "1481";
    @RBEntry("Creo View ECADCompare")
    public static final String DOWNLOAD_PVECADCOMPARE = "1482";
    @RBEntry("Creo View ECAD Validate")
    public static final String DOWNLOAD_PVVALIDATE = "1483";
    @RBEntry("歡迎使用適用 {0} 的 Creo View ECAD 的安裝頁")
    public static final String DOWNLOAD_ECAD_WELCOME_FOR = "1484";
    @RBEntry("按一下此處以下載額外的 Creo View ECAD 轉接器安裝程式 ")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_ECAD_ADAPTERS_FROM = "1485";
    @RBEntry("結果 - CAD 文件")
    public static final String RESULTS_CAD_DOCUMENTS = "1501";
    @RBEntry("結果 - 零件")
    public static final String RESULTS_PARTS = "1502";
    @RBEntry("結果 - 文件")
    public static final String RESULTS_DOCUMENTS = "1503";
    @RBEntry("結果 - 不明類型")
    public static final String RESULTS_UNKNOWN_TYPE = "1504";
    @RBEntry("{0}-{1} 個，共 {2} 個")
    public static final String RESULTS_OF = "1505";
    @RBEntry("上一頁")
    public static final String RESULTS_PREVIOUS = "1506";
    @RBEntry("下一頁")
    public static final String RESULTS_NEXT = "1507";
    @RBEntry("全部")
    public static final String RESULTS_All = "1508";
    @RBEntry("新增至剪貼簿")
    public static final String RESULTS_COPY_ALL = "1509";
    @RBEntry("全部新增至剪貼簿")
    public static final String RESULTS_COPY_ALL_TIP = "1510";
    @RBEntry("全部刪除")
    public static final String RESULTS_DELETE_ALL = "1511";
    @RBEntry("全部刪除")
    public static final String RESULTS_DELETE_ALL_TIP = "1512";
    @RBEntry("顯示全部縮圖")
    public static final String RESULTS_SHOW_ALL_THUMBNAILS = "1513";
    @RBEntry("顯示全部縮圖")
    public static final String RESULTS_SHOW_ALL_THUMBNAILS_TIP = "1514";
    @RBEntry("結果 - 產品實例")
    public static final String RESULTS_PRODUCT_INSTANCES = "1515";
    @RBEntry("結果 - 產品組態")
    public static final String RESULTS_PRODUCT_CONFIGURATIONS = "1516";
    @RBEntry("類型")
    public static final String RESULTS_DOC_TYPE = "1521";
    @RBEntry("擁有者應用程式")
    public static final String RESULTS_OWNER_APP = "1522";
    @RBEntry("編寫應用程式")
    public static final String RESULTS_AUTHOR_APP = "1523";
    @RBEntry("狀態")
    public static final String RESULTS_STATE = "1524";
    @RBEntry("檢視")
    public static final String RESULTS_VIEW = "1525";
    @RBEntry("類型")
    public static final String RESULTS_TYPE = "1526";
    @RBEntry("來源")
    public static final String RESULTS_SOURCE = "1527";
    @RBEntry("生命週期")
    public static final String RESULTS_LIFECYCLE = "1528";
    @RBEntry("小組")
    public static final String RESULTS_PROJECT = "1529";
    @RBEntry("位置")
    public static final String RESULTS_LOCATION = "1530";
    @RBEntry("描述")
    public static final String RESULTS_DESCRIPTION = "1531";
    @RBEntry("刪除")
    public static final String RESULTS_DELETE_TIP = "1532";
    @RBEntry("顯示縮圖")
    public static final String RESULTS_SHOW_THUMBNAIL_TIP = "1533";
    @RBEntry("隱藏縮圖")
    public static final String RESULTS_HIDE_THUMBNAIL_TIP = "1534";
    @RBEntry("組態名稱")
    public static final String RESULTS_CONFIGURATION_NAME = "1535";
    @RBEntry("序號")
    public static final String RESULTS_SERIAL_NUMBER = "1536";
    @RBEntry("產品編號")
    public static final String RESULTS_PRODUCT_NUMBER = "1537";
    @RBEntry("產品名稱")
    public static final String RESULTS_PRODUCT_NAME = "1538";
    @RBEntry("視覺化收集區")
    public static final String CB_TITLE = "1601";
    @RBEntry("視覺化收集區")
    public static final String CB_HEADING = "1602";
    @RBEntry("開啟全部")
    public static final String CB_VIEW_ALL = "1603";
    @RBEntry("在 Creo View 開啟全部")
    public static final String CB_VIEW_ALL_TIP = "1604";
    @RBEntry("全部移除")
    public static final String CB_DELETE_ALL = "1605";
    @RBEntry("全部從視覺化收集區刪除")
    public static final String CB_DELETE_ALL_TIP = "1606";
    @RBEntry("從視覺化收集區刪除")
    public static final String CB_DELETE_TIP = "1607";
    @RBEntry("全部列印")
    public static final String CB_PRINT_ALL = "1608";
    @RBEntry("全部以 Creo View 批次列印")
    public static final String CB_PRINT_ALL_TIP = "1609";
    @RBEntry("表示名稱")
    public static final String CB_REP_NAME_HEADING = "1610";
    @RBEntry("所選項目均無法檢視")
    public static final String CB_NOTHING_VIEWABLE = "1611";
    @RBEntry("表示")
    public static final String REP_TITLE = "1701";
    @RBEntry("{0} 的表示")
    public static final String REP_HEADING = "1702";
    @RBEntry("新建表示")
    public static final String REP_CREATE = "1703";
    @RBEntry("新建表示")
    public static final String REP_CREATE_TIP = "1704";
    @RBEntry("名稱")
    public static final String REP_NAME = "1705";
    @RBEntry("描述")
    public static final String REP_DESCRIPTION = "1706";
    @RBEntry("其他詳細資訊")
    public static final String REP_CONFIG_SPEC = "1707";
    @RBEntry("建立日期")
    public static final String REP_DATE_CREATED = "1708";
    @RBEntry("重新整理清單")
    public static final String REP_REFRESH = "1709";
    @RBEntry("重新整理表示清單")
    public static final String REP_REFRESH_TIP = "1710";
    @RBEntry("從剪貼簿貼上")
    public static final String REP_PASTE = "1711";
    @RBEntry("從剪貼簿加入表示")
    public static final String REP_PASTE_TIP = "1712";
    @RBEntry("複製全部至剪貼簿")
    public static final String REP_COPY_ALL = "1713";
    @RBEntry("複製全部至剪貼簿")
    public static final String REP_COPY_ALL_TIP = "1714";
    @RBEntry("傳送表示以重新發行")
    public static final String REP_SENT_REPUBLISH = "1715";
    @RBEntry("傳送表示以重新發行失敗")
    public static final String REP_FAILED_REPUBLISH = "1716";
    @RBEntry("描述者表示")
    public static final String REP_DESCRIBED_BY = "1717";
    @RBEntry("貼上選取項")
    public static final String REP_PASTE_SELECT = "1718";
    @RBEntry("從剪貼簿貼上選取項")
    public static final String REP_PASTE_SELECT_TIP = "1719";
    @RBEntry("已發佈")
    public static final String VIEW_ALREADY_PUBLISHED = "1801";
    @RBEntry("已傳給發佈者")
    public static final String VIEW_SENT_TO_PUBLISHER = "1802";
    @RBEntry("批次列印")
    public static final String VIEW_BATCHPRINT = "1803";
    @RBEntry("Creo View")
    public static final String VIEW_PRODUCTVIEW = "1804";
    @RBEntry("正在載入...")
    public static final String VIEW_LOADING = "1805";
    @RBEntry("針對工作狀況選取{0}WVS 工作監視器{1}")
    public static final String VIEW_PUBLISH_MONITOR = "1806";
    @RBEntry("加入協同合作")
    public static final String VIEW_JOIN_COLLAB = "1807";
    @RBEntry("主持協同合作")
    public static final String VIEW_HOST_COLLAB = "1808";
    @RBEntry("舊的視覺化資料")
    public static final String VIEW_OOD_TITLE = "1809";
    @RBEntry("此視覺化資料{0}標記為過期{1}")
    public static final String VIEW_OOD_MESSAGE = "1810";
    @RBEntry("{0}繼續{1}檢視")
    public static final String VIEW_OOD_CONTINUE = "1811";
    @RBEntry("資料標記為不發佈")
    public static final String MARKED_NOT_PUBLISHABLE = "1812";
    @RBEntry("不進行發佈")
    public static final String NO_PUBLISHING = "1813";
    @RBEntry("可視資料導覽")
    public static final String VIEW_VISUAL_NAVIGATION = "1814";
    @RBEntry("您正在關閉可視資料導覽檢視器視窗。")
    public static final String VIEW_EXIT_VISUAL_NAVIGATION = "1815";
    @RBEntry("過期詳細資訊")
    public static final String VIEW_OODDET_TITLE = "1850";
    @RBEntry("{0} 表示的過期詳細資訊")
    public static final String VIEW_OODDET_HEADING = "1851";
    @RBEntry("物件記錄為將此表示標記為過期")
    public static final String VIEW_OODDET_OBJECTS = "1852";
    @RBEntry("啟動 Creo View 用戶端")
    public static final String STARTING_CREO_VIEW_CLIENT = "1853";
    @RBEntry("注意: 必須使用相同認證 Windchill 使用者認證用戶端。")
    public static final String CLIENT_AUTHENTICATE_SAME_USER = "1854";
    @RBEntry("此視覺化資料標記為過期。是否要繼續檢視?")
    public static final String VIEW_OOD_MESSAGE_AND_CONTINUE = "1855";
    @RBEntry("過期詳細資訊...")
    public static final String VIEW_OODDET_BUTTON = "1856";
    @RBEntry("說明")
    public static final String HLP_TITLE = "1901";
    @RBEntry("視覺化說明")
    public static final String HLP_HEADING = "1902";
    @RBEntry("圖示定義")
    public static final String HLP_ICON_DEF = "1903";
    @RBEntry("圖示")
    public static final String HLP_ICON = "1904";
    @RBEntry("描述")
    public static final String HLP_DESCRIPTION = "1905";
    @RBEntry("啟動 Creo View")
    public static final String HLP_ICON_PV = "1906";
    @RBEntry("呼叫「發佈者」處理資料，以便在 Creo View 檢視")
    public static final String HLP_ICON_PUBLISH = "1907";
    @RBEntry("加入資料至剪貼簿")
    public static final String HLP_ICON_CLIP = "1908";
    @RBEntry("啟動 Creo View 批次列印")
    public static final String HLP_ICON_PRINT = "1909";
    @RBEntry("顯示 Creo View 表示的表格")
    public static final String HLP_ICON_REP = "1910";
    @RBEntry("刪除資料")
    public static final String HLP_ICON_DEL = "1911";
    @RBEntry("指示在清單及內容頁上顯示的預設表示")
    public static final String HLP_ICON_DEFAULT = "1912";
    @RBEntry("使此表示成為預設值")
    public static final String HLP_ICON_MAKE_DEFAULT = "1913";
    @RBEntry("顯示 Creo View 註釋和群組")
    public static final String HLP_ICON_MARKUP = "1914";
    @RBEntry("顯示縮圖圖像")
    public static final String HLP_ICON_DISPLAY_THUMBNAIL = "1915";
    @RBEntry("隱藏縮圖圖像")
    public static final String HLP_ICON_HIDE_THUMBNAIL = "1916";
    @RBEntry("鎖定註釋或群組")
    public static final String HLP_ICON_LOCK_MARKUP = "1917";
    @RBEntry("解除鎖定註釋或群組")
    public static final String HLP_ICON_UNLOCK_MARKUP = "1918";
    @RBEntry("Creo View 教學專區可從 {0}這裡{1} 存取")
    public static final String HLP_TUTORIAL = "1931";
    @RBEntry("WVS 工作監視器")
    public static final String MON_TITLE = "2001";
    @RBEntry("自動重新整理")
    public static final String MON_REFRESH = "2002";
    @RBEntry("{0} 的發佈工作摘要")
    public static final String MON_SUMMARY_HEADING_FOR = "2010";
    @RBEntry("發佈工作摘要")
    public static final String MON_SUMMARY_HEADING = "2011";
    @RBEntry("刪除所有佇列項目")
    public static final String MON_SUMMARY_DELETE_ALL_TIP = "2012";
    @RBEntry("全部刪除")
    public static final String MON_SUMMARY_DELETE_ALL = "2013";
    @RBEntry("刪除所有已完成的佇列項目")
    public static final String MON_SUMMARY_DELETE_COMPLETED_TIP = "2014";
    @RBEntry("刪除完畢")
    public static final String MON_SUMMARY_DELETE_COMPLETED = "2015";
    @RBEntry("刪除所有已成功完成的佇列項目")
    public static final String MON_SUMMARY_DELETE_SUCCESSFUL_TIP = "2016";
    @RBEntry("刪除成功")
    public static final String MON_SUMMARY_DELETE_SUCCESSFUL = "2017";
    @RBEntry("重新整理清單")
    public static final String MON_SUMMARY_REFRESH_LIST = "2018";
    @RBEntry("重新整理工作摘要清單")
    public static final String MON_SUMMARY_REFRESH_LIST_TIP = "2019";
    @RBEntry("發佈統計數字")
    public static final String MON_SUMMARY_STATISTICS = "2020";
    @RBEntry("發佈統計數字摘要資訊")
    public static final String MON_SUMMARY_STATISTICS_TIP = "2021";
    @RBEntry("發佈工作詳細資訊")
    public static final String MON_JOB_HEADING = "2051";
    @RBEntry("重新整理")
    public static final String MON_JOB_REFRESH_LIST = "2052";
    @RBEntry("重新整理工作詳細資訊")
    public static final String MON_JOB_REFRESH_LIST_TIP = "2053";
    @RBEntry("僅有顯示失敗")
    public static final String MON_ONLY_FAILED_JOBS = "2054";
    @RBEntry("工作統計數字")
    public static final String MON_STAT_HEADING = "2060";
    @RBEntry("{0} 的工作統計")
    public static final String MON_STAT_HEADING_FOR = "2061";
    @RBEntry("工作摘要統計")
    public static final String MON_STAT_SUMMARY_HEADING = "2062";
    @RBEntry("{0} 的工作摘要統計")
    public static final String MON_STAT_SUMMARY_HEADING_FOR = "2063";
    @RBEntry("篩選:")
    public static final String MON_STAT_FILTER_ON = "2064";
    @RBEntry("工作提交日期")
    public static final String MON_STAT_FILTER_SUBMIT = "2065";
    @RBEntry("工作開始日期")
    public static final String MON_STAT_FILTER_START = "2066";
    @RBEntry("工作終止日期")
    public static final String MON_STAT_FILTER_END = "2067";
    @RBEntry("開始日期:")
    public static final String MON_STAT_FROM_DATE = "2068";
    @RBEntry("終止日期:")
    public static final String MON_STAT_TO_DATE = "2069";
    @RBEntry("顯示摘要統計數字")
    public static final String MON_STAT_DISPLAY_SUMMARY = "2070";
    @RBEntry("儲存統計數字")
    public static final String MON_STAT_SAVE_CSV = "2071";
    @RBEntry("將特定期間的工作統計儲存為 CSV 檔案")
    public static final String MON_STAT_SAVE_CSV_TIP = "2072";
    @RBEntry("編寫應用程式")
    public static final String MON_STAT_DATA_TYPE = "2073";
    @RBEntry("Worker 類型")
    public static final String MON_STAT_WORKER_TYPE = "2074";
    @RBEntry("總體工作")
    public static final String MON_STAT_TOTAL_JOBS = "2075";
    @RBEntry("成功工作")
    public static final String MON_STAT_SUCCESSFUL_JOBS = "2076";
    @RBEntry("已失敗工作")
    public static final String MON_STAT_FAILED_JOBS = "2077";
    @RBEntry("% 成功工作")
    public static final String MON_STAT_PERCENT_SUCCESSFUL_JOBS = "2078";
    @RBEntry("% 失敗工作")
    public static final String MON_STAT_PERCENT_FAILED_JOBS = "2079";
    @RBEntry("Worker 利用率")
    public static final String MON_STAT_WORKER_UTILIZATION = "2080";
    @RBEntry("Worker 名稱")
    public static final String MON_STAT_WORKER_NAME = "2081";
    @RBEntry("忙錄時間")
    public static final String MON_STAT_BUSY_TIME = "2082";
    @RBEntry("新建表示")
    public static final String CR_TITLE = "2101";
    @RBEntry("\"{0}\" 表示已經存在")
    public static final String CR_ALREADY_EXISTS = "2102";
    @RBEntry("新建表示")
    public static final String CR_HEADING = "2103";
    @RBEntry("步驟")
    public static final String CR_STEPS = "2104";
    @RBEntry("輸入表示的詳細資訊")
    public static final String CR_SPECIFY_NAME = "2105";
    @RBEntry("設定 EPM 組態規格")
    public static final String CR_SET_CONFIG_SPEC = "2106";
    @RBEntry("選擇結構類型")
    public static final String CR_SET_STRUCTURE_TYPE = "2107";
    @RBEntry("確認選項")
    public static final String CR_REVIEW_OPTIONS = "2108";
    @RBEntry("摘要")
    public static final String CR_COMPLETE = "2109";
    @RBEntry("完成")
    public static final String CR_FINISH = "2110";
    @RBEntry("取消")
    public static final String CR_CANCEL = "2111";
    @RBEntry("下一步 ")
    public static final String CR_NEXT = "2112";
    @RBEntry(" 上一步")
    public static final String CR_BACK = "2113";
    @RBEntry("提交發佈工作")
    public static final String CR_SUBMIT_PUBLISH_JOB = "2114";
    @RBEntry("關閉")
    public static final String CR_CLOSE = "2115";
    @RBEntry("選擇輸入來源")
    public static final String CR_SPECIFY_EDZ = "2116";
    @RBEntry("輸入表示的名稱和描述。選擇是否以新的表示作為預設表示。")
    public static final String CR_NAME_HEADING = "2121";
    @RBEntry("名稱:")
    public static final String CR_NAME = "2122";
    @RBEntry("描述:")
    public static final String CR_DESCRIPTION = "2123";
    @RBEntry("設為預設表示")
    public static final String CR_SET_AS_DEFAULT = "2124";
    @RBEntry("設定建立表示時會使用的 EPM 組態規格，一旦設定完畢，按一下 \"下一步\"，此規格即會成為所有工作階段期間在使用者介面上新建的表示的預設。")
    public static final String CR_CS_HEADING = "2131";
    @RBEntry("最新")
    public static final String CR_CS_LATEST = "2132";
    @RBEntry("基準線")
    public static final String CR_CS_BASELINE = "2133";
    @RBEntry("生命週期")
    public static final String CR_CS_LIFECYCLE = "2134";
    @RBEntry("已資料夾化")
    public static final String CR_CS_FOLDERED = "2135";
    @RBEntry("生失效")
    public static final String CR_CS_EFFECTIVITY = "2136";
    @RBEntry("預設")
    public static final String CR_CS_DEFAULT = "2137";
    @RBEntry("原儲存")
    public static final String CR_CS_AS_STORED = "2138";
    @RBEntry("自行指定要建立表示的 {0}。")
    public static final String CR_STRUCT_HEADING1 = "2140";
    @RBEntry("選擇要建立表示的結構類型。")
    public static final String CR_STRUCT_HEADING = "2141";
    @RBEntry("僅 EPM")
    public static final String CR_STRUCT_EPM_ONLY = "2142";
    @RBEntry("EPM 加上額外零件 (預設的零件組態規格)")
    public static final String CR_STRUCT_EPM_PLUS_PARTS = "2143";
    @RBEntry("選擇要用來建立表示的輸入來源。")
    public static final String CR_EDZ_HEADING = "2144";
    @RBEntry("本機檔案名稱:")
    public static final String CR_EDZ_NAME = "2145";
    @RBEntry("產生縮圖")
    public static final String CR_GENERATE_THUMBNAIL = "2146";
    @RBEntry("(例如:  PVZ、ZIP、JAR、OL、PLT、HPGL、DWG、DXF、CC、CCZ 或 CAD 檔案)")
    public static final String CR_EDZ_TYPES = "2147";
    @RBEntry("正在上載檔案...")
    public static final String CR_UPLOADING_FILE = "2148";
    @RBEntry("請選取檔案來建立「表示」，位置是")
    public static final String CR_NO_FILE_SPECIFIED = "2149";
    @RBEntry("請選取副檔名正確的檔案")
    public static final String CR_INVALID_EXTENSION = "2150";
    @RBEntry("請審核已選的選項")
    public static final String CR_REVIEW_HEADING = "2151";
    @RBEntry("名稱:")
    public static final String CR_REVIEW_NAME = "2152";
    @RBEntry("描述:")
    public static final String CR_REVIEW_DESCRIPTION = "2153";
    @RBEntry("預設:")
    public static final String CR_REVIEW_DEFAULT = "2154";
    @RBEntry("組態規格:")
    public static final String CR_REVIEW_CONFIG_SPEC = "2155";
    @RBEntry("結構類型:")
    public static final String CR_REVIEW_STRUCT_TYPE = "2156";
    @RBEntry("無")
    public static final String CR_STRUCT_NONE = "2157";
    @RBEntry("僅限零件 (預設的零件組態規格)")
    public static final String CR_STRUCT_PART_ONLY = "2158";
    @RBEntry("零件和 EPM")
    public static final String CR_STRUCT_PART_AND_EPM = "2159";
    @RBEntry("工作提交給發佈者以建立新表示 {0}")
    public static final String CR_JOB_SUBMITTED = "2161";
    @RBEntry("請求中遺失 \"fileName\" 這個表單欄位")
    public static final String CR_FILENAME_FIELD_MISSING = "2162";
    @RBEntry("遺失「可表示物件」參考 (工作階段已逾時?)")
    public static final String CR_OBJREF_MISSING = "2163";
    @RBEntry("檔案資料沒上載，這個檔案的大小可能為零，或者此檔案根本不存在")
    public static final String CR_ZERO_SIZE_FILE = "2164";
    @RBEntry("零件結構 (預設組態規格)")
    public static final String CR_PART_STRUCTURE = "2165";
    @RBEntry("本機資料")
    public static final String CR_CONVERTED_DATA = "2166";
    @RBEntry("CAD 類型/名稱:")
    public static final String CR_CAD_TYPE_NAME = "2167";
    @RBEntry("若 ZIP 或 JAR 檔案內含多個 CAD 檔案，則需指定 ZIP 或 JAR 檔案內的最上層 CAD 檔案。{0}若 ZIP 或 JAR 內只有一個 CAD 檔案，則選取「確定」以繼續。")
    public static final String CR_CAD_SPECIFY_TOP_LEVEL = "2168";
    @RBEntry("剪貼簿 (表示/可檢視項 {0}，註釋和群組: {1})")
    public static final String CR_CLIPBOARD = "2169";
    @RBEntry("文件內容:")
    public static final String CR_DOCUMENT_CONTENT = "2170";
    @RBEntry("文件不包含任何可發行檔")
    public static final String CR_NO_DOCUMENT_FILE_SPECIFIED = "2171";
    @RBEntry("您可利用 {0}WVS 工作監視器{1} 監視工作進度。")
    public static final String CR_JOB_SUBMITTED1 = "2172";
    @RBEntry("零件結構 (指定的組態規格)")
    public static final String CR_PART_STRUCTURE_CONFIG_SPEC = "2173";
    @RBEntry("以定位組件發佈")
    public static final String CR_PUBLISH_AS_POS_ASSY = "2174";
    @RBEntry("不以定位組件發佈")
    public static final String CR_DO_NOT_PUBLISH_AS_POS_ASSY = "2175";
    @RBEntry("以延伸的定位組件發佈")
    public static final String CR_PUBLISH_AS_XPOS_ASSY = "2176";
    @RBEntry("不以延伸的定位組件發佈")
    public static final String CR_DO_NOT_PUBLISH_AS_XPOS_ASSY = "2177";
    @RBEntry("以不同延伸的定位組件發佈")
    public static final String CR_PUBLISH_AS_DIFFERENT_XPOS_ASSY = "2178";
    @RBEntry("註釋和群組")
    public static final String MARKUP_TITLE = "2201";
    @RBEntry("{0} 的註釋和群組")
    public static final String MARKUP_HEADING = "2202";
    @RBEntry("全部刪除")
    public static final String MARKUP_DELETE = "2203";
    @RBEntry("刪除全部註釋和群組")
    public static final String MARKUP_DELETE_TIP = "2204";
    @RBEntry("名稱")
    public static final String MARKUP_NAME = "2205";
    @RBEntry("描述")
    public static final String MARKUP_DESCRIPTION = "2206";
    @RBEntry("鎖定者")
    public static final String MARKUP_LOCKEDBY = "2207";
    @RBEntry("擁有者")
    public static final String MARKUP_OWNER = "2208";
    @RBEntry("上次修改")
    public static final String MARKUP_LAST_UPDATED = "2209";
    @RBEntry("類型")
    public static final String MARKUP_TYPE = "2210";
    @RBEntry("重新整理清單")
    public static final String MARKUP_REFRESH = "2211";
    @RBEntry("重新整理註釋和群組清單")
    public static final String MARKUP_REFRESH_TIP = "2212";
    @RBEntry("註釋")
    public static final String MARKUP_ANNOTATION = "2213";
    @RBEntry("標示")
    public static final String MARKUP_MARKUP = "2214";
    @RBEntry("不明")
    public static final String MARKUP_UNKNOWN = "2215";
    @RBEntry("表示")
    public static final String MARKUP_REPRESENTATIONS = "2216";
    @RBEntry("從剪貼簿貼上")
    public static final String MARKUP_PASTE = "2217";
    @RBEntry("貼上剪貼簿的註釋/群組")
    public static final String MARKUP_PASTE_TIP = "2218";
    @RBEntry("複製全部至剪貼簿")
    public static final String MARKUP_COPY_ALL = "2219";
    @RBEntry("將全部的註釋/群組複製至剪貼簿")
    public static final String MARKUP_COPY_ALL_TIP = "2220";
    @RBEntry("複製至下一版序")
    public static final String MARKUP_COPYFORWARD = "2221";
    @RBEntry("不複製至下一版序")
    public static final String MARKUP_NO_COPYFORWARD = "2222";
    @RBEntry("貼上選取項")
    public static final String MARKUP_PASTE_SELECT = "2223";
    @RBEntry("從剪貼簿貼上選取項")
    public static final String MARKUP_PASTE_SELECT_TIP = "2224";
    @RBEntry("儲存表示")
    public static final String SAVE_ZIP_TITLE = "2301";
    @RBEntry("儲存表示")
    public static final String SAVE_ZIP_HEADING = "2302";
    @RBEntry("包括註釋和群組")
    public static final String SAVE_ZIP_INCLUDE_ANNOTATIONS = "2303";
    @RBEntry("檔案類型:")
    public static final String SAVE_ZIP_FILE_TYPE = "2304";
    @RBEntry("ZIP/PVZ/EDZ")
    @RBPseudo(false)
    public static final String SAVE_ZIP_TYPE_ZIP = "2305";
    @RBEntry("JAR")
    @RBPseudo(false)
    public static final String SAVE_ZIP_TYPE_JAR = "2306";
    @RBEntry("儲存 ...")
    public static final String SAVE_ZIP_SAVE = "2307";
    @RBEntry("選擇存取此表示的方法")
    public static final String SAVE_ZIP_HOW_SAVE = "2308";
    @RBEntry("將表示儲存為檔案")
    public static final String SAVE_ZIP_AS_FILE = "2309";
    @RBEntry("儲存連結至表示")
    public static final String SAVE_ZIP_AS_LINK = "2310";
    @RBEntry("指定檔案的儲存格式")
    public static final String SAVE_ZIP_SPECIFY_FORMAT = "2311";
    @RBEntry("希望連結以哪種格式開啟表示?")
    public static final String SAVE_ZIP_LINK_WHICH_FORMAT = "2312";
    @RBEntry("顯示為使用中超連結")
    public static final String SAVE_ZIP_LINK_ACTIVE = "2313";
    @RBEntry("在文字欄位內以文字顯示")
    public static final String SAVE_ZIP_LINK_TEXT = "2314";
    @RBEntry("以內文裡的超連結生成電子郵件位址")
    public static final String SAVE_ZIP_LINK_EMAIL = "2315";
    @RBEntry("若想複製下方連結，請按一下滑鼠右鍵，然後選擇選單內的複製動作")
    public static final String SAVE_ZIP_LINK_ACTIVE_HEADING = "2316";
    @RBEntry("於 Creo View 開啟表示: {0}")
    public static final String SAVE_ZIP_LINK_ACTIVE_MSG = "2317";
    @RBEntry("若想複製下方連結，在文字欄位內反白標示文字，再使用複製/貼上功能")
    public static final String SAVE_ZIP_LINK_TEXT_HEADING = "2318";
    @RBEntry("選取下方連結，預設的電子郵件應用程式即會開啟視窗，供您撰寫。")
    public static final String SAVE_ZIP_LINK_EMAIL_HEADING = "2319";
    @RBEntry("連至 {0} 表示的電子郵件連結")
    public static final String SAVE_ZIP_LINK_EMAIL_MSG = "2320";
    @RBEntry("管理")
    public static final String ADMIN_TITLE = "8001";
    @RBEntry("管理任務")
    public static final String ADMIN_HEADING = "8002";
    @RBEntry("Worker Agent  監視器")
    public static final String ADMIN_CAD_AGENT = "8003";
    @RBEntry("發佈排程器")
    public static final String ADMIN_SCHEDULER = "8004";
    @RBEntry("關閉")
    public static final String ADMIN_CLOSE = "8005";
    @RBEntry("發佈與縮圖控制")
    public static final String ADMIN_VETO = "8006";
    @RBEntry("伺服器控制的 Creo View 組態")
    public static final String ADMIN_PVCONFIG = "8007";
    @RBEntry("此前後關聯已有組態。每個前後關聯只允許一個組態。")
    public static final String ADMIN_MULTIPLE_CONFIG_WARNING = "ADMIN_MULTIPLE_CONFIG_WARNING";
    @RBEntry("Worker Agent 管理")
    public static final String CAD_TITLE = "8101";
    @RBEntry("配置")
    public static final String CAD_CONFIGURE = "8102";
    @RBEntry("關閉")
    public static final String CAD_CLOSE = "8103";
    @RBEntry("Worker Agent 管理")
    public static final String CAD_HEADING = "8104";
    @RBEntry("全部開始")
    public static final String CAD_START_ALL = "8105";
    @RBEntry("啟動所有 workers")
    public static final String CAD_START_ALL_TIP = "8106";
    @RBEntry("全部停止")
    public static final String CAD_STOP_ALL = "8107";
    @RBEntry("停止所有 workers")
    public static final String CAD_STOP_ALL_TIP = "8108";
    @RBEntry("重新載入")
    public static final String CAD_RELOAD = "8109";
    @RBEntry("重新載入 Worker Agent 組態檔")
    public static final String CAD_RELOAD_TIP = "8110";
    @RBEntry("Worker")
    public static final String CAD_WORKER = "8111";
    @RBEntry("狀況")
    public static final String CAD_STATUS = "8112";
    @RBEntry("動作")
    public static final String CAD_ACTION = "8113";
    @RBEntry("工作")
    public static final String CAD_JOB = "8114";
    @RBEntry("編號")
    public static final String CAD_NUMBER = "8115";
    @RBEntry("日期")
    public static final String CAD_DATE = "8116";
    @RBEntry("Worker Agent 傳回錯誤")
    public static final String CAD_ERROR = "8117";
    @RBEntry("自動重新整理")
    public static final String CAD_AUTO_REFRESH = "8118";
    @RBEntry("忙碌,開啟,關閉,可使用,開始失敗")
    public static final String CAD_STATES = "8119";
    @RBEntry("啟動 worker")
    public static final String CAD_START = "8120";
    @RBEntry("停止 worker")
    public static final String CAD_STOP = "8121";
    @RBEntry("未設定可執行檔")
    public static final String CAD_EXE_NOT_SET = "CAD_EXE_NOT_SET";
    @RBEntry("可執行檔不安全")
    public static final String CAD_EXE_NOT_SAFE = "CAD_EXE_NOT_SAFE";
    @RBEntry("代理程式或 Worker")
    public static final String CAD_AGENTWORKER = "8122";
    @RBEntry("在線上")
    public static final String CAD_ONLINE = "8123";
    @RBEntry("使 worker 處於離線狀態")
    public static final String CAD_MAKE_OFFLINE = "8124";
    @RBEntry("使 worker 保持線上")
    public static final String CAD_MAKE_ONLINE = "8125";
    @RBEntry("重新整理清單")
    public static final String CAD_REFRESH = "8126";
    @RBEntry("重新整理 worker 清單")
    public static final String CAD_REFRESH_TIP = "8127";
    @RBEntry("測試 worker")
    public static final String CAD_TEST_WORKER = "8128";
    @RBEntry("Worker 測試")
    public static final String CAD_TEST_TITLE = "8129";
    @RBEntry("啟動 worker 測試")
    public static final String CAD_TEST_START = "8130";
    @RBEntry("Worker 測試已完成，有錯誤產生")
    public static final String CAD_TEST_ERROR = "8131";
    @RBEntry("已完成 Worker 測試")
    public static final String CAD_TEST_END = "8132";
    @RBEntry("檢視 worker 記錄檔")
    public static final String CAD_LOG_WORKER = "8133";
    @RBEntry("Worker 記錄檔")
    public static final String CAD_LOG_TITLE = "8134";
    @RBEntry("Worker {1} 的 Worker 記錄檔 {0}")
    public static final String CAD_LOG_HEADING = "8135";
    @RBEntry("Worker 記錄檔")
    public static final String CAD_LOGFILES_TITLE = "8136";
    @RBEntry("Worker {0} 的記錄檔")
    public static final String CAD_LOGFILES_HEADING = "8137";
    @RBEntry("重新整理清單")
    public static final String CAD_LOGFILES_REFRESH = "8138";
    @RBEntry("重新整理記錄檔的清單")
    public static final String CAD_LOGFILES_REFRESH_TIP = "8139";
    @RBEntry("記錄檔")
    public static final String CAD_LOGFILES_FILE = "8140";
    @RBEntry("檔案大小")
    public static final String CAD_LOGFILES_SIZE = "8141";
    @RBEntry("建立時間")
    public static final String CAD_LOGFILES_ATIME = "8142";
    @RBEntry("上次修改")
    public static final String CAD_LOGFILES_MTIME = "8143";
    @RBEntry("無法使用")
    public static final String CAD_NOT_AVAILABLE = "8144";
    @RBEntry("啟動詳細資訊 workers")
    public static final String CAD_START_IN_DEBUG = "8145";
    @RBEntry("停止 worker 監視器")
    public static final String CAD_STOP_MONITOR = "8146";
    @RBEntry("排程工作")
    public static final String SCH_TITLE = "8201";
    @RBEntry("關閉")
    public static final String SCH_CLOSE = "8202";
    @RBEntry("排程的工作")
    public static final String SCH_LIST_HEADING = "8203";
    @RBEntry("佇列")
    public static final String SCH_QUEUE = "8204";
    @RBEntry("名稱")
    public static final String SCH_NAME = "8205";
    @RBEntry("描述")
    public static final String SCH_DESCRIPTION = "8206";
    @RBEntry("開始日期")
    public static final String SCH_START_DATE = "8207";
    @RBEntry("下一個日期")
    public static final String SCH_NEXT_DATE = "8208";
    @RBEntry("即將執行")
    public static final String SCH_TO_BE_RUN = "8209";
    @RBEntry("計數")
    public static final String SCH_COUNT = "8210";
    @RBEntry("頻率")
    public static final String SCH_FREQUENCY = "8211";
    @RBEntry("類別")
    public static final String SCH_CLASS = "8212";
    @RBEntry("方法")
    public static final String SCH_METHOD = "8213";
    @RBEntry("工作")
    public static final String SCH_PUBLISH = "8214";
    @RBEntry("結束,一次,完成,日,時,分")
    public static final String SCH_STATES = "8215";
    @RBEntry("已完成")
    public static final String SCH_STATES_COMPLETED = "8215A";
    @RBEntry("完成")
    public static final String SCH_STATES_DONE = "8215B";
    @RBEntry("{0} 的排程工作")
    public static final String SCH_LIST_HEADING_FOR = "8216";
    @RBEntry("{0} 的排程工作")
    public static final String SCH_HEADING_FOR = "8220";
    @RBEntry("排程工作")
    public static final String SCH_HEADING = "8221";
    @RBEntry("佇列:")
    public static final String SCH_IN_QUEUE = "8222";
    @RBEntry("名稱:")
    public static final String SCH_IN_NAME = "8223";
    @RBEntry("描述:")
    public static final String SCH_IN_DESCRIPTION = "8224";
    @RBEntry("工作:")
    public static final String SCH_IN_PUBLISH = "8225";
    @RBEntry("開始工作:")
    public static final String SCH_IN_START = "8226";
    @RBEntry("年")
    public static final String SCH_IN_YEAR = "8227";
    @RBEntry("月")
    public static final String SCH_IN_MONTH = "8228";
    @RBEntry("日")
    public static final String SCH_IN_DAY = "8229";
    @RBEntry("時")
    public static final String SCH_IN_HOUR = "8230";
    @RBEntry("分")
    public static final String SCH_IN_MINUTES = "8231";
    @RBEntry("立刻發行")
    public static final String SCH_IN_IMMEDIATE = "8233";
    @RBEntry("工作頻率:")
    public static final String SCH_IN_FREQUENCY = "8234";
    @RBEntry("一次")
    public static final String SCH_IN_ONCE = "8235";
    @RBEntry("排程")
    public static final String SCH_IN_SCHEDULE = "8236";
    @RBEntry("關閉")
    public static final String SCH_IN_CLOSE = "8237";
    @RBEntry("發行時間")
    public static final String SCH_IN_ON = "8238";
    @RBEntry("每隔")
    public static final String SCH_IN_EVERY = "8239";
    @RBEntry("選取任務")
    public static final String SCH_SELECT_TASK = "8240";
    @RBEntry("必須指定頻率")
    public static final String SCH_SPECIFY_FREQUENCY = "8241";
    @RBEntry("必須指定天數的頻率")
    public static final String SCH_SPECIFY_VALID_DAY = "8242";
    @RBEntry("所指定的日期無效")
    public static final String SCH_INVALID_DATE = "8243";
    @RBEntry("必須指定名稱")
    public static final String SCH_SPECIFY_NAME = "8244";
    @RBEntry("日")
    public static final String SCH_IN_EVERY_DAY = "8245";
    @RBEntry("時")
    public static final String SCH_IN_EVERY_HOUR = "8246";
    @RBEntry("分")
    public static final String SCH_IN_EVERY_MINUTES = "8247";
    @RBEntry("只建立記錄檔")
    public static final String SCH_LOG_FILE_ONLY = "8248";
    @RBEntry("狀況")
    public static final String SCH_CURRENT_STATUS = "8249";
    @RBEntry("重新整理清單")
    public static final String SCH_REFRESH = "8250";
    @RBEntry("重新整理排程工作清單")
    public static final String SCH_REFRESH_TIP = "8251";
    @RBEntry("排定工作記錄檔")
    public static final String SCH_JOB_LOG = "8252";
    @RBEntry("前後關聯")
    public static final String SCH_CONTAINER = "8253";
    @RBEntry("工作類型:")
    public static final String SCH_IN_JOB_TYPE = "8254";
    @RBEntry("使用最新版序:")
    public static final String CLASH_DEFINITION_LATEST = "8255";
    @RBEntry("干涉偵測定義:")
    public static final String CLASH_DEFINITION_PICKER = "8256";
    @RBEntry("刪除超過以下時間的工作:")
    public static final String DELETE_COMPLETE_JOBS_DAYS_PICKER = "8259";
    @RBEntry("請輸入有效數字。")
    public static final String VALIDATE_DELETE_COMPLETE_JOBS_DAYS_PICKER = "8260";
    @RBEntry("天。")
    public static final String DAYS = "8261";
    @RBEntry("搜尋")
    public static final String CLASH_DEFINITION_PICKER_BUTTON = "8257";
    @RBEntry("提交前，請先選取干涉偵測定義")
    public static final String CLASH_DEFINITION_PICKER_VALIDATOR = "8258";
    @RBEntry("協同合作工作階段")
    public static final String COLLAB_TITLE = "8301";
    @RBEntry("可視協同合作工作階段")
    public static final String COLLAB_HEADING = "8302";
    @RBEntry("開始工作階段")
    public static final String COLLAB_CREATE = "8303";
    @RBEntry("開始新的可視協同合作工作階段")
    public static final String COLLAB_CREATE_TIP = "8304";
    @RBEntry("重新整理清單")
    public static final String COLLAB_REFRESH = "8305";
    @RBEntry("重新整理可視協同合作工作階段清單")
    public static final String COLLAB_REFRESH_TIP = "8306";
    @RBEntry("工作階段擁有者")
    public static final String COLLAB_OWNER = "8307";
    @RBEntry("使用者")
    public static final String COLLAB_USERS = "8308";
    @RBEntry("描述")
    public static final String COLLAB_DESCRIPTION = "8309";
    @RBEntry("伺服器字串")
    public static final String COLLAB_STRING = "8310";
    @RBEntry("清除主控")
    public static final String COLLAB_CLEAR_ACTIVE = "8311";
    @RBEntry("從 Windchill 工作階段清除主控可視協同合作")
    public static final String COLLAB_CLEAR_ACTIVE_TIP = "8312";
    @RBEntry("您主控可視協同合作工作階段，將共用 Creo View 內載入的資料")
    public static final String COLLAB_WARNING = "8313";
    @RBEntry("開始協同合作工作階段")
    public static final String COLLAB_NEW_TITLE = "8401";
    @RBEntry("開始可視協同合作工作階段")
    public static final String COLLAB_NEW_HEADING = "8402";
    @RBEntry("描述:")
    public static final String COLLAB_NEW_DESCRIPTION = "8403";
    @RBEntry("密碼:")
    public static final String COLLAB_NEW_PASS = "8404";
    @RBEntry("確認密碼:")
    public static final String COLLAB_NEW_CONFIRM_PASS = "8405";
    @RBEntry("確定")
    public static final String COLLAB_NEW_OK = "8406";
    @RBEntry("取消")
    public static final String COLLAB_NEW_CANCEL = "8407";
    @RBEntry("密碼不同。請重新輸入密碼。")
    public static final String COLLAB_NEW_UNMATCHED_PASS = "8408";
    @RBEntry("「描述」或「密碼」不可使用 % 此字元。")
    public static final String COLLAB_NEW_NO_PERCENT = "8409";
    @RBEntry("開始新的協同合作工作階段。可選擇指定描述和密碼。")
    public static final String COLLAB_NEW_SUBHEADING = "8410";
    @RBEntry("協同合作工作階段無法開始。請洽詢系統管理員，確定已安裝配置協同合作代理程式。")
    public static final String COLLAB_FAILED_TO_START = "8411";
    @RBEntry("確定")
    public static final String UL_OK = "8501";
    @RBEntry("取消")
    public static final String UL_CANCEL = "8502";
    @RBEntry("更新位置")
    public static final String UL_UPDATE_LOCATION = "8503";
    @RBEntry("位置更新完畢，您可以關閉瀏覽器視窗")
    public static final String UL_UPDATE_COMPLETE = "8504";
    @RBEntry("從 Creo View 'location' 內容值複製/貼上位置字串")
    public static final String UL_COPY_PASTE = "8505";
    @RBEntry("再生縮圖:")
    public static final String UL_REGENERATE_THUMBNAIL = "8506";
    @RBEntry("正在儲存...")
    public static final String UL_SAVING = "8507";
    @RBEntry("發佈與縮圖控制")
    public static final String VETO_TITLE = "8601";
    @RBEntry("發佈與縮圖控制")
    public static final String VETO_HEADING = "8602";
    @RBEntry("關閉")
    public static final String VETO_CLOSE = "8603";
    @RBEntry("新增")
    public static final String VETO_ADD = "8604";
    @RBEntry("編號:")
    public static final String VETO_NUMBER = "8605";
    @RBEntry("名稱:")
    public static final String VETO_NAME = "8606";
    @RBEntry("尋找")
    public static final String VETO_FIND = "8607";
    @RBEntry("僅禁止縮圖建立")
    public static final String VETO_THUMBNAIL_ONLY = "8608";
    @RBEntry("發佈控制物件")
    public static final String VETO_LIST_HEADING = "8609";
    @RBEntry("編號")
    public static final String VETO_LIST_NUMBER = "8610";
    @RBEntry("名稱")
    public static final String VETO_LIST_NAME = "8611";
    @RBEntry("版本")
    public static final String VETO_LIST_VERSION = "8612";
    @RBEntry("控制類型")
    public static final String VETO_LIST_TYPE = "8613";
    @RBEntry("發佈")
    public static final String VETO_LIST_TYPE_PUBLISH = "8614";
    @RBEntry("縮圖")
    public static final String VETO_LIST_TYPE_THUMBNAIL = "8615";
    @RBEntry("刪除發佈控制")
    public static final String VETO_DELETE_TIP = "8616";
    @RBEntry("描述:")
    public static final String VETO_DESCRIPTION = "8617";
    @RBEntry("描述")
    public static final String VETO_LIST_DESCRIPTION = "8618";
    @RBEntry("全部")
    public static final String VETO_LIST_ALL = "8619";
    @RBEntry("未新增發佈控制 (檢查號碼)")
    public static final String VETO_NO_ADD = "8620";
    @RBEntry("發佈 {0} 的控制物件")
    public static final String VETO_LIST_HEADING_FOR = "8621";
    @RBEntry("{0} 的發佈與縮圖控制")
    public static final String VETO_HEADING_FOR = "8622";
    @RBEntry("搜尋 ...")
    public static final String VETO_BROWSE = "8623";
    @RBEntry("搜尋 CAD 文件")
    public static final String VETO_SEARCH_CAD = "8624";
    @RBEntry("在 {0} 內搜尋 CAD 文件/ 動態文件")
    public static final String VETO_SEARCH_CAD_FOR = "8625";
    @RBEntry("搜尋")
    public static final String VETO_SEARCH = "8627";
    @RBEntry("找不到物件")
    public static final String VETO_SEARCH_NO_ITEMS_FOUND = "8628";
    @RBEntry("前後關聯")
    public static final String VETO_LIST_CONTAINER = "8629";
    @RBEntry("定位組件")
    public static final String VETO_LIST_TYPE_POSASSY = "8630";
    @RBEntry("以定位組件發佈")
    public static final String VETO_POSASSY = "8631";
    @RBEntry("禁止發佈")
    public static final String VETO_PUBLISH = "8632";
    @RBEntry("未新增發佈控制 (確認 CAD 文件可以定位組件發佈)")
    public static final String VETO_NO_ADD_POSASSY = "8633";
    @RBEntry("未新增發佈控制 (確認 CAD 文件可作為延伸的定位組件發佈)")
    public static final String VETO_NO_ADD_EXED_POSASSY = "8633B";
    @RBEntry("延伸的定位組件 [{0}]")
    public static final String VETO_LIST_TYPE_XPOSASSY = "8634";
    @RBEntry("以延伸的定位組件發佈")
    public static final String VETO_XPOSASSY = "8635";
    @RBEntry("未加入發佈控制，您必須針對延伸的定位組件指定 CAD 表單名稱。")
    public static final String VETO_NO_ADD_XPOSASSY = "8636";
    @RBEntry("Creo View 組態")
    public static final String PVCONFIG_TITLE = "8701";
    @RBEntry("Creo View  的 {0} 組態")
    public static final String PVCONFIG_LIST_HEADING = "8702";
    @RBEntry("建立組態")
    public static final String PVCONFIG_NEW = "8703";
    @RBEntry("建立新 Creo View 組態")
    public static final String PVCONFIG_NEW_TIP = "8704";
    @RBEntry("組態類型")
    public static final String PVCONFIG_NAME = "8705";
    @RBEntry("前後關聯")
    public static final String PVCONFIG_CONTEXT = "8706";
    @RBEntry("刪除 Creo View 組態")
    public static final String PVCONFIG_DELETE_CONFIG_TIP = "8707";
    @RBEntry("{0} 的檔案")
    public static final String PVCONFIG_CONTENT_LIST_HEADING = "8708";
    @RBEntry("新增檔案至組態")
    public static final String PVCONFIG_NEW_FILE = "8709";
    @RBEntry("新增檔案至組態")
    public static final String PVCONFIG_NEW_FILE_TIP = "8710";
    @RBEntry("檔案名稱")
    public static final String PVCONFIG_FILE_NAME = "8711";
    @RBEntry("從組態中刪除檔案")
    public static final String PVCONFIG_DELETE_CONTENT_TIP = "8712";
    @RBEntry("新增新建檔案")
    public static final String PVCONFIG_NEW_FILE_HEADING = "8713";
    @RBEntry("取消")
    public static final String PVCONFIG_CANCEL = "8714";
    @RBEntry("新增檔案")
    public static final String PVCONFIG_ADD_FILE = "8715";
    @RBEntry("建立")
    public static final String PVCONFIG_CREATE = "8716";
    @RBEntry("請求中遺失 \"fileName\" 這個表單欄位")
    public static final String PVCONFIG_FILENAME_FIELD_MISSING = "8717";
    @RBEntry("遺失 WVSConfigurationTemplate 物件參考")
    public static final String PVCONFIG_OBJREF_MISSING = "8718";
    @RBEntry("請選取欲新增到組態的檔案")
    public static final String PVCONFIG_NO_FILE_SPECIFIED = "8719";
    @RBEntry("新增檔案至組態失敗")
    public static final String PVCONFIG_FAILED_TO_ADD_FILE = "8720";
    @RBEntry("檔案資料沒上載，這個檔案的大小可能為零，或者此檔案根本不存在")
    public static final String PVCONFIG_ZERO_SIZE_FILE = "8721";
    @RBEntry("此組態已具有同名的檔案")
    public static final String PVCONFIG_ALREADY_FILE = "8722";
    @RBEntry("檔案名稱:")
    public static final String PVCONFIG_INPUT_FILE_NAME = "8723";
    @RBEntry("檔案大小")
    public static final String PVCONFIG_FILE_SIZE = "8724";
    @RBEntry("組態類型:")
    public static final String PVCONFIG_INPUT_NAME = "8725";
    @RBEntry("建立新組態")
    public static final String PVCONFIG_CREATE_NEW = "8726";
    @RBEntry("預設類型")
    public static final String PVCONFIG_DEFAULT_TYPE = "8727";
    @RBEntry("此組態內不具檔案")
    public static final String PVCONFIG_NO_FILES = "8728";
    @RBEntry("新建 {0} 的組態")
    public static final String PVCONFIG_CREATE_NEW_FOR = "8729";
    @RBEntry("檔案")
    public static final String PVCONFIG_CONTENT_LIST_TITLE = "8730";
    @RBEntry("此前後關聯不具組態")
    public static final String PVCONFIG_NO_CONFIGS = "8731";
    @RBEntry("可依需要指定一個類型，使用者修改受檢視物件的存取權限時，可使用此類型來提供另一個組態。請參見 \"productview.modifyconfigtype\" 內容。")
    public static final String PVCONFIG_INPUT_NAME_HEADING = "8732";
    @RBEntry("可指定單一檔案，亦可指定內含一組檔案的 zip/jar 檔案。")
    public static final String PVCONFIG_INPUT_FILE_NAME_HEADING = "8733";
    @RBEntry("操作系统为Windows10、Windows11 ，请下载安装程序")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM_NEW = "8734";
    @RBEntry("操作系统为Windows7 ，请下载安装程序")
    public static final String DOWNLOAD_CLICK_HERE_DOWNLOAD_FROM_NEWCX = "8735";
    @RBEntry(".exe 文件可以自动运行，也可以先下载，稍后再运行。")
    public static final String DOWNLOAD_MSI_FILE_NEW = "8736";
    public messageResource_zh_TW() {
    }
}
