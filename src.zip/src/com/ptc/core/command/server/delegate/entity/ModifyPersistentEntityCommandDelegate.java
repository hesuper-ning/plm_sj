//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.core.command.server.delegate.entity;

import com.ptc.core.command.common.Command;
import com.ptc.core.command.common.CommandException;
import com.ptc.core.command.common.bean.entity.UpdatePersistentEntityCommand;
import com.ptc.core.command.common.delegate.CommandDelegateUtility;
import com.ptc.core.command.server.delegate.AbstractRemoteCommandDelegate;
import com.ptc.core.command.server.delegate.io.GenericSetterCommandDelegate;
import com.ptc.core.meta.common.AssociationIdentifier;
import com.ptc.core.meta.common.AttributeIdentifier;
import com.ptc.core.meta.common.OperationIdentifier;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.common.impl.WCPersistableInstanceIdentifier;
import com.ptc.core.meta.common.impl.WCTypeInstanceIdentifier;
import com.ptc.core.meta.container.common.ConstraintContainer;
import com.ptc.core.meta.container.common.State;
import com.ptc.core.meta.container.common.impl.BasicAttributeContainer;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.core.meta.type.common.impl.DefaultTypeInstance;
import ext.plm.util.CtCommonUtil;
import ext.plm.util.CtFormatUtil;
import org.apache.log4j.Logger;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.iba.value.litevalue.AbstractValueViewMap;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.part.Quantity;
import wt.part.QuantityUnit;
import wt.part.WTPartUsageLink;
import wt.util.WTContext;
import wt.util.WTException;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ModifyPersistentEntityCommandDelegate extends AbstractRemoteCommandDelegate {
    private static final String RESOURCE = "com.ptc.core.command.server.delegate.entity.entityResource";
    private static final String CLASSNAME = ModifyPersistentEntityCommandDelegate.class.getName();
    private static final Logger logger;

    public ModifyPersistentEntityCommandDelegate() {
    }

    protected Command doExecution(Command var1) throws CommandException {
        if (DEBUG) {
            getDebugLog(var1).enter(CLASSNAME, "doExecution", new Object[]{var1});
        }

        CommandDelegateUtility.validateCommand(var1, UpdatePersistentEntityCommand.class);
        UpdatePersistentEntityCommand var2 = (UpdatePersistentEntityCommand)var1;

        try {
            TypeInstance var3 = var2.getSource();
            boolean var18 = ((TypeInstanceIdentifier)var3.getIdentifier()).getInstanceIdentifier() instanceof WCPersistableInstanceIdentifier;
            Persistable var19 = this.populatePersistable(var3, OperationIdentifier.newOperationIdentifier("STDOP|com.ptc.windchill.update"));


            //客制化-start ***********************************************
            WTPartUsageLink usageLink = (WTPartUsageLink) var19;
            usageLink = (WTPartUsageLink) PersistenceHelper.manager.refresh(usageLink);
            DefaultTypeInstance source = (DefaultTypeInstance) var2.getSource();
            BasicAttributeContainer attributeContainer = (BasicAttributeContainer) source.getAttributeContainer();
            AttributeIdentifier[] attributeIdentifiers = attributeContainer.getAttributeIdentifiers();
            if (attributeIdentifiers.length > 0) {
                AttributeIdentifier attributeIdentifier = attributeIdentifiers[0];
                String definitionIdentifier = attributeIdentifier.getDefinitionIdentifier().toExternalForm();
                if (CtFormatUtil.hasContent(definitionIdentifier)) {
                    //分数
                    if(definitionIdentifier.contains("ct_fraction")){
                        Object object = attributeContainer.get(attributeIdentifier);
                        if(null != object){
                            String fraction = object.toString();
                            //校验分数
                            if(!CtCommonUtil.isFraction(fraction)){
                                throw new WTException("分数字段只能输入分数,正确格式如：1/2 或 2/1");
                            }
                            //分数转成小数
                            double dosage = CtFormatUtil.formatFraction(fraction);
                            Quantity quantity = usageLink.getQuantity();
                            if(null != quantity){
                                QuantityUnit quantityUnit = quantity.getUnit();
                                if(null != quantityUnit && "PCS".equals(quantityUnit.toString())){
                                    if(Math.round(dosage) != dosage){
                                        throw new WTException("单位为“个”时，值必须为整数!");
                                    }
                                }
                            }
//                            IBAUtil ibaUtil = new IBAUtil(usageLink);
//                            ibaUtil.setIBAValue(CtBomConstant.IBA_FRACTION, fraction);
//                            ibaUtil.updateIBAHolder(usageLink);
                        }
                    }
                }
            }else{
//                if(attributeContainer.toString().contains("~IBA|ct_fraction") && attributeContainer.toString().contains("State: DELETED")){
//                    IBAUtil ibaUtil = new IBAUtil(usageLink);
//                    ibaUtil.setIBAValue(CtBomConstant.IBA_FRACTION, "");
//                    ibaUtil.updateIBAHolder(usageLink);
//                }
            }
            //客制化-end ***********************************************


            if (var3.getConstraintContainer() != null) {
                var3.setConstraintContainer((ConstraintContainer)null);
            }

            boolean var5 = MethodContext.getContext().containsKey("MultiObjIBAValueDBService.METHOD_CONTEXT_KEY");
            if (!var5) {
                MethodContext.getContext().put("MultiObjIBAValueDBService.METHOD_CONTEXT_KEY", new AbstractValueViewMap());
            }

            AbstractValueViewMap var6 = (AbstractValueViewMap)MethodContext.getContext().get("MultiObjIBAValueDBService.METHOD_CONTEXT_KEY");
            boolean var7 = MethodContext.getContext().containsKey("REPLACEMENTS_METHOD_CONTEXT_KEY");
            if (!var7) {
                MethodContext.getContext().put("REPLACEMENTS_METHOD_CONTEXT_KEY", new HashMap());
            }

            HashSet var8 = new HashSet();
            AttributeIdentifier[] var9 = var3.getAttributeIdentifiers(State.CHANGED);
            AttributeIdentifier[] var10 = var9;
            int var11 = var9.length;

            for(int var12 = 0; var12 < var11; ++var12) {
                AttributeIdentifier var13 = var10[var12];
                if (!(var13 instanceof AssociationIdentifier) && var3.get(var13) == null) {
                    var8.add(var13);
                }
            }

            var19 = this.populatePersistable(var3, OperationIdentifier.newOperationIdentifier("STDOP|com.ptc.windchill.update"));
            var19 = this.persist(var19);
            CreatePersistentEntityCommandDelegate.replaceIBAs(var3, var6.toMap());
            HashMap var20 = (HashMap)MethodContext.getContext().get("REPLACEMENTS_METHOD_CONTEXT_KEY");
            if (var20 != null && var20.size() > 0) {
                var3 = CreatePersistentEntityCommandDelegate.replace(var3, var19, var20);
            }

            if (!var5) {
                MethodContext.getContext().remove("MultiObjIBAValueDBService.METHOD_CONTEXT_KEY");
            }

            if (!var7) {
                MethodContext.getContext().remove("REPLACEMENTS_METHOD_CONTEXT_KEY");
            }

            Object var21 = TypeIdentifierUtility.getTypeInstanceIdentifier(var19);
            if (var18 && var21 instanceof WCTypeInstanceIdentifier) {
                var21 = ((WCTypeInstanceIdentifier)var21).getWithWCPersistableInstanceIdentifier();
            }

            TypeInstance var22 = this.doPrepareEntityCommand((TypeInstanceIdentifier)var21, var2.getFilter(), WTContext.getContext().getLocale());
            if (var22.getIdentifier() == null) {
                var2.setResult(var22);
            } else {
                var3.merge(var22);
                Iterator var14 = var8.iterator();

                while(var14.hasNext()) {
                    AttributeIdentifier var15 = (AttributeIdentifier)var14.next();
                    if (var3.getState(var15).equals(State.CHANGED) && var3.get(var15) == null) {
                        var3.setState(var15, State.UNCHANGED);
                    }
                }

                var2.setResult(var3);
            }
        } catch (Exception var17) {
            StringBuffer var4 = new StringBuffer();
            var4.append("EXCEPTION DURING UPDATE[\n");
            var4.append("SOURCE:\n");
            var4.append(var2.getSource());
            var4.append("FILTER:\n");

            try {
                var4.append(var2.getFilter());
            } catch (CommandException var16) {
                var4.append("ERROR!\n");
            }

            var4.append("]EXCEPTION DURING UPDATE");
            throw new CommandException(var17, var4.toString());
        }

        if (DEBUG) {
            getDebugLog(var2).exit(CLASSNAME, "doExecution", var2);
        }

        return var2;
    }

    public Persistable persist(Persistable var1) throws WTException {
        if (wasBusinessAttModified(var1)) {
            removeBusinessAttFromMC(var1);
            if (logger.isTraceEnabled()) {
                logger.trace("Persisting changes to " + var1 + " AND updating time stamp.");
            }

            return PersistenceHelper.manager.modify(var1);
        } else {
            if (logger.isTraceEnabled()) {
                logger.trace("Persisting changes to " + var1 + " and NOT updating time stamp.");
            }

            PersistenceServerHelper.manager.update(var1, false);
            return var1;
        }
    }

    protected static boolean wasBusinessAttModified(Persistable var0) {
        boolean var1 = false;
        if (MethodContext.getContext().containsKey(GenericSetterCommandDelegate.BUSINESS_ATT_KEY)) {
            Set var2 = (Set)MethodContext.getContext().get(GenericSetterCommandDelegate.BUSINESS_ATT_KEY);
            if (var2 != null && var2.contains(var0)) {
                var1 = true;
            }
        }

        return var1;
    }

    protected static void removeBusinessAttFromMC(Persistable var0) {
        Set var1 = (Set)MethodContext.getContext().get(GenericSetterCommandDelegate.BUSINESS_ATT_KEY);
        if (var1 != null) {
            var1.remove(var0);
        }

    }

    protected void finalize(Command var1) throws CommandException {
    }

    static {
        logger = LogR.getLogger(CLASSNAME);
    }
}
