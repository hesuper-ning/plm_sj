package com.ptc.core.ui.tab;

import com.ptc.core.ui.tab.ClientTab;
import com.ptc.core.ui.tab.DefaultTabSetDelegate;
import com.ptc.core.ui.tab.server.ClientTabHelper;
import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.netmarkets.util.misc.NmHTMLActionModel;
import com.ptc.netmarkets.util.misc.NmHTMLTabActionModel;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import wt.fc.PersistenceHelper;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;

import java.util.ArrayList;
import java.util.Iterator;

public class HomePageTabDelegate extends DefaultTabSetDelegate {
    private static final Logger log = LogR.getLogger(HomePageTabDelegate.class
            .getName());

    public NmHTMLActionModel getDefaultAndDynamicTabs() throws WTException {
        NmHTMLActionModel localNmHTMLActionModel = super
                .getDefaultAndDynamicTabs();
        try {
            NmHTMLTabActionModel localNmHTMLTabActionModel1 = checkAndLazyLoadSiteTab(localNmHTMLActionModel);
            Object localObject;
            //管理员页面
            if (WTContainerHelper.service.isAdministrator(
                    WTContainerHelper.service.getExchangeRef(),
                    SessionHelper.getPrincipal())) {
                localObject = WTMessage.getLocalizedMessage(
                        "com.ptc.core.ui.navigationRB", "PUBLIC_TAB", null,
                        SessionHelper.getLocale());

                localNmHTMLTabActionModel1.setLabel((String) localObject);

                NmHTMLTabActionModel localNmHTMLTabActionModel2 = getPrivateTabActionModel(localNmHTMLActionModel);
                String str1 = WTMessage.getLocalizedMessage(
                        "com.ptc.core.ui.navigationRB", "PRIVATE_TAB", null,
                        SessionHelper.getLocale());

                if (localNmHTMLTabActionModel2 == null) {
                    String str2 = getJSONStringForActionModel(localNmHTMLTabActionModel1);

                    ClientTab localClientTab = ClientTabHelper.service.saveTab(
                            "homepage", "home-page", "home-page", str2, false);

                    localNmHTMLTabActionModel2 = (NmHTMLTabActionModel) buildActionModelForTab(
                            localClientTab, true);

                    localNmHTMLTabActionModel2.setLabel(str1);
                } else {
                    localNmHTMLTabActionModel2.setLabel(str1);
                }

                //自定义
                ClientTab localClientTab = makeProjectTab();
                NmHTMLTabActionModel projectNmHTMLTabActionModel = (NmHTMLTabActionModel) buildActionModelForTab(
                        localClientTab, true);

                ClientTab reportClientTab = makeProjecReportTab();
                NmHTMLTabActionModel reportNmHTMLTabActionModel = (NmHTMLTabActionModel) buildActionModelForTab(
                        reportClientTab, true);

                localNmHTMLActionModel = new NmHTMLActionModel();
                localNmHTMLActionModel.add(localNmHTMLTabActionModel2);
                localNmHTMLActionModel.add(localNmHTMLTabActionModel1);
                localNmHTMLActionModel.add(projectNmHTMLTabActionModel);
                localNmHTMLActionModel.add(reportNmHTMLTabActionModel);
            } else {
                //私人页面----原生
				/*localObject = getPrivateTabActionModel(localNmHTMLActionModel);
				localNmHTMLActionModel = new NmHTMLActionModel();

				localNmHTMLActionModel.add(localObject != null ? localObject
						: localNmHTMLTabActionModel1);
				NmHTMLTabActionModel localNmHTMLTabActionModel2 = getPrivateTabActionModel(localNmHTMLActionModel);
				String str1 = WTMessage.getLocalizedMessage(
						"com.ptc.core.ui.navigationRB", "PRIVATE_TAB", null,
						SessionHelper.getLocale());
				localNmHTMLTabActionModel2.setLabel("流程专用");*/
                NmHTMLTabActionModel localNmHTMLTabActionModel2 = getPrivateTabActionModel(localNmHTMLActionModel);
                String str1 = WTMessage.getLocalizedMessage(
                        "com.ptc.core.ui.navigationRB", "PRIVATE_TAB", null,
                        SessionHelper.getLocale());
                if (localNmHTMLTabActionModel2 == null) {
                    String str2 = getJSONStringForActionModel(localNmHTMLTabActionModel1);

                    ClientTab localClientTab = ClientTabHelper.service.saveTab(
                            "homepage", "home-page", "home-page", str2, false);

                    localNmHTMLTabActionModel2 = (NmHTMLTabActionModel) buildActionModelForTab(
                            localClientTab, true);

                    localNmHTMLTabActionModel2.setLabel("流程专用");
                } else {
                    localNmHTMLTabActionModel2.setLabel("流程专用");
                }

                //自定义

                ClientTab localClientTab = makeProjectTab();
                NmHTMLTabActionModel projectNmHTMLTabActionModel = (NmHTMLTabActionModel) buildActionModelForTab(
                        localClientTab, true);
                projectNmHTMLTabActionModel.setPublic(false);

                ClientTab reportClientTab = makeProjecReportTab();
                NmHTMLTabActionModel reportNmHTMLTabActionModel = (NmHTMLTabActionModel) buildActionModelForTab(
                        reportClientTab, true);
                reportNmHTMLTabActionModel.setPublic(false);
				
				/*ClientTab reportClientTab = makeProjectReportTab();
				NmHTMLTabActionModel reportmHTMLTabActionModel = (NmHTMLTabActionModel) buildActionModelForTab(
						reportClientTab, true);*/
                localNmHTMLActionModel = new NmHTMLActionModel();
                localNmHTMLActionModel.add(localNmHTMLTabActionModel2);
                localNmHTMLActionModel.add(projectNmHTMLTabActionModel);
                localNmHTMLActionModel.add(reportNmHTMLTabActionModel);
            }
        } catch (Exception localException) {
            log.error("Unable to save the private tab for admin.",
                    localException);
        }
        return (NmHTMLActionModel) localNmHTMLActionModel;
    }

    protected WTCollection getClientTabObjects(
            WTContainerRef paramWTContainerRef1,
            WTContainerRef paramWTContainerRef2, String[] paramArrayOfString)
            throws WTException {
        WTCollection localWTCollection = super.getClientTabObjects(null,
                paramWTContainerRef2, paramArrayOfString);
        WTArrayList localWTArrayList = new WTArrayList();
        Iterator localIterator = localWTCollection.persistableIterator();
        while (localIterator.hasNext()) {
            ClientTab localClientTab = (ClientTab) localIterator.next();
            localClientTab = fixTab(localClientTab);
            localWTArrayList.add(localClientTab);
        }
        return localWTArrayList;
    }

    protected ClientTab fixTab(ClientTab paramClientTab) throws WTException {
        if ((paramClientTab.getContainer() != null)
                && (paramClientTab.getPrincipal() != null)
                && (paramClientTab.getPrincipal().getReferencedClass() != null)) {
            if (log.isDebugEnabled()) {
                log.debug(" Displaying the actions which have both ContainerReference and PrinicipalReference:"
                        + paramClientTab);
            }

            paramClientTab = ClientTabHelper.service.updateTab(
                    ClientTabHelper.getReference(paramClientTab),
                    paramClientTab.getName(), paramClientTab.getComponents(),
                    Boolean.valueOf(false));
        }

        return paramClientTab;
    }

    protected NmHTMLTabActionModel checkAndLazyLoadSiteTab(
            NmHTMLActionModel paramNmHTMLActionModel) throws Exception,
            WTException {
        NmHTMLTabActionModel localNmHTMLTabActionModel = getPublicTabActionModel(paramNmHTMLActionModel);
        if (localNmHTMLTabActionModel == null) {
            ClientTab localClientTab = makeSiteTab();
            localNmHTMLTabActionModel = (NmHTMLTabActionModel) buildActionModelForTab(
                    localClientTab, true);
            paramNmHTMLActionModel.add(localNmHTMLTabActionModel);
        }

        return localNmHTMLTabActionModel;
    }

    protected NmHTMLTabActionModel checkProjectTab(
            NmHTMLActionModel paramNmHTMLActionModel) throws Exception,
            WTException {
        NmHTMLTabActionModel localNmHTMLTabActionModel = getProjectTabActionModel(paramNmHTMLActionModel);
        if (localNmHTMLTabActionModel == null) {
            ClientTab localClientTab = makeProjectTab();
            localNmHTMLTabActionModel = (NmHTMLTabActionModel) buildActionModelForTab(
                    localClientTab, true);
            paramNmHTMLActionModel.add(localNmHTMLTabActionModel);
        }

        return localNmHTMLTabActionModel;
    }

    private NmHTMLTabActionModel getPublicTabActionModel(
            NmHTMLActionModel paramNmHTMLActionModel) {
        NmHTMLTabActionModel localObject1 = null;
        ArrayList localArrayList = paramNmHTMLActionModel.getActions();
        Iterator localIterator = localArrayList.iterator();
        while (localIterator.hasNext()) {
            Object localObject2 = localIterator.next();
            if ((localObject2 instanceof NmHTMLTabActionModel)) {
                NmHTMLTabActionModel localNmHTMLTabActionModel = (NmHTMLTabActionModel) localObject2;
                if (localNmHTMLTabActionModel.isPublic().booleanValue()) {
                    localObject1 = localNmHTMLTabActionModel;

                    break;
                }
            }
        }
        return localObject1;
    }

    private NmHTMLTabActionModel getPrivateTabActionModel(
            NmHTMLActionModel paramNmHTMLActionModel) {
        NmHTMLTabActionModel localObject1 = null;
        ArrayList localArrayList = paramNmHTMLActionModel.getActions();
        Iterator localIterator = localArrayList.iterator();
        while (localIterator.hasNext()) {
            Object localObject2 = localIterator.next();
            if ((localObject2 instanceof NmHTMLTabActionModel)) {
                NmHTMLTabActionModel localNmHTMLTabActionModel = (NmHTMLTabActionModel) localObject2;
                if (!localNmHTMLTabActionModel.isPublic().booleanValue()) {
                    localObject1 = localNmHTMLTabActionModel;

                    break;
                }
            }
        }

        return localObject1;
    }

    private NmHTMLTabActionModel getProjectTabActionModel(
            NmHTMLActionModel paramNmHTMLActionModel) {
        NmHTMLTabActionModel localObject1 = null;
        ArrayList localArrayList = paramNmHTMLActionModel.getActions();
        Iterator localIterator = localArrayList.iterator();
        while (localIterator.hasNext()) {
            Object localObject2 = localIterator.next();
            if ((localObject2 instanceof NmHTMLTabActionModel)) {
                NmHTMLTabActionModel localNmHTMLTabActionModel = (NmHTMLTabActionModel) localObject2;
                if (!localNmHTMLTabActionModel.isPublic().booleanValue()) {
                    localObject1 = localNmHTMLTabActionModel;

                    break;
                }
            }
        }

        return localObject1;
    }

    private String getJSONStringForActionModel(
            NmHTMLTabActionModel paramNmHTMLTabActionModel) {
        JSONArray localJSONArray = new JSONArray();
        ArrayList localArrayList = paramNmHTMLTabActionModel.getActions();
        Iterator localIterator = localArrayList.iterator();
        while (localIterator.hasNext()) {
            NmAction localNmAction = (NmAction) localIterator.next();
            JSONObject localJSONObject = new JSONObject();
            try {
                localJSONObject.putOpt("name", localNmAction.getAction());
                localJSONObject.putOpt("type", localNmAction.getType());
            } catch (JSONException localJSONException) {
                log.error("Unable to get the JSON for action model",
                        localJSONException);
            }
            localJSONArray.put(localJSONObject);
        }
        return localJSONArray.toJSONString();
    }

    protected void setIsPublic(ClientTab paramClientTab,
                               NmHTMLTabActionModel paramNmHTMLTabActionModel) {
        paramNmHTMLTabActionModel.setPublic(Boolean.valueOf(paramClientTab
                .isPublic()));
    }

    protected NmHTMLActionModel buildActionModelForTab(
            ClientTab paramClientTab, boolean paramBoolean) throws WTException {
        NmHTMLActionModel localNmHTMLActionModel = super
                .buildActionModelForTab(paramClientTab, paramBoolean);
        if ((localNmHTMLActionModel instanceof NmHTMLTabActionModel)) {
            ((NmHTMLTabActionModel) localNmHTMLActionModel).setEditable(true);
        }

        return localNmHTMLActionModel;
    }

    protected ClientTab makeSiteTab() throws Exception {
        ClientTab localClientTab = ClientTab.newClientTab();
        localClientTab.setName("homepage");
        localClientTab.setObjectType("home-page");
        localClientTab.setTabSetKey("home-page");
        localClientTab.setContainerReference(WTContainerHelper.service
                .getExchangeRef());
        localClientTab
                .setComponents("[ { \"name\" : \"listAssignments\", \"type\" : \"work\"},{   \"name\" : \"listUpdates\",  \"type\" : \"report\"},{   \"name\" : \"listCheckedOutWork\",  \"type\" : \"user\"}]");

        return (ClientTab) PersistenceHelper.manager.save(localClientTab);
    }

    protected ClientTab makeProjectTab() throws Exception {
        ClientTab localClientTab = ClientTab.newClientTab();
        localClientTab.setName("项目专用");
        localClientTab.setObjectType("home-projectTask");
        localClientTab.setTabSetKey("projectTaskKey");
        localClientTab.setContainerReference(WTContainerHelper.service
                .getExchangeRef());
        localClientTab
                .setComponents("[ { \"name\" : \"ctPlanActivityBuilder\", \"type\" : \"ctProject\"}" +
                        ",{ \"name\" : \"ctPlanDeliverableBuilder\", \"type\" : \"ctProject\"}]");

        return (ClientTab) PersistenceHelper.manager.save(localClientTab);
    }

    protected ClientTab makeProjecReportTab() throws Exception {
        ClientTab localClientTab = ClientTab.newClientTab();
        localClientTab.setName("项目列表");
        localClientTab.setObjectType("home-projectList");
        localClientTab.setTabSetKey("projectListKey");
        localClientTab.setContainerReference(WTContainerHelper.service
                .getExchangeRef());
        localClientTab.setComponents("[ { \"name\" : \"projectListTable\", \"type\" : \"ctProject\"}]");

        return (ClientTab) PersistenceHelper.manager.save(localClientTab);
    }
}