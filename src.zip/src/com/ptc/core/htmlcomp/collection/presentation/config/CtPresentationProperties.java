package com.ptc.core.htmlcomp.collection.presentation.config;

import org.apache.commons.lang3.StringUtils;

import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Properties;


public class CtPresentationProperties {

	private static volatile CtPresentationProperties instance;

	private Properties properties;

	public static CtPresentationProperties getInstance() {
		if(instance==null) {
			synchronized (CtPresentationProperties.class) {
				if(instance==null) {
					instance = new CtPresentationProperties();
				}
			}
		}

		return instance;
	}

	private CtPresentationProperties() {
		try {
			initProperties();
		} catch (Exception e) {
			properties = new Properties();
			System.out.println("com.ptc.core.htmlcomp.collection.presentation.config.CtPresentationProperties.initProperties 失败！");
			e.printStackTrace();
		}
	}

	private void initProperties() throws Exception {
		properties = new Properties();
		properties.load(new InputStreamReader(
				CtPresentationProperties.class.getResourceAsStream("CtPresentation.properties"), "UTF-8"));
	}


	public String getStringValue(String key){
		return this.properties.getProperty(key);
	}

	public Long getLongValue(String key){
		Long resultValue = 0l;
		String value = this.properties.getProperty(key);
		if (StringUtils.isNotEmpty(value)) {
			resultValue = Long.parseLong(value);
		}
		return resultValue;
	}

	public HashSet<String> getHashSetValue(String key){
		HashSet<String> resultValue = new HashSet<>(0);
		String value = this.properties.getProperty(key);
		if (StringUtils.isNotEmpty(value)) {
			String[] values = value.split(",");
			for (String item : values) {
				resultValue.add(item);
			}
		}
		return resultValue;
	}

	public void reload() throws Exception {
		initProperties();
	}
}
