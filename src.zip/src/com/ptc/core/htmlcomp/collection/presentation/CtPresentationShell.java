package com.ptc.core.htmlcomp.collection.presentation;

import com.ptc.core.htmlcomp.collection.presentation.config.CtPresentationProperties;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;

import java.io.Serializable;

public class CtPresentationShell implements Serializable, RemoteAccess {
    private static final long serialVersionUID = 1L;

    public static void main(String[] args) throws Exception {
        String host = args[0];
        if (!RemoteMethodServer.ServerFlag) {
            Class[] cls = { String[].class };
            Object[] obj = { args };
            try {
                RemoteMethodServer rms = RemoteMethodServer.getDefault();
                if ("plmtest".equals(host)) {
                    rms.setUserName("wcadmin");
                    rms.setPassword("wcadmin");
                } else if ("plm".equals(host)) {
                    rms.setUserName("wcadmin");
                    rms.setPassword("Icewcadmin@2020");
                }
                rms.invoke("main", CtPresentationShell.class.getName(), null, cls, obj);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        String methodName = args[1];
        if ("reload".equals(methodName)) {
            // windchill com.ptc.core.htmlcomp.collection.presentation.CtTableColumnShell plm reload
            CtPresentationProperties.getInstance().reload();
        }
    }
}
