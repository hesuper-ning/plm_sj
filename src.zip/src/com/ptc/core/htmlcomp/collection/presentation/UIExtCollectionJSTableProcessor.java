package com.ptc.core.htmlcomp.collection.presentation;

import com.ptc.core.htmlcomp.collection.engine.CollectionContext;
import com.ptc.core.htmlcomp.collection.engine.CollectorDisplay;
import com.ptc.core.htmlcomp.collection.presentation.config.CtPresentationProperties;
import com.ptc.core.htmlcomp.cs.ConfigSpecHolder;
import com.ptc.core.htmlcomp.ext.JSTContext;
import com.ptc.core.htmlcomp.ext.JSTTVValues;
import com.ptc.core.htmlcomp.jstable.*;
import com.ptc.core.htmlcomp.util.PageContext;
import com.ptc.core.logging.Log;
import com.ptc.core.logging.LogFactory;
import wt.util.WTException;
import wt.util.WTMessage;

import java.io.OutputStream;
import java.net.MalformedURLException;
import java.util.*;

public class UIExtCollectionJSTableProcessor extends UIExtCollectionDataProcessor {
    private static Log log = LogFactory.getLog(UICollectionJSTableProcessor.class);

    public static final String DEFAULT_TABLEID = "CollectionComponentTable";

    public static final String DEFAULT_TOOLBARID = "CollectionComponentExtTableToolbar";

    private String toolbarID = "CollectionComponentExtTableToolbar";

    private JSTableDescriptor tableDesc;

    private ConfigSpecHolder configSpecHolder;

    private CollectionContext collectionContext;

    private UICollectionContext uiCollectionContext;

    private AdvancedUIRenderer advancedUIRenderer;

    public JSTableDescriptor getTableDescriptor(String paramString, Properties paramProperties, Locale paramLocale) throws WTException {
        String str = paramString;
        if (str == null)
            str = "CollectionComponentTable";
        System.out.println("com.ptc.core.htmlcomp.collection.presentation.UIExtCollectionJSTableProcessor.getTableDescriptor >>>>>>>> ");
        if (this.tableDesc == null) {
            this.tableDesc = new JSTableDescriptor(paramString);
            JSStandardColumnDescriptorFactory jSStandardColumnDescriptorFactory = new JSStandardColumnDescriptorFactory();
            this.tableDesc.setSelectionEnabled(true);
            if (isPicker()) {
                JSStatusColumnHelper.addStatusColumnsToTable(this.tableDesc, true, true, false, false, false, true, true, paramLocale, 65535);
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newTypeIconColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newNumberColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newIterationColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newActionsColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newNameColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newCADNameColumn(paramLocale, false));
                addCollectionColumns(this.tableDesc, jSStandardColumnDescriptorFactory, paramLocale);
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newModifiedColumn(paramLocale, false));

                // 增加列
                CtPresentationProperties tableColumnProperties = CtPresentationProperties.getInstance();
                HashSet<String> tableColumnSet = tableColumnProperties.getHashSetValue("table.column");
                System.out.println("客制化列的个数：" + tableColumnSet.size());
                for (String tableColumn : tableColumnSet) {
                    String[] arrays = tableColumn.split("\\|");
                    if (arrays.length < 2) continue;

                    this.tableDesc.addColumn(new JSColumnDescriptor("IBA|" + arrays[0], arrays[1], false));
                }

                int[] arrayOfInt = { 2, 8, 2, 16, 8, 10, 16, 16, 18, 10 };
                this.tableDesc.setColumnWidths(arrayOfInt);
            } else {
                JSStatusColumnHelper.addStatusColumnsToTable(this.tableDesc, true, true, false, false, false, true, false, paramLocale, 65535);
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newTypeIconColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newCADNameColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newIterationColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newActionsColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newNameColumn(paramLocale, false));
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newNumberColumn(paramLocale, false));
                addCollectionColumns(this.tableDesc, jSStandardColumnDescriptorFactory, paramLocale);
                this.tableDesc.addColumn((JSColumnDescriptorIfc)jSStandardColumnDescriptorFactory.newModifiedColumn(paramLocale, false));
                int[] arrayOfInt = { 2, 8, 2, 16, 8, 10, 16, 16, 18, 10 };
                this.tableDesc.setColumnWidths(arrayOfInt);
            }
            String str1 = WTMessage.getLocalizedMessage("com.ptc.core.htmlcomp.collection.collectionResource", "CollectObjectsLabel", null, paramLocale);
            this.tableDesc.setTableTitle(str1);
            this.tableDesc.setDefaultSortColumn("typeicon");
            this.tableDesc.setJSDataUtility(getJSDataUtility());
            this.tableDesc.setToolBar(this.toolbarID);
        }
        this.tableDesc.setVisibleOfTotalTitle(true);
        return this.tableDesc;
    }

    protected void addCollectionColumns(JSTableDescriptor paramJSTableDescriptor, JSStandardColumnDescriptorFactory paramJSStandardColumnDescriptorFactory, Locale paramLocale) throws WTException {
        if (isShowCollectionRulesColumn())
            paramJSTableDescriptor.addColumn((JSColumnDescriptorIfc)paramJSStandardColumnDescriptorFactory.newCollectionRulesColumn(paramLocale, true));
        if (isShowRelationshipTypesColumn()) {
            JSColumnDescriptor jSColumnDescriptor = paramJSStandardColumnDescriptorFactory.newRelationshipTypesColumn(paramLocale, true);
            if (isShowCollectionRulesColumn()) {
                Set set = jSColumnDescriptor.getDataAttributes();
                set.remove("includedBys");
                set.remove("appliedCollections");
                set.remove("objVROID");
            }
            paramJSTableDescriptor.addColumn((JSColumnDescriptorIfc)jSColumnDescriptor);
        }
    }

    protected void preRenderTrigger(JSTContext paramJSTContext, JSTableDescriptor paramJSTableDescriptor, JSTableData paramJSTableData) throws WTException {
        if (paramJSTableDescriptor != null) {
            addCollectionComponentMenusToJSMenuBar(paramJSTableDescriptor, paramJSTContext.getLocale());
            paramJSTableDescriptor.setVisibleOfTotalTitle(true);
        }
    }

    public List getTableRequiredUpdateDataAttributes() {
        return Arrays.asList(new String[] { "objOID", "appliedCollections", "includedBys" });
    }

    public Set getTableRequiredDataAttributes() throws WTException {
        UICollectionContext uICollectionContext = getUICollectionContext();
        List list = (List)uICollectionContext.getValue("displays");
        if (list != null && list.size() > 0) {
            HashSet hashSet = new HashSet();
            for (Object object : list) {
                if (object instanceof CollectorDisplay) {
                    CollectorDisplay collectorDisplay = (CollectorDisplay) object;
                    List list1 = collectorDisplay.getRequiredDataAttributes();
                    if (list1 != null)
                        hashSet.addAll(list1);
                }
            }
            if (hashSet.size() > 0)
                return hashSet;
        }
        return null;
    }

    protected void addCollectionComponentMenusToJSMenuBar(JSTableDescriptor paramJSTableDescriptor, Locale paramLocale) throws WTException {}

    public void displayMenu(Properties paramProperties, Locale paramLocale, OutputStream paramOutputStream) throws WTException, MalformedURLException {}

    protected String getCSMode() {
        return "BASIC_MODE";
    }

    protected String getActiveCSString() throws WTException {
        return getConfigSpecFormatString();
    }

    public String getConfigSpecFormatString() throws WTException {
        return getContextProperties().getProperty("configSpecFormatString", getInitialConfigSpecFormatString());
    }

    public String getInitialConfigSpecFormatString() throws WTException {
        return getContextProperties().getProperty("initialConfigSpecFormatString");
    }

    public ConfigSpecHolder getApplicableConfigSpecs(CollectionContext paramCollectionContext) throws WTException {
        if (this.configSpecHolder == null)
            this.configSpecHolder = (ConfigSpecHolder)getUICollectionContext().getValue("applicableConfigSpecs");
        return this.configSpecHolder;
    }

    public CollectionContext getCollectionContext() throws WTException {
        if (this.collectionContext == null)
            this.collectionContext = (CollectionContext)PageContext.getPageAttribute(
                    getOriginalContextAction() + "_" + getCollectionComponentID() + "_" + "collectionContext");
        return this.collectionContext;
    }

    public UICollectionContext getUICollectionContext() throws WTException {
        if (this.uiCollectionContext == null)
            this.uiCollectionContext = (UICollectionContext)PageContext.getPageAttribute(
                    getOriginalContextAction() + "_" + getCollectionComponentID() + "_" + "uiCollectionContext");
        return this.uiCollectionContext;
    }

    public String getCollectionComponentID() {
        return getContextProperties().getProperty("collectionCompID");
    }

    public String getOriginalContextAction() {
        return getContextProperties().getProperty("ORIGINAL_CONTEXT_ACTION");
    }

    public boolean isCollectionComponentInteraction() throws WTException {
        return getUICollectionContext().isCollectionComponentInteraction();
    }

    public AdvancedUIRenderer getAdvancedUIRenderer() {
        if (this.advancedUIRenderer == null)
            this.advancedUIRenderer = (AdvancedUIRenderer)PageContext.getPageAttribute(
                    getOriginalContextAction() + "_" + getCollectionComponentID() + "_" + "advancedUIRenderer");
        return this.advancedUIRenderer;
    }

    public boolean isPicker() {
        return Boolean.parseBoolean(getQueryData().getProperty("isPicker", "false"));
    }

    public String getDisplaysHTML(Locale paramLocale) throws WTException {
        Properties properties = new Properties();
        properties.setProperty("selectedDisplayID", getDisplayID());
        return (String)getAdvancedUIRenderer().renderDisplayMenu(properties);
    }

    public JSTTVValues getAppFilters(JSTContext paramJSTContext) {
        JSTTVValues jSTTVValues = null;
        try {
            Properties properties = new Properties();
            String str = getDisplayID();
            properties.setProperty("selectedDisplayID", str);
            AdvancedUIRenderer advancedUIRenderer = getAdvancedUIRenderer();
            if (advancedUIRenderer != null) {
                List<JSTableFilterDescriptor> list = getAdvancedUIRenderer().getDisplayMenu(properties);
                if (list != null && list.size() > 0) {
                    jSTTVValues = new JSTTVValues();
                    jSTTVValues.setActionID("displays");
                    jSTTVValues.setFilters(list);
                    jSTTVValues.setActiveFilterId(str);
                    jSTTVValues.setUseGeneratedId(false);
                    jSTTVValues.setTooltip(WTMessage.getLocalizedMessage("com.ptc.core.htmlcomp.collection.collectionResource", "PickADisplayLabel", null, paramJSTContext

                            .getLocale()));
                }
            }
        } catch (WTException wTException) {
            log.error(wTException, (Throwable)wTException);
        }
        return jSTTVValues;
    }

    public String getRecollectColsToExecFormatString() throws WTException {
        return getContextProperties().getProperty("recollectColsToExecFormatString");
    }

    public String getDisplayID() throws WTException {
        return getContextProperties().getProperty("displayID", "all_as_list");
    }

    public String getShowCollectionRulesColumn() throws WTException {
        return getContextProperties().getProperty("showCollectionRulesColumn", "true");
    }

    public boolean isShowCollectionRulesColumn() throws WTException {
        return Boolean.parseBoolean(getShowCollectionRulesColumn());
    }

    public String getShowRelationshipTypesColumn() throws WTException {
        return getContextProperties().getProperty("showRelationshipTypesColumn", "false");
    }

    public boolean isShowRelationshipTypesColumn() throws WTException {
        return Boolean.parseBoolean(getShowRelationshipTypesColumn());
    }
}