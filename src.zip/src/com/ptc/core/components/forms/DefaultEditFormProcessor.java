package com.ptc.core.components.forms;

import com.ptc.core.command.server.delegate.ServerCommandDelegateUtility;
import com.ptc.core.components.beans.CreateAndEditWizBean;
import com.ptc.core.components.beans.FormDataHolder;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import org.apache.log4j.Logger;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.WTReference;
import wt.iba.value.litevalue.AbstractValueViewMap;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.part.WTPart;
import wt.util.WTException;
import wt.vc.Mastered;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class DefaultEditFormProcessor extends DefaultObjectFormProcessor {
    private static final Logger log;

    public DefaultEditFormProcessor() {
    }

    public FormResult doOperation(NmCommandBean var1, List<ObjectBean> var2) throws WTException {
        FormResult var3 = new FormResult(FormProcessingStatus.SUCCESS);
        new FormResult(FormProcessingStatus.SUCCESS);
        FormResult var4 = super.doOperation(var1, var2);
        var3 = this.mergeIntermediateResult(var4, var3);
        if (!this.continueProcessing(var3)) {
            return var3;
        } else {
            Iterator var5 = var2.iterator();

            while(var5.hasNext()) {
                ObjectBean var6 = (ObjectBean)var5.next();
                Object var7 = var6.getObject();
                if (var7 == null) {
                    log.error("doOperation(): no object found in ObjectBean with handle \"" + var6.getObjectHandle() + "\".  Skipping that ObjectBean.");
                    break;
                }

                if (!(var7 instanceof Persistable)) {
                    log.error("doOperation(): object in the ObjectBean with handle \"" + var6.getObjectHandle() + "\" is not a Persistable.  Skipping that ObjectBean.");
                    break;
                }

                Persistable var9 = PersistenceHelper.manager.save((Persistable)var7);
                if (var9 instanceof RevisionControlled) {
                    if(var9 instanceof WTPart) {
                        //lzp start 处理在编辑或者导入bom时同步物料描述与名称时的持久化问题
                        var9=(WTPart) PersistenceHelper.manager.refresh(var9);
                        //lzp end
                    }
                    Mastered var8 = ((RevisionControlled)var9).getMaster();
                    var8 = (Mastered)PersistenceHelper.manager.save(var8);
                }
            }

            log.debug("doOperation() successful");
            return var3;
        }
    }

    public FormResult preProcess(NmCommandBean var1, List<ObjectBean> var2) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("\npreProcess() - request parameters on entry:");
            log.debug(var1.requestParametersToString());
        }

        FormResult var3 = new FormResult(FormProcessingStatus.SUCCESS);
        Iterator var4 = var2.iterator();

        while(var4.hasNext()) {
            ObjectBean var5 = (ObjectBean)var4.next();
            FormResult var6 = new FormResult(FormProcessingStatus.SUCCESS);
            TypeInstance var7 = this.getEditItemInstance(var1, var5, var6);
            if (this.continueProcessing(var6)) {
                Persistable var8 = (Persistable)var5.getObject();
                boolean var9 = MethodContext.getContext().containsKey("MultiObjIBAValueDBService.METHOD_CONTEXT_KEY");
                if (!var9) {
                    MethodContext.getContext().put("MultiObjIBAValueDBService.METHOD_CONTEXT_KEY", new AbstractValueViewMap());
                }

                ServerCommandDelegateUtility.translate(var7, var8);
            }

            var3 = this.mergeIntermediateResult(var6, var3);
            if (!this.continueProcessing(var3)) {
                break;
            }
        }

        if (!this.continueProcessing(var3)) {
            return var3;
        } else {
            FormResult var10 = super.preProcess(var1, var2);
            var3 = this.mergeIntermediateResult(var10, var3);
            log.debug("preProcess() successful");
            return var3;
        }
    }

    protected FormResult setRefreshInfo(FormResult var1, NmCommandBean var2, List<ObjectBean> var3) throws WTException {
        return var1;
    }

    protected TypeInstanceIdentifier getObjFromDatabase(ObjectBean var1) throws WTException {
        WTReference var2 = this.getObjectBeingEdited(var1);
        if (var2 == null) {
            throw new WTException("DefaultEditFormProcessor.preProcess(): cannot obtain a reference to the object with the object handle \"" + var1.getObjectHandle() + "\"");
        } else {
            if (log.isDebugEnabled()) {
                log.debug("getObjFromDatabase(): object to edit is " + var2.toString());
            }

            Persistable var3 = var2.getObject();
            var1.setObject(var3);
            return TypeIdentifierUtility.getTypeInstanceIdentifier(var3);
        }
    }

    protected TypeInstance getEditItemInstance(NmCommandBean var1, ObjectBean var2, FormResult var3) throws WTException {
        TypeInstance var4 = null;
        TypeInstanceIdentifier var5 = this.getObjFromDatabase(var2);
        HashMap var6 = new HashMap();
        FormResult var7 = CreateEditFormProcessorHelper.getStandardAttributes(var5, var2, var6, "STDOP|com.ptc.windchill.update");
        var3 = this.mergeIntermediateResult(var7, var3);
        if (this.continueProcessing(var3)) {
            var7 = new FormResult();
            TypeInstanceIdentifier var8 = null;
            TypeIdentifier var9 = TypeIdentifierUtility.getTypeIdentifierFromPersistedType("wt.inf.container.WTContained");
            if (var5.getDefinitionIdentifier().isDescendedFrom(var9)) {
                var8 = CreateAndEditWizBean.getContainerTypeInstanceId(var2);
            }

            Object var10 = null;
            var4 = CreateEditFormProcessorHelper.getTypeInstanceWithFormVals(var5, var6, var8, "STDOP|com.ptc.windchill.update", var1.getLocale(), var7, (TypeInstanceIdentifier[])var10);
            this.mergeIntermediateResult(var7, var3);
        }

        return var4;
    }

    protected WTReference getObjectBeingEdited(FormDataHolder var1) {
        String var2 = CreateAndEditWizBean.getCurrentObjectHandle(var1);
        return CreateAndEditWizBean.getEditObjectReference(var2, var1);
    }

    static {
        try {
            log = LogR.getLogger(DefaultEditFormProcessor.class.getName());
        } catch (Exception var1) {
            throw new ExceptionInInitializerError(var1);
        }
    }
}

