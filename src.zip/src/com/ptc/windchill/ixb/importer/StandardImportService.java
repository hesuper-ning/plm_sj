//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.windchill.ixb.importer;

import com.ptc.windchill.ixb.importer.*;
import com.ptc.windchill.ixb.importer.part.PartSheetElementBuilder;
import com.ptc.windchill.ixb.util.ImportXlsHelper;
import ext.plm.util.CtFormatUtil;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.admin.AdminDomainRef;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.fc.*;
import wt.fc.collections.*;
import wt.inf.container.WTContainerRef;
import wt.ixb.clientAccess.IXBExpImpStatus;
import wt.ixb.publicforapps.Importer;
import wt.ixb.publicforapps.IxbHelper;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.notify.DistributionList;
import wt.notify.WTDistributionList;
import wt.notify.templateProcessor.EmailTemplateNotificationRequest;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.ownership.OwnershipHelper;
import wt.part.WTPart;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.queue.ProcessingQueue;
import wt.queue.QueueEntry;
import wt.queue.QueueHelper;
import wt.queue.StandardQueueService;
import wt.services.ManagerException;
import wt.services.ManagerService;
import wt.services.ManagerServiceFactory;
import wt.services.StandardManager;
import wt.services.applicationcontext.UnableToCreateServiceException;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.util.*;
import wt.wvs.VisualizationHelperFactory;
import wt.wvs.VisualizationHelperIfc;

import java.io.*;
import java.util.*;
import java.util.regex.Pattern;

public class StandardImportService extends StandardManager implements ImportService, ImportServerService {
    private static final String RESOURCE = "com.ptc.windchill.ixb.importer.importerResource";
    private static final String CLASSNAME = com.ptc.windchill.ixb.importer.StandardImportService.class.getName();
    private static WTKeyedMap canceledJobToPrincipalMap = CollectionsHelper.synchronizedWTKeyedMap(new WTKeyedHashMap());
    private static String IXB_TEMP_DIRECTORY;
    private static StandardQueueService queueManager;
    private static final String DEFAULT_SENDER_EMAIL;
    private static final String DEFAULT_ENCODING = "UTF-8";
    private static final Logger logger;
    private static String xlsFileName;
    private static int importChunkSize;
    private static final int DEFAULT_CANCELLABLE_CHUNK_SIZE = 5;
    private static final String CANCELLABLE_CHUNK_SIZE_PROPERTY_KEY = "com.ptc.windchill.ixb.importer.cancellableChunkSize";
    private static final String IMPORT_SEQUENCE = "com.ptc.windchill.ixb.importer.ImportSequence";

    public StandardImportService() {
    }

    /** @deprecated */
    public String getConceptualClassname() {
        return CLASSNAME;
    }

    protected synchronized void performStartupProcess() throws ManagerException {
        super.performStartupProcess();
    }

    public static final ImportJob importSpreadsheet(ObjectIdentifier var0, ImportJobArgsBean var1) throws WTException {
        logger.debug("importSpreadsheet started.");
        ImportJob var2 = null;

        try {
            var2 = (ImportJob)PersistenceHelper.manager.refresh(var0);
            if (var2 == null) {
                throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "301", new Object[]{var0.getId()});
            } else {
                var2.getSpec().setPreview(false);
                var2.setStatus(ImportJobStatus.RUNNING);
                var2 = (ImportJob)PersistenceHelper.manager.save(var2);
                var2.setImportJobArgsBean(var1);
                boolean var10 = false;

                ImportJob var3;
                label129: {
                    label130: {
                        try {
                            var10 = true;
                            var2 = doPreviewOrImport(var2);
                            var2 = (ImportJob)PersistenceHelper.manager.refresh(var2);
                            if (var2.getStatus() != ImportJobStatus.COMPLETED && var2.getStatus() != ImportJobStatus.PARTIAL) {
                                sendImportJobEvent(var2, "FAILED");
                                var10 = false;
                            } else if (var2.getStatus().equals(ImportJobStatus.COMPLETED)) {
                                sendImportJobEvent(var2, "COMPLETED");
                                var10 = false;
                            } else {
                                var10 = false;
                            }
                            break label129;
                        } catch (ImportCanceledException var11) {
                            var2.setStatus(ImportJobStatus.CANCELED);
                            canceledJobToPrincipalMap.remove(var2);
                            sendImportJobEvent(var2, "CANCELED");
                            var10 = false;
                        } catch (Exception var12) {
                            var2.setStatus(ImportJobStatus.FAILED);
                            sendImportJobEvent(var2, "FAILED");
                            var10 = false;
                            break label130;
                        } finally {
                            if (var10) {
                                ImportJob var5 = (ImportJob)PersistenceHelper.manager.refresh(var2);
                                if (var5.getStatus() != ImportJobStatus.CANCELED) {
                                    var2 = (ImportJob)PersistenceHelper.manager.save(var2);
                                }

                            }
                        }

                        var3 = (ImportJob)PersistenceHelper.manager.refresh(var2);
                        if (var3.getStatus() != ImportJobStatus.CANCELED) {
                            var2 = (ImportJob)PersistenceHelper.manager.save(var2);
                        }

                        return var2;
                    }

                    var3 = (ImportJob)PersistenceHelper.manager.refresh(var2);
                    if (var3.getStatus() != ImportJobStatus.CANCELED) {
                        var2 = (ImportJob)PersistenceHelper.manager.save(var2);
                    }

                    return var2;
                }

                var3 = (ImportJob)PersistenceHelper.manager.refresh(var2);
                if (var3.getStatus() != ImportJobStatus.CANCELED) {
                    var2 = (ImportJob)PersistenceHelper.manager.save(var2);
                }

                return var2;
            }
        } catch (WTPropertyVetoException var14) {
            throw new WTException(var14);
        }
    }

    public static com.ptc.windchill.ixb.importer.StandardImportService newStandardImportService() throws WTException {
        com.ptc.windchill.ixb.importer.StandardImportService var0 = new com.ptc.windchill.ixb.importer.StandardImportService();
        var0.initialize();
        return var0;
    }

    public ImportJob createImportJob(ImportSpec var1) throws WTException {
        logger.debug("StandardImportService.createImportJob()...started");
        Transaction var2 = new Transaction();
        logger.debug("The transaction description: " + var2.getDescription());

        ImportJob var8;
        try {
            var2.start();
            ImportJob var3 = ImportJob.newImportJob();
            var3.setImportJobArgsBean(new ImportJobArgsBean());
            WTContainerRef var4 = var1.getContainerRef();
            var3.setContainerReference(var4);
            String var5 = var1.getFilename();
            int var6 = var5.lastIndexOf("/");
            var6 = var6 >= 0 ? var6 : var5.lastIndexOf("\\");
            if (var6 >= 0) {
                var5 = var5.substring(var6 + 1);
            }

            var1.setFilename(var5);
            var3.setSpec(var1);
            var3.setStatus(ImportJobStatus.DEFINING);
            OwnershipHelper.setOwner(var3, SessionHelper.manager.getPrincipal());
            AdminDomainRef var7 = var4.getReferencedContainer().getDefaultDomainReference();
            var3.setDomainRef(var7);
            var3 = (ImportJob)PersistenceHelper.manager.store(var3);
            logger.debug("job persisted: " + var3);
            var2.commit();
            var2 = null;
            var8 = var3;
        } catch (Exception var12) {
            var12.printStackTrace();
            throw new WTException(var12);
        } finally {
            if (var2 != null) {
                logger.debug("transaction rolled back");
                var2.rollback();
            }

            logger.debug("StandardImportService.createImportJob()...ended");
        }

        return var8;
    }

    public synchronized void cancelImportJob(ObjectIdentifier var1) throws WTException {
        ImportJob var2 = (ImportJob)PersistenceHelper.manager.refresh(var1);
        WTPrincipal var3 = SessionHelper.manager.getPrincipal();
        WTPrincipal var4 = OwnershipHelper.getOwner(var2);
        if (!var3.equals(var4)) {
            AccessControlHelper.manager.checkAccess(var2, AccessPermission.ADMINISTRATIVE);
        }

        ImportJobStatus var5 = var2.getStatus();
        if (!var5.equals(ImportJobStatus.COMPLETED) && !var5.equals(ImportJobStatus.PARTIAL)) {
            if (var5.equals(ImportJobStatus.CANCELED)) {
                throw new ImportException("com.ptc.windchill.ixb.importer.importerResource", "102", new Object[]{var2.getDisplayIdentity()});
            } else if (var5.equals(ImportJobStatus.FAILED)) {
                throw new ImportException("com.ptc.windchill.ixb.importer.importerResource", "101", new Object[]{var2.getDisplayIdentity()});
            } else {
                if (var5.equals(ImportJobStatus.RUNNING)) {
                    canceledJobToPrincipalMap.put(var2, var3);

                    try {
                        var2.setStatus(ImportJobStatus.CANCELED);
                        canceledJobToPrincipalMap.remove(var2);
                        sendImportJobEvent(var2, "CANCELED");
                        var2 = (ImportJob)PersistenceHelper.manager.save(var2);
                    } catch (WTPropertyVetoException var7) {
                        var7.printStackTrace();
                    }
                }

                if (var5.equals(ImportJobStatus.PENDING)) {
                    canceledJobToPrincipalMap.put(var2, var3);
                }

            }
        } else {
            throw new ImportException("com.ptc.windchill.ixb.importer.importerResource", "103", new Object[]{var2.getDisplayIdentity()});
        }
    }

    public void deleteImportJob(ObjectIdentifier var1) throws WTException {
        ImportJob var2 = (ImportJob)PersistenceHelper.manager.refresh(var1);
        ImportJobStatus var3 = var2.getStatus();
        if (var3.equals(ImportJobStatus.RUNNING)) {
            throw new ImportException("A currently running job cannot be deleted.");
        } else {
            PersistenceHelper.manager.delete(var2);
        }
    }

    public ImportJob doPreview(ImportJob var1) throws WTException {
        logger.debug("StandardImportService.doPreview()...started");
        boolean var10 = false;

        ImportJob var2;
        label99: {
            try {
                var10 = true;
                if (var1 == null) {
                    throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "303", new Object[0]);
                }

                var1.getSpec().setPreview(true);
                var1.setStatus(ImportJobStatus.RUNNING);
                var1 = (ImportJob)PersistenceHelper.manager.save(var1);
                var1 = doPreviewOrImport(var1);
                var10 = false;
            } catch (WTPropertyVetoException var12) {
                throw new WTException(var12);
            } catch (Exception var13) {
                var13.printStackTrace();

                try {
                    var1.setStatus(ImportJobStatus.FAILED);
                    var10 = false;
                    break label99;
                } catch (WTPropertyVetoException var11) {
                    throw new WTException(var11);
                }
            } finally {
                if (var10) {
                    ImportJob var5 = (ImportJob)PersistenceHelper.manager.refresh(var1);
                    if (var5.getStatus() != ImportJobStatus.CANCELED) {
                        var1 = (ImportJob)PersistenceHelper.manager.save(var1);
                    }

                }
            }

            var2 = (ImportJob)PersistenceHelper.manager.refresh(var1);
            if (var2.getStatus() != ImportJobStatus.CANCELED) {
                var1 = (ImportJob)PersistenceHelper.manager.save(var2);
            }

            return var1;
        }

        var2 = (ImportJob)PersistenceHelper.manager.refresh(var1);
        if (var2.getStatus() != ImportJobStatus.CANCELED) {
            var1 = (ImportJob)PersistenceHelper.manager.save(var1);
        }

        return var1;
    }

    public ImportJob doImport(ImportJob var1) throws WTException {
        logger.debug("StandardImportService.doImport()...started");
        if (var1.getSpec().isPreviewStep()) {
            try {
                var1.getSpec().setPreviewStep(true);
            } catch (WTPropertyVetoException var3) {
                var3.printStackTrace();
            }

            PersistenceHelper.manager.modify(var1);
            importSpreadsheet(var1.getPersistInfo().getObjectIdentifier(), var1.getImportJobArgsBean());
        } else {
            var1 = this.queueImportJob(var1);
        }

        logger.debug("StandardImportService.doImport()...ended");
        return var1;
    }

    public WTCollection getImportJobs(WTContainerRef var1) throws WTException {
        throw new WTException("not implemented yet.");
    }

    public WTCollection getAllImportJobs() throws WTException {
        WTArrayList var1 = new WTArrayList();
        QuerySpec var2 = new QuerySpec(ImportJob.class);
        logger.trace("getAllImportJobs() SQL: " + var2.toString());
        QueryResult var3 = PersistenceHelper.manager.find(var2);
        if (var3.size() > 0) {
            logger.trace("Query found " + var3.size() + " matching import jobs.");
            var1.addAll(var3);
            return var1;
        } else {
            return null;
        }
    }

    public synchronized void checkJobCancelation(ImportJob var1) throws WTException {
        if (canceledJobToPrincipalMap.containsKey(var1)) {
            WTPrincipal var2 = (WTPrincipal)canceledJobToPrincipalMap.get(var1);
            throw new ImportCanceledException("com.ptc.windchill.ixb.importer.importerResource", "104", new Object[]{var1.getDisplayIdentity(), var2.getDisplayIdentity()});
        }
    }

    public void processPreInsertEvent(PersistenceManagerEvent var1) throws WTException {
        WTCollection var2 = ((WTCollection)var1.getEventTarget()).subCollection(ImportJob.class);
        if (!var2.isEmpty()) {
            this.processPreInsertForImportJob(var2);
        }

    }

    public void registerEvents(ManagerService var1) {
        var1.addEventBranch(ImportJobEvent.generateEventKey("CREATED"), ImportJobEvent.class.getName(), "CREATED");
        var1.addEventBranch(ImportJobEvent.generateEventKey("SUBMITTED"), ImportJobEvent.class.getName(), "SUBMITTED");
        var1.addEventBranch(ImportJobEvent.generateEventKey("STARTED"), ImportJobEvent.class.getName(), "STARTED");
        var1.addEventBranch(ImportJobEvent.generateEventKey("COMPLETED"), ImportJobEvent.class.getName(), "COMPLETED");
        var1.addEventBranch(ImportJobEvent.generateEventKey("CANCELED"), ImportJobEvent.class.getName(), "CANCELED");
        var1.addEventBranch(ImportJobEvent.generateEventKey("FAILED"), ImportJobEvent.class.getName(), "FAILED");
    }

    private static synchronized void checkJobCancelation(ImportJob var0, WTPrincipal var1) throws ImportCanceledException {
        if (canceledJobToPrincipalMap.containsKey(var0)) {
            WTPrincipal var2 = (WTPrincipal)canceledJobToPrincipalMap.get(var0);
            throw new ImportCanceledException("com.ptc.windchill.ixb.importer.importerResource", "104", new Object[]{var0.getDisplayIdentity(), var2.getDisplayIdentity()});
        }
    }

    protected static void sendImportJobEvent(ImportJob var0, String var1) throws WTException {
        ImportJobEvent var2 = new ImportJobEvent(var1, var0);
        if (logger.isTraceEnabled()) {
            logger.trace("send ImportJobEvent: job = " + var0.getDisplayIdentity() + " eventType = " + var1);
        }

        WTUser var3 = (WTUser)SessionContext.getEffectivePrincipal();
        if (var3 == null) {
            var3 = (WTUser)SessionHelper.getPrincipal();
        }

        if (logger.isTraceEnabled()) {
            logger.trace("sender = " + var3);
        }

        WTDistributionList var4 = new WTDistributionList();
        var4.addUser(var3);
        EmailTemplateNotificationRequest var5 = getNotificationRequest(var2, var4);
        var5.setEventInitiator(var3.getFullName());
        var5.setSender(getSenderEmailAddress(var3));
        var5.send();
    }

    public static EmailTemplateNotificationRequest getNotificationRequest(ImportJobEvent var0, DistributionList var1) throws WTException {
        ObjectReference var2 = ObjectReference.newObjectReference(((ImportJob)var0.getEventTarget()).getPersistInfo().getObjectIdentifier());
        EmailTemplateNotificationRequest var3 = EmailTemplateNotificationRequest.newEmailTemplateNotificationRequest(var1, var2, false);
        var3.setEvent(var0.getEventType());
        return var3;
    }

    private static String getSenderEmailAddress(WTUser var0) throws WTException {
        String var1 = null;
        if (var0 != null) {
            var1 = var0.getEMail();
        }

        if (var1 == null) {
            var1 = DEFAULT_SENDER_EMAIL;
        }

        if (logger.isTraceEnabled()) {
            logger.trace("Sender e-mail address = " + var1);
        }

        return var1;
    }

    private static ImportJob uploadFakeContent(ImportJob var0, String var1, boolean var2, long var3) throws WTException {
        Transaction var5 = new Transaction();

        ImportJob var8;
        try {
            ApplicationData var6 = ApplicationData.newApplicationData(var0);
            String var7 = (new File(var1)).getName();
            var6.setFileName(var7);
            var6.setUploadedFromPath(var1);
            var6.setDescription("Fake File: " + var1);
            var6.setRole(var2 ? ContentRoleType.PRIMARY : ContentRoleType.SECONDARY);
            ContentServerHelper.service.updateContent(var0, var6, var1);
            var0 = (ImportJob)PersistenceHelper.manager.refresh(var0);
            var5.commit();
            var5 = null;
            if (var3 > 0L) {
                try {
                    Thread.sleep(var3);
                } catch (InterruptedException var13) {
                }
            }

            var8 = var0;
        } catch (Exception var14) {
            throw var14 instanceof WTException ? (WTException)var14 : new WTException(var14);
        } finally {
            if (var5 != null) {
                var5.rollback();
            }

        }

        return var8;
    }

    private static ProcessingQueue getImportJobQueue() throws WTException {
        String var0 = ImportHelper.getImportJobQueueName();
        ProcessingQueue var1 = QueueHelper.manager.getQueue(var0);
        if (var1 == null) {
            try {
                logger.debug("creating/starting \"" + var0 + "\"");
                var1 = getQueueManager().createQueue(var0, true);
            } finally {
                if (var1 == null) {
                    throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "304", new Object[]{var0});
                }

            }
        }

        return var1;
    }

    private ImportJob queueImportJob(ImportJob var1) throws WTException {
        logger.debug("queueImportJob started");
        Transaction var2 = new Transaction();

        ImportJob var22;
        try {
            var2.start();
            WTPrincipal var3 = SessionHelper.manager.getAdministrator();
            WTPrincipal var4 = SessionContext.setEffectivePrincipal(var3);
            WTPrincipal var5 = SessionHelper.getPrincipal();
            ProcessingQueue var6 = getImportJobQueue();
            logger.debug("queue = " + var6);
            var1.setStatus(ImportJobStatus.PENDING);
            var1 = (ImportJob)PersistenceHelper.manager.save(var1);
            Class[] var7 = new Class[]{ObjectIdentifier.class, ImportJobArgsBean.class};
            Object[] var8 = new Object[]{var1.getPersistInfo().getObjectIdentifier(), var1.getImportJobArgsBean()};
            QueueEntry var9 = null;

            try {
                var9 = var6.addEntry(var5, "importSpreadsheet", this.getClass().getName(), var7, var8);
                JobToQueueEntryLink var10 = JobToQueueEntryLink.newJobToQueueEntryLink(var9, var1);
                PersistenceHelper.manager.save(var10);
            } finally {
                SessionContext.setEffectivePrincipal(var4);
            }

            logger.debug("Admin = " + var3);
            logger.debug("Current = " + var5);
            var2.commit();
            var2 = null;
            var22 = var1;
        } catch (WTPropertyVetoException var20) {
            throw new WTException(var20);
        } finally {
            if (var2 != null) {
                var2.rollback();
            }

        }

        return var22;
    }

    private static StandardQueueService getQueueManager() throws WTException {
        if (queueManager == null) {
            queueManager = (StandardQueueService)ManagerServiceFactory.getDefault().getManager(StandardQueueService.class);
        }

        return queueManager;
    }

    private static InputStream getImportSourceStream(ImportJob var0) throws WTException {
        if (var0 == null) {
            throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "302", new Object[0]);
        } else {
            QueryResult var1 = ContentHelper.service.getContentsByRole(var0, ContentRoleType.PRIMARY);
            if (var1 != null && var1.hasMoreElements()) {
                ApplicationData var2 = (ApplicationData)var1.nextElement();
                return ContentServerHelper.service.findContentStream(var2);
            } else {
                throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "305", new Object[0]);
            }
        }
    }

    private static void validateFileNameAndFormat(String var0, String var1) throws WTException {
        if (null != var0 && !"".equals(var0) || null != var1 && !"".equals(var1)) {
            if (null != var0 && !"".equals(var0) || null == var1 && "".equals(var1)) {
                if ((null != var0 || !"".equals(var0)) && (null == var1 || "".equals(var1))) {
                    throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "158", new Object[0]);
                } else {
                    logger.debug("File name is <" + var0 + "> and file format is <" + var1 + ">");
                }
            } else {
                throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "157", new Object[0]);
            }
        } else {
            throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "156", new Object[0]);
        }
    }

    private static synchronized File getUniqueLogFile(ImportJob var0) throws WTException {
        String var1 = null;

        try {
            if (IXB_TEMP_DIRECTORY == null) {
                WTProperties var2 = WTProperties.getServerProperties();
                var1 = var2.getProperty("wt.temp");
                IXB_TEMP_DIRECTORY = var1;
            } else {
                var1 = IXB_TEMP_DIRECTORY;
            }

            String var8 = "IxbLog";
            var1 = var1 + File.separator + var8;
            File var3 = new File(var1);
            var3.mkdirs();
            String var4 = ".log";
            String var5 = "ImportJob-" + var0.getNumber() + "-" + System.currentTimeMillis() + var4;
            File var6 = new File(var1, var5);
            return var6;
        } catch (IOException var7) {
            throw new WTException(var7);
        }
    }

    private static Importer getIxbImporter(ImportJob var0, ImportXlsHandler var1) throws WTException {
        String var2 = IxbHelper.STANDARD_DTD;
        Object var3 = null;
        Object var4 = null;
        Object var5 = null;
        String var6 = "NewIteration";
        if (var0.getSpec().getAction().equals(ImportAction.UPDATE_CHECKED_OUT_PARTS)) {
            var6 = "UpdateInPlaceForXls";
        }

        boolean var7 = true;
        boolean var8 = false;

        try {
            Importer var9 = IxbHelper.newImporter(var1, var0.getSpec().getContainerRef(), var2, (String)var3, (String)var4, (String)var5, var6, new Boolean(var7), new Boolean(var8));
            var9.setIgnoreSignalPersistenceOf(false);
            var9.setCheckTypeConstraints(true);
            var9.setPopulateMissingTypeAttributess(false);
            return var9;
        } catch (WTPropertyVetoException var10) {
            throw new WTException(var10);
        }
    }

    private static ImportXlsHandler getHandler(ImportJob var0, PrintWriter var1) throws WTException {
        IXBExpImpStatus var2 = new IXBExpImpStatus();
        ImportXlsHandler var3 = new ImportXlsHandler(var2, var0, (Locale)null, var1);
        return var3;
    }

    public static synchronized void logMessage(BufferedWriter var0, String var1) throws WTException {
        try {
            if (null != var0 && null != var1) {
                var0.write(var1);
                var0.newLine();
                var0.flush();
            }

        } catch (IOException var3) {
            throw new WTException(var3);
        }
    }

    private static ImportJob doPreviewOrImport(ImportJob var0) throws WTException {
        HashMap var1 = new HashMap();
        SessionHelper.getPrincipal().setAdditionalAttributes(var1);
        boolean var2 = false;
        boolean var3 = false;
        logger.debug("StandardImportService.doPreviewOrImport()...started");
        boolean var4 = var0.getSpec().isPreview();
        File var5 = getUniqueLogFile(var0);
        if (null == var5) {
            throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "306", new Object[0]);
        } else {
            SessionData var6 = new SessionData();
            SessionData var7 = new SessionData();
            initSessionData(var6, var0);
            initSessionData(var7, var0);
            PrintWriter var8 = null;
            Transaction var9 = null;
            ArrayList var10 = new ArrayList();

            String var11;
            try {
                importChunkSize = WTProperties.getServerProperties().getProperty("com.ptc.windchill.ixb.importer.cancellableChunkSize", 5);
                var11 = WTProperties.getServerProperties().getProperty("com.ptc.windchill.ixb.importer.ImportSequence");
                Collections.addAll(var10, var11.split(","));
            } catch (IOException var35) {
                var35.printStackTrace();
            }

            var11 = "";

            try {
                OutputStreamWriter var12 = new OutputStreamWriter(new FileOutputStream(var5), "UTF-8");
                var8 = new PrintWriter(var12);
                ImportSourceFormat var13 = getImportSourceFormat(var0);
                ImportSource var14 = ImportSourceFactory.getInstance().newImportSource(var13, getImportSourceStream(var0));
                logger.debug("Uploading Excel file on Windchill server from primary content of the import job...");
                var8.println(getLocalizedMessage("163", (Object[])null, var6.getJobLocale()));
                List var15 = var14.getSheets();
                if (var15 != null && !var15.isEmpty()) {
                    if (!var4) {
                        var9 = new Transaction();
                        var9.start();
                    }

                    Map var16 = Transaction.getGlobalMap();
                    VisualizationHelperIfc var17 = (new VisualizationHelperFactory()).getHelper();
                    var16.put(var17.getWvsCopyForwardTransactionKey(), (Object)null);
                    var6.setLogger(var8);
                    var7.setLogger(var8);
                    xlsFileName = ImportXlsHelper.getFileName(var0);
                    HashMap var18 = new HashMap();
                    ListIterator var19 = var15.listIterator();

                    while(var19.hasNext()) {
                        var0 = (ImportJob)PersistenceHelper.manager.refresh(var0);
                        if (var0.getStatus() == ImportJobStatus.CANCELED) {
                            ImportJob var39 = var0;
                            return var39;
                        }

                        ImportSheet var20 = (ImportSheet)var19.next();
                        if (null == var20) {
                            logger.debug("The sheet is null.");
                        } else {
                            var8.println();
                            var8.println(getSheetTitle(var20));
                            var11 = var20.getSheetName();
                            ImportSheetParser var21 = ImportSheetParserFactory.getInstance().newParser(var20);
                            PreImportSheetValidator var22 = getPreImportSheetValidatorHandler(var0, var21);
                            ImportSheetType var23 = var22.validateImportSheetType(var21, var11, var8, var0);
                            if (var23 != null) {
                                var3 = setAdditionalAttributeToIndicateBOMSheetPresence(var3, var23, var1);
                                Object var24;
                                if (var18.containsKey(var23)) {
                                    var24 = (List)var18.get(var23);
                                } else {
                                    var24 = new ArrayList();
                                }

                                ((List)var24).add(var20);
                                var18.put(var23, var24);
                            }
                        }
                    }

                    if (var18.keySet().isEmpty()) {
                        logger.debug("No valid sheets were found in this spreadsheet");
                        var8.println(getLocalizedMessage("100", (Object[])null, var6.getJobLocale()));
                        var2 = false;
                        ImportXlsHelper.reportError(new String[]{ImportXlsHelper.getLocaleErrorStr(), xlsFileName, "", "", getLocalizedMessage("100", (Object[])null, var6.getJobLocale())});
                    } else {
                        var8.println();
                        var8.println(getLocalizedMessage("168", (Object[])null, var6.getJobLocale()));
                        boolean var38 = var2;
                        Set var40 = var18.keySet();
                        var2 = true;
                        boolean var41 = true;
                        Iterator var42 = var10.iterator();

                        while(true) {
                            List var25;
                            ImportSheetType var45;
                            do {
                                String var43;
                                do {
                                    do {
                                        if (!var42.hasNext()) {
                                            Iterator var44 = var40.iterator();

                                            while(true) {
                                                do {
                                                    if (!var44.hasNext()) {
                                                        var1.put("isJobFail", !var41);
                                                        if (var4) {
                                                            doFinalizeImport(var6, var0, false);
                                                            doFinalizeImport(var7, var0, false);
                                                            logger.debug("Preview completed.");
                                                        } else {
                                                            if (!var0.getSpec().isPreviewStep()) {
                                                                doFinalizeImport(var6, var0, false);
                                                                doFinalizeImport(var7, var0, false);
                                                            } else {
                                                                MethodContext.getContext().put("sheetNamePartCache", var7.getSheetNamePartCache());
                                                                MethodContext.getContext().put("keysMappedToPartsCache", getKeysMappedToParts(var7.getSheetNamePartCache()));
                                                            }

                                                            if (null != var9 && !var0.getStatus().equals(ImportJobStatus.CANCELED)) {
                                                                var9.commit();
                                                                var9 = null;
                                                                logger.trace("Transaction committed.");
                                                            }

                                                            logger.debug("Import completed.");
                                                        }

                                                        var6.dumpSessionData(Level.TRACE);
                                                        var7.dumpSessionData(Level.TRACE);
                                                        return var0;
                                                    }

                                                    var45 = (ImportSheetType)var44.next();
                                                    var25 = (List)var18.get(var45);
                                                } while(!var2 && !var4);

                                                if (!var45.equals(ImportSheetType.PART) && !var4) {
                                                    var2 = doSameTypeSheetImport(var7, var0, var45, var25);
                                                    if (!var2) {
                                                        var41 = var2;
                                                    }
                                                } else {
                                                    var2 = doSameTypeSheetImport(var6, var0, var45, var25);
                                                }

                                                if (!var2 && var41) {
                                                    var41 = var2;
                                                }

                                                if (!var4) {
                                                    var6 = null;
                                                    var6 = new SessionData();
                                                    initSessionData(var6, var0);
                                                    var6.setLogger(var8);
                                                }

                                                if (var38) {
                                                    var38 = var2;
                                                }
                                            }
                                        }

                                        var43 = (String)var42.next();
                                    } while(var43 == null);
                                } while(var43.isEmpty());

                                var45 = ImportSheetType.toImportSheetType(var43.toLowerCase());
                            } while(!var40.contains(var45));

                            var25 = (List)var18.get(var45);
                            if (var2 || var4) {
                                if (!var45.equals(ImportSheetType.PART) && !var4) {
                                    var2 = doSameTypeSheetImport(var7, var0, var45, var25);
                                    if (!var2) {
                                        var41 = var2;
                                    }
                                } else {
                                    var2 = doSameTypeSheetImport(var6, var0, var45, var25);
                                }

                                if (!var2 && var41) {
                                    var41 = var2;
                                }

                                if (!var4) {
                                    var6 = null;
                                    var6 = new SessionData();
                                    initSessionData(var6, var0);
                                    var6.setLogger(var8);
                                }

                                if (var38) {
                                    var38 = var2;
                                }
                            }

                            var40.remove(var45);
                        }
                    }
                } else {
                    logger.debug("sheets is null or empty");
                    var8.println(getLocalizedMessage("164", (Object[])null, var6.getJobLocale()));
                    var2 = false;
                }
            } catch (Exception var36) {
                var2 = false;
                doFinalizeImport(var6, var0, true);
                doFinalizeImport(var7, var0, true);
                if (!var4 && var36 instanceof ImportCanceledException) {
                    logger.trace("The import job has been cancelled.");
                } else {
                    var8.println(var36.getMessage());
                    logger.debug(var36);
                    ImportXlsHelper.reportError(new String[]{ImportXlsHelper.getLocaleErrorStr(), xlsFileName, var11, "", var36.getLocalizedMessage()});
                }

                throw var36 instanceof WTException ? (WTException)var36 : new WTException(var36);
            } finally {
                if (null != var9 || var0.getStatus().equals(ImportJobStatus.CANCELED)) {
                    var9.rollback();
                    logger.trace("Rollback the transaction.");
                }

                if (var8 != null) {
                    finalize(var0, var8, var5, var2, var4, var0.getSpec().isPreviewStep());
                }

                try {
                    var0 = (ImportJob)PersistenceHelper.manager.refresh(var0);
                    if (!var4) {
                        var0.setStatus(var2 ? (var0.getSpec().isPreviewStep() ? ImportJobStatus.PARTIAL : ImportJobStatus.COMPLETED) : (var0.getStatus() == ImportJobStatus.CANCELED ? ImportJobStatus.CANCELED : ImportJobStatus.FAILED));
                    } else {
                        var0.setStatus(var2 ? ImportJobStatus.VALIDATED : (var0.getStatus() == ImportJobStatus.CANCELED ? ImportJobStatus.CANCELED : ImportJobStatus.FAILED));
                    }

                    var0 = (ImportJob)PersistenceHelper.manager.save(var0);
                } catch (WTPropertyVetoException var34) {
                    var34.printStackTrace();
                    throw new WTException(var34);
                }
            }

            return var0;
        }
    }

    private static boolean setAdditionalAttributeToIndicateBOMSheetPresence(boolean var0, ImportSheetType var1, HashMap var2) throws WTException {
        if (!var0) {
            if (var1.equals(ImportSheetType.BOM)) {
                var0 = true;
            } else {
                var0 = false;
            }

            var2.put("isBomCache", var0);
        }

        return var0;
    }

    /**
     * 校验分数
     * @param rowMap
     * @throws Exception
     */
    public static void checkFraction(Map rowMap) throws WTException {
        Object fraction = rowMap.get("ct_fraction");
        Object quantity = rowMap.get("Quantity");
        if(CtFormatUtil.hasContent(fraction)){
            //校验分数
            if(!isFraction(fraction.toString())){
                throw new WTException("分数字段只能输入分数,正确格式如：1/2 或 2/1");
            }
            if(CtFormatUtil.hasContent(quantity)){
                //分数转成小数
                double dosage = formatFraction(fraction.toString());
                //目前的数量
                String quantityStr = quantity.toString();
                if(!quantityStr.equals(String.valueOf(dosage))){
                    throw new WTException("数量与分数转换值有差异，分数" + fraction.toString() + ",转换数量应为：" + dosage + "\r\n");
                }
            }
        }
    }

    /**
     * 校验分数
     * @param value
     * @return
     * @throws Exception
     */
    public static boolean isFraction(String value) throws WTException {
        String regexFraction = "\\d+/\\d+";
        return Pattern.matches(regexFraction, value);
    }

    /**
     * 分数转小数，超过六位小数，则进一并保留六位小数
     * @param value
     * @return
     * @throws Exception
     */
    public static double formatFraction(String value) throws WTException{
        String numeratorStr = value.substring(0, value.indexOf("/"));
        String denominatorStr = value.substring(value.indexOf("/") + 1);
        int numerator = Integer.parseInt(numeratorStr);
        int denominator = Integer.parseInt(denominatorStr);
        double d = (double) numerator/denominator;
        return formatDouble(d);
    }

    /**
     * 超过六位小数，则进一并保留六位小数
     * @param d
     * @return
     * @throws Exception
     */
    public static double formatDouble(double d) throws WTException{
        String s = String.valueOf(d);
        int position = s.length() - (s.indexOf(".") + 1);
        if(position > 6){
            int num = (int) (d * 10000000);
            d = (num -num % 10 + 10 * 1.0d) / 10000000.0d;
        }
        return d;
    }

    private static boolean doSameTypeSheetImport(SessionData var0, ImportJob var1, ImportSheetType var2, List var3) throws WTException {
        PrintWriter var4 = var0.getLogger();
        boolean var5 = true;
        String var6 = "";
        byte var7 = 0;
        int var8 = 0;

        try {
            ListIterator var9 = var3.listIterator();

            while(true) {
                List var13;
                String var15;
                ImportSheet var30;
                ImportSheetParser var31;
                Map var32;
                while(true) {
                    if (!var9.hasNext()) {
                        return var5;
                    }

                    boolean var28 = true;
                    var30 = (ImportSheet)var9.next();
                    var4.println();
                    var4.println(getSheetTitle(var30));
                    var6 = var30.getSheetName();
                    var31 = ImportSheetParserFactory.getInstance().newParser(var30);
                    var32 = var31.parseProlog();
                    logger.debug("prolog is " + var32);
                    var13 = null;

                    try {
                        var13 = var31.parseHeader();
                        logger.debug("header is " + var13);
                        break;
                    } catch (WTException var25) {
                        var15 = var25.getLocalizedMessage(var0.getJobLocale());
                        Object[] var16 = var25.getAdditionalMessageArray();
                        int var17 = (Integer)var16[0];
                        String var18 = (String)var16[1];
                        ImportXlsHelper.reportLogError(var4, new String[]{": " + var18, ": " + var17, ": " + var15});
                        ImportXlsHelper.reportError(new String[]{var18, xlsFileName, var6, var17 + "", var15});
                    }
                }

                int var29 = 2;
                SheetElementBuilder var14 = ElementBuilderFactory.getInstance().newSheetElementBuilder(var2);
                if (var1.getSpec().getAction().equals(ImportAction.UPDATE_CHECKED_OUT_PARTS) && !(var14 instanceof PartSheetElementBuilder)) {
                    var15 = ImportXlsHelper.getLocaleWarningStr();
                    String var35 = getLocalizedMessage("IGNORE_SHEET", new Object[]{var6}, var0.getJobLocale());
                    ImportXlsHelper.reportLogError(var4, new String[]{": " + var15, ": ", ": " + var35});
                    ImportXlsHelper.reportError(new String[]{var15, xlsFileName, var6, "", var35});
                    return true;
                }

                var14.initialize(var32, var13, var0);
                LinkedHashMap var33 = new LinkedHashMap();
                ArrayList var34 = new ArrayList();

                for(Iterator var36 = var31.parseSheet(); var36.hasNext(); ++var29) {
                    var1 = (ImportJob)PersistenceHelper.manager.refresh(var1);
                    if (var1.getStatus() == ImportJobStatus.CANCELED) {
                        return false;
                    }

                    Map var37 = (Map)var36.next();
                    if (null != var37.values() && var37.values().size() != 0) {
                        ImportElement var19 = null;
                        var0.setFileName(xlsFileName);
                        var0.setSheetName(var6);
                        var0.setRowNumber(5 + var29 + "");

                        String var21;
                        String var23;
                        try {
                            //客制化代码，校验分数
                            checkFraction(var37);
                            var19 = var14.newElement(var37);
                        } catch (WTException var26) {
                            if (!var0.isPreview()) {
                                ImportXlsHelper.reportLogError(var4, new String[]{ImportXlsHelper.getLocaleTypeStr() + ": " + ImportXlsHelper.getLocaleErrorStr(), "", ImportXlsHelper.getLocaleDescriptionStr() + ": " + var26.getLocalizedMessage()});
                                var26.printStackTrace(var4);
                                var5 = false;
                                throw new WTException("Import failed...");
                            }

                            logger.debug("StandardImportService -> doPreviewOrImport() : " + var26);
                            var21 = ImportXlsHelper.getLocaleErrorStr();
                            String var22 = var26.getLocalizedMessage(var0.getJobLocale());
                            if (var26.getAdditionalMessageArray() != null && var26.getAdditionalMessageArray().length > 0 && var26.getAdditionalMessageArray()[0].equals(ImportXlsHelper.getLocaleWarningStr())) {
                                var21 = ImportXlsHelper.getLocaleWarningStr();
                                var22 = var26.getCause().getLocalizedMessage();
                            }

                            var23 = 5 + var29 + "";
                            ImportXlsHelper.reportLogError(var4, new String[]{": " + var21, ": " + var23, ": " + var22});
                            ImportXlsHelper.reportError(new String[]{var21, xlsFileName, var6, var23, var22});
                            if (var21.equals(ImportXlsHelper.getLocaleErrorStr())) {
                                var5 = false;
                            }
                        }

                        if (null != var19) {
                            if (logger.isTraceEnabled()) {
                                ImportHndHelper.printDomXml(var19.getDocument().getDom(), System.out);
                            }

                            String var20 = var19.getPathToTrackable();
                            var21 = var19.getDocument().getValue(var20);
                            if (var0.isPreview() && null == var21) {
                                var21 = " ((null))";
                            }

                            if (null == var21 || "".equals(var21)) {
                                throw new WTException("com.ptc.windchill.ixb.importer.importerResource", "307", new Object[0]);
                            }

                            if (logger.isTraceEnabled()) {
                                logger.debug("Key = <" + var21 + ">");
                            }

                            TreeMap var40;
                            if (var33.containsKey(var21)) {
                                List var38 = (List)var33.get(var21);
                                var23 = null;
                                if (var2.equals(ImportSheetType.PART)) {
                                    var40 = (TreeMap)var38.get(0);
                                } else {
                                    List var24 = (List)var38.get(0);
                                    var40 = (TreeMap)var24.get(0);
                                }

                                ++var8;
                                var40.put(var29, var19);
                            } else {
                                ArrayList var39 = new ArrayList();
                                var40 = new TreeMap();
                                ++var8;
                                var40.put(var29, var19);
                                var39.add(var40);
                                if (var2.equals(ImportSheetType.PART)) {
                                    var33.put(var21, var39);
                                } else {
                                    ArrayList var41 = new ArrayList();
                                    var41.add(0, var39);
                                    if (var2.equals(ImportSheetType.BOM)) {
                                        var41.add(1, var37.get("Level"));
                                    }

                                    var33.put(var21, var41);
                                }
                            }

                            var34.add(var21);
                            if (var8 >= importChunkSize && !var33.keySet().isEmpty() && !var2.equals(ImportSheetType.BOM)) {
                                var5 = importInChunk(var1, var0, var2, var30, var29, var33, var4, var5);
                                var33.clear();
                            }
                        } else {
                            logger.debug("The ImportElement object is null, ignore it.");
                        }
                    }
                }

                logger.debug("Build the import element map with " + var33.size() + " key(s).");
                if (var33.keySet().size() != 0 && !var33.keySet().isEmpty()) {
                    var5 = importInChunk(var1, var0, var2, var30, var29, var33, var4, var5);
                }
            }
        } catch (Exception var27) {
            logger.debug("StandardImportService -> doSameTypeSheetImport() : ImportSheetType :" + var2, var27);
            if (!var0.isPreview() && var27 instanceof ImportCanceledException) {
                logger.trace("The import job has been cancelled.");
            } else {
                String var10 = ImportXlsHelper.getLocaleErrorStr();
                String var11 = 5 + var7 + "";
                String var12 = var27.getLocalizedMessage();
                ImportXlsHelper.reportLogError(var4, new String[]{": " + var10, ": " + var11, ": " + var12});
                ImportXlsHelper.reportError(new String[]{var10, xlsFileName, var6, var11, var12});
                logger.debug(var27.getMessage());
            }

            var5 = false;
            if (!var0.isPreview()) {
                throw new WTException(var27);
            } else {
                return var5;
            }
        }
    }

    private static boolean importInChunk(ImportJob var0, SessionData var1, ImportSheetType var2, ImportSheet var3, int var4, Map var5, PrintWriter var6, boolean var7) throws WTException, WTPropertyVetoException {
        ImportXlsHandler var8 = getHandler(var0, var1.getLogger());
        SheetImporter var9 = ImporterFactory.getInstance().newSheetImporter(var2);
        var9.setSheetNumber(var3.getSheetNumber());
        var9.setSheetName(var3.getSheetName());
        Importer var10 = getIxbImporter(var0, var8);
        var9.initialize(var0, var10, var1);
        if (var1.isSkipCopyForwardPrefrance() == null) {
            WTContainerRef var11 = var10.getTargetContainerRef();
            boolean var12 = ImportHndHelper.skipCopyForward(var11);
            var1.setSkipCopyForwardPrefrance(var12);
        }

        boolean var23 = false;

        try {
            var9.importSheetElements(var5);
        } catch (WTException var22) {
            logger.debug("StandardImportService -> doSameTypeSheetImport() : ImportSheetType :" + var2, var22);
            if (!var1.isPreview()) {
                ImportXlsHelper.reportLogError(var6, new String[]{ImportXlsHelper.getLocaleTypeStr() + ": " + ImportXlsHelper.getLocaleErrorStr(), "", ImportXlsHelper.getLocaleDescriptionStr() + ": " + var22.getLocalizedMessage()});
                var22.printStackTrace(var6);
                var7 = false;
                throw new WTException("Import failed...");
            }

            Object[] var24 = var22.getAdditionalMessageArray();
            if (var24 != null && var24.length > 0) {
                Object[] var13 = var24;
                int var14 = var24.length;

                for(int var15 = 0; var15 < var14; ++var15) {
                    Object var16 = var13[var15];
                    WTException var17 = (WTException)var16;
                    if (logger.isDebugEnabled()) {
                        var17.printStackTrace();
                    }

                    String var18 = getExceptionMessage(var17, var1);
                    Object[] var19 = var17.getAdditionalMessageArray();
                    int var20 = (Integer)var19[0] + 5;
                    String var21 = (String)var19[1];
                    ImportXlsHelper.reportLogError(var6, new String[]{": " + var21, ": " + var20, ": " + var18});
                    ImportXlsHelper.reportError(new String[]{var21, xlsFileName, var1.getSheetName(), var20 + "", var18});
                    if (var21.equals(ImportXlsHelper.getLocaleErrorStr())) {
                        var7 = false;
                    }
                }
            }
        }

        return var7;
    }

    private static String getExceptionMessage(Throwable var0, SessionData var1) throws WTException {
        String var2 = "";
        Locale var3 = var1.getJobLocale();
        Throwable var4 = var0.getCause();
        if (var4.getCause() != null) {
            var2 = getExceptionMessage(var4, var1);
        } else if (var4 instanceof WTException) {
            var2 = ((WTException)var4).getLocalizedMessage(var3);
        } else if (var4 instanceof WTRuntimeException) {
            var2 = ((WTRuntimeException)var4).getLocalizedMessage(var3);
        } else if (var4 instanceof WTPropertyVetoException) {
            var2 = ((WTPropertyVetoException)var4).getLocalizedMessage(var3);
        } else if (var4 instanceof Exception) {
            var2 = ((Exception)var4).toString();
        }

        return var2;
    }

    private static void doFinalizeImport(SessionData var0, ImportJob var1, boolean var2) throws WTException {
        Map var3 = var0.getCheckedOutBeanCache();
        Set var4 = var3.keySet();
        Iterator var5 = var4.iterator();

        while(var5.hasNext()) {
            ((AbstractCheckedOutObject)var3.get(var5.next())).doPostCleanUpImport(var1, !var2);
        }

    }

    private static synchronized void closeImportLog(PrintWriter var0, boolean var1, boolean var2, Locale var3) throws WTException {
        if (var0 != null) {
            if (var2 && var1) {
                var0.println(getLocalizedMessage("PREVIEW_RESULT_VALIDATED", (Object[])null, var3));
            } else if (var2 && !var1) {
                var0.println(getLocalizedMessage("170", (Object[])null, var3));
            } else if (!var2 && var1) {
                var0.println(getLocalizedMessage("171", (Object[])null, var3));
            } else {
                var0.println(getLocalizedMessage("172", (Object[])null, var3));
            }

            var0.flush();
            var0.close();
        }

    }

    private static void removeConflictResolutions() throws WTException {
        MethodContext var0 = MethodContext.getContext();
        if (var0 != null && var0.get("RESOLUTIONS_STORE") != null) {
            var0.remove("RESOLUTIONS_STORE");
        }

    }

    private static void finalize(ImportJob var0, PrintWriter var1, File var2, boolean var3, boolean var4, boolean var5) throws WTException {
        if (var1 != null) {
            try {
                if (!var4) {
                    var0.setStatus(var3 ? (var5 ? ImportJobStatus.PARTIAL : ImportJobStatus.COMPLETED) : ImportJobStatus.FAILED);
                } else {
                    var0.setStatus(var3 ? ImportJobStatus.VALIDATED : ImportJobStatus.FAILED);
                }

                closeImportLog(var1, var3, var4, var0.getSpec().getLocale());
                QueryResult var6 = ContentHelper.service.getContentsByRole(var0, ContentRoleType.SECONDARY);
                ApplicationData var7 = null;
                if (!var6.hasMoreElements()) {
                    var7 = ApplicationData.newApplicationData(var0);
                } else {
                    var7 = (ApplicationData)var6.nextElement();
                    String var8 = var7.getUploadedFromPath();
                    File var9 = new File(var8);
                    if (var9.delete()) {
                        logger.debug("File <" + var8 + "> has been deleted.");
                    }
                }

                var7.setFileName(var2.getName());
                var7.setUploadedFromPath(var2.getAbsolutePath());
                var7.setDescription("Import log file: " + var2.getName());
                var7.setRole(ContentRoleType.SECONDARY);
                ContentServerHelper.service.updateContent(var0, var7, var2.getAbsolutePath());
                removeConflictResolutions();
            } catch (Exception var10) {
                throw var10 instanceof WTException ? (WTException)var10 : new WTException(var10);
            }
        }
    }

    private static String getSheetTitle(ImportSheet var0) {
        int var1 = var0.getSheetNumber();
        String var2 = var0.getSheetName();
        String var3 = new String("");
        if (var1 >= 0) {
            var3 = "Sheet " + var1;
        }

        if (null != var2 && var2.trim().length() > 0) {
            var3 = var3 + " \"" + var2 + "\"";
        }

        var3 = var3 + ":";
        return var3;
    }

    private static String getLocalizedMessage(String var0, Object[] var1, Locale var2) {
        return (new WTMessage("com.ptc.windchill.ixb.importer.importerResource", var0, var1)).getLocalizedMessage(var2);
    }

    private void processPreInsertForImportJob(WTCollection var1) throws WTException {
        logger.debug("PRE_INSERT: processing " + var1.size() + " import jobs");

        try {
            Iterator var2 = var1.persistableIterator();

            while(var2.hasNext()) {
                ImportJob var3 = (ImportJob)var2.next();
                String var4 = PersistenceHelper.manager.getNextSequence(ImportJobNumberSeq.class);
                var3.setNumber(Long.parseLong(var4));
                logger.debug("job number is set to: " + var3.getNumber());
            }
        } catch (Exception var5) {
            throw new WTException(var5);
        }

        logger.debug("PRE_INSERT: processed " + var1.size() + " import jobs");
    }

    private static ImportSourceFormat getImportSourceFormat(ImportJob var0) throws WTException {
        String var1 = var0.getSpec().getFilename();
        String var2 = var1.substring(var1.lastIndexOf(".") + 1).toLowerCase();
        ImportSourceFormat var3 = ImportSourceFormat.toImportSourceFormat(var2);
        logger.debug("getImportSourceFormat(): filename=" + var1 + " extension=" + var2 + " format=" + var3);
        return var3;
    }

    private static Map getKeysMappedToParts(Map var0) throws WTException {
        HashMap var1 = new HashMap();
        Set var2 = var0 != null ? var0.keySet() : null;
        Iterator var3 = var2 != null ? var2.iterator() : null;
        if (var3 != null) {
            Object var4 = null;
            ObjectIdentifier var5 = null;
            WTPart var6 = null;

            while(var3.hasNext()) {
                var4 = var3.next();
                var5 = ImportHndHelper.getObjectIdentifier(var4 + "");
                var6 = (WTPart)PersistenceHelper.manager.refresh(var5);
                var1.put(var6, var4);
            }
        }

        return var1;
    }

    private static void initSessionData(SessionData var0, ImportJob var1) throws WTException {
        if (var1.getImportJobArgsBean() != null) {
            if (var1.getImportJobArgsBean().getFolderPath() == null) {
                var0.setDirectoryPathCache("/Default");
            } else {
                var0.setDirectoryPathCache(var1.getImportJobArgsBean().getFolderPath());
            }
        }

        var0.setPreview(var1.getSpec().isPreview());
        var0.setContainerRef(var1.getContainerReference());
        var0.setImportAction(var1.getSpec().getAction());
        var0.setJobLocale(var1.getSpec().getLocale());
        var0.setOid(var1.getImportJobArgsBean().getOid());
    }

    private static PreImportSheetValidator getPreImportSheetValidatorHandler(ImportJob var0, ImportSheetParser var1) {
        Object var2 = null;
        ImportSheetType var3 = null;
        String var4 = null;

        try {
            var3 = var1.parseSheetType();
        } catch (WTException var8) {
            var3 = null;
        }

        logger.debug("parser is a " + var1.getClass().getName());
        if (var3 != null) {
            var4 = var3.getDisplay();
        }

        if (var0 != null && var4 != null) {
            String var5 = var4;

            try {
                var2 = (PreImportSheetValidator)DefaultServiceProvider.getService(PreImportSheetValidator.class, var5, var0);
            } catch (UnableToCreateServiceException var7) {
                logger.info("The requestor:" + var0 + ", selector:" + var4 + " doesn't have LabelHandler");
            }

            if (var2 == null) {
                var2 = new StandardPreImportSheetValidator();
            }

            return (PreImportSheetValidator)var2;
        } else {
            return new StandardPreImportSheetValidator();
        }
    }

    static {
        logger = LogR.getLogger(CLASSNAME);
        xlsFileName = "";

        try {
            WTProperties var0 = WTProperties.getLocalProperties();
            DEFAULT_SENDER_EMAIL = var0.getProperty("wt.notify.notificationSenderEmail");
        } catch (Throwable var1) {
            logger.error("Error initializing " + com.ptc.windchill.ixb.importer.StandardImportService.class.getName(), var1);
            throw new ExceptionInInitializerError(var1);
        }
    }
}
