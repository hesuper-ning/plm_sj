//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.windchill.pdmlink.object.operations.pasteAsCopy.datautilities;

import com.ptc.core.components.descriptor.JCAObject;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.factory.CloneDatum;
import com.ptc.core.components.rendering.guicomponents.ComboBox;
import com.ptc.core.components.util.AttributeHelper;
import com.ptc.core.meta.common.AttributeIdentifier;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.type.common.TypeInstance;
import org.apache.log4j.Logger;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.views.ViewReference;

import java.util.ArrayList;
import java.util.Locale;

public class ViewIdForPasteTableDataUtility extends AbstractDataUtility {
    private static final Logger logger;
    private Locale locale = null;
    private static final String EMPTY_VIEW = "";

    public ViewIdForPasteTableDataUtility() {
    }

    public Object getDataValue(String var1, Object var2, ModelContext var3) throws WTException {
        if (var2 instanceof CloneDatum) {
            CloneDatum var4 = (CloneDatum)var2;
            if (!(var4.getJcaObject().getBackingObject() instanceof WTPart)) {
                return null;
            } else {
                WTPart var5 = (WTPart)var4.getJcaObject().getBackingObject();
                if (this.locale == null && var3 != null) {
                    this.locale = var3.getLocale();
                } else {
                    this.locale = SessionHelper.getLocale();
                }

                ComboBox var6 = new ComboBox();
                ArrayList var7 = new ArrayList();
                var7.add(var5.getViewName());
//                View[] var8 = ViewHelper.service.getAllViews();
//                for(int var9 = 0; var9 < var8.length; ++var9) {
//                    View var10 = var8[var9];
//                    var7.add(var10.getName());
//                    if (logger.isDebugEnabled()) {
//                        logger.debug("Child view: " + var10.getName());
//                    }
//                }

                var6.setId("30");
                var6.setName("30");
                var6.setLocale(this.locale);
                var6.setValues(var7);
                String var11 = this.getSelectedValue(var4.getJcaObject(), var4.getTypeInstanceForClone(), var5);
                if (var11 != null) {
                    var6.setSelected(var11);
                } else {
                    var6.setSelected((String)var7.get(0));
                }

                return var6;
            }
        } else {
            return null;
        }
    }

    private String getSelectedValue(JCAObject var1, TypeInstance var2, WTPart var3) throws WTException {
        String var4 = "";
        AttributeTypeIdentifier var5 = AttributeHelper.getATI("view.id", (TypeIdentifier)var2.getIdentifier().getDefinitionIdentifier(), false);
        AttributeIdentifier[] var6 = var2.getAttributeIdentifiers(var5);
        if (var6 != null && var6.length > 0) {
            Object var7 = var2.get(var6[0]);
            if (var7 != null) {
                if (var7 instanceof ViewReference) {
                    var4 = ((ViewReference)var7).getName();
                }

                if (var7 instanceof String) {
                    var4 = (String)var7;
                }
            } else {
                var4 = var3.getViewName();
            }
        }

        return var4;
    }

    static {
        try {
            logger = LogR.getLogger(ViewIdForPasteTableDataUtility.class.getName());
        } catch (Exception var1) {
            throw new ExceptionInInitializerError(var1);
        }
    }
}
