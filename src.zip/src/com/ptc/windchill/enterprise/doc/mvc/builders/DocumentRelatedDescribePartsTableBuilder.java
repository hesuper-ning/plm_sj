//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.windchill.enterprise.doc.mvc.builders;

import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.jca.mvc.components.JcaColumnConfig;
import com.ptc.mvc.components.*;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ext.plm.util.CtDocUtil;
import ext.plm.util.CtFormatUtil;
import ext.plm.util.CtPartUtil;
import ext.plm.util.CtVersionUtil;
import org.apache.log4j.Logger;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.fc.QueryResult;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;

@ComponentBuilder({"docRelatedDescribeParts"})
public class DocumentRelatedDescribePartsTableBuilder extends AbstractDocumentRelatedTableBuilder {
    private static final Logger log;
    public static final Method getAssociatedPartsMethod;

    public DocumentRelatedDescribePartsTableBuilder() {
    }

    public Object buildComponentData(ComponentConfig var1, ComponentParams var2) throws Exception {
        Object var3 = var2.getContextObject();
        Object var4 = null;
        if (var3 instanceof WTDocument) {
            log.debug("Context object is document " + ((WTDocument)var3).getName());
            //var4 = getAssociatedPartsMethod.invoke((Object)null, (WTDocument)var3);
            WTDocument doc = (WTDocument)var3;
            String docNumber = doc.getNumber();
            WTDocument docNew = CtDocUtil.getDocumentByNumber(docNumber);
            long docIda2a2 = doc.getPersistInfo().getObjectIdentifier().getId();
            long docIda2a2New = docNew.getPersistInfo().getObjectIdentifier().getId();
            //过滤不是最新的部件
            QueryResult queryResult = WTPartHelper.service
                    .getDescribesWTParts(doc);
            var4 = getAssociatedPartsMethod.invoke((Object)null, (WTDocument)var3);
            List<WTPart> list = new ArrayList<>();
            List<WTPart> listM = new ArrayList<>();
            List<WTPart> listD = new ArrayList<>();
            HashMap<String,List<WTPart>> hash = new HashMap<>();
            if (queryResult != null && queryResult.size() > 0) {
                while (queryResult.hasMoreElements()) {
                    WTPart part = (WTPart) queryResult.nextElement();
                    String partNumber = part.getNumber();
                    String view = part.getViewName();
                    long ida2a2 = part.getPersistInfo().getObjectIdentifier().getId();

                    //判断当前文档是否是最新的文档对象
                    if(docIda2a2==docIda2a2New) {
                        if (view.equals("Design")) {
                            //判断文档关联的物料是不是最新的
                            WTPart partD = CtPartUtil.getPartByNumber(partNumber, "Design");
                            long ida2a2D = partD.getPersistInfo().getObjectIdentifier().getId();
                            //boolean bb = ida2a2 .equals(ida2a2D) ;
                            if (CtFormatUtil.hasContent(partD) && ida2a2 == ida2a2D) {
                                list.add(part);
                            }
                        }
                        if (view.equals("Manufacturing")) {
                            WTPart partM = CtPartUtil.getPartByNumber(partNumber, "Manufacturing");
                            long ida2a2M = partM.getPersistInfo().getObjectIdentifier().getId();
                            if (CtFormatUtil.hasContent(partM) && ida2a2 == ida2a2M) {
                                list.add(part);
                            }
                        }
                    }

                    //按照部件编码和视图分类
                    if(!(docIda2a2==docIda2a2New)) {
                        String numberAndView = partNumber + view;
                        if (!hash.containsKey(numberAndView)) {
                            List<WTPart> li = new ArrayList<>();
                            li.add(part);
                            hash.put(numberAndView, li);
                        } else {
                            hash.get(numberAndView).add(part);
                        }
                    }
                    //if (CtVersionUtil.isLatest(part)) {
                    //    System.out.println("2"+CtVersionUtil.getVersionInfo(part));
                    //    list.add(part);
                    //}
                }
                //如果文档不是最新版本则显示文档关联的所有相同物料中的最新版本
                if(!(docIda2a2==docIda2a2New)) {
                    for (HashMap.Entry<String, List<WTPart>> entry : hash.entrySet()) {
                        String key = entry.getKey();
                        List<WTPart> value = entry.getValue();
                        int letterBefore = 0;
                        int numberBefore = 0;
                        WTPart wtPartFinally = null;
                        for (int i = 0; i < value.size(); i++) {
                            WTPart wtPart = value.get(i);
                            String versionInfo = CtVersionUtil.getVersionInfo(wtPart);
                            String[] parts = versionInfo.split("\\.");
                            String letterAfter = parts[0];
                            String numberAfter = parts[1];
                            char charA = letterAfter.toCharArray()[0];
                            char charB = numberAfter.toCharArray()[0];
                            int asciiA = (int) charA;
                            int asciiB = (int) charB;
                            //先通过大版本过滤再根据小版本过滤
                            if (letterBefore == 0) {
                                letterBefore = asciiA;
                                numberBefore = asciiB;
                                wtPartFinally = wtPart;
                            } else if (asciiA > letterBefore) {
                                letterBefore = asciiA;
                                wtPartFinally = wtPart;
                            } else if (asciiA == letterBefore) {
                                if (asciiB > numberBefore) {
                                    numberBefore = asciiB;
                                    wtPartFinally = wtPart;
                                }
                            }

                        }
                        list.add(wtPartFinally);
                    }
                }

                var4 = list;
            }
        }

        return var4;
    }

    public ComponentConfig buildComponentConfig(ComponentParams var1) throws WTException {
        TableConfig var2 = (TableConfig)super.buildComponentConfig(var1);
        String var3 = WTMessage.getLocalizedMessage("com.ptc.windchill.enterprise.part.partResource", "DESCRIBES_PARTS_TABLE_HEADER", (Object[])null, SessionHelper.getLocale());
        var2.setLabel(var3);
        var2.setSelectable(true);
        var2.setId("part.relatedDocumentsDescribesParts.list");
        var2.setActionModel("relatedDocPartDescribesToolBar");
        var2.setHelpContext("part_describe_ref");
        return var2;
    }

    public ConfigurableTable buildConfigurableTable(String var1) throws WTException {
        ConfigurableTable var3 = null;

        try {
            Class var2 = Class.forName("com.ptc.windchill.enterprise.part.views.DocumentsPartsDescTableViews");
            var3 = (ConfigurableTable)var2.newInstance();
        } catch (Exception var5) {
            log.error("Unable to instantiate Table view for id: " + var1, var5);
        }

        return var3;
    }

    static {
        try {
            Class var0 = Class.forName("com.ptc.windchill.enterprise.part.commands.PartDocServiceCommand");
            getAssociatedPartsMethod = var0.getMethod("getAssociatedDescParts", Class.forName("wt.doc.WTDocument"));
            log = LogR.getLogger(DocumentRelatedDescribePartsTableBuilder.class.getName());
        } catch (Exception var1) {
            var1.printStackTrace();
            throw new ExceptionInInitializerError(var1);
        }
    }
}
