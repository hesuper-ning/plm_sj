//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.windchill.enterprise.object;

import com.ptc.core.htmlcomp.components.JCAConfigurableTable;
import com.ptc.core.htmlcomp.createtableview.Attribute;
import com.ptc.core.htmlcomp.tableview.TableColumnDefinition;
import com.ptc.core.htmlcomp.tableview.TableViewDescriptor;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

public class WhereUsedTableView extends JCAConfigurableTable {
    private static final String CLASSNAME = WhereUsedTableView.class.getName();
    public static final String STATUSGENERAL = "statusFamily_General";
    public static final String STATUSCHANGE = "statusFamily_Change";
    public static final String TYPE = "type_icon";
    public static final String NUMBER = "number";
    public static final String VERSION = "groupedVersions";
    public static final String ORGANIZATION_ID = "orgid";
    public static final String NAME = "name";
    public static final String CONTAINER = "containerName";
    public static final String DETAILSACTIONS = "detailsAction";
    private static final String RESOURCE = "com.ptc.windchill.enterprise.object.whereUsedResource";

    public WhereUsedTableView() {
    }

    public boolean canAttributeBeUsedInFilter(String var1) {
        return false;
    }

    public Class[] getClassTypes() {
        return new Class[]{WTPart.class, WTDocument.class, WTPartMaster.class, WTDocumentMaster.class};
    }

    public String getLabel(Locale var1) {
        return WTMessage.getLocalizedMessage("com.ptc.windchill.enterprise.object.whereUsedResource", "1", (Object[])null, var1);
    }

    public String getOOTBActiveViewName() {
        return getViewResourceEntryKey("com.ptc.windchill.enterprise.object.whereUsedResource", "3");
    }

    public List getOOTBTableViews(String var1, Locale var2) throws WTException {
        ArrayList var3 = new ArrayList(1);
        Vector var4 = new Vector(10);
        Vector var5 = new Vector(10);

        try {
            var4.add(TableColumnDefinition.newTableColumnDefinition("number", true));
            var4.add(TableColumnDefinition.newTableColumnDefinition("orgid", true));
            var4.add(TableColumnDefinition.newTableColumnDefinition("groupedVersions", false));
            var4.add(TableColumnDefinition.newTableColumnDefinition("name", false));
            var4.add(TableColumnDefinition.newTableColumnDefinition("containerName", false));
            var4.add(TableColumnDefinition.newTableColumnDefinition("IBA|ct_banci", false));
            var4.add(TableColumnDefinition.newTableColumnDefinition("IBA|ct_ModelSpecification", false));
            var4.add(TableColumnDefinition.newTableColumnDefinition("IBA|ct_materialType", false));
            //var4.add(TableColumnDefinition.newTableColumnDefinition("IBA|ct_BOMNotes", false));
            var4.add(TableColumnDefinition.newTableColumnDefinition("state", false));
            String var6 = getViewResourceEntryKey("com.ptc.windchill.enterprise.object.whereUsedResource", "3");
            String var7 = getViewResourceEntryKey("com.ptc.windchill.enterprise.object.whereUsedResource", "3");
            TableViewDescriptor var8 = TableViewDescriptor.newTableViewDescriptor(var6, var1, true, true, var4, (Vector)null, true, var7);
            var8.setSystem(false);
            var3.add(var8);
            var5.add(TableColumnDefinition.newTableColumnDefinition("number", true));
            var5.add(TableColumnDefinition.newTableColumnDefinition("orgid", true));
            var5.add(TableColumnDefinition.newTableColumnDefinition("groupedVersions", false));
            var5.add(TableColumnDefinition.newTableColumnDefinition("name", false));
            var5.add(TableColumnDefinition.newTableColumnDefinition("containerName", false));
            var5.add(TableColumnDefinition.newTableColumnDefinition("IBA|ct_banci", false));
            var5.add(TableColumnDefinition.newTableColumnDefinition("IBA|ct_ModelSpecification", false));
            var5.add(TableColumnDefinition.newTableColumnDefinition("IBA|ct_materialType", false));
            //var5.add(TableColumnDefinition.newTableColumnDefinition("IBA|ct_BOMNotes", false));
            var5.add(TableColumnDefinition.newTableColumnDefinition("state", false));
            var6 = getViewResourceEntryKey("com.ptc.windchill.enterprise.object.whereUsedResource", "2");
            var7 = getViewResourceEntryKey("com.ptc.windchill.enterprise.object.whereUsedResource", "2");
            var8 = TableViewDescriptor.newTableViewDescriptor(var6, var1, true, true, var5, (Vector)null, true, var7);
            var8.setSystem(false);
            var3.add(var8);
            return var3;
        } catch (WTPropertyVetoException var9) {
            throw new WTRuntimeException(var9);
        }
    }

    public List getSpecialTableColumnsAttrDefinition(Locale var1) {
        ArrayList var2 = new ArrayList(1);
        var2.add(new Attribute.TextAttribute("creator", "creator", var1));
        return var2;
    }

    public boolean isColumnLocked(String var1) {
        return true;
    }

    public String getDefaultSortColumn() {
        return "number";
    }
}
