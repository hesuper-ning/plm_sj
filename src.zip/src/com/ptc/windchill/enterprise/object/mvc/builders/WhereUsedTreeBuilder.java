//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.windchill.enterprise.object.mvc.builders;

import com.ptc.core.htmlcomp.components.AbstractConfigurableTableBuilder;
import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.jca.mvc.components.JcaColumnConfig;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.jca.mvc.components.JcaTreeConfig;
import com.ptc.mvc.components.*;
import com.ptc.mvc.components.ds.DataSourceMode;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.beans.NmHelperBean;
import com.ptc.netmarkets.util.beans.NmSessionBean;
import com.ptc.windchill.enterprise.object.WhereUsedTableView;
import com.ptc.windchill.enterprise.object.WhereUsedTreeHandler;
import com.ptc.windchill.enterprise.utility.EnterpriseHelper;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

@Scope("prototype")
@ComponentBuilder({"enterpriseUI.whereUsed.view"})
public class WhereUsedTreeBuilder extends AbstractConfigurableTableBuilder implements TreeDataBuilderAsync {
    private static final Logger log = LogR.getLogger(WhereUsedTreeBuilder.class.getName());
    private WhereUsedTreeHandler treeHandler = null;
    ClientMessageSource messageWhereUsedResource = this.getMessageSource("com.ptc.windchill.enterprise.object.whereUsedResource");

    public WhereUsedTreeBuilder() {
    }

    public Object buildComponentData(ComponentConfig var1, ComponentParams var2) throws Exception {
        return new WhereUsedTreeHandler();
    }

    public ComponentConfig buildComponentConfig(ComponentParams var1) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("WhereUsedTreeBuilder - Entering buildComponentConfig");
        }

        if (log.isTraceEnabled()) {
            log.trace("WhereUsedTreeBuilder.buildComponentConfig input params " + var1);
        }
        String var2 = "";
        NmHelperBean var3 = ((JcaComponentParams)var1).getHelperBean();
        NmCommandBean var4 = var3.getNmCommandBean();
        NmSessionBean var5 = var3.getNmSessionBean();
        ComponentConfigFactory var6 = this.getComponentConfigFactory();
        JcaTreeConfig var7 = (JcaTreeConfig)var6.newTreeConfig();
        Object var8 = var4.getPageOid().getRef();
        if (EnterpriseHelper.isProjectLink((Persistable)var8)) {
            var2 = "whereUsed";
        } else {
            var2 = "whereUsed.view";
        }

        if (var4.getTextParameter("viewchange") != null) {
            var5.removeAllNodes(var4, "whereUsed.view");
        }

        var1.setAttribute("whereUsedTableID", var2);
        var7.setId(var2);
        var7.setShowCustomViewLink(false);
        var7.setNodeColumn("number");
        var7.setExpansionLevel("one");
        var7.setTargetObject("contextObject");
        var7.setLabel(this.messageWhereUsedResource.getMessage("1"));
        var7.setSelectable(true);
        var7.setActionModel("whereUsedTablePart");
        ColumnConfig var9 = var6.newColumnConfig("number", true);
        var9.setInfoPageLink(false);
        var9.setDataUtilityId("whereUsedNumber");
        var7.addComponent(var9);
        var7.addComponent(var6.newColumnConfig("orgid", false));
        var9 = var6.newColumnConfig("groupedVersions", false);
        var9.setTargetObject("");
        var9.setVariableHeight(true);
        var7.addComponent(var9);
        var7.addComponent(var6.newColumnConfig("name", true));
        var9 = var6.newColumnConfig("containerName", true);
        var9.setTargetObject("contained");
        var7.addComponent(var9);
        var7.addComponent(var6.newColumnConfig("IBA|ct_banci", "内部版本", true));
        var7.addComponent(var6.newColumnConfig("IBA|mkt_banben", "规格型号", true));
        var7.addComponent(var6.newColumnConfig("IBA|ct_materialType", "物料类型", true));
        //var7.addComponent(var6.newColumnConfig("IBA|ct_BOMNotes", "BOM备注", true));
        var7.addComponent(var6.newColumnConfig("state", "状态", true));
        var9 = var6.newColumnConfig("nmActions", false);
        ((JcaColumnConfig)var9).setDescriptorProperty("actionModel", "EMPTY_ACTION_MODEL");
        var7.addComponent(var9);
        var7.setHelpContext("WhereUsedTableHelp");
        var7.setDataSourceMode(DataSourceMode.ASYNCHRONOUS);
        if (log.isDebugEnabled()) {
            log.debug("Tree Id is   :-- " + var7.getId());
        }

        return var7;
    }

    public ConfigurableTable buildConfigurableTable(String var1) throws WTException {
        return "whereUsed.view".equals(var1) ? new WhereUsedTableView() : null;
    }

    public void buildNodeData(Object var1, ComponentResultProcessor var2) throws Exception {
        if (var1 == TreeNode.RootNode) {
            this.treeHandler = new WhereUsedTreeHandler(var2.getParams());
            var2.addElements(this.treeHandler.getRootNodes());
        } else {
            ArrayList var3 = new ArrayList();
            var3.add(var1);
            if (this.treeHandler == null) {
                this.treeHandler = new WhereUsedTreeHandler(var2.getParams());
            }

            Map var4 = this.treeHandler.getNodes(var3);
            Set var5 = var4.keySet();
            Iterator var6 = var5.iterator();

            while(var6.hasNext()) {
                Object var7 = var6.next();
                var2.addElements((Iterable)var4.get(var7));
            }
        }

    }
}
