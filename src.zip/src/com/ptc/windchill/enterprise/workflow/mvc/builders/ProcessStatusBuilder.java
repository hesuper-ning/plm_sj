package com.ptc.windchill.enterprise.workflow.mvc.builders;

import com.ptc.jca.mvc.components.AbstractJcaComponentConfig;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.jca.mvc.components.JcaTableConfig;
import com.ptc.mvc.components.*;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.beans.NmHelperBean;
import com.ptc.windchill.enterprise.workflow.WorkflowCommands;
import org.apache.log4j.Logger;
import wt.fc.ObjectReference;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.lifecycle.LifeCycleLWHelper;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.workflow.engine.LWWfProcess;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfState;

/**
 * OOTB工作流任务builder，增加附件展示
 */
@ComponentBuilder({"enterpriseui.netmarkets.workitem.list"})
public class ProcessStatusBuilder extends AbstractComponentBuilder {
    private static final String LIFE_CYCLE_RESOURCE = "wt.lifecycle.lifecycleResource";
    private static final String WORK_FLOW_RESOURCE = "com.ptc.netmarkets.workflow.workflowResource";
    ClientMessageSource messageLifeCycleSource = this.getMessageSource("wt.lifecycle.lifecycleResource");
    ClientMessageSource messageWorkFlowSource = this.getMessageSource("com.ptc.netmarkets.workflow.workflowResource");
    private static final Logger log = LogR.getLogger(ProcessStatusBuilder.class.getName());

    public ProcessStatusBuilder() {
    }

    public Object buildComponentData(ComponentConfig var1, ComponentParams var2) throws WTException {
        NmHelperBean var3 = ((JcaComponentParams)var2).getHelperBean();
        NmCommandBean var4 = var3.getNmCommandBean();
        NmOid var5 = null;
        String var6 = var3.getRequest().getParameter("showProcessStatus");
        if (var6 != null && var6 != "" && var6.equalsIgnoreCase("true")) {
            String var7 = var3.getRequest().getParameter("procOid");
            var5 = new NmOid(var7);
            var4.getMap().put("procOid", var5);
            var3.setNmCommandBean(var4);
        } else {
            var5 = (NmOid)var3.getRequest().getAttribute("argOid");
            var4.getMap().put("procOid", var5);
            var3.setNmCommandBean(var4);
        }

        if (log.isDebugEnabled()) {
            log.debug("ProcessStatusBuilder.buildComponentData, oid = " + var5);
        }

        if (var5 != null && var5.getReferencedClass().isAssignableFrom(WfProcess.class)) {
            QueryResult var10 = WorkflowCommands.getRouteStatus(var5);
            if (log.isDebugEnabled()) {
                log.debug("Objects found from getRouteStatus = " + var10.size());
            }

            return var10;
        } else if (var5 != null && var5.getReferencedClass().isAssignableFrom(LWWfProcess.class)) {
            LWWfProcess var9 = (LWWfProcess)var5.getRefObject();
            new WTArrayList();
            WTCollection var8;
            if (WfState.OPEN.includes(var9.getState())) {
                var8 = LifeCycleLWHelper.service.getLWWorkItems(ObjectReference.newObjectReference(var9));
            } else {
                var8 = LifeCycleLWHelper.service.getLWVotingEventAudits(ObjectReference.newObjectReference(var9));
            }

            if (log.isDebugEnabled()) {
                log.debug("Routing objects found for LWWfProcess state= " + var9.getState() + ", " + var8.size());
            }

            return var8;
        } else {
            return new WTArrayList();
        }
    }

    public ComponentConfig buildComponentConfig(ComponentParams var1) throws WTException {

        ComponentConfigFactory var2 = this.getComponentConfigFactory();
        JcaTableConfig var3 = (JcaTableConfig)var2.newTableConfig();
        ((AbstractJcaComponentConfig)var3).setDescriptorProperty("variableRowHeight", true);
        var3.setLabel(this.messageWorkFlowSource.getMessage("174"));
        var3.setHelpContext("processStatusHelp");
        var3.setShowCount(true);
        var3.setId("taskStatusTableId");
        ColumnConfig var4 = var2.newColumnConfig("ASSIGNMENT_STATUS", true);
        var4.setLabel(this.messageWorkFlowSource.getMessage("17"));
        var4.setHidden(true);
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("ASSIGNMENT_REASSIGNED", true);
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workSigRequired", true);
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workIcon", true);
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workName", true);
        var4.setLabel(this.messageWorkFlowSource.getMessage("63"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workAssignee", true);
        var4.setLabel(this.messageWorkFlowSource.getMessage("64"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workRole", true);
        var4.setLabel(this.messageWorkFlowSource.getMessage("67"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workVote", true);
        var4.setLabel(this.messageWorkFlowSource.getMessage("65"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workComments", true);
        var4.setLabel(this.messageLifeCycleSource.getMessage("99"));
        var3.addComponent(var4);
        //----------↓add-----------
        //添加附件
        ColumnConfig col = var2.newColumnConfig("CtShowFile", "附件", true);
        col.setDataUtilityId("CtShowFile");
        var3.addComponent(col);
        //----------↑add-----------
        var4 = var2.newColumnConfig("workCompletedBy", true);
        var4.setLabel(this.messageWorkFlowSource.getMessage("97"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workDeadline", true);
        var4.setLabel(this.messageWorkFlowSource.getMessage("68"));
        var3.addComponent(var4);
        var4 = var2.newColumnConfig("workCompletedDate", true);
        var4.setLabel(this.messageWorkFlowSource.getMessage("62"));
        var4.setDefaultSort(true);
        var3.addComponent(var4);
        if (log.isDebugEnabled()) {
            log.debug("Configured tableConfig : " + var3);
        }

        return var3;
    }
}
