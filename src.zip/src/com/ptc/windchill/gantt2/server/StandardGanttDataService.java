//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ptc.windchill.gantt2.server;

import com.ptc.core.command.common.CommandException;
import com.ptc.core.command.common.IllegalCommandArgumentException;
import com.ptc.core.command.common.bean.TypeInstanceToNonPersistableTranslatorCommand;
import com.ptc.core.command.server.delegate.ServerCommandDelegateUtility;
import com.ptc.core.components.util.TimeZoneHelper;
import com.ptc.core.meta.common.IdentifierFactory;
import com.ptc.core.meta.common.IllegalFormatException;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.projectmanagement.plan.DurationFormat;
import com.ptc.projectmanagement.plan.Plan;
import com.ptc.projectmanagement.plan.PlanActivity;
import com.ptc.projectmanagement.plan.TaskType;
import com.ptc.projectmanagement.plannable.ScheduleUtils;
import com.ptc.projectmanagement.plannable.WorkingCalendarConfig;
import com.ptc.windchill.gantt2.common.GanttActivity;
import com.ptc.windchill.gantt2.common.GanttActivityFactory;
import com.ptc.windchill.gantt2.common.GanttConstraint;
import com.ptc.windchill.gantt2.common.GanttConstraintFactory;
import com.ptc.windchill.gantt2.common.GanttDataModel;
import com.ptc.windchill.gantt2.common.GanttReservation;
import com.ptc.windchill.gantt2.common.GanttReservationFactory;
import com.ptc.windchill.gantt2.common.GanttResource;
import com.ptc.windchill.gantt2.common.GanttResourceFactory;
import com.ptc.windchill.gantt2.common.GanttTransferableItem;
import com.ptc.windchill.gantt2.common.GanttUtility;
import com.ptc.windchill.gantt2.common.WorkingHourHandler;
import ext.project.template.CtProjectTemplateHelper;
import ilog.views.gantt.IlvActivity;
import ilog.views.gantt.IlvConstraintType;
import ilog.views.gantt.IlvDuration;
import ilog.views.gantt.IlvGanttModel;
import ilog.views.gantt.IlvTimeInterval;
import ilog.views.gantt.IlvTimeUtil;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import wt.fc.Persistable;
import wt.inf.template.DefaultWTContainerTemplate;
import wt.method.MethodContext;
import wt.projmgmt.admin.Project2;
import wt.services.ManagerException;
import wt.services.StandardManager;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.session.SessionHelper;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.config.ConfigHelper;
import wt.vc.config.ConfigSpec;

public class StandardGanttDataService extends StandardManager implements GanttDataService, Serializable {
    private static final String CLASSNAME = StandardGanttDataService.class.getName();
    protected GanttActivityFactory activityFactory = new GanttActivityFactory();
    protected GanttResourceFactory resourceFactory = new GanttResourceFactory();
    protected GanttConstraintFactory constraintFactory = new GanttConstraintFactory();
    protected GanttReservationFactory reservationFactory = new GanttReservationFactory();
    protected GanttDataDelegateFactory ganttDataDelegateFactory = new GanttDataDelegateFactory();
    protected Locale locale = WTContext.getContext().getLocale();
    protected static TypeIdentifier ITERATED_TYPE_ID = null;
    protected static IdentifierFactory identifierFactory = (IdentifierFactory)DefaultServiceProvider.getService(IdentifierFactory.class, "logical");

    public StandardGanttDataService() {
    }

    /** @deprecated */
    public String getConceptualClassname() {
        return CLASSNAME;
    }

    protected void performStartupProcess() throws ManagerException {
        super.performStartupProcess();
    }

    public static StandardGanttDataService newStandardGanttDataService() throws WTException {
        StandardGanttDataService var0 = new StandardGanttDataService();
        var0.initialize();
        return var0;
    }

    public IlvGanttModel getILogGanttModel(ArrayList var1) throws WTException {
        return this.getILogGanttModel(var1, (WorkingHourHandler)null, SessionHelper.getLocale());
    }

    protected ConfigSpec translateConfigSpec(TypeInstance var1) {
        ConfigSpec var2 = null;
        TypeInstanceToNonPersistableTranslatorCommand var3 = new TypeInstanceToNonPersistableTranslatorCommand();

        try {
            var3.setApplyChangesOnly(false);
        } catch (WTPropertyVetoException var7) {
            var7.printStackTrace();
        }

        try {
            var3.setSource(var1);
            var3.execute();
        } catch (IllegalCommandArgumentException var5) {
            var5.printStackTrace();
        } catch (CommandException var6) {
            var6.printStackTrace();
        }

        var2 = (ConfigSpec)var3.getTarget();
        return var2;
    }

    protected GanttDataModel initGanttModel(AbstractActivityInstance var1, ConfigSpec var2, Date var3, WorkingHourHandler var4, boolean var5) throws WTException {
        try {
            Object var6 = var1.getActivityMaster().getRefObject();
            GanttDataModel var7 = new GanttDataModel();
            Object var8 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getRootActivity();
            GanttActivity var9 = null;
            if (var8 == null) {
                if (!var5) {
                    var9 = this.createActivity(var3);
                } else {
                    var9 = this.createActivityByFinishDate(var3);
                }
            } else {
                String var10 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var8).getUUID(var8);
                AbstractActivityInstance var11 = (new ActivityMaster(var10, var8)).getNewActivityInstance(var10, (AbstractActivityInstance)null);
                var9 = this.createActivity(var11, var2, var3, var5);
            }

            var9.setProperty("tags", "root");
            var9.setProperty("start_date", this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getStartDate(var1, var2));
            var7.setRootActivity(var9);
            if (var4 != null) {
                var9.setProperty("WORKING_HOUR_HANDLER", var4);
            }

            var9.setProperty("is_filtered_model", Boolean.TRUE);
            var9.setID("0");
            var7.setActivityId(var9.getID(), var9);
            var7.cacheActivity(var9.getID(), var9);
            ResourceCategoryObject var14 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getResourceRootWithCategories(var1);
            if (var14 == null) {
                GanttResource var15 = this.createResource("ResourceRoot");
                var7.setRootResource(var15);
                var7.cacheResource(var15.getID(), var15);
            } else {
                this.buildResourceCategoryTree(var7, (GanttResource)null, var14);
            }

            return var7;
        } catch (WTException var12) {
            throw var12;
        } catch (Exception var13) {
            var13.printStackTrace();
            return null;
        }
    }

    protected void buildActivityNodeRecursively(AbstractActivityInstance var1, GanttDataModel var2, ConfigSpec var3, HashMap var4, Date var5, boolean var6) throws WTException {
        Object var7 = var1.getActivityMaster().getRefObject();
        if (var7 != null) {
            ArrayList var8 = null;

            try {
                var8 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var7).getChildrenActivities(var1, var3, var4);
            } catch (WTException var14) {
                throw var14;
            }

            GanttActivity var9 = null;
            if (!this.ganttDataDelegateFactory.getGanttActivityDelegate(var7).beSkipped(var7)) {
                var1.setProperty("ganttModel", var2);
                var9 = this.createActivity(var1, var3, var5, var6);
                Object var10 = null;
                if (var1.getParentActivity() != null) {
                    var10 = this.activityFactory.getActivity(var1.getParentActivity().getUUID());
                }

                if (var10 == null) {
                    var10 = var2.getRootActivity();
                }

                if (var9 != null) {
                    var2.addActivity(var9, (IlvActivity)var10);
                    int var11 = var2.getChildActivityIndex((IlvActivity)var10, var9);
                    var9.setID(((IlvActivity)var10).getID() + "_" + var11);
                    var2.setActivityId(var9.getID(), var9);
                    GanttActivity var12 = (GanttActivity)var9;
                    Object var13 = var12.getProperty("CHILD_ITERATION_UUID");
                    var2.cacheActivity((String)var13, var9);
                }
            }

            if (var8 != null) {
                for(int var15 = 0; var15 < var8.size(); ++var15) {
                    this.buildActivityNodeRecursively((AbstractActivityInstance)var8.get(var15), var2, var3, var4, var5, var6);
                }

            }
        }
    }

    protected void buildConstraintAndResources(GanttDataModel var1, HashMap var2, ConfigSpec var3) throws WTException {
        Iterator var4 = var2.values().iterator();

        while(true) {
            Iterator var6;
            Object var7;
            do {
                if (!var4.hasNext()) {
                    return;
                }

                AbstractActivityMaster var5 = (AbstractActivityMaster)var4.next();
                var6 = var5.getActivitiesInstance().iterator();
                var7 = var5.getRefObject();
            } while(var7 == null);

            AbstractActivityInstance var8;
            for(; var6.hasNext(); this.buildResourceReservations(var8, var1, var3)) {
                var8 = (AbstractActivityInstance)var6.next();
                ArrayList var9 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var7).getConstraints(var8, var3, var2);
                if (var9 != null && var9.size() > 0) {
                    for(int var10 = 0; var10 < var9.size(); ++var10) {
                        Constraint var11 = (Constraint)var9.get(var10);
                        GanttActivity var12 = this.activityFactory.getActivity(var11.getFromUUID());
                        if (var12 != null && var12.getID() != null && var12.getName() != null) {
                            GanttActivity var13 = this.activityFactory.getActivity(var11.getToUUID());
                            if (var13 != null && var13.getID() != null && var13.getName() != null) {
                                IlvConstraintType var14 = GanttConstraint.getILogConstraintType(var11.getConstraintType());
                                GanttConstraint var15 = this.createConstraint(var12, var13, var14, var11.getUserProperties());
                                var1.addConstraint(var15);
                            }
                        }
                    }
                }
            }
        }
    }

    protected void buildResourceReservations(AbstractActivityInstance var1, GanttDataModel var2, ConfigSpec var3) {
        Object var4 = var1.getActivityMaster().getRefObject();
        ArrayList var5 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var4).getReservedResources(var1, var3);
        if (var5 != null && var5.size() != 0) {
            Iterator var6 = var5.iterator();

            while(var6.hasNext()) {
                ReservationObject var7 = (ReservationObject)var6.next();
                Object var8 = var7.getReservedResource();
                if (var8 != null) {
                    String var9 = this.ganttDataDelegateFactory.getGanttResourceDelegate(var8).getUUID(var8);
                    GanttResource var10 = this.resourceFactory.getResource(var9);
                    if (var10 == null) {
                        String var11 = this.ganttDataDelegateFactory.getGanttResourceDelegate(var8).getCategoryType(var8);
                        if (var11 != null) {
                            GanttResource var12 = this.resourceFactory.getResource(var11.trim());
                            if (var12 != null) {
                                var10 = this.createResource(var9, var8, var3);
                                var2.addResource(var10, var12);
                                var2.cacheResource(var9, var10);
                            }
                        }
                    }

                    if (var10 != null) {
                        GanttReservation var13 = this.createReservation(var10, this.activityFactory.getActivity(var1.getUUID()), var7.getUserProperties());
                        var2.addReservation(var13);
                    }
                }
            }

        }
    }

    protected void buildResourceCategoryTree(GanttDataModel var1, GanttResource var2, ResourceCategoryObject var3) {
        if (var3 != null) {
            GanttResource var4 = this.createResource(var3.getUuid());
            if (var3.getId() != null && !"".equals(var3.getId())) {
                var4.setID(var3.getId());
            }

            if (var3.getName() != null && !"".equals(var3.getName())) {
                var4.setName(var3.getName());
            }

            if (var3.getQuantity() != null && !"".equals(var3.getQuantity())) {
                var4.setQuantity(Float.parseFloat(var3.getQuantity()));
            }

            var4.setProperty("UUID", var3.getUuid());
            HashMap var5 = var3.getUserProperties();
            Iterator var6;
            if (var5 != null && var5.size() > 0) {
                var6 = var5.keySet().iterator();

                while(var6.hasNext()) {
                    String var7 = (String)var6.next();
                    var4.setProperty(var7, var5.get(var7));
                }
            }

            if (var2 == null) {
                var1.setRootResource(var4);
            } else {
                var1.addResource(var4, var2);
                var1.cacheResource(var3.getUuid(), var4);
            }

            if (var3.getChildrenList() != null) {
                var6 = var3.getChildrenList().iterator();

                while(var6.hasNext()) {
                    ResourceCategoryObject var8 = (ResourceCategoryObject)var6.next();
                    this.buildResourceCategoryTree(var1, var4, var8);
                }
            }

        }
    }

    protected GanttActivity createActivity(Date var1) {
        Date var2 = null;
        if (var1 != null) {
            var2 = var1;
        } else {
            var2 = new Date();
        }

        GanttActivity var3 = (GanttActivity)((GanttActivity)this.activityFactory.createActivity(new IlvTimeInterval(var2, IlvTimeUtil.add(var2, IlvDuration.ONE_DAY))));
        return var3;
    }

    protected GanttActivity createActivity(String var1, Date var2) {
        Date var3 = null;
        if (var2 != null) {
            var3 = var2;
        } else {
            var3 = new Date();
        }

        GanttActivity var4 = (GanttActivity)((GanttActivity)this.activityFactory.createActivity(var1, new IlvTimeInterval(var3, IlvTimeUtil.add(var3, IlvDuration.ONE_DAY))));
        return var4;
    }

    protected GanttActivity createActivity(AbstractActivityInstance var1, ConfigSpec var2, Date var3, boolean var4) throws WTException {
        try {
            GanttActivity var5 = null;
//            if (var4) {
//                var5 = this.createActivityByFinishDate(var1.getUUID(), var3);
//            } else {
//                var5 = this.createActivity(var1.getUUID(), var3);
//            }
//
//            Object var6 = var1.getActivityMaster().getRefObject();
//            TaskType var7 = null;
//            if (var6 instanceof PlanActivity) {
//                var7 = ((PlanActivity)var6).getTaskType();
//            }
//
//            var5.setTaskType(var7);

            /***  OOTB CUSTOM CODE START ***/

            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            df.setTimeZone(TimeZoneHelper.getLocalTimeZone());

            Object var6 = var1.getActivityMaster().getRefObject();
            Plan plan = null;
            if (var6 instanceof PlanActivity) {
                PlanActivity activity = (PlanActivity) var6;
                plan = (Plan) activity.getRoot();
                if (activity.getStartDate() == null) {
                    Project2 project = (Project2) plan.getContainer();
                    DefaultWTContainerTemplate containerTemplate = (DefaultWTContainerTemplate) project.getContainerTemplate();
                    Date planDefaultStart = CtProjectTemplateHelper.getInstance().getDefaultPlanStartDateByTemplate(containerTemplate);
                    Date planStartDate = plan.getStartDate();
                    long differenceDays = ScheduleUtils.calculateWorkingDuration(planDefaultStart, planStartDate, TimeZoneHelper.getTimeZone(), null);
                    long duration = (long) (activity.getDuration().getDuration(DurationFormat.DAYS) * 3600 * 8 * 1000);
                    Date startDate = ScheduleUtils.addWorkingDuration(activity.getFinishDate(), -duration);
                    var3 = ScheduleUtils.addWorkingDuration(startDate, differenceDays);
                    if (!activity.isMilestone()) {
                        var3 = ScheduleUtils.addWorkingDuration(var3, 28800000);
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeZone(TimeZoneHelper.getLocalTimeZone());
                        calendar.setTime(var3);
                        calendar.set(Calendar.HOUR_OF_DAY, WorkingCalendarConfig.DAY_START);
                        var3 = calendar.getTime();
                    }
                } else if (plan.getDefaultStart().compareTo(plan.getStartDate()) != 0) {
                    Date planDefaultStart = plan.getDefaultStart();
                    Date planStartDate = plan.getStartDate();
                    long duration;
                    if (planStartDate.after(planDefaultStart)) {
                        duration = -ScheduleUtils.calculateWorkingDuration(planDefaultStart, planStartDate, TimeZoneHelper.getTimeZone(), null);
                    } else {
                        duration = ScheduleUtils.calculateWorkingDuration(planStartDate, planDefaultStart, TimeZoneHelper.getTimeZone(), null);
                    }
                    var3 = ScheduleUtils.addWorkingDuration(activity.getStartDate(), duration);
                    if (!activity.isMilestone()) {
                        var3 = ScheduleUtils.addWorkingDuration(var3, 28800000);
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeZone(TimeZoneHelper.getLocalTimeZone());
                        calendar.setTime(var3);
                        calendar.set(Calendar.HOUR_OF_DAY, WorkingCalendarConfig.DAY_START);
                        var3 = calendar.getTime();
                    }
                } else {
                    var3 = activity.getStartDate();
                }
            } else if (var6 instanceof Plan) {
                plan = (Plan) var6;
                if (plan.getDefaultStart().compareTo(plan.getStartDate()) != 0) {
                    var3 = plan.getDefaultStart();
                }
            }

            /***  OOTB CUSTOM CODE END ***/

            if (var4) {
                var5 = this.createActivityByFinishDate(var1.getUUID(), var3);
            } else {
                var5 = this.createActivity(var1.getUUID(), var3);
            }

            var5.setProperty("UUID", var1.getUUID());
            var5.setProperty("MASTER_UUID", var1.getActivityMaster().getUUID());
            var5.setProperty("start_date", this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getStartDate(var1, var2));
            HashMap var8 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getUserProperties(var1, var2, this.locale);
            if (var8 == null) {
                return null;
            } else {
                var8.put("WORKING_HOUR_HANDLER", var1.getProperty("WORKING_HOUR_HANDLER"));
                String var9 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getId(var1);
                if (var9 != null && !var9.trim().equals("")) {
                    var5.setID(var9);
                }

                var9 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getName(var1);
                if (var9 != null && !var9.trim().equals("")) {
                    var5.setName(var9);
                } else {
                    var5.setName("_");
                }

                Object var10 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getWorkCalendar(var1, var2);
                var5.setWorkCalendar(var10);
                long var11 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var6).getDuration(var1, var2);
                if (var11 > 0L) {
                    var5.setDuration(new IlvDuration(var11));
                    var5.setWorkingDuration(new IlvDuration(var11));
                } else {
                    var5.setDuration(new IlvDuration(0L));
                    var5.setWorkingDuration(new IlvDuration(0L));
                }

                if (var8 != null && var8.size() > 0) {
                    Iterator var13 = var8.keySet().iterator();

                    while(var13.hasNext()) {
                        String var14 = (String)var13.next();
                        var5.setProperty(var14, var8.get(var14));
                    }
                }

                return var5;
            }
        } catch (WTException var15) {
            throw var15;
        } catch (Exception var16) {
            var16.printStackTrace();
            return null;
        }
    }

    protected GanttActivity createActivityByFinishDate(Date var1) {
        return this.createActivityByFinishDate((String)null, var1);
    }

    protected GanttActivity createActivityByFinishDate(String var1, Date var2) {
        Date var3 = null;
        Date var4 = null;
        if (var2 != null) {
            var3 = var2;
            var4 = var2;
        } else {
            var4 = var3 = new Date();
        }

        GanttActivity var5 = null;
        if (var1 != null) {
            var5 = (GanttActivity)((GanttActivity)this.activityFactory.createActivity(var1, new IlvTimeInterval(var4, var3)));
        } else {
            var5 = (GanttActivity)((GanttActivity)this.activityFactory.createActivity(new IlvTimeInterval(var4, var3)));
        }

        var5.setProperty("scheduleBackward", true);
        return var5;
    }

    protected GanttResource createResource(String var1) {
        GanttResource var2 = (GanttResource)this.resourceFactory.createResource(var1);
        return var2;
    }

    protected GanttResource createResource(String var1, Object var2, ConfigSpec var3) {
        GanttResource var4 = this.createResource(var1);
        var4.setID(this.ganttDataDelegateFactory.getGanttResourceDelegate(var2).getId(var2));
        var4.setName(this.ganttDataDelegateFactory.getGanttResourceDelegate(var2).getName(var2));
        var4.setQuantity(this.ganttDataDelegateFactory.getGanttResourceDelegate(var2).getQuantity(var2));
        var4.setProperty("UUID", var1);
        HashMap var5 = this.ganttDataDelegateFactory.getGanttResourceDelegate(var2).getUserProperties(var2, var3);
        if (var5 != null && var5.size() > 0) {
            Iterator var6 = var5.keySet().iterator();

            while(var6.hasNext()) {
                String var7 = (String)var6.next();
                var4.setProperty(var7, var5.get(var7));
            }
        }

        return var4;
    }

    protected GanttReservation createReservation(GanttResource var1, IlvActivity var2, HashMap var3) {
        GanttReservation var4 = (GanttReservation)this.reservationFactory.createReservation(var1, var2);
        if (var3 != null && var3.size() > 0) {
            Iterator var5 = var3.keySet().iterator();

            while(var5.hasNext()) {
                String var6 = (String)var5.next();
                var4.setProperty(var6, var3.get(var6));
            }
        }

        return var4;
    }

    protected GanttConstraint createConstraint(IlvActivity var1, IlvActivity var2, IlvConstraintType var3, HashMap var4) {
        GanttConstraint var5 = (GanttConstraint)this.constraintFactory.createConstraint(var1, var2, var3);
        if (var4 != null && var4.size() > 0) {
            Iterator var6 = var4.keySet().iterator();

            while(var6.hasNext()) {
                String var7 = (String)var6.next();
                var5.setProperty(var7, var4.get(var7));
            }
        }

        return var5;
    }

    public IlvGanttModel getILogGanttModel(ArrayList var1, WorkingHourHandler var2, Locale var3) throws WTException {
        this.locale = var3;
        MethodContext.getContext().put("OPERATION", "OPERATION_ILOG");

        GanttDataModel var4;
        try {
            HashMap var5;
            try {
                if (var1 != null && var1.size() >= 1) {
                    var4 = null;
                    var5 = null;
                    this.resourceFactory = new GanttResourceFactory();

                    for(int var6 = 0; var6 < var1.size(); ++var6) {
                        GanttTransferableItem var7 = (GanttTransferableItem)var1.get(var6);
                        Date var8 = (Date)var7.getUserProperties().get("PROJECT_FINISH_DATE");
                        Date var9 = (Date)var7.getUserProperties().get("default_start_time");
                        TypeInstanceIdentifier var10 = var7.getItemTii();
                        TypeInstance var11 = var7.getConfigSpec();
                        ConfigSpec var12 = null;
                        if (var11 != null) {
                            var12 = this.translateConfigSpec(var11);
                        } else if (var10 != null && var10.isInstanceOf(ITERATED_TYPE_ID)) {
                            Class var13 = Class.forName(((WCTypeIdentifier)var10.getDefinitionIdentifier()).getClassnameFromTypename());
                            var12 = ConfigHelper.service.getDefaultConfigSpecFor(var13);
                        }

                        this.activityFactory = new GanttActivityFactory();
                        var5 = null;
                        Persistable var30 = null;
                        HashMap var14 = var7.getPreferences();
                        String var15;
                        if (var14 != null && var14.size() >= 1) {
                            var15 = (String)var14.get("object_ti_str");
                            if (var15 != null) {
                                TypeInstance var16 = GanttUtility.getDecodedConfigSpec(var15);
                                if (var16 != null) {
                                    var30 = ServerCommandDelegateUtility.refresh(var16);
                                }
                            }

                            if (var30 == null) {
                                var30 = GanttUtility.getPersistableWithConfigSpec(var10, var12);
                            }
                        } else {
                            var30 = GanttUtility.getPersistableWithConfigSpec(var10, var12);
                        }

                        var15 = this.ganttDataDelegateFactory.getGanttActivityDelegate(var30).getUUID(var30);
                        ParalleleActivityMaster var31 = new ParalleleActivityMaster(var15, var30);
                        var31.setPreferences(var7.getPreferences());
                        AbstractActivityInstance var17 = var31.getNewActivityInstance(var15, (AbstractActivityInstance)null);
                        var7.getUserProperties().put("WORKING_HOUR_HANDLER", var2);
                        var17.setUserProperties(var7.getUserProperties());
                        Date var18 = var9;
                        if (var4 == null) {
                            this.ganttDataDelegateFactory.getGanttActivityDelegate(var30).resetMaps(var30);
                            boolean var19 = var8 != null;
                            if (var19) {
                                var18 = var8;
                            }

                            var4 = this.initGanttModel(var17, var12, var18, var2, var19);
                        }

                        var5 = new HashMap();
                        this.buildActivityNodeRecursively(var17, var4, var12, var5, var18, var8 != null);
                        this.buildConstraintAndResources(var4, var5, var12);
                        var5 = null;
                    }

                    if (var4 != null) {
                        GanttActivity var27 = (GanttActivity)var4.getActivityById("0_0");
                        Plan var29 = GanttUtility.getPlan(var4);
                        if (var29 != null && var27 != null) {
                            var27.setProperty("isAutoExecution", var29.isAutoExecution());
                        }
                    }

                    GanttDataModel var28 = var4;
                    return var28;
                }

                var4 = null;
            } catch (WTException var24) {
                throw var24;
            } catch (Exception var25) {
                var25.printStackTrace();
                var5 = null;
                return (IlvGanttModel) var5;
            }
        } finally {
            MethodContext.getContext().remove("OPERATION");
        }

        return var4;
    }

    static {
        try {
            ITERATED_TYPE_ID = (TypeIdentifier)identifierFactory.get("WCTYPE|wt.vc.Iterated");
        } catch (IllegalFormatException var1) {
            var1.printStackTrace();
        }

    }
}
