package com.landray.kmss.fanh.plm.KmReviewWebservice;

public class IPLMKmReviewWebserviceProxy implements IPLMKmReviewWebservice {
  private String _endpoint = null;
  private IPLMKmReviewWebservice iPLMKmReviewWebservice = null;
  
  public IPLMKmReviewWebserviceProxy() {
    _initIPLMKmReviewWebserviceProxy();
  }
  
  public IPLMKmReviewWebserviceProxy(String endpoint) {
    _endpoint = endpoint;
    _initIPLMKmReviewWebserviceProxy();
  }
  
  private void _initIPLMKmReviewWebserviceProxy() {
    try {
      iPLMKmReviewWebservice = (new com.landray.kmss.fanh.plm.KmReviewWebservice.IPLMKmReviewWebserviceServiceLocator()).getIPLMKmReviewWebservicePort();
      if (iPLMKmReviewWebservice != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iPLMKmReviewWebservice)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iPLMKmReviewWebservice)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iPLMKmReviewWebservice != null)
      ((javax.xml.rpc.Stub)iPLMKmReviewWebservice)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public IPLMKmReviewWebservice getIPLMKmReviewWebservice() {
    if (iPLMKmReviewWebservice == null)
      _initIPLMKmReviewWebserviceProxy();
    return iPLMKmReviewWebservice;
  }
  
  public String addReview(com.landray.kmss.fanh.crm.webservice.KmReviewParamterForm arg0) throws java.rmi.RemoteException, Exception{
    if (iPLMKmReviewWebservice == null)
      _initIPLMKmReviewWebserviceProxy();
    return iPLMKmReviewWebservice.addReview(arg0);
  }
  
  
}