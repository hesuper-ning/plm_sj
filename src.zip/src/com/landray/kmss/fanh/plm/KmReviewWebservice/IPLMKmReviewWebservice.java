/**
 * IPLMKmReviewWebservice.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.landray.kmss.fanh.plm.KmReviewWebservice;

public interface IPLMKmReviewWebservice extends java.rmi.Remote {
    public String addReview(com.landray.kmss.fanh.crm.webservice.KmReviewParamterForm arg0) throws java.rmi.RemoteException, Exception;
}
