/**
 * IPLMKmReviewWebserviceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.landray.kmss.fanh.plm.KmReviewWebservice;

public class IPLMKmReviewWebserviceServiceLocator extends org.apache.axis.client.Service implements IPLMKmReviewWebserviceService {

    public IPLMKmReviewWebserviceServiceLocator() {
    }


    public IPLMKmReviewWebserviceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public IPLMKmReviewWebserviceServiceLocator(String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for IPLMKmReviewWebservicePort
    private String IPLMKmReviewWebservicePort_address = "http://hometest.fhsjdz.com/sys/webservice/PLMKmReviewWebservice";

    public String getIPLMKmReviewWebservicePortAddress() {
        return IPLMKmReviewWebservicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private String IPLMKmReviewWebservicePortWSDDServiceName = "IPLMKmReviewWebservicePort";

    public String getIPLMKmReviewWebservicePortWSDDServiceName() {
        return IPLMKmReviewWebservicePortWSDDServiceName;
    }

    public void setIPLMKmReviewWebservicePortWSDDServiceName(String name) {
        IPLMKmReviewWebservicePortWSDDServiceName = name;
    }

    public IPLMKmReviewWebservice getIPLMKmReviewWebservicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(IPLMKmReviewWebservicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getIPLMKmReviewWebservicePort(endpoint);
    }

    public IPLMKmReviewWebservice getIPLMKmReviewWebservicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.landray.kmss.fanh.plm.KmReviewWebservice.IPLMKmReviewWebserviceServiceSoapBindingStub _stub = new com.landray.kmss.fanh.plm.KmReviewWebservice.IPLMKmReviewWebserviceServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getIPLMKmReviewWebservicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setIPLMKmReviewWebservicePortEndpointAddress(String address) {
        IPLMKmReviewWebservicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (IPLMKmReviewWebservice.class.isAssignableFrom(serviceEndpointInterface)) {
                com.landray.kmss.fanh.plm.KmReviewWebservice.IPLMKmReviewWebserviceServiceSoapBindingStub _stub = new com.landray.kmss.fanh.plm.KmReviewWebservice.IPLMKmReviewWebserviceServiceSoapBindingStub(new java.net.URL(IPLMKmReviewWebservicePort_address), this);
                _stub.setPortName(getIPLMKmReviewWebservicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("IPLMKmReviewWebservicePort".equals(inputPortName)) {
            return getIPLMKmReviewWebservicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://KmReviewWebservice.plm.fanh.kmss.landray.com/", "IPLMKmReviewWebserviceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://KmReviewWebservice.plm.fanh.kmss.landray.com/", "IPLMKmReviewWebservicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(String portName, String address) throws javax.xml.rpc.ServiceException {
        
if ("IPLMKmReviewWebservicePort".equals(portName)) {
            setIPLMKmReviewWebservicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
