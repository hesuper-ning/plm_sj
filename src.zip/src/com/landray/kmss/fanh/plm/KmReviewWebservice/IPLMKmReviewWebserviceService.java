/**
 * IPLMKmReviewWebserviceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.landray.kmss.fanh.plm.KmReviewWebservice;

public interface IPLMKmReviewWebserviceService extends javax.xml.rpc.Service {
    public String getIPLMKmReviewWebservicePortAddress();

    public IPLMKmReviewWebservice getIPLMKmReviewWebservicePort() throws javax.xml.rpc.ServiceException;

    public IPLMKmReviewWebservice getIPLMKmReviewWebservicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
