/**
 * IKmReviewWebserviceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.landray.kmss.km.review.webservice;

public interface IKmReviewWebserviceService extends java.rmi.Remote {
    public String addReview(KmReviewParamterForm arg0) throws java.rmi.RemoteException, Exception;
}
