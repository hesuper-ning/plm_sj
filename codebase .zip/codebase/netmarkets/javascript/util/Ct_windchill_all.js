function productNamePickerCallback(objects, pickerID, attr, displayFieldId) {
    var updateHiddenField = document.getElementsByName(pickerID)[0];
    var updateDisplayField = document.getElementsByName(displayFieldId)[0];
    if (updateDisplayField) PTC.util._setMainFormStartingElement(updateDisplayField);
    var myJSONObjects = objects.pickedObject;
    var oid = "";
    var displayAttr = "";
    for (var i = 0; i < myJSONObjects.length; i++) {
        oid += myJSONObjects[i].oid + ",";
        displayAttr += myJSONObjects[i].name + ",";
    }
    if(displayAttr.length > 0){
        displayAttr = displayAttr.substring(0,displayAttr.length - 1);
    }
    updateHiddenField.value = displayAttr;
    updateDisplayField.value = displayAttr;
}
function ctProjectPickerCallback(objects, pickerID, attr, displayFieldId) {
    var updateHiddenField = document.getElementsByName(pickerID)[0];
    var updateDisplayField = document.getElementsByName(displayFieldId)[0];
    if (updateDisplayField) PTC.util._setMainFormStartingElement(updateDisplayField);
    var myJSONObjects = objects.pickedObject;
    var oid = "";
    var displayAttr = "";
    for (var i = 0; i < myJSONObjects.length; i++) {
        oid += myJSONObjects[i].oid + ",";
        displayAttr += myJSONObjects[i].projectNumber + ",";
    }
    if(displayAttr.length > 0){
        displayAttr = displayAttr.substring(0,displayAttr.length - 1);
    }
    updateHiddenField.value = displayAttr;
    updateDisplayField.value = displayAttr
};


function ctPartNumberPickerCallback(objects, pickerID, attr, displayFieldId) {
    var updateHiddenField = document.getElementsByName(pickerID)[0];
    var updateDisplayField = document.getElementsByName(displayFieldId)[0];
    if (updateDisplayField) PTC.util._setMainFormStartingElement(updateDisplayField);
    var myJSONObjects = objects.pickedObject;
    var oid = "";
    var displayAttr = "";
    for (var i = 0; i < myJSONObjects.length; i++) {
        oid += myJSONObjects[i].oid + ",";
        displayAttr += myJSONObjects[i].number + ",";
    }
    if(displayAttr.length > 0){
        displayAttr = displayAttr.substring(0,displayAttr.length - 1);
    }
    updateHiddenField.value = displayAttr;
    updateDisplayField.value = displayAttr
};

function CustomPickerInputComponentCallback(objects,pickerID,attr,displayFieldId)
{
    // var total_fullNames = "";
    // var updateHiddenField=document.getElementsByName(pickerID)[0];
    // var updateDisplayField=document.getElementsByName(displayFieldId)[0];
    // if(updateDisplayField)PTC.util._setMainFormStartingElement(updateDisplayField);
    // var myJSONObjects=objects.pickedObject;
    // for(var i=0;i<myJSONObjects.length;i++)
    // {
    //     var oid=myJSONObjects[i].oid;var
    //     displayAttr=myJSONObjects[i][attr];
    //     if (total_fullNames == "")
    //     {
    //         total_fullNames = displayAttr;
    //     }
    //     else
    //     {
    //         total_fullNames = total_fullNames + ", " + displayAttr;
    //     }
    // }
    // updateHiddenField.value=total_fullNames;
    // updateDisplayField.value=total_fullNames
    var updateHiddenField = document.getElementsByName(pickerID)[0];
    var updateDisplayField = document.getElementsByName(displayFieldId)[0];
    if (updateDisplayField) PTC.util._setMainFormStartingElement(updateDisplayField);
    var myJSONObjects = objects.pickedObject;
    var oid = "";
    var displayAttr = "";
    var hiddenAttr = "";

    for (var i = 0; i < myJSONObjects.length; i++) {
        let tranOid=myJSONObjects[i].oid;
        oid += tranOid + ",";
        console.log("=====indexOf"+tranOid.indexOf(","))

        displayAttr += myJSONObjects[i].fullName + ",";
        hiddenAttr +=tranOid.substring(4,tranOid.indexOf(",")) + ",";
        console.log("=====displayAttr"+ displayAttr);
        console.log("=====hiddenAttr"+ hiddenAttr);
    }
    if(displayAttr.length > 0){
        displayAttr = displayAttr.substring(0,displayAttr.length - 1);
    }
    if(hiddenAttr.length > 0){
        hiddenAttr = hiddenAttr.substring(0,hiddenAttr.length - 1);
    }
    updateHiddenField.value = hiddenAttr;
    updateDisplayField.value = displayAttr;
};