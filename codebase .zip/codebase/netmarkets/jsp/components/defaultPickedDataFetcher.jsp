 <%@ taglib uri="http://www.ptc.com/infoengine/taglib/core" prefix="ie"%>

  
  <%@ page import="com.infoengine.SAK.Task, 
                  com.infoengine.object.factory.Group,
                  com.infoengine.object.factory.Element,
                  com.infoengine.object.factory.Att,
                  wt.util.WTProperties,
                  java.util.Enumeration" %>
                  
  <ie:getService varName="vdb"/>

  <%
    String[] attributes = request.getParameterValues("attributes");//{"name", "number"};  
    String[] oids = request.getParameterValues("selectedOids");   
    WTProperties properties = WTProperties.getLocalProperties();
    String wtadapterVMName = properties.getProperty("wt.federation.ie.VMName","Windchill");
  %>
  
  <%
      StringBuffer sb = new StringBuffer();
      for(String s: attributes)
      	  sb.append(s).append(",");
      
      sb.deleteCharAt(sb.length() - 1);
      String attribs = sb.toString();
      
      sb = new StringBuffer();
      
      for(String s: oids)
            	  sb.append(s).append("#");
            
      sb.deleteCharAt(sb.length() - 1);
      String oid = sb.toString();
      
      
   %>

  <ie:webject name="Query-Objects" type="OBJ">
        <ie:param name="instance"              data="<%= wtadapterVMName %>" 
                                               valueSeparator=";" 
                                               delim=";" 
                                               default="Windchill" />
        <ie:param name="attribute"             data="<%= attribs%>"
                                               delim="," />
        <ie:param name="object_ref"         data="<%= oid %>" delim="#"/>        
        <ie:param name="group_out"             data="output" />        
  </ie:webject>
  
  
  
  <%
  Group g = vdb.getGroup("output");
     g.printTree();
     
     Element[] elms = g.getElementArray();
     sb = new StringBuffer();
     sb.append("{\"pickedObject\": [");
     int i = 1;
     for(Element elm : elms)
     {
        sb.append("{");        
        for (Enumeration enumm = elm.getAtts(); enumm.hasMoreElements() ;) {
          Att att = (Att)enumm.nextElement();
          String name = att.getName();
          String value = (String)att.getRawValue();
          if(name.equals("obid"))
          {
             name = "oid";
             if(value.indexOf("@") > 0)
             {
               int index = value.lastIndexOf(":");
               if(index > 0)
                value = value.substring(0, index);
             }
           }
          
          sb.append("\"").append(name).append("\":").append("\"").append(value).append("\"");
          if(enumm.hasMoreElements())
            sb.append(",");
        }        
        sb.append("}");
        i++;
        if(i <= elms.length)
           sb.append(",");
     }
     sb.append("]}");
     //System.out.println(sb);
     out.print(sb); out.flush();
    
     
   %>
     
 
 
   
   
