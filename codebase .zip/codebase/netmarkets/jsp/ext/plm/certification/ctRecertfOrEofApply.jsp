<%@page import="ext.plm.certification.config.CtCertfProperties"%>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.maturity.PromotionNotice" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
<%
    String proOid="";
    String workItemOid = request.getParameter("oid");
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
    Persistable object2 = workItem.getPrimaryBusinessObject().getObject();
    WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
    String actName = activity.getName();
    System.out.println("actName"+actName);
    if(object2 instanceof PromotionNotice){
        PromotionNotice promotionNotice = (PromotionNotice)object2;
        proOid = CtWTObjectUtil.getOid(promotionNotice);
    }else if(object2 instanceof WTDocument){
        proOid= CtWTObjectUtil.getVid(object2);
    }

    String currentActKey = CtCertfProperties.getActivityNodeName(actName);
    WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
    long branchId = doc.getBranchIdentifier();

    boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workItem,
            CtCertfProperties.getRequiredAtt("Recertf_allowEdit_roles"));

//打印页面信息，有用
    System.out.println(">>>>>>>>> ctRecertfOrEofApply.jsp actName="+actName+">>>>currentActKey="+currentActKey
            +">>>>>branchId="+branchId+">>>workItemOid="+workItemOid+">>allowEdit"+allowEdit);

    boolean taskCompleted = false; //任务是否已完成
    if(workItem.isComplete()) {
        taskCompleted = true;
    }
%>

<script type="text/javascript">

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="/Windchill/netmarkets/css/ptc/ptcProjectManagement.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
<%--    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/formexport/js/download-toolbar.js"></script>--%>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctRecertfOrEofApply.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctRecertfOrEofApplyFunctions.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>

    //认证请求vid
    var branchId = "<%=branchId%>";

    var proOid ='<%= proOid %>';

    var actName ='<%= actName %>';
    //当前审批结点key
    var currentActKey = "<%=currentActKey%>";
    //当前的任务完成状态
    var taskCompleted = "<%=taskCompleted%>";
    //oid
    var oid = "<%=workItemOid%>";
    var allowEdit = false;
    <%if(allowEdit){ %>
    allowEdit = true;
    <%}%>

Ext.onReady(function() {
	 Ext.QuickTips.init();

	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'recertfOrEofApply'
		    }]
		});
});
</script>

</body>
</html>