<%@page import="ext.plm.certification.config.CtCertfProperties"%>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
<%
    String oid = request.getParameter("oid");

    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WTDocument doc = (WTDocument) rf.getReference(oid).getObject();
    long branchId = doc.getBranchIdentifier();
    long proOid = doc.getBranchIdentifier();

    /*wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
    WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
    String actName = activity.getName();
    System.out.println("actName"+actName);

    String currentActKey = CtCertfProperties.getActivityKey(actName);

    WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
    long branchId = doc.getBranchIdentifier();
//打印页面信息，有用
    System.out.println(">>>>>>>>> ec jsp actName="+actName+">>>>currentActKey="+currentActKey
            +">>>>>branchId="+branchId+">>>workItemOid="+workItemOid);

    boolean taskCompleted = false; //任务是否已完成
    if(workItem.isComplete()) {
        taskCompleted = true;
    }*/
%>

<script type="text/javascript">

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="/Windchill/netmarkets/css/ptc/ptcProjectManagement.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
<%--    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/formexport/js/download-toolbar.js"></script>--%>
    <script type="text/javascript" src="js/ctRecertfOrEofApply.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctRecertfOrEofApplyFunctions.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>

    //oid
    var oid = "<%=oid%>";

    var branchId = "<%=branchId%>";

    var proOid ='<%= proOid %>';

    var actName ='<%= "" %>';
    //当前审批结点key
    var currentActKey = "";
    //当前的任务完成状态
    var taskCompleted = "";
    var allowEdit = false;
Ext.onReady(function() {
	 Ext.QuickTips.init();

	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'recertfOrEofApply'
		    }]
		});
});
</script>

</body>
</html>