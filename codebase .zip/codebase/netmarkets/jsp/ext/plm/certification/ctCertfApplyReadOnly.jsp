<%@page import="ext.plm.util.CtWTObjectUtil"%>
<%@ page import="wt.doc.WTDocument" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
<%
    String oid = request.getParameter("oid");
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WTDocument document = (WTDocument) CtWTObjectUtil.getObjectByOid(oid);
    String certfId = document.getBranchIdentifier()+"";
    boolean taskCompleted = true; //任务是否已完成
%>

<script type="text/javascript">

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="/Windchill/netmarkets/css/ptc/ptcProjectManagement.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctCertfApplyPanel.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctCertfApplyFunctions.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
    //认证请求vid
    var certfId = "<%=certfId%>";
    var currentActKey = "";
    //当前的任务完成状态
    var taskCompleted = "<%=taskCompleted%>";

Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'CertfApplyPanel'
		    }]
		});
});
</script>

</body>
</html>