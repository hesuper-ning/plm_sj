<%@page import="ext.plm.certification.config.CtCertfProperties"%>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.maturity.PromotionNotice" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="ext.plm.util.IBAUtil" %>
<%@ page import="ext.plm.util.CtDocUtil" %>
<%@ page import="java.util.Hashtable" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
<%
    String oid = request.getParameter("oid");
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(oid);

    IBAUtil ibaUtil = new IBAUtil(doc);
    String value = ibaUtil.getIBAValue("ct_RenewalDelistingApplicationFormNumber");
    WTDocument document = CtDocUtil.getDocumentByNumber(value);
    long branchId = document.getBranchIdentifier();

    boolean taskCompleted = true;
%>

<script type="text/javascript">

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="/Windchill/netmarkets/css/ptc/ptcProjectManagement.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
<%--    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/formexport/js/download-toolbar.js"></script>--%>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctRecertfOrEofApply.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctRecertfOrEofApplyFunctions.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>

    //认证请求vid
    var branchId = "<%=branchId%>";


    //当前的任务完成状态
    var taskCompleted = "<%=taskCompleted%>";
    //oid
    var oid = "<%=oid%>";
    var allowEdit = false;

Ext.onReady(function() {
	 Ext.QuickTips.init();

	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'recertfOrEofApply'
		    }]
		});
});
</script>

</body>
</html>