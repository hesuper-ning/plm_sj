/**
 * 认证
 */
Ext.define('PLM.view.CertfApplyPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CertfApplyPanel',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">认证管理</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {

/////////////////////////Panel items//////////////////////////////////
        var me = this;
        //========可编辑列头显示控制============
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';

        var head_demandSourceText = '需求来源';
        var head_projectNumberText = '项目编号';
        var head_remarkText = '需求说明';

        var projectPrincipalAuditText = '审核意见';
        var procurementAuditText = '审核意见';
        var isPhysicalText = '是否已核对实物';
        var engineerAuditAuditText = '审核意见';
        var isRecertificationText = '是否属于续证且属于CCC或自愿性认证';
        var PMAuditText = '审核意见';
        var submitEngineerText = '提交工程师';

        var filePrintText = '送检申请文件打印';
        var dataDisposeText = '上传盖章文件，其他问题线下沟通处理';

        var inspectDataFilingText = '送检资料已存档';
        var inspectDataAffirmText = '送检资料留存确认';
        var technologyFilePrintingText = '送检资料盖章并打印';

        var certfConfirmText = '确认送检过程中资料是否需要修改（如果需要修改，请选择驳回路由）';

        var certfCreateFilingText = '检验报告已存档';
        var certfNumberText = '检验报告/证书系统文档编号';
        var certfCreateReportText = '说明';

        var exploitCreateReportText = '说明';

        var initiatorConfirmText = '确认此次上传的资料为机构备案资料';

        var exploitConfirmText = '确认说明';

        var dataConfirmText = '确认说明';

        var dataRequireText = '认证工程师填写所需资料';

        var ProcessDataText = '备注';
        var productionRecordText = '备注';

        var certfArchiveRemarkText = '备注';

        var ECRNumberText = 'ECR编号';
        var isDataSaveText = '生产使用的技术资料是否有更新';
        var revisionDocNumberText = '修订文档编号';
        var productionDataRemarkText = '备注';

        var whetherPassText = '是否通过';
        var withoutExplanationText = '不通过说明';

        if (currentActKey == 'submit_node') {
            head_demandSourceText = redStarFlag + blueFlagStart + head_demandSourceText + blueFlagEnd;
            head_remarkText = redStarFlag + blueFlagStart + head_remarkText + blueFlagEnd;
        } else if (currentActKey == 'principal_node') {
            projectPrincipalAuditText = redStarFlag + blueFlagStart + projectPrincipalAuditText + blueFlagEnd;
        } else if (currentActKey == 'procurement_node') {
            procurementAuditText = redStarFlag + blueFlagStart + procurementAuditText + blueFlagEnd;
            isPhysicalText = redStarFlag + blueFlagStart + isPhysicalText + blueFlagEnd;
        } else if (currentActKey == 'engineer_node') {
            engineerAuditAuditText = redStarFlag + blueFlagStart + engineerAuditAuditText + blueFlagEnd;
            isRecertificationText = redStarFlag + blueFlagStart + isRecertificationText + blueFlagEnd;
        } else if (currentActKey == 'PM_node') {
            PMAuditText = redStarFlag + blueFlagStart + PMAuditText + blueFlagEnd;
        } else if (currentActKey == 'dateCollect_node') {
            filePrintText = redStarFlag + blueFlagStart + filePrintText + blueFlagEnd;
            dataDisposeText = redStarFlag + blueFlagStart + dataDisposeText + blueFlagEnd;
        } else if (currentActKey == 'inDateCollect_node') {
            filePrintText = redStarFlag + blueFlagStart + filePrintText + blueFlagEnd;
            dataDisposeText = redStarFlag + blueFlagStart + dataDisposeText + blueFlagEnd;
        } else if (currentActKey == 'mDateCollect_node') {
            inspectDataFilingText = redStarFlag + blueFlagStart + inspectDataFilingText + blueFlagEnd;
            inspectDataAffirmText = redStarFlag + blueFlagStart + inspectDataAffirmText + blueFlagEnd;
            technologyFilePrintingText = redStarFlag + blueFlagStart + technologyFilePrintingText + blueFlagEnd;
        } else if (currentActKey == 'mInDateCollect_node') {
            inspectDataFilingText = redStarFlag + blueFlagStart + inspectDataFilingText + blueFlagEnd;
            inspectDataAffirmText = redStarFlag + blueFlagStart + inspectDataAffirmText + blueFlagEnd;
            technologyFilePrintingText = redStarFlag + blueFlagStart + technologyFilePrintingText + blueFlagEnd;
        } else if (currentActKey == 'dateConfirm_node') {
            certfConfirmText = redStarFlag + blueFlagStart + certfConfirmText + blueFlagEnd;
        } else if (currentActKey == 'creationReport_node') {
            certfCreateFilingText = redStarFlag + blueFlagStart + certfCreateFilingText + blueFlagEnd;
            certfCreateReportText = redStarFlag + blueFlagStart + certfCreateReportText + blueFlagEnd;
        } else if (currentActKey == 'hasConfirmationReport_node') {
            exploitCreateReportText = redStarFlag + blueFlagStart + exploitCreateReportText + blueFlagEnd;
        } else if (currentActKey == 'hasConfirmationDataReport_node') {
            exploitConfirmText = redStarFlag + blueFlagStart + exploitConfirmText + blueFlagEnd;
        } else if (currentActKey == 'mDateUpdate_node') {
            dataConfirmText = redStarFlag + blueFlagStart + dataConfirmText + blueFlagEnd;
        } else if (currentActKey == 'dateAudit_node') {

        } else if (currentActKey == 'waiting_authentication_result_node') {
            dataRequireText = redStarFlag + blueFlagStart + dataRequireText + blueFlagEnd;
            whetherPassText = blueFlagStart + whetherPassText + blueFlagEnd;
            withoutExplanationText = blueFlagStart + withoutExplanationText + blueFlagEnd;
        } else if (currentActKey == 'certificationDoc_node') {
            certfArchiveRemarkText = redStarFlag + blueFlagStart + certfArchiveRemarkText + blueFlagEnd;
        } else if (currentActKey == 'certificationCheckDoc_node') {
            certfArchiveRemarkText = redStarFlag + blueFlagStart + certfArchiveRemarkText + blueFlagEnd;
        } else if (currentActKey == 'dateReconfirm_node') {
            ECRNumberText = blueFlagStart + ECRNumberText + blueFlagEnd;
            isDataSaveText = redStarFlag + blueFlagStart + isDataSaveText + blueFlagEnd;
            revisionDocNumberText = redStarFlag + blueFlagStart + revisionDocNumberText + blueFlagEnd;
            productionDataRemarkText = redStarFlag + blueFlagStart + productionDataRemarkText + blueFlagEnd;
        } else if (currentActKey == 'isDate_node') {
            filePrintText = redStarFlag + blueFlagStart + filePrintText + blueFlagEnd;
            dataDisposeText = redStarFlag + blueFlagStart + dataDisposeText + blueFlagEnd;
            head_demandSourceText = redStarFlag + blueFlagStart + head_demandSourceText + blueFlagEnd;
            head_remarkText = redStarFlag + blueFlagStart + head_remarkText + blueFlagEnd;
        } else if (currentActKey == 'hasConfirmationData_node') {
            initiatorConfirmText = redStarFlag + blueFlagStart + initiatorConfirmText + blueFlagEnd;
        } else if(currentActKey == 'supplementary_responsible_person_node'){
            submitEngineerText = redStarFlag + blueFlagStart + submitEngineerText + blueFlagEnd;
        }


        Ext.define('certfGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'productType', 'name', 'certfType', 'inspectType', 'isDevice', 'deviceNumber',
                'sampleCount', 'endItemNumber'],
            idProperty: 'id'
        });
        Ext.define('fileItemModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'applyFilePath', 'skillFilePath', 'elseFilePath', 'productType', 'applyFile',
                'skillFile', 'elseFile', 'baseLineNumber', 'submitEngineer'],
            idProperty: 'id'
        });


        var itemStore = Ext.create('Ext.data.Store', {
            id: 'itemStore',
            model: 'certfGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/certf/getItemsByCertfId?certfId=' + certfId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'item',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var fileItemStore = Ext.create('Ext.data.Store', {
            id: 'fileItemStore',
            model: 'fileItemModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/certf/getFileItemsByCertfId?certfId=' + certfId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'item',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });


        Ext.define('productTypeModel', {
            extend: 'Ext.data.Model',
            fields: [
                'PRODUCTTYPE'
            ],
            idProperty: 'id'
        });

        // 产品类型下拉
        var productTypeListStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'productTypeModel',
            id: 'productTypeListStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/certf/getProductTypes?certfId=' + certfId,
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });

        var productTypeCombo = new Ext.form.ComboBox({
            name: 'productTypeCombo',
            id: 'productTypeCombo',
            multiSelect: false,
            valueField: 'PRODUCTTYPE',
            displayField: 'PRODUCTTYPE',
            anyMatch: true,
            editable: false,
            store: productTypeListStore
        });

        /*  //用户下拉列表
          var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
              storeId: 'allUserStore_projectPlan'
          });
          var allUserCombo_projectPlan = Ext.create('PLM.hr.CtAllUserCombo', {
              store: allUserStore_projectPlan
          });
  */
        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing2 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        //认证类型
        var certfTypes = new Ext.form.ComboBox({
            name: 'certfTypes',
            id: 'certfTypes',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//CCC认证，自愿性认证，技术鉴定，防爆认证，LPCB认证，CE认证，APPLUS认证，CoC中东认证，  防腐认证、船检认证
            // 电信设备进网许可证，无线电发射设备型号核准证，中国商品条码系统成员，计量器具型式批准，其它，无
            store: [['无', '无'], ['CCC认证', 'CCC认证'], ['自愿性认证', '自愿性认证'], ['技术鉴定', '技术鉴定'],
                ['防爆认证', '防爆认证'], ['LPCB认证', 'LPCB认证'], ['电信设备进网许可证', '电信设备进网许可证'],
                ['APPLUS认证', 'APPLUS认证'], ['CoC中东认证', 'CoC中东认证'], ['防爆委托', '防爆委托'],
                ['无线电发射设备型号核准证', '无线电发射设备型号核准证'], ['中国商品条码系统成员', '中国商品条码系统成员'], ['计量器具型式批准', '计量器具型式批准'],
                ['其它', '其它'], ['非认证', '非认证'], ['防腐认证', '防腐认证'], ['船检认证', '船检认证']
            ]
        });

        //送检类型
        var inspectTypes = new Ext.form.ComboBox({
            name: 'inspectTypes',
            id: 'inspectTypes',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//型式试验，分型试验，变更确认检验，型式检验，委托检验，发证检验，
            // 系统兼容性试验，防爆委托，LPCB，CE，APPLUS，进网检测，无线电核准，其它，无 防腐委托、船检委托
            store: [['无', '无'], ['型式试验', '型式试验'], ['分型试验', '分型试验'], ['变更确认检验', '变更确认检验'],
                ['型式检验', '型式检验'], ['委托检验', '委托检验'], ['发证检验', '发证检验'],
                ['系统兼容性试验', '系统兼容性试验'], ['防爆委托', '防爆委托'], ['LPCB', 'LPCB'],
                ['CE', 'CE'], ['APPLUS', 'APPLUS'], ['进网检测', '进网检测'], ['无线电核准', '无线电核准'], ['计量委托检验', '计量委托检验'],
                ['变更报备', '变更报备'],['防腐委托', '防腐委托'],['船检委托', '船检委托'],['其它', '其它']
            ]
        });

        //来源
        var sourceCombo = new Ext.form.ComboBox({
            name: 'sourceCombo',
            id: 'sourceCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//新产品，老产品变更_需备注变更内容，证书延续，其它
            store: [['新产品', '新产品'], ['老产品', '老产品'], ['证书延续', '证书延续'],
                ['其它', '其它']
            ]
        });

        //是否有关键元器件
        var isDeviceCombo = new Ext.form.ComboBox({
            name: 'isDeviceCombo',
            id: 'isDeviceCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['是', '是'], ['否', '否']
            ]
        });


        var itemGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('itemStore'),
            id: 'itemGrid',
            sortableColumns: false,
            margin: '10 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer',width:40},
                //['id', 'certfId', 'productType', 'name', 'certfType', 'inspectType', 'isDevice', 'deviceNumber',
                // 				'sampleCount']
                {text: '', dataIndex: 'id', hidden: true},
                {text: '', dataIndex: 'docBranchId', hidden: true},
                {text: '编号', dataIndex: 'tagId'},
                {text: '产品型号', dataIndex: 'productType', width: 100, editor: 'textfield'},
                {text: '名称', dataIndex: 'name', width: 100, editor: 'textfield'},
                {text: '成品编码', dataIndex: 'endItemNumber', width: 100, editor: 'textfield'},
                {text: '认证类型', dataIndex: 'certfType', width: 100, editor: certfTypes},
                {text: '送检类型', dataIndex: 'inspectType', width: 100, editor: inspectTypes},
                {text: '是否有关键元器件', dataIndex: 'isDevice', width: 100, editor: isDeviceCombo},
                {text: '关键元器件编码(多值)', dataIndex: 'deviceNumber', width: 100, editor: 'textfield'},
                {text: '样品数量', dataIndex: 'sampleCount', width: 100, editor: 'textfield'},
            ],
            tbar: [{
                text: '新增',
                id: 'add',
                iconCls: 'icon-add',
                name: 'add',
                hidden: disableNode(submit_node) ? disableNode(resubmit_node) : !disableNode(resubmit_node) ? disableNode(isDate_node) : false,
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('itemStore').reload()
                        Ext.getStore('fileItemStore').reload()
                    };
                    insertItemData('ZCertfItem', callbackFn);


                }
            }, {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                hidden: disableNode(submit_node) ? disableNode(resubmit_node) : !disableNode(resubmit_node) ? disableNode(isDate_node) : false,
                handler: function () {
                    let selectionArr = itemGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    let tagIds = new Array();
                    Ext.each(selectionArr, function (record) {
                        tagIds.push(record.data['tagId'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('itemStore').reload()
                        Ext.getStore('fileItemStore').reload()
                    };
                    deleteData('ZCertfItem', obj, tagIds, callbackFn);
                }
            }],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if (!disableNode(submit_node) || !disableNode(resubmit_node)
                        || !disableNode(mDateUpdate_node) || !disableNode(isDate_node) || !disableNode(dateCollect_node)) {
                        return true
                    }
                    if (!disableNode(engineer_node)) {
                        if (tField == 'certfType' || tField == 'inspectType'
                            || tField == 'isDevice') {
                            return true;
                        }
                    }
                    if (!disableNode(isDate_node)) {
                        if (tField == 'certfType' || tField == 'inspectType') {
                            return true;
                        }
                    }
                    return false;
                },
            }
        });

        Ext.define('documentPassModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'engineer', 'whetherPass', 'withoutExplanation'],
            idProperty: 'id'
        });

        var documentPassStore = Ext.create('Ext.data.Store', {
            id: 'documentPassStore',
            model: 'documentPassModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/certf/getDocumentPassData?certfId=' + certfId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'item',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: true
        });

        //是否通过
        let isPassStore = [['是', '是'], ['否', '否']];

        var documentPassGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing2],
            store: Ext.getStore('documentPassStore'),
            id: 'documentPassGrid',
            sortableColumns: false,
            margin: '10 0 0 0',
            forceFit: true,
            autoWidth: true,
            autoScroll: false,
            region: 'center',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            columns: [
                {xtype: 'rownumberer',text:'序号', width:80},
                {text: '', dataIndex: 'id', hidden: true},
                {text: '', dataIndex: 'docBranchId', hidden: true},
                {text: '工程师', dataIndex: 'engineer', width: 120, editor: 'displayfield'},
                {
                    text: whetherPassText,//是否通过
                    dataIndex: 'whetherPass',
                    width: 100,
                    editor: {
                        xtype: 'combobox',
                        editable: false,
                        forceSelection: false,
                        store: isPassStore
                    }
                },
                {
                    text: withoutExplanationText,//不通过说明
                    dataIndex: 'withoutExplanation',
                    width: 200,
                    editor: 'textfield'
                }
            ],
            tbar: [],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if (!disableNode(waiting_authentication_result_node)) {
                        return true
                    }
                    // if (!disableNode(isDate_node)) {
                    //     if (tField == 'certfType' || tField == 'inspectType') {
                    //         return true;
                    //     }
                    // }
                    return false;
                },
            }
        });

        documentPassGrid.on('edit',
            function (editor, e) {
                updateDocPass(editor, e);
            });

        //提交工程师
        var submitEngineerStore = new Ext.data.ArrayStore({
            id: 'submitEngineerStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        var submitEngineerCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'submitEngineer',
            id: 'submitEngineer',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: submitEngineerStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });

        var fileItemGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('fileItemStore'),
            id: 'fileItemGrid',
            margin: '10 0 0 0',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            sortableColumns: false,
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer',width:40},
                //['id', 'certfId', 'productType', 'name', 'certfType', 'inspectType', 'isDevice', 'deviceNumber',
                // 				'sampleCount']
                {text: '', dataIndex: 'id', hidden: true},
                {text: '', dataIndex: 'docBranchId', hidden: true},
                {text: '', dataIndex: 'applyFilePath', hidden: true},
                {text: '', dataIndex: 'skillFilePath', hidden: true},
                {text: '', dataIndex: 'scanSkillFilePath', hidden: true},
                {text: '', dataIndex: 'elseFilePath', hidden: true},
                {text: '编号', dataIndex: 'tagId', width: 80},
                //{text: '产品型号', dataIndex: 'productType', width: 100, editor: 'textfield'},
                {
                    text: '产品送检申请文件', dataIndex: 'applyFile', width: 180,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        if (value != null) {
                            var start = value.toString().indexOf("fileName=") + 9;
                            var s = value.toString().substring(start, value.toString().indexOf("&", start))
                            metaData.tdAttr = "data-qtip = '" + s + "'";
                        }
                        return value;
                    }
                },
                {
                    text: '产品送检技术文件', dataIndex: 'skillFile', width: 180,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        if (value != null) {
                            var start = value.toString().indexOf("fileName=") + 9;
                            var s = value.toString().substring(start, value.toString().indexOf("&", start))
                            metaData.tdAttr = "data-qtip = '" + s + "'";
                        }
                        return value;
                    }
                },
                {
                    text: '送检文件（盖章）', dataIndex: 'scanSkillFile', width: 180,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        if (value != null) {
                            var start = value.toString().indexOf("fileName=") + 9;
                            var s = value.toString().substring(start, value.toString().indexOf("&", start))
                            metaData.tdAttr = "data-qtip = '" + s + "'";
                        }
                        return value;
                    }
                },
                {
                    text: '其他文件',menuDisabled: true,
                    columns: [
                        {
                            text: submitEngineerText,
                            dataIndex: 'submitEngineer',
                            width: 150,
                            editor: submitEngineerCom
                        },
                        {
                            text: '获证所需其他文件', dataIndex: 'elseFile', width: 180,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if (value != null) {
                                    var start = value.toString().indexOf("fileName=") + 9;
                                    var s = value.toString().substring(start, value.toString().indexOf("&", start))
                                    metaData.tdAttr = "data-qtip = '" + s + "'";
                                }
                                return value;
                            }
                        }
                    ]
                },
                {text: '产品送检齐套技术文件基线编号', dataIndex: 'baseLineNumber', width: 180, editor: 'textfield'},
            ],
            tbar: [
                /*{
                text: '新增',
                iconCls : 'icon-add',
                hidden: disableNode(submit_node) ? disableNode(resubmit_node) : false,
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('fileItemStore').reload()
                    };
                    insertItemData('ZCertfFileItem', callbackFn);
                }
            }, {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                //hidden:!disableNode(submit_node)?!disableNode(resubmit_node):disableNode(resubmit_node),
                hidden: disableNode(submit_node) ? disableNode(resubmit_node) : false,
                handler: function () {
                    let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('fileItemStore').reload()
                    };
                    deleteData('ZCertfFileItem', obj, callbackFn);
                }
            },*/
                {

                    xtype: 'filefield',
                    hidden: true,
                    buttonOnly: true,
                    id: 'head_uploadFile',
                    name: 'head_uploadFile',
                    // hidden:true,
                    hideLabel: true,
                    buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加送检申请文件',
                    allowBlank: false,
                    scope: this,
                    listeners: {

                        'focus': function () {
                            let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                            if (selectionArr.length == 0) {
                                alert("未选择添加文件行！");
                                return;
                            }
                            /*//alert(selectionArr[0].get("attachment"))
                            if (selectionArr[0].get("attachment") != null){
                                alert('只能上传一个文件');
                                return;
                            }*/

                            var productType = selectionArr[0].get("productType");
                            var file = selectionArr[0].get("applyFilePath");

                            /*if (productType == '' || productType == undefined) {
                                alert("请先填写产品型号!");
                                return;
                            }*/
                            if (file != undefined) {
                                alert("只能上传一个文件!");
                                return;
                            }

                            if (selectionArr.length >= 2) {
                                alert("不支持多行添加文件操作，请确认要添加的行");
                                return;
                            }
                        },
                        'change': function (fb, newValue) {
                            if (!newValue) {
                                return;
                            }
                            let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                            var productType = selectionArr[0].get("productType");
                            var file = selectionArr[0].get("applyFilePath");
                            var id = selectionArr[0].get("id");

                            /*if (productType == '' || productType == undefined) {
                                alert("请先填写产品型号!");
                                return;
                            }*/
                            if (file != undefined) {
                                alert("只能上传一个文件!");
                                return;
                            }
                            if (selectionArr.length == 0) {
                                alert("添加文件失败，未选择添加文件对象!");
                                return;
                            } else {

                                var file = document.querySelector('[id=' + 'head_uploadFile' + '-button-fileInputEl]');
                                var formData = new FormData();
                                formData.append('head_uploadFile' + '-button-fileInputEl', file.files[0]);
                                fb.reset();//清空表单的值
                                var myMask = new Ext.LoadMask({
                                    msg: '正在上传，请稍候......',
                                    target: this.findParentByType('panel')
                                });

                                var tRecord = fileItemGrid.getSelectionModel().getSelection()[0];
                                var itemId = tRecord.get('id');
                                myMask.show();
                                $.ajax({
                                    url: '/Windchill/ptc1/certf/uploadFiles?branchId=' + certfId + '&id=' + id + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + 'head_node' + "&type=applyFile"+"&id="+itemId,
                                    type: 'POST',
                                    cache: false,
                                    data: formData,
                                    processData: false,
                                    contentType: false
                                }).done(function (res) {
                                    myMask.hide();
                                    var obj = Ext.decode(res);
                                    var success = obj['success'];
                                    var msg = obj['msg'];
                                    if (!success) {
                                        alert(msg);
                                    } else {
                                        var fileName = obj['fileName'];
                                        var filePath = obj['filePath'];

                                        var attachmentValue = fileItemGrid.getSelectionModel().getSelection()[0].data.applyFile;
                                        var attachmentPath = fileItemGrid.getSelectionModel().getSelection()[0].data.applyFilePath;
                                        if (attachmentValue != null && attachmentValue != '') {
                                            fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                            filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                        }
                                        tRecord.set('applyFile', fileName);
                                        tRecord.set('applyFilePath', filePath);
                                        var callbackFn = function () {
                                            tRecord.commit();
                                        };
                                        var itemId = tRecord.get('id');
                                        saveMockItemData("ZCertfFileItem", itemId, 'applyFile', fileName, callbackFn);
                                        saveMockItemData("ZCertfFileItem", itemId, 'applyFilePath', filePath, callbackFn);

                                    }
                                    var callbackFn = function () {
                                        //tRecord.commit();
                                        Ext.getStore('fileItemStore').reload();
                                    };
                                }).fail(function (res) {
                                    myMask.hide();
                                    alert('上传失败！');
                                });
                            }
                        }

                    }
                },
                {

                    xtype: 'filefield',
                    hidden: true,
                    buttonOnly: true,
                    id: 'head_uploadFile1',
                    name: 'head_uploadFile1',
                    // hidden:true,
                    hideLabel: true,
                    buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加送检技术文件',
                    allowBlank: false,
                    scope: this,
                    listeners: {

                        'focus': function () {
                            let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                            if (selectionArr.length == 0) {
                                alert("未选择添加文件行！");
                                return;
                            }
                            /*//alert(selectionArr[0].get("attachment"))
                            if (selectionArr[0].get("attachment") != null){
                                alert('只能上传一个文件');
                                return;
                            }*/
                            var productType = selectionArr[0].get("productType");
                            var file = selectionArr[0].get("skillFile");

                            /*if (productType == '' || productType == undefined) {
                                alert("请先填写产品型号!");
                                return;
                            }*/
                            if (file != undefined) {
                                alert("只能上传一个文件!");
                                return;
                            }

                            if (selectionArr.length >= 2) {
                                alert("不支持多行添加文件操作，请确认要添加的行");
                                return;
                            }
                        },
                        'change': function (fb, newValue) {
                            if (!newValue) {
                                return;
                            }
                            let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                            var productType = selectionArr[0].get("productType");
                            var file = selectionArr[0].get("skillFile");
                            var id = selectionArr[0].get("id");

                            /*if (productType == '' || productType == undefined) {
                                alert("请先填写产品型号!");
                                return;
                            }*/
                            if (file != undefined) {
                                alert("只能上传一个文件!");
                                return;
                            }
                            if (selectionArr.length == 0) {
                                alert("添加文件失败，未选择添加文件对象!");
                                return;
                            } else {

                                var file = document.querySelector('[id=' + 'head_uploadFile1' + '-button-fileInputEl]');
                                var formData = new FormData();
                                formData.append('head_uploadFile1' + '-button-fileInputEl', file.files[0]);
                                fb.reset();//清空表单的值
                                var myMask = new Ext.LoadMask({
                                    msg: '正在上传，请稍候......',
                                    target: this.findParentByType('panel')
                                });


                                myMask.show();
                                $.ajax({
                                    url: '/Windchill/ptc1/certf/uploadFiles?branchId=' + certfId + '&id=' + id + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + 'head_node' + "&type=skillFile",
                                    type: 'POST',
                                    cache: false,
                                    data: formData,
                                    processData: false,
                                    contentType: false
                                }).done(function (res) {
                                    myMask.hide();
                                    var obj = Ext.decode(res);
                                    var success = obj['success'];
                                    var msg = obj['msg'];
                                    if (!success) {
                                        alert(msg);
                                    } else {
                                        var fileName = obj['fileName'];
                                        var filePath = obj['filePath'];
                                        var tRecord = fileItemGrid.getSelectionModel().getSelection()[0];
                                        var attachmentValue = fileItemGrid.getSelectionModel().getSelection()[0].data.skillFile;
                                        var attachmentPath = fileItemGrid.getSelectionModel().getSelection()[0].data.skillFilePath;
                                        if (attachmentValue != null && attachmentValue != '') {
                                            fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                            filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                        }
                                        tRecord.set('skillFile', fileName);
                                        tRecord.set('skillFilePath', filePath);
                                        var callbackFn = function () {
                                            tRecord.commit();
                                        };
                                        var itemId = tRecord.get('id');
                                        saveMockItemData("ZCertfFileItem", itemId, 'skillFile', fileName, callbackFn);
                                        saveMockItemData("ZCertfFileItem", itemId, 'skillFilePath', filePath, callbackFn);

                                    }
                                    var callbackFn = function () {
                                        //tRecord.commit();
                                        Ext.getStore('fileItemStore').reload();
                                    };
                                }).fail(function (res) {
                                    myMask.hide();
                                    alert('上传失败！');
                                });
                            }
                        }

                    }
                },
                {

                    xtype: 'filefield',
                    hidden: true,
                    buttonOnly: true,
                    id: 'head_uploadScanSkillFile',
                    name: 'head_uploadScanSkillFile',
                    // hidden:true,
                    hideLabel: true,
                    buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加送检技术文件（盖章）',
                    allowBlank: false,
                    scope: this,
                    listeners: {

                        'focus': function () {
                            let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                            if (selectionArr.length == 0) {
                                alert("未选择添加文件行！");
                                return;
                            }
                            /*//alert(selectionArr[0].get("attachment"))
                            if (selectionArr[0].get("attachment") != null){
                                alert('只能上传一个文件');
                                return;
                            }*/
                            var productType = selectionArr[0].get("productType");
                            var file = selectionArr[0].get("scanSkillFilePath");

                            /*if (productType == '' || productType == undefined) {
                                alert("请先填写产品型号!");
                                return;
                            }*/
                            if (file != undefined) {
                                alert("只能上传一个文件!");
                                return;
                            }

                            if (selectionArr.length >= 2) {
                                alert("不支持多行添加文件操作，请确认要添加的行");
                                return;
                            }
                        },
                        'change': function (fb, newValue) {
                            if (!newValue) {
                                return;
                            }
                            let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                            var productType = selectionArr[0].get("productType");
                            var file = selectionArr[0].get("scanSkillFile");
                            var id = selectionArr[0].get("id");

                            /*if (productType == '' || productType == undefined) {
                                alert("请先填写产品型号!");
                                return;
                            }*/
                            if (file != undefined) {
                                alert("只能上传一个文件!");
                                return;
                            }
                            if (selectionArr.length == 0) {
                                alert("添加文件失败，未选择添加文件对象!");
                                return;
                            } else {

                                var file = document.querySelector('[id=' + 'head_uploadScanSkillFile' + '-button-fileInputEl]');
                                var formData = new FormData();
                                formData.append('head_uploadScanSkillFile' + '-button-fileInputEl', file.files[0]);
                                fb.reset();//清空表单的值
                                var myMask = new Ext.LoadMask({
                                    msg: '正在上传，请稍候......',
                                    target: this.findParentByType('panel')
                                });


                                myMask.show();
                                $.ajax({
                                    url: '/Windchill/ptc1/certf/uploadFiles?branchId=' + certfId + '&id=' + id + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + 'head_node' + "&type=scanSkillFile",
                                    type: 'POST',
                                    cache: false,
                                    data: formData,
                                    processData: false,
                                    contentType: false
                                }).done(function (res) {
                                    myMask.hide();
                                    var obj = Ext.decode(res);
                                    var success = obj['success'];
                                    var msg = obj['msg'];
                                    if (!success) {
                                        alert(msg);
                                    } else {
                                        var fileName = obj['fileName'];
                                        var filePath = obj['filePath'];
                                        var tRecord = fileItemGrid.getSelectionModel().getSelection()[0];
                                        var attachmentValue = fileItemGrid.getSelectionModel().getSelection()[0].data.scanSkillFile;
                                        var attachmentPath = fileItemGrid.getSelectionModel().getSelection()[0].data.scanSkillFilePath;
                                        if (attachmentValue != null && attachmentValue != '') {
                                            fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                            filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                        }
                                        tRecord.set('scanSkillFile', fileName);
                                        tRecord.set('scanSkillFilePath', filePath);
                                        var callbackFn = function () {
                                            tRecord.commit();
                                        };
                                        var itemId = tRecord.get('id');
                                        saveMockItemData("ZCertfFileItem", itemId, 'scanSkillFile', fileName, callbackFn);
                                        saveMockItemData("ZCertfFileItem", itemId, 'scanSkillFilePath', filePath, callbackFn);

                                    }
                                    var callbackFn = function () {
                                        //tRecord.commit();
                                        Ext.getStore('fileItemStore').reload();
                                    };
                                }).fail(function (res) {
                                    myMask.hide();
                                    alert('上传失败！');
                                });
                            }
                        }

                    }
                },
                {

                    xtype: 'filefield',
                    hidden: true,
                    buttonOnly: true,
                    id: 'head_uploadFile2',
                    name: 'head_uploadFile2',
                    // hidden:true,
                    hideLabel: true,
                    buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加送检其他文件',
                    allowBlank: false,
                    scope: this,
                    listeners: {

                        'focus': function () {
                            let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                            if (selectionArr.length == 0) {
                                alert("未选择添加文件行！");
                                return;
                            }
                            /*//alert(selectionArr[0].get("attachment"))
                            if (selectionArr[0].get("attachment") != null){
                                alert('只能上传一个文件');
                                return;
                            }*/
                            var productType = selectionArr[0].get("productType");
                            var file = selectionArr[0].get("elseFile");

                            /*if (productType == '' || productType == undefined) {
                                alert("请先填写产品型号!");
                                return;
                            }*/
                            if (file != undefined) {
                                alert("只能上传一个文件!");
                                return;
                            }

                            if (selectionArr.length >= 2) {
                                alert("不支持多行添加文件操作，请确认要添加的行");
                                return;
                            }

                        },
                        'change': function (fb, newValue) {
                            if (!newValue) {
                                return;
                            }
                            let selectionArr = fileItemGrid.getSelectionModel().getSelection();
                            var productType = selectionArr[0].get("productType");
                            var file = selectionArr[0].get("elseFile");
                            var id = selectionArr[0].get("id");

                            /*if (productType == '' || productType == undefined) {
                                alert("请先填写产品型号!");
                                return;
                            }*/
                            if (file != undefined) {
                                alert("只能上传一个文件!");
                                return;
                            }
                            if (selectionArr.length == 0) {
                                alert("添加文件失败，未选择添加文件对象!");
                                return;
                            } else {

                                var file = document.querySelector('[id=' + 'head_uploadFile2' + '-button-fileInputEl]');
                                var formData = new FormData();
                                formData.append('head_uploadFile2' + '-button-fileInputEl', file.files[0]);
                                fb.reset();//清空表单的值
                                var myMask = new Ext.LoadMask({
                                    msg: '正在上传，请稍候......',
                                    target: this.findParentByType('panel')
                                });


                                myMask.show();
                                $.ajax({
                                    url: '/Windchill/ptc1/certf/uploadFiles?branchId=' + certfId +'&id=' + id + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + 'head_node' + "&type=其他文件",
                                    type: 'POST',
                                    cache: false,
                                    data: formData,
                                    processData: false,
                                    contentType: false
                                }).done(function (res) {
                                    myMask.hide();
                                    var obj = Ext.decode(res);
                                    var success = obj['success'];
                                    var msg = obj['msg'];
                                    if (!success) {
                                        alert(msg);
                                    } else {
                                        var fileName = obj['fileName'];
                                        var filePath = obj['filePath'];
                                        var tRecord = fileItemGrid.getSelectionModel().getSelection()[0];
                                        var attachmentValue = fileItemGrid.getSelectionModel().getSelection()[0].data.elseFile;
                                        var attachmentPath = fileItemGrid.getSelectionModel().getSelection()[0].data.elseFilePath;
                                        if (attachmentValue != null && attachmentValue != '') {
                                            fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                            filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                        }
                                        tRecord.set('elseFile', fileName);
                                        tRecord.set('elseFilePath', filePath);
                                        var callbackFn = function () {
                                            tRecord.commit();
                                        };
                                        var itemId = tRecord.get('id');
                                        saveMockItemData("ZCertfFileItem", itemId, 'elseFile', fileName, callbackFn);
                                        saveMockItemData("ZCertfFileItem", itemId, 'elseFilePath', filePath, callbackFn);

                                    }
                                    var callbackFn = function () {
                                        //tRecord.commit();
                                        Ext.getStore('fileItemStore').reload();
                                    };
                                }).fail(function (res) {
                                    myMask.hide();
                                    alert('上传失败！');
                                });
                            }
                        }

                    }
                },
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列
                    if(!disableNode(supplementary_responsible_person_node)){
                        if(tField == 'submitEngineer'){
                            return true;
                        }else{
                            return false;
                        }
                    }

                    if (!disableNode(createBaseline_node) || !disableNode(submit_node) || !disableNode(resubmit_node)
                        || !disableNode(isDate_node) || !disableNode(dateCollect_node)
                    ) {
                        return true;
                    }
                    return false;
                },
            }
        });

        itemGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                    //Ext.getStore('itemStore').reload()
                };
                saveMockItemData('ZCertfItem', itemId, tField, tValue, callbackFn);

            });


        fileItemGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');
                var callbackFn = function () {
                    tRecord.commit();
                    //Ext.getStore('itemStore').reload()
                };
                saveMockItemData('ZCertfFileItem', itemId, tField, tValue, callbackFn);
                Ext.getStore('fileItemStore').load();
            });


        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            collapsible: true,
            title: '1.跟踪表基本信息',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                layout: {
                    type: 'hbox',
                    padding: '2 10 2 10'
                }
            },
            items: [
                {//第一行
                    xtype: 'panel',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '申请日期',
                        name: 'head_applyDate',
                        id: 'head_applyDate',
                        width: 250,
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '申请人',
                        name: 'head_applyUser',
                        id: 'head_applyUser',
                        width: 250,
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '部门',
                        name: 'head_department',
                        id: 'head_department',
                        width: 250,
                    }]
                }, {
                    xtype: 'panel',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'combo',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        store: [['新产品', '新产品'], ['老产品变更', '老产品变更'], ['证书延续', '证书延续'],
                            ['其它', '其它']],
                        fieldLabel: head_demandSourceText,
                        name: 'head_demandSource',
                        id: 'head_demandSource',
                        disabled: (disableNode(submit_node) && disableNode(resubmit_node) && disableNode(isDate_node)),
                        //disabled: disableNode(submit_node) ? disableNode(resubmit_node) : !disableNode(resubmit_node) ? disableNode(isDate_node) : !disableNode(isDate_node) ? disableNode(hasConfirmationData_node) : !disableNode(hasConfirmationData_node),
                        disabledCls: 'none',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('head_demandSource').getValue();
                                //触发后台保存
                                autoSaveAtt('head_demandSource', value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: head_projectNumberText,
                        name: 'head_projectNumber',
                        id: 'head_projectNumber',
                        //disabled: true,
                        disabled: disableNode(submit_node) ? disableNode(resubmit_node) : !disableNode(resubmit_node) ? disableNode(isDate_node) : !disableNode(isDate_node) ? disableNode(hasConfirmationData_node) : !disableNode(hasConfirmationData_node),
                        disabledCls: 'none',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('head_projectNumber').getValue();
                                //触发后台保存
                                autoSaveAtt('head_projectNumber', value);
                            }
                        }

                    }, {
                        xtype: 'textarea',
                        fieldLabel: head_remarkText,
                        name: 'head_remark',
                        id: 'head_remark',
                        disabled: (disableNode(submit_node) && disableNode(resubmit_node) && disableNode(isDate_node)),
                        //disabled: disableNode(submit_node) ? disableNode(resubmit_node) : !disableNode(resubmit_node) ? disableNode(isDate_node) : !disableNode(isDate_node) ? disableNode(hasConfirmationData_node) : !disableNode(hasConfirmationData_node),
                        disabledCls: 'none',
                        width: 450,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('head_remark').getValue();
                                //触发后台保存
                                autoSaveAtt('head_remark', value);
                            }
                        }
                    }]
                }, itemGrid, fileItemGrid, {
                    xtype: 'panel',
                    title: '',
                    //collapsible: true,
                    margin: '5 20 5 5',
                    //defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [/*applyItemGrid, restsItemGrid, skillItemGrid*/]
                },
            ]//~end of hbox items
        },//~end of 测试项目

            {
                xtype: 'form',
                id: 'mainForm1',
                name: 'mainForm1',
                //padding:'5',
                anchor: '90%',
                border: false,
                defaults: {
                    labelWidth: 100,
                    border: false,
                },
                items: [{//第五行
                    xtype: 'panel',
                    title: '2.基本信息审核',
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    items: [{
                        xtype: 'panel',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            border: false,
                            html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">开发代表审核</div>'
                        }, {
                            xtype: 'textarea',
                            fieldLabel: projectPrincipalAuditText,
                            name: 'projectPrincipalAudit',
                            id: 'projectPrincipalAudit',
                            disabled: disableNode(principal_node),
                            disabledCls: 'none',
                            width: 550,
                            height: 35,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('projectPrincipalAudit').getValue();
                                    //触发后台保存
                                    autoSaveAtt('projectPrincipalAudit', value);
                                }
                            }
                        }],
                    }, {
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">采购主管审核</div>'
                    }, {
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            xtype: 'textarea',
                            fieldLabel: procurementAuditText,
                            name: 'procurementAudit',
                            id: 'procurementAudit',
                            disabled: disableNode(procurement_node),
                            disabledCls: 'none',
                            width: 550,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('procurementAudit').getValue();
                                    //触发后台保存
                                    autoSaveAtt('procurementAudit', value);
                                }
                            }
                        }, {
                            xtype: 'combobox',
                            fieldLabel: isPhysicalText,
                            name: 'isPhysical',
                            id: 'isPhysical',
                            disabled: disableNode(procurement_node),
                            disabledCls: 'none',
                            width: 250,
                            store: [['是', '是'], ['否', '否']],
                            listeners: {
                                select: function (e) {
                                    if (!ght_dataLoadedFlag) {
                                        //阻止加载时执行后台保存
                                        return;
                                    }
                                    var value = Ext.getCmp('isPhysical').getValue();
                                    //触发后台保存
                                    autoSaveAtt('isPhysical', value);
                                }
                            }
                        }]
                    }, {
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">认证工程师审核</div>'
                    }, {
                        xtype: 'panel',
                        items: [{
                            xtype: 'textarea',
                            fieldLabel: engineerAuditAuditText,
                            id: 'engineerAudit',
                            name: 'engineerAudit',
                            disabled: disableNode(engineer_node),
                            disabledCls: 'none',
                            width: 550,
                            height: 150,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('engineerAudit').getValue();
                                    //触发后台保存
                                    autoSaveAtt('engineerAudit', value);
                                }
                            }
                        }, {
                            xtype: 'radiogroup',
                            labelWidth: 100,
                            disabled: disableNode(engineer_node),
                            disabledCls: 'none',
                            fieldLabel: isRecertificationText,
                            name: 'isRecertification',
                            id: 'isRecertification',
                            width: 250,
                            columns: 2,
                            items: [
                                {boxLabel: '是', name: 'recertification', inputValue: '是', disabledCls: 'none'},
                                {boxLabel: '否', name: 'recertification', inputValue: '否', disabledCls: 'none'},
                            ],
                            listeners: {
                                change: function (field, newValue, oldValue) {
                                    if (!ght_dataLoadedFlag) {
                                        //阻止加载时执行后台保存
                                        return;
                                    }
                                    //触发后台保存
                                    var data = newValue.recertification;
                                    autoSaveAtt('recertification', data);
                                }
                            }
                        }],
                    }, {
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">产品管理部经理审核</div>'
                    }, {
                        xtype: 'panel',
                        items: [{
                            xtype: 'textarea',
                            fieldLabel: PMAuditText,
                            name: 'PMAudit',
                            id: 'PMAudit',
                            disabled: disableNode(PM_node),
                            disabledCls: 'none',
                            width: 550,
                            height: 35,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('PMAudit').getValue();
                                    //触发后台保存
                                    autoSaveAtt('PMAudit', value);
                                }
                            }
                        }],
                    }]
                }, {//第六行
                    xtype: 'panel',
                    title: '3.产品送检申请文件 / 产品送检技术文件准备',
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    items: [
                        {
                            html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">资料室存档</div>'
                        },
                        {
                            layout: 'hbox',
                            xtype: 'panel',
                            title: '',
                            defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                            items: [
                                {
                                    xtype: 'textarea',
                                    labelWidth: 150,
                                    fieldLabel: technologyFilePrintingText,
                                    disabled: disableNode(mDateCollect_node) ? disableNode(mInDateCollect_node) : false,
                                    disabledCls: 'none',
                                    name: 'technologyFilePrinting',
                                    id: 'technologyFilePrinting',
                                    width: 500,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('technologyFilePrinting').getValue();
                                            //触发后台保存
                                            autoSaveAtt('technologyFilePrinting', value);
                                        }
                                    }
                                }
                            ]
                        },
                        {
                            html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">送检过程中资料更新</div>'
                        },
                        {
                            layout: 'hbox',
                            xtype: 'panel',
                            title: '',
                            defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                            items: [
                                {
                                    xtype: 'textarea',
                                    disabled: disableNode(dateCollect_node) ? disableNode(inDateCollect_node) ? disableNode(isDate_node) : false : false,
                                    disabledCls: 'none',
                                    fieldLabel: dataDisposeText,//送检过程中资料更新
                                    labelWidth: 250,
                                    name: 'dataDispose',
                                    id: 'dataDispose',
                                    width: 650,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('dataDispose').getValue();
                                            //触发后台保存
                                            autoSaveAtt('dataDispose', value);
                                        }
                                    }
                                }
                            ]
                         },
                         {
                            xtype: 'panel',
                            title: '',
                            defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                            items: [

                                {
                                    html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">认证工程师确认送检资料</div>'
                                },
                                {
                                    xtype: 'textarea',
                                    labelWidth: 250,
                                    fieldLabel: certfConfirmText,
                                    disabled: disableNode(dateConfirm_node),
                                    disabledCls: 'none',
                                    name: 'certfConfirm',
                                    id: 'certfConfirm',
                                    width: 650,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('certfConfirm').getValue();
                                            //触发后台保存
                                            autoSaveAtt('certfConfirm', value);
                                        }
                                    }
                                }
                            ]
                        }
                    ]
                },



                    {//第九行
                        xtype: 'panel',
                        collapsible: true,
                        title: '4.检验报告归档',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [, {
                            html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">认证工程师创建检验报告</div>'
                        }, {
                            xtype: 'combobox',
                            labelWidth: 150,
                            fieldLabel: certfCreateFilingText,
                            name: 'certfCreateFiling',
                            id: 'certfCreateFiling',
                            disabled: disableNode(creationReport_node),
                            disabledCls: 'none',
                            width: 250,
                            store: [['是', '是'], ['否', '否']],
                            listeners: {
                                select: function (e) {
                                    if (!ght_dataLoadedFlag) {
                                        //阻止加载时执行后台保存
                                        return;
                                    }
                                    var value = Ext.getCmp('certfCreateFiling').getValue();
                                    //触发后台保存
                                    autoSaveAtt('certfCreateFiling', value);
                                }
                            }
                        }, {
                            xtype: 'button',
                            labelWidth: 150,
                            text: "存储库跳转",
                            handler: function () {
                                window.open("http://plm.fhsjdz.com/Windchill/app/#ptc1/tcomp/infoPage?ContainerOid=OR%3Awt.inf.library.WTLibrary%3A7132983&oid=OR%3Awt.folder.Cabinet%3A7133017&u8=1")
                                //window.open("http://plmdemo.fhsj.com:8885/Windchill/app/#ptc1/library/listFiles?ContainerOid=OR%3Awt.inf.library.WTLibrary%3A10721428&oid=OR%3Awt.folder.Cabinet%3A10721462&folderNavigatorParameter=true&u8=1")
                            }
                        }, {
                            xtype: 'textfield',
                            labelWidth: 170,
                            fieldLabel: certfNumberText,
                            disabled: disableNode(creationReport_node),
                            disabledCls: 'none',
                            name: 'certfNumber',
                            id: 'certfNumber',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('certfNumber').getValue();
                                    //触发后台保存
                                    getCertfLink(value, "检验报告");
                                }
                            }
                        }, {
                            xtype: 'displayfield',
                            labelWidth: 170,
                            fieldLabel: "检验报告/证书系统文档链接",
                            disabled: true,
                            disabledCls: 'none',
                            name: 'certfNumberLink',
                            id: 'certfNumberLink',
                            width: 500,
                        }, {
                            xtype: 'textarea',
                            labelWidth: 150,
                            fieldLabel: certfCreateReportText,
                            disabled: disableNode(creationReport_node),
                            disabledCls: 'none',
                            name: 'certfCreateReport',
                            id: 'certfCreateReport',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('certfCreateReport').getValue();
                                    //触发后台保存
                                    autoSaveAtt('certfCreateReport', value);
                                }
                            }
                        },
                            , {
                                html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">开发代表确认检验报告</div>'
                            }, {
                                xtype: 'textarea',
                                labelWidth: 150,
                                fieldLabel: exploitCreateReportText,
                                disabled: disableNode(hasConfirmationReport_node),
                                disabledCls: 'none',
                                name: 'exploitCreateReport',
                                id: 'exploitCreateReport',
                                width: 500,
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('exploitCreateReport').getValue();
                                        //触发后台保存
                                        autoSaveAtt('exploitCreateReport', value);
                                    }
                                }
                            }]
                    },
                    // {//第八行
                    //     xtype: 'panel',
                    //     collapsible: true,
                    //     title: '5.送检资料再确认',
                    //     defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    //     items: [{
                    //         html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">发起人确认送检资料</div>'
                    //     }, {
                    //         xtype: 'textarea',
                    //         labelWidth: 150,
                    //         fieldLabel: initiatorConfirmText,
                    //         disabled: disableNode(hasConfirmationData_node),
                    //         disabledCls: 'none',
                    //         name: 'initiatorConfirm',
                    //         id: 'initiatorConfirm',
                    //         width: 500,
                    //         listeners: {
                    //             blur: function (e) {
                    //                 var value = Ext.getCmp('initiatorConfirm').getValue();
                    //                 //触发后台保存
                    //                 autoSaveAtt('initiatorConfirm', value);
                    //             }
                    //         }
                    //     }, {
                    //         html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">开发代表确认送检资料</div>'
                    //     }, {
                    //         xtype: 'textarea',
                    //         labelWidth: 150,
                    //         fieldLabel: exploitConfirmText,
                    //         disabled: disableNode(hasConfirmationDataReport_node),
                    //         disabledCls: 'none',
                    //         name: 'exploitConfirm',
                    //         id: 'exploitConfirm',
                    //         width: 500,
                    //         listeners: {
                    //             blur: function (e) {
                    //                 var value = Ext.getCmp('exploitConfirm').getValue();
                    //                 //触发后台保存
                    //                 autoSaveAtt('exploitConfirm', value);
                    //             }
                    //         }
                    //     }, {
                    //         html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">资料室确认送检资料</div>'
                    //     }, {
                    //         xtype: 'textarea',
                    //         labelWidth: 150,
                    //         fieldLabel: dataConfirmText,
                    //         disabled: disableNode(mDateUpdate_node),
                    //         disabledCls: 'none',
                    //         name: 'dataConfirm',
                    //         id: 'dataConfirm',
                    //         width: 500,
                    //         listeners: {
                    //             blur: function (e) {
                    //                 var value = Ext.getCmp('dataConfirm').getValue();
                    //                 //触发后台保存
                    //                 autoSaveAtt('dataConfirm', value);
                    //             }
                    //         }
                    //     }]
                    // },
                    {//第六行
                        xtype: 'panel',
                        title: '5.获证所需其他资料',
                        collapsible: true,
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [
                            {
                                html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">待补充资料</div>'
                            },
                            {
                                xtype: 'panel',
                                title: '',
                                defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                                items: [{
                                    xtype: 'textarea',
                                    fieldLabel: dataRequireText,
                                    name: 'dataRequire',
                                    id: 'dataRequire',
                                    disabled: disableNode(waiting_authentication_result_node),
                                    disabledCls: 'none',
                                    width: 500,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('dataRequire').getValue();
                                            //触发后台保存
                                            autoSaveAtt('dataRequire', value);
                                        }
                                    }
                                },]
                            },
                            documentPassGrid
                        // {
                        //     html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">所需资料上传</div>'
                        // }, {
                        //     xtype: 'panel',
                        //     title: '',
                        //     defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        //     items: [{
                        //         xtype: 'textarea',
                        //         fieldLabel: ProcessDataText,
                        //         name: 'ProcessData',
                        //         id: 'ProcessData',
                        //         disabled: disableNode(dReplenishDate_node),
                        //         disabledCls: 'none',
                        //         width: 500,
                        //         listeners: {
                        //             blur: function (e) {
                        //                 var value = Ext.getCmp('ProcessData').getValue();
                        //                 //触发后台保存
                        //                 autoSaveAtt('ProcessData', value);
                        //             }
                        //         }
                        //     },]
                        // },
                        /*{
                            html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">生产记录</div>'
                        }, {//第七行
                            xtype: 'panel',
                            title: '',
                            defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                            items: [{
                                xtype: 'textarea',
                                fieldLabel: productionRecordText,
                                name: 'productionRecord',
                                id: 'productionRecord',
                                disabled: disableNode(dReplenishDate_node),
                                disabledCls: 'none',
                                width: 500,
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('productionRecord').getValue();
                                        //触发后台保存
                                        autoSaveAtt('productionRecord', value);
                                    }
                                }
                            }]
                        }*/]
                    },
                    {//第九行
                        xtype: 'panel',
                        collapsible: true,
                        title: '6.认证证书归档',
                        defaults: {margin: '5 20 5 5', labelWidth: 100},
                        items: [, {
                            xtype: 'button',
                            labelWidth: 150,
                            text: "存储库跳转",
                            handler: function () {
                                window.open("http://plm.fhsjdz.com/Windchill/app/#ptc1/tcomp/infoPage?ContainerOid=OR%3Awt.inf.library.WTLibrary%3A7132983&oid=OR%3Awt.folder.Cabinet%3A7133017&u8=1")
                                //window.open("http://plmdemo.fhsj.com:8885/Windchill/app/#ptc1/library/listFiles?ContainerOid=OR%3Awt.inf.library.WTLibrary%3A10721428&oid=OR%3Awt.folder.Cabinet%3A10721462&folderNavigatorParameter=true&u8=1")
                            }
                        }, {
                            xtype: 'textfield',
                            labelWidth: 170,
                            fieldLabel: certfNumberText,
                            disabled: disableNode(certificationDoc_node) ? disableNode(certificationCheckDoc_node) : false,
                            disabledCls: 'none',
                            name: 'certfNumber1',
                            id: 'certfNumber1',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('certfNumber1').getValue();
                                    //触发后台保存
                                    getCertfLink(value, "证书");
                                }
                            }
                        }, {
                            xtype: 'displayfield',
                            labelWidth: 170,
                            fieldLabel: "检验报告/证书系统文档链接",
                            disabled: true,
                            disabledCls: 'none',
                            name: 'certfNumberLink1',
                            id: 'certfNumberLink1',
                            width: 500,
                        }, {
                            xtype: 'textarea',
                            fieldLabel: certfArchiveRemarkText,
                            name: 'certfArchiveRemark',
                            id: 'certfArchiveRemark',
                            disabled: disableNode(certificationDoc_node) ? disableNode(certificationCheckDoc_node) : false,
                            disabledCls: 'none',
                            width: 500,
                            listeners: {
                                blur: function () {
                                    var value = Ext.getCmp('certfArchiveRemark').getValue();
                                    //触发后台保存
                                    autoSaveAtt('certfArchiveRemark', value);
                                }
                            }
                        }],
                    },
                    {//第六行
                        xtype: 'panel',
                        title: '7.生产资料再确认',
                        collapsible: true,
                        defaults: {margin: '5 20 5 5', labelWidth: 100},
                        items: [{
                            xtype: 'radiogroup',
                            labelWidth: 100,
                            disabled: disableNode(dateReconfirm_node),
                            disabledCls: 'none',
                            fieldLabel: isDataSaveText,
                            name: 'isDataSave',
                            id: 'isDataSave',
                            width: 250,
                            columns: 2,
                            items: [
                                {boxLabel: '有', name: 'dataSave', inputValue: '有', disabledCls: 'none'},
                                {boxLabel: '无', name: 'dataSave', inputValue: '无', disabledCls: 'none'},
                            ],
                            listeners: {
                                change: function (field, newValue, oldValue) {
                                    if (!ght_dataLoadedFlag) {
                                        //阻止加载时执行后台保存
                                        return;
                                    }
                                    //触发后台保存
                                    var data = newValue.dataSave;
                                    if (data == '有') {
                                        Ext.getCmp("ECRNumber").setDisabled(false);
                                    } else {
                                        Ext.getCmp("ECRNumber").setDisabled(true);
                                    }
                                    autoSaveAtt('dataSave', data);
                                }
                            }
                        }, {
                            xtype: 'textarea',
                            fieldLabel: ECRNumberText,
                            name: 'ECRNumber',
                            id: 'ECRNumber',
                            disabled: true,
                            disabledCls: 'none',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('ECRNumber').getValue();
                                    //触发后台保存
                                    autoSaveAtt('ECRNumber', value);
                                }
                            }
                        },/* {
                            xtype: 'textarea',
                            fieldLabel: revisionDocNumberText,
                            name: 'revisionDocNumber',
                            id: 'revisionDocNumber',
                            disabled: disableNode(dateReconfirm_node),
                            disabledCls: 'none',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('revisionDocNumber').getValue();
                                    //触发后台保存
                                    autoSaveAtt('revisionDocNumber', value);
                                }
                            }
                        }, {
                            xtype: 'textarea',
                            fieldLabel: productionDataRemarkText,
                            name: 'productionDataRemark',
                            id: 'productionDataRemark',
                            disabled: disableNode(dateReconfirm_node),
                            disabledCls: 'none',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('productionDataRemark').getValue();
                                    //触发后台保存
                                    autoSaveAtt('productionDataRemark', value);
                                }
                            }
                        }*/]
                    },],
            },

        ];

        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            if (!disableNode(submit_node) || !disableNode(mDateCollect_node) || !disableNode(mInDateCollect_node)
                || !disableNode(mDateUpdate_node) || !disableNode(submit_node) || !disableNode(resubmit_node)
                || !disableNode(hasConfirmationData_node) || !disableNode(isDate_node) || !disableNode(createBaseline_node) ) {
                Ext.getCmp("head_uploadFile").show();

            }
            if (!disableNode(submit_node) || !disableNode(mDateCollect_node) || !disableNode(mInDateCollect_node)
                || !disableNode(mDateUpdate_node) || !disableNode(submit_node) || !disableNode(resubmit_node)
                || !disableNode(hasConfirmationData_node) || !disableNode(isDate_node) || !disableNode(dateCollect_node) || !disableNode(createBaseline_node) ) {
                Ext.getCmp("head_uploadFile1").show();

            }
            if (!disableNode(submit_node) || !disableNode(mDateCollect_node) || !disableNode(mInDateCollect_node)
                || !disableNode(mDateUpdate_node) || !disableNode(submit_node) || !disableNode(resubmit_node)
                || !disableNode(dateCollect_node) || !disableNode(hasConfirmationData_node) || !disableNode(isDate_node) || !disableNode(createBaseline_node) ) {

                Ext.getCmp("head_uploadScanSkillFile").show();
            }

            if (!disableNode(dReplenishDate_node) || !disableNode(certificationCheckDoc_node) || !disableNode(certificationDoc_node) || !disableNode(dateAudit_node)) {
                Ext.getCmp("head_uploadFile2").show();
            }

            Ext.getStore('itemStore').load({

                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            Ext.getStore('fileItemStore').load({

                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            // 查询form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/certf/getCertfApplyForm?certfId=' + certfId,
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        var mainPanel1 = Ext.getCmp('mainForm1');
                        mainPanel.getForm().setValues(obj);
                        mainPanel1.getForm().setValues(obj);
                        ght_dataLoadedFlag = true;
                    } else {
                        alert(obj['msg']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }


    }

});
