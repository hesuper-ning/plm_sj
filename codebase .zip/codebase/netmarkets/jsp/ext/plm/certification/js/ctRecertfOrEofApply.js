/**
 * 认证产品续证、退市申请表
 */
Ext.define('PLM.view.recertfOrEofApply', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.recertfOrEofApply',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">认证产品续证、退市申请表</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',

    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;


        //========可编辑列头显示控制============
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';

        //提交
        var productTypeText = '产品型号';
        var certfNumberText = '证书/检验报告编号';
        var productNameText = '产品名称';
        var productLineText = '所属产品线';
        var backgroundText = '发起背景';
        var certfTypeText = '认证/检验类型';
        var certfDueDateText = '证书/报告到期时间';
        var reasonText = '发起原因';


        //开发代表完善信息
        var finishedMaterialCodeText = '成品物料代码';
        var semiMaterialCodeText = '半成品物料代码';
        var specialMaterialCodeText = '专用物料代码';
        var typeText = '型号';

        //销售完善销售数据
        var topOneYearText = '当前年';
        var topTwoYearText = '前一年';
        var topThreeYearText = '前两年';
        var totalText = '合计';
        var countText = '未履行销售订单产品数量';

        //采购完善供应商信息
        var supplierInventoryText = '供应商库存';

        //PDT经理
        var recertfPersonOrEofPersonText = '续证/退市流程发起人';
        var recertfOrEofText = '续证/退市结论';
        var whetherRenewCertificateText = '是否续证';
        var renewalProcessPersonText = '续证流程发起人';
        var whetherDelistedText = '是否退市';
        var delistingProcessPersonText = '退市流程发起人';

        //确认待停用的成品
        var isDelistText = '是否退市停用';

        if (allowEdit) {
            //提交时可填与必填项提示
            if ("rSubmit_node" == currentActKey) {
                productTypeText = redStarFlag + blueFlagStart + productTypeText + blueFlagEnd;
                certfNumberText = redStarFlag + blueFlagStart + certfNumberText + blueFlagEnd;
                productNameText = redStarFlag + blueFlagStart + productNameText + blueFlagEnd;
                productLineText = redStarFlag + blueFlagStart + productLineText + blueFlagEnd;
                backgroundText = redStarFlag + blueFlagStart + backgroundText + blueFlagEnd;
                certfTypeText = blueFlagStart + certfTypeText + blueFlagEnd;
                certfDueDateText = blueFlagStart + certfDueDateText + blueFlagEnd;
                reasonText = blueFlagStart + reasonText + blueFlagEnd;
            } else if ("exploit_node" == currentActKey) {
                finishedMaterialCodeText = redStarFlag + blueFlagStart + finishedMaterialCodeText + blueFlagEnd;
                semiMaterialCodeText = redStarFlag + blueFlagStart + semiMaterialCodeText + blueFlagEnd;
                specialMaterialCodeText = redStarFlag + blueFlagStart + specialMaterialCodeText + blueFlagEnd;
            } else if ("sell_node" == currentActKey) {
                topOneYearText = redStarFlag + blueFlagStart + topOneYearText + blueFlagEnd;
                topTwoYearText = redStarFlag + blueFlagStart + topTwoYearText + blueFlagEnd;
                topThreeYearText = redStarFlag + blueFlagStart + topThreeYearText + blueFlagEnd;
                totalText = redStarFlag + blueFlagStart + totalText + blueFlagEnd;
                countText = redStarFlag + blueFlagStart + countText + blueFlagEnd;
            } else if ("purchase_node" == currentActKey) {
                supplierInventoryText = redStarFlag + blueFlagStart + supplierInventoryText + blueFlagEnd;
            } else if ("PDTManager_node" == currentActKey) {
                recertfPersonOrEofPersonText = redStarFlag + blueFlagStart + recertfPersonOrEofPersonText + blueFlagEnd;
                recertfOrEofText = redStarFlag + blueFlagStart + recertfOrEofText + blueFlagEnd;
                whetherRenewCertificateText = blueFlagStart + whetherRenewCertificateText + blueFlagEnd;
                renewalProcessPersonText = blueFlagStart + renewalProcessPersonText + blueFlagEnd;
                whetherDelistedText = blueFlagStart + whetherDelistedText + blueFlagEnd;
                delistingProcessPersonText = blueFlagStart + delistingProcessPersonText + blueFlagEnd;
            } else if ("confirmPart_node" == currentActKey) {
                finishedMaterialCodeText = redStarFlag + blueFlagStart + finishedMaterialCodeText + blueFlagEnd;
                semiMaterialCodeText = redStarFlag + blueFlagStart + semiMaterialCodeText + blueFlagEnd;
                specialMaterialCodeText = redStarFlag + blueFlagStart + specialMaterialCodeText + blueFlagEnd;
                isDelistText = redStarFlag + blueFlagStart + isDelistText + blueFlagEnd;
            }

        }

        //导入panel
        var uploadForm1 = new Ext.form.Panel({
            layout: 'form',
            id: 'uploadForm1',
            name: 'uploadForm1',
            width: 450,
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            border: 0,
            tbar: [{
                xtype: 'filefield',
                name: 'recertfAssessFile1',
                id: 'recertfAssessFile1',
                msgTarget: 'side',
                fieldLabel: '上传Excel文件',
                width: 280,
                anchor: '100%',
                buttonText: '选择文件..',
                buttonOnly: false,
                buttonMargin: '5 5 5 5'
            }, {
                xtype: 'button',
                padding: '5 5 5 5',
                id: 'technic_submit1',
                //disabled: existManufacturingViewPart?false:true,
                text: '开始导入',
                handler: function () {
                    var mainForm = Ext.getCmp('uploadForm1').getForm();
                    var furl = "";  //文件物理地址
                    var fname = ""; //文件名称
                    furl = Ext.getCmp("recertfAssessFile1").getValue();
                    //alert(furl);
                    if (furl == "") {
                        alert("请先选择文件！");
                        return false;
                    }

                    mainForm.submit({
                        url: '/Windchill/ptc1/recertf/importRecertfAssess?proOid=' + branchId + '&oid=' + oid + '&activityName=' + actName + '&number=' + 1,
                        waitMsg: '正在导入......',
                        waitTitle: '请等待',
                        // method : 'POST',
                        success: function (form, action) {
                            var obj = action.result;
                            if (obj.success) {
                                alert(obj.msg);
                                Ext.getStore('recertfOrEofSpecialItemStore').reload();
                            } else {
                                alert(obj.msg);
                                Ext.getStore('recertfOrEofSpecialItemStore').reload();
                            }
                            uploadPlanWindow1.close();
                        },
                        failure: function (form, action) {
                            var obj = action.result;
                            alert(obj.msg);
                        },
                        scope: this
                    });
                }
            }]
        });
        //导入窗口
        var uploadPlanWindow1 = new Ext.create('Ext.Window', {
            title: '导入',
            // width: 430,
            autoHeight: true,
            autoWidth: true,
            closeAction: 'hidden',
            y: '10%',
            id: 'uploadProblemWindow1',
            constrain: true,
            modal: true,
            layout: 'fit',
            //border : 0,
            items: uploadForm1
        });


        Ext.define('itemGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'branchId', 'productType', 'certfNumber', 'productName', 'background',
                'productLine', 'certfType', 'certfDueDate', 'recertfOrEof', 'recertfPersonOrEofPerson',
            'whetherRenewCertificate', 'renewalProcessPerson', 'whetherDelisted', 'delistingProcessPerson'],
            idProperty: 'id'
        });

        Ext.define('specialItemGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'branchId', 'specialMaterialCode', 'supplierInventory', 'materialName', 'unit', 'transitOrder',
                'inventory','stopUsingDocNumber', 'stopUsingDocState'],
            idProperty: 'id'
        });


        Ext.define('finishedItemGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'branchId', 'finishedMaterialCode', 'supplierInventory', 'materialName', 'unit', 'inventory',
                'salesData', 'orderNumber', 'count', 'topOneYear', 'topTwoYear', 'topThreeYear', 'total', 'productType',
            'stopUsingDocNumber', 'stopUsingDocState'],
            idProperty: 'id'
        });


        var recertfOrEofItemStore = Ext.create('Ext.data.Store', {
            id: 'recertfOrEofItemStore',
            model: 'itemGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/recertf/getItemByBranchId?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'item',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var recertfOrEofSpecialItemStore = Ext.create('Ext.data.Store', {
            id: 'recertfOrEofSpecialItemStore',
            model: 'specialItemGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/recertf/getSpecialItemByBranchId?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'item',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });


        var recertfOrEofFinishedItemStore = Ext.create('Ext.data.Store', {
            id: 'recertfOrEofFinishedItemStore',
            model: 'finishedItemGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/recertf/getFinishItemByBranchId?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'item',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var productLines = new Ext.form.ComboBox({
            name: 'productLines',
            id: 'productLines',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//火报/ 应急疏散/防火门/电气火灾&消防设备电源监控/物联网家报/海外火报
            store: [['火报', '火报'], ['应急疏散', '应急疏散'], ['防火门', '防火门'],
                ['电气火灾&消防设备电源监控', '电气火灾&消防设备电源监控'], ['物联网家报', '物联网家报'],
                ['海外火报', '海外火报']
            ]
        });


        var conclusion = new Ext.form.ComboBox({
            name: 'conclusion',
            id: 'conclusion',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['续证', '续证'], ['退市', '退市']]
        });

        var renewCertificate = new Ext.form.ComboBox({
            name: 'renewCertificate',
            id: 'renewCertificate',
            multiSelect: false,
            valueField: 'renewCertificate',
            displayField: 'renewCertificate',
            anyMatch: true,
            editable: false,
            store: [['是', '是'], ['否', '否']]
        });

        var delisted = new Ext.form.ComboBox({
            name: 'delisted',
            id: 'delisted',
            multiSelect: false,
            valueField: 'delisted',
            displayField: 'delisted',
            anyMatch: true,
            editable: false,
            store: [['是', '是'], ['否', '否']]
        });

        var backgroundComb = new Ext.form.ComboBox({
            name: 'backgroundComb',
            id: 'backgroundComb',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['证书到期', '证书到期'], ['其他原因', '其他原因']]
        });

        var isRecertf = new Ext.form.ComboBox({
            name: 'isRecertf',
            id: 'isRecertf',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['是', '是'], ['否', '否']]
        });

        var numberStore = new Ext.data.ArrayStore({
            id: 'numberStore',
            fields: ['displayText'],
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/recertf/getCertificateNumber',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });
        numberStore.on('beforeload', function (store, options) {
            let selectionArr = recertfOrEofItemGrid.getSelectionModel().getSelection();
            if (selectionArr.length == 1) {
                var id = selectionArr[0].data['id']
                //getType(type);
                var data = {
                    id:id
                };
                Ext.apply(typeStore.proxy.extraParams, data);
            }else {
                return;
            }

        });


        var numbers = new Ext.form.ComboBox({
            name: 'numbers',
            id: 'numbers',
            multiSelect: false,
            valueField: 'displayText',
            displayField: 'displayText',
            anyMatch: true,
            editable: true,
            store: numberStore
        });


        //认证类型
        var typeStore = new Ext.data.ArrayStore({
            id: 'typeStore',
            fields: ['displayText','certificateType'],
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/recertf/getType',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });
        typeStore.on('beforeload', function (store, options) {
            let selectionArr = recertfOrEofItemGrid.getSelectionModel().getSelection();
            if (selectionArr.length == 1) {
                var type = selectionArr[0].data['productType']
                //getType(type);
                var data = {
                    type:type
                };
                Ext.apply(typeStore.proxy.extraParams, data);
            }else {
                return;
            }

        });

        var types = new Ext.form.ComboBox({
            name: 'types',
            id: 'types',
            multiSelect: false,
            valueField: 'certificateType',
            displayField: 'displayText',
            anyMatch: true,
            editable: true,
            store: typeStore
        });


        var endDateStore = new Ext.data.ArrayStore({
            id: 'endDateStore',
            fields: ['displayText'],
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/recertf/endDateStore',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });

        var certfStore = new Ext.data.ArrayStore({
            id: 'certfStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/certf/getAllCertificateInfo',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });
        var productNameStore = new Ext.data.ArrayStore({
            id: 'productNameStore',
            fields: ['displayText'],
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/recertf/productNameStore',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });

        var endDates = new Ext.form.ComboBox({
            name: 'endDates',
            id: 'endDates',
            multiSelect: false,
            valueField: 'displayText',
            displayField: 'displayText',
            anyMatch: true,
            editable: true,
            store: endDateStore
        });
        var productNames = new Ext.form.ComboBox({
            name: 'productNames',
            id: 'productNames',
            multiSelect: false,
            valueField: 'displayText',
            displayField: 'displayText',
            forceSelection: true,//forceSelection 是否能够手填
            anyMatch: true,
            editable: true,
            store: productNameStore
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });
        var allUserCombo_projectPlan = Ext.create('PLM.common.CtAllUserCombo', {
            store: allUserStore_projectPlan
        });

        var userCombo = new Ext.form.ComboBox({
            typeAhead: false,
            store: allUserStore_projectPlan,
            triggerAction: 'all',
            name: 'report_createUser',
            id: 'report_createUser',
            editable: true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 250,
            labelWidth: 100,
            selectOnFocus: true,
            forceSelection: true,
            valueField: 'userFullName',
            displayField: 'userFullName'
        });


        var recertfOrEofItemGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('recertfOrEofItemStore'),
            id: 'recertfOrEofItemGrid',
            margin: '10 0 20 0',
            sortableColumns:false,
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            //autoScroll: false,
            //region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer',width:40},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: productTypeText, dataIndex: 'productType', width: 80, editor: 'textfield'},
                {text: certfTypeText, dataIndex: 'certfType', width: 160, editor: types,
                    renderer: function (value) {
                        if (value != null) {
                            return value.toString().split(',')[0];
                        }
                        return value;
                    }
                },
                {text: productLineText, dataIndex: 'productLine', width: 100, editor: productLines},
                {text: productNameText, dataIndex: 'productName', width: 100, editor: productNames},
                {text: certfNumberText, dataIndex: 'certfNumber', width: 180, editor: numbers,},
                {text: certfDueDateText, dataIndex: 'certfDueDate', width: 160, editor: endDates},
                {text: backgroundText, dataIndex: 'background', width: 100, editor: backgroundComb},
                {text: reasonText, dataIndex: 'reason', width: 140, editor: 'textfield'},
                // {text: recertfOrEofText, dataIndex: 'recertfOrEof', width: 140, editor: conclusion},
                // {
                //     text: recertfPersonOrEofPersonText,
                //     dataIndex: 'recertfPersonOrEofPerson',
                //     width: 140,
                //     editor: userCombo
                // },
                {
                    text: '续证结论',menuDisabled: true,
                    columns: [
                        {text: whetherRenewCertificateText, dataIndex: 'whetherRenewCertificate', width: 100, editor: renewCertificate},
                        {
                            text: renewalProcessPersonText,
                            dataIndex: 'renewalProcessPerson',
                            width: 140,
                            editor: userCombo
                        }
                    ]
                },
                {
                    text: '退市结论',menuDisabled: true,
                    columns: [
                        {text: whetherDelistedText, dataIndex: 'whetherDelisted', width: 100, editor: delisted},
                        {
                            text: delistingProcessPersonText,
                            dataIndex: 'delistingProcessPerson',
                            width: 140,
                            editor: userCombo
                        }
                    ]
                }
            ],
            tbar: [
                {
                text: '新增',
                id: 'add',
                iconCls: 'icon-add',
                name: 'add',
                hidden: disableNode(rSubmit_node),
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('recertfOrEofItemStore').reload()
                    }
                    //Ext.getStore('certfStore').reload()
                    createMockItemData('ZRecertfOrEofItem', callbackFn);
                }
            }, {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                hidden: disableNode(rSubmit_node),
                handler: function () {
                    let selectionArr = recertfOrEofItemGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('recertfOrEofItemStore').reload()
                    };
                    deleteData('ZRecertfOrEofItem', obj, callbackFn);
                }
            }],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列
                    var tRecord = e.record; //得到当前行所有数据
                    debugger
                    if (!disableNode(rSubmit_node)) {
                        if (tField == 'recertfOrEof' || tField == 'recertfPersonOrEofPerson'
                            || tField == 'whetherRenewCertificate'|| tField == 'renewalProcessPerson'
                            || tField == 'whetherDelisted'|| tField == 'delistingProcessPerson') {
                            return false;
                        } else {
                            if (tField == 'productType' && (tRecord.get('productType') != '' || tRecord.get('productType') != undefined)) {
                                getType(tRecord.get('productType'));

                            } else if (tField == 'certfNumber') {
                                if (tRecord.get('certfType') == undefined) {
                                    alert("请先填写认证/检验类型")
                                    return false;
                                }else {
                                    getCertificateNumber(tRecord.get('id'));
                                }
                            } else if (tField == 'certfType') {

                                if (tRecord.get('productType') == undefined) {
                                    alert("请先填写产品型号")
                                    return false;
                                }else {
                                    getType(tRecord.get('productType'));
                                }

                                if (tRecord.get('certfType')!=undefined && tRecord.get('certfType')!="NA") {
                                    getProductName(tRecord.get('id'));
                                    getCertificateNumber(tRecord.get('id'));
                                    getEndDate(tRecord.get('id'));
                                }else {
                                    productNameStore.removeAll()
                                    numberStore.removeAll()
                                    endDateStore.removeAll()
                                }


                            } else if (tField == 'certfDueDate') {
                                if (tRecord.get('certfType') == undefined) {
                                    alert("请先填写认证/检验类型")
                                    return false;
                                }else {
                                    getEndDate(tRecord.get('id'));
                                }

                            } else if (tField == 'productName') {
                                if (tRecord.get('productType') == undefined) {
                                    alert("请先填写产品型号")
                                    return false;
                                }else {
                                    getProductName(tRecord.get('id'));
                                }
                            }

                            return true;
                        }
                    }
                    if (!disableNode(PDTManager_node)) {
                        if (tField == 'recertfOrEof' || tField == 'recertfPersonOrEofPerson' || tField == 'whetherRenewCertificate'|| tField == 'renewalProcessPerson'
                            || tField == 'whetherDelisted'|| tField == 'delistingProcessPerson'
                        ) {
                            return true;
                        } else {
                            return false;
                        }
                    }


                    return false;
                },

            }
        });

        var cellEditing_s1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var recertfOrEofSpecialItemGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing_s1],
            store: Ext.getStore('recertfOrEofSpecialItemStore'),
            id: 'recertfOrEofSpecialItemGrid',
            margin: '0 20 10 0',
            //forceFit: true,
            autoWidth: true,
            sortableColumns:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer',width:40},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: specialMaterialCodeText, dataIndex: 'specialMaterialCode', width: 130, editor: 'textfield',},
                {text: '物料名称', dataIndex: 'materialName', width: 150, editor: 'textfield',},
                {text: '单位', dataIndex: 'unit', width: 100,},
                {text: 'SAP库存', dataIndex: 'inventory', width: 100, editor: 'textfield'},
                {text: '在途订单物料数量', dataIndex: 'count', width: 150, editor: 'textfield'},
                {text: supplierInventoryText, dataIndex: 'supplierInventory', width: 100, editor: 'textfield'},
                {text: isDelistText, dataIndex: 'isDelist', width: 100, editor: isRecertf},
                {
                    text: '停用追踪文档编号', dataIndex: 'stopUsingDocNumber', width: 200, editor: 'textfield',
                    renderer: function(value,metaData,record,row,col,store){
                        if(record.get('stopUsingDocUrl')) {
                            var changeLink = record.get('stopUsingDocUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '停用追踪文档状态', dataIndex: 'stopUsingDocState', width: 200, editor: 'textfield'},
            ],
            tbar: [{
                text: '新增',
                id: 'add1',
                iconCls: 'icon-add',
                name: 'add1',
                hidden: disableNode(exploit_node),
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('recertfOrEofSpecialItemStore').reload()
                    }
                    createMockItemData('ZRecertfOrEofSpecialItem', callbackFn);
                }
            }, {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                hidden: disableNode(exploit_node),
                handler: function () {
                    let selectionArr = recertfOrEofSpecialItemGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('recertfOrEofSpecialItemStore').reload()
                    };
                    deleteData('ZRecertfOrEofSpecialItem', obj, callbackFn);
                }
            }, {

                iconCls: 'icon-download ',
                xtype: 'button',
                id: "downTemplate",
                text: '下载模板',
                hidden: disableNode(exploit_node),
                handler: function () {
                    window.open('/Windchill/template/退市续证物料导入模板.xlsx', '', 'width=300,height=200');
                }
            }, {
                text: 'Excel导入',
                hidden: false,
                iconCls: 'icon-excelImport',
                xtype: 'button',
                id: "excelInputData1",
                hidden: disableNode(exploit_node),
                handler: function () {
                    uploadPlanWindow1.show();
                },
            }],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if(tField == 'stopUsingDocNumber' || tField == 'stopUsingDocState'){
                        return false;
                    }

                    if (!disableNode(exploit_node)) {
                        if (tField != 'specialMaterialCode') {
                            return false;
                        } else {
                            return true
                        }
                    }
                    if (!disableNode(purchase_node)) {
                        if (tField != 'supplierInventory') {
                            return false;
                        } else {
                            return true
                        }
                    }
                    if (!disableNode(confirmPart_node)) {
                        if (tField == 'isDelist' || tField == 'specialMaterialCode') {
                            return true;
                        } else {
                            return false
                        }
                    }

                    return false;
                },
            }
        });

        var cellEditing_s2 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var recertfOrEofFinishedItemGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing_s2],
            store: Ext.getStore('recertfOrEofFinishedItemStore'),
            id: 'recertfOrEofFinishedItemGrid',
            margin: '0 20 0 0',
            //forceFit: true,
            autoWidth: true,
            sortableColumns:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer',width:40},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: finishedMaterialCodeText, dataIndex: 'finishedMaterialCode', menuDisabled: true, width: 150, editor: 'textfield',},
                {text: typeText, dataIndex: 'productType', menuDisabled: true, width: 100},
                {text: '物料名称', dataIndex: 'materialName', menuDisabled: true, width: 120},
                {text: '单位', dataIndex: 'unit', width: 100, menuDisabled: true},
                {text: 'SAP库存', dataIndex: 'inventory', width: 100, editor: 'textfield', menuDisabled: true},
                {text: 'SAP在制品数量', dataIndex: 'wipCount', width: 150, menuDisabled: true, editor: 'textfield'},
                {text: supplierInventoryText, dataIndex: 'supplierInventory', width: 100, menuDisabled: true, editor: 'textfield'},
                {
                    text: '近三年销量数据：',
                    columns: [
                        {text: topThreeYearText, dataIndex: 'topThreeYear', width: 100, menuDisabled: true, editor: 'numberfield'},
                        {text: topTwoYearText, dataIndex: 'topTwoYear', width: 100, menuDisabled: true, editor: 'numberfield'},
                        {text: topOneYearText, dataIndex: 'topOneYear', width: 100, menuDisabled: true, editor: 'numberfield'},
                        {text: totalText, dataIndex: 'total', width: 100, menuDisabled: true},
                    ]
                },
                {text: countText, dataIndex: 'count', width: 180, menuDisabled: true, editor: 'textfield'},
                {text: isDelistText, dataIndex: 'isDelist', width: 120, menuDisabled: true, editor: isRecertf},
                {
                    text: '停用追踪文档编号', dataIndex: 'stopUsingDocNumber', width: 200, menuDisabled: true, editor: 'textfield',
                    renderer: function(value,metaData,record,row,col,store){
                        if(record.get('stopUsingDocUrl')) {
                            var changeLink = record.get('stopUsingDocUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '停用追踪文档状态', dataIndex: 'stopUsingDocState', width: 200, menuDisabled: true, editor: 'textfield'},
            ], tbar: [{
                text: '新增',
                id: 'add3',
                iconCls: 'icon-add',
                name: 'add3',
                hidden: disableNode(exploit_node),
                handler: function () {

                    var callbackFn = function () {
                        Ext.getStore('recertfOrEofFinishedItemStore').reload()
                    }
                    createMockItemData('ZRecertfOrEofFinishedItem', callbackFn);
                }
            }, {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                hidden: disableNode(exploit_node),
                handler: function () {
                    let selectionArr = recertfOrEofFinishedItemGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('recertfOrEofFinishedItemStore').reload()
                    };
                    deleteData('ZRecertfOrEofFinishedItem', obj, callbackFn);
                }
            }],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    //“停用追踪文档编号”、“停用追踪文档状态”不可编辑
                    if(tField == 'stopUsingDocNumber' || tField == 'stopUsingDocState'){
                        return false;
                    }

                    if (!disableNode(exploit_node)) {
                        if (tField != 'finishedMaterialCode') {
                            return false;
                        } else {
                            return true;
                        }
                    }
                    if (!disableNode(purchase_node)) {
                        if (tField != 'supplierInventory') {
                            return false;
                        } else {
                            return true;
                        }
                    }
                    if (!disableNode(confirmPart_node)) {
                        if (tField == 'finishedMaterialCode' || tField == 'isDelist') {
                            return true;
                        } else {
                            return false;
                        }
                    }
                    if (!disableNode(sell_node)) {
                        if (tField == 'topThreeYear' || tField == 'topTwoYear' || tField == 'topOneYear' ||
                            tField == 'total' || tField == 'count') {
                            return true;
                        } else {
                            return false;
                        }
                    }
                    return false;
                },
            }
        });


        recertfOrEofItemGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');
                //debugger
               /* if (tField == 'productType' && (tRecord.get('productType') != '' || tRecord.get('productType') != undefined)) {
                    getType(tRecord.get('productType'));

                }

                if (tField == 'certfNumber') {
                    if (tRecord.get('certfType') == undefined) {
                        alert("请先填写认证/检验类型")
                        return false;
                    }else {

                    }
                } else if (tField == 'certfType') {
                    if (tRecord.get('productType') == undefined) {
                        alert("请先填写产品型号")
                        return false;
                    }


                    if (tRecord.get('certfType')!=undefined && tRecord.get('certfType')!="NA") {
                        saveMockItemData('ZRecertfOrEofItem', itemId, tField, tValue, callbackFn);
                        getProductName(tRecord.get('id'));
                        getCertificateNumber(tRecord.get('id'));
                        getEndDate(tRecord.get('id'));
                    }


                } else if (tField == 'certfDueDate') {
                    if (tRecord.get('certfType') == undefined) {
                        alert("请先填写认证/检验类型")
                        return false;
                    }

                } else if (tField == 'productName') {
                    if (tRecord.get('productType') == undefined) {
                        alert("请先填写产品型号")
                        return false;
                    }
                }
*/
                var callbackFn = function () {
                    if (tField == 'productType' && (tRecord.get('productType') != '' || tRecord.get('productType') != undefined)) {
                        getType(tRecord.get('productType'));

                    }
                    if (tField == 'certfType') {
                        if (tRecord.get('certfType') != undefined && tRecord.get('certfType') != "NA") {
                            getProductName(tRecord.get('id'));
                            getCertificateNumber(tRecord.get('id'));
                            getEndDate(tRecord.get('id'));
                        }
                    }
                    if (tField == 'recertfOrEof'){
                        Ext.getStore('recertfOrEofFinishedItemStore').reload()
                    }
                    Ext.getStore('recertfOrEofItemStore').reload()

                    //tRecord.commit();
                };
                saveMockItemData('ZRecertfOrEofItem', itemId, tField, tValue, callbackFn);
            });

        recertfOrEofSpecialItemGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    Ext.getStore('recertfOrEofSpecialItemStore').reload()
                    //tRecord.commit();
                };
                saveMockItemData('ZRecertfOrEofSpecialItem', itemId, tField, tValue, callbackFn);

            });

        recertfOrEofFinishedItemGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    Ext.getStore('recertfOrEofFinishedItemStore').reload()
                    //tRecord.commit();
                };
                saveMockItemData('ZRecertfOrEofFinishedItem', itemId, tField, tValue, callbackFn);
            });


        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
            },
            items: [{
                html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">1. 申请人填写</div>'
            }, {//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 5 0 20', labelWidth: 80},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '需求申请人',
                    name: 'userName',
                    id: 'userName',
                    width: 200,
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '需求部门',
                    name: 'department',
                    id: 'department',
                    width: 200,
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '申请日期 ',
                    name: 'applyDate',
                    id: 'applyDate',
                    width: 200,
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '续证退市文档编号',
                    name: 'documentId',
                    id: 'documentId',
                    labelWidth: 120,
                    width: 200,
                }]
            }, recertfOrEofItemGrid,
            ]//~end of hbox items
        },//~end of 测试项目

            {
                xtype: 'form',
                id: 'mainForm1',
                //padding:'5',
                anchor: '99%',
                border: false,
                items: [{
                    html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">2. 其他人员填写</div>'
                }, {
                    html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">2.1 成品数据</div>'
                }, recertfOrEofFinishedItemGrid, {
                    html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">2.2 仅供以上成品使用的原材料及半成品</div>'
                }, recertfOrEofSpecialItemGrid,/* {
                    html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">2.3 半成品物料数据</div>'
                }, recertfOrEofSemilItemGrid,*/ {//第六行
                    xtype: 'panel',
                    defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    items: [{
                        html: '<span>说明：<br/>' +
                            ' - 研发代表：负责填写专用物料代码及成品半成品料号；<br/>' +
                            ' - 市场代表：近三年销量数据 & 未履行销售订单数据；<br/>' +
                            ' - 采购代表：负责填写对应物料的库存；<span/>'
                    }]
                }],
            },

        ];

        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {

            Ext.getStore('recertfOrEofItemStore').load({

                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('recertfOrEofSpecialItemStore').load({

                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('recertfOrEofFinishedItemStore').load({

                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/certf/getRecertfForm?branchId=' + branchId,
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['msg']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request

        }
    }

});