//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//
var submit_node = 'submit_node';//提交
var resubmit_node = 'resubmit_node';//重新提交
var principal_node = 'principal_node';//项目负责人审核
var procurement_node = 'procurement_node';//采购主管审核
var engineer_node = 'engineer_node';//认证工程师审核
var PM_node = 'PM_node';//产品管理部经理审核
var mDateCollect_node = 'mDateCollect_node';//资料员送检资料收集
var mInDateCollect_node = 'mInDateCollect_node';//资料员送检资料再次收集
var dateCollect_node = 'dateCollect_node';//送检资料收集
var inDateCollect_node = 'inDateCollect_node';//发起人送检再次资料收集
var dateConfirm_node = 'dateConfirm_node';//送检资料确认
var issueDateReconfirm_node = 'issueDateReconfirm_node';//已发布\送检资料再确认
var isDate_node = 'isDate_node';//送检资料收集
var creationReport_node = 'creationReport_node';//认证工程师创建检验报告
var cReplenishDate_node = 'cReplenishDate_node';//工艺工程师获取证书补充资料
var pReplenishDate_node = 'pReplenishDate_node';//计划专员获取证书补充资料
var dateAudit_node = 'dateAudit_node';//认证工程师补充资料审核
var certificationDoc_node = 'certificationDoc_node';//认证工程师创建认证证书文档
var dateReconfirm_node = 'dateReconfirm_node';//生产资料再确认
var hasConfirmationData_node = 'hasConfirmationData_node';//发起人确认送检资料和是否有技术资料
var dReplenishDate_node = 'dReplenishDate_node';
var hasConfirmationReport_node = 'hasConfirmationReport_node';
var hasConfirmationDataReport_node = 'hasConfirmationDataReport_node';
var mDateUpdate_node = 'mDateUpdate_node';//资料员送检资料更新
var certificationCheckDoc_node = 'certificationCheckDoc_node';
var createBaseline_node = 'createBaseline_node'; //产品数据管理工程师创建技术资料基线
var supplementary_responsible_person_node = 'supplementary_responsible_person_node';//三江电子-认证流程-PDT经理指定资料补充负责人
var waiting_authentication_result_node = 'waiting_authentication_result_node';//三江电子-认证流程-认证工程师等待认证结果
//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ght_dataLoadedFlag = false;

/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */
function disableNode(formkey) {
    //return false;
    if (taskCompleted == 'true') {
        return true;
    } else {
        if (formkey == currentActKey) {
            return false;
        } else {
            return true;
        }
    }
};

//自动保存字段
function autoSaveAtt(attKey, attValue) {
    var data = {
        certfId: certfId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKey, //全局变量，当前活动key
        oid: oid
    };
    Ext.Ajax.request({
        scope: this,
        async: false,
        url: '/Windchill/ptc1/certf/autoSaveAtt',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {

            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName, itemId, dataKey, dataValue, callbackFn) {

    var returnItemId = undefined;
    var mockRec = {
        oid: oid,
        dbTableName: dbTableName,
        itemId: itemId,
        dataKey: dataKey,
        dataValue: dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/certf/saveItemData',
        params: {
            updateRecord: Ext.encode(mockRec)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}


/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(dbTableName, callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/certf/insertItemData',
        params: {
            oid: oid,
            dbTableName: dbTableName,
            certfId: certfId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                callbackFn();
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//删除grid信息
function deleteData(tableName, ids, callback) {
    //var myMask = new Ext.LoadMask(Ext.getBody(), {msg: "数据正在处理中，请稍后..."});
    // myMask.show();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/certf/deleteItemData',
        method: "POST",
        params: {
            oid: oid,
            data: Ext.encode(ids),
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['msg']);
                //myMask.hide();
            } else {
                //myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

//删除grid信息
function deleteData(tableName, ids, tagIds, callback) {
    //var myMask = new Ext.LoadMask(Ext.getBody(), {msg: "数据正在处理中，请稍后..."});
    // myMask.show();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/certf/deleteItemData',
        method: "POST",
        params: {
            oid: oid,
            branchId: certfId,
            data: Ext.encode(ids),
            tagIds: Ext.encode(tagIds),
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['msg']);
                //myMask.hide();
            } else {
                //myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}


/**
 * 获取部门信息
 */
function getDepartment(no) {
    Ext.Ajax.request({
        scope: this,
        async: false,
        method: "GET",
        url: '/Windchill/ptc1/hr/getDeptName',
        params: {
            no: no
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == "success") {
                Ext.getCmp("head_department").setValue(obj.data)
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：获取部门信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


/**
 * 查询产品型号
 */
function getProductType() {
    Ext.getStore('productTypeListStore').load({
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询问题信息失败，请联系管理员！');
            }
        }
    });
}


function uploadFile(file, path, type, node) {

    let selectionArr = fileItemGrid.getSelectionModel().getSelection();

    var productType = selectionArr[0].get("productType");
    // store.reload();
    if (productType == '' || productType == undefined) {
        alert("请先填写产品型号!");
        return;
    } else if (selectionArr.length == 0) {
        alert("添加附件失败，未选择添加附件对象!");
        return;
    } else if (selectionArr.length >= 2) {
        alert("不支持多行添加附件操作，请确认要添加的行");
        return;
    } else {

        var file = document.querySelector('[id=' + 'head_uploadFile' + '-button-fileInputEl]');
        var formData = new FormData();
        formData.append('head_uploadFile' + '-button-fileInputEl', file.files[0]);
        fb.reset();//清空表单的值
        var myMask = new Ext.LoadMask({
            msg: '正在上传，请稍候......',
            target: this.findParentByType('panel')
        });


        myMask.show();
        $.ajax({
            url: '/Windchill/ptc1/certf/uploadFiles?branchId=' + certfId + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + node + "&type=" + type,
            type: 'POST',
            cache: false,
            data: formData,
            processData: false,
            contentType: false
        }).done(function (res) {
            myMask.hide();
            var obj = Ext.decode(res);
            var success = obj['success'];
            var msg = obj['msg'];
            if (!success) {
                alert(msg);
            } else {
                var fileName = obj['fileName'];
                var filePath = obj['filePath'];
                var tRecord = fileItemGrid.getSelectionModel().getSelection()[0];
                var attachmentValue = tRecord.data[file];
                var attachmentPath = tRecord.data[path];
                if (attachmentValue != null && attachmentPath != '') {
                    fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                    filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                }
                tRecord.set(file, fileName);
                tRecord.set(path, filePath);
                var callbackFn = function () {
                    tRecord.commit();
                };
                var itemId = tRecord.get('id');
                saveMockItemData("ZMRSupplierDocInfo", itemId, file, fileName, callbackFn);
                saveMockItemData("ZMRSupplierDocInfo", itemId, path, filePath, callbackFn);

            }
            var callbackFn = function () {
                //tRecord.commit();
                Ext.getStore('fileItemGrid').reload();
            };
        }).fail(function (res) {
            myMask.hide();
            alert('上传失败！');
        });
    }
}

function deleteFilefield(branchId, fileName, tetx_name, node, type,id) {
    Ext.Msg.confirm('提示','确定要删除选中文件？',
        function(btn){
            if(btn =='yes'){
                deleteFile(branchId, fileName, tetx_name, node, type,id)
            }else{
                return;
            }
        },this);
}

//删除附件
function deleteFile(branchId, fileName, tetx_name, node, type,id) {


    var file = '';
    var path = '';
    if (taskCompleted == 'true') {
        return;
    }
    if (type == '申请文件' || type == 'applyFile') {
        if (!(!disableNode(submit_node) || !disableNode(mDateCollect_node) || !disableNode(mInDateCollect_node)
            || !disableNode(mDateUpdate_node) || !disableNode(submit_node) || !disableNode(resubmit_node)
            ||! disableNode(hasConfirmationData_node)||! disableNode(isDate_node)  || !disableNode(createBaseline_node) )){

            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'applyFile';
        path = 'applyFilePath';

    } else if (type == '技术文件（打印档）' || type == 'skillFile') {
        if (!(!disableNode(submit_node) || !disableNode(mDateCollect_node) || !disableNode(mInDateCollect_node)
            || !disableNode(mDateUpdate_node) || !disableNode(submit_node) || !disableNode(resubmit_node)
             ||! disableNode(hasConfirmationData_node)||! disableNode(isDate_node)|| !disableNode(dateCollect_node) || !disableNode(createBaseline_node) )){

            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'skillFile';
        path = 'skillFilePath';
    } else if (type == '技术文件（盖章扫描档）' || type == 'scanSkillFile') {
        if (!(!disableNode(submit_node) || !disableNode(mDateCollect_node) || !disableNode(mInDateCollect_node)
            || !disableNode(mDateUpdate_node) || !disableNode(submit_node) || !disableNode(resubmit_node)
            || !disableNode(dateCollect_node) ||! disableNode(hasConfirmationData_node)||! disableNode(isDate_node) || !disableNode(createBaseline_node) )){

            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'scanSkillFile';
        path = 'scanSkillFilePath';
    } else {
        if (!(!disableNode(dReplenishDate_node)||!disableNode(certificationCheckDoc_node)||!disableNode(certificationDoc_node)||!disableNode(dateAudit_node))){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'elseFile';
        path = 'elseFilePath';
    }


    // var myMask = new Ext.LoadMask({
    // 	msg: '正在删除，请稍候......',
    // 	target:Ext.getCmp('headPanel')
    // });
    // myMask.show();
    Ext.Ajax.request({
        scope: this,
        async: false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url: '/Windchill/ptc1/certf/deleteFiles',
        params: {
            branchId: branchId, fileName: fileName,type:type
        },
        success: function (response, opts) {
            // myMask.hide();
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if (!success) {
                alert(msg);
            } else {
                var tRecord = Ext.getCmp('fileItemGrid').getSelectionModel().getSelection()[0];
                if(tRecord != undefined){
                    id = tRecord.get("id");

                    tRecord.set(file, "");
                    tRecord.set(path, "");
                }

                /*var attachmentValue = tRecord.data[file];
                var attachmentPathValue = tRecord.data[path];
                var arr= new Array(); //定义一数组
                var arr1= new Array(); //定义一数组
                arr=attachmentValue.split("|"); //字符分割
                for (i=0;i<arr.length ;i++ ){
                    var index = arr[i].indexOf(fileName);
                    if (index > -1) {
                        arr.splice(i,1);// 删除
                    }
                }
                arr1=attachmentPathValue.split("|"); //字符分割
                for (i=0;i<arr1.length ;i++ ){
                    var index = arr1[i].indexOf(fileName);
                    if (index > -1) {
                        arr1.splice(i,1);// 删除
                    }
                }
                var result = arr.join("&nbsp;|&nbsp;");
                var result1 = arr1.join("&nbsp;|&nbsp;");
                tRecord.set(file,result);
                tRecord.set(path,result1);*/
                // var itemId = tRecord.data["id"];
debugger
                var callbackFn = function () {
                    Ext.getStore('fileItemStore').reload();
                };
                saveMockItemData('ZCertfFileItem', id, file, "", callbackFn);
                saveMockItemData('ZCertfFileItem', id, path, "", callbackFn);

            }
        },
        failure: function (response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });
}

function getCertfLink(certfNumber, type) {
    Ext.Ajax.request({
        scope: this,
        async: true, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url: '/Windchill/ptc1/certf/getCertfNumberLink',
        params: {
            certfNumber: certfNumber
        },
        success: function (response, opts) {
            // myMask.hide();
            var obj = Ext.decode(response.responseText);
            debugger
            var success = obj['message'];
            if (success != "success") {
                alert(success);
            } else {
                if (type == '检验报告') {
                    Ext.getCmp("certfNumberLink").setValue(obj['data']);
                    autoSaveAtt('certfNumberLink', obj['data']);
                    autoSaveAtt('certfNumber', certfNumber);
                }else {
                    Ext.getCmp("certfNumberLink1").setValue(obj['data']);
                    autoSaveAtt('certfNumberLink1', obj['data']);
                    autoSaveAtt('certfNumber1', certfNumber);
                }
            }
        },
        failure: function (response, opts) {
            // myMask.hide();
            alert('错误：删除获取证书链接失败，请检查网络！');
        }
    });
}

//修改
function updateDocPass(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        Ext.getStore('documentPassStore').reload();
    }
    function failCallback() {
        record.reject();
    }
    let param = {id: id, key: field, value: value}
    sendRequest('/Windchill/ptc1/certf/updateDocumentPassBo', 'GET',
        {}, false, {updateRecord: Ext.encode(param)}, successCallback, failCallback);
}

/**
 * 对Request封装
 * @Param url 请求url
 * @Param method 请求方法'GET' 'POST'
 * @Param async true 请求异步 false 请求步
 * @Param object
 * @Param callback 回调方法
 */
function sendRequest(url, method, headers, async, params, successCallback, failCallback) {
    Ext.Ajax.request({
        scope: this,
        url: url,
        method: method,
        timeout: 600000,
        async: async,
        headers: {'Content-Type': headers},
        params: params,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
                if (failCallback) {
                    failCallback();
                }
            } else {
                if (successCallback) {
                    successCallback(obj.data);
                }
            }
        },
        failure: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj && obj['message']) {
                Ext.Msg.alert('错误', obj['message']);
            } else {
                Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
            }
            if (failCallback != null && failCallback !== '') {
                failCallback();
            }
        }
    }); //~End of Ajax request
}