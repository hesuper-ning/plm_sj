//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//
rSubmit_node='rSubmit_node';//提交
exploit_node='exploit_node';//开发代表完善物料信息
sell_node='sell_node';//销售代表完善销售数据
purchase_node='purchase_node';//采购代表完善供应商库存数据
PDTManager_node='PDTManager_node';//PDT经理续证退市结论-指定续证/退市执行人
confirmPart_node='confirmPart_node';//确认待停用的成品及专用原材料编码

/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */
function disableNode(formkey) {
	if (taskCompleted == 'true') {
		return true;
	} else {
		if (formkey == currentActKey) {
			return false;
		} else {
			return true;
		}
	}
};
/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){

	var returnItemId = undefined;
	var mockRec = {
		oid:oid,
		dbTableName:dbTableName,
		itemId:itemId,
		dataKey:dataKey,
		dataValue:dataValue
	};

	Ext.Ajax.request({
		url: '/Windchill/ptc1/recertf/recertfSaveItemData',
		params:{
			updateRecord:Ext.encode(mockRec)
		},
		success: function(response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj['success']){

				//回调函数，一般用于后台操作成功后刷新列表
				if(callbackFn){
					callbackFn();
				}
			}else{
				alert(obj['msg']);
			}
		},
		failure: function(response, opts) {
			alert('错误：保存信息失败，请检查网络！!');
		}
	}); //~End of Ajax request
	return returnItemId;
}

/**
 * grid创建空列
 * @param dbTableName 表名
 */
function createMockItemData(dbTableName,callbackFn) {
	insertItemData(dbTableName,callbackFn);
}

function insertItemData(dbTableName,callbackFn) {

	Ext.Ajax.request({
		url: '/Windchill/ptc1/recertf/insertItemData',
		params:{
			oid:oid,
			dbTableName:dbTableName,
			branchId: branchId
		},
		success: function(response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj['success']){
				callbackFn();
			}else{
				alert(obj['error']);
			}
		},
		failure: function(response, opts) {
			alert('错误：保存信息失败，请检查网络！!');
		}
	}); //~End of Ajax request
}

//删除grid信息
function deleteData(tableName,ids,callback) {
	//var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"数据正在处理中，请稍后..."});
	///myMask.show();
	Ext.Ajax.request({
		scope:this,
		url: '/Windchill/ptc1/certf/deleteItemData',
		method: "POST",
		params: {
			oid:oid,
			data:Ext.encode(ids),
			tableName:tableName
		},
		success: function(response, opts) {
			var obj = Ext.decode(response.responseText);
			if(!obj['success']) {
				Ext.Msg.alert("数据删除失败",obj['msg']);
				//myMask.hide();
			}else{
				//myMask.hide();
				alert("数据删除成功");
				callback();
			}
		},
		failure: function(response, opts) {
			Ext.Msg.alert("错误",'数据删除失败，请检查网络！')
		}
	});
}

function getCertificateNumber(id) {
	Ext.getStore('numberStore').removeAll();
	Ext.getStore('numberStore').load({
		params: {
			id:id
		},
		callback: function (records, operation, success) {
			if (!success) {
				alert('查询信息失败，请联系管理员！');
			}
		}
	})
}

function getType(type) {
	Ext.getStore('typeStore').load({
		params: {
			type:type
		},
		callback: function (records, operation, success) {
			if (!success) {
				alert('查询信息失败，请联系管理员！');
			}
		}
	})
}

function getEndDate(id) {
	Ext.getStore('endDateStore').removeAll();
	Ext.getStore('endDateStore').load({
		params: {
			id:id,
		},
		callback: function (records, operation, success) {
			if (!success) {
				alert('查询信息失败，请联系管理员！');
			}else {
			}
		}
	})
}

function getProductName(id) {
	Ext.getStore('productNameStore').removeAll();
	Ext.getStore('productNameStore').load({
		params: {
			id:id,
		},
		callback: function (records, operation, success) {
			if (!success) {
				alert('查询信息失败，请联系管理员！');
			}
		}
	})
}