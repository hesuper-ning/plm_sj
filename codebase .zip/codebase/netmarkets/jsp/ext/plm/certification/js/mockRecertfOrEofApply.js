Ext.define('PLM.view.recertfOrEofApply', {
	extend: 'Ext.panel.Panel',
	alias: 'widget.recertfOrEofApply',
	border: false,
	layout: 'anchor',
	title: '&nbsp;<font style="font-size:18px">认证产品续证、退市申请表</font>',
	autoWidth: true,
	autoHeight: true,
	autoScroll: true,
	collapsible: false,
	id: 'simpleForm',
	config: {
		in_objectKey: 'recertfOrEofApply',
		in_objectDesc: '认证产品续证、退市',
		in_objectKey1: 'recertfOrEofApply-1',
		in_objectDesc1: '认证产品续证、退市',
		in_objectKey2: 'recertfOrEofApply-2',
		in_objectDesc2: '认证产品续证、退市',
		in_objectKey3: 'recertfOrEofApply-2',
		in_objectDesc3: '认证产品续证、退市',
	},
	fieldDefaults: {
		msgTarget: 'side',
		labelWidth: 75
	},

	initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
		var me = this;
		var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore'
		});

		var mockExampleStore1 = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore1'
		});
		var mockExampleStore2 = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore2'
		});

		var mockExampleStore3 = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore3'
		});

		var cellEditing = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		var cellEditing1 = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		var productLines = new Ext.form.ComboBox({
			name: 'productLines',
			id: 'productLines',
			multiSelect: false,
			valueField: 'groupName',
			displayField: 'groupName',
			anyMatch: true,
			editable: false,
			store: [['火报', '火报'], ['紧急疏散', '紧急疏散'], ['防火门', '防火门'],
				['电器火灾&消防设备电源监控','电器火灾&消防设备电源监控'],['物联网家报','物联网家报']
				,['海外火报','海外火报']
			]
		});


		var mockExampleGrid = Ext.create('Ext.grid.Panel', {
			plugins: [cellEditing],
			store: Ext.getStore('mockExampleStore'),
			id: 'mockExampleGrid',
			margin: '10 0 20 0',
			forceFit: true,
			autoWidth: true,
			// width:2500,
			autoScroll: false,
			region: 'center',
			//height: 300,
			selModel: {
				mode: 'MULTI' //可以多选
			},
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: mockExampleGrid,
							param_objectKey: me.in_objectKey,
							param_objectDesc: me.in_objectDesc
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			selType: 'checkboxmodel',
			listeners: {
				change: 'onAllCircuitsChecked'
			},

			columns: [{xtype: 'rownumberer'},
				{text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
				{text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
				{text: '产品型号', dataIndex: 'data1', width: 100, editor: 'textfield'},
				{text: '证书编号', dataIndex: 'data2', width: 100, editor: 'textfield'},
				{text: '产品名称', dataIndex: 'data3', width: 100, editor: 'textfield'},
				{text: '所属产品线', dataIndex: 'data4', width: 100, editor: productLines},
				{text: '认证类型', dataIndex: 'data5', width: 100, editor: 'textfield'},
				{text: '证书到期时间', dataIndex: 'data6', width: 100, editor: 'textfield'},
				{text: '发起原因', dataIndex: 'data9', width: 100, editor: 'textfield'},
				{text: '续证/退市结论', dataIndex: 'data7', width: 200, editor: 'textfield'},
				{text: '续证/退市流程发起人', dataIndex: 'data8', width: 200, editor: 'textfield'},
			]
		});

		var cellEditing_s1 = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		var mockExampleGrid1 = Ext.create('Ext.grid.Panel', {
			plugins: [cellEditing_s1],
			store: Ext.getStore('mockExampleStore1'),
			id: 'mockExampleGrid1',
			margin: '0 20 10 0',
			forceFit: true,
			autoWidth: true,
			// width:2500,
			autoScroll: false,
			region: 'center',
			//height: 300,
			selModel: {
				mode: 'MULTI' //可以多选
			},
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: mockExampleGrid1,
							param_objectKey: me.in_objectKey1,
							param_objectDesc: me.in_objectDesc1
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			selType: 'checkboxmodel',
			listeners: {
				change: 'onAllCircuitsChecked'
			},

			columns: [{xtype: 'rownumberer'},
				{text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
				{text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
				{text: '专用物料代码', dataIndex: 'data9', width: 100, editor: 'textfield',},
				{text: '物料名称', dataIndex: 'data10', width: 100, editor: 'textfield',},
				{text: '库存', dataIndex: 'data12', width: 200, editor: 'textfield'},
				{text: '在途订单物料数量', dataIndex: 'data11', width: 200, editor: 'textfield'},
				{text: '供应商库存', dataIndex: 'data15', width: 200, editor: 'textfield'},
				{text: '是否退市停用', dataIndex: 'data28', width: 200, editor: 'textfield'},
				{text: '', dataIndex: '', flex:1},
			]
		});

		var cellEditing_s3 = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		var mockExampleGrid3 = Ext.create('Ext.grid.Panel', {
			plugins: [cellEditing_s3],
			store: Ext.getStore('mockExampleStore3'),
			id: 'mockExampleGrid3',
			margin: '0 20 10 0',
			forceFit: true,
			autoWidth: true,
			// width:2500,
			autoScroll: false,
			region: 'center',
			//height: 300,
			selModel: {
				mode: 'MULTI' //可以多选
			},
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: mockExampleGrid3,
							param_objectKey: me.in_objectKey3,
							param_objectDesc: me.in_objectDesc3
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			selType: 'checkboxmodel',
			listeners: {
				change: 'onAllCircuitsChecked'
			},

			columns: [{xtype: 'rownumberer'},
				{text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
				{text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
				{text: '半成品物料代码', dataIndex: 'data13', width: 120, editor: 'textfield',},
				{text: '物料名称', dataIndex: 'data14', width: 100, editor: 'textfield',},
				{text: '库存', dataIndex: 'data16', width: 200, editor: 'textfield'},
				{text: '在途订单物料数量', dataIndex: 'data15', width: 200, editor: 'textfield'},
				{text: '供应商库存', dataIndex: 'data1', width: 200, editor: 'textfield'},
				{text: '是否退市停用', dataIndex: 'data27', width: 200, editor: 'textfield'},
				{text: '', dataIndex: '', flex:1},
			]
		});

		var cellEditing_s2 = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		var mockExampleGrid2 = Ext.create('Ext.grid.Panel', {
			plugins: [cellEditing_s2],
			store: Ext.getStore('mockExampleStore2'),
			id: 'mockExampleGrid2',
			margin: '0 20 0 0',
			forceFit: true,
			autoWidth: true,
			// width:2500,
			autoScroll: false,
			region: 'center',
			//height: 300,
			selModel: {
				mode: 'MULTI' //可以多选
			},
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: mockExampleGrid2,
							param_objectKey: me.in_objectKey2,
							param_objectDesc: me.in_objectDesc2
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			selType: 'checkboxmodel',
			listeners: {
				change: 'onAllCircuitsChecked'
			},

			columns: [{xtype: 'rownumberer'},
				{text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
				{text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
				{text: '成品物料代码', dataIndex: 'data13', width: 120, editor: 'textfield',},
				{text: '物料名称', dataIndex: 'data1', width: 120, editor: 'textfield',},
				{text: '库存', dataIndex: 'data2', width: 100, editor: 'textfield',},
				{text: '在制品数量', dataIndex: 'data3', width: 150, editor: 'textfield'},
				{text: '供应商库存', dataIndex: 'data4', width: 150, editor: 'textfield'},
				{
					text: '近三年销量数据：',
					columns:[
						{text: '显示当前年份-2', dataIndex: 'data5', width: 150, editor: 'textfield'},
						{text: '显示当前年份-1', dataIndex: 'data6', width: 150, editor: 'textfield'},
						{text: '显示填表时当前年份', dataIndex: 'data7', width: 150, editor: 'textfield'},
						{text: '合计', dataIndex: 'data8', width: 150, editor: 'textfield'},
					]
				},
				{text: '未履行销售订单产品数量', dataIndex: 'data9', width: 150, editor: 'textfield'},
				{text: '是否退市停用', dataIndex: 'data10', width: 150, editor: 'textfield'},
			]
		});


		mockExampleGrid.on('edit',
			function (editor, e) {
				var tRecord = e.record; //得到当前行所有数据
				var tField = e.field; //得到修改列
				var tValue = e.value; //得到修改列修改后值
				var itemId = tRecord.get('id');

				var callbackFn = function () {
					tRecord.commit();
				};
				saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

			});

		mockExampleGrid1.on('edit',
			function (editor, e) {
				var tRecord = e.record; //得到当前行所有数据
				var tField = e.field; //得到修改列
				var tValue = e.value; //得到修改列修改后值
				var itemId = tRecord.get('id');

				var callbackFn = function () {
					tRecord.commit();
				};
				saveMockItemData(this.in_objectKey1, this.in_objectDesc1, itemId, tField, tValue, callbackFn);

			});
		mockExampleGrid2.on('edit',
			function (editor, e) {
				var tRecord = e.record; //得到当前行所有数据
				var tField = e.field; //得到修改列
				var tValue = e.value; //得到修改列修改后值
				var itemId = tRecord.get('id');

				var callbackFn = function () {
					tRecord.commit();
				};
				saveMockItemData(this.in_objectKey2, this.in_objectDesc2, itemId, tField, tValue, callbackFn);

			});

		mockExampleGrid3.on('edit',
			function (editor, e) {
				var tRecord = e.record; //得到当前行所有数据
				var tField = e.field; //得到修改列
				var tValue = e.value; //得到修改列修改后值
				var itemId = tRecord.get('id');

				var callbackFn = function () {
					tRecord.commit();
				};
				saveMockItemData(this.in_objectKey3, this.in_objectDesc3, itemId, tField, tValue, callbackFn);

			});



		this.items = [{
			xtype: 'form',
			id: 'mainForm',
			//padding:'5',
			anchor: '90%',
			border: false,
			defaults: {
				labelWidth: 100,
				border: false,
			},
			items: [{
				html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">1. 申请人填写</div>'
			},{//第一行
				xtype: 'panel',
				layout: 'hbox',
				defaults: {margin: '5 20 0 0', labelWidth: 100},
				items: [{
					xtype: 'displayfield',
					value:'wcadmin',
					fieldLabel: '需求申请人',
					name: 'att1',
					id: 'att1',
					width: 250,
				}, {
					xtype: 'displayfield',
					fieldLabel: '需求部门',
					value:'硬件部',
					name: 'att3',
					id: 'att3',
					width: 250,
				},{
					xtype: 'displayfield',
					fieldLabel: '申请日期 ',
					value:'2021-06-29',
					name: 'att14',
					id: 'att14',
					width: 250,
				}, {
					xtype: 'displayfield',
					fieldLabel: '编号',
					value:'123456',
					name: 'att15',
					id: 'att15',
					width: 250,
				}]
			}, mockExampleGrid,
			]//~end of hbox items
		},//~end of 测试项目

			{
				xtype: 'form',
				id: 'mainForm1',
				//padding:'5',
				anchor: '90%',
				border: false,
				defaults: {
					labelWidth: 100,
					border: false,
				},
				items: [{
					html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">2. 支持数据</div>'
				},{
					html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">2.1 成品数据</div>'
				},mockExampleGrid2,{
					html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">2.2 半成品物料数据</div>'
				},mockExampleGrid3,{
					html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">2.3 本产品专用物料数据</div>'
				}, mockExampleGrid1,{//第六行
					xtype: 'panel',
					defaults: {margin: '5 20 5 5', labelWidth: 100,border:false},
					items: [{
						html:'<span>说明：<br/>'+
							' - 研发代表：负责填写专用物料代码及成品半成品料号；<br/>' +
							' - 市场代表：近三年销量数据 & 未履行销售订单数据；<br/>' +
							' - 采购代表：负责填写对应物料的库存；<span/>'
					}]
				}],
			},

		];

		this.callParent();
	},//~End of initComponent
	listeners: {
		'afterrender': function () {
			Ext.getStore('mockExampleStore').load({
				params: {
					objectKey: Ext.getCmp('simpleForm').getIn_objectKey()//表头key
				},
				callback: function (records, operation, success) {
					if (!success) {
						if (typeof (operation.error) == 'string') {
							alert(operation.error);
						} else {
							alert('查询超时！请重试！')
						}
					} else {
						//无数据时自动添加一条空数据
						if (Ext.getStore('mockExampleStore').getCount() == 0) {
							var callbackFn = function () {
								Ext.getStore('mockExampleStore').reload()
							}
							createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey()
								, Ext.getCmp('simpleForm').getIn_objectDesc, callbackFn);
						}
					}
				}
			});
			Ext.getStore('mockExampleStore1').load({
				params: {
					objectKey: Ext.getCmp('simpleForm').getIn_objectKey1()//表头key
				},
				callback: function (records, operation, success) {
					if (!success) {
						if (typeof (operation.error) == 'string') {
							alert(operation.error);
						} else {
							alert('查询超时！请重试！')
						}
					} else {
						//无数据时自动添加一条空数据
						if (Ext.getStore('mockExampleStore1').getCount() == 0) {
							var callbackFn = function () {
								Ext.getStore('mockExampleStore1').reload()
							}
							createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey1()
								, Ext.getCmp('simpleForm').getIn_objectDesc1, callbackFn);
						}
					}
				}
			});
			Ext.getStore('mockExampleStore2').load({
				params: {
					objectKey: Ext.getCmp('simpleForm').getIn_objectKey2()//表头key
				},
				callback: function (records, operation, success) {
					if (!success) {
						if (typeof (operation.error) == 'string') {
							alert(operation.error);
						} else {
							alert('查询超时！请重试！')
						}
					} else {
						//无数据时自动添加一条空数据
						if (Ext.getStore('mockExampleStore2').getCount() == 0) {
							var callbackFn = function () {
								Ext.getStore('mockExampleStore2').reload()
							}
							createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey2()
								, Ext.getCmp('simpleForm').getIn_objectDesc2, callbackFn);
						}
					}
				}
			});

			Ext.getStore('mockExampleStore3').load({
				params: {
					objectKey: Ext.getCmp('simpleForm').getIn_objectKey3()//表头key
				},
				callback: function (records, operation, success) {
					if (!success) {
						if (typeof (operation.error) == 'string') {
							alert(operation.error);
						} else {
							alert('查询超时！请重试！')
						}
					} else {
						//无数据时自动添加一条空数据
						if (Ext.getStore('mockExampleStore3').getCount() == 0) {
							var callbackFn = function () {
								Ext.getStore('mockExampleStore3').reload()
							}
							createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey3()
								, Ext.getCmp('simpleForm').getIn_objectDesc3, callbackFn);
						}
					}
				}
			});

			// 查询MockExample form表单数据
			Ext.Ajax.request({
				url: '/Windchill/ptc1/mock/getObject',
				params: {
					objectKey: Ext.getCmp('simpleForm').getIn_objectKey()
				},
				success: function (response, opts) {
					var obj = Ext.decode(response.responseText);
					if (obj['success']) {
						var mainPanel = Ext.getCmp('mainForm');
						mainPanel.getForm().setValues(obj);
						var mainPanel1 = Ext.getCmp('mainForm1');
                         mainPanel1.getForm().setValues(obj);
					} else {
						alert(obj['error']);
					}
				},
				failure: function (response, opts) {
					alert('错误：查询信息失败，请检查网络！!');
				}
			}); //~End of Ajax request
		}
	}

});