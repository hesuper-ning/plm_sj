Ext.define('PLM.view.CertfApplyPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CertfApplyPanel',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">认证管理</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    config: {
        in_objectKey: 'certification',
        in_objectDesc: '认证管理',
        in_objectKey1: 'certification-1',
        in_objectDesc1: '认证管理',
        in_objectKey2: 'certification-2',
        in_objectDesc2: '认证管理',
        in_objectKey3: 'certification-3',
        in_objectDesc3: '认证管理',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var mockExampleStore1 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore1'
        });
        var mockExampleStore2 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore2'
        });

        var mockExampleStore3 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore3'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var certfTypes = new Ext.form.ComboBox({
            name: 'certfTypes',
            id: 'certfTypes',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['型式试验', '型式试验'], ['分型试验', '分型试验'], ['变更确认检验', '变更确认检验'],
                ['型式检验', '型式检验'], ['委托检验', '委托检验'], ['技术鉴定', '技术鉴定'],
                ['变更报备', '变更报备'], ['证书延续', '证书延续'], ['防爆委托', '防爆委托'],
                ['无线电发射设备核准', '无线电发射设备核准'], ['进网检测', '进网检测'], ['其它', '其它']
            ]
        });


        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            margin: '10 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '产品型号', dataIndex: 'data4', width: 100, editor: 'textfield'},
                {text: '名称', dataIndex: 'data11', width: 100, editor: 'textfield'},
                {text: '认证类别', dataIndex: 'data10', width: 100, editor: certfTypes},
                {text: '送检类型', dataIndex: 'data6', width: 100, editor: certfTypes},
                {text: '是否有关键元器件', dataIndex: 'data3', width: 100, editor: 'textfield'},
                {text: '关键元器件编码(多值)', dataIndex: 'data5', width: 100, editor: 'textfield'},
                {text: '样品数量', dataIndex: 'data8', width: 100, editor: 'textfield'},
            ]
        });

        var cellEditing_s1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mockExampleGrid1 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing_s1],
            title: '产品送检申请文件',
            store: Ext.getStore('mockExampleStore1'),
            id: 'mockExampleGrid1',
            margin: '10 20 0 0',
            //forceFit: true,
            //autoWidth: true,
            width: 350,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid1,
                            param_objectKey: me.in_objectKey1,
                            param_objectDesc: me.in_objectDesc1
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '产品型号', dataIndex: 'data17', width: 100, editor: 'textfield',},
                {text: '文件编号', dataIndex: 'data11', width: 100, editor: 'textfield',},
                {text: '文件名', dataIndex: 'data12', width: 200, editor: 'textfield'},
            ]
        });

        var cellEditing_s2 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mockExampleGrid2 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing_s2],
            title: '产品送检技术文件',
            store: Ext.getStore('mockExampleStore2'),
            id: 'mockExampleGrid2',
            margin: '10 20 0 0',
            //forceFit: true,
            //autoWidth: true,
            width: 350,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid2,
                            param_objectKey: me.in_objectKey2,
                            param_objectDesc: me.in_objectDesc2
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '产品型号', dataIndex: 'data18', width: 100, editor: 'textfield',},
                {text: '文件编号', dataIndex: 'data13', width: 100, editor: 'textfield',},
                {text: '文件名', dataIndex: 'data14', width: 200, editor: 'textfield'},
            ]
        });

        var cellEditing_s3 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mockExampleGrid3 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing_s3],
            title: '获证所需其他文件',
            store: Ext.getStore('mockExampleStore3'),
            id: 'mockExampleGrid3',
            margin: '10 20 0 0',
            //forceFit: true,
            //autoWidth: true,
            width: 350,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid3,
                            param_objectKey: me.in_objectKey3,
                            param_objectDesc: me.in_objectDesc3
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '产品型号', dataIndex: 'data19', width: 100, editor: 'textfield',},
                {text: '文件编号', dataIndex: 'data15', width: 100, editor: 'textfield',},
                {text: '文件名', dataIndex: 'data16', width: 200, editor: 'textfield'},
            ]
        });


        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        mockExampleGrid1.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey1, this.in_objectDesc1, itemId, tField, tValue, callbackFn);

            });
        mockExampleGrid2.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey2, this.in_objectDesc2, itemId, tField, tValue, callbackFn);

            });

        mockExampleGrid3.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey3, this.in_objectDesc3, itemId, tField, tValue, callbackFn);

            });

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            collapsible: true,
            title: '1.跟踪表基本信息',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                layout: {
                    type: 'hbox',
                    padding: '2 10 2 10'
                }
            },
            items: [{//第一行
                xtype: 'panel',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '申请日期',
                    name: 'att1',
                    id: 'att1',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '申请人',
                    name: 'att3',
                    id: 'att3',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '部门',
                    name: 'att4',
                    id: 'att4',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }]
            }, {
                xtype: 'panel',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '需求来源',
                    name: 'att14',
                    id: 'att14',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'textfield',
                    fieldLabel: '项目编码',
                    name: 'att33',
                    id: 'att33',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '备注',
                    name: 'att15',
                    id: 'att15',
                    width: 350,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }]
            }, mockExampleGrid, {
                xtype: 'panel',
                title: '',
                //collapsible: true,
                margin: '5 20 5 5',
                //defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [mockExampleGrid1, mockExampleGrid2, mockExampleGrid3]
            }
            ]//~end of hbox items
        },//~end of 测试项目

            {
                xtype: 'panel',
                id: 'mainForm1',
                //padding:'5',
                anchor: '90%',
                border: false,
                defaults: {
                    labelWidth: 100,
                    border: false,
                },
                items: [{//第五行
                    xtype: 'panel',
                    title: '2.基本信息审核',
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    items: [{
                        xtype: 'panel',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            border: false,
                            html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">项目负责人审核</div>'
                        }, {
                            xtype: 'textfield',
                            fieldLabel: '审核意见',
                            name: 'att16',
                            id: 'att16',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }],
                    }, {
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">供应链审核</div>'
                    }, {
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '审核意见',
                            labelWidth: 130,
                            name: 'att17',
                            id: 'att17',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }, {
                            xtype: 'combobox',
                            fieldLabel: '是否已核对实物',
                            name: 'att18',
                            id: 'att18',
                            width: 250,
                            store: [['是', '是'], ['否', '否']]
                        }]
                    }, {
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">认证工程师审核</div>'
                    }, {
                        xtype: 'panel',
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '审核意见',
                            id: 'att19',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }],
                    }, {
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">产品部副经理审核</div>'
                    }, {
                        xtype: 'panel',
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '审核意见',
                            name: 'att20',
                            id: 'att20',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }],
                    }]
                }, {//第六行
                    xtype: 'panel',
                    title: '3.产品送检申请文件 / 产品送检技术文件准备',
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    items: [{
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">送检资料处理</div>'
                    }, {
                        layout: 'hbox',
                        xtype: 'panel',
                        title: '',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '技术文件打印',
                            name: 'att21',
                            id: 'att21',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }, {
                            xtype: 'textfield',
                            labelWidth: 350,
                            fieldLabel: '送检资料处理（打印、签字、盖章、复印、洗照片、寄出）',
                            name: 'att22',
                            id: 'att22',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]
                    }, {
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">资料室存档</div>'
                    }, {//第七行
                        xtype: 'panel',
                        title: '',
                        defaults: {margin: '5 20 5 5', labelWidth: 100},
                        items: [{
                            xtype: 'textfield',
                            labelWidth: 150,
                            fieldLabel: '送检资料留存确认',
                            name: 'att23',
                            id: 'att23',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]
                    }]
                }, {//第八行
                    xtype: 'panel',
                    collapsible: true,
                    title: '4.获证前的送检资料确认',
                    defaults: {margin: '5 20 5 5', labelWidth: 100},
                    items: [{
                        xtype: 'radiogroup',
                        labelWidth: 110,
                        fieldLabel: '获证前的送检资料修改需求确认',
                        name: '999',
                        id: '999',
                        width: 250,
                        columns: 1,
                        items: [
                            {boxLabel: '无需修改', name: 'quoteFile', inputValue: '无需修改', disabledCls: 'none'},
                            {boxLabel: '不含技术资料修改', name: 'quoteFile', inputValue: '不含技术资料修改', disabledCls: 'none'},
                            {boxLabel: '含技术资料修改', name: 'quoteFile', inputValue: '含技术资料修改', disabledCls: 'none'},
                        ],
                    }]
                }, {//第六行
                    xtype: 'panel',
                    title: '5. 检验完成后生产资料再确认',
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: 'ECR编号',
                        name: 'att297',
                        id: 'att297',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '修订文档编号',
                        name: 'att287',
                        id: 'att287',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '备注',
                        name: 'att277',
                        id: 'att277',
                        width: 450,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                }, {//第九行
                    xtype: 'panel',
                    collapsible: true,
                    title: '6.检验报告归档',
                    defaults: {margin: '5 20 5 5', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '备注',
                        name: 'att24',
                        id: 'att24',
                        width: 450,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                }, {//第六行
                    xtype: 'panel',
                    title: '7.技术资料完善',
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    items: [{
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">工艺资料</div>'
                    }, {
                        xtype: 'panel',
                        title: '',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '备注',
                            name: 'att25',
                            id: 'att25',
                            width: 450,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        },]
                    }, {
                        html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">生产记录</div>'
                    }, {//第七行
                        xtype: 'panel',
                        title: '',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '备注',
                            name: 'att26',
                            id: 'att26',
                            width: 450,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]
                    }]
                }, {//第九行
                    xtype: 'panel',
                    collapsible: true,
                    title: '8.认证证书归档',
                    defaults: {margin: '5 20 5 5', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '备注',
                        name: 'att30',
                        id: 'att30',
                        width: 450,
                    }]
                }, {//第六行
                    xtype: 'panel',
                    title: '9.获证后生产资料再确认',
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: 'ECR编号',
                        name: 'att29',
                        id: 'att29',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '修订文档编号',
                        name: 'att28',
                        id: 'att28',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '备注',
                        name: 'att27',
                        id: 'att27',
                        width: 450,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                },],
            },

        ];

        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey()
                                , Ext.getCmp('simpleForm').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore1').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey1()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore1').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore1').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey1()
                                , Ext.getCmp('simpleForm').getIn_objectDesc1, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore2').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey2()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore2').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore2').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey2()
                                , Ext.getCmp('simpleForm').getIn_objectDesc2, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore3').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey3()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore3').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore3').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey3()
                                , Ext.getCmp('simpleForm').getIn_objectDesc3, callbackFn);
                        }
                    }
                }
            });
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                        /* var mainPanel1 = Ext.getCmp('mainForm1');
                         mainPanel1.getForm().setValues(obj);*/
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});