<%@page import="wt.workflow.work.*"%>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
<%

%>

<script type="text/javascript">

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<link href="/Windchill/netmarkets/css/ptc/ptcProjectManagement.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
<%--    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/formexport/js/download-toolbar.js"></script>--%>
    <script type="text/javascript" src="js/mockCertfApplyPanel.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctCertfApplyFunctions.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js"></script>
</head>

<body>
<script>
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'CertfApplyPanel'
		    }]
		});
});
</script>

</body>
</html>