<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <!-- 为ECharts准备一个具备大小（宽高）的Dom -->
    <div id="complaintClassValidTrue" style="width: 500px;height:400px;float:left;margin-left: 20px"></div>


    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>in CtBomToolPlugin.jsp oid=" + oid);

    %>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css"/>
    <!-- ExtJS -->
    <!-- ECharts单文件引入 -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <%--    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/common/download-toolbar.js?time=<%=System.currentTimeMillis()%>"></script>--%>
    <script type="text/javascript" src="js/echarts.min.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctProjectGroupChart.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctProjectGroupFunction.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctProjectGroupPanel.js?_dc=<%System.currentTimeMillis();%>"></script>
</head>

<body>
<style>
    .classDiv1 {
        font-size: 21px;
        color: red;
    }

</style>
<script>
    // ==============layout define area=================================//
    var allowEdit = false;
    var url = '/Windchill/ptc1/ec/exportEcContentExcel?changeRequestId=';
    var controll = false;// 不同的请求方式，true为请求controller
    Ext.onReady(function () {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ctProjectGroup'
            }]
        });
    });
</script>
</body>
</html>
