/**
 * 项目群报表
 */
Ext.define('Plm.view.ctProjectGroup', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctProjectGroup',
    border: false,
    // collapsible: true,
    // autoWidth: true,
    // autoHeight: true,
    // height: 3500,
    autoScroll: true,
    // fieldDefaults: {
    //     msgTarget: 'side',
    //     labelWidth: 75
    // },
    initComponent: function () {
        //===================初始化
        //border-style:solid; border-width:1px; border-color:#000
        var projectGroupChartGrid = Ext.create('Ext.form.Panel', {
            // width: 1000,
            height: 500,
            align: 'center',
            border:0,
            id:'projectGroupChartGrid',
            //id:'projectWeightChartGrid',
            html:'<div id="projectGroupChartGridT" style="float:left;border-style:solid; border-width:1px; border-color:#333333;width:750px;height:500px;"></div>' +
                '<div id="projectGroupChartGridT2" style="float:left;border-style:solid; border-width:1px; border-color:#333333;width:750px;height:500px;"></div>',
            listeners: {
                'afterrender': function () {

                },
            },
        });


        var projectGroupChartGrid2 = Ext.create('Ext.form.Panel', {
            // width: 1000,
            height: 500,
            autoWidth : false,
            border:0,
            id:'projectGroupChartGrid2',
            //id:'projectWeightChartGrid',
            html:'<div id="projectGroupChartGridT3" style="float:left;border-style:solid; border-width:1px; border-color:#333333;width:750px;height:500px;"></div>' +
                '<div id="projectGroupChartGridT4" style="float:left;border-style:solid; border-width:1px; border-color:#333333;width:750px;height:500px;"></div>',
            listeners: {
                'afterrender': function () {

                },


            },
        });

        var projectGroupChartGrid3 = Ext.create('Ext.form.Panel', {
            // width: 1000,
            height: 500,
            autoWidth : false,
            border:0,
            id:'projectGroupChartGrid3',
            //id:'projectWeightChartGrid',
            html:'<div id="projectGroupChartGrid3" style="width:1500px;height:500px"></div>',
            listeners: {
                'afterrender': function () {

                },


            },
        });

        Ext.define('ctAllUserModel', {
            extend: 'Ext.data.Model',
            fields:['no' ,'riskId']
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var delayDaysRemark='延期天数=当天-所处里程碑阶段计划完成日期';
        var projectScheduleDeviationRateRemark='延期天数(有正、负)/里程碑阶段计划工期(天数)。说明：里程碑阶段计划工期=当前里程碑的时间-项目实际启动时间';

        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        //'id' ,'updateTime','projectname','projectType','projectStatus','projectSource'
        //                 ,'projectScheduleDeviationRate','projectRealActionTime','projectPriority','projectNumber'
        //                 ,'projectId','productModel','productCode','planProjectName','pdtManager','pdt','nowStage'
        //                 ,'delayDays','commitmentEndTime','commitmentActionTime'
        var pdtText = 'PDT';
        var planProjectNameText = '规划项目名称';
        var projectNumberText = '项目编号';
        var projectNameText = '实际执行项目名称';
        var projectPriorityText = '项目优先级';
        var pdtManagerText = 'PDT经理';
        var projectTypeText = '项目类型';
        var productModelText = '产品型号';
        var productCodeText = '产品代码';
        var projectSourceText = '立项来源';
        var projectRealActionTimeText = '项目实际开始时间';
        var nowStageText = '当前阶段';
        var projectStatusText = '项目状态';
        var delayDaysText = '延期天数';
        var projectScheduleDeviationRateText = '项目进度偏差率';
        var commitmentActionTimeText = '任务书开发时间';
        var commitmentEndTimeText = '任务书结束时间';
        var upStreamProjectNumberText = '上游项目编号';
        var workBookNumberText = '任务书文档编号';


        //可编辑项

        // }
        Ext.define('ctProjectGroupModel', {
            extend: 'Ext.data.Model',
            fields:['id','updateTime','projectname','projectType','projectStatus','projectSource'
                ,{name:'projectScheduleDeviationRate',type:'number'},{name:'projectRealActionTime',type:'string'},'projectPriority','projectNumber'
                ,'projectId',{name:'productModel',type:'string'},{name:'productCode',type:'string'},{name:'planProjectName',type:'string'},{name:'pdtManager',type:'string'},{name:'pdt',type:'string'},{name:'nowStage',type:'string'}
                ,{name:'delayDays',type:'string'},{name:'commitmentEndTime',type:'string'},{name:'commitmentActionTime',type:'string'},{name:'upStreamProjectNumber',type:'string'},{name:'workBookNumber',type:'string'}],
            idProperty: 'id',
            sorters : [{
                property : 'nowStage', // 指定要排序的列索引
                direction : 'DESC' // 降序，  ASC：赠序
            }]
        });
        var ctProjectGroupStore = Ext.create('Ext.data.Store', {
            // pageSize: 1,
            model: 'ctProjectGroupModel',
            id: 'ctProjectGroupStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/projectGroup/getDateBySearch',
                method: 'POST',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });
        //==========================combe start
//  var ctPdtStore = Ext.create('Ext.data.Store', {
//             fields:['pdt' ],
//             id: 'ctPdtStore',
//             autoSync: true,//同步更新
//             pruneModifiedRecords: true,
//             // forceSelection: true,//强制从列表中选择
//             proxy: new Ext.data.HttpProxy({
//                 type: 'ajax',
//                 url: '/Windchill/ptc1/projectGroup/getAllPdt',
//                 method: 'GET',
//                 reader:{
//                     type:'json',
//                     rootProperty: 'data',
//                     idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
//                     messageProperty: 'message'
//                 }
//             }),
//             autoLoad: true
//         });
        var projectPlanProjectNameStore = Ext.create('Ext.data.Store', {
            fields: ['planProjectName'],
            autoSync: true,//同步更新
            pruneModifiedRecords: true,
            id: 'projectPlanProjectNameStore',
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/projectGroup/getAllPlanProjectName',
                method: 'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });
        var projectNumberStore = Ext.create('Ext.data.Store', {
            fields: [
                'projectNumber'
            ],
            autoSync: true,//同步更新
            id: 'projectNumberStore',
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/projectGroup/getAllProjectNumber',
                method: 'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });
        var planProjectNameCombo = new Ext.form.field.ComboBox({
            fieldLabel: '规划项目名称',
            triggerAction: 'all',
            editable : true,
            allowBlank : true,
            // lazyRender:true,
            // triggerAction: 'all',
            forceSelection: false, //forceSelection 是否能够手填
            // id: 'planProjectNameCombo',
            // name: 'planProjectNameCombo',
            mode: 'remote',
            store: projectPlanProjectNameStore,
            queryMode: 'local',
            valueField: 'planProjectName',
            displayField: 'planProjectName'
        });

        var projectNumberCombo = new Ext.form.field.ComboBox({
            fieldLabel: '项目编号',
            // triggerAction: 'all',
            editable : true,
            allowBlank : true,
            // lazyRender:true,
            // triggerAction: 'all',
            // forceSelection: true, //forceSelection 是否能够手填
            id: 'projectNumberCombo',
            name: 'projectNumberCombo',
            mode: 'remote',
            store: projectNumberStore,
            queryMode: 'local',
            // valueField: 'name',
            displayField: 'projectNumber',
            listeners: {
                blur: function (e) {

                }
            }
        });
        var ctAllUserStore = Ext.create('Ext.data.Store', {
            //正式机
            // fields:['NAME' ,'FULLNAME'],
            //测试机
            fields:['NAME' ,'FULLNAME'],
            id: 'ctAllUserStore',
            autoSync: true,//同步更新
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/projectGroup/getAllPdtManager',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });

        var ctPdtStore = Ext.create('Ext.data.Store', {
            fields:['pdt' ],
            id: 'ctPdtStore',
            autoSync: true,//同步更新
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/projectGroup/getAllPdt',
                method: 'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });

        var pdtManagerComboBox = new Ext.form.field.ComboBox({
            fieldLabel:  'PDT经理',
            multiSelect: false,
            anyMatch: true,
            editable : true,
            allowBlank : true,
            // triggerAction: 'all',
            queryMode: 'local',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'pdtManagerComboBox',
            // name: 'hiddenName',
            mode: 'remote',
            store: ctAllUserStore,
            valueField: 'NAME',
            displayField: 'FULLNAME',
            width: 275,

        });
        var pdtComboBox = new Ext.form.field.ComboBox({
            fieldLabel:  ' PDT',
            multiSelect: false,
            anyMatch: true,
            editable : true,
            allowBlank : true,
            // triggerAction: 'all',
            queryMode: 'local',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'pdtComboBox',
            // name: 'hiddenName',
            mode: 'remote',
            store: ctPdtStore,
            valueField: 'pdt',
            displayField: 'pdt',
            labelWidth: 125,
            margin: '0 5 0 10',
            width: 280,

        });

        var ctYearStore = Ext.create('Ext.data.Store', {
            fields:['year' ],
            id: 'ctYearStore',
            autoSync: true,//同步更新
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/projectGroup/getAllYear',
                method: 'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });
        var yearComboBox = new Ext.form.field.ComboBox({
            fieldLabel:  '项目发起年度',
            multiSelect: false,
            anyMatch: true,
            editable : true,
            allowBlank : true,
            // triggerAction: 'all',
            queryMode: 'local',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'yearComboBox',
            // name: 'hiddenName',
            mode: 'remote',
            store: ctYearStore,
            valueField: 'year',
            displayField: 'year',
            width: 275,
            listeners: {
                select: function () {
                    whetherLookProjectPerform();
                    let yearValue= Ext.getCmp('yearComboBox').getValue();
                    let pdt=Ext.getCmp('radioPdtId').getValue();
                    let radioType1=Ext.getCmp('radioTypeId').getValue();
                    if(pdt.radioPdt!=undefined && pdt.radioPdt==='1'){
                        console.log("====执行了if");
                        whetherLookProjectPDT(yearValue,'是');
                    }else{
                        whetherLookProjectPDT(yearValue,'否');
                    }
                    if(radioType1.radioType!=undefined && radioType1.radioType==='1'){
                        console.log("====执行了if2");
                        whetherLookProjectType(yearValue,'是');
                    }else{
                        whetherLookProjectType(yearValue,'否');
                    }

                }
            }

        });



        var projectStatus = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : true,
            fieldLabel: '项目状态',
            // margin: '0 5 0 10',
            labelWidth: 135,
            width: 315,
            // forceSelection: true, //forceSelection 是否能够手填
            id: 'projectStatus',
            name: 'projectStatus',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["SUSPENDED", "已暂停"],["DEFINED", "已定义"]
                    ,["RUNNING", "正在运行"],["CANCELLED", "已取消"]
                    ,["COMPLETED", "已完成"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var phaseCombo = new Ext.form.field.ComboBox({
            anyMatch: true,
            editable : true,
            // forceSelection: true, //forceSelection 是否能够手填
            fieldLabel: '项目阶段',
            margin: '0 10 0 0',
            id: 'phaseCombo',
            name: 'phaseCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"],["TR4-TR4A", "TR4-TR4A"],
                    ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });



        //==========================combin end
        var ctProjectGroupGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: ctProjectGroupStore,
            id: 'ctProjectGroupGrid',
            // title:'风险评估表单',
            margin: '20 10 0 10',
            // forceFit: true,
            height:595,
            // autoScroll: true,
            // region: 'center',
            // height: '100%',
            // listeners: {
            //     'beforeedit':function (editor, e, eOpts) {
            //
            //     },
            // },
            selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"MULTI",showHeaderCheckbox:true}),
            viewConfig: {enableTextSelection: true, stripeRows: true,},
            columns: [
                {xtype: 'rownumberer', text: '序号', width: 50, align: 'center'},
                // {text: 'id', dataIndex: 'id', width: 120, menuDisabled: true, hidden: true, align: 'center'},
                {text: pdtText, dataIndex: 'pdt', width: 150
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        }
                        return value;
                    }},
                {text: planProjectNameText, dataIndex: 'planProjectName', width: 130
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        }
                        return value;
                    }},
                {text: projectNumberText, dataIndex: 'projectNumber', width: 150},
                {text: projectNameText, dataIndex: 'projectName', width: 140
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        }
                        return value;
                    }},
                {text: projectPriorityText, dataIndex: 'projectPriority', width: 120},
                {text: pdtManagerText, dataIndex: 'pdtManager', width: 120
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        }
                        return value;
                    }},
                {text: projectTypeText, dataIndex: 'projectType', width: 150},
                {text: productModelText, dataIndex: 'productModel', width: 120
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        }
                        return value;
                    }},
                {text: productCodeText, dataIndex: 'productCode', width: 120
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        }
                        return value;
                    }},
                {text: projectSourceText, dataIndex: 'projectSource', width: 120},
                {text: upStreamProjectNumberText, dataIndex: 'upStreamProjectNumber', width: 140
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        }
                        return value;
                    }},
                {text: workBookNumberText, dataIndex: 'workBookNumber', width: 140
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        }
                        return value;
                    }},
                {text: projectRealActionTimeText, dataIndex: 'projectRealActionTime', width: 120
                        ,renderer: function(value,metaData,record,row,col,store){
                    if(value) {
                        return selfDateFormat(value);

                    }
                }},
                {text: nowStageText, dataIndex: 'nowStage', width: 120,
                    //重写此方法
                    doSort: function(state) {
                    console.log("执行了这个方法");
                        var ds = this.up('grid').getStore();
                        var field = this.getSortParam();
                        ds.sort({
                            property: field,
                            direction: state,
                            //排序规则（重点）
                            sorterFn: function(v1, v2){
                                v1 = v1.get(field);
                                v2 = v2.get(field);
                                return v1.length > v2.length ? 1 : (v1.length < v2.length ? -1 : 0);
                            }
                        });
                    }},
                {text: projectStatusText, dataIndex: 'projectStatus', width: 120},
                {text: delayDaysText, dataIndex: 'delayDays',tooltip:delayDaysRemark, width: 120},
                {text: projectScheduleDeviationRateText,enableTextSelection: false, dataIndex: 'projectScheduleDeviationRate', tooltip:projectScheduleDeviationRateRemark,width: 120,
                    renderer: function(value, metaData, record) {
                        metaData.style = 'white-space:normal;word-break:break-all;';
                        if (value) {
                            return value+'%';
                        }
                    }
                },
                {text: commitmentActionTimeText, dataIndex: 'commitmentActionTime', width: 120
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value) {
                            return selfDateFormat(value);

                        }
                    }},
                {text: commitmentEndTimeText, dataIndex: 'commitmentEndTime', width: 120
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value) {
                            return selfDateFormat(value);

                        }
                    }},

            ],
            // bbar: Ext.create('Ext.PagingToolbar', {
            //     store: Ext.data.StoreManager.lookup('ctProjectGroupStore'),
            //     displayInfo: true,
            //     displayMsg: '当前显示 {0} - {1} ，共 {2}',
            //     emptyMsg: "查询结果为空",
            //     items:[{
            //         text: '查询全部',
            //         scope: this,
            //         id:'queryAll',
            //         handler:function(){
            //             ctProjectGroupStore.pageSize=ctProjectGroupStore.getTotalCount();
            //             ctProjectGroupStore.currentPage = 1;
            //             // refreshAllRequireStore();
            //             refreshAllRequireStore(false,25,1);
            //             Ext.getCmp("queryAll").hide();
            //             Ext.getCmp("pageQuery").show();
            //         }
            //     },{
            //         text: '分页查询',
            //         scope: this,
            //         id:'pageQuery',
            //         hidden:true,
            //         handler:function(){
            //             ctProjectGroupStore.pageSize=25;
            //             refreshRequireStore(true,25,1);
            //             // refreshRequireStore();
            //             Ext.getCmp("pageQuery").hide();
            //             Ext.getCmp("queryAll").show();
            //         }
            //     }]
            // }),//~End bbar
            tbar: [{
                iconCls: 'icon-excelExport',
                // xtype: 'button',
                id: "excelOutputData",
                text: 'Excel导出',
                handler : function () {
                    this.exportReport();
                },
                scope : this
            }]

        });

        var projectGroupReportForm = {
            title: '<font size=4 color=blue bold >项目群报表</font>',
            xtype: 'fieldset',
            region: 'center',
            margin: '5 0 0 10',
            align: 'center',
            // height:2000,
            id: 'mainForm',
            width: '98%',
            hidden: false,
            // hideLabel: true,
            // frame: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '10 0 0 10',
                items: [{
                    margin: '0 10 0 0',
                    fieldLabel: '规划项目名称',
                    // xtype:planProjectNameCombo,
                    id: 'planProjectNameCombo',
                    xtype: 'textfield',
                    // labelWidth: 120,
                    width: 275,
                }, {
                    // margin: '10 0 0 10',
                    // fieldLabel: '规划项目名称',
                    xtype:projectStatus,
                    width: 315,
                }, {
                    // margin: '0 10 0 0',
                    // fieldLabel: 'PDT',
                    // labelWidth: 100,
                    xtype:pdtComboBox,
                    labelWidth: 122,
                    margin: '0 5 0 10',
                    width: 275,
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                margin: '10 0 0 10',
                items: [{
                    // id: 'nowStatus',
                    xtype: projectNumberCombo,
                    // margin: '0 5 0 0',
                    // width: 275,
                },{
                    id: 'projectActualTimeFrom',
                    // fieldLabel:  '<font size=1  >项目实际开始时间,从</font>',
                    fieldLabel:  '项目实际开始时间,从',
                    xtype: 'datefield',
                    format:'Y-m-d',
                    labelWidth: 135,
                    margin: '0 5 0 10',
                    width: 315,
                },{
                    id: 'projectActualTimeTo',
                    fieldLabel:  '到',
                    xtype: 'datefield',
                    format:'Y-m-d',
                    labelWidth: 120,
                    margin: '0 5 0 10',
                    width: 275,
                }]
            },{
                xtype: 'container',
                layout: 'hbox',
                margin: '10 0 0 10',
                items: [{
                    // id: 'pdtManager',
                    // fieldLabel:  'PDT经理',
                    xtype: pdtManagerComboBox,
                    // margin: '0 5 0 0',
                    // width: 275,
                },{
                    id: 'actualProjectName',
                    fieldLabel:  '实际执行项目名称',
                    xtype: 'textfield',
                    labelWidth: 135,
                    margin: '0 5 -20 10',
                    width: 315,
                },{
                    fieldLabel: '任务书文档编号',
                    id: 'workBookNumber',
                    xtype: 'textfield',
                    labelWidth: 120,
                    margin: '0 5 0 10',
                    width: 275,
                },{
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 20 10',
                    items: [{
                        text: '查询',
                        iconCls : 'icon-search',
                        name: 'phone',
                        margin: '0 100 0 10',
                        xtype: 'button',
                        width: 75,
                        handler: function () {
                            doSearch()
                        }
                    }]
                }]
            },
            //     {
            //     xtype: 'container',
            //     layout: 'hbox',
            //     margin: '10 0 0 10',
            //     items: [{
            //         // id: 'selectYearFrom',
            //         // fieldLabel:  '选择年份(从)',
            //         xtype: yearComboBox,
            //         // labelWidth: 120,
            //         // margin: '0 5 -20 10',
            //         // width: 285,
            //     },{  xtype : 'radiogroup',
            //             fieldLabel : '是否显示PDT汇总数据',
            //             margin: '10 0 0 10',
            //             // width: 285,
            //             labelWidth: 160,
            //             name:'radioPdt',
            //             id:'radioPdtId',
            //             items : [{
            //                 boxLabel : '是',
            //                 name:'radioPdt',
            //                 inputValue : '1',
            //                 handler: function () {
            //                     let yearValue= Ext.getCmp('yearComboBox').getValue();
            //                     whetherLookProjectPDT(yearValue,'否');
            //
            //                 }
            //             }, {
            //                 boxLabel : '否',
            //                 name:'radioPdt',
            //                 inputValue : '0',
            //                 checked:true,
            //                 handler: function () {
            //                     let yearValue= Ext.getCmp('yearComboBox').getValue();
            //                     whetherLookProjectPDT(yearValue,'是');
            //
            //                 }
            //             }]
            //         },{  xtype : 'radiogroup',
            //             fieldLabel : '是否显示项目类型汇总数据',
            //             margin: '10 0 0 10',
            //             labelWidth: 170,
            //             name:'radioType',
            //             id:'radioTypeId',
            //             items : [{
            //                 boxLabel : '是',
            //                 name:'radioType',
            //                 inputValue : '1',
            //                 handler: function () {
            //                     let yearValue= Ext.getCmp('yearComboBox').getValue();
            //                     whetherLookProjectType(yearValue,'否');
            //
            //                 }
            //             }, {
            //                 boxLabel : '否',
            //                 name:'radioType',
            //                 inputValue : '0',
            //                 checked:true,
            //                 handler: function () {
            //                     let yearValue= Ext.getCmp('yearComboBox').getValue();
            //                     whetherLookProjectType(yearValue,'是');
            //
            //                 }
            //             }]
            //         }]
            // },
                ctProjectGroupGrid],
        };


        var yearSelectForm = {
            // title: '<font size=4 color=blue bold >项目群报表</font>',
            xtype: 'fieldset',
            region: 'center',
            margin: '5 0 0 10',
            align: 'center',
            // height:2000,
            id: 'selectForm',
            width: '98%',
            hidden: false,
            // hideLabel: true,
            // frame: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                margin: '10 0 0 10',
                items: [{
                    // id: 'selectYearFrom',
                    // fieldLabel:  '选择年份(从)',
                    xtype: yearComboBox,
                    // labelWidth: 120,
                    // margin: '0 5 -20 10',
                    // width: 285,
                },{  xtype : 'radiogroup',
                    fieldLabel : '是否显示PDT汇总数据',
                    margin: '10 0 0 10',
                    // width: 285,
                    labelWidth: 160,
                    name:'radioPdt',
                    id:'radioPdtId',
                    items : [{
                        boxLabel : '是',
                        name:'radioPdt',
                        inputValue : '1',
                    }, {
                        boxLabel : '否',
                        name:'radioPdt',
                        inputValue : '0',
                        checked:true,
                    }],
                    listeners: {
                        change: function (field, newValue, oldValue) {
                            var value = newValue.radioPdt;
                            let yearValue= Ext.getCmp('yearComboBox').getValue();
                            if(value&&"1"==value){
                                whetherLookProjectPDT(yearValue,'是');
                            }
                            if(value&&"0"==value){
                                whetherLookProjectPDT(yearValue,'否');
                            }
                        },
                    }
                },{  xtype : 'radiogroup',
                    fieldLabel : '是否显示项目类型汇总数据',
                    margin: '10 0 0 10',
                    labelWidth: 170,
                    name:'radioType',
                    id:'radioTypeId',
                    items : [{
                        boxLabel : '是',
                        name:'radioType',
                        inputValue : '1',

                    }, {
                        boxLabel : '否',
                        name:'radioType',
                        inputValue : '0',
                        checked:true,

                    }],
                    listeners: {
                        change: function (field, newValue, oldValue) {
                            var value = newValue.radioType;
                            let yearValue= Ext.getCmp('yearComboBox').getValue();

                            if(value&&"1"==value){
                                whetherLookProjectType(yearValue,'是');
                            }
                            if(value&&"0"==value){
                                whetherLookProjectType(yearValue,'否');
                            }
                        },
                    }
                }]
            }],
        };

        this.items = [ projectGroupReportForm,projectGroupChartGrid,projectGroupChartGrid2,yearSelectForm];

        this.callParent();

    },

    exportReport: function() {
        let data = getDate();
        if(Ext.getCmp('projectActualTimeFrom').getValue()){
            console.log("执行了有值")
            data['projectRealActionTimeFrom']=Ext.util.Format.date(new Date(Ext.getCmp('projectActualTimeFrom').getValue()),'Y-m-d H:i:s');

        }
        if(Ext.getCmp('projectActualTimeTo').getValue()){
            data['projectRealActionTimeTo']=Ext.util.Format.date(new Date(Ext.getCmp('projectActualTimeTo').getValue()),'Y-m-d H:i:s');
        }
        window.location.href = '/Windchill/ptc1/projectGroup/exportProjectGroup?data='+Ext.encode(data);
    },
    listeners: {
        'afterrender': function () {
            let yearValue= Ext.getCmp('yearComboBox').getValue();
            //规划内外项目执行情况
            whetherLookProjectPerform();
            //各产品线规划内外项目分布情况
            whetherLookProjectPDT(yearValue,'');
            //各类型项目执行情况
            whetherLookProjectType(yearValue,'');
        },
        'beforerender': function () {
            // whetherLookProjectPerform();
            // whetherLookProjectPDT();
            // whetherLookProjectType();

        },

    },

});



////////////////////Function Area//////////////////////////////





