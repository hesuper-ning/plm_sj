//项目执行状况汇总表
var option = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    title: {
        // margin:300,
        // left:'25%',
        left: 'center',
        text: '规划内外项目执行情况',
        textStyle:{

            color:'#0000cc',        //颜色
            fontStyle:'normal',     //风格
            fontWeight:'normal',    //粗细
            fontFamily:'Microsoft yahei',   //字体
            fontSize:23,     //大小
            align:'center'   //水平对齐
        }
    },
    legend: {
        type: 'scroll',
        orient: 'vertical',
        right: 5,
        top: 180,
    },
    grid: {
        x:10,
        y:75,
        // y2:75,
        // left: '3%',
        // right: '4%',
        // bottom: '3%',
        containLabel: true
    },
    xAxis: [
        {
            type: 'category',
            data: ['规划内', '规划外']
        }
    ],
    yAxis: [
        {
            type: 'value'
        }
    ],
    series: [


    ],

};



//PDT
var option2 = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    title: {
        left: 'center',
        text: '各产品线规划内外项目分布情况',
        textStyle:{
            color:'#0000cc',        //颜色
            fontStyle:'normal',     //风格
            fontWeight:'normal',    //粗细
            fontFamily:'Microsoft yahei',   //字体
            fontSize:23,     //大小
            align:'center'   //水平对齐
        }
    },
    legend: {
        type: 'scroll',
        orient: 'vertical',
        right: 1,
        top: 180,
    },
    grid: {
        x:20,
        y:75,
        // left: '3%',
        // right: '4%',
        // bottom: '3%',
        containLabel: true
    },
    xAxis: [
        {
            type: 'category',
            axisLabel: {
                interval:0,
                formatter:function(params){

                    let newParamsName = "";// 最终拼接成的字符串
                    let paramsNameNumber = params.length;// 实际标签的个数
                    let provideNumber = 4;// 每行能显示的字的个数
                    let rowNumber = Math.ceil(paramsNameNumber / provideNumber);// 换行的话，需要显示几行，向上取整
                    /**
                     * 判断标签的个数是否大于规定的个数， 如果大于，则进行换行处理 如果不大于，即等于或小于，就返回原标签
                     */
                    // 条件等同于rowNumber>1
                    if (paramsNameNumber > provideNumber) {
                        /** 循环每一行,p表示行 */
                        for (let p = 0; p < rowNumber; p++) {
                            let tempStr = "";// 表示每一次截取的字符串
                            let start = p * provideNumber;// 开始截取的位置
                            let end = start + provideNumber;// 结束截取的位置
                            // 此处特殊处理最后一行的索引值
                            if (p == rowNumber - 1) {
                                // 最后一次不换行
                                tempStr = params.substring(start, paramsNameNumber);
                            } else {
                                // 每一次拼接字符串并换行
                                tempStr = params.substring(start, end) + "\n";
                            }
                            newParamsName += tempStr;// 最终拼成的字符串
                        }

                    } else {
                        // 将旧标签的值赋给新标签
                        newParamsName = params;
                    }
                    //将最终的字符串返回
                    return newParamsName
                }
            }
        }
    ],
    yAxis: [
        {
            type: 'value'
        }
    ],
    series: [


    ]
};



//项目状态
var option3 = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    title: {
        text: '各类型项目执行情况',
        left:'center',
        textStyle:{
            color:'#0000cc',        //颜色
            fontStyle:'normal',     //风格
            fontWeight:'normal',    //粗细
            fontFamily:'Microsoft yahei',   //字体
            fontSize:23,     //大小
            align:'center',   //水平对齐
            marginLeft:100
        }
    },
    legend: {
        type: 'scroll',
        orient: 'vertical',
        right: 10,
        top: 180,
    },
    grid: {
        x:10,
        y:75,
        // x2:20,
        // y2:100,
        // left: '3%',
        // right: '4%',
        // bottom: '3%',
        containLabel: true
    },
    xAxis: [
        {    type: 'category',
            axisLabel: {
                interval:0,
                formatter:function(params){

                    let newParamsName = "";// 最终拼接成的字符串
                    let paramsNameNumber = params.length;// 实际标签的个数
                    let provideNumber = 4;// 每行能显示的字的个数
                    let rowNumber = Math.ceil(paramsNameNumber / provideNumber);// 换行的话，需要显示几行，向上取整
                    /**
                     * 判断标签的个数是否大于规定的个数， 如果大于，则进行换行处理 如果不大于，即等于或小于，就返回原标签
                     */
                    // 条件等同于rowNumber>1
                    if (paramsNameNumber > provideNumber) {
                        /** 循环每一行,p表示行 */
                        for (let p = 0; p < rowNumber; p++) {
                            let tempStr = "";// 表示每一次截取的字符串
                            let start = p * provideNumber;// 开始截取的位置
                            let end = start + provideNumber;// 结束截取的位置
                            // 此处特殊处理最后一行的索引值
                            if (p == rowNumber - 1) {
                                // 最后一次不换行
                                tempStr = params.substring(start, paramsNameNumber);
                            } else {
                                // 每一次拼接字符串并换行
                                tempStr = params.substring(start, end) + "\n";
                            }
                            newParamsName += tempStr;// 最终拼成的字符串
                        }

                    } else {
                        // 将旧标签的值赋给新标签
                        newParamsName = params;
                    }
                    //将最终的字符串返回
                    return newParamsName
                }
            }

        }
    ],
    yAxis: [
        {
            type: 'value'
        }
    ],
    series: [


    ]
};





