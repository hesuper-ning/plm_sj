

//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}

function getDate() {
    var data = {
        planProjectName: Ext.getCmp('planProjectNameCombo').getValue(),
        projectStatus: Ext.getCmp('projectStatus').getValue(),
        pdt: Ext.getCmp('pdtComboBox').getValue(),
        projectNumber: Ext.getCmp('projectNumberCombo').getValue(),
        // projectRealActionTimeFrom: Ext.getCmp('projectActualTimeFrom').getValue(),
        // projectRealActionTimeTo: Ext.getCmp('projectActualTimeTo').getValue(),
        pdtManager: Ext.getCmp('pdtManagerComboBox').getValue(),
        projectName: Ext.getCmp('actualProjectName').getValue(),
        workBookNumber: Ext.getCmp('workBookNumber').getValue(),


    };
    return data;
}
function doSearch(){
    let data = getDate();
    if(Ext.getCmp('projectActualTimeFrom').getValue()){
        console.log("执行了有值")
        data['projectRealActionTimeFrom']=Ext.util.Format.date(new Date(Ext.getCmp('projectActualTimeFrom').getValue()),'Y-m-d H:i:s');

    }
    if(Ext.getCmp('projectActualTimeTo').getValue()){
        data['projectRealActionTimeTo']=Ext.util.Format.date(new Date(Ext.getCmp('projectActualTimeTo').getValue()),'Y-m-d H:i:s');
    }
    // data['isPageQuery']=false;
    // data['limit']=25;
    // data['page']=1;
    Ext.getStore('ctProjectGroupStore').load({
        params: data,
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询项目群报表失败，请联系管理员！');
            }
        }
    });

}
//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    value=value.substring(0,10);
    return value;
}
function lookUpChart() {
    Ext.getCmp('projectGroupChartGrid').setVisible (false);
    // var projectGroupChartGrid = echarts.init(document
    //     .getElementById("projectGroupChartGrid"));
    // projectGroupChartGrid.setOption(option, true);
    // var projectGroupChartGrid2 = echarts.init(document
    //     .getElementById("projectGroupChartGrid2"));
    // projectGroupChartGrid2.setOption(option2, false);

}
//显示项目执行状况
function whetherLookProjectPerform() {
    let projectGroupChart = echarts.init(document
        .getElementById("projectGroupChartGridT"));
    projectGroupChart.setOption(option, false);
    let yearValue= Ext.getCmp('yearComboBox').getValue();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/projectGroup/getExecutionStatus',
        method : 'GET',
        params:{
            yearValue:yearValue,
        },
        success: function(response, opts) {
            let obj = Ext.decode(response.responseText);
            let series=[];
            for(let i=0,l=obj.data.length;i<l;i++){
                let name=obj.data[i].name;
                let list=obj.data[i].seriesData;
                let valueObj = {
                    name: name,
                    type: 'bar',
                    stack: 'Ad',
                    barWidth : 40,//柱图宽度
                    emphasis: {
                        focus: 'series'
                    },label: {
                        show: true
                    },
                    data:list
                }
                series.push(valueObj);
            }
            //设置表单值
            projectGroupChart.setOption({
                series:series
            });
        },
        failure: function(response, opts) {
            alert('错误：刷新报表失败，请检查网络！');
            loadMarsk.hide();
        }
    });

}
function whetherLookProjectPerform2(){
    Ext.getCmp('projectGroupChartGrid').setVisible (false);
}
function whetherLookProjectPDT(yearValue,flag){
    let projectGroupChart2 = echarts.init(document
        .getElementById("projectGroupChartGridT3"));
    projectGroupChart2.setOption(option2, true);
    Ext.Ajax.request({
        url: '/Windchill/ptc1/projectGroup/getExecutionStatusByPDT',
        method : 'GET',
        params:{
            yearValue:yearValue,
            flag:flag,
        },
        success: function(response, opts) {
            let obj = Ext.decode(response.responseText);
            let series=[];
            let inPlan= {
                name: '规划内',
                type: 'bar',
                stack: 'Ad',
                barWidth : 40,//柱图宽度
                emphasis: {
                    focus: 'series'
                },label: {
                    show: true
                },
                data: obj.data.inPlan
            }
            series.push(inPlan);
            let outPlan= {
                name: '规划外',
                type: 'bar',
                stack: 'Ad',
                barWidth : 40,//柱图宽度
                emphasis: {
                    focus: 'series'
                },label: {
                    show: true
                },
                data:obj.data.outPlan
            }
            series.push(outPlan);

            //设置表单值
            projectGroupChart2.setOption({
                series:series,
                xAxis: [{
                    data: obj.data.pdtName
                }],
            });
        },
        failure: function(response, opts) {
            alert('错误：刷新报表失败，请检查网络！');
            loadMarsk.hide();
        }
    });
}

function whetherLookProjectType(yearValue,flag){
    let projectGroupChartT3 = echarts.init(document
        .getElementById("projectGroupChartGridT4"));
    projectGroupChartT3.setOption(option3, true);

    Ext.Ajax.request({
        url: '/Windchill/ptc1/projectGroup/getExecutionStatusByStatus',
        method : 'GET',
        params:{
            yearValue:yearValue,
            flag:flag,
        },
        success: function(response, opts) {
            let obj = Ext.decode(response.responseText);
            let series=[];
            let suspendedList= {
                name: '暂停中',
                type: 'bar',
                stack: 'Ad',
                barWidth : 40,//柱图宽度
                emphasis: {
                    focus: 'series'
                },label: {
                    show: true
                },
                data: obj.data.suspendedList
            }
            series.push(suspendedList);
            let runningList= {
                name: '正在运行',
                type: 'bar',
                stack: 'Ad',
                barWidth : 40,//柱图宽度
                emphasis: {
                    focus: 'series'
                },label: {
                    show: true
                },
                data:obj.data.runningList
            }
            series.push(runningList);
            let definedList= {
                name: '未定义',
                type: 'bar',
                stack: 'Ad',
                barWidth : 40,//柱图宽度
                emphasis: {
                    focus: 'series'
                },label: {
                    show: true
                },
                data:obj.data.definedList
            }
            series.push(definedList);
            let cancelledList= {
                name: '已取消',
                type: 'bar',
                stack: 'Ad',
                barWidth : 40,//柱图宽度
                emphasis: {
                    focus: 'series'
                },label: {
                    show: true
                },
                data:obj.data.cancelledList
            }
            series.push(cancelledList);
            let completedList= {
                name: '已完成',
                type: 'bar',
                stack: 'Ad',
                barWidth : 40,//柱图宽度
                emphasis: {
                    focus: 'series'
                },label: {
                    show: true
                },
                data:obj.data.completedList
            }
            series.push(completedList);

            //设置表单值
            projectGroupChartT3.setOption({
                series:series,
                xAxis: [{
                    type: 'category',
                    data: obj.data.typeList
                }],
            });
        },
        failure: function(response, opts) {
            alert('错误：刷新报表失败，请检查网络！');
            loadMarsk.hide();
        }
    });

}

function lookUpChart2() {
    Ext.getCmp('projectGroupChartGrid').setVisible (true);
    Ext.getCmp('projectGroupChartGrid2').setVisible (true);
    Ext.getCmp('projectGroupChartGrid3').setVisible (true);
    let yearValue= Ext.getCmp('yearComboBox').getValue();
    var projectGroupChartGrid = echarts.init(document
        .getElementById("projectGroupChartGrid"));
    projectGroupChartGrid.setOption(option, false);
    var projectGroupChartGrid2 = echarts.init(document
        .getElementById("projectGroupChartGrid2"));
    projectGroupChartGrid2.setOption(option2, true);
    var projectGroupChartGrid3 = echarts.init(document
        .getElementById("projectGroupChartGrid3"));
    projectGroupChartGrid3.setOption(option3, true);
    Ext.Ajax.request({
        url: '/Windchill/ptc1/projectGroup/getExecutionStatus',
        method : 'GET',
        params:{
            yearValue:yearValue,
        },
        success: function(response, opts) {
            let obj = Ext.decode(response.responseText);
            let series=[];
            for(let i=0,l=obj.data.length;i<l;i++){
                let name=obj.data[i].name;
                let list=obj.data[i].seriesData;
                let valueObj = {
                    name: name,
                    type: 'bar',
                    stack: 'Ad',
                    barWidth : 80,//柱图宽度

                    emphasis: {
                        focus: 'series'
                    },
                    data:list
                }
                series.push(valueObj);
            }
            //设置表单值
            projectGroupChartGrid.setOption({
                series:series
            });
        },
        failure: function(response, opts) {
            alert('错误：刷新报表失败，请检查网络！');
            loadMarsk.hide();
        }
    });
    Ext.Ajax.request({
        url: '/Windchill/ptc1/projectGroup/getExecutionStatusByPDT',
        method : 'GET',
        params:{
            yearValue:yearValue,
        },
        success: function(response, opts) {
            let obj = Ext.decode(response.responseText);
            let series=[];
            let inPlan= {
                name: '规划内',
                type: 'bar',
                stack: 'Ad',
                barWidth : 80,//柱图宽度
                emphasis: {
                    focus: 'series'
                },
                data: obj.data.inPlan
            }
            series.push(inPlan);
            let outPlan= {
                name: '规划外',
                type: 'bar',
                stack: 'Ad',
                barWidth : 80,//柱图宽度
                emphasis: {
                    focus: 'series'
                },
                data:obj.data.outPlan
            }
            series.push(outPlan);

            //设置表单值
            projectGroupChartGrid2.setOption({
                series:series,
                xAxis: [{
                    data: obj.data.pdtName,
                    axisLabel: {
                        interval:0,
                        // rotate:40,
                        formatter:function(value){

                            let ret = "";  //拼接加\n返回的类目项
                            let maxLength = 2;  //每项显示文字个数
                            let valLength = value.length;  //X轴类目项的文字个数
                            let rowN = Math.ceil(valLength / maxLength); //类目项需要换行的行数
                            if (rowN > 1) { //如果类目项的文字大于3,
                                for (let i = 0; i < rowN; i++) {
                                    let temp = "";//每次截取的字符串
                                    let start = i * maxLength;//开始截取的位置
                                    let end = start + maxLength;//结束截取的位置
                                    //这里也可以加一个是否是最后一行的判断，但是不加也没有影响，那就不加吧
                                    temp = value.substring(start, end) + "\n";
                                    ret += temp; //凭借最终的字符串
                                }
                                return ret;
                            }else {
                                return value;
                            }
                        }
                    }
                }],
            });
        },
        failure: function(response, opts) {
            alert('错误：刷新报表失败，请检查网络！');
            loadMarsk.hide();
        }
    });


   Ext.Ajax.request({
        url: '/Windchill/ptc1/projectGroup/getExecutionStatusByStatus',
        method : 'GET',
        params:{
            yearValue:yearValue,
        },
        success: function(response, opts) {
            let obj = Ext.decode(response.responseText);
            let series=[];
            let suspendedList= {
                    name: '暂停中',
                    type: 'bar',
                    stack: 'Ad',
                barWidth : 80,//柱图宽度
                    emphasis: {
                    focus: 'series'
                },
                data: obj.data.suspendedList
            }
            series.push(suspendedList);
            let runningList= {
                    name: '正在允许',
                    type: 'bar',
                    stack: 'Ad',
                barWidth : 80,//柱图宽度
                    emphasis: {
                    focus: 'series'
                },
                data:obj.data.runningList
            }
            series.push(runningList);
            let definedList= {
                    name: '未定义',
                    type: 'bar',
                    stack: 'Ad',
                barWidth : 80,//柱图宽度
                    emphasis: {
                    focus: 'series'
                },
                data:obj.data.definedList
            }
            series.push(definedList);
            let cancelledList= {
                    name: '已取消',
                    type: 'bar',
                    stack: 'Ad',
                barWidth : 80,//柱图宽度
                    emphasis: {
                    focus: 'series'
                },
                data:obj.data.cancelledList
            }
            series.push(cancelledList);

            //设置表单值
            projectGroupChartGrid3.setOption({
                series:series,
                xAxis: [{
                        type: 'category',
                        data: obj.data.typeList,

                }],
            });
        },
        failure: function(response, opts) {
            alert('错误：刷新报表失败，请检查网络！');
            loadMarsk.hide();
        }
    });
}