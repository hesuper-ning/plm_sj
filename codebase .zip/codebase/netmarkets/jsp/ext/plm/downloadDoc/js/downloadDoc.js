Ext.define('PLM.view.downloadDoc', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.downloadDoc',
    border: false,
    autoScroll: false,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'downloadDoc',
    initComponent: function () {
        var me = this;
        var mainPanel = {
            xtype:'form',
            height: 200,
            id:"mainPanel",
            border:false,
            padding:10,
            // margin: '20 20 20 20',
            items:[{
                border:false,
                html:'确定下载文档内容为压缩文件吗？'
                //margin: '50 50 50 120'
            },{
                xtype: 'panel',
                layout: 'hbox',
                border:false,
                margin: '30 50 50 20',
                items:[{
                    xtype: 'button',
                    text:'确定',
                    scale: 'medium',
                    id:'confirmCreate',
                    name:'confirmCreate',
                    handler:function () {
                        t();
                    }
                },{
                    xtype: 'button',
                    text:'关闭',
                    scale: 'medium',
                    margin: '0 0 0 30',
                    handler:function () {
                        window.close();
                    }
                }]
            }]
        }

/////////////////////////Main Panel items//////////////////////////////////
        this.items=[
            {
                region     : 'center',
                collapsible: false,
                height      : '70%',
                items:[mainPanel],
            }
        ];

/////////////////////////Main Panel items//////////////////////////////////

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            //downloadDoc();
        }
    }
});


function downloadDoc() {
    if(error != ""){
        alert(error);
        window.close();
        return;
    }
    var mainPanel = Ext.getCmp("mainPanel");
    var myMask = new Ext.LoadMask({
        msg: '数据正在处理中，请稍等...',
        target:mainPanel
    });
    myMask.show();
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/doc/downloadDoc',
        method: "POST",
        params: {
            jsonData:Ext.encode(jsonData),
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj.message=='success') {
                Ext.Msg.alert(obj.message);
                 myMask.hide();
            }else{
                myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'数据删除失败，请检查网络！')
            myMask.hide();
        }
    });
}

function t() {
    if(error != ""){
        alert(error);
        window.close();
        return;
    }
    var mainPanel = Ext.getCmp("mainPanel");
    var myMask = new Ext.LoadMask({
        msg: '数据正在处理中，请稍等...',
        target:mainPanel
    });
    myMask.show();
    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/doc/downloadDoc', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    debugger
    xmlResquest.onload = function (oEvent) {
        debugger
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
                myMask.hide();
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "document_contents"+timestamp+".zip";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
            myMask.hide();
            window.close();
        }
    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "jsonData=" + Ext.encode(jsonData)
    );
}