<%@ page import="java.sql.*,
                 java.util.ArrayList,
                 java.util.*,
                 wt.part.WTPart,
                 wt.fc.ReferenceFactory,
                 wt.fc.Persistable,
                 ext.plm.util.*,
                 ext.plm.common.*,
                 wt.type.TypedUtilityServiceHelper,
                 org.json.*,
                 wt.vc.wip.WorkInProgressHelper,
                 wt.vc.wip.Workable,
                 com.ptc.windchill.enterprise.change2.commands.RelatedChangesQueryCommands,
                 wt.change2.WTChangeRequest2,
                 wt.change2.Changeable2,
                 wt.fc.QueryResult,
                 wt.doc.WTDocument,
                 wt.epm.EPMDocument,
                 wt.maturity.PromotionNotice,
                 wt.change2.WTChangeActivity2"
         pageEncoding="utf-8" %>
<%@ page import="com.ptc.netmarkets.util.beans.*"
%>
<%@ page import="com.ptc.netmarkets.util.misc.*"
%>
<%@ page import="com.ptc.netmarkets.util.wizard.*,java.io.*"
%>
<%@ page import="com.ptc.windchill.classproxy.ConsoleClassProxy"
%>
<%@ page import="com.ptc.netmarkets.object.objectResource,
                 com.ptc.netmarkets.model.*,
                 com.ptc.netmarkets.role.NmRoleHelper,
                 com.ptc.netmarkets.user.NmUserHelper,
                 com.ptc.netmarkets.projectPlan.NmProjectPlanCommands,
                 com.ptc.core.ui.validation.*,
                 com.ptc.core.components.forms.FormResult,
                 com.ptc.core.components.forms.FormResultAction,
                 java.util.*"
%>
<%@ page import="java.util.ResourceBundle"
%>
<%@ page import="com.ptc.core.meta.common.TypeIdentifier" %>
<%@ page import="wt.type.ClientTypedUtility" %>
<%@ page import="com.ptc.core.lwc.common.view.TypeDefinitionReadView" %>
<%@ page import="com.ptc.core.lwc.server.TypeDefinitionServiceHelper" %>
<%@ page import="java.text.DateFormat" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="wt.folder.FolderHelper" %>
<%@ page import="wt.content.ApplicationData" %>
<%@ page import="ext.plm.supplier.CtSupplierDocumentLogic" %>
<jsp:useBean id="wtcontext" class="wt.httpgw.WTContextBean" scope="request"/>
<%
    //
    wtcontext.setRequest(request);

%>
<jsp:useBean id="nmcontext" class="com.ptc.netmarkets.util.beans.NmContextBean" scope="request"/>
<%
    //
    request.setCharacterEncoding("UTF-8");
    if (request.getParameter("portlet") != null)
        nmcontext.setPortlet(request.getParameter("portlet"));
    nmcontext.setRequest(request);
    nmcontext.setResponse(response);
    nmcontext.adjustContext(request);
%>
<jsp:useBean id="localeBean" class="com.ptc.netmarkets.util.beans.NmLocaleBean" scope="request"/>
<jsp:useBean id="sessionBean" class="com.ptc.netmarkets.util.beans.NmSessionBean" scope="session"/>
<%
    sessionBean.setDoneCB(false);
    NmCommandBean cb1 = new NmCommandBean();
    cb1.setInBeginJsp(true);
    cb1.setOpenerCompContext(request.getParameter("compContext"));
    cb1.setOpenerElemAddress(NmCommandBean.convert(request.getParameter("openerElemAddress")));
    cb1.setCompContext(NmCommandBean.convert(request.getParameter("compContext")));
    cb1.setElemAddress(NmCommandBean.convert(request.getParameter("elemAddress")));
    cb1.setSessionBean(sessionBean);
    cb1.setRequest(request);
    cb1.setResponse(response);
    cb1.setOut(out);
    cb1.setWtcontextBean(wtcontext);
    cb1.setContextBean(nmcontext);

    ArrayList oidList = cb1.getSelectedOidForPopup();
    JSONArray dataList = new JSONArray();
    ReferenceFactory renferenceFactory = new ReferenceFactory();
    String error = "";
    List<ApplicationData> attachments = new ArrayList<>();
    for (int i = 0; i < oidList.size(); i++) {
        Object obj = oidList.get(i);
        NmOid nmOid = (NmOid) obj;
        Persistable persistable = renferenceFactory.getReference(
                nmOid.toString()).getObject();
        JSONObject map = new JSONObject();
        if (persistable instanceof WTDocument) {
            WTDocument doc = (WTDocument) persistable;
            List<ApplicationData> attachment = CtSupplierDocumentLogic.getAttachmentByDoc(doc);
            ApplicationData primaryContent = CtDocUtil.getPrimaryContent(doc);
            if(CtFormatUtil.hasContent(attachment))
                attachments.addAll(attachment);
            if (CtFormatUtil.hasContent(primaryContent))
                attachments.add(primaryContent);

            map.put("fileNumber", doc.getNumber());
            map.put("fileName", doc.getName());
            map.put("version", CtVersionUtil.getVersionInfo(doc));
            dataList.put(map);
        } else {
            error = "未选择有效对象，仅限文档进行“将文件下载为压缩文件”操作！！！";
            System.out.println(error);
            break;
        }
    }
    if (!CtFormatUtil.hasContent(error)){
        if (!CtFormatUtil.hasContent(attachments)){
            error = "选择的文档对象无有效下载文件！！！";
        }
    }

    response.setCharacterEncoding("UTF-8");
    String jsonString = dataList.toJSONString();
    System.out.println(jsonString);
    String containerOid = request.getParameter("ContainerOid");
    String folderOid = request.getParameter("oid");
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css"/>
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript"
            src="/Windchill/netmarkets/jsp/ext/plm/downloadDoc/js/downloadDoc.js"></script>
</head>
<body>

<script>
    var jsonData = <%=jsonString%>;

    var ContainerOid = "<%=containerOid%>";
    var FolderOid = "<%=folderOid%>";
    var error = "<%=error%>";
    // ==============layout define area=================================//
    Ext.onReady(function () {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {
                    xtype: 'panel',
                    region: 'center',
                    border: false,
                    items: [{
                        xtype: 'downloadDoc'
                    }]
                }

            ]
        });
    });
</script>
</body>
</html>

