Ext.define('PLM.view.CtWorkItemUploadFilePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtWorkItemUploadFilePanel',
    border: false,
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'CtWorkItemUploadFilePanel',
    initComponent: function () {
        var WorkItemFilePanel = Ext.create('Ext.panel.Panel', {
            width: '100%',
            autoHeight: true,
            border: false,
            id: 'WorkItemFilePanel',
            items: [{
                xtype: 'CtWorkItemFileList',
            }]
        });

        this.items = [WorkItemFilePanel];
        this.callParent();
    }
});
