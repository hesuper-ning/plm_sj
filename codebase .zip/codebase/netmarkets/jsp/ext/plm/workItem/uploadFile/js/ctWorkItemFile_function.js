Ext.Ajax.timeout = 60000; // 60秒

/**
 * 请求操作
 * @param url 请求地址
 * @param method 请求方式
 * @param params 参数
 * @param successCFN 成功的回调方法，会将返回的数据的“data”装进该方法中
 * @param failCFN 失败的回调方法
 * @param finallyFN 成功或失败都执行的方法
 * @param requestFailMsg 请求失败的提示信息
 */
function doRequest(params){
    console.log('doRequest',params)
    var myMask = null;
    if (params['cmpId']) {
        myMask = new Ext.LoadMask({msg: "正在处理，请稍候......", target: Ext.getCmp(params['cmpId'])});
    }
    if (myMask) myMask.show();
    if (typeof workItemOid !== 'undefined') {
        if (params['url'].indexOf('?') != -1) {
            params['url'] += '&workItemOid=' + workItemOid
        } else {
            params['url'] += '?workItemOid=' + workItemOid
        }
    }
    Ext.Ajax.request({
        // scope:this,
        async: false, // FALSE 同步访问，防止后台ZEcFormMaster表产生重复数据
        url: params['url'],
        method: params['method'],
        params: params['params'],
        headers: params['headers'],
        jsonData: params['jsonData'],
        success: function (response, opts) {
            if (myMask) myMask.hide();
            var obj = Ext.decode(response.responseText);
            if (obj['status'] == '200') {
                if (params['successCFN']) params['successCFN'](obj['data']);

                if (obj['message'] && obj['message'] !== 'success') {
                    alert(obj['message']);
                }
            } else {
                if (params['failCFN']) params['failCFN']();
                alert(obj['message']);
            }
            if (params['finallyFN']) params['finallyFN']();
        },
        failure: function (response, opts) {
            if (myMask) myMask.hide();
            if (params['failCFN']) params['failCFN']();
            if (params['finallyFN']) params['finallyFN']();
            if (params['requestFailMsg']) alert(params['requestFailMsg']);
        }
    });
}



/**
 * 打开上传文件窗口，并发送请求
 * @param url 请求地址
 * @param successCFN 成功回调函数
 * @param failCFN 失败回调函数
 */
function commitUpdateFile(params) {
console.log(11111);
//debugger;
    var form = Ext.getCmp('CtUploadFile').getForm();
    //var form = this.up('form').getForm();
    //if(form.isValid()){
        //debugger;
        console.log('file', form);
        var file = form.findField("file").getValue();
        console.log('file', file)
        file = file.toLowerCase();
        form.submit({
            url: params['url'],
            method: params['method'],
            waitMsg: '正在上传中...',
            success: function(form, action) {
                var result = JSON.parse(action.response.responseText);
                if (result['status'] == '200') {
                    if (params['successCFN']) params['successCFN'](result['data']);
                    //uploadWindow.destroy();
                } else {
                    if (params['failCFN']) params['failCFN']();
                    //alert(result['message'])
                }
            },
            failure: function(form,action) {
                if (action.response && action.response.responseText) {
                    try {
                        var result = JSON.parse(action.response.responseText);
                        if (result['status'] == '200') {
                            if (params['successCFN']) params['successCFN'](result['data']);
                            //uploadWindow.destroy();
                        } else {
                            if (params['failCFN']) params['failCFN']();
                            //alert(result['message'])
                        }
                    } catch (e) {
                        //alert(action.response.responseText);
                    }
                } else {
                    var obj = action.result;
                    console.log(obj);
                    /*var message = action.result.message;
                    if (message) {
                        if (params['failCFN']) params['failCFN']();
                        //alert(message);
                    }*/
                }
            }
        });
    //}

}


function uploadFile(uploadFile, url) {
    var formData = new FormData();
    formData.append('file', uploadFile);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.send(formData);
    xhr.onload = function() {
        if (xhr.status === 200) {
            Ext.getStore('workItemUploadFileStore').load();
        } else {
            alert('上传失败！');
        }
    };
}

//拖拽上传
function dropUploadFile() {

    let panelBody = document.getElementById('CtWorkItemUploadFilePanel-body');
    let panelChildren = document.getElementById('CtWorkItemUploadFilePanel-innerCt');
    let oldClass = document.getElementById('CtWorkItemUploadFilePanel-body').className;

    // 获取拖拽区域和文件输入框
    var dropZone = document.getElementById('CtWorkItemUploadFilePanel-outerCt');

    // 监听拖拽事件
    dropZone.addEventListener('dragover', function(e) {
        e.stopPropagation();
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy'; // 显示拖拽效果
        panelBody.className='dropHighlight_Multiple';
        panelChildren.style.opacity='0.1';

    });
    // 监听离开
    dropZone.addEventListener('dragleave', function(e) {
        e.stopPropagation();
        e.preventDefault();
        panelBody.className=oldClass
        panelChildren.style.opacity='';

    });

    // 监听放置事件
    dropZone.addEventListener('drop', function(e) {
        panelBody.className=oldClass
        panelChildren.style.opacity='';
        e.stopPropagation();
        e.preventDefault();
        // 获取拖拽的文件列表
        var files = e.dataTransfer.files; // FileList对象
        // 遍历文件列表，处理每个文件
        for (var i = 0; i < files.length; i++) {
            var file = files[i]; // File对象
            uploadFile(file,t_uploadFileUrl);
        }
    });
}



