<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>
<%@ page import="ext.plm.ec.CtEcLogic" %>
<%@ page import="ext.plm.util.CtProjectUtil" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="org.apache.commons.collections4.CollectionUtils" %>
<%@ page import="wt.change2.WTChangeActivity2" %>
<%@ page import="wt.change2.WTChangeOrder2" %>
<%@ page import="wt.change2.WTChangeRequest2" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.inf.container.WTContainer" %>
<%@ page import="wt.pdmlink.PDMLinkProduct" %>
<%@ page import="wt.projmgmt.admin.Project2" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="java.util.List" %>
<%@ page import="com.alibaba.fastjson.JSONObject" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String workItemOid = request.getParameter("oid").replace("%3A",":");
        WorkItem workItem = (WorkItem) CtWTObjectUtil.getObjectByOid(workItemOid);
        Long ida2a2 = workItem.getPersistInfo().getObjectIdentifier().getId();
        String className = WorkItem.class.getName();
        WfAssignedActivity assignedActivity = (WfAssignedActivity)workItem.getSource().getObject();
        String assignedActivityOid = "oid:"+WfAssignedActivity.class.getName()+assignedActivity.getPersistInfo().getObjectIdentifier().getId();
        String baseUrl = "/Windchill/ptc1/ctWorkItem/uploadFile";
        String uploadFileUrl = baseUrl+"/customUpload?workItemOid="+workItem;
                //+"&assignedActivityOid="+assignedActivityOid;
    %>

    <script type="text/javascript">
        var t_allowEdit = true;
        var t_assignedActivityOid = "<%= assignedActivityOid %>";
        var t_workItemOid = "<%= workItemOid %>";
        var t_className = "<%= className %>";
        var t_uploadFileUrl = "<%=uploadFileUrl%>";
        var t_baseUrl = "<%=baseUrl%>";

    </script>

    <style type="text/css">
        .x-grid-with-row-lines .x-grid-td {
            vertical-align:middle; /* 单元格垂直居中 */
        }
        .dropHighlight_Multiple{
            background: url(/Windchill/netmarkets/images/dragNDrop_Multiple.png) no-repeat;
            background-position: center center;
            background-color:white;
            position: relative;
            z-index: 100;
            border-radius: 7px;
            border: 4px dashed rgb(82,170,222);
        }
        .dragNDrop {
            /* opacity: 0.1; */
            filter:alpha(opacity=10);
            -moz-opacity:0.1;
        }
    </style>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>上传附件</title>
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <style type="text/css">
        .x-toolbar-footer{ background: white; }
    </style>
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/workItem/uploadFile/js/ctWorkItemFile_function.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/workItem/uploadFile/js/ctWorkItemFileList.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/workItem/uploadFile/js/ctWorkItemUploadFile.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>



<script>
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'CtWorkItemUploadFilePanel',
            }]
        });
    });
    //关闭浏览器刷新builder
    window.onbeforeunload = function(event) {
        window.opener.PTC.jca.table.Utils.reload('taskStatusTableId', null, true);
    };


</script>
</body>
</html>