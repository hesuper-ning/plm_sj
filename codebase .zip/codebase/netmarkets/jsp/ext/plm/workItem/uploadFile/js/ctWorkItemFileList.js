var downloadLink = "<a href='/Windchill/ptc1/ctWorkItem/downloadFile?id={0}'  target='_self'>{1}</a>";

Ext.define('PLM.view.CtUploadFile', {
    extend: 'Ext.form.Panel',
    alias: 'widget.CtUploadFile',
    hidden : !t_allowEdit,
    border: false,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtUploadFile',
    layout: 'hbox',
    items: [{
        xtype: 'filefield',
        buttonOnly: true,
        hideEmptyLabel:true ,
        name: 'file',
        id:'fileButton',
        msgTarget: 'side',
        allowBlank: false,
        buttonText: '上传文件',
        listeners: {
            change: function(field, value) {
                let inputFile = document.getElementById('fileButton-button-fileInputEl');
                let file =  inputFile.files.item(0);
                uploadFile(file, t_uploadFileUrl);
            }
        }
    }],
    initComponent: function () {
        this.callParent();
    },
    listeners: {
        'afterrender': function () {
            //拖拽上传
            dropUploadFile();
        }
    }
});







Ext.define('Plm.view.CtWorkItemFileList',{
    extend:'Ext.panel.Panel',
    alias:'widget.CtWorkItemFileList',
    border:false,
    layout:'anchor',
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'CtWorkItemFileList',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent:function(){
        var me = this;

        Ext.define('workItemUploadFileModel', {
            extend: 'Ext.data.Model',
            fields: ['id','assignedActivityOid', 'workItemOid', 'processOid', 'uploadUserOid', 'uploadUser', 'fileName', 'savePath','createTime'],
            idProperty: 'id'
        });

        var workItemUploadFileStore = Ext.create('Ext.data.Store', {
            model: 'workItemUploadFileModel',
            id:'workItemUploadFileStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: t_baseUrl,
                method:'GET',
                extraParams: {
                    'workItemOid': t_workItemOid,
                },
                reader:{
                    type:'json',
                    root: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            //autoLoad:false,
            autoLoad: true,
            listeners: {
                load: function(store, records, successful) {
                    store.sort('createTime', 'ASC'); // 本地排序
                }
            }
        });

        var fileGrid = Ext.create('Ext.grid.Panel', {
            title: '',
            store: workItemUploadFileStore,
            id:'fileGrid',
            autoWidth : true,
            autoScroll:true,
            region:'center',
            height:'auto',
            margin: '0 0 20 0',
            multiSelect : false,
            viewConfig: { enableTextSelection: true },
            selModel: Ext.create('Ext.selection.CheckboxModel', {mode: "SIMPLE", showHeaderCheckbox: true}),
            tbar:t_allowEdit? [{
                xtype: 'CtUploadFile',
            }, {
                iconCls: 'icon icon-delete',
                text: '删除',
                scope: this,
                disabled: false,
                handler: function () {
                    var modelArray = fileGrid.getSelectionModel().getSelection();
                    if(modelArray.length == 0){
                        alert("请您选择要删除的数据！");
                        return;
                    }

                    var flag = confirm('您确定要删除选中内容？');
                    if(flag){
                        var idList = new Array();
                        for(var i = 0; i < modelArray.length; i++){
                            var id = modelArray[i]['data']['id'];
                            if (id) {
                                idList.push(id);
                            }
                        }
                        doRequest({
                            cmpId: 'fileGrid',
                            url: t_baseUrl,
                            method: 'DELETE',
                            headers:{'Content-Type':'application/json'},
                            jsonData: JSON.stringify(idList),
                            successCFN: function (data) {
                                //workItemUploadFileStore.remove(modelArray);
                                Ext.getStore('workItemUploadFileStore').load();
                            }
                        });
                    }
                }
            }]:null,
            fbar:[{
                text: '确定',
                scope: this,
                disabled: false,
                marginRight:15,
                handler:function(){
                    window.close()
                }
            }],
            columns: [
                {
                    xtype: 'rownumberer',
                    text:'序号',
                    width:60,
                    align: 'center',
                    menuDisabled: true
                }, {
                    text: '文件名称',
                    dataIndex: 'fileName',
                    width: '100%',
                    editor: 'textfield',
                    menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        let id = record.get('id');
                        let fileName = record.get('fileName');
                        fileName = fileName.substr(fileName.indexOf("_")+1)
                        metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value = Ext.String.format(downloadLink, id, fileName);
                    }
                }

            ]
        });

        this.items=[fileGrid];
        this.callParent();
    },
    listeners:{
        'afterrender':function(){
            Ext.getStore('workItemUploadFileStore').reload();
        }

    }
});
