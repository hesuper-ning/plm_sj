<%@ page import="ext.plm.supplier.config.CtSupplierDocumentProperties" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page language="java" pageEncoding="UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>>oid=" + oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workitem = (WorkItem) rf.getReference(oid).getObject();
        WTDocument doc = (WTDocument) workitem.getPrimaryBusinessObject().getObject();
        long branchId = doc.getBranchIdentifier();
        //编辑权限判断
        WfAssignedActivity activity = (WfAssignedActivity) workitem.getSource().getObject();
        String actName = activity.getName();
        String actKey = CtSupplierDocumentProperties.getActivityNodeName(actName);
        boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workitem,
                CtSupplierDocumentProperties.getProperty("supplier_allowEdit_roles"));
        System.out.println(">>>>>>>>>>" + allowEdit);
    %>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css"/>
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <%--    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>--%>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctSupplierDocument.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctSupplierDocumentFunction.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script type="text/javascript">

</script>
<script>
    // ==============layout define area=================================//
    //编辑权限
    var allowEdit = '<%= allowEdit %>';
    var actKey = '<%= actKey %>';
    var branchId = '<%= branchId %>';
    var oid = '<%= oid %>';
    Ext.onReady(function () {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {
                    region: 'center',
                    xtype: 'supplierPanel'
                }
            ]
        });
    });
</script>
</body>
</html>
