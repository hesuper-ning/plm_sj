<%@ page import="wt.change2.WTChangeReview" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.type.Typed" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page language="java" pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

<head>
    <%
        boolean allowEdit = true;
        String oid = request.getParameter("oid");//此oid有可能为workItem oid，也可能为对象 oid
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Persistable obj = rf.getReference(oid).getObject();
        if(obj instanceof WTDocument) {
            oid = rf.getReferenceString(obj);
        } else if(obj instanceof WorkItem) {
            WorkItem item = (WorkItem)obj;
            allowEdit = !item.isComplete();
            Typed typedObj = (Typed)item.getPrimaryBusinessObject().getObject();
            oid = rf.getReferenceString(typedObj);
        }
        WTDocument document = (WTDocument) rf.getReference(oid).getObject();
        String externalNumber = document.getNumber();
    %>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js"></script>
    <!-- ExtJS -->
    <script type="text/javascript" src="js/mockSupplierDocument.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script type="text/javascript">
    var loadMarsk = new Ext.LoadMask(document.body, {
        msg : '正在处理，请稍候。。。。。。',
        removeMask : true// 完成后移除,
    });
</script>
<script>
    // ==============layout define area=================================//
    var allowEdit = <%=allowEdit%>;
    var oid = "<%=oid%>";
    var externalNumber = "<%=externalNumber%>";
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {xtype:'panel',
                    region: 'center',
                    border:false,
                    items:[{
                        xtype: 'SupplierDocumentPanel'
                    }]
                }
            ]
        });
    });
</script>
</body>
</html>
