<%@ page import="ext.plm.supplier.config.CtSupplierDocumentProperties" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page language="java" pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>>oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WTDocument doc = (WTDocument) rf.getReference(oid).getObject();
        long branchId = doc.getBranchIdentifier();
    %>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <%--    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>--%>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctSupplierDocument.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctSupplierDocumentFunction.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script type="text/javascript">

</script>
<script>
    // ==============layout define area=================================//
    //编辑权限
    var allowEdit = false;
    var actKey ='';
    var branchId ='<%= branchId %>';
    var oid ='<%= oid %>';
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {xtype:'panel',
                    region: 'center',
                    border:false,
                    items:[{
                        xtype: 'supplierPanel'
                    }]
                }
                ]
        });
    });
</script>
</body>
</html>
