Ext.define('PLM.view.supplierPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.supplierPanel',
    border: false,
    layout: 'anchor',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {

        //***************加载表单信息**********************
        var me = this;

        //========可编辑列头显示控制============
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';

        //提交
        var partNumberText = '物料编号';
        var docNumberText = '系统文件编号';
        var tagIdText = '编号';
        var docDescriptionText = '文档说明';
        var versionText = '版本(请选择)';
        var versionStartText = '版本状态';
        var attachmentText = '附件';
        var outFormatRequirementText = '外发格式要求<br/>（中间格式只对epm文件有效）';
        var systemAttachmentText = '外发系统附件';
        var outsourcedText = '是否外发';
        var partNoText = '物料编号';

        //采购工程师维护报价及供应商信息
        var budgetText = '预算(元)';
        var quoteText = '报价(元)';
        var supplierNameText = '供应商名称';


        if (allowEdit) {
            if (actKey == 'submit_node') {
                budgetText = blueFlagStart + budgetText + blueFlagEnd;
                docNumberText = redStarFlag + blueFlagStart + docNumberText + blueFlagEnd;
                versionText = redStarFlag + blueFlagStart + versionText + blueFlagEnd;
                docDescriptionText = blueFlagStart + docDescriptionText + blueFlagEnd;
                outsourcedText = redStarFlag + blueFlagStart + outsourcedText + blueFlagEnd;
                attachmentText = blueFlagStart + attachmentText + blueFlagEnd;
                outFormatRequirementText = redStarFlag + blueFlagStart + outFormatRequirementText + blueFlagEnd;
                systemAttachmentText =   blueFlagStart + systemAttachmentText + blueFlagEnd;
                partNumberText = redStarFlag + blueFlagStart + partNumberText + blueFlagEnd;
            } else if (actKey == 'procurement_node') {
                tagIdText = redStarFlag + blueFlagStart + tagIdText + blueFlagEnd;
                partNoText = redStarFlag + blueFlagStart + partNoText + blueFlagEnd;
                quoteText = blueFlagStart + quoteText + blueFlagEnd;
                supplierNameText = redStarFlag + blueFlagStart + supplierNameText + blueFlagEnd;
                outFormatRequirementText = redStarFlag + blueFlagStart + outFormatRequirementText + blueFlagEnd;
                systemAttachmentText = redStarFlag + blueFlagStart + systemAttachmentText + blueFlagEnd;
            } else if (actKey == 'resourceCenter_node') {
                outFormatRequirementText = redStarFlag + blueFlagStart + outFormatRequirementText + blueFlagEnd;
                systemAttachmentText = redStarFlag + blueFlagStart + systemAttachmentText + blueFlagEnd;
            }
        }

        //外发格式要求
        var outFormatRequirementCobo = new Ext.form.ComboBox({
            name: 'productLines',
            id: 'productLines',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [['源文件', '源文件'], ['中间格式', '中间格式'], ['源文件和中间格式', '源文件和中间格式']]
            }),
            valueField: 'key',
            displayField: 'displayText'
        });

        var versionStore = new Ext.data.ArrayStore({
            id: 'versionStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/supplier/getVersion',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        var attachmentStore = new Ext.data.ArrayStore({
            id: 'attachmentStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/supplier/getSystemAttachment',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        //版本
        var versionCom = new Ext.form.ComboBox({
            name: 'versionCom',
            id: 'versionCom',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: versionStore,
            valueField: 'version',
            displayField: 'version'
        });

        var attachmentCombo = new Ext.form.ComboBox({
            name: 'attachmentCombo',
            id: 'attachmentCombo',
            multiSelect: true,
            valueField: 'attachment',
            displayField: 'attachment',
            anyMatch: true,
            editable: false,
            store: attachmentStore
        });


        Ext.define('supplierDocModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'tagId', 'attachmentPath', 'versionState','budget', 'interiorVersion', 'systemAttachment', 'docNumber', 'docName', 'attachment', 'outFormatRequirement',
            'partNumber', 'partName', 'objectType', 'outsourced'],
            idProperty: 'id'
        });

        Ext.define('supplierModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'tagId', 'docNumber', 'docName', 'quote', 'supplierName', 'supplierEmail', 'userName'],
            idProperty: 'id'
        });

        var supplierDocStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'supplierDocModel',
            id: 'supplierDocStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/supplier/getSupplierItemInfo?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var supplierStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'supplierModel',
            id: 'supplierStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/supplier/getSupplierItem?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var providerStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            fields: ['supplierName'],
            id: 'providerStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/supplier/getSupplierInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    messageProperty: 'error',
                    root: 'data'
                }
            }),
            autoLoad: false
        });
        var providerCombo = Ext.create('Ext.form.field.ComboBox', {
            store: providerStore,
            id: 'demandType',
            labelWidth: 150,
            displayField: 'supplierName',
            valueField: 'supplierName',
            typeAhead: true,
            triggerAction: 'all',
            queryMode: 'local',
            allowBlank: true,
            anyMatch: true
        });

        Ext.define('checkResultModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'partNumber', 'partName', 'failureReason', 'docType', 'docNumber'],
            idProperty: 'id'
        });

        var checkResultStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'checkResultModel',
            id: 'checkResultStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/supplier/getCheckResultList?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var checkResultPanel = new Ext.create("Ext.grid.Panel", {
            margin: '20 0 0 0',
            store: Ext.getStore('checkResultStore'),
            id: 'checkResultPanel',
            title:"",
            width: '100%',
            autoScroll: true,
            region: 'center',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            columns: [
                {xtype: 'rownumberer', width: '50'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                //物料编号
                {text: '物料编号', dataIndex: 'partNumber', width: 100, menuDisabled: true},
                //物料描述
                {text: '物料描述', dataIndex: 'partName', width: 200, menuDisabled: true},
                //校验失败原因
                {text: '校验失败原因', dataIndex: 'failureReason', width: 100, menuDisabled: true},
                //文档类型
                {text: '文档类型', dataIndex: 'docType', width: 200, menuDisabled: true},
                //文档编号
                {text: '文档编号', dataIndex: 'docNumber', width: 100, menuDisabled: true}
            ]
        });

        var checkCompleteSetWindow = Ext.create('Ext.Window', {
            title: '关联图文档校验',
            width: 800,
            height: 500,
            closeAction: 'hide',
            id: 'win_checkCompleteSetWindow',
            autoScroll: false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: checkResultPanel,
            buttons: [{
                xtype: "button",
                text: "关闭",
                handler: function () {
                    checkCompleteSetWindow.close();
                }
            }]
        });

        var cellEditing0 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        Ext.define('materialCollectionModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'partNumber', 'partName', 'partVersion', 'insideVersion', 'completeVerification', 'repeatVerification', 'superiorMaterials'],
            idProperty: 'id'
        });

        var materialCollectionStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'materialCollectionModel',
            id: 'materialCollectionStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/supplier/getSupplierMaterial?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var materialCollectionGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing0],
            margin: '20 0 0 0',
            store: Ext.getStore('materialCollectionStore'),
            id: 'materialCollectionGrid',
            //forceFit: true,
            //autoWidth: true,
            title:"1. 物料收集表",
            width: '100%',
            height:240,
            autoScroll: true,
            region: 'center',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {xtype: 'rownumberer', width: '50'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                //物料编号
                {text: partNumberText, dataIndex: 'partNumber', width: 100, editor: 'textfield', menuDisabled: true},
                //物料描述
                {text: '物料描述', dataIndex: 'partName', width: 300, menuDisabled: true},
                //系统版本
                {text: '版本状态', dataIndex: 'partVersion', width: 100, menuDisabled: true},
                //内部版本
                {text: '内部版本', dataIndex: 'insideVersion', width: 100, menuDisabled: true},
                //文档齐套校验
                {text: '文档齐套校验', dataIndex: 'completeVerification', width: 100, menuDisabled: true},
                //文档重复校验
                {
                    text: '文档重复校验',
                    dataIndex: 'repeatVerification',
                    width: 100,
                    menuDisabled: true
                },
                //相关上级物料
                {
                    text: '相关上级物料',
                    dataIndex: 'superiorMaterials',
                    width: 400,
                    menuDisabled: true
                }
            ],

            //表格权限设置
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列
                    if (allowEdit) {
                        console.log(actKey)
                        if (actKey == 'submit_node') {
                            return true;
                        } else {
                            return false;
                        }
                    }
                }
            },

            tbar: [
                {
                    text: '添加',
                    iconCls: 'icon icon-add',
                    scope: this,
                    hidden: actKey != 'submit_node',
                    handler: function () {
                        var callbackFn = function () {
                            Ext.getStore('materialCollectionStore').reload();
                        };
                        //创建空行,含branchId
                        insertSupplierPartItemData(callbackFn);
                    }
                }, '&nbsp;', {
                    text: '删除',
                    iconCls: 'icon icon-delete',
                    scope: this,
                    hidden: actKey != 'submit_node',
                    handler: function () {
                        let selectionArr = materialCollectionGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('materialCollectionStore').reload();
                            Ext.getStore('supplierDocStore').reload();
                        };
                        deleteSupplierPartItem(obj, callbackFn);
                    }
                }, '&nbsp;', {
                    text: '关联图文档校验',
                    scope: this,
                    hidden: actKey != 'submit_node',
                    handler: function () {
                        Ext.getStore('checkResultStore').load({
                            callback: function (records, operation, success) {
                                if (!success) {
                                    if (typeof (operation.error) == 'string') {
                                        alert(operation.error);
                                    } else {
                                        alert('查询超时！请重试！')
                                    }
                                }
                            }
                        });
                        checkCompleteSetWindow.show();
                    }
                }
            ]
        });

        materialCollectionGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据f
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');
                var callbackFn = function () {
                    Ext.getStore('materialCollectionStore').reload();
                    if(tField == 'partNumber'){
                        Ext.getStore('supplierDocStore').reload();
                    }
                    tRecord.commit();
                };
                saveMockItemData("ZSupplierMaterial", itemId, tField, tValue, callbackFn);
            }
        );

        var supplierDocumentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            margin: '20 0 0 0',
            store: Ext.getStore('supplierDocStore'),
            id: 'supplierDocumentGrid',
            //forceFit: true,
            //autoWidth: true,
            title:"2. 图文档收集表",
            width: '100%',
            height:300,
            autoScroll: true,
            region: 'center',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {xtype: 'rownumberer', width: '50'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'attachmentPath', menuDisabled: true, hidden: true},
                //{text: '编号', dataIndex: 'tagId', width: 70, menuDisabled: true},
                {
                    text: outsourcedText,
                    dataIndex: 'outsourced',
                    width: 100,
                    editor:{
                        xtype : 'combo',
                        editable : false,
                        store : [['是','是'],['否', '否']],
                        mode : 'local'
                    },
                    menuDisabled: true
                },
                {text: '物料编号', dataIndex: 'partNumber', width: 100, menuDisabled: true},
                {text: '物料描述', dataIndex: 'partName', width: 100, menuDisabled: true},
                {text: '对象类型', dataIndex: 'objectType', width: 100, menuDisabled: true},
                {text: '文档图纸编号', dataIndex: 'docNumber', width: 100, menuDisabled: true},
                {text: '文档名称', dataIndex: 'docName', width: 180, menuDisabled: true},
                {text: '系统版本', dataIndex: 'version', width: 100, menuDisabled: true},
                {text: '内部版本', dataIndex: 'interiorVersion', width: 100, menuDisabled: true},
                {text: '状态', dataIndex: 'versionState', width: 100, menuDisabled: true},
                // {text: budgetText, dataIndex: 'budget', width: 100, editor:{
                //         xtype: 'numberfield',
                //         anchor: '100%',
                //         decimalPrecision: 5,
                //         //minValue: 0
                //     }, menuDisabled: true},
                {text: attachmentText, dataIndex: 'attachment', width: 250, menuDisabled: true},
                {
                    text: systemAttachmentText,
                    dataIndex: 'systemAttachment',
                    width: 250,
                    editor: attachmentCombo,
                    menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        var temp = new Array();
                        if (value == '' || value == undefined || value == null) {
                            return '';
                        }
                        if (!Array.isArray(value)) {
                            value += ",";
                            var start = 0;
                            var pos = value.indexOf(',');
                            while (pos > -1) {
                                temp.push(value.substr(start, pos - start));
                                start = pos + 1;
                                pos = value.indexOf(',', pos + 1);
                            }
                            record.set("systemAttachment", temp);
                            record.commit();
                        } else {
                            temp = value;
                        }
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + temp + "'";
                        return temp;
                    }
                },
                {
                    text: outFormatRequirementText,
                    dataIndex: 'outFormatRequirement',
                    width: 150,
                    editor: outFormatRequirementCobo, menuDisabled: true
                },
                {
                    text: docDescriptionText,
                    dataIndex: 'docDescription',
                    width: 100,
                    editor: 'textfield',
                    menuDisabled: true
                },
                {text: '', dataIndex: '', width: 10,},
            ],

            //表格权限设置
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列
                    if (allowEdit) {
                        console.log(actKey)
                        if (actKey == 'submit_node') {

                            if (tField == 'version') {
                                let selectionArr = supplierDocumentGrid.getSelectionModel().getSelection();
                                if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                    return;
                                }
                                var number = selectionArr[0].data['docNumber']
                                if (!number) {
                                    Ext.getCmp('saveStatus2').setText('请先填写编号！');
                                    return false;
                                } else {
                                    getVersion(number);
                                }
                            }
                            if (tField == 'systemAttachment') {
                                let selectionArr = supplierDocumentGrid.getSelectionModel().getSelection();
                                if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                    return;
                                }
                                var version = selectionArr[0].data['version']
                                var docNumber = selectionArr[0].data['docNumber']
                                if (!version) {
                                    Ext.getCmp('saveStatus2').setText('请先填写版本！');
                                    return false;
                                } else {
                                    getSystemAttachment(docNumber, version);
                                }
                            }
                            Ext.getCmp('saveStatus2').setText(' ');
                            return true;

                        } else if (actKey == 'procurement_node') {
                            return false;
                        }  else if (actKey == 'resourceCenter_node') {
                            if(tField == 'outFormatRequirement' || tField == 'systemAttachment'){
                                if (tField == 'systemAttachment') {
                                    let selectionArr = supplierDocumentGrid.getSelectionModel().getSelection();
                                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                        return;
                                    }
                                    var version = selectionArr[0].data['version']
                                    var docNumber = selectionArr[0].data['docNumber']
                                    if (!version) {
                                        Ext.getCmp('saveStatus2').setText('请先填写版本！');
                                        return false;
                                    } else {
                                        getSystemAttachment(docNumber, version);
                                    }
                                }
                                Ext.getCmp('saveStatus2').setText(' ');
                                return true;
                            }
                            return false;
                        } else {
                            Ext.getCmp('saveStatus2').setText('不允许编辑');
                            return false
                        }
                    } else {
                        Ext.getCmp('saveStatus2').setText('不允许编辑');
                        return false
                    }
                }
            },

            tbar: [
            //     {
            //     text: '添加',
            //     iconCls: 'icon icon-add',
            //     scope: this,
            //     hidden: actKey != 'submit_node',
            //     handler: function () {
            //         var callbackFn = function () {
            //             Ext.getStore('supplierDocStore').reload();
            //         };
            //         //创建空行,含branchId
            //         insertItemData(callbackFn);
            //     }
            // }, '&nbsp;', {
            //     text: '删除',
            //     iconCls: 'icon icon-delete',
            //     scope: this,
            //     hidden: actKey != 'submit_node',
            //     handler: function () {
            //         let selectionArr = supplierDocumentGrid.getSelectionModel().getSelection();
            //         if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
            //             Ext.Msg.alert("提示", "请选择要删除的数据");
            //             return;
            //         }
            //         //数据组装
            //         let obj = new Array();
            //         Ext.each(selectionArr, function (record) {
            //             obj.push(record.data['id'])
            //         });
            //         var callbackFn = function () {
            //             //tRecord.commit();
            //             Ext.getStore('supplierDocStore').reload();
            //         };
            //         deleteData(obj, callbackFn);
            //     }
            // }, '&nbsp;',
                {
                xtype: 'filefield',
                hidden: actKey != 'submit_node',
                buttonOnly: true,
                id: 'head_uploadFile',
                name: 'head_uploadFile',
                // hidden:true,
                hideLabel: true,
                buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加附件',
                allowBlank: false,
                scope: this,
                listeners: {
                    'focus': function () {
                        let selectionArr = supplierDocumentGrid.getSelectionModel().getSelection();
                        if (selectionArr.length == 0) {
                            alert("未选择添加附件行！");
                            return;
                        }
                        /*//alert(selectionArr[0].get("attachment"))
                        if (selectionArr[0].get("attachment") != null){
                            alert('只能上传一个附件');
                            return;
                        }*/
                        if (selectionArr.length >= 2) {
                            alert("不支持多行选择添加附件！");
                            return;
                        }

                    },
                    'change': function (fb, newValue) {
                        if (!newValue) {
                            return;
                        }
                        let selectionArr = supplierDocumentGrid.getSelectionModel().getSelection();

                        var outDrawings = selectionArr[0].get("docNumber");
                        // store.reload();
                        if (outDrawings == '' || outDrawings == undefined) {
                            alert("请先填写外发图纸编号!");
                            return;
                        } else if (selectionArr.length == 0) {
                            alert("添加附件失败，未选择添加附件对象!");
                            return;
                        } else if (selectionArr.length >= 2) {
                            alert("不支持多行添加附件操作，请确认要添加的行");
                            return;
                        } else {

                            var file = document.querySelector('[id=' + 'head_uploadFile' + '-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('head_uploadFile' + '-button-fileInputEl', file.files[0]);
                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在上传，请稍候......',
                                target: this.findParentByType('panel')
                            });


                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/supplier/uploadFiles?branchId=' + branchId + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + 'head_node',
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function (res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if (!success) {
                                    alert(msg);
                                } else {
                                    var fileName = obj['fileName'];
                                    var filePath = obj['filePath'];
                                    var tRecord = supplierDocumentGrid.getSelectionModel().getSelection()[0];
                                    var attachmentValue = supplierDocumentGrid.getSelectionModel().getSelection()[0].data.attachment;
                                    var attachmentPath = supplierDocumentGrid.getSelectionModel().getSelection()[0].data.attachmentPath;
                                    if (attachmentValue != null && attachmentValue != '') {
                                        fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                        filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                    }
                                    tRecord.set('attachment', fileName);
                                    tRecord.set('attachmentPath', filePath);
                                    var callbackFn = function () {
                                        tRecord.commit();
                                    };
                                    var itemId = tRecord.get('id');
                                    saveMockItemData("ZSupplierDocument",itemId, 'attachment', fileName, callbackFn);
                                    saveMockItemData("ZSupplierDocument",itemId, 'attachmentPath', filePath, callbackFn);

                                }
                                var callbackFn = function () {
                                    //tRecord.commit();
                                    Ext.getStore('supplierDocumentGrid').reload();
                                };
                            }).fail(function (res) {
                                myMask.hide();
                                alert('上传失败！');
                            });
                        }
                    }

                }
            }, {
                xtype: 'tbtext',
                text: '',
                id: 'saveStatus2',
                disabled: true
            }, {
                xtype: 'tbtext',
                text: '<b>本机文件外发时上传到附件列，系统文件编号为：0000041617、0000041618 （同一天发同一个供应商请用不同的编号）</b>',
                id: 'text',
                disabled: true
            }]
        });

        var fel = new Ext.form.NumberField({
            allowDecimals:true,
            decimalPrecision:6//小数点后位数
        })

        var partNumberStore = new Ext.data.ArrayStore({
            id: 'partNumberStore',
            fields: ['partNumber'],
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/supplier/getPartNumber?branchId=' + branchId,
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        //版本
        var partNumberCom = new Ext.form.ComboBox({
            name: 'partNumberCom',
            id: 'partNumberCom',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: partNumberStore,
            valueField: 'partNumber',
            displayField: 'partNumber'
        });

        var supplierItemGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            margin: '20 0 0 0',
            store: Ext.getStore('supplierStore'),
            id: 'supplierItemGrid',
            //forceFit: true,
            autoWidth: true,
            title:"3. 外发供应商清单",
            width: '100%',
            height: 240,
            autoScroll: true,
            region: 'center',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {xtype: 'rownumberer', width: '50'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'attachmentPath', menuDisabled: true, hidden: true},
                {
                    text: partNoText,
                    dataIndex: 'partNumber',
                    width: 100,
                    menuDisabled: true,
                    editor: partNumberCom
                },
                // {text: tagIdText, dataIndex: 'tagId', width: 70, editor: 'textfield', menuDisabled: true},
                // {text: '系统文件编号', dataIndex: 'docNumber'},
                // {text: '文档名称', dataIndex: 'docName'},

               /* {text: quoteText, dataIndex: 'quote', width: 100, editor:{
                        xtype: 'numberfield',
                        anchor: '100%',
                        decimalPrecision: 5,
                        //minValue: 0
                    }, menuDisabled: true},*/
                {
                    text: supplierNameText,
                    dataIndex: 'supplierName',
                    width: 300,
                    editor: providerCombo,
                    menuDisabled: true
                },
                {text: '供应商邮箱', dataIndex: 'supplierEmail', width: 300, menuDisabled: true, editor: 'textfield'},
                {text: '用户名', dataIndex: 'userName', width: 100, menuDisabled: true, editor: 'textfield'},
                {text: '', dataIndex: '', width: 10,},
            ],
            tbar: [
                {
                    text: '添加',
                    iconCls: 'icon icon-add',
                    scope: this,
                    hidden: actKey != 'procurement_node',
                    handler: function () {

                        var callbackFn = function () {
                            Ext.getStore('supplierStore').reload();
                        };
                        //创建空行,含branchId
                        addSupplierItem(callbackFn);
                    }


                }, '&nbsp;', {
                    text: '删除',
                    iconCls: 'icon icon-delete',
                    scope: this,
                    hidden: actKey != 'procurement_node',
                    handler: function () {
                        let selectionArr = supplierItemGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('supplierStore').reload();
                        };
                        delSupplier(obj, callbackFn);
                    }
                }
            ],
            //表格权限设置
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if(!allowEdit){
                        return false;
                    }
                    /*if (actKey == 'procurement_node'){
                        var flag = true;
                        if (tField == 'supplierEmail' || tField == 'userName'){
                            providerStore.each(function (record) {
                                var sf = record.get('supplierName');
                                var supplierName = e.record.data.supplierName;
                                if (supplierName == sf){
                                    flag = false
                                    return
                                }
                            })
                        }
                        return flag;
                    }else if (actKey == 'submit_node'){
                        return false;
                    }
                    return false;*/
                }
            }
        });

        supplierItemGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据f
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');


                if (tField == 'tagId') {
                    getDocInfo(itemId, tValue);
                    Ext.getStore('supplierStore').reload();
                    return;
                }
                var callbackFn = function () {
                    if (tField == 'supplierName' ) {
                        Ext.getStore('supplierStore').reload();
                    }
                    tRecord.commit();
                };
                saveMockItemData("ZSupplierItem", itemId, tField, tValue, callbackFn);

            });

        supplierDocumentGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据f
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

               /* if (tValue == null || tValue == '' || tValue == undefined) {
                    return;
                }*/

                var callbackFn = function () {

                    if (tField == 'supplierName' || tField == 'docNumber' || tField =='version') {
                        Ext.getStore('supplierDocStore').reload();
                    }
                    tRecord.commit();
                };
                saveMockItemData("ZSupplierDocument", itemId, tField, tValue, callbackFn);
            });

        this.items = [{
            xtype: 'form',
            id: 'mainForm1',
            //padding:'5',
            anchor: '99%',
            border: false,
            items: [materialCollectionGrid, supplierDocumentGrid, supplierItemGrid]
        }];


        this.callParent();
    },//~End of initComponent

    //加载表格数据
    listeners: {
        'afterrender': function () {
            Ext.getStore('materialCollectionStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            Ext.getStore('supplierDocStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            Ext.getStore('supplierStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('providerStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    }

});
