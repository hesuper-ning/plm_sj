/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){

	var mockRec = {
		oid:oid,
		itemId:itemId,
		dbTableName:dbTableName,
		dataKey:dataKey,
		dataValue:dataValue
	};

	Ext.Ajax.request({
		url: '/Windchill/ptc1/supplier/saveSupplierItem',
		params: {updateRecord:Ext.encode(mockRec)},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj.message=="success") {
				//回调函数，一般用于后台操作成功后刷新列表
				if (callbackFn) {
					callbackFn();
				}
			} else {
				alert(obj.message);
			}
		},
		failure: function (response, opts) {
			alert('错误：保存信息失败，请检查网络！!');
		}
	}); //~End of Ajax request
}

/**
 * 保存列表中的一个属性(单元格）
 */
function getDocInfo(id,tagId,callbackFn){
	if (tagId == null || tagId == '' || tagId == undefined) {
		return;
	}
	var mockRec = {
		oid:oid,
		id:id,
		tagId:tagId,
		branchId:branchId
	};

	Ext.Ajax.request({
		url: '/Windchill/ptc1/supplier/gridGetDocInfo',
		params: {info:Ext.encode(mockRec)},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj.message=="success") {
				//回调函数，一般用于后台操作成功后刷新列表
				if (callbackFn) {
					callbackFn();
				}
			} else {
				alert(obj.message);
			}
		},
		failure: function (response, opts) {
			alert('错误：保存信息失败，请检查网络！!');
		}
	}); //~End of Ajax request
}

function insertSupplierPartItemData(callbackFn) {
	Ext.Ajax.request({
		url: '/Windchill/ptc1/supplier/addSupplierPartItem?oid='+oid,
		params: {
			branchId: branchId,
		},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj.message=="success") {
				callbackFn();
			} else {
				alert(obj.message);
			}
		},
		failure: function (response, opts) {
			alert('错误：保存信息失败，请检查网络！!');
		}
	}); //~End of Ajax request
}

//删除grid信息
function deleteSupplierPartItem(ids, callback) {
	var data = {
		oid:oid,
		ids:ids,
	}
	Ext.Ajax.request({
		scope: this,
		url: '/Windchill/ptc1/supplier/deleteSupplierPartItem',
		method: "POST",
		params:{
			data: Ext.encode(data)
		},
		//headers: {'Content-Type':'application/json'},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj.message!="success") {
				Ext.Msg.alert("数据删除失败", obj.message);
			} else {
				alert("数据删除成功");
				callback();
			}
		},
		failure: function (response, opts) {
			Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
		}
	});
}

/**
 *    grid插入数据
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(callbackFn) {

	Ext.Ajax.request({
		url: '/Windchill/ptc1/supplier/addItem?oid='+oid,
		params: {
			branchId: branchId,
		},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj.message=="success") {
				callbackFn();
			} else {
				alert(obj.message);
			}
		},
		failure: function (response, opts) {
			alert('错误：保存信息失败，请检查网络！!');
		}
	}); //~End of Ajax request
}

//删除grid信息
function deleteData(ids, callback) {
	var data = {
		oid:oid,
		ids:ids,
	}
	Ext.Ajax.request({
		scope: this,
		url: '/Windchill/ptc1/supplier/delSupplierItem',
		method: "POST",
		params:{
			data: Ext.encode(data)
		},
		//headers: {'Content-Type':'application/json'},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj.message!="success") {
				Ext.Msg.alert("数据删除失败", obj.message);
			} else {
				alert("数据删除成功");
				callback();
			}
		},
		failure: function (response, opts) {
			Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
		}
	});
}

/**
 *    grid插入数据
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function addSupplierItem(callbackFn) {

	Ext.Ajax.request({
		url: '/Windchill/ptc1/supplier/addSupplierItem?oid='+oid,
		params: {
			branchId: branchId,
		},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj.message=="success") {
				callbackFn();
			} else {
				alert(obj.message);
			}
		},
		failure: function (response, opts) {
			alert('错误：保存信息失败，请检查网络！!');
		}
	}); //~End of Ajax request
}

//删除grid信息
function delSupplier(ids, callback) {
	var data = {
		oid:oid,
		ids:ids,
	}
	Ext.Ajax.request({
		scope: this,
		url: '/Windchill/ptc1/supplier/delSupplier',
		method: "POST",
		params:{
			data: Ext.encode(data)
		},
		//headers: {'Content-Type':'application/json'},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj.message!="success") {
				Ext.Msg.alert("数据删除失败", obj.message);
			} else {
				alert("数据删除成功");
				callback();
			}
		},
		failure: function (response, opts) {
			Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
		}
	});
}


//删除附件
function deleteFilefield(branchId,fileName,path) {
	if(!allowEdit){
		alert("您没有权限删除其他用户的附件！");
		return;
	}
	if(actKey != 'submit_node'){
		alert("只有提交节点可以删除附件！");
		return;
	}

	// var myMask = new Ext.LoadMask({
	// 	msg: '正在删除，请稍候......',
	// 	target:Ext.getCmp('headPanel')
	// });
	// myMask.show();
	Ext.Ajax.request({
		scope : this,
		async : false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
		url : '/Windchill/ptc1/supplier/deleteFiles',
		params : {
			branchId: branchId,
			fileName: fileName,
			path:path
		},
		success : function(response, opts) {
			// myMask.hide();
			var obj = Ext.decode(response.responseText);
			var success = obj['success'];
			var msg = obj['msg'];
			if(!success){
				alert(msg);
			}else {
				debugger
				var fileName = obj['fileName'];
				var arr= new Array(); //定义一数组
				arr=fileName.split("|"); //字符分割
				for (i=0;i<arr.length ;i++ ){
					var index = arr[i].indexOf(fileName);
					if (index > -1) {
						arr.splice(i,1);// 删除
					}
				}

				var result = arr.join("&nbsp;|&nbsp;");
				var tRecord =  Ext.getCmp('supplierDocumentGrid').getSelectionModel().getSelection()[0];
				var attachmentValue = tRecord.data.attachment;
				var attachmentPath = tRecord.data.attachmentPath;
				var arr= new Array(); //定义一数组
				var arr1= new Array(); //定义一数组
				arr=attachmentValue.split("|"); //字符分割
				for (i=0;i<arr.length ;i++ ){
					var index = arr[i].indexOf(fileName);
					if (index > -1) {
						arr.splice(i,1);// 删除
					}
				}

				arr1=attachmentPath.split("|"); //字符分割
				for (i=0;i<arr1.length ;i++ ){
					var index = arr1[i].indexOf(fileName);
					if (index > -1) {
						arr1.splice(i,1);// 删除
					}
				}

				var result = arr.join("&nbsp;|&nbsp;");
				var result1 = arr1.join("&nbsp;|&nbsp;");

				tRecord.set('attachment',result);
				tRecord.set('attachmentPath',result1);


				var itemId = tRecord.get('id');

				var callbackFn = function () {
					tRecord.commit();
				};
				saveMockItemData("ZSupplierDocument", itemId, 'attachment', result, callbackFn);
				saveMockItemData( "ZSupplierDocument",itemId, 'attachmentPath',result1, callbackFn);

				/*  var fileName = obj['fileName'];
                  var tRecord = pcbApplyDocGrid.getSelectionModel().getSelection()[0];
                  var docEnclosureValue = pcbApplyDocGrid.getSelectionModel().getSelection()[0].data.docEnclosure;
                  if (docEnclosureValue != null && docEnclosureValue != '') {
                      fileName = docEnclosureValue + "&nbsp;|&nbsp;" + fileName;
                  }
                  tRecord.set('docEnclosure',fileName);
                  var itemId = tRecord.get('id');*/

			}
		},
		failure : function(response, opts) {
			// myMask.hide();
			alert('错误：删除附件失败，请检查网络！');
		}
	});


}


function getVersion(number) {
	Ext.getStore('versionStore').load({
		params: {
			number:number,
		},
		callback: function (records, operation, success) {
			if (!success) {
				alert('查询信息失败，请联系管理员！');
			}
		}
	})
}

function  getSystemAttachment(docNumber,version){
	Ext.getStore('attachmentStore').load({
		params: {
			number:docNumber,
			version:version,
		},
		callback: function (records, operation, success) {
			if (!success) {
				alert('查询信息失败，请联系管理员！');
			}
		}
	})
}