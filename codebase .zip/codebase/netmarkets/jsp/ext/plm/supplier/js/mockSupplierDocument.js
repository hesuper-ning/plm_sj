Ext.define('PLM.view.SupplierDocumentPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.SupplierDocumentPanel',
	// title:'<font style="font-size:18px">供应商外发</font>',
	border:false,
	layout:'anchor',
	autoScroll:true,
	autoWidth:true,
	autoHeight:true,
	collapsible: false,
	id: 'supplierDocumentPanel',
	config: {
		in_objectKey: 'SupplierDocumentPanel',
		in_objectDesc: '供应商外发',
	},
	fieldDefaults: {
		msgTarget: 'side',
		labelWidth: 75
	},
	initComponent:function(){
		var me = this;

		// create the Data Store
		var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore'
		});
		this.cellEditing = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});


		var supplierDocumentGrid = Ext.create('Ext.grid.Panel', {
			plugins: [this.cellEditing],
			title: '文件权限申请单',
			margin:'20 0 0 0',
			store:Ext.getStore('mockExampleStore'),
			id:'supplierDocumentGrid',
			//forceFit : true,
			autoWidth : true,
			// width:2500,
			autoScroll:true,
			region:'center',
			height:400,
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: supplierDocumentGrid,
							param_objectKey: me.in_objectKey,
							param_objectDesc: me.in_objectDesc
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			selModel: {
				mode: 'MULTI' //可以多选
			},

			columns: [
				{xtype: 'rownumberer',text: '序号',width:50,align:'center' },
				{ text: 'ID',  dataIndex: 'id',hidden:true,align:'center' },
				{ text: '用户ID',  dataIndex: 'data1',hidden:true,align:'center' },
				{ text: '类型',dataIndex: 'data2',menuDisabled:true,hidden:true,align:'center'},
				{ text: '编号', width:150,dataIndex: 'data3',menuDisabled:true,align:'center',editor:'textfield',},
				{ text: '供应商名称', width:150,dataIndex: 'data4',menuDisabled:true,align:'center',
					renderer: function(value,metaData,record,row,col,store){
						//提示tip
						metaData.tdAttr = " data-qtip = '"+value+"'";
						return value;
					},editor:{
						xtype : 'combo',
						editable : false,
						id:"data4",
						// multiSelect:true,
						value: ' ',
						store : [['供应商1','供应商1'],['供应商2', '供应商2']],
						mode : 'local',
						menuDisabled:true
					}
				},
				{ text: '邮箱地址', width:150,dataIndex: 'data5',menuDisabled:true,align:'center',editor:'textfield',
					renderer: function(value,metaData,record,row,col,store){
						//提示tip
						metaData.tdAttr = " data-qtip = '"+value+"'";
						return value;
					}
				},
				{ text: '用户', width:150,dataIndex: 'data6',menuDisabled:true,align:'center',editor:'textfield',
					renderer: function(value,metaData,record,row,col,store){
						//提示tip
						metaData.tdAttr = " data-qtip = '"+value+"'";
						return value;
					}
				},
				{ text: '外发图纸', width:150,dataIndex: 'data7',menuDisabled:true,editor:'textfield',align:'center'},
				{ text: '外发格式',width:150, dataIndex: 'data8',menuDisabled:true,editor:{
						xtype : 'combo',
						editable : false,
						id:"data8",
						value: ' ',
						store : [['外发格式1','外发格式1'],['外发格式2', '外发格式2']],
						mode : 'local',
						menuDisabled:true
					} ,align:'center'},
			],
			tbar: [

				{
					xtype: 'label',
					id: 'message',
					name: 'message',
					width: 450,
					readOnly:true,
				}
			]

		});
		supplierDocumentGrid.on('edit',
			function (editor, e) {
				var tRecord = e.record; //得到当前行所有数据
				var tField = e.field; //得到修改列
				var tValue = e.value; //得到修改列修改后值
				var itemId = tRecord.get('id');

				var callbackFn = function () {
					tRecord.commit();
				};
				saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

			});

		this.items=[{
			xtype: 'form',
			width: '100%',
			title: '外发信息',
			frame: false,
			collapsible: true,
			defaults: {
				border: false,
				anchor: '98%'
			},
			id: 'primaryBusinessObjectForm',
			items: [{
				xtype: 'displayfield',
				fieldLabel: '外发单号',
				id: 'externalNumber',
				name: 'externalNumber',
				value:externalNumber,
				readOnly:true,
			}]
		},supplierDocumentGrid];

		this.callParent();
	},//~End of initComponent
	listeners:{
		'afterrender': function () {
			Ext.getStore('mockExampleStore').load({
				params: {
					objectKey: Ext.getCmp('supplierDocumentPanel').getIn_objectKey()//表头key
				},
				callback: function (records, operation, success) {
					if (!success) {
						if (typeof (operation.error) == 'string') {
							alert(operation.error);
						} else {
							alert('查询超时！请重试！')
						}
					} else {
						//无数据时自动添加一条空数据
						if (Ext.getStore('mockExampleStore').getCount() == 0) {
							var callbackFn = function () {
								Ext.getStore('mockExampleStore').reload()
							}
							createMockItemData(Ext.getCmp('supplierDocumentPanel').getIn_objectKey()
								, Ext.getCmp('supplierDocumentPanel').getIn_objectDesc, callbackFn);
						}
					}
				}
			});

			// 查询MockExample form表单数据
			Ext.Ajax.request({
				url: '/Windchill/ptc1/mock/getObject',
				params: {
					objectKey: Ext.getCmp('supplierDocumentPanel').getIn_objectKey()
				},
				success: function (response, opts) {
					var obj = Ext.decode(response.responseText);
					if (obj['success']) {
						var mainPanel = Ext.getCmp('mainForm');
						mainPanel.getForm().setValues(obj);
					} else {
						alert(obj['error']);
					}
				},
				failure: function (response, opts) {
					alert('错误：查询信息失败，请检查网络！!');
				}
			}); //~End of Ajax request
		}
	}

});
