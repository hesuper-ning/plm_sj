Ext.define('PLM.view.problemDispose', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.problemDispose',
    //title: '<font style="font-size:18px">问题</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'problemDispose',

    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {

        //***************加载表单信息**********************
        var me = this;

        //***************    **********************

        var problemForm = {
            //title: '问题报表',
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [
                {
                    html:'<a href="/Windchill/ptc1/supplier/downLoadDoc?&fileName=test 1.xls" title="点击下载" target="_blank" >test 1.xls</a> <a title=\'删除该附件\' href=\'javascript:;\' class ="head_node" style =\'color:red;text-decoration:none;\' onclick=\'deleteFilefield("1992045","test 1.xls","head_uploadFileRecord","head_node")\'>☒</a> '
                }, {
                    xtype: 'panel',
                    title: '问题',
                    border: false,
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    items: [{
                        xtype: 'container',
                        layout: 'hbox',
                        defaultType: 'textfield',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            fieldLabel: '机型',
                            name: 'cProblemNumber',
                            id: 'cProblemNumber',
                            allowBlank: false,
                            width: 200,
                        }, {
                            fieldLabel: '问题描述',
                            labelWidth: 100,
                            name: 'cStatus',
                            id: 'cStatus',
                            width: 200,
                        }, {
                            fieldLabel: '问题来源',
                            labelWidth: 100,
                            id: 'cCreatorVerify',
                            name: 'cCreatorVerify',
                            width: 200,
                        }]
                    },{
                        xtype: 'container',
                        layout: 'hbox',
                        defaultType: 'textfield',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [
                            {
                                fieldLabel: '初步原因分析',
                                id: 'cDescription',
                                name: 'cDescription',
                                allowBlank: false,
                                width: 200,
                            }, {
                                fieldLabel: '问题处理',
                                labelWidth: 100,
                                id: 'cCharger',
                                name: 'cCharger',
                                width: 200,
                            }
                        ]
                    }]
                }, {
                    xtype: 'panel',
                    title: '问题处理',
                    border: false,
                    collapsible: true,
                    defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                    items: [{
                        xtype: 'container',
                        layout: 'hbox',
                        defaultType: 'textfield',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            fieldLabel: '问题原因',
                            id: 'cDescrsfdiption',
                            name: 'cDescrsfdiption',
                            allowBlank: false,
                            width: 200,
                        },]
                    },{
                        xtype: 'container',
                        layout: 'hbox',
                        defaultType: 'textfield',
                        defaults: {margin: '5 20 5 5', labelWidth: 100, border: false},
                        items: [{
                            fieldLabel: '解决方案',
                            id: 'fasdf',
                            name: 'fasdf',
                            allowBlank: false,
                            width: 200,
                        }]
                    },{
                        xtype: 'container',
                        layout: 'hbox',
                        defaultType: 'button',
                        margin: '10 0 0 10',
                        items: [{
                            text: '查询',
                            name: 'phone',
                            width: 50,
                            handler: function () {
                               // doSearch()
                                window.open("/Windchill/ptc1/supplier/compressDocumentContents?docNumber=0000002082&version=A.1&attachmentPath=D:\\ptc\\Windchill_11.0\\Windchill\\CtFile\\supplier\\2021\\10\\外发.jar")
                            }
                        }]
                    }]
                }]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [problemForm];


        this.callParent();
    },//~End of initComponent

    //加载表格数据
    listeners: {
        'afterrender': function () {

        }
    }

});


function doSearch() {
    Ext.Ajax.request({
        url: '/Windchill/ptc1/supplier/compressDocumentContents',
        method: "GET",
        params:{
            docNumber:'0000002083',
            version:'A.1'
        },
        success: function (response, opts) {
            //var obj = Ext.decode(response.responseText);

        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}