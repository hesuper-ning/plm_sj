
var button1 = Ext.create('Ext.Button', {
    text: '点击显示生效中条目',
    listeners: {
        click: showEffectEntry
    }
});
var button2 = Ext.create('Ext.Button', {
    text: '点击显示全部条目',
    listeners: {
        click: showAllEntry
    }
});
var button3 = Ext.create('Ext.Button', {
    text: '下载全部文件',
    listeners: {
        click: downloadAllFile
    }
});
var button4 = Ext.create('Ext.Button', {
    text: '下载生效中文件',
    listeners: {
        click: downloadEffectFile
    }
});
var button5 = Ext.create('Ext.Button', {
    text: '下载选中文件',
    listeners: {
        click: downloadSelectFile
    }
});
var buttonPanel = Ext.create('Ext.container.Container', {
    id: 'buttonPanel',
    forceFit: false,
    items: [button1,button2,button3,button4,button5]
});

Ext.define('PLM.view.CertificatePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CertificatePanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CertificatePanel',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        items: [buttonPanel,ctModelListBo,ctCertificateListBo,ctReportCheckListBo,ctProductApplicabilityBo,ctUpdateResumeBo]
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    }
});