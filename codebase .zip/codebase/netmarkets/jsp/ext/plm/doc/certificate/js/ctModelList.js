var ctModelEditingConfig = Ext.create('Ext.grid.plugin.CellEditing', {
    clicksToEdit: 1
})

var ctModelListBo = Ext.create('Ext.grid.Panel', {
    id: 'ctModelListBo',
    store: ctModelListStore,
    forceFit: false,
    //height: 300,
    autoWidth: true,
    title: '1. 相关型号清单',
    collapsible: true,
    collapsed: false,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctModelEditingConfig],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {
            text: setMust('产品型号',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'productModel',
            align: 'center',
            sortable: false,
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: setMust('产品名称',isEditable(submit_Node)),
            width: 300,
            dataIndex: 'productName',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: setMust('是否依然适用',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'applicable',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {
                xtype: 'combobox',
                editable: false,
                forceSelection: false,
                store: [['是', '是'], ['否', '否']]
            }
        }
    ],
    tbar: Ext.create('Ext.toolbar.Toolbar', {
        items: [{
            text: '添加行',
            xtype: 'button',
            iconCls: 'icon icon-add',
            hidden:!isEditable(submit_Node),
            handler: addCtModelList
        }, {
            text: '删除行',
            xtype: 'button',
            iconCls: 'icon icon-delete',
            hidden:!isEditable(submit_Node),
            handler: delCtModelList
        }]

    }),
    listeners: {
        beforeedit: function (editor, context) {
            // 假设我们根据某些条件决定是否允许编辑'name'字段
            var record = context.record; // 当前行记录
            var field = context.field; // 当前字段名
            var value = record.get(field); // 当前字段的值


            // 如果满足条件，则允许编辑
            return checkEditAccess(context);
        },
        edit: function (editor, e) {
            updateCtModelList(editor, e);
        }
    }
});