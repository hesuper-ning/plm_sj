var ctReportEditingConfig = Ext.create('Ext.grid.plugin.CellEditing', {
    clicksToEdit: 1
})
var ctReportCheckListStore = new Ext.data.ArrayStore({
    id: 'ctReportCheckListStore',
    fields: [],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/ext/plm/doc/certificate/reportChecklist/getReportChecklistData',
        extraParams: {
            // 这里可以添加任何需要作为请求参数的数据
            masterId:masterId,
            ids:'',
            effective: readOnlyPage?'effective':''//只读页面展示有效的
        },
        timeout: 60000,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: true
});
var ctReportCheckListBo = Ext.create('Ext.grid.Panel', {
    id: 'ctReportCheckListBo',
    store: ctReportCheckListStore,
    forceFit: false,
    //height: 300,
    autoWidth: true,
    title: '3. 报告清单',
    collapsible: true,
    collapsed: false,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctReportEditingConfig],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {
            text: '报告状态',
            width: 120,
            align: 'center',
            dataIndex: 'reportStatus',
            editAccess: false,
            sortable: false
        },
        {
            text: setMust('检验报告类型',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'reportType',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: inspectionReportTypeComboBox
        },
        {
            text: setMust('产品型号',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'productModel',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: productModelComboBox
        },
        {
            text: setMust('检验报告编号',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'reportNumber',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: setRequired('产品标准',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'productStandards',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: setRequired('报告签发日期',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'issuanceDate',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'datefield', format: 'Y-m-d', selectOnFocus: true},
            renderer: function (value) {
                return renderDateField(value);
            }
        },
        {
            text: setRequired('报告有效期',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'validityDate',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'datefield', format: 'Y-m-d', selectOnFocus: true},
            renderer: function (value) {
                return renderDateField(value);
            }
        },
        // {
        //     text: setMust('状态选择',isEditable(submit_Node)),
        //     width: 80,
        //     dataIndex: 'whetherToCancel',
        //     align: 'center',
        //     editAccess: isEditable(submit_Node),
        //     editor: statusSelectComboBox1
        // },
        {
            text: '关联证书编号',
            width: 120,
            dataIndex: 'certificateNumber',
            editAccess: false,
            align: 'center'
        },
        {
            text: setMust('检验报告文件',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'reportFile',
            align: 'center',
            xtype: 'actioncolumn',
            items: [
                '->',
                {
                    iconCls: 'icon icon-uploadImage',
                    tooltip: '添加文件',
                    hidden: !isEditable(submit_Node),
                    handler: function (grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        addFileInfo(record.get('id'),'reportFile','ZReportChecklistTable','ctReportCheckListBo')
                    }
                },
                '-',
                {
                    iconCls: 'icon-showInfo',
                    tooltip: '查看文件',
                    handler: function (grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        showFileInfo(record.get('id'),'reportFile','ZReportChecklistTable','ctReportCheckListBo')

                        let deleteBtn = Ext.getCmp('showDelete');
                        if(isEditable(submit_Node)){
                            deleteBtn.show();
                        }else{
                            deleteBtn.hide();
                        }
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var boolean = record.data.reportFile;
                        if(boolean!=null) {
                            return false;
                        }
                        return true;
                    }
                }
            ]
        },
        {
            text: setRequired('特性文件表文件',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'featureFiles',
            align: 'center',
            xtype: 'actioncolumn',
            items: [
                '->',
                {
                    iconCls: 'icon icon-uploadImage',
                    tooltip: '添加文件',
                    hidden: !isEditable(submit_Node),
                    handler: function (grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        addFileInfo(record.get('id'),'featureFiles','ZReportChecklistTable','ctReportCheckListBo')
                    }
                },
                '-',
                {
                    iconCls: 'icon-showInfo',
                    tooltip: '查看文件',
                    handler: function (grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        showFileInfo(record.get('id'),'featureFiles','ZReportChecklistTable','ctReportCheckListBo')

                        let deleteBtn = Ext.getCmp('showDelete');
                        if(isEditable(submit_Node)){
                            deleteBtn.show();
                        }else{
                            deleteBtn.hide();
                        }
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var boolean = record.data.featureFiles;
                        if(boolean!=null) {
                            return false;
                        }
                        return true;
                    }
                }
            ]
        }
    ],
    tbar: Ext.create('Ext.toolbar.Toolbar', {
        items: [{
            text: '添加行',
            xtype: 'button',
            iconCls: 'icon icon-add',
            hidden: !isEditable(submit_Node),
            handler: addReportCheckList
        }, {
            text: '删除行',
            xtype: 'button',
            iconCls: 'icon icon-delete',
            hidden: !isEditable(submit_Node),
            handler: delReportCheckList
        }, {
            text: '点击显示关联记录',
            iconCls: 'icon icon-add',
            disabled: false,
            hidden: !isEditable(submit_Node),
            handler: showRelationReportCheckListRecord
        }, {
            text: '点击显示全部记录',
            iconCls: 'icon icon-add',
            disabled: false,
            hidden: !isEditable(submit_Node),
            handler: showAllReportCheckListRecord
        }]

    }),
    listeners: {
        beforeedit: function (editor, context) {
            // 假设我们根据某些条件决定是否允许编辑'name'字段
            var record = context.record; // 当前行记录
            var field = context.field; // 当前字段名
            var value = record.get(field); // 当前字段的值


            // 如果满足条件，则允许编辑
            return checkEditAccess(context);
        },
        edit: function (editor, e) {
            updateReportCheckList(editor, e);
        },
        rowclick: function (view, record, item, index, e) {
            setSelectDefaultValue(view, record, item, index, e)
        }
    }
});
