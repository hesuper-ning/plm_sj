<%@ page import="ext.plm.doc.certificate.config.CtCertificateProperties" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.util.CtVersionUtil" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css"/>
    <%
        long timestamp = System.currentTimeMillis();
        String urlOid = request.getParameter("oid");
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(urlOid).getObject();
        boolean taskCompleted = false;
        boolean readOnlyPage = false;
        String activityName = "";
        String currentActKey = "";
        WTDocument doc = null;
        if (obj instanceof WorkItem) {
            WorkItem workItem = (WorkItem) rf.getReference(urlOid).getObject();
            doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
            WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
            activityName = activity.getName();
            currentActKey = CtCertificateProperties.getActivityKey(activityName);
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
        } else if (obj instanceof WTDocument) {
            doc = (WTDocument) obj;
            readOnlyPage = true;
        }
        WTDocument previousVersion = (WTDocument) CtVersionUtil.getPreviousVersion(doc.getMaster());
        long previousBranchId = 0L;
        if(null != previousVersion){
            previousBranchId = previousVersion.getBranchIdentifier();
        }
        long branchId = doc.getBranchIdentifier();
        long masterId = doc.getMaster().getPersistInfo().getObjectIdentifier().getId();
    %>
    <script type="text/javascript">
        var branchId = '<%= branchId %>';
        var previousBranchId = '<%= previousBranchId %>';
        var masterId = '<%= masterId %>';
        //列ID
        var fileColumnId = '';
        //列名
        var fileColumnName = '';
        //下载文件名称
        var uploadTableName = '';
        var gridName = '';

        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";

        //判断当前任务是否已经完成
        var taskCompleted = false;
        <%if(taskCompleted){%>
            taskCompleted = true;
        <%}%>

        var readOnlyPage = false;
        <%if(readOnlyPage){%>
            readOnlyPage = true;
        <%}%>
    </script>
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript"
            src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="../../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="../../common/ctCommonObjects.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/uploadPanel.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/certificateDict.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/certificateFn.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctModelList.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctCertificateList.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctReportChecklist.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctProductApplicability.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctUpdateResume.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/certificate.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript">
        Ext.onReady(function () {
            Ext.QuickTips.init();
            Ext.apply(Ext.QuickTips.getQuickTip(), {
                dismissDelay: 120000
            });
            Ext.create('Ext.container.Viewport', {
                layout: 'border',
                items: [{
                    region: 'center',
                    xtype: 'CertificatePanel',
                }]
            });
        });
    </script>
</head>

<body>

</body>
</html>
