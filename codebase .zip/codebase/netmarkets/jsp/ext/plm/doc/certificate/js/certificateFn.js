var redStarFlag = '<font color=red bold>*</font>';//必填标志
var blueFlagStart = '<font color=blue bold><b>';//可编辑标识
var blueFlagEnd = '</b></font>';

var submit_Node="submit_Node";//三江电子-证书上传即发布流程-提交

/* ----------------------仅用于combobox设置选中值使用---------------*/
var certificateSelectFileds = ['productModel', 'certificationMark', 'relatedReportNumber']
var reportSelectFileds = ['productModel']
var productSelectFileds = ['productModel']
/* ----------------------仅用于是否可编辑条件使用---------------*/
/* ---------------------公共------------------------  */

/**
 * 判断是否可编辑
 * @param node 节点表单key
 * @returns {boolean}
 */
function isEditable(...node) {
    //return true;
    if (readOnlyPage || taskCompleted) return false;
    let flag = false;
    node.forEach((item, index) => {
        if (item === currentActKey) {
            flag = true;
        }
    });
    return flag;
}

//region grid单元格悬浮提示
function showTip(value, metaData, record, row, col, store) {
    if (value)
        metaData.tdAttr = 'data-qtip="' + value + '"';
    return value;
}//endregion

/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    //if(isAdmin) return true;
    var column = e.column;//获取编辑列
    if(column.editAccess){
        return true;
    }else{
        return false;
    }
    return true;
}

/**
 * 设为必填
 */
function setMust(field, flag) {
    // flag = true;
    if (flag)
        return redStarFlag + blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 设为可填
 */
function setRequired(field, flag) {
    // flag = true;
    if (flag)
        return blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 回显格式化日期格式
 * @param value
 * @returns {*|string}
 */
function renderDateField(value) {
    var timeStr = value;
    if (value != null && value != undefined && value != '') {
        var date = new Date(value);
        timeStr = Ext.Date.format(date, "Y-m-d");
    }
    return timeStr;
}

/**
 * 对Request封装
 * @Param url 请求url
 * @Param method 请求方法'GET' 'POST'
 * @Param async true 请求异步 false 请求步
 * @Param object
 * @Param callback 回调方法
 */
function sendRequest(url, method, headers, async, params, successCallback, failCallback) {
    Ext.Ajax.request({
        scope: this,
        url: url,
        method: method,
        timeout: 600000,
        async: async,
        headers: {'Content-Type': headers},
        params: params,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
                if (failCallback) {
                    failCallback();
                }
            } else {
                if (successCallback) {
                    successCallback(obj.data);
                }
            }
        },
        failure: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj && obj['message']) {
                Ext.Msg.alert('错误', obj['message']);
            } else {
                Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
            }
            if (failCallback != null && failCallback !== '') {
                failCallback();
            }
        }
    }); //~End of Ajax request
}

/* ---------------------证书管理主页------------------------  */

//点击显示生效中条目
function showEffectEntry() {
    // 当需要重新加载数据时，调用 load 方法
    ctCertificateListBo.getStore().load({
        params: {
            effective: 'effective'
        }
    });
    ctReportCheckListBo.getStore().load({
        params: {
            effective: 'effective'
        }
    });
}

//点击显示全部条目
function showAllEntry() {
    showAllCertificateListRecord();
}

//下载全部文件
function downloadAllFile() {
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在下载全部文件，请稍等......',
        target: Ext.getCmp('CertificatePanel'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    //勾选导出文档，下载压缩包
    Ext.Ajax.request({
        scope: this,
        url: "/Windchill/ptc1/ext/plm/doc/certificate/certificateList/exportZipFile",
        method: "POST",
        async: false,
        params: {
            masterId: masterId,
            branchId:branchId,
            viewName: '',
            selectedIds: ''
        },
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
            } else {
                let url = obj['data'];
                if(url){
                    window.location.href = url, '', 'width=300,height=200';
                }
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            loadMarsk.hide();
            Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
        }
    });
}

//下载生效中文件
function downloadEffectFile() {
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在下载生效中的文件，请稍等......',
        target: Ext.getCmp('CertificatePanel'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    //勾选导出文档，下载压缩包
    Ext.Ajax.request({
        scope: this,
        url: "/Windchill/ptc1/ext/plm/doc/certificate/certificateList/exportZipFile",
        method: "POST",
        async: false,
        params: {
            masterId: masterId,
            branchId:branchId,
            viewName: 'effective',
            selectedIds: ''
        },
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
            } else {
                let url = obj['data'];
                if(url){
                    window.location.href = url, '', 'width=300,height=200';
                }
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            loadMarsk.hide();
            Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
        }
    });
}

//下载选中文件
function downloadSelectFile() {
    //校验是否有选择
    let certificateGrid = Ext.getCmp("ctCertificateListBo");
    var certificateSm = certificateGrid.getSelectionModel().getSelection();
    let reportGrid = Ext.getCmp("ctReportCheckListBo");
    var reportSm = reportGrid.getSelectionModel().getSelection();
    if((!certificateSm || certificateSm=='') && (!reportSm || reportSm=='')){
        Ext.Msg.alert('提示', '请选择要下载文件的证书或报告！');
        return;
    }
    //获取选择数据的id
    let ids = '';
    for(let i = 0;i < certificateSm.length;i++){
        let rowData = certificateSm[i].getData();
        if(ids){
            ids += ',' + rowData['id'];
        }else{
            ids += rowData['id'];
        }
    }
    for(let i = 0;i < reportSm.length;i++){
        let rowData = reportSm[i].getData();
        if(ids){
            ids += ',' + rowData['id'];
        }else{
            ids += rowData['id'];
        }
    }

    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在下载选中的文件，请稍等......',
        target: Ext.getCmp('CertificatePanel'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    //勾选导出文档，下载压缩包
    Ext.Ajax.request({
        scope: this,
        url: "/Windchill/ptc1/ext/plm/doc/certificate/certificateList/exportZipFile",
        method: "POST",
        async: false,
        params: {
            masterId: masterId,
            branchId:branchId,
            viewName: 'select',
            selectedIds: ids
        },
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
            } else {
                let url = obj['data'];
                if(url){
                    window.location.href = url, '', 'width=300,height=200';
                }
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            loadMarsk.hide();
            Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
        }
    });
}

/* ---------------------相关型号------------------------  */

//添加相关型号
function addCtModelList() {
    function successCallback(data) {
        ctModelEditingConfig.cancelEdit();
        ctModelListBo.getStore().reload();
    }

    function failCallback() {
    }

    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/modelList/addModelListData', 'POST', "application/x-www-form-urlencoded",
        false, {branchId: branchId, masterId: masterId}, successCallback, failCallback);
}

//修改相关型号
function updateCtModelList(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    if (field === 'productModel') {
        var store = ctModelListBo.getStore();
        var count = 0;

        store.each(function (record) {
            if (record.get('productModel') === value) {
                count++;
            }
        });
        if (count > 1) {
            Ext.MessageBox.alert('Error', '产品型号必须是唯一的，请输入一个唯一的值！');
            record.reject();
            return false;
        }
    }

    function successCallback(data) {
        ctModelListBo.getStore().reload();
    }

    function failCallback() {
        record.reject();
    }

    let param = {id: id, key: field, value: value}
    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/modelList/updateModelListData', 'GET',
        {}, false, {updateRecord: Ext.encode(param)}, successCallback, failCallback);
}

//删除相关型号
function delCtModelList() {
    let selected = ctModelListBo.getSelectionModel().getSelection();
    if (selected.length === 0) {
        alert('请选择数据！');
    } else {
        function successCallback() {
            ctModelListBo.getStore().remove(selected);
            ctModelListBo.view.refresh();
        }

        function failCallback() {
        }

        let param = [];
        for (let i = 0; i < selected.length; i++) {
            let id = selected[i].get('id');
            if (id) {
                param[i] = id;
            }
        }
        if (param.length !== 0) {
            sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/modelList/deleteModelListData', 'DELETE',
                'application/json', false, JSON.stringify(param), successCallback, failCallback);
        }
    }
}

/* ---------------------证书清单------------------------  */
//上传文件弹框
function addFileInfo(columnId,columnName,tableName,gridTableName){
    fileColumnId = columnId;
    fileColumnName = columnName;
    uploadTableName = tableName;
    // //设置grid名称用于上传文件后刷新数据
    gridName = gridTableName;
    uploadFileWindow.show();
}
//查看文件弹框
function showFileInfo(columnId,columnName,tableName,gridTableName){
    fileColumnId = columnId;
    fileColumnName = columnName;
    uploadTableName = tableName;
    //设置grid名称用于上传文件后刷新数据
    gridName = gridTableName;
    // 刷新当前单元格内文件
    showFileStore.load({
        params: {
            fileColumnId: fileColumnId,
            fileColumnName: fileColumnName,
            uploadTableName:uploadTableName
        }
    });
    showFile.show();
}
//添加证书清单
function addCertificateList() {
    function successCallback(data) {
        ctCertificateEditingConfig.cancelEdit();
        ctCertificateListBo.getStore().reload();
        certificateNumberStates.reload();
    }

    function failCallback() {
    }

    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/certificateList/addCertificateListData', 'POST', "application/x-www-form-urlencoded",
        false, {branchId: branchId, masterId: masterId}, successCallback, failCallback);
}

//修改证书清单
function updateCertificateList(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    if (certificateSelectFileds.indexOf(field) !== -1) {
        if (value.length > 0) {
            let temp = JSON.parse(JSON.stringify(value))
            value = temp.map((item) => {
                return item;
            }).join(',');
        } else {
            value = '';
        }
    }

    function successCallback(data) {
        ctCertificateListBo.getStore().reload();
        if('relatedReportNumber' == field || 'whetherToCancel' == field){
            ctReportCheckListBo.getStore().reload();
        }
        if('whetherToCancel' == field){
            ctModelListBo.getStore().reload();
        }
        if('certificateNumber' == field){
            ctReportCheckListBo.getStore().reload();
        }
    }

    function failCallback() {
        record.reject();
    }

    let param = {id: id, key: field, value: value}
    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/certificateList/updateCertificateListData', 'GET',
        {}, false, {updateRecord: Ext.encode(param)}, successCallback, failCallback);
}

//下拉选择设置默认值
function setSelectDefaultValue(view, record, item, index, e) {
    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    if(!cell){
        return;
    }
    var cellIndex = cell.cellIndex + 1; // 获取单元格的索引
    var column = headerCt.getGridColumns()[cellIndex];
    if (column) {
        var columnName = column.dataIndex;
        if (columnName == 'productModel') {
            var productModel = record['data'].productModel;
            if (productModel) {
                var productModelSelectedValues = productModel.split(',');
                productModelComboBox.setValue(productModelSelectedValues);
            }
        } else if (columnName == 'certificationMark') {
            var certificationMark = record['data'].certificationMark;
            if (certificationMark) {
                var certificationMarkSelectedValues = certificationMark.split(',');
                certificationMarkComboBox.setValue(certificationMarkSelectedValues);
            }
        } else if (columnName == 'relatedReportNumber') {
            var relatedReportNumber = record['data'].relatedReportNumber;
            if (relatedReportNumber) {
                var relatedReportNumberSelectedValues = relatedReportNumber.split(',');
                relationReportComboBox.setValue(relatedReportNumberSelectedValues);
            }
        }
    }
}

//删除证书清单
function delCertificateList() {
    let selected = ctCertificateListBo.getSelectionModel().getSelection();
    if (selected.length === 0) {
        alert('请选择数据！');
    } else {
        function successCallback() {
            ctCertificateListBo.getStore().remove(selected);
            ctCertificateListBo.view.refresh();
        }

        function failCallback() {
        }


        let param = [];
        for (let i = 0; i < selected.length; i++) {
            let currentBranchId = selected[i].get('branchId');
            if(branchId != currentBranchId){
                Ext.Msg.alert('提示', '不能删除历史版本添加的条目！');
                return;
            }
            let id = selected[i].get('id');
            if (id) {
                param.push(id);
            }
        }
        if (param.length !== 0) {
            sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/certificateList/deleteCertificateListData', 'DELETE',
                'application/json', false, JSON.stringify(param), successCallback, failCallback);
        }
    }
}

//点击显示关联记录
function showRelationCertificateListRecord() {
    let selected = ctCertificateListBo.getSelectionModel().getSelection();
    if (selected.length === 0) {
        alert('请选择数据！');
    } else {
        let param = '';
        param = selected.map((item) => {
            return item.id;
        }).join(',');
        // 当需要重新加载数据时，调用 load 方法
        ctCertificateListBo.getStore().load({
            params: {
                ids: param
            }
        });
        ctReportCheckListBo.getStore().load({
            params: {
                certificateIds: param
            }
        });
        ctModelListBo.getStore().load({
            params: {
                certificateIds: param
            }
        });
    }
}

//点击显示全部记录
function showAllCertificateListRecord() {
    ctReportCheckListBo.getStore().load({
        params: {
            ids: '',
            effective:''
        }
    });
    ctCertificateListBo.getStore().load({
        params: {
            ids: '',
            effective:''
        }
    });
    ctModelListBo.getStore().load({
        params: {
            ids: ''
        }
    });
}

/* ---------------------报告清单------------------------  */

//添加报告清单
function addReportCheckList() {
    function successCallback(data) {
        ctReportEditingConfig.cancelEdit();
        ctReportCheckListBo.getStore().reload();
        relationReportStore.reload();
    }

    function failCallback() {
    }

    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/reportChecklist/addReportChecklistData', 'POST', "application/x-www-form-urlencoded",
        false, {branchId: branchId, masterId: masterId}, successCallback, failCallback);
}

//修改报告清单
function updateReportCheckList(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    if (reportSelectFileds.indexOf(field) !== -1) {
        let temp = JSON.parse(JSON.stringify(value))
        if (value.length > 0) {
            value = temp.map((item) => {
                return item;
            }).join(',');
        } else {
            value = '';
        }
    }

    function successCallback(data) {
        ctReportCheckListBo.getStore().reload();
        relationReportStore.reload();
    }

    function failCallback() {
        record.reject();
    }

    let param = {id: id, key: field, value: value}
    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/reportChecklist/updateReportChecklistData', 'GET',
        {}, false, {updateRecord: Ext.encode(param)}, successCallback, failCallback);
}

//删除报告清单
function delReportCheckList() {
    let selected = ctReportCheckListBo.getSelectionModel().getSelection();
    if (selected.length === 0) {
        alert('请选择数据！');
    } else {
        function successCallback() {
            ctReportCheckListBo.getStore().remove(selected);
            ctReportCheckListBo.view.refresh();

        }

        function failCallback() {
        }

        let param = [];
        for (let i = 0; i < selected.length; i++) {
            let currentBranchId = selected[i].get('branchId');
            if(branchId != currentBranchId){
                Ext.Msg.alert('提示', '不能删除历史版本添加的条目！');
                return;
            }
            let id = selected[i].get('id');
            if (id) {
                param[i] = id;
            }
        }
        if (param.length !== 0) {
            sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/reportChecklist/deleteReportChecklistData', 'DELETE',
                'application/json', false, JSON.stringify(param), successCallback, failCallback);
        }
    }
}

//点击显示关联记录
function showRelationReportCheckListRecord() {
    let selected = ctReportCheckListBo.getSelectionModel().getSelection();
    if (selected.length === 0) {
        alert('请选择数据！');
    } else {
        let param = '';
        param = selected.map((item) => {
            return item.id;
        }).join(',');
        // 当需要重新加载数据时，调用 load 方法
        ctReportCheckListBo.getStore().load({
            params: {
                ids: param
            }
        });
        ctCertificateListBo.getStore().load({
            params: {
                reportIds: param
            }
        });
        ctModelListBo.getStore().load({
            params: {
                reportIds: param
            }
        });
    }
}

//点击显示全部记录
function showAllReportCheckListRecord() {
    showAllCertificateListRecord()
}

/* ---------------------相关成品清单------------------------  */

//添加相关成品清单
function addProductApplicability() {
    function successCallback(data) {
        ctProductEditingConfig.cancelEdit();
        ctProductApplicabilityBo.getStore().reload();
    }

    function failCallback() {
    }

    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/productApplicability/addProductApplicabilityData', 'POST', "application/x-www-form-urlencoded",
        false, {branchId: branchId, masterId: masterId}, successCallback, failCallback);
}

//修改相关成品清单
function updateProductApplicability(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    if (productSelectFileds.indexOf(field) !== -1) {
        let temp = JSON.parse(JSON.stringify(value))
        if (value.length > 0) {
            value = temp.map((item) => {
                return item;
            }).join(',');
        } else {
            value = '';
        }
    }
    function successCallback(data) {
        ctProductApplicabilityBo.getStore().reload();
    }

    function failCallback() {
        record.reject();
    }

    let param = {id: id, key: field, value: value}
    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/productApplicability/updateProductApplicabilityData', 'GET',
        {}, false, {updateRecord: Ext.encode(param)}, successCallback, failCallback);
}

//删除相关成品清单
function delProductApplicability() {
    let selected = ctProductApplicabilityBo.getSelectionModel().getSelection();
    if (selected.length === 0) {
        alert('请选择数据！');
    } else {
        function successCallback() {
            ctProductApplicabilityBo.getStore().remove(selected);
            ctProductApplicabilityBo.view.refresh();
        }

        function failCallback() {
        }

        let param = [];
        for (let i = 0; i < selected.length; i++) {
            let id = selected[i].get('id');
            if (id) {
                param[i] = id;
            }
        }
        if (param.length !== 0) {
            sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/productApplicability/deleteProductApplicabilityData', 'DELETE',
                'application/json', false, JSON.stringify(param), successCallback, failCallback);
        }
    }
}

/* ---------------------更新履历------------------------  */

//添加更新履历
function addUpdateResume() {
    function successCallback(data) {
        ctResumeEditingConfig.cancelEdit();
        ctUpdateResumeBo.getStore().reload();
    }

    function failCallback() {
    }

    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/updateResume/addUpdateResumeData', 'POST', "application/x-www-form-urlencoded",
        false, {branchId: branchId, masterId: masterId}, successCallback, failCallback);
}

//修改更新履历
function updateUpdateResume(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }

    function successCallback(data) {
        ctUpdateResumeBo.getStore().reload();
    }

    function failCallback() {
        record.reject();
    }

    let param = {id: id, key: field, value: value}
    sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/updateResume/updateUpdateResumeData', 'GET',
        {}, false, {updateRecord: Ext.encode(param)}, successCallback, failCallback);
}

//删除更新履历
function delUpdateResume() {
    let selected = ctUpdateResumeBo.getSelectionModel().getSelection();
    if (selected.length === 0) {
        alert('请选择数据！');
    } else {
        function successCallback() {
            ctUpdateResumeBo.getStore().remove(selected);
            ctUpdateResumeBo.view.refresh();
        }

        function failCallback() {
        }

        let param = [];
        for (let i = 0; i < selected.length; i++) {
            let id = selected[i].get('id');
            if (id) {
                param[i] = id;
            }
        }
        if (param.length !== 0) {
            sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/updateResume/deleteUpdateResumeData', 'DELETE',
                'application/json', false, JSON.stringify(param), successCallback, failCallback);
        }
    }
}
