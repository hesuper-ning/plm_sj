var ctProductEditingConfig = Ext.create('Ext.grid.plugin.CellEditing', {
    clicksToEdit: 1
})
var ctProductApplicabilityStore = new Ext.data.ArrayStore({
    id: 'ctProductApplicabilityStore',
    fields: [],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/ext/plm/doc/certificate/productApplicability/getProductApplicabilityData?masterId=' + masterId,
        timeout: 60000,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: true
});
var ctProductApplicabilityBo = Ext.create('Ext.grid.Panel', {
    id: 'ctProductApplicabilityBo',
    store: ctProductApplicabilityStore,
    forceFit: false,
    //height: 300,
    autoWidth: true,
    title: '4. 相关成品适用性',
    collapsible: true,
    collapsed: false,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctProductEditingConfig],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {
            text: setMust('成品编码',isEditable(submit_Node)),
            width: 120,
            align: 'center',
            dataIndex: 'productNumber',
            sortable: false,
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: '成品描述',
            width: 300,
            dataIndex: 'productDesc',
            align: 'center',
            editAccess: false,
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: '产品型号',
            width: 120,
            dataIndex: 'productModel',
            align: 'center',
            editAccess: false
            //editor: productModelComboBox
        },
        {
            text: setMust('是否适用证书',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'applicableCertificates',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: ynDictComboBox
        },
        {
            text: setRequired('说明',isEditable(submit_Node)),
            width: 600,
            dataIndex: 'explain',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        }
    ],
    tbar: Ext.create('Ext.toolbar.Toolbar', {
        items: [{
            text: '添加行',
            xtype: 'button',
            iconCls: 'icon icon-add',
            hidden: !isEditable(submit_Node),
            handler: addProductApplicability
        }, {
            text: '删除行',
            xtype: 'button',
            iconCls: 'icon icon-delete',
            hidden: !isEditable(submit_Node),
            handler: delProductApplicability
        }]

    }),
    listeners: {
        beforeedit: function (editor, context) {
            // 假设我们根据某些条件决定是否允许编辑'name'字段
            var record = context.record; // 当前行记录
            var field = context.field; // 当前字段名
            var value = record.get(field); // 当前字段的值

            // 如果满足条件，则允许编辑
            return checkEditAccess(context);
        },
        edit: function (editor, e) {
            updateProductApplicability(editor, e);
        },
        rowclick: function (view, record, item, index, e) {
            setSelectDefaultValue(view, record, item, index, e);
        }
    }
});
