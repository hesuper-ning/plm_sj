var ctCertificateEditingConfig = Ext.create('Ext.grid.plugin.CellEditing', {
    clicksToEdit: 1
})

var ctCertificateListStore = new Ext.data.ArrayStore({
    id: 'ctCertificateListStore',
    fields: [],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/ext/plm/doc/certificate/certificateList/getCertificateListData',
        extraParams: {
            // 这里可以添加任何需要作为请求参数的数据
            masterId: masterId,
            ids: '',
            effective: readOnlyPage?'effective':''//只读页面展示有效的
        },
        timeout: 60000,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: true,
    autoDestroy: true
});
var ctCertificateListBo = Ext.create('Ext.grid.Panel', {
    id: 'ctCertificateListBo',
    store: ctCertificateListStore,
    forceFit: false,
    //height: 300,
    autoWidth: true,
    title: '2. 证书清单',
    collapsible: true,
    collapsed: false,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctCertificateEditingConfig],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {
            text: '证书状态',
            width: 100,
            align: 'center',
            dataIndex: 'certificateStatus',
            editAccess: isEditable(submit_Node),
            sortable: false
            // editor: cerStatusComboBox
        },
        {
            text: setMust('认证类型',isEditable(submit_Node)),
            width: 100,
            dataIndex: 'certificationType',
            editAccess: isEditable(submit_Node),
            align: 'center',
            editor: authenticationTypeComboBox
        },
        {
            text: setMust('产品型号',isEditable(submit_Node)),
            width: 100,
            dataIndex: 'productModel',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: productModelComboBox,
            renderer: function (value, metaData, record, row, col, store) {
                //提示tip
                metaData.tdAttr = " data-qtip = '" + value + "'";
                return value;
            }
        },
        {
            text: setMust('证书编号',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'certificateNumber',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        // {
        //     text: '国内海外',
        //     width: 120,
        //     dataIndex: 'branchId',
        //     align: 'center',
        //     editor: {xtype: 'textfield', selectOnFocus: true}
        // },
        {
            text: setRequired('首次发证日期',isEditable(submit_Node)),
            width: 100,
            dataIndex: 'firstIssuanceDate',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'datefield', format: 'Y-m-d'},
            renderer: function (value) {
                return renderDateField(value);
            }
        },
        {
            text: setMust('获得证书日期',isEditable(submit_Node)),
            width: 100,
            dataIndex: 'obtainingCertificateDate',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'datefield', format: 'Y-m-d', selectOnFocus: true},
            renderer: function (value) {
                return renderDateField(value);
            }
        },
        {
            text: setRequired('证书到期日期',isEditable(submit_Node)),
            width: 100,
            dataIndex: 'certificateExpirationDate',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'datefield', format: 'Y-m-d', selectOnFocus: true},
            renderer: function (value) {
                return renderDateField(value);
            }
        },
        {
            text: setMust('关联报告编号',isEditable(submit_Node)),
            width: 100,
            dataIndex: 'relatedReportNumber',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: relationReportComboBox,
            renderer: function (value, meta, record) {
                if(value){
                    let tip = "<p style='word-wrap:break-word'>"+value+"</p>";
                    meta.tdAttr = 'data-qtip="' + tip + '"';
                }
                return value;
            }
        },
        {
            text: setMust('证书文件',isEditable(submit_Node)),
            width: 80,
            dataIndex: 'certificateFile',
            align: 'center',
            xtype: 'actioncolumn',
            items: [
                '->',
                {
                    iconCls: 'icon icon-uploadImage',
                    tooltip: '添加文件',
                    hidden: !isEditable(submit_Node),
                    handler: function (grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        addFileInfo(record.get('id'),'certificateFile','ZCertificateListTable','ctCertificateListBo')
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var rowBranchId = record.get('branchId');
                        // 这里添加你的逻辑来决定是否允许编辑
                        if (branchId != rowBranchId) {
                            return true;
                        }
                    }
                },
                '-',
                {
                    iconCls: 'icon-showInfo',
                    tooltip: '查看文件',
                    handler: function (grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        branchId = record.get('branchId');
                        //设置当前列的id与列名和表名
                        showFileInfo(record.get('id'),'certificateFile','ZCertificateListTable','ctCertificateListBo')

                        let deleteBtn = Ext.getCmp('showDelete');
                        if(isEditable(submit_Node)){
                            deleteBtn.show();
                        }else{
                            deleteBtn.hide();
                        }
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var boolean = record.data.certificateFile;
                        if(boolean!=null) {
                            return false;
                        }
                        return true;
                    }
                }
            ]
        },
        {
            text: setRequired('电子证书',isEditable(submit_Node)),
            width: 80,
            dataIndex: 'electronicCertificate',
            align: 'center',
            xtype: 'actioncolumn',
            items: [
                '->',
                {
                    iconCls: 'icon icon-uploadImage',
                    tooltip: '添加文件',
                    hidden: !isEditable(submit_Node),
                    handler: function (grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        addFileInfo(record.get('id'),'electronicCertificate','ZCertificateListTable','ctCertificateListBo')
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var rowBranchId = record.get('branchId');
                        // 这里添加你的逻辑来决定是否允许编辑
                        if (branchId != rowBranchId) {
                            return true;
                        }
                    }
                },
                '-',
                {
                    iconCls: 'icon-showInfo',
                    tooltip: '查看文件',
                    handler: function (grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        showFileInfo(record.get('id'),'electronicCertificate','ZCertificateListTable','ctCertificateListBo')

                        let deleteBtn = Ext.getCmp('showDelete');
                        if(isEditable(submit_Node)){
                            deleteBtn.show();
                        }else{
                            deleteBtn.hide();
                        }
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var boolean = record.data.electronicCertificate;
                        if(boolean!=null) {
                            return false;
                        }
                        return true;
                    }
                }
            ]
        },
        {
            text: setRequired('存档类型',isEditable(submit_Node)),
            width: 80,
            dataIndex: 'archiveType',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: archiveTypeComboBox
        },
        {
            text: setMust('状态选择',isEditable(submit_Node)),
            width: 80,
            dataIndex: 'whetherToCancel',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: statusSelectComboBox
        },
        // {
        //     text: '是否注销',
        //     width: 120,
        //     dataIndex: 'whetherToCancel',
        //     align: 'center',
        //     editor: ynDictComboBox
        // },
        {
            text: setRequired('注销日期',isEditable(submit_Node)),
            width: 80,
            dataIndex: 'expirationDate',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'datefield', format: 'Y-m-d', selectOnFocus: true},
            renderer: function (value) {
                return renderDateField(value);
            }
        },
        {
            text: setRequired('注销履历',isEditable(submit_Node)),
            width: 80,
            dataIndex: 'cancelResume',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: setMust('身份信息类型',isEditable(submit_Node)),
            width: 80,
            dataIndex: 'identityInformationType',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: identityInformationTypeComboBox
        },
        {
            text: setMust('认证标识',isEditable(submit_Node)),
            width: 120,
            dataIndex: 'certificationMark',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: certificationMarkComboBox
        },
        {
            text: setRequired('标识编号',isEditable(submit_Node)),
            width: 100,
            dataIndex: 'identificationNumber',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: setRequired('生产企业',isEditable(submit_Node)),
            width: 240,
            dataIndex: 'manufacturingEnterprise',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {
                xtype: 'combo',
                editable: true,
                forceSelection: false,
                store: manufacturingEnterpriseStore
            }
        },
        {
            text: '',
            width: 50
        }
    ],
    tbar: Ext.create('Ext.toolbar.Toolbar', {
        items: [{
            text: '添加行',
            xtype: 'button',
            iconCls: 'icon icon-add',
            hidden: !isEditable(submit_Node),
            handler: addCertificateList
        }, {
            text: '删除行',
            xtype: 'button',
            iconCls: 'icon icon-delete',
            hidden: !isEditable(submit_Node),
            handler: delCertificateList
        },
        {
            xtype: 'button',
            text: '复制',
            iconCls: 'icon-copy',
            hidden: !isEditable(submit_Node),
            handler: function () {
                var selected = ctCertificateListBo.getSelectionModel().getSelection();
                if(selected.length == 0){
                    Ext.Msg.alert("提示", "请先选择要复制的数据！");
                    return false;
                }
                if(selected.length > 1){
                    Ext.Msg.alert("提示", "只能选择一行数据！")
                    return false;
                }
                let id = selected[0].get('id');

                function successCallback(data) {
                    ctCertificateListBo.getStore().load();
                }
                sendRequest('/Windchill/ptc1/ext/plm/doc/certificate/certificateList/copyCertificateData', 'POST',
                    'application/x-www-form-urlencoded', false, {masterId: masterId, branchId: branchId, id: id},
                    successCallback);
            }
        },
        {
            text: '点击显示关联记录',
            iconCls: 'icon icon-add',
            disabled: false,
            hidden: !isEditable(submit_Node),
            handler: showRelationCertificateListRecord
        }, {
            text: '点击显示全部记录',
            iconCls: 'icon icon-add',
            disabled: false,
            hidden: !isEditable(submit_Node),
            handler: showAllCertificateListRecord
        }]

    }),
    listeners: {
        beforeedit: function(editor, context, eOpts) {
            // 假设我们根据某些条件决定是否允许编辑'name'字段
            var record = context.record; // 当前行记录
            var field = context.field; // 当前字段名
            var value = record.get(field); // 当前字段的值


            var rowBranchId = record.get('branchId');
            var whetherToCancel = record.get('whetherToCancel');
            // 这里添加你的逻辑来决定是否允许编辑
            if (branchId != rowBranchId && '勘误' != whetherToCancel) {
                if(previousBranchId && previousBranchId==rowBranchId){
                    if(field != 'whetherToCancel' && field != 'expirationDate' && field != 'cancelResume' && field != 'relatedReportNumber') {
                        return false;
                    }
                }else{
                    return false;
                }
            }
            // 如果满足条件，则允许编辑
            return checkEditAccess(context);
        },
        edit: function (editor, e) {
            updateCertificateList(editor, e);
        },
        rowclick: function (view, record, item, index, e) {
            setSelectDefaultValue(view, record, item, index, e)
        }
    }
});
