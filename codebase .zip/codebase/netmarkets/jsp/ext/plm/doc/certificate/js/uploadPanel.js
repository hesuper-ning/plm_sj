/* ----------------------仅用于文件上传查看使用---------------*/

Ext.define('PLM.view.uploadFileCertificatePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.uploadFileCertificatePanel',
    border: false,
    height: 300,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //文件提交表单
        var formUpload = new Ext.form.FormPanel({
            fileUpload: true,
            autoHeight: true,
            autoWidth: true,
            //frame:true,
            id: "uploadFormPannel",
            border: false,
            items: []
        });
        addPanel("pannel_1");
        //为附件panelID赋值
        var n = 1;
        //文件提交表单最外层form
        var uploadPanel = new Ext.form.FormPanel({
            setZIndex: Ext.emptyFn,
            closeAction: 'hide',
            buttonAlign: 'center',
            width: 530,
            height: 300,
            layout: 'fit',
            plain: true,
            border: 0,
            defaults: {autoScroll: true},// 设置滚动条
            id: 'uploadPanel',
            items: formUpload,
            name: 'userfile',
            tbar: ['->', {
                text: '继续添加文件',
                iconCls: 'btn-add',
                handler: function () {
                    if(fileColumnName==="certificateFile") {
                        alert("该字段只允许上传一个文件！")
                    }else {
                        n++;
                        var newPannelId = "pannel_" + n;
                        addPanel(newPannelId);
                    }
                }
            }],
            buttons: [{
                text: '上 传',
                id: 'uploadBtn',
                handler: function () {
                    if (formUpload.form.isValid()) {
                        // 添加遮罩
                        formUpload.mask('正在导入......');
                        formUpload.getForm().submit({
                            method: 'POST',
                            url: '/Windchill/ptc1/ext/plm/doc/certificate/certificateList/uploadFile?fileColumnId=' + fileColumnId + '&fileColumnName=' + fileColumnName+ '&branchId=' + branchId+'&uploadTableName='+uploadTableName,
                            success: function (form, action) {
                                problemId = '';
                                alert('导入成功');
                                var obj = action.result;
                                imgs = action.result.imgs;

                                //刷新表格内的数据
                                var uploadFormPannel = Ext.getCmp(gridName);
                                // 获取关联的 Store
                                var store = uploadFormPannel.getStore();
                                // 更新 Store 中的数据
                                store.load();
                                var pannelId = "";
                                for (var i = n; i > 0; i--) {
                                    pannelId = "pannel_" + i;
                                    uploadFormPannel.remove(Ext.getCmp(pannelId));
                                }

                                // addPanel(pannelId);
                                Ext.getCmp('uploadPanel').ownerCt.ownerCt.hide();
                                // 取消遮罩
                                formUpload.unmask();
                            },
                            failure: function (form, action) {
                                problemId = '';
                                // 取消遮罩
                                formUpload.unmask();
                                alert('导入失败，请检查网络');
                            }
                        });
                    }
                }
            }, {
                text: '取 消',
                handler: function () {
                    problemId = "";
                    var pannelId = "";
                    for (var i = n; i > 0; i--) {
                        pannelId = "pannel_" + i;
                        Ext.getCmp('uploadFormPannel').remove(Ext.getCmp(pannelId));
                    }
                    addPanel(pannelId);
                    Ext.getCmp('uploadPanel').ownerCt.ownerCt.hide();
                }
            }]
        });

        function addPanel(pannelId) { // 添加一个组件面板
            try {
                Ext.getCmp('uploadFormPannel').add(createPanel(pannelId));
                Ext.getCmp('uploadFormPannel').updateLayout();
            } catch (e) {
                alert(e.name + " -- " + e.message);
            }
        }

        function createPanel(pannelId) { // 创建一个panel
            var newPannel = new Ext.Panel({
                //frame:true,
                height: 40,
                width: 500,
                id: pannelId,
                border: false,
                style: {
                    borderColor: 'white',
                    borderStyle: 'solid'
                },
                items: [{
                    autoHeight: true,
                    layout: 'column',
                    border: false,
                    style: 'font-size:13px;',
                    items: [{
                        xtype: 'filefield',
                        fieldLabel: '附件',
                        labelWidth: 50,
                        name: 'uploadName',
                        allowBlank: false,
                        buttonText: '选择文件',
                        blankText: '请上传文件',
                        listeners: {
                            //t代表本身对象，n和o为前后的value
                            change: function (t, n, o, e) {
                            }
                        }
                    }, {
                        margin: '0 0 0 10',
                        xtype: "button",
                        text: "删除",
                        handler: function () {
                            if (fileColumnName === "certificateFile") {
                                alert("该字段只允许上传一个文件,不允许删除！")
                            } else {
                                Ext.getCmp('uploadFormPannel').remove(Ext.getCmp(pannelId));
                            }
                        }
                    }]
                }]
            });
            return newPannel;
        }

        this.items = [
            uploadPanel
        ];
        this.callParent();
    }
});
//上传文件窗口
var uploadFileWindow = Ext.create('Ext.Window', {
    title: '导入文件',
    width: 550,
    height: 350,
    //autoHeight : true,
    //autoWidth : true,
    closeAction: 'hide',
    id: 'uploadFileWindow',
    autoScroll: false,
    //closable:false,
    constrain: true,
    layout: 'fit',
    modal: true,
    items: {
        xtype: 'uploadFileCertificatePanel'
    }
});
//文件显示
var showFileStore = Ext.create('Ext.data.Store', {
    fields: ['fileName'],
    id: 'showFileStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/ext/plm/doc/certificate/certificateList/searchFileName',
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            messageProperty: 'message'
        }
    }),
    autoLoad: false,
});
var showGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});
var showFileColumns = [
    {text: '文档名称', dataIndex: 'fileName', flex: 1, menuDisabled: true, editor: false}
];
var showFileGrid = Ext.create('Ext.grid.Panel', {
    plugins: [showGridEditing],
    store: showFileStore,
    columns: showFileColumns,
    id: 'showFileGrid',
    autoWidth: true,
    columnLines: true,
    width: '100%',
    height: '100%',
    height: 300,
    multiSelect: false,
    autoScroll: true,
    forceFit: false,
    viewConfig: {
        enableTextSelection: true
    },
    selModel: {
        type: "checkboxmodel",
        mode: 'SINGLE'//单选
        // mode: 'MULTI'//多选
    },
    tbar: [
        {
            xtype: 'button',
            text: '下载文件',
            id: 'showInsert',
            iconCls: 'icon icon-download',
            handler: function () {
                var recordList = showFileGrid.getSelectionModel().getSelection();
                if (recordList.length != 0) {
                    var fileName = recordList[0].data.fileName;
                    fileName = fileName.replace(/\+/g, '%2B');
                    window.location.href = '/Windchill/ptc1/ext/plm/doc/certificate/certificateList/downLoadDoc?fileName=' + fileName + '&branchId=' + branchId + '&fileColumnName=' + fileColumnName;
                } else {
                    alert("请选择一条数据")
                }
            }
        },
        {
            xtype: 'button',
            text: '删除文件',
            id: 'showDelete',
            // hidden:showDeleteValue?true:false,
            iconCls: 'icon icon-delete',
            handler: function () {
                // if (showDeleteValue) {
                //     alert("当前节点不允许删除该文件！");
                //     return;
                // }
                var recordList = showFileGrid.getSelectionModel().getSelection();
                if (recordList.length != 0) {
                    var fileName = recordList[0].data.fileName;
                    var deleteParam = {
                        fileName: fileName,
                        branchId: branchId,
                        fileColumnId: fileColumnId,
                        fileColumnName: fileColumnName,
                        uploadTableName: uploadTableName
                    }
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/ext/plm/doc/certificate/certificateList/deleteFiles',
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        params: JSON.stringify(deleteParam),
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            alert(obj.msg)
                            showFileStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName: uploadTableName
                                }
                            });
                            //刷新表格内的数据
                            var uploadFormPannel = Ext.getCmp(gridName);
                            // 获取关联的 Store
                            var store = uploadFormPannel.getStore();
                            // 更新 Store 中的数据
                            store.load();
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                } else {
                    alert("请选择一条数据")
                }
            }
        },
        {
            xtype: 'button',
            text: '下载全部文件',
            id: 'downloadAllFile',
            iconCls: 'icon icon-download',
            handler: function () {
                var store = showFileGrid.getStore(); // 获取Grid的数据源
                var allData = store.getData().items; // 获取数据源中的所有数据
                var concatenatedData = '';

                if (allData) {
                    for (let i = 0; i < allData.length; i++) {
                        let rowData = allData[i].data;
                        if (i == 0) {
                            concatenatedData = rowData['fileName']
                        } else {
                            concatenatedData += ";;;qqq" + rowData['fileName'];
                        }
                    }
                }

                if (concatenatedData.length != 0) {
                    //window.location.href = '/Windchill/ptc1/technicalChange/downLoadAllDoc?fileName='+concatenatedData+'&branchId='+branchId+'&fileColumnName='+fileColumnName;
                    // 创建一个 form 表单
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '/Windchill/ptc1/ext/plm/doc/certificate/certificateList/downLoadAllDoc';

                    // 创建一个 input 元素用于存放参数
                    var fileNameInput = document.createElement('input');
                    fileNameInput.type = 'hidden';
                    fileNameInput.name = 'fileName';
                    fileNameInput.value = concatenatedData;
                    form.appendChild(fileNameInput);

                    var branchIdInput = document.createElement('input');
                    branchIdInput.type = 'hidden';
                    branchIdInput.name = 'branchId';
                    branchIdInput.value = branchId;
                    form.appendChild(branchIdInput);

                    var fileColumnNameInput = document.createElement('input');
                    fileColumnNameInput.type = 'hidden';
                    fileColumnNameInput.name = 'fileColumnName';
                    fileColumnNameInput.value = fileColumnName;
                    form.appendChild(fileColumnNameInput);
                    // 将表单添加到页面中
                    document.body.appendChild(form);
                    // 提交表单
                    form.submit();

                } else {
                    alert("当前没有可以下载的文件！")
                }
            }
        }
    ]
    // 其他配置项...
});

var showFile = Ext.create('Ext.Window', {
    id: 'show1',
    title: '文档操作',
    width: 700,
    //height: 300,
    autoHeight: true,
    closeAction: 'hide',
    //closable:false,
    constrain: true,
    modal: true,
    items: [showFileGrid]
});
