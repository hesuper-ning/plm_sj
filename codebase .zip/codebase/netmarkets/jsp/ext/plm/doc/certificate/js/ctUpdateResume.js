var ctResumeEditingConfig = Ext.create('Ext.grid.plugin.CellEditing', {
    clicksToEdit: 1
})
var ctUpdateResumeStore = new Ext.data.ArrayStore({
    id: 'ctUpdateResumeStore',
    fields: [],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/ext/plm/doc/certificate/updateResume/getUpdateResumeData?masterId=' + masterId,
        timeout: 60000,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: true
});
var ctUpdateResumeBo = Ext.create('Ext.grid.Panel', {
    id: 'ctUpdateResumeBo',
    store: ctUpdateResumeStore,
    forceFit: false,
    //height: 300,
    autoWidth: true,
    title: '5. 更新履历',
    collapsible: true,
    collapsed: false,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctResumeEditingConfig],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {
            text: '更新日期',
            width: 120,
            align: 'center',
            dataIndex: 'updateDate',
            sortable: false,
            editAccess: false,
            // editor: {xtype: 'datefield', format: 'Y-m-d', selectOnFocus: true},
            renderer: function (value) {
                return renderDateField(value);
            }
        },
        {
            text: '更新人员',
            width: 120,
            dataIndex: 'updatePersonnel',
            align: 'center',
            editAccess: false
            // editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {
            text: setMust('更新履历',isEditable(submit_Node)),
            width: 600,
            dataIndex: 'updateResume',
            align: 'center',
            editAccess: isEditable(submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        }
    ],
    tbar: Ext.create('Ext.toolbar.Toolbar', {
        items: [{
            text: '添加行',
            xtype: 'button',
            iconCls: 'icon icon-add',
            hidden: !isEditable(submit_Node),
            handler: addUpdateResume
        }]

    }),
    listeners: {
        beforeedit: function (editor, context) {
            // 假设我们根据某些条件决定是否允许编辑'name'字段
            var record = context.record; // 当前行记录
            var field = context.field; // 当前字段名
            var value = record.get(field); // 当前字段的值


            // 如果满足条件，则允许编辑
            return checkEditAccess(context);
        },
        edit: function (editor, e) {
            updateUpdateResume(editor, e);
        }
    }
});
