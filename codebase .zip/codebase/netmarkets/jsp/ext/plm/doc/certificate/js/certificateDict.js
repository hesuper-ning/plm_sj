//是否字典
var ynDictStates = Ext.create('Ext.data.Store', {
    fields: ['value', 'name'],
    data: [
        {"value": "是", "name": "是"},
        {"value": "否", "name": "否"}
    ]
});

var ynDictComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'ynDictComboBox',
    id: 'ynDictComboBox',
    multiSelect: false,
    store: ynDictStates,
    queryMode: 'local',
    displayField: 'name',
    valueField: 'value'
});

//认证类型
var authenticationTypeStates = Ext.create('Ext.data.Store', {
    fields: ['value', 'name'],
    data: [
        {"value": "防腐认证", "name": "防腐认证"},
        {"value": "船检认证", "name": "船检认证"},
        {"value": "CCC认证", "name": "CCC认证"},
        {"value": "自愿性认证", "name": "自愿性认证"},
        {"value": "技术鉴定", "name": "技术鉴定"},
        {"value": "防爆认证", "name": "防爆认证"},
        {"value": "LPCB认证", "name": "LPCB认证"},
        {"value": "APPLUS认证", "name": "APPLUS认证"},
        {"value": "CoC中东认证", "name": "CoC中东认证"},
        {"value": "电信设备进网许可证", "name": "电信设备进网许可证"},
        {"value": "无线电发射设备型号核准证", "name": "无线电发射设备型号核准证"},
        {"value": "计量器具型式批准", "name": "计量器具型式批准"},
        {"value": "其它", "name": "其它"},
        {"value": "非认证", "name": "非认证"},
        {"value": "CCS", "name": "CCS"},
        {"value": "SIL认证", "name": "SIL认证"},
        {"value": "UL认证", "name": "UL认证"},
        {"value": "CE认证(欧洲)", "name": "CE认证(欧洲)"},
        {"value": "CE认证(国内)", "name": "CE认证(国内)"},
        {"value": "船检认证", "name": "船检认证"},
        {"value": "UKCA", "name": "UKCA"},
        {"value": "(停)CCC认证", "name": "(停)CCC认证"},
        {"value": "(停)自愿性认证", "name": "(停)自愿性认证"},
        {"value": "(停)技术鉴定", "name": "(停)技术鉴定"},
        {"value": "(停)防爆认证", "name": "(停)防爆认证"},
        {"value": "(停)LPCB认证", "name": "(停)LPCB认证"},
        {"value": "(停)APPLUS认证", "name": "(停)APPLUS认证"},
        {"value": "(停)CoC中东认证", "name": "(停)CoC中东认证"},
        {"value": "(停)电信设备进网许可证", "name": "(停)电信设备进网许可证"},
        {"value": "(停)无线电发射设备型号核准证", "name": "(停)无线电发射设备型号核准证"},
        {"value": "(停)计量器具型式批准", "name": "(停)计量器具型式批准"},
        {"value": "(停)CCS", "name": "(停)CCS"},
        {"value": "(停)SIL认证", "name": "(停)SIL认证"},
        {"value": "(停)UL认证", "name": "(停)UL认证"},
        {"value": "(停)CE认证(欧洲)", "name": "(停)CE认证(欧洲)"},
        {"value": "(停)CE认证(国内)", "name": "(停)CE认证(国内)"},
        {"value": "(停)船检认证", "name": "(停)船检认证"},
        {"value": "(停)非认证", "name": "(停)非认证"},
        {"value": "(停)UKCA", "name": "(停)UKCA"}
    ]
});
var authenticationTypeComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'authenticationTypeComboBox',
    id: 'authenticationTypeComboBox',
    multiSelect: false,
    store: authenticationTypeStates,
    queryMode: 'local',
    displayField: 'name',
    valueField: 'value'
});

//产品型号
/**
 * 1. 下拉选择，下拉选项为“相关型号清单”表中的产品型号字段
 2. 支持多选
 *
 */
//相关类型提过来的同时作为字典使用
var ctModelListStore = new Ext.data.ArrayStore({
    id: 'ctModelListStore',
    fields: [],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/ext/plm/doc/certificate/modelList/getModelListData',
        extraParams: {
            // 这里可以添加任何需要作为请求参数的数据
            masterId:masterId,
            ids:''
        },
        timeout: 60000,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: true
});

//关联报告编号
/**
 * 1. 下拉选择，下拉选项为报告清单中的鉴研报告编号
 *
 */
var relationReportStore = new Ext.data.ArrayStore({
    id: 'relationReportStore',
    fields: [],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/ext/plm/doc/certificate/reportChecklist/getReportChecklistData',
        extraParams: {
            // 这里可以添加任何需要作为请求参数的数据
            masterId:masterId,
            ids:'',
            effective:'noEffective'
        },
        timeout: 60000,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: true
});

var productModelComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'productModelComboBox',
    id: 'productModelComboBox',
    multiSelect: true,
    editable: false,
    store: ctModelListStore,
    queryMode: 'local',
    displayField: 'productModel',
    loadMask:true,
    valueField: 'productModel'
});

var relationReportComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'relationReportComboBox',
    id: 'relationReportComboBox',
    multiSelect: true,
    editable: false,
    store: relationReportStore,
    queryMode: 'local',
    displayField: 'reportNumber',
    valueField: 'reportNumber'
});

//存档类型
/**
 1. 下拉选择：纸制文件、电子档；
 2. 默认为空；
 3. 只有证书状态为“待注销 / 生效中”的才可以编辑；
 */
var archiveTypeStates = Ext.create('Ext.data.Store', {
    fields: ['value', 'name'],
    data: [
        {"value": "纸制文件", "name": "纸制文件"},
        {"value": "电子档", "name": "电子档"}
    ]
});

var archiveTypeComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'archiveTypeComboBox',
    id: 'archiveTypeComboBox',
    multiSelect: false,
    store: archiveTypeStates,
    queryMode: 'local',
    displayField: 'name',
    valueField: 'value'
});

//状态选择
/**
 * 1. 下拉选择：是，否；
 2. 默认为空；
 3. 只有证书状态为“待注销 / 生效中”的才可以编辑；
 4. 字段背景：
 - 可能发生的情况，新证已经拿到，但旧的证书迟迟没有注销
 - 建议每周把待注销的履历清单通过邮件发送给认证工程师；                                                                                                                           证书有可能存在维护错误，需要再次修订版本来更新数据的情况，按照现有的规则，修订后只能增加数据，针对这种场景，现场沟通了下，希望做以下调整：
 是否注销字段名称--改为状态选择，选项值为以下三个：
 1、有效（否）
 2、注销（是）
 3、勘误删除（证书状态根据状态选择字段对应，全部下载、报表功能过滤掉勘误删除）
 *
 */
var statusSelectStates = Ext.create('Ext.data.Store', {
    fields: ['value', 'name'],
    data: [
        {"value": "有效", "name": "有效"},
        {"value": "注销", "name": "注销"},
        {"value": "证书到期", "name": "证书到期"},
        {"value": "勘误", "name": "勘误"}
    ]
});
var statusSelectComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'statusSelectComboBox',
    id: 'statusSelectComboBox',
    multiSelect: false,
    store: statusSelectStates,
    queryMode: 'local',
    displayField: 'name',
    valueField: 'value'
});
var statusSelectStates1 = Ext.create('Ext.data.Store', {
    fields: ['value', 'name'],
    data: [
        {"value": "有效", "name": "有效"},
        {"value": "注销", "name": "注销"},
        {"value": "证书到期", "name": "证书到期"}
    ]
});
var statusSelectComboBox1 = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'statusSelectComboBox1',
    id: 'statusSelectComboBox1',
    multiSelect: false,
    store: statusSelectStates1,
    queryMode: 'local',
    displayField: 'name',
    valueField: 'value'
});
//身份信息类型
var identityInformationTypeStates = Ext.create('Ext.data.Store', {
    fields: ['value', 'name'],
    data: [
        {"value": "Ⅰ型", "name": "Ⅰ型"},
        {"value": "Ⅱ型", "name": "Ⅱ型"},
        {"value": "暂不使用", "name": "暂不使用"},
        {"value": "不适用", "name": "不适用"}
    ]
});
var identityInformationTypeComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'identityInformationTypeComboBox',
    id: 'identityInformationTypeComboBox',
    multiSelect: false,
    store: identityInformationTypeStates,
    queryMode: 'local',
    displayField: 'name',
    valueField: 'value'
});
//认证标识
/**
 * 1. 下拉选择（多选），下拉选项：
 - CMIIT ID（无线电）
 - 型号编号（进网）
 - 防爆等级
 - CPA标志编号
 */

var certificationMarkStates = Ext.create('Ext.data.Store', {
    fields: ['value', 'name'],
    data: [
        {"value": "无", "name": "无"},
        {"value": "防腐等级", "name": "防腐等级"},
        {"value": "CMIIT ID（无线电）", "name": "CMIIT ID（无线电）"},
        {"value": "型号编号（进网）", "name": "型号编号（进网）"},
        {"value": "防爆等级", "name": "防爆等级"},
        {"value": "CPA标志编号", "name": "CPA标志编号"}
    ]
});

var manufacturingEnterpriseStore = [
    ['深圳市高新投三江电子股份有限公司光明分厂', '深圳市高新投三江电子股份有限公司光明分厂'],
    ['广东艺光消防科技有限公司', '广东艺光消防科技有限公司'],
    ['深圳市查知科技有限公司', '深圳市查知科技有限公司'],
    ['上海普临智能科技有限公司大连分公司', '上海普临智能科技有限公司大连分公司'],
    ['上海曜成电子科技有限公司', '上海曜成电子科技有限公司'],
    ['上海鸿真电子有限公司', '上海鸿真电子有限公司'],
    ['青岛中阳消防科技股份有限公司', '青岛中阳消防科技股份有限公司'],
    ['其他', '其他']
]

var certificationMarkComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'certificationMarkComboBox',
    id: 'certificationMarkComboBox',
    multiSelect: true,
    editable: false,
    store: certificationMarkStates,
    queryMode: 'local',
    displayField: 'name',
    valueField: 'value'
});

//检验报告类型
var inspectionReportTypeStates = Ext.create('Ext.data.Store', {
    fields: ['value', 'name'],
    data: [
        {"value": "防腐委托", "name": "防腐委托"},
        {"value": "船检委托", "name": "船检委托"},
        {"value": "型式试验", "name": "型式试验"},
        {"value": "分型试验", "name": "分型试验"},
        {"value": "变更确认检验", "name": "变更确认检验"},
        {"value": "型式检验", "name": "型式检验"},
        {"value": "委托检验", "name": "委托检验"},
        {"value": "发证检验", "name": "发证检验"},
        {"value": "系统兼容性试验", "name": "系统兼容性试验"},
        {"value": "防爆委托", "name": "防爆委托"},
        {"value": "LPCB", "name": "LPCB"},
        {"value": "CE", "name": "CE"},
        {"value": "APPLUS", "name": "APPLUS"},
        {"value": "进网检验", "name": "进网检验"},
        {"value": "无线电核准", "name": "无线电核准"},
        {"value": "其它", "name": "其它"},
        {"value": "监督检验", "name": "监督检验"},
        {"value": "船检委托", "name": "船检委托"},
        {"value": "认证发证检验", "name": "认证发证检验"},
        {"value": "计量器具型式评价", "name": "计量器具型式评价"},
        {"value": "UKCA", "name": "UKCA"},
        {"value": "质量检验", "name": "质量检验"},
        {"value": "型式认可发证检验", "name": "型式认可发证检验"}
    ]
});
var inspectionReportTypeComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'inspectionReportTypeComboBox',
    id: 'inspectionReportTypeComboBox',
    multiSelect: false,
    store: inspectionReportTypeStates,
    queryMode: 'local',
    displayField: 'name',
    valueField: 'value'
});
//关联证书编号
var certificateNumberStates = new Ext.data.ArrayStore({
    id: 'ctCertificateListStore',
    fields: [],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/ext/plm/doc/certificate/certificateList/getCertificateListData',
        extraParams: {
            // 这里可以添加任何需要作为请求参数的数据
            masterId: masterId,
            ids: ''
        },
        timeout: 60000,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: true,
    autoDestroy: true
});
var certificateNumberComboBox = Ext.create('Ext.form.ComboBox', {
    xtype: 'combo',
    name: 'certificateNumberComboBox',
    id: 'certificateNumberComboBox',
    multiSelect: true,
    editable: false,
    store: certificateNumberStates,
    queryMode: 'local',
    displayField: 'certificateNumber',
    valueField: 'id'
});