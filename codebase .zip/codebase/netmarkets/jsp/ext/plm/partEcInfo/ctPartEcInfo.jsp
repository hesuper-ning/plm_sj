
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
%>
<script>
    var browserHeight = window.innerHeight;
    jQuery(function(){
        jQuery("#ctPartEcInfoctPartEcInfo").html('<iframe id="ctHumanResourceIframe" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"\n' +
            '        src="netmarkets/jsp/ext/plm/partEcInfo/ctPartEcInfoPlugin.jsp?oid=<%=oid%>" style="width:98%;height:'+(browserHeight-180)+'px" ></iframe>')
    })
</script>



