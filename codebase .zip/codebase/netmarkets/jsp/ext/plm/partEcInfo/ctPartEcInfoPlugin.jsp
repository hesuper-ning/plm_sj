
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.workflow.engine.WfActivity" %>
<%@ page import="wt.workflow.engine.WfProcess" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page language="java" contentType="text/html; charset=utf-8"
         pageEncoding="utf-8"%>

<%
    String oid = request.getParameter("oid");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <script type="text/javascript">


    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <style type="text/css">
        /*表头换号居中*/
        .x-column-header {  text-align: center; }
        .x-column-header-text-inner {
            white-space: normal;
            line-height: 15px;
            padding-top: 3px !important;
            padding-bottom: 3px !important;
        }
    </style>
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <!-- jQuery -->
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <!-- content -->
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctPartEcInfo_fn.js?_dc=<%="timestamp"%>"></script>
    <script type="text/javascript" src="js/ctPartEcInfo.js?_dc=<%="timestamp"%>"></script>
    <script type="text/javascript" src="js/ctChildrenEcInfo.js?_dc=<%="timestamp"%>"></script>

    <script>
        var oid = "<%=oid%>";
        var items = [];
        items.push({
            title: '<font style="font-size:12px">当前对象变更清单</font>',
            xtype:'CtPartEcInfoPanel'
        });
        if(oid.indexOf("WTDocument")===-1){
            items.push({
                title: '<font style="font-size:12px">子项变更清单</font>',
                xtype:'CtChildrenEcInfoPanel'
            });
        }
        Ext.onReady(function() {
            Ext.QuickTips.init();

            Ext.create('Ext.container.Viewport', {
                layout: 'border',
                items: [ {
                    region: 'center',
                    items:[{
                        xtype:'panel',
                        border:false,
                        items:[{
                            xtype:'tabpanel',
                            activeTab: 0,
                            items:items
                        }]
                    }]
                }]
            });

        });

    </script>
</head>
<body>


</body>

</html>


