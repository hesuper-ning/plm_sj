//Model for the inside grid store
Ext.define('dataAuditReportModel', {
    extend: 'Ext.data.Model',
    fields: [
        'ecrOid', 'ecrNumber', 'ecReason', 'ecType', 'ecrState',
        'ecrOwner','ecrCreateTime','ecrCompletionTime','ecnOid','ecnNumber',
        'ecrProcessedBy','ecaOid','ecaNumber','beforeObjectNumber','beforeObjectName',
        'beforeObjectVersion','ecaState','ecaOwner','ecaProcessedBy','ecaCreateTime',
        'ecaCompletionTime'
    ]
});

/**展开内嵌**/
function displayInnerGrid(renderId, record) {

    if(renderId.indexOf("null")>0){
        return;
    }
    var dataAuditReportStore = Ext.create('Ext.data.Store', {
        //pageSize: 100,
        model: 'dataAuditReportModel',
        id:'dataAuditReportStore',
        pruneModifiedRecords: true,
        proxy: new Ext.data.HttpProxy({
            url: '/Windchill/ptc1/partEcInfo/getRefEcaInfo?oid=' + record.get('ecnOid')+'&partOid=' + record.get('partOid'),
            method:'GET',
            reader:{
                type: 'json',
                root: 'data'
            }
        }),
        autoLoad:true
    });


    Ext.create('Ext.grid.Panel', {
        //title: '数据变更流程统计表',
        store:dataAuditReportStore,
        renderTo: renderId,
        forceFit : true,
        autoWidth : true,
        columnLines: true,
        //height:350,
        selModel: {
            selType: 'cellmodel'
        },
        frame: false,
        iconCls: 'icon-grid',
        //bodyStyle : 'overflow-x:hidden; overflow-y:scroll',
        viewConfig:{enableTextSelection:true},
        //selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SIMPLE",showHeaderCheckbox:true}),
        columns: [
            { text: 'ECA编号',  dataIndex: 'ecaNumber', width:100, resizable: false, menuDisabled:true
                ,renderer:function(value,metaData,record,row,col,store){
                    return infoLink(record.get('ecaOid'),value);
                }},
            { text: '受影响对象',  dataIndex: 'beforeObjectNumber', width:100, resizable: false, menuDisabled:true },
            { text: '受影响对象名称',  dataIndex: 'beforeObjectName' ,menuDisabled:true},
            { text: '受影响对象版本',  dataIndex: 'beforeObjectVersion', width:120, resizable: false,menuDisabled:true},
            { text: 'ECA状态',  dataIndex: 'ecaState', width:80, resizable: false,menuDisabled:true},
            { text: 'ECA发起人',  dataIndex: 'ecaOwner', width:80, resizable: false,menuDisabled:true},
            { text: 'ECA当前处理人',  dataIndex: 'ecaProcessedBy' , width:100, resizable: false,menuDisabled:true},
            { text: 'ECA发起时间',  dataIndex: 'ecaCreateTime', width:100, resizable: false,menuDisabled:true},
            { text: 'ECA完成时间',  dataIndex: 'ecaCompletionTime', width:100, resizable: false, menuDisabled:true },

        ]
    });
}

/**折叠内嵌**/
function destroyInnerGrid(elId) {
    if(elId.indexOf("null")>0){
        return;
    }
    var parent = document.getElementById(elId);
    var child = parent.firstChild;

    while (child) {
        child.parentNode.removeChild(child);
        child = child.nextSibling;
    }

}


/**导出所有数据**/
function exportAllData(isNowPart) {
    Ext.Ajax.request({
        url: '/Windchill/ptc1/partEcInfo/export?oid='+oid+'&isNowPart='+isNowPart,
        params:{

        },
        success: function(response, opts) {
            let url = JSON.parse(response.responseText).url;
            window.location.href = window.location.origin + "/Windchill" + url;
        },
        failure: function(response, opts) {

            alert('错误：导出失败，请检查网络！');
        }
    });//~End of request

}

/**格式化日期格式*/
function sdfDate(value) {
    var timeStr = value;
    if(value != null && value != undefined && value != ''){
        var date = new Date(value);
        timeStr = Ext.Date.format(date,"Y-m-d")
    }
    return timeStr;
}


/**
 * 按查询参数查询
 */
function initData(storeStr,isNowPart){

    var data = {
        oid:oid,
        isNowPart:isNowPart,
    };
    Ext.getStore(storeStr).reload({
        params:{
            data:Ext.encode(data)
        },
        callback: function(records, operation, success) {
            console.log(records);
            if(!success){
                alert('查询数据审核流程信息失败，请联系管理员！');
            }
        }
    });
}

/** 跳转到详情页 */
function infoLink(oid,name){

    let url = window.location.href;
    let hostname = url.substr(0,url.indexOf('Windchill')-1);
    let oidStr = oid.replaceAll(':','%3A');
    let alink = `<a style="white-space: normal;word-wrap: break-word;" href="${hostname}/Windchill/app/#ptc1/tcomp/infoPage?oid=${oidStr}" target="_blank">${name}</a>`;
    return alink;
}