Ext.define('Pnt.view.CtPartEcInfoPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.CtPartEcInfoPanel',
    border:false,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    scrollable: true,
    id: 'CtPartEcInfoPanel',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent:function(){

        //
        Ext.define('dataAuditAnalysisModel', {
            extend: 'Ext.data.Model',
            fields: [
                'ecrOid', 'ecrNumber', 'ecReason', 'ecType', 'ecrState',
                'ecrOwner','ecrCreateTime','ecrCompletionTime','ecnOid','ecnNumber',
                'ecrProcessedBy','ecaOid','ecaNumber','beforeObjectNumber','beforeObjectName',
                'beforeObjectVersion','ecaState','ecaOwner','ecaProcessedBy','ecaCreateTime',
                'ecaCompletionTime','partOid','beforeObjectOid'
            ],
        });

        // create the Data Store
        var dataAuditAnalysisStore = Ext.create('Ext.data.Store', {
            pageSize: 2000,
            model: 'dataAuditAnalysisModel',
            id:'dataAuditAnalysisStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/partEcInfo/getRefEcInfo',
                timeout: 9000000,
                method:'GET',
                reader: {
                    type: 'json',
                    root: 'data'
                }
            }),
            autoLoad:false
        });

        dataAuditAnalysisStore.on('beforeload', function(store, options) {
            var data = {
                oid:oid,
                isNowPart:true,
            };
            Ext.apply(dataAuditAnalysisStore.proxy.extraParams, data);
        });

        var dataAuditAnalysisGrid = Ext.create('Ext.grid.Panel', {
            id:'dataAuditAnalysisGrid',
            store:dataAuditAnalysisStore,
            forceFit : true,
            width : 1800,
            height:window.innerHeight-30,
            scrollable: true,
            /* selModel: {
                 selType: 'cellmodel'
             }, */
            //selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SIMPLE",showHeaderCheckbox:true}),
            //展开折叠
            /*plugins: [{
                ptype: 'rowexpander',
                rowBodyTpl: [
                    '<div id="a{ecnNumber}">',
                    '</div>'
                ]
            }],*/
            //collapsible: true,
            animCollapse: false,
            //renderTo: Ext.getBody() ,
            columns: [
                { text: 'ID',  dataIndex: 'id', menuDisabled:true,hidden:true},
                { text: 'ecrOid',  dataIndex: 'ecrOid', menuDisabled:true,hidden:true},
                { text: 'ECR编号',  dataIndex: 'ecrNumber',width:80, resizable: false, menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return infoLink(record.get('ecrOid'),value);
                    }},
                { text: '变更原因',  dataIndex: 'ecReason',width:200, menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: '更改类型',  dataIndex: 'ecType', menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECR状态',  dataIndex: 'ecrState',width:60, resizable: false,  menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECR发起人',  dataIndex: 'ecrOwner',width:80,  resizable: false,  menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECR当前处理人',  dataIndex: 'ecrProcessedBy' ,width:80, resizable: false,menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECR提交时间',  dataIndex: 'ecrCreateTime',width:80, resizable: false, menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return value;
                    }},
                { text: 'ECR完成时间',  dataIndex: 'ecrCompletionTime', width:80, resizable: false, menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECN编号',  dataIndex: 'ecnNumber',width:50, resizable: false,menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return infoLink(record.get('ecnOid'),value);
                    }},
                { text: 'ECA编号',  dataIndex: 'ecaNumber', width:50, resizable: false, menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return infoLink(record.get('ecaOid'),value);
                    }},
                { text: '受影响对象',  dataIndex: 'beforeObjectNumber', width:100, resizable: false, menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return infoLink(record.get('beforeObjectOid'),value);
                    }},
                { text: '受影响对象名称',  dataIndex: 'beforeObjectName' ,menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: '受影响对象版本',  dataIndex: 'beforeObjectVersion', width:100, resizable: false,menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;overflow-wrap: break-word;">' + value + '</div>' ;
                    }},
                { text: 'ECA状态',  dataIndex: 'ecaState', width:60, resizable: false,menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECA发起人',  dataIndex: 'ecaOwner', width:70, resizable: false,menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECA当前处理人',  dataIndex: 'ecaProcessedBy' , width:80, resizable: false,menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECA发起时间',  dataIndex: 'ecaCreateTime', width:80, resizable: false,menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},
                { text: 'ECA完成时间',  dataIndex: 'ecaCompletionTime', width:80, resizable: false, menuDisabled:true
                    ,renderer:function(value,metaData,record,row,col,store){
                        return '<div style="white-space: normal;">' + value + '</div>' ;
                    }},

            ],
            tbar: [ {
                text : '导出清单',
                iconCls: 'icon icon-download',
                handler : function() {
                    exportAllData(true);
                },
                scope : this
            }]
        });

        dataAuditAnalysisGrid.view.on('expandBody', function (rowNode, record, expandRow, eOpts) {
            displayInnerGrid("a"+record.get('ecnNumber'), record);
        });

        dataAuditAnalysisGrid.view.on('collapsebody', function (rowNode, record, expandRow, eOpts) {
            destroyInnerGrid('a'+record.get('ecnNumber'));
        });

        //dataAuditAnalysisGrid.render(Ext.getBody());



/////////////////////////Panel items//////////////////////////////////
        this.items=[
            dataAuditAnalysisGrid
        ];
        this.callParent();
    },

    listeners:{
        'afterrender':function(){
            initData("dataAuditAnalysisStore",true);
        }
    },



});

