<%@ page language="java" import="ext.plm.tool.workItemForm.CtWorkItemFormTool" pageEncoding="UTF-8"%>
<%@page import="org.apache.commons.lang3.StringUtils,wt.type.Typed"%>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%
	String oid = request.getParameter("oid");//此oid有可能为workItem oid，也可能为WTDocument oid
	Persistable obj = CtWTObjectUtil.getObjectByOid(oid);
%>

<%if(obj instanceof WorkItem) {
	String url = CtWorkItemFormTool.getUrlByType_workItem((WorkItem)obj);
	String height = "850";
	if(StringUtils.isNotEmpty(url) && url.contains("|")) {
		height = url.split("\\|")[1];
		url = url.split("\\|")[0];
	}
	if(ext.plm.util.CtFormatUtil.hasContent(url)){%>
<iframe id="<%=oid%>" src="netmarkets/jsp/ext/plm<%=url%>?oid=<%=oid%>" style="width:98%;height:<%=height%>px" ></iframe>
<%}}else {
	String url = CtWorkItemFormTool.getUrlByType_pboTab((Typed) obj);
	String height = "850";
	if(StringUtils.isNotEmpty(url) && url.contains("|")) {
		height = url.split("\\|")[1];
		url = url.split("\\|")[0];
	}
	if(ext.plm.util.CtFormatUtil.hasContent(url)) {%>
<iframe id="<%=oid%>" src="netmarkets/jsp/ext/plm<%=url%>?oid=<%=oid%>" style="width:98%;height:<%=height%>px" ></iframe>
<%}} %>



