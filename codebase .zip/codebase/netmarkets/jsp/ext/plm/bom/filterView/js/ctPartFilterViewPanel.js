Ext.define('PLM.view.CtPartFilterViewPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtPartFilterViewPanel',
    title: '<font style="font-size:15px">筛选视图</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtPartFilterViewPanel',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //类型Store
        var partTypeStore = Ext.create('Ext.data.Store', {
            storeId: 'partTypeStore',
            fields: ['value', 'displayValue'],
            data: [
                {value: 'com.fhsj.ct_CBB', displayValue: 'CBB物料'},
                {value: 'com.fhsj.ct_fhsjiallyPreparedProducts', displayValue: '半成品'},
                {value: 'com.fhsj.ct_fhsjfinishedproduct', displayValue: '成品'},
                {value: 'com.fhsj.ct_fhsjRawMaterialElectronics', displayValue: '原材料（电子）'},
                {value: 'com.fhsj.ct_fhsjmarkAccessories', displayValue: '原材料（辅料）'},
                {value: 'com.fhsj.ct_fhsjRawmaterialstructure', displayValue: '原材料（结构）'},
                {value: 'com.fhsj.ct_fhsjGuestFor', displayValue: '原材料（客供物料）'},
                {value: 'com.fhsj.ct_fhsjsoftware', displayValue: '原材料（虚拟）'},
                {value: 'com.fhsj.ct_virtualPart', displayValue: '原材料（虚拟-其他物料）'},
                {value: 'com.fhsj.ct_fhsjSpecialMaterials', displayValue: '原材料（专用物料）'}
            ]
        });

        //状态Store
        var partStateStore = Ext.create('Ext.data.Store', {
            storeId: 'partStateStore',
            fields: ['value', 'displayValue'],
            data: [
                {value: '创建中', displayValue: '创建中'},
                {value: '审批中', displayValue: '审批中'},
                {value: '研发修改', displayValue: '研发修改'},
                {value: '认证中', displayValue: '认证中'},
                {value: '样机', displayValue: '样机'},
                {value: '已生效', displayValue: '已生效'},
                {value: '试产', displayValue: '试产'},
                {value: '量产', displayValue: '量产'},
                {value: '变更中', displayValue: '变更中'},
                {value: '停用中', displayValue: '停用中'},
                {value: '停用', displayValue: '停用'},
                {value: '返工', displayValue: '返工'}
            ]
        });

        //树的列模型
        Ext.define('bomSearchModel', {
            extend: 'Ext.data.Model',
            fields: ['partBranchId','partNumber','parentPartNumber','partPath','targetObject','partName','internalVersion','version','partState','defaultUnit',
                'quantity','referenceDesignatorRange','remarks','isRoHS','creator','editor','partUrl'],
            idProperty: 'partPath'
        });

        var bomSearchStore = Ext.create('Ext.data.TreeStore', {
            id: 'bomSearchStore',
            model: 'bomSearchModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/bom/searchBom',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json'
                }
            }),
            root: {
                expanded: true
            },
            listeners: {
                beforeload: function (store, opts) {
                    let data = {
                        oid: '',
                        type: '',
                        state: '',
                        commonParam: ''
                    };
                    Ext.apply(store.proxy.extraParams, data);
                }
            },
            autoLoad: false,
            folderSort: true
        });

        var bomSearchGrid = Ext.create('Ext.tree.Panel', {
            store: bomSearchStore,
            // 隐藏默认的根节点
            //renderTo: Ext.getBody(),
            rootVisible: false,
            height: 800,
            autoWidth: true,
            expanded: true,
            border: 0,
            id: 'bomSearchGrid',
            autoScroll: true,
            //plugins: [cellEditing],
            viewConfig: {enableTextSelection: true},
            // width:1180,
            // selModel: Ext.create('Ext.selection.CheckboxModel', {
            //             //     mode: "SIMPLE",
            //             //     showHeaderCheckbox: true,
            //             //     checkOnly: true,
            //             //     listeners: {
            //             //         beforeselect: function (obj, record, index) {
            //             //             if (record.get('purchaseType') !== 'F') {
            //             //                 return false;
            //             //             }
            //             //         }
            //             //     }
            //             // }),
            // bodyStyle : 'overflow-x:scroll;
            // overflow-y:scroll',
            //title: '库存列表',
            columns: [
                /*     {text: '序号', width: 50, align: 'center', menuDisabled: true, xtype: 'rownumberer', sortable: false},*/
                {
                    text: '路径',
                    width: 50,
                    align: 'center',
                    menuDisabled: true,
                    dataIndex: 'partPath',
                    sortable: false,
                    hidden: true
                },
                {
                    text: 'branchId',
                    width: 1,
                    dataIndex: 'partBranchId',
                    sortable: false,
                    menuDisabled: true,
                    hidden: true
                },
                {text: '目标对象', width: 80, dataIndex: 'targetObject', menuDisabled: true, sortable: false},
                {
                    text: '编号',
                    width: 180,
                    dataIndex: 'partUrl',
                    xtype: 'treecolumn',
                    menuDisabled: true,
                    sortable: false
                },
                {text: '名称', width: 300, dataIndex: 'partName', menuDisabled: true, sortable: false},
                {text: '内部版本', width: 100, dataIndex: 'internalVersion', menuDisabled: true, sortable: false},
                {text: '版本', width: 120, dataIndex: 'version', menuDisabled: true, sortable: false},
                {text: '状态', width: 80, dataIndex: 'partState', menuDisabled: true, sortable: false},
                {text: '默认单位', width: 80, dataIndex: 'defaultUnit', menuDisabled: true, sortable: false},
                {text: '数量', width: 80, dataIndex: 'quantity', menuDisabled: true, sortable: false},
                {text: '位号', width: 180, dataIndex: 'referenceDesignatorRange', menuDisabled: true, sortable: false},
                {text: 'BOM备注', width: 300, dataIndex: 'remarks', menuDisabled: true, sortable: false},
                {text: '是否RoHS', width: 80, dataIndex: 'isRoHS', menuDisabled: true, sortable: false},
                {text: '创建人', width: 80, dataIndex: 'creator', menuDisabled: true, sortable: false},
                {text: '修改人', width: 80, dataIndex: 'editor', menuDisabled: true, sortable: false}
                // {text: '物料描述', width: 250, dataIndex: 'partDes', menuDisabled: true, sortable: false},
                // {
                //     text: '需求数量',
                //     width: 80,
                //     dataIndex: 'requiredQty',
                //     menuDisabled: true,
                //     sortable: false,
                //     readOnly: true,
                //     editor: {
                //         xtype: 'textfield',
                //         selectOnFocus: true
                //     }
                // },
                // {
                //     text: '研发仓库存是否满足', width: 130, dataIndex: 'rdQtyFlag', menuDisabled: true, sortable: false,
                //     renderer: function (v, m, r) {
                //         if (r.get('requiredQty') == null || r.get('requiredQty') === '') {
                //             return '';
                //         } else {
                //             return r.get('rdQty') >= r.get('requiredQty') ? '是' : '否';
                //         }
                //     }
                // }
            ],
            //tbar: [
                // {
                //     text: '查询',
                //     iconCls: 'icon icon-search',
                //     handler: function () {
                //         var bomNum = Ext.getCmp('partListCombo2').getValue();
                //         var setNum = Ext.getCmp('setNum').getValue();
                //         var division = Ext.getCmp('division').getValue();
                //         if (bomNum == null || bomNum === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         if (setNum == null || setNum === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         if (division == null || division === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         //getBomInventoryInfo(bomNum, setNum, division);
                //     }
                // }
            //],
            listeners: {
                afterrender: function (t) {
                    // //选择器， 为所有表格添加
                    // var selector = ".x-column-header";
                    // //选择器， 可以为指定的表格添加头部样式内容需要添加id属性，例如id为 firstGrid 那选择器的值如下：
                    // //var selector = "#firstGrid-bodyWrap .x-column-header"
                    // var elments = Ext.select(selector, true);
                    // elments.each(function (el) {
                    //     el.setStyle("font-size", '5px');
                    //     el.setStyle("line-height", '5px');
                    // }, this);
                }
            }
        });

        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">搜索条件</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 0 20',
                            labelWidth: 50
                        },
                        items: [
                            {
                                xtype: 'combobox',
                                margin: '20 20 10 30',
                                fieldLabel: '类型',
                                id: 'partType',
                                name: 'partType',
                                labelWidth: 50,
                                store: partTypeStore,
                                editable: false,
                                multiSelect: true,
                                displayField: 'displayValue',
                                valueField: 'value'
                            },
                            {
                                xtype: 'combobox',
                                margin: '20 20 10 30',
                                fieldLabel: '状态',
                                id: 'partState',
                                name: 'partState',
                                labelWidth: 50,
                                store: partStateStore,
                                editable: false,
                                multiSelect: true,
                                displayField: 'displayValue',
                                valueField: 'value'
                            },
                            {
                                xtype: 'textfield',
                                margin: '20 20 10 30',
                                fieldLabel: '公共参数',
                                id: 'allAttribute',
                                name: 'allAttribute',
                                labelWidth: 60,
                                width: 300
                            },
                            {
                                xtype: 'button',
                                margin: '20 20 10 0',
                                width: 50,
                                text: '搜索',
                                scope: this,
                                handler: function () {
                                    getBomInfo();
                                }
                            },
                            {
                                xtype: 'button',
                                margin: '20 20 10 0',
                                width: 50,
                                text: '重置',
                                scope: this,
                                handler: function () {
                                    resetCondition();
                                }
                            },
                            {
                                xtype: 'button',
                                margin: '20 20 10 0',
                                width: 50,
                                text: '导出',
                                scope: this,
                                handler: function () {
                                    doExport();
                                }
                            }
                        ]
                    }
                ]
            },
            bomSearchGrid
        ];
        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});


