/**
 * 获取搜索结果
 */
function getBomInfo() {
    var bomSearchGrid = Ext.getCmp('bomSearchGrid');
    // var loadMarsk = new Ext.LoadMask({
    //     msg: '正在查询，请稍等......',
    //     target: bomSearchGrid,
    //     removeMask: true // 完成后移除
    // });
    // loadMarsk.show();
    var store = bomSearchGrid.getStore();
    var partType = Ext.getCmp('partType').getValue();
    var partState = Ext.getCmp('partState').getValue();
    var allAttribute = Ext.getCmp('allAttribute').getValue();
    store.load({
        params: {
            oid: oid,
            type: partType,
            state: partState,
            commonParam: allAttribute
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('搜索失败,请联系管理员!');
            }
            ///loadMarsk.hide();
        }
    });
}

/**
 * 导出
 */
function doExport() {
    var bomSearchGrid = Ext.getCmp('bomSearchGrid');
    var store = bomSearchGrid.getStore();
    let data = store.root.childNodes;
    if(!data || data.length == 0){
        Ext.Msg.alert("提示", "请先搜索查询出数据再导出！");
        return;
    }

    // 获取XMLHttpRequest
    var xmlHttpRequest = new XMLHttpRequest();
    //  发起请求
    xmlHttpRequest.open("POST", '/Windchill/ptc1/bom/exportFilterBom', true);
    // 设置请求头类型
    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
    xmlHttpRequest.responseType = "blob";
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg: '导出中，请稍等......',
        target: bomSearchGrid,
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    //  返回
    xmlHttpRequest.onload = function (oEvent) {
        var content = xmlHttpRequest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).message)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            var fileNamePrefix = '筛选视图';
            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }
        loadMarsk.hide();
    };
    xmlHttpRequest.send(JSON.stringify(data[0].data));
}

/**
 * 重置搜索条件
 */
function resetCondition(){
    var partType = Ext.getCmp('partType');
    partType.reset();
    var partState = Ext.getCmp('partState');
    partState.reset();
    var allAttribute = Ext.getCmp('allAttribute');
    allAttribute.reset();
    let treeGridStore = Ext.getCmp("bomSearchGrid").getStore();
    treeGridStore.removeAll();
    treeGridStore.reload();
}

