<%@ page import="wt.fc.Persistable" %>
<%@ page language="java" pageEncoding="UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<%
		String oid = request.getParameter("oid");
		wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
		Persistable object = rf.getReference(oid).getObject();
	%>

	<SCRIPT type="text/javascript">
		var oid ='<%= oid %>';
	</SCRIPT>

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
	<link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
	<script type="text/javascript" src="../../common/jquery-2.0.0.min.js"></script>
	<script type="text/javascript" src="js/ctPartFilterViewFn.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<script type="text/javascript" src="js/ctPartFilterViewPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
// ==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		 layout: 'border',
		 items: [{
			 region: 'center',
			 xtype: 'CtPartFilterViewPanel'
		 }]
	 });
});
</script>
</body>
</html>