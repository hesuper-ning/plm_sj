Ext.define('PLM.view.CtUseRelationshipReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtUseRelationshipReport',
    title: '',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtUseRelationshipReport',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        Ext.define('ctUseRelationshipModel', {
            extend: 'Ext.data.Model',
            fields: ['id','partNumber','partView','partVersion','internalVersion','partState',
                'transitionTime','partName', 'partUrl'],
            idProperty: 'id'
        });

        // var ctUseRelationshipStore = Ext.create('Ext.data.Store', {
        //     model: 'ctUseRelationshipModel',
        //     id: 'ctUseRelationshipStore',
        //     pruneModifiedRecords: true,
        //     autoSync: true,//同步更新
        //     proxy: new Ext.data.HttpProxy({
        //         url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/searchUseRelationship',
        //         method: 'GET',
        //         reader: {
        //             type: 'json',
        //             rootProperty: 'data',
        //             idProperty: 'id',
        //             totalProperty:'totalCount',
        //             messageProperty: 'message'
        //         }
        //     }),
        //     autoLoad: false
        // });

        var ctUseRelationshipStore = Ext.create('Ext.data.TreeStore', {
            id: 'ctUseRelationshipStore',
            model: 'ctUseRelationshipModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/searchUseRelationship',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json'
                }
            }),
            root: {
                expanded: true
            },
            sorters: [{
                property: 'partNumber', // 排序的字段名
                direction: 'ASC' // 排序方向，ASC为升序，DESC为降序
            }],
            autoLoad: false
        });

        var ctUseRelationshipGrid = Ext.create('Ext.tree.Panel', {
            store: Ext.getStore('ctUseRelationshipStore'),
            // 隐藏默认的根节点
            //renderTo: Ext.getBody(),
            rootVisible: false,
            height: 440,
            autoWidth: true,
            expanded: true,
            border: 0,
            id: 'ctUseRelationshipGrid',
            autoScroll: true,
            //plugins: [cellEditing],
            viewConfig: {enableTextSelection: true},
            columns: [
                {
                    text: 'id',
                    width: 50,
                    align: 'center',
                    menuDisabled: true,
                    dataIndex: 'id',
                    sortable: false,
                    hidden: true
                },
                {
                    text: '物料编号',
                    xtype: 'treecolumn',
                    dataIndex: 'partNumber',
                    width: 200,
                    menuDisabled: true,
                    sortable: false,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('partUrl')) {
                            var changeLink = record.get('partUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '视图', dataIndex: 'partView', width: 100, menuDisabled: true, sortable: false},
                {text: '版本', dataIndex: 'partVersion', width: 100, menuDisabled: true, sortable: false},
                {text: '内部版本', dataIndex: 'internalVersion', width: 100, menuDisabled: true, sortable: false},
                {text: '状态', dataIndex: 'partState', width: 120, menuDisabled: true, sortable: false},
                {text: '版本转变时间', dataIndex: 'transitionTime', width: 120, menuDisabled: true, sortable: false},
                {
                    text: '物料描述',
                    dataIndex: 'partName',
                    width: 200,
                    menuDisabled: true,
                    sortable: false,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        }
                        return value;
                    }
                }
            ],
            tbar: [{
                text: '导出查询结果',
                id: 'exportUseRelationshipGrid',
                iconCls: 'icon icon-store-export',
                scope: this,
                handler: function () {
                    var ctUseRelationshipGrid = Ext.getCmp('ctUseRelationshipGrid');
                    var store = ctUseRelationshipGrid.getStore();
                    let data = store.root.childNodes;
                    if(!data || data.length == 0){
                        Ext.Msg.alert("提示", "请先搜索查询出数据再导出！");
                        return;
                    }

                    // 获取XMLHttpRequest
                    var xmlHttpRequest = new XMLHttpRequest();
                    //  发起请求
                    xmlHttpRequest.open("POST", '/Windchill/ptc1/ext/plm/bom/baselineQuery/exportUseData', true);
                    // 设置请求头类型
                    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
                    xmlHttpRequest.responseType = "blob";
                    //增加遮罩
                    var loadMarsk = new Ext.LoadMask({
                        msg: '导出中，请稍等......',
                        target: ctUseRelationshipGrid,
                        removeMask: true // 完成后移除
                    });
                    loadMarsk.show();
                    //  返回
                    xmlHttpRequest.onload = function (oEvent) {
                        var content = xmlHttpRequest.response;
                        if (content.type == 'application/json') {
                            content.text().then(res => {
                                alert(Ext.decode(res).message)
                            })
                        } else {
                            var timestamp =new Date().getTime();
                            // 组装a标签
                            var elink = document.createElement("a");
                            // 设置下载文件名
                            var fileNamePrefix = '物料使用关系记录';
                            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
                            elink.style.display = "none";
                            var blob = new Blob([content]);
                            elink.href = URL.createObjectURL(blob);
                            document.body.appendChild(elink);
                            elink.click();
                            document.body.removeChild(elink);
                        }
                        loadMarsk.hide();
                    };
                    let newData = [];
                    for(let i = 0;i < data.length;i++){
                        newData[i] = data[i].data;
                    }
                    xmlHttpRequest.send(JSON.stringify(newData));
                }
            }, '->',]
        });

        var versionStore_baseline_use = new Ext.data.ArrayStore({
            id: 'versionStore_baseline_use',
            fields: [
                {partOid: "partOid"},
                {partVersion: "partVersion"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/getPartVersion',
                extraParams: {
                    partNumber: partNumber,
                    partView: partViewUse
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            listeners: {
                beforeload: function(store, operation) {
                    var params = operation.getParams();
                    params.partView = partViewUse; // 添加新的参数，如果需要的话
                },
                load: function(store, records, successful, operation, options) {
                    if (successful) {
                        let versionCom = Ext.getCmp('versionCom_baseline_use');
                        if(versionCom){
                            let value = versionCom.getValue();
                            if(value){
                                versionCom.setValue(value);
                            }
                        }
                    }
                }
            },
            autoLoad: false
        });

        var versionCom = new Ext.form.ComboBox({
            xtype: 'combo',
            fieldLabel: '版本',
            name: 'versionCom_baseline_use',
            id: 'versionCom_baseline_use',
            multiSelect: true,
            editable: false,
            width: 150,
            store: versionStore_baseline_use,
            valueField: 'partOid',
            displayField: 'partVersion',
            listeners: {
                expand: function() {
                    var partNumber = Ext.getCmp('partNumber_baseline_use').getValue();
                    var partView = Ext.getCmp('baselineView_baseline_use').getValue();
                    if(!partView){
                        alert("请选择视图！");
                        versionStore_baseline_use.setData([])
                        return;
                    }
                    if(partNumber&&partView){
                        versionStore_baseline_use.load({
                            params: {
                                partNumber: partNumber,
                                partView:partView
                            }
                        });
                    }
                }
            }
        });

        var internalVersionStore_baseline_use = new Ext.data.ArrayStore({
            id: 'internalVersionStore_baseline_use',
            fields: [
                {partOid: "partOid"},
                {internalVersion: "partVersion"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/getInternalVersion',
                extraParams: {
                    partNumber: partNumber,
                    partView: partViewUse
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            listeners: {
                beforeload: function(store, operation) {
                    var params = operation.getParams();
                    params.partView = partViewUse; // 添加新的参数，如果需要的话
                }
            },
            autoLoad: false
        });

        var internalVersionCom_baseline_use = new Ext.form.ComboBox({
            xtype: 'combo',
            fieldLabel: '内部版本',
            name: 'internalVersionCom_baseline_use',
            id: 'internalVersionCom_baseline_use',
            multiSelect: false,
            editable: false,
            width: 150,
            store: internalVersionStore_baseline_use,
            valueField: 'partOid',
            displayField: 'internalVersion',
            listeners: {
                expand: function() {
                    var partNumber = Ext.getCmp('partNumber_baseline_use').getValue();
                    var partView = Ext.getCmp('baselineView_baseline_use').getValue();
                    if(!partView){
                        alert("请选择视图！");
                        internalVersionStore_baseline_use.setData([])
                        return;
                    }
                    if(partNumber&&partView){
                        internalVersionStore_baseline_use.load({
                            params: {
                                partNumber: partNumber,
                                partView:partView
                            }
                        });
                    }
                }
            }
        });

        //======================  userResourceGrid End  ======================//

        ////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 5 10 5',
                title: '查询条件',
                collapsible: true,
                defaults: {
                    labelWidth: 70, border: false, anchor: '95%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 20 10 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'displayfield',
                                fieldLabel: '物料编号',
                                width: 120,
                                id: 'partNumber_baseline_use',
                                name: 'partNumber_baseline_use',
                                value: partNumber
                            },
                            {
                                xtype: 'combobox',
                                fieldLabel: '视图',
                                name: 'baselineView_baseline_use',
                                id: 'baselineView_baseline_use',
                                width: 180,
                                enableKeyEvents: true,
                                store: {data:[{baselineView:'Design'},{baselineView:'Manufacturing'}]}, // 下拉框的选项数据
                                queryMode: 'local', // 查询模式
                                editable: false, // 设置为不可编辑
                                valueField: 'baselineView',
                                displayField: 'baselineView',
                                listeners: {
                                    expand: function() {
                                    },
                                    select: function(combo, record) {
                                        partViewUse = record.data.baselineView;
                                        var version = Ext.getCmp('versionCom_baseline_use');
                                        version.reset();
                                    }
                                }
                            },
                            internalVersionCom_baseline_use,
                            versionCom,
                            {
                                xtype: 'datefield',
                                fieldLabel: '日期时间',
                                name: 'creationTime_baseline_use',
                                id: 'creationTime_baseline_use',
                                width: 180
                            },
                            {
                                xtype: 'button',
                                text: '搜索',
                                width: 70,
                                scope: this,
                                handler: function () {
                                    let partView = Ext.getCmp('baselineView_baseline_use').getValue();
                                    let creationTime = Ext.getCmp('creationTime_baseline_use').getValue();
                                    let internalVersion = Ext.getCmp('internalVersionCom_baseline_use').getValue();
                                    let version = Ext.getCmp('versionCom_baseline_use').getValue();
                                    if((creationTime && internalVersion) ||
                                        (creationTime && version && version.length > 0) ||
                                        (internalVersion && version && version.length > 0)){
                                        Ext.Msg.alert('提示', '日期时间、版本、内部版本同时只能填一个条件！');
                                        return;
                                    }
                                    if(!creationTime && !internalVersion && !version){
                                        Ext.Msg.alert('提示', '日期时间、版本、内部版本必须填一个条件！');
                                        return;
                                    }
                                    if(!partView){
                                        Ext.Msg.alert('提示', '视图不能为空！');
                                        return;
                                    }
                                    ctUseRelationshipGrid.getStore().load({
                                        params: {
                                            oid: oid,
                                            date: creationTime,
                                            view: partView,
                                            internalVersion: internalVersion,
                                            version: version?version.join(","):version
                                        }
                                    });
                                }
                            },
                            {
                                xtype: 'button',
                                width: 70,
                                margin: '10 20 10 0',
                                text: '重置',
                                scope: this,
                                handler: function () {
                                    var baselineView = Ext.getCmp('baselineView_baseline_use');
                                    baselineView.reset();
                                    var version = Ext.getCmp('versionCom_baseline_use');
                                    version.reset();
                                    var internalVersion = Ext.getCmp('internalVersionCom_baseline_use');
                                    internalVersion.reset();
                                    var creationTime = Ext.getCmp('creationTime_baseline_use');
                                    creationTime.reset();
                                    let treeGridStore = Ext.getCmp("ctUseRelationshipGrid").getStore();
                                    treeGridStore.removeAll();
                                    treeGridStore.reload();
                                }
                            },
                        ]
                    },
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 20 10 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                border: false,
                                html: '<div style="color:red;">说明：查询“原材料”时“版本”信息都按Design视图版本显示；选择Design视图时查询父项结果都为Design视图；选择Manufacturing视图时查询父项结果都为Manufacturing视图。</div>'
                            }
                        ]
                    }
                ]
            },
            ctUseRelationshipGrid
        ];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});


