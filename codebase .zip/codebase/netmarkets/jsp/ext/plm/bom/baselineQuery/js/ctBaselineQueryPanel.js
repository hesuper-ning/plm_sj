Ext.define('PLM.view.CtBaselineQueryPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtBaselineQueryPanel',
    border: false,
    autoScroll: false,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtBaselineQueryPanel',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        xtype:'tabpanel',
                        id: 'ctBaselineQueryTabPanel',
                        activeTab: 0,
                        items:[
                            {
                                title: '<font style="font-size:12px">物料使用关系记录</font>',
                                xtype: 'CtUseRelationshipReport'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">物料子项变动记录(按版本)</font>',
                                xtype: 'CtNewSubItemChangeReport'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">物料子项变动记录(按时间)</font>',
                                xtype: 'CtSubItemChangeReport',
                                hidden: !isAdmin
                            }
                        ]//~End of tabpanel items
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    }
});