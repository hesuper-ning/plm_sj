Ext.define('PLM.view.CtSubItemChangeReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtSubItemChangeReport',
    title: '',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtSubItemChangeReport',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        Ext.define('ctSubItemChangeModel', {
            extend: 'Ext.data.Model',
            fields: ['id','partNumber','partView','partVersion','internalVersion','partState',
                'transitionTime','partName','consumption','unit','tagNumber',
                'bomRemarks'],
            idProperty: 'id'
        });

        var gridCount = 0;

        var ctSubItemChangeStore = Ext.create('Ext.data.TreeStore', {
            id: 'ctSubItemChangeStore',
            model: 'ctSubItemChangeModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/searchChildChange',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json'
                }
            }),
            root: {
                expanded: true
            },
            sorters: [{
                property: 'partNumber', // 排序的字段名
                direction: 'ASC' // 排序方向，ASC为升序，DESC为降序
            }],
            autoLoad: false,
            listeners:{
                load: function (store, records, successful, operation, options) {
                    if (successful) {
                        // 获取返回的数据
                        let count = 0;
                        for(let i = 0;i < records.length;i++){
                            if(!records[i]){
                                return;
                            }
                            count ++;
                            count += getTotalChildNodes(records[i].data);
                        }
                        showGridCount.child('#gridCount').setText('共有条目: {' + count + '}');
                    }
                }
            }
        });

        var showGridCount = Ext.create('Ext.toolbar.Toolbar', {
            items: [{
                xtype: 'tbtext',
                itemId: 'gridCount',
                text: '共有条目: {0}'
            }]
        });

        var ctSubItemChangeGrid = Ext.create('Ext.tree.Panel', {
            store: Ext.getStore('ctSubItemChangeStore'),
            // 隐藏默认的根节点
            //renderTo: Ext.getBody(),
            rootVisible: false,
            height: 440,
            width: '98%',
            expanded: true,
            border: 0,
            id: 'ctSubItemChangeGrid',
            autoScroll: true,
            //plugins: [cellEditing],
            viewConfig: {enableTextSelection: true},
            selType: 'checkboxmodel',
            columns: [
                {
                    text: 'id',
                    width: 50,
                    align: 'center',
                    menuDisabled: true,
                    dataIndex: 'id',
                    sortable: false,
                    hidden: true
                },
                {
                    text: '物料编号',
                    xtype: 'treecolumn',
                    dataIndex: 'partNumber',
                    width: 120,
                    menuDisabled: true,
                    sortable: false,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('partUrl')) {
                            var changeLink = record.get('partUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '视图', dataIndex: 'partView', width: 100, menuDisabled: true},
                {text: '版本', dataIndex: 'partVersion', width: 100, menuDisabled: true},
                {text: '内部版本', dataIndex: 'internalVersion', width: 100, menuDisabled: true},
                {text: '状态', dataIndex: 'partState', width: 100, menuDisabled: true},
                {text: '版本转变时间', dataIndex: 'transitionTime', width: 100, menuDisabled: true},
                {
                    text: '物料描述',
                    dataIndex: 'partName',
                    width: 120,
                    menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        }
                        return value;
                    }
                },
                {text: '用量', dataIndex: 'consumption', width: 80, menuDisabled: true},
                {text: '单位', dataIndex: 'unit', width: 80, menuDisabled: true},
                {
                    text: '位号',
                    dataIndex: 'tagNumber',
                    width: 200,
                    menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        }
                        return value;
                    }
                },
                {text: 'BOM备注', dataIndex: 'bomRemarks', width: 120, menuDisabled: true}
            ],
            tbar: [{
                text: '导出查询结果',
                id: 'exportModelCertificateGrid',
                iconCls: 'icon icon-store-export',
                scope: this,
                handler: function () {
                    var ctSubItemChangeGrid = Ext.getCmp('ctSubItemChangeGrid');
                    var store = ctSubItemChangeGrid.getStore();
                    let data = store.root.childNodes;
                    if(!data || data.length == 0){
                        Ext.Msg.alert("提示", "请先搜索查询出数据再导出！");
                        return;
                    }

                    // 获取XMLHttpRequest
                    var xmlHttpRequest = new XMLHttpRequest();
                    //  发起请求
                    xmlHttpRequest.open("POST", '/Windchill/ptc1/ext/plm/bom/baselineQuery/exportSubItemData', true);
                    // 设置请求头类型
                    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
                    xmlHttpRequest.responseType = "blob";
                    //增加遮罩
                    var loadMarsk = new Ext.LoadMask({
                        msg: '导出中，请稍等......',
                        target: ctSubItemChangeGrid,
                        removeMask: true // 完成后移除
                    });
                    loadMarsk.show();
                    //  返回
                    xmlHttpRequest.onload = function (oEvent) {
                        var content = xmlHttpRequest.response;
                        if (content.type == 'application/json') {
                            content.text().then(res => {
                                alert(Ext.decode(res).message)
                            })
                        } else {
                            var timestamp =new Date().getTime();
                            // 组装a标签
                            var elink = document.createElement("a");
                            // 设置下载文件名
                            var fileNamePrefix = '物料子项变动记录';
                            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
                            elink.style.display = "none";
                            var blob = new Blob([content]);
                            elink.href = URL.createObjectURL(blob);
                            document.body.appendChild(elink);
                            elink.click();
                            document.body.removeChild(elink);
                        }
                        loadMarsk.hide();
                    };
                    let newData = [];
                    for(let i = 0;i < data.length;i++){
                        newData[i] = data[i].data;
                    }
                    xmlHttpRequest.send(JSON.stringify(newData));
                }
            }, {
                text: '记录比较',
                id: 'recordComparison',
                iconCls: 'icon-information-compare',
                scope: this,
                handler: function () {
                    var recordList = ctSubItemChangeGrid.getSelectionModel().getSelection();
                    if(recordList.length == 0){
                        alert("请选择数据！");
                        return;
                    }
                    if(recordList.length > 2){
                        alert("只能选择一条或者两条数据！");
                        return;
                    }
                    if (recordList.length == 1) {
                        var partNumber = recordList[0].data.partNumber;
                        var partName = recordList[0].data.partName;

                        partNumberRight = partNumber;
                        partNumberLeft = partNumber;

                        Ext.getCmp('partNumber_right').setValue(partNumber);
                        Ext.getCmp('partName_right').setValue(partName);

                        Ext.getCmp('partNumber_left').setValue(partNumber);
                        Ext.getCmp('partName_left').setValue(partName);
                    } else {
                        var partNumberLeftIn = recordList[0].data.partNumber;
                        var partNameLeft = recordList[0].data.partName;

                        var partNumberRightIn = recordList[1].data.partNumber;
                        var partNameRight = recordList[1].data.partName;

                        partNumberRight = partNumberRightIn;
                        partNumberLeft = partNumberLeftIn;

                        Ext.getCmp('partNumber_right').setValue(partNumberRight);
                        Ext.getCmp('partName_right').setValue(partNameRight);

                        Ext.getCmp('partNumber_left').setValue(partNumberLeft);
                        Ext.getCmp('partName_left').setValue(partNameLeft);
                    }
                    recordComparisonWindow.show();
                }
            }, '->'
            , showGridCount,
            {
                width: 20
            }
            ]
        });

        var versionStore_baseline_right = new Ext.data.ArrayStore({
            id: 'versionStore_baseline_right',
            fields: [
                {partOid: "partOid"},
                {partVersion: "partVersion"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/getPartVersion',
                extraParams: {
                    partNumber: partNumberRight,
                    partView: partViewRight
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            listeners: {
                beforeload: function(store, operation) {
                    var params = operation.getParams();
                    params.partView = partViewRight; // 添加新的参数，如果需要的话
                }
            },
            autoLoad: false
        });
        var versionStore_baseline_left = new Ext.data.ArrayStore({
            id: 'versionStore_baseline_left',
            fields: [
                {partOid: "partOid"},
                {partVersion: "partVersion"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/getPartVersion',
                extraParams: {
                    partNumber: partNumberLeft,
                    partView: partViewLeft
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            listeners: {
                beforeload: function(store, operation) {
                    var params = operation.getParams();
                    params.partView = partViewLeft; // 添加新的参数，如果需要的话
                }
            },
            autoLoad: false
        });

        var versionStore_baseline_sub = new Ext.data.ArrayStore({
            id: 'versionStore_baseline_sub',
            fields: [
                {partOid: "partOid"},
                {partVersion: "partVersion"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/getPartVersion',
                extraParams: {
                    partNumber: partNumber,
                    partView: partViewSub
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            listeners: {
                beforeload: function(store, operation) {
                    var params = operation.getParams();
                    params.partView = partViewSub; // 添加新的参数，如果需要的话
                },
                load: function(store, records, successful, operation, options) {
                    if (successful) {
                        let versionCom = Ext.getCmp('versionCom_baseline_sub');
                        if(versionCom){
                            let value = versionCom.getValue();
                            if(value){
                                versionCom.setValue(value);
                            }
                        }
                    }
                }
            },
            autoLoad: false
        });

        var versionCom = new Ext.form.ComboBox({
            xtype: 'combo',
            fieldLabel: '版本',
            name: 'versionCom_baseline_sub',
            id: 'versionCom_baseline_sub',
            multiSelect: true,
            editable: false,
            width: 150,
            store: versionStore_baseline_sub,
            valueField: 'partOid',
            displayField: 'partVersion',
            listeners: {
                expand: function() {
                    var partNumber = Ext.getCmp('partNumber_baseline_sub').getValue();
                    var partView = Ext.getCmp('baselineView_baseline_sub').getValue();
                    if(!partView){
                        alert("请选择视图！");
                        versionStore_baseline_sub.setData([])
                        return;
                    }
                    if(partNumber&&partView){
                        versionStore_baseline_sub.load({
                            params: {
                                partNumber: partNumber,
                                partView:partView
                            }
                        });
                    }
                },
                select: function(combo, record) {
                }
            }
        });

//===============================搜索物料相关弹窗 start==================================================================
        var partColumns = [
            {text: '物料编号', dataIndex: 'partNumber', flex: 1, menuDisabled: true, editor: false},
            {text: '物料名称', dataIndex: 'partName', flex: 1, menuDisabled: true, editor: false}
        ];
        var partStore = Ext.create('Ext.data.Store', {
            fields: ['partNumber','partName'],
            id: 'partStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ext/plm/bom/baselineQuery/getPartNumberAndPartName',
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false,
        });
        var partGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var partGrid = Ext.create('Ext.grid.Panel', {
            plugins: [partGridEditing],
            store: partStore,
            columns: partColumns,
            id:'partGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: {
                enableTextSelection: true
            },
            selModel: {
                type: "checkboxmodel",
                mode: 'SINGLE'//单选
            },
            dockedItems: [{
                xtype: 'container',
                dock: 'bottom',
                layout: {
                    type: 'hbox',
                    pack: 'end' // 右对齐
                },
                items: [{
                    xtype: 'button',
                    text: '确定',
                    margin: '10 10 10 0', // 右侧留出 10px 的间距
                    handler: function() {
                        var recordList = partGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var partNumber = recordList[0].data.partNumber;
                            var partName = recordList[0].data.partName;
                            if ("right" == searchCriteria) {
                                Ext.getCmp('partNumber_right').setValue(partNumber);
                                Ext.getCmp('partName_right').setValue(partName);
                                partNumberRight = partNumber;
                            }
                            if ("left" == searchCriteria) {
                                Ext.getCmp('partNumber_left').setValue(partNumber);
                                Ext.getCmp('partName_left').setValue(partName);
                                partNumberLeft = partNumber;
                            }
                            Ext.getCmp('partWindow').close();
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }, {
                    xtype: 'button',
                    text: '取消',
                    margin: '10 10 10 0', // 右侧留出 10px 的间距
                    handler: function() {
                        Ext.getCmp('partWindow').close();
                    }
                }]
            }]
        });

        var partWindow = Ext.create('Ext.Window', {
            id:'partWindow',
            title: '搜索物料',
            width: 700,
            //height: 300,
            autoHeight : true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal:true,
            items:[
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    defaults: {
                        margin: '20 20 20 20'
                    },
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: '物料编号',
                            width: 180,
                            labelWidth: 60,
                            id: 'partNumber',
                            name: 'partNumber',
                            // value: partNumber
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '物料名称',
                            width: 180,
                            labelWidth: 60,
                            id: 'partName',
                            name: 'partName'
                        },
                        {
                            xtype: 'button',
                            text: '搜索',
                            width: 70,
                            labelWidth: 60,
                            handler: function() {
                                var partNumber = Ext.getCmp('partNumber').getValue();
                                var partName = Ext.getCmp('partName').getValue();
                                partStore.load({
                                    params: {
                                        partNumber: partNumber,
                                        partName: partName
                                    }
                                });
                            }
                        },
                    ]
                },
                {
                    // margin: '20 0 20 0',
                    html: '<div style="font-weight: bold; color: red;">最多只展示100行数据</div>'
                },
                partGrid
            ],
        });
//===============================搜索物料相关弹窗 end==================================================================


//===============================记录比较相关弹窗 start==================================================================
        var recordComparisonPanel = Ext.create('Ext.panel.Panel', {
            // title: '查询条件',
            width: 800,
            bodyPadding: 10,
            layout: {
                type: 'table',
                columns: 2,
                tdAttrs: { style: 'padding: 10px;' }
            },
            defaults: {
                xtype: 'textfield',
                labelAlign: 'right',
                width: 250,
                margin: '0 10 0 0' // 间距设定
            },
            items: [
                {
                    xtype: 'container',
                    width: 400,
                    items: [
                        {
                            xtype: 'container',
                            layout: {
                                type: 'hbox', // 水平布局，用于放置搜索框和按钮
                                align: 'stretch' // 拉伸以填充整个容器宽度
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: '搜索其它物料',
                                    iconCls: 'icon icon-search', // 设置搜索按钮的图标
                                    handler: function() {
                                        searchCriteria = "left";
                                        partWindow.show();
                                    }
                                }
                            ]
                        },
                        { xtype: 'component', height: 10 },
                        {
                            xtype: 'displayfield',
                            fieldLabel: '物料编号',
                            width: 280,
                            id: 'partNumber_left',
                            name: 'partNumber_left',
                            value: partNumber
                        },
                        {
                            xtype: 'displayfield',
                            fieldLabel: '名称',
                            width: 280,
                            id: 'partName_left',
                            name: 'partName_left'
                        },
                        {
                            xtype: 'combobox',
                            fieldLabel: '视图',
                            name: 'baselineView_left',
                            id: 'baselineView_left',
                            width: 280,
                            enableKeyEvents: true,
                            store: {data:[{baselineView:'Design'},{baselineView:'Manufacturing'}]}, // 下拉框的选项数据
                            queryMode: 'local', // 查询模式
                            editable: false, // 设置为不可编辑
                            valueField: 'baselineView',
                            displayField: 'baselineView',
                            listeners: {
                                expand: function() {
                                },
                                select: function(combo, record) {
                                    partViewLeft = record.data.baselineView;
                                }
                            }
                        },
                        {
                            xtype: 'combo',
                            fieldLabel: '版本',
                            name: 'versionCom_left',
                            id: 'versionCom_left',
                            multiSelect: false,
                            editable: false,
                            width: 280,
                            store: versionStore_baseline_left,
                            valueField: 'partOid',
                            displayField: 'partVersion',
                            listeners: {
                                expand: function() {
                                    var partNumber = Ext.getCmp('partNumber_left').getValue();
                                    var partView = Ext.getCmp('baselineView_left').getValue();
                                    if(!partNumber){
                                        alert("请选择物料编码！");
                                        versionStore_baseline_left.setData([])
                                        return;
                                    }
                                    if(!partView){
                                        alert("请选择视图！");
                                        versionStore_baseline_left.setData([])
                                        return;
                                    }
                                    if(partNumber&&partView){
                                        versionStore_baseline_left.load({
                                            params: {
                                                partNumber: partNumber,
                                                partView:partView
                                            }
                                        });
                                    }
                                },
                                select: function(combo, record) {
                                }
                            }
                        },
                        {
                            xtype: 'datefield',
                            fieldLabel: '日期时间',
                            name: 'creationTime_left',
                            id: 'creationTime_left',
                            width: 280
                        }
                    ]
                },
                {
                    xtype: 'container',
                    width: 400,
                    items: [
                        {
                            xtype: 'container',
                            layout: {
                                type: 'hbox', // 水平布局，用于放置搜索框和按钮
                                align: 'stretch' // 拉伸以填充整个容器宽度
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: '搜索其它物料',
                                    iconCls: 'icon icon-search', // 设置搜索按钮的图标
                                    handler: function() {
                                        searchCriteria = "right";
                                        partWindow.show();
                                    }
                                }
                            ]
                        },
                        { xtype: 'component', height: 10 },
                        {
                            xtype: 'displayfield',
                            fieldLabel: '物料编号',
                            width: 280,
                            id: 'partNumber_right',
                            name: 'partNumber_right',
                            // value: partNumber
                        },
                        {
                            xtype: 'displayfield',
                            fieldLabel: '名称',
                            width: 280,
                            id: 'partName_right',
                            name: 'partName_right'
                        },
                        {
                            xtype: 'combobox',
                            fieldLabel: '视图',
                            name: 'baselineView_right',
                            id: 'baselineView_right',
                            width: 280,
                            enableKeyEvents: true,
                            store: {data:[{baselineView:'Design'},{baselineView:'Manufacturing'}]}, // 下拉框的选项数据
                            queryMode: 'local', // 查询模式
                            editable: false, // 设置为不可编辑
                            valueField: 'baselineView',
                            displayField: 'baselineView',
                            listeners: {
                                expand: function() {
                                },
                                select: function(combo, record) {
                                    partViewRight = record.data.baselineView;
                                }
                            }
                        },
                        {
                            xtype: 'combo',
                            fieldLabel: '版本',
                            name: 'versionCom_right',
                            id: 'versionCom_right',
                            multiSelect: false,
                            editable: false,
                            width: 280,
                            store: versionStore_baseline_right,
                            valueField: 'partOid',
                            displayField: 'partVersion',
                            listeners: {
                                expand: function() {
                                    var partNumber = Ext.getCmp('partNumber_right').getValue();
                                    var partView = Ext.getCmp('baselineView_right').getValue();
                                    if(!partNumber){
                                        alert("请选择物料编码！");
                                        versionStore_baseline_right.setData([])
                                        return;
                                    }
                                    if(!partView){
                                        alert("请选择视图！");
                                        versionStore_baseline_right.setData([])
                                        return;
                                    }
                                    if(partNumber&&partView){
                                        versionStore_baseline_right.load({
                                            params: {
                                                partNumber: partNumber,
                                                partView:partView
                                            }
                                        });
                                    }
                                },
                                select: function(combo, record) {
                                }
                            }
                        },
                        {
                            xtype: 'datefield',
                            fieldLabel: '日期时间',
                            name: 'creationTime_right',
                            id: 'creationTime_right',
                            width: 280
                        }
                    ]
                },
            ],
            buttons: [
                {
                    text: '确定',
                    handler: function() {
                        var partNumberLeft = Ext.getCmp('partNumber_left').getValue();
                        //var partNameLeft = Ext.getCmp('partName_left').getValue();
                        var partViewLeft = Ext.getCmp('baselineView_left').getValue();
                        var partVersionLeft = Ext.getCmp('versionCom_left').getValue();
                        var partDateLeft = Ext.getCmp('creationTime_left').getValue();

                        var partNumberRight = Ext.getCmp('partNumber_right').getValue();
                        //var partNameRight = Ext.getCmp('partName_right').getValue();
                        var partViewRight = Ext.getCmp('baselineView_right').getValue();
                        var partVersionRight = Ext.getCmp('versionCom_right').getValue();
                        var partDateRight = Ext.getCmp('creationTime_right').getValue();

                        if(!partViewLeft || !partViewRight){
                            Ext.Msg.alert('提示', '视图不能为空！');
                            return false;
                        }
                        if((!partVersionLeft && !partDateLeft) || (!partVersionRight && !partDateRight)){
                            Ext.Msg.alert('提示', '版本和时间不能同时为空！');
                            return false;
                        }
                        if((partVersionLeft && partDateLeft) || (partVersionRight && partDateRight)){
                            Ext.Msg.alert('提示', '版本和时间只能填一个条件！');
                            return false;
                        }
                        var param = {
                            partNumberLeft:partNumberLeft,
                            partViewLeft:partViewLeft,
                            partVersionLeft:partVersionLeft,
                            partDateLeft:partDateLeft,
                            partNumberRight:partNumberRight,
                            partViewRight:partViewRight,
                            partVersionRight:partVersionRight,
                            partDateRight:partDateRight
                        };

                        //重置数据
                        resetWindowData();
                        Ext.getCmp('recordComparisonWindow').close();

                        //导出
                        // 获取XMLHttpRequest
                        var xmlHttpRequest = new XMLHttpRequest();
                        //  发起请求
                        xmlHttpRequest.open("POST", '/Windchill/ptc1/ext/plm/bom/baselineQuery/exportBaselineBomDifferent', true);
                        // 设置请求头类型
                        xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
                        xmlHttpRequest.responseType = "blob";
                        //  返回
                        xmlHttpRequest.onload = function (oEvent) {
                            var content = xmlHttpRequest.response;
                            if (content.type == 'application/json') {
                                content.text().then(res => {
                                    alert(Ext.decode(res).message)
                                })
                            } else {
                                var timestamp =new Date().getTime();
                                // 组装a标签
                                var elink = document.createElement("a");
                                // 设置下载文件名
                                var fileNamePrefix = 'BOM基线记录比较';
                                elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
                                elink.style.display = "none";
                                var blob = new Blob([content]);
                                elink.href = URL.createObjectURL(blob);
                                document.body.appendChild(elink);
                                elink.click();
                                document.body.removeChild(elink);
                            }
                        };
                        xmlHttpRequest.send(JSON.stringify(param));
                    }
                },
                {
                    text: '取消',
                    handler: function() {
                        resetWindowData();
                        Ext.getCmp('recordComparisonWindow').close();
                    }
                }
            ]
        });

        var recordComparisonWindow = Ext.create('Ext.Window', {
            id:'recordComparisonWindow',
            title: '记录比较',
            width: 800,
            //height: 300,
            autoHeight : true,
            closeAction: 'hide',
            closable: false,  // 不显示关闭按钮
            constrain: true,
            modal:true,
            items:[recordComparisonPanel],
        });
//===============================记录比较相关弹窗 start==================================================================



        //======================  userResourceGrid End  ======================//

        ////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '查询条件',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 20 10 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'displayfield',
                                fieldLabel: '物料编号',
                                width: 120,
                                id: 'partNumber_baseline_sub',
                                name: 'partNumber_baseline_sub',
                                value: partNumber
                            },
                            {
                                xtype: 'combobox',
                                fieldLabel: '视图',
                                name: 'baselineView_baseline_sub',
                                id: 'baselineView_baseline_sub',
                                width: 180,
                                // labelWidth: 40,
                                enableKeyEvents: true,
                                store: {data:[{baselineView:'Design'},{baselineView:'Manufacturing'}]}, // 下拉框的选项数据
                                queryMode: 'local', // 查询模式
                                editable: false, // 设置为不可编辑
                                valueField: 'baselineView',
                                displayField: 'baselineView',
                                listeners: {
                                    expand: function() {
                                    },
                                    select: function(combo, record) {
                                        partViewSub = record.data.baselineView;
                                        var version = Ext.getCmp('versionCom_baseline_sub');
                                        version.reset();
                                    }
                                }
                            },
                            versionCom,
                            {
                                xtype: 'datefield',
                                fieldLabel: '日期时间',
                                name: 'creationTime_baseline_sub',
                                id: 'creationTime_baseline_sub',
                                width: 180
                            },
                            {
                                xtype: 'button',
                                text: '搜索',
                                width: 70,
                                scope: this,
                                handler: function () {
                                    var partNumber = Ext.getCmp('partNumber_baseline_sub').getValue();
                                    var baselineView = Ext.getCmp('baselineView_baseline_sub').getValue();
                                    var versionCom = Ext.getCmp('versionCom_baseline_sub').getValue();
                                    var creationTime = Ext.getCmp('creationTime_baseline_sub').getValue();
                                    // if(!partNumber){
                                    //     alert("物料编码必须填写！");
                                    //     return;
                                    // }
                                    if((versionCom && versionCom.length > 0 && creationTime)||(!versionCom&&!creationTime)){
                                        alert("版本和日期时间必须填写一个且只能填写一个！");
                                        return;
                                    }
                                    if(!baselineView){
                                        alert("视图必须填写！");
                                        return;
                                    }
                                    ctSubItemChangeGrid.getStore().load({
                                        params: {
                                            oid: oid,
                                            date: creationTime,
                                            view: baselineView,
                                            partNumber:partNumber,
                                            version:versionCom?versionCom.join(","):versionCom
                                        }
                                    });
                                }
                            },
                            {
                                xtype: 'button',
                                width: 70,
                                margin: '10 20 10 0',
                                text: '重置',
                                scope: this,
                                handler: function () {
                                    var baselineView = Ext.getCmp('baselineView_baseline_sub');
                                    baselineView.reset();
                                    var version = Ext.getCmp('versionCom_baseline_sub');
                                    version.reset();
                                    var creationTime = Ext.getCmp('creationTime_baseline_sub');
                                    creationTime.reset();
                                    let treeGridStore = Ext.getCmp("ctSubItemChangeGrid").getStore();
                                    treeGridStore.removeAll();
                                    treeGridStore.reload();
                                }
                            }
                        ]
                    }
                ]
            },
            ctSubItemChangeGrid
        ];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});

function resetWindowData() {
    var partNumberLeft = Ext.getCmp('partNumber_left');
    partNumberLeft.reset();
    var partNameLeft = Ext.getCmp('partName_left');
    partNameLeft.reset();
    var partViewLeft = Ext.getCmp('baselineView_left');
    partViewLeft.reset();
    var partVersionLeft = Ext.getCmp('versionCom_left');
    partVersionLeft.reset();
    var partDateLeft = Ext.getCmp('creationTime_left');
    partDateLeft.reset();
    var partNumberRight = Ext.getCmp('partNumber_right');
    partNumberRight.reset();
    var partNameRight = Ext.getCmp('partName_right');
    partNameRight.reset();
    var partViewRight = Ext.getCmp('baselineView_right');
    partViewRight.reset();
    var partVersionRight = Ext.getCmp('versionCom_right');
    partVersionRight.reset();
    var partDateRight = Ext.getCmp('creationTime_right');
    partDateRight.reset();
}

function getTotalChildNodes(tree) {
    if (!tree || !tree.children) {
        return 0;
    }
    let count = tree.children.length;
    for (let i = 0; i < tree.children.length; i++) {
        count += getTotalChildNodes(tree.children[i]);
    }
    return count;
}