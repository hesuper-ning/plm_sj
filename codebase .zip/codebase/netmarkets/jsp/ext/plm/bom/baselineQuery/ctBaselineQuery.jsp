<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.part.WTPart" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page language="java" pageEncoding="UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<%
		String oid = request.getParameter("oid");
		wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
		Persistable object = rf.getReference(oid).getObject();
		String partNumber = null;
		if(object instanceof WTPart) {
			WTPart part = (WTPart) object;
			partNumber = part.getNumber();
		}
		boolean isAdmin = CtUserUtil.isInGroup(CtUserUtil.getCurrentUser(), "Administrators");
	%>

	<SCRIPT type="text/javascript">
		var oid ='<%= oid %>';
		//部件编码
		var partNumber  = "<%=partNumber%>";
		//用于判断给左边条件赋值还是右边的条件赋值
		var searchCriteria  = "";

		//物料使用关系记录页面版本与内部版本使用
		var partNumberUse = "";
		var partViewUse = "";

		//物料子项变动记录页面版本使用
		var partNumberSub = "";
		var partViewSub = "";

		//物料子项变动记录页面弹窗右边版本使用
		var partNumberRight = "";
		var partViewRight = "";
		//物料子项变动记录页面弹窗左边版本使用
		var partNumberLeft = "";
		var partViewLeft = "";

		var isAdmin = "<%=isAdmin%>";

	</SCRIPT>

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
	<link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
	<script type="text/javascript" src="../../common/jquery-2.0.0.min.js"></script>
	<script type="text/javascript" src="js/ctUseRelationshipReport.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<script type="text/javascript" src="js/ctSubItemChangeReport.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<script type="text/javascript" src="js/ctNewSubItemChangeReport.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<script type="text/javascript" src="js/ctBaselineQueryPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
// ==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();

	 Ext.create('Ext.container.Viewport', {
		 layout: 'border',
		 items: [{
			 region: 'center',
			 xtype: 'CtBaselineQueryPanel'
		 }]
	 });
});
</script>
</body>
</html>