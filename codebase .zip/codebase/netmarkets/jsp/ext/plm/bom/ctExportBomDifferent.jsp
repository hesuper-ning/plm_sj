<%response.setCharacterEncoding("UTF-8");%>
<%@ page import="
             ext.plm.bom.CtBomService,
            wt.services.ServiceFactory,
			java.io.OutputStream"%>
<%@ page import="java.util.List" %>
<%@ page import="ext.plm.report.part.CtPartReportHelper" %>
<%@ page import="ext.plm.bom.CtBomLogic" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="org.apache.poi.xssf.streaming.SXSSFWorkbook" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%
    /**
     * 页面导出EBOM/MBOM差异
     */
    String partOid = request.getParameter("oid");
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    wt.part.WTPart part = (wt.part.WTPart)rf.getReference(partOid).getObject();
    System.out.println("fpartname-------------------->"+part.getName());
    String partNumber = part.getNumber();

    response.setContentType("application/octet-stream");
    String fileName = "EBOM和MBOM差异-" + System.currentTimeMillis() + ".xlsx";
    response.addHeader("Content-Disposition","attachment;filename="+ java.net.URLEncoder.encode(fileName, "UTF-8"));
    //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
    response.addHeader("Cache-Control","no-cache");

    OutputStream os = response.getOutputStream();
    List<String> partNumberList = new ArrayList<>();
    partNumberList.add(partNumber);
    SXSSFWorkbook workbook = CtBomLogic.exportBomDifferent(partNumberList, "");
    workbook.write(os);
    workbook.dispose();
    out.clear();
    out=pageContext.pushBody();
%>