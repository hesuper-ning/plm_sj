<%response.setCharacterEncoding("UTF-8");%>
<%@ page import="
             ext.plm.bom.CtBomService,
            wt.services.ServiceFactory,
			java.io.OutputStream"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%
    /**
     * 页面导出BOM
     */
    String partOid = request.getParameter("oid");
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    wt.part.WTPart part = (wt.part.WTPart)rf.getReference(partOid).getObject();
    System.out.println("fpartname-------------------->"+part.getName());
    String file = part.getNumber();

    response.setContentType("application/octet-stream");
    response.addHeader("Content-Disposition","attachment;filename="+ java.net.URLEncoder.encode(file,"UTF-8") + ".xlsx");
    //response.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
    response.addHeader("Cache-Control","no-cache");

    OutputStream os = response.getOutputStream();
    CtBomService ctBomService = ServiceFactory.getService(CtBomService.class);
    ctBomService.exportBom(os, part,file);

    out.clear();
    out=pageContext.pushBody();
%>