<%@ page import="ext.plm.report.resourceLoad.CtHumanResourceLogic" %>
<%@ page import="java.util.HashMap" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<%
	HashMap<String, String> columns = CtHumanResourceLogic.getColumns();
	String column1 = columns.get("column1");
	String column2 = columns.get("column2");
	String column3 = columns.get("column3");
	String column4 = columns.get("column4");
	String column5 = columns.get("column5");
	String column6 = columns.get("column6");
	String column7 = columns.get("column7");
	String column8 = columns.get("column8");
	String column9 = columns.get("column9");
	String column10 = columns.get("column10");
	String column11 = columns.get("column11");
	String column12 = columns.get("column12");
%>

<script type="text/javascript">
		var gridWidth = window.innerWidth/2-40;
		var column1 = '<%=column1%>';
		var column2 = '<%=column2%>';
		var column3 = '<%=column3%>';
		var column4 = '<%=column4%>';
		var column5 = '<%=column5%>';
		var column6 = '<%=column6%>';
		var column7 = '<%=column7%>';
		var column8 = '<%=column8%>';
		var column9 = '<%=column9%>';
		var column10 = '<%=column10%>';
		var column11 = '<%=column11%>';
		var column12 = '<%=column12%>';
</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
	<link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="js/ctHumanResource.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>
// ==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'CtHumanResourcePanel'
		    }]
		});
});
</script>
</body>
</html>