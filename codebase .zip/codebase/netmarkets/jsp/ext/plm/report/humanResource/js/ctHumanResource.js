Ext.define('PLM.view.CtHumanResourcePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtHumanResourcePanel',
    title: '<font style="font-size:15px">人力资源负荷报表</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtHumanResourcePanel',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {

        //====================== 用户计划投入人天&用户剩余人天 ===================//
        //======================  userResourceGrid Begin  ======================//
        Ext.define('userResourceModel', {
            extend: 'Ext.data.Model',
            fields: [

            ],
            idProperty: 'userName'
        });
        // create the Data Store
        var userResourceStore = Ext.create('Ext.data.Store', {
            model: 'userResourceModel',
            id: 'userResourceStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/humanResource/getUserResource',
                timeout: 9999999,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'userName',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });
        userResourceStore.on('beforeload', function (store, options) {
        });

        var userResourceGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.data.StoreManager.lookup('userResourceStore'),
            id: 'userResourceGrid',
            title: '计划投入工作量(人天)/计划剩余工作量(人天)',
            titleAlign: 'center',
            width: '98%',
            autoScroll: true,
            height: 500,
            // autoHeight:true,
            region: 'center',
            collapsible: true,
            viewConfig: {enableTextSelection: true},
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '部门', dataIndex: 'parentDept', flex:1, menuDisabled: true},
                {text: '姓名', dataIndex: 'userFullName', flex:1, menuDisabled: true},
                {text: '岗位', dataIndex: 'postName', flex:1, menuDisabled: true},
                {
                    text: '计划投入工作量(人天)',
                    columns: [
                        {text: column1, dataIndex: 'intoMonth1', flex:1, menuDisabled: true},
                        {text: column2, dataIndex: 'intoMonth2', flex:1, menuDisabled: true},
                        {text: column3, dataIndex: 'intoMonth3', flex:1, menuDisabled: true},
                        {text: column4, dataIndex: 'intoMonth4', flex:1, menuDisabled: true},
                        {text: column5, dataIndex: 'intoMonth5', flex:1, menuDisabled: true},
                        {text: column6, dataIndex: 'intoMonth6', flex:1, menuDisabled: true},
                        {text: column7, dataIndex: 'intoMonth7', flex:1, menuDisabled: true},
                        {text: column8, dataIndex: 'intoMonth8', flex:1, menuDisabled: true},
                        {text: column9, dataIndex: 'intoMonth9', flex:1, menuDisabled: true},
                        {text: column10, dataIndex: 'intoMonth10', flex:1, menuDisabled: true},
                        {text: column11, dataIndex: 'intoMonth11', flex:1, menuDisabled: true},
                        {text: column12, dataIndex: 'intoMonth12', flex:1, menuDisabled: true}
                    ]
                },
                {
                    text: '计划剩余工作量(人天)',
                    columns: [
                        {text: column1, dataIndex: 'leftMonth1', flex:1, menuDisabled: true},
                        {text: column2, dataIndex: 'leftMonth2', flex:1, menuDisabled: true},
                        {text: column3, dataIndex: 'leftMonth3', flex:1, menuDisabled: true},
                        {text: column4, dataIndex: 'leftMonth4', flex:1, menuDisabled: true},
                        {text: column5, dataIndex: 'leftMonth5', flex:1, menuDisabled: true},
                        {text: column6, dataIndex: 'leftMonth6', flex:1, menuDisabled: true},
                        {text: column7, dataIndex: 'leftMonth7', flex:1, menuDisabled: true},
                        {text: column8, dataIndex: 'leftMonth8', flex:1, menuDisabled: true},
                        {text: column9, dataIndex: 'leftMonth9', flex:1, menuDisabled: true},
                        {text: column10, dataIndex: 'leftMonth10', flex:1, menuDisabled: true},
                        {text: column11, dataIndex: 'leftMonth11', flex:1, menuDisabled: true},
                        {text: column12, dataIndex: 'leftMonth12', flex:1, menuDisabled: true}
                    ]
                }

            ]
        });
        //======================  userResourceGrid End  ======================//

        //====================== 计划投入人天（部门） ===================//
        //======================  deptIntoResourceGrid Begin  ======================//
        Ext.define('deptIntoResourceModel', {
            extend: 'Ext.data.Model',
            fields: [

            ],
            idProperty: 'dept'
        });
        // create the Data Store
        var deptIntoResourceStore = Ext.create('Ext.data.Store', {
            model: 'deptIntoResourceModel',
            id: 'deptIntoResourceStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/humanResource/getDeptIntoResource',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'dept',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });
        deptIntoResourceStore.on('beforeload', function (store, options) {
        });

        var deptIntoResourceGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.data.StoreManager.lookup('deptIntoResourceStore'),
            id: 'deptIntoResourceGrid',
            title: '计划投入人力(人天)',
            titleAlign: 'center',
            // autoWidth: true,
            width: gridWidth,
            autoScroll: true,
            height: 300,
            collapsible: true,
            region: 'center',
            viewConfig: {enableTextSelection: true},
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '部门', dataIndex: 'dept', flex:1, menuDisabled: true},
                {text: column1, dataIndex: 'month1', flex:1, menuDisabled: true},
                {text: column2, dataIndex: 'month2', flex:1, menuDisabled: true},
                {text: column3, dataIndex: 'month3', flex:1, menuDisabled: true},
                {text: column4, dataIndex: 'month4', flex:1, menuDisabled: true},
                {text: column5, dataIndex: 'month5', flex:1, menuDisabled: true},
                {text: column6, dataIndex: 'month6', flex:1, menuDisabled: true},
                {text: column7, dataIndex: 'month7', flex:1, menuDisabled: true},
                {text: column8, dataIndex: 'month8', flex:1, menuDisabled: true},
                {text: column9, dataIndex: 'month9', flex:1, menuDisabled: true},
                {text: column10, dataIndex: 'month10', flex:1, menuDisabled: true},
                {text: column11, dataIndex: 'month11', flex:1, menuDisabled: true},
                {text: column12, dataIndex: 'month12', flex:1, menuDisabled: true}

            ]
        });
        //====================== 计划投入人天（部门） ===================//
        //======================  deptIntoResourceGrid End  ======================//

        //====================== 计划剩余人天（部门） ===================//
        //======================  deptLeftResourceGrid Begin  ======================//
        Ext.define('deptLeftResourceModel', {
            extend: 'Ext.data.Model',
            fields: [

            ],
            idProperty: 'dept'
        });
        // create the Data Store
        var deptLeftResourceStore = Ext.create('Ext.data.Store', {
            model: 'deptLeftResourceModel',
            id: 'deptLeftResourceStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/humanResource/getDeptLeftResource',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'dept',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });
        deptLeftResourceStore.on('beforeload', function (store, options) {
        });

        var deptLeftResourceGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.data.StoreManager.lookup('deptLeftResourceStore'),
            id: 'deptLeftResourceGrid',
            title: '计划剩余人力(人天)',
            titleAlign: 'center',
            // autoWidth: true,
            width: gridWidth,
            autoScroll: true,
            collapsible: true,
            height: 300,
            region: 'center',
            viewConfig: {enableTextSelection: true},
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '部门', dataIndex: 'dept', flex:1, menuDisabled: true},
                {text: column1, dataIndex: 'month1', flex:1, menuDisabled: true},
                {text: column2, dataIndex: 'month2', flex:1, menuDisabled: true},
                {text: column3, dataIndex: 'month3', flex:1, menuDisabled: true},
                {text: column4, dataIndex: 'month4', flex:1, menuDisabled: true},
                {text: column5, dataIndex: 'month5', flex:1, menuDisabled: true},
                {text: column6, dataIndex: 'month6', flex:1, menuDisabled: true},
                {text: column7, dataIndex: 'month7', flex:1, menuDisabled: true},
                {text: column8, dataIndex: 'month8', flex:1, menuDisabled: true},
                {text: column9, dataIndex: 'month9', flex:1, menuDisabled: true},
                {text: column10, dataIndex: 'month10', flex:1, menuDisabled: true},
                {text: column11, dataIndex: 'month11', flex:1, menuDisabled: true},
                {text: column12, dataIndex: 'month12', flex:1, menuDisabled: true}

            ]
        });
        //====================== 计划剩余人天（部门） ===================//
        //======================  deptLeftResourceGrid End  ======================//


        //====================== 计划剩余人天占比（部门） ===================//
        //======================  deptLeftResourceAvgGrid Begin  ======================//
        Ext.define('deptLeftResourceAvgModel', {
            extend: 'Ext.data.Model',
            fields: [

            ],
            idProperty: 'dept'
        });
        // create the Data Store
        var deptLeftResourceAvgStore = Ext.create('Ext.data.Store', {
            model: 'deptLeftResourceAvgModel',
            id: 'deptLeftResourceAvgStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/humanResource/getDeptLeftResourceAvg',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'dept',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });
        deptLeftResourceAvgStore.on('beforeload', function (store, options) {
        });

        var deptLeftResourceAvgGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.data.StoreManager.lookup('deptLeftResourceAvgStore'),
            id: 'deptLeftResourceAvgGrid',
            // autoWidth: true,
            width: gridWidth,
            autoScroll: true,
            title: '计划剩余人力占比',
            titleAlign: 'center',
            collapsible: true,
            height: 300,
            region: 'center',
            viewConfig: {enableTextSelection: true},
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '部门', dataIndex: 'dept', flex:1, menuDisabled: true},
                {text: column1, dataIndex: 'month1percent', flex:1, menuDisabled: true},
                {text: column2, dataIndex: 'month2percent', flex:1, menuDisabled: true},
                {text: column3, dataIndex: 'month3percent', flex:1, menuDisabled: true},
                {text: column4, dataIndex: 'month4percent', flex:1, menuDisabled: true},
                {text: column5, dataIndex: 'month5percent', flex:1, menuDisabled: true},
                {text: column6, dataIndex: 'month6percent', flex:1, menuDisabled: true},
                {text: column7, dataIndex: 'month7percent', flex:1, menuDisabled: true},
                {text: column8, dataIndex: 'month8percent', flex:1, menuDisabled: true},
                {text: column9, dataIndex: 'month9percent', flex:1, menuDisabled: true},
                {text: column10, dataIndex: 'month10percent', flex:1, menuDisabled: true},
                {text: column11, dataIndex: 'month11percent', flex:1, menuDisabled: true},
                {text: column12, dataIndex: 'month12percent', flex:1, menuDisabled: true}


            ]
        });
        //====================== 计划剩余人天占比（部门） ===================//
        //======================  deptLeftResourceAvgGrid End  ======================//

        //====================== 计划可投入总人天（部门） ===================//
        //======================  deptAllResourceGrid Begin  ======================//
        Ext.define('deptAllResourceModel', {
            extend: 'Ext.data.Model',
            fields: [

            ],
            idProperty: 'dept'
        });
        // create the Data Store
        var deptAllResourceStore = Ext.create('Ext.data.Store', {
            model: 'deptAllResourceModel',
            id: 'deptAllResourceStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/humanResource/getDeptAllResource',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'dept',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });
        deptAllResourceStore.on('beforeload', function (store, options) {
        });

        var deptAllResourceGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.data.StoreManager.lookup('deptAllResourceStore'),
            id: 'deptAllResourceGrid',
            // autoWidth: true,
            width: gridWidth,
            autoScroll: true,
            collapsible: true,
            title: '合计可投入项目的总人天',
            titleAlign: 'center',
            height: 300,
            region: 'center',
            viewConfig: {enableTextSelection: true},
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '部门', dataIndex: 'dept', flex:1, menuDisabled: true},
                {text: column1, dataIndex: 'month1', flex:1, menuDisabled: true},
                {text: column2, dataIndex: 'month2', flex:1, menuDisabled: true},
                {text: column3, dataIndex: 'month3', flex:1, menuDisabled: true},
                {text: column4, dataIndex: 'month4', flex:1, menuDisabled: true},
                {text: column5, dataIndex: 'month5', flex:1, menuDisabled: true},
                {text: column6, dataIndex: 'month6', flex:1, menuDisabled: true},
                {text: column7, dataIndex: 'month7', flex:1, menuDisabled: true},
                {text: column8, dataIndex: 'month8', flex:1, menuDisabled: true},
                {text: column9, dataIndex: 'month9', flex:1, menuDisabled: true},
                {text: column10, dataIndex: 'month10', flex:1, menuDisabled: true},
                {text: column11, dataIndex: 'month11', flex:1, menuDisabled: true},
                {text: column12, dataIndex: 'month12', flex:1, menuDisabled: true}
            ]
        });
        //====================== 计划可投入总人天（部门） ===================//
        //======================  deptAllResourceGrid End  ======================//

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [{
            xtype: 'fieldset',
            margin: '5 3 10 3',
            title: '<font style="font-size:12px">查询参数</font>',
            collapsible: true,
            defaults: {
                labelWidth: 100, border: false, anchor: '98%',
                layout: {
                    type: 'hbox'
                }
            },
            items: [{
                xtype: 'panel',
                defaults: {
                    margin: '5 20 0 0',
                    labelWidth: 25
                },
                items: [{
                    xtype: 'textfield',
                    disabledCls: 'none',
                    fieldLabel: '部门',
                    labelWidth: 60,
                    name: 'userDept',
                    id: 'userDept',
                    width: '15%',
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                doUserResourceSearch();
                            }
                        }
                    }
                },{
                    xtype: 'textfield',
                    disabledCls: 'none',
                    fieldLabel: '姓名',
                    labelWidth: 60,
                    name: 'userFullName',
                    id: 'userFullName',
                    width: '15%',
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                doUserResourceSearch();
                            }
                        }
                    }
                },{
                    xtype: 'button',
                    margin: '5 0 10 0',
                    width: 70,
                    text: '查询',
                    scope: this,
                    iconCls: 'icon icon-search',
                    handler: function () {
                        doUserResourceSearch();
                    }
                }, {
                    xtype: 'button',
                    margin: '5 0 10 30',
                    text: 'Excel导出',
                    iconCls: 'icon icon-store-export',
                    scope: this,
                    handler: function () {
                        var userDept = Ext.getCmp('userDept').getValue();
                        var userFullName = Ext.getCmp('userFullName').getValue();
                        window.location.href = "/Windchill/ptc1/humanResource/exportUserResource?userDept="+userDept+"&userFullName="+userFullName;
                    }
                }]
            }]
        }, userResourceGrid,{
            xtype: 'fieldset',
            margin: '5 3 10 3',
            title: '<font style="font-size:12px">查询参数</font>',
            collapsible: true,
            defaults: {
                labelWidth: 100, border: false, anchor: '98%',
                layout: {
                    type: 'hbox'
                }
            },
            items: [{
                xtype: 'panel',
                defaults: {
                    margin: '5 20 0 0',
                    labelWidth: 25
                },
                items: [{
                    xtype: 'textfield',
                    disabledCls: 'none',
                    fieldLabel: '部门',
                    labelWidth: 60,
                    name: 'dept',
                    id: 'dept',
                    width: '35%',
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                doDeptResourceSearch();
                            }
                        }
                    }
                },{
                    xtype: 'button',
                    margin: '5 0 10 0',
                    width: 70,
                    text: '查询',
                    scope: this,
                    iconCls: 'icon icon-search',
                    handler: function () {
                        doDeptResourceSearch();
                    }
                }, {
                    xtype: 'button',
                    margin: '5 0 10 30',
                    text: 'Excel导出',
                    iconCls: 'icon icon-store-export',
                    scope: this,
                    handler: function () {
                        var dept = Ext.getCmp('dept').getValue();
                        window.location.href = "/Windchill/ptc1/humanResource/exportDeptResource?dept="+dept;
                    }
                }]
            }]
        },{
            xtype: 'panel',
            layout:'hbox',
            defaults: {
                margin: '5 20 0 0',
                labelWidth: 25
            },
            items: [
                deptAllResourceGrid,deptIntoResourceGrid
            ]
        },{
            xtype: 'panel',
            layout:'hbox',
            defaults: {
                margin: '5 20 0 0',
                labelWidth: 25
            },
            items: [
                deptLeftResourceGrid,deptLeftResourceAvgGrid
            ]
        }];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            doSearch();
        }
    }

});

function doSearch() {
    Ext.getStore('userResourceStore').load({
        params: {},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.getError());
            } else {
            }
        }
    });
    Ext.getStore('deptIntoResourceStore').load({
        params: {},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.getError());
            } else {
            }
        }
    });
    Ext.getStore('deptLeftResourceStore').load({
        params: {},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.getError());
            } else {
            }
        }
    });
    Ext.getStore('deptLeftResourceAvgStore').load({
        params: {},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.getError());
            } else {
            }
        }
    });
    Ext.getStore('deptAllResourceStore').load({
        params: {},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.getError());
            } else {
            }
        }
    });
}

function doUserResourceSearch(){
    var userDept = Ext.getCmp('userDept').getValue();
    var userFullName = Ext.getCmp('userFullName').getValue();
    Ext.getStore("userResourceStore").clearFilter();
    if(!userDept&&!userFullName){
        return;
    }
    Ext.getStore("userResourceStore").filterBy(function(record, id) {
        if((userDept&&record.get('parentDept').indexOf(userDept)<0)){
            return false;
        }
        if(userFullName&&record.get('userFullName').indexOf(userFullName)<0){
            return false;
        }

        return true;
    });

}

function doDeptResourceSearch(){
    var dept = Ext.getCmp('pdept').getValue();
    Ext.getStore("deptAllResourceStore").clearFilter();
    Ext.getStore("deptIntoResourceStore").clearFilter();
    Ext.getStore("deptLeftResourceStore").clearFilter();
    Ext.getStore("deptLeftResourceAvgStore").clearFilter();
    if(!dept){
        return;
    }
    Ext.getStore("deptAllResourceStore").filterBy(function(record, id) {
        if(dept&&record.get('dept').indexOf(dept)>-1)
            return true;
        else
            return false;
    });
    Ext.getStore("deptIntoResourceStore").filterBy(function(record, id) {
        if(dept&&record.get('dept').indexOf(dept)>-1)
            return true;
        else
            return false;
    });
    Ext.getStore("deptLeftResourceStore").filterBy(function(record, id) {
        if(dept&&record.get('dept').indexOf(dept)>-1)
            return true;
        else
            return false;
    });
    Ext.getStore("deptLeftResourceAvgStore").filterBy(function(record, id) {
        if(dept&&record.get('dept').indexOf(dept)>-1)
            return true;
        else
            return false;
    });

}

