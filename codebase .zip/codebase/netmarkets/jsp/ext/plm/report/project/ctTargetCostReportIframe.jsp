
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>


<iframe id="ctTargetCostReportIframe" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"
        src="netmarkets/jsp/ext/plm/report/project/ctTargetCostReport.jsp?" style="width:98%;height:900px" ></iframe>

<script type="text/javascript">
    var iframe = document.getElementById("ctTargetCostReportIframe");
    iframe.style.height = window.innerHeight*80/100 + 'px';
</script>