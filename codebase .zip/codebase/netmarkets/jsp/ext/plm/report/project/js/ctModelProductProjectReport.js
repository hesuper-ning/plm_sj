/**
 * 管理员漏填工时查询
 * 描述：查询哪些工作日报未填写，可发邮件通知
 */
Ext.define('PLM.view.ctModelProductProjectReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctModelProductProjectReport',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ctModelProductProjectReport',
    initComponent: function () {
        Ext.define('modelProductProjectReportGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'productModel', 'productLibraryName', 'projectNumber', 'projectName', 'projectStatus'],
            idProperty: 'id'
        });

        var modelProductProjectReportStore = Ext.create('Ext.data.Store', {
            id: 'modelProductProjectReportStore',
            model: 'modelProductProjectReportGridModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/projectInquiry',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            root: {
                expanded: true
            },
            autoLoad: false,
            folderSort: true
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var modelProductProjectReportGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('modelProductProjectReportStore'),
            id: 'modelProductProjectReportGrid',
            autoWidth: true,
            autoScroll: true,
            // scroll: 'both' ,// 添加滚动条
            region: 'center',
            height: 500,
            // selModel: {
            //     mode: 'MULTI' //可以多选
            // },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            // selType: 'checkboxmodel',
            // listeners: {
            //     change: 'onAllCircuitsChecked'
            // },
            columns: [
                {xtype: 'rownumberer', text: '序号', flex: 0.2, align: 'center'},
                {text: '产品型号', dataIndex: 'productModel', flex: 1, menuDisabled: true},
                {text: '产品库', dataIndex: 'productLibraryName', flex: 1, menuDisabled: true,},
                {text: '项目编号', dataIndex: 'projectNumber', flex: 1, menuDisabled: true,},
                {text: '项目名称', dataIndex: 'projectName', flex: 1, menuDisabled: true,},
                {text: '项目状态', dataIndex: 'projectStatus', flex: 1, menuDisabled: true,}
            ]
        });



        var modelProductProjectReportPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            padding:'5',
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            autoScroll: true,
            border: false,
            anchor:'100%',
            height: 600,
            items:[
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '10 5 0 20', labelWidth: 100, border: false, padding: 5},
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: '产品型号',
                            width: 180,
                            labelWidth: 60,
                            id: 'productModel',
                            name: 'productModel',
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '产品库',
                            width: 180,
                            labelWidth: 60,
                            id: 'productLibraryName',
                            name: 'productLibraryName'
                        }, {
                            xtype: 'textfield',
                            fieldLabel: '项目名称',
                            width: 180,
                            labelWidth: 60,
                            id: 'projectName',
                            name: 'projectName'
                        }, {
                            iconCls: 'icon icon-search',
                            xtype: 'button',
                            id: "query",
                            text: '查询',
                            handler: function () {
                                var productType = Ext.getCmp('productModel').getValue();
                                var productLibraryName = Ext.getCmp('productLibraryName').getValue();
                                var projectName = Ext.getCmp('projectName').getValue();
                                var queryType = "report";
                                modelProductProjectReportStore.reload({
                                    params: {
                                        productType: productType,
                                        productLibraryName:productLibraryName,
                                        projectName:projectName,
                                        queryType:queryType
                                    }
                                });
                            }
                        }
                    ]
                },
                , modelProductProjectReportGrid
            ]
        });


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [modelProductProjectReportPanel];

        this.callParent();

    },//~End of initComponent
    listeners: {
    },

});


