Ext.define('PLM.view.ctProjectBudgetReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctProjectBudgetReport',
    title: '项目群预算执行报表',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    height: 600,
    collapsible: false,
    id: 'ctProjectBudgetReport',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        Ext.define('ctProjectBudgetModel', {
            extend: 'Ext.data.Model',
            fields: ['projectNumber','projectName','productLine','plannedWorkingHours','actualWorkingHours'
                ,'utilizationRate','budgetAmount','executionAmount','executionRate'
                ,'budgetAmount1','executionAmount1','executionRate1'
            ],
            idProperty: 'id'
        });


        var ctProjectBudgetStore = Ext.create('Ext.data.Store', {
            model: 'ctProjectBudgetModel',
            id: 'ctProjectBudgetStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBudgetExecutionReport',
                method: 'GET',
                timeout: 1800000,
                extraParams:{

                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var ctProjectBudgetGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.getStore('ctProjectBudgetStore'),
            id: 'ctProjectBudgetGrid',
            title: '查询结果',
            autoScroll: true,
            height: 450,
            collapsible: false,
            viewConfig: { enableTextSelection: true },
            columns: [
                {text: 'NO.', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
                {
                    text: '项目编号',
                    dataIndex: 'projectNumber',
                    width: 100,
                    menuDisabled: true
                },
                {
                    text: '项目名称',
                    dataIndex: 'projectName',
                    width: 120,
                    menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        if(value){
                            metaData.tdAttr = " data-qtip = '" + value + "'";
                        }
                        return value;
                    }
                },
                {
                    text: '产品线',
                    dataIndex: 'productLine',
                    width: 100,
                    menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        if(value){
                            metaData.tdAttr = " data-qtip = '" + value + "'";
                        }
                        return value;
                    }
                },
                {
                    text: '人力费用预算执行',
                    columns:[
                        {
                            text: '计划工时',
                            dataIndex: 'plannedWorkingHours',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        },
                        {
                            text: '实际工时',
                            dataIndex: 'actualWorkingHours',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        },
                        {
                            text: '计划工时使用率',
                            dataIndex: 'utilizationRate',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        },
                        {
                            text: '预算金额',
                            dataIndex: 'budgetAmount',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        },
                        {
                            text: '执行金额',
                            dataIndex: 'executionAmount',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        },
                        {
                            text: '预算执行率',
                            dataIndex: 'executionRate',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        },
                    ]
                },
                {
                    text: '其他费用预算执行',
                    columns:[
                        {
                            text: '预算金额',
                            dataIndex: 'budgetAmount1',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        },
                        {
                            text: '执行金额',
                            dataIndex: 'executionAmount1',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        },
                        {
                            text: '预算执行率',
                            dataIndex: 'executionRate1',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                if(value){
                                    metaData.tdAttr = " data-qtip = '" + value + "'";
                                }
                                return value;
                            }
                        }
                    ]
                }
            ],
            tbar: [
                {
                    text: '导出',
                    iconCls: 'icon icon-excelExport',
                    //disabled: !isEditable(maintenance_bom_node),
                    handler: function () {
                        var ctProjectBudgetGrid = Ext.getCmp('ctProjectBudgetGrid');
                        let data = ctProjectBudgetGrid.getStore().data;
                        if(!data || data.length == 0){
                            Ext.Msg.alert("提示", "请先搜索查询出数据再导出！");
                            return;
                        }
                        // 获取XMLHttpRequest
                        var xmlHttpRequest = new XMLHttpRequest();
                        //  发起请求
                        xmlHttpRequest.open("POST", '/Windchill/ptc1/finance/exportProjectBudgetReportData', true);
                        // 设置请求头类型
                        xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
                        xmlHttpRequest.responseType = "blob";
                        //增加遮罩
                        var loadMarsk = new Ext.LoadMask({
                            msg: '导出中，请稍等......',
                            target: ctProjectBudgetGrid,
                            removeMask: true // 完成后移除
                        });
                        loadMarsk.show();
                        //  返回
                        xmlHttpRequest.onload = function (oEvent) {
                            var content = xmlHttpRequest.response;
                            if (content.type == 'application/json') {
                                content.text().then(res => {
                                    alert(Ext.decode(res).message)
                                })
                            } else {
                                var timestamp =new Date().getTime();
                                // 组装a标签
                                var elink = document.createElement("a");
                                // 设置下载文件名
                                var fileNamePrefix = '项目群预算执行报表';
                                elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
                                elink.style.display = "none";
                                var blob = new Blob([content]);
                                elink.href = URL.createObjectURL(blob);
                                document.body.appendChild(elink);
                                elink.click();
                                document.body.removeChild(elink);
                            }
                            loadMarsk.hide();
                        };
                        let newData = [];
                        let items = data.items;
                        for(let i = 0;i < items.length;i++){
                            newData[i] = items[i].data;
                        }
                        xmlHttpRequest.send(JSON.stringify(newData));
                    },
                    scope: this
                }
            ]
        });
        //======================  userResourceGrid End  ======================//

        ////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '查询条件',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 10 20',
                            labelWidth: 60
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                fieldLabel: '项目名称',
                                width: 200,
                                id: 'projectName',
                                name: 'projectName'
                            },
                            {
                                xtype: 'combo',
                                fieldLabel: '产品线',
                                width: 200,
                                id: 'productLine',
                                name: 'productLine',
                                enableKeyEvents: true,
                                store: {data: [{productLine: '火灾报警系统产品'}, {productLine: '电气火灾监控系统&消防设备电源监控系统产品'}
                                        , {productLine: '消防电气监控系统产品'}
                                        , {productLine: '防火门监控系统产品'}, {productLine: '消防应急照明和疏散指示系统产品'}
                                , {productLine: '海外火灾报警系统产品'}, {productLine: '城市更新SDT产品'}
                                        , {productLine: '储能SDT产品'}, {productLine: '工业SDT产品'}
                                        , {productLine: '外购品产品管理团队'}, {productLine: 'TDT'},
                                        {productLine: '研发其他'}, {productLine: '工业消防报警系统产品'}
                                        ]}, // 下拉框的选项数据
                                editable: false, // 设置为不可编辑
                                valueField: 'productLine',
                                displayField: 'productLine'
                            },
                            {
                                xtype: 'datefield',
                                fieldLabel: '项目实际开始时间',
                                name: 'projectPlan_startTime',
                                id: 'projectPlan_startTime',
                                labelWidth: 110,
                                width: 220
                            },
                            {border: false, margin: '10 0 10 0', html: '<span>至</span>'},
                            {
                                xtype: 'datefield',
                                name: 'projectPlan_endTime',
                                id: 'projectPlan_endTime',
                                labelWidth: 0,
                                width: 110
                            },
                            {
                                xtype: 'datefield',
                                fieldLabel: '项目实际结束时间',
                                name: 'projectActual_startTime',
                                id: 'projectActual_startTime',
                                labelWidth: 110,
                                width: 220
                            },
                            {border: false, margin: '10 0 10 0', html: '<span>至</span>'},
                            {
                                xtype: 'datefield',
                                name: 'projectActual_endTime',
                                id: 'projectActual_endTime',
                                labelWidth: 0,
                                width: 110
                            },
                            {
                                xtype: 'button',
                                text: '搜索',
                                width: 60,
                                scope: this,
                                handler: function () {
                                    var projectName = Ext.getCmp('projectName').getValue();
                                    var productLine = Ext.getCmp('productLine').getValue();
                                    var projectPlan_startTime = Ext.getCmp('projectPlan_startTime').getValue();
                                    var projectPlan_endTime = Ext.getCmp('projectPlan_endTime').getValue();
                                    var projectActual_startTime = Ext.getCmp('projectActual_startTime').getValue();
                                    var projectActual_endTime = Ext.getCmp('projectActual_endTime').getValue();
                                    if(!projectName && !productLine && !projectPlan_startTime && !projectPlan_endTime
                                        && !projectActual_startTime && !projectActual_endTime){
                                        Ext.Msg.alert('提示', '请填入查询条件！');
                                        return;
                                    }
                                    Ext.getStore('ctProjectBudgetStore').reload({
                                        params: {
                                            projectName: projectName,
                                            productLine: productLine,
                                            startTime1: projectPlan_startTime,
                                            startTime2: projectPlan_endTime,
                                            endTime1: projectActual_startTime,
                                            endTime2: projectActual_endTime
                                        }
                                    });
                                }
                            },
                            {
                                xtype: 'button',
                                width: 60,
                                text: '清空',
                                scope: this,
                                handler: function () {
                                    let projectName = Ext.getCmp('projectName');
                                    if(projectName){
                                        projectName.reset();
                                    }
                                    let productLine = Ext.getCmp('productLine');
                                    if(productLine){
                                        productLine.reset();
                                    }
                                    let projectPlan_startTime = Ext.getCmp('projectPlan_startTime');
                                    if(projectPlan_startTime){
                                        projectPlan_startTime.reset();
                                    }
                                    let projectPlan_endTime = Ext.getCmp('projectPlan_endTime');
                                    if(projectPlan_endTime){
                                        projectPlan_endTime.reset();
                                    }
                                    let projectActual_startTime = Ext.getCmp('projectActual_startTime');
                                    if(projectActual_startTime){
                                        projectActual_startTime.reset();
                                    }
                                    let projectActual_endTime = Ext.getCmp('projectActual_endTime');
                                    if(projectActual_endTime){
                                        projectActual_endTime.reset();
                                    }
                                    let grid = Ext.getCmp('ctProjectBudgetGrid');
                                    grid.getStore().loadData([],false);
                                }
                            }
                        ]
                    }
                ]
            },
            ctProjectBudgetGrid
        ];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});


