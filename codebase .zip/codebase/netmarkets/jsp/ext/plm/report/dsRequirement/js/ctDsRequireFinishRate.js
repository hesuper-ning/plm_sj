Ext.define('PLM.view.DSRequireFinishRateInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.DSRequireFinishRateInfo',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'DSRequireFinishRateInfo',
    initComponent: function () {
        Ext.define('DSRequireFinishRateListModel', {
            extend: 'Ext.data.Model',
            fields: [
                 'id','projectNumber','projectName','projectState','projectLines','dsDomain',
                 'dsTotalCount','dsFinishCount','dsFinishRate','dsInTimeFinishCount',
                 'dsInTimeFinishRate','green','yellow','red','greenRatio'
            ],
            idProperty: 'DSRequireFinishRateListModel'
        });

        // 查询 Store
        var DSRequireFinishRateListStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'DSRequireFinishRateListModel',
            id:'DSRequireFinishRateListStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
            	url: '/Windchill/ptc1/reportForms/getDsSecRequireFinishRate',
                method:'POST',
                timeout: 9000000,
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'DSRequireFinishRateListModel',
                    messageProperty: 'massage'
                }
            }),
            autoLoad:false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var dSRequireFinishRateListGrid = Ext.create('Ext.grid.Panel', {
            plugins: cellEditing,
            store:DSRequireFinishRateListStore,
            autoWidth : true,
            autoScroll:true,
            height:500,
            viewConfig:{enableTextSelection:true, forceFit : false},
            columns: [
                      new Ext.grid.RowNumberer({
                          align:"center",
                          width : 50,
                          renderer:function(value, metaData, record, rowIdx, colIdx, store) {
                              return rowIdx + 1;
                          }
                      }),
                      { text: 'id',dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
                      { text: '项目编码',dataIndex: 'projectNumber',width:100 ,menuDisabled:true,renderer:showTip},
                      { text: '项目名称',dataIndex: 'projectName',width:260 ,menuDisabled:true,renderer:showTip},
                      { text: '项目状态',dataIndex: 'projectState',width:100 ,menuDisabled:true,renderer:showTip},
                      { text: '产品线',dataIndex: 'projectLines',width:200 ,menuDisabled:true,renderer:showTip},
                      { text: 'DS领域',dataIndex: 'dsDomain',width:150 ,menuDisabled:true,summaryType: 'count',
                          summaryRenderer: function(value){
                              return Ext.String.format('共 {0} 条数据', value);
                          }
                      },{
                          text: '<b>项目交付统计</b>',
                          columns: [
                              { text: '项目DS总数',dataIndex: 'dsTotalCount',width:100 ,menuDisabled:true},
                              { text: '项目DS交付数',dataIndex: 'dsFinishCount',width:100 ,menuDisabled:true},
                              { text: '项目DS交付率',dataIndex: 'dsFinishRate',width:100 ,menuDisabled:true},
                              { text: '项目DS及时交付数',dataIndex: 'dsInTimeFinishCount',width:100 ,menuDisabled:true},
                              { text: '项目DS及时交付率',dataIndex: 'dsInTimeFinishRate',width:100 ,menuDisabled:true}
                          ],
                          menuDisabled:true
                      },{
                          text: '<b>需求质量状态</b>',
                          columns: [
                              { text: '绿灯',dataIndex: 'green',width:80 ,menuDisabled:true},
                              { text: '黄灯',dataIndex: 'yellow',width:80 ,menuDisabled:true},
                              { text: '红灯',dataIndex: 'red',width:80 ,menuDisabled:true},
                              { text: '绿灯比例',dataIndex: 'greenRatio',width:160 ,menuDisabled:true}
                          ],
                          menuDisabled:true
                      }
                  ]
        });





// ========================Items Area======================//

        this.items=[
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">查询条件</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100,
                    border: false,
                    anchor: '99%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                    xtype: 'panel',
                    defaults: {margin: '5 10 10 0', labelWidth: 70},
                    items: [
						{
						    xtype: 'textfield',
						    fieldLabel: '项目编码',
						    name: 'projectNumber',
						    id: 'projectNumber',
						    width: 250,
						    enableKeyEvents: true
						},{
						    xtype: 'textfield',
						    fieldLabel: '项目名称',
						    name: 'projectName',
						    id: 'projectName',
						    width: 250,
						    enableKeyEvents: true
						}, 
                        {
                            xtype:projectStatus,
                            width: 250,
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '产品线',
                            name: 'productLine',
                            id: 'productLine',
                            width: 250,
                            enableKeyEvents: true
                        }
                    ]
                },{
                    xtype: 'panel',
                    defaults: {margin: '5 10 10 0', labelWidth: 70},
                    items: [
						{
						    xtype: 'datefield',
						    id: 'actualBBeginTime',
						    name:'actualBBeginTime',
						    fieldLabel: '项目实际开始时间从',
						    margin: '0 2 0 0',
						    format:'Y-m-d',
						    allowBlank: false
						},
						{
						    xtype: 'datefield',
						    id: 'actualBEndTime',
						    name:'actualBEndTime',
						    format:'Y-m-d',
						    fieldLabel: '到',
						    allowBlank: false
						},
                        {
                            xtype: 'datefield',
                            id: 'actualEBeginTime',
                            name:'actualEBeginTime',
                            fieldLabel: '项目实际结束时间从',
                            margin: '0 2 0 0',
                            format:'Y-m-d',
                            allowBlank: false
                        },
                        {
                            xtype: 'datefield',
                            id: 'actualEEndTime',
                            name:'actualEEndTime',
                            format:'Y-m-d',
                            fieldLabel: '到',
                            allowBlank: false
                        }
                    ]
                }, {
                    xtype: 'panel',
                    defaults: {margin: '5 20 10 0', labelWidth: 70},
                    items: [
                    {
                        xtype:'button',
                        // margin:'10 0 10 0',
                        width:70,
                        text: '查询',
                        scope:this,
                        iconCls: 'icon icon-search',
                        handler: function() {
                        	doSearch2();
                        }
                    },
                    {
                        xtype: 'button',
                        text: '导出为Excel文件',
                        id:'materialSubstitutionReportExport',
                        iconCls: 'icon icon-exportExcel',
                        handler: function () {
                        	var projectNumber = Ext.getCmp('projectNumber').getValue();
                        	var projectName = Ext.getCmp('projectName').getValue();
                        	var projectStatus = Ext.getCmp('projectStatus').getValue();
                        	var productLine = Ext.getCmp('productLine').getValue();

                        	var actualBBeginTimeDt = Ext.getCmp('actualBBeginTime').getValue();
                        	var actualBEndTimeDt = Ext.getCmp('actualBEndTime').getValue();
                        	var actualEBeginTimeDt = Ext.getCmp('actualEBeginTime').getValue();
                        	var actualEEndTimeDt = Ext.getCmp('actualEEndTime').getValue();
                        	var actualBBeginTime = "";
                        	if(actualBBeginTimeDt){
                        		actualBBeginTime = Ext.util.Format.date(new Date(actualBBeginTimeDt),'Y-m-d');
                        	}
                        	var actualBEndTime = "";
                        	if(actualBEndTimeDt){
                        		actualBEndTime = Ext.util.Format.date(new Date(actualBEndTimeDt),'Y-m-d');
                        	}
                        	var actualEBeginTime = "";
                        	if(actualEBeginTimeDt){
                        		actualEBeginTime = Ext.util.Format.date(new Date(actualEBeginTimeDt),'Y-m-d');
                        	}
                        	var actualEEndTime = "";
                        	if(actualEEndTimeDt){
                        		actualEEndTime = Ext.util.Format.date(new Date(actualEEndTimeDt),'Y-m-d');
                        	}
                            window.location.href = '/Windchill/ptc1/reportForms/ctDsSecRequireFinishRatetExport?projectStatus=' + projectStatus +'&productLine='+productLine
                            +'&actualBBeginTime='+actualBBeginTime+'&actualBEndTime='+actualBEndTime
                            +'&actualEBeginTime='+actualEBeginTime+'&actualEEndTime='+actualEEndTime
                            +'&projectNumber='+projectNumber+'&projectName='+projectName;
                        },
                        scope: this
                    }]
                }]
            },
            dSRequireFinishRateListGrid];
        this.callParent();

    },// ~End of initComponent
});

/**
 * 按查询参数查询
 */
function doSearch2() {
	var projectNumber = Ext.getCmp('projectNumber').getValue();
	var projectName = Ext.getCmp('projectName').getValue();
	var projectStatus = Ext.getCmp('projectStatus').getValue();
	var productLine = Ext.getCmp('productLine').getValue();

	var actualBBeginTimeDt = Ext.getCmp('actualBBeginTime').getValue();
	var actualBEndTimeDt = Ext.getCmp('actualBEndTime').getValue();
	var actualEBeginTimeDt = Ext.getCmp('actualEBeginTime').getValue();
	var actualEEndTimeDt = Ext.getCmp('actualEEndTime').getValue();
	var actualBBeginTime = "";
	if(actualBBeginTimeDt){
		actualBBeginTime = Ext.util.Format.date(new Date(actualBBeginTimeDt),'Y-m-d');
	}
	var actualBEndTime = "";
	if(actualBEndTimeDt){
		actualBEndTime = Ext.util.Format.date(new Date(actualBEndTimeDt),'Y-m-d');
	}
	var actualEBeginTime = "";
	if(actualEBeginTimeDt){
		actualEBeginTime = Ext.util.Format.date(new Date(actualEBeginTimeDt),'Y-m-d');
	}
	var actualEEndTime = "";
	if(actualEEndTimeDt){
		actualEEndTime = Ext.util.Format.date(new Date(actualEEndTimeDt),'Y-m-d');
	}
	Ext.getStore('DSRequireFinishRateListStore').load({
		params : {
			projectNumber : projectNumber,
			projectName : projectName,
			projectStatus : projectStatus,
			productLine : productLine,
			actualBBeginTime : actualBBeginTime,
			actualBEndTime:actualBEndTime,
			actualEBeginTime : actualEBeginTime,
			actualEEndTime : actualEEndTime
			
		},
		callback : function(records, operation, success) {
			if (!success) {
				var responseText = operation.getResponse().responseText;
				var responseObject = Ext.decode(responseText);
				alert(responseObject.message);
				// alert('查询信息失败，请联系管理员！');
			}
		}
	});
}
//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}
var projectStatus = new Ext.form.field.ComboBox({
    multiSelect: false,
    anyMatch: true,
    editable : true,
    fieldLabel: '项目状态',
    margin: '0 5 0 0',
//    labelWidth: 135,
//   width: 315,
    // forceSelection: true, //forceSelection 是否能够手填
    id: 'projectStatus',
    name: 'projectStatus',
    mode: 'local',
    store: new Ext.data.ArrayStore({
        id: 0,
        fields: [
            'key',
            'displayText'
        ],
        data: [["已暂停", "已暂停"],["已定义", "已定义"]
        ,["正在运行", "正在运行"],["已取消", "已取消"]
        ,["已完成", "已完成"]]
//        data: [["SUSPENDED", "已暂停"],["DEFINED", "已定义"]
//            ,["RUNNING", "正在运行"],["CANCELLED", "已取消"]
//            ,["COMPLETED", "已完成"]]
    }),
    valueField: 'key',
    displayField: 'displayText',
});