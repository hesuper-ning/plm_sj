Ext.define('PLM.view.CtDsRequirement', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtDsRequirement',
    border: false,
    autoScroll: true,
    autoWidth: true,
    height: 588,
    collapsible: false,
    id: 'CtDsRequirement',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        xtype:'tabpanel',
                        id: 'dsRequirementTabPanel',
                        activeTab: 0,
                        items:[
                            {
                                title: '<font style="font-size:12px">项目群需求统计</font>',
                                xtype: 'dsRequireSummaryInfo'
                            }
                            ,
                            {
                                scrollable: true,
                                title: '<font style="font-size:12px">领域需求完成率</font>',
                                xtype:'DSRequireFinishRateInfo'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">个人需求完成率</font>',
                                xtype:'dsPersonalRequireReportInfo'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">项目群需求结构树</font>',
                                xtype:'DSRequireTreeInfo'
                            }
                        ]//~End of tabpanel items
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    }
});