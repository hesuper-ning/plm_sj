<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>

<meta http-equiv="Content-Type" charset="UTF-8" content="text/html">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
	<link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
	<script type="text/javascript" src="js/ctDsRequirement.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctDsRequireFinishRate.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctDsPersonalRequireRate.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctDsRequireTree.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctDsRequireSummary.js?_dc=<%=System.currentTimeMillis()%>"></script> 
</head>

<body>
<!-- <script>
// ==============layout define area=================================//
Ext.onReady(function() {
	Ext.QuickTips.init();

	Ext.util.CSS.createStyleSheet(".normal-certificate-btn { background-color: #d0d0d0; color: #000; border-color: #000; }", "normal-certificate-btn-style");

	Ext.create('Ext.container.Viewport', {
		layout: 'border',
		width: "100%",
		height: '1400px',
		items: [ {
			region: 'center',
			// items:[{
			//     xtype:'panel',
			//     scrollable: true,CtCertificationServiceImpl
			//     border:false,
			items:[
				{
					region: 'center',
					xtype: 'CtDsRequirement',
				}
			]
			//}]//~End of center region items
		}]//~End of viewPort items
	});
});
</script> -->
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'CtDsRequirement'
            }]
        });
    });
</script>
</body>
</html>