Ext.define('PLM.view.DSRequireTreeInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.DSRequireTreeInfo',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'DSRequireTreeInfo',
    initComponent: function () {
        Ext.define('DSrequireTreeModel', {
            extend: 'Ext.data.Model',
            fields: [
                 'id','projectNumber','projectName','projectState','projectLines',
                 'requireType','number','requireTitle','dsRequireDesc','dsRequireRemark','dsComponent',
                 'dsDomain','dsPriority','dsImportance','isSelfVerify','dsSelfVerifyReportNumber','dsSelfVerifyReportDocOid',
                 'rdPersonLiable','rdPlanTime','rdProgress','rdRemark','rdActualTime','implementConfirm','implementConfirmRemark',
                 'caPersonLiable','caPlanTime','caProgress','isTestCase','dsTestCaseNumber','dsTestCaseDocOid','caActualTime','qualityState','testRemark','problemNumber'
             
            ],
            idProperty: 'DSrequireTreeModel'
        });

        // 查询 Store
        var DSRequireTreeStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'DSrequireTreeModel',
            id:'DSRequireTreeStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
            	url: '/Windchill/ptc1/reportForms/getDsForRequireTree',
                method:'POST',
                timeout: 90000000,
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'DSrequireTreeModel',
                    messageProperty: 'massage'
                }
            }),
            autoLoad:false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var dSRequireFinishRateListGrid = Ext.create('Ext.grid.Panel', {
            plugins: cellEditing,
            store:DSRequireTreeStore,
            autoWidth : true,
            autoScroll:true,
            height:500,
            viewConfig:{enableTextSelection:true, forceFit : false},
            columns: [
                      new Ext.grid.RowNumberer({
                          align:"center",
                          width : 50,
                          renderer:function(value, metaData, record, rowIdx, colIdx, store) {
                              return rowIdx + 1;
                          }
                      }),
                      { text: 'id',dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
                      { text: '项目编码',dataIndex: 'projectNumber',width:100 ,menuDisabled:true,renderer:showTip},
                      { text: '项目名称',dataIndex: 'projectName',width:260 ,menuDisabled:true,renderer:showTip},
                      { text: '项目状态',dataIndex: 'projectState',width:100 ,menuDisabled:true,renderer:showTip},
                      { text: '产品线',dataIndex: 'projectLines',width:200 ,menuDisabled:true,renderer:showTip},
                      { text: '类型',dataIndex: 'requireType',width:50 ,menuDisabled:true},
                      { text: '编号',dataIndex: 'number',width:130 ,menuDisabled:true,summaryType: 'count',
                          summaryRenderer: function(value){
                              return Ext.String.format('共 {0} 条数据', value);
                          }},
                      { text: '需求标题',dataIndex: 'requireTitle',width:150 ,menuDisabled:true},
                      { text: 'DS需求描述',	dataIndex: 'dsRequireDesc',width:100 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      },
                      { text: 'DS需求备注说明',	dataIndex: 'dsRequireRemark',width:150 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      },
                      { text: 'DS构件', dataIndex: 'dsComponent',width:100 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      },
                      { text: 'DS领域',dataIndex: 'dsDomain',width:100,renderer: function(value,metaData,record,row,col,store){
                              //
                              return value;
                          },menuDisabled:true
                      },
                      { text: 'DS优先级',dataIndex: 'dsPriority',width:100 ,renderer: function(value,metaData,record,row,col,store){
                              //
                              return value;
                          },menuDisabled:true
                      },
                      { text: 'DS重要性',dataIndex: 'dsImportance',width:100 ,renderer: function(value,metaData,record,row,col,store){
                              //
                              return value;
                          },menuDisabled:true
                      },
                      { text: '是否自验报告',dataIndex: 'isSelfVerify',width:120 ,renderer: function(value,metaData,record,row,col,store){
                              if(value=="Y") {
                                  value="是";
                              }else if(value=="N") {
                                  value="否";
                              }
                              return value;
                          },menuDisabled:true
                      },
                      { text: 'DS自验报告文档编号',dataIndex: 'dsSelfVerifyReportNumber',width:200 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              if(value) {
                                  var docLink = "<a href='" + urlPathPrefix +record.get('dsSelfVerifyReportDocOid') +"' target='_blank' >"
                                      + value + "</a>";
                                  return docLink;
                              }else {
                                  return value;
                              }
                          },editor:'textfield'},
                      { text: '研发责任人',dataIndex: 'rdPersonLiable',width:100 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      },
                      { text: '研发计划时间',dataIndex: 'rdPlanTime',width:120 ,menuDisabled:true,renderer:selfDateFormat},
                      { text: '研发进度',dataIndex: 'rdProgress',width:85 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value==0&&record.get('qualityState')=="") {
                                  value ="";
                              }
                              return value;
                          }
                      },
                      { text: '研发备注',	dataIndex: 'rdRemark',width:100 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      },
                      { text: '研发实际时间',dataIndex: 'rdActualTime',width:120 ,menuDisabled:true,
                          renderer: selfDateFormat

                      },
                      { text: '需求实现确认（SE）',dataIndex: 'implementConfirm',width:150 ,menuDisabled:true
                      },
                      { text: '需求实现确认备注（SE）',dataIndex: 'implementConfirmRemark',width:200 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      },
                      { text: '测试验收责任人',dataIndex: 'caPersonLiable',width:150 ,menuDisabled:true},
                      { text: '测试验收计划时间',dataIndex: 'caPlanTime',width:180 ,menuDisabled:true,renderer:selfDateFormat},
                      { text: '测试验收进度',dataIndex: 'caProgress',width:120 ,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value==0) {
                                  value ="";
                              }
                              return value;
                          },menuDisabled:true},
                      { text: '是否有对应测试用例',dataIndex: 'isTestCase',width:200 ,renderer: function(value,metaData,record,row,col,store){
                              if(value=="Y") {
                                  value="是";
                              }else if(value=="N") {
                                  value="否";
                              }
                              return value;
                          },menuDisabled:true
                      },
                      { text: 'DS测试用例文档编号',dataIndex: 'dsTestCaseNumber',width:200 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';

                              if(value) {
                                  var docLink = "<a href='" + urlPathPrefix +record.get('dsTestCaseDocOid') +"' target='_blank' >"
                                      + value + "</a>";
                                  return docLink;
                              }else {
                                  return value;
                              }
                          },editor:'textfield'},
                      { text: '验收实际时间',dataIndex: 'caActualTime',width:120 ,menuDisabled:true,
                          renderer: selfDateFormat
                      },
                      { text: '质量状态',dataIndex: 'qualityState',width:80 ,renderer: function(value,metaData,record,row,col,store){

                              metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode("<font color='green'>绿（测试通过）</font><br><font color='yellow'> 黄（有条件测试通过）</font><br> <font color='red'> 红（测试未通过）</font>") + '"';

                              if("红"==value) {
                                  var img = "<img src='" + imagePath +"red_16x16.gif'>";
                                  return img;
                              }else if("黄"==value) {
                                  var img = "<img src='" + imagePath +"yellow_16x16.gif'>";
                                  return img;
                              }else if("绿"==value) {
                                  var img = "<img src='" + imagePath +"green_16x16.gif'>";
                                  return img;
                              }else {
                                  return '';
                              }
                          },menuDisabled:true
                      },
                      { text: '测试备注',dataIndex: 'testRemark',width:100 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      },
                      { text: '转问题编号',dataIndex: 'problemNumber',width:100 ,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      }
                  ]
        });





// ========================Items Area======================//

        this.items=[
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">查询条件</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100,
                    border: false,
                    anchor: '99%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                    xtype: 'panel',
                    defaults: {margin: '5 10 10 0', labelWidth: 70},
                    items: [
						{
						    xtype: 'textfield',
						    fieldLabel: '项目编码',
						    name: 'projectNumber4',
						    id: 'projectNumber4',
						    width: 250,
						    enableKeyEvents: true
						},{
						    xtype: 'textfield',
						    fieldLabel: '项目名称',
						    name: 'projectName4',
						    id: 'projectName4',
						    width: 250,
						    enableKeyEvents: true
						},    
                        {
                            xtype:projectStatus4,
                            width: 250,
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '产品线',
                            name: 'productLine4',
                            id: 'productLine4',
                            width: 250,
                            enableKeyEvents: true
                        }
                    ]
                },{
                    xtype: 'panel',
                    defaults: {margin: '5 10 10 0', labelWidth: 70},
                    items: [
						{
						    xtype: 'datefield',
						    id: 'actualBBeginTime4',
						    name:'actualBBeginTime4',
						    fieldLabel: '项目实际开始时间从',
						    margin: '0 2 0 0',
						    format:'Y-m-d',
						    allowBlank: false
						},
						{
						    xtype: 'datefield',
						    id: 'actualBEndTime4',
						    name:'actualBEndTime4',
						    format:'Y-m-d',
						    fieldLabel: '到',
						    allowBlank: false
						},
                        {
                            xtype: 'datefield',
                            id: 'actualEBeginTime4',
                            name:'actualEBeginTime4',
                            fieldLabel: '项目实际结束时间从',
                            margin: '0 2 0 0',
                            format:'Y-m-d',
                            allowBlank: false
                        },
                        {
                            xtype: 'datefield',
                            id: 'actualEEndTime4',
                            name:'actualEEndTime4',
                            format:'Y-m-d',
                            fieldLabel: '到',
                            allowBlank: false
                        }
                    ]
                }, {
                    xtype: 'panel',
                    defaults: {margin: '5 20 10 0', labelWidth: 70},
                    items: [
                    {
                        xtype:'button',
                        // margin:'10 0 10 0',
                        width:70,
                        text: '查询',
                        scope:this,
                        iconCls: 'icon icon-search',
                        handler: function() {
                            doSearch4();
                        }
                    },
                    {
                        xtype: 'button',
                        text: '导出为Excel文件',
                        id:'requireTreeReportExport',
                        iconCls: 'icon icon-exportExcel',
                        handler: function () {
                    	    var projectNumber = Ext.getCmp('projectNumber4').getValue();
                    		var projectName = Ext.getCmp('projectName4').getValue();
                    		var projectStatus = Ext.getCmp('projectStatus4').getValue();
                    		var productLine = Ext.getCmp('productLine4').getValue();

                    		var actualBBeginTimeDt = Ext.getCmp('actualBBeginTime').getValue();
                    		var actualBEndTimeDt = Ext.getCmp('actualBEndTime').getValue();
                    		var actualEBeginTimeDt = Ext.getCmp('actualEBeginTime').getValue();
                    		var actualEEndTimeDt = Ext.getCmp('actualEEndTime').getValue();
                    		var actualBBeginTime = "";
                    		if(actualBBeginTimeDt){
                    			actualBBeginTime = Ext.util.Format.date(new Date(actualBBeginTimeDt),'Y-m-d');
                    		}
                    		var actualBEndTime = "";
                    		if(actualBEndTimeDt){
                    			actualBEndTime = Ext.util.Format.date(new Date(actualBEndTimeDt),'Y-m-d');
                    		}
                    		var actualEBeginTime = "";
                    		if(actualEBeginTimeDt){
                    			actualEBeginTime = Ext.util.Format.date(new Date(actualEBeginTimeDt),'Y-m-d');
                    		}
                    		var actualEEndTime = "";
                    		if(actualEEndTimeDt){
                    			actualEEndTime = Ext.util.Format.date(new Date(actualEEndTimeDt),'Y-m-d');
                    		}
                            window.location.href = '/Windchill/ptc1/reportForms/ctDsForExportRequireTree?projectStatus=' + projectStatus +'&productLine='+productLine
                            +'&actualBBeginTime='+actualBBeginTime+'&actualBEndTime='+actualBEndTime
                            +'&actualEBeginTime='+actualEBeginTime+'&actualEEndTime='+actualEEndTime
                            +'&projectNumber='+projectNumber+'&projectName='+projectName;
                        },
                        scope: this
                    }]
                }]
            },
            dSRequireFinishRateListGrid];
        this.callParent();

    },// ~End of initComponent
});

/**
 * 按查询参数查询
 */
function doSearch4() {
    var projectNumber = Ext.getCmp('projectNumber4').getValue();
	var projectName = Ext.getCmp('projectName4').getValue();
	var projectStatus = Ext.getCmp('projectStatus4').getValue();
	var productLine = Ext.getCmp('productLine4').getValue();

	var actualBBeginTimeDt = Ext.getCmp('actualBBeginTime').getValue();
	var actualBEndTimeDt = Ext.getCmp('actualBEndTime').getValue();
	var actualEBeginTimeDt = Ext.getCmp('actualEBeginTime').getValue();
	var actualEEndTimeDt = Ext.getCmp('actualEEndTime').getValue();
	var actualBBeginTime = "";
	if(actualBBeginTimeDt){
		actualBBeginTime = Ext.util.Format.date(new Date(actualBBeginTimeDt),'Y-m-d');
	}
	var actualBEndTime = "";
	if(actualBEndTimeDt){
		actualBEndTime = Ext.util.Format.date(new Date(actualBEndTimeDt),'Y-m-d');
	}
	var actualEBeginTime = "";
	if(actualEBeginTimeDt){
		actualEBeginTime = Ext.util.Format.date(new Date(actualEBeginTimeDt),'Y-m-d');
	}
	var actualEEndTime = "";
	if(actualEEndTimeDt){
		actualEEndTime = Ext.util.Format.date(new Date(actualEEndTimeDt),'Y-m-d');
	}
	Ext.getStore('DSRequireTreeStore').load({
		params : {
			projectNumber : projectNumber,
			projectName : projectName,
			projectStatus : projectStatus,
			productLine : productLine,
			actualBBeginTime : actualBBeginTime,
			actualBEndTime:actualBEndTime,
			actualEBeginTime : actualEBeginTime,
			actualEEndTime : actualEEndTime
			
		},
		callback : function(records, operation, success) {
			if (!success) {
				var responseText = operation.getResponse().responseText;
				var responseObject = Ext.decode(responseText);
				alert(responseObject.message);
				// alert('查询信息失败，请联系管理员！');
			}
		}
	});
}
//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}
//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}
var projectStatus4 = new Ext.form.field.ComboBox({
    multiSelect: false,
    anyMatch: true,
    editable : true,
    fieldLabel: '项目状态',
    margin: '0 5 0 0',
//    labelWidth: 135,
//   width: 315,
    // forceSelection: true, //forceSelection 是否能够手填
    id: 'projectStatus4',
    name: 'projectStatus4',
    mode: 'local',
    store: new Ext.data.ArrayStore({
        id: 0,
        fields: [
            'key',
            'displayText'
        ],
        data: [["已暂停", "已暂停"],["已定义", "已定义"]
        ,["正在运行", "正在运行"],["已取消", "已取消"]
        ,["已完成", "已完成"]]
//        data: [["SUSPENDED", "已暂停"],["DEFINED", "已定义"]
//            ,["RUNNING", "正在运行"],["CANCELLED", "已取消"]
//            ,["COMPLETED", "已完成"]]
    }),
    valueField: 'key',
    displayField: 'displayText',
});