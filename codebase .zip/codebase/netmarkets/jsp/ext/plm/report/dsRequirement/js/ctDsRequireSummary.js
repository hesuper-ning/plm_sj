Ext.define('PLM.view.dsRequireSummaryInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.dsRequireSummaryInfo',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'dsRequireSummaryInfo',
    initComponent: function () {
        Ext.define('dsRequireSummaryModel', {
            extend: 'Ext.data.Model',
            fields: [
                 'id','projectNumber','projectName','projectState','projectLines',
                 'branchId','projectNumber','projectName','dsRequireDocNumber','dsTotalCount','dsFinishCount','dsFinishRate',
                 'dsInTimeFinishCount','dsInTimeFinishRate','green','yellow','red','greenRatio',
                 'problemCount','changeCount','planChangeCount'
            ],
            idProperty: 'dsRequireSummaryModel'
        });

        // 查询 Store
        var dsRequireSummaryReportStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'dsRequireSummaryModel',
            id:'dsRequireSummaryReportStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
            	url: '/Windchill/ptc1/reportForms/getDsOneRequireSummary',
                method:'POST',
                timeout: 9000000,
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'dsRequireSummaryModel',
                    messageProperty: 'massage'
                }
            }),
            autoLoad:false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var dSRequireFinishRateListGrid = Ext.create('Ext.grid.Panel', {
            plugins: cellEditing,
            store:dsRequireSummaryReportStore,
            autoWidth : true,
            autoScroll:true,
            height:500,
            viewConfig:{enableTextSelection:true, forceFit : false},
            columns: [
                      { text:'序号', xtype:'rownumberer', width:60,menuDisabled:true },
                      {text:'branchId',dataIndex:'branchId',hidden: true},
                      { text: '项目编号',  dataIndex: 'projectNumber',width:100,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              var projectLink =  record.get('projectLink');
                              if(projectLink)return projectLink;
                              return value;
                          }
                      },
                      { text: '项目名称',  dataIndex: 'projectName',width:200,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              if(value)
                                  metaData.tdAttr = 'data-qtip="' + value +'"';
                              return value;
                          }
                      },
                      {text:'项目状态',dataIndex:'projectState',width:100,menuDisabled:true},
                      {text:'产品线',dataIndex:'projectLines',width:200,menuDisabled:true,renderer:showTip },
                      { text: '需求矩阵文档',  dataIndex: 'dsRequireDocNumber',width:150,menuDisabled:true,
                          renderer: function(value,metaData,record,row,col,store){
                              var dsRequireDocLink =  record.get('dsRequireDocLink');
                              if(dsRequireDocLink)return dsRequireDocLink;
                              return value;
                          }
                      },
                      {
                          text: '<b>项目交付统计</b>',
                          columns: [
                              { text: '项目DS总数',dataIndex: 'dsTotalCount',width:100 ,menuDisabled:true},
                              { text: '项目DS交付数',dataIndex: 'dsFinishCount',width:100 ,menuDisabled:true},
                              { text: '项目DS交付完成率',dataIndex: 'dsFinishRate',width:100 ,menuDisabled:true},
                              { text: '项目DS及时交付数',dataIndex: 'dsInTimeFinishCount',width:100 ,menuDisabled:true},
                              { text: '项目DS及时交付率',dataIndex: 'dsInTimeFinishRate',width:100 ,menuDisabled:true}
                          ],
                          menuDisabled:true
                      },{
                          text: '<b>需求质量状态</b>',
                          columns: [
                              { text: '绿灯',dataIndex: 'green',width:50 ,menuDisabled:true},
                              { text: '黄灯',dataIndex: 'yellow',width:50 ,menuDisabled:true},
                              { text: '红灯',dataIndex: 'red',width:50 ,menuDisabled:true},
                              { text: '绿灯比例',dataIndex: 'greenRatio',width:90 ,menuDisabled:true}
                          ],
                          menuDisabled:true
                      },
                      {text:'转问题数量',dataIndex:'problemCount',width:100,menuDisabled:true},
                      {text:'需求变更次数',dataIndex:'changeCount',width:100,menuDisabled:true},
                      {text:'需求计划调整次数',dataIndex:'planChangeCount',width:100,menuDisabled:true}
                  ]
        });





// ========================Items Area======================//

        this.items=[
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">查询条件</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100,
                    border: false,
                    anchor: '99%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                    xtype: 'panel',
                    defaults: {margin: '5 10 10 0', labelWidth: 70},
                    items: [
						{
						    xtype: 'textfield',
						    fieldLabel: '项目编码',
						    name: 'projectNumber1',
						    id: 'projectNumber1',
						    width: 250,
						    enableKeyEvents: true
						},{
						    xtype: 'textfield',
						    fieldLabel: '项目名称',
						    name: 'projectName1',
						    id: 'projectName1',
						    width: 250,
						    enableKeyEvents: true
						},     
                        {
                            xtype:projectStatus1,
                            width: 250,
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '产品线',
                            name: 'productLine1',
                            id: 'productLine1',
                            width: 250,
                            enableKeyEvents: true
                        }
                    ]
                },{
                    xtype: 'panel',
                    defaults: {margin: '5 10 10 0', labelWidth: 70},
                    items: [
						{
						    xtype: 'datefield',
						    id: 'actualBBeginTime1',
						    name:'actualBBeginTime1',
						    fieldLabel: '项目实际开始时间从',
						    margin: '0 2 0 0',
						    format:'Y-m-d',
						    allowBlank: false
						},
						{
						    xtype: 'datefield',
						    id: 'actualBEndTime1',
						    name:'actualBEndTime1',
						    format:'Y-m-d',
						    fieldLabel: '到',
						    allowBlank: false
						},
                        {
                            xtype: 'datefield',
                            id: 'actualEBeginTime1',
                            name:'actualEBeginTime1',
                            fieldLabel: '项目实际结束时间从',
                            margin: '0 2 0 0',
                            format:'Y-m-d',
                            allowBlank: false
                        },
                        {
                            xtype: 'datefield',
                            id: 'actualEEndTime1',
                            name:'actualEEndTime1',
                            format:'Y-m-d',
                            fieldLabel: '到',
                            allowBlank: false
                        }
                    ]
                }, {
                    xtype: 'panel',
                    defaults: {margin: '5 20 10 0', labelWidth: 70},
                    items: [
                    {
                        xtype:'button',
                        // margin:'10 0 10 0',
                        width:70,
                        text: '查询',
                        scope:this,
                        iconCls: 'icon icon-search',
                        handler: function() {
                            doSearch1();
                        }
                    },
                    {
                        xtype: 'button',
                        text: '导出为Excel文件',
                        id:'dsRequireSummaryReportExport',
                        iconCls: 'icon icon-exportExcel',
                        handler: function () {
                        	var projectNumber = Ext.getCmp('projectNumber1').getValue();
                        	var projectName = Ext.getCmp('projectName1').getValue();
                        	var projectStatus = Ext.getCmp('projectStatus1').getValue();
                        	var productLine = Ext.getCmp('productLine1').getValue();

                        	var actualBBeginTimeDt = Ext.getCmp('actualBBeginTime1').getValue();
                        	var actualBEndTimeDt = Ext.getCmp('actualBEndTime1').getValue();
                        	var actualEBeginTimeDt = Ext.getCmp('actualEBeginTime1').getValue();
                        	var actualEEndTimeDt = Ext.getCmp('actualEEndTime1').getValue();
                        	var actualBBeginTime = "";
                        	if(actualBBeginTimeDt){
                        		actualBBeginTime = Ext.util.Format.date(new Date(actualBBeginTimeDt),'Y-m-d');
                        	}
                        	var actualBEndTime = "";
                        	if(actualBEndTimeDt){
                        		actualBEndTime = Ext.util.Format.date(new Date(actualBEndTimeDt),'Y-m-d');
                        	}
                        	var actualEBeginTime = "";
                        	if(actualEBeginTimeDt){
                        		actualEBeginTime = Ext.util.Format.date(new Date(actualEBeginTimeDt),'Y-m-d');
                        	}
                        	var actualEEndTime = "";
                        	if(actualEEndTimeDt){
                        		actualEEndTime = Ext.util.Format.date(new Date(actualEEndTimeDt),'Y-m-d');
                        	}
                            window.location.href = '/Windchill/ptc1/reportForms/ctDsOneRequireSummaryExport?projectStatus=' + projectStatus +'&productLine='+productLine
                            +'&actualBBeginTime='+actualBBeginTime+'&actualBEndTime='+actualBEndTime
                            +'&actualEBeginTime='+actualEBeginTime+'&actualEEndTime='+actualEEndTime
                            +'&projectNumber='+projectNumber+'&projectName='+projectName;
                        },
                        scope: this
                    }]
                }]
            },
            dSRequireFinishRateListGrid];
        this.callParent();

    },// ~End of initComponent
});

/**
 * 按查询参数查询
 */
function doSearch1() {
	var projectNumber = Ext.getCmp('projectNumber1').getValue();
	var projectName = Ext.getCmp('projectName1').getValue();
	var projectStatus = Ext.getCmp('projectStatus1').getValue();
	var productLine = Ext.getCmp('productLine1').getValue();

	var actualBBeginTimeDt = Ext.getCmp('actualBBeginTime1').getValue();
	var actualBEndTimeDt = Ext.getCmp('actualBEndTime1').getValue();
	var actualEBeginTimeDt = Ext.getCmp('actualEBeginTime1').getValue();
	var actualEEndTimeDt = Ext.getCmp('actualEEndTime1').getValue();
	var actualBBeginTime = "";
	if(actualBBeginTimeDt){
		actualBBeginTime = Ext.util.Format.date(new Date(actualBBeginTimeDt),'Y-m-d');
	}
	var actualBEndTime = "";
	if(actualBEndTimeDt){
		actualBEndTime = Ext.util.Format.date(new Date(actualBEndTimeDt),'Y-m-d');
	}
	var actualEBeginTime = "";
	if(actualEBeginTimeDt){
		actualEBeginTime = Ext.util.Format.date(new Date(actualEBeginTimeDt),'Y-m-d');
	}
	var actualEEndTime = "";
	if(actualEEndTimeDt){
		actualEEndTime = Ext.util.Format.date(new Date(actualEEndTimeDt),'Y-m-d');
	}
	Ext.getStore('dsRequireSummaryReportStore').load({
		params : {
			projectNumber : projectNumber,
			projectName : projectName,
			projectStatus : projectStatus,
			productLine : productLine,
			actualBBeginTime : actualBBeginTime,
			actualBEndTime:actualBEndTime,
			actualEBeginTime : actualEBeginTime,
			actualEEndTime : actualEEndTime
			
		},
		callback : function(records, operation, success) {
			if (!success) {
				var responseText = operation.getResponse().responseText;
				var responseObject = Ext.decode(responseText);
				alert(responseObject.message);
				// alert('查询信息失败，请联系管理员！');
			}
		}
	});
}
//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}
var projectStatus1 = new Ext.form.field.ComboBox({
    multiSelect: false,
    anyMatch: true,
    editable : true,
    fieldLabel: '项目状态',
    margin: '0 5 0 0',
//    labelWidth: 135,
//   width: 315,
    // forceSelection: true, //forceSelection 是否能够手填
    id: 'projectStatus1',
    name: 'projectStatus1',
    mode: 'local',
    store: new Ext.data.ArrayStore({
        id: 0,
        fields: [
            'key',
            'displayText'
        ],
        data: [["已暂停", "已暂停"],["已定义", "已定义"]
        ,["正在运行", "正在运行"],["已取消", "已取消"]
        ,["已完成", "已完成"]]
//        data: [["SUSPENDED", "已暂停"],["DEFINED", "已定义"]
//            ,["RUNNING", "正在运行"],["CANCELLED", "已取消"]
//            ,["COMPLETED", "已完成"]]
    }),
    valueField: 'key',
    displayField: 'displayText',
});