Ext.define('PLM.view.ctIpdUnProgressDeviationRateInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctIpdUnProgressDeviationRateInfo',
//    title: '<font style="font-size:15px">筛选视图</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ctIpdUnProgressDeviationRateInfo',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //树的列模型
        Ext.define('ctIpdUnProgressDeviationRateModel', {
            extend: 'Ext.data.Model',
            fields: ['ymShow','belongingtoYear','belongingtoMouth','productLine','projectNumber','projectName',
                     'relatedMile','executeStatus','pdcpPlannedTime','mileStoneNameEnd','planCompleteTimeEnd',
                'actualCompleteTimeEnd','mileStoneNameIng','planCompleteTimeIng','deviationRate',
                'costAmount','costweight','weightDeviationRate'],
            idProperty: 'partPath'
        });

        var ctIpdUnProgressDeviationRateStore = Ext.create('Ext.data.TreeStore', {
            id: 'ctIpdUnProgressDeviationRateStore',
            model: 'ctIpdUnProgressDeviationRateModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/reportForms/getIpdCompUnDeviationRateReport',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json'
                }
            }),
            root: {
                expanded: true
            },
            listeners: {
                beforeload: function (store, opts) {
                    let data = {
                        oid: '',
                        type: '',
                        state: '',
                        commonParam: ''
                    };
                    Ext.apply(store.proxy.extraParams, data);
                }
            },
            autoLoad: false,
            folderSort: true
        });

        var ctIpdUnProgressDeviationRateGrid = Ext.create('Ext.tree.Panel', {
            store: ctIpdUnProgressDeviationRateStore,
            // 隐藏默认的根节点
            //renderTo: Ext.getBody(),
            rootVisible: false,
            height: 800,
            autoWidth: true,
            expanded: true,
            border: 0,
            id: 'ctIpdUnProgressDeviationRateGrid',
            autoScroll: true,
            //plugins: [cellEditing],
            viewConfig: {enableTextSelection: true},
            // width:1180,
            // selModel: Ext.create('Ext.selection.CheckboxModel', {
            //             //     mode: "SIMPLE",
            //             //     showHeaderCheckbox: true,
            //             //     checkOnly: true,
            //             //     listeners: {
            //             //         beforeselect: function (obj, record, index) {
            //             //             if (record.get('purchaseType') !== 'F') {
            //             //                 return false;
            //             //             }
            //             //         }
            //             //     }
            //             // }),
            // bodyStyle : 'overflow-x:scroll;
            // overflow-y:scroll',
            //title: '库存列表',
            columns: [
                {
                    text: '年',
                    width: 180,
                    dataIndex: 'ymShow',
                    xtype: 'treecolumn',
                    menuDisabled: true,
                    sortable: false,
                    renderer:function(value,record){
                    	
                    	return value;
                    }
                },
                { text: '产品线',dataIndex: 'productLine',width:200 ,menuDisabled:true,renderer:showTip},
                { text: '项目编码',dataIndex: 'projectNumber',width:100 ,menuDisabled:true,renderer:showTip},
                { text: '项目名称',dataIndex: 'projectName',width:250 ,menuDisabled:true,renderer:showTip},
                { text: '已投入资金',dataIndex: 'costAmount',width:100 ,menuDisabled:true,renderer:showTip},
                { text: '已投入资金权重',dataIndex: 'costweight',width:100 ,menuDisabled:true,renderer:showTip},
                { text: '加权偏差率',dataIndex: 'weightDeviationRate',width:100 ,menuDisabled:true,renderer:showTip},
                { text: '相关里程碑',dataIndex: 'relatedMile',width:100 ,menuDisabled:true,renderer:showTip},
                { text: '相关里程碑执行状况',dataIndex: 'executeStatus',width:100 ,menuDisabled:true,renderer:showTip},
                {
                    text: '<b>相关数据</b>',
                    columns: [
						{ text: 'PDCP计划时间',dataIndex: 'pdcpPlannedTime',width:110 ,menuDisabled:true,renderer:showTip},
						{
	                          text: '<b>当月完成里程碑</b>',
	                          columns: [
								{ text: '里程碑名称',dataIndex: 'mileStoneNameEnd',width:110 ,menuDisabled:true,renderer:showTip},
								{ text: '计划完成时间',dataIndex: 'planCompleteTimeEnd',width:110 ,menuDisabled:true,renderer:showTip},
								{ text: '实际完成时间',dataIndex: 'actualCompleteTimeEnd',width:110 ,menuDisabled:true,renderer:showTip}
	                                    ],
	                          menuDisabled:true
	                      },
	                      {
	                          text: '<b>当月进行中里程碑</b>',
	                          columns: [
								{ text: '里程碑名称',dataIndex: 'mileStoneNameIng',width:110 ,menuDisabled:true,renderer:showTip},
								{ text: '计划完成时间',dataIndex: 'planCompleteTimeIng',width:110 ,menuDisabled:true,renderer:showTip}
								     ],
	                          menuDisabled:true
	                      },
						{ text: '偏差率',dataIndex: 'deviationRate',width:110 ,menuDisabled:true,renderer:showTip}
                         
                ]}
	                      ],
            //tbar: [
                // {
                //     text: '查询',
                //     iconCls: 'icon icon-search',
                //     handler: function () {
                //         var bomNum = Ext.getCmp('partListCombo2').getValue();
                //         var setNum = Ext.getCmp('setNum').getValue();
                //         var division = Ext.getCmp('division').getValue();
                //         if (bomNum == null || bomNum === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         if (setNum == null || setNum === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         if (division == null || division === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         //getBomInventoryInfo(bomNum, setNum, division);
                //     }
                // }
            //],
            listeners: {
                afterrender: function (t) {
                    // //选择器， 为所有表格添加
                    // var selector = ".x-column-header";
                    // //选择器， 可以为指定的表格添加头部样式内容需要添加id属性，例如id为 firstGrid 那选择器的值如下：
                    // //var selector = "#firstGrid-bodyWrap .x-column-header"
                    // var elments = Ext.select(selector, true);
                    // elments.each(function (el) {
                    //     el.setStyle("font-size", '5px');
                    //     el.setStyle("line-height", '5px');
                    // }, this);
                }
            }
        });

        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">搜索条件</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 0 20',
                            labelWidth: 50
                        },
                        items: [
							{
							    xtype: 'combobox',
							    fieldLabel: '类型',
							    name: 'prjjtype2',
							    id: 'prjjtype2',
							    margin: '0 10 5 0',
							    labelWidth: 60,
							    width: 300,
							    value:'VR',
							    enableKeyEvents: true,
							    store: ['VR', 'C'], // 下拉框的选项数据
							    queryMode: 'local', // 查询模式
							    editable: false // 设置为不可编辑
							},    
							{
	                            xtype: 'datefield',
	                            id: 'belongingtoYear2',
	                            name:'belongingtoYear2',
	                            fieldLabel: '所属年',
	                            margin: '0 5 0 0',
	                            format:'Y',
	                            labelWidth: 60,
							    width: 300,
	                            allowBlank: false
	                        },
	                        {
	                            xtype: 'datefield',
	                            id: 'belongingtoMouth2',
	                            name:'belongingtoMouth2',
	                            fieldLabel: '所属月',
	                            margin: '0 5 0 0',
	                            format:'m',
	                            labelWidth: 60,
							    width: 300,
	                            allowBlank: false
	                        }
                        ]
                    },{
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 0 20',
                            labelWidth: 50
                        },
                        items: [
							{
							    xtype: 'textfield',
							    margin: '0 10 5 0',
							    fieldLabel: '产品线',
							    id: 'productLine2',
							    name: 'productLine2',
							    labelWidth: 60,
							    width: 300
							},
                            {
                                xtype: 'textfield',
                                margin: '0 10 5 0',
                                fieldLabel: '项目编码',
                                id: 'projectNumber2',
                                name: 'projectNumber2',
                                labelWidth: 60,
                                width: 300
                            },
                            {
                                xtype: 'textfield',
                                margin: '0 10 5 0',
                                fieldLabel: '项目名称',
                                id: 'projectName2',
                                name: 'projectName2',
                                labelWidth: 60,
                                width: 300
                            },
                            {
                                xtype: 'button',
                                margin: '0 10 5 0',
                                width: 50,
                                text: '搜索',
                                scope: this,
                                handler: function () {
                                	doSearch2();
                                }
                            },
                            {
                                xtype: 'button',
                                margin: '0 10 5 0',
                                text: '导出',
                                id:'materialSubstitutionReportExport2',
                                iconCls: 'icon icon-exportExcel',
                                handler: function () {
                                	var prjjtype2Q = Ext.getCmp('prjjtype2').getValue();
                                	var belongingtoYearQ = Ext.getCmp('belongingtoYear2').getValue();
                                	var belongingtoMouthQ = Ext.getCmp('belongingtoMouth2').getValue();
                                	var productLineQ = Ext.getCmp('productLine2').getValue();
                                	var projectNumberQ = Ext.getCmp('projectNumber2').getValue();
                                	var projectNameQ = Ext.getCmp('projectName2').getValue();
                                	
                                	var belongingtoYear = "";
                                	if(belongingtoYearQ){
                                		belongingtoYear = Ext.util.Format.date(new Date(belongingtoYearQ),'Y');
                                	}
                                	var belongingtoMouth = "";
                                	if(belongingtoMouthQ){
                                		belongingtoMouth = Ext.util.Format.date(new Date(belongingtoMouthQ),'m');
                                	}
                                    window.location.href = '/Windchill/ptc1/reportForms/exportIpdDeviationRateReport?prjtype=' + prjjtype2Q +'&belongingtoYear='+belongingtoYear
                                    +'&belongingtoMouth='+belongingtoMouth+'&productLine='+productLineQ
                                    +'&projectNumber='+projectNumberQ+'&projectName='+projectNameQ+'&ipdType=un';
                                },
                                scope: this
                            }
                        ]
                    }
                ]
            },
            ctIpdUnProgressDeviationRateGrid
        ];
        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});
/**
 * 按查询参数查询
 */
function doSearch2() {
	var prjjtype2Q = Ext.getCmp('prjjtype2').getValue();
	var belongingtoYearQ = Ext.getCmp('belongingtoYear2').getValue();
	var belongingtoMouthQ = Ext.getCmp('belongingtoMouth2').getValue();
	var productLineQ = Ext.getCmp('productLine2').getValue();
	var projectNumberQ = Ext.getCmp('projectNumber2').getValue();
	var projectNameQ = Ext.getCmp('projectName2').getValue();
	
	var belongingtoYear = "";
	if(belongingtoYearQ){
		belongingtoYear = Ext.util.Format.date(new Date(belongingtoYearQ),'Y');
	}
	var belongingtoMouth = "";
	if(belongingtoMouthQ){
		belongingtoMouth = Ext.util.Format.date(new Date(belongingtoMouthQ),'m');
	}
	Ext.getStore('ctIpdUnProgressDeviationRateStore').load({
		params : {
			// data: Ext.encode(data)
			ipdType : "un",
			prjtype : prjjtype2Q,
			belongingtoYear : belongingtoYear,
			belongingtoMouth : belongingtoMouth,
			productLine : productLineQ,
			projectNumber:projectNumberQ,
			projectName : projectNameQ
		},
		callback : function(records, operation, success) {
			if (!success) {
				var responseText = operation.getResponse().responseText;
				var responseObject = Ext.decode(responseText);
				alert(responseObject.message);
				// alert('查询信息失败，请联系管理员！');
			}
		}
	});
}

