Ext.define('PLM.view.ctIpdUnAccumulateInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctIpdUnAccumulateInfo',
//    title: '<font style="font-size:15px">筛选视图</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ctIpdUnAccumulateInfo',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //树的列模型
        Ext.define('ctIpdUnAccumulateModel', {
            extend: 'Ext.data.Model',
            fields: ['ymShow','belongingtoYear','belongingtoMouth','productLine','projectNumber','projectName','allIPDPocessCompliance','avelFileScoreRate','avelKeyDeliverableRateScore','avelKeyDeEffectivenessEvaluation',
                'avelKeyDeTimelinessScore','totalScoreDeductPoints','totalScoreBonusPoints'],
            idProperty: 'partPath'
        });

        var ctIpdUnAccumulateStore = Ext.create('Ext.data.TreeStore', {
            id: 'ctIpdUnAccumulateStore',
            model: 'ctIpdUnAccumulateModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/reportForms/getIpdCompUnAccumulate',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json'
                }
            }),
            root: {
                expanded: true
            },
            listeners: {
                beforeload: function (store, opts) {
                    let data = {
                        oid: '',
                        type: '',
                        state: '',
                        commonParam: ''
                    };
                    Ext.apply(store.proxy.extraParams, data);
                }
            },
            autoLoad: false,
            folderSort: true
        });

        var ctIpdUnAccumulateGrid = Ext.create('Ext.tree.Panel', {
            store: ctIpdUnAccumulateStore,
            // 隐藏默认的根节点
            //renderTo: Ext.getBody(),
            rootVisible: false,
            height: 800,
            autoWidth: true,
            expanded: true,
            border: 0,
            id: 'ctIpdUnAccumulateGrid',
            autoScroll: true,
            //plugins: [cellEditing],
            viewConfig: {enableTextSelection: true},
            // width:1180,
            // selModel: Ext.create('Ext.selection.CheckboxModel', {
            //             //     mode: "SIMPLE",
            //             //     showHeaderCheckbox: true,
            //             //     checkOnly: true,
            //             //     listeners: {
            //             //         beforeselect: function (obj, record, index) {
            //             //             if (record.get('purchaseType') !== 'F') {
            //             //                 return false;
            //             //             }
            //             //         }
            //             //     }
            //             // }),
            // bodyStyle : 'overflow-x:scroll;
            // overflow-y:scroll',
            //title: '库存列表',
            columns: [
                /*     {text: '序号', width: 50, align: 'center', menuDisabled: true, xtype: 'rownumberer', sortable: false},*/
                /*{
                    text: '路径',
                    width: 50,
                    align: 'center',
                    menuDisabled: true,
                    dataIndex: 'partPath',
                    sortable: false,
                    hidden: true
                },
                {
                    text: 'branchId',
                    width: 1,
                    dataIndex: 'partBranchId',
                    sortable: false,
                    menuDisabled: true,
                    hidden: true
                },*/
//                {text: '目标对象', width: 80, dataIndex: 'targetObject', menuDisabled: true, sortable: false},
               {text: 'nian', width: 10, dataIndex: 'belongingtoYear',hidden: true},
               {text: 'yue', width: 10, dataIndex: 'belongingtoMouth',hidden: true},
               
                {
                    text: '年',
                    width: 180,
                    dataIndex: 'ymShow',
                    xtype: 'treecolumn',
                    menuDisabled: true,
                    sortable: false,
                    renderer:function(value,record){
                    	
                    	return value;
                    }
                },
                {text: '产品线', width: 300, dataIndex: 'productLine', menuDisabled: true, sortable: false},
                {text: '项目编码', width: 100, dataIndex: 'projectNumber', menuDisabled: true, sortable: false},
                {text: '项目名称', width: 120, dataIndex: 'projectName', menuDisabled: true, sortable: false},
                {text: 'IPD流程符合度', width: 80, dataIndex: 'allIPDPocessCompliance', menuDisabled: true, sortable: false},
                {text: '文件提交率', width: 80, dataIndex: 'avelFileScoreRate', menuDisabled: true, sortable: false},
                {text: '关键交付件评审率得分', width: 80, dataIndex: 'avelKeyDeliverableRateScore', menuDisabled: true, sortable: false},
                {text: '关键交付物评审有效性评价', width: 180, dataIndex: 'avelKeyDeEffectivenessEvaluation', menuDisabled: true, sortable: false},
                {text: '关键交付件交付及时性得分', width: 300, dataIndex: 'avelKeyDeTimelinessScore', menuDisabled: true, sortable: false},
                {text: '不符合项扣分', width: 80, dataIndex: 'totalScoreDeductPoints', menuDisabled: true, sortable: false},
                {text: '加分项', width: 80, dataIndex: 'totalScoreBonusPoints', menuDisabled: true, sortable: false}
                
            ],
            //tbar: [
                // {
                //     text: '查询',
                //     iconCls: 'icon icon-search',
                //     handler: function () {
                //         var bomNum = Ext.getCmp('partListCombo2').getValue();
                //         var setNum = Ext.getCmp('setNum').getValue();
                //         var division = Ext.getCmp('division').getValue();
                //         if (bomNum == null || bomNum === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         if (setNum == null || setNum === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         if (division == null || division === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         //getBomInventoryInfo(bomNum, setNum, division);
                //     }
                // }
            //],
            listeners: {
            	rowclick: function (view, record, item, index, e) {
                    var headerCt = view.getHeaderCt(); // 获取列头组件
                    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
                    var cellIndex = cell.cellIndex; // 获取单元格的索引
//                    var partNumber = record.get('projectNumber');
                    // 通过单元格索引获取列
                    var column = headerCt.getGridColumns()[cellIndex + 2];
                    if (column) {
                        var columnName = column.dataIndex;
                        if(columnName == 'projectNumber'){
                        	allprojectNumber = record.get("projectNumber");
                        	var yer = record.get("belongingtoYear");
                        	var moth = record.get("belongingtoMouth");
                        	currentMonth = (yer+"-"+moth);
                         	transferProblemWindow.show();
                 			loadBasisFormData(allprojectNumber);
                        }
                    }
                },
                afterrender: function (t) {
                    // //选择器， 为所有表格添加
                    // var selector = ".x-column-header";
                    // //选择器， 可以为指定的表格添加头部样式内容需要添加id属性，例如id为 firstGrid 那选择器的值如下：
                    // //var selector = "#firstGrid-bodyWrap .x-column-header"
                    // var elments = Ext.select(selector, true);
                    // elments.each(function (el) {
                    //     el.setStyle("font-size", '5px');
                    //     el.setStyle("line-height", '5px');
                    // }, this);
                }
            }
        });

        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">搜索条件</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 0 20',
                            labelWidth: 50
                        },
                        items: [
							{
							    xtype: 'combobox',
							    fieldLabel: '类型',
							    name: 'prjjtype',
							    id: 'prjjtype',
							    margin: '0 10 5 0',
							    labelWidth: 60,
							    width: 300,
							    value:'VR',
							    enableKeyEvents: true,
							    store: ['VR', 'C'], // 下拉框的选项数据
							    queryMode: 'local', // 查询模式
							    editable: false // 设置为不可编辑
							},    
							{
	                            xtype: 'datefield',
	                            id: 'belongingtoYear',
	                            name:'belongingtoYear',
	                            fieldLabel: '所属年',
	                            margin: '0 5 0 0',
	                            format:'Y',
	                            labelWidth: 60,
							    width: 300,
	                            allowBlank: false
	                        },
	                        {
	                            xtype: 'datefield',
	                            id: 'belongingtoMouth',
	                            name:'belongingtoMouth',
	                            fieldLabel: '所属月',
	                            margin: '0 5 0 0',
	                            format:'m',
	                            labelWidth: 60,
							    width: 300,
	                            allowBlank: false
	                        }
                        ]
                    },{
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 0 20',
                            labelWidth: 50
                        },
                        items: [
							{
							    xtype: 'textfield',
							    margin: '0 10 5 0',
							    fieldLabel: '产品线',
							    id: 'productLine',
							    name: 'productLine',
							    labelWidth: 60,
							    width: 300
							},
                            {
                                xtype: 'textfield',
                                margin: '0 10 5 0',
                                fieldLabel: '项目编码',
                                id: 'projectNumber',
                                name: 'projectNumber',
                                labelWidth: 60,
                                width: 300
                            },
                            {
                                xtype: 'textfield',
                                margin: '0 10 5 0',
                                fieldLabel: '项目名称',
                                id: 'projectName',
                                name: 'projectName',
                                labelWidth: 60,
                                width: 300
                            },
                            {
                                xtype: 'button',
                                margin: '0 10 5 0',
                                width: 50,
                                text: '搜索',
                                scope: this,
                                handler: function () {
                                	doSearch();
                                }
                            },
                            {
                                xtype: 'button',
                                margin: '0 10 5 0',
                                text: '导出',
                                id:'materialSubstitutionReportExport',
                                iconCls: 'icon icon-exportExcel',
                                handler: function () {
                                	var prjjtypeQ = Ext.getCmp('prjjtype').getValue();
                                	var belongingtoYearQ = Ext.getCmp('belongingtoYear').getValue();
                                	var belongingtoMouthQ = Ext.getCmp('belongingtoMouth').getValue();
                                	var productLineQ = Ext.getCmp('productLine').getValue();
                                	var projectNumberQ = Ext.getCmp('projectNumber').getValue();
                                	var projectNameQ = Ext.getCmp('projectName').getValue();
                                	
                                	var belongingtoYear = "";
                                	if(belongingtoYearQ){
                                		belongingtoYear = Ext.util.Format.date(new Date(belongingtoYearQ),'Y');
                                	}
                                	var belongingtoMouth = "";
                                	if(belongingtoMouthQ){
                                		belongingtoMouth = Ext.util.Format.date(new Date(belongingtoMouthQ),'m');
                                	}
                                	
                                    window.location.href = '/Windchill/ptc1/reportForms/exportIpdCompUnAccumulateReport?prjtype=' + prjjtypeQ +'&belongingtoYear='+belongingtoYear
                                    +'&belongingtoMouth='+belongingtoMouth+'&productLine='+productLineQ
                                    +'&projectNumber='+projectNumberQ+'&projectName='+projectNameQ+'&ipdType=un';
                                },
                                scope: this
                            }
                        ]
                    }
                ]
            },
            ctIpdUnAccumulateGrid
        ];
        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});
/**
 * 按查询参数查询
 */
function doSearch() {
	var prjjtypeQ = Ext.getCmp('prjjtype').getValue();
	var belongingtoYearQ = Ext.getCmp('belongingtoYear').getValue();
	var belongingtoMouthQ = Ext.getCmp('belongingtoMouth').getValue();
	var productLineQ = Ext.getCmp('productLine').getValue();
	var projectNumberQ = Ext.getCmp('projectNumber').getValue();
	var projectNameQ = Ext.getCmp('projectName').getValue();
	
	var belongingtoYear = "";
	if(belongingtoYearQ){
		belongingtoYear = Ext.util.Format.date(new Date(belongingtoYearQ),'Y');
	}
	var belongingtoMouth = "";
	if(belongingtoMouthQ){
		belongingtoMouth = Ext.util.Format.date(new Date(belongingtoMouthQ),'m');
	}
	Ext.getStore('ctIpdUnAccumulateStore').load({
		params : {
			// data: Ext.encode(data)
			ipdType : "un",
			prjtype : prjjtypeQ,
			belongingtoYear : belongingtoYear,
			belongingtoMouth : belongingtoMouth,
			productLine : productLineQ,
			projectNumber:projectNumberQ,
			projectName : projectNameQ
		},
		callback : function(records, operation, success) {
			if (!success) {
				var responseText = operation.getResponse().responseText;
				var responseObject = Ext.decode(responseText);
				alert(responseObject.message);
				// alert('查询信息失败，请联系管理员！');
			}
		}
	});
}

