Ext.define('PLM.view.CtIpdCompliance', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtIpdCompliance',
    border: false,
    autoScroll: true,
    autoWidth: true,
    height: 588,
    collapsible: false,
    id: 'CtIpdCompliance',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        xtype:'tabpanel',
                        id: 'ctIpdComplianceTabPanel',
                        activeTab: 0,
                        items:[
                            {
                                title: '<font style="font-size:12px">IPD流程符合度(不累积)</font>',
                                xtype: 'ctIpdUnAccumulateInfo'
                            }
                            ,
                            {
                                scrollable: true,
                                title: '<font style="font-size:12px">IPD流程符合度(累积)</font>',
                                xtype:'ctIpdCompAllAccumulateInfo'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">进度偏差率(不累积)</font>',
                                xtype:'ctIpdUnProgressDeviationRateInfo'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">进度偏差率(累积)</font>',
                                xtype:'ctIpdAllProgressDeviationRateInfo'
                            }
                        ]//~End of tabpanel items
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    }
});