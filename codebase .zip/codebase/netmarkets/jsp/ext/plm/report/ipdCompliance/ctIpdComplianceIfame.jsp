<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>


<!-- <iframe id="ctDsRequirementIfame" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"
        src="netmarkets/jsp/ext/plm/report/dsRequirement/ctDsRequirementReport.jsp?" style="width:99%;height:550px" ></iframe>

<script type="text/javascript">
    var iframe = document.getElementById("ctDsRequirementIfame");
    iframe.style.height = window.innerHeight*98/100 + 'px';
</script> -->

<iframe id="ctIpdComplianceIfame" src="netmarkets/jsp/ext/plm/report/ipdCompliance/ctIpdComplianceReport.jsp" style="width:98%;height:600px" ></iframe>
