Ext.define('PLM.view.CtCertificate', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtCertificate',
    border: false,
    autoScroll: true,
    autoWidth: true,
    height: 588,
    collapsible: false,
    id: 'CtCertificate',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        xtype:'tabpanel',
                        id: 'certificateTabPanel',
                        activeTab: 0,
                        items:[
                            {
                                title: '<font style="font-size:12px">型号证书表</font>',
                                xtype: 'CtModelCertificateReport'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">证书注销表</font>',
                                xtype:'CtCertificateRevocationReport'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">型号报告表</font>',
                                xtype:'CtModelReport'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">成品报告表</font>',
                                xtype:'CtFinishedProductReport'
                            }
                        ]//~End of tabpanel items
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    }
});