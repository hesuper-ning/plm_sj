Ext.define('PLM.view.CtCertificateRevocationReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtCertificateRevocationReport',
    title: '证书注销表',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtCertificateRevocationReport',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        Ext.define('certificateRevocationModel', {
            extend: 'Ext.data.Model',
            fields: ['docNumber', 'productName', 'productModel', 'certificateNumber', 'logoutDate', 'cancelResume', 'certificationType'
            ,'identificationnumber','manufacturingenterprise','productstandards'],
            idProperty: 'id'
        });

        var certificateRevocationStore = Ext.create('Ext.data.Store', {
            model: 'certificateRevocationModel',
            id: 'certificateRevocationStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ext/plm/report/doc/certificateReport/getCancellationData',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    totalProperty:'totalCount',
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var certificateRevocationGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.getStore('certificateRevocationStore'),
            id: 'certificateRevocationGrid',
            title: '查询结果',
            width: '98%',
            autoScroll: true,
            height: 460,
            viewConfig: { enableTextSelection: true },
            collapsible: true,
            columns: [
                {xtype: 'rownumberer', text: '序号', width: 50, align: 'center'},
                {
                    text: '文档编号',
                    dataIndex: 'docNumber',
                    flex:1,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        if(r.get('docUrl')) {
                            var docLink = r.get('docUrl');
                            return docLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '产品名称', dataIndex: 'productName', flex:1, menuDisabled: true},
                {text: '产品型号', dataIndex: 'productModel', flex:1, menuDisabled: true},
                {text: '认证类型', dataIndex: 'certificationType', flex:1, menuDisabled: true},
                {text: '证书编号', dataIndex: 'certificateNumber', flex:1, menuDisabled: true},
                {text: '注销日期', dataIndex: 'logoutDate', flex:1, menuDisabled: true},
                {text: '注销履历', dataIndex: 'cancelResume', flex:1, menuDisabled: true},
                {text: '标识编号', dataIndex: 'identificationnumber', flex:1, menuDisabled: true},
                {text: '生产企业', dataIndex: 'manufacturingenterprise', flex:1, menuDisabled: true},
                {text: '产品标准', dataIndex: 'productstandards', flex:1, menuDisabled: true}
            ],
            tbar: [
                {
                    text: '<b>全部</b>',
                    cls: 'normal-certificate-btn',
                    disabled:false,
                    scope: this,
                    handler: function () {
                        Ext.getStore('certificateRevocationStore').reload({
                            params: {}
                        });
                    }
                },
                {
                    text: '导出',
                    iconCls: 'icon icon-excelExport',
                    //disabled: !isEditable(maintenance_bom_node),
                    handler: function () {
                        var certificateRevocationGrid = Ext.getCmp('certificateRevocationGrid');
                        let data = certificateRevocationGrid.getStore().data;
                        if(!data || data.length == 0){
                            Ext.Msg.alert("提示", "请先搜索查询出数据再导出！");
                            return;
                        }

                        // 获取XMLHttpRequest
                        var xmlHttpRequest = new XMLHttpRequest();
                        //  发起请求
                        xmlHttpRequest.open("POST", '/Windchill/ptc1/ext/plm/report/doc/certificateReport/exportCertificateReport?typeName=certificateRevocation', true);
                        // 设置请求头类型
                        xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
                        xmlHttpRequest.responseType = "blob";
                        //增加遮罩
                        var loadMarsk = new Ext.LoadMask({
                            msg: '导出中，请稍等......',
                            target: certificateRevocationGrid,
                            removeMask: true // 完成后移除
                        });
                        loadMarsk.show();
                        //  返回
                        xmlHttpRequest.onload = function (oEvent) {
                            var content = xmlHttpRequest.response;
                            if (content.type == 'application/json') {
                                content.text().then(res => {
                                    alert(Ext.decode(res).message)
                                })
                            } else {
                                var timestamp =new Date().getTime();
                                // 组装a标签
                                var elink = document.createElement("a");
                                // 设置下载文件名
                                var fileNamePrefix = '证书注销表';
                                elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
                                elink.style.display = "none";
                                var blob = new Blob([content]);
                                elink.href = URL.createObjectURL(blob);
                                document.body.appendChild(elink);
                                elink.click();
                                document.body.removeChild(elink);
                            }
                            loadMarsk.hide();
                        };
                        let newData = [];
                        let items = data.items;
                        for(let i = 0;i < items.length;i++){
                            newData[i] = items[i].data;
                        }
                        xmlHttpRequest.send(JSON.stringify(newData));
                    },
                    scope: this
                }
            ]
        });
        //======================  userResourceGrid End  ======================//

        ////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '查询条件',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '5 0 5 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                fieldLabel: '产品型号',
                                width: 230,
                                id: 'productModel_revocationReport',
                                name: 'productModel_revocationReport'
                            },
                            {
                                xtype: 'button',
                                text: '搜索',
                                width: 70,
                                scope: this,
                                handler: function () {
                                    var productModel = Ext.getCmp('productModel_revocationReport').getValue();
                                    if(!productModel){
                                        Ext.Msg.alert('提示', '请填入查询条件！');
                                        return;
                                    }
                                    Ext.getStore('certificateRevocationStore').load({
                                        params: {
                                            productModel: productModel
                                        }
                                    });
                                }
                            },
                            {
                                xtype: 'button',
                                width: 70,
                                text: '清空',
                                scope: this,
                                handler: function () {
                                    let productModel = Ext.getCmp('productModel_revocationReport');
                                    productModel.reset();
                                    let certificateRevocationGrid = Ext.getCmp('certificateRevocationGrid');
                                    certificateRevocationGrid.getStore().loadData([],false);
                                }
                            }
                        ]
                    }
                ]
            },
            certificateRevocationGrid
        ];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});


