Ext.define('PLM.view.CtModelCertificateReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtModelCertificateReport',
    title: '型号证书表',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    height: 600,
    collapsible: false,
    id: 'CtModelCertificateReport',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        Ext.define('ctModelCertificateModel', {
            extend: 'Ext.data.Model',
            fields: ['docNumber'
                , 'creationTime', 'modificationTime', 'productName', 'productModel',
                'certificationType', 'certificateNumber', 'firstIssuanceDate', 'obtainingCertificateDate', 'certificateExpirationDate',
                'identityInformationType', 'certificationMark', 'certificateStatus', 'whetherCancel', 'logoutDate',
                'cancelResume', 'approvalDocumentNumber', 'changeHistory', 'inspectionReport','inspectionPartNumber'
                ,'identificationnumber','manufacturingenterprise','productstandards'
            ],
            idProperty: 'id'
        });

        var ctModelCertificateStore = Ext.create('Ext.data.Store', {
            model: 'ctModelCertificateModel',
            id: 'ctModelCertificateStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ext/plm/report/doc/certificateReport/modelCertificateReport',
                method: 'GET',
                extraParams:{

                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var ctModelCertificateGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.getStore('ctModelCertificateStore'),
            id: 'ctModelCertificateGrid',
            title: '查询结果',
            autoScroll: true,
            height: 405,
            collapsible: false,
            viewConfig: { enableTextSelection: true },
            columns: [
                {xtype: 'rownumberer', text: '序号', width: 50, align: 'center'},
                {
                    text: '文档编号',
                    dataIndex: 'docNumber',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        if(r.get('docUrl')) {
                            var docLink = r.get('docUrl');
                            return docLink;
                        }else {
                            return value;
                        }
                    }
                },
                {
                    text: '创建时间',
                    dataIndex: 'creationTime',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '修改时间',
                    dataIndex: 'modificationTime',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '产品名称',
                    dataIndex: 'productName',
                    width: 120,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'data-qtip = "'+value+'" style="background-color: ' + color + ';width: 120px;"';
                        }else{
                            meta.tdAttr = 'data-qtip = "'+value+'"';
                        }
                        return value;
                    }
                },
                {
                    text: '产品型号',
                    dataIndex: 'productModel',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '认证类型',
                    dataIndex: 'certificationType',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '证书编号',
                    dataIndex: 'certificateNumber',
                    width: 120,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 120px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '首次发证日期',
                    dataIndex: 'firstIssuanceDate',
                    width: 100,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '获得证书日期',
                    dataIndex: 'obtainingCertificateDate',
                    width: 100,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '证书到期日期',
                    dataIndex: 'certificateExpirationDate',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '身份信息类型',
                    dataIndex: 'identityInformationType',
                    width: 100,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '认证标识',
                    dataIndex: 'certificationMark',
                    width: 120,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 120px;"';
                        }
                        return value;
                    }
                },{
                    text: '标识编号',
                    dataIndex: 'identificationnumber',
                    width: 150,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 150px;"';
                        }
                        return value;
                    }
                },{
                    text: '生产企业',
                    dataIndex: 'manufacturingenterprise',
                    width: 150,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 150px;"';
                        }
                        return value;
                    }
                },{
                    text: '产品标准',
                    dataIndex: 'productstandards',
                    width: 150,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 150px;"';
                        }
                        return value;
                    }
                },{
                    text: '检验报告',
                    dataIndex: 'inspectionReport',
                    width: 300,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'data-qtip = "'+value+'" style="background-color: ' + color + ';width: 300px;"';
                        }else{
                            meta.tdAttr = 'data-qtip = "'+value+'"';
                        }
                        return value;
                    }
                },
                {
                    text: '证书状态',
                    dataIndex: 'certificateStatus',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '是否注销',
                    dataIndex: 'whetherCancel',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '注销日期',
                    dataIndex: 'logoutDate',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '注销履历',
                    dataIndex: 'cancelResume',
                    width: 120,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 120px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '批复文档编号',
                    dataIndex: 'approvalDocumentNumber',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '更改履历',
                    dataIndex: 'changeHistory',
                    width: 300,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'data-qtip = "'+value+'" style="background-color: ' + color + ';width: 300px;"';
                        }else{
                            meta.tdAttr = 'data-qtip = "'+value+'"';
                        }
                        return value;
                    }
                },
                {
                    text: '销服资料物料编码',
                    dataIndex: 'inspectionPartNumber',
                    width: 150,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 150px;"';
                        }
                        return value;
                    }
                }
            ],
            tbar: [
                {
                    text: '<b>生效中</b>',
                    cls: 'normal-certificate-btn',
                    disabled:false,
                    scope: this,
                    handler: function () {
                        Ext.getStore('ctModelCertificateStore').reload({
                            params: {
                                certificateStatus: '生效中'
                            }
                        });
                    }
                },
                {
                    text: '<b>已失效</b>',
                    cls: 'normal-certificate-btn',
                    disabled:false,
                    scope: this,
                    handler: function () {
                        Ext.getStore('ctModelCertificateStore').reload({
                            params: {
                                certificateStatus: '已失效'
                            }
                        });
                    }
                },
                {
                    text: '<b>全部</b>',
                    cls: 'normal-certificate-btn',
                    disabled:false,
                    scope: this,
                    handler: function () {
                        Ext.getStore('ctModelCertificateStore').reload({
                            params: {}
                        });
                    }
                },
                {
                    text: '<b>即将到期</b>',
                    cls: 'normal-certificate-btn',
                    disabled:false,
                    scope: this,
                    handler: function () {
                        Ext.getStore('ctModelCertificateStore').reload({
                            params: {
                                expiration: 'Y'
                            }
                        });
                    }
                },
                {
                    text: '导出',
                    iconCls: 'icon icon-excelExport',
                    //disabled: !isEditable(maintenance_bom_node),
                    handler: function () {
                        var ctModelCertificateGrid = Ext.getCmp('ctModelCertificateGrid');
                        let data = ctModelCertificateGrid.getStore().data;
                        if(!data || data.length == 0){
                            Ext.Msg.alert("提示", "请先搜索查询出数据再导出！");
                            return;
                        }

                        // 获取XMLHttpRequest
                        var xmlHttpRequest = new XMLHttpRequest();
                        //  发起请求
                        xmlHttpRequest.open("POST", '/Windchill/ptc1/ext/plm/report/doc/certificateReport/exportCertificateReport?typeName=modelCertificate', true);
                        // 设置请求头类型
                        xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
                        xmlHttpRequest.responseType = "blob";
                        //增加遮罩
                        var loadMarsk = new Ext.LoadMask({
                            msg: '导出中，请稍等......',
                            target: ctModelCertificateGrid,
                            removeMask: true // 完成后移除
                        });
                        loadMarsk.show();
                        //  返回
                        xmlHttpRequest.onload = function (oEvent) {
                            var content = xmlHttpRequest.response;
                            if (content.type == 'application/json') {
                                content.text().then(res => {
                                    alert(Ext.decode(res).message)
                                })
                            } else {
                                var timestamp =new Date().getTime();
                                // 组装a标签
                                var elink = document.createElement("a");
                                // 设置下载文件名
                                var fileNamePrefix = '型号证书表';
                                elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
                                elink.style.display = "none";
                                var blob = new Blob([content]);
                                elink.href = URL.createObjectURL(blob);
                                document.body.appendChild(elink);
                                elink.click();
                                document.body.removeChild(elink);
                            }
                            loadMarsk.hide();
                        };
                        let newData = [];
                        let items = data.items;
                        for(let i = 0;i < items.length;i++){
                            newData[i] = items[i].data;
                        }
                        xmlHttpRequest.send(JSON.stringify(newData));
                    },
                    scope: this
                }
            ]
        });
        //======================  userResourceGrid End  ======================//

        ////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '查询条件',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 20 10 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                fieldLabel: '产品型号',
                                width: 230,
                                id: 'productModel_certificate',
                                name: 'productModel_certificate'
                            },
                            {
                                xtype: 'datefield',
                                fieldLabel: '创建时间',
                                name: 'creationTimeStart_certificate',
                                id: 'creationTimeStart_certificate',
                                width: 180
                            },
                            {border: false, margin: '10 0 10 0', html: '<span>至</span>'},
                            {
                                xtype: 'datefield',
                                name: 'creationTimeEnd_certificate',
                                id: 'creationTimeEnd_certificate',
                                width: 110
                            },
                            {
                                xtype: 'datefield',
                                fieldLabel: '修改时间',
                                name: 'updateTimeStart_certificate',
                                id: 'updateTimeStart_certificate',
                                width: 180
                            },
                            {border: false, margin: '10 0 10 0', html: '<span>至</span>'},
                            {
                                xtype: 'datefield',
                                name: 'updateTimeEnd_certificate',
                                id: 'updateTimeEnd_certificate',
                                width: 110
                            }
                        ]
                    },
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 20 10 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                fieldLabel: '证书编号',
                                width: 230,
                                id: 'certificateNumber_certificate',
                                name: 'certificateNumber_certificate'
                            },
                            {
                                xtype: 'combo',
                                fieldLabel: '证书状态',
                                width: 230,
                                id: 'certificateStatus_certificate',
                                name: 'certificateStatus_certificate',
                                enableKeyEvents: true,
                                store: {data:[{certificateStatus:'生效中'},{certificateStatus:'已失效'}]}, // 下拉框的选项数据
                                editable: false, // 设置为不可编辑
                                valueField: 'certificateStatus',
                                displayField: 'certificateStatus'
                            },
                            {
                                xtype: 'numberfield',
                                fieldLabel: '证书到期时间(天)',
                                labelWidth: 110,
                                width: 270,
                                id: 'certificateExpirationDate_certificate',
                                name: 'certificateExpirationDate_certificate'
                            },
                            {
                                xtype: 'button',
                                text: '搜索',
                                width: 70,
                                scope: this,
                                handler: function () {
                                    var productModel = Ext.getCmp('productModel_certificate').getValue();
                                    var creationTimeStart = Ext.getCmp('creationTimeStart_certificate').getValue();
                                    var creationTimeEnd = Ext.getCmp('creationTimeEnd_certificate').getValue();
                                    var modificationTimeStart = Ext.getCmp('updateTimeStart_certificate').getValue();
                                    var modificationTimeEnd = Ext.getCmp('updateTimeEnd_certificate').getValue();
                                    var certificateNumber = Ext.getCmp('certificateNumber_certificate').getValue();
                                    var certificateStatus = Ext.getCmp('certificateStatus_certificate').getValue();
                                    var days = Ext.getCmp('certificateExpirationDate_certificate').getValue();
                                    if(!productModel && !creationTimeStart && !creationTimeEnd && !modificationTimeStart
                                        && !modificationTimeEnd && !certificateNumber && (!certificateStatus || certificateStatus.length < 1 ) && !days){
                                        Ext.Msg.alert('提示', '请填入查询条件！');
                                        return;
                                    }
                                    if(days){
                                        if(!Number.isInteger(days) || days <= 0){
                                            Ext.Msg.alert('提示', '【证书到期时间(天)】请填写正整数！');
                                            return;
                                        }
                                    }
                                    Ext.getStore('ctModelCertificateStore').reload({
                                        params: {
                                            productModel: productModel,
                                            creationTimeStart: creationTimeStart,
                                            creationTimeEnd: creationTimeEnd,
                                            modificationTimeStart: modificationTimeStart,
                                            modificationTimeEnd: modificationTimeEnd,
                                            certificateNumber: certificateNumber,
                                            certificateStatus: certificateStatus,
                                            days: days
                                        }
                                    });
                                }
                            },
                            {
                                xtype: 'button',
                                width: 70,
                                text: '清空',
                                scope: this,
                                handler: function () {
                                    let productModel = Ext.getCmp('productModel_certificate');
                                    if(productModel){
                                        productModel.reset();
                                    }
                                    let creationTimeStart = Ext.getCmp('creationTimeStart_certificate');
                                    if(creationTimeStart){
                                        creationTimeStart.reset();
                                    }
                                    let creationTimeEnd = Ext.getCmp('creationTimeEnd_certificate');
                                    if(creationTimeEnd){
                                        creationTimeEnd.reset();
                                    }
                                    let modificationTimeStart = Ext.getCmp('updateTimeStart_certificate');
                                    if(modificationTimeStart){
                                        modificationTimeStart.reset();
                                    }
                                    let modificationTimeEnd = Ext.getCmp('updateTimeEnd_certificate');
                                    if(modificationTimeEnd){
                                        modificationTimeEnd.reset();
                                    }
                                    let certificateNumber = Ext.getCmp('certificateNumber_certificate');
                                    if(certificateNumber){
                                        certificateNumber.reset();
                                    }
                                    let certificateStatus = Ext.getCmp('certificateStatus_certificate');
                                    if(certificateStatus){
                                        certificateStatus.reset();
                                    }
                                    let days = Ext.getCmp('certificateExpirationDate_certificate');
                                    if(days){
                                        days.reset();
                                    }
                                    let grid = Ext.getCmp('ctModelCertificateGrid');
                                    grid.getStore().loadData([],false);
                                }
                            }
                        ]
                    }
                ]
            },
            ctModelCertificateGrid
        ];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});


