Ext.define('PLM.view.CtModelReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtModelReport',
    title: '型号报告表',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    height: 600,
    collapsible: false,
    id: 'CtModelReport',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {

        Ext.define('modelReportModel', {
            extend: 'Ext.data.Model',
            fields: ['docNumber', 'creationTime', 'modificationTime', 'productName', 'productModel',
                'certificationType', 'certificateNumber', 'firstIssuanceDate', 'obtainingCertificateDate', 'certificateExpirationDate',
                'identityInformationType', 'certificationMark', 'certificateStatus', 'whetherCancel', 'logoutDate',
                'cancelResume', 'approvalDocumentNumber', 'changeHistory', 'reportNumber', 'reportType', 'reportStatus',
                'issuanceDate', 'validityDate'],
            idProperty: 'id'
        });

        var modelReportStore = Ext.create('Ext.data.Store', {
            model: 'modelReportModel',
            id: 'modelReportStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ext/plm/report/doc/certificateReport/getModelReportData',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    totalProperty:'totalCount',
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var modelReportGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.data.StoreManager.lookup('modelReportStore'),
            id: 'modelReportGrid',
            title: '查询结果',
            width: '98%',
            autoScroll: true,
            height: 380,
            viewConfig: { enableTextSelection: true },
            collapsible: false,
            columns: [
                {xtype: 'rownumberer', text: '序号', width: 50, align: 'center'},
                {
                    text: '文档编号',
                    dataIndex: 'docNumber',
                    width: 80,
                    menuDisabled: true,
                    renderer: function(value,meta,r){
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        if(r.get('docUrl')) {
                            var docLink = r.get('docUrl');
                            return docLink;
                        }else {
                            return value;
                        }
                    }
                },
                {
                    text: '创建时间',
                    dataIndex: 'creationTime',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '修改时间',
                    dataIndex: 'modificationTime',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '产品名称',
                    dataIndex: 'productName',
                    width: 120,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'data-qtip = "'+value+'" style="background-color: ' + color + ';width: 120px;"';
                        }else{
                            meta.tdAttr = 'data-qtip = "'+value+'"';
                        }
                        return value;
                    }
                },
                {
                    text: '产品型号',
                    dataIndex: 'productModel',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '报告编号',
                    dataIndex: 'reportNumber',
                    width: 120,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 120px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '报告类型',
                    dataIndex: 'reportType',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '报告状态',
                    dataIndex: 'reportStatus',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '报告签发日期',
                    dataIndex: 'issuanceDate',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '报告有效期',
                    dataIndex: 'validityDate',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '更改履历',
                    dataIndex: 'changeHistory',
                    width: 300,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'data-qtip = "'+value+'" style="background-color: ' + color + ';width: 300px;"';
                        }else{
                            meta.tdAttr = 'data-qtip = "'+value+'"';
                        }
                        return value;
                    }
                },
                {
                    text: '认证类型',
                    dataIndex: 'certificationType',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '证书编号',
                    dataIndex: 'certificateNumber',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '首次发证日期',
                    dataIndex: 'firstIssuanceDate',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '获得证书日期',
                    dataIndex: 'obtainingCertificateDate',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '证书到期日期',
                    dataIndex: 'certificateExpirationDate',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '身份信息类型',
                    dataIndex: 'identityInformationType',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '认证标识',
                    dataIndex: 'certificationMark',
                    width: 120,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 120px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '证书状态',
                    dataIndex: 'certificateStatus',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '是否注销',
                    dataIndex: 'whetherCancel',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '注销日期',
                    dataIndex: 'logoutDate',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '注销履历',
                    dataIndex: 'cancelResume',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                },
                {
                    text: '批复文档编号',
                    dataIndex: 'approvalDocumentNumber',
                    width: 80,
                    menuDisabled: true,
                    renderer: function (value, meta, r) {
                        let color = '#cf3d2d';
                        if('Y' == r.get('expiration')){
                            meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                        }
                        return value;
                    }
                }
            ],
            tbar: [
                {
                    text: '<b>生效中</b>',
                    cls: 'normal-certificate-btn',
                    disabled:false,
                    scope: this,
                    handler: function () {
                        Ext.getStore('modelReportStore').load({
                            params: {
                                reportStatus: '生效中'
                            }
                        });
                    }
                },
                {
                    text: '<b>已失效</b>',
                    cls: 'normal-certificate-btn',
                    disabled:false,
                    scope: this,
                    handler: function () {
                        Ext.getStore('modelReportStore').load({
                            params: {
                                reportStatus: '已失效'
                            }
                        });
                    }
                },
                {
                    text: '<b>全部</b>',
                    cls: 'normal-certificate-btn',
                    disabled:false,
                    scope: this,
                    handler: function () {
                        Ext.getStore('modelReportStore').load({
                            params: {}
                        });
                    }
                },
                {
                    text: '导出',
                    iconCls: 'icon icon-excelExport',
                    //disabled: !isEditable(maintenance_bom_node),
                    handler: function () {
                        var modelReportGrid = Ext.getCmp('modelReportGrid');
                        let data = modelReportGrid.getStore().data;
                        if(!data || data.length == 0){
                            Ext.Msg.alert("提示", "请先搜索查询出数据再导出！");
                            return;
                        }

                        // 获取XMLHttpRequest
                        var xmlHttpRequest = new XMLHttpRequest();
                        //  发起请求
                        xmlHttpRequest.open("POST", '/Windchill/ptc1/ext/plm/report/doc/certificateReport/exportCertificateReport?typeName=modelReport', true);
                        // 设置请求头类型
                        xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
                        xmlHttpRequest.responseType = "blob";
                        //增加遮罩
                        var loadMarsk = new Ext.LoadMask({
                            msg: '导出中，请稍等......',
                            target: modelReportGrid,
                            removeMask: true // 完成后移除
                        });
                        loadMarsk.show();
                        //  返回
                        xmlHttpRequest.onload = function (oEvent) {
                            var content = xmlHttpRequest.response;
                            if (content.type == 'application/json') {
                                content.text().then(res => {
                                    alert(Ext.decode(res).message)
                                })
                            } else {
                                var timestamp =new Date().getTime();
                                // 组装a标签
                                var elink = document.createElement("a");
                                // 设置下载文件名
                                var fileNamePrefix = '型号报告表';
                                elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
                                elink.style.display = "none";
                                var blob = new Blob([content]);
                                elink.href = URL.createObjectURL(blob);
                                document.body.appendChild(elink);
                                elink.click();
                                document.body.removeChild(elink);
                            }
                            loadMarsk.hide();
                        };
                        let newData = [];
                        let items = data.items;
                        for(let i = 0;i < items.length;i++){
                            newData[i] = items[i].data;
                        }
                        xmlHttpRequest.send(JSON.stringify(newData));
                    },
                    scope: this
                }
            ]
        });
        //======================  userResourceGrid End  ======================//

        ////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 5 3',
                title: '查询条件',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '5 0 5 0',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                margin: '5 0 5 20',
                                fieldLabel: '产品型号',
                                width: 230,
                                id: 'productModel_report',
                                name: 'productModel_report'
                            },
                            {
                                xtype: 'datefield',
                                margin: '5 0 5 20',
                                fieldLabel: '创建时间',
                                name: 'creationTimeStart_report',
                                id: 'creationTimeStart_report',
                                width: 180
                            },
                            {border: false, margin: '5 0 5 0', html: '<span>至</span>'},
                            {
                                xtype: 'datefield',
                                name: 'creationTimeEnd_report',
                                id: 'creationTimeEnd_report',
                                width: 110
                            },
                            {
                                xtype: 'datefield',
                                margin: '5 0 5 20',
                                fieldLabel: '修改时间',
                                name: 'updateTimeStart_report',
                                id: 'updateTimeStart_report',
                                width: 180
                            },
                            {border: false, margin: '5 0 5 0', html: '<span>至</span>'},
                            {
                                xtype: 'datefield',
                                name: 'updateTimeEnd_report',
                                id: 'updateTimeEnd_report',
                                width: 110
                            }
                        ]
                    },
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '5 20 5 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                fieldLabel: '证书编号',
                                width: 230,
                                id: 'certificateNumber_report',
                                name: 'certificateNumber_report'
                            },
                            {
                                xtype: 'combo',
                                fieldLabel: '证书状态',
                                width: 230,
                                id: 'certificateStatus_report',
                                name: 'certificateStatus_report',
                                enableKeyEvents: true,
                                store: {data: [{certificateStatus: '生效中'}, {certificateStatus: '已失效'}]}, // 下拉框的选项数据
                                editable: false, // 设置为不可编辑
                                valueField: 'certificateStatus',
                                displayField: 'certificateStatus'
                            },
                            {
                                xtype: 'textfield',
                                fieldLabel: '报告编号',
                                width: 230,
                                id: 'reportNumber_report',
                                name: 'reportNumber_report'
                            },
                            {
                                xtype: 'combo',
                                fieldLabel: '报告状态',
                                width: 230,
                                id: 'reportStatus_report',
                                name: 'reportStatus_report',
                                enableKeyEvents: true,
                                store: {data: [{reportStatus: '生效中'}, {reportStatus: '已失效'}]}, // 下拉框的选项数据
                                editable: false, // 设置为不可编辑
                                valueField: 'reportStatus',
                                displayField: 'reportStatus'
                            },
                        ]
                    },
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '5 20 5 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'numberfield',
                                fieldLabel: '证书到期时间(天)',
                                labelWidth: 110,
                                width: 270,
                                id: 'certificateExpirationDate_report',
                                name: 'certificateExpirationDate_report'
                            },
                            {
                                xtype: 'numberfield',
                                fieldLabel: '报告到期时间(天)',
                                labelWidth: 110,
                                width: 270,
                                id: 'reportExpirationDate_report',
                                name: 'reportExpirationDate_report'
                            },
                            {
                                xtype: 'button',
                                text: '搜索',
                                width: 70,
                                scope: this,
                                handler: function () {
                                    var productModel = Ext.getCmp('productModel_report').getValue();
                                    var creationTimeStart = Ext.getCmp('creationTimeStart_report').getValue();
                                    var creationTimeEnd = Ext.getCmp('creationTimeEnd_report').getValue();
                                    var modificationTimeStart = Ext.getCmp('updateTimeStart_report').getValue();
                                    var modificationTimeEnd = Ext.getCmp('updateTimeEnd_report').getValue();
                                    var certificateNumber = Ext.getCmp('certificateNumber_report').getValue();
                                    var certificateStatus = Ext.getCmp('certificateStatus_report').getValue();
                                    var reportNumber = Ext.getCmp('reportNumber_report').getValue();
                                    var reportStatus = Ext.getCmp('reportStatus_report').getValue();
                                    var days = Ext.getCmp('certificateExpirationDate_report').getValue();
                                    var reportDays = Ext.getCmp('reportExpirationDate_report').getValue();
                                    if(!productModel && !creationTimeStart && !creationTimeEnd && !modificationTimeStart
                                        && !modificationTimeEnd && !certificateNumber && (!certificateStatus || certificateStatus.length < 1 ) && !days
                                        && (!reportStatus || reportStatus.length < 1 ) && !reportNumber && !reportDays){
                                        Ext.Msg.alert('提示', '请填入查询条件！');
                                        return;
                                    }
                                    if(days){
                                        if(!Number.isInteger(days) || days <= 0){
                                            Ext.Msg.alert('提示', '【证书到期时间(天)】请填写正整数！');
                                            return;
                                        }
                                    }
                                    if(reportDays){
                                        if(!Number.isInteger(reportDays) || reportDays <= 0){
                                            Ext.Msg.alert('提示', '【报告到期时间(天)】请填写正整数！');
                                            return;
                                        }
                                    }
                                    Ext.getStore('modelReportStore').load({
                                        params: {
                                            productModel: productModel,
                                            creationTimeStart: creationTimeStart,
                                            creationTimeEnd: creationTimeEnd,
                                            modificationTimeStart: modificationTimeStart,
                                            modificationTimeEnd: modificationTimeEnd,
                                            certificateNumber: certificateNumber,
                                            certificateStatus: certificateStatus,
                                            days: days,
                                            reportNumber: reportNumber,
                                            reportStatus: reportStatus,
                                            reportDays: reportDays
                                        }
                                    });
                                }
                            },
                            {
                                xtype: 'button',
                                width: 70,
                                text: '清空',
                                scope: this,
                                handler: function () {
                                    let productModel = Ext.getCmp('productModel_report');
                                    productModel.reset();
                                    let creationTimeStart = Ext.getCmp('creationTimeStart_report');
                                    creationTimeStart.reset();
                                    let creationTimeEnd = Ext.getCmp('creationTimeEnd_report');
                                    creationTimeEnd.reset();
                                    let modificationTimeStart = Ext.getCmp('updateTimeStart_report');
                                    modificationTimeStart.reset();
                                    let modificationTimeEnd = Ext.getCmp('updateTimeEnd_report');
                                    modificationTimeEnd.reset();
                                    let certificateNumber = Ext.getCmp('certificateNumber_report');
                                    certificateNumber.reset();
                                    let certificateStatus = Ext.getCmp('certificateStatus_report');
                                    certificateStatus.reset();
                                    let reportNumber = Ext.getCmp('reportNumber_report');
                                    reportNumber.reset();
                                    let reportStatus = Ext.getCmp('reportStatus_report');
                                    reportStatus.reset();
                                    let days = Ext.getCmp('certificateExpirationDate_report');
                                    days.reset();
                                    let reportDays = Ext.getCmp('reportExpirationDate_report');
                                    reportDays.reset();
                                    let modelReportGrid = Ext.getCmp('modelReportGrid');
                                    modelReportGrid.getStore().loadData([],false);
                                }
                            }
                        ]
                    }
                ]
            },
            modelReportGrid
        ];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});


