/**
 * 设置按钮是否失效
 */
function setButtonDisabled(){
    let dataSource = Ext.getCmp("dataSource");
    if(dataSource){
        let dataSourceValue = dataSource.getValue();
        if(dataSourceValue && dataSourceValue === 'all'){
            //失效上传文件按钮
            let uploadPartFile = Ext.getCmp("uploadPartFile");
            uploadPartFile.disable();
            //失效是否需要导出文档下拉
            let isExportDoc = Ext.getCmp("isExportDoc");
            isExportDoc.disable();
        }else{
            //激活上传文件按钮
            let uploadPartFile = Ext.getCmp("uploadPartFile");
            uploadPartFile.enable();
            //激活是否需要导出文档下拉
            let isExportDoc = Ext.getCmp("isExportDoc");
            isExportDoc.enable();
        }
    }
}

/**
 * 清空搜索条件、用户要求表格也清空内容
 */
function doRefreshSearch(){
    let dataSource = Ext.getCmp("dataSource");
    dataSource.reset();
    let uploadPartFile = Ext.getCmp("uploadPartFile");
    uploadPartFile.reset();
    uploadPartFile.disable();
    let isExportDoc = Ext.getCmp("isExportDoc");
    isExportDoc.reset();
    isExportDoc.disable();
    let importPartNumbers = Ext.getCmp("importPartNumbers");
    importPartNumbers.reset();
    let partView = Ext.getCmp("partView");
    partView.reset();
    let docListGrid = Ext.getCmp("docListGrid");
    docListGrid.getStore().loadData([],false);
}

/**
 * 确定按钮，查询文档类型清单
 */
function doDocListSearch(){
    //先清空表格数据
    let docListGrid = Ext.getCmp("docListGrid");
    docListGrid.getStore().loadData([],false);

    let dataSourceValue = Ext.getCmp("dataSource").getValue();
    let isExportDocValue = Ext.getCmp("isExportDoc").getValue();
    let partView = Ext.getCmp("partView").getValue();
    if(dataSourceValue === 'import'){
        //本地导入
        let furl = "";  //文件物理地址
        let file = document.querySelector('[id=uploadPartFile-button-fileInputEl]');
        furl = file.value;
        if (furl == "") {
            Ext.Msg.alert("提示", "请先导入本地Excel文件！");
            return;
        }
        //选择视图
        if (!partView || partView == '') {
            Ext.Msg.alert("提示", "请选择视图！");
            return;
        }
        let formData = new FormData();
        formData.append('uploadPartFile-button-fileInputEl', file.files[0]);
        let uploadPartFile = Ext.getCmp("uploadPartFile");
        uploadPartFile.reset();

        //导入物料清单
        let docListGrid = Ext.getCmp("docListGrid");
        var loadMarsk = new Ext.LoadMask({
            msg: '文档类型清单加载中，请稍等......',
            target: docListGrid,
            removeMask: true // 完成后移除
        });
        loadMarsk.show();
        $.ajax({
            url: '/Windchill/ptc1/partReport/getDocListByPart?isExportDocValue=' + isExportDocValue + "&partView=" + partView,
            type: 'POST',
            cache: false,
            data: formData,
            processData: false,
            contentType: false
        }).done(function (res) {
            loadMarsk.hide();
            let message = res['message'];
            if (message == 'success') {
                let data = res['data'];
                if(data){
                    //记录导入的物料编码
                    let partNumbers = data['partNumbers'];
                    let importPartNumbers = Ext.getCmp("importPartNumbers");
                    importPartNumbers.setValue(partNumbers);

                    //加载文档清单
                    if(isExportDocValue == 'y'){
                        let items = data['items'];
                        let store = Ext.data.StoreManager.lookup('docListStore');
                        items.forEach((item,index,array)=>{
                            store.add(item);
                        })
                    }
                    Ext.Msg.alert('提示', '导入成功！');
                }
            }else{
                Ext.Msg.alert('错误', message);
            }
        }).fail(function (res) {
            loadMarsk.hide();
            Ext.Msg.alert('错误', '文档类型清单加载失败！');
        });
    }else{
        Ext.Msg.alert('提示', '请点击“确定并导出”按钮，导出“全部系统物料”！');
    }
}

/**
 * 取消
 */
function doCancel(){
    let dataSource = Ext.getCmp("dataSource");
    dataSource.reset();
    let uploadPartFile = Ext.getCmp("uploadPartFile");
    uploadPartFile.reset();
    uploadPartFile.disable();
    let isExportDoc = Ext.getCmp("isExportDoc");
    isExportDoc.reset();
    isExportDoc.disable();
    let docListGrid = Ext.getCmp("docListGrid");
    docListGrid.getStore().loadData([],false);
    let importPartNumbers = Ext.getCmp("importPartNumbers");
    importPartNumbers.reset();
    let partView = Ext.getCmp("partView");
    partView.reset();
}

/**
 * 确定并导出
 */
function doConfirmAndExport() {
    let dataSourceValue = Ext.getCmp("dataSource").getValue();
    let partView = Ext.getCmp("partView").getValue();
    if(!partView || partView==''){
        Ext.Msg.alert('提示','请选择视图！');
        return;
    }
    if(dataSourceValue === 'all'){
        exportAllPartReport('', partView);
    }else{
        //用户没点确定按钮导入时，提示
        let partNumbers = Ext.getCmp("importPartNumbers").getValue();
        if(!partNumbers || '' == partNumbers){
            Ext.Msg.alert('提示', '请先点击“确定”按钮导入数据！');
            return;
        }
        let isExportDocValue = Ext.getCmp("isExportDoc").getValue();
        if(isExportDocValue == 'y'){
            //校验是否有选择文档类型
            let docListGrid = Ext.getCmp("docListGrid");
            var tmpSm = docListGrid.getSelectionModel().getSelection();
            if(!tmpSm || tmpSm==''){
                Ext.Msg.alert('提示','请选择要下载的文档类型！');
                return;
            }
            //获取选择的文档类型
            let docTypeNameArray = new Array();
            for(let i = 0;i < tmpSm.length;i++){
                let rowData = tmpSm[i].getData();
                docTypeNameArray.push(rowData)
            }

            //增加遮罩
            var loadMarsk = new Ext.LoadMask({
                msg: '正在下载物料属性及关联文档，请稍等......',
                target: docListGrid,
                removeMask: true // 完成后移除
            });
            loadMarsk.show();
            //勾选导出文档，需要导出物料属性和带文档的压缩包
            Ext.Ajax.request({
                scope: this,
                url: "/Windchill/ptc1/partReport/exportZipFile",
                method: "POST",
                async: false,
                params: {
                    partNumbers: partNumbers,
                    partView: partView,
                    selectedArray: JSON.stringify(docTypeNameArray)
                },
                success: function (response, opts) {
                    let obj = Ext.decode(response.responseText);
                    if (obj['status'] !== 200) {
                        Ext.Msg.alert('错误', obj['message']);
                    } else {
                        let url = obj['data'];
                        if(url){
                            window.location.href = url, '', 'width=300,height=200';
                        }
                    }
                    loadMarsk.hide();
                },
                failure: function (response, opts) {
                    loadMarsk.hide();
                    Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
                }
            });
        }else{
            //没勾选导出文档，就直接导出物料属性
            exportAllPartReport(partNumbers, partView);
        }
    }
}

/**
 * 导出系统全部物料
 */
function exportAllPartReport(partNumbers, partView) {
    // 获取XMLHttpRequest
    var xmlHttpRequest = new XMLHttpRequest();
    //  发起请求
    xmlHttpRequest.open("POST", '/Windchill/ptc1/partReport/exportAllPartAttribute', true);
    // 设置请求头类型
    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
    xmlHttpRequest.responseType = "blob";
    //增加遮罩
    let docListGrid = Ext.getCmp("docListGrid");
    var loadMarsk = new Ext.LoadMask({
        msg: '查询物料属性清单中，请稍等......',
        target: docListGrid,
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    //  返回
    xmlHttpRequest.onload = function (oEvent) {
        var content = xmlHttpRequest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).message)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            var fileNamePrefix = '系统全部物料属性清单';
            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }
        loadMarsk.hide();
    };
    let object = new Object();
    object['partNumbers'] = partNumbers;
    object['partView'] = partView;
    xmlHttpRequest.send(JSON.stringify(object));
}


