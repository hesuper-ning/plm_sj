Ext.define('PLM.view.CtPartAndRefDocPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtPartAndRefDocPanel',
    title: '<font style="font-size:15px">物料属性及关联文档导出</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtPartAndRefDocPanel',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //数据来源Store
        var dataSourceStore = Ext.create('Ext.data.Store', {
            storeId: 'dataSourceStore',
            fields: ['value', 'displayValue'],
            data: [
                {value: 'import', displayValue: '本地导入'},
                {value: 'all', displayValue: '全部系统物料'},
            ]
        });

        //是否需要导出文档Store
        var isExportDocStore = Ext.create('Ext.data.Store', {
            storeId: 'isExportDocStore',
            fields: ['value', 'displayValue'],
            data: [
                {value: 'y', displayValue: '是'},
                {value: 'n', displayValue: '否'},
            ]
        });

        //视图Store
        var viewStore = Ext.create('Ext.data.Store', {
            storeId: 'viewStore',
            fields: ['value', 'displayValue'],
            data: [
                {value: 'eView', displayValue: '设计视图'},
                {value: 'mView', displayValue: '制造视图'},
                {value: 'noRepeat', displayValue: '去重'}
            ]
        });

        //导入panel
        var uploadPartInfoForm = new Ext.form.Panel({
            layout: 'hbox',
            id: 'uploadPartInfoForm',
            name: 'uploadPartInfoForm',
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            padding: 1,
            width: '98%',
            border: false,
            items: [
                {
                    xtype: 'label',
                    margin: '10 20 10 50',
                    text: '本地导入:'
                },
                {
                    xtype: 'button',
                    margin: '10 20 10 20',
                    text: '下载模板',
                    iconCls : 'icon icon-store-export',
                    scope: this,
                    hidden:false,
                    handler : function(){
                        window.location.href = '/Windchill/template/导入物料清单模板.xlsx', '', 'width=300,height=200';
                    }
                },
                {
                    xtype: 'filefield',
                    margin: '10 20 10 50',
                    buttonOnly: true,
                    id: 'uploadPartFile',
                    hideLabel: true,
                    disabled: true,
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>选择导入本地Excel文件</span>',
                    allowBlank: false
                },
                {
                    xtype: 'combobox',
                    margin: '10 20 10 50',
                    fieldLabel: '是否需要导出文档',
                    id: 'isExportDoc',
                    name: 'isExportDoc',
                    labelWidth: 120,
                    store: isExportDocStore,
                    disabled: true,
                    editable: false,
                    displayField: 'displayValue',
                    valueField: 'value'
                },
                {
                    xtype: 'combobox',
                    margin: '10 20 10 50',
                    fieldLabel: '视图',
                    id: 'partView',
                    name: 'partView',
                    labelWidth: 50,
                    store: viewStore,
                    disabled: false,
                    editable: false,
                    displayField: 'displayValue',
                    valueField: 'value'
                },
                {
                    xtype: 'hidden',
                    id: 'importPartNumbers',
                    name: 'importPartNumbers'
                }
            ]
        });

        Ext.define('docListModel', {
            extend: 'Ext.data.Model',
            fields: ['docType', 'docTypeName'],
            idProperty: 'docTypeName'
        });

        var docListStore = Ext.create('Ext.data.Store', {
            model: 'docListModel',
            id: 'docListStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/partReport/getDocListByPart',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    totalProperty:'totalCount',
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var docListGrid = Ext.create('Ext.grid.Panel', {
            padding: 1,
            store: Ext.data.StoreManager.lookup('docListStore'),
            id: 'docListGrid',
            title: '文档类型清单',
            width: '98%',
            autoScroll: true,
            height: 360,
            selModel: Ext.create('Ext.selection.CheckboxModel', {
                id: 'docListCheckboxModel',
                mode: "SIMPLE",
                showHeaderCheckbox: true
            }),
            collapsible: true,
            columns: [
                {text: '文档类型', dataIndex: 'docType', flex:1, menuDisabled: true},
                {text: '文档名称', dataIndex: 'docTypeName', flex:1, menuDisabled: true},
            ]
        });
        //======================  userResourceGrid End  ======================//

        var buttonPanel = Ext.create('Ext.form.Panel', {
            padding: 1,
            id: 'buttonPanel',
            width: '98%',
            border: false,
            items:[
                {
                    xtype: 'button',
                    width: 100,
                    text: '确定并导出',
                    scope: this,
                    margin: '0 20 0 580',
                    handler: function () {
                        doConfirmAndExport();
                    }
                },
                {
                    xtype: 'button',
                    width: 70,
                    text: '取消',
                    scope: this,
                    handler: function () {
                        doCancel();
                    }
                }
            ]
        });

        ////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">查询参数</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 0 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'combobox',
                                margin: '10 20 10 50',
                                fieldLabel: '数据来源',
                                id: 'dataSource',
                                name: 'dataSource',
                                labelWidth: 70,
                                store: dataSourceStore,
                                editable: false,
                                displayField: 'displayValue',
                                valueField: 'value',
                                listeners: {
                                    'select': function () {
                                        //控制按钮的有效性
                                        setButtonDisabled();
                                    },
                                }
                            }
                        ]
                    },
                    //上传文件Form
                    uploadPartInfoForm,
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '0 0 10 20',
                            labelWidth: 70
                        },
                        items: [
                            {
                                xtype: 'button',
                                width: 70,
                                text: '确定',
                                scope: this,
                                margin: '0 0 0 560',
                                handler: function () {
                                    doDocListSearch();
                                }
                            },
                            {
                                xtype: 'button',
                                width: 70,
                                text: '重置',
                                scope: this,
                                handler: function () {
                                    //清空查询条件
                                    doRefreshSearch();
                                }
                            }
                            // ,
                            // {
                            //     xtype: 'button',
                            //     margin: '5 0 10 30',
                            //     text: 'Excel导出',
                            //     iconCls: 'icon icon-store-export',
                            //     scope: this,
                            //     handler: function () {
                            //         var userDept = Ext.getCmp('userDept').getValue();
                            //         var userFullName = Ext.getCmp('userFullName').getValue();
                            //         window.location.href = "/Windchill/ptc1/humanResource/exportUserResource?userDept="+userDept+"&userFullName="+userFullName;
                            //     }
                            // },
                        ]
                    }
                ]
            },
            docListGrid,buttonPanel
        ];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {

        },
        'afterrender': function () {
            //doSearch();
        }
    }

});


