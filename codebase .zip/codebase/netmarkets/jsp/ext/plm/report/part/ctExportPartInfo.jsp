<%@ page import="ext.plm.report.resourceLoad.CtHumanResourceLogic" %>
<%@ page import="java.util.HashMap" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
	<link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
	<script type="text/javascript" src="../../common/jquery-2.0.0.min.js"></script>
	<script type="text/javascript" src="js/ctPartAndRefDocFn.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctPartAndRefDocPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
// ==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'CtPartAndRefDocPanel'
		    }]
		});
});
</script>
</body>
</html>