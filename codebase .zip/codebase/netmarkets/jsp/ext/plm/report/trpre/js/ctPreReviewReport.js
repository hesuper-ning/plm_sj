Ext.define('PLM.view.PreReviewInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.PreReviewInfo',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'PreReviewInfo',
    initComponent: function () {
        Ext.define('trPreReviewListModel', {
            extend: 'Ext.data.Model',
            fields: [
                'docNumber', 'docName', 'docStatus', 'productNumber', 'productName','productLine','projectStatus',
                'trPint','reviewExperts','expertsDepartment','preReviewCompleted','taskAcceptime','taskCompletetime',
                'preReviewCycle','preReviewOpinion'
            ],
            idProperty: 'trPreReviewListModel'
        });

        // 查询 Store
        var trPreReviewListStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'trPreReviewListModel',
            id:'trPreReviewListStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/reportForms/ctPreReview',
                method:'GET',
                timeout: 9000000,
                reader:{
                    type:'json',
                    root: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'trPreReviewListModel',
                    messageProperty: 'massage'
                }
            }),
            autoLoad:false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var alternativeMaterialListGrid = Ext.create('Ext.grid.Panel', {
            plugins: cellEditing,
            store:trPreReviewListStore,
            autoWidth : true,
            autoScroll:true,
            height:400,
            viewConfig:{enableTextSelection:true, forceFit : false},
            columns: [
                { text: 'TR评审文档编号', dataIndex: 'docNumber', width: 150, align: 'center',menuDisabled: true},
                {text: 'TR评审文档名称',  align: 'center', dataIndex: 'docName', width: 150, menuDisabled:true, editor:false,renderer:showTip},
                { text: '文档状态',  dataIndex: 'docStatus' , width:100, align: 'center',menuDisabled: true},
                { text: '项目编号',  dataIndex: 'productNumber', width:150, align: 'center',menuDisabled: true},
                { text: '项目名称',  dataIndex: 'productName',width:100, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '产品线', align: 'center',  dataIndex: 'productLine', menuDisabled:true, editor:false,renderer:showTip},
                { text: '项目状态',  dataIndex: 'projectStatus' , width:100, align: 'center',menuDisabled: true},
                { text: 'TR点',  dataIndex: 'trPint' , width:100, align: 'center',menuDisabled: true},
                { text: '评审专家',  dataIndex: 'reviewExperts' , width:100, align: 'center',menuDisabled: true},
                { text: '专家所属部门',  dataIndex: 'expertsDepartment' , width:100, align: 'center',menuDisabled: true},
                { text: '预评审是否完成',  dataIndex: 'preReviewCompleted' , width:100, align: 'center',menuDisabled: true},
                { text: '填报预审意见任务接受时间',  dataIndex: 'taskAcceptime' , width:100, align: 'center',menuDisabled: true},
                { text: '填报预审意见任务完成时间',  dataIndex: 'taskCompletetime' , width:100, align: 'center',menuDisabled: true},
                { text: '预审周期(天)',  dataIndex: 'preReviewCycle' , width:100, align: 'center',menuDisabled: true},
                { text: '预审意见',  dataIndex: 'preReviewOpinion' , width:300, align: 'center',menuDisabled: true,renderer:showTip}
            ]
        });





// ========================Items Area======================//

        this.items=[
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">TR评审报表</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100,
                    border: false,
                    anchor: '99%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                    xtype: 'panel',
                    defaults: {margin: '5 20 20 0', labelWidth: 70},
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: '评审专家',
                            name: 'reviewExperts',
                            id: 'reviewExperts',
                            width: 250,
                            enableKeyEvents: true
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '所属部门',
                            name: 'expertsDepartment',
                            id: 'expertsDepartment',
                            width: 250,
                            enableKeyEvents: true
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '项目名称',
                            name: 'productName',
                            id: 'productName',
                            width: 250,
                            enableKeyEvents: true
                        }
                    ]
                },{
                    xtype: 'panel',
                    defaults: {margin: '5 20 20 0', labelWidth: 70},
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: '产品线',
                            name: 'productLine',
                            id: 'productLine',
                            width: 250,
                            enableKeyEvents: true
                        },
                        {
                            xtype: 'combobox',
                            margin: '0 5 0 0',
                            store: ['TR2','TR4','TR4A','TR5','TR6'],
                            //labelWidth: 90,
                            forceSelection: true,//强制从列表中选择
                            fieldLabel: 'TR点',
                            name: 'trPint',
                            id: 'trPint',
                            width: 250
                        },{
                            xtype: 'datefield',
                            id: 'productBeginBeginTime',
                            name:'productBeginBeginTime',
                            fieldLabel: '项目实际开始时间从',
                            margin: '0 5 0 0',
                            format:'Y-m-d',
                            allowBlank: false
                        },
                        {
                            xtype: 'datefield',
                            id: 'productBeginEndTime',
                            name:'productBeginEndTime',
                            format:'Y-m-d',
                            fieldLabel: '到',
                            allowBlank: false
                        }
                    ]
                }, {
                    xtype: 'panel',
                    defaults: {margin: '5 20 20 0', labelWidth: 70},
                    items: [{
                        xtype: 'datefield',
                        id: 'productfinishBeginTime',
                        name:'productfinishBeginTime',
                        fieldLabel: '项目实际结束时间从',
                        margin: '0 5 0 0',
                        format:'Y-m-d',
                        allowBlank: false
                    },
                    {
                        xtype: 'datefield',
                        id: 'productfinishEndTime',
                        name:'productfinishEndTime',
                        format:'Y-m-d',
                        fieldLabel: '到',
                        allowBlank: false
                    },
                    
                    {
                        xtype:'button',
                        // margin:'10 0 10 0',
                        width:70,
                        text: '查询',
                        scope:this,
                        iconCls: 'icon icon-search',
                        handler: function() {
                            doSearch();
                        }
                    },
                    {
                        xtype: 'button',
                        text: '导出为Excel文件',
                        id:'materialSubstitutionReportExport',
                        iconCls: 'icon icon-exportExcel',
                        handler: function () {
                        	var reviewExpertsQ = Ext.getCmp('reviewExperts').getValue();
                        	var expertsDepartmentQ = Ext.getCmp('expertsDepartment').getValue();
                        	var productNameQ = Ext.getCmp('productName').getValue();
                        	var productLineQ = Ext.getCmp('productLine').getValue();
                        	var trPintQ = Ext.getCmp('trPint').getValue();
                        	var productBeginBeginTimeDt = Ext.getCmp('productBeginBeginTime').getValue();
                        	var productBeginEndTimeDt = Ext.getCmp('productBeginEndTime').getValue();
                        	var productfinishBeginTimeDt = Ext.getCmp('productfinishBeginTime').getValue();
                        	var productfinishEndTimeDt = Ext.getCmp('productfinishEndTime').getValue();
                        	if(productBeginBeginTimeDt){
                        		if(!productBeginEndTimeDt){
                        			alert("项目实际开始时间开始结束时间都必须填写！")
                        			return;
                        		}
                        	}
                        	if(productBeginEndTimeDt){
                        		if(!productBeginBeginTimeDt){
                        			alert("项目实际开始时间开始结束时间都必须填写！")
                        			return;
                        		}
                        	}
                        	if(productfinishBeginTimeDt){
                        		if(!productfinishEndTimeDt){
                        			alert("项目实际结束时间开始结束时间都必须填写！")
                        			return;
                        		}
                        	}
                        	if(productfinishEndTimeDt){
                        		if(!productfinishBeginTimeDt){
                        			alert("项目实际结束时间开始结束时间都必须填写！")
                        			return;
                        		}
                        	}
                        	var productBeginBeginTime = "";
                        	if(productBeginBeginTimeDt){
                        		productBeginBeginTime = Ext.util.Format.date(new Date(productBeginBeginTimeDt),'Y-m-d');
                        	}	
                        	var productBeginEndTime = "";
                        	if(productBeginEndTimeDt){
                        		productBeginEndTime = Ext.util.Format.date(new Date(productBeginEndTimeDt),'Y-m-d');
                        	}
                        	var productfinishBeginTime = "";
                        	if(productfinishBeginTimeDt){
                        		productfinishBeginTime = Ext.util.Format.date(new Date(productfinishBeginTimeDt),'Y-m-d');
                        	}
                        	var productfinishEndTime = "";
                        	if(productfinishEndTimeDt){
                        		productfinishEndTime = Ext.util.Format.date(new Date(productfinishEndTimeDt),'Y-m-d');
                        	}
                            window.location.href = '/Windchill/ptc1/reportForms/ctPreReviewReportExport?reviewExperts=' + reviewExpertsQ +'&expertsDepartment='+expertsDepartmentQ
                            +'&productName='+productNameQ+'&productLine='+productLineQ
                            +'&trPint='+trPintQ+'&productBeginBeginTime='+productBeginBeginTime
                            +'&productBeginEndTime='+productBeginEndTime+'&productfinishBeginTime='+productfinishBeginTime
                            +'&productfinishEndTime='+productfinishEndTime;
                        },
                        scope: this
                    }]
                }]
            },
            alternativeMaterialListGrid];
        this.callParent();

    },// ~End of initComponent
});

/**
 * 按查询参数查询
 */
function doSearch() {
	var reviewExpertsQ = Ext.getCmp('reviewExperts').getValue();
	var expertsDepartmentQ = Ext.getCmp('expertsDepartment').getValue();
	var productNameQ = Ext.getCmp('productName').getValue();
	var productLineQ = Ext.getCmp('productLine').getValue();
	var trPintQ = Ext.getCmp('trPint').getValue();
	var productBeginBeginTimeDt = Ext.getCmp('productBeginBeginTime').getValue();
	var productBeginEndTimeDt = Ext.getCmp('productBeginEndTime').getValue();
	var productfinishBeginTimeDt = Ext.getCmp('productfinishBeginTime').getValue();
	var productfinishEndTimeDt = Ext.getCmp('productfinishEndTime').getValue();
	
	/*if (!reviewExpertsQ && !expertsDepartmentQ && !productNameQ
			&& !productLineQ && !trPintQ && !productBeginBeginTimeDt && !productBeginEndTimeDt
			&& !productfinishBeginTimeDt && !productfinishEndTimeDt) {
		alert("必须选择查询类型！")
		return;
	}*/
	if(productBeginBeginTimeDt){
		if(!productBeginEndTimeDt){
			alert("项目实际开始时间开始结束时间都必须填写！")
			return;
		}
	}
	if(productBeginEndTimeDt){
		if(!productBeginBeginTimeDt){
			alert("项目实际开始时间开始结束时间都必须填写！")
			return;
		}
	}
	if(productfinishBeginTimeDt){
		if(!productfinishEndTimeDt){
			alert("项目实际结束时间开始结束时间都必须填写！")
			return;
		}
	}
	if(productfinishEndTimeDt){
		if(!productfinishBeginTimeDt){
			alert("项目实际结束时间开始结束时间都必须填写！")
			return;
		}
	}
	var productBeginBeginTime = "";
	if(productBeginBeginTimeDt){
		productBeginBeginTime = Ext.util.Format.date(new Date(productBeginBeginTimeDt),'Y-m-d');
	}	
	var productBeginEndTime = "";
	if(productBeginEndTimeDt){
		productBeginEndTime = Ext.util.Format.date(new Date(productBeginEndTimeDt),'Y-m-d');
	}
	var productfinishBeginTime = "";
	if(productfinishBeginTimeDt){
		productfinishBeginTime = Ext.util.Format.date(new Date(productfinishBeginTimeDt),'Y-m-d');
	}
	var productfinishEndTime = "";
	if(productfinishEndTimeDt){
		productfinishEndTime = Ext.util.Format.date(new Date(productfinishEndTimeDt),'Y-m-d');
	}
	Ext.getStore('trPreReviewListStore').load({
		params : {
			// data: Ext.encode(data)
			reviewExperts : reviewExpertsQ,
			expertsDepartment : expertsDepartmentQ,
			productName : productNameQ,
			productLine : productLineQ,
			trPint : trPintQ,
			productBeginBeginTime : productBeginBeginTime,
			productBeginEndTime : productBeginEndTime,
			productfinishBeginTime : productfinishBeginTime,
			productfinishEndTime : productfinishEndTime
		},
		callback : function(records, operation, success) {
			if (!success) {
				var responseText = operation.getResponse().responseText;
				var responseObject = Ext.decode(responseText);
				alert(responseObject.message);
				// alert('查询信息失败，请联系管理员！');
			}
		}
	});
}
//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}
