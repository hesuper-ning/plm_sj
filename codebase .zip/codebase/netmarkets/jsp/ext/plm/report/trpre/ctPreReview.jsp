<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>in CtBomToolPlugin.jsp oid="+oid);
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css" href="css/ablum.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctPreReviewFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctPreReviewReport.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
    //查询共享

    var projectId = "<%=oid%>";
    var share = '1';
    //用于判断图片是否可以删除
    var problemStatus = '';
    var actKey = '';
    var containerId = null;
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'PreReviewInfo'
            }]
        });
    });
</script>
</body>
</html>