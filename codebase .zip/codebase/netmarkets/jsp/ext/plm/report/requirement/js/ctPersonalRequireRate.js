Ext.define('PLM.view.PersonalRequireReportPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.PersonalRequireReportPanel',
    border:false,
    layout:'anchor',
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'PersonalRequireReportPanel',
    initComponent:function(){


        Ext.define('personalRequireReportModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','personsData','devDepartment','totalStake','taskCompletions','taskCompletionsRate',
                'taskCompletionInTime','taskCompletionInTimeRate','totalStakeRD','taskCompletionInTimeRD','taskCompletionInTimeRDRate'
            ],
            idProperty: 'id'
        });


        // create the Data Store
        var personalRequireReprtStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'personalRequireReportModel',
            id:'personalRequireReportStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/report/require/getPersonalFinishRate?projectOid='+projectOid,
                method:'GET',
                timeout:900000000,
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });

        this.cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var personalRequireReportGrid = Ext.create('Ext.grid.Panel', {
            plugins: [this.cellEditing],
            store:Ext.data.StoreManager.lookup('personalRequireReportStore'),
            id:'personalRequireReportGrid',
            title:'个人需求完成率',
            autoWidth : true,
            autoScroll:true,
            autoHeight:true,
            viewConfig:{enableTextSelection:true},
//				selModel: {
//					selType: 'cellmodel'
//				},
            selType: 'checkboxmodel',
            listeners: {
                change:'onAllCircuitsChecked'
            },
            features: [{
                ftype: 'summary',
                dock: 'bottom'
            }],
            columns: [
                new Ext.grid.RowNumberer({
                    align:"center",
                    width : 60,
                    renderer:function(value, metaData, record, rowIdx, colIdx, store) {
                        return rowIdx + 1;
                    }
                }),
                { text: 'id',dataIndex: 'id',menuDisabled:true,hidden:true},
                { text: '成员',dataIndex: 'personsData',width:100 ,menuDisabled:true,summaryType: 'count',
                    summaryRenderer: function(value){
                        return Ext.String.format('共 {0} 条数据', value);
                    }},
                { text: '开发部门',dataIndex: 'devDepartment',width:100 ,menuDisabled:true},
                {
                    text: '<b>个人需求任务统计</b>',
                    columns: [
                        { text: '任务总数',dataIndex: 'totalStake',width:100 ,menuDisabled:true},
                        { text: '任务完成数',dataIndex: 'taskCompletions',width:100 ,menuDisabled:true},
                        { text: '任务完成率',dataIndex: 'taskCompletionsRate',width:100 ,menuDisabled:true},
                        { text: '任务及时完成数',dataIndex: 'taskCompletionInTime',width:120 ,menuDisabled:true},
                        { text: '任务及时完成率',dataIndex: 'taskCompletionInTimeRate',width:120 ,menuDisabled:true}
                    ],
                    menuDisabled:true
                },
                {
                    text: '<b>研发一次成功交付率</b>',
                    columns: [
                        { text: '研发DS数',dataIndex: 'totalStakeRD',width:100 ,menuDisabled:true},
                        { text: '研发一次成功交付DS数',dataIndex: 'taskCompletionInTimeRD',width:200 ,menuDisabled:true},
                        { text: '研发一次成功交付率',dataIndex: 'taskCompletionInTimeRDRate',width:200 ,menuDisabled:true}
                    ],
                    menuDisabled:true
                }

            ],
            tbar: [{
                text: '导出',
                iconCls : 'icon icon-store-export',
                scope: this,
                handler : function(){
                    window.location.href =
                        '/Windchill/ptc1/report/require/exportPersonalRequireReport?projectOid='+projectOid;
                }
            }],
            listeners:{
                'beforeedit': function  (editor,  e,  eOpts)  {
                    if(e.field!="") {
                        return false;
                    }
                }
            }
        });

/////////////////////////Main Panel items//////////////////////////////////
        this.items=[personalRequireReportGrid];

        this.callParent();

    },//~End of initComponent
    listeners:{
        'afterrender':function() {
            //加载列表
            Ext.getStore('personalRequireReportStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        alert('查詢失敗，请联系管理员！' + operation.getError());
                    } else {
                    }
                }
            });
        }
    }
});