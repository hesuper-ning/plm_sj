<%@ page language="java" import="java.util.*"  contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<iframe id="ctRequireSummaryIframe" src="netmarkets/jsp/ext/plm/report/requirement/ctRequireSummary.jsp" style="width:98%;height:500px" ></iframe>
