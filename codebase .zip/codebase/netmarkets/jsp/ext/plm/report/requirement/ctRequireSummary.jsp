<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctRequireSummary.js?_dc=<%System.currentTimeMillis();%>"></script>
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'RequireSummaryPanel'
            }]
        });
    });
</script>
</body>
</html>