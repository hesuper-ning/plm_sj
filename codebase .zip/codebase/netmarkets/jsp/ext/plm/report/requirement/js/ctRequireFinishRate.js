Ext.define('PLM.view.RequireFinishRatePanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.RequireFinishRatePanel',
    border:false,
    layout:'anchor',
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'requireFinishRatePanel',
    initComponent:function(){

        Ext.define('requireFinishRateModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','dsDomain','dsTotalCount','dsFinishCount','dsFinishRate','dsInTimeFinishCount','dsInTimeFinishRate',
                'green','yellow','red','greenRatio'
            ],
            idProperty: 'a'
        });


        // create the Data Store
        var requireFinishRateStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'requireFinishRateModel',
            id:'requireFinishRateStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/report/require/getRequireFinishRate?projectOid='+projectOid,
                method:'GET',
                timeout:900000000,
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });

        this.cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var requireFinishRateGrid = Ext.create('Ext.grid.Panel', {
            plugins: [this.cellEditing],
            store:Ext.data.StoreManager.lookup('requireFinishRateStore'),
            id:'requireFinishRateGrid',
            title:'项目需求完成率',
            autoWidth : true,
            autoScroll:true,
            // height:550,
            autoHeight:true,
            viewConfig:{enableTextSelection:true},
//				selModel: {
//					selType: 'cellmodel'
//				},
            selType: 'checkboxmodel',
            listeners: {
                change:'onAllCircuitsChecked'
            },
            features: [{
                ftype: 'summary',
                dock: 'bottom'
            }],
            columns: [
                new Ext.grid.RowNumberer({
                    align:"center",
                    width : 50,
                    renderer:function(value, metaData, record, rowIdx, colIdx, store) {
                        return rowIdx + 1;
                    }
                }),
                { text: 'id',dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
                { text: 'DS领域',dataIndex: 'dsDomain',width:130 ,menuDisabled:true,summaryType: 'count',
                    summaryRenderer: function(value){
                        return Ext.String.format('共 {0} 条数据', value);
                    }
                },{
                    text: '<b>项目交付统计</b>',
                    columns: [
                        { text: '项目DS总数',dataIndex: 'dsTotalCount',width:120 ,menuDisabled:true},
                        { text: '项目DS交付数',dataIndex: 'dsFinishCount',width:150 ,menuDisabled:true},
                        { text: '项目DS交付率',dataIndex: 'dsFinishRate',width:150 ,menuDisabled:true},
                        { text: '项目DS及时交付数',dataIndex: 'dsInTimeFinishCount',width:180 ,menuDisabled:true},
                        { text: '项目DS及时交付率',dataIndex: 'dsInTimeFinishRate',width:180 ,menuDisabled:true}
                    ],
                    menuDisabled:true
                },{
                    text: '<b>需求质量状态</b>',
                    columns: [
                        { text: '绿灯',dataIndex: 'green',width:50 ,menuDisabled:true},
                        { text: '黄灯',dataIndex: 'yellow',width:50 ,menuDisabled:true},
                        { text: '红灯',dataIndex: 'red',width:50 ,menuDisabled:true},
                        { text: '绿灯比例',dataIndex: 'greenRatio',width:80 ,menuDisabled:true}
                    ],
                    menuDisabled:true
                }
            ],
            tbar: [{
                text: '导出',
                iconCls : 'icon icon-store-export',
                scope: this,
                handler : function(){
                    window.location.href =
                        '/Windchill/ptc1/report/require/exportRequireFinishRate?projectOid='+projectOid;
                }
            }],
            listeners:{
                'beforeedit': function  (editor,  e,  eOpts)  {
                    if(e.field!="") {
                        return false;
                    }
                }
            }
        });

/////////////////////////Main Panel items//////////////////////////////////
        this.items=[requireFinishRateGrid];

        this.callParent();

    },//~End of initComponent
    listeners:{
        'afterrender':function() {
            //加载列表
            Ext.getStore('requireFinishRateStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        alert('查詢失敗，请联系管理员！' + operation.getError());
                    } else {
                    }

                }
            });
        }
    }
});
