Ext.define('PLM.view.RequireTreePanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.RequireTreePanel',
    border:false,
    layout:'anchor',
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'requireTreePanel',
    initComponent:function(){
        var imagePath = "/Windchill/netmarkets/images/";//质量状态照片的路径
        Ext.define('requireTreeModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','requireType','number','requireTitle','dsRequireDesc','dsRequireRemark','dsComponent',
                'dsDomain','dsPriority','dsImportance','isSelfVerify','dsSelfVerifyReportNumber','dsSelfVerifyReportDocOid',
                'rdPersonLiable','rdPlanTime','rdProgress','rdRemark','rdActualTime','implementConfirm','implementConfirmRemark',
                'caPersonLiable','caPlanTime','caProgress','isTestCase','dsTestCaseNumber','dsTestCaseDocOid','caActualTime','qualityState','testRemark','problemNumber'
            ],
            idProperty: 'id'
        });


        // create the Data Store
        var requireTreeStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'requireTreeModel',
            id:'requireTreeStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/report/require/getRequireTree?projectOid='+projectOid,
                method:'GET',
                timeout:900000000,
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });

        this.cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var requireTreeGrid = Ext.create('Ext.grid.Panel', {
            plugins: [this.cellEditing],
            store:Ext.data.StoreManager.lookup('requireTreeStore'),
            id:'requireTreeGrid',
            title:'需求结构树',
            autoWidth : true,
            autoScroll:true,
            autoHeight:true,
            viewConfig:{enableTextSelection:true},
//				selModel: {
//					selType: 'cellmodel'
//				},
            selType: 'checkboxmodel',
            listeners: {
                change:'onAllCircuitsChecked'
            },
            features: [{
                ftype: 'summary',
                dock: 'bottom'
            }],
            columns: [
                new Ext.grid.RowNumberer({
                    align:"center",
                    width : 50,
                    renderer:function(value, metaData, record, rowIdx, colIdx, store) {
                        return rowIdx + 1;
                    }
                }),
                { text: 'id',dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
                { text: '类型',dataIndex: 'requireType',width:50 ,menuDisabled:true},
                { text: '编号',dataIndex: 'number',width:130 ,menuDisabled:true,summaryType: 'count',
                    summaryRenderer: function(value){
                        return Ext.String.format('共 {0} 条数据', value);
                    }},
                { text: '需求标题',dataIndex: 'requireTitle',width:150 ,menuDisabled:true},
                { text: 'DS需求描述',	dataIndex: 'dsRequireDesc',width:100 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                { text: 'DS需求备注说明',	dataIndex: 'dsRequireRemark',width:150 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                { text: 'DS构件', dataIndex: 'dsComponent',width:100 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                { text: 'DS领域',dataIndex: 'dsDomain',width:100,renderer: function(value,metaData,record,row,col,store){
                        //
                        return value;
                    },menuDisabled:true
                },
                { text: 'DS优先级',dataIndex: 'dsPriority',width:100 ,renderer: function(value,metaData,record,row,col,store){
                        //
                        return value;
                    },menuDisabled:true
                },
                { text: 'DS重要性',dataIndex: 'dsImportance',width:100 ,renderer: function(value,metaData,record,row,col,store){
                        //
                        return value;
                    },menuDisabled:true
                },
                { text: '是否自验报告',dataIndex: 'isSelfVerify',width:120 ,renderer: function(value,metaData,record,row,col,store){
                        if(value=="Y") {
                            value="是";
                        }else if(value=="N") {
                            value="否";
                        }
                        return value;
                    },menuDisabled:true
                },
                { text: 'DS自验报告文档编号',dataIndex: 'dsSelfVerifyReportNumber',width:200 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(value) {
                            var docLink = "<a href='" + urlPathPrefix +record.get('dsSelfVerifyReportDocOid') +"' target='_blank' >"
                                + value + "</a>";
                            return docLink;
                        }else {
                            return value;
                        }
                    },editor:'textfield'},
                { text: '研发责任人',dataIndex: 'rdPersonLiable',width:100 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                { text: '研发计划时间',dataIndex: 'rdPlanTime',width:120 ,menuDisabled:true,renderer:selfDateFormat},
                { text: '研发进度',dataIndex: 'rdProgress',width:85 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value==0&&record.get('qualityState')=="") {
                            value ="";
                        }
                        return value;
                    }
                },
                { text: '研发备注',	dataIndex: 'rdRemark',width:100 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                { text: '研发实际时间',dataIndex: 'rdActualTime',width:120 ,menuDisabled:true,
                    renderer: selfDateFormat

                },
                { text: '需求实现确认（SE）',dataIndex: 'implementConfirm',width:150 ,menuDisabled:true
                },
                { text: '需求实现确认备注（SE）',dataIndex: 'implementConfirmRemark',width:200 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                { text: '测试验收责任人',dataIndex: 'caPersonLiable',width:150 ,menuDisabled:true},
                { text: '测试验收计划时间',dataIndex: 'caPlanTime',width:180 ,menuDisabled:true,renderer:selfDateFormat},
                { text: '测试验收进度',dataIndex: 'caProgress',width:120 ,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value==0) {
                            value ="";
                        }
                        return value;
                    },menuDisabled:true},
                { text: '是否有对应测试用例',dataIndex: 'isTestCase',width:200 ,renderer: function(value,metaData,record,row,col,store){
                        if(value=="Y") {
                            value="是";
                        }else if(value=="N") {
                            value="否";
                        }
                        return value;
                    },menuDisabled:true
                },
                { text: 'DS测试用例文档编号',dataIndex: 'dsTestCaseNumber',width:200 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';

                        if(value) {
                            var docLink = "<a href='" + urlPathPrefix +record.get('dsTestCaseDocOid') +"' target='_blank' >"
                                + value + "</a>";
                            return docLink;
                        }else {
                            return value;
                        }
                    },editor:'textfield'},
                { text: '验收实际时间',dataIndex: 'caActualTime',width:120 ,menuDisabled:true,
                    renderer: selfDateFormat
                },
                { text: '质量状态',dataIndex: 'qualityState',width:80 ,renderer: function(value,metaData,record,row,col,store){

                        metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode("<font color='green'>绿（测试通过）</font><br><font color='yellow'> 黄（有条件测试通过）</font><br> <font color='red'> 红（测试未通过）</font>") + '"';

                        if("红"==value) {
                            var img = "<img src='" + imagePath +"red_16x16.gif'>";
                            return img;
                        }else if("黄"==value) {
                            var img = "<img src='" + imagePath +"yellow_16x16.gif'>";
                            return img;
                        }else if("绿"==value) {
                            var img = "<img src='" + imagePath +"green_16x16.gif'>";
                            return img;
                        }else {
                            return '';
                        }
                    },menuDisabled:true
                },
                { text: '测试备注',dataIndex: 'testRemark',width:100 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                { text: '转问题编号',dataIndex: 'problemNumber',width:100 ,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                }
            ],
            tbar: [{
                text: '导出',
                iconCls : 'icon icon-store-export',
                scope: this,
                handler : function(){
                    window.location.href =
                        '/Windchill/ptc1/report/require/exportRequireTree?projectOid='+projectOid;
                }
            }],
            listeners:{
                'beforeedit': function  (editor,  e,  eOpts)  {
                    if(e.field!="") {
                        return false;
                    }
                }
            }
        });

/////////////////////////Main Panel items//////////////////////////////////
        this.items=[requireTreeGrid];

        this.callParent();

    },//~End of initComponent
    listeners:{
        'afterrender':function() {
            //加载列表
            Ext.getStore('requireTreeStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        alert('查詢失敗，请联系管理员！' + operation.getError());
                    } else {
                    }

                }
            });
        }
    }
});
//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}