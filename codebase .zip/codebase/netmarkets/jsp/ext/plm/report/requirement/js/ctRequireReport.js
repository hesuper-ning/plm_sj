Ext.define('PLM.view.RequireReportPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.RequireReportPanel',
    border:false,
    layout:'anchor',
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'requireReportPanel',
    initComponent:function(){
        Ext.define('requireReportModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','reportType'
            ],
            idProperty: 'a'
        });


        // create the Data Store
        var requireTreeStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'requireReportModel',
            id:'requireReportStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/report/require/getReports?projectOid='+projectOid,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });

        this.cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var record_start = 0;
        var number=0;
        var requireReportGrid = Ext.create('Ext.grid.Panel', {
            plugins: [this.cellEditing],
            store:Ext.data.StoreManager.lookup('requireReportStore'),
            id:'requireReportGrid',
            title:'需求报表查询',
            autoWidth : true,
            autoScroll:true,
            autoHeight:true,
            viewConfig:{enableTextSelection:true},
            selModel: {
                selType: 'cellmodel'
            },
            selType: 'checkboxmodel',
            listeners: {
                change:'onAllCircuitsChecked'
            },

            columns: [
                new Ext.grid.RowNumberer({
                    header : "序号",
                    width : 60,
                    renderer:function(value,metadata,record,rowIndex){
                        number=record_start + 1 + rowIndex;
                        return record_start + 1 + rowIndex;
                    }
                }),
                { text: 'ID',  dataIndex: 'id',menuDisabled:true, hidden:true },
                { text: '报表类型',  dataIndex: 'reportType',width:200,menuDisabled:true}

            ]
        });

/////////////////////////Main Panel items//////////////////////////////////
        this.items=[requireReportGrid];

        this.callParent();

    }//~End of initComponent
});
