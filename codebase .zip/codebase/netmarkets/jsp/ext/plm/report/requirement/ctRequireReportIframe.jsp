<%@ page language="java" import="java.util.*"  contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");

%>
<iframe id="ctRequireReportIframe" src="netmarkets/jsp/ext/plm/report/requirement/ctRequireReport.jsp?oid=<%=oid%>" style="width:98%;height:500px" ></iframe>
