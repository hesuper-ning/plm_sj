<%@ page language="java" import="java.util.*"  contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");

%>
<iframe id="ctPersonalRequireRateIframe" src="/Windchill/netmarkets/jsp/ext/plm/report/requirement/ctPersonalRequireRate.jsp?oid=<%=oid%>" style="width:99%;height:550px" ></iframe>
<script type="text/javascript">
    window.onload = function() {
        var iframe = document.getElementById("ctPersonalRequireRateIframe");
        iframe.style.height = window.innerHeight*95/100 + 'px';
    };
</script>