<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%


        String oid = request.getParameter("oid");
        System.out.println("ctRequireReport.jsp   oid>>>>>>>>>>>>"+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();

        String projectOid="";
        Object obj = rf.getReference(oid).getObject();
        if(obj instanceof com.ptc.projectmanagement.plan.Plan) {
            com.ptc.projectmanagement.plan.Plan plan = (com.ptc.projectmanagement.plan.Plan)obj;
            wt.projmgmt.admin.Project2 project = (wt.projmgmt.admin.Project2)plan.getHolder().getObject();
            projectOid = ext.plm.util.CtWTObjectUtil.getOid(project);
        }else if(obj instanceof wt.projmgmt.admin.Project2) {
            wt.projmgmt.admin.Project2 project = (wt.projmgmt.admin.Project2)obj;
            projectOid = ext.plm.util.CtWTObjectUtil.getOid(project);
        }

        wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
        String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=";
    %>
    <script>
        //项目oid
        var projectOid = "<%=projectOid%>";

    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctRequireReport.js?_dc=<%System.currentTimeMillis();%>"></script>
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'RequireReportPanel'
            }]
        });
    });
</script>
</body>
</html>