Ext.define('PLM.view.RequireSummaryPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.RequireSummaryPanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'requireSummaryPanel',
    initComponent: function () {
        var me = this;

        //================== 开始  requireSummaryGrid ======================
        Ext.define('requireSummaryModel', {
            extend: 'Ext.data.Model',
            fields: [
                'branchId','projectNumber','projectName','dsRequireDocNumber','dsTotalCount','dsFinishCount','dsFinishRate',
                'dsInTimeFinishCount','dsInTimeFinishRate','green','yellow','red','greenRatio',
                'problemCount','changeCount','planChangeCount'
            ],
            idProperty: 'branchId'
        });


        // create the Data Store
        var requireSummaryStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'requireSummaryModel',
            id:'requireSummaryStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/report/require/getRequireSummary',
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'branchId',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });


        var requireSummaryGrid = Ext.create('Ext.grid.Panel', {
            store:Ext.data.StoreManager.lookup('requireSummaryStore'),
            id:'requireReportGrid',
            title:'需求报表查询<font color="red">（没有需求条目的需求跟踪矩阵不在搜索范围内）</font>',
            autoWidth : true,
            autoScroll:true,
            autoHeight:true,
            viewConfig:{enableTextSelection:true},
            selModel: {
                selType: 'cellmodel'
            },
            selType: 'checkboxmodel',
            listeners: {
                change:'onAllCircuitsChecked'
            },

            columns: [
                { text:'序号', xtype:'rownumberer', width:60,menuDisabled:true },
                {text:'branchId',dataIndex:'branchId',hidden: true},
                { text: '项目编号',  dataIndex: 'projectNumber',width:100,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        var projectLink =  record.get('projectLink');
                        if(projectLink)return projectLink;
                        return value;
                    }
                },
                { text: '项目名称',  dataIndex: 'projectName',width:100,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                { text: '需求矩阵文档',  dataIndex: 'dsRequireDocNumber',width:150,menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        var dsRequireDocLink =  record.get('dsRequireDocLink');
                        if(dsRequireDocLink)return dsRequireDocLink;
                        return value;
                    }
                },
                {
                    text: '<b>项目交付统计</b>',
                    columns: [
                        { text: '项目DS总数',dataIndex: 'dsTotalCount',width:150 ,menuDisabled:true},
                        { text: '项目DS交付数',dataIndex: 'dsFinishCount',width:150 ,menuDisabled:true},
                        { text: '项目DS交付完成率',dataIndex: 'dsFinishRate',width:160 ,menuDisabled:true},
                        { text: '项目DS及时交付数',dataIndex: 'dsInTimeFinishCount',width:160 ,menuDisabled:true},
                        { text: '项目DS及时交付率',dataIndex: 'dsInTimeFinishRate',width:160 ,menuDisabled:true}
                    ],
                    menuDisabled:true
                },{
                    text: '<b>需求质量状态</b>',
                    columns: [
                        { text: '绿灯',dataIndex: 'green',width:50 ,menuDisabled:true},
                        { text: '黄灯',dataIndex: 'yellow',width:50 ,menuDisabled:true},
                        { text: '红灯',dataIndex: 'red',width:50 ,menuDisabled:true},
                        { text: '绿灯比例',dataIndex: 'greenRatio',width:90 ,menuDisabled:true}
                    ],
                    menuDisabled:true
                },
                {text:'转问题数量',dataIndex:'problemCount',width:120,menuDisabled:true},
                {text:'需求变更次数',dataIndex:'changeCount',width:150,menuDisabled:true},
                {text:'需求计划调整次数',dataIndex:'planChangeCount',width:200,menuDisabled:true}
            ]
        });





        var queryParameter = {
            title:'查询参数',
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '10 0 10 10',
                items: [{
                    margin: '0 20 0 0',
                    fieldLabel: '项目编号',
                    labelWidth: 70,
                    id:'projectNumber',
                    name: 'projectNumber',
                    allowBlank: false,
                    width: 300,
                },{
                    margin: '0 20 0 0',
                    fieldLabel: '项目名称',
                    labelWidth: 70,
                    id:'projectName',
                    name: 'projectName',
                    allowBlank: false,
                    width: 300,
                }]
            },{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'button',
                margin: '20 0 0 10',
                items: [{
                    margin: '0 20 10 0',
                    text: '查询',
                    name: 'search',
                    width: 100,
                    handler:function () {
                        doSearch();
                    }
                },{
                    margin: '0 20 10 0',
                    text: '导出查询记录',
                    name: 'exportSearchRecord',
                    hidden:true,
                    width: 100,
                    handler:function () {
                        window.location.href="/Windchill/ptc1/...";
                    }
                }]
            }]
        };



/////////////////////////Main Panel items//////////////////////////////////
        this.items = [queryParameter, requireSummaryGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('requireSummaryStore').load({
                callback: function(records, operation, success) {
                    if(!success){
                        alert(operation.getError());
                    }
                }
            });
        }
    }
});


function doSearch(){
    var projectNumber = Ext.getCmp('projectNumber').getValue();
    var projectName = Ext.getCmp('projectName').getValue();
    Ext.getStore("requireSummaryStore").clearFilter();
    if(!projectNumber&&!projectName){
        return;
    }
    Ext.getStore("requireSummaryStore").filterBy(function(record, id) {
        if((projectNumber&&record.get('projectNumber').indexOf(projectNumber)>-1)||(projectName&&record.get('projectName').indexOf(projectName)>-1))
            return true;
        else
            return false;
    });

}



