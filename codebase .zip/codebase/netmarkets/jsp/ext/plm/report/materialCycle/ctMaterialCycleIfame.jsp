
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<iframe id="ctMaterialCycleIfame" src="netmarkets/jsp/ext/plm/report/materialCycle/ctMaterialCycleReport.jsp" style="width:98%;height:600px" ></iframe>
