Ext.define('PLM.view.ctMaterialCycleInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctMaterialCycleInfo',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ctMaterialCycleInfo',
    initComponent: function () {
        Ext.define('ctMaterialCycleListModel', {
            extend: 'Ext.data.Model',
            fields: [
				'materialCode', 'materialDescription', 'materialGroup','currentVersion','currentState',
				'admittedVersion','admittedState','admittingProgress','creationTime','admittingTime',
				'admittingCycle','processType','processNumber','largeVersion','processBeforeStatus',
				'processAfterStatus','processBeginTime','processEndTime','processCycle',
				'currentProcessStatus'
			],
            idProperty: 'ctMaterialCycleListModel'
        });

        // 查询 Store
        var ctMaterialCycleListStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'ctMaterialCycleListModel',
            id:'ctMaterialCycleListStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/reportForms/getMaterialCycleReport',
                method:'GET',
                timeout: 9000000,
                reader:{
                    type:'json',
                    root: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'ctMaterialCycleListModel',
                    messageProperty: 'massage'
                }
            }),
            autoLoad:false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var documentSummaryListGrid = Ext.create('Ext.grid.Panel', {
            plugins: cellEditing,
            store:ctMaterialCycleListStore,
            autoWidth : true,
            autoScroll:true,
            height:400,
            viewConfig:{enableTextSelection:true, forceFit : false},
            columns: [
			{
			    text: '<b>物料承认周期</b>',
			    columns: [
	            { text: '物料编码', dataIndex: 'materialCode', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '物料描述', dataIndex: 'materialDescription', width: 250, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '物料组及描述', dataIndex: 'materialGroup', width: 80, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '当前版本', dataIndex: 'currentVersion', width: 80, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '当前状态', dataIndex: 'currentState', width: 80, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '承认版本', dataIndex: 'admittedVersion', width: 80, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '承认状态', dataIndex: 'admittedState', width: 80, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '承认进度', dataIndex: 'admittingProgress', width: 80, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '创建时间', dataIndex: 'creationTime', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '承认时间', dataIndex: 'admittingTime', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
                { text: '承认周期（天）', dataIndex: 'admittingCycle', width: 80, align: 'center',menuDisabled: true,renderer:showTip}
			    ],
			    menuDisabled:true
			},
			{
			    text: '<b>相关承认流程</b>',
			    columns: [
					{ text: '流程类型', dataIndex: 'processType', width: 150, align: 'center',menuDisabled: true,renderer:showTip},
					{ text: '流程编号', dataIndex: 'processNumber', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
					{ text: '大版本', dataIndex: 'largeVersion', width: 80, align: 'center',menuDisabled: true,renderer:showTip},
					{ text: '流程执行前状态', dataIndex: 'processBeforeStatus', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
					{ text: '流程执行后状态', dataIndex: 'processAfterStatus', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
					{ text: '流程发起时间', dataIndex: 'processBeginTime', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
					{ text: '流程结束时间', dataIndex: 'processEndTime', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
					{ text: '流程周期（天）', dataIndex: 'processCycle', width: 100, align: 'center',menuDisabled: true,renderer:showTip},
					{ text: '当前流程状态', dataIndex: 'currentProcessStatus', width: 80, align: 'center',menuDisabled: true,renderer:showTip}
			    ],
			    menuDisabled:true
			}
            ]
        });





// ========================Items Area======================//

        this.items=[
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">查询条件</font><font color=red bold>【建议输入查询条件，否则查询时间会很长】</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100,
                    border: false,
                    anchor: '99%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                    xtype: 'panel',
                    defaults: {margin: '5 20 20 0', labelWidth: 70},
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: '物料编码',
                            name: 'materialCode',
                            id: 'materialCode',
                            width: 250,
                            enableKeyEvents: true
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '物料名称',
                            name: 'materialName',
                            id: 'materialName',
                            width: 250,
                            enableKeyEvents: true
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '物料组及描述',
                            name: 'materialGroup',
                            id: 'materialGroup',
                            width: 250,
                            enableKeyEvents: true
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '流程类型',
                            name: 'processType',
                            id: 'processType',
                            width: 250,
                            enableKeyEvents: true
                        }
                    ]
                },{
                    xtype: 'panel',
                    defaults: {margin: '5 20 20 0', labelWidth: 70},
                    items: [
						{
						    xtype:completeCombo,
						},
                        {
                            xtype: 'datefield',
                            id: 'creationTimeBeginTime',
                            name:'creationTimeBeginTime',
                            fieldLabel: '创建时间从',
                            margin: '0 5 0 15',
                            format:'Y-m-d',
                            allowBlank: false
                        },
                        {
                            xtype: 'datefield',
                            id: 'creationTimeEndTime',
                            name:'creationTimeEndTime',
                            labelWidth: 70,
                            format:'Y-m-d',
                            fieldLabel: '到',
                            allowBlank: false
                        }
                    ]
                }, {
                    xtype: 'panel',
                    defaults: {margin: '5 20 20 0', labelWidth: 70},
                    items: [
                    {
                        xtype:'button',
                        // margin:'10 0 10 0',
                        width:70,
                        text: '查询',
                        scope:this,
                        iconCls: 'icon icon-search',
                        handler: function() {
                            doSearch();
                        }
                    },
                    {
                        xtype: 'button',
                        text: '导出为Excel文件',
                        id:'ctMaterialCycleExport',
                        iconCls: 'icon icon-exportExcel',
                        handler: function () {
                        	var materialCodeQ = Ext.getCmp('materialCode').getValue();
                        	var materialNameQ = Ext.getCmp('materialName').getValue();
                        	var materialGroupQ = Ext.getCmp('materialGroup').getValue();
                        	var processTypeQ = Ext.getCmp('processType').getValue();
                        	var admittingProgressQ = Ext.getCmp('admittingProgress').getValue();
                        	var creationTimeBeginTimeDt = Ext.getCmp('creationTimeBeginTime').getValue();
                        	var creationTimeEndTimeDt = Ext.getCmp('creationTimeEndTime').getValue();
                        	
                        	var creationTimeBeginTime = "";
                        	if(creationTimeBeginTimeDt){
                        		creationTimeBeginTime = Ext.util.Format.date(new Date(creationTimeBeginTimeDt),'Y-m-d');
                        	}
                        	var creationTimeEndTime = "";
                        	if(creationTimeEndTimeDt){
                        		creationTimeEndTime = Ext.util.Format.date(new Date(creationTimeEndTimeDt),'Y-m-d');
                        	}
                        	/*if(!creationTimeBeginTime){
                        		alert('请选择开始时间');
                        		return;
                        	} 
                        	if(!creationTimeEndTime){
                        		alert('请选择结束时间');
                        		return;
                        	}
                        	const date1 = new Date(creationTimeBeginTime);
                        	const date2 = new Date(creationTimeEndTime);
                        	date1.setMonth(date1.getMonth() + 3);
                        	if (date1 <= date2) {
                        	    alert('结束时间不能超过开始时间3个月');
                        	    return ;
                        	} */
                            window.location.href = '/Windchill/ptc1/reportForms/ctMaterialCycleReportExport?'
                            +'materialCode='+materialCodeQ+'&materialName='+materialNameQ+'&materialGroup='+materialGroupQ
                				+'&processType='+processTypeQ+'&admittingProgress='+admittingProgressQ
                				+'&creationTimeBeginTime='+creationTimeBeginTime+'&creationTimeEndTime='+creationTimeEndTime;
                        },
                        scope: this
                    }]
                }]
            },
            documentSummaryListGrid];
        this.callParent();

    },// ~End of initComponent
});

/**
 * 按查询参数查询
 */
function doSearch() {
	var materialCodeQ = Ext.getCmp('materialCode').getValue();
	var materialNameQ = Ext.getCmp('materialName').getValue();
	var materialGroupQ = Ext.getCmp('materialGroup').getValue();
	var processTypeQ = Ext.getCmp('processType').getValue();
	var admittingProgressQ = Ext.getCmp('admittingProgress').getValue();
	var creationTimeBeginTimeDt = Ext.getCmp('creationTimeBeginTime').getValue();
	var creationTimeEndTimeDt = Ext.getCmp('creationTimeEndTime').getValue();
	
	var creationTimeBeginTime = null;
	if(creationTimeBeginTimeDt){
		creationTimeBeginTime = Ext.util.Format.date(new Date(creationTimeBeginTimeDt),'Y-m-d');
	}
	var creationTimeEndTime = null;
	if(creationTimeEndTimeDt){
		creationTimeEndTime = Ext.util.Format.date(new Date(creationTimeEndTimeDt),'Y-m-d');
	}
	/*if(!creationTimeBeginTime){
		alert('请选择开始时间');
		return;
	} 
	if(!creationTimeEndTime){
		alert('请选择结束时间');
		return;
	}
	const date1 = new Date(creationTimeBeginTime);
	const date2 = new Date(creationTimeEndTime);
	date1.setMonth(date1.getMonth() + 3);
	if (date1 <= date2) {
	    alert('结束时间不能超过开始时间3个月');
	    return ;
	} */
	Ext.getStore('ctMaterialCycleListStore').load({
		params : {
			materialCode : materialCodeQ,
			materialName : materialNameQ,
			materialGroup : materialGroupQ,
			processType:processTypeQ,
			admittingProgress : admittingProgressQ,
			creationTimeBeginTime : creationTimeBeginTime,
			creationTimeEndTime : creationTimeEndTime
			
		},
		callback : function(records, operation, success) {
			if (!success) {
				var responseText = operation.getResponse().responseText;
				var responseObject = Ext.decode(responseText);
				alert(responseObject.message);
				// alert('查询信息失败，请联系管理员！');
			}
		}
	});
}
//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}

var completeCombo = new Ext.form.field.ComboBox({
    multiSelect: false,
    anyMatch: true,
    editable : true,
    fieldLabel: '承认进度',
//    margin: '0 20 0 0',
    labelWidth: 70,
    width: 250,
    // forceSelection: true, //forceSelection 是否能够手填
    id: 'admittingProgress',
    name: 'admittingProgress',
    mode: 'local',
    store: new Ext.data.ArrayStore({
        id: 0,
        fields: [
            'key',
            'displayText'
        ],
        data: [['已完成', '已完成'], ['未完成', '未完成']]
//        data: [["SUSPENDED", "已暂停"],["DEFINED", "已定义"]
//            ,["RUNNING", "正在运行"],["CANCELLED", "已取消"]
//            ,["COMPLETED", "已完成"]]
    }),
    valueField: 'key',
    displayField: 'displayText',
});
