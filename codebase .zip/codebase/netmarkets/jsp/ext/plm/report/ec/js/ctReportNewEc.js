var itemsStart = 0;   // 设置开始条
var itemsPerPage = 20;   // 设置你想要的每页显示条数
Ext.define('PLM.view.reportNewEcPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.reportNewEcPanel',
    title: '<font style="font-size:15px">ECN报表（新）</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'reportNewEcPanel',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {

        Ext.define('reportNewEcModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'changeRequestId', 'head_ecrNumber', 'head_ecrName', 'head_changeType', 'head_productModel', 'head_changeReason', 'head_changeDesc',
                'trialSuggest', 'head_applicant', 'head_applyTime', 'head_affectedEndParts', 'head_affectedBOMs', 'head_affectedDocs',
                'rdRep_auditUser', 'rdRep_auditTime', 'ebomCharge_auditUser', 'ebomCharge_auditTime', 'mbomCharge_auditUser',
                'mbomCharge_auditTime', 'consistencyRisk_auditUser', 'consistencyRisk_auditTime', 'ccbGroup_auditTime',
                'pdt_auditTime', 'pdt_auditUser', 'ccb_auditTime', 'ipmt_auditTime', 'ecrApprovalTime', 'result_auditTime',
                'pdt_endItemsPlan1', 'pdt_endItemsPlan2', 'pdt_endItemsPlan3', 'pdt_endItemsPlan4', 'pdt_endItemsPlan5',
                'pdt_materialPlan1', 'pdt_materialPlan2', 'pdt_materialPlan3', 'pdt_materialPlan4', 'partF', 'ebomF', 'mbomF', 'state'
                , 'createDate', 'ecrNumber', 'ecnNumber', 'ecaNumber', 'trialSuggest', 'handlingOpinions',
                'ecn_startTime','ecn_endTime','eca_startTime','eca_endTime','closeDocNumber','doc_startTime',
                'closeDocEndTime','ecr_eca','ecr_close','changeSource'
            ],
            idProperty: 'changeRequestId'
        });
        // create the Data Store
        var reportNewEcStore = Ext.create('Ext.data.Store', {
            pageSize: itemsPerPage,
            model: 'reportNewEcModel',
            id: 'reportNewEcStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getNewEcReport',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
//		        autoLoad:{start:0,limit:itemsPerPage}
//		        autoLoad:false
        });
        reportNewEcStore.on('beforeload', function (store, options) {
            var paramAllNew = Ext.getCmp('paramAllNew').getValue(); //公共参数
            var state = Ext.getCmp('state').getValue();
            var createDate_start = Ext.getCmp('createDate_start').getValue();
            if(createDate_start!=null&&createDate_start!=""){
                createDate_start = Ext.Date.format(createDate_start, "Y-m-d");
            }
            var createDate_end = Ext.getCmp('createDate_end').getValue();
            if(createDate_end!=null&&createDate_end!=""){
                createDate_end = Ext.Date.format(createDate_end, "Y-m-d");
            }
            var params = {
                paramAllNew: paramAllNew,
                limit: itemsPerPage,
                state: state,
                createDate_start: createDate_start,
                createDate_end: createDate_end
            };
            Ext.apply(store.proxy.extraParams, params);
        });
        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var reportNewEcGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            padding: 1,
            store: Ext.data.StoreManager.lookup('reportNewEcStore'),
            id: 'reportNewEcGrid',
            autoWidth: true,
            autoScroll: true,
            height: 530,
            region: 'center',
            viewConfig: {enableTextSelection: true},
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {xtype: 'rownumberer', width: 35},
                {text: '更改编号', dataIndex: 'ecrNumber', width: 90, menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(record.get("state")=="已解决"){
                            metaData.style='background: greenyellow';
                        }
                        return value;
                    }
                },
                {text: '更改名称', dataIndex: 'head_ecrName', width: 90, menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }},
                {text: '状态', dataIndex: 'state', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {text: '更改类型', dataIndex: 'head_changeType', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {text: '变更来源', dataIndex: 'changeSource', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {text: '变更原因描述', dataIndex: 'head_changeReason', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                //{text: '变更描述', dataIndex: 'head_changeDesc', width: 90, menuDisabled: true},
                {text: '产品型号', dataIndex: 'head_productModel', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {text: '物料变更父项编码', dataIndex: 'partF', width: 160, menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {text: 'EBOM父项所属成品编码', dataIndex: 'ebomF', width: 200, menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    } },
                {text: 'MBOM父项所属成品编码', dataIndex: 'mbomF', width: 200, menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                // {text: '受影响的成品', dataIndex: 'head_affectedEndParts', width: 90, menuDisabled: true},
                {text: '受影响的物料、BOM', dataIndex: 'head_affectedBOMs', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {text: '受影响的文档', dataIndex: 'head_affectedDocs', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {text: '是否试产', dataIndex: 'trialSuggest', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {
                    text: '变更发起',
                    columns: [
                        {text: '发起人', dataIndex: 'head_applicant', width: 90, menuDisabled: true},
                        {text: '发起时间', dataIndex: 'createDate', width: 90, menuDisabled: true}
                    ]
                },
                {
                    text: '开发代表审核',
                    columns: [
                        {text: '审核人', dataIndex: 'rdRep_auditUser', width: 90, menuDisabled: true},
                        {text: '审核时间', dataIndex: 'rdRep_auditTime', width: 90, menuDisabled: true}
                    ]
                },
                {
                    text: 'EBOM变更负责人制定EBOM变更方案',
                    columns: [
                        {text: '负责人', dataIndex: 'ebomCharge_auditUser', width: 90, menuDisabled: true},
                        {text: '完成时间', dataIndex: 'ebomCharge_auditTime', width: 90, menuDisabled: true}
                    ]
                },
                {
                    text: 'MBOM变更负责人制定MBOM变更方案',
                    columns: [
                        {text: '负责人', dataIndex: 'mbomCharge_auditUser', width: 90, menuDisabled: true},
                        {text: '完成时间', dataIndex: 'mbomCharge_auditTime', width: 90, menuDisabled: true}
                    ]
                },
                {
                    text: '产品一致性风险识别',
                    columns: [
                        {text: '负责人', dataIndex: 'consistencyRisk_auditUser', width: 90, menuDisabled: true},
                        {text: '完成时间', dataIndex: 'consistencyRisk_auditTime', width: 90, menuDisabled: true}
                    ]
                },
                {text: 'CCB评审完成时间', dataIndex: 'ccbGroup_auditTime', width: 90, menuDisabled: true},
                {text: '处理意见', dataIndex: 'handlingOpinions', width: 90, menuDisabled: true
                    ,renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
                {
                    text: 'CCB评审意见汇总人汇总评审意见',
                    columns: [
                        {text: '汇总人', dataIndex: 'pdt_auditUser', width: 90, menuDisabled: true},
                        {text: '完成时间', dataIndex: 'pdt_auditTime', width: 90, menuDisabled: true}
                    ]
                },
                {text: 'CCB方案批准时间', dataIndex: 'ccb_auditTime', width: 90, menuDisabled: true},
                {text: '认证技术负责人审核时间', dataIndex: 'ipmt_auditTime', width: 90, menuDisabled: true},
                {text: 'ECR批准时间', dataIndex: 'ecrApprovalTime', width: 90, menuDisabled: true},
                {text: '变更结束时间', dataIndex: 'result_auditTime', width: 90, menuDisabled: true},
                {text: 'ECN编号', dataIndex: 'ecnNumber', width: 90, menuDisabled: true},
                {text: 'ECN开始时间', dataIndex: 'ecn_startTime', width: 90, menuDisabled: true},
                {text: 'ECN结束时间', dataIndex: 'ecn_endTime', width: 90, menuDisabled: true},
                {text: 'ECA编号', dataIndex: 'ecaNumber', width: 90, menuDisabled: true},
                {text: 'ECA开始时间', dataIndex: 'eca_startTime', width: 90, menuDisabled: true},
                {text: 'ECA结束时间', dataIndex: 'eca_endTime', width: 90, menuDisabled: true},
                {text: '闭环流程文档', dataIndex: 'closeDocNumber', width: 90, menuDisabled: true},
                {text: '闭环流程开始时间', dataIndex: 'doc_startTime', width: 90, menuDisabled: true},
                {text: '闭环流程结束时间', dataIndex: 'closeDocEndTime', width: 90, menuDisabled: true},
                {text: 'ECR-ECA周期（天）', dataIndex: 'ecr_eca', width: 90, menuDisabled: true},
                {text: '完整周期（天）', dataIndex: 'ecr_close', width: 90, menuDisabled: true}
            ],
            selType: 'checkboxmodel',
            tbar: [],
            bbar: Ext.create('Ext.PagingToolbar', {
                store: Ext.data.StoreManager.lookup('reportNewEcStore'),
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1}条 ，共 {2}条',
                emptyMsg: "查询结果为空"
            })
            // ~End bbar
        });

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [{
            xtype: 'fieldset',
            margin: '5 3 10 3',
            title: '<font style="font-size:12px">查询参数</font>',
            collapsible: true,
            defaults: {
                labelWidth: 100, border: false, anchor: '98%',
                margin: '5 20 10 0',
                layout: {
                    type: 'hbox'
                }
            },
            items: [{
                xtype: 'panel',
                defaults: {
                    margin: '5 20 0 0',
                    labelWidth: 25
                },
                items: [{
                    xtype: 'textfield',
                    disabledCls: 'none',
                    fieldLabel: '公共参数',
                    labelWidth: 60,
                    name: 'paramAllNew',
                    id: 'paramAllNew',
                    width: '35%',
                    emptyText: '可输入列表中的任意列的值当参数进行过滤',
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                reportNewEcGrid.getStore().lastOptions.start = 0;
                                doSearchEcList();
                            }
                        }
                    }
                }]
            }, {
                xtype: 'panel',
                defaults: {
                    margin: '5 20 0 0',
                    labelWidth: 25
                },
                items: [{
                    xtype: 'combo',
                    disabledCls: 'none',
                    fieldLabel: '状态',
                    labelWidth: 60,
                    name: 'stateNew',
                    id: 'stateNew',
                    width: 200,
                    store:[[' ',' '],['OPEN','开启'],['IN REVIEW','正在审阅'],['APPROVED','已批准'],['REJECTED','已否决']
                    ,['IMPLEMENTATION','实施'],['RESOLVED','已解决'],['CANCELLED','已取消'],['REWORK','返工']],
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                reportNewEcGrid.getStore().lastOptions.start = 0;
                                doSearchEcList();
                            }
                        }
                    }
                }, {
                    xtype:'datefield',
                    labelWidth:70,
                    width:250,
                    fieldLabel:'申请日期从:',
                    format:'Y-m-d',
                    id:'createDate_start_New',
                    name:'createDate_start_New',
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                reportNewEcGrid.getStore().lastOptions.start = 0;
                                doSearchEcList();
                            }
                        }
                    }
                },
                    {
                        xtype:'datefield',
                        labelWidth:70,
                        width:250,
                        fieldLabel:'&nbsp;&nbsp;&nbsp;&nbsp;到:',
                        format:'Y-m-d',
                        id:'createDate_end_New',
                        name:'createDate_end_New',
                        listeners: {
                            scope: this,
                            'specialkey': function (field, e) {
                                if (e.getKey() == Ext.EventObject.ENTER) {
                                    reportNewEcGrid.getStore().lastOptions.start = 0;
                                    doSearchEcList();
                                }
                            }
                        }
                    }]
            }, {
                xtype: 'panel',
                defaults: {
                    margin: '5 20 0 0',
                    labelWidth: 25
                },
                items: [
                    {
                        xtype: 'button',
                        margin: '5 0 10 0',
                        width: 70,
                        text: '查询',
                        scope: this,
                        iconCls: 'icon icon-search',
                        handler: function () {
                            reportNewEcGrid.getStore().lastOptions.start = 0;
                            doSearchEcList();
                        }
                    },
                    {
                        xtype: 'button',
                        margin: '5 0 10 30',
                        text: 'Excel导出',
                        iconCls: 'icon icon-store-export',
                        scope: this,
                        handler: function () {
                            var paramAllNew = Ext.getCmp('paramAllNew').getValue(); //公共参数
                            var state = Ext.getCmp('stateNew').getValue();
                            var createDate_start = Ext.getCmp('createDate_start_New').getValue();
                            if(createDate_start!=null&&createDate_start!=""){
                                createDate_start = Ext.Date.format(createDate_start, "Y-m-d");
                            }
                            var createDate_end = Ext.getCmp('createDate_end_New').getValue();
                            if(createDate_end!=null&&createDate_end!=""){
                                createDate_end = Ext.Date.format(createDate_end, "Y-m-d");
                            }
                            var params = {
                                paramAll: paramAllNew,
                                state: state,
                                createDate_start: createDate_start,
                                createDate_end: createDate_end
                            };
                            window.location.href = "/Windchill/ptc1/ec/exportNewEcReport?data=" + Ext.encode(params);
                        }
                    },
                    {
                        xtype: 'button',
                        margin: '5 0 10 30',
                        width: 70,
                        text: '重置',
                        scope: this,
                        handler: function () {
                            var paramAllNew = Ext.getCmp('paramAllNew');
                            paramAllNew.reset();
                            var stateNew = Ext.getCmp('stateNew');
                            stateNew.reset();
                            var createDate_start_New = Ext.getCmp('createDate_start_New');
                            createDate_start_New.reset();
                            var createDate_end_New = Ext.getCmp('createDate_end_New');
                            createDate_end_New.reset();
                            let reportNewEcGridStore = Ext.getCmp("reportNewEcGrid").getStore();
                            reportNewEcGridStore.removeAll();
                            reportNewEcGridStore.reload({
                                    params:{
                                        paramAllNew:'',
                                        stateNew:'',
                                        createDate_start_New:'',
                                        createDate_end_New:''
                                    }
                                }
                            );
                        }
                    }
                ]
            }]
        }, reportNewEcGrid];

        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {
            // 初始化加载
            doSearchEcList();// 查询
        }
    },
    /**
     * 按查询参数查询
     */
    doSearch: function () {
        reportNewEcGrid.getStore().lastOptions.start = 0;
        doSearchEcList();// 查询
    }

});

function doSearchEcList() {
    var paramAllNew = Ext.getCmp('paramAllNew').getValue(); //公共参数
    var state = Ext.getCmp('stateNew').getValue();
    var createDate_start = Ext.getCmp('createDate_start_New').getValue();
    if(createDate_start!=null&&createDate_start!=""){
        createDate_start = Ext.Date.format(createDate_start, "Y-m-d");
    }
    var createDate_end = Ext.getCmp('createDate_end_New').getValue();
    if(createDate_end!=null&&createDate_end!=""){
        createDate_end = Ext.Date.format(createDate_end, "Y-m-d");
    }


    Ext.getStore('reportNewEcStore').reload({
        params: {
            paramAll: paramAllNew,
            start: itemsStart,
            limit: itemsPerPage,
            state: state,
            createDate_start: createDate_start,
            createDate_end: createDate_end
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！' + operation.getError());
            }
        }
    });
}
