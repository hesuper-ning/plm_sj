<%@ page import="ext.plm.util.CtUserUtil" pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<%
String userName = CtUserUtil.getCurrentUserDisplayName();
%>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
	<link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="js/ctReportEc.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctReportNewEc.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<style type="text/css">
		.x-grid-back-green{
			background:greenyellow;
		}
	</style>
</head>

<body>
<script>
    //是否为分页查询
    var isPageQuery = true;
    var USER_NAME = "<%=userName%>";

// ==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();

	Ext.create('Ext.container.Viewport', {
		layout: 'border',
		width: "100%",
		height: '100%',
		items: [ {
			region: 'center',
			items:[{
				xtype:'tabpanel',
				activeTab: 0,
				items:[
					{
						scrollable: true,
						title: '<font style="font-size:12px">ECN报表（新）</font>',
						xtype: 'reportNewEcPanel'
					},
					{
						title: '<font style="font-size:12px">ECN报表（旧）</font>',
						xtype: 'reportEcPanel'
					}
				]//~End of tabpanel items
			}]
			//}]//~End of center region items
		}]//~End of viewPort items
	});
});
</script>
</body>
</html>