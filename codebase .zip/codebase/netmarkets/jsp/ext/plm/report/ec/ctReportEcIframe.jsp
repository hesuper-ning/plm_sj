
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>


<iframe id="ctReportEcIframe" frameborder="0" marginwidth="0" marginheight="0" scrolling="yes" allowtransparency="yes"
src="netmarkets/jsp/ext/plm/report/ec/ctReportEc.jsp?" style="width:98%;height:600px" ></iframe>

<script type="text/javascript">
    var iframe = document.getElementById("ctReportEcIframe");
    iframe.style.height = window.innerHeight*95/100 + 'px';
</script>
