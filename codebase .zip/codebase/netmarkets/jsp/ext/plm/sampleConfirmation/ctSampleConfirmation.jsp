<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.workflow.engine.WfActivity" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="ext.plm.sampleConfirmation.config.CtSampleConfirmationProperties" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String workItemOid = request.getParameter("oid");
        long branchId = 1L;
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(workItemOid).getObject();
        String currentActKey = "";
        boolean taskCompleted = false; //任务是否已完成
        //文档只读表单展开
        boolean collapsedValue = false;
        long timestamp = System.currentTimeMillis();
        wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
        String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=VR:wt.part.WTPart:";
        String urlPathPrefixDoc = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=VR:wt.doc.WTDocument:";
        String promotionNoticeUrl = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=OR:wt.maturity.PromotionNotice:";
        String changeUrl = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=";
        if(obj instanceof WorkItem){
            WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            String actName = activity.getName();
            currentActKey = CtSampleConfirmationProperties.getActivityKey(actName);
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
            WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
            branchId = doc.getBranchIdentifier();
        }else if(obj instanceof WTDocument){
            WTDocument doc = (WTDocument) obj;
            branchId = doc.getBranchIdentifier();
            collapsedValue = true;
        }
    %>
    <script type="text/javascript">
        var workItemOid = "<%=workItemOid%>";
        var docNumber = '';
        var branchId = '<%=branchId%>';
        //列ID
        var fileColumnId = '';
        //列名
        var fileColumnName = '';
        //下载文件名称
        var uploadTableName = '';
        var gridName = '';
        //单一字段表ID
        var singleFieldId = '';

        var partNumber  = '';
        //判断是否是快速流程
        var fastTrack  = false;
        //url前缀
        var urlPathPrefix ="<%=urlPathPrefix%>";
        var urlPathPrefixDoc = "<%=urlPathPrefixDoc%>";
        var promotionNoticeUrl = "<%=promotionNoticeUrl%>";
        var changeUrl = "<%=changeUrl%>";
        var urlOa = "https://home.fhsjdz.com/km/review/km_review_main/kmReviewMain.do?method=view&fdId=";

        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";

        var collapsedValue = <%=collapsedValue%>;

        //当前的任务完成状态
        var taskCompleted = false;
        <%if(taskCompleted){%>
        taskCompleted = true;
        <%}%>

        var readOnlyPage = false;

        var showDeleteValue = true;

    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="js/uploadPanel.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctSampleConfirmationFunction.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctConfirmedFillInInformationConclusion.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctSampleConfirmation.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBasicInformation.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctCertifiedProductIdentification.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctEngineerConfirmationAndTesting.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctTQCUploadReport.js?_dc=<%=timestamp%>"></script>
    <%--<script type="text/javascript" src="js/ctSampleConfirmerFillInInformation.js?_dc=<%=timestamp%>"></script>--%>
    <%--<script type="text/javascript" src="js/ctTrialProductionAndUseResult.js?_dc=<%=timestamp%>"></script>--%>
    <%--<script type="text/javascript" src="js/ctIQCConfirmationResults.js?_dc=<%=timestamp%>"></script>--%>
    <%--<script type="text/javascript" src="js/ctTrialProductionAndUseResultAgain.js?_dc=<%=timestamp%>"></script>--%>
    <script type="text/javascript" src="js/ctQualityCenterConfirmation.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctMaintenanceMaterial.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctMaintenanceAndCertification.js?_dc=<%=timestamp%>"></script>
    



    <style>
        .x-form-item-label-default {
            text-align: center;
        }
    </style>

</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.apply(Ext.QuickTips.getQuickTip(), {
            dismissDelay: 120000
        });

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            // margin: '10 10 10 10',
            items: [{
                region: 'center',
                xtype: 'ctTemporaryTechnicalChanges',
            }]
        });
    });
</script>
</body>
</html>