
// ========================================S03工程师确认及测试=================================================================================
Ext.define('engineerConfirmationAndTestingModel', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','personResponsible','tqc','engineer','doYouNeedToCommissionTesting',
        'entrustedTestingLink','entrustedTestingStatus','annex','rAndDOpinions','fdId','explain'
    ],
    idProperty: 'engineerConfirmationAndTestingModel'
});

var engineerConfirmationAndTestingStore = Ext.create('Ext.data.Store', {
    model: 'engineerConfirmationAndTestingModel',
    id: 'engineerConfirmationAndTestingStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtValidationTestingBo?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

//负责人
let personResponsibleStore = new Ext.data.ArrayStore({
    id: 'personResponsibleStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/sampleConfirmation/searchPersonResponsible?branchId='+branchId+'&roleNames=B171技术部经理、B025结构开发部经理、B128硬件开发部经理、A029产品工程部经理、B037产品管理部经理、A001PDT经理',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});

//tqc
let tqcStore = new Ext.data.ArrayStore({
    id: 'tqcStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/personLiableList',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});

//工程师
let engineerStore = new Ext.data.ArrayStore({
    id: 'engineerStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/personLiableList',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});

let needToCommissionTestingStore = [['是', '是'], ['否', '否']];

let rAndDOpinionsStore = [['通过', '通过'], ['不通过', '不通过']];

var engineerConfirmationAndTestingColumns = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber',flex: 1, editor: false, menuDisabled: true,},
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
    {
        text: setMust('负责人',isEditable(designated_person_in_charge,initiator_confirms_integrated,system_administrator_confirms_integrated)),
        dataIndex: 'personResponsible',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(designated_person_in_charge,initiator_confirms_integrated,system_administrator_confirms_integrated)?{
            xtype: 'combo',
            editable: true,
            multiSelect: false,
            anyMatch: true,
            store: personResponsibleStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        }:false
    },
    {
        text: setMust('测试工程师',isEditable(designated_person_in_charge,initiator_confirms_integrated,system_administrator_confirms_integrated,designated_engineer)),
        dataIndex: 'tqc',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(designated_person_in_charge,initiator_confirms_integrated,system_administrator_confirms_integrated,designated_engineer)?{
            xtype: 'combo',
            editable: true,
            multiSelect: false,
            anyMatch: true,
            store: tqcStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars: 1,//开始查询最小字符数
            mode: 'remote', //查询模式  local为本地数据源  remote为远程服务端
        }:false
    },
    {
        text: setMust('研发工程师',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated,designated_engineer_standard
        ,designated_engineer_finish_product)),
        dataIndex: 'engineer',
        flex: 1,
        menuDisabled: true,
        editor: true,
        editAccess: true,
        editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated,designated_engineer_standard
        ,designated_engineer_finish_product)?{
            xtype: 'combo',
            editable: true,
            multiSelect: true,
            anyMatch: true,
            store: engineerStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars: 1,//开始查询最小字符数
            mode: 'remote', //查询模式  local为本地数据源  remote为远程服务端
        }:false
    },
    {
        text: setRequired('是否需要委托测试',isEditable(preliminary_confirmation,initiator_confirms_integrated,
            system_administrator_confirms_integrated,finish_product_preliminary_confirmation,preliminary_confirmation_again)),
        dataIndex: 'doYouNeedToCommissionTesting',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
            ,finish_product_preliminary_confirmation,preliminary_confirmation_again)?{
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: needToCommissionTestingStore
        }:false
    },
    {
        text: setRequired('委托测试编号',isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
            ,finish_product_preliminary_confirmation,preliminary_confirmation_again)),
        dataIndex: 'entrustedTestingLink',
        flex: 1,menuDisabled: true,
        editor: isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
            ,finish_product_preliminary_confirmation,preliminary_confirmation_again)?true:false,
        renderer: function(value,metaData,record,row,col,store){
            if(value)
                metaData.tdAttr = 'data-qtip="' + value +'"';
            if(value) {
                var docLink = "<a href='" + urlOa +record.get('fdId') +"' target='_blank' >"
                    + value + "</a>";
                return docLink;
            }else {
                return value;
            }
        }
    },
    {text: '委托测试状态', dataIndex: 'entrustedTestingStatus', flex: 1,menuDisabled: true, editor: false},
    {
        text: setRequired('附件',isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
            ,finish_product_preliminary_confirmation,preliminary_confirmation_again)),
        dataIndex: 'annex',
        width: 100,
        menuDisabled: true,
        editAccess: true,
        xtype:'actioncolumn',
        items: [
            '->',
            {
                iconCls: 'icon icon-uploadImage',
                tooltip: '添加文件',
                hidden:isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
                    ,finish_product_preliminary_confirmation,preliminary_confirmation_again)?false:true,
                handler: function(grid, rowIndex, colIndex) {
                    var record = grid.getStore().getAt(rowIndex);
                    //设置当前列的id与列名和表名
                    fileColumnId = record.get('id');
                    fileColumnName = 'annex';
                    uploadTableName = 'ZValidationTestingTable';
                    //设置grid名称用于上传文件后刷新数据
                    gridName = 'engineerConfirmationAndTestingGrid';

                    uploadImageWindow.show();
                }
            },
            '-',
            {
                iconCls: 'icon-showInfo',
                tooltip: '查看文件',
                handler: function(grid, rowIndex, colIndex) {
                    var record = grid.getStore().getAt(rowIndex);
                    //设置当前列的id与列名和表名
                    fileColumnId = record.get('id');
                    fileColumnName = 'annex';
                    uploadTableName = 'ZValidationTestingTable';
                    //设置grid名称用于上传文件后刷新数据
                    gridName = 'engineerConfirmationAndTestingGrid';
                    // 刷新当前单元格内文件
                    showStore.load({
                        params: {
                            fileColumnId: fileColumnId,
                            fileColumnName: fileColumnName,
                            uploadTableName:uploadTableName
                        }
                    });
                    showDeleteValue = !isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
                        ,finish_product_preliminary_confirmation,preliminary_confirmation_again);
                    showFile.show();
                },
                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                    var boolean = record.data.annex;
                    if(boolean!=null) {
                        return false;
                    }
                    return true;
                }
            }
        ]
    },
    {
        text: setRequired('特殊说明',isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
            ,sample_preliminary_comments,finish_product_preliminary_confirmation,preliminary_confirmation_again)),
        dataIndex: 'explain',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
            ,sample_preliminary_comments,finish_product_preliminary_confirmation,preliminary_confirmation_again)?true:false
    },
    {
        text: setMust('工程师意见',isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
        )),
        dataIndex: 'rAndDOpinions',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(preliminary_confirmation,initiator_confirms_integrated,system_administrator_confirms_integrated
            )?{
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: rAndDOpinionsStore
        }:false
    },
];

var engineerConfirmationAndTestingGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var engineerConfirmationAndTestingGrid = Ext.create('Ext.grid.Panel', {
    plugins: [engineerConfirmationAndTestingGridEditing],
    store: engineerConfirmationAndTestingStore,
    columns: engineerConfirmationAndTestingColumns,
    id:'engineerConfirmationAndTestingGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    // tbar: [
    //     {
    //         xtype: 'button',
    //         text: '新增行',
    //         id: 'engineerConfirmationAndTestingInsert',
    //         iconCls: 'icon icon-add',
    //         handler: function () {
    //             let callbackFn = function (response, opts) {
    //                 var obj = Ext.decode(response.responseText);
    //                 if(obj.message=='success') {
    //                     engineerConfirmationAndTestingStore.load();
    //                 }else {
    //                     alert(obj.message);
    //                 }
    //             };
    //             insertData('ZValidationTestingTable', branchId, callbackFn);
    //         }
    //     },
    //     {
    //         xtype: 'button',
    //         text: '删除行',
    //         id: 'engineerConfirmationAndTestingDelete',
    //         iconCls: 'icon icon-delete',
    //         handler: function () {
    //             let selected = engineerConfirmationAndTestingGrid.getSelectionModel().getSelection();
    //             if (selected.length === 0) {
    //                 alert('请选择数据！');
    //             } else {
    //                 let ids = '';
    //                 for (let i = 0; i < selected.length; i++) {
    //                     let id = selected[i].get('id');
    //                     if (id) {
    //                         if(i == 0){
    //                             ids += id;
    //                         }else{
    //                             ids += ',' + id;
    //                         }
    //                     }
    //                 }
    //                 let callbackFn = function (response, opts) {
    //                     engineerConfirmationAndTestingGrid.getStore().remove(selected);
    //                     engineerConfirmationAndTestingGrid.view.refresh();
    //                 };
    //                 deleteData('ZValidationTestingTable', ids, callbackFn);
    //             }
    //         }
    //     }
    // ]
});

//编辑前需要做的校验
engineerConfirmationAndTestingGrid.on('beforeedit',function(editor,e){
    //是否需要委托测试为“否”，“委托测试链接”不可编辑
    if(e.field == 'entrustedTestingLink') {
        var record = e.record;
        var doYouNeedToCommissionTesting = record.get('doYouNeedToCommissionTesting');
        if(doYouNeedToCommissionTesting == '否') {
            return false;
        }
    }
});

engineerConfirmationAndTestingGrid.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            engineerConfirmationAndTestingStore.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZValidationTestingTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
engineerConfirmationAndTestingGrid.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];


});


var engineerConfirmationAndTesting  = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S03：工程师确认及测试',
    padding:'5',
    collapsed:openPanel(designated_person_in_charge,designated_engineer,preliminary_confirmation,initiator_confirms_integrated,
        system_administrator_confirms_integrated,sample_preliminary_comments,finish_product_preliminary_confirmation,preliminary_confirmation_again
    ,designated_engineer_standard,designated_engineer_finish_product),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    width: '100%',
    anchor:'100%',
    defaults: {
        labelWidth: 80,
        border: false
    },
    items:[
        engineerConfirmationAndTestingGrid
    ]
});