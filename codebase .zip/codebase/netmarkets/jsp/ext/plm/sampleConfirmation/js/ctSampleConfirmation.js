Ext.define('PLM.view.ctTemporaryTechnicalChanges', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctTemporaryTechnicalChanges',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ctTemporaryTechnicalChanges',
    initComponent: function () {

        this.items = [
            basicInformationPanel,
            certifiedProductIdentification,
            engineerConfirmationAndTesting,
            TQCUploadReport,
            confirmerFillInInformationConclusion,
            // sampleConfirmerFillInInformation,
            // trialProductionAndUseResult,
            // IQCConfirmationResults,
            // trialProductionAndUseResultAgainResult,
            qualityCenterConfirmation,
            maintenanceMaterial,
            maintenanceAndCertification
        ];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {

        }
    }
});


