//
// // ========================================S07：IQC确认结果=================================================================================
//
// var iqcOverallConclusion = new Ext.form.ComboBox({
//     xtype: 'combo',
//     name: 'iqcOverallConclusionCombo',
//     id: 'iqcOverallConclusionCombo',
//     multiSelect: false,
//     anyMatch: true,
//     editable: false,
//     store: {
//         data: [
//             { fullName: '通过' },
//             { fullName: '不通过' }
//         ],
//         fields: ['fullName']
//     },
//     valueField: 'fullName',
//     displayField: 'fullName'
// });
//
// Ext.define('IQCConfirmationResultsModel', {
//     extend: 'Ext.data.Model',
//     fields: [
//         'id','parentNumber','partDescribe','sampleConfirmationProgress',
//         'sealedSample','dataIntegrity','iqcOverallConclusion'
//     ],
//     idProperty: 'IQCConfirmationResultsModel'
// });
//
// var IQCConfirmationResultsStore = Ext.create('Ext.data.Store', {
//     model: 'IQCConfirmationResultsModel',
//     id: 'IQCConfirmationResultsStore',
//     pruneModifiedRecords: true,
//     proxy: new Ext.data.HttpProxy({
//         url: '/Windchill/ptc1/sampleConfirm/getCtIQCResultBo?branchId='+branchId,
//         method:'GET',
//         reader:{
//             type:'json',
//             rootProperty: 'data',
//             idProperty: 'id',
//             messageProperty: 'message'
//         }
//     }),
//     autoLoad:true,
// });
//
// let sealedSampleStore = [['已收到', '已收到'],['未收到', '未收到']];
//
// let dataIntegrityStore = [['完整', '完整'],['不完整', '不完整']];
//
// var IQCConfirmationResultsColumns = [
//     {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
//     {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: false, menuDisabled: true,
//     },
//     {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
//     {text: '样品确认进展', dataIndex: 'sampleConfirmationProgress', flex: 1, editor: false , menuDisabled: true},
//
//     {
//         text: 'IQC确认项目',menuDisabled: true,flex: 2,
//         columns: [
//             {
//                 text: setMust('封样',isEditable(opinion_of_iqc_supervisor,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//                 dataIndex: 'sealedSample', flex: 1,
//                 editAccess: isEditable(opinion_of_iqc_supervisor,system_administrator_confirms_integrated,initiator_confirms_integrated),
//                 menuDisabled: true,
//                 editor: {
//                     xtype: 'combobox',
//                     editable: false,
//                     forceSelection: false,
//                     store: sealedSampleStore
//                 }
//             },
//             // {
//             //     text: setMust('资料完整性',isEditable(opinion_of_iqc_supervisor,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//             //     dataIndex: 'dataIntegrity',
//             //     flex: 1,
//             //     menuDisabled: true,
//             //     editAccess: isEditable(opinion_of_iqc_supervisor,system_administrator_confirms_integrated,initiator_confirms_integrated),
//             //     editor: {
//             //         xtype: 'combobox',
//             //         editable: false,
//             //         forceSelection: false,
//             //         store: dataIntegrityStore
//             //     }
//             // }
//         ]
//     },
//     {
//         text: setMust('IQC总体结论',isEditable(opinion_of_iqc_supervisor,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//         dataIndex: 'iqcOverallConclusion',
//         flex: 1,
//         editAccess: isEditable(opinion_of_iqc_supervisor,system_administrator_confirms_integrated,initiator_confirms_integrated),
//         editor: iqcOverallConclusion,
//         menuDisabled: true
//     }
// ];
//
// var IQCConfirmationResultsGridEditing = new Ext.grid.plugin.CellEditing({
//     clicksToEdit: 1
// });
//
// var IQCConfirmationResultsGrid = Ext.create('Ext.grid.Panel', {
//     plugins: [IQCConfirmationResultsGridEditing],
//     store: IQCConfirmationResultsStore,
//     columns: IQCConfirmationResultsColumns,
//     id:'IQCConfirmationResultsGrid',
//     autoWidth: true,
//     columnLines: true,
//     width:'100%',
//     height:'100%',
//     height:300,
//     multiSelect : false,
//     autoScroll: true,
//     forceFit: false,
//     selType: 'checkboxmodel',
//     // tbar: [
//     //     {
//     //         xtype: 'button',
//     //         text: '新增行',
//     //         id: 'IQCConfirmationResultsInsert',
//     //         iconCls: 'icon icon-add',
//     //         handler: function () {
//     //             let callbackFn = function (response, opts) {
//     //                 var obj = Ext.decode(response.responseText);
//     //                 if(obj.message=='success') {
//     //                     IQCConfirmationResultsStore.load();
//     //                 }else {
//     //                     alert(obj.message);
//     //                 }
//     //             };
//     //             insertData('ZIQCResultTable', branchId, callbackFn);
//     //         }
//     //     },
//     //     {
//     //         xtype: 'button',
//     //         text: '删除行',
//     //         id: 'IQCConfirmationResultsDelete',
//     //         iconCls: 'icon icon-delete',
//     //         handler: function () {
//     //             let selected = IQCConfirmationResultsGrid.getSelectionModel().getSelection();
//     //             if (selected.length === 0) {
//     //                 alert('请选择数据！');
//     //             } else {
//     //                 let ids = '';
//     //                 for (let i = 0; i < selected.length; i++) {
//     //                     let id = selected[i].get('id');
//     //                     if (id) {
//     //                         if(i == 0){
//     //                             ids += id;
//     //                         }else{
//     //                             ids += ',' + id;
//     //                         }
//     //                     }
//     //                 }
//     //                 let callbackFn = function (response, opts) {
//     //                     IQCConfirmationResultsGrid.getStore().remove(selected);
//     //                     IQCConfirmationResultsGrid.view.refresh();
//     //                 };
//     //                 deleteData('ZIQCResultTable', ids, callbackFn);
//     //             }
//     //         }
//     //     }
//     // ]
// });
//
// IQCConfirmationResultsGrid.on('edit',function(editor,e){
//     let record = e.record; // 得到当前行所有数据
//     let field = e.field;   // 得到修改列
//     let value = e.value;   // 得到修改列修改后的值
//     let oldValue = e.originalValue; // 旧值
//     let id = record.get('id');
//     if (value === oldValue) {
//         record.reject();
//         return; // 没有修改内容则返回
//     }
//     var callbackFn = function (response, opts) {
//         var obj = Ext.decode(response.responseText);
//         if(obj.message=='success') {
//             var obj = Ext.decode(response.responseText);
//             e.record.commit();
//             IQCConfirmationResultsStore.load();
//         }else {
//             alert(obj.message)
//         }
//     };
//     saveMockItemData("ZIQCResultTable", id, field, value, callbackFn);
// });
//
// // 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
// IQCConfirmationResultsGrid.on('rowclick', function(view, record, item, index, e) {
//
//     var headerCt = view.getHeaderCt(); // 获取列头组件
//     var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
//     var cellIndex = cell.cellIndex+1; // 获取单元格的索引
//
//     // 通过单元格索引获取列
//     var column = headerCt.getGridColumns()[cellIndex];
//
// });
//
// //根据特定字段的值判断是否禁止编辑
// IQCConfirmationResultsGrid.on('beforeedit', function (editor, context) {
//     var record = context.record;
//     var sampleConfirmationProgress = record.get('sampleConfirmationProgress');
//     if(sampleConfirmationProgress === "确认终止"){
//         return false; // 禁止编辑
//     }
//     return true; // 允许编辑操作
// });
//
//
// var IQCConfirmationResults  = Ext.create('Ext.panel.Panel',{
//     xtype:'panel',
//     title: 'S07：IQC确认结果',
//     padding:'5',
//     collapsed:openPanel(opinion_of_iqc_supervisor,system_administrator_confirms_integrated,initiator_confirms_integrated),
//     collapsible:true,
//     titleCollapse:true,
//     hideCollapseTool:true,
//     width: '100%',
//     anchor:'100%',
//     defaults: {
//         labelWidth: 80,
//         border: false
//     },
//     items:[
//         IQCConfirmationResultsGrid
//     ]
// });