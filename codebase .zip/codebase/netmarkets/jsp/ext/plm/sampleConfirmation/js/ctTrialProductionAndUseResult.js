
// ========================================S06：试产试用结果确认表一开始=================================================================================
Ext.define('trialProductionAndUseResultModel01', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','trialProcessNumber','combinationNumber','semiFinishedProductNumber',
        'semiFinishedProductDescribe','finishedProductNumber','finishedProductDescription','internalVersion',
        'supplierCodeAndName','trialQuantity','trialNumberOfTimes','trialStatus'
    ],
    idProperty: 'id'
});

var trialProductionAndUseResultStore01 = Ext.create('Ext.data.Store', {
    model: 'trialProductionAndUseResultModel01',
    id: 'trialProductionAndUseResultStore01',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtResultConfirmationBo?branchId='+branchId+'&isEdit='+isEditable(''),
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

var trialProductionAndUseResultColumns01 = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: false, menuDisabled: true,},
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
    {text: '试用流程编号', dataIndex: 'trialProcessNumber', flex: 1, editor: false , menuDisabled: true},
    {text: '组合编号', dataIndex: 'combinationNumber', flex: 1, editor: false , menuDisabled: true},
    {text: '半成品编号', dataIndex: 'semiFinishedProductNumber', flex: 1, editor: false, menuDisabled: true},
    {text: '半成品描述', dataIndex: 'semiFinishedProductDescribe', flex: 1, editor: false, menuDisabled: true},
    {text: '成品编号', dataIndex: 'finishedProductNumber', flex: 1, editor: false, menuDisabled: true},
    {text: '成品描述', dataIndex: 'finishedProductDescription', flex: 1, editor: false, menuDisabled: true},
    {text: '内部版本', dataIndex: 'internalVersion', flex: 1, editor: false, menuDisabled: true},
    {text: '供应商编码_名称', dataIndex: 'supplierCodeAndName', flex: 1, editor: false, menuDisabled: true},
    {text: '试用数量', dataIndex: 'trialQuantity', flex: 1, editor: false, menuDisabled: true},
    {text: '试用次数', dataIndex: 'trialNumberOfTimes', flex: 1, editor: false, menuDisabled: true},
    {text: '试用状态', dataIndex: 'trialStatus', flex: 1, editor: false, menuDisabled: true}
];

var trialProductionAndUseResultGridEditing01 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var trialProductionAndUseResultGrid01 = Ext.create('Ext.grid.Panel', {
    plugins: [trialProductionAndUseResultGridEditing01],
    store: trialProductionAndUseResultStore01,
    columns: trialProductionAndUseResultColumns01,
    id:'trialProductionAndUseResultGrid01',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    tbar: [
        // {
        //     xtype: 'button',
        //     text: '新增行',
        //     id: 'trialProductionAndUseResultInsert01',
        //     iconCls: 'icon icon-add',
        //     handler: function () {
        //         let callbackFn = function (response, opts) {
        //             var obj = Ext.decode(response.responseText);
        //             if(obj.message=='success') {
        //                 trialProductionAndUseResultStore01.load();
        //             }else {
        //                 alert(obj.message);
        //             }
        //         };
        //         insertData('ZResultConfirmationTable', branchId, callbackFn);
        //     }
        // },
        // {
        //     xtype: 'button',
        //     text: '删除行',
        //     id: 'trialProductionAndUseResulttDelete01',
        //     iconCls: 'icon icon-delete',
        //     handler: function () {
        //         let selected = trialProductionAndUseResultGrid01.getSelectionModel().getSelection();
        //         if (selected.length === 0) {
        //             alert('请选择数据！');
        //         } else {
        //             let ids = '';
        //             for (let i = 0; i < selected.length; i++) {
        //                 let id = selected[i].get('id');
        //                 if (id) {
        //                     if(i == 0){
        //                         ids += id;
        //                     }else{
        //                         ids += ',' + id;
        //                     }
        //                 }
        //             }
        //             let callbackFn = function (response, opts) {
        //                 trialProductionAndUseResultGrid01.getStore().remove(selected);
        //                 trialProductionAndUseResultGrid01.view.refresh();
        //             };
        //             deleteData('ZResultConfirmationTable', ids, callbackFn);
        //         }
        //     }
        // }
    ]
});

trialProductionAndUseResultGrid01.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            trialProductionAndUseResultStore01.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZResultConfirmationTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
trialProductionAndUseResultGrid01.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});
// ========================================S06：试产试用结果确认表一结束=================================================================================

// ========================================S06：试产试用结果确认表二开始=================================================================================
Ext.define('trialProductionAndUseResultModel02', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','sampleConfirmationProgress','newProductOrMaterial',
        'whetherSealedSample','sealingSampleNumber',
        'trialProductionReportNumber','trialProductionConclusion',
        'whetherOnTrial','trialConclusion','overallConclusion'
    ],
    idProperty: 'id'
});

var trialProductionAndUseResultStore02 = Ext.create('Ext.data.Store', {
    model: 'trialProductionAndUseResultModel02',
    id: 'trialProductionAndUseResultStore02',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtResultConfirmationTwoBo?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

let overallConclusionStore = [['通过', '通过'], ['不通过', '不通过']];

let trialConclusionStore = [['通过', '通过'], ['不通过', '不通过']];

var trialProductionAndUseResultColumns02 = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: false, menuDisabled: true,
    },
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
    {text: '样品确认进展', dataIndex: 'sampleConfirmationProgress', flex: 1, editor: false , menuDisabled: true},
    {text: '是否是新产品新物料', dataIndex: 'newProductOrMaterial', flex: 1, editor: false , menuDisabled: true},

    {
        text: '封样',menuDisabled: true,
        columns: [
            {text: '是否需要封样', dataIndex: 'whetherSealedSample', flex: 1, editor: false, menuDisabled: true},
            {text: '封样编号', dataIndex: 'sealingSampleNumber', flex: 1, editor: false, menuDisabled: true},
            // {text: setRequired('封样移交表',isEditable(confirm_trial_node,system_administrator_confirms_integrated,initiator_confirms_integrated)),xtype:'actioncolumn', dataIndex: 'sealingDocument', flex: 1, editor: false, menuDisabled: true,
            //     items: [
            //         '->',
            //         {
            //             iconCls: 'icon icon-uploadImage',
            //             tooltip: '添加文件',
            //             hidden:isEditable(confirm_trial_node,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
            //             handler: function(grid, rowIndex, colIndex) {
            //                 var record = grid.getStore().getAt(rowIndex);
            //                 //设置当前列的id与列名和表名
            //                 fileColumnId = record.get('id');
            //                 fileColumnName = 'sealingDocument';
            //                 uploadTableName = 'ZResultConfirmationTwoTable';
            //                 //设置grid名称用于上传文件后刷新数据
            //                 gridName = 'trialProductionAndUseResultGrid02';
            //
            //                 uploadImageWindow.show();
            //             }
            //         },
            //         '-',
            //         {
            //             iconCls: 'icon-showInfo',
            //             tooltip: '查看文件',
            //             handler: function(grid, rowIndex, colIndex) {
            //                 var record = grid.getStore().getAt(rowIndex);
            //                 //设置当前列的id与列名和表名
            //                 fileColumnId = record.get('id');
            //                 fileColumnName = 'sealingDocument';
            //                 uploadTableName = 'ZResultConfirmationTwoTable';
            //                 //设置grid名称用于上传文件后刷新数据
            //                 gridName = 'trialProductionAndUseResultGrid02';
            //                 // 刷新当前单元格内文件
            //                 showStore.load({
            //                     params: {
            //                         fileColumnId: fileColumnId,
            //                         fileColumnName: fileColumnName,
            //                         uploadTableName:uploadTableName
            //                     }
            //                 });
            //                 showFile.show();
            //             },
            //             isDisabled: function (view ,rowIndex,colIndex, item,record) {
            //                 var boolean = record.data.relatedAccessories;
            //                 if(boolean!=null) {
            //                     return false;
            //                 }
            //                 return true;
            //             }
            //         }
            //     ]
            //
            // }
        ]
    },
    // {
    //     text: '试产结果',menuDisabled: true,
    //     columns: [
    //         {text: '试产报告编号', dataIndex: 'trialProductionReportNumber', flex: 1, editor: false, menuDisabled: true},
    //         {text: '试产结论', dataIndex: 'trialProductionConclusion', flex: 1, editor: false, menuDisabled: true}
    //     ]
    // },
    {
        text: '试用结果',menuDisabled: true,
        columns: [
            {text: '是否需要试用', dataIndex: 'whetherOnTrial', flex: 1, editor: false, menuDisabled: true},
            {
                text: setMust('试用结论',isEditable(confirm_trial_node,system_administrator_confirms_integrated,initiator_confirms_integrated)),
                dataIndex: 'trialConclusion',
                flex: 1,
                editAccess: true,
                menuDisabled: true,
                editor: isEditable(confirm_trial_node,system_administrator_confirms_integrated,initiator_confirms_integrated)?{
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: trialConclusionStore
                }:false
            }
        ]
    },
    {
        text: setMust('总体试产试用结论',isEditable(confirm_trial_node,system_administrator_confirms_integrated,initiator_confirms_integrated)),
        dataIndex: 'overallConclusion',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(confirm_trial_node,system_administrator_confirms_integrated,initiator_confirms_integrated)?{
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: overallConclusionStore
        }:false
    }
];

var trialProductionAndUseResultGridEditing02 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var trialProductionAndUseResultGrid02 = Ext.create('Ext.grid.Panel', {
    plugins: [trialProductionAndUseResultGridEditing02],
    store: trialProductionAndUseResultStore02,
    columns: trialProductionAndUseResultColumns02,
    id:'trialProductionAndUseResultGrid02',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    tbar: [
        // {
        //     xtype: 'button',
        //     text: '新增行',
        //     hidden:isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
        //     id: 'trialProductionAndUseResultInsert02',
        //     iconCls: 'icon icon-add',
        //     handler: function () {
        //         let callbackFn = function (response, opts) {
        //             var obj = Ext.decode(response.responseText);
        //             if(obj.message=='success') {
        //                 trialProductionAndUseResultStore02.load();
        //             }else {
        //                 alert(obj.message);
        //             }
        //         };
        //         insertData('ZResultConfirmationTwoTable', branchId, callbackFn);
        //     }
        // },
        // {
        //     xtype: 'button',
        //     text: '删除行',
        //     hidden:isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
        //     id: 'trialProductionAndUseResultDelete02',
        //     iconCls: 'icon icon-delete',
        //     handler: function () {
        //         let selected = trialProductionAndUseResultGrid02.getSelectionModel().getSelection();
        //         if (selected.length === 0) {
        //             alert('请选择数据！');
        //         } else {
        //             let ids = '';
        //             for (let i = 0; i < selected.length; i++) {
        //                 let id = selected[i].get('id');
        //                 if (id) {
        //                     if(i == 0){
        //                         ids += id;
        //                     }else{
        //                         ids += ',' + id;
        //                     }
        //                 }
        //             }
        //             let callbackFn = function (response, opts) {
        //                 trialProductionAndUseResultGrid02.getStore().remove(selected);
        //                 trialProductionAndUseResultGrid02.view.refresh();
        //             };
        //             deleteData('ZResultConfirmationTwoTable', ids, callbackFn);
        //         }
        //     }
        // },
        {
            xtype: 'button',
            text: '试用流程创建',
            hidden:isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
            id: 'trialProductionAndUseResultExport01',
            iconCls : 'icon icon-store-export',
            handler: function () {
                let selected = trialProductionAndUseResultGrid02.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    Ext.Msg.alert('提示', '请选择数据！');
                } else {
                    let ids = '';
                    for (let i = 0; i < selected.length; i++) {
                        let partNumber = selected[i].get('partNumber');
                        let whetherOnTrial = selected[i].get('whetherOnTrial');
                        if('是' != whetherOnTrial){
                            Ext.Msg.alert('提示', '只能选择“是否需要试用”为“是”的数据');
                            return;
                        }
                        if (partNumber) {
                            if(i == 0){
                                ids += partNumber;
                            }else{
                                ids += ',' + partNumber;
                            }
                        }
                    }
                    let callbackFn = function (response, opts) {
                        trialProductionAndUseResultGrid01.view.refresh();
                    };
                    createTrialProcess(ids, callbackFn);
                }
            }
        }
    ]
});

trialProductionAndUseResultGrid02.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            trialProductionAndUseResultStore02.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZResultConfirmationTwoTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
trialProductionAndUseResultGrid02.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});

//根据特定字段的值判断是否禁止编辑
trialProductionAndUseResultGrid02.on('beforeedit', function (editor, context) {
    var record = context.record;
    var sampleConfirmationProgress = record.get('sampleConfirmationProgress');
    if(sampleConfirmationProgress === "确认终止"){
        return false; // 禁止编辑
    }
    return true; // 允许编辑操作
});
// ========================================S06：试产试用结果确认表二结束=================================================================================


var trialProductionAndUseResult  = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S06：试产试用结果确认',
    padding:'5',
    collapsed:openPanel(confirm_trial_node,system_administrator_confirms_integrated,initiator_confirms_integrated),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    width: '100%',
    anchor:'100%',
    defaults: {
        labelWidth: 80,
        border: false
    },
    items:[
        // trialProductionAndUseResultGrid01,
        trialProductionAndUseResultGrid02
    ]
});