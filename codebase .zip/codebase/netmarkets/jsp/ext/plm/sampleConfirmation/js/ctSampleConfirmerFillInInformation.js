//
// // ========================================S05：样品确认人填写相关信息和综合结论=================================================================================
// Ext.define('sampleConfirmerFillInInformationModel', {
//     extend: 'Ext.data.Model',
//     fields: [
//         'id','parentNumber','partDescribe','sampleConfirmationProgress','sampleConfirmer',
//         'whetherSealedSample','numberOfSealedSamples','sealingDepartment',
//         'whetherOnTrial','trialModel',
//         'selectOperation','existingSuppliers',
//         'illustrate','confirmerOpinion'
//     ],
//     idProperty: 'id'
// });
//
// var sampleConfirmerFillInInformationStore = Ext.create('Ext.data.Store', {
//     model: 'sampleConfirmerFillInInformationModel',
//     id: 'sampleConfirmerFillInInformationStore',
//     pruneModifiedRecords: true,
//     proxy: new Ext.data.HttpProxy({
//         url: '/Windchill/ptc1/sampleConfirm/getCtComprehensiveConclusionBo?branchId='+branchId,
//         method:'GET',
//         reader:{
//             type:'json',
//             rootProperty: 'data',
//             idProperty: 'id',
//             messageProperty: 'message'
//         }
//     }),
//     autoLoad:true,
// });
//
// let confirmerOpinionStore = [
//     ['通过', '通过'],['不通过', '不通过']
// ]
//
// let whetherSealedSampleStore = [
//     ['是', '是'],['否', '否']
// ]
//
// let whetherOnTrialStore = [
//     ['是', '是'],['否', '否']
// ]
//
// let selectOperationStore = [
//     ['修订', '修订'],['新建', '新建']
// ]
//
// //现有供应商
// var existSupplierCombo = new Ext.form.ComboBox({
//     xtype: 'combo',
//     name: 'existSupplierCombo',
//     id: 'existSupplierCombo',
//     multiSelect: false,
//     anyMatch: true,
//     editable: true,
//     store: {
//         data: [
//         ],
//         fields: ['supplier']
//     },
//     valueField: 'supplier',
//     displayField: 'supplier'
// });
//
// var sampleConfirmerFillInInformationColumns = [
//     {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
//     {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: true, menuDisabled: true,
//     },
//     {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: true,},
//     {text: '样品确认进展', dataIndex: 'sampleConfirmationProgress', flex: 1, editor: true , menuDisabled: true},
//     // {text: '样品确认人', dataIndex: 'sampleConfirmer', flex: 1, editor: true , menuDisabled: true},
//     {
//         text: '封样要求',menuDisabled: true,
//         columns: [
//             {
//                 text: setMust('是否需要封样',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//                 dataIndex: 'whetherSealedSample',
//                 flex: 1,
//                 editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//                 menuDisabled: true,
//                 editor: {
//                     xtype: 'combo',
//                     editable: false,
//                     forceSelection: false,
//                     store: whetherSealedSampleStore
//                 }
//             },
//             {
//                 text: setRequired('封样数量',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//                 dataIndex: 'numberOfSealedSamples', flex: 1,
//                 editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//                 editor: {xtype: 'textfield', selectOnFocus: true},
//                 menuDisabled: true
//             },
//             {
//                 text: setRequired('封样部门',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//                 dataIndex: 'sealingDepartment', flex: 1,
//                 editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//                 // editor: {xtype: 'textfield', selectOnFocus: true},
//                 editor: {
//                     xtype: 'combo',
//                     selectOnFocus: true,
//                     store: ['质控', '质控+采购'] // 设置只有两个选项的数据源
//                 },
//                 menuDisabled: true
//             }
//         ]
//     },
//     {
//         text: '试用要求',menuDisabled: true,
//         columns: [
//             {
//                 text: setMust('是否需要试用',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//                 dataIndex: 'whetherOnTrial',
//                 flex: 1,
//                 editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//                 menuDisabled: true,
//                 editor: {
//                     xtype: 'combo',
//                     editable: false,
//                     forceSelection: false,
//                     store: whetherOnTrialStore,
//                 }
//             },
//             {
//                 text: setRequired('试用成品',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//                 dataIndex: 'trialModel', flex: 1,
//                 editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//                 editor: {xtype: 'textfield', selectOnFocus: true},
//                 menuDisabled: true
//             }
//         ]
//     },
//     // {
//     //     text: '文件归档',menuDisabled: true,
//     //     columns: [
//     //         {
//     //             text: setMust('选择操作',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//     //             dataIndex: 'selectOperation',
//     //             flex: 1,
//     //             editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//     //             menuDisabled: true,
//     //             editor: {
//     //                 xtype: 'combo',
//     //                 editable: false,
//     //                 forceSelection: false,
//     //                 store: selectOperationStore
//     //             }
//     //         },
//     //         {
//     //             text: setMust('现有供应商',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//     //             dataIndex: 'existingSuppliers',
//     //             flex: 1,
//     //             editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//     //             menuDisabled: true,
//     //             editor: existSupplierCombo
//     //         }
//     //     ]
//     // },
//     {
//         text: setMust('说明',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//         dataIndex: 'illustrate', flex: 1,
//         editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//         editor: {xtype: 'textfield', selectOnFocus: true},
//         menuDisabled: true
//     },
//     {
//         text: setMust('确认人意见',isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated)),
//         dataIndex: 'confirmerOpinion',
//         flex: 1,
//         editAccess: isEditable(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//         menuDisabled: true,
//         editor: {
//             xtype: 'combo',
//             editable: false,
//             forceSelection: false,
//             store: confirmerOpinionStore,
//         }
//     }
// ];
//
// var sampleConfirmerFillInInformationGridEditing = new Ext.grid.plugin.CellEditing({
//     clicksToEdit: 1
// });
//
// var sampleConfirmerFillInInformationGrid = Ext.create('Ext.grid.Panel', {
//     plugins: [sampleConfirmerFillInInformationGridEditing],
//     store: sampleConfirmerFillInInformationStore,
//     columns: sampleConfirmerFillInInformationColumns,
//     id:'sampleConfirmerFillInInformationGrid',
//     autoWidth: true,
//     columnLines: true,
//     width:'100%',
//     height:'100%',
//     height:300,
//     multiSelect : false,
//     autoScroll: true,
//     forceFit: false,
//     selType: 'checkboxmodel',
//     // tbar: [
//     //     {
//     //         xtype: 'button',
//     //         text: '新增行',
//     //         id: 'sampleConfirmerFillInInformationInsert',
//     //         iconCls: 'icon icon-add',
//     //         handler: function () {
//     //             let callbackFn = function (response, opts) {
//     //                 var obj = Ext.decode(response.responseText);
//     //                 if(obj.message=='success') {
//     //                     sampleConfirmerFillInInformationStore.load();
//     //                 }else {
//     //                     alert(obj.message);
//     //                 }
//     //             };
//     //             insertData('ZComprehensiveConclusionTable', branchId, callbackFn);
//     //         }
//     //     },
//     //     {
//     //         xtype: 'button',
//     //         text: '删除行',
//     //         id: 'sampleConfirmerFillInInformationDelete',
//     //         iconCls: 'icon icon-delete',
//     //         handler: function () {
//     //             let selected = sampleConfirmerFillInInformationGrid.getSelectionModel().getSelection();
//     //             if (selected.length === 0) {
//     //                 alert('请选择数据！');
//     //             } else {
//     //                 let ids = '';
//     //                 for (let i = 0; i < selected.length; i++) {
//     //                     let id = selected[i].get('id');
//     //                     if (id) {
//     //                         if(i == 0){
//     //                             ids += id;
//     //                         }else{
//     //                             ids += ',' + id;
//     //                         }
//     //                     }
//     //                 }
//     //                 let callbackFn = function (response, opts) {
//     //                     sampleConfirmerFillInInformationGrid.getStore().remove(selected);
//     //                     sampleConfirmerFillInInformationGrid.view.refresh();
//     //                 };
//     //                 deleteData('ZComprehensiveConclusionTable', ids, callbackFn);
//     //             }
//     //         }
//     //     }
//     // ]
// });
//
// sampleConfirmerFillInInformationGrid.on('edit',function(editor,e){
//     let record = e.record; // 得到当前行所有数据
//     let field = e.field;   // 得到修改列
//     let value = e.value;   // 得到修改列修改后的值
//     let oldValue = e.originalValue; // 旧值
//     let id = record.get('id');
//     if (value === oldValue) {
//         record.reject();
//         return; // 没有修改内容则返回
//     }
//     var callbackFn = function (response, opts) {
//         var obj = Ext.decode(response.responseText);
//         if(obj.message=='success') {
//             var obj = Ext.decode(response.responseText);
//             e.record.commit();
//             sampleConfirmerFillInInformationStore.load();
//         }else {
//             alert(obj.message)
//         }
//     };
//     saveMockItemData("ZComprehensiveConclusionTable", id, field, value, callbackFn);
// });
//
// // 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
// sampleConfirmerFillInInformationGrid.on('rowclick', function(view, record, item, index, e) {
//     var headerCt = view.getHeaderCt(); // 获取列头组件
//     var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
//     var cellIndex = cell.cellIndex; // 获取单元格的索引
//
//     // 通过单元格索引获取列
//     var column = headerCt.getGridColumns()[cellIndex];
//     if (column) {
//         var columnName = column.dataIndex;
//         if (columnName == 'existingSuppliers') {
//             let partNumber = record.get('partNumber');
//             existSupplierCombo.getStore().removeAll();
//             Ext.Ajax.request({
//                 url: '/Windchill/ptc1/sampleConfirmation/getSupplierList?partNumber=' + partNumber,
//                 method: 'GET',
//                 headers: {'Content-Type': 'application/json'},
//                 success: function (response, opts) {
//                     var obj = Ext.decode(response.responseText);
//                     if (obj.message == 'success') {
//                         let pdtList = Ext.decode(response.responseText).data;
//                         if(pdtList){
//                             pdtList.map(function (item) {
//                                 existSupplierCombo.getStore().add({supplier: item.supplier});
//                             })
//                         }
//                     } else {
//                         alert(obj.message)
//                     }
//                 },
//                 failure: function (response, opts) {
//                     alert('错误：获取信息失败，请检查网络！!');
//                 }
//             });
//         }
//     }
// });
//
// //根据特定字段的值判断是否禁止编辑
// sampleConfirmerFillInInformationGrid.on('beforeedit', function (editor, context) {
//     var record = context.record;
//     var sampleConfirmationProgress = record.get('sampleConfirmationProgress');
//     if(sampleConfirmationProgress === "确认终止"){
//         return false; // 禁止编辑
//     }
//     return checkEditAccess(context); // 允许编辑操作
// });
//
//
// var sampleConfirmerFillInInformation  = Ext.create('Ext.panel.Panel',{
//     xtype:'panel',
//     title: 'S05：样品确认人填写相关信息和物料结论',
//     padding:'5',
//     collapsed:openPanel(sample_confirm_review,confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,confirm_sample_opinions,system_administrator_confirms_integrated,initiator_confirms_integrated),
//     collapsible:true,
//     titleCollapse:true,
//     hideCollapseTool:true,
//     width: '100%',
//     anchor:'100%',
//     defaults: {
//         labelWidth: 80,
//         border: false
//     },
//     items:[
//         sampleConfirmerFillInInformationGrid
//     ]
// });