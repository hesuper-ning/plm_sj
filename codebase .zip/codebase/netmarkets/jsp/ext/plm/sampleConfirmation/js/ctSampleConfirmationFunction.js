var redStarFlag = '<font color=red bold>*</font>';//必填标志
var blueFlagStart = '<font color=blue bold><b>';//可编辑标识
var blueFlagEnd = '</b></font>';


var start_node='start_node';//发起样品确认流程
var start_node1='start_node1';
var resubmit_node='resubmit_node'; //重新提交节点
var procurement_sourcing_fill_in='procurement_sourcing_fill_in';//采购寻源工程师完善信息
var sqe_confirm_node='sqe_confirm_node';//SQE确认环保属性与资料
var sample_confirm_review='sample_confirm_review';//样品确认人审核
var tqc_confirms_sample_comments='tqc_confirms_sample_comments';//TQC确认样品意见
var seal_sample_node='seal_sample_node';//是否需要封样
var confirm_trial_node='confirm_trial_node';//确认是否需要试用及试用结果
var opinion_of_iqc_supervisor='opinion_of_iqc_supervisor';//IQC主管意见
var cc_iqc_supervisor='cc_iqc_supervisor';//抄送IQC主管
var confirmation_of_trial_production='confirmation_of_trial_production';//试产/试用结果确认
var quality_center_confirmation='quality_center_confirmation';//质量中心确认
var cc_certified_engineer='cc_certified_engineer';//抄送：认证工程师
var procurement_sourcing_allocation_share='procurement_sourcing_allocation_share';//采购寻源分配份额
var initiator_confirms_integrated='initiator_confirms_integrated';//发起人确认待集成/自动更新信息
var system_administrator_confirms_integrated='system_administrator_confirms_integrated';//系统管理员确认待集成/自动更新信息
var notify_initiator_node='notify_initiator_node';//通知发起人-有物料没有通过确认，请及时处理
var confirm_sample_opinions='confirm_sample_opinions';//确认样品意见，确认是否需要驳回
var confirmation_by_development_engineer='confirmation_by_development_engineer';//是否需要研发工程师确认
var preliminary_confirmation='preliminary_confirmation';//初步确认
var confirm_inspection_requirements='confirm_inspection_requirements';//确认送检要求
var improve_inspection_requirements='improve_inspection_requirements';//完善关键物料替代料送检要求
var cc_development_representative='cc_development_representative';//抄送：项目管理工程师，开发代表
var submit_fai_report='submit_fai_report';//提交FAI报告
var improve_information='improve_information';//完善采购及替代信息
var designated_engineer='designated_engineer';//在表单中指定工程师，确认是否需要驳回
var designated_person_in_charge='designated_person_in_charge';//在表单中指定负责人
var confirm_sample_opinions_standard='confirm_sample_opinions_standard';//确认样品意见，确认是否需要驳回(标准流程)
var confirm_sample_opinions_supporting_facilities='confirm_sample_opinions_supporting_facilities';//确认样品意见，确认是否需要驳回(配套成品)

var trial_probation_comprehensive_conclusion='trial_probation_comprehensive_conclusion'//样品确认流程-确认试产试用结论及综合结论

var tqc_sealingSample='tqc_sealingSample';//样品确认流程-TQC自动生成封样编码集分发样品
var iqc_storageValidityPeriod='iqc_storageValidityPeriod';//样品确认流程-IQC主管确认接收并填写有效期

var flow_path_sample_comments='flow_path_sample_comments';//样品确认流程-确认样品意见
var flow_path_sealed_sample='flow_path_sealed_sample';//样品确认流程-封样、封样编码、分发样品
var sample_confirmation_submit02='sample_confirmation_submit02';//样品确认流程-发起人确认采购及替代信息

var sample_preliminary_comments = 'sample_preliminary_comments';//样品确认流程-初步确认、确认样品意见

var finish_product_preliminary_confirmation='finish_product_preliminary_confirmation';//样品确认流程(成品)-初步确认
var opinion_and_sealed_sample='opinion_and_sealed_sample';//样品确认流程(成品)-确认样品意见，确认是否需要封样
var finish_product_opinion='finish_product_opinion';//样品确认流程(成品)-确认样品意见(产品管理部)
var opinion_CPMT='opinion_CPMT';//样品确认流程(成品)-确认样品意见(CPMT)

var preliminary_confirmation_again='preliminary_confirmation_again';//样品确认流程-初步确认
var sample_confirmation_submit02_again='sample_confirmation_submit02_again';//样品确认流程-发起人确认采购及替代信息(重新提交)

var designated_engineer_standard='designated_engineer_standard';//样品确认流程（标准）-在表单中指定工程师，确认是否需要驳回

var designated_engineer_finish_product='designated_engineer_finish_product';//样品确认流程(成品)-在表单中指定工程师，确认是否需要驳回

/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    var column = e.column;//获取编辑列
    if (column.editAccess) {
        return true;
    } else {
        return false;
    }
}

/**
 * 判断是否可编辑
 * @param node 节点表单key
 * @returns {boolean}
 */
function isEditable(...node) {
    //return true;
   if (readOnlyPage || taskCompleted) return false;
   let flag = false;
   node.forEach((item, index) => {
       if (item === currentActKey) {
           flag = true;
       }
   });
   return flag;
}


/**
 * 判断节点表单是否应该展开
 */
function openPanel(...node) {
    //只读页面全打开
    if(collapsedValue) {
        return false;
    }

    if(isEditable(...node)) {
        return false;
    }else {
        return true;
    }
}




/**
 * 设为必填
 */
function setMust(field, flag) {
    if (flag)
        return redStarFlag + blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 设为可填
 */
function setRequired(field, flag) {
    if (flag)
        return blueFlagStart + field + blueFlagEnd;
    else
        return field;
}


//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion

/**
 * combobox空白行高度与选项保持一致
 * @param name
 * @returns {Ext.XTemplate}
 */
function getXTemplate(name) {
    return Ext.create('Ext.XTemplate',
        '<tpl for=".">',
        '<div class="x-boundlist-item" style="height:25px">{' + name + '}</div>',
        '</tpl>'
    )
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){
    // 显示遮罩
    var mask = new Ext.LoadMask({
        msg: '加载中，请稍候...',
        target: Ext.getCmp('basicInformationGrid01') // 可以根据实际情况更改 target
    });
    if("ZConfirmMainContentTable" == dbTableName && "partNumber" == dataKey){
        mask.show();
    }
    var mockRec = {
        oid:workItemOid,
        dbTableName:dbTableName,
        itemId:itemId,
        dataKey:dataKey,
        dataValue:dataValue,
        branchId:branchId
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/sampleConfirm/saveItemData?oid=' + workItemOid,
        params: {updateRecord:Ext.encode(mockRec)},
        timeout: 1000000,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
            if("ZConfirmMainContentTable" == dbTableName && "partNumber" == dataKey){
                // 请求完成后隐藏遮罩
                mask.hide();
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
            if("ZConfirmMainContentTable" == dbTableName && "partNumber" == dataKey){
                // 请求完成后隐藏遮罩
                mask.hide();
            }
        }
    });
}

/**
 * 插入数据
 * @param dbTableName
 * @param branchId
 * @param callbackFn
 */
function insertData(dbTableName, branchId, callbackFn){
    var insertRecord = {
        dbTableName:dbTableName,
        branchId:branchId
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/sampleConfirm/insertTableData?oid=' + workItemOid,
        params: {insertRecord:Ext.encode(insertRecord)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 删除数据
 * @param dbTableName
 * @param ids
 * @param callbackFn
 */
function deleteData(dbTableName, ids, callbackFn){
    var deleteRecord = {
        dbTableName:dbTableName,
        ids:ids
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/sampleConfirm/deleteTableData?oid=' + workItemOid,
        params: {deleteRecord:Ext.encode(deleteRecord)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 创建试用流程
 * @param partNumbers
 * @param callbackFn
 */
function createTrialProcess(partNumbers, callbackFn){
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/sampleConfirm/createTrialProcess',
        method:'POST',
        params:{
            branchId:branchId,
            partNumbers:partNumbers
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 导入认证产品一致性识别表格
 */
function importCertifiedProducts() {
    uploadCertifiedProductsWindow.show();
}

/**
 * 处理特殊符号
 * @param fileName
 * @returns {string}
 */
function urlStr2Ascii (fileName) {
    fileName = fileName.replace(/\%/g, '%25');
    fileName = fileName.replace(/\+/g, '%2B');
    fileName = fileName.replace(/\\/g, '%3F');
    fileName = fileName.replace(/\#/g, '%23');
    fileName = fileName.replace(/\&/g, '%26');
    fileName = fileName.replace(/\//g, '%2F');
    fileName = fileName.replace(/\=/g, '%3D');
    return fileName;
}

//导入panel
var uploadFileForm = new Ext.form.Panel({
    layout: 'form',
    id: 'uploadFileForm',
    name: 'uploadFileForm',
    width: 450,
    border: 0,
    tbar: [{
        xtype: 'filefield',
        name: 'userfile',
        id: 'userfile',
        msgTarget: 'side',
        fieldLabel: '上传Excel文件',
        width: 280,
        anchor: '100%',
        buttonText: '选择文件..',
        buttonOnly: false,
        buttonMargin: '5 5 5 5'
    }, {
        xtype: 'button',
        padding: '5 5 5 5',
        id: 'certifiedProducts_submit',
        text: '开始导入',
        handler: function () {
            var mainForm = Ext.getCmp('uploadFileForm').getForm();
            var furl = "";  //文件物理地址
            var fname = ""; //文件名称
            furl = Ext.getCmp("userfile").getValue();
            //alert(furl);
            if (furl == "") {
                alert("请先选择文件！");
                return false;
            }
            mainForm.submit({
                scope: this,
                url: '/Windchill/ptc1/sampleConfirmation/importCertifiedProducts?branchId=' + branchId,
                waitMsg: '正在导入......',
                waitTitle: '请等待',
                //method : 'POST',
                success: function (form, action) {
                    var obj = action.result;
                    if (obj.success) {
                        alert("导入成功");
                        window.parent.location.reload();
                    } else {
                        alert(obj.msg);
                    }
                },
                failure: function (form, action) {
                    var obj = action.result;
                    alert(obj.msg);
                }
            });
        }
    }]
});

//导入窗口
var uploadCertifiedProductsWindow = new Ext.create('Ext.Window', {
    title: '导入问题',
    autoHeight: true,
    autoWidth: true,
    closeAction: 'hide',
    y: '10%',
    id: 'uploadCertifiedProductsWindow',
    constrain: true,
    modal: true,
    layout: 'fit',
    items: uploadFileForm
});
Ext.define('PLM.hr.CtAllUserStore',{
    extend:'Ext.data.Store',
    alias:'widget.CtAllUserStore',
    fields:['userFullName','no'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/hr/getAllUser',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            //idProperty: 'id',
            messageProperty: 'error'
        }
    }),
    autoLoad:true
});
//用户下拉列表
var allUserStore_conPerson2 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_conPerson2'
});
Ext.define('PLM.common.CtAllUserStore',{
    extend:'Ext.data.Store',
    alias:'widget.CtAllUserStore',
    fields:['userFullName'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/common/getAllUserNames',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'items',
            //idProperty: 'id',
            messageProperty: 'error'
        }
    }),
    autoLoad:true
});
//用户下拉列表
var allUserStore_conPerson = Ext.create('PLM.common.CtAllUserStore', {
    storeId: 'allUserStore_conPerson'
});
var allUserCombo_conPerson = new Ext.form.ComboBox({
    name: 'allUserCombo_conPerson',
    id: 'allUserCombo_conPerson',
    valueField: 'userFullName',
    displayField: 'userFullName',
    queryMode: 'local',
    anyMatch: true,
    typeAhead: true,
    forceSelection: true,
    triggerAction: 'all',
    allowBlank: true,
    store: allUserStore_conPerson2,
});