

// ========================================S09：物料属性及替代关系维护=================================================================================

var procurementMeasurementUnit  = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'procurementMeasurementUnitCombo',
    id: 'procurementMeasurementUnitCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: 'PCS' },
            { fullName: '微升' },
            { fullName: 'ML' },
            { fullName: 'L' },
            { fullName: 'G' },
            { fullName: 'mg' },
            { fullName: '微克' },
            { fullName: '千克' },
            { fullName: '米' },
            { fullName: '个' },
            { fullName: '盒' },
            { fullName: '平方' },
            { fullName: '台' },
            { fullName: 'U' },
            { fullName: '套' },
            { fullName: '厘米' },
            { fullName: 'square meters' },
            { fullName: '毫米' },
            { fullName: 'PC' },
            { fullName: '卷' },
            { fullName: 'PAA' },
            { fullName: '瓶' },
            { fullName: '批' },
            { fullName: '条' },
            { fullName: '桶' },
            { fullName: 'PAC' },
            { fullName: 'H' },
            { fullName: 'CV' },
            { fullName: 'M2' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

// var preferredLevel = new Ext.form.ComboBox({
//     xtype: 'combo',
//     name: 'preferredLevelCombo',
//     id: 'preferredLevelCombo',
//     multiSelect: false,
//     anyMatch: true,
//     editable: false,
//     store: {
//         data: [
//             { fullName: 'A-优先推荐选用' },
//             { fullName: 'B-可以选用' },
//             { fullName: 'C-限制选用' },
//             { fullName: 'D-停产禁选' },
//             { fullName: 'E-禁止选用及采购' },
//             { fullName: 'F-定制件选用' },
//             { fullName: 'X-客供料' }
//         ],
//         fields: ['fullName']
//     },
//     valueField: 'fullName',
//     displayField: 'fullName'
// });


var targetIncomingMaterialMethod = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'targetIncomingMaterialMethodCombo',
    id: 'targetIncomingMaterialMethodCombo',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
            { fullName: '编带' },
            { fullName: '管装' },
            { fullName: '袋装' },
            { fullName: '散装' },
            { fullName: '盘装' },
            { fullName: '桶装' },
            { fullName: '卷' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var alternativeMaterialsStore = new Ext.data.ArrayStore({
    id: 'alternativeMaterialsStore',
    fields: [
        {name: "partNumber"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/sampleConfirmation/partNumberList?branchId='+branchId,
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});
var alternativeMaterialsCom = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'alternativeMaterialsCom',
    id: 'alternativeMaterialsCom',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: alternativeMaterialsStore,
    valueField: 'partNumber',
    displayField: 'partNumber',
    minChars : 1,//开始查询最小字符数
    mode : 'local', //查询模式  local为本地数据源  remote为远程服务端
});




Ext.define('maintenanceMaterialModel', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','sampleConfirmationProgress',
        'currentState','targetState',
        'currentPreferredLevel','targetSelectionLevel',
        'currentInternalVersion','targetInternalVersion',
        'currentBrand','targetBrand',
        'currentIncomingMaterialMethod','targetIncomingMaterialMethod',
        'currentNumber','targetNumber',
        'selectOperation','existingSuppliers',
        'minimumPackQuantity','procurementMeasurementUnit','procurementCycle',
        'resultsOfExecution','defaultData'
    ],
    idProperty: 'id'
});

var maintenanceMaterialStore = Ext.create('Ext.data.Store', {
    model: 'maintenanceMaterialModel',
    id: 'maintenanceMaterialStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtDataMaintenanceBo?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

var maintenanceMaterialColumns = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: setMust('物料编号',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'partNumber', width: 100,
        editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?alternativeMaterialsCom:false, menuDisabled: true,
    },
    {text: '物料描述', dataIndex: 'partDescribe', width: 100,menuDisabled: true, editor: false,},
    {text: '样品确认进展', dataIndex: 'sampleConfirmationProgress', width: 100, editor: false , menuDisabled: true},

    {
        text: '自动受控',menuDisabled: true,
        columns: [
            {text: '当前状态', dataIndex: 'currentState', width: 100, editor: false, menuDisabled: true},
            {text: '目标状态'
                    // setRequired('目标状态',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated))
                , dataIndex: 'targetState', width: 100,
                editor:
                    // isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?true:
                        false
                , menuDisabled: true}
        ]
    },
    {
        text: '优选等级调整',menuDisabled: true,
        columns: [
            {text: '当前优选等级', dataIndex: 'currentPreferredLevel', width: 100, editor: false, menuDisabled: true},
            {text: setMust('目标优选等级',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)),
                dataIndex: 'targetSelectionLevel', width: 100,
                editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?preferredLevel:false, menuDisabled: true}
        ]
    },
    {
        text: '内部版本调整',menuDisabled: true,
        columns: [
            {text: '当前内部版本', dataIndex: 'currentInternalVersion', width: 100, editor: false, menuDisabled: true},
            {text: setRequired('目标内部版本',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'targetInternalVersion', width: 100, editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?true:false, menuDisabled: true}
        ]
    },
    {
        text: '品牌调整',menuDisabled: true,
        columns: [
            {text: '当前品牌', dataIndex: 'currentBrand', width: 100, editor: false, menuDisabled: true},
            {text: setRequired('目标品牌',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'targetBrand', width: 100, editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?true:false, menuDisabled: true}
        ]
    },
    {
        text: '来料方式',menuDisabled: true,
        columns: [
            {text: '当前来料方式', dataIndex: 'currentIncomingMaterialMethod', width: 100, editor: false, menuDisabled: true},
            {text: setRequired('目标来料方式',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'targetIncomingMaterialMethod', width: 100, editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?targetIncomingMaterialMethod:false, menuDisabled: true}
        ]
    },
    {
        text: '供应商模具编号',menuDisabled: true,
        columns: [
            {text: '当前编号', dataIndex: 'currentNumber', width: 100, editor: false, menuDisabled: true},
            {text: setRequired('目标编号',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'targetNumber', width: 100, editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?true:false, menuDisabled: true}
        ]
    },
    // {
    //     text: '文件归档',menuDisabled: true,
    //     columns: [
    //         {text: setRequired('选择操作',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'selectOperation', width: 100, editor: false, menuDisabled: true},
    //         {text: setRequired('现有供应商',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'existingSuppliers', width: 100, editor: false, menuDisabled: true}
    //     ]
    // },
    {
        text: '其他业务属性',menuDisabled: true,
        columns: [
            {text: setRequired('最小包装量',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'minimumPackQuantity', width: 100, editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?true:false, menuDisabled: true},
            {text: setRequired('采购计量单位',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'procurementMeasurementUnit', width: 100, editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?procurementMeasurementUnit:false, menuDisabled: true},
            {text: setRequired('采购周期（天）',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'procurementCycle', width: 100, editor: isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?true:false, menuDisabled: true}
        ]
    },
    {text: '执行结果', dataIndex: 'resultsOfExecution', width: 100, editor: false, menuDisabled: true}
];

var maintenanceMaterialGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var maintenanceMaterialGrid = Ext.create('Ext.grid.Panel', {
    plugins: [maintenanceMaterialGridEditing],
    store: maintenanceMaterialStore,
    columns: maintenanceMaterialColumns,
    id:'maintenanceMaterialGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    tbar: [
        {
            xtype: 'button',
            text: '新增行',
            id: 'maintenanceMaterialInsert',
            iconCls: 'icon icon-add',
            hidden:isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?false:true,
            handler: function () {
                let callbackFn = function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        maintenanceMaterialStore.load();
                    }else {
                        alert(obj.message);
                    }
                };
                insertData('ZDataMaintenanceTable', branchId, callbackFn);
            }
        },
        {
            xtype: 'button',
            text: '删除行',
            id: 'maintenanceMaterialDelete',
            iconCls: 'icon icon-delete',
            hidden:isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?false:true,
            handler: function () {
                let selected = maintenanceMaterialGrid.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    let ids = '';
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            if(i == 0){
                                ids += id;
                            }else{
                                ids += ',' + id;
                            }
                        }
                    }
                    let callbackFn = function (response, opts) {
                        maintenanceMaterialGrid.getStore().remove(selected);
                        maintenanceMaterialGrid.view.refresh();
                    };
                    deleteData('ZDataMaintenanceTable', ids, callbackFn);
                }
            }
        }
    ]
});

maintenanceMaterialGrid.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            maintenanceMaterialStore.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZDataMaintenanceTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
maintenanceMaterialGrid.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});

//根据特定字段的值判断是否禁止编辑
maintenanceMaterialGrid.on('beforeedit', function (editor, context) {
    var record = context.record;
    var sampleConfirmationProgress = record.get('sampleConfirmationProgress');
    if(sampleConfirmationProgress === "确认终止"){
        return false; // 禁止编辑
    }
    // var defaultData = record.get('defaultData');
    var currentState = record.get('currentState');
    // 判断点击的是哪一列，列名
    var columnName = context.column.dataIndex;
    // if (defaultData) {
    if (currentState === "-") {
        return false; // 禁止编辑指定列
    }
    return true; // 允许编辑操作
});


var maintenanceMaterial  = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S07：物料属性及替代关系维护',
    padding:'5',
    collapsed:openPanel(initiator_confirms_integrated,system_administrator_confirms_integrated),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    width: '100%',
    anchor:'100%',
    defaults: {
        labelWidth: 80,
        border: false
    },
    items:[
        {
            xtype: 'displayfield',
            // fieldLabel: setMust('替代关系变更申请链接',isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)),
            fieldLabel: '替代关系变更申请链接',
            id: 'alternativeChangeRequestLink',
            name: 'alternativeChangeRequestLink',
            value:'',
            margin: '10 0 0 0',
            labelWidth: 150,
            width: 300,
            readOnly:isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?false:true
        },{
            xtype: 'textfield',
            fieldLabel: '替代关系变更申请状态',
            id: 'alternativeChangeRequestState',
            name: 'alternativeChangeRequestState',
            value:'',
            margin: '10 0 10 0',
            labelWidth: 150,
            width: 300,
            readOnly:isEditable(initiator_confirms_integrated,system_administrator_confirms_integrated)?false:true
        },
        maintenanceMaterialGrid
    ]
});