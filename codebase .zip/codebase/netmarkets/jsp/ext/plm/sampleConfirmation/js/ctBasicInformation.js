
//======================================单个字段查询开始==========================
        var roleUserCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
var singleFieldStore = Ext.create('Ext.data.Store', {
    model: '',
    id: 'singleFieldStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getSingleField?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            messageProperty: 'message'
        }
    }),
    autoLoad: true,

    listeners: {
        load: function(store, records, successful, operation, options) {
            if (successful) {
                // 获取返回的数据
                var singleFields = records[0].getData();
                singleFieldId = singleFields.id;
                //样品类型
                var sampleType = Ext.getCmp('sampleType');
                if(sampleType) {
                    var sampleTypeValue = singleFields.sampleType;
                    if (sampleTypeValue != null) {
                        if("快速流程"===sampleTypeValue){
                            fastTrack = true;
                        }
                        sampleType.setValue(sampleTypeValue);
                    }
                }

                //部门经理
                var sampleConfirmercomb = Ext.getCmp('sampleConfirmer');
                if(sampleConfirmercomb) {
                    var sampleConfirmerValue = singleFields.sampleConfirmer;
                    if (sampleConfirmerValue != null) {
                        sampleConfirmercomb.setRawValue(sampleConfirmerValue);
                    }
                }

                //紧急程度
                var urgencyDegree = Ext.getCmp('urgencyDegree');
                if(urgencyDegree) {
                    var urgencyDegreeValue = singleFields.urgencyDegree;
                    if (urgencyDegreeValue != null) {
                        urgencyDegree.setValue(urgencyDegreeValue);
                    }
                }

                //期望完成日期
                var expectedCompletionDate = Ext.getCmp('expectedCompletionDate');
                if(expectedCompletionDate) {
                    var expectedCompletionDateValue = singleFields.expectedCompletionDate;
                    if (expectedCompletionDateValue != null) {
                        var dateObj = new Date(expectedCompletionDateValue); // 创建一个 Date 对象
                        var formattedTime = Ext.Date.format(dateObj, 'Y-m-d');
                        expectedCompletionDate.setValue(formattedTime);
                    }
                }

                //关联流程类型
                var associatedProcessType = Ext.getCmp('associatedProcessType');
                if(associatedProcessType) {
                    var associatedProcessTypeValue = singleFields.associatedProcessType;
                    if (associatedProcessTypeValue != null) {
                        associatedProcessType.setValue(associatedProcessTypeValue);
                    }
                }

                //关联流程链接
                var associatedProcessLink = Ext.getCmp('associatedProcessLink');
                if(associatedProcessLink) {
                    var associatedProcessLinkValue = singleFields.associatedProcessLink;
                    if (associatedProcessLinkValue != null) {
                        var list = associatedProcessLinkValue.split('-');
                        var wmp = list[0];
                        var number = list[1];

                        // var processTypeObj = Ext.getCmp('associatedProcessType');
                        var processType =singleFields.associatedProcessType;
                        if(processType!== 'undefined') {
                            if("升级流程"===processType) {
                                var link = "<a href='" + promotionNoticeUrl + wmp + "' target='_blank' >"
                                    + number + "</a>";
                                associatedProcessLink.setValue(link);
                            }
                        }
                        if(processType!== 'undefined') {
                            if("工程变更"===processType) {
                                var link = "<a href='" + changeUrl + wmp + "' target='_blank' >"
                                    + number + "</a>";
                                associatedProcessLink.setValue(link);
                            }
                        }
                    }
                }

                //申请人
                var applicant = Ext.getCmp('applicant');
                if(applicant) {
                    var applicantValue = singleFields.applicant;
                    if (applicantValue != null) {
                        applicant.setValue(applicantValue);
                    }
                }

                //申请部门
                var applicationDepartment = Ext.getCmp('applicationDepartment');
                if(applicationDepartment) {
                    var applicationDepartmentValue = singleFields.applicationDepartment;
                    if (applicationDepartmentValue != null) {
                        applicationDepartment.setValue(applicationDepartmentValue);
                    }
                }
                //申请日期
                var applicationDate = Ext.getCmp('applicationDate');
                if(applicationDate) {
                    var applicationDateValue = singleFields.applicationDate;
                    if (applicationDateValue != null) {
                        var dateObj = new Date(applicationDateValue); // 创建一个 Date 对象
                        var formattedTime = Ext.Date.format(dateObj, 'Y-m-d');
                        applicationDate.setValue(formattedTime);
                    }
                }

                //替代关系变更申请链接
                var alternativeChangeRequestLink = Ext.getCmp('alternativeChangeRequestLink');
                if(alternativeChangeRequestLink) {
                    var alternativeChangeRequestLinkValue = singleFields.alternativeChangeRequestLink;
                    if (alternativeChangeRequestLinkValue != null) {
                        // 使用 "-" 符号拆分字符串
                        var parts = alternativeChangeRequestLinkValue.split("-");
                        // 拆分后的结果
                        var firstPart = parts[0]; // 第一个子字符串
                        var secondPart = parts[1]; // 第二个子字符串

                        var docLink = "<a href='" + urlPathPrefixDoc + secondPart + "' target='_blank' >"
                            + firstPart + "</a>";
                        alternativeChangeRequestLink.setValue(docLink);
                    }
                }

                //替代关系变更申请状态
                var alternativeChangeRequestState = Ext.getCmp('alternativeChangeRequestState');
                if(alternativeChangeRequestState!== 'undefined') {
                    var alternativeChangeRequestStateValue = singleFields.alternativeChangeRequestState;
                    if (alternativeChangeRequestStateValue != null) {
                        alternativeChangeRequestState.setValue(alternativeChangeRequestStateValue);
                    }
                }

            } else {
                let response = operation.getResponse();
                let responseData = Ext.JSON.decode(response.responseText);
                alert(responseData.message)
            }
        }
    }
});

//======================================单个字段查询结束==========================

var preferredLevel = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'preferredLevelCombo',
    id: 'preferredLevelCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '' },
            { fullName: 'A-优先推荐选用' },
            { fullName: 'B-可以选用' },
            { fullName: 'C-限制选用' },
            { fullName: 'D-停产禁选' },
            { fullName: 'E-禁止选用及采购' },
            { fullName: 'F-定制件选用' },
            { fullName: 'X-客供料' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName',
    tpl: getXTemplate('fullName')
});


var incomingMaterialMethod = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'incomingMaterialMethodCombo',
    id: 'incomingMaterialMethodCombo',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
            { fullName: '编带' },
            { fullName: '管装' },
            { fullName: '袋装' },
            { fullName: '散装' },
            { fullName: '盘装' },
            { fullName: '桶装' },
            { fullName: '卷' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});



var applicableProductModels = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'applicableProductModelsCombo',
    id: 'applicableProductModelsCombo',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
            { fullName: '参考物料使用情况查询结果' },
            { fullName: '参考替代组物料编码使用情况' },
            { fullName: '参考被替代物料使用情况查询结果' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

var isItAnImportantComponent = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'isItAnImportantComponentCombo',
    id: 'isItAnImportantComponentCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '是' },
            { fullName: '否' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

var storageTemperatureAndHumidity = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'storageTemperatureAndHumidityCombo',
    id: 'storageTemperatureAndHumidityCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '常温仓库' },
            { fullName: '恒温恒湿仓库' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

var opinionsOfTheInitiator= new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'opinionsOfTheInitiatorCombo',
    id: 'opinionsOfTheInitiatorCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '通过' },
            { fullName: '不通过' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});



var isItASubstituteMaterial = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'isItASubstituteMaterialCombo',
    id: 'isItASubstituteMaterialCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '是' },
            { fullName: '否' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

var seriesCertificationMaterials = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'seriesCertificationMaterialsCombo',
    id: 'seriesCertificationMaterialsCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '是' },
            { fullName: '否' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var supplierType = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'supplierTypeCombo',
    id: 'supplierTypeCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '新供应商' },
            { fullName: '未经过供应商评审的已开发供应商' },
            { fullName: '经过供应商评审的供应商' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

var supplierNature = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'supplierNatureCombo',
    id: 'supplierNaturelCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '代理商' },
            { fullName: '厂家' },
            { fullName: '贸易商' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var isTheSampleQualified = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'isTheSampleQualifiedCombo',
    id: 'isTheSampleQualifiedCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '是' },
            { fullName: '否' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var isItAHazardousChemical = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'isItAHazardousChemicalCombo',
    id: 'isItAHazardousChemicalCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '否' },
            { fullName: '001-与危险品，检查，和文档相关' },
            { fullName: 'G00-与危险品相关' },
            { fullName: 'G0P-与危险品和文档相关' },
            { fullName: 'GP0-与危险品和检查相关' },
            { fullName: 'GPP-与危险品，检查，和文档相关' },
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var reasonForSampleDelivery = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'reasonForSampleDeliveryCombo',
    id: 'reasonForSampleDeliveryCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '新产品新物料' },
            { fullName: '变更产生的新物料' },
            { fullName: '替代料' },
            { fullName: 'PCN' },
            { fullName: '其他' },
            { fullName: '外购成品' },
            { fullName: '辅料' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var theLifecycleOfTheMaterial = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'theLifecycleOfTheMaterialCombo',
    id: 'theLifecycleOfTheMaterialCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '出生' },
            { fullName: '成长' },
            { fullName: '成熟' },
            { fullName: '下降' },
            { fullName: '衰落' },
            { fullName: '灭亡' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var unitOfMeasurement  = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'unitOfMeasurementCombo',
    id: 'unitOfMeasurementCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: 'PCS' },
            { fullName: '微升' },
            { fullName: 'ML' },
            { fullName: 'L' },
            { fullName: 'G' },
            { fullName: 'mg' },
            { fullName: '微克' },
            { fullName: '千克' },
            { fullName: '米' },
            { fullName: '个' },
            { fullName: '盒' },
            { fullName: '平方' },
            { fullName: '台' },
            { fullName: 'U' },
            { fullName: '套' },
            { fullName: '厘米' },
            { fullName: 'square meters' },
            { fullName: '毫米' },
            { fullName: 'PC' },
            { fullName: '卷' },
            { fullName: 'PAA' },
            { fullName: '瓶' },
            { fullName: '批' },
            { fullName: '条' },
            { fullName: '桶' },
            { fullName: 'PAC' },
            { fullName: 'H' },
            { fullName: 'CV' },
            { fullName: 'M2' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var supplierNameStore = new Ext.data.ArrayStore({
    id: 'supplierNameStore',
    fields: [
        {name: "supplierName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/common/supplierNameList',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});
var supplierNameCom = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'supplierNameCom',
    id: 'supplierNameCom',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: supplierNameStore,
    valueField: 'supplierName',
    displayField: 'supplierName',
    minChars : 1,//开始查询最小字符数
    mode : 'local', //查询模式  local为本地数据源  remote为远程服务端
});





// ========================================S01基础信息第一张表开始=================================================================================

// var supplierNameCom = new Ext.form.ComboBox({
//     xtype: 'combo',
//     name: 'supplierNameCom',
//     id: 'supplierNameCom',
//     multiSelect: false,
//     anyMatch: true,
//     editable: false,
//     store: {
//         data: [
//         ],
//         fields: ['supplierName']
//     },
//     valueField: 'supplierName',
//     displayField: 'supplierName'
// });

Ext.define('basicInformationModel01', {
    extend: 'Ext.data.Model',
    fields: [
        'id','serialNumber','parentNumber','partDescribe','partSpecificationsAndModels','comSampConfPerson','preferredLevel','partState',
        'internalVersion','supplierMoldNumber','isItACriticalComponent','isItAnImportantComponent','isItASubstituteMaterial',
        'sampleSupplier','supplierType','supplierNature','sampleDeliveryNumber','numberOfSamples',
        'specification','manufacturersTestReport','pCNChangeLetter','thirdPartyTestReport','annotationDocumentation','others','fAIReport',
        'rdEnvCertRequirements','isTheSampleQualified','environmentalReport',
        'materialConfirmationProgress','partBranchId','storageTemperatureAndHumidity','isItAHazardousChemical','seriesCertificationMaterials'
    ],
    idProperty: 'basicInformationModel01'
});

var basicInformationStore01 = Ext.create('Ext.data.Store', {
    model: 'basicInformationModel01',
    id: 'basicInformationStore01',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtConfirmMainContentBo?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'basicInformationModel01',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});




var basicInformationColumns01 = [
    // {text: '序号', dataIndex: 'serialNumber', menuDisabled: true, editor: false},
    {text: '序号', width: 40, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: setMust('物料编号',isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1)), dataIndex: 'partNumber', width: 90, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1)?true:false, menuDisabled: true,

        renderer: function(value,metaData,record,row,col,store){
            if(value)
                metaData.tdAttr = 'data-qtip="' + value +'"';

            if(value) {
                var docLink = "<a href='" + urlPathPrefix +record.get('partBranchId') +"' target='_blank' >"
                    + value + "</a>";
                return docLink;
            }else {
                return value;
            }
        }

    },
    {text: '物料描述', dataIndex: 'partDescribe', width: 100,menuDisabled: true, editor: false,renderer:showTip},
    {text: '物料规格和型号', dataIndex: 'partSpecificationsAndModels', width: 100, editor: false, menuDisabled: true,renderer:showTip},
    {text: setMust('委托样品确认人',isEditable(procurement_sourcing_fill_in)),dataIndex: 'comSampConfPerson', width: 100,
    	editor:isEditable(procurement_sourcing_fill_in)?
    	/*{
        xtype: 'combobox',
        store: allUserCombo_conPerson,
        typeAhead: false,
        triggerAction: 'all',
        queryMode: 'local',
        displayField: 'value',
        valueField: 'key',
        repeatTriggerClick: true,
        selectOnFocus: true,
        allowBlank: true,
        forceSelection: true,
        matchFieldWidth: false
    }, */
    {
        xtype: 'combobox',
        valueField: 'userFullName',
        displayField: 'userFullName',
        typeAhead: false,
        triggerAction: 'all',
        queryMode: 'local',
        repeatTriggerClick: true,
        selectOnFocus: true,
        allowBlank: true,
        forceSelection: true,
        matchFieldWidth: false,
        store: allUserStore_conPerson2
    }:false,


    menuDisabled: true,renderer:showTip},

    {text: setRequired('是否系列认证资料',isEditable(sample_confirmation_submit02)), dataIndex: 'seriesCertificationMaterials', width: 100,menuDisabled: true, editor: isEditable(sample_confirmation_submit02)?seriesCertificationMaterials:false},

    {text: setMust('优选等级及描述',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'preferredLevel', width: 120,menuDisabled: true, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?preferredLevel:false,renderer:showTip},
    {text: '物料状态', dataIndex: 'partState', width: 80,menuDisabled: true, editor: false,},
    {text: setRequired('内部版本（变更触发的需要确认）',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'internalVersion', width: 100,menuDisabled: true, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?true:false},
    {text: setRequired('供应商模具编号',isEditable(procurement_sourcing_fill_in,improve_information,sample_confirmation_submit02)), dataIndex: 'supplierMoldNumber', width: 100,menuDisabled: true, editor: isEditable(procurement_sourcing_fill_in,improve_information)?true:false,renderer:showTip},
    {text: '是否为关键元器件', dataIndex: 'isItACriticalComponent', width: 100,menuDisabled: true, editor: false},
    {text: setMust('是否为重要元器件',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'isItAnImportantComponent', width: 100,menuDisabled: true, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?isItAnImportantComponent:false},
    {text: setMust('是否为替代物料',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'isItASubstituteMaterial', width: 100,menuDisabled: true, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?isItASubstituteMaterial:false},
    {text: setMust('供应商类型',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'supplierType', width: 100,menuDisabled: true, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?supplierType:false,renderer:showTip},
    {text: setMust('样品供应商',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'sampleSupplier', width: 100,menuDisabled: true, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?supplierNameCom:false,renderer:showTip},
    {text: setMust('供应商性质',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'supplierNature', width: 100,menuDisabled: true, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?supplierNature:false,renderer:showTip},
    {text: '送样次数', dataIndex: 'sampleDeliveryNumber', width: 100,menuDisabled: true, editor: false,},
    {text: setMust('样品数量',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'numberOfSamples', width: 100,menuDisabled: true, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?true:false},
    {
        text: '相关报告',menuDisabled: true,
        columns: [
            {text: setMust('规格书',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'specification', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'specification';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.specification;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'specification';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.specification;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {text: setRequired('生产厂家试验报告',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'manufacturersTestReport', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'manufacturersTestReport';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.manufacturersTestReport;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'manufacturersTestReport';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.manufacturersTestReport;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {text: setRequired('PCN变更函',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'pCNChangeLetter', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'pCNChangeLetter';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.pCNChangeLetter;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'pCNChangeLetter';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.pCNChangeLetter;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {text: setRequired('第三方试验报告',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'thirdPartyTestReport', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'thirdPartyTestReport';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.thirdPartyTestReport;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'thirdPartyTestReport';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.thirdPartyTestReport;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {text: setRequired('注释说明文档',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'annotationDocumentation', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'annotationDocumentation';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.annotationDocumentation;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'annotationDocumentation';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.annotationDocumentation;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {text: setRequired('其他资料',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'others', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'others';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.others;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'others';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.others;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {text: setRequired('环保报告',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'environmentalReport', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'environmentalReport';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.environmentalReport;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'environmentalReport';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.environmentalReport;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {text: setRequired('FAI报告',isEditable(start_node,resubmit_node,submit_fai_report,sample_confirmation_submit02,procurement_sourcing_fill_in,start_node1)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'fAIReport', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,submit_fai_report,sample_confirmation_submit02,procurement_sourcing_fill_in,start_node1)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'fAIReport';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.fAIReport;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'fAIReport';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1,procurement_sourcing_fill_in);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.fAIReport;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {text: setRequired('图片（初版）',isEditable(start_node,resubmit_node,submit_fai_report,sample_confirmation_submit02,start_node1,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)),xtype:'actioncolumn', dataIndex: 'picture', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(start_node,resubmit_node,submit_fai_report,sample_confirmation_submit02,start_node1,procurement_sourcing_fill_in)||(isEditable(tqc_confirms_sample_comments)&&fastTrack)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'picture';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.picture;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1,procurement_sourcing_fill_in);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'picture';
                            uploadTableName = 'ZConfirmMainContentTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'basicInformationGrid01';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.picture;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            }
        ]
    },
    {
        text: '环保认证要求确认',menuDisabled: true,
        columns: [
            {text: '研发环保认证要求', dataIndex: 'rdEnvCertRequirements', width: 100, editor: false, menuDisabled: false},
            {text: setMust('样品是否满足环保要求',isEditable(sqe_confirm_node)), dataIndex: 'isTheSampleQualified', width: 100, editor: isEditable(sqe_confirm_node)?isTheSampleQualified:false , menuDisabled: true},
        ]
    },
    {text: setMust('存储温湿度',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'storageTemperatureAndHumidity', width: 200, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?storageTemperatureAndHumidity:false, menuDisabled: true},
    {text: setMust('是否危化品',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'isItAHazardousChemical', width: 200, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?isItAHazardousChemical:false, menuDisabled: true},
    {text: '物料确认进展', dataIndex: 'materialConfirmationProgress', width: 200, editor: false, menuDisabled: true},
    {text: '', dataIndex: '', width: 10, menuDisabled: true}
];

var basicInformationGridEditing01 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var basicInformationGrid01 = Ext.create('Ext.grid.Panel', {
    plugins: [basicInformationGridEditing01],
    store: basicInformationStore01,
    columns: basicInformationColumns01,
    id:'basicInformationGrid01',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    viewConfig: {
        enableTextSelection: true
    },
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    tbar: [
        {
            xtype: 'button',
            text: '新增行',
            id: 'basicInformationInsert01',
            iconCls: 'icon icon-add',
            hidden:isEditable(start_node,start_node1)?false:true,
            handler: function () {
                let callbackFn = function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        basicInformationStore01.load();
                    }else {
                        alert(obj.message);
                    }
                };
                insertData('ZConfirmMainContentTable', branchId, callbackFn);
            }
        },
        {
            xtype: 'button',
            text: '删除行',
            id: 'basicInformationDelete01',
            iconCls: 'icon icon-delete',
            hidden:isEditable(start_node,start_node1)?false:true,
            handler: function () {
                var selected = basicInformationGrid01.getSelectionModel().getSelection();
                if (selected.length != 0) {
                    let ids = '';
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            if(i == 0){
                                ids += id;
                            }else{
                                ids += ',' + id;
                            }
                        }
                    }
                    let callbackFn = function (response, opts) {
                        basicInformationGrid01.getStore().remove(selected);
                        basicInformationGrid01.view.refresh();
                        basicInformationStore02.load();
                    };
                    deleteData('ZConfirmMainContentTable', ids, callbackFn);
                } else {
                    alert("请选择一条数据")
                }
            }
        },
        {
            xtype: 'button',
            text: '重复条目检索',
            id: 'retrievalButton',
            iconCls : 'icon icon-search',
            handler: function () {
                Ext.getStore('retrievalStore').reload({
                    params: {
                        branchId: branchId
                    }
                });
                retrieval.show()
            }
        }
    ]
});



basicInformationGrid01.on('edit',function(editor,e){
    if (e.originalValue === e.value) {
        return;
    }
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let id = record.get('id');
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            basicInformationStore01.load();
            basicInformationStore02.load();
        }else {
            basicInformationStore01.load();
            alert(obj.message)
        }
    };
    saveMockItemData("ZConfirmMainContentTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
basicInformationGrid01.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex; // 获取单元格的索引

    var partNumber = record.get('partNumber');
    if(!partNumber.startsWith("K")){
        // 清空原有数据
        isItASubstituteMaterial.getStore().removeAll();
        // 添加新的单个选项
        // isItASubstituteMaterial.getStore().add({
        //     fullName: '否'
        // });
        isItASubstituteMaterial.getStore().setData([
            { fullName: '否' }
        ]);
    }else {
        // 清空原有数据
        isItASubstituteMaterial.getStore().removeAll();
        // 添加新的单个选项
        isItASubstituteMaterial.getStore().add({
            fullName: '是'
        });
        isItASubstituteMaterial.getStore().add({
            fullName: '否'
        });
    }



    // var column = headerCt.getGridColumns()[cellIndex];
    // if (column) {
    //     var columnName = column.dataIndex;
    //     if (columnName == 'sampleSupplier') {
    //         partNumber = record.get('partNumber');
    //         supplierNameStore.load(
    //             {
    //                 params: {
    //                     partNumber: partNumber
    //                 }
    //             }
    //         );
    //     }
    // }
    // // 通过单元格索引获取列
    // var column = headerCt.getGridColumns()[cellIndex];
    // if (column) {
    //     var columnName = column.dataIndex;
    //     if(columnName=='sampleSupplier'){
    //         // supplierNameStore.load({
    //         //     params: {
    //         //         partNumber: partNumber
    //         //     }
    //         // });
    //         supplierNameCom.getStore().removeAll();
    //         Ext.Ajax.request({
    //             url: '/Windchill/ptc1/supplierNameList?partNumber='+partNumber,
    //             method:'GET',
    //             headers: {'Content-Type':'application/json'},
    //             // params: JSON.stringify(record.data),
    //             success: function (response, opts) {
    //                 var obj = Ext.decode(response.responseText);
    //                 if(obj.message=='success') {
    //                     var parentNumberList = Ext.decode(response.responseText).data;
    //                     var store = Ext.create('Ext.data.Store', {
    //                         fields: ['supplierName'], // 定义数据字段
    //                         data: parentNumberList.map(function(item) {
    //                             supplierNameCom.getStore().add({ supplierName: item });
    //                         })
    //                     });
    //                 }else {
    //                     alert(obj.message)
    //                 }
    //             },
    //             failure: function (response, opts) {
    //                 alert('错误：删除信息失败，请检查网络！!');
    //             }
    //         });
    //     }
    // }

});
//根据特定字段的值判断是否禁止编辑
basicInformationGrid01.on('beforeedit', function (editor, context) {
    var record = context.record;
    var materialConfirmationProgress = record.get('materialConfirmationProgress');
    if(materialConfirmationProgress === "确认终止"){
        return false; // 禁止编辑
    }


    var sampleType = Ext.getCmp('sampleType').getValue()
    // 判断点击的是哪一列，列名
    var columnName = context.column.dataIndex;
    if ((sampleType === '外购成品' || sampleType === '辅料')&& (columnName === 'isItASubstituteMaterial'
        || columnName === 'seriesCertificationMaterials')) {
        return false; // 禁止编辑指定列
    }
    var partNumber = record.get('partNumber');
    if(!partNumber){
        return true;
    }
    // if(!partNumber.startsWith("K")){
    //     // 清空原有数据
    //     isItASubstituteMaterial.getStore().removeAll();
    //     // 添加新的单个选项
    //     // isItASubstituteMaterial.getStore().add({
    //     //     fullName: '否'
    //     // });
    //     isItASubstituteMaterial.getStore().setData([
    //         { fullName: '否' }
    //     ]);
    // }else {
    //     // 清空原有数据
    //     isItASubstituteMaterial.getStore().removeAll();
    //     // 添加新的单个选项
    //     isItASubstituteMaterial.getStore().add({
    //         fullName: '是'
    //     });
    //     isItASubstituteMaterial.getStore().add({
    //         fullName: '否'
    //     });
    // }

    return true; // 允许编辑操作
});





// ========================================S01基础信息第一张表结束=================================================================================


// ========================================S01基础信息第二张表开始=================================================================================
var personLiableStore = new Ext.data.ArrayStore({
    id: 'personLiableStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/personLiableList',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});
var personLiableCom = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'personLiableCom',
    id: 'personLiableCom',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: personLiableStore,
    valueField: 'name',
    displayField: 'fullName',
    minChars : 1,//开始查询最小字符数
    mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
});


Ext.define('basicInformationModel02', {
    extend: 'Ext.data.Model',
    fields: [
        'serialNumber','partNumber','partDescribe','usageInquiry','relatedToSpecialCustomers','applicableProductModels',
        'brand','otherMaterialsSupplied','minimumPackQuantity','procurementMeasurementUnit','procurementCycle',
        'incomingMaterialMethod','isItASubstituteMaterial','detailedReasons','substitutionGroupMaterial','alternativeMaterials',
        'alternativeMaterialsDesc','usageInquirySubstituted','alternativeMaterialsSupplier','alternativeMaterialsBrand','originalPrice','currentPrice',
        'lastYearProcurementVolume','expectedAnnualPriceDifference','situationDescription','theLifecycleOfTheMaterial',
        'sampleConfirmer','relatedAccessories','reasonForSampleDelivery','opinionsOfTheInitiator'
    ],
    idProperty: 'basicInformationModel02'
});

var basicInformationStore02 = Ext.create('Ext.data.Store', {
    model: 'basicInformationModel02',
    id: 'basicInformationStore02',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtReplacePartInfoBo?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'basicInformationModel02',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

var basicInformationColumns02 = [
    // {text: '序号', dataIndex: 'serialNumber', menuDisabled: true, editor: true},
    {text: '序号', width: 40, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', width: 80, editor: false, menuDisabled: true,renderer:showTip},
    {text: '物料描述', dataIndex: 'partDescribe', width: 100,menuDisabled: true, editor: false,renderer:showTip},
    {text: '使用情况查询',xtype:'actioncolumn', dataIndex: 'usageInquiry', width: 80, editor: false , menuDisabled: true,
        items: ['->',{
            iconCls: 'icon-showInfo',
            tooltip: '使用情况查询',
            handler: function(grid, rowIndex, colIndex) {
                var record = grid.getStore().getAt(rowIndex);
                var id = record.get('id');
                var partNumber = record.get('partNumber');
                Ext.getStore('usageInquiryStore').reload({
                    params: {
                        id: id,
                        branchId:branchId,
                        partNumber:partNumber,
                        currentActKey:currentActKey,
                        fieldName:'usageInquiry'
                    }
                });
                // usageInquiryStore.load();
                usageInquiry.show();
            },
            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                // var boolean = record.data.usageInquiry;
                // if(boolean!=null) {
                    return false;
                // }
                // return true;
            }
        },'->']
    },

    {text: '是否涉及特殊客户', dataIndex: 'relatedToSpecialCustomers', width: 100,menuDisabled: true, editor: false,renderer:showTip},
    {text: setMust('适用产品型号',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'applicableProductModels', width: 100,menuDisabled: true, editor:isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)? applicableProductModels:false,renderer:showTip},
    {text: setMust('品牌',isEditable(start_node,resubmit_node,procurement_sourcing_fill_in,improve_information,sample_confirmation_submit02)), dataIndex: 'brand', width: 80,menuDisabled: true, editor: isEditable(start_node,resubmit_node,procurement_sourcing_fill_in,improve_information,sample_confirmation_submit02)? true:false,renderer:showTip},
    {text: '该品牌已供应的其他物料',xtype:'actioncolumn', dataIndex: 'otherMaterialsSupplied', width: 100,menuDisabled: true, editor: false,
        items: ['->',{
            iconCls: 'icon-showInfo',
            tooltip: '该品牌已供应的其他物料',
            handler: function(grid, rowIndex, colIndex) {
                var record = grid.getStore().getAt(rowIndex);
                var cellValue = record.get('brand');
                Ext.getStore('otherMaterialsSuppliedStore').reload({
                    params: {
                        brand: cellValue
                    }
                });
                otherMaterialsSupplied.show();
            },
            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                var boolean = record.data.otherMaterialsSupplied;
                if(boolean!=null) {
                    return false;
                }
                return true;
            }
        },'->']
    },
    {text: setRequired('最小包装量',isEditable(procurement_sourcing_fill_in)), dataIndex: 'minimumPackQuantity', width: 80,menuDisabled: true, editor: isEditable(procurement_sourcing_fill_in)? true:false,renderer:showTip},
    {text: setMust('采购计量单位',isEditable(procurement_sourcing_fill_in)), dataIndex: 'procurementMeasurementUnit', width: 90,menuDisabled: true, editor: isEditable(procurement_sourcing_fill_in)? unitOfMeasurement:false,renderer:showTip},
    {text: setMust('采购周期（天）',isEditable(procurement_sourcing_fill_in)), dataIndex: 'procurementCycle', width: 100,menuDisabled: true, editor: isEditable(procurement_sourcing_fill_in)? true:false,renderer:showTip},
    {text: setMust('来料方式',isEditable(procurement_sourcing_fill_in)), dataIndex: 'incomingMaterialMethod', width: 80,menuDisabled: true, editor: isEditable(procurement_sourcing_fill_in)? incomingMaterialMethod:false,renderer:showTip},

    {
        text: '替代物料',menuDisabled: true,
        columns: [
            {text: '是否为替代物料', dataIndex: 'isItASubstituteMaterial', width: 100, editor: false, menuDisabled: true},
            {text: setRequired('替代组物料编码',isEditable(start_node,resubmit_node,procurement_sourcing_fill_in,sample_confirmation_submit02)), dataIndex: 'substitutionGroupMaterial', width: 100, editor: isEditable(start_node,resubmit_node,procurement_sourcing_fill_in,sample_confirmation_submit02)? true:false, menuDisabled: true},
            {text: '使用情况查询',xtype:'actioncolumn', dataIndex: 'usageInquiryReplace', width: 80, editor: false , menuDisabled: true,
                items: ['->',{
                    iconCls: 'icon-showInfo',
                    tooltip: '使用情况查询',
                    handler: function(grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        var id = record.get('id');
                        var partNumber = record.get('substitutionGroupMaterial');
                        Ext.getStore('usageInquiryStore').reload({
                            params: {
                                id: id,
                                branchId:branchId,
                                partNumber:partNumber,
                                currentActKey:currentActKey,
                                fieldName:'usageInquiryReplace'
                            }
                        });
                        // usageInquiryStore.load();
                        usageInquiry.show();
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var boolean = record.data.substitutionGroupMaterial;
                        if(boolean!=null) {
                            return false;
                        }
                        return true;
                    }
                },'->']
            },
            {text: setRequired('被替代物料编号',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'alternativeMaterials', width: 100, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)? true:false, menuDisabled: true},
            {text: '被替代物料描述', dataIndex: 'alternativeMaterialsDesc', width: 100, editor: false, menuDisabled: true,renderer:showTip},
            {text: '使用情况查询',xtype:'actioncolumn', dataIndex: 'usageInquirySubstituted', width: 80, editor: false , menuDisabled: true,
                items: ['->',{
                    iconCls: 'icon-showInfo',
                    tooltip: '使用情况查询',
                    handler: function(grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        var id = record.get('id');
                        var partNumber = record.get('alternativeMaterials');
                        Ext.getStore('usageInquiryStore').reload({
                            params: {
                                id: id,
                                branchId:branchId,
                                partNumber:partNumber,
                                currentActKey:currentActKey,
                                fieldName:'usageInquirySubstituted'
                            }
                        });
                        // usageInquiryStore.load();
                        usageInquiry.show();
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var boolean = record.data.alternativeMaterials;
                        if(boolean!=null) {
                            return false;
                        }
                        return true;
                    }
                },'->']
            },
            {text: setRequired('被替代物料供应商',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'alternativeMaterialsSupplier', width: 100, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)? supplierNameCom:false, menuDisabled: true,renderer:showTip},
            {text: '被替代物料物料品牌', dataIndex: 'alternativeMaterialsBrand', width: 100, editor: false, menuDisabled: true,renderer:showTip},
            {text: '预期经济效益',menuDisabled: true,
                columns: [
                    {text: '原价格', dataIndex: 'originalPrice', width: 100, editor: false, menuDisabled: true},
                    {text: setRequired('现价格',isEditable(procurement_sourcing_fill_in)), dataIndex: 'currentPrice', width: 100, editor: isEditable(procurement_sourcing_fill_in)? true:false, menuDisabled: true},
                    {text: setRequired('上一年度采购量',isEditable(procurement_sourcing_fill_in)), dataIndex: 'lastYearProcurementVolume', width: 100, editor: isEditable(procurement_sourcing_fill_in)? true:false, menuDisabled: true},
                    {text: '预期年度价格差', dataIndex: 'expectedAnnualPriceDifference', width: 100, editor: false, menuDisabled: true}
                ]
            }
        ]
    },
    {
        text: '其他物料',menuDisabled: true,
        columns: [
            {text: setRequired('情况说明',isEditable(start_node,resubmit_node,sample_confirmation_submit02)), dataIndex: 'situationDescription', width: 100, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02)? true:false, menuDisabled: true,renderer:showTip}
        ]
    },
    {text: setMust('物料所处生命周期',isEditable(procurement_sourcing_fill_in,improve_information)), dataIndex: 'theLifecycleOfTheMaterial', width: 200, editor: isEditable(procurement_sourcing_fill_in,improve_information)? theLifecycleOfTheMaterial:false, menuDisabled: true},
    // {text: setMust('样品确认人',isEditable(procurement_sourcing_fill_in,improve_information)), dataIndex: 'sampleConfirmer', width: 200, editor: isEditable(procurement_sourcing_fill_in,improve_information)?personLiableCom:false, menuDisabled: true},
    {text: setMust('送样原因',isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)), dataIndex: 'reasonForSampleDelivery', width: 100, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02,procurement_sourcing_fill_in)?reasonForSampleDelivery:false , menuDisabled: true},
    {text: setMust('详细原因',isEditable(procurement_sourcing_fill_in)), dataIndex: 'detailedReasons', width: 100, editor: isEditable(start_node,resubmit_node,procurement_sourcing_fill_in,sample_confirmation_submit02)? true:false, menuDisabled: true,renderer:showTip},
    {text: setRequired('相关附件',isEditable(start_node,resubmit_node,procurement_sourcing_fill_in,sample_confirmation_submit02)),xtype:'actioncolumn', dataIndex: 'relatedAccessories', width: 200, editor: false, menuDisabled: true,
        items: [
            '->',
            {
                iconCls: 'icon icon-uploadImage',
                tooltip: '添加文件',
                hidden:isEditable(start_node,resubmit_node,procurement_sourcing_fill_in,sample_confirmation_submit02)?false:true,
                handler: function(grid, rowIndex, colIndex) {
                    var record = grid.getStore().getAt(rowIndex);
                    //设置当前列的id与列名和表名
                    fileColumnId = record.get('id');
                    fileColumnName = 'relatedAccessories';
                    uploadTableName = 'ZReplacePartInfoTable';
                    //设置grid名称用于上传文件后刷新数据
                    gridName = 'basicInformationGrid02';

                    uploadImageWindow.show();
                }
            },
            '-',
            {
                iconCls: 'icon-showInfo',
                tooltip: '查看文件',
                handler: function(grid, rowIndex, colIndex) {
                    var record = grid.getStore().getAt(rowIndex);
                    //设置当前列的id与列名和表名
                    fileColumnId = record.get('id');
                    fileColumnName = 'relatedAccessories';
                    uploadTableName = 'ZReplacePartInfoTable';
                    //设置grid名称用于上传文件后刷新数据
                    gridName = 'basicInformationGrid02';
                    // 刷新当前单元格内文件
                    showStore.load({
                        params: {
                            fileColumnId: fileColumnId,
                            fileColumnName: fileColumnName,
                            uploadTableName:uploadTableName
                        }
                    });
                    showDeleteValue = !isEditable(start_node,resubmit_node,sample_confirmation_submit02);
                    showFile.show();
                },
                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                    var boolean = record.data.relatedAccessories;
                    if(boolean!=null) {
                        return false;
                    }
                    return true;
                }
            }
        ]
    },
    // {text: setMust('发起人意见',isEditable(start_node,resubmit_node,sample_confirmation_submit02)), dataIndex: 'opinionsOfTheInitiator', width: 100, editor: isEditable(start_node,resubmit_node,sample_confirmation_submit02)?opinionsOfTheInitiator:false , menuDisabled: true},
    {text: setMust('发起人意见',isEditable(sample_confirmation_submit02_again)), dataIndex: 'opinionsOfTheInitiator', width: 100, editor: isEditable(sample_confirmation_submit02_again)?opinionsOfTheInitiator:false , menuDisabled: true},
    {text: '', dataIndex: '', width: 10, menuDisabled: true}
];

var basicInformationGridEditing02 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var basicInformationGrid02 = Ext.create('Ext.grid.Panel', {
    plugins: [basicInformationGridEditing02],
    store: basicInformationStore02,
    columns: basicInformationColumns02,
    viewConfig: {
        enableTextSelection: true
    },
    id:'basicInformationGrid02',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    // tbar: [
    //     {
    //         xtype: 'button',
    //         text: '新增行',
    //         id: 'basicInformationInsert02',
    //         iconCls: 'icon icon-add',
    //         handler: function () {
    //             let callbackFn = function (response, opts) {
    //                 var obj = Ext.decode(response.responseText);
    //                 if(obj.message=='success') {
    //                     basicInformationStore02.load();
    //                 }else {
    //                     alert(obj.message);
    //                 }
    //             };
    //             insertData('ZReplacePartInfoTable', branchId, callbackFn);
    //         }
    //     },
    //     {
    //         xtype: 'button',
    //         text: '删除行',
    //         id: 'basicInformationDelete02',
    //         iconCls: 'icon icon-delete',
    //         handler: function () {
    //             var selected = basicInformationGrid02.getSelectionModel().getSelection();
    //             if (selected.length != 0) {
    //                 let ids = '';
    //                 for (let i = 0; i < selected.length; i++) {
    //                     let id = selected[i].get('id');
    //                     if (id) {
    //                         if(i == 0){
    //                             ids += id;
    //                         }else{
    //                             ids += ',' + id;
    //                         }
    //                     }
    //                 }
    //                 let callbackFn = function (response, opts) {
    //                     basicInformationGrid02.getStore().remove(selected);
    //                     basicInformationGrid02.view.refresh();
    //                 };
    //                 deleteData('ZReplacePartInfoTable', ids, callbackFn);
    //             } else {
    //                 alert("请选择一条数据")
    //             }
    //         }
    //     },
    //     {
    //         xtype: 'filefield',
    //         buttonOnly: true,
    //         id: 'technicalDocument_uploadFile',
    //         name: 'technicalDocument_uploadFile',
    //         hideLabel: true,
    //         buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '上传附件',
    //         allowBlank: false,
    //         scope: this,
    //         listeners: {
    //             'click': function () {
    //                 let selectionArr = basicInformationGrid02.getSelectionModel().getSelection();
    //                 if (selectionArr.length == 0) {
    //                     alert("未选择添加文件行！");
    //                     return false;
    //                 }
    //             },
    //             'focus': function () {
    //                 let selectionArr = basicInformationGrid02.getSelectionModel().getSelection();
    //                 if (selectionArr.length == 0) {
    //                     alert("未选择添加文件行！");
    //                     return false;
    //                 }
    //                 if (selectionArr.length >= 2) {
    //                     alert("不支持多行添加文件操作，请确认要添加的行");
    //                     return false;
    //                 }
    //                 dropdownWindow.show();
    //
    //
    //                 var file = selectionArr[0].get("attachmentFile");
    //                 if (file != undefined) {
    //                     alert("只能上传一个文件!");
    //                     return;
    //                 }
    //             },
    //             'change': function (fb, newValue) {
    //                 if (!newValue) {
    //                     return;
    //                 }
    //                 let selectionArr = basicInformationGrid02.getSelectionModel().getSelection();
    //                 var file = selectionArr[0].get("pCN");
    //                 if (file != undefined) {
    //                     alert("只能上传一个文件!");
    //                     return;
    //                 }
    //                 if (selectionArr.length == 0) {
    //                     alert("添加文件失败，未选择添加文件对象!");
    //                     return;
    //                 } else {
    //                     var file = document.querySelector('[id=' + 'technicalDocument_uploadFile' + '-button-fileInputEl]');
    //                     var formData = new FormData();
    //                     formData.append('technicalDocument_uploadFile' + '-button-fileInputEl', file.files[0]);
    //                     fb.reset();//清空表单的值
    //                     var myMask = new Ext.LoadMask({
    //                         msg: '正在上传，请稍候......',
    //                         target: this.findParentByType('panel')
    //                     });
    //                     var tRecord = relatedProductsGrid.getSelectionModel().getSelection()[0];
    //                     var serialNumber = tRecord.get('serialNumber');
    //                     myMask.show();
    //                     $.ajax({
    //                         url: '/Windchill/ptc1/technicalChange/uploadFiles?docNumber=' + docNumber + '&tetx_name=' + 'PCN' + "&node=" + 'technicalDocument_node' + "&type=technicalDocument"+"&serialNumber="+serialNumber,
    //                         type: 'POST',
    //                         cache: false,
    //                         data: formData,
    //                         processData: false,
    //                         contentType: false
    //                     }).done(function (res) {
    //                         myMask.hide();
    //                         var obj = Ext.decode(res);
    //                         var success = obj['success'];
    //                         var msg = obj['msg'];
    //                         if (!success) {
    //                             alert(msg);
    //                         } else {
    //                             var fileName = obj['fileName'];
    //                             var filePath = obj['filePath'];
    //
    //                             tRecord.set('pCN', fileName);
    //                             tRecord.set('pCNPath', filePath);
    //
    //                             Ext.Ajax.request({
    //                                 url: '/Windchill/ptc1/saveTechnicalChangeProduct',
    //                                 method:'POST',
    //                                 headers: {'Content-Type':'application/json'},
    //                                 params: JSON.stringify(tRecord.data),
    //                                 success: function (response, opts) {
    //                                     var obj = Ext.decode(response.responseText);
    //                                     if(obj.message=='success') {
    //                                         var obj = Ext.decode(response.responseText);
    //                                         relatedProductsStore.load();
    //                                     }else {
    //                                         relatedProductsStore.load();
    //                                         alert(obj.message);
    //                                     }
    //                                 },
    //                                 failure: function (response, opts) {
    //                                     relatedProductsStore.load();
    //                                     alert('错误：修改信息失败，请检查网络！!');
    //                                 }
    //                             });
    //                         }
    //                         var callbackFn = function () {
    //                             Ext.getStore('ctTechnicalDocumentStore').reload();
    //                         };
    //                     }).fail(function (res) {
    //                         myMask.hide();
    //                         alert('上传失败！');
    //                     });
    //                 }
    //             }
    //
    //         }
    //     }
    // ]
});

basicInformationGrid02.on('edit',function(editor,e){
    if (e.originalValue === e.value) {
        return;
    }
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let id = record.get('id');
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            basicInformationStore02.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZReplacePartInfoTable", id, field, value, callbackFn);

});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
basicInformationGrid02.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex; // 获取单元格的索引

    // var column = headerCt.getGridColumns()[cellIndex];
    // if (column) {
    //     var columnName = column.dataIndex;
    //     if (columnName == 'alternativeMaterialsSupplier') {
    //         partNumber = record.get('alternativeMaterials');
    //         supplierNameStore.load(
    //             {
    //                 params: {
    //                     partNumber: partNumber
    //                 }
    //             }
    //         );
    //     }
    // }

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];
    if (column) {
        var columnName = column.dataIndex;
        if(columnName=='sampleSupplier'){
            // parentNumberCom.getStore().removeAll();
            // Ext.Ajax.request({
            //     url: '/Windchill/ptc1/searchParentNumberList?docNumber='+docNumber,
            //     method:'POST',
            //     headers: {'Content-Type':'application/json'},
            //     // params: JSON.stringify(record.data),
            //     success: function (response, opts) {
            //         var obj = Ext.decode(response.responseText);
            //         if(obj.message=='success') {
            //             var parentNumberList = Ext.decode(response.responseText).data;
            //             var store = Ext.create('Ext.data.Store', {
            //                 fields: ['parentNumber'], // 定义数据字段
            //                 data: parentNumberList.map(function(item) {
            //                     parentNumberCom.getStore().add({ fullName: item });
            //                 })
            //             });
            //         }else {
            //             alert(obj.message)
            //         }
            //     },
            //     failure: function (response, opts) {
            //         alert('错误：删除信息失败，请检查网络！!');
            //     }
            // });
        }
    }

});

//根据特定字段的值判断是否禁止编辑
basicInformationGrid02.on('beforeedit', function (editor, context) {
    var record = context.record;
    var sampleType = record.get('isItASubstituteMaterial');
    // 判断点击的是哪一列，列名
    var columnName = context.column.dataIndex;
    if (sampleType === '否'||"不适用" === sampleType) {
        if(columnName === 'isItASubstituteMaterial'||columnName === 'substitutionGroupMaterial'||
            columnName === 'alternativeMaterials'||columnName === 'alternativeMaterialsDesc'||columnName === 'alternativeMaterialsSupplier'||
            columnName === 'alternativeMaterialsBrand'||columnName === 'originalPrice'||columnName === 'currentPrice'||
            columnName === 'lastYearProcurementVolume'||columnName === 'expectedAnnualPriceDifference'){
            return false; // 禁止编辑指定列
        }
    }
    return true; // 允许编辑操作
});







// ========================================S01基础信息第二张表结束=================================================================================


var basicInformationPanel = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S01：基础信息',
    padding:'5',
    collapsed:openPanel(start_node,resubmit_node,submit_fai_report,procurement_sourcing_fill_in,sqe_confirm_node,sample_confirmation_submit02,sample_confirmation_submit02_again,start_node1),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    border: false,
    anchor:'100%',
    items:[
        {
            xtype: 'panel',
            layout: 'hbox',
            border: false,
            align: 'stretch',
            defaults: {margin: '5 20 0 0', labelWidth: 100},
            items: [{
                    xtype: 'combobox',
                    fieldLabel: setMust('样品类型',isEditable(start_node,resubmit_node,start_node1)),
                    id: 'sampleType',
                    name: 'sampleType',
                    value:'',
                    width: 200,
                    multiSelect: false,
                    anyMatch: true,
                    editable: false,
                    readOnly:isEditable(start_node,resubmit_node,start_node1)?false:true,
                    store: {
                        data: [
                            { fullName: '快速流程' },
                            { fullName: '外购成品' },
                            { fullName: '普通物料' },
                            { fullName: '辅料' },
                            { fullName: '简易流程' }
                        ],
                        fields: ['fullName']
                    },
                    valueField: 'fullName',
                    displayField: 'fullName',
                    listeners: {
                        select: function(combo, records) {
                            if(!isEditable(start_node,resubmit_node,start_node1)){
                                return;
                            }
                            // // 获取下拉框选中的新值
                            // var newValue = combo.getValue();
                            // // 获取下拉框之前的旧值
                            // var oldValue = combo.lastValue;
                            // if (newValue === oldValue) {
                            //     return;
                            // }

                            var sampleTypeValue =  combo.getValue();
                            var callbackFn = function (response, opts) {
                                singleFieldStore.load();
                            };
                            saveMockItemData("ZConfirmationBasisTable", singleFieldId, "sampleType", sampleTypeValue, callbackFn);
                            basicInformationStore01.load();
                            basicInformationStore02.load();
                        }
                    }
                },
                {
                    xtype: 'combobox',
                    fieldLabel: setMust('部门经理',isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1)),
                    id: 'sampleConfirmer',
                    name: 'sampleConfirmer',
                    value:'',
                    width: 200,
                    multiSelect: false,
                    anyMatch: true,
                    editable: isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1),
                    readOnly:isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1)?false:true,
                    store: personLiableStore,
                    minChars : 1,//开始查询最小字符数
                    mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
                    forceSelection: isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1),
                    valueField: 'name',
                    displayField: 'fullName',
                    listeners: {
                        select: function(combo, records) {
                            if(!isEditable(start_node,resubmit_node,sample_confirmation_submit02,start_node1)){
                                return;
                            }
                            // // 获取下拉框选中的新值
                            // var newValue = combo.getValue();
                            // // 获取下拉框之前的旧值
                            // var oldValue = combo.lastValue;
                            // if (newValue === oldValue) {
                            //     return;
                            // }

                            var sampleTypeValue =  combo.getValue();
                            var callbackFn = function (response, opts) {
                                singleFieldStore.load();
                            };
                            saveMockItemData("ZConfirmationBasisTable", singleFieldId, "sampleConfirmer", sampleTypeValue, callbackFn);
                        }
                    }
                }


                , {
                    xtype: 'textfield',
                    fieldLabel: '紧急程度',
                    id: 'urgencyDegree',
                    name: 'urgencyDegree',
                    value:'',
                    width: 200,
                    readOnly:true
                },{
                    xtype: 'datefield',
                    fieldLabel: setMust('期望完成日期',isEditable(start_node,resubmit_node,start_node1)),
                    format: 'Y-m-d',  // 设置日期格式为中文
                    // altFormats: 'Y-m-d|Ymd',  // 可选的其他日期格式（如果需要）
                    submitFormat: 'Y-m-d',  // 提交的日期格式
                    id: 'expectedCompletionDate',
                    name: 'expectedCompletionDate',
                    readOnly:isEditable(start_node,resubmit_node,start_node1)?false:true,
                    // value:'',
                    width: 200,
                    listeners: {
                        change: function(dateField, newValue, oldValue, eOpts) {
                            if (newValue === oldValue) {
                                return;
                            }
                            // 获取选择的日期
                            var expectedCompletionDate = Ext.Date.format(newValue, 'Y-m-d');
                            var callbackFn = function (response, opts) {
                                singleFieldStore.load();
                            };
                            if(isEditable(start_node,resubmit_node,start_node1)) {
                                saveMockItemData("ZConfirmationBasisTable", singleFieldId, "expectedCompletionDate", expectedCompletionDate, callbackFn);
                            }
                        }
                    }
                },{
                    xtype: 'textfield',
                    fieldLabel: '关联流程类型',
                    id: 'associatedProcessType',
                    name: 'associatedProcessType',
                    value:'',
                    width: 200,
                    readOnly:true
                },{
                    xtype: 'displayfield',
                    fieldLabel: '关联流程链接',
                    id: 'associatedProcessLink',
                    name: 'associatedProcessLink',
                    value:'',
                    width: 300,
                    readOnly:true
                }
            ]
        },
        {
            xtype: 'panel',
            layout: 'hbox',
            border: false,
            align: 'stretch',
            defaults: {margin: '5 20 0 0', labelWidth: 100},
            items: [{
                xtype: 'displayfield',
                fieldLabel: '申请人',
                id: 'applicant',
                name: 'applicant',
                value:'',
                width: 200,

            },{
                xtype: 'displayfield',
                fieldLabel: '申请部门',
                id: 'applicationDepartment',
                name: 'applicationDepartment',
                value:'',
                width: 200,

            },{
                xtype: 'displayfield',
                fieldLabel: '申请日期',
                id: 'applicationDate',
                name: 'applicationDate',
                value:'',
                width: 300,

            }]
        },
        basicInformationGrid01
        ,basicInformationGrid02
    ]
});


// ================================================重复条目检索页面开始================================================================================
Ext.define('retrievalModel', {
    extend: 'Ext.data.Model',
    fields: [
        'docNumber','docStatus','partNumber','internalVersion','sampleSupplier','materialConfirmationProgress'
    ],
    idProperty: 'retrievalModel'
});

var retrievalStore = Ext.create('Ext.data.Store', {
    model: 'retrievalModel',
    id: 'retrievalStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirmation/queryDuplicateEntries?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'retrievalModel',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

var retrievalColumns = [
    {text: '样品确认单编号', dataIndex: 'docNumber', flex: 1,menuDisabled: true, editor: false},
    {text: '样品确认单状态', dataIndex: 'docStatus', flex: 1, editor: false, menuDisabled: true,},
    {text: '物料编号', dataIndex: 'partNumber', flex: 1,menuDisabled: true, editor: false,},
    {text: '内部版本', dataIndex: 'internalVersion',flex: 1, editor: false , menuDisabled: true},
    {text: '供应商编号_供应商名称', dataIndex: 'sampleSupplier', flex: 1,menuDisabled: true, editor: false},
    {text: '样品确认进展', dataIndex: 'materialConfirmationProgress', flex: 1,menuDisabled: true, editor: false,}
];

var retrievalGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var retrievalGrid = Ext.create('Ext.grid.Panel', {
    plugins: [retrievalGridEditing],
    store: retrievalStore,
    columns: retrievalColumns,
    id:'retrievalGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    // selType: 'checkboxmodel',
});


var retrieval = Ext.create('Ext.Window', {
    id:'retrieval',
    title: '相同物料信息',
    width: 700,
    //height: 300,
    autoHeight : true,
    closeAction: 'hide',
    //closable:false,
    constrain: true,
    modal:true,
    items:[retrievalGrid],
});

// ================================================重复条目检索页面结束================================================================================



// ================================================使用情况查询页面开始================================================================================
// Ext.define('usageInquiryModel', {
//     extend: 'Ext.data.Model',
//     fields: [
//         'parentNumber','partDescribe','partState','specialCustomers'
//     ],
//     idProperty: 'usageInquiryModel'
// });
//
// var usageInquiryStore = Ext.create('Ext.data.Store', {
//     model: 'usageInquiryModel',
//     id: 'usageInquiryStore',
//     pruneModifiedRecords: true,
//     proxy: new Ext.data.HttpProxy({
//         // url: '/Windchill/ptc1/searchTechnicalChangeOnTrial?docNumber='+docNumber,
//         method:'GET',
//         reader:{
//             type:'json',
//             rootProperty: 'data',
//             idProperty: 'usageInquiryModel',
//             messageProperty: 'message'
//         }
//     }),
//     autoLoad:true,
// });
//
// var usageInquiryColumns = [
//     {text: '物料编号', dataIndex: 'parentNumber', flex: 1,menuDisabled: true, editor: false,},
//     {text: '物料描述', dataIndex: 'partDescribe',flex: 1, editor: false , menuDisabled: true},
//     {text: '状态', dataIndex: 'partState', flex: 1,menuDisabled: true, editor: false},
//     {text: '特殊客户', dataIndex: 'specialCustomers', flex: 1,menuDisabled: true, editor: false,}
// ];
//
// var usageInquiryGridEditing = new Ext.grid.plugin.CellEditing({
//     clicksToEdit: 1
// });
//
// var usageInquiryGrid = Ext.create('Ext.grid.Panel', {
//     plugins: [usageInquiryGridEditing],
//     store: usageInquiryStore,
//     columns: usageInquiryColumns,
//     id:'usageInquiryGrid',
//     autoWidth: true,
//     columnLines: true,
//     width:'100%',
//     height:'100%',
//     height:300,
//     multiSelect : false,
//     autoScroll: true,
//     forceFit: false,
//     // selType: 'checkboxmodel',
// });


//树的列模型
Ext.define('usageInquiryModel', {
    extend: 'Ext.data.Model',
    fields: [
        'parentNumber','viewNameAndVersion','partDescribe','partState','relatedToSpecialCustomers','model'
    ],
    idProperty: 'partPath'
});

var usageInquiryStore = Ext.create('Ext.data.TreeStore', {
    id: 'usageInquiryStore',
    model: 'usageInquiryModel',
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirmation/getUsageInquiry',
        method: 'GET',
        timeout: 99999999,
        reader: {
            type: 'json'
        }
    }),
    root: {
        expanded: true
    },
    listeners: {
        // beforeload: function (store, opts) {
        //     Ext.apply(store.proxy.extraParams, data);
        // }
    },
    autoLoad: false,
    folderSort: true
});

var usageInquiryGridCellEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var usageInquiryGrid = Ext.create('Ext.tree.Panel', {
    plugins: [usageInquiryGridCellEditing],
    store: usageInquiryStore,
    rootVisible: false,
    width: 820,
    height: 300,
    // autoWidth: true,
    expanded: true,
    border: 0,
    id: 'usageInquiryGrid',
    autoScroll: true,
    viewConfig: { enableTextSelection: true },
    columnLines: true,
    columns: [
        {xtype: 'treecolumn',text: '物料编号', width: 300, dataIndex: 'partNumber', menuDisabled: true, sortable: false
            ,editor: {xtype: 'textfield', selectOnFocus: true, editable: false}},
        {text: '视图（版本）', width: 100, dataIndex: 'viewNameAndVersion', menuDisabled: true, sortable: false,editor: false
            ,editor: {xtype: 'textfield', selectOnFocus: true, editable: false}},
        {text: '物料描述', width: 100, dataIndex: 'partDescribe', menuDisabled: true, sortable: false,editor: false
            ,editor: {xtype: 'textfield', selectOnFocus: true, editable: false}},
        {text: '型号', width: 100, dataIndex: 'model', menuDisabled: true, sortable: false,editor: false
            ,editor: {xtype: 'textfield', selectOnFocus: true, editable: false}},
        {text: '状态', width: 120, dataIndex: 'partState', menuDisabled: true, sortable: false,editor: false
            ,editor: {xtype: 'textfield', selectOnFocus: true, editable: false}},
        {text: '特殊客户', width: 200, dataIndex: 'relatedToSpecialCustomers', menuDisabled: true, sortable: false,editor: false
            ,editor: {xtype: 'textfield', selectOnFocus: true, editable: false}}
    ]
});







var usageInquiry = Ext.create('Ext.Window', {
    id:'usageInquiry',
    title: '使用情况查询（以D视图为主）',
    width: 820,
    height: 340,
    autoHeight : true,
    closeAction: 'hide',
    //closable:false,
    constrain: true,
    modal:true,
    items:[usageInquiryGrid],
});
// ================================================使用情况查询页面结束================================================================================

// ================================================该品牌已供应的其他物料页面开始================================================================================
Ext.define('otherMaterialsSuppliedModel', {
    extend: 'Ext.data.Model',
    fields: [
        'partNumber','partDescribe','partState'
    ],
    idProperty: 'otherMaterialsSuppliedModel'
});

var otherMaterialsSuppliedStore = Ext.create('Ext.data.Store', {
    model: 'otherMaterialsSuppliedModel',
    id: 'otherMaterialsSuppliedStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirmation/queryBrandInfo?docNumber='+docNumber,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'otherMaterialsSuppliedModel',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

var otherMaterialsSuppliedColumns = [
    {text: '物料编号', dataIndex: 'partNumber', flex: 1,menuDisabled: true, editor: false,},
    {text: '物料描述', dataIndex: 'partDescribe',flex: 1, editor: false , menuDisabled: true},
    {text: '状态', dataIndex: 'partState', flex: 1,menuDisabled: true, editor: false}
];

var otherMaterialsSuppliedGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var otherMaterialsSuppliedGrid = Ext.create('Ext.grid.Panel', {
    plugins: [otherMaterialsSuppliedGridEditing],
    store: otherMaterialsSuppliedStore,
    columns: otherMaterialsSuppliedColumns,
    id:'otherMaterialsSuppliedGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    // selType: 'checkboxmodel',
});


var otherMaterialsSupplied = Ext.create('Ext.Window', {
    id:'otherMaterialsSupplied',
    title: '该品牌已供应的其他物料',
    width: 700,
    height: 340,
    autoHeight : true,
    closeAction: 'hide',
    //closable:false,
    constrain: true,
    modal:true,
    items:[otherMaterialsSuppliedGrid],
});
// ================================================该品牌已供应的其他物料页面结束================================================================================

//上传图片窗口
var uploadImageWindow = Ext.create('Ext.Window', {
    title: '导入图片',
    width: 550,
    height: 350,
    //autoHeight : true,
    //autoWidth : true,
    closeAction: 'hide',
    id: 'uploadImageWindow',
    autoScroll: false,
    //closable:false,
    constrain: true,
    layout: 'fit',
    modal: true,
    items: {
        xtype: 'uploadFilePanel'
    }
});

var showColumns = [
    {text: '文档名称', dataIndex: 'fileName', flex: 1, menuDisabled: true, editor: false}
];



var showStore = Ext.create('Ext.data.Store', {
    fields: ['fileName'],
    id: 'showStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirmation/searchFileName',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            messageProperty: 'message'
        }
    }),
    autoLoad:false,
});



var showGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var showGrid = Ext.create('Ext.grid.Panel', {
    plugins: [showGridEditing],
    store: showStore,
    columns: showColumns,
    id:'showGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    viewConfig: {
        enableTextSelection: true
    },
    selModel: {
        type: "checkboxmodel",
        mode: 'SINGLE'//单选
        // mode: 'MULTI'//多选
    },
    tbar: [
        {
            xtype: 'button',
            text: '下载文件',
            id: 'showInsert',
            iconCls: 'icon icon-download',
            handler: function () {
                var recordList = showGrid.getSelectionModel().getSelection();
                if (recordList.length != 0) {
                    var fileName = recordList[0].data.fileName;
                    fileName = urlStr2Ascii(fileName);
                    window.location.href = '/Windchill/ptc1/sampleConfirmation/downLoadDoc?fileName='+fileName+'&branchId='+branchId;
                } else {
                    alert("请选择一条数据")
                }
            }
        },
        {
            xtype: 'button',
            text: '删除文件',
            id: 'showDelete',
            // hidden:showDeleteValue?true:false,
            iconCls: 'icon icon-delete',
            handler: function () {
                if(showDeleteValue){
                    alert("当前节点不允许删除该文件！");
                    return;
                }
                var recordList = showGrid.getSelectionModel().getSelection();
                if (recordList.length != 0) {
                    var fileName = recordList[0].data.fileName;
                    fileName = urlStr2Ascii(fileName);
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/sampleConfirmation/deleteFiles?fileName='+fileName+'&branchId='+branchId+
                            '&fileColumnId='+fileColumnId+'&fileColumnName='+fileColumnName+'&uploadTableName='+uploadTableName,
                        method:'POST',
                        headers: {'Content-Type':'application/json'},
                        // params: JSON.stringify(record.data),
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            alert(obj.msg)
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            //刷新表格内的数据
                            var uploadFormPannel = Ext.getCmp(gridName);
                            // 获取关联的 Store
                            var store = uploadFormPannel.getStore();
                            // 更新 Store 中的数据
                            store.load();
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                } else {
                    alert("请选择一条数据")
                }
            }
        },
        {
            xtype: 'button',
            text: '下载全部文件',
            id: 'downloadAllFile',
            iconCls: 'icon icon-download',
            handler: function () {
                var store = showGrid.getStore(); // 获取Grid的数据源
                var allData = store.getData().items; // 获取数据源中的所有数据
                var concatenatedData = '';

                if(allData){
                    for(let i = 0;i < allData.length; i++){
                        let rowData = allData[i].data;
                        if(i==0){
                            concatenatedData = rowData['fileName']
                        }else {
                            concatenatedData += ";;;qqq" + rowData['fileName'];
                        }
                    }
                }

                if (concatenatedData.length != 0) {
                    //     window.location.href = '/Windchill/ptc1/technicalChange/downLoadAllDoc?fileName='+concatenatedData+'&branchId='+branchId;
                    // 创建一个 form 表单
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '/Windchill/ptc1/sampleConfirmation/downLoadAllDoc';

                    // 创建一个 input 元素用于存放参数
                    var fileNameInput = document.createElement('input');
                    fileNameInput.type = 'hidden';
                    fileNameInput.name = 'fileName';
                    fileNameInput.value = concatenatedData;
                    form.appendChild(fileNameInput);

                    var branchIdInput = document.createElement('input');
                    branchIdInput.type = 'hidden';
                    branchIdInput.name = 'branchId';
                    branchIdInput.value = branchId;
                    form.appendChild(branchIdInput);
                    // 将表单添加到页面中
                    document.body.appendChild(form);
                    // 提交表单
                    form.submit();

                } else {
                    alert("当前没有可以下载的文件！")
                }
            }
        }
        ]
    // 其他配置项...
});

var showFile = Ext.create('Ext.Window', {
    id:'show1',
    title: '文档操作',
    width: 700,
    //height: 300,
    autoHeight : true,
    closeAction: 'hide',
    //closable:false,
    constrain: true,
    modal:true,
    items:[showGrid],
});



















