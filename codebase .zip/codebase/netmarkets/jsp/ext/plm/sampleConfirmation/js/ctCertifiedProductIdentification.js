
// ========================================S02认证产品一致性识别=================================================================================
Ext.define('certifiedProductIdentificationModel', {
    extend: 'Ext.data.Model',
    fields: [
        'id', 'parentNumber','partDescribe','productType','finishedProductList','relatedPDT','pDTManager','whetherSubmission','illustrate'
    ],
    idProperty: 'id'
});

var certifiedProductIdentificationStore = Ext.create('Ext.data.Store', {
    model: 'certifiedProductIdentificationModel',
    id: 'certifiedProductIdentificationStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtProductIdentification?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

//物料编码
var partNumberCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'partNumberCombo',
    id: 'partNumberCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['partNumber']
    },
    valueField: 'partNumber',
    displayField: 'partNumber'
});



//相关PDT
var pdtCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'pdtCombo',
    id: 'pdtCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['relatedPDT']
    },
    valueField: 'relatedPDT',
    displayField: 'relatedPDT'
});

//PDT经理
// let pdtPersonLiableStore = new Ext.data.ArrayStore({
//     id: 'pdtPersonLiableStore',
//     fields: [
//         {name:"name"},
//         {name: "fullName"}
//     ],
//     pruneModifiedRecords: true,
//     proxy: {
//         type: 'ajax',
//         url: '/Windchill/ptc1/personLiableList',
//         reader: {
//             type: 'json',
//             rootProperty: 'data'
//         }
//     },
//     autoLoad: false
// });


let pdtPersonLiableStore = new Ext.data.ArrayStore({
    id: 'pdtPersonLiableStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/sampleConfirmation/searchPersonResponsible?branchId='+branchId+'&roleNames=A001PDT经理',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});







//
let whetherSubmissionStore = [['是', '是'], ['否', '否']];

var certifiedProductIdentificationColumns = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {
        text: setMust('物料编号',isEditable(improve_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)),
        dataIndex: 'partNumber',
        flex: 1,
        editAccess: true,
        menuDisabled: true,
        editor: isEditable(improve_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)?partNumberCombo:false
    },
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
    {text: setMust('产品型号',isEditable(improve_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'productType',
        flex: 1,menuDisabled: true, editor: isEditable(improve_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)?true:false,},
    {text: '成品清单',xtype:'actioncolumn', dataIndex: 'finishedProductList', flex: 1,menuDisabled: true, editor: false,

        items: ['->',{
            iconCls: 'icon-showInfo',
            tooltip: '成品清单',
            handler: function(grid, rowIndex, colIndex) {
                var record = grid.getStore().getAt(rowIndex);
                var productType = record.get('productType');
                Ext.getStore('finishedProductListStore').reload({
                    params: {
                        productType:productType
                    }
                });
                // usageInquiryStore.load();
                finishedProductList.show();
            },
            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                // var boolean = record.data.usageInquiry;
                // if(boolean!=null) {
                    return false;
                // }
                // return true;
            }
        },'->']

    },
    {
        text: setMust('相关PDT',isEditable(improve_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)),
        dataIndex: 'relatedPDT',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor:isEditable(improve_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)?pdtCombo:false
    },
    {
        text: setMust('PDT经理',isEditable(improve_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)),
        dataIndex: 'pDTManager',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(improve_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)?{
            xtype: 'combo',
            editable: true,
            multiSelect: false,
            anyMatch: true,
            store: pdtPersonLiableStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        }:false
    },
    {
        text: setMust('是否同意送检',isEditable(confirm_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)),
        dataIndex: 'whetherSubmission',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(confirm_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)?{
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: whetherSubmissionStore,
        }:false
    },
    {text: setRequired('说明',isEditable(confirm_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'illustrate',
        flex: 1,menuDisabled: true, editor: isEditable(confirm_inspection_requirements,initiator_confirms_integrated,system_administrator_confirms_integrated)?true:false,},
];

var certifiedProductIdentificationGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var certifiedProductIdentificationGrid = Ext.create('Ext.grid.Panel', {
    plugins: [certifiedProductIdentificationGridEditing],
    store: certifiedProductIdentificationStore,
    columns: certifiedProductIdentificationColumns,
    id:'certifiedProductIdentificationGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    tbar: [
        {
            xtype: 'button',
            text: '新增行',
            id: 'certifiedProductIdentificationInsert',
            iconCls: 'icon icon-add',
            hidden:isEditable(improve_inspection_requirements,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
            handler: function () {
                let callbackFn = function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        certifiedProductIdentificationStore.load();
                    }else {
                        alert(obj.message);
                    }
                };
                insertData('ZProductIdentificationTable', branchId, callbackFn);
            }
        },
        {
            xtype: 'button',
            text: '删除行',
            id: 'certifiedProductIdentificationDelete',
            iconCls: 'icon icon-delete',
            hidden:isEditable(improve_inspection_requirements,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
            handler: function () {
                let selected = certifiedProductIdentificationGrid.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    let ids = '';
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            if(i == 0){
                                ids += id;
                            }else{
                                ids += ',' + id;
                            }
                        }
                    }
                    let callbackFn = function (response, opts) {
                        certifiedProductIdentificationGrid.getStore().remove(selected);
                        certifiedProductIdentificationGrid.view.refresh();
                    };
                    deleteData('ZProductIdentificationTable', ids, callbackFn);
                }
            }
        },
        {
            xtype: 'button',
            text: '导入（B）',
            id: 'certifiedProductIdentificationImport',
            iconCls : 'icon icon-store-export',
            hidden:isEditable(improve_inspection_requirements,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
            handler: function () {
                importCertifiedProducts();
            }
        },
        {
            xtype: 'button',
            text: '下载模板',
            iconCls : 'icon icon-store-export',
            scope: this,
            hidden:false,
            handler : function(){
                window.location.href = '/Windchill/template/认证产品一致性识别导入模板.xlsx', '', 'width=300,height=200';
            }
        }
    ]
});



certifiedProductIdentificationGrid.on('edit',function(editor, e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            certifiedProductIdentificationStore.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZProductIdentificationTable", id, field, value, callbackFn);
});

certifiedProductIdentificationGrid.on('rowclick', function (view, record, item, index, e) {
    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];
    if (column) {
        var columnName = column.dataIndex;
        if (columnName == 'relatedPDT') {
            let id = record.get('id');
            pdtCombo.getStore().removeAll();
            Ext.Ajax.request({
                url: '/Windchill/ptc1/sampleConfirmation/getRelatedPDTList?branchId=' + branchId + "&id=" + id,
                method: 'GET',
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == 'success') {
                        let pdtList = Ext.decode(response.responseText).data;
                        if(pdtList){
                            pdtList.map(function (item) {
                                pdtCombo.getStore().add({relatedPDT: item});
                            })
                        }
                    } else {
                        alert(obj.message)
                    }
                },
                failure: function (response, opts) {
                    alert('错误：删除信息失败，请检查网络！!');
                }
            });
        }

        if (columnName == 'partNumber') {
            partNumberCombo.getStore().removeAll();
            Ext.Ajax.request({
                url: '/Windchill/ptc1/sampleConfirmation/getPartNumberList?branchId='+branchId,
                method: 'GET',
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == 'success') {
                        let partNumberList = Ext.decode(response.responseText).data;
                        if(partNumberList){
                            partNumberList.map(function (item) {
                                partNumberCombo.getStore().add({partNumber: item.partNumber});
                            })
                        }
                    } else {
                        alert(obj.message)
                    }
                },
                failure: function (response, opts) {
                    alert('错误：删除信息失败，请检查网络！!');
                }
            });
        }
    }
});




Ext.define('finishedProductListModel', {
    extend: 'Ext.data.Model',
    fields: [
        'partNumber','partDescribe','partState'
    ],
    idProperty: 'finishedProductListModel'
});

var finishedProductListStore = Ext.create('Ext.data.Store', {
    model: 'finishedProductListModel',
    id: 'finishedProductListStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirmation/queryFinishedProductList',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'finishedProductListModel',
            messageProperty: 'message'
        }
    }),
    autoLoad:false,
});

var finishedProductListColumns = [
    {text: '物料编号', dataIndex: 'partNumber', flex: 1,menuDisabled: true, editor: false,},
    {text: '物料描述', dataIndex: 'partDescribe',flex: 1, editor: false , menuDisabled: true},
    {text: '状态', dataIndex: 'partState', flex: 1,menuDisabled: true, editor: false}
];

var finishedProductListGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var finishedProductListGrid = Ext.create('Ext.grid.Panel', {
    plugins: [finishedProductListGridEditing],
    store: finishedProductListStore,
    columns: finishedProductListColumns,
    id:'finishedProductListGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    // selType: 'checkboxmodel',
});


var finishedProductList = Ext.create('Ext.Window', {
    id:'finishedProductList',
    title: '成品清单',
    width: 700,
    //height: 300,
    autoHeight : true,
    closeAction: 'hide',
    //closable:false,
    constrain: true,
    modal:true,
    items:[finishedProductListGrid],
});








var certifiedProductIdentification  = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S02：认证产品一致性识别(认证工程师判断有一致性风险的物料进行添加)',
    padding:'5',
    collapsed:openPanel(improve_inspection_requirements,confirm_inspection_requirements,system_administrator_confirms_integrated,initiator_confirms_integrated),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    width: '100%',
    anchor:'100%',
    defaults: {
        labelWidth: 80,
        border: false
    },
    items:[
        certifiedProductIdentificationGrid
    ]
});