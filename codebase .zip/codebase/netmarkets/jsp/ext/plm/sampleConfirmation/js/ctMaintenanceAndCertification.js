
// ========================================S10：采购份额维护及认证跟进=================================================================================

var procurementMaintenance = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'procurementMaintenanceCombo',
    id: 'procurementMaintenanceCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '是' },
            { fullName: '否' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});



Ext.define('maintenanceAndCertificationModel', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','sampleConfirmationProgress',
        'procurementMaintenance'
    ],
    idProperty: 'id'
});

var maintenanceAndCertificationStore = Ext.create('Ext.data.Store', {
    model: 'maintenanceAndCertificationModel',
    id: 'maintenanceAndCertificationStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtFollowUpBo?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

var maintenanceAndCertificationColumns = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: false, menuDisabled: true,
    },
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
    {text: '样品确认进展', dataIndex: 'sampleConfirmationProgress', flex: 1, editor: false , menuDisabled: true},
    {text: setMust('采购份额维护是否已完成',isEditable(procurement_sourcing_allocation_share)), dataIndex: 'procurementMaintenance', flex: 1, editor: isEditable(procurement_sourcing_allocation_share)?procurementMaintenance:false , menuDisabled: true}
];

var maintenanceAndCertificationGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var maintenanceAndCertificationGrid = Ext.create('Ext.grid.Panel', {
    plugins: [maintenanceAndCertificationGridEditing],
    store: maintenanceAndCertificationStore,
    columns: maintenanceAndCertificationColumns,
    id:'maintenanceAndCertificationGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    // selType: 'checkboxmodel',
    // tbar: [
    //     {
    //         xtype: 'button',
    //         text: '新增行',
    //         id: 'maintenanceAndCertificationInsert',
    //         iconCls: 'icon icon-add',
    //         handler: function () {
    //             let callbackFn = function (response, opts) {
    //                 var obj = Ext.decode(response.responseText);
    //                 if(obj.message=='success') {
    //                     maintenanceAndCertificationStore.load();
    //                 }else {
    //                     alert(obj.message);
    //                 }
    //             };
    //             insertData('ZFollowUpTable', branchId, callbackFn);
    //         }
    //     },
    //     {
    //         xtype: 'button',
    //         text: '删除行',
    //         id: 'maintenanceAndCertificationDelete',
    //         iconCls: 'icon icon-delete',
    //         handler: function () {
    //             let selected = maintenanceAndCertificationGrid.getSelectionModel().getSelection();
    //             if (selected.length === 0) {
    //                 alert('请选择数据！');
    //             } else {
    //                 let ids = '';
    //                 for (let i = 0; i < selected.length; i++) {
    //                     let id = selected[i].get('id');
    //                     if (id) {
    //                         if(i == 0){
    //                             ids += id;
    //                         }else{
    //                             ids += ',' + id;
    //                         }
    //                     }
    //                 }
    //                 let callbackFn = function (response, opts) {
    //                     maintenanceAndCertificationGrid.getStore().remove(selected);
    //                     maintenanceAndCertificationGrid.view.refresh();
    //                 };
    //                 deleteData('ZFollowUpTable', ids, callbackFn);
    //             }
    //         }
    //     }
    // ]
});

maintenanceAndCertificationGrid.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            maintenanceAndCertificationStore.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZFollowUpTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
maintenanceAndCertificationGrid.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});

//根据特定字段的值判断是否禁止编辑
maintenanceAndCertificationGrid.on('beforeedit', function (editor, context) {
    var record = context.record;
    var sampleConfirmationProgress = record.get('sampleConfirmationProgress');
    if(sampleConfirmationProgress === "确认终止"){
        return false; // 禁止编辑
    }
    return true; // 允许编辑操作
});


var maintenanceAndCertification  = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S08：采购份额维护及认证跟进',
    padding:'5',
    collapsed:openPanel(procurement_sourcing_allocation_share),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    width: '100%',
    anchor:'100%',
    defaults: {
        labelWidth: 80,
        border: false
    },
    items:[
        maintenanceAndCertificationGrid
    ]
});