
// ========================================S04：TQC上传报告=================================================================================
Ext.define('TQCUploadReportModel', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','sampleConfirmationProgress',
        'unitTesting','onBoardTesting','serviceabilityTesting','completeMachineTesting','uploadReport',
        'picture','fAIReport',
        'tQCOpinion','explain'
    ],
    idProperty: 'TQCUploadReportModel'
});

var TQCUploadReportStore = Ext.create('Ext.data.Store', {
    model: 'TQCUploadReportModel',
    id: 'TQCUploadReportStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtTQCReportBo?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

let unitTestingStore = [['是', '是'], ['否', '否']];

let onBoardTestingStore = [['是', '是'], ['否', '否']];

let serviceabilityStore = [['是', '是'], ['否', '否']];

let completeMachineStore = [['是', '是'], ['否', '否']];

let tQCOpinionStore = [['通过', '通过'], ['不通过', '不通过']];

let pdtManagerOpinion= [['通过', '通过'], ['不通过', '不通过']];

let managementDepartmentOpinion= [['通过', '通过'], ['不通过', '不通过']];

let cpmtDirectorOpinion = [['通过', '通过'], ['不通过', '不通过']];


var TQCUploadReportColumns = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: false, menuDisabled: true},
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false},
    {text: '样品确认进展', dataIndex: 'sampleConfirmationProgress', flex: 1, editor: false , menuDisabled: true},
    {
        text: '上传报告并确认报告涵盖测试项目',menuDisabled: true, flex: 4,
        columns: [
            {
                text: setRequired('单体测试',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
                dataIndex: 'unitTesting',
                flex: 1,
                menuDisabled: true,
                editAccess: true,
                editor:  isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?{
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: unitTestingStore
                }:false
            },
            {
                text: setRequired('上板测试',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
                dataIndex: 'onBoardTesting',
                flex: 1,
                menuDisabled: true,
                editAccess: true,
                editor:  isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?{
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: onBoardTestingStore
                }:false
            },
            {
                text: setRequired('适用性测试',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
                dataIndex: 'serviceabilityTesting',
                flex: 1,
                menuDisabled: true,
                editAccess: true,
                editor: isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?{
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: serviceabilityStore
                }:false
            },
            {
                text: setRequired('整机测试',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
                dataIndex: 'completeMachineTesting',
                flex: 1,
                menuDisabled: true,
                editAccess: true,
                editor:  isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?{
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: completeMachineStore
                }:false
            },
            {
                text: setRequired('上传测试报告',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
                dataIndex: 'uploadReport',
                width: 100,
                editAccess: true,
                menuDisabled: true,
                xtype:'actioncolumn',
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                            ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'uploadReport';
                            uploadTableName = 'ZTQCReportTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'TQCUploadReportGrid';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.uploadReport;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'uploadReport';
                            uploadTableName = 'ZTQCReportTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'TQCUploadReportGrid';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                                ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.uploadReport;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
        ]
    },
    {
        text: setRequired('FAI报告（终版）',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
            ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
        dataIndex: 'faiReport',
        flex: 1,
        editAccess: true,
        menuDisabled: true,
        xtype:'actioncolumn',
        items: [
            '->',
            {
                iconCls: 'icon icon-uploadImage',
                tooltip: '添加文件',
                hidden:isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?false:true,
                handler: function(grid, rowIndex, colIndex) {
                    var record = grid.getStore().getAt(rowIndex);
                    //设置当前列的id与列名和表名
                    fileColumnId = record.get('id');
                    fileColumnName = 'faiReport';
                    uploadTableName = 'ZTQCReportTable';
                    //设置grid名称用于上传文件后刷新数据
                    gridName = 'TQCUploadReportGrid';

                    uploadImageWindow.show();
                },
                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                    var boolean = record.data.faiReport;
                    if(boolean!=null) {
                        return true;
                    }
                    return false;
                }
            },
            '-',
            {
                iconCls: 'icon-showInfo',
                tooltip: '查看文件',
                handler: function(grid, rowIndex, colIndex) {
                    var record = grid.getStore().getAt(rowIndex);
                    //设置当前列的id与列名和表名
                    fileColumnId = record.get('id');
                    fileColumnName = 'faiReport';
                    uploadTableName = 'ZTQCReportTable';
                    //设置grid名称用于上传文件后刷新数据
                    gridName = 'TQCUploadReportGrid';
                    // 刷新当前单元格内文件
                    showStore.load({
                        params: {
                            fileColumnId: fileColumnId,
                            fileColumnName: fileColumnName,
                            uploadTableName:uploadTableName
                        }
                    });
                    showDeleteValue = !isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                        ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation);
                    showFile.show();
                },
                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                    var boolean = record.data.faiReport;
                    if(boolean!=null) {
                        return false;
                    }
                    return true;
                }
            }
        ]
    },
    // {
        // text: '其他资料',menuDisabled: true,
        // columns: [
            {
                text: setMust('图片（终版）',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                    ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
                dataIndex: 'picture',
                flex: 1,
                editAccess: true,
                menuDisabled: true,
                xtype:'actioncolumn',
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                            ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'picture';
                            uploadTableName = 'ZTQCReportTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'TQCUploadReportGrid';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.picture;
                            if(boolean!=null) {
                                return true;
                            }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'picture';
                            uploadTableName = 'ZTQCReportTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'TQCUploadReportGrid';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showDeleteValue = !isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
                                ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation);
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data.picture;
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
    //     ]
    // },
    {
        text: setRequired('说明',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
            ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
        dataIndex: 'explain',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
            ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?true:false
    },
    {
        text: setMust('审批人意见',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
            ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)),
        dataIndex: 'tQCOpinion',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
            ,flow_path_sample_comments,sample_preliminary_comments,finish_product_preliminary_confirmation)?{
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: tQCOpinionStore
        }:false
    },
    {
    text: '配套成品相关',menuDisabled: true,flex: 3,
    columns: [
        // {
        //     text: setRequired('PDT经理意见',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,
        //         initiator_confirms_integrated,opinion_and_sealed_sample)),
        //     dataIndex: 'pdtManagerOpinion',
        //     flex: 1,
        //     menuDisabled: true,
        //     editAccess: true,
        //     editor: isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated
        //     ,opinion_and_sealed_sample)?{
        //         xtype: 'combobox',
        //         editable: false,
        //         forceSelection: false,
        //         store: pdtManagerOpinion
        //     }:false
        // },
        {
            text: setMust('产品管理部意见',isEditable(finish_product_opinion)),
            dataIndex: 'managementDepartmentOpinion',
            flex: 1,
            menuDisabled: true,
            editAccess: true,
            editor: isEditable(finish_product_opinion)?{
                xtype: 'combobox',
                editable: false,
                forceSelection: false,
                store: managementDepartmentOpinion
            }:false
        },
        {
            text: setMust('CPMT主任意见',isEditable(opinion_CPMT)),
            dataIndex: 'cpmtDirectorOpinion',
            flex: 1,
            menuDisabled: true,
            editAccess: true,
            editor: isEditable(opinion_CPMT)?{
                xtype: 'combobox',
                editable: false,
                forceSelection: false,
                store: cpmtDirectorOpinion
            }:false
        },
    ]
    },
    {
        text: setRequired('综合意见',isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated)),
        dataIndex: 'comprehensiveOpinions',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor:false
        // editor: isEditable(tqc_confirms_sample_comments,system_administrator_confirms_integrated,initiator_confirms_integrated)?true:false
    },

];

var TQCUploadReportGridEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var TQCUploadReportGrid = Ext.create('Ext.grid.Panel', {
    plugins: [TQCUploadReportGridEditing],
    store: TQCUploadReportStore,
    columns: TQCUploadReportColumns,
    id:'TQCUploadReportGrid',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    // tbar: [
    //     {
    //         xtype: 'button',
    //         text: '新增行',
    //         id: 'TQCUploadReportInsert',
    //         iconCls: 'icon icon-add',
    //         handler: function () {
    //             let callbackFn = function (response, opts) {
    //                 var obj = Ext.decode(response.responseText);
    //                 if(obj.message=='success') {
    //                     TQCUploadReportStore.load();
    //                 }else {
    //                     alert(obj.message);
    //                 }
    //             };
    //             insertData('ZTQCReportTable', branchId, callbackFn);
    //         }
    //     },
    //     {
    //         xtype: 'button',
    //         text: '删除行',
    //         id: 'TQCUploadReportDelete',
    //         iconCls: 'icon icon-delete',
    //         handler: function () {
    //             let selected = TQCUploadReportGrid.getSelectionModel().getSelection();
    //             if (selected.length === 0) {
    //                 alert('请选择数据！');
    //             } else {
    //                 let ids = '';
    //                 for (let i = 0; i < selected.length; i++) {
    //                     let id = selected[i].get('id');
    //                     if (id) {
    //                         if(i == 0){
    //                             ids += id;
    //                         }else{
    //                             ids += ',' + id;
    //                         }
    //                     }
    //                 }
    //                 let callbackFn = function (response, opts) {
    //                     TQCUploadReportGrid.getStore().remove(selected);
    //                     TQCUploadReportGrid.view.refresh();
    //                 };
    //                 deleteData('ZTQCReportTable', ids, callbackFn);
    //             }
    //         }
    //     }
    // ]
});

TQCUploadReportGrid.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            TQCUploadReportStore.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZTQCReportTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
TQCUploadReportGrid.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});

//根据特定字段的值判断是否禁止编辑
TQCUploadReportGrid.on('beforeedit', function (editor, context) {
    var record = context.record;
    var sampleConfirmationProgress = record.get('sampleConfirmationProgress');
    if(sampleConfirmationProgress === "确认终止"){
        return false; // 禁止编辑
    }
    return true; // 允许编辑操作
});


var TQCUploadReport  = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S04：上传报告',
    padding:'5',
    collapsed:openPanel(tqc_confirms_sample_comments,system_administrator_confirms_integrated,
        initiator_confirms_integrated,flow_path_sample_comments,sample_preliminary_comments
        ,finish_product_preliminary_confirmation,opinion_and_sealed_sample,finish_product_opinion,opinion_CPMT),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    width: '100%',
    anchor:'100%',
    defaults: {
        labelWidth: 80,
        border: false
    },
    items:[
        TQCUploadReportGrid
    ]
});