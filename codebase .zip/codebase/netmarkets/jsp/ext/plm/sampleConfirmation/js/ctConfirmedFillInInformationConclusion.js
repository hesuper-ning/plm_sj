
// =========================================S05：样品确认人填写相关信息和综合结论 01开始===================================================
Ext.define('trialProductionAndUseResultModel01', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','trialProcessNumber','combinationNumber','semiFinishedProductNumber',
        'semiFinishedProductDescribe','finishedProductNumber','finishedProductDescription','internalVersion',
        'supplierCodeAndName','trialQuantity','trialNumberOfTimes','trialStatus'
    ],
    idProperty: 'id'
});

var trialProductionAndUseResultStore01 = Ext.create('Ext.data.Store', {
    model: 'trialProductionAndUseResultModel01',
    id: 'trialProductionAndUseResultStore01',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtResultConfirmationBo?branchId='+branchId+'&isEdit='+isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
            confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated,
            opinion_of_iqc_supervisor,trial_probation_comprehensive_conclusion,tqc_sealingSample,iqc_storageValidityPeriod,confirmation_of_trial_production),
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

var trialProductionAndUseResultColumns01 = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: false, menuDisabled: true,},
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
    {
        text: '试用流程编号', dataIndex: 'trialProcessNumber', flex: 1, editor: false , menuDisabled: true,
        renderer: function(value,metaData,record,row,col,store){
            if(value)
                metaData.tdAttr = 'data-qtip="' + value +'"';
            if(record.get('trialProcessUrl')) {
                var changeLink = record.get('trialProcessUrl');
                return changeLink;
            }else {
                return value;
            }
        }
    },
    {text: '组合编号', dataIndex: 'combinationNumber', flex: 1, editor: false , menuDisabled: true},
    {text: '半成品编号', dataIndex: 'semiFinishedProductNumber', flex: 1, editor: false, menuDisabled: true},
    {text: '半成品描述', dataIndex: 'semiFinishedProductDescribe', flex: 1, editor: false, menuDisabled: true},
    {text: '成品编号', dataIndex: 'finishedProductNumber', flex: 1, editor: false, menuDisabled: true},
    {text: '成品描述', dataIndex: 'finishedProductDescription', flex: 1, editor: false, menuDisabled: true},
    {text: '内部版本', dataIndex: 'internalVersion', flex: 1, editor: false, menuDisabled: true},
    {text: '供应商编码_名称', dataIndex: 'supplierCodeAndName', flex: 1, editor: false, menuDisabled: true},
    {text: '试用数量', dataIndex: 'trialQuantity', flex: 1, editor: false, menuDisabled: true},
    {text: '试用次数', dataIndex: 'trialNumberOfTimes', flex: 1, editor: false, menuDisabled: true},
    {text: '试用状态', dataIndex: 'trialStatus', flex: 1, editor: false, menuDisabled: true}
];

var trialProductionAndUseResultGridEditing01 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var trialProductionAndUseResultGrid01 = Ext.create('Ext.grid.Panel', {
    plugins: [trialProductionAndUseResultGridEditing01],
    store: trialProductionAndUseResultStore01,
    columns: trialProductionAndUseResultColumns01,
    id:'trialProductionAndUseResultGrid01',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    viewConfig: {
        enableTextSelection: true
    },
    tbar: [

    ]
});

trialProductionAndUseResultGrid01.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            trialProductionAndUseResultStore01.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZResultConfirmationTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
trialProductionAndUseResultGrid01.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});

// =========================================S05：样品确认人填写相关信息和综合结论 01结束===================================================

// =========================================S05：样品确认人填写相关信息和综合结论 02开始===================================================
var materialConclusion = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'materialConclusionCombo',
    id: 'materialConclusionCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '合格' },
            { fullName: '不合格' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

var unit = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'unitCombo',
    id: 'unitCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '年' },
            { fullName: '月' },
            { fullName: '周' },
            { fullName: '天' },
            { fullName: '小时' },
            { fullName: '分钟' },
            { fullName: '秒' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

var whetherSealedSample = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'whetherSealedSampleCombo',
    id: 'whetherSealedSampleCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '是' },
            { fullName: '否' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});

var isTheSampleSealingCompleted = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'isTheSampleSealingCompletedCombo',
    id: 'isTheSampleSealingCompletedCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '已完成' },
            { fullName: '未完成' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});



var theSealedSampleBeenReceived = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'theSealedSampleBeenReceivedCombo',
    id: 'theSealedSampleBeenReceivedCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '' },
            { fullName: '已收到' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName',
    tpl: getXTemplate('fullName')
});


var haveYouPassedTheTrial = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'haveYouPassedTheTrialCombo',
    id: 'haveYouPassedTheTrialCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '通过' },
            { fullName: '不通过' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var trialProductionConclusion = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'trialProductionConclusionCombo',
    id: 'trialProductionConclusionCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '通过' },
            { fullName: '不通过' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


var comprehensiveOpinions = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'comprehensiveOpinionsCombo',
    id: 'comprehensiveOpinionsCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
            { fullName: '合格' },
            { fullName: '不合格' }
        ],
        fields: ['fullName']
    },
    valueField: 'fullName',
    displayField: 'fullName'
});


Ext.define('trialProductionAndUseResultModel02', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','sampleConfirmationProgress','materialConclusion',
        'whetherSealedSample','numberOfSealedSamples','sealingDepartment','sealingSampleNumber',
        'isTheSampleSealingCompleted','theSealedSampleBeenReceived','storageValidityPeriod',
        'reasonForSampleDelivery','whetherOnTrial','trialModel','haveYouPassedTheTrial','illustrate',
        'needTrialProduction','trialProductionReportNumber','trialProductionConclusion','comprehensiveOpinions'
    ],
    idProperty: 'id'
});

var trialProductionAndUseResultStore02 = Ext.create('Ext.data.Store', {
    model: 'trialProductionAndUseResultModel02',
    id: 'trialProductionAndUseResultStore02',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getConfirmedFillInInformationConclusion?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

let overallConclusionStore = [['通过', '通过'], ['不通过', '不通过']];

let trialConclusionStore = [['通过', '通过'], ['不通过', '不通过']];

let whetherOnTrialStore = [
    ['是', '是'],['否', '否']
]

let needTrialProductionStore = [
    ['是', '是'],['否', '否']
]

let trialModelStore = [
    ['不限', '不限']
]

var trialProductionAndUseResultColumns02 = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', width: 100, editor: false, menuDisabled: true,
    },
    {text: '物料描述', dataIndex: 'partDescribe', width: 80,menuDisabled: true, editor: false,},
    {text: '样品确认进展', dataIndex: 'sampleConfirmationProgress', width: 100, editor: false , menuDisabled: true},
    {text: setMust('物料结论',isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
            confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated
        ,flow_path_sealed_sample,opinion_and_sealed_sample)),
        dataIndex: 'materialConclusion', width: 80,
        editor:
            isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
            confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated
                ,flow_path_sealed_sample,opinion_and_sealed_sample)?
                materialConclusion
                :false
        , menuDisabled: true},
    {
        text: '封样要求',menuDisabled: true,
        columns: [
            {text: setMust('是否需要封样',isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
                    confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated
                    ,flow_path_sealed_sample,opinion_and_sealed_sample)), dataIndex: 'whetherSealedSample', width: 100,
                editor:
                    isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
                    confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated
                        ,flow_path_sealed_sample,opinion_and_sealed_sample)?
                        whetherSealedSample
                        :false
                , menuDisabled: true},
            {text: setRequired('封样数量',isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
                    confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated
                    ,flow_path_sealed_sample,opinion_and_sealed_sample)), dataIndex: 'numberOfSealedSamples', width: 100,
                editor:
                    isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
                    confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated
                        ,flow_path_sealed_sample,opinion_and_sealed_sample)
                , menuDisabled: true},
            {text: setRequired('留样部门',isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
                    confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated,flow_path_sealed_sample
                    ,opinion_and_sealed_sample)), dataIndex: 'sealingDepartment', width: 100,
                editor: isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
                    confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated,flow_path_sealed_sample
                    ,opinion_and_sealed_sample)?{
                    xtype: 'combo',
                    selectOnFocus: true,
                    valueField: 'sealingDepartment',
                    displayField: 'sealingDepartment',
                    // 设置只有两个选项的数据源
                    store: {data:[{sealingDepartment:''},{sealingDepartment:'质控'},{sealingDepartment:'质控+采购'}]},
                    tpl: getXTemplate('sealingDepartment')
                }:false,
                // editor: false,
                menuDisabled: true},
        ]
    },
    {
        text: '封样执行',menuDisabled: true,
        columns: [
            {text: '封样编号', dataIndex: 'sealingSampleNumber', width: 100, editor: false, menuDisabled: true},
            {text: setMust('是否完成封样',isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated,tqc_sealingSample
                    ,flow_path_sealed_sample)), dataIndex: 'isTheSampleSealingCompleted', width: 100,
                editor:
                    isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated,tqc_sealingSample
                        ,flow_path_sealed_sample)?
                        isTheSampleSealingCompleted
                        :false
                , menuDisabled: true},
        ]
    },
    {
        text: '封样接收',menuDisabled: true,
        columns: [
            {text: setRequired('封样是否已收到',isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated,iqc_storageValidityPeriod)), dataIndex: 'theSealedSampleBeenReceived', width: 100,
                editor:
                    isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated,iqc_storageValidityPeriod)?
                        theSealedSampleBeenReceived
                        :false
                , menuDisabled: true},
        ]
    },
   /* {text: setMust('存储有效期（月）',isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated,iqc_storageValidityPeriod)), dataIndex: 'storageValidityPeriod', width: 100,
        editor:
            isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated,iqc_storageValidityPeriod)
        ,menuDisabled: true},*/
    // {text: setMust('存储有效期单位',isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'unit', width: 100,
    //     editor:unit
    //     // isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated)
    //     ,menuDisabled: true},
    {text: '送样原因', dataIndex: 'reasonForSampleDelivery', width: 100, editor: false , menuDisabled: true},
    {
        text: '试用要求',menuDisabled: true,
        columns: [
            {text: setRequired('是否需要试用',isEditable(confirm_sample_opinions_standard,confirm_sample_opinions)), dataIndex: 'whetherOnTrial', width: 100, editor:
                    isEditable(confirm_sample_opinions_standard,confirm_sample_opinions)?
                    {
                    xtype: 'combo',
                    editable: false,
                    forceSelection: false,
                    store: whetherOnTrialStore
                }:false
                , menuDisabled: true},
            {text: setRequired('试用成品',isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
                    confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated)),
                dataIndex: 'trialModel', width: 100,
                editor:
                    isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,
                    confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated)?
                        {
                            xtype: 'combo',
                            editable: true,
                            forceSelection: false,
                            store: trialModelStore
                        }:false
                , menuDisabled: true}
        ]
    },
    {
        text: '试用结论',menuDisabled: true,
        columns: [
            {text: setRequired('是否通过试用',isEditable(confirmation_of_trial_production,trial_probation_comprehensive_conclusion)), dataIndex: 'haveYouPassedTheTrial', width: 100, editor: isEditable(confirmation_of_trial_production,trial_probation_comprehensive_conclusion)?haveYouPassedTheTrial:false, menuDisabled: true},
            {text: setRequired('说明',isEditable(trial_probation_comprehensive_conclusion, initiator_confirms_integrated,system_administrator_confirms_integrated,confirmation_of_trial_production)),
                dataIndex: 'illustrate', width: 100,
                editor:
                    isEditable(trial_probation_comprehensive_conclusion,initiator_confirms_integrated,system_administrator_confirms_integrated,confirmation_of_trial_production)
                , menuDisabled: true}
        ]
    },
    {
        text: '试产结果',menuDisabled: true,
        columns: [
            {text: setRequired('是否需要试产',isEditable(confirm_sample_opinions_standard,confirm_sample_opinions)), dataIndex: 'needTrialProduction', width: 100, editor:
                    isEditable(confirm_sample_opinions_standard,confirm_sample_opinions)?{
                    xtype: 'combo',
                    editable: false,
                    forceSelection: false,
                    store: needTrialProductionStore
                }:false
                , menuDisabled: true},
            {text: setRequired('试产报告编号',isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated,confirmation_of_trial_production)), dataIndex: 'trialProductionReportNumber', width: 100,
                editor:
                    isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated,confirmation_of_trial_production)
                , menuDisabled: true},
            {text: setRequired('试产结论',isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated)), dataIndex: 'trialProductionConclusion', width: 100,
                editor:
                    isEditable(opinion_of_iqc_supervisor,initiator_confirms_integrated,system_administrator_confirms_integrated)?
                        trialProductionConclusion
                        :false
                        , menuDisabled: true}
        ]
    },
    {
        text: setMust('确认人综合意见',isEditable(trial_probation_comprehensive_conclusion,initiator_confirms_integrated,system_administrator_confirms_integrated)),
        dataIndex: 'comprehensiveOpinions',
        width: 120,
        menuDisabled: true,
        editAccess: true,
        editor:
            isEditable(trial_probation_comprehensive_conclusion,initiator_confirms_integrated,system_administrator_confirms_integrated)?
                comprehensiveOpinions
                :false

        //     isEditable(confirm_trial_node,system_administrator_confirms_integrated,initiator_confirms_integrated)?{
        //     xtype: 'combobox',
        //     editable: false,
        //     forceSelection: false,
        //     store: overallConclusionStore
        // }:false
    }
];

var trialProductionAndUseResultGridEditing02 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var trialProductionAndUseResultGrid02 = Ext.create('Ext.grid.Panel', {
    plugins: [trialProductionAndUseResultGridEditing02],
    store: trialProductionAndUseResultStore02,
    columns: trialProductionAndUseResultColumns02,
    id:'trialProductionAndUseResultGrid02',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    tbar: [

        // {
        //     xtype: 'button',
        //     text: '新增行',
        //     // hidden:isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
        //     id: 'trialProductionAndUseResultInsert02',
        //     iconCls: 'icon icon-add',
        //     handler: function () {
        //         let callbackFn = function (response, opts) {
        //             var obj = Ext.decode(response.responseText);
        //             if(obj.message=='success') {
        //                 trialProductionAndUseResultStore02.load();
        //             }else {
        //                 alert(obj.message);
        //             }
        //         };
        //         insertData('ZInformationAndConclusion', branchId, callbackFn);
        //     }
        // },
        // {
        //     xtype: 'button',
        //     text: '删除行',
        //     // hidden:isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
        //     id: 'trialProductionAndUseResultDelete02',
        //     iconCls: 'icon icon-delete',
        //     handler: function () {
        //         let selected = trialProductionAndUseResultGrid02.getSelectionModel().getSelection();
        //         if (selected.length === 0) {
        //             alert('请选择数据！');
        //         } else {
        //             let ids = '';
        //             for (let i = 0; i < selected.length; i++) {
        //                 let id = selected[i].get('id');
        //                 if (id) {
        //                     if(i == 0){
        //                         ids += id;
        //                     }else{
        //                         ids += ',' + id;
        //                     }
        //                 }
        //             }
        //             let callbackFn = function (response, opts) {
        //                 trialProductionAndUseResultGrid02.getStore().remove(selected);
        //                 trialProductionAndUseResultGrid02.view.refresh();
        //             };
        //             deleteData('ZInformationAndConclusion', ids, callbackFn);
        //         }
        //     }
        // },

        {
            xtype: 'button',
            text: '试用流程创建',
            hidden:isEditable(confirm_sample_opinions_standard,confirm_sample_opinions_supporting_facilities,sample_confirm_review,
                confirm_sample_opinions,confirmation_of_trial_production)?false:true,
            id: 'trialProductionAndUseResultExport01',
            iconCls : 'icon icon-store-export',
            handler: function () {
                let selected = trialProductionAndUseResultGrid02.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    Ext.Msg.alert('提示', '请选择数据！');
                } else {
                    let ids = '';
                    for (let i = 0; i < selected.length; i++) {
                        let partNumber = selected[i].get('partNumber');
                        let whetherOnTrial = selected[i].get('whetherOnTrial');
                        if('是' != whetherOnTrial){
                            Ext.Msg.alert('提示', '只能选择“是否需要试用”为“是”的数据');
                            return;
                        }
                        if (partNumber) {
                            if(i == 0){
                                ids += partNumber;
                            }else{
                                ids += ',' + partNumber;
                            }
                        }
                    }
                    let callbackFn = function (response, opts) {
                        trialProductionAndUseResultGrid01.getStore().load();
                        Ext.Msg.alert('提示', '创建试用单成功！');
                    };
                    createTrialProcess(ids, callbackFn);
                }
            }
        }
    ]
});

trialProductionAndUseResultGrid02.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            trialProductionAndUseResultStore02.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZInformationAndConclusion", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
trialProductionAndUseResultGrid02.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});

//根据特定字段的值判断是否禁止编辑
trialProductionAndUseResultGrid02.on('beforeedit', function (editor, context) {
    var record = context.record;
    var sampleConfirmationProgress = record.get('sampleConfirmationProgress');
    //物料结论
    var materialConclusion = record.get('materialConclusion');
    //是否需要试用
    var whetherOnTrial = record.get('whetherOnTrial');
    //是否需要试产
    var needTrialProduction = record.get('needTrialProduction');
    //送样原因
    var reasonForSampleDelivery = record.get('reasonForSampleDelivery');
    // 判断点击的是哪一列，列名
    var columnName = context.column.dataIndex;

    //新产品新物料,变更产生的新物料,替代料，pcn，其它，配套成品，辅料
    if(reasonForSampleDelivery){
        if("新产品新物料"===reasonForSampleDelivery){
            if(columnName === "whetherOnTrial"){
                return false;
            }
        }
        if(("替代料，pcn，其他，外购成品".indexOf(reasonForSampleDelivery))!=-1){
            if(columnName === "needTrialProduction"){
                return false;
            }
        }
    }

    if(whetherOnTrial){
        if(whetherOnTrial === "否" && (columnName ==="trialModel"||columnName ==="haveYouPassedTheTrial"||columnName ==="illustrate") ){
            return false;
        }
    } else {
        if(columnName ==="trialModel"||columnName ==="haveYouPassedTheTrial"||columnName ==="illustrate"){
            return false;
        }
    }
    if(needTrialProduction){
        if(needTrialProduction === "否" &&(columnName ==="trialProductionReportNumber"||columnName ==="trialProductionConclusion")){
            return false;
        }
    } else {
        if(columnName ==="trialProductionReportNumber"||columnName ==="trialProductionConclusion"){
            return false;
        }
    }
    if(materialConclusion){
        if(materialConclusion === "不合格" &&(columnName ==="whetherSealedSample"||columnName ==="numberOfSealedSamples"||columnName ==="sealingDepartment"
            ||columnName ==="sealingSampleNumber"||columnName ==="isTheSampleSealingCompleted"||columnName ==="theSealedSampleBeenReceived"
            ||columnName ==="storageValidityPeriod"||columnName==="unit"||columnName==="whetherOnTrial"||columnName==="needTrialProduction"
        ||columnName==="comprehensiveOpinions")){
            return false;
        }
    }else {
        if(columnName ==="whetherSealedSample"||columnName ==="numberOfSealedSamples"||columnName ==="sealingDepartment"
            ||columnName ==="sealingSampleNumber"||columnName ==="isTheSampleSealingCompleted"||columnName ==="theSealedSampleBeenReceived"
            ||columnName ==="storageValidityPeriod"||columnName==="unit"||columnName==="whetherOnTrial"||columnName==="needTrialProduction"
            ||columnName==="comprehensiveOpinions"){
            return false;
        }
    }


    if(sampleConfirmationProgress === "确认终止"){
        return false; // 禁止编辑
    }
    return true; // 允许编辑操作
});
// =========================================S05：样品确认人填写相关信息和综合结论 02结束===================================================



var confirmerFillInInformationConclusion  = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S05：样品确认人填写相关信息和物料结论',
    padding:'5',
    collapsed:openPanel(confirm_sample_opinions_supporting_facilities,
        confirm_sample_opinions,sample_confirm_review,initiator_confirms_integrated,system_administrator_confirms_integrated,
        opinion_of_iqc_supervisor,trial_probation_comprehensive_conclusion,tqc_sealingSample,iqc_storageValidityPeriod,
        confirmation_of_trial_production,flow_path_sealed_sample,confirm_sample_opinions_standard,opinion_and_sealed_sample),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    width: '100%',
    anchor:'100%',
    defaults: {
        labelWidth: 80,
        border: false
    },
    items:[
        trialProductionAndUseResultGrid01,
        trialProductionAndUseResultGrid02
    ]
});


























