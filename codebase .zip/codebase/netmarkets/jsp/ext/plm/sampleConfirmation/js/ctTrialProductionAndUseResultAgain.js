
// ========================================S08：试产试用结果确认表一开始=================================================================================
Ext.define('trialProductionAndUseResultAgainModel01', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','trialProcessNumber','combinationNumber','semiFinishedProductNumber',
        'semiFinishedProductDescribe','finishedProductNumber','finishedProductDescription','internalVersion',
        'supplierCodeAndName','trialQuantity','trialNumberOfTimes','trialStatus'
    ],
    idProperty: 'id'
});

var trialProductionAndUseResultAgainStore01 = Ext.create('Ext.data.Store', {
    model: 'trialProductionAndUseResultAgainModel01',
    id: 'trialProductionAndUseResultAgainStore01',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtResultConfirmationAgainBo?branchId='+branchId+'&isEdit='+isEditable(''),
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

var trialProductionAndUseResultAgainColumns01 = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: false, menuDisabled: true,},
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
    {text: '试用流程编号', dataIndex: 'trialProcessNumber', flex: 1, editor: false , menuDisabled: true},
    {text: '组合编号', dataIndex: 'combinationNumber', flex: 1, editor: false , menuDisabled: true},
    {text: '半成品编号', dataIndex: 'semiFinishedProductNumber', flex: 1, editor: false, menuDisabled: true},
    {text: '半成品描述', dataIndex: 'semiFinishedProductDescribe', flex: 1, editor: false, menuDisabled: true},
    {text: '成品编号', dataIndex: 'finishedProductNumber', flex: 1, editor: false, menuDisabled: true},
    {text: '成品描述', dataIndex: 'finishedProductDescription', flex: 1, editor: false, menuDisabled: true},
    {text: '内部版本', dataIndex: 'internalVersion', flex: 1, editor: false, menuDisabled: true},
    {text: '供应商编码_名称', dataIndex: 'supplierCodeAndName', flex: 1, editor: false, menuDisabled: true},
    {text: '试用数量', dataIndex: 'trialQuantity', flex: 1, editor: false, menuDisabled: true},
    {text: '试用次数', dataIndex: 'trialNumberOfTimes', flex: 1, editor: false, menuDisabled: true},
    {text: '试用状态', dataIndex: 'trialStatus', flex: 1, editor: false, menuDisabled: true}
];

var trialProductionAndUseResultAgainGridEditing01 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var trialProductionAndUseResultAgainGrid01 = Ext.create('Ext.grid.Panel', {
    plugins: [trialProductionAndUseResultAgainGridEditing01],
    store: trialProductionAndUseResultAgainStore01,
    columns: trialProductionAndUseResultAgainColumns01,
    id:'trialProductionAndUseResultAgainGrid01',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    tbar: [
        // {
        //     xtype: 'button',
        //     text: '新增行',
        //     id: 'trialProductionAndUseResultInsert01',
        //     iconCls: 'icon icon-add',
        //     handler: function () {
        //         let callbackFn = function (response, opts) {
        //             var obj = Ext.decode(response.responseText);
        //             if(obj.message=='success') {
        //                 trialProductionAndUseResultStore01.load();
        //             }else {
        //                 alert(obj.message);
        //             }
        //         };
        //         insertData('ZResultConfirmationTable', branchId, callbackFn);
        //     }
        // },
        // {
        //     xtype: 'button',
        //     text: '删除行',
        //     id: 'trialProductionAndUseResulttDelete01',
        //     iconCls: 'icon icon-delete',
        //     handler: function () {
        //         let selected = trialProductionAndUseResultGrid01.getSelectionModel().getSelection();
        //         if (selected.length === 0) {
        //             alert('请选择数据！');
        //         } else {
        //             let ids = '';
        //             for (let i = 0; i < selected.length; i++) {
        //                 let id = selected[i].get('id');
        //                 if (id) {
        //                     if(i == 0){
        //                         ids += id;
        //                     }else{
        //                         ids += ',' + id;
        //                     }
        //                 }
        //             }
        //             let callbackFn = function (response, opts) {
        //                 trialProductionAndUseResultGrid01.getStore().remove(selected);
        //                 trialProductionAndUseResultGrid01.view.refresh();
        //             };
        //             deleteData('ZResultConfirmationTable', ids, callbackFn);
        //         }
        //     }
        // }
    ]
});

trialProductionAndUseResultAgainGrid01.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            trialProductionAndUseResultAgainStore01.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZResultConfirmationAgainTable", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
trialProductionAndUseResultAgainGrid01.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});
// ========================================S06：试产试用结果确认表一结束=================================================================================

// ========================================S06：试产试用结果确认表二开始=================================================================================
Ext.define('trialProductionAndUseResultAgainModel02', {
    extend: 'Ext.data.Model',
    fields: [
        'id','parentNumber','partDescribe','sampleConfirmationProgress','newProductOrMaterial',
        'whetherSealedSample','sealingSampleNumber',
        'trialProductionReportNumber','trialProductionConclusion',
        'whetherOnTrial','trialConclusion','overallConclusion'
    ],
    idProperty: 'id'
});

var trialProductionAndUseResultAgainStore02 = Ext.create('Ext.data.Store', {
    model: 'trialProductionAndUseResultAgainModel02',
    id: 'trialProductionAndUseResultAgainStore02',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/sampleConfirm/getCtResultConfirmationAgainTwoBo?branchId='+branchId,
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad:true,
});

let overallConclusionStoreAgain = [['通过', '通过'], ['不通过', '不通过']];

let trialConclusionStoreAgain = [['通过', '通过'], ['不通过', '不通过']];

var trialProductionAndUseResultAgainColumns02 = [
    {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
    {text: '物料编号', dataIndex: 'partNumber', flex: 1, editor: false, menuDisabled: true,
    },
    {text: '物料描述', dataIndex: 'partDescribe', flex: 1,menuDisabled: true, editor: false,},
    {text: '样品确认进展', dataIndex: 'sampleConfirmationProgress', flex: 1, editor: false , menuDisabled: true},
    {text: '是否是新产品新物料', dataIndex: 'newProductOrMaterial', flex: 1, editor: false , menuDisabled: true},

    {
        text: '试产结果',menuDisabled: true,
        columns: [
            {text: '试产报告编号', dataIndex: 'trialProductionReportNumber', flex: 1, editor: false, menuDisabled: true},
            {text: '试产结论', dataIndex: 'trialProductionConclusion', flex: 1, editor: false, menuDisabled: true}
        ]
    },
    {
        text: '试用结果',menuDisabled: true,
        columns: [
            {text: '是否需要试用', dataIndex: 'whetherOnTrial', flex: 1, editor: false, menuDisabled: true},
            {
                text: setMust('试用结论',isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)),
                dataIndex: 'trialConclusion',
                flex: 1,
                editAccess: true,
                menuDisabled: true,
                editor: isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)?{
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: trialConclusionStoreAgain
                }:false
            }
        ]
    },
    {
        text: setMust('总体试产试用结论',isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)),
        dataIndex: 'overallConclusion',
        flex: 1,
        menuDisabled: true,
        editAccess: true,
        editor: isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)?{
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: overallConclusionStoreAgain
        }:false
    }
];

var trialProductionAndUseResultAgainGridEditing02 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var trialProductionAndUseResultAgainGrid02 = Ext.create('Ext.grid.Panel', {
    plugins: [trialProductionAndUseResultAgainGridEditing02],
    store: trialProductionAndUseResultAgainStore02,
    columns: trialProductionAndUseResultAgainColumns02,
    id:'trialProductionAndUseResultAgainGrid02',
    autoWidth: true,
    columnLines: true,
    width:'100%',
    height:'100%',
    height:300,
    multiSelect : false,
    autoScroll: true,
    forceFit: false,
    selType: 'checkboxmodel',
    tbar: [
        {
            xtype: 'button',
            text: '试用流程创建',
            hidden:isEditable(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated)?false:true,
            id: 'trialProductionAndUseResultAgainExport01',
            iconCls : 'icon icon-store-export',
            handler: function () {
                let selected = trialProductionAndUseResultAgainGrid02.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    Ext.Msg.alert('提示', '请选择数据！');
                } else {
                    let ids = '';
                    for (let i = 0; i < selected.length; i++) {
                        let partNumber = selected[i].get('partNumber');
                        let whetherOnTrial = selected[i].get('whetherOnTrial');
                        if('是' != whetherOnTrial){
                            Ext.Msg.alert('提示', '只能选择“是否需要试用”为“是”的数据');
                            return;
                        }
                        if (partNumber) {
                            if(i == 0){
                                ids += partNumber;
                            }else{
                                ids += ',' + partNumber;
                            }
                        }
                    }
                    let callbackFn = function (response, opts) {
                        trialProductionAndUseResultAgainGrid01.view.refresh();
                    };
                    createTrialProcess(ids, callbackFn);
                }
            }
        }
    ]
});

trialProductionAndUseResultAgainGrid02.on('edit',function(editor,e){
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    var callbackFn = function (response, opts) {
        var obj = Ext.decode(response.responseText);
        if(obj.message=='success') {
            var obj = Ext.decode(response.responseText);
            e.record.commit();
            trialProductionAndUseResultAgainStore02.load();
        }else {
            alert(obj.message)
        }
    };
    saveMockItemData("ZResultConfirmationAgainTwo", id, field, value, callbackFn);
});

// 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
trialProductionAndUseResultAgainGrid02.on('rowclick', function(view, record, item, index, e) {

    var headerCt = view.getHeaderCt(); // 获取列头组件
    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
    var cellIndex = cell.cellIndex+1; // 获取单元格的索引

    // 通过单元格索引获取列
    var column = headerCt.getGridColumns()[cellIndex];

});

//根据特定字段的值判断是否禁止编辑
trialProductionAndUseResultAgainGrid02.on('beforeedit', function (editor, context) {
    var record = context.record;
    var sampleConfirmationProgress = record.get('sampleConfirmationProgress');
    if(sampleConfirmationProgress === "确认终止"){
        return false; // 禁止编辑
    }
    return true; // 允许编辑操作
});
// ========================================S06：试产试用结果再确认二结束=================================================================================


var trialProductionAndUseResultAgainResult  = Ext.create('Ext.panel.Panel',{
    xtype:'panel',
    title: 'S08：试产试用结果再确认',
    padding:'5',
    collapsed:openPanel(confirmation_of_trial_production,system_administrator_confirms_integrated,initiator_confirms_integrated),
    collapsible:true,
    titleCollapse:true,
    hideCollapseTool:true,
    width: '100%',
    anchor:'100%',
    defaults: {
        labelWidth: 80,
        border: false
    },
    items:[
        // trialProductionAndUseResultGrid01,
        trialProductionAndUseResultAgainGrid02
    ]
});