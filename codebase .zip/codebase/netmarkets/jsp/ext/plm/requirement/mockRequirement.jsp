<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="wt.workflow.work.*,wt.fc.Persistable,wt.doc.WTDocument,wt.inf.container.WTContainer,wt.projmgmt.admin.Project2,ext.plm.util.IBAUtil,org.apache.commons.lang3.StringUtils"%>
<html>
<head>



<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- 	<link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/css/ext-all.css"> -->
	<link href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-gray/ext-theme-gray-all.css" rel="stylesheet" type="text/css" />
	<link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
	<!-- ExtJS -->
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
	<script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>

	<script type="text/javascript" src="../mock/js/ctMockFunctions.js"></script>
	<script type="text/javascript" src="../mock/js/ctMockObjects.js"></script>
    <script type="text/javascript" src="js/mockRequirement.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>
// ==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'CtRequirePanel'
		    }]
		});
});
</script>
</body>
</html>