<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="ext.plm.util.IBAUtil,org.apache.commons.lang3.StringUtils,wt.doc.WTDocument,wt.fc.Persistable,wt.workflow.work.WfAssignedActivity,wt.workflow.work.WorkItem"%>
<html>
<head>
	<%
		String oid = request.getParameter("oid");
		String workItemOid = oid;
		wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
		WorkItem workItem = (WorkItem)rf.getReference(oid).getObject();
		WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
		String actName = activity.getName();
		String actKey = ext.plm.requirement.config.CtRequireProperties.getActivityKey(actName);
		String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
		Persistable pbo = workItem.getPrimaryBusinessObject().getObject();
		WTDocument doc = (WTDocument) pbo;
		long branchId = doc.getBranchIdentifier();

		IBAUtil ibaUtil = new IBAUtil(doc);
		String ibaValue = ibaUtil.getIBAValue("Ct_RequireChangeDoc");

		boolean allowImport=true;
		if(!actKey.equals("ActivityNode_Require_CreatorSubmit")) {
			allowImport=false;
		}
		System.out.println("allowImport============="+allowImport);
		wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
		String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=";

		//编辑权限判断
		boolean allowEdit = ext.plm.util.CtWorkFlowUtil.hasEditAccess(workItem,
				ext.plm.requirement.config.CtRequireProperties.getProperty("Require_allowEdit_roles"));
	%>

	<script type="text/javascript">
		var workItemOid = "<%=workItemOid%>";
		//文档vid
		var branchId = "<%=branchId%>";
		//当前用户全名
		var userName = "<%=userName%>";

		//节点名称Key
		var actKey = "<%=actKey%>";

		//流程当前节点名称
		var actName = "<%=actName%>";

		//文档链接url前缀
		var urlPathPrefix = "<%=urlPathPrefix%>";

		//编辑权限
		var allowEdit = false;
		<%if(allowEdit){ %>
		allowEdit = true;
		<%}%>

		//是否可以导入
		var allowImport = false;
		<%if(allowImport){ %>
		allowImport = true;
		<%}%>

		//只读页面标记
		var readOnly = false;

		//是否为分页查询
		var isPageQuery = true;

	</script>

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<!-- ExtJS -->
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>

	<script type="text/javascript" src="js/ctRequirement.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<script type="text/javascript" src="js/ctRequirementDetails.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>

</head>

<body>
<script>
	// ==============layout define area=================================//
	Ext.onReady(function() {
		Ext.QuickTips.init();

		Ext.create('Ext.container.Viewport', {
			layout: 'border',
			items: [{
				region: 'center',
				xtype: 'CtRequirePanel'
			}]
		});
	});
</script>
</body>
</html>