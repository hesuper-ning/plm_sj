<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="java.util.*,wt.workflow.work.*,wt.fc.Persistable,wt.doc.WTDocument"%>
<html>
<head>
<%
    String oid = request.getParameter("oid");
    String workItemOid = oid;
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WorkItem workItem = (WorkItem)rf.getReference(oid).getObject();
    WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
    String actName = activity.getName();
    String actKey = ext.plm.requirement.config.CtRequireProperties.getActivityKey(actName);
    String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
    Persistable pbo = workItem.getPrimaryBusinessObject().getObject();
    WTDocument doc = (WTDocument) pbo;
    String docNumber = doc.getNumber();
    long branchId = doc.getBranchIdentifier();

    //编辑权限判断
    boolean allowEdit = ext.plm.util.CtWorkFlowUtil.hasEditAccess(workItem,
            ext.plm.requirement.config.CtRequireProperties.getProperty("RequireChange_allowEdit_roles"));
%>

<script type="text/javascript">
var workItemOid = "<%=workItemOid%>";
//文档编码
var docNumber = "<%=docNumber%>";
//流程当前节点名称
var actName = "<%=actName%>";
//当前用户全名
var userName ="<%=userName%>";
//文档vid
var branchId ="<%=branchId%>";

//节点名称
var actKey = "<%=actKey%>";

//编辑权限
var allowEdit = false;
<%if(allowEdit){ %>
	allowEdit = true;
<%}%>
</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="js/ctRequirementChange.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>

//==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'RequireChangePanel'
		    }]
		});
});

</script>

</body>
</html>