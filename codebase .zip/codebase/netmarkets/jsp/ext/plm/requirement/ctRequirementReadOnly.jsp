<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="wt.workflow.work.*,wt.fc.Persistable,wt.doc.WTDocument,wt.inf.container.WTContainer,wt.projmgmt.admin.Project2"%>
<html>
<head>

<%
String oid = request.getParameter("oid");
wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
wt.doc.WTDocument doc = (wt.doc.WTDocument)rf.getReference(oid).getObject();
//将文档的大版本branchId作为主键id
String branchId = doc.getBranchIdentifier()+"";
wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
 String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=";
 String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
%>

<script type="text/javascript">
//文档vid
var branchId = "<%=branchId%>";
//当前用户全名
var userName = "<%=userName%>";

//节点名称
var actKey = "NA";

//文档链接url前缀
var urlPathPrefix = "<%=urlPathPrefix%>";

var allowEdit = false;

//是否可以导入
var allowImport = false;

//只读页面标记
var readOnly = true;

//是否为分页查询
var isPageQuery = true;

</script>


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<!-- ExtJS -->
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
	<script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
	<script type="text/javascript" src="js/ctRequirement.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<script type="text/javascript" src="js/ctRequirementDetails.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>
// ==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'CtRequirePanel'
		    }]
		});
});
</script>
</body>
</html>