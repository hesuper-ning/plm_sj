Ext.define('Pnt.view.RequireDetailsPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.RequireDetailsPanel',
	border:false,
	layout:'anchor',
    autoWidth:true,
 	autoHeight:true,
     collapsible: false,
     fieldDefaults: {
         msgTarget: 'side',
         labelWidth: 75
     },
	initComponent:function(){
    	 
    	 Ext.Ajax.request({
			   scope:this,
	   		   url: '/Windchill/ptc1/require/getRequireItem?id='+this.param_id,
	   		   method:'GET',
	   		   success: function(response, opts) {
		   			var respText = Ext.decode(response.responseText);
		   			var success = respText['success'];
		   			var msg = respText['msg'];
		   			if(success) {
		   				var items = respText['items'];
		   				Ext.getCmp('orRequireTitle').setValue(items['orRequireTitle']);
		   				Ext.getCmp('orRequireNumber').setValue(items['orRequireNumber']);
						Ext.getCmp('drRequireTitle').setValue(items['drRequireTitle']);
						Ext.getCmp('drRequireNumber').setValue(items['drRequireNumber']);
						Ext.getCmp('dsRequireTitle').setValue(items['dsRequireTitle']);
						Ext.getCmp('dsRequireNumber').setValue(items['dsRequireNumber']);
						Ext.getCmp('dsRequireDesc').setValue(items['dsRequireDesc']);
						Ext.getCmp('dsRequireRemark').setValue(items['dsRequireRemark']);
						Ext.getCmp('dsComponent').setValue(items['dsComponent']);
						Ext.getCmp('dsDomain').setValue(items['dsDomain']);
						Ext.getCmp('dsPriority').setValue(items['dsPriority']);
						Ext.getCmp('dsImportance').setValue(items['dsImportance']);
		   			}else {
		   				alert(msg);
		   			}
		   			
				},
	    	  failure: function(response, opts) {
	 			   
	 		   }
	      });
    	 
    	 
    	 var requireDetailPanel = Ext.create('Ext.panel.Panel', {
 	    	xtype:'form',
 	    	border:false,
 	    	items:[{
 		    	layout:'hbox',
 		    	border:false,
 				margin:'30 5 10 60',
 				 items:[{
 					 xtype:'textfield',
 					 fieldLabel:'OR需求标题',
 					 labelWidth:70,
 					 width:300,
 					 id:'orRequireTitle',
 					 name:'orRequireTitle',
 					 readOnly:true
 				 },{
 					 xtype:'textfield',
 					 width:300,
 					 margin:'0 0 0 70',
 					 fieldLabel: 'OR需求编号',
 					 id:'orRequireNumber',
 					 name:'orRequireNumber',
 					 labelWidth:70,
 					 readOnly:true
 				 }
 				 ]
 		    },{
 		    	layout:'hbox',
 		    	border:false,
 				margin:'5 5 10 60',
 				 items:[{
 					 xtype:'textfield', 
 					 width:300,
 					 fieldLabel: 'DR需求标题',
 					 id:'drRequireTitle',
 					 name:'drRequireTitle',
 					 labelWidth:70,
 					 readOnly:true
 				 },{
 					 xtype:'textfield', 
 					 width:300,
 					 margin:'0 0 0 70',
 					 fieldLabel: 'DR需求编号',
 					 id:'drRequireNumber',
 					 name:'drRequireNumber',
 					 labelWidth:70,
 					 readOnly:true
 				 }
 				 ]
 		    },{
 		    	layout:'hbox',
 		    	border:false,
 				margin:'5 5 20 60',
 				 items:[{
 					 xtype:'textfield', 
 					 width:300,
 					 fieldLabel: 'DS需求标题',
 					 id:'dsRequireTitle',
 					 name:'dsRequireTitle',
 					 labelWidth:70,
 					 readOnly:true
 					 
 				 },{
 					 xtype:'textfield', 
 					 width:300,
 					 margin:'0 0 0 70',
 					 fieldLabel: 'DS需求编号',
 					 id:'dsRequireNumber',
 					 name:'dsRequireNumber',
 					 labelWidth:70,
 					 readOnly:true
 				 }
 				 ]
 		    },{
 		    	layout:'hbox',
 		    	border:false,
 				margin:'5 5 20 60',
 				 items:[{
 					 xtype:'textarea', 
 					 width:670,
 					 fieldLabel: 'DS需求描述',
 					 id:'dsRequireDesc',
 					 name:'dsRequireDesc',
 					 labelWidth:70,
 					 readOnly:true
 				 }]
 		    },{
 		    	layout:'hbox',
 		    	border:false,
 				margin:'5 5 20 60',
 				 items:[{
 					 xtype:'textfield', 
 					 width:300,
 					 fieldLabel: 'DS需求备注说明',
 					 id:'dsRequireRemark',
 					 name:'dsRequireRemark',
 					 labelWidth:70,
 					 readOnly:true
 				 },{
 					 xtype:'textfield', 
 					 width:300,
 					 margin:'0 0 0 70',
 					 fieldLabel: 'DS构件',
 					 id:'dsComponent',
 					 name:'dsComponent',
 					 labelWidth:70,
 					 readOnly:true
 				 }
 				 ]
 		    },{
 		    	layout:'hbox',
 		    	border:false,
 				margin:'5 5 20 60',
 				 items:[{
 					 xtype:'textfield', 
 					 width:300,
 					 fieldLabel: 'DS领域',
 					 id:'dsDomain',
 					 name:'dsDomain',
 					 labelWidth:70,
 					 readOnly:true
 				 },{
 					 xtype:'textfield', 
 					 width:300,
 					 margin:'0 0 0 70',
 					 fieldLabel: 'DS优先级',
 					 id:'dsPriority',
 					 name:'dsPriority',
 					 labelWidth:70,
 					 readOnly:true
 				 }
 				 ]
 		    },{
 		    	layout:'hbox',
 		    	border:false,
 				margin:'5 5 20 60',
 				 items:[{
 					 xtype:'textfield', 
 					 width:300,
 					 fieldLabel: 'DS重要性',
 					 id:'dsImportance',
 					 name:'dsImportance',
 					 labelWidth:70,
 					 readOnly:true
 				 }
 				 ]
 		    }]
 	    });
	        				
/////////////////////////Panel items//////////////////////////////////
		this.items=[requireDetailPanel];
		
		this.callParent();
	}
	
});
////////////////////////Function area//////////////////////////