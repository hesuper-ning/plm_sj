Ext.define('PLM.view.RequireChangePanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.RequireChangePanel',
	title:'<font style="font-size:18px">需求更改通知单</font>',
	border:false,
	layout:'anchor',
	autoScroll:true,
    autoWidth:true,
 	autoHeight:true,
     collapsible: false,
     id: 'requireChangePanel',
     fieldDefaults: {
         msgTarget: 'side',
         labelWidth: 75
     },
	initComponent:function(){
		 var beforeDsNumber="";

		 var changeType = "变更类型";
		 var productModel = "产品型号";
		 var orRequireTitle = "OR需求标题";

		var orDescribe = "OR描述";
		var drDescribe = "DR描述";

		 var orRequireNumber = "OR需求编号";
		 var drRequireTitle = "DR需求标题";
		 var drRequireNumber = "DR需求编号";
		 var dsRequireTitle = "DS需求标题";
		 var dsRequireNumber = "DS需求编号";
		 var dsRequireDesc = "DS需求描述";
		 var dsRequireRemark = "DS需求备注说明";
		 var dsComponent = "DS构件";
		 var dsDomain = "DS领域";
		 var dsPriority = "DS优先级";
		 var dsImportance = "DS重要性";
		 var isSelfVerify = "是否需要自测报告";
		 var isTestCase = "是否有对应测试用例";
		 var rdPersonLiable = "研发责任人";
		 var rdPlanTime = "研发计划完成时间";
		 var caPersonLiable = "测试验收责任人";
		 var caPlanTime = "测试验收计划时间";


		 var redStarFlag = '<font color=red bold>*</font>'; //必填标志
         var blueFlagStart = '<font color=blue bold><b>';
         var blueFlagEnd = '</b></font>';
		 if(actKey=="ActivityNode_RequireChange_SECarryOut"&&allowEdit){
             changeType = redStarFlag+blueFlagStart+changeType+blueFlagEnd;
             productModel = redStarFlag+blueFlagStart+productModel+blueFlagEnd;
             orRequireTitle = redStarFlag+blueFlagStart+orRequireTitle+blueFlagEnd;

             orDescribe = redStarFlag+blueFlagStart+orDescribe+blueFlagEnd;

             orRequireNumber = redStarFlag+blueFlagStart+orRequireNumber+blueFlagEnd;
             drRequireTitle = redStarFlag+blueFlagStart+drRequireTitle+blueFlagEnd;

             drDescribe = redStarFlag+blueFlagStart+drDescribe+blueFlagEnd;

             drRequireNumber = redStarFlag+blueFlagStart+drRequireNumber+blueFlagEnd;
             dsRequireTitle = redStarFlag+blueFlagStart+dsRequireTitle+blueFlagEnd;
             dsRequireNumber = redStarFlag+blueFlagStart+dsRequireNumber+blueFlagEnd;
             dsRequireDesc = redStarFlag+blueFlagStart+dsRequireDesc+blueFlagEnd;
             dsRequireRemark = blueFlagStart+dsRequireRemark+blueFlagEnd;
             dsComponent = blueFlagStart+dsComponent+blueFlagEnd;
             dsDomain = redStarFlag+blueFlagStart+dsDomain+blueFlagEnd;
             dsPriority = redStarFlag+blueFlagStart+dsPriority+blueFlagEnd;
             dsImportance = redStarFlag+blueFlagStart+dsImportance+blueFlagEnd;
             isSelfVerify = redStarFlag+blueFlagStart+isSelfVerify+blueFlagEnd;
             isTestCase = redStarFlag+blueFlagStart+isTestCase+blueFlagEnd;
             rdPersonLiable = redStarFlag+blueFlagStart+rdPersonLiable+blueFlagEnd;
             rdPlanTime = redStarFlag+blueFlagStart+rdPlanTime+blueFlagEnd;
             caPersonLiable = redStarFlag+blueFlagStart+caPersonLiable+blueFlagEnd;
             caPlanTime = redStarFlag+blueFlagStart+caPlanTime+blueFlagEnd;
         }


    	 var panelType = actKey=="ActivityNode_RequireChange_CreatorSubmit"&&allowEdit ? "textfield":"displayfield";
    	 var panelType2 = actKey=="ActivityNode_RequireChange_CreatorSubmit"&&allowEdit ? "textarea":"displayfield";
    	 var combo = actKey=="ActivityNode_RequireChange_CreatorSubmit"&&allowEdit ? "combo":"displayfield";

    	 //***************加载请求获取变更表单信息**********************
    	 Ext.Ajax.request({
			   scope:this,
	   		   url: '/Windchill/ptc1/require/getRequireChangeHead?branchId='+branchId,
	   		   method:'GET',
	   		   success: function(response, opts) {
		   			var respText = Ext.decode(response.responseText);
		   			var success = respText['success'];
		   			var msg = respText['msg'];
		   			if(success) {
		   				var result = respText['result'];
		   				if(result!=undefined) {
		   					Ext.getCmp('applicant').setValue(result['applicant']);
			   				Ext.getCmp('department').setValue(result['department']);
							Ext.getCmp('requireChangeSource').setValue(result['requireChangeSource']);
							Ext.getCmp('requireChangeReason').setValue(result['requireChangeReason']);
							Ext.getCmp('requireChangeDesc').setValue(result['requireChangeDesc']);
							if(result['dsRequireDocUrl']&&actKey!="ActivityNode_RequireChange_CreatorSubmit"){
								Ext.getCmp('dsRequireDocNumber').setValue(result['dsRequireDocUrl']);
							}else{
								Ext.getCmp('dsRequireDocNumber').setValue(result['dsRequireDocNumber']);
							}
							if(result['orRequireDocUrl']&&actKey!="ActivityNode_RequireChange_CreatorSubmit"){
								Ext.getCmp('orRequireDocNumber').setValue(result['orRequireDocUrl']);
							}else{
								Ext.getCmp('orRequireDocNumber').setValue(result['orRequireDocNumber']);
							}
		   				}
		   			}else {
		   				alert(msg);
		   			}

				},
	    	  failure: function(response, opts) {
			   	alert("表单加载失败，请检查网络!");
			   }
	      });

        //==============下拉加载项目团队的人===================
        Ext.define('teamMembersModel', {
            extend: 'Ext.data.Model',
            fields: [
                'storeId', 'storeName'
            ],
            idProperty: 'id'
        });

        teamMembersStore = new Ext.data.Store({
            storeId:'teamMembersStore',
            model:'teamMembersModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/require/getProjectUser?branchId='+branchId,
                method:'GET',
                reader:{
                    type:'json',
                    idProperty: 'id',
                    rootProperty:'items',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

		teamMembersStore2 = new Ext.data.Store({
			storeId:'teamMembersStore2',
			model:'teamMembersModel',
			pruneModifiedRecords: true,
			proxy: new Ext.data.HttpProxy({
				url: '/Windchill/ptc1/require/getProjectUser?branchId='+branchId,
				method:'GET',
				reader:{
					type:'json',
					idProperty: 'id',
					rootProperty:'items',
					messageProperty: 'msg'
				}
			}),
			autoLoad: true
		});

        var teamMembersCombo = new Ext.form.field.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            queryMode: 'local',
            displayField: 'storeName',
            valueField: 'storeId',
            forceSelection:true,
            allowBlank : false,
            anyMatch: true,
            store:teamMembersStore
        });

        var teamMembersCombo2 = new Ext.form.field.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            queryMode: 'local',
            displayField: 'storeName',
            valueField: 'storeId',
            forceSelection:true,
            allowBlank : false,
            anyMatch: true,
            store:teamMembersStore2
        });

    	 //***************需求变更信息**********************
    	 var requireChangeInfoPanel = Ext.create('Ext.panel.Panel', {
 	    	margin:'0 10 0 10',
 	    	border: false,
 	    	xtype:'form',
 	    	border:false,
 	    	align:'middle',
 	    	items:[{
 	    		border: false,
 		    	layout:'hbox',
 		    	align: 'middle',
 				margin:'10 0 0 10',
 				 items:[{
 					 xtype:'displayfield',
 					 width:500,
 					 fieldLabel: '<font color="red">*</font>发起人',
 					 id:'applicant',
 					 name:'applicant',
 					 labelWidth:150,
	 				 // listeners:{
	 					// blur:function(){
	 					//  	saveRequireChangeHead('applicant',Ext.getCmp('applicant').getValue());
	 					// }
	 				 // }
 				 },{
 					 xtype:'displayfield',
 					 width:500,
 					 margin:'0 0 0 40',
 					 fieldLabel: '<font color="red">*</font>发起人部门',
 					 name:'department',
 					 id:'department',
 					 labelWidth:150,
 					 // listeners:{
 	 					// blur:function(){
 	 					//  	saveRequireChangeHead('department',Ext.getCmp('department').getValue());
 	 					// }
 	 				 // }
 				 }
 				 ]
 		    },{
				border: false,
				layout:'hbox',
				align: 'middle',
				margin:'10 0 0 10',
				items:[{
					xtype:''+combo+'',
					width:500,
					fieldLabel: '<font color="red">*</font>需求变更源',
					id:'requireChangeSource',
					name:'requireChangeSource',
					labelWidth:150,
					editable:false,
					store : [['市场需求变更', '市场需求变更'], ['设计需求变更', '设计需求变更'], ['制造需求变更', '制造需求变更'],['物料需求变更','物料需求变更'],['其他需求变更','其他需求变更']],
					listeners:{
						select:function(){
							saveRequireChangeHead('requireChangeSource',Ext.getCmp('requireChangeSource').getValue());
						}
					}
				},{
					xtype:''+panelType+'',
					width:500,
					margin:'0 0 0 40',
					fieldLabel: '<font color="red">*</font>DS需求条目化文档编号',
					id:'dsRequireDocNumber',
					name:'dsRequireDocNumber',
					labelWidth:150,
					listeners:{
						blur:function(){
							saveRequireChangeHead('dsRequireDocNumber',Ext.getCmp('dsRequireDocNumber').getValue());
						}
					}
				}
				]
			},{
				layout:'hbox',
				border:false,
				margin:'10 0 0 10',
				items:[{
					xtype:''+panelType+'',
					width:500,
					fieldLabel: '《初始产品包需求》文档编号',
					id:'orRequireDocNumber',
					name:'orRequireDocNumber',
					labelWidth:150,
					listeners:{
						blur:function(){
							saveRequireChangeHead('orRequireDocNumber',Ext.getCmp('orRequireDocNumber').getValue());
						}
					}
				}]
			},{
				layout:'hbox',
				border:false,
				margin:'10 0 0 10',
				items:[{
					xtype:''+panelType2+'',
					width:500,
					fieldLabel: '<font color="red">*</font>需求变更原因',
					id:'requireChangeReason',
					name:'requireChangeReason',
					labelWidth:150,
					listeners:{
						blur:function(){
							saveRequireChangeHead('requireChangeReason',Ext.getCmp('requireChangeReason').getValue());
						}
					}
				}]
			},{
				layout:'hbox',
				border:false,
				margin:'10 0 0 10',
				items:[{
					xtype:''+panelType2+'',
					width:500,
					fieldLabel: '<font color="red">*</font>需求变更说明',
					id:'requireChangeDesc',
					name:'requireChangeDesc',
					labelWidth:150,
					listeners:{
						blur:function(){
							saveRequireChangeHead('requireChangeDesc',Ext.getCmp('requireChangeDesc').getValue());
						}
					}
				}]
			}]
 	    });
    	 
    	var objValue = "";
    	//*****弹窗显示值或填写******//
    	 var editPanel =  Ext.create('Ext.panel.Panel', {
     		title: '',
     	    width: 100,
   	        id:'editPanel',
   	        region:'center',
   	        autoWidth:true,
   	        items:[{
   	        	xtype:'textarea',
 	  	  		fieldLabel: '内容',
 	  	  		id:'editValue',
 	  	        width:400,
 	  	        height:200,
 	  	        margin:"5 10 0 20",
 	  	        labelWidth: 40,
 	  	        readOnly:actKey=="ActivityNode_RequireChange_SECarryOut"&&allowEdit?false:true,
 	  	        listeners:{
   	 				blur:function(){
		   	        	var value = Ext.getCmp("editValue").getValue();
		   	        	var key = Ext.getCmp("tField").getValue();
		 	    		var id = objValue.get("id");
		 	    		if(!isNumber(id))id="";
		 	    		if(!id){
		 	    			alert("请先填写DS需求编号!");
		 	    			return;
						}


		 	    		saveRequireChangeItems(objValue,id,key,value);
		 	    		// objValue.set(""+key+"",value);
   	 				}
   	 			 }
   	        },{
  	        	xtype:'textfield',
	  	  		fieldLabel: 'tField',
	  	  		id:'tField',
	  	        width:380,
	  	        height:250,
	  	        margin:"5 10 0 40",
	  	        labelWidth: 60,
	  	        hidden:true  
  	        }]
     	});
     	
     	//********显示值或填写值窗口*********//
     	var editWindow = new Ext.Window({
 			id: 'editWindow',
 			title: '',
     		width: 480,
     		height: 350,
     		draggable: false,
     		modal: true,
     		closeAction: 'hide',
     		items: [editPanel],
     		layout:'fit',
     	    bbar:['->', {
 				text: '保存',
 				id:"determine",
 				handler: function() {
     	    		editWindow.hide();
     	    		objValue="";
     	    	}
 					
 			}]
 		});
    	 
    	 //***********需求差异项*************
		 Ext.define('requireChangeModel', {
		        extend: 'Ext.data.Model',
		        fields: [
					'id','changeType','productModel','orRequireTitle','orRequireNumber','drRequireTitle','drRequireNumber',
					'dsRequireTitle','dsRequireNumber','dsRequireDesc','dsRequireRemark','dsComponent','dsDomain',
					'dsPriority','dsImportance','isSelfVerify','isTestCase','rdPersonLiable','rdPlanTime',
                    'caPersonLiable','caPlanTime'
		                 ],
		        idProperty: 'id'
		  });
    	 
		    // create the Data Store
		    this.requireChangeStore = Ext.create('Ext.data.Store', {
		        //pageSize: 50,
		        model: 'requireChangeModel',
		        id:'requireChangeStore',
		        pruneModifiedRecords: true,
		        proxy: new Ext.data.HttpProxy({
		            url: '/Windchill/ptc1/require/getRequireChangeItems',
		            method:'GET',
		            reader:{
		            	type:'json',
		            	rootProperty: 'items',
		                totalProperty: 'totalCount',
		                idProperty: 'id',
		    		    messageProperty: 'msg'
		            }
		        }),
		        autoLoad:false
		    });
 
		this.cellEditing = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		
		 
		var requireChangeGrid = Ext.create('Ext.grid.Panel', {
	    	plugins: [this.cellEditing],
	        title: '需求差异项',
	        margin:'20 0 0 0',
	        store:Ext.data.StoreManager.lookup('requireChangeStore'),
	        id:'requireChangeGrid',
	        //forceFit : true,
	        autoWidth : true,
	       // width:2500,
	        autoScroll:true,
	        region:'center',
			height:400,
			viewConfig:{enableTextSelection:true},
   			selModel: Ext.create('Ext.selection.CheckboxModel', {
 				id: 'requireChangeModel',
 				mode: "SIMPLE",
 				showHeaderCheckbox: true
 			}),
			
			columns: [
			          	
			          	{ text: 'id',  dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
			          	{text: changeType,dataIndex: 'changeType',width: 100, editor:{
		        	  		xtype : 'combo',
							editable : false,
							value: ' ',
							store : [['添加','添加'],['删除', '删除']],
							mode : 'local',
							menuDisabled:true
		          	  	} },
                        { text: productModel,	dataIndex: 'productModel',width:100 ,editor: 'textfield',menuDisabled:true,
                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                return value;
                            }
                        },
						{ text: orRequireTitle,	dataIndex: 'orRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},
						{ text: orRequireNumber,	dataIndex: 'orRequireNumber',width:100 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},
                { text: orDescribe,	dataIndex: 'orDescribe',width:100 ,editor: 'textfield',menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },
						{ text: drRequireTitle,	dataIndex: 'drRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},
						{ text: drRequireNumber,	dataIndex: 'drRequireNumber',width:100 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},

                { text: drDescribe,	dataIndex: 'drDescribe',width:100 ,editor: 'textfield',menuDisabled:true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return value;
                    }
                },

						{ text: dsRequireTitle,  dataIndex: 'dsRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},
						{ text: dsRequireNumber,  dataIndex: 'dsRequireNumber',width:100 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},
						{ text: dsRequireDesc,  dataIndex: 'dsRequireDesc',width:100 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},
						{ text: dsRequireRemark,  dataIndex: 'dsRequireRemark',width:160 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},
						{ text: dsComponent,  dataIndex: 'dsComponent',width:100 ,editor: 'textfield',menuDisabled:true,
							renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
								return value;
							}
						},
                        { text: dsDomain,dataIndex: 'dsDomain',width:100 ,editor:{
                                xtype : 'combo',
                                editable : false,
                                typeAhead:false,
                                value: ' ',
                                store : [['结构','结构'],['硬件', '硬件'],['软件','软件'],['中试','中试'],['认证','认证']],
                                mode : 'local'
                            },renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
                                return value;
                            },menuDisabled:true
                        },
                        { text: dsPriority,dataIndex: 'dsPriority',width:100 ,editor:{
                                xtype : 'combo',
                                editable : false,
                                typeAhead:false,
                                value: ' ',
                                store : [['紧急','紧急'],['高', '高'],['中','中'],['低','低']],
                                mode : 'local'
                            },renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
                                return value;
                            },menuDisabled:true
                        },
                        { text: dsImportance,dataIndex: 'dsImportance',width:100 ,editor:{
                                xtype : 'combo',
                                editable : false,
                                typeAhead:false,
                                value: ' ',
                                store : [['必须','必须'],['重要', '重要'],['最好有','最好有']],
                                mode : 'local'
                            },renderer: function(value,metaData,record,row,col,store){
								if(value)
									metaData.tdAttr = 'data-qtip="' + value +'"';
                                return value;
                            },menuDisabled:true
                        },
                        { text: isSelfVerify,dataIndex: 'isSelfVerify',width:160 ,editor:{
                                xtype : 'combo',
                                editable : false,
                                typeAhead:false,
                                value: ' ',
                                store : [['Y','是'],['N', '否']],
                                mode : 'local'
                            },
                            renderer: function(value,metaData,record,row,col,store){
                                if(value=="Y") {
                                    value="是";
                                }else if(value=="N") {
                                    value="否";
                                }
                                return value;
                            },menuDisabled:true
                        },
                        { text: isTestCase,dataIndex: 'isTestCase',width:180 ,editor:{
                                xtype : 'combo',
                                editable : false,
                                typeAhead:false,
                                value: '',
                                store : [['Y','是'],['N', '否']],
                                mode : 'local'
                            },renderer: function(value,metaData,record,row,col,store){
                                if(value=="Y") {
                                    value="是";
                                }else if(value=="N") {
                                    value="否";
                                }
                                return value;
                            },menuDisabled:true
                        },

                        { text: rdPersonLiable,dataIndex: 'rdPersonLiable',width:100 ,editor: teamMembersCombo,menuDisabled:true,filter:{type:"string"},
                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                return value;
                            }
                        },
                        { text: rdPlanTime,dataIndex: 'rdPlanTime',width:160 ,editor: {xtype:'datefield',format:'Y-m-d'},menuDisabled:true,
                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                return selfDateFormat(value);
                            }
                        },
                        { text: caPersonLiable,dataIndex: 'caPersonLiable',width:150 ,editor: teamMembersCombo2,menuDisabled:true,filter:{type:"string"},
                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                return value;
                            }
                        },
                        { text: caPlanTime,dataIndex: 'caPlanTime',width:160 ,editor: {xtype:'datefield',format:'Y-m-d'},menuDisabled:true,renderer:selfDateFormat}

				],
			tbar: {
				xtype: 'container',
				border:false,
				items: [{
					//tbar第一行工具栏
					xtype:"toolbar",
					items : [{
						text: '添加',
						iconCls: 'icon icon-add',
						disabled: disabledButton(),
						scope: this,
						handler: function () {
							if (actKey != "ActivityNode_RequireChange_SECarryOut") {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return;
							}
							var rec = new requireChangeModel({});
							this.requireChangeStore.insert(0, rec);
						}
					}, '&nbsp;', {
						text: '删除',
						iconCls: 'icon icon-delete',
						disabled: disabledButton(),
						scope: this,
						handler: function () {
							if (actKey != "ActivityNode_RequireChange_SECarryOut") {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return;
							}
							var tmpSm = requireChangeGrid.getSelectionModel().getSelection();
							if (!tmpSm || tmpSm == '') {
								Ext.Msg.alert('提示', '未选择任何列，请选择要删除的数据！');
								return;
							}
							var delFn = function () {
								var deleteItems = new Array();//删除项
								var sm = requireChangeGrid.getSelectionModel();

								var tmpStore = Ext.getStore('requireChangeStore');
								tmpStore.remove(sm.getSelection());

								var removedRecords = tmpStore.getRemovedRecords();

								Ext.each(removedRecords, function (record) {
									deleteItems.push(record.data);
								});
								var submitData = {
									deleteItems: Ext.encode(deleteItems)
								};
								Ext.Ajax.request({
									scope: this,
									url: '/Windchill/ptc1/require/deleteRequireChangeItems',
									//params: {submitData:Ext.encode(submitData)},
									params: {deleteItems: Ext.encode(deleteItems)},
									success: function (response, opts) {
										var obj = Ext.decode(response.responseText);
										if (!obj['success']) {
											alert(obj['msg']);
										} else {
											refreshRequrieChangeItems();
										}
									},
									failure: function (response, opts) {
										alert('错误：删除失败，请检查网络！');
									}
								});
							};//~end of delFn

							Ext.Msg.confirm('提示', '确定要删除选中内容？',
								function (btn) {
									if (btn == 'yes') {
										delFn();
									} else {
										return;
									}
								}, this);
						}
						}, {
							text: '',
							id: 'saveStatus',
							disabled: true
						}]
					},{
                        xtype:"toolbar",
                        items:[
                            '<font color="blue" disabled="'+disabledButton()+'">如需修改原有需求，请先删除再增加</font>'
                        ]
					}
				]

			},
				listeners:{
					cellclick:function(obj,td,cellIndex,record,tr,rowIndex,e,eOpts){
						var dsRequireNumber = e.record.get("dsRequireNumber");
						if(cellIndex!= 11 &&!dsRequireNumber) {
							alert("请先填写DS需求编号!");
							return false;
						}
						var changeType = e.record.get("changeType");
						if(changeType=='删除') {
							Ext.getCmp('saveStatus').setText('不允许编辑！');
							return false;
						}

						if(cellIndex=='13'){
		        			editWindow.show();
		        			Ext.getCmp("editValue").setValue(record.get("dsRequireRemark"));
		        			Ext.getCmp("tField").setValue("dsRequireRemark");
		        			objValue=record;
		        		}else if(cellIndex=='12') {
		        			editWindow.show();
		        			Ext.getCmp("editValue").setValue(record.get("dsRequireDesc"));
		        			Ext.getCmp("tField").setValue("dsRequireDesc");
		        			objValue=record;
		        		}
		        		
		        	},
	        	 	beforeedit: function (editor, e, eOpts) {
						if(allowEdit) {
							beforeDsNumber = e.record.get("dsRequireNumber");
							if(actKey!="ActivityNode_RequireChange_SECarryOut") {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return false;
							}else {
								var changeType = e.record.get("changeType");
								if(changeType=='删除') {
									Ext.getCmp('saveStatus').setText('不允许编辑！');
			         	 			return false;
								}else if(e.field == 'dsRequireDesc'||e.field == 'dsRequireRemark'){
			         	 			//控制在弹窗填写
			         	 			return false;
			         	 		}else {
			         	 			Ext.getCmp('saveStatus').setText('正在编辑！');
			         	 		}
							 }
						}else {
							Ext.getCmp('saveStatus').setText('不允许编辑！');
							return false;
						}
						Ext.getCmp('saveStatus').setText('正在编辑！');
	          	 	}
	           }
	    });	
		requireChangeGrid.on('edit',function(editor,e){
		    	var tRecord = e.record; //得到当前行所有数据
	            var tField = e.field; //得到修改列
	            var tValue = e.value; //得到修改列修改后值
	            var id = tRecord.get('id');
	            if(!isNumber(id)){
	            	id = "";
				}
	            var dsRequireNumber = tRecord.get('dsRequireNumber');
	            if(!id&&"dsRequireNumber"!=tField) {//编辑其他字段需要先填DS编号
	            	alert("请先填写DS需求编号！");
                    tRecord.reject();
                    return;
	            }else {
	            	if("dsRequireNumber"==tField&&!tValue){
	            		alert("DS需求编号不能为空!");
						tRecord.reject();
						return;
					}else if("dsRequireNumber"==tField&&tValue==beforeDsNumber){
	            		//ds编号没改不用保存
	            		return;
					}else{
						saveRequireChangeItems(tRecord,id,tField,tValue);
					}
	            }
	            
		 });
	    
		this.items=[requireChangeInfoPanel,requireChangeGrid];
		
		
		this.callParent();
	},//~End of initComponent
	listeners:{
		'afterrender':function(){
			//加载列表
			Ext.getStore('requireChangeStore').load({
				params:{branchId:branchId},
				callback: function(records, operation, success) {
					if(!success){
						 alert('查询需求变更信息失败，请联系管理员！');
					}
				}
			});
		}
	}

});

function disabledButton(){
	if(allowEdit && actKey=="ActivityNode_RequireChange_SECarryOut"){
		return false;
	}else{
		return true;
	}
}

//保存需求变更通知表单信息
function saveRequireChangeHead(key,value){
	Ext.Ajax.request({
		scope:this,
		url: '/Windchill/ptc1/require/saveRequireChangeHead?workItemOid='+workItemOid,
		method:'POST',
		params:{
			branchId:branchId,
			docNumber:docNumber,
			key:key,
			value:value
		},
		success: function(response, opts) {
			var respText = Ext.decode(response.responseText);
			var success = respText['success'];
			var msg = respText['msg'];
			if(!success){
				alert(msg);
			}
		},
	 	failure: function(response, opts) {
				alert('错误：保存失败，请检查网络！');
		}
	});
}

//保存需求变更条目化信息
function saveRequireChangeItems(tRecord,id,tField,tValue) {
	var tempRec= {
			branchId:branchId,//文档docVid
   			id:id, //得到当前行所有数据
     		key:tField, //得到修改列
     		value:tValue, //得到修改列修改后值
   			
	}
	Ext.Ajax.request({
		scope:this,
		url: '/Windchill/ptc1/require/saveRequireChangeItems',
		method:'POST',
		params:{
			updatedRecords:Ext.encode(tempRec)
		},
		success: function(response, opts) {
			var respText = Ext.decode(response.responseText);
			var success = respText['success'];
			var msg = respText['msg'];
			if(!success){
				alert(msg);
			}else {
			    Ext.getCmp('saveStatus').setText('保存成功！');
			}
			refreshRequrieChangeItems();

		},
	 	failure: function(response, opts) {
				alert('错误：保存失败，请检查网络！');
		}
	});
	
}

function refreshRequrieChangeItems() {
	Ext.getStore('requireChangeStore').load({
		params:{branchId:branchId},
		callback: function(records, operation, success) {
 			if(!success){
 				alert('查询信息失败，请联系管理员！');
 			}
 		}
	});
}

//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {
	if(value instanceof Date){ 
		return Ext.Date.format(value,"Y-m-d");  
	}
	return value; 
}

function isNumber( str ) {
	var reg=/^[0-9]+$/;
	return reg.test(str);
}