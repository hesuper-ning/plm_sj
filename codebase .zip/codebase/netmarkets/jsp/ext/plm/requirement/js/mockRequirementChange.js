Ext.define('PLM.view.RequireChangePanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.RequireChangePanel',
	title:'<font style="font-size:18px">需求更改通知单</font>',
	border:false,
	layout:'anchor',
	autoScroll:true,
    autoWidth:true,
 	autoHeight:true,
     collapsible: false,
     id: 'requireChangePanel',
	config: {
		in_objectKey: 'requireChangePanel',
		in_objectDesc: '定制的Form表单',
	},
     fieldDefaults: {
         msgTarget: 'side',
         labelWidth: 75
     },
	initComponent:function(){
    	 var panelType = actKey=="ActivityNode_RequireChange_CreatorSubmit"&&allowEdit ? "textfield":"displayfield";
    	 var panelType2 = actKey=="ActivityNode_RequireChange_CreatorSubmit"&&allowEdit ? "textarea":"displayfield";
    	 var combo = actKey=="ActivityNode_RequireChange_CreatorSubmit"&&allowEdit ? "combo":"displayfield";
    	 //***************加载请求获取变更表单信息**********************
		var me = this;

    	 //***************需求变更信息**********************
    	 var requireChangeInfoPanel =  {
			 xtype: 'form',
			 id: 'mainForm',
			 width: '100%',
			 hideLabel: true,
			 frame: false,
 	    	items:[{
 	    		border: false,
 		    	layout:'hbox',
 		    	align: 'middle',
 				margin:'10 0 0 10',
 				 items:[{
 					 xtype:''+panelType+'',
 					 width:500,
 					 fieldLabel: '<font color="red">*</font>发起人',
 					 id:'att1',
 					 name:'att1',
 					 labelWidth:150,
					 listeners: {
						 blur: function (e) {
							 saveObjectData(Ext.getCmp('requireChangePanel').getIn_objectKey(), Ext.getCmp('requireChangePanel').getIn_objectDesc(), e.id, e.value);
						 }
					 }
 				 },{
 					 xtype:''+panelType+'', 
 					 width:500,
 					 margin:'0 0 0 40',
 					 fieldLabel: '<font color="red">*</font>发起人部门',
 					 name:'att2',
 					 id:'att2',
 					 labelWidth:150,
					 listeners: {
						 blur: function (e) {
							 saveObjectData(Ext.getCmp('requireChangePanel').getIn_objectKey(), Ext.getCmp('requireChangePanel').getIn_objectDesc(), e.id, e.value);
						 }
					 }
 				 }
 				 ]
 		    },{
 		    	border: false,
 		    	layout:'hbox',
 				margin:'10 0 0 10',
 				 items:[{
 					 border: false,
 					 xtype:''+panelType+'',
 					 width:500,
 					 fieldLabel: '<font color="red">*</font>需求变更源',
 					 id:'att3',
 					 name:'att3',
 					 labelWidth:150,
 					 editable:false,
 					 value: '',
					 listeners: {
						 blur: function (e) {
							 saveObjectData(Ext.getCmp('requireChangePanel').getIn_objectKey(), Ext.getCmp('requireChangePanel').getIn_objectDesc(), e.id, e.value);
						 }
					 }
 				 },{
					 border: false,
					 xtype:''+panelType+'',
					 margin:'0 0 0 40',
					 fieldLabel: '<font color="red">*</font>DS需求条目化文档编号',
					 id:'att9',
					 name:'att9',
					 width:500,
					 labelWidth:150,
					 listeners: {
						 blur: function (e) {
							 saveObjectData(Ext.getCmp('requireChangePanel').getIn_objectKey(), Ext.getCmp('requireChangePanel').getIn_objectDesc(), e.id, e.value);
						 }
					 }
				 }
 				 ]
 		    },{
 		    	border: false,
 		    	layout:'hbox',
 		    	align: 'middle',
 				margin:'10 0 0 10',
 				 items:[{
 					 border: false,
 					 xtype:''+panelType2+'',
 					 width:500,
 					 fieldLabel: '<font color="red">*</font>需求变更原因',
 					 id:'att5',
 					 name:'att5',
 					 labelWidth:150,
					 listeners: {
						 blur: function (e) {
							 saveObjectData(Ext.getCmp('requireChangePanel').getIn_objectKey(), Ext.getCmp('requireChangePanel').getIn_objectDesc(), e.id, e.value);
						 }
					 }
 				 },
 				 ]
 		    },{
 			    	layout:'hbox',
 			    	border:false,
 					margin:'10 0 0 10',
 					 items:[{
 						 border: false,
 						 xtype:''+panelType2+'',
 						 fieldLabel: '<font color="red">*</font>需求变更说明',
 						 id:'att6',
 						 name:'att6',
						 width:500,
 						 labelWidth:150,
						 listeners: {
						blur: function (e) {
							saveObjectData(Ext.getCmp('requireChangePanel').getIn_objectKey(), Ext.getCmp('requireChangePanel').getIn_objectDesc(), e.id, e.value);
						}
					}
 					 }
 					 ]
 			    }]
 	    };

     	
     	//********显示值或填写值窗口*********//
    	 
    	 //***********AR需求差异项*************
    	 
		    // create the Data Store
		var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore'
		});
		this.cellEditing = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		
		 
		var requireChangeGrid = Ext.create('Ext.grid.Panel', {
	    	plugins: [this.cellEditing],
	        title: '需求差异项',
	        margin:'20 0 0 0',
	        store:Ext.getStore('mockExampleStore'),
	        id:'requireChangeGrid',
	        //forceFit : true,
	        autoWidth : true,
	       // width:2500,
	        autoScroll:true,
	        region:'center',
			height:400,
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: requireChangeGrid,
							param_objectKey: me.in_objectKey,
							param_objectDesc: me.in_objectDesc
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			selModel: {
				mode: 'MULTI' //可以多选
			},
			
			columns: [
				{xtype: 'rownumberer'},
				{ text: 'id',  dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
				{text: '变更类型',dataIndex: 'data1',width: 100, editor:{
						xtype : 'combo',
						editable : false,
						id:"changeType",
						value: ' ',
						store : [['添加','添加'],['删除', '删除']],
						mode : 'local',
						menuDisabled:true
					} },
				{ text: 'OR需求标题',	dataIndex: 'data2',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'OR需求编号',	dataIndex: 'data3',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DR需求标题',	dataIndex: 'data4',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DR需求编号',	dataIndex: 'data5',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求标题',  dataIndex: 'data6',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求编号',  dataIndex: 'data7',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求描述',  dataIndex: 'data8',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求备注说明',  dataIndex: 'data9',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS构件',  dataIndex: 'data10',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS领域',  dataIndex: 'data11',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS优先级',  dataIndex: 'data12',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS重要性',  dataIndex: 'data13',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS工作量',  dataIndex: 'data14',width:100 ,editor: 'textfield',menuDisabled:true}
			],
			tbar: [{
		            text: '添加',
		            iconCls : 'icon icon-add',
//		            hidden:allowEdit?false:true
		            scope: this,
		        },'&nbsp;', {
				text: '删除',
				iconCls: 'icon icon-delete',
//					hidden:allowEdit?false:true,
				scope: this,
				}]
	    });	
		requireChangeGrid.on('edit',
			function (editor, e) {
				var tRecord = e.record; //得到当前行所有数据
				var tField = e.field; //得到修改列
				var tValue = e.value; //得到修改列修改后值
				var itemId = tRecord.get('id');

				var callbackFn = function () {
					tRecord.commit();
				};
				saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

			});
	    
		this.items=[requireChangeInfoPanel,requireChangeGrid];
		
		
		this.callParent();
	},//~End of initComponent
	listeners:{
		'afterrender': function () {
			Ext.getStore('mockExampleStore').load({
				params: {
					objectKey: Ext.getCmp('requireChangePanel').getIn_objectKey()//表头key
				},
				callback: function (records, operation, success) {
					if (!success) {
						if (typeof (operation.error) == 'string') {
							alert(operation.error);
						} else {
							alert('查询超时！请重试！')
						}
					} else {
						//无数据时自动添加一条空数据
						if (Ext.getStore('mockExampleStore').getCount() == 0) {
							var callbackFn = function () {
								Ext.getStore('mockExampleStore').reload()
							}
							createMockItemData(Ext.getCmp('requireChangePanel').getIn_objectKey()
								, Ext.getCmp('requireChangePanel').getIn_objectDesc, callbackFn);
						}
					}
				}
			});

			// 查询MockExample form表单数据
			Ext.Ajax.request({
				url: '/Windchill/ptc1/mock/getObject',
				params: {
					objectKey: Ext.getCmp('requireChangePanel').getIn_objectKey()
				},
				success: function (response, opts) {
					var obj = Ext.decode(response.responseText);
					if (obj['success']) {
						var mainPanel = Ext.getCmp('mainForm');
						mainPanel.getForm().setValues(obj);
					} else {
						alert(obj['error']);
					}
				},
				failure: function (response, opts) {
					alert('错误：查询信息失败，请检查网络！!');
				}
			}); //~End of Ajax request
		}
	}

});
