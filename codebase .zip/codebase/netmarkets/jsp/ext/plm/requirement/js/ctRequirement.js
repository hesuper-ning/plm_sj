// Ext.require([
// 	'Ext.grid.*',
// 	'Ext.data.*',
// 	'Ext.ux.grid.FiltersFeature',
// 	'Ext.toolbar.Paging',
// 	'Ext.ux.ajax.JsonSimlet',
// 	'Ext.ux.ajax.SimManager',
// 	'Ext.grid.plugin.BufferedRenderer'
// ]);

Ext.define('PLM.view.CtRequirePanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.CtRequirePanel',
	border:false,
	layout:'anchor',
	autoScroll:true,
	autoWidth:true,
	autoHeight:true,
	collapsible: false,
	id: 'ctRequirePanel',
	initComponent:function(){
		var imagePath = "/Windchill/netmarkets/images/";//质量状态照片的路径
		var beforeRdProgress="";
		var beforeCaProgress="";

		var userDisplayName="";
		var isShowAllRequire =false;

		var filters = {
			ftype: 'filters',
			// encode and local configuration options defined previously for easier reuse
			encode: false, // json encode the filter query
			local: true,   // defaults to false (remote filtering)

			// Filters are most naturally placed in the column definition, but can also be
			// added here.
			filters: [
				{
					type: 'boolean',
					dataIndex: 'visible'
				}
			]
		};

		//==============下拉加载项目团队的人===================
		Ext.define('teamMembersModel', {
			extend: 'Ext.data.Model',
			fields: [
				'storeId', 'storeName'
			],
			idProperty: 'id'
		});

		teamMembersStore = new Ext.data.Store({
			storeId:'teamMembersStore',
			model:'teamMembersModel',
			pruneModifiedRecords: true,
			proxy: new Ext.data.HttpProxy({
				url: '/Windchill/ptc1/require/getProjectUser?branchId='+branchId,
				method:'GET',
				reader:{
					type:'json',
					idProperty: 'id',
					rootProperty:'items',
					messageProperty: 'msg'
				}
			}),
			autoLoad: true
		});


		teamMembersStore2 = new Ext.data.Store({
			storeId:'teamMembersStore2',
			model:'teamMembersModel',
			pruneModifiedRecords: true,
			proxy: new Ext.data.HttpProxy({
				url: '/Windchill/ptc1/require/getProjectUser?branchId='+branchId,
				method:'GET',
				reader:{
					type:'json',
					idProperty: 'id',
					rootProperty:'items',
					messageProperty: 'msg'
				}
			}),
			autoLoad: true
		});

		var teamMembersCombo = new Ext.form.field.ComboBox({
			typeAhead: true,
			triggerAction: 'all',
			queryMode: 'local',
			displayField: 'storeName',
			valueField: 'storeId',
			forceSelection:true,
			allowBlank : false,
			anyMatch: true,
			store:teamMembersStore

		});

		var teamMembersCombo2 = new Ext.form.field.ComboBox({
			typeAhead: true,
			triggerAction: 'all',
			queryMode: 'local',
			displayField: 'storeName',
			valueField: 'storeId',
			forceSelection:true,
			allowBlank : false,
			anyMatch: true,
			store:teamMembersStore2

		});

		//========可编辑列头显示控制============
		var redStarFlag = '<font color=red bold>*</font>'; //必填标志
		var blueFlagStart = '<font color=blue bold><b>';
		var blueFlagEnd = '</b></font>';
		//========需求字段定义=============
		var productModel = "产品型号";
		var orRequireTitle = "OR需求标题";
		var orRequireNumber = "OR需求编号";
		var drRequireTitle = "DR需求标题";
		var drRequireNumber = "DR需求编号";
		var dsRequireTitle = "DS需求标题";
		var dsRequireNumber = "DS需求编号";
		var dsRequireDesc = "DS需求描述";
		var dsRequireRemark = "DS需求备注说明";
		var dsComponent = "DS构件";
		var dsDomain = "DS领域";
		var dsPriority = "DS优先级";
		var dsImportance = "DS重要性";
		var isSelfVerify = "是否需要自测报告";
		var dsSelfVerifyReportNumber = "DS自测报告文档编号";
		var rdPersonLiable = "研发责任人";
		var rdPlanTime = "研发计划完成时间";
		var latestPlanTime = "最新计划完成时间";
		var changePlanDesc = "修改计划说明";
		var rdProgress = "研发进度%";
		var rdRemark = "研发备注";
		var rdActualTime = "研发实际完成时间";
		var implementConfirm = "需求实现确认（SE）";
		var implementConfirmRemark = "需求实现确认备注（SE）";
		var caPersonLiable = "验收责任人";
		var caPlanTime = "验收计划时间";
		var caProgress = "验收进度%";
		var isTestCase = "是否有对应测试用例";
		var dsTestCaseNumber = "测试用例文档编号";
		var caActualTime = "验收实际时间";
		var qualityState = "质量状态";
		var testRemark = "测试备注";
		var problemNumber = "转问题编号";

		var orDescribe = "OR描述";
		var drDescribe = "DR描述";

		if(allowEdit) {
			if(actKey=="ActivityNode_Require_CreatorSubmit"||
				actKey=="ActivityNode_Require_CreatorSubmitChange") {
				productModel = redStarFlag+blueFlagStart+productModel+blueFlagEnd;
				orRequireTitle = redStarFlag+blueFlagStart+orRequireTitle+blueFlagEnd;

				orDescribe = redStarFlag+blueFlagStart+orDescribe+blueFlagEnd;
				drDescribe = redStarFlag+blueFlagStart+drDescribe+blueFlagEnd;

				orRequireNumber = redStarFlag+blueFlagStart+orRequireNumber+blueFlagEnd;
				drRequireTitle = redStarFlag+blueFlagStart+drRequireTitle+blueFlagEnd;
				drRequireNumber = redStarFlag+blueFlagStart+drRequireNumber+blueFlagEnd;
				dsRequireTitle = redStarFlag+blueFlagStart+dsRequireTitle+blueFlagEnd;
				dsRequireNumber = redStarFlag+blueFlagStart+dsRequireNumber+blueFlagEnd;
				dsRequireDesc = redStarFlag+blueFlagStart+dsRequireDesc+blueFlagEnd;
				dsRequireRemark = blueFlagStart+dsRequireRemark+blueFlagEnd;
				dsComponent = blueFlagStart+dsComponent+blueFlagEnd;
				dsDomain = redStarFlag+blueFlagStart+dsDomain+blueFlagEnd;
				dsPriority = redStarFlag+blueFlagStart+dsPriority+blueFlagEnd;
				dsImportance = redStarFlag+blueFlagStart+dsImportance+blueFlagEnd;
				isSelfVerify = redStarFlag+blueFlagStart+isSelfVerify+blueFlagEnd;
				isTestCase = redStarFlag+blueFlagStart+isTestCase+blueFlagEnd;
				rdPersonLiable = redStarFlag+blueFlagStart+rdPersonLiable+blueFlagEnd;
				rdPlanTime = redStarFlag+blueFlagStart+rdPlanTime+blueFlagEnd;
				caPersonLiable = redStarFlag+blueFlagStart+caPersonLiable+blueFlagEnd;
				caPlanTime = redStarFlag+blueFlagStart+caPlanTime+blueFlagEnd;
			}else if(actKey=="ActivityNode_Require_AuditByPME"){//PME调整责任人和时间
				rdPersonLiable = redStarFlag+blueFlagStart+rdPersonLiable+blueFlagEnd;
				//rdPlanTime = redStarFlag+blueFlagStart+rdPlanTime+blueFlagEnd;
				latestPlanTime = redStarFlag+blueFlagStart+latestPlanTime+blueFlagEnd;
				changePlanDesc = redStarFlag+blueFlagStart+changePlanDesc+blueFlagEnd;
				caPersonLiable = redStarFlag+blueFlagStart+caPersonLiable+blueFlagEnd;
				caPlanTime = redStarFlag+blueFlagStart+caPlanTime+blueFlagEnd;
			}else if(actKey=="ActivityNode_Require_ConfirmRequireImplement") {//责任人 确认需求实现
				dsSelfVerifyReportNumber = blueFlagStart+dsSelfVerifyReportNumber+blueFlagEnd;
				rdProgress = redStarFlag+blueFlagStart+rdProgress+blueFlagEnd;
				rdRemark = blueFlagStart+rdRemark+blueFlagEnd;
			}else if(actKey=="ActivityNode_Require_ConfirmRequireDevelopment"){//SE 确认需求开发程度
				implementConfirm = redStarFlag+blueFlagStart+implementConfirm+blueFlagEnd;
				implementConfirmRemark = blueFlagStart+implementConfirmRemark+blueFlagEnd;
			}else if(actKey=="ActivityNode_Require_TestValidation"){//测试小组组长 测试验证确认
				dsTestCaseNumber = blueFlagStart+dsTestCaseNumber+blueFlagEnd;
				caProgress = redStarFlag+blueFlagStart+caProgress+blueFlagEnd;
				qualityState = redStarFlag+blueFlagStart+qualityState+blueFlagEnd;
				testRemark = blueFlagStart+testRemark+blueFlagEnd;
			}else if(actKey=="ActivityNode_Require_UpdateProblemListByPQA"){//PQA 更新问题清单
				problemNumber = blueFlagStart+problemNumber+blueFlagEnd;
			}
		}

		//***********需求表单*************

		Ext.define('ctRequireModel', {
			extend: 'Ext.data.Model',
			fields: [
				'id','docBranchId','productModel','orRequireTitle','orRequireNumber','drRequireTitle','drRequireNumber','dsRequireTitle','dsRequireNumber',
				'dsRequireDesc','dsRequireRemark','dsComponent','dsDomain', 'dsPriority','dsImportance','isSelfVerify',
				'dsSelfVerifyReportNumber','dsSelfVerifyReportDocOid','rdPersonLiable','rdPlanTime','rdProgress','rdRemark','rdActualTime',
				'implementConfirm','implementConfirmRemark','caPersonLiable','caPlanTime', 'caProgress','isTestCase','dsTestCaseNumber','dsTestCaseDocOid',
				'caActualTime','qualityState','testRemark','problemNumber','problemStatus','problemLink',
				'changeType','changeDocNumber','changeTime','changeDocOid', 'plusChangeType','latestPlanTime','changePlanDesc'
			],
			idProperty: 'id'
		});

		// create the Data Store
		var ctRequireStore = Ext.create('Ext.data.Store', {
			//pageSize: 50,
			pageSize: 20, // 每页记录数
			model: 'ctRequireModel',
			id:'ctRequireStore',
			pruneModifiedRecords: true,
			proxy: new Ext.data.HttpProxy({
				url: '/Windchill/ptc1/require/getRequire',
				method:'GET',
				reader:{
					type:'json',
					rootProperty: 'items',
					totalProperty: 'totalCount',
					idProperty: 'a',//修改显示重复数据,叠加变更时数据库的id相同
					messageProperty: 'msg'
				}
			}),
			autoLoad:false
		});


		ctRequireStore.on('beforeload', function(store, options) {
			var data = {
				branchId:branchId,
				userDisplayName:userDisplayName,
				isShowAllRequire:isShowAllRequire,
				isPageQuery:isPageQuery,
				actKey:actKey
			};
			Ext.apply(ctRequireStore.proxy.extraParams, data);
		});

		this.cellEditing = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		var record_start = 0;
		var number=0;
		var ctRequireGrid = Ext.create('Ext.grid.Panel', {
			plugins: [this.cellEditing],
			store:Ext.data.StoreManager.lookup('ctRequireStore'),
			id:'ctRequireGrid',
			//forceFit : true,
			autoWidth : true,
			autoScroll:true,
			// autoHeight:true,
			maxHeight: 800, // 设置最大高度为 800 像素
			// height:800,
			// features: [filters],
			viewConfig:{enableTextSelection:true},
//			selModel: {
//				selType: 'cellmodel'
//			},
			selType: 'checkboxmodel',
			listeners: {
				change:'onAllCircuitsChecked'
			},
			columns: [
				Ext.create('Ext.grid.RowNumberer',{width:40}),
				{ text: 'id',  dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
				{ hidden:true,text: '叠加变更类型',	dataIndex: 'plusChangeType',width:100 ,editor: 'textfield',menuDisabled:true},
				{ hidden:true,text: '变更类型', itemId:'changeType',	dataIndex: 'changeType',width:50 ,editor: 'textfield',menuDisabled:true},
				{ hidden:true,text: '变更时间',	itemId:'changeTime', dataIndex: 'changeTime',width:130 ,editor: 'textfield',menuDisabled:true},
				{ hidden:true,text: '变更编号', itemId:'changeNumber',	dataIndex: 'changeDocNumber',width:110 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value) {
							var docLink = "<a href='" + urlPathPrefix +record.get('changeDocOid') +"' target='_blank' >"
								+ value + "</a>";
							return docLink;
						}else {
							return value;
						}
					}},
				{ text: productModel,	dataIndex: 'productModel',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: orRequireTitle,	dataIndex: 'orRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: orRequireNumber,dataIndex: 'orRequireNumber',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},

				{ text: orDescribe,dataIndex: 'orDescribe',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},

				{ text: drRequireTitle,	dataIndex: 'drRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: drRequireNumber,dataIndex: 'drRequireNumber',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},

				{ text: drDescribe,dataIndex: 'drDescribe',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},

				{ text: dsRequireTitle,	dataIndex: 'dsRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: dsRequireNumber,  dataIndex: 'dsRequireNumber',menuDisabled:true,width:100,editor: 'textfield',
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';

						if(value==undefined) {
							value="";
						}
						return "<a href='#' onclick='openRequireDetail("+record.get('id')+")'>"+value+"</a>";
					}},

				{ text: dsRequireDesc,	dataIndex: 'dsRequireDesc',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = Ext.String.format('data-qtip=\'{0}\'',value);
						return value;
					}
				},
				{ text: dsRequireRemark, dataIndex: 'dsRequireRemark',width:150 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: dsComponent,	dataIndex: 'dsComponent',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: dsDomain,dataIndex: 'dsDomain',width:80 ,editor:{
						xtype : 'combo',
						editable : false,
						typeAhead:false,
						value: ' ',
						store : [['结构','结构'],['硬件', '硬件'],['软件','软件'],['中试','中试'],['认证','认证']],
						mode : 'local'
					},renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					},menuDisabled:true
				},
				{ text: dsPriority,dataIndex: 'dsPriority',width:100 ,editor:{
						xtype : 'combo',
						editable : false,
						typeAhead:false,
						value: ' ',
						store : [['紧急','紧急'],['高', '高'],['中','中'],['低','低']],
						mode : 'local'
					},renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					},menuDisabled:true
				},
				{ text: dsImportance,dataIndex: 'dsImportance',width:100 ,editor:{
						xtype : 'combo',
						editable : false,
						typeAhead:false,
						value: ' ',
						store : [['必须','必须'],['重要', '重要'],['最好有','最好有']],
						mode : 'local'
					},renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					},menuDisabled:true
				},
				{ text: isSelfVerify,dataIndex: 'isSelfVerify',width:160 ,editor:{
						xtype : 'combo',
						editable : false,
						typeAhead:false,
						value: ' ',
						store : [['Y','是'],['N', '否']],
						mode : 'local'
					},renderer: function(value,metaData,record,row,col,store){
						if(value=="Y") {
							value="是";
						}else if(value=="N") {
							value="否";
						}
						return value;
					},menuDisabled:true
				},
				{ text: dsSelfVerifyReportNumber,dataIndex: 'dsSelfVerifyReportNumber',width:188 ,menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						if(value) {
							var docLink = "<a href='" + urlPathPrefix +record.get('dsSelfVerifyReportDocOid') +"' target='_blank' >"
								+ value + "</a>";
							return docLink;
						}else {
							return value;
						}
					},editor:'textfield'},
				{ text: rdPersonLiable,dataIndex: 'rdPersonLiable',width:100 ,editor: teamMembersCombo,menuDisabled:true,filter:{type:"string"},
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: rdPlanTime,dataIndex: 'rdPlanTime',width:160 ,editor: {xtype:'datefield',format:'Y-m-d'},menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return selfDateFormat(value);
					}
				},
				{ text: latestPlanTime,dataIndex: 'latestPlanTime',width:160 ,editor: {xtype:'datefield',format:'Y-m-d'},menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return selfDateFormat(value);
					}
				},
				{ text: changePlanDesc,	dataIndex: 'changePlanDesc',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: rdProgress,dataIndex: 'rdProgress',width:100 ,editor: {xtype:'numberfield',minValue:'0',maxValue:'100'},menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value==0&&record.get('qualityState')=="") {
							value ="";
						}
						return value;
					}
				},
				{ text: rdRemark,	dataIndex: 'rdRemark',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: rdActualTime,dataIndex: 'rdActualTime',width:160 ,menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return selfDateFormat(value);
					}

				},
				{ text: implementConfirm,dataIndex: 'implementConfirm',width:180 ,editor:{
						xtype : 'combo',
						editable : false,
						typeAhead:false,
						value: ' ',
						store : [['需求已开发','需求已开发'],['需求未开发', '需求未开发'],['带风险通过','带风险通过']],
						mode : 'local'
					},renderer: function(value,metaData,record,row,col,store){
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					},menuDisabled:true
				},
				{ text: implementConfirmRemark,	dataIndex: 'implementConfirmRemark',width:200 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: caPersonLiable,dataIndex: 'caPersonLiable',width:160 ,editor: teamMembersCombo2,menuDisabled:true,filter:{type:"string"},
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: caPlanTime,dataIndex: 'caPlanTime',width:160 ,editor: {xtype:'datefield',format:'Y-m-d'},menuDisabled:true,renderer:selfDateFormat},
				{ text: caProgress,dataIndex: 'caProgress',width:150 ,editor: {xtype:'numberfield',minValue:'0',maxValue:'100',},
					renderer: function(value,metaData,record,row,col,store){
						if(value==0) {
							value ="";
						}
						return value;
					},menuDisabled:true},
				{ text: isTestCase,dataIndex: 'isTestCase',width:200 ,editor:{
						xtype : 'combo',
						editable : false,
						typeAhead:false,
						value: '',
						store : [['Y','是'],['N', '否']],
						mode : 'local'
					},renderer: function(value,metaData,record,row,col,store){
						if(value=="Y") {
							value="是";
						}else if(value=="N") {
							value="否";
						}
						return value;
					},menuDisabled:true
				},
				{ text: dsTestCaseNumber,dataIndex: 'dsTestCaseNumber',width:200 ,menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';

						if(value) {
							var docLink = "<a href='" + urlPathPrefix +record.get('dsTestCaseDocOid') +"' target='_blank' >"
								+ value + "</a>";
							return docLink;
						}else {
							return value;
						}
					},editor:'textfield'},
				{ text: caActualTime,dataIndex: 'caActualTime',width:120 ,editor: {xtype:'datefield',format:'Y-m-d'},menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return selfDateFormat(value);
					}
				},
				{ text: qualityState,dataIndex: 'qualityState',width:80 , editor:{
						xtype : 'combo',
						editable : false,
						typeAhead:false,
						id:"qualityState",
						value: ' ',
						store : [
							['红','<img src="'+imagePath+'red_16x16.gif">'],
							['黄', '<img src="' + imagePath +'yellow_16x16.gif">'],
							// ['蓝', '<img src="' + imagePath +'blue_16x16.gif">'],
							['绿', '<img src="' + imagePath +'green_16x16.gif">'],
							['', '(空)']
						],
						mode : 'local'

					} ,renderer: function(value,metaData,record,row,col,store){

						metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode("<font color='green'>绿（测试通过）</font><br><font color='orange'> 黄（有条件测试通过）</font><br> <font color='red'> 红（测试未通过）</font>") + '"';

						if("红"==value) {
							var img = "<img src='" + imagePath +"red_16x16.gif'>";
							return img;
						}else if("黄"==value) {
							var img = "<img src='" + imagePath +"yellow_16x16.gif'>";
							return img;
						}else if("绿"==value) {
							var img = "<img src='" + imagePath +"green_16x16.gif'>";
							return img;
						}else {
							return '';
						}
					},menuDisabled:true
				},
				{ text: testRemark,dataIndex: 'testRemark',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				},
				{ text: problemNumber,dataIndex: 'problemNumber',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
						metaData.tdAttr = 'data-qtip="' + value +'"';
						var problemLink = record.get('problemLink');
						if(problemLink){
							return  problemLink;
						}
						return value;
					}
				},
				{ text: '问题状态',dataIndex: 'problemStatus',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = 'data-qtip="' + value +'"';
						return value;
					}
				}
			],
			bbar: Ext.create('Ext.PagingToolbar', {
				store: Ext.data.StoreManager.lookup('ctRequireStore'),
				displayInfo: true,
				displayMsg: '当前显示 {0} - {1} ，共 {2}',
				emptyMsg: "查询结果为空",
				items:[{
					text: '查询全部',
					scope: this,
					id:'queryAll',
					handler:function(){
						isPageQuery=false;
						ctRequireStore.pageSize=ctRequireStore.getTotalCount();
						ctRequireStore.currentPage = 1;
						refreshRequireStore();
						Ext.getCmp("queryAll").hide();
						Ext.getCmp("pageQuery").show();
					}
				},{
					text: '分页查询',
					scope: this,
					id:'pageQuery',
					hidden:true,
					handler:function(){
						isPageQuery=true;
						ctRequireStore.pageSize=20;
						refreshRequireStore();
						Ext.getCmp("pageQuery").hide();
						Ext.getCmp("queryAll").show();
					}
				}]
			}),//~End bbar
			tbar: ['&nbsp;',
				{
					xtype:'filefield',
					buttonOnly: true,
					hidden:allowEdit&&allowImport?false:true,
					id:'upload1',
					hideLabel: true,
					buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>Excel导入</span>',
					allowBlank: false,
					scope: this,
					listeners:{
						'change':function(fb,newValue,oldValue,opts){
							if(!newValue){
								return;
							}
							var file = document.querySelector('[id=upload1-button-fileInputEl]');
							var formData = new FormData();
							formData.append('upload1-button-fileInputEl', file.files[0]);
							fb.reset();//清空表单的值
							var myMask = new Ext.LoadMask({
								msg: '正在导入数据，请稍候......',
								target: ctRequireGrid
							});
							myMask.show();
							$.ajax({
								url: '/Windchill/ptc1/require/importRequireItems?branchId='+branchId+'&workItemOid='+workItemOid,
								type: 'POST',
								cache: false,
								data: formData,
								processData: false,
								contentType: false
							}).done(function(res) {
								myMask.hide();
								var obj = Ext.decode(res);
								var success = obj['success'];
								var msg = obj['msg'];
								if(!success){
									alert(msg);
								}else {
									refreshRequireStore();
								}
							}).fail(function(res) {
								myMask.hide();
								alert('上传失败！') ;
							});
						}
					}

				},'&nbsp;',
				{
					text: '下载模板',
					iconCls : 'icon icon-download',
					scope: this,
					hidden:allowEdit&&allowImport?false:true,
					handler : function(){
						window.location.href =
							'/Windchill/ptc1/require/exportRequireTemplate';

					}
				},'&nbsp;',{
					text: '导出',
					iconCls : 'icon icon-store-export',
					scope: this,
					hidden:readOnly?false:true,
					handler : function(){
						window.location.href =
							'/Windchill/ptc1/require/exportRequire?branchId='+branchId;

					}
				},'&nbsp;',{
					text: '显示个人',
					scope: this,
					id:'displayUser',
					handler:function(){
						userDisplayName=userName;
						refreshRequireStore();
						Ext.getCmp("displayUser").hide();
						Ext.getCmp("displayAll").show();
					}
				},{
					text: '显示全部',
					scope: this,
					id:'displayAll',
					hidden:true,
					handler:function(){
						userDisplayName="";
						refreshRequireStore();
						Ext.getCmp("displayUser").show();
						Ext.getCmp("displayAll").hide();
					}
				},{
					text: '显示最新版本',
					scope: this,
					id:'displayLatestVersion',
					hidden:true,
					handler:function(){
						isShowAllRequire = false;
						refreshRequireStore();
						ctRequireGrid.down('#changeType').hide();
						ctRequireGrid.down('#changeTime').hide();
						ctRequireGrid.down('#changeNumber').hide();
						Ext.getCmp("displayAllVersion").show();
						Ext.getCmp("displayLatestVersion").hide();
						//最新版本只保留变更类型为空和添加 的，过滤掉删除的    后台过滤
						// ctRequireGrid.getStore().filterBy(function(record, id) {
						// 	if (!record.get('changeType')||record.get('changeType') == ''
						// 		||record.get('changeType') == '添加') {
						// 		//判断是否是上一次变更
						// 		if(!record.get('plusChangeType')||record.get('plusChangeType')=='') {
						// 			return true;
						// 		}
						// 	} else
						// 		return false;
						// });
					}
				},{
					text: '显示全部版本',
					scope: this,
					id:'displayAllVersion',
					handler:function(){
						isShowAllRequire = true;
						refreshRequireStore();
						ctRequireGrid.down('#changeType').show();
						ctRequireGrid.down('#changeTime').show();
						ctRequireGrid.down('#changeNumber').show();
						Ext.getCmp("displayAllVersion").hide();
						Ext.getCmp("displayLatestVersion").show();
						ctRequireStore.clearFilter(true);
					}
				},{
					text:'',
					id:'saveStatus',
					disabled:true
				}],
			listeners:{
				'beforeedit': function  (editor,  e,  eOpts)  {
					if(allowEdit) {
						var rdPersonLiable = e.record.get("rdPersonLiable");
						var caPersonLiable = e.record.get("caPersonLiable");
						beforeRdProgress = e.record.get("rdProgress");
						beforeCaProgress = e.record.get("caProgress");

						//创建人  可编辑字段
						if(actKey=="ActivityNode_Require_CreatorSubmit"||actKey=="ActivityNode_Require_CreatorSubmitChange") {
							if(e.field!="orRequireTitle"&&e.field!="orRequireNumber"
								&&e.field!="drRequireTitle"&&e.field!="drRequireNumber"
								&&e.field!="dsRequireTitle"&&e.field!="dsRequireNumber"
								&&e.field!="dsRequireDesc"&&e.field!="dsRequireRemark"
								&&e.field!="dsComponent"&&e.field!="dsDomain"
								&&e.field!="dsPriority"&&e.field!="dsImportance"
								&&e.field!="isSelfVerify"&&e.field!="isTestCase"
								&&e.field!="rdPersonLiable"&&e.field!="caPersonLiable"
								&&e.field!="rdPlanTime"&&e.field!="caPlanTime"
								&&e.field!="productModel"
								&&e.field!="orDescribe"&&e.field!="drDescribe"
							) {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return false;
							}else {
								/*
								if(actKey=="ActivityNode_Require_CreatorSubmit"&&e.field=="isTestCase"){
									Ext.getCmp('saveStatus').setText('不允许编辑！');
									return false;
								}*/

								//判断是否变更的数据
								if (!e.record.get('changeType')||e.record.get('changeType') == ''||e.record.get('changeType') == '添加') {
									//判断是否是上一次变更
									if(e.record.get('plusChangeType')&&e.record.get('plusChangeType')!='') {
										Ext.getCmp('saveStatus').setText('不允许编辑！');
										return false;
									}else {
										Ext.getCmp('saveStatus').setText('正在编辑！');
									}
								}else {
									Ext.getCmp('saveStatus').setText('不允许编辑！');
									return false;
								}
							}
						}else if(actKey=="ActivityNode_Require_AuditByPME") {
							if(e.field!="rdPersonLiable"&&e.field!="caPersonLiable"
								&&e.field!="latestPlanTime"&&e.field!="caPlanTime"&&e.field!="changePlanDesc") {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return false;
							}else {
								//判断是否变更的数据
								if (!e.record.get('changeType')||e.record.get('changeType') == ''||e.record.get('changeType') == '添加') {
									//判断是否是上一次变更
									if(e.record.get('plusChangeType')&&e.record.get('plusChangeType')!='') {
										Ext.getCmp('saveStatus').setText('不允许编辑！');
										return false;
									}else {
										Ext.getCmp('saveStatus').setText('正在编辑！');
									}
								}else {
									Ext.getCmp('saveStatus').setText('不允许编辑！');
									return false;
								}
							}
						}else if(actKey=="ActivityNode_Require_ConfirmRequireImplement") {
							if(e.field!="dsSelfVerifyReportNumber"&&e.field!="rdProgress"
								&&e.field!="rdRemark") {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return false;
							}else {
								if(e.record.get('caProgress') == '100') {
									//验收进度100%后不允许修改
									Ext.getCmp('saveStatus').setText('验收已完成，不允许编辑！');
									return false;
								}/*else if(e.record.get('implementConfirm') == '需求已开发'||e.record.get('implementConfirm') == '带风险通过') {
                                    //需求已开发或带风险通过 责任人不能再编辑
                                    Ext.getCmp('saveStatus').setText('需求已开发或带风险通过，不允许编辑！');
                                    return false;
                                }*/else{
									if(userName!=rdPersonLiable) {
										Ext.getCmp('saveStatus').setText('只能编辑自己负责的行！');
										return false;
									}else{
										//判断是否变更的数据
										if (!e.record.get('changeType')||e.record.get('changeType') == ''||e.record.get('changeType') == '添加') {
											//判断是否是上一次变更
											if(e.record.get('plusChangeType')&&e.record.get('plusChangeType')!='') {
												Ext.getCmp('saveStatus').setText('不允许编辑！');
												return false;
											}else {
												Ext.getCmp('saveStatus').setText('正在编辑！');
											}
										}else {
											Ext.getCmp('saveStatus').setText('不允许编辑！');
											return false;
										}
									}
								}
							}
						}else if(actKey=="ActivityNode_Require_ConfirmRequireDevelopment") {
							if(e.field!="implementConfirm"&&e.field!="implementConfirmRemark"
								) {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return false;
							}else {
								//判断是否变更的数据
								if (!e.record.get('changeType')||e.record.get('changeType') == ''||e.record.get('changeType') == '添加') {
									//判断是否是上一次变更
									if(e.record.get('plusChangeType')&&e.record.get('plusChangeType')!='') {
										Ext.getCmp('saveStatus').setText('不允许编辑！');
										return false;
									}else {
										// if(e.record.get('rdProgress')!=100) {
										// 	//判断责任人是否已经填写
										// 	Ext.getCmp('saveStatus').setText('研发进度未达到100%，不允许编辑！');
										// 	return false;
										// }else {
											Ext.getCmp('saveStatus').setText('正在编辑！');
										// }
									}
								}else {
									Ext.getCmp('saveStatus').setText('不允许编辑！');
									return false;
								}
							}
						}else if(actKey=="ActivityNode_Require_TestValidation") {
							if(e.field!="dsTestCaseNumber" && e.field!="caProgress" && e.field!="qualityState"&&e.field!="testRemark") {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return false;
							}else {
								if(userName!=caPersonLiable) {
									Ext.getCmp('saveStatus').setText('只允许编辑自己负责的行！');
									return false;
								}else {
									//判断是否变更的数据
									if (!e.record.get('changeType')||e.record.get('changeType') == ''||e.record.get('changeType') == '添加') {
										//判断是否是上一次变更
										if(e.record.get('plusChangeType')&&e.record.get('plusChangeType')!='') {
											Ext.getCmp('saveStatus').setText('不允许编辑！');
											return false;
										}else {
											Ext.getCmp('saveStatus').setText('正在编辑！');
										}
									}else {
										Ext.getCmp('saveStatus').setText('不允许编辑！');
										return false;
									}
								}
							}
						}else if(actKey=="ActivityNode_Require_UpdateProblemListByPQA"){
							if(e.field!="problemNumber") {
								Ext.getCmp('saveStatus').setText('不允许编辑！');
								return false;
							}else {
								//判断是否变更的数据
								if (!e.record.get('changeType')||e.record.get('changeType') == ''||e.record.get('changeType') == '添加') {
									//判断是否是上一次变更
									if(e.record.get('plusChangeType')&&e.record.get('plusChangeType')!='') {
										Ext.getCmp('saveStatus').setText('不允许编辑！');
										return false;
									}else {
										Ext.getCmp('saveStatus').setText('正在编辑！');
									}
								}else {
									Ext.getCmp('saveStatus').setText('不允许编辑！');
									return false;
								}
							}
						}else {
							Ext.getCmp('saveStatus').setText('不允许编辑！');
							return false;
						}
					 }else {
						Ext.getCmp('saveStatus').setText('不允许编辑！');
						return false;
					}
					Ext.getCmp('saveStatus').setText('正在编辑！');
				}
			}
		});
		ctRequireGrid.on('edit',function(editor,e){
			var tRecord = e.record; //得到当前行所有数据
			var tField = e.field; //得到修改列
			var tValue = e.value; //得到修改列修改后值
			var id = tRecord.get('id');

			if(e.field=="rdProgress"&&e.value==beforeRdProgress) {
				tRecord.commit();
				return;
			}
			if(e.field=="caProgress"&&e.value==beforeCaProgress) {
				tRecord.commit();
				return;
			}

			//除“调整责任人与计划完成时间”节点外当“研发计划时间”或“验收计划时间”被修改时同步修改用于校验这两个时间是否修改的值
			if(e.field=="latestPlanTime"&&actKey!="ActivityNode_Require_AuditByPME"){
				saveRequireItem(id,"rdActualTimeBackups",tValue,tRecord);
			}
			if(e.field=="caPlanTime"&&actKey!="ActivityNode_Require_AuditByPME"){
				saveRequireItem(id,"caPlanTimeBackups",tValue,tRecord);
			}

			saveRequireItem(id,tField,tValue,tRecord);
		});

		//====================开始 需求版本记录===============================
		Ext.define('RequireChangeDocModel', {
			extend: 'Ext.data.Model',
			fields: [
				'docNumber','docName','docOid','docCreator','docEffectDate'
			],
			idProperty: 'docNumber'
		});

		// create the Data Store
		this.requireChangeDocStore = Ext.create('Ext.data.Store', {
			//pageSize: 50,
			model: 'RequireChangeDocModel',
			id:'requireChangeDocStore',
			pruneModifiedRecords: true,
			proxy: new Ext.data.HttpProxy({
				url: '/Windchill/ptc1/require/getRequireChangeDocs?branchId='+branchId,
				method:'GET',
				reader:{
					type:'json',
					rootProperty: 'items',
					totalProperty: 'totalCount',
					idProperty: 'id',
					messageProperty: 'msg'
				}
			}),
			autoLoad:true
		});

		var requireChangeDocGrid = Ext.create('Ext.grid.Panel', {
			title: '变更文档列表',
			store:Ext.data.StoreManager.lookup('requireChangeDocStore'),
			id:'requireChangeDocGrid',
			//forceFit : true,
			autoWidth : true,
			autoScroll:true,
			height:200,
			viewConfig:{enableTextSelection:true},
			columns: [
				Ext.create('Ext.grid.RowNumberer'),
				{ text: '变更文档编号',dataIndex: 'docNumber',width:130 ,menuDisabled:true,renderer: function(value,metaData,record,row,col,store){
						if(value) {
							var docLink = "<a href='" + urlPathPrefix +record.get('docOid') +"' target='_blank' >"
								+ value + "</a>";
							return docLink;
						}else {
							return value;
						}
					}},
				{ text: '变更文档名称',dataIndex: 'docName',width:130,menuDisabled:true},
				{ text: '变更文档创建者',dataIndex: 'docCreator',width:100,menuDisabled:true},
				{ text: '查看变更数据',dataIndex: 'search',width:130 ,menuDisabled:true,
					renderer:function(value, metaData, record, rowIndex, colIndex, store){
						var docNumber = record.get("docNumber");
						docNumber = '"'+docNumber+'"';
						var str = "<a href='javascript:;' title='查看变更数据' onclick='getRequireHistory("+docNumber+")'>查看变更数据</a>";
						return str;
					}
				},
				{ text: '变更生效时间',dataIndex: 'docEffectDate',width:150,menuDisabled:true}
			]
		});

		Ext.define('RequireHistoryModel', {
			extend: 'Ext.data.Model',
			fields: [
				'id','changeType','orRequireTitle','orRequireNumber','drRequireTitle','drRequireNumber',
				'dsRequireTitle','dsRequireNumber','dsRequireDesc','dsRequireRemark','dsComponent','dsDomain',
				'dsPriority','dsImportance'
			],
			idProperty: 'id'
		});

		// create the Data Store
		this.requireHistoryStore = Ext.create('Ext.data.Store', {
			//pageSize: 50,
			model: 'RequireHistoryModel',
			id:'requireHistoryStore',
			pruneModifiedRecords: true,
			proxy: new Ext.data.HttpProxy({
				url: '/Windchill/ptc1/require/getRequireHistory',
				method:'GET',
				reader:{
					type:'json',
					rootProperty: 'items',
					totalProperty: 'totalCount',
					idProperty: 'id',
					messageProperty: 'msg'
				}
			}),
			autoLoad:false
		});

		var requireHistoryGrid = Ext.create('Ext.grid.Panel', {
			title: '当次变更记录',
			store:Ext.data.StoreManager.lookup('requireHistoryStore'),
			id:'requireHistoryGrid',
			//forceFit : true,
			autoWidth : true,
			autoScroll:true,
			height:400,
			viewConfig:{enableTextSelection:true},
			columns: [
				// Ext.create('Ext.grid.RowNumberer'),
				Ext.create('Ext.grid.RowNumberer',{width:40}),
				{ text: '变更类型',	dataIndex: 'changeType',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'OR需求标题',	dataIndex: 'orRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'OR需求编号',	dataIndex: 'orRequireNumber',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DR需求标题',	dataIndex: 'drRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DR需求编号',	dataIndex: 'drRequireNumber',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求标题',  dataIndex: 'dsRequireTitle',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求编号',  dataIndex: 'dsRequireNumber',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求描述',  dataIndex: 'dsRequireDesc',width:100 ,editor: 'textfield',menuDisabled:true,
					renderer: function(value,metaData,record,row,col,store){
						if(value)
							metaData.tdAttr = Ext.String.format('data-qtip=\'{0}\'',value);
						return value;
					}},
				{ text: 'DS需求备注说明',  dataIndex: 'dsRequireRemark',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS构件',  dataIndex: 'dsComponent',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS领域',  dataIndex: 'dsDomain',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS优先级',  dataIndex: 'dsPriority',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS重要性',  dataIndex: 'dsImportance',width:100 ,editor: 'textfield',menuDisabled:true}
			]});

		//需求变更版本分页
		var requireVersionPanel = Ext.create('Ext.panel.Panel',{
			items:[
				requireChangeDocGrid,
				requireHistoryGrid
			]
		});

		//====================结束  需求版本记录===============================

/////////////////////////Main Panel items//////////////////////////////////
		this.items=[{
			xtype:'tabpanel',
			height: '100%',
			header: false,
			collapsible: true,
			split: true,
			activeTab: 0,
			items: [{
				xtype:'panel',
				title:'需求计划表',
				hidden:false,
				items:[ctRequireGrid]
			},{
				xtype:'panel',
				title:'需求版本记录',
				hidden:false,
				items:[requireVersionPanel]
			}]
		}//~end of tabpanel
		];//~end of this.items


		this.callParent();
	},//~End of initComponent
	listeners:{
		'afterrender':function(){
			//加载列表
			Ext.getStore('ctRequireStore').load({
				params:{branchId:branchId,actKey:actKey},
				callback: function(records, operation, success) {
					if(!success){
						alert('查询需求条目化信息失败，请联系管理员！'+operation.getError());
					}else {
						if(allowImport) {
							Ext.getCmp("upload1").enable();
						}else {
							Ext.getCmp("upload1").disable();
						}

						//查询所有版本默认显示最新版本，只保留变更类型为空和添加的，过滤掉删除的  后台过滤
						// Ext.getCmp('ctRequireGrid').getStore().filterBy(function(record, id) {
						// 	if (!record.get('changeType')||record.get('changeType') == ''||record.get('changeType') == '添加') {
						// 		//判断是否是上一次变更
						// 		if(!record.get('plusChangeType')||record.get('plusChangeType')=='') {
						// 			return true;
						// 		}
						// 	} else
						// 		return false;
						// });
					}
				}
			});


		}
	}

});


//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

	if(value instanceof Date){
		return Ext.Date.format(value,"Y-m-d");
	}
	return value;
}

function openRequireDetail(id) {

	var requireDetailWin = Ext.create('Ext.Window', {
		title: '需求基本信息',
		width: 800,
		//height: 300,
		autoHeight : true,
		closeAction: 'destroy',
		//closable:false,
		constrain: true,
		modal:true,

		items:[{
			//xtype:'panel',
			//html:'test'
			xtype: 'RequireDetailsPanel',
			param_id:id,
		}]
	});
	requireDetailWin.show();
}

function refreshRequireStore(){
	Ext.getStore('ctRequireStore').load({
		params:{branchId:branchId},
		callback: function(records, operation, success) {
			if(!success){
				alert('查询信息失败，请联系管理员！');
			}else {
				if(allowImport) {
					Ext.getCmp("upload1").enable();
				}else {
					Ext.getCmp("upload1").disable();
				}
			}
		}
	});
}

function saveRequireItem(id,tField,tValue,tRecord) {
	var tempRec= {
		branchId:branchId,//文档vid
		id:id, //得到当前行所有数据
		key:tField,
		value:tValue
	}
	Ext.Ajax.request({
		scope:this,
		url: '/Windchill/ptc1/require/saveRequireItem?workItemOid='+workItemOid,
		params:{
			updatedRecords:Ext.encode(tempRec)
		},
		success: function(response, opts) {
			var obj = Ext.decode(response.responseText);
			if(obj['success']){
				if(id!=""&&id!=undefined) {
					var result = obj['result'];
					//设置完成时间
					if(tField=="caProgress") {
						tRecord.set("caActualTime",result);
						/*var productModel = tRecord.get("productModel");
						var rec=Ext.getCmp("ctRequireGrid").getStore().queryRecords('productModel',productModel);
						if(rec){
							for (var i = 0;i < rec.length;i++){
								var record = rec[i];
								record.set("caProgress",tValue);
								record.set("caActualTime",result);
								record.commit();
							}
						}*/
					}else if(tField=="rdProgress") {
						tRecord.set("rdActualTime",result);
					}else if(tField=="caPersonLiable"){
						/*var productModel = tRecord.get("productModel");
						var rec=Ext.getCmp("ctRequireGrid").getStore().queryRecords('productModel',productModel);
						if(rec){
							for (var i = 0;i < rec.length;i++){
								var record = rec[i];
								record.set("caPersonLiable",tValue);
								record.commit();
							}
						}*/
					}else if(tField=="problemNumber"){
						tRecord.set("problemStatus",result);
					}
					Ext.getCmp('saveStatus').setText('保存成功！');
					tRecord.commit();
				}else {
					refreshRequireStore();
				}
				Ext.getCmp('saveStatus').setText('保存成功！');
			}else{
				Ext.getCmp('saveStatus').setText('保存失败！');
				tRecord.reject();
				alert(obj['msg']);
			}
		},
		failure: function(response, opts) {
			alert('错误：保存需求信息失败，请检查网络！');
		}
	}); //~End of Ajax request
}

function getRequireHistory(docNumber) {
	Ext.getStore('requireHistoryStore').load({
		params:{branchId:branchId,docNumber:docNumber},
		callback: function(records, operation, success) {
			if(!success){
				alert('查询信息失败，请联系管理员！');
			}
		}
	});
}

