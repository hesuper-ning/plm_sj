Ext.require([
    'Ext.grid.*',
    'Ext.data.*',
    'Ext.ux.grid.FiltersFeature',
    'Ext.toolbar.Paging',
    'Ext.ux.ajax.JsonSimlet',
    'Ext.ux.ajax.SimManager',
    'Ext.grid.plugin.BufferedRenderer'
]);

Ext.define('PLM.view.CtRequirePanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.CtRequirePanel',
	border:false,
	layout:'anchor',
	autoScroll:true,
    autoWidth:true,
 	autoHeight:true,
    collapsible: false,
	config: {
		in_objectKey: 'RequirePanel',
		in_objectDesc: '定制的Form表单',
		in_objectKey1: 'RequirePanel1',
		in_objectDesc1: '定制的Form表单',
		in_objectKey2: 'RequirePanel2',
		in_objectDesc2: '定制的Form表单',
	},
    id: 'ctRequirePanel',
	initComponent:function(){
		var imagePath = "/Windchill/netmarkets/images/";//质量状态照片的路径
		var beforeRdProgress="";
		var beforeCaProgress="";
		var me = this;
		var userDisplayName="";
		var isShowAllRequire =false;

		var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore'
		});

		var mockExampleStore1 = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore1'
		});

		var mockExampleStore2 = Ext.create('PLM.store.MockItemStore', {
			id: 'mockExampleStore2'
		});


	    
	  //========可编辑列头显示控制============
		   
		this.cellEditing = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		var record_start = 0;
		var number=0;
	    var requireGrid = Ext.create('Ext.grid.Panel', {
	    	plugins: [this.cellEditing],
	        store:Ext.getStore('mockExampleStore'),
	        id:'requireGrid',
	        //forceFit : true,
	        autoWidth : true,
	        autoScroll:true,
			height:400,
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: requireGrid,
							param_objectKey: me.in_objectKey,
							param_objectDesc: me.in_objectDesc
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			// selType: 'checkboxmodel',

//			selModel: {
//				selType: 'cellmodel'
//			},
			selType: 'checkboxmodel',

			listeners: {
                change:'onAllCircuitsChecked'
                },
			columns: [
				Ext.create('Ext.grid.RowNumberer',{width:40}),
				{ text: 'id',  dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
				{  text: '产品型号',	dataIndex: 'data26',width:100 ,editor: 'textfield',menuDisabled:true},
				{  text: 'OR需求编号',	dataIndex: 'data2',width:100 ,editor: 'textfield',menuDisabled:true},
				{  text: 'OR需求标题',	dataIndex: 'data1',width:100 ,editor: 'textfield',menuDisabled:true},
				{  text: 'DR需求编号',	dataIndex: 'data3',width:100 ,editor: 'textfield',menuDisabled:true},
				{  text: 'DR需求标题',	dataIndex: 'data4',width:100 ,editor: 'textfield',menuDisabled:true},
				{  text: 'DS需求编号',	dataIndex: 'data5',width:100 ,editor: 'textfield',menuDisabled:true},
				{  text: 'DS需求标题',	dataIndex: 'data6',width:100 ,editor: 'textfield',menuDisabled:true},
				{  text: 'DS需求描述',	dataIndex: 'data7',width:130 ,editor: 'textfield',menuDisabled:true},
				{text: 'DS需求备注说明', dataIndex: 'data8', width: 100, editor: 'textfield', menuDisabled: true},
				{text: 'DS构件', dataIndex: 'data9', width: 120, editor: 'textfield', menuDisabled: true},
				{text: 'DS领域', dataIndex: 'data10', width: 80, editor: 'textfield', menuDisabled: true},
				{text: 'DS优先级', dataIndex: 'data11', width: 80, editor: 'textfield', menuDisabled: true},
				{text: 'DS重要性', dataIndex: 'data12', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '项目阶段', dataIndex: 'data13', width: 80, editor: 'textfield', menuDisabled: true},
				{text: 'DS工作量', dataIndex: 'data14', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '是否自验报告', dataIndex: 'data15', width: 80, editor: 'textfield', menuDisabled: true},
				{text: 'DS自验报告文档编号', dataIndex: 'data16', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '研发责任人', dataIndex: 'data17', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '研发计划时间', dataIndex: 'data18', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '研发进度', dataIndex: 'data19', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '研发备注', dataIndex: 'data20', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '研发实际时间', dataIndex: 'data21', width: 80, editor: 'textfield', menuDisabled: true},
				//modify by lcd 21-07-07
				// {text: '验收责任人', dataIndex: 'data22', width: 80, editor: 'textfield', menuDisabled: true},
				// {text: '验收计划时间', dataIndex: 'data23', width: 80, editor: 'textfield', menuDisabled: true},
				// {text: '验收进度', dataIndex: 'data24', width: 80, editor: 'textfield', menuDisabled: true},
				// {text: '是否测试用例', dataIndex: 'data25', width: 80, editor: 'textfield', menuDisabled: true},
				// {text: 'DS测试用例文档编号', dataIndex: 'data30', width: 80, editor: 'textfield', menuDisabled: true},
				// {text: '验收实际时间', dataIndex: 'data27', width: 80, editor: 'textfield', menuDisabled: true},
				// {text: '质量状态', dataIndex: 'data28', width: 80, editor: 'textfield', menuDisabled: true},
				// {text: '验收说明', dataIndex: 'data29', width: 80, editor: 'textfield', menuDisabled: true},	
				{text: '需求实现确认（SE）', dataIndex: 'data22', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '需求实现确认备注（SE）', dataIndex: 'data23', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '测试验收责任人', dataIndex: 'data24', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '测试验收计划时间', dataIndex: 'data27', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '测试验收进度', dataIndex: 'data28', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '是否有对应测试用例', dataIndex: 'data29', width: 80, editor: 'textfield', menuDisabled: true},
				{text: 'DS测试用例文档编号', dataIndex: 'data30', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '验收实际时间', dataIndex: 'data1', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '质量状态', dataIndex: 'data2', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '测试备注', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
				{text: '转问题编号', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
		        ],
		        tbar: ['&nbsp;',
		        {
		    	   xtype:'filefield',
 	        	   buttonOnly: true,
 	        	   hidden:false,
 	        	   id:'upload1',
 	        	   hideLabel: true, 
 	        	   buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>Excel导入</span>',
	 		       allowBlank: false,
	 		       scope: this,
	 		       listeners:{
	    	           'change':function(fb,v){
	 			   	        var file = document.querySelector('[id=upload1-button-fileInputEl]');
	 						var formData = new FormData();
	 						formData.append('upload1-button-fileInputEl', file.files[0]);
	 						fb.reset();//清空表单的值
	 						var loadMarsk = new Ext.LoadMask(document.body, {    
	 							  msg:'正在导入数据，请稍候......',    
	 							   removeMask:true // 完成后移除    
	 						});
	 						loadMarsk.show();
	 						$.ajax({
	 								url: '/Windchill/ptc1/require/importRequireItems?branchId='+branchId,
	 								type: 'POST',
	 								cache: false,
	 								data: formData,
	 								processData: false,
	 								contentType: false
	 							}).done(function(res) {
	 								loadMarsk.hide();
	 								
	 								var obj = Ext.decode(res);
	 								
	 							   	 var success = obj['success'];
	 							   	 var msg = obj['msg'];
	 							   	 if(!success){
	 							   		alert(msg);
	 							   	 }else {
	 							   		refreshArRequireStore();
	 							   	 }
	 							}).fail(function(res) {
	 								loadMarsk.hide();
	 								alert('上传失败！') ;
	 							});
	    	           		}
 	           		}
		    				          
		    	},'&nbsp;',
	    		{
	    			text: '下载模板',
	    			iconCls : 'icon icon-store-export',
	    			scope: this,
	    			hidden:false,
	    			handler : function(){
			        	window.location.href = 
		    	    		 '/Windchill/ptc1/require/exportRequireTemplate'; 
	 		        	
			         }		           
	    		},'&nbsp;',{
	   	        	   text: '显示个人',
	   	        	   scope: this,
	   	        	   id:'displayUser',
	   	        	   handler:function(){
	    					userDisplayName=userName;
	    					refreshArRequireStore();
	   	        	   		Ext.getCmp("displayUser").hide();
	   	        	   		Ext.getCmp("displayAll").show();
	   	           	  }
	   	           },{
	   	        	   text: '显示全部',
	   	        	   scope: this,
	   	        	   id:'displayAll',
	   	        	   hidden:true,
	   	        	   handler:function(){
	   	        	   		userDisplayName="";
	   	        	   		refreshArRequireStore();
	   	        	   		Ext.getCmp("displayUser").show();
	   	        	   		Ext.getCmp("displayAll").hide();
	   	           	  }
	   	           },{
	   	        	   text: '显示最新版本',
	   	        	   scope: this,
	   	        	   id:'displayLatestVersion',
	   	        	   hidden:true,
	   	        	   handler:function(){
	   	        	   		requireGrid.down('#changeType').hide();
	   	        	   		requireGrid.down('#changeTime').hide();
	   	        	   		requireGrid.down('#changeNumber').hide();
	   	        	   	Ext.getCmp("displayAllVersion").show();
   	        	   		Ext.getCmp("displayLatestVersion").hide();
   	        	   		//最新版本只保留变更类型为空和添加 的，过滤掉删除的
   	        	   		arRequireStore.filterBy(function(record, id) {
	                     if (!record.get('changeType')||record.get('changeType') == ''
	                    		 ||record.get('changeType') == '添加') {
	                    	 //判断是否是上一次变更
	                    	 if(record.get('plusChangeType')=='') {
	                    		 return true;
	                    	 }
	                        
	                     } else
	                         return false;
	   	        	   	 });
	   	           		}
	   	           },{
	   	        	   text: '显示全部版本',
	   	        	   scope: this,
	   	        	   id:'displayAllVersion',
	   	        	   handler:function(){
	   	        	   		requireGrid.down('#changeType').show();
	   	        	   		requireGrid.down('#changeTime').show();
	   	        	   		requireGrid.down('#changeNumber').show();
	   	        	   		Ext.getCmp("displayAllVersion").hide();
	   	        	   		Ext.getCmp("displayLatestVersion").show();
	   	        	   		arRequireStore.clearFilter(true);
	   	           		}
	   	           },{
		    		 text:'',
	   	        	 id:'saveStatus',
	   	        	 disabled:true
		    	}],
	    });	
	    requireGrid.on('edit',
			function (editor, e) {
				var tRecord = e.record; //得到当前行所有数据
				var tField = e.field; //得到修改列
				var tValue = e.value; //得到修改列修改后值
				var itemId = tRecord.get('id');

				var callbackFn = function () {
					tRecord.commit();
				};
				saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

			});

	    
	    //====================开始 需求版本记录===============================
	    Ext.define('RequireChangeDocModel', {
	        extend: 'Ext.data.Model',
	        fields: [
	                 'docNumber','docName','docOid','docCreator','docEffectDate'
	        ],
	        idProperty: 'docNumber'
	    });


	    var requireChangeDocGrid = Ext.create('Ext.grid.Panel', {
	        title: '变更文档列表',
	        store:Ext.getStore('mockExampleStore1'),
	        id:'requireChangeDocGrid',
	        //forceFit : true,
	        autoWidth : true,
	        autoScroll:true,
			height:200,
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: mockExampleGrid,
							param_objectKey: me.in_objectKey,
							param_objectDesc: me.in_objectDesc
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			columns: [
						Ext.create('Ext.grid.RowNumberer'),	
						{ text: '变更文档编号',dataIndex: 'data1',width:130 ,menuDisabled:true},
						{ text: '变更文档名称',dataIndex: 'data2',width:130,menuDisabled:true},
						{ text: '变更文档创建者',dataIndex: 'data3',width:100,menuDisabled:true},
						{ text: '查看变更数据',dataIndex: 'data4',width:130 ,menuDisabled:true,},
						{ text: '变更生效时间',dataIndex: 'data5',width:150,menuDisabled:true}
		        ]
	    	});
	    var requireHistoryGrid = Ext.create('Ext.grid.Panel', {
	    	title: '当次变更记录',
	        store:Ext.getStore('mockExampleStore2'),
	        id:'requireHistoryGrid',
	        //forceFit : true,
	        autoWidth : true,
	        autoScroll:true,
	        height:400,
			viewConfig: {
				enableTextSelection: true,
				stripeRows: true,
				listeners: {
					itemcontextmenu: function (view, rec, node, index, e) {
						e.stopEvent();
						var contextMenu = Ext.create('PLM.mock.ContextMenu', {
							param_grid: mockExampleGrid,
							param_objectKey: me.in_objectKey,
							param_objectDesc: me.in_objectDesc
						});
						contextMenu.showAt(e.getXY());
						return false;
					}
				}
			},
			columns: [
				Ext.create('Ext.grid.RowNumberer'),
				{ text: '变更类型',	dataIndex: 'data1',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'OR需求标题',	dataIndex: 'data2',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'OR需求编号',	dataIndex: 'data3',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DR需求标题',	dataIndex: 'data4',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DR需求编号',	dataIndex: 'data5',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求标题',  dataIndex: 'data6',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求编号',  dataIndex: 'data7',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求描述',  dataIndex: 'data8',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS需求备注说明',  dataIndex: 'data9',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS构件',  dataIndex: 'data10',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS领域',  dataIndex: 'data11',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS优先级',  dataIndex: 'data12',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS重要性',  dataIndex: 'data13',width:100 ,editor: 'textfield',menuDisabled:true},
				{ text: 'DS工作量',  dataIndex: 'data14',width:100 ,editor: 'textfield',menuDisabled:true}
			]});
    
	    //需求变更版本分页
	    var requrieVersionPanel = Ext.create('Ext.panel.Panel',{
	    	items:[
	    	       requireChangeDocGrid,
	    	       requireHistoryGrid
	    	       ]
	    });
	    
	  //====================结束  需求版本记录===============================
	    
/////////////////////////Main Panel items//////////////////////////////////
		this.items=[{
			xtype:'tabpanel',
			height: '100%',
    		header: false,
    		collapsible: true,
        	split: true,
    		activeTab: 0,
	        items: [{
	        	xtype:'panel',
	        	title:'需求计划表',
	        	hidden:false,
	        	items:[requireGrid]
	        },{
	        	xtype:'panel',
	        	title:'需求版本记录',
	        	hidden:false,
	        	items:[requrieVersionPanel]
	        }]
	      }//~end of tabpanel
		];//~end of this.items
		
		
		this.callParent();
	},//~End of initComponent
	listeners:{
			'afterrender': function () {
				Ext.getStore('mockExampleStore').load({
					params: {
						objectKey: Ext.getCmp('ctRequirePanel').getIn_objectKey()//表头key
					},
					callback: function (records, operation, success) {
						if (!success) {
							if (typeof (operation.error) == 'string') {
								alert(operation.error);
							} else {
								alert('查询超时！请重试！')
							}
						} else {
							//无数据时自动添加一条空数据
							if (Ext.getStore('mockExampleStore').getCount() == 0) {
								var callbackFn = function () {
									Ext.getStore('mockExampleStore').reload()
								}
								createMockItemData(Ext.getCmp('ctRequirePanel').getIn_objectKey()
									, Ext.getCmp('ctRequirePanel').getIn_objectDesc, callbackFn);
							}
						}
					}
				});
				Ext.getStore('mockExampleStore1').load({
					params: {
						objectKey: Ext.getCmp('ctRequirePanel').getIn_objectKey1()//表头key
					},
					callback: function (records, operation, success) {
						if (!success) {
							if (typeof (operation.error) == 'string') {
								alert(operation.error);
							} else {
								alert('查询超时！请重试！')
							}
						} else {
							//无数据时自动添加一条空数据
							if (Ext.getStore('mockExampleStore1').getCount() == 0) {
								var callbackFn = function () {
									Ext.getStore('mockExampleStore1').reload()
								}
								createMockItemData(Ext.getCmp('ctRequirePanel').getIn_objectKey1()
									, Ext.getCmp('ctRequirePanel').getIn_objectDesc1, callbackFn);
							}
						}
					}
				});
				Ext.getStore('mockExampleStore2').load({
					params: {
						objectKey: Ext.getCmp('ctRequirePanel').getIn_objectKey2()//表头key
					},
					callback: function (records, operation, success) {
						if (!success) {
							if (typeof (operation.error) == 'string') {
								alert(operation.error);
							} else {
								alert('查询超时！请重试！')
							}
						} else {
							//无数据时自动添加一条空数据
							if (Ext.getStore('mockExampleStore2').getCount() == 0) {
								var callbackFn = function () {
									Ext.getStore('mockExampleStore2').reload()
								}
								createMockItemData(Ext.getCmp('ctRequirePanel').getIn_objectKey2()
									, Ext.getCmp('ctRequirePanel').getIn_objectDesc2, callbackFn);
							}
						}
					}
				});

			}
		}

});
