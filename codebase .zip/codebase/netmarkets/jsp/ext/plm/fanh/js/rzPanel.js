Ext.define('Pnt.view.rzPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.rzPanel',
	border:false,
	title:'<font style="font-size:18px">产品信息认证对照表</font>',
	autoWidth:true,
	autoHeight:true,
	collapsible: false,
	id: 'rzPanel',
	fieldDefaults: {
		msgTarget: 'side',
		labelWidth: 75
	},
	initComponent:function(){

		//定义展现模型
		Ext.define('rzModel', {
			extend: 'Ext.data.Model',
			fields: [
				'docid',
				'ct_productName',
				'ct_model',
				'ct_materialsnumber',
				'ct_Identityinformationtype',
				'ct_Authenticationtype',
				'ct_Dateoffirstissuance',
				'ct_DateofObtainingCertificate',
				'ct_Certificateexpirationdate',
				'ct_Certificatenumber',
				'ct_1InspectionReportNo',
				'ct_1Productstandard',
				'description'
			],
			idProperty: 'docid'
		});

		//定义请求
		var rzReportStore = Ext.create('Ext.data.Store', {
			//pageSize: 100,
			model: 'rzModel',
			id:'rzReport',
			pruneModifiedRecords: true,
			proxy: new Ext.data.HttpProxy({
				url: '/Windchill/ptc1/fanh/report/productrz',
				method:'GET',
				reader:{
					type:'json',
					root: 'data',
					totalProperty: 'count',
					idProperty: 'docid',
					messageProperty: 'msg'
				}
			}),
			autoLoad:false
		});

		var dataAuditReportGrid = Ext.create('Ext.grid.Panel', {
			title: '产品信息认证对照表',
			store:rzReportStore,
			autoWidth : true,
			columnLines: true,
			autoScroll: true,
			height:250,
			selModel: {
				selType: 'cellmodel'
			},
			iconCls: 'icon-grid',
			viewConfig:{enableTextSelection:true},
			columns: [
				{xtype: 'rownumberer',width:40},
				{ text: '主文档id',  dataIndex: 'docid', menuDisabled:true,hidden:true},
				{ text: '认证产品名称',  dataIndex: 'ct_productName', menuDisabled:true,width:250 },
				{ text: '型号',  dataIndex: 'ct_model', menuDisabled:true },
				{ text: '物料编码',  dataIndex: 'ct_materialsnumber' ,menuDisabled:true,width:200},
				{ text: '身份信息类型',  dataIndex: 'ct_Identityinformationtype',menuDisabled:true},
				{ text: '认证类型',  dataIndex: 'ct_Authenticationtype',menuDisabled:true},
				{ text: '首次发证日期',  dataIndex: 'ct_Dateoffirstissuance',menuDisabled:true},
				{ text: '获得证书日期',  dataIndex: 'ct_DateofObtainingCertificate' ,menuDisabled:true,width:160},
				{ text: '证书到期日期',  dataIndex: 'ct_Certificateexpirationdate',menuDisabled:true,width:160,},
				{ text: '证书',  dataIndex: 'ct_Certificatenumber', menuDisabled:true , width: 120},
				{ text: '校验报告',  dataIndex: 'ct_1InspectionReportNo', menuDisabled:true , width: 120},
				{ text: '产品标准',  dataIndex: 'ct_1Productstandard', menuDisabled:true , width: 120},
				{ text: '主要变更内容',  dataIndex: 'description', menuDisabled:true , width: 120}
			]
		})
		this.items = [
			userResourceGrid
		]
		this.callParent();
	}
});

