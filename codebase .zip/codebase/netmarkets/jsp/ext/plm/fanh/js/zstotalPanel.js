Ext.define('Pnt.view.zstotalPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.zstotalPanel',
	border:false,
	title:'<font style="font-size:18px">产品信息认证对照表</font>',
	autoWidth:true,
	autoHeight:true,
	collapsible: false,
	id: 'zstotalPanel',
	fieldDefaults: {
		msgTarget: 'side',
		labelWidth: 75
	},
	initComponent:function(){
		this.callParent();
	}
});

