
<%-- //////////////////Start - HTML Area //////////////////// --%>

<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>

<%-- //////////////////End - HTML Area //////////////////// --%>
<%
String oid = request.getParameter("oid");
%>

<iframe id="dataReportQueryPlugin" src="netmarkets/jsp/ext/plm/fanh/dataRZReportQuerylayui_fh.jsp?oid=<%=oid%>"  style="width:98%;height:700px" ></iframe>