<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="layui/css/layui.css">
    <script src="layui/layui.js"></script>
    <script src="https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js"></script>
    <style>
        .layui-table-cell {
            height:auto;
          /* white-space: normal;
          */
            line-height: 34px;
        }

    </style>
</head>

<body>
    <div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
        <ul class="layui-tab-title">
            <li class="layui-this">产品信息认证对照表</li>
            <li>证书注销汇总表</li>
        </ul>
        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
                <button type="button" class="layui-btn layui-btn-primary layui-btn-xs" onclick="productrzexport()">excel导出</button>
                <table id="productrz"></table>
            </div>
            <div class="layui-tab-item">
                <button type="button" class="layui-btn layui-btn-primary layui-btn-xs" onclick="productzsexport()">excel导出</button>
                <table id="productzs"></table>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function productzsexport(){
            window.location.href = "/Windchill/ptc1/fanh/report/productzs/export";
        }
        function productrzexport(){
            window.location.href = "/Windchill/ptc1/fanh/report/productrz/export";
        }
        function addLink(d){
            return d;
        }
        layui.use(['layer', 'form','table'], function(){
            var layer = layui.layer;
            var form = layui.form;
            var table = layui.table;
            table.render({
                elem: '#productrz',//id
                height: 600, //高度
                //toolbar: '#productrz',//工具栏
                totalRow: true,//开启合计行gu
                url: '/Windchill/ptc1/fanh/report/productrz', //数据接口
                page: false, //开启分页
                cols: [[    //表头
                    {field: 'rank', title: '序号',width:80, templet: '#rank' },
                    {field: 'docnumber', title: '文档编码',width:110},
                    {field: 'ct_productName', title: '认证产品名称',width:300},
                    {field: 'ct_model', title: '型号',width:200},
                    {field: 'ct_materialsnumber', title: '物料编码(此代码为PLM系统所有同型号代码，非所有代码都经过认证送检)',width:500},
                    {field: 'ct_Authenticationtype', title: '认证类型',width:130},
                    {field: 'ct_Dateoffirstissuance', title: '首次发证日期',sort: true,width:130},
                    {field: 'ct_DateofObtainingCertificate', title: '获得证书日期',width:130},
                    {field: 'ct_Certificateexpirationdate', title: '证书到期日期',sort: true,width:130},
                    {field: 'ct_Certificatenumber', title: '证书编号',width:160},
                    {field: 'ct_1InspectionReportNo', title: '检验报告',width:220},
                    {field: 'ct_1Productstandard', title: '产品标准',width:220},
                    {field: 'description', title: '变更履历',width:400},
                    {field: 'ct_Identityinformationtype', title: '身份信息类型',width:160}
                ]],
                done : function (res,curr,count) {  //获取渲染后返回值
                    var systemTime = new Date().getTime();
                    for(var i = 0;i<res.data.length;i++){  //遍历返回的数据
                        var docurl=res.data[i].docurl;
                        addLink(docurl);
                        var rzType=res.data[i].ct_Authenticationtype;
                        var InspectionReportNo=res.data[i].ct_1InspectionReportNo;
                        if(InspectionReportNo!=null){
                            var a=InspectionReportNo.indexOf(',')+1;
                            var rzReportTime=InspectionReportNo.substring(a,a+10);
                            if(rzReportTime!=""){
                                var rpDays=Math.abs(parseInt(systemTime-rzReportTime)/1000/3600/24);
                                if(rpDays<=120){
                                    $("table tbody tr").eq(i).css('background-color','#f4e744');
                                }
                            }
                        }
                        if(rzType == '防爆认证'){
                            var time1 = Date.parse(new Date(res.data[i].ct_Certificateexpirationdate));
                            var nDays=Math.abs(parseInt(systemTime-time1)/1000/3600/24);
                            if(nDays<=270){
                                $("table tbody tr").eq(i).css('background-color','#f49a87');
                            }
                        }else if(rzType == 'CCC认证'||rzType == '自愿性认证'||rzType == '技术鉴定'
                            ||rzType =='无线电发射设备型号核准证' ||rzType == '计量器具型式批准'||rzType == '电信设备进网许可证'){
                            var time1 = Date.parse(new Date(res.data[i].ct_Certificateexpirationdate ));
                            var nDays=Math.abs(parseInt(systemTime-time1)/1000/3600/24);
                            if(nDays<=120){
                                $("table tbody tr").eq(i).css('background-color','#f49a87');
                            }
                        }
                    }
                }

            })

            table.render({
                elem: '#productzs',//id
                height: 600, //高度
                //toolbar: '#productzs',//工具栏
                totalRow: true,//开启合计行
                url: '/Windchill/ptc1/fanh/report/productzs', //数据接口
                page: false, //开启分页
                cols: [[    //表头
                    {field: 'rank', title: '序号',width:80, templet: '#rank' },
                    {field: 'docnumber', title: '文档编号',width:110},
                    {field: 'ct_productName', title: '认证产品名称',width:320},
                    {field: 'ct_model', title: '型号',width:580},
                    {field: 'ct_CancellationResume', title: '注销履历',width:720,align:'left'}
                ]]
            })
        })
    </script>
    <script type="text/html" id="rank">
        {{d.LAY_TABLE_INDEX+1}}
    </script>
</body>
</html>