let ctContentEditing6 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

Ext.define('ctTrialStandardModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'combinationNumber', 'productNumber', 'productDesc',
    'productionOrderNumber', 'productionProcesses', 'experimentalProjects', 'trialStandard',
    'suspensionPrinciple', 'eligibility', 'disposalMethods', 'identificationMethod', 'plugCommandNumber'
        //, 'productOrderNumber','actualQuantity'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctTrialStandardModel',
    storeId: 'ctTrialStandardStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getTrialStandard?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//组合编号
var combinationNumberCombo3 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'combinationNumberCombo3',
    id: 'combinationNumberCombo3',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['combinationNumber']
    },
    valueField: 'combinationNumber',
    displayField: 'combinationNumber'
});

//物料编码
// var partNumberCombo1 = new Ext.form.ComboBox({
//     xtype: 'combo',
//     name: 'partNumberCombo1',
//     id: 'partNumberCombo1',
//     multiSelect: false,
//     anyMatch: true,
//     editable: false,
//     store: {
//         data: [
//         ],
//         fields: ['productNumber']
//     },
//     valueField: 'productNumber',
//     displayField: 'productNumber'
// });

//父项编码
let parentNumberCombo1 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'parentNumberCombo1',
    id: 'parentNumberCombo1',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['parentNumber']
    },
    valueField: 'parentNumber',
    displayField: 'parentNumber'
});

//物料是否齐套
let partCompleteStore = [['是', '是'], ['否', '否']];

let ctTrialStandardBo = Ext.create('Ext.grid.Panel', {
    id: 'ctTrialStandardBo',
    store: Ext.data.StoreManager.lookup('ctTrialStandardStore'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: '2. 试用执行标准',
    collapsible: true,
    collapsed:openPanel(Quality_Control_Department_PQC_Node,Standard_Setting_TQC_Node,Update_Confirm_Order_Node,Production_Manager_Approval_Node,Technical_Department_Manager_Node,Quality_Control_Department_Manager_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing6],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('组合编码',isEditable(Quality_Control_Department_PQC_Node,Standard_Setting_TQC_Node,Update_Confirm_Order_Node)),
            width: 80,
            dataIndex: 'combinationNumber',
            align: 'center',
            editAccess:isEditable(Quality_Control_Department_PQC_Node,Standard_Setting_TQC_Node,Update_Confirm_Order_Node),
            editor: combinationNumberCombo3
            , renderer:showTip
        },
        {
            text: setMust('试用产品编码',isEditable(Quality_Control_Department_PQC_Node,Update_Confirm_Order_Node,Standard_Setting_TQC_Node)),
            width: 100,
            dataIndex: 'productNumber',
            align: 'center',
            editAccess:isEditable(Quality_Control_Department_PQC_Node,Update_Confirm_Order_Node,Standard_Setting_TQC_Node),
            editor: parentNumberCombo1
            , renderer:showTip
        },
        {text: '试用产品描述', width: 120, dataIndex: 'productDesc', align: 'center', renderer:showTip},
        {
            text: setMust('物料是否齐套',isEditable(Update_Confirm_Order_Node)),
            dataIndex: 'productionOrderNumber',
            width: 100,
            menuDisabled: true,renderer:showTip,
            editAccess:isEditable(Update_Confirm_Order_Node),
            editor: {
                xtype: 'combobox',
                editable: false,
                forceSelection: false,
                store: partCompleteStore
            }
        },
        {
            text: setMust('说明',isEditable(Update_Confirm_Order_Node)),
            width: 140,
            dataIndex: 'plugCommandNumber',
            align: 'center',
            editAccess:isEditable(Update_Confirm_Order_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        // {
        //     text: setMust('组装成品令号',isEditable(Update_Confirm_Order_Node)),
        //     width: 120,
        //     dataIndex: 'productOrderNumber',
        //     align: 'center',
        //     editAccess:isEditable(Update_Confirm_Order_Node),
        //     editor: {xtype: 'textfield', selectOnFocus: true}
        //     , renderer:showTip
        // },
        // {
        //     text: setMust('实际试用物料数量',isEditable(Update_Confirm_Order_Node)),
        //     width: 120,
        //     dataIndex: 'actualQuantity',
        //     align: 'center',
        //     editAccess:isEditable(Update_Confirm_Order_Node),
        //     editor: {xtype: 'textfield', selectOnFocus: true}
        //     , renderer:showTip
        // },
        {
            text: setMust('关注工序',isEditable(Quality_Control_Department_PQC_Node)),
            width: 80,
            dataIndex: 'productionProcesses',
            align: 'center',
            editAccess:isEditable(Quality_Control_Department_PQC_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('增加的试验项目',isEditable(Quality_Control_Department_PQC_Node)),
            width: 100,
            dataIndex: 'experimentalProjects',
            align: 'center',
            editAccess:isEditable(Quality_Control_Department_PQC_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        // {
        //     text: setMust('试用标准',isEditable(Quality_Control_Department_PQC_Node)),
        //     width: 120,
        //     dataIndex: 'trialStandard',
        //     align: 'center',
        //     editAccess:isEditable(Quality_Control_Department_PQC_Node),
        //     editor: {xtype: 'textfield', selectOnFocus: true}
        //     , renderer:showTip
        // },
        {
            text: setMust('暂停原则',isEditable(Quality_Control_Department_PQC_Node)),
            width: 80,
            dataIndex: 'suspensionPrinciple',
            align: 'center',
            editAccess:isEditable(Quality_Control_Department_PQC_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('试用合格标准',isEditable(Standard_Setting_TQC_Node)),
            width: 100,
            dataIndex: 'eligibility',
            align: 'center',
            editAccess:isEditable(Standard_Setting_TQC_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        // {
        //     text: setMust('不良品处置方法',isEditable(Quality_Control_Department_PQC_Node)),
        //     width: 120,
        //     dataIndex: 'disposalMethods',
        //     align: 'center',
        //     editAccess:isEditable(Quality_Control_Department_PQC_Node),
        //     editor: {xtype: 'textfield', selectOnFocus: true}
        //     , renderer:showTip
        // },
        {
            text: setMust('成品标识方法',isEditable(Quality_Control_Department_PQC_Node)),
            width: 300,
            dataIndex: 'identificationMethod',
            align: 'center',
            editAccess:isEditable(Quality_Control_Department_PQC_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        }
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(Quality_Control_Department_PQC_Node,Standard_Setting_TQC_Node,Update_Confirm_Order_Node),
            handler: function () {
                ctContentEditing6.cancelEdit();
                function successCallback(data) {
                    let store = ctTrialStandardBo.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveTrialStandard', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(Quality_Control_Department_PQC_Node,Standard_Setting_TQC_Node,Update_Confirm_Order_Node),
            handler: function () {
                let selected = ctTrialStandardBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctTrialStandardBo.getStore().remove(selected);
                        ctTrialStandardBo.view.refresh();
                    }

                    function failCallback() {
                    }

                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteTrialStandard', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'combinationNumber') {
                    combinationNumberCombo3.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getCombinationNumber?branchId=' + branchId,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                   combinationNumberList.map(function (item) {
                                       combinationNumberCombo3.getStore().add({combinationNumber: item});
                                   })
                                }
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            // // 通过单元格索引获取列
            // var column = headerCt.getGridColumns()[cellIndex + 2];
            // if (column) {
            //     var columnName = column.dataIndex;
            //     if(columnName == 'productNumber'){
            //         parentNumberCombo1.getStore().removeAll();
            //         Ext.Ajax.request({
            //             url: '/Windchill/ptc1/trial/getTrialPartNumber?branchId=' + branchId + "&combinationNumber=" + combinationNumber,
            //             method:'GET',
            //             headers: {'Content-Type':'application/json'},
            //             success: function (response, opts) {
            //                 var obj = Ext.decode(response.responseText);
            //                 if(obj.message=='success') {
            //                     var combinationNumberList = Ext.decode(response.responseText).data;
            //                     if(combinationNumberList){
            //                         combinationNumberList.map(function(item) {
            //                             partNumberCombo1.getStore().add({productNumber:item.trialPartNumber});
            //                         })
            //                     }
            //                 }else {
            //                     alert(obj.message)
            //                 }
            //             },
            //             failure: function (response, opts) {
            //                 alert('错误：删除信息失败，请检查网络！!');
            //             }
            //         });
            //     }
            // }

            // 通过单元格索引获取列
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'productNumber'){
                    parentNumberCombo1.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getParentNumber?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var parentNumberList = Ext.decode(response.responseText).data;
                                if(parentNumberList){
                                    parentNumberList.map(function(item) {
                                        parentNumberCombo1.getStore().add({parentNumber:item.parentNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            updateTrialStandard(editor, e);
        }
    }
});
