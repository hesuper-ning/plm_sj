let ctContentEditing7 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

Ext.define('ctFollowUpTrialModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'trialNumber', 'trialProductNumber', 'trialProductDesc',
    'batchNumber', 'productionLine', 'plungeIntoDate', 'plungeIntoQuantity', 'finishedProductCode',
    'finishedProductDesc', 'finishedProductOrder', 'defectiveQuantity', 'followUpTrialSituation', 'annexFile'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctFollowUpTrialModel',
    storeId: 'ctFollowUpTrialStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getFollowUpTrial?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//组合编码
var combinationNumberCombo4 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'combinationNumberCombo4',
    id: 'combinationNumberCombo4',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['combinationNumber']
    },
    valueField: 'combinationNumber',
    displayField: 'combinationNumber'
});

//物料编码
var partNumberCombo2 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'partNumberCombo2',
    id: 'partNumberCombo2',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['trialPartNumber']
    },
    valueField: 'trialPartNumber',
    displayField: 'trialPartNumber'
});

//物料是否齐套
let productionProcessStore = [['贴片', '贴片'], ['插件', '插件'], ['成品', '成品']];

let ctFollowUpTrialBo = Ext.create('Ext.grid.Panel', {
    id: 'ctFollowUpTrialBo',
    store: Ext.data.StoreManager.lookup('ctFollowUpTrialStore'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: 'S03：试用过程跟进',
    collapsible: true,
    collapsed:openPanel(Approval_By_Team_Leader_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing7],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('组合编码',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'trialNumber',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: combinationNumberCombo4
        },
        {
            text: setMust('物料编码',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'trialProductNumber',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: partNumberCombo2
        },
        {text: '物料描述', width: 100, dataIndex: 'trialProductDesc', align: 'center'},
        {
            text: setMust('工单编号', isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'batchNumber',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('生产工序', isEditable(Approval_By_Team_Leader_Node)),
            dataIndex: 'productionProcess',
            width: 80,
            menuDisabled: true,renderer:showTip,
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {
                xtype: 'combobox',
                editable: false,
                forceSelection: false,
                store: productionProcessStore
            }
        },
        {
            text: setMust('生产线别',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'productionLine',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('投入日期',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'plungeIntoDate',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {xtype: 'datefield', format: 'Y-m-d', editable: false},
            renderer: function (value) {
                return renderDateField(value);
            }
            , renderer:showTip
        },
        {
            text: setMust('投入数量',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'plungeIntoQuantity',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('父项物料编码',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'finishedProductCode',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {text: '父项物料描述', width: 100, dataIndex: 'finishedProductDesc', align: 'center'},
        {
            text: setMust('生产订单号',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'finishedProductOrder',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('试用物料不良数量',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'defectiveQuantity',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('试用情况跟进',isEditable(Approval_By_Team_Leader_Node)),
            width: 80,
            dataIndex: 'followUpTrialSituation',
            align: 'center',
            editAccess:isEditable(Approval_By_Team_Leader_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setRequired('附件',isEditable(Approval_By_Team_Leader_Node)),
            width: 120,
            dataIndex: 'annexFile',
            align: 'center'
        }
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(Approval_By_Team_Leader_Node),
            handler: function () {
                ctContentEditing7.cancelEdit();
                function successCallback(data) {
                    let store = ctFollowUpTrialBo.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveFollowUpTrial', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(Approval_By_Team_Leader_Node),
            handler: function () {
                let selected = ctFollowUpTrialBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctFollowUpTrialBo.getStore().remove(selected);
                        ctFollowUpTrialBo.view.refresh();
                    }

                    function failCallback() {
                    }

                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteFollowUpTrial', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        },
        {
            xtype: 'filefield',
            hidden: !isEditable(Approval_By_Team_Leader_Node),
            buttonOnly: true,
            id: 'FollowUpTrial_annexFile',
            name: 'FollowUpTrial_annexFile',
            hideLabel: true,
            buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '上传附件',
            allowBlank: false,
            scope: this,
            listeners: {
                'focus': function () {
                    let selectionArr = ctFollowUpTrialBo.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("annexFile");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    if (selectionArr.length >= 2) {
                        alert("不支持多行添加文件操作，请确认要添加的行");
                        return;
                    }
                },
                'change': function (fb, newValue) {
                    if (!newValue) {
                        return;
                    }
                    let selectionArr = ctFollowUpTrialBo.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("annexFile");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    var file = document.querySelector('[id=' + 'FollowUpTrial_annexFile' + '-button-fileInputEl]');
                    var formData = new FormData();
                    formData.append('FollowUpTrial_annexFile' + '-button-fileInputEl', file.files[0]);
                    fb.reset();//清空表单的值
                    var myMask = new Ext.LoadMask({
                        msg: '正在上传，请稍候......',
                        target: this.findParentByType('panel')
                    });
                    var tRecord = ctFollowUpTrialBo.getSelectionModel().getSelection()[0];
                    var itemId = tRecord.get('id');
                    myMask.show();
                    $.ajax({
                        url: '/Windchill/ptc1/trial/uploadFiles?branchId=' + branchId + '&tetx_name=' + 'FollowUpTrial_annexFile' + "&node=" + 'FollowUpTrial_node' + "&type=annexFile_1" + "&id=" + itemId,
                        type: 'POST',
                        cache: false,
                        data: formData,
                        processData: false,
                        contentType: false
                    }).done(function (res) {
                        myMask.hide();
                        var obj = Ext.decode(res);
                        var success = obj['success'];
                        var msg = obj['msg'];
                        if (!success) {
                            alert(msg);
                        } else {
                            var fileName = obj['fileName'];
                            var attachmentValue = ctFollowUpTrialBo.getSelectionModel().getSelection()[0].data.annexFile;
                            if (attachmentValue != null && attachmentValue != '') {
                                fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                            }
                            tRecord.set('annexFile', fileName);
                            var callbackFn = function () {
                                tRecord.commit();
                            };
                            var itemId = tRecord.get('id');
                            saveMockItemData("ZFollowUpTrialTable", itemId, 'annexFile', fileName, callbackFn);
                        }
                        var callbackFn = function () {
                            Ext.getStore('ctFollowUpTrialStore').reload();
                        };
                    }).fail(function (res) {
                        myMask.hide();
                        alert('上传失败！');
                    });
                }
            }
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'trialNumber') {
                    combinationNumberCombo4.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getCombinationNumber?branchId=' + branchId,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function (item) {
                                        combinationNumberCombo4.getStore().add({combinationNumber: item});
                                    })
                                }
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            var combinationNumber = record.get('trialNumber');
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'trialProductNumber'){
                    partNumberCombo2.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getTrialPartNumber?branchId=' + branchId + "&combinationNumber=" + combinationNumber,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        partNumberCombo2.getStore().add({trialPartNumber:item.trialPartNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            updateFollowUpTrial(editor, e);
        }
    }
});
