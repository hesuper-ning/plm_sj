let ctContentEditing9 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

Ext.define('ctTrialResultModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'combinationNumber', 'semiProductNumber', 'semiProductDesc',
    'productNumber', 'productDesc', 'partNumber', 'partDesc', 'partVersion',
    'supplierNumber', 'trialStatus', 'tQCOpinion', 'trialConclusion', 'resultIllustrate'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctTrialResultModel',
    storeId: 'ctTrialResultStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getTrialCombination?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

let opinionStore = [['通过', '通过'], ['不通过', '不通过']];

let conclusionStore = [['通过', '通过'], ['不通过', '不通过']];

let ctTrialResultBo = Ext.create('Ext.grid.Panel', {
    id: 'ctTrialResultBo',
    store: Ext.data.StoreManager.lookup('ctTrialResultStore'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: 'S04：试用结果确认',
    collapsible: true,
    collapsed:openPanel(Fill_In_Trial_Comments_Node,Fill_In_Trial_Comments_TWO_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing9],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {text: '组合编码', width: 80, dataIndex: 'combinationNumber', align: 'center', renderer:showTip},
        {text: '半成品编码', width: 80, dataIndex: 'semiProductNumber', align: 'center', renderer:showTip},
        {text: '半成品描述', width: 100, dataIndex: 'semiProductDesc', align: 'center', renderer:showTip},
        {text: '成品编码', width: 80, dataIndex: 'productNumber', align: 'center', renderer:showTip},
        {text: '成品描述', width: 100, dataIndex: 'productDesc', align: 'center', renderer:showTip},
        {text: '物料编码', width: 80, dataIndex: 'partNumber', align: 'center', renderer:showTip},
        {text: '物料描述', width: 100, dataIndex: 'partDesc', align: 'center', renderer:showTip},
        {text: '内部版本', width: 80, dataIndex: 'partVersion', align: 'center', renderer:showTip},
        {text: '供应商编码_名称', width: 120, dataIndex: 'supplierNumber', align: 'center', renderer:showTip},
        {text: '试用状态', width: 80, dataIndex: 'trialStatus', align: 'center', renderer:showTip},
        {
            text: setMust('TQC意见',isEditable(Fill_In_Trial_Comments_Node)),
            width: 80,
            dataIndex: 'tQCOpinion',
            align: 'center',
            editAccess:isEditable(Fill_In_Trial_Comments_Node),
            editor: {
                xtype: 'combobox',
                editable: false,
                forceSelection: false,
                store: opinionStore,
            }
        },
        {
            text: setMust('试用结论',isEditable(Fill_In_Trial_Comments_TWO_Node)),
            width: 80,
            dataIndex: 'trialConclusion',
            align: 'center',
            editAccess:isEditable(Fill_In_Trial_Comments_TWO_Node),
            editor: {
                xtype: 'combobox',
                editable: false,
                forceSelection: false,
                store: conclusionStore,
            }
        },
        {
            text: setRequired('说明',isEditable(Fill_In_Trial_Comments_TWO_Node)),
            width: 80,
            dataIndex: 'resultIllustrate',
            align: 'center',
            editAccess:isEditable(Fill_In_Trial_Comments_TWO_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        }
    ],
    tbar: [],
    listeners: {
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            updateTrialCombination(editor, e);
        }
    }
});
