let ctContentEditing8 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

Ext.define('ctFollowUpTrialTwoModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'trialNumber', 'productNumber', 'partDesc',
    'opinionPqe', 'reportFilePqe', 'reportFilePathPqe', 'opinionIPQc', 'reportFileIPQc',
    'reportFilePathIPQc', 'opinionTechnology', 'reportFileTechnology', 'reportFilePathTechnology'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctFollowUpTrialTwoModel',
    storeId: 'ctFollowUpTrialTwoStore1',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getFollowUpTrialTwo?tableType=pqe&branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

Ext.create('Ext.data.Store', {
    model: 'ctFollowUpTrialTwoModel',
    storeId: 'ctFollowUpTrialTwoStore2',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getFollowUpTrialTwo?tableType=ipqc&branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

Ext.create('Ext.data.Store', {
    model: 'ctFollowUpTrialTwoModel',
    storeId: 'ctFollowUpTrialTwoStore3',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getFollowUpTrialTwo?tableType=technology&branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//组合编号
var combinationNumberCombo5 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'combinationNumberCombo5',
    id: 'combinationNumberCombo5',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['combinationNumber']
    },
    valueField: 'combinationNumber',
    displayField: 'combinationNumber'
});

// //物料编码
// var partNumberCombo3 = new Ext.form.ComboBox({
//     xtype: 'combo',
//     name: 'partNumberCombo3',
//     id: 'partNumberCombo3',
//     multiSelect: false,
//     anyMatch: true,
//     editable: false,
//     store: {
//         data: [
//         ],
//         fields: ['trialPartNumber']
//     },
//     valueField: 'trialPartNumber',
//     displayField: 'trialPartNumber'
// });

//父项编码
let parentNumberCombo2 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'parentNumberCombo2',
    id: 'parentNumberCombo2',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['parentNumber']
    },
    valueField: 'parentNumber',
    displayField: 'parentNumber'
});

//父项编码
let parentNumberCombo3 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'parentNumberCombo3',
    id: 'parentNumberCombo3',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['parentNumber']
    },
    valueField: 'parentNumber',
    displayField: 'parentNumber'
});

let parentNumberCombo4 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'parentNumberCombo4',
    id: 'parentNumberCombo4',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['parentNumber']
    },
    valueField: 'parentNumber',
    displayField: 'parentNumber'
});




let ctFollowUpTrialTwoBo1 = Ext.create('Ext.grid.Panel', {
    id: 'ctFollowUpTrialTwoBo1',
    store: Ext.data.StoreManager.lookup('ctFollowUpTrialTwoStore1'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: 'PQE质量测试项目填写',
    collapsible: true,
    collapsed:openPanel(PQE_Confirmation),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing8],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('组合编码',isEditable(PQE_Confirmation)),
            width: 120,
            dataIndex: 'trialNumber',
            align: 'center',
            editAccess:isEditable(PQE_Confirmation),
            editor: combinationNumberCombo5
        },
        {
            text: setMust('产品编码',isEditable(PQE_Confirmation)),
            width: 120,
            dataIndex: 'productNumber',
            align: 'center',
            editAccess:isEditable(PQE_Confirmation),
            editor: parentNumberCombo2
        },
        {text: '物料描述', width: 240, dataIndex: 'partDesc', align: 'center', renderer:showTip},
        {
            text: setMust('试用最终情况跟进',isEditable(PQE_Confirmation)),
            width: 260,
            dataIndex: 'opinionPqe',
            align: 'center',
            editAccess:isEditable(PQE_Confirmation),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {text: '报告链接', width: 240, dataIndex: 'reportFilePqe', align: 'center'}
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(PQE_Confirmation),
            handler: function () {
                ctContentEditing8.cancelEdit();
                function successCallback(data) {
                    let store = ctFollowUpTrialTwoBo1.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveFollowUpTrialTwo', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId, tableType: 'pqe'}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(PQE_Confirmation),
            handler: function () {
                let selected = ctFollowUpTrialTwoBo1.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctFollowUpTrialTwoBo1.getStore().remove(selected);
                        ctFollowUpTrialTwoBo1.view.refresh();
                    }

                    function failCallback() {
                    }

                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteFollowUpTrialTwo', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        },
        {
            xtype: 'filefield',
            hidden: !isEditable(PQE_Confirmation),
            buttonOnly: true,
            id: 'PQE_uploadFile',
            name: 'PQE_uploadFile',
            hideLabel: true,
            buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '上传PQE质量测试报告',
            allowBlank: false,
            scope: this,
            listeners: {
                'focus': function () {
                    let selectionArr = ctFollowUpTrialTwoBo1.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("reportFileIPQc");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    if (selectionArr.length >= 2) {
                        alert("不支持多行添加文件操作，请确认要添加的行");
                        return;
                    }
                },
                'change': function (fb, newValue) {
                    if (!newValue) {
                        return;
                    }
                    let selectionArr = ctFollowUpTrialTwoBo1.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("reportFilePqe");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    var file = document.querySelector('[id=' + 'PQE_uploadFile' + '-button-fileInputEl]');
                    var formData = new FormData();
                    formData.append('PQE_uploadFile' + '-button-fileInputEl', file.files[0]);
                    fb.reset();//清空表单的值
                    var myMask = new Ext.LoadMask({
                        msg: '正在上传，请稍候......',
                        target: this.findParentByType('panel')
                    });
                    var tRecord = ctFollowUpTrialTwoBo1.getSelectionModel().getSelection()[0];
                    var itemId = tRecord.get('id');
                    myMask.show();
                    $.ajax({
                        url: '/Windchill/ptc1/trial/uploadFiles?branchId=' + branchId + '&tetx_name=' + 'PQE_uploadFile' + "&node=" + 'PQE_node' + "&type=PQE"+"&id="+itemId,
                        type: 'POST',
                        cache: false,
                        data: formData,
                        processData: false,
                        contentType: false
                    }).done(function (res) {
                        myMask.hide();
                        var obj = Ext.decode(res);
                        var success = obj['success'];
                        var msg = obj['msg'];
                        if (!success) {
                            alert(msg);
                        } else {
                            var fileName = obj['fileName'];
                            var filePath = obj['filePath'];

                            var attachmentValue = ctFollowUpTrialTwoBo1.getSelectionModel().getSelection()[0].data.attachmentFile;
                            var attachmentPath = ctFollowUpTrialTwoBo1.getSelectionModel().getSelection()[0].data.attachmentPath;
                            if (attachmentValue != null && attachmentValue != '') {
                                fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                            }
                            tRecord.set('reportFilePqe', fileName);
                            tRecord.set('reportFilePathPqe', filePath);
                            var callbackFn = function () {
                                tRecord.commit();
                            };
                            var itemId = tRecord.get('id');
                            saveMockItemData("ZFollowUpTrialTwoTable", itemId, 'reportFilePqe', fileName, callbackFn);
                            saveMockItemData("ZFollowUpTrialTwoTable", itemId, 'reportFilePathPqe', filePath, callbackFn);
                        }
                        var callbackFn = function () {
                            Ext.getStore('ctFollowUpTrialTwoStore1').reload();
                        };
                    }).fail(function (res) {
                        myMask.hide();
                        alert('上传失败！');
                    });
                }
            }
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'trialNumber') {
                    combinationNumberCombo5.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getCombinationNumber?branchId=' + branchId,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function (item) {
                                        combinationNumberCombo5.getStore().add({combinationNumber: item});
                                    })
                                }
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            // var combinationNumber = record.get('trialNumber');
            // // 通过单元格索引获取列
            // var column = headerCt.getGridColumns()[cellIndex + 2];
            // if (column) {
            //     var columnName = column.dataIndex;
            //     if(columnName == 'productNumber'){
            //         partNumberCombo3.getStore().removeAll();
            //         Ext.Ajax.request({
            //             url: '/Windchill/ptc1/trial/getTrialPartNumber?branchId=' + branchId + "&combinationNumber=" + combinationNumber,
            //             method:'GET',
            //             headers: {'Content-Type':'application/json'},
            //             success: function (response, opts) {
            //                 var obj = Ext.decode(response.responseText);
            //                 if(obj.message=='success') {
            //                     var combinationNumberList = Ext.decode(response.responseText).data;
            //                     if(combinationNumberList){
            //                         combinationNumberList.map(function(item) {
            //                             partNumberCombo3.getStore().add({trialPartNumber:item.trialPartNumber});
            //                         })
            //                     }
            //                 }else {
            //                     alert(obj.message)
            //                 }
            //             },
            //             failure: function (response, opts) {
            //                 alert('错误：删除信息失败，请检查网络！!');
            //             }
            //         });
            //     }
            // }

            // 通过单元格索引获取列
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'productNumber'){
                    parentNumberCombo2.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getParentNumber?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var parentNumberList = Ext.decode(response.responseText).data;
                                if(parentNumberList){
                                    parentNumberList.map(function(item) {
                                        parentNumberCombo2.getStore().add({parentNumber:item.parentNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            function successCallback(data) {
                ctFollowUpTrialTwoBo1.getStore().reload();
            }
            updateFollowUpTrialTwo(editor, e, successCallback);
        }
    }
});

let ctContentEditing81 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

let ctFollowUpTrialTwoBo2 = Ext.create('Ext.grid.Panel', {
    id: 'ctFollowUpTrialTwoBo2',
    store: Ext.data.StoreManager.lookup('ctFollowUpTrialTwoStore2'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: 'IPQC测试项目填写',
    collapsible: true,
    collapsed:openPanel(IPQC_Approval_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing81],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('组合编码',isEditable(IPQC_Approval_Node)),
            width: 120,
            dataIndex: 'trialNumber',
            align: 'center',
            editAccess:isEditable(IPQC_Approval_Node),
            editor: combinationNumberCombo5
        },
        {
            text: setMust('产品编码',isEditable(IPQC_Approval_Node)),
            width: 120,
            dataIndex: 'productNumber',
            align: 'center',
            editAccess:isEditable(IPQC_Approval_Node),
            editor: parentNumberCombo3
        },
        {text: '物料描述', width: 240, dataIndex: 'partDesc', align: 'center', renderer:showTip},
        {
            text: setMust('试用跟进情况',isEditable(IPQC_Approval_Node)),
            width: 260,
            dataIndex: 'opinionIPQc',
            align: 'center',
            editAccess:isEditable(IPQC_Approval_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {text: '报告链接', width: 240, dataIndex: 'reportFileIPQc', align: 'center'}
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(IPQC_Approval_Node),
            handler: function () {
                ctContentEditing81.cancelEdit();
                function successCallback(data) {
                    let store = ctFollowUpTrialTwoBo2.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveFollowUpTrialTwo', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId, tableType: 'ipqc'}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(IPQC_Approval_Node),
            handler: function () {
                let selected = ctFollowUpTrialTwoBo2.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctFollowUpTrialTwoBo2.getStore().remove(selected);
                        ctFollowUpTrialTwoBo2.view.refresh();
                    }

                    function failCallback() {
                    }

                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteFollowUpTrialTwo', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        },
        {
            xtype: 'filefield',
            hidden: !isEditable(IPQC_Approval_Node),
            buttonOnly: true,
            id: 'IPQC_uploadFile',
            name: 'IPQC_uploadFile',
            hideLabel: true,
            buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '上传IPQC测试报告',
            allowBlank: false,
            scope: this,
            listeners: {
                'focus': function () {
                    let selectionArr = ctFollowUpTrialTwoBo2.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("reportFileIPQc");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    if (selectionArr.length >= 2) {
                        alert("不支持多行添加文件操作，请确认要添加的行");
                        return;
                    }
                },
                'change': function (fb, newValue) {
                    if (!newValue) {
                        return;
                    }
                    let selectionArr = ctFollowUpTrialTwoBo2.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("reportFileIPQc");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }

                    var file = document.querySelector('[id=' + 'IPQC_uploadFile' + '-button-fileInputEl]');
                    var formData = new FormData();
                    formData.append('IPQC_uploadFile' + '-button-fileInputEl', file.files[0]);
                    fb.reset();//清空表单的值
                    var myMask = new Ext.LoadMask({
                        msg: '正在上传，请稍候......',
                        target: this.findParentByType('panel')
                    });
                    var tRecord = ctFollowUpTrialTwoBo2.getSelectionModel().getSelection()[0];
                    var itemId = tRecord.get('id');
                    myMask.show();
                    $.ajax({
                        url: '/Windchill/ptc1/trial/uploadFiles?branchId=' + branchId + '&tetx_name=' + 'IPQC_uploadFile' + "&node=" + 'IPQC_node' + "&type=IPQC"+"&id="+itemId,
                        type: 'POST',
                        cache: false,
                        data: formData,
                        processData: false,
                        contentType: false
                    }).done(function (res) {
                        myMask.hide();
                        var obj = Ext.decode(res);
                        var success = obj['success'];
                        var msg = obj['msg'];
                        if (!success) {
                            alert(msg);
                        } else {
                            var fileName = obj['fileName'];
                            var filePath = obj['filePath'];

                            var attachmentValue = ctFollowUpTrialTwoBo2.getSelectionModel().getSelection()[0].data.attachmentFile;
                            var attachmentPath = ctFollowUpTrialTwoBo2.getSelectionModel().getSelection()[0].data.attachmentPath;
                            if (attachmentValue != null && attachmentValue != '') {
                                fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                            }
                            tRecord.set('reportFileIPQc', fileName);
                            tRecord.set('reportFilePathIPQc', filePath);
                            var callbackFn = function () {
                                tRecord.commit();
                            };
                            var itemId = tRecord.get('id');
                            saveMockItemData("ZFollowUpTrialTwoTable", itemId, 'reportFileIPQc', fileName, callbackFn);
                            saveMockItemData("ZFollowUpTrialTwoTable", itemId, 'reportFilePathIPQc', filePath, callbackFn);
                        }
                        var callbackFn = function () {
                            Ext.getStore('ctFollowUpTrialTwoStore2').reload();
                        };
                    }).fail(function (res) {
                        myMask.hide();
                        alert('上传失败！');
                    });
                }
            }
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'trialNumber') {
                    combinationNumberCombo5.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getCombinationNumber?branchId=' + branchId,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function (item) {
                                        combinationNumberCombo5.getStore().add({combinationNumber: item});
                                    })
                                }
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            // var combinationNumber = record.get('trialNumber');
            // // 通过单元格索引获取列
            // var column = headerCt.getGridColumns()[cellIndex + 2];
            // if (column) {
            //     var columnName = column.dataIndex;
            //     if(columnName == 'productNumber'){
            //         partNumberCombo3.getStore().removeAll();
            //         Ext.Ajax.request({
            //             url: '/Windchill/ptc1/trial/getTrialPartNumber?branchId=' + branchId + "&combinationNumber=" + combinationNumber,
            //             method:'GET',
            //             headers: {'Content-Type':'application/json'},
            //             success: function (response, opts) {
            //                 var obj = Ext.decode(response.responseText);
            //                 if(obj.message=='success') {
            //                     var combinationNumberList = Ext.decode(response.responseText).data;
            //                     if(combinationNumberList){
            //                         combinationNumberList.map(function(item) {
            //                             partNumberCombo3.getStore().add({trialPartNumber:item.trialPartNumber});
            //                         })
            //                     }
            //                 }else {
            //                     alert(obj.message)
            //                 }
            //             },
            //             failure: function (response, opts) {
            //                 alert('错误：删除信息失败，请检查网络！!');
            //             }
            //         });
            //     }
            // }

            // 通过单元格索引获取列
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'productNumber'){
                    parentNumberCombo3.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getParentNumber?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var parentNumberList = Ext.decode(response.responseText).data;
                                if(parentNumberList){
                                    parentNumberList.map(function(item) {
                                        parentNumberCombo3.getStore().add({parentNumber:item.parentNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            function successCallback(data) {
                ctFollowUpTrialTwoBo2.getStore().reload();
            }
            updateFollowUpTrialTwo(editor, e, successCallback);
        }
    }
});

let ctContentEditing82 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

let ctFollowUpTrialTwoBo3 = Ext.create('Ext.grid.Panel', {
    id: 'ctFollowUpTrialTwoBo3',
    store: Ext.data.StoreManager.lookup('ctFollowUpTrialTwoStore3'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: '技术部测试项目填写',
    collapsible: true,
    collapsed:openPanel(Technical_Department_Engineer_Approval_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing82],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('组合编码',isEditable(Technical_Department_Engineer_Approval_Node)),
            width: 120,
            dataIndex: 'trialNumber',
            align: 'center',
            editAccess:isEditable(Technical_Department_Engineer_Approval_Node),
            editor: combinationNumberCombo5
        },
        {
            text: setMust('产品编码',isEditable(Technical_Department_Engineer_Approval_Node)),
            width: 120,
            dataIndex: 'productNumber',
            align: 'center',
            editAccess:isEditable(Technical_Department_Engineer_Approval_Node),
            editor: parentNumberCombo4
        },
        {text: '物料描述', width: 240, dataIndex: 'partDesc', align: 'center', renderer:showTip},
        {
            text: setMust('试用跟进情况（生产工艺，产品功能，直通率）',isEditable(Technical_Department_Engineer_Approval_Node)),
            width: 260,
            dataIndex: 'opinionTechnology',
            align: 'center',
            editAccess:isEditable(Technical_Department_Engineer_Approval_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
        },
        {text: '报告链接', width: 240, dataIndex: 'reportFileTechnology', align: 'center'}
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(Technical_Department_Engineer_Approval_Node),
            handler: function () {
                ctContentEditing82.cancelEdit();
                function successCallback(data) {
                    let store = ctFollowUpTrialTwoBo3.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveFollowUpTrialTwo', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId, tableType: 'technology'}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(Technical_Department_Engineer_Approval_Node),
            handler: function () {
                let selected = ctFollowUpTrialTwoBo3.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctFollowUpTrialTwoBo3.getStore().remove(selected);
                        ctFollowUpTrialTwoBo3.view.refresh();
                    }

                    function failCallback() {
                    }

                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteFollowUpTrialTwo', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        },
        {
            xtype: 'filefield',
            hidden: !isEditable(Technical_Department_Engineer_Approval_Node),
            buttonOnly: true,
            id: 'TechnicalTest_uploadFile',
            name: 'TechnicalTest_uploadFile',
            hideLabel: true,
            buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '上传技术部测试报告',
            allowBlank: false,
            scope: this,
            listeners: {
                'focus': function () {
                    let selectionArr = ctFollowUpTrialTwoBo3.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("reportFileTechnology");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    if (selectionArr.length >= 2) {
                        alert("不支持多行添加文件操作，请确认要添加的行");
                        return;
                    }
                },
                'change': function (fb, newValue) {
                    if (!newValue) {
                        return;
                    }
                    let selectionArr = ctFollowUpTrialTwoBo3.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("reportFileTechnology");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    var file = document.querySelector('[id=' + 'TechnicalTest_uploadFile' + '-button-fileInputEl]');
                    var formData = new FormData();
                    formData.append('TechnicalTest_uploadFile' + '-button-fileInputEl', file.files[0]);
                    fb.reset();//清空表单的值
                    var myMask = new Ext.LoadMask({
                        msg: '正在上传，请稍候......',
                        target: this.findParentByType('panel')
                    });
                    var tRecord = ctFollowUpTrialTwoBo3.getSelectionModel().getSelection()[0];
                    var itemId = tRecord.get('id');
                    myMask.show();
                    $.ajax({
                        url: '/Windchill/ptc1/trial/uploadFiles?branchId=' + branchId + '&tetx_name=' + 'TechnicalTest_uploadFile' + "&node=" + 'TechnicalTest_node' + "&type=TechnicalTest" + "&id=" + itemId,
                        type: 'POST',
                        cache: false,
                        data: formData,
                        processData: false,
                        contentType: false
                    }).done(function (res) {
                        myMask.hide();
                        var obj = Ext.decode(res);
                        var success = obj['success'];
                        var msg = obj['msg'];
                        if (!success) {
                            alert(msg);
                        } else {
                            var fileName = obj['fileName'];
                            var filePath = obj['filePath'];

                            var attachmentValue = ctFollowUpTrialTwoBo3.getSelectionModel().getSelection()[0].data.reportFileTechnology;
                            var attachmentPath = ctFollowUpTrialTwoBo3.getSelectionModel().getSelection()[0].data.reportFilePathTechnology;
                            if (attachmentValue != null && attachmentValue != '') {
                                fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                            }
                            tRecord.set('reportFileTechnology', fileName);
                            tRecord.set('reportFilePathTechnology', filePath);
                            var callbackFn = function () {
                                tRecord.commit();
                            };
                            var itemId = tRecord.get('id');
                            saveMockItemData("ZFollowUpTrialTwoTable", itemId, 'reportFileTechnology', fileName, callbackFn);
                            saveMockItemData("ZFollowUpTrialTwoTable", itemId, 'reportFilePathTechnology', filePath, callbackFn);
                        }
                        var callbackFn = function () {
                            Ext.getStore('ctFollowUpTrialTwoStore3').reload();
                        };
                    }).fail(function (res) {
                        myMask.hide();
                        alert('上传失败！');
                    });
                }
            }
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'trialNumber') {
                    combinationNumberCombo5.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getCombinationNumber?branchId=' + branchId,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function (item) {
                                        combinationNumberCombo5.getStore().add({combinationNumber: item});
                                    })
                                }
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            // var combinationNumber = record.get('trialNumber');
            // // 通过单元格索引获取列
            // var column = headerCt.getGridColumns()[cellIndex + 2];
            // if (column) {
            //     var columnName = column.dataIndex;
            //     if(columnName == 'productNumber'){
            //         partNumberCombo3.getStore().removeAll();
            //         Ext.Ajax.request({
            //             url: '/Windchill/ptc1/trial/getTrialPartNumber?branchId=' + branchId + "&combinationNumber=" + combinationNumber,
            //             method:'GET',
            //             headers: {'Content-Type':'application/json'},
            //             success: function (response, opts) {
            //                 var obj = Ext.decode(response.responseText);
            //                 if(obj.message=='success') {
            //                     var combinationNumberList = Ext.decode(response.responseText).data;
            //                     if(combinationNumberList){
            //                         combinationNumberList.map(function(item) {
            //                             partNumberCombo3.getStore().add({trialPartNumber:item.trialPartNumber});
            //                         })
            //                     }
            //                 }else {
            //                     alert(obj.message)
            //                 }
            //             },
            //             failure: function (response, opts) {
            //                 alert('错误：删除信息失败，请检查网络！!');
            //             }
            //         });
            //     }
            // }
            // 通过单元格索引获取列
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'productNumber'){
                    parentNumberCombo4.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getParentNumber?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var parentNumberList = Ext.decode(response.responseText).data;
                                if(parentNumberList){
                                    parentNumberList.map(function(item) {
                                        parentNumberCombo4.getStore().add({parentNumber:item.parentNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            function successCallback(data) {
                ctFollowUpTrialTwoBo3.getStore().reload();
            }
            updateFollowUpTrialTwo(editor, e, successCallback);
        }
    }
});
