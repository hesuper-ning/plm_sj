let ctContentEditing2 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

Ext.define('ctTechnicalDocumentModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'docType', 'attachmentFile', 'attachmentPath',
    'partNumber', 'relatedSuppliers', 'attachmentDescription', 'trialNumber'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctTechnicalDocumentModel',
    storeId: 'ctTechnicalDocumentStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getTechnicalDocument?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//文档类型
var docTypeStore = Ext.create('Ext.data.Store', {
    fields: ['innerName', 'displayName'],
    id: 'docTypeStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getLeafDocType',
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }),
    autoLoad: true
});

//物料编码
var tdPartNumberCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'tdPartNumberCombo',
    id: 'tdPartNumberCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['partNumber']
    },
    valueField: 'partNumber',
    displayField: 'partNumber'
});

//供应商信息
var supplierCombo1 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'supplierCombo1',
    id: 'supplierCombo1',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['relatedSuppliers']
    },
    valueField: 'relatedSuppliers',
    displayField: 'relatedSuppliers'
});

//组合编码
var combinationNumberCombo51 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'combinationNumberCombo51',
    id: 'combinationNumberCombo51',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['combinationNumber']
    },
    valueField: 'combinationNumber',
    displayField: 'combinationNumber'
});

let ctTechnicalDocumentBo = Ext.create('Ext.grid.Panel', {
    id: 'ctTechnicalDocumentBo',
    store: Ext.data.StoreManager.lookup('ctTechnicalDocumentStore'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: '2. 相关技术文档',
    collapsible: true,
    collapsed:openPanel(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Production_Manager_Approval_Node,Technical_Department_Manager_Node,Quality_Control_Department_Manager_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing2],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setRequired('组合编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 120,
            dataIndex: 'trialNumber',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: combinationNumberCombo51
        },
        // {
        //     text: setMust('文档类型',isEditable(Update_Confirm_Trial_Plan_Submit_Node)),
        //     width: 280,
        //     dataIndex: 'docType',
        //     align: 'center',
        //     editAccess:isEditable(Update_Confirm_Trial_Plan_Submit_Node),
        //     editor: {
        //         xtype: 'combo',
        //         editable: true,
        //         forceSelection: false,
        //         store: docTypeStore,
        //         displayField: 'displayName',
        //         valueField: 'innerName',
        //         queryMode: 'local'
        //     }
        //     , renderer:showTip
        // },
        {
            text: setRequired('上传附件',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 260,
            dataIndex: 'attachmentFile',
            align: 'center'
        },
        // {
        //     text: setMust('关联物料对象',isEditable(Update_Confirm_Trial_Plan_Submit_Node)),
        //     width: 120,
        //     dataIndex: 'partNumber',
        //     align: 'center',
        //     editAccess:isEditable(Update_Confirm_Trial_Plan_Submit_Node),
        //     editor: tdPartNumberCombo
        // },
        // {
        //     text: setMust('关联供应商',isEditable(Update_Confirm_Trial_Plan_Submit_Node)),
        //     width: 300,
        //     dataIndex: 'relatedSuppliers',
        //     align: 'center',
        //     editAccess:isEditable(Update_Confirm_Trial_Plan_Submit_Node),
        //     editor: supplierCombo1
        // },
        {
            text: setRequired('附件说明',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 300,
            dataIndex: 'attachmentDescription',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        }
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            handler: function () {
                ctContentEditing2.cancelEdit();
                function successCallback(data) {
                    let store = ctTechnicalDocumentBo.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveTechnicalDocument', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            handler: function () {
                let selected = ctTechnicalDocumentBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctTechnicalDocumentBo.getStore().remove(selected);
                        ctTechnicalDocumentBo.view.refresh();
                    }

                    function failCallback() {
                    }
                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteTechnicalDocument', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        },
        {
            xtype: 'filefield',
            hidden: !isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            buttonOnly: true,
            id: 'technicalDocument_uploadFile',
            name: 'technicalDocument_uploadFile',
            hideLabel: true,
            buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '上传附件',
            allowBlank: false,
            scope: this,
            listeners: {
                'focus': function () {
                    let selectionArr = ctTechnicalDocumentBo.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("attachmentFile");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    if (selectionArr.length >= 2) {
                        alert("不支持多行添加文件操作，请确认要添加的行");
                        return;
                    }
                },
                'change': function (fb, newValue) {
                    if (!newValue) {
                        return;
                    }
                    let selectionArr = ctTechnicalDocumentBo.getSelectionModel().getSelection();
                    var file = selectionArr[0].get("attachmentFile");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    if (selectionArr.length == 0) {
                        alert("添加文件失败，未选择添加文件对象!");
                        return;
                    } else {
                        var file = document.querySelector('[id=' + 'technicalDocument_uploadFile' + '-button-fileInputEl]');
                        var formData = new FormData();
                        formData.append('technicalDocument_uploadFile' + '-button-fileInputEl', file.files[0]);
                        fb.reset();//清空表单的值
                        var myMask = new Ext.LoadMask({
                            msg: '正在上传，请稍候......',
                            target: this.findParentByType('panel')
                        });
                        var tRecord = ctTechnicalDocumentBo.getSelectionModel().getSelection()[0];
                        var itemId = tRecord.get('id');
                        myMask.show();
                        $.ajax({
                            url: '/Windchill/ptc1/trial/uploadFiles?branchId=' + branchId + '&tetx_name=' + 'technicalDocument_uploadFileRecord' + "&node=" + 'technicalDocument_node' + "&type=technicalDocument"+"&id="+itemId,
                            type: 'POST',
                            cache: false,
                            data: formData,
                            processData: false,
                            contentType: false
                        }).done(function (res) {
                            myMask.hide();
                            var obj = Ext.decode(res);
                            var success = obj['success'];
                            var msg = obj['msg'];
                            if (!success) {
                                alert(msg);
                            } else {
                                var fileName = obj['fileName'];
                                var filePath = obj['filePath'];

                                var attachmentValue = ctTechnicalDocumentBo.getSelectionModel().getSelection()[0].data.attachmentFile;
                                var attachmentPath = ctTechnicalDocumentBo.getSelectionModel().getSelection()[0].data.attachmentPath;
                                if (attachmentValue != null && attachmentValue != '') {
                                    fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                    filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                }
                                tRecord.set('attachmentFile', fileName);
                                tRecord.set('attachmentPath', filePath);
                                var callbackFn = function () {
                                    tRecord.commit();
                                };
                                var itemId = tRecord.get('id');
                                saveMockItemData("ZTechnicalDocumentTable", itemId, 'attachmentFile', fileName, callbackFn);
                                saveMockItemData("ZTechnicalDocumentTable", itemId, 'attachmentPath', filePath, callbackFn);
                            }
                            var callbackFn = function () {
                                Ext.getStore('ctTechnicalDocumentStore').reload();
                            };
                        }).fail(function (res) {
                            myMask.hide();
                            alert('上传失败！');
                        });
                    }
                }

            }
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'partNumber'){
                    tdPartNumberCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getPartNumberByBranchId?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                let partNumberList = Ext.decode(response.responseText).data;
                                if(partNumberList){
                                    partNumberList.map(function(item) {
                                        tdPartNumberCombo.getStore().add({partNumber:item.partNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            // 通过单元格索引获取列
            let partNumber = record.get('partNumber');
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column && partNumber) {
                var columnName = column.dataIndex;
                if(columnName == 'relatedSuppliers'){
                    supplierCombo1.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getSelectedSupplier?partNumber=' + partNumber + '&branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var supplierList = Ext.decode(response.responseText).data;
                                if(supplierList){
                                    supplierList.map(function(item) {
                                        supplierCombo1.getStore().add({relatedSuppliers:item.supplierInfo});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'trialNumber') {
                    combinationNumberCombo51.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getCombinationNumber?branchId=' + branchId,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function (item) {
                                        combinationNumberCombo51.getStore().add({combinationNumber: item});
                                    })
                                }
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            //变更操作为增加，“变更前物料编码”不可编辑
            if(e.field == 'relatedSuppliers') {
                var record = e.record;
                var partNumber = record.get('partNumber');
                if(!partNumber) {
                    return false;
                }
            }
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            updateTechnicalDocument(editor, e);
        }
    }
});
