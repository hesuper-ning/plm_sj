let ctContentEditing4 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

Ext.define('ctDemandPlanModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'docType', 'combinationNumber', 'parentNumber',
    'parentDesc', 'changeType', 'partNumberBefore', 'partDescBefore', 'quantityBefore',
    'tagNumberBefore', 'internalVersionBefore', 'bomRemarksBefore', 'supplierBefore', 'partNumberAfter',
    'partDescAfter', 'quantityAfter', 'tagNumberAfter', 'internalVersionAfter', 'bomRemarksAfter',
    'supplierAfter', 'remarks'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctDemandPlanModel',
    storeId: 'ctDemandPlanStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getDemandPlan?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//组合编号
var combinationNumberCombo2 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'combinationNumberCombo2',
    id: 'combinationNumberCombo2',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['combinationNumber']
    },
    valueField: 'combinationNumber',
    displayField: 'combinationNumber'
});

//试用编码
var trialPartCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'trialPartCombo',
    id: 'trialPartCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['trialPartNumber']
    },
    valueField: 'trialPartNumber',
    displayField: 'trialPartNumber'
});

let ctDemandPlanBo = Ext.create('Ext.grid.Panel', {
    id: 'ctDemandPlanBo',
    store: Ext.data.StoreManager.lookup('ctDemandPlanStore'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: '4. 需求计划单号',
    collapsible: true,
    collapsed:openPanel(Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Order_Node,Production_Manager_Approval_Node,Technical_Department_Manager_Node,Quality_Control_Department_Manager_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing4],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('组合编码',isEditable(Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 90,
            dataIndex: 'combinationNumber',
            align: 'center',
            editAccess:isEditable(Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: combinationNumberCombo2
        },
        {
            text: setMust('试用物料编码',isEditable(Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 120,
            dataIndex: 'trialPartNumber',
            align: 'center',
            editAccess:isEditable(Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: trialPartCombo
        },
        {text: '试用物料描述', width: 120, dataIndex: 'trialPartDesc', align: 'center'},
        {
            text: setMust('工单编号',isEditable(Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Order_Node)),
            width: 120,
            dataIndex: 'orderNumber',
            align: 'center',
            editAccess:isEditable(Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Order_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {text: '工单数量', width: 120, dataIndex: 'orderQuantity', align: 'center', renderer:showTip},
        {text: '工单状态', width: 120, dataIndex: 'orderState', align: 'center', renderer:showTip},
        {
            text: setRequired('工单处理意见',isEditable(Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 300,
            dataIndex: 'handlingOpinions',
            align: 'center',
            editAccess:isEditable(Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        }
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(Update_Confirm_Trial_Plan_Material_Control_Node),
            handler: function () {
                ctContentEditing4.cancelEdit();
                function successCallback(data) {
                    let store = ctDemandPlanBo.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveDemandPlan', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(Update_Confirm_Trial_Plan_Material_Control_Node),
            handler: function () {
                let selected = ctDemandPlanBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctDemandPlanBo.getStore().remove(selected);
                        ctDemandPlanBo.view.refresh();
                    }

                    function failCallback() {
                    }

                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteDemandPlan', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'combinationNumber'){
                    combinationNumberCombo2.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getCombinationNumber?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        combinationNumberCombo2.getStore().add({combinationNumber:item});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            var combinationNumber = record.get('combinationNumber');
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'trialPartNumber'){
                    trialPartCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getTrialPartNumber?branchId=' + branchId + "&combinationNumber=" + combinationNumber,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        trialPartCombo.getStore().add({trialPartNumber:item.trialPartNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            updateDemandPlan(editor, e);
        }
    }
});
