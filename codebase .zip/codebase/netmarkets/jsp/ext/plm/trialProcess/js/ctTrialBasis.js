let ctTrialBasisBo =  Ext.create('Ext.form.Panel', {
    title: 'S01：基础信息',
    id:'ctTrialBasisBo',
    autoWidth:true,
    xtype: 'form',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
        {
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
                // {
                //     xtype: 'displayfield',
                //     fieldLabel: setRequired('试用方案', isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
                //     labelWidth: 170,
                // },uploadFilefield("trialPlanFile","点击上传","trialPlan_node","trialPlanFilePath","trialPlan"),{
                //     xtype:'displayfield',
                //     fieldLabel: '方案链接',
                //     labelWidth:70,
                //     id:'trialPlanFilePath',
                //     name:'trialPlanFilePath',
                //     width:'30%'
                // },
                {
                    xtype: 'displayfield',
                    fieldLabel: '关联样品确认单号',
                    labelAlign: 'right',
                    id: 'sampleOrderUrl',
                    name: 'sampleOrderUrl',
                    width: 285
                },
                {
                    xtype: 'displayfield',
                    fieldLabel: '关联工程变更单号',
                    labelAlign: 'right',
                    id: 'engineeringChangesOrder',
                    name: 'engineeringChangesOrder',
                    width: 285
                }
            ]
        }
    ],
    listeners:{
        'afterrender': function () {
            loadBasisFormData();
        }
    }
});