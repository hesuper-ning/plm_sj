let ctContentEditing3 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

//变更类型Store
let changeTypeStore = [
    ['增加', '增加'],
    ['删除', '删除'],
    ['修改', '修改']
]

Ext.define('ctTrialMBomModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'docType', 'combinationNumber', 'parentNumber',
    'parentDesc', 'changeType', 'partNumberBefore', 'partDescBefore', 'quantityBefore',
    'tagNumberBefore', 'internalVersionBefore', 'bomRemarksBefore', 'supplierBefore', 'partNumberAfter',
    'partDescAfter', 'quantityAfter', 'tagNumberAfter', 'internalVersionAfter', 'bomRemarksAfter',
    'supplierAfter', 'remarks'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctTrialMBomModel',
    storeId: 'ctTrialMBomStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getTrialMBom?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//组合编号
var combinationNumberCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'combinationNumberCombo',
    id: 'combinationNumberCombo',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['combinationNumber']
    },
    valueField: 'combinationNumber',
    displayField: 'combinationNumber'
});

//父项编码
let parentNumberCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'parentNumberCombo',
    id: 'parentNumberCombo',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['parentNumber']
    },
    valueField: 'parentNumber',
    displayField: 'parentNumber'
});

//变更前供应商信息
let supplierCombo2 = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'supplierCombo2',
    id: 'supplierCombo2',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['supplierInfo']
    },
    valueField: 'supplierInfo',
    displayField: 'supplierInfo'
});

//变更后物料编码
var changeAfterPartNumberCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'changeAfterPartNumberCombo',
    id: 'changeAfterPartNumberCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['partNumber']
    },
    valueField: 'partNumber',
    displayField: 'partNumber'
});

//变更前物料编码
var changeBeforePartNumberCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'changeBeforePartNumberCombo',
    id: 'changeBeforePartNumberCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['partNumber']
    },
    valueField: 'partNumber',
    displayField: 'partNumber'
});

let ctTrialMBomBo = Ext.create('Ext.grid.Panel', {
    id: 'ctTrialMBomBo',
    store: Ext.data.StoreManager.lookup('ctTrialMBomStore'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: '3. 试用MBOM',
    collapsible: true,
    collapsed:openPanel(Update_Confirm_Trial_Plan_Material_Control_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing3],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 50, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('组合编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 70,
            dataIndex: 'combinationNumber',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: combinationNumberCombo
        },
        {
            text: setMust('父项编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 70,
            dataIndex: 'parentNumber',
            align: 'left',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: parentNumberCombo
        },
        {text: '父项描述', width: 60, dataIndex: 'parentDesc', align: 'center', renderer:showTip},
        {
            text: setMust('变更类型',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 70,
            dataIndex: 'changeType',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: {
                xtype: 'combo',
                editable: false,
                forceSelection: false,
                store: changeTypeStore
            }
            , renderer:showTip
        },
        {
            text: '变更前',
            menuDisabled: true,
            columns: [
                {
                    text: setRequired('物料编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
                    width: 70,
                    dataIndex: 'partNumberBefore',
                    align: 'center',
                    editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
                    editor: changeBeforePartNumberCombo,
                    renderer:showTip
                },
                {text: '物料描述', width: 60, dataIndex: 'partDescBefore', align: 'center', renderer:showTip, editAccess: false},
                {
                    text: '数量',
                    width: 50,
                    dataIndex: 'quantityBefore',
                    align: 'center',
                    editAccess: false,
                    renderer:showTip
                },
                {
                    text: '位号',
                    width: 60,
                    dataIndex: 'tagNumberBefore',
                    align: 'center',
                    editAccess: false,
                    renderer:showTip
                },
                {text: '内部版本', width: 60, dataIndex: 'internalVersionBefore', align: 'center', renderer:showTip, editAccess: false},
                {
                    text: 'BOM备注',
                    width: 70,
                    dataIndex: 'bomRemarksBefore',
                    align: 'center',
                    editAccess: false,
                    renderer:showTip
                },
                {text: '供应商', width: 60, dataIndex: 'supplierBefore', align: 'center', editAccess: false, renderer:showTip}
            ]
        },
        {
            text: '变更后',
            menuDisabled: true,
            columns: [
                {
                    text: setRequired('物料编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
                    width: 70,
                    dataIndex: 'partNumberAfter',
                    align: 'center',
                    editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
                    editor: changeAfterPartNumberCombo
                    , renderer:showTip
                },
                {text: '物料描述', width: 60, dataIndex: 'partDescAfter', align: 'center', renderer:showTip, editAccess: false},
                {
                    text: setRequired('数量',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
                    width: 50,
                    dataIndex: 'quantityAfter',
                    align: 'center',
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
                    renderer:showTip
                },
                {
                    text: setRequired('位号',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
                    width: 60,
                    dataIndex: 'tagNumberAfter',
                    align: 'center',
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
                    renderer:showTip
                },
                {text: '内部版本', width: 60, dataIndex: 'internalVersionAfter', align: 'center', renderer:showTip, editAccess: false},
                {
                    text: setRequired('BOM备注',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
                    width: 80,
                    dataIndex: 'bomRemarksAfter',
                    align: 'center',
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
                    renderer:showTip
                },
                {
                    text: setRequired('供应商',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
                    width: 60,
                    dataIndex: 'supplierAfter',
                    align: 'center',
                    editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
                    editor: supplierCombo2
                    , renderer:showTip
                }
            ]
        },
        {
            text: setRequired('备注',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 60,
            dataIndex: 'remarks',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        }
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            handler: function () {
                ctContentEditing3.cancelEdit();
                function successCallback(data) {
                    let store = ctTrialMBomBo.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveTrialMBom', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            handler: function () {
                let selected = ctTrialMBomBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctTrialMBomBo.getStore().remove(selected);
                        ctTrialMBomBo.view.refresh();
                    }

                    function failCallback() {
                    }

                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteTrialMBom', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        },
        {
            text: '导出更改后BOM',
            iconCls: 'icon icon-excelExport',
            disabled: !isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            handler: function () {
                ctContentEditing3.cancelEdit();
                exportUpdateBOM();
            },
            scope: this
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'combinationNumber'){
                    combinationNumberCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getCombinationNumber?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        combinationNumberCombo.getStore().add({combinationNumber:item});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            var partNumberBefore = record.get('partNumberBefore');
            // 通过单元格索引获取列
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'supplierBefore'){
                    supplierCombo2.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getSupplierByPartNumber?partNumber=' + partNumberBefore,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var supplierInfoList = Ext.decode(response.responseText).data;
                                if(supplierInfoList){
                                    supplierInfoList.map(function(item) {
                                        supplierCombo2.getStore().add({supplierInfo:item.supplierInfo});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            // 通过单元格索引获取列
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'parentNumber'){
                    parentNumberCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getParentNumber?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var parentNumberList = Ext.decode(response.responseText).data;
                                if(parentNumberList){
                                    parentNumberList.map(function(item) {
                                        parentNumberCombo.getStore().add({parentNumber:item.parentNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            // 通过单元格索引获取列
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'partNumberAfter'){
                    changeAfterPartNumberCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getPartNumberByBranchId?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var parentNumberList = Ext.decode(response.responseText).data;
                                if(parentNumberList){
                                    parentNumberList.map(function(item) {
                                        changeAfterPartNumberCombo.getStore().add({partNumber:item.partNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'partNumberBefore'){
                    changeBeforePartNumberCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getReplacedPartNumberByBranchId?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var parentNumberList = Ext.decode(response.responseText).data;
                                if(parentNumberList){
                                    parentNumberList.map(function(item) {
                                        changeBeforePartNumberCombo.getStore().add({partNumber:item.partNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },

        beforeedit: function (editor, obj) {
            //变更操作为增加，“变更前物料编码”不可编辑
            if(obj.field == 'partNumberBefore' || obj.field == 'supplierBefore') {
                var record = obj.record;
                var changeType = record.get('changeType');
                if(changeType == '增加') {
                    return false;
                }
            }
            //变更操作为删除，“变更后物料编码”不可编辑
            if(obj.field == 'partNumberAfter' || obj.field == 'quantityAfter'
                || obj.field == 'tagNumberAfter' || obj.field == 'bomRemarksAfter') {
                var record = obj.record;
                var changeType = record.get('changeType');
                if(changeType == '删除') {
                    return false;
                }
            }
            //父项编码未选择，则不能填物料编码
            if(obj.field == 'partNumberBefore' || obj.field == 'partNumberAfter') {
                var record = obj.record;
                var parentNumber = record.get('parentNumber');
                if(!parentNumber) {
                    Ext.Msg.alert("提示", "请先填写父项编号！");
                    return false;
                }
            }
            if(obj.field == 'partNumberBefore'){
                var record = obj.record;
                var changeType = record.get('changeType');
                if (changeType == '删除'){
                    Ext.getCmp('changeBeforePartNumberCombo').setEditable(true);
                }else {
                    Ext.getCmp('changeBeforePartNumberCombo').setEditable(false);
                }

            }
            return checkBeforeEdit(editor, obj);
        },
        edit: function (editor, e) {
            updateTrialMBom(editor, e);
        }
    }
});
