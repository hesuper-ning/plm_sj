let ctContentEditing5 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

Ext.define('ctIncomingInspectionModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'docType', 'partNumber', 'partDesc',
    'partVersion', 'supplierNumber', 'inspectionResults', 'pr', 'po',
    'illustrate','annexFile'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctIncomingInspectionModel',
    storeId: 'ctIncomingInspectionStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getIncomingInspection?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

let preparationPanel =  Ext.create('Ext.panel.Panel', {
    title: 'S02：试用前期准备',
    id:'preparationPanel',
    autoWidth:true,
    anchor: '100%'
});

//物料编码
var IncomePartNumberCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'IncomePartNumberCombo',
    id: 'IncomePartNumberCombo',
    multiSelect: false,
    anyMatch: true,
    editable: false,
    store: {
        data: [
        ],
        fields: ['partNumber']
    },
    valueField: 'partNumber',
    displayField: 'partNumber'
});

//来料检验结果Store
let IncomingInspectionResultStore = [
    ['通过', '通过'],['不通过', '不通过']
]

let ctIncomingInspectionBo = Ext.create('Ext.grid.Panel', {
    id: 'ctIncomingInspectionBo',
    store: Ext.data.StoreManager.lookup('ctIncomingInspectionStore'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: '1. 质量控制部来料检验情况',
    collapsible: true,
    collapsed:openPanel(Material_Preparation_PR_Node,Fill_In_PO_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Incoming_Inspection_Node,Production_Manager_Approval_Node,Technical_Department_Manager_Node,Quality_Control_Department_Manager_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing5],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('物料编码',isEditable(Material_Preparation_PR_Node,Fill_In_PO_Node,Incoming_Inspection_Node)),
            width: 80,
            dataIndex: 'partNumber',
            align: 'center',
            editAccess:isEditable(Material_Preparation_PR_Node,Fill_In_PO_Node,Incoming_Inspection_Node),
            editor: IncomePartNumberCombo
        },
        {text: '物料描述', width: 120, dataIndex: 'partDesc', align: 'center', renderer:showTip},
        {
            text: setMust('内部版本',isEditable(Material_Preparation_PR_Node,Fill_In_PO_Node)),
            width: 120,
            dataIndex: 'partVersion',
            align: 'center',
            editAccess:isEditable(Material_Preparation_PR_Node,Fill_In_PO_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {text: '供应商编码_名称', width: 200, dataIndex: 'supplierNumber', align: 'center', renderer:showTip},
        {
            text: setMust('PR',isEditable(Material_Preparation_PR_Node,Update_Confirm_Trial_Plan_Material_Control_Node)),
            width: 80,
            dataIndex: 'pr',
            align: 'center',
            editAccess:isEditable(Material_Preparation_PR_Node,Update_Confirm_Trial_Plan_Material_Control_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('PO',isEditable(Fill_In_PO_Node)),
            width: 80,
            dataIndex: 'po',
            align: 'center',
            editAccess:isEditable(Fill_In_PO_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('来料检验结果',isEditable(Incoming_Inspection_Node)),
            width: 100,
            dataIndex: 'inspectionResults',
            align: 'center',
            editAccess:isEditable(Incoming_Inspection_Node),
            editor: {
                xtype: 'combo',
                editable: false,
                forceSelection: false,
                store: IncomingInspectionResultStore
            }
            , renderer:showTip
        },
        {
            text: setRequired('说明',isEditable(Incoming_Inspection_Node)),
            width: 120,
            dataIndex: 'illustrate',
            align: 'center',
            editAccess:isEditable(Incoming_Inspection_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setRequired('附件',isEditable(Incoming_Inspection_Node)),
            width: 200,
            dataIndex: 'annexFile',
            align: 'center'
        }
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(Fill_In_PO_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Incoming_Inspection_Node),
            handler: function () {
                ctContentEditing5.cancelEdit();
                function successCallback(data) {
                    let store = ctIncomingInspectionBo.getStore();
                    store.insert(store.getCount(), data);
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveIncomingInspection', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(Fill_In_PO_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Incoming_Inspection_Node),
            handler: function () {
                let selected = ctIncomingInspectionBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctIncomingInspectionBo.getStore().remove(selected);
                        ctIncomingInspectionBo.view.refresh();
                    }

                    function failCallback() {
                    }

                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteIncomingInspection', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        },
        {
            xtype: 'filefield',
            hidden: !isEditable(Incoming_Inspection_Node),
            buttonOnly: true,
            id: 'IncomingInspection_annexFile',
            name: 'IncomingInspection_annexFile',
            hideLabel: true,
            buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '上传附件',
            allowBlank: false,
            scope: this,
            listeners: {
                'focus': function () {
                    let selectionArr = ctIncomingInspectionBo.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("annexFile");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    if (selectionArr.length >= 2) {
                        alert("不支持多行添加文件操作，请确认要添加的行");
                        return;
                    }
                },
                'change': function (fb, newValue) {
                    if (!newValue) {
                        return;
                    }
                    let selectionArr = ctIncomingInspectionBo.getSelectionModel().getSelection();
                    if (selectionArr.length == 0) {
                        alert("未选择添加文件行！");
                        return;
                    }
                    var file = selectionArr[0].get("annexFile");
                    if (file != undefined) {
                        alert("只能上传一个文件!");
                        return;
                    }
                    var file = document.querySelector('[id=' + 'IncomingInspection_annexFile' + '-button-fileInputEl]');
                    var formData = new FormData();
                    formData.append('IncomingInspection_annexFile' + '-button-fileInputEl', file.files[0]);
                    fb.reset();//清空表单的值
                    var myMask = new Ext.LoadMask({
                        msg: '正在上传，请稍候......',
                        target: this.findParentByType('panel')
                    });
                    var tRecord = ctIncomingInspectionBo.getSelectionModel().getSelection()[0];
                    var itemId = tRecord.get('id');
                    myMask.show();
                    $.ajax({
                        url: '/Windchill/ptc1/trial/uploadFiles?branchId=' + branchId + '&tetx_name=' + 'IncomingInspection_annexFile' + "&node=" + 'IncomingInspection_node' + "&type=annexFile" + "&id=" + itemId,
                        type: 'POST',
                        cache: false,
                        data: formData,
                        processData: false,
                        contentType: false
                    }).done(function (res) {
                        myMask.hide();
                        var obj = Ext.decode(res);
                        var success = obj['success'];
                        var msg = obj['msg'];
                        if (!success) {
                            alert(msg);
                        } else {
                            var fileName = obj['fileName'];
                            var attachmentValue = ctIncomingInspectionBo.getSelectionModel().getSelection()[0].data.annexFile;
                            if (attachmentValue != null && attachmentValue != '') {
                                fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                            }
                            tRecord.set('annexFile', fileName);
                            var callbackFn = function () {
                                tRecord.commit();
                            };
                            var itemId = tRecord.get('id');
                            saveMockItemData("ZIncomingInspectionTable", itemId, 'annexFile', fileName, callbackFn);
                        }
                        var callbackFn = function () {
                            Ext.getStore('ctIncomingInspectionStore').reload();
                        };
                    }).fail(function (res) {
                        myMask.hide();
                        alert('上传失败！');
                    });
                }
            }
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'partNumber'){
                    IncomePartNumberCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getPartNumberByBranchId?branchId=' + branchId,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var partNumberList = Ext.decode(response.responseText).data;
                                if(partNumberList){
                                    partNumberList.map(function(item) {
                                        IncomePartNumberCombo.getStore().add({partNumber:item.partNumber});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            updateIncomingInspection(editor, e);
        }
    }
});
