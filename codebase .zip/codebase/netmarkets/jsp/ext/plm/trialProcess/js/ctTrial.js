Ext.define('PLM.view.TrialPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.TrialPanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'trialPanel',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        items: [ctTrialBasisBo, ctTrialCombinationBo, ctTechnicalDocumentBo, ctTrialMBomBo, ctDemandPlanBo,
                            preparationPanel, ctIncomingInspectionBo, ctTrialStandardBo,
                            ctFollowUpTrialBo,
                            ctFollowUpTrialTwoBo2,ctFollowUpTrialTwoBo3,ctFollowUpTrialTwoBo1,
                            ctTrialResultBo
                        ]
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    }
});