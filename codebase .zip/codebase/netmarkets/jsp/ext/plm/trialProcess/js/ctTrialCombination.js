let ctContentEditing1 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});


//组合编号Store
let combinationNumberStore = [
    ['P001', 'P001'],['P002', 'P002'],['P003', 'P003'],['P004', 'P004'],['P005', 'P005'],['P006', 'P006'],['P007', 'P007'],
    ['P008', 'P008'],['P009', 'P009'],['P010', 'P010'],['P011', 'P011'],['P012', 'P012'],['P013', 'P013'],['P014', 'P014'],
    ['P015', 'P015'],['P016', 'P016'],['P017', 'P017'],['P018', 'P018'],['P019', 'P019'],['P020', 'P020'],['P021', 'P021'],
    ['P022', 'P022'],['P023', 'P023'],['P024', 'P024'],['P025', 'P025'],['P026', 'P026'],['P027', 'P027'],['P028', 'P028'],
    ['P029', 'P029'],['P030', 'P030'],['P031', 'P031'],['P032', 'P032'],['P033', 'P033'],['P034', 'P034'],['P035', 'P035'],
    ['P036', 'P036'],['P037', 'P037'],['P038', 'P038'],['P039', 'P039'],['P040', 'P040'],['P041', 'P041'],['P042', 'P042'],
    ['P043', 'P043'],['P044', 'P044'],['P045', 'P045'],['P046', 'P046'],['P047', 'P047'],['P048', 'P048'],['P049', 'P049'],
    ['P050', 'P050']
]

Ext.define('ctTrialCombinationModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'combinationNumber', 'semiProductNumber', 'semiProductDesc',
    'productNumber', 'productDesc', 'partNumber', 'partDesc', 'partVersion',
    'supplierNumber','brand','numberOfUses','trialQuantity','trialStatus','illustrate'
    ],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctTrialCombinationModel',
    storeId: 'ctTrialCombinationStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getTrialCombination?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//物料编码
var partNumberStore = Ext.create('Ext.data.Store', {
    fields: ['partNumber'],
    id: 'partNumberStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getSampleConfirmationFormPartNumber?branchId='+branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }),
    autoLoad: false
});

//供应商信息
var supplierCombo = new Ext.form.ComboBox({
    xtype: 'combo',
    name: 'supplierCombo',
    id: 'supplierCombo',
    multiSelect: false,
    anyMatch: true,
    editable: true,
    store: {
        data: [
        ],
        fields: ['supplierInfo']
    },
    valueField: 'supplierInfo',
    displayField: 'supplierInfo'
});

let ctTrialCombinationBo = Ext.create('Ext.grid.Panel', {
    id: 'ctTrialCombinationBo',
    store: Ext.data.StoreManager.lookup('ctTrialCombinationStore'),
    forceFit: false,
    height: 300,
    autoWidth: true,
    title: '1. 物料试用组合安排',
    collapsible: true,
    collapsed:openPanel(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node,Production_Manager_Approval_Node,Technical_Department_Manager_Node,Quality_Control_Department_Manager_Node),
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing1],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 120, dataIndex: 'branchId', hidden: true, align: 'center'},
        {
            text: setMust('组合编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 70,
            dataIndex: 'combinationNumber',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {
                xtype: 'combo',
                editable: true,
                forceSelection: false,
                store: combinationNumberStore,
                mode: 'local'
            }
            , renderer:showTip
        },
        {
            text: setRequired('半成品编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 80,
            dataIndex: 'semiProductNumber',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {text: '半成品描述', width: 80, dataIndex: 'semiProductDesc', align: 'center', renderer:showTip},
        {
            text: setRequired('成品编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 80,
            dataIndex: 'productNumber',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {text: '成品描述', width: 80, dataIndex: 'productDesc', align: 'center', renderer:showTip},
        {
            text: setMust('物料编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 80,
            dataIndex: 'partNumber',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {
                xtype: 'combo',
                editable: true,
                forceSelection: false,
                store: partNumberStore,
                displayField: 'partNumber',
                valueField: 'partNumber'
            }
            , renderer:showTip
        },
        {text: '物料描述', width: 80, dataIndex: 'partDesc', align: 'center', renderer:showTip},
        {
            text: setRequired('内部版本',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 60,
            dataIndex: 'partVersion',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('供应商编码_名称',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 100,
            dataIndex: 'supplierNumber',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: supplierCombo
            , renderer:showTip
        },
        {
            text: setRequired('品牌',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 60,
            dataIndex: 'brand',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: '试用次数', width: 60, dataIndex: 'numberOfUses', align: 'center', renderer:showTip},
        {
            text: setMust('试用数量',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 70,
            dataIndex: 'trialQuantity',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {text: '试用状态', width: 60, dataIndex: 'trialStatus', align: 'center', renderer:showTip},
        {
            text: setRequired('说明',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 60,
            dataIndex: 'illustrate',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {
            text: setMust('被替代物料编码',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 90,
            dataIndex: 'alternativePartNumber',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },
        {text: '被替代物料描述', width: 90, dataIndex: 'alternativePartDesc', align: 'center', renderer:showTip}
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled: !isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            handler: function () {
                ctContentEditing1.cancelEdit();
                function successCallback(data) {
                    let store = ctTrialCombinationBo.getStore();
                    store.insert(store.getCount(), data);
                    ctDemandPlanBo.getStore().reload();
                    ctIncomingInspectionBo.getStore().reload();
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/trial/saveTrialCombination', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            handler: function () {
                let selected = ctTrialCombinationBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctTrialCombinationBo.getStore().remove(selected);
                        ctTrialCombinationBo.view.refresh();
                        ctDemandPlanBo.getStore().reload();
                        ctIncomingInspectionBo.getStore().reload();
                    }
                    function failCallback() {
                    }
                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/trial/deleteTrialCombination', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引
            var partNumber = record.get('partNumber');
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'supplierNumber'){
                    supplierCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getSupplierByPartNumber?partNumber=' + partNumber,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        supplierCombo.getStore().add({supplierInfo:item.supplierInfo});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            updateTrialCombination(editor, e);
        }
    }
});
