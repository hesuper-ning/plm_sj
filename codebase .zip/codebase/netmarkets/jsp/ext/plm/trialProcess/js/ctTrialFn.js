var redStarFlag = '<font color=red bold>*</font>';//必填标志
var blueFlagStart = '<font color=blue bold><b>';//可编辑标识
var blueFlagEnd = '</b></font>';


var Initiate_Trial_Node='Initiate_Trial_Node'; //发起试用流程
var Department_Manager_Review_Node='Department_Manager_Review_Node';//部门经理审核
var Update_Confirm_Trial_Plan_Material_Control_Node='Update_Confirm_Trial_Plan_Material_Control_Node';//更新/确认试用方案(物控)
var Update_Confirm_Trial_Plan_Submit_Node='Update_Confirm_Trial_Plan_Submit_Node';//更新/确认试用方案(提交人)
var Material_Preparation_PR_Node='Material_Preparation_PR_Node';//更新备料/创建工单/生产排期(线下),填写PR
var Fill_In_PO_Node='Fill_In_PO_Node';//填写PO
var Update_Confirm_Order_Node='Update_Confirm_Order_Node';
var Technical_Manager_Node='Technical_Manager_Node';//试用执行标准制定(技术部经理)
var Standard_Setting_TQC_Node='Standard_Setting_TQC_Node';
var Incoming_Inspection_Node='Incoming_Inspection_Node';
var Confirm_Incoming_Material_Inspection_Node='Confirm_Incoming_Material_Inspection_Node';
var Procurement_Engineer_Send_Duplicate_Node='Procurement_Engineer_Send_Duplicate_Node';
var Production_Manager_Approval_Node='Production_Manager_Approval_Node';
var Approval_By_Team_Leader_Node='Approval_By_Team_Leader_Node';
var Quality_Control_Department_PQC_Node='Quality_Control_Department_PQC_Node';
var IPQC_Approval_Node='IPQC_Approval_Node';
var Technical_Department_Manager_Node='Technical_Department_Manager_Node';
var Technical_Department_Engineer_Approval_Node='Technical_Department_Engineer_Approval_Node';
var Fill_In_Trial_Comments_Node='Fill_In_Trial_Comments_Node';
var Fill_In_Trial_Comments_TWO_Node='Fill_In_Trial_Comments_TWO_Node';
var Engineering_Manager_Send_Duplicate_Node='Engineering_Manager_Send_Duplicate_Node';
var PQE_Confirmation='PQE_Confirmation';
var Quality_Control_Department_Manager_Node = 'Quality_Control_Department_Manager_Node';

//表格beforeedit校验
function checkBeforeEdit(editor, e) {
    let field = e.field;
    let value = e.value;
    let record = e.record;
    return checkEditAccess(e);
}

/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    //if(isAdmin) return true;
    var column = e.column;//获取编辑列
    if(column.editAccess){
        return true;
    }else{
        return false;
    }
    return true;
}

/**
 * 设为必填
 */
function setMust(field, flag) {
    if (flag)
        return redStarFlag + blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 设为可填
 */
function setRequired(field, flag) {
    if (flag)
        return blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion

/**
 * 判断是否可编辑
 * @param node 节点表单key
 * @returns {boolean}
 */
function isEditable(...node) {
    //return true;
    if (readOnlyPage || taskCompleted) return false;
    let flag = false;
    node.forEach((item, index) => {
        if (item === currentActKey) {
            flag = true;
        }
    });
    return flag;
}

/**
 * 判断节点表单是否应该展开
 */
function openPanel(...node) {
    //只读页面全打开
    if(readOnlyPage) {
        return false;
    }
    if(isEditable(...node)) {
        return false;
    }else {
        return true;
    }
}

/**
 * 回显格式化日期格式
 * @param value
 * @returns {*|string}
 */
function renderDateField(value) {
    var timeStr = value;
    if(value != null && value != undefined && value != ''){
        var date = new Date(value);
        timeStr = Ext.Date.format(date,"Y-m-d")
    }
    return timeStr;
}

//传入公共的参数，返回上传附件的代码
function uploadFilefield(fileName,text,node,tetx_name,type){
    if(text==null || text==""){
        text = "浏览...";
    }
    var inform ={
        xtype:'filefield',
        buttonOnly: true,
        id:fileName,
        name:fileName,
        labelWidth:70,
        disabled:!isEditable(Initiate_Trial_Node,Department_Manager_Review_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
        hideLabel: true,
        buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>'+text+'</span>',
        allowBlank: false,
        scope: this,
        listeners:{
            'change':function(fb,newValue,oldValue,opts){
                if(!newValue){
                    return;
                }
                var file = document.querySelector('[id='+fileName+'-button-fileInputEl]');
                var formData = new FormData();
                formData.append(fileName+'-button-fileInputEl', file.files[0]);
                fb.reset();//清空表单的值
                var myMask = new Ext.LoadMask({
                    msg: '正在上传，请稍候......',
                    target:this.findParentByType('panel')
                });
                myMask.show();
                $.ajax({
                    url: '/Windchill/ptc1/trial/uploadFiles?branchId='+branchId+'&tetx_name='+tetx_name+"&node="+node+"&type="+type+"&id=",
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function(res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if(!success){
                        alert(msg);
                    }else {
                        var fileName = obj['fileName'];
                        var value = Ext.getCmp(tetx_name).getValue();
                        if(value != null && value != ''){
                            fileName = value +"&nbsp;|&nbsp;" + fileName;
                        }
                        Ext.getCmp(tetx_name).setValue(fileName);
                        autoSaveBasis(tetx_name, fileName);
                    }
                }).fail(function(res) {
                    myMask.hide();
                    alert('上传失败！') ;
                });
            }
        }
    };
    return inform;
}

//自动保存字段
function autoSaveBasis(attKey, attValue) {
    var data = {
        branchId: branchId,
        key: attKey, //字段key
        value: attValue//字段值
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/trial/updateTrialBasis',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);

            if(obj.message==="success") {

            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

/**
 * 加载Form表单
 */
function loadBasisFormData() {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/trial/getTrialBasis?branchId=' + branchId,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var data = obj.data;
            let form = Ext.getCmp('ctTrialBasisBo');
            if (form !== undefined) {
                form.getForm().setValues(data);
            }
            if(obj.message==="success") {} else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    });
}

function deleteFilefield(branchId, fileName, tetx_name, node, type, id) {
    Ext.Msg.confirm('提示','确定要删除选中文件？',
        function(btn){
            if(btn =='yes'){
                deleteFile(branchId, fileName, tetx_name, node, type,id)
            }else{
                return;
            }
        },this
    );
}

//删除附件
function deleteFile(branchId, fileName, tetx_name, node, type, id) {
    var file = '';
    var path = '';
    if (taskCompleted) {
        return;
    }
    if (type == 'trialPlan') {
        if (!isEditable(Initiate_Trial_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'trialPlanFile';
        path = 'trialPlanFilePath';
    }else if(type == 'technicalDocument'){
        if (!isEditable(Update_Confirm_Trial_Plan_Submit_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'attachmentFile';
        path = 'attachmentPath';
    }else if(type == 'PQE'){
        if (!isEditable(PQE_Confirmation)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'reportFilePqe';
        path = 'reportFilePathPqe';
    }else if(type == 'IPQC'){
        if (!isEditable(IPQC_Approval_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'reportFileIPQc';
        path = 'reportFilePathIPQc';
    }else if(type == 'TechnicalTest'){
        if (!isEditable(Technical_Department_Engineer_Approval_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'reportFileTechnology';
        path = 'reportFilePathTechnology';
    }else if(type == 'annexFile'){
        if (!isEditable(Incoming_Inspection_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'annexFile';
    }else if(type == 'annexFile_1'){
        if (!isEditable(Approval_By_Team_Leader_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'annexFile';
    }





    Ext.Ajax.request({
        scope: this,
        async: false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url: '/Windchill/ptc1/trial/deleteFiles',
        params: {
            branchId: branchId, fileName: fileName,type:type
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if (!success) {
                alert(msg);
            } else {
                if (type == 'trialPlan') {
                    var value = Ext.getCmp(tetx_name).getValue();
                    var arr= new Array(); //定义一数组
                    arr=value.split("|"); //字符分割
                    for (i=0;i<arr.length ;i++ ){
                        var index = arr[i].indexOf(fileName);
                        if (index > -1) {
                            arr.splice(i,1);// 删除
                        }
                    }
                    var result = arr.join("&nbsp;|&nbsp;");
                    Ext.getCmp(tetx_name).setValue(result);
                    autoSaveBasis(tetx_name, '');
                }else if(type == 'technicalDocument'){
                    var tRecord =  Ext.getCmp('ctTechnicalDocumentBo').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                        tRecord.set(path, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctTechnicalDocumentBo').getStore().reload();
                    };
                    saveMockItemData("ZTechnicalDocumentTable",id,'attachmentFile','',callbackFn);
                    saveMockItemData("ZTechnicalDocumentTable",id,'attachmentPath','',callbackFn);
                }else if(type == 'PQE'){
                    var tRecord =  Ext.getCmp('ctFollowUpTrialTwoBo1').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                        tRecord.set(path, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctFollowUpTrialTwoBo1').getStore().reload();
                    };
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFilePqe','',callbackFn);
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFilePathPqe','',callbackFn);
                }else if(type == 'IPQC'){
                    var tRecord =  Ext.getCmp('ctFollowUpTrialTwoBo2').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                        tRecord.set(path, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctFollowUpTrialTwoBo2').getStore().reload();
                    };
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFileIPQc','',callbackFn);
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFilePathIPQc','',callbackFn);
                }else if(type == 'TechnicalTest'){
                    var tRecord =  Ext.getCmp('ctFollowUpTrialTwoBo3').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                        tRecord.set(path, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctFollowUpTrialTwoBo3').getStore().reload();
                    };
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFileTechnology','',callbackFn);
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFilePathTechnology','',callbackFn);
                }else if(type == 'annexFile'){
                    var tRecord =  Ext.getCmp('ctIncomingInspectionBo').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctIncomingInspectionBo').getStore().reload();
                    };
                    saveMockItemData("ZIncomingInspectionTable",id,'annexFile','',callbackFn);
                }else if(type == 'annexFile_1'){
                    var tRecord =  Ext.getCmp('ctFollowUpTrialBo').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctFollowUpTrialBo').getStore().reload();
                    };
                    saveMockItemData("ZFollowUpTrialTable",id,'annexFile','',callbackFn);
                }
            }
        },
        failure: function (response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });
}

/**
 * 对Request封装
 * @Param url 请求url
 * @Param method 请求方法'GET' 'POST'
 * @Param async true 请求异步 false 请求步
 * @Param object
 * @Param callback 回调方法
 */
function sendRequest(url, method, headers, async, params, successCallback, failCallback) {
    Ext.Ajax.request({
        scope: this,
        url: url,
        method: method,
        timeout: 600000,
        async: async,
        headers: {'Content-Type': headers},
        params: params,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
                if (failCallback) {
                    failCallback();
                }
            } else {
                if (successCallback) {
                    successCallback(obj.data);
                }
            }
        },
        failure: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj&&obj['message']) {
                Ext.Msg.alert('错误', obj['message']);
            }else{
                Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
            }
            if (failCallback != null && failCallback !== '') {
                failCallback();
            }
        }
    }); //~End of Ajax request
}

/**
 * 更新物料试用组合安排
 * @param editor
 * @param e
 */
function updateTrialCombination(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        if(field == 'tQCOpinion' || field == 'trialConclusion'){
            ctTrialResultBo.getStore().reload();
            ctDemandPlanBo.getStore().reload();
            ctIncomingInspectionBo.getStore().reload();
            ctTrialResultBo.getStore().reload();
        }else{
            ctTrialCombinationBo.getStore().reload();
            ctDemandPlanBo.getStore().reload();
            ctIncomingInspectionBo.getStore().reload();
            ctTrialResultBo.getStore().reload();
        }
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTrialCombination', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 更新技术文档
 * @param editor
 * @param e
 */
function updateTechnicalDocument(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctTechnicalDocumentBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTechnicalDocument', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value, branchId:branchId},
        successCallback, failCallback);
}

/**
 * 更新试用MBOM
 * @param editor
 * @param e
 */
function updateTrialMBom(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctTrialMBomBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTrialMBom', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value, branchId: branchId},
        successCallback, failCallback);
}

/**
 * 更新需求文档
 * @param editor
 * @param e
 */
function updateDemandPlan(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctDemandPlanBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateDemandPlan', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value, branchId: branchId},
        successCallback, failCallback);
}

/**
 * 更新质量控制部来料检验情况
 * @param editor
 * @param e
 */
function updateIncomingInspection(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctIncomingInspectionBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateIncomingInspection', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value, branchId:branchId},
        successCallback, failCallback);
}

/**
 * 更新试用执行标准
 * @param editor
 * @param e
 */
function updateTrialStandard(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctTrialStandardBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTrialStandard', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 更新试用过程跟进表1
 * @param editor
 * @param e
 */
function updateFollowUpTrial(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctFollowUpTrialBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateFollowUpTrial', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 更新试用过程跟进表2
 * @param editor
 * @param e
 */
function updateFollowUpTrialTwo(editor, e, successCallback) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateFollowUpTrialTwo', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 更新物料试用结果
 * @param editor
 * @param e
 */
function updateTrialResult(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctTrialResultBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTrialResult', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){
    var mockRec = {
        oid:workItemOid,
        dbTableName:dbTableName,
        itemId:itemId,
        dataKey:dataKey,
        dataValue:dataValue
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/trial/saveItemData?oid=' + workItemOid,
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 导出更改后BOM
 */
function exportUpdateBOM() {
    // 获取XMLHttpRequest
    var xmlHttpRequest = new XMLHttpRequest();
    //  发起请求
    xmlHttpRequest.open("POST", '/Windchill/ptc1/trial/exportUpdateBOM?branchId=' + branchId, true);
    // 设置请求头类型
    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
    xmlHttpRequest.responseType = "blob";
    //  返回
    xmlHttpRequest.onload = function (oEvent) {
        var content = xmlHttpRequest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).message)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            var fileNamePrefix = '更改后BOM';
            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }
    };
    xmlHttpRequest.send();
}







