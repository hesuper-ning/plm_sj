<%@ page import="ext.plm.trialProcess.config.CtTrialProperties" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<%--   物料试用流程表单 --%>
    <%
        String workItemOid = request.getParameter("oid");
        long branchId = 1L;
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(workItemOid).getObject();
        String currentActKey = "";
        boolean taskCompleted = false; //任务是否已完成
        long timestamp = System.currentTimeMillis();
        boolean readOnlyPage = false;
        if(obj instanceof WorkItem){
            WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            String actName = activity.getName();
            currentActKey = CtTrialProperties.getActivityKey(actName);
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
            WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
            branchId = doc.getBranchIdentifier();
        }else{
            String branchIdStr = workItemOid.substring(workItemOid.lastIndexOf(":") + 1);
            branchId = Long.valueOf(branchIdStr);
            readOnlyPage = true;
        }
    %>

    <script type="text/javascript">
        var workItemOid = "<%=workItemOid%>";
        var branchId ='<%= branchId %>';
        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";
        //当前的任务完成状态
        var taskCompleted = false;
        <%if(taskCompleted){%>
            taskCompleted = true;
        <%}%>
        var readOnlyPage = <%=readOnlyPage%>;
        var loadFormFlag = true;
    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js/ctTrialFn.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctTrialBasis.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctTrialCombination.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctTechnicalDocument.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctTrialMBom.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctDemandPlan.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctIncomingInspection.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctTrialStandard.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctFollowUpTrial.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctFollowUpTrialTwo.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctTrialResult.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctTrial.js?_dc=<%=timestamp%>"></script>
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.apply(Ext.QuickTips.getQuickTip(), {
            dismissDelay: 120000
        });
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'TrialPanel',
            }]
        });
    });
</script>
</body>
</html>