<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="ext.plm.workReport.config.CtWorkReportProperties" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.workReport.CtWorkReportLogic" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WTDocument doc = (WTDocument) rf.getReference(oid).getObject();
        String docBranchId = doc.getBranchIdentifier()+"";
        boolean workReportAuthorityProcess = CtWorkReportLogic.workReportAuthorityProcess(docBranchId);

    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctWorkReportProcess.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
    var branchId = "<%=docBranchId%>";
    var allowEdit = false;
    var workReportAuthorityProcess = <%=workReportAuthorityProcess%>

    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            hidden:workReportAuthorityProcess,
            items: [{
                region: 'center',
                xtype: 'WorkReport'
            }]
        });
    });
</script>
</body>
</html>