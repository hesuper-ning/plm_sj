<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>



    <%
        String oid = request.getParameter("oid");
        String userDisplayName = CtUserUtil.getCurrentUserAccountName();
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctWorkReport.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctWorkReportFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>

    <style type="text/css">
        .x-form-item-label-text{
            font-weight:bold
        }
        .x-btn-inner x-btn-inner-default-toolbar-small{
            font-weight:bold
        }
        .x-column-header-text-inner{
            font-weight:bold
        }
        .x-grid-cell-inner {
            font-weight:bold
        }
        #manJobContent1-inputEl {
            font-weight:bold
        }
        /*!* 自定义 filefield 按钮样式 *!*/
        /*.x-form-file-wrap .x-form-file-input {*/
        /*    background-color: #ffffff !important; !* 设置背景颜色 *!*/
        /*    border: 1px solid #ccc !important;    !* 设置边框 *!*/
        /*}*/
        .wrap-text {
            white-space: normal !important;  /* 允许内容换行 */
            overflow-wrap: break-word;       /* 防止长单词溢出 */
        }
        .x-selectable, .x-selectable * {
            -moz-user-select: text! important ;
            -khtml-user-select: text! important ;
        }
    </style>

</head>

<body>
<script>

    //当前用户
    var userDisplayName = "<%=userDisplayName%>";
    var docStatus = '';
    var projectWorkItemsId = "";
    var productLine1 = "";
    var workDate = "";
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'WorkReport'
            }]
        });
    });
</script>
</body>
</html>