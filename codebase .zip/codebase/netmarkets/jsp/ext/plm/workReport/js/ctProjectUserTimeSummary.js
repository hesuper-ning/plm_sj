/**
 * 项目群工时统计
 * 描述：项目中每个用户工作时间的统计
 */
Ext.define('PLM.view.projectUserTimeSummary', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.projectUserTimeSummary',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'projectUserTimeSummary',
    initComponent: function () {
        var me = this;
        Ext.define('projectUserTimeSummaryGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'userName', 'userDepartment', 'workNumber', 'productLine','creatorDate',
                'projectNumber', 'projectName', 'manHour','planningProjectName','projectSource'],
            idProperty: 'id'
        });

        var projectUserTimeSummaryStore = Ext.create('PLM.store.MockItemStore', {
            id: 'projectUserTimeSummaryStore',
            model: 'projectUserTimeSummaryGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getProjectHour',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        // 部门下拉
        var departmentStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            fields: ['name'],
            id: 'departmentStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllUserDepartment',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });



        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'number', 'name'
            ],
            idProperty: 'projectNumber'
        });


        // 项目下拉
        var projectStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getProjects',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        // 产品线下拉
        var productLineStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            fields: ['name'],
            id: 'productLineStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllProductLine',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

       /* //项目导出选择表单
        var projectGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('projectStore'),
            id: 'projectGrid',
            //margin: '0 5 5 5',
            forceFit: true,
            autoWidth: true,
            //border:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '项目编号', dataIndex: 'number', width: 100, menuDisabled: true},
                {text: '项目名称', dataIndex: 'name', width: 100, menuDisabled: true},
            ],
            tbar:[{
                xtype: 'textfield',
                fieldLabel: '项目名称',
                labelWidth: 70,
                margin:'0 0 0 20',
                id: 'projectName1'
            },{
                xtype: 'textfield',
                fieldLabel: '项目编码',
                margin: '0 0 0 20',
                id: 'projectNumber1',
                name: 'projectNumber1',
                labelWidth: 70,
            },{
                xtype: 'textfield',
                fieldLabel: '项目编码',
                margin: '0 0 0 20',
                id: 'productLine',
                name: 'productLine',
                labelWidth: 70,
            },{
                iconCls: 'icon icon-search',
                xtype: 'button',
                id: "queryProject",
                margin: '0 0 0 20',
                text: '查询',
                handler : function () {
                    getProjectInfo();
                }
            },{
                text: '导出',
                id:'export',
                name:'export',
                scope: this,
                handler:function () {
                    let selectionArr = projectGrid.getSelectionModel().getSelection();
                    if (selectionArr==undefined||selectionArr==null||selectionArr.length==0){
                        Ext.Msg.alert("提示","请选择要导出的项目数据");
                        return;
                    }
                    //数据组装
                    var projectNames = "";
                    Ext.each(selectionArr,function(record){
                        projectNames+=record.data['name']+',';
                    });
                    exportReportByName(projectNames)
                }
            }]
        });
*/
       /* var requireWin = Ext.create('Ext.Window', {
            id:'requireWin2',
            title: '选择项目导出',
            width: 700,
            //height: 300,
            autoHeight : true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal:true,
            items:[projectGrid],
        });*/



        var projectUserTimeSummaryGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('projectUserTimeSummaryStore'),
            id: 'projectUserTimeSummaryGrid',
            //margin: '0 5 5 5',
            //forceFit: true,
            autoWidth: true,
            //border:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '98%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer',width:60, align: 'center'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                // {text: '日期', dataIndex: 'creatorDate', width: 100, menuDisabled: true},
                {text: '姓名', dataIndex: 'userName', width: 100, menuDisabled: true},
                // {text: '账号', dataIndex: 'workNumber', width: 100, menuDisabled: true},
                {text: '部门', dataIndex: 'userDepartment', width: 100, menuDisabled: true},
                {text: '项目编码', dataIndex: 'projectNumber', width: 100, menuDisabled: true},
                {text: '产品线', dataIndex: 'productLine', width: 100, menuDisabled: true},
                {text: '项目名称', dataIndex: 'projectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目来源', dataIndex: 'projectSource', width: 100, menuDisabled: true},
                {text: '规划项目名称', dataIndex: 'planningProjectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '合计工时', dataIndex: 'manHour', width: 100, menuDisabled: true},
            ]
        });


        var projectUserTimeSummaryForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            title:'项目群工时统计',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{//第*行
                xtype: 'panel',
                layout: 'hbox',
                border:false,
                defaults: {margin: '5 20 5 5', labelWidth: 100,border:false,padding:5},
                items: [{
                    xtype: 'combobox',
                    fieldLabel: '部门名称',
                    labelWidth: 70,
                    store: departmentStore,
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'name',
                    id: 'departmentName',
                    name: 'departmentName',
                },{
                    xtype: 'combobox',
                    fieldLabel: '用户名称',
                    id: 'userName',
                    name: 'userName',
                    store: allUserStore_projectPlan,
                    labelWidth: 70,
                    typeAhead: true,
                    triggerAction: 'all',
                    queryMode: 'local',
                    displayField: 'userFullName',
                    valueField: 'no',
                    forceSelection: true,
                    allowBlank: true,
                    anyMatch: true
                }, {
                    xtype: 'combobox',
                    fieldLabel: '项目名称',
                    margin: '0 0 0 20',
                    id: 'projectName',
                    name: 'projectName',
                    store: projectStore,
                    labelWidth: 70,
                    typeAhead: true,
                    triggerAction: 'all',
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'name',
                    // valueField: 'projectNumber',
                    forceSelection: true,
                    allowBlank: true,
                    anyMatch: true
                },{
                    xtype: 'combobox',
                    fieldLabel: '项目编码',
                    margin: '0 0 0 20',
                    id: 'projectNumber',
                    name: 'projectNumber',
                    store: projectStore,
                    labelWidth: 70,
                    typeAhead: true,
                    triggerAction: 'all',
                    queryMode: 'local',
                    displayField: 'projectNumber',
                    valueField: 'projectNumber',
                    // valueField: 'projectNumber',
                    forceSelection: true,
                    allowBlank: true,
                    anyMatch: true
                }, {
                    xtype: 'combobox',
                    fieldLabel: '产品线',
                    labelWidth: 70,
                    margin: '0 0 0 20',
                    store: productLineStore,
                    multiSelect: false,
                    anyMatch: true,
                    editable: false,
                    displayField: 'name',
                    valueField: 'name',
                    id: 'productLine',
                    name: 'productLine',
                }]
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                border:false,
                defaults: {margin: '10 5 0 20', labelWidth: 100,border:false,padding:5},
                items: [{
                    xtype: 'datefield',
                    fieldLabel: '开始日期',
                    id: 'dateStart',
                    format: 'Y-m-d',
                    name: 'dateStart',
                    // value: Ext.util.Format.date(Ext.Date.add(Ext.Date.getFirstDateOfMonth(new Date()), Ext.Date.MONTH, 0), "Y-m-d"),
                    value: Ext.util.Format.date(Ext.Date.add(new Date(), Ext.Date.YEAR, -1), "Y-m-d"),
                    labelWidth: 70,
                    width: 220
                },{
                    xtype: 'datefield',
                    fieldLabel: '结束日期',
                    id: 'dateEnd',
                    format: 'Y-m-d',
                    name: 'dateEnd',
                    value: new Date(),
                    labelWidth: 70,
                    width: 220
                }, {
                    iconCls: 'icon icon-search',
                    xtype: 'button',
                    id: "query",
                    text: '查询',
                    handler:function () {
                        getReport()
                    }
                }, {
                    iconCls: 'icon icon-store-export',
                    xtype: 'button',
                    id: "exportResult",
                    text: '查询结果导出',
                    handler : function () {
                        exportReport();
                    }
                }

                    , {
                        iconCls: 'icon icon-store-export',
                        xtype: 'button',
                        id: "exportResultSelect",
                        text: '导出选择的数据',
                        handler : function() {
                            let selectionArr = projectUserTimeSummaryGrid.getSelectionModel().getSelection();
                            if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                Ext.Msg.alert("提示", "请选择要导出的数据");
                                return;
                            }
                            //数据组装
                            let workReportItemId = new Array();
                            Ext.each(selectionArr, function (record) {
                                workReportItemId.push(record.data['id'])
                            });

                            let rowIndexItemId = new Array();
                            selectionArr.forEach((selectedRecord) => {
                                // 获取选中行在Store中的索引（即自然排序的行号）
                                let rowIndex = projectUserTimeSummaryGrid.getStore().indexOf(selectedRecord);
                                rowIndexItemId.push(rowIndex)
                                console.log("选中的行号: " + rowIndex);
                                console.log("选中的行数据: ", selectedRecord.data);
                            });

                            exportReport(rowIndexItemId,"select");
                        },
                        scope : this
                    }

                , {
                    xtype: 'label',
                    id: "userWorkHoursCountLable",
                    text: '工时统计：0',
                } /*{
                    iconCls: 'icon icon-store-export',
                    xtype: 'button',
                    id: "exportResultByProjects",
                    text: '按项目导出',
                    handler:function () {
                        requireWin.show();
                    }
                }*/]
            },projectUserTimeSummaryGrid]
        };



/////////////////////////Main Panel items//////////////////////////////////
        this.items = [projectUserTimeSummaryForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('projectStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('departmentStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('productLineStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        },
    },

});
function exportReportByName(projectNames) {
    var data = getSearchData();

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportProjectsByName', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "项目群工时"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "projectName=" + projectNames
    );
}


function exportReport(workReportItemId,select) {
    var data = {};
    // if("select" === select){
    //     data = {
    //         workReportItemId: workReportItemId,
    //         select:select
    //     };
    // }else {
        data = getSearchData();
    // }

    if("select" === select) {
        Object.assign(data, {
            workReportItemId: workReportItemId,
            select: select
        });
    }

    // var data = getSearchData();

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportTimeSummary', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "项目群工时"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(data)
    );
}

//获取参数
function getSearchData() {
    var data = {
        workNumber: Ext.getCmp("userName").getValue(),
        projectName:Ext.getCmp("projectName").getValue(),
        departmentName:Ext.getCmp("departmentName").getValue(),
        productLine:Ext.getCmp("productLine").getValue(),
        dateStart:Ext.getCmp("dateStart").getValue(),
        dateEnd:Ext.getCmp("dateEnd").getValue(),
        projectNumber:Ext.getCmp("projectNumber").getValue()
    };
    return data;
}

//查询项目群工时统计
function getReport() {
    var data = getSearchData();
    Ext.getStore('projectUserTimeSummaryStore').load({
        params: {
            data:Ext.encode(data)
        },
        callback: function (records, operation, success) {
            if (!success) {
                if(typeof(operation.error)=='string'){
                    alert(operation.error);
                }else {
                    alert('查询超时！请重试！')
                }
            }else {
                getSumHour();
            }
        },
    })
}

//查询项目信息
function getProjectInfo(){
    var projectName = Ext.getCmp("projectName1").getValue();
    Ext.getStore('projectStore').load({
        params: {
            projectName:projectName
        },
        callback: function (records, operation, success) {
            if (!success) {
                if(typeof(operation.error)=='string'){
                    alert(operation.error);
                }else {
                    alert('查询超时！请重试！')
                }
            }
        },
    })
}

function getSumHour() {
    var data = getSearchData();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getSumHour',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                Ext.getCmp("userWorkHoursCountLable").setText("工时统计:" + obj['sumHour'] + "小时");
            }
        },
        failure: function (response, opts) {
            alert('错误：请检查网络！');
        }
    });
}