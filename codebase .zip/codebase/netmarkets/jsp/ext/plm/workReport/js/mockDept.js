Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    layout: 'border',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'workReport-infoPage',
        in_objectDesc: '工时创建页面',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        //问题添加表单
        var addForm = new Ext.form.Panel({
            xtype:'form',
            margin: '10 0 0 0',
            border:false,
            items:[{
                layout:'hbox',
                border:false,
                margin:'5 5 10 30',
                items:[{
                    xtype:'combo',
                    fieldLabel:'<font color=red>*</font>项目名称',
                    margin:'0 20 0 0',
                    multiSelect: true,
                    valueField: 'groupName',
                    displayField: 'groupName',
                    anyMatch: true,
                    editable : false,
                    store: [['软件', '软件'],['硬件', '硬件'],['工艺', '工艺'],
                        ['结构', '结构'],['包装', '包装'],['其他', '其他']],
                    width:300,
                    id:'problemTerritory',
                    name:'problemTerritory',
                    labelWidth:100
                },{
                    xtype:'textfield',
                    fieldLabel:'<font color=red>*</font>项目编码',
                    margin:'0 20 0 0',
                    width:300,
                    id:'planFinishDatem',
                    name:'planFinishDatem',
                    labelWidth:100
                }
                ]
            },{
                layout:'hbox',
                border:false,
                margin:'5 5 10 30',
                items:[{
                    fieldLabel:'<font color=red>*</font>产品线',
                    xtype:'combo',
                    margin:'0 20 0 0',
                    multiSelect: false,
                    valueField: 'groupName',
                    displayField: 'groupName',
                    anyMatch: true,
                    editable : false,
                    store: [['严重', '严重'],['一般', '一般'],['轻微', '轻微'],
                        ['N/A', 'N/A']],
                    width:300,
                    id:'problemGradexx',
                    name:'problemGradexx',
                    labelWidth:100
                },{
                    xtype:'combo',
                    fieldLabel:'<font color=red>*</font>项目阶段',
                    margin:'0 20 0 0',
                    multiSelect: false,
                    valueField: 'groupName',
                    displayField: 'groupName',
                    anyMatch: true,
                    editable : false,
                    store: [['严重', '严重'],['一般', '一般'],['轻微', '轻微'],
                        ['N/A', 'N/A']],
                    width:300,
                    id:'problemGrade',
                    name:'problemGrade',
                    labelWidth:100
                }
                ]
            },{
                layout:'hbox',
                border:false,
                margin:'5 5 10 30',
                items:[{
                    fieldLabel:'<font color=red>*</font>活动名称',
                    xtype:'combo',
                    margin:'0 20 0 0',
                    multiSelect: false,
                    valueField: 'groupName',
                    displayField: 'groupName',
                    anyMatch: true,
                    editable : false,
                    store: [['1', '1'],['2', '2'],['3', '3'],
                        ['N/A', 'N/A']],
                    width:300,
                    id:'problemGradedd',
                    name:'problemGradedd',
                    labelWidth:100
                },{
                    xtype:'numberfield',
                    fieldLabel:'<font color=red>*</font>工时',
                    margin:'0 20 0 0',
                    width:300,
                    id:'planFinishDateaa',
                    name:'planFinishDateaa',
                    labelWidth:100
                }
                ]
            },{
                layout:'hbox',
                border:false,
                margin:'5 5 10 30',
                items:[{
                    xtype:'textarea',
                    margin:'0 20 0 0',
                    fieldLabel:'<font color=red>*</font>工作内容及遇到的问题或风险',
                    width:630,
                    height:230,
                    id:'description',
                    name:'description',
                    labelWidth:100
                }
                ]
            },{
                layout:'hbox',
                border:false,
                margin:'5 5 10 30',
                items:[{
                    margin:'0 10 0 0',
                    xtype:'button',
                    id:'save',
                    text:'保存',
                    handler: function() {

                        Ext.getCmp('requireWin2').close();
                    }
                },{
                    xtype:'button',
                    id:'close',
                    text:'取消',
                    handler: function() {
                        /*clear();*/
                        Ext.getCmp('requireWin2').close();
                    }
                }]
            }]
        })

        var requireWin2 = Ext.create('Ext.Window', {
            id:'requireWin2',
            title: '添加问题',
            width: 700,
            //height: 300,
            autoHeight : true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal:true,
            items:[addForm],
        });

        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            margin: '20 10 20 10',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '产品线', dataIndex: 'data1', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '项目编码', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '项目名称', dataIndex: 'data3', width: 150, editor: 'textfield', menuDisabled: true},
                {text: '活动名称', dataIndex: 'data4', width: 150,editor: 'textfield', menuDisabled: true},
                {text: '项目阶段', dataIndex: 'data5', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '工时（h）', dataIndex: 'data6', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '工作内容及遇到的问题或风险', flex:1,dataIndex: 'data7',editor: 'textarea',rows:5, width: 300,  menuDisabled: true,
                    renderer: function (value, meta, record) {
                        meta.style = 'overflow:auto;padding: 3px 6px;text-overflow: ellipsis;white-space: nowrap;white-space:normal;line-height:20px;';
                        value = value.replace(/\n/g, "<br/>")
                        return value;
                    }
                },
            ],
            tbar:[{
                text: '添加',
                iconCls: 'icon icon-add',
                scope: this,
                handler: function () {
                    requireWin2.show();
                }
            },{
                text: '修改',
                iconCls: 'icon icon-add',
                scope: this,
                handler: function () {
                    requireWin2.show();
                }
            },{
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    alert('开发中....')
                }
            }]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            padding: '5',
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{//第*行
                xtype: 'panel',
                layout: 'hbox',
                border:false,
                margin: '30 20 0 0',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border:false},
                items: [{
                    xtype: 'datefield',
                    border:false,
                    fieldLabel: '工作日期',
                    padding: '20 15 10 20',
                    id: 'att1',
                    name: 'att1',
                    width: 450,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype:'button',
                    text:'创建工作日报',
                    handler: function () {
                        alert('开发中...')

                    }
                },{
                    xtype:'displayfield',
                    width:280,
                    fieldLabel: '文档编号'
                },{
                    xtype:'displayfield',
                    fieldLabel: '文档状态'
                }]
            },{
                margin: '15 0 10 0',
                html:'<div style="font-weight:bold ;font-size:22px;top:50px;left:50px;background-color: gainsboro;text-align:center">项目工作</div>'
            },{
                border:false,
                html:'指投入PDT/TDT产品线的工作，还包括评审，Charter开发、产品技术支持等。如果该工作无对应的项目, 则选择该产品线的费用公摊。工时单位：小时，包括加班时间。'
            }, mockExampleGrid,
                {
                    html:'<div style="font-weight:bold ;font-size:22px;top:50px;left:50px;background-color: gainsboro;text-align:center">部门工作</div>'
                },{
                    html:'指产品线之外的工作，例如：CBB，专利编制，部门能力建设等，工作单位：小时，包括加班时间。'
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    border:false,
                    margin: '15 20 10 0',
                    defaults: { labelWidth: 100,border:false},
                    items: [{
                        xtype: 'numberfield',
                        margin: '5 5 5 0',
                        fieldLabel: '',
                        name: 'att2',
                        id: 'att2',
                        width: 200,
                    }, {
                        xtype: 'label',
                        margin: '7 20 5 0',
                        text: '(h)',
                        width: 200,
                    }],

                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;text-align:left">部门工作内容</div>'
                },{
                    html:'简述工作内容，及遇到的问题'
                },{
                    xtype: 'textarea',
                    fieldLabel: '',
                    name: 'att3',
                    id: 'att3',
                    //rows:8,
                    height:200,
                    width: 800,
                    sortable: true,
                    listeners: {
                        renderer: function (value, meta, record) {
                            meta.style = 'overflow:auto;padding: 3px 6px;text-overflow: ellipsis;white-space: nowrap;white-space:normal;line-height:20px;';
                            value = value.replace(/\n/g, "<br/>")
                            return value;
                        },
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }

            ]
        };

        Ext.define('departmentUserWorkHoursTreeModel', {
            extend: "Ext.data.TreeModel",
            fields: [
                'name', 'wid'
            ],
            idProperty: 'id'
        });
        var userWorkHoursTreeStore = Ext.create("Ext.data.TreeStore", {
            model: "departmentUserWorkHoursTreeModel",
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getDeptTree',//请求
                reader: {
                    type: 'json'
                }
            },
            autoLoad: true,
            root: {
                coreRole: '日报',
                expanded: true
            },
        });

        var departmentUserWorkHoursTreePanel = Ext.create('Ext.tree.TreePanel', {
            store: userWorkHoursTreeStore,
            id: 'departmentUserWorkHoursTreePanel',
            autoWidth: true,
            autoScroll: true,
            rootVisible: false,
            width: 310,
            height: 530,
            viewConfig: {enableTextSelection: true, forceFit: false},
            columns: [
                {text: '日期', dataIndex: 'name', xtype: 'treecolumn', width: 200},
            ],

        });



/////////////////////////Main Panel items//////////////////////////////////
        this.items =[
            {
                region      : 'west',
                border:false,
                split: true,
                width: 500,
                minWidth: 175,
                maxWidth: 600,
                collapsible: true,
                //collapseMode: 'mini',
                width       : 300,
                items:[departmentUserWorkHoursTreePanel]
            },
            {
                region     : 'center',
                collapsible: false,
                items:[mockExampleForm],
                id:'centerPanel'
            }]
        //this.items = [mockExampleForm];

        Ext.getCmp("departmentUserWorkHoursTreePanel").getStore().addListener('load', function (st, rds, opts) {
        });

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

