Ext.define('PLM.view.WorkReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.WorkReport',
    border: false,
    layout: 'border',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'workReport-infoPage',
        in_objectDesc: '工时创建页面',
    },
    id: 'WorkReport',
    initComponent: function () {
        var me = this;


        Ext.define('projectInquiryModel', {
            extend: 'Ext.data.Model',
            fields: [
                'productModel','projectNumber','projectName','productLibraryName','projectStatus','inTheProjectTeam'
            ],
            idProperty: 'projectNumber'
        });

        var projectInquiryStore = Ext.create('Ext.data.Store', {
            id: 'projectInquiryStore',
            model: 'projectInquiryModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/projectInquiry',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            root: {
                expanded: true
            },
            autoLoad: false,
            folderSort: true
        });


        var projectInquiryCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var projectInquiryGrid = Ext.create('Ext.grid.Panel', {
            plugins: [projectInquiryCellEditing],
            store: projectInquiryStore,
            autoWidth: true,
            height: 500,
            id: 'usageInquiryGrid',
            autoScroll: true,
            selModel: {
                mode: 'SINGLE' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '产品型号', width: 130, dataIndex: 'productModel', menuDisabled: true, renderer:showTip,editor: true},
                {text: '项目编码', width: 120, dataIndex: 'projectNumber', menuDisabled: true, renderer:showTip,editor: true},
                {text: '项目名称', width: 100, dataIndex: 'projectName', menuDisabled: true, renderer:showTip,editor: true},
                {text: '产品库名称', width: 200, dataIndex: 'productLibraryName', menuDisabled: true, renderer:showTip,editor: true},
                {text: '项目状态', width: 100, dataIndex: 'projectStatus', menuDisabled: true, renderer:showTip,editor: true},
                {text: '是否在项目团队中', width: 130, dataIndex: 'inTheProjectTeam', menuDisabled: true, renderer:showTip,editor: true},
            ],
            dockedItems: [{
                xtype: 'container',
                dock: 'bottom',
                layout: {
                    type: 'hbox',
                    pack: 'end' // 右对齐
                },
                items: [{
                    xtype: 'button',
                    text: '确定',
                    margin: '10 10 10 0', // 右侧留出 10px 的间距
                    handler: function() {
                        var recordList = projectInquiryGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var projectNumber = recordList[0].data.projectNumber;
                            var projectName = recordList[0].data.projectName;
                            var masterId = Ext.getCmp('id').getValue();
                            var inTheProjectTeam = recordList[0].data.inTheProjectTeam;
                            if("否" == inTheProjectTeam){
                                alert("你不在项目：“"+projectName+"”团队中，请联系相关人员添加进项目团队！");
                                return;
                            }

                            var callbackFn = function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.success==true) {
                                    // getGridInfo();
                                    var callbackFn1 = function (response, opts) {
                                        if(obj.success==true) {
                                            getGridInfo();
                                        }else {
                                            alert(obj.msg)
                                        }
                                    }
                                    saveData(projectWorkItemsId, "projectName", projectNumber, callbackFn1);

                                    Ext.getCmp('projectInquiryWindow').close();
                                }else {
                                    alert(obj.msg)
                                }
                            };
                            isMember(projectNumber,projectName,masterId,callbackFn);
                            // saveData(id, field, value, callbackFn);
                            // saveData(projectWorkItemsId, "projectName", projectNumber, callbackFn);
                            //
                            // Ext.getCmp('projectInquiryWindow').close();
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }, {
                    xtype: 'button',
                    text: '取消',
                    margin: '10 10 10 0', // 右侧留出 10px 的间距
                    handler: function() {
                        Ext.getCmp('projectInquiryWindow').close();
                    }
                }]
            }]
        });

        projectInquiryGrid.getStore().on('update', function(store, record, operation, modifiedFieldNames) {
            // 恢复记录到编辑前的状态
            record.reject();
        });


        var projectInquiryWindow = Ext.create('Ext.Window', {
            id:'projectInquiryWindow',
            title: '项目高级查询',
            width: 820,
            height: 600,
            // autoHeight : true,
            closeAction: 'hide',
            // closable:false,
            // constrain: false,
            // modal:false,
            items:[
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    defaults: {
                        margin: '20 20 20 20'
                    },
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: '产品型号',
                            width: 180,
                            labelWidth: 60,
                            id: 'productType',
                            name: 'productType',
                            // value: partNumber
                        },
                        {
                            xtype: 'button',
                            text: '搜索',
                            width: 70,
                            labelWidth: 60,
                            handler: function() {
                                var productType = Ext.getCmp('productType').getValue();
                                projectInquiryStore.reload({
                                    params: {
                                        productType: productType
                                    }
                                });
                            }
                        },
                    ]
                },
                projectInquiryGrid
            ],
        });

        var explanationButtonWindow = Ext.create('Ext.Window', {
            id:'explanationButtonWindow',
            title: '报工填写说明',
            width: 820,
            height: 600,
            autoHeight : true,
            closeAction: 'hide',
            // closable:false,
            constrain: true,
            modal:true,
            items:[
                {
                    xtype: 'panel',
                    // hidden: true,
                    //layout: 'hbox',
                    id: 'explanationButtonPanel',
                    border: false,
                    margin: '10 20 0 0',
                    defaults: {margin: '5 20 0 10', labelWidth: 100, border: false},
                    items: [{
                        // html: '<div  >需抄送人员:1.项目工作需抄送给对应的项目管理工程师、开发代表、项目负责人；2.部门工作需抄送给部门主管</div>'
                        html: '<div  >' +
                            '<h3 style="margin: 10;">需抄送人员填写说明：</h3>' +
                            '<ol>' +
                            '<li>自动抄送对象：所填报项目对应的PDT/TDT经理、项目管理工程师、开发代表、项目负责人，本部门经理；</li>' +
                            '<li>用户可以手动选择抄送其他人员。</li>' +
                            '</ol>' +
                            '</div>'
                    }, {
                        border: false,
                        // html: '<div  >指投入项目中的工作，如PDT/TDT产品线项目、Charter开发项目、产品技术支持等。如该工作无具体对应的项目，则选择该工作所属产品线的费用公摊项目。工时单位：小时，包括加班时间。<div/>'
                        html: '<div  >' +
                            '<h3 style="margin: 10;">项目工作填写说明：</h3>' +
                            '<ol>' +
                            '<li>指投入项目中的工作，如PDT/TDT/SDT产品线项目、Charter开发项目、产品技术支持等；</li>' +
                            '<li>如该工作无具体对应的项目，但是与产品线密切相关，则选择该工作所属产品线的费用公摊项目；</li>' +
                            '<li>项目工作除了常规研发事务之外，以下也都是属于项目工作：<br>' +
                            '1）项目例会、项目周会、项目评审会议（含线上、线下评审）、项目相关会议纪要编制等；<br>' +
                            '2）项目相关的工作，如项目文档编写、项目文档评审、项目需求调研分析、项目技术研讨等；<br>' +
                            '3）客户特殊需求响应处理等。</li>' +
                            '<li>当默认的项目阶段、活动名称与实际不一致时，请手动调整到与当前阶段、活动名称相同。</li>' +
                            '</ol>' +
                            '</div>'
                    },
                        {
                            html: '<div  >' +
                                '<h3 style="margin: 10;">部门工作填写说明：</h3>' +
                                '<ol>' +
                                '<li>指与产品线研发项目无关的工作，例如：培训学习、部门会议、流程/文件处理、员工辅导等。</li>' +
                                '</ol>' +
                                '</div>'
                        },
                        {
                            html: '<div  >' +
                                '<h3 style="margin: 10;">其他说明及要求：</h3>' +
                                '<ol>' +
                                '<li>工时单位：小时。正常工作时间投入填写在“正常工时(h)”列，加班时间投入填写在“附加工时(h)”列；</li>' +
                                '<li>周末、节假日加班时也需要填报，工时填在“附加工时(h)”列；</li>' +
                                '<li>不要把项目工作、部门工作内容混到一块写，需要分开，项目工作报到项目中，部门工作报到部门中。</li>' +
                                '<li>不要把多个项目工作内容混到一块写（特殊情况除外），需要分开，分别报到不同的项目中。</li>' +
                                '<li>如果负责人亲自参与具体项目工作，请填报项目工时。</li>' +
                                '</ol>' +
                                '</div>'
                        }
                    ],
                }
            ],
        });


        Ext.define('workReportGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'masterId', 'workNumber', 'productLine', 'projectNumber', 'projectName', 'principals', 'activityName',
                'projectPhase', 'manHour', 'manhourOvertime','manJobContent'],
            idProperty: 'id'
        });

        var WorkReportGridStore = Ext.create('Ext.data.Store', {
            id: 'WorkReportGridStore',
            model: 'workReportGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getItemsByMasterId',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1,
            preserveUnedited: true  // 保留未编辑的字段内容
        });

        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectNumber', 'name'
            ],
            idProperty: 'projectNumber'
        });


        // 项目下拉
        var projectListStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectListStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                timeout: 9999999, // 设置超时时间为10秒 (10000毫秒)
                url: '/Windchill/ptc1/workReport/getOwnerPNAndPLList?type=PN',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: true
        });

        // 产品线下拉
        var projectLineListStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectLineListStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getOwnerPNAndPLList?type=PL',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });

        Ext.define('ProjectPhaseModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectPhase', 'projectPhaseVal'
            ],
            idProperty: 'projectPhaseVal'
        });


        // 项目阶段下拉
        var projectPhaseStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectPhaseModel',
            id: 'projectPhaseStore',
            pruneModifiedRecords: false,
            autoSync: false,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getProjectPhase',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });


        // 项目外项  活动名称
        Ext.define('PlanActivityModel', {
            extend: 'Ext.data.Model',
            fields: [
                'activityName'
            ],
            idProperty: 'activityName'
        });

        var activityListStores = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'PlanActivityModel',
            id: 'activityListStores',
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getWorkReportActivitys',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    messageProperty: 'error'
                }
            },
            autoLoad: false
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });

        var allUserStore_projectPlan1 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan1'
        });

        //问题添加表单
        var addForm = new Ext.form.Panel({
            xtype: 'form',
            margin: '10 0 0 0',
            id: 'addForm',
            name: 'addForm',
            border: false,
            items: [{
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    xtype: 'combobox',
                    fieldLabel: '<font color=red>*</font>项目名称',
                    margin: '0 20 0 0',
                    queryMode: 'local',
                    enableRegEx: true,
                    displayField: 'name',
                    valueField: 'projectNumber',
                    store: projectListStore,
                    width: 300,
                    id: 'projectName',
                    name: 'projectName',
                    labelWidth: 100,
                    listeners: {
                        /*beforequery: function (e) {
                            var combo = e.combo;

                            if (!e.forceAll) {
                                var value = e.query;
                                combo.store.filterBy(function (record, id) {
                                    var text = record.get(combo.displayField);
                                    return (text.indexOf(value) != -1);
                                });
                                combo.expand();
                                return false;
                            }
                        },*/
                        'blur': function () {
                            getProjectNumber();
                        },

                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '<font color=red>*</font>项目编码',
                    margin: '0 20 0 0',
                    width: 300,
                    id: 'projectNumber',
                    name: 'projectNumber',
                    labelWidth: 100,
                    listeners: {
                        'change': function () {
                            var number = Ext.getCmp('projectNumber').getValue();
                            if (number != '') {
                                getProjectPhase(number);
                            }
                        }
                    }

                }, {
                    xtype: 'textfield',
                    fieldLabel: '',
                    hidden: true,
                    margin: '0 20 0 0',
                    width: 300,
                    id: 'updateId',
                    name: 'updateId',
                    labelWidth: 100
                }
                ]
            }, {
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    fieldLabel: '<font color=red>*</font>产品线',
                    xtype: 'displayfield',
                    margin: '0 20 0 0',
                    valueField: '999',
                    width: 300,
                    id: 'productLine',
                    name: 'productLine',
                    labelWidth: 100
                }, {
                    xtype: 'combo',
                    fieldLabel: '<font color=red>*</font>项目阶段(之前)',
                    margin: '0 20 0 0',
                    multiSelect: false,
                    anyMatch: true,
                    editable: false,
                    displayField: 'projectPhase',
                    valueField: 'projectPhaseVal',
                    store: projectPhaseStore,
                    width: 290,
                    id: 'projectPhase',
                    name: 'projectPhase',
                    labelWidth: 100,
                    listeners: {
                        'select': function () {
                            getActivity();
                        }
                    }
                }
                ]
            }, {
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    xtype: 'combo',
                    fieldLabel: '<font color=red>*</font>活动名称',
                    margin: '0 20 0 0',
                    queryMode: 'local',
                    enableRegEx: true,
                    displayField: 'activityName',
                    valueField: 'activityName',
                    store: activityListStores,
                    width: 290,
                    id: 'activityName',
                    name: 'activityName',
                    labelWidth: 100
                }, {
                    xtype: 'numberfield',
                    fieldLabel: '<font color=red>*</font>正常工时(h)',
                    margin: '0 20 0 0',
                    width: 290,
                    id: 'manHour',
                    name: 'manHour',
                    minValue: '0',
                    maxValue: '16',
                    decimalPrecision: 1,
                    labelWidth: 100,
                    listeners: {
                        blur: function (e) {
                            var manHour = Ext.getCmp("manHour").getValue();
                            var itemId = Ext.getCmp('updateId').getValue();

                            if (manHour < 0.1 || manHour > 24) {
                                alert("请输入0.1-24之间数字")
                                Ext.getCmp("manHour").setValue("");
                            }
                            var is = checkHour(manHour, itemId);
                            if (!is) {
                                Ext.getCmp("manHour").setValue("");
                            }
                        }
                    }
                }, {
                    xtype: 'numberfield',
                    fieldLabel: '<font color=red>*</font>附加工时(h)',
                    margin: '0 20 0 0',
                    width: 290,
                    id: 'manhourOvertime',
                    name: 'manhourOvertime',
                    minValue: '0',
                    maxValue: '16',
                    decimalPrecision: 1,
                    labelWidth: 100,
                    listeners: {
                        blur: function (e) {
                            var manhourOvertime = Ext.getCmp("manhourOvertime").getValue();
                            var itemId = Ext.getCmp('updateId').getValue();

                            if (manhourOvertime < 0.1 || manhourOvertime > 24) {
                                alert("请输入0.1-24之间数字")
                                Ext.getCmp("manhourOvertime").setValue("");
                            }
                            var is = checkHour(manhourOvertime, itemId);
                            if (!is) {
                                Ext.getCmp("manhourOvertime").setValue("");
                            }
                        }
                    }
                }]
            }, {
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    xtype: 'textarea',
                    fieldLabel: '<font color=red>*</font>工作内容及遇到的问题或风险',
                    name: 'manJobContent',
                    id: 'manJobContent',
                    maxLength: 1500,
                    maxLengthText: "工作内容必须在1500字及以内!",
                    width: 620,
                    height: 150
                }]
            }, {
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    margin: '0 10 0 0',
                    xtype: 'button',
                    id: 'save',
                    text: '保存',
                    handler: function () {

                        var data = {
                            id: Ext.getCmp('updateId').getValue(),
                            masterId: Ext.getCmp('id').getValue(),
                            productLine: Ext.getCmp('productLine').getValue(),
                            projectNumber: Ext.getCmp('projectNumber').getValue(),
                            projectName: Ext.getCmp('projectName').getRawValue(),
                            activityName: Ext.getCmp('activityName').getValue(),
                            projectPhase: Ext.getCmp('projectPhase').getValue(),
                            manHour: Ext.getCmp('manHour').getValue(),
                            manhourOvertime: Ext.getCmp('manhourOvertime').getValue(),
                            manJobContent: Ext.getCmp('manJobContent').getValue(),
                        };
                        debugger

                        if (data.productLine == "" || data.projectNumber == "" || data.projectName == "" || data.activityName == null
                            || data.projectPhase == null || data.manHour == null || data.manhourOvertime == null|| data.manJobContent == "") {
                            alert("弹窗中*号标识为必填项，不允许为空");
                            return;
                        }


                        if (data.manJobContent.toString().length > 1500) {
                            return;
                        }

                        save(data);
                        clear();
                        Ext.getCmp('requireWin2').close();
                    }
                }, {
                    xtype: 'button',
                    id: 'close',
                    text: '取消',
                    handler: function () {
                        clear();
                        Ext.getCmp('requireWin2').close();
                    }
                }]
            }]
        });

        var requireWin2 = Ext.create('Ext.Window', {
            id: 'requireWin2',
            title: '工时信息',
            width: 700,
            //height: 300,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [addForm],
        });

        var WorkReportGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('WorkReportGridStore'),
            id: 'WorkReportGrid',
            //hidden:true,
            margin: '10 10 0 10',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            height: '98%',
            maxHeight: '400',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: { enableTextSelection:true},
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{text: '序号',xtype: 'rownumberer', width: 20},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '产品线', dataIndex: 'productLine', width: 100, menuDisabled: true,
                    // renderer:showTip,
                    renderer: function (value, meta, record) {
                        // 确保样式支持换行
                        meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                        return value ? value.replace(/\n/g, "<br/>") : '';
                    },
                    editor: {
                        xtype: 'combobox',
                        editable: false,
                        forceSelection: false,
                        displayField: 'name',
                        valueField: 'name',
                        store: projectLineListStore
                    }
                },
                {text: '项目名称', dataIndex: 'projectName', width: 150, menuDisabled: true,
                    // renderer:showTip,
                    renderer: function (value, meta, record) {
                        // 确保样式支持换行
                        meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                        return value ? value.replace(/\n/g, "<br/>") : '';
                    },
                    editor: {
                        xtype: 'combobox',
                        editable: true,
                        forceSelection: false,
                        enableRegEx:true,
                        // queryMode: 'local',
                        queryMode: 'local', // 设置为远程查询模式
                        displayField: 'name',
                        valueField: 'projectNumber',
                        store: projectListStore,
                        listeners: {
                            'beforequery': function (e) {
                                var combo = this,
                                    size = 15,
                                    idx = 1;

                                if (e.query === '' || e.query == null) {
                                    // 当输入框为空或内容被删除时，清除过滤器，显示原始数据
                                    combo.store.clearFilter();
                                    combo.expand();
                                } else {
                                    if (!e.forceAll) {
                                        // 每次输入都清除之前的过滤器，确保每次输入都能进行新的检索
                                        combo.store.clearFilter();
                                        var input = e.query.toUpperCase(); // 将输入内容转换为大写

                                        // 创建正则表达式，用于模糊匹配
                                        var regExp = new RegExp(".*" + input + ".*");

                                        // 使用 filterBy 方法进行数据过滤
                                        combo.store.filterBy(function (record, id) {
                                            if (idx > size) {
                                                return false;
                                            }
                                            var text = record.get(combo.displayField).toUpperCase(); // 将记录中的文本转换为大写
                                            var flag = regExp.test(text);
                                            if (flag) {
                                                idx++;
                                            }
                                            return flag;
                                        });

                                        // 展开下拉框，显示过滤后的数据
                                        combo.expand();

                                        // 阻止默认的查询行为
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                },
                {text: '项目编码', dataIndex: 'projectNumber', width: 100, menuDisabled: true,renderer:showTip,
                    // renderer: function (value, meta, record) {
                    //     // 确保样式支持换行
                    //     meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                    //     return value ? value.replace(/\n/g, "<br/>") : '';
                    // },
                },
                {text: '项目阶段（前）', dataIndex: 'projectPhase', width: 120, menuDisabled: true,
                    // renderer:showTip,
                    renderer: function (value, meta, record) {
                        // 确保样式支持换行
                        meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                        return value ? value.replace(/\n/g, "<br/>") : '';
                    },
                    editor: {
                        xtype: 'combobox',
                        editable: false,
                        forceSelection: false,
                        displayField: 'projectPhase',
                        valueField: 'projectPhaseVal',
                        store: projectPhaseStore
                    }
                },
                {text: '活动名称', dataIndex: 'activityName', width: 90, menuDisabled: true,
                    // renderer:showTip,
                    renderer: function (value, meta, record) {
                        // 确保样式支持换行
                        meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                        return value ? value.replace(/\n/g, "<br/>") : '';
                    },
                    editor: {
                        xtype: 'combobox',
                        editable: true,
                        forceSelection: false,
                        enableRegEx:true,//模糊搜索
                        queryMode: 'local', // 或者 'remote'，根据你的需求
                        displayField: 'activityName',
                        valueField: 'activityName',
                        store: activityListStores
                    }
                },
                {text: '正常工时(h)', dataIndex: 'manHour', width: 90, menuDisabled: true,
                    editor:{
                        xtype: 'numberfield',
                        minValue: '0',
                        maxValue: '8',
                        decimalPrecision: 1,
                        labelWidth: 100
                    }
                },
                {text: '附加工时(h)', dataIndex: 'manhourOvertime', width: 90, menuDisabled: true,
                    editor:{
                        xtype: 'numberfield',
                        minValue: '0',
                        maxValue: '16',
                        decimalPrecision: 1,
                        labelWidth: 100
                    }
                },
                {
                    text: '工作内容及遇到的问题或风险',
                    flex: 1,
                    // editor: 'textarea',
                    editor: {
                        xtype: 'textarea',
                        grow: true,  // 使 textarea 自动增长
                        growMin: 3  // 最小行数
                    },
                    dataIndex: 'manJobContent',
                    rows: 5,
                    width: 300,
                    menuDisabled: true,
                    renderer:showTip,
                    renderer: function (value, meta, record) {
                        // 确保样式支持换行
                        meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                        return value ? value.replace(/\n/g, "<br/>") : '';

                        // meta.style = 'overflow:auto;padding: 3px 6px;text-overflow: ellipsis;white-space: nowrap;white-space:normal;line-height:20px;';
                        // value = value.replace(/\n/g, "<br/>")
                        // return value;
                    },
                    listeners: {
                        edit: function (editor, e) {
                            // 获取当前编辑的 textarea
                            var textarea = e.field;
                            // 监听输入事件，动态调整高度
                            textarea.on('keyup', function () {
                                var rows = textarea.getValue().split('\n').length;
                                textarea.setRows(rows);
                            });
                        }
                    }
                },
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var docState = Ext.getCmp('docState').getValue()
                    if (docState != '创建' && docState != '返工') {
                        return false;
                    }
                },
            },
            tbar: [{
                text: '<span style="font-weight:bold;">添加</span>',
                id: 'addItem',
                iconCls: 'icon icon-add',
                scope: this,
                handler: function () {
                    // Ext.getStore('projectListStore').load()
                    // requireWin2.show();

                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.success==true) {
                            getGridInfo();
                        }else {
                            getGridInfo();
                            alert(obj.msg);
                        }
                    };
                    insertData(Ext.getCmp('id').getValue(), "", callbackFn);

                }
            },
                //     {
                //     text: '<span style="font-weight:bold;">修改</span>',
                //     id: 'saveItem',
                //     iconCls: 'icon icon-update',
                //     scope: this,
                //     hidden: true,
                //     handler: function () {
                //         var editRecords = Ext.getCmp('WorkReportGrid').getSelectionModel().getSelection();
                //         if (editRecords.length == 0) {
                //             alert("请选择要编辑的产品信息！");
                //             return;
                //         } else if (editRecords.length > 1) {
                //             alert("只能编辑一个产品信息！");
                //             return;
                //         }
                //         //ID
                //         var id = editRecords[0].data['id'];
                //         Ext.getStore('projectListStore').load()
                //         getReportItemById(id);
                //         requireWin2.show();
                //
                //     }
                // },
                {
                    text: '<span style="font-weight:bold;">删除</span>',
                    id: 'delItem',
                    iconCls: 'icon icon-delete',
                    scope: this,
                    handler: function () {
                        let selectionArr = WorkReportGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        Ext.Msg.confirm('提示', '确定要删除？',
                            function (btn) {
                                if (btn == 'yes') {
                                    //数据组装
                                    let obj = new Array();
                                    Ext.each(selectionArr, function (record) {
                                        obj.push(record.data['id'])
                                    });
                                    var callbackFn = function () {
                                        //tRecord.commit();
                                        Ext.getStore('WorkReportGridStore').reload()
                                    };
                                    deleteData(obj, callbackFn);
                                } else {
                                    return;
                                }
                            }, this);

                    }
                },
                {
                    text: '<span style="font-weight:bold;">项目高级查询</span>',
                    id: 'projectInquiry',
                    iconCls: 'icon icon-search',
                    scope: this,
                    handler: function () {
                        var recordList = WorkReportGrid.getSelectionModel().getSelection();
                        if(recordList.length == 0){
                            alert("请选择一条数据！");
                            return;
                        }
                        if(recordList.length > 1){
                            alert("只能选择一条数据！");
                            return;
                        }
                        projectWorkItemsId = recordList[0].data.id;

                        projectInquiryWindow.show();
                    }
                },
                {
                    xtype: 'button',
                    text: '下载导入模板',
                    id: 'downLoadTemplate',
                    iconCls: 'icon icon-download',
                    // hidden: downloadECAEBOM?false:true,
                    handler: function () {
                        window.location.href = '/Windchill/ptc1/ECRApprovalRecords/downLoadTemplate?templateName=报工导入模版';
                    }
                },
                {
                    xtype:'filefield',
                    buttonOnly: true,
                    id:'workReportUpload',
                    hideLabel: true,
                    // hidden: ecaEBOMuploadECAEBOM?false:true,
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入报工记录</span>',
                    // buttonText: '<span style="width:120px; background-color:white; color:black; padding:5px; display:inline-block; text-align:center;">' +
                    //     '<img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入报工记录</span>',

                    allowBlank: false,
                    scope: this,
                    listeners:{
                        'change':function(fb,newValue,oldValue,opts){
                            if(!newValue){
                                return;
                            }
                            var file = document.querySelector('[id=workReportUpload-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('workReportUpload-button-fileInputEl', file.files[0]);

                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在导入数据，请稍候......',
                                target: WorkReportGrid
                            });

                            var date = Ext.getCmp('workDate').getValue();
                            var formattedDate = Ext.Date.format(date, 'Y-m-d'); // 格式化为 '年-月-日'

                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/workReport/importWorkReport?masterId=' + Ext.getCmp('id').getValue() + '&workDate=' + formattedDate,
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function(res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if(!success){
                                    alert(msg);
                                    // Ext.getStore('ecaEBOMStore').load();
                                    // ecaEBOMGrid.getStore().load();
                                }
                                getFormInfo()
                                // WorkReportGrid.getStore().load();
                            }).fail(function(res) {
                                var obj = Ext.decode(res);
                                var msg = obj['msg'];
                                myMask.hide();
                                alert('导入失败！\n'+msg) ;
                            });
                        }
                    }
                },
                '->',]
        });

        WorkReportGrid.on('rowclick', function (view, record, item, index, e){

            var docState = Ext.getCmp('docState').getValue()
            if (docState != '创建' && docState != '返工') {
                return false;
            }

            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex+2; // 获取单元格的索引，前面隐藏了两列所以加2
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                var productLine = record.get('productLine');
                var projectNumber = record.get('projectNumber');
                var phase = record.get('projectPhase');
                //项目名称下拉
                // if (columnName == 'projectName'&&(!productLine1===productLine)||productLine==undefined) {
                if (columnName == 'projectName') {
                    if(workDate==""||workDate!=Ext.getCmp('workDate').getValue()||productLine1!=productLine){
                        productLine1=productLine;
                        workDate=Ext.getCmp('workDate').getValue();
                        Ext.getStore("projectListStore").load(
                            {
                                params: {
                                    productLine:productLine,
                                    workDate: Ext.getCmp('workDate').getValue()
                                }
                            }
                        );
                    }
                };
                //产品线下拉
                if (columnName == 'productLine') {
                    Ext.getStore("projectLineListStore").load(
                        {
                            params: {
                                productLine:projectNumber,
                                workDate: Ext.getCmp('workDate').getValue()
                            }
                        }
                    );
                }
                //活动名称下拉
                if (columnName == 'activityName') {
                    // if(!phase){
                    //     alert("请先选择“项目阶段（前）”！");
                    //     return;
                    // }
                    Ext.getStore("activityListStores").load(
                        {
                            params: {
                                projectNumber:projectNumber,
                                phase:phase
                            }
                        }
                    );
                };
                //项目阶段（前）下拉
                if (columnName == 'projectPhase') {
                    if(!projectNumber){
                        alert("请先选择“项目名称”！");
                        return;
                    }
                    Ext.getStore("projectPhaseStore").load(
                        {
                            params: {
                                projectNumber:projectNumber
                            }
                        }
                    );
                };
            }
        });

        WorkReportGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let oldValue = e.originalValue;//旧值
            if(value===oldValue||(oldValue===undefined&&value===null)){
                return;
            }
            let id = record.get('id');
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success==true) {
                    getGridInfo();
                }else {
                    alert(obj.msg)
                }
            };

            if(field == 'manHour'){
                if (value < 0.1 || value > 24) {
                    alert("请输入0.1-24之间数字")
                }
                var is = checkHour(value, id);
                if (!is) {
                    saveData(id, field, 0, callbackFn);
                    return;
                }
            }
            if(field == 'manhourOvertime'){
                if (value < 0.1 || value > 24) {
                    alert("请输入0.1-24之间数字")
                }
                var is = checkHour(value, id);
                if (!is) {
                    saveData(id, field, 0, callbackFn);
                    return;
                }
            }
            saveData(id, field, value, callbackFn);

        });


        Ext.define('departmentWorkGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'masterId', 'workNumber', 'natureOfWork', 'projectNumber', 'projectName', 'principals', 'activityName',
                'projectPhase', 'manHour', 'manhourOvertime', 'manJobContent'],
            idProperty: 'id'
        });

        var departmentWorkGridStore = Ext.create('Ext.data.Store', {
            id: 'departmentWorkGridStore',
            model: 'departmentWorkGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getDepartmentWorkByMasterId',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        let natureOfWorkStore = [
            // 培训学习、部门类会议、技术评审类会议、文件/报表处理、技术问题处理、新员工辅导、流程处理、其他
            ['培训学习', '培训学习'],
            ['部门类会议', '部门类会议'],
            ['技术评审类会议', '技术评审类会议'],
            ['文件/报表处理', '文件/报表处理'],
            ['技术问题处理', '技术问题处理'],
            ['新员工辅导', '新员工辅导'],
            ['流程处理', '流程处理'],
            ['产品送检', '产品送检'],
            ['产品认证', '产品认证'],
            ['其他', '其他']
        ];

        var departmentWorkGridCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var departmentWorkGrid = Ext.create('Ext.grid.Panel', {
            plugins: [departmentWorkGridCellEditing],
            store: Ext.getStore('departmentWorkGridStore'),
            id: 'departmentWorkGrid',
            //hidden:true,
            margin: '10 10 0 10',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            height: '98%',
            maxHeight: '320',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',
            // listeners: {
            //     change: 'onAllCircuitsChecked'
            // },
            viewConfig: { enableTextSelection:true},
            columns: [
                {text: '序号',xtype: 'rownumberer', flex: 0.5,editor: false},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '工作性质', dataIndex: 'natureOfWork', flex: 1, menuDisabled: true,renderer:showTip,
                    editor: {
                        xtype: 'combobox',
                        editable: false,
                        forceSelection: false,
                        store: natureOfWorkStore
                    }
                },
                {text: '正常工时(h)', dataIndex: 'manHour', flex: 1, menuDisabled: true,
                    editor:{
                        xtype: 'numberfield',
                        minValue: '0',
                        maxValue: '16',
                        decimalPrecision: 1,
                        labelWidth: 100
                    }
                },
                {text: '附加工时(h)', dataIndex: 'manhourOvertime', flex: 1, menuDisabled: true,
                    editor:{
                        xtype: 'numberfield',
                        minValue: '0',
                        maxValue: '16',
                        decimalPrecision: 1,
                        labelWidth: 100
                    }
                },
                {
                    text: '部门工作内容',
                    flex: 4,
                    editor: {
                        xtype: 'textarea',
                        grow: true,  // 使 textarea 自动增长
                        growMin: 1  // 最小行数
                    },
                    wrap: true,  // 启用自动换行
                    dataIndex: 'manJobContent',
                    renderer:showTip,
                    rows: 5,
                    width: 300,
                    menuDisabled: true,
                    renderer: function (value, meta, record) {
                        // 确保样式支持换行
                        meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                        return value ? value.replace(/\n/g, "<br/>") : '';
                    },
                    listeners: {
                        edit: function (editor, e) {
                            // 获取当前编辑的 textarea
                            var textarea = e.field;
                            // 监听输入事件，动态调整高度
                            textarea.on('keyup', function () {
                                var rows = textarea.getValue().split('\n').length;
                                textarea.setRows(rows);
                            });
                        }
                    }
                }
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var docState = Ext.getCmp('docState').getValue()
                    if (docState != '创建' && docState != '返工') {
                        return false;
                    }
                },
            },
            tbar: [{
                text: '<span style="font-weight:bold;">添加</span>',
                id: 'addDepartmentWork',
                iconCls: 'icon icon-add',
                scope: this,
                handler: function () {
                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.success==true) {
                            // departmentWorkGridStore.load();
                            getDepartmentWorkGridInfo();
                        }else {
                            getDepartmentWorkGridInfo();
                            alert(obj.msg);
                        }
                    };
                    insertData(Ext.getCmp('id').getValue(), "部门工作", callbackFn);
                }
            }, {
                text: '<span style="font-weight:bold;">删除</span>',
                id: 'delDepartmentWork',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    let selectionArr = departmentWorkGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    Ext.Msg.confirm('提示', '确定要删除？',
                        function (btn) {
                            if (btn == 'yes') {
                                //数据组装
                                let obj = new Array();
                                Ext.each(selectionArr, function (record) {
                                    obj.push(record.data['id'])
                                });
                                var callbackFn = function () {
                                    //tRecord.commit();
                                    // Ext.getStore('departmentWorkGridStore').reload()
                                    getDepartmentWorkGridInfo();
                                };
                                deleteData(obj, callbackFn);
                            } else {
                                return;
                            }
                        }, this);

                }
            }, '->',]
        });

        departmentWorkGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let id = record.get('id');
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success==true) {
                    getDepartmentWorkGridInfo();
                }else {
                    alert(obj.msg)
                }
            };

            if(field == 'manHour'){
                if (value < 0.1 || value > 24) {
                    alert("请输入0.1-24之间数字")
                }
                var is = checkHour(value, id);
                if (!is) {
                    saveData(id, field, 0, callbackFn);
                    return;
                }
            }
            if(field == 'manhourOvertime'){
                if (value < 0.1 || value > 24) {
                    alert("请输入0.1-24之间数字")
                }
                var is = checkHour(value, id);
                if (!is) {
                    saveData(id, field, 0, callbackFn);
                    return;
                }
            }
            saveData(id, field, value, callbackFn);

        });


        var WorkReportForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '98%',
            hideLabel: true,
            frame: false,
            autoScroll: true,
            height: '99%',
            //autoHeight:true,
            padding: '5',
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            //layout: "anchor",// 整个大的表单是anchor布局
            items: [
                {//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    width: '98%',
                    margin: '10 20 0 0',
                    defaults: {margin: '5 20 0 0', labelWidth: 70, border: false},
                    items: [
                        {
                            xtype: 'datefield',
                            border: false,
                            fieldLabel: '工作日期',
                            padding: '10 15 0 20',
                            format: 'Y-m-d',
                            maxValue: new Date(),
                            id: 'workDate',
                            name: 'workDate',
                            width: 200,
                            listeners: {
                                change: function (e) {
                                    Ext.getCmp('createDoc').enable();
                                    getFormInfo();
                                }
                            }
                        }, {
                            xtype: 'button',
                            id: 'createDoc',
                            text: '创建工作日报',
                            handler: function () {
                                var hourLink = Ext.getCmp('hourLink').getValue();
                                var workDate = Ext.getCmp('workDate').getValue();
                                if (workDate != null) {
                                    if (hourLink == "") {
                                        var flag  = isCreateInfo();
                                        if (flag) {
                                            Ext.getCmp('createDoc').disable();
                                            createDoc();
                                        }
                                    } else {
                                        alert("本日已创建日报");
                                        return false;
                                    }

                                } else {
                                    alert("请选择工作时间")
                                    return false;
                                }

                            }
                        }, {
                            xtype: 'displayfield',
                            id: 'id',
                            hidden: true,
                            fieldLabel: ''
                        }, {
                            xtype: 'displayfield',
                            id: 'itemId',
                            hidden: true,
                            fieldLabel: ''
                        }, {
                            xtype: 'displayfield',
                            id: 'docBranchId',
                            // width: 220,
                            hidden: true,
                            fieldLabel: ''
                        }, {
                            xtype: 'displayfield',
                            id: 'hourLink',
                            // width: 150,
                            hidden: true,
                            fieldLabel: '文档编号'
                        }, {
                            xtype: 'displayfield',
                            id: 'docState',
                            hidden: true,
                            fieldLabel: '文档状态'
                        }, {
                            xtype: 'combobox',
                            multiSelect: false,
                            valueField: 'no',
                            displayField: 'userFullName',
                            queryMode: 'local',
                            anyMatch: true,
                            typeAhead: true,
                            //editable: false,
                            forceSelection: true,
                            triggerAction: 'all',
                            width: 150,
                            fieldLabel: '审批人:',
                            store: allUserStore_projectPlan,
                            name: 'approver',
                            id: 'approver',
                            hidden: true,
                            disabled: true,
                            disabledCls: 'none',
                            listeners: {
                                blur: function () {
                                    saveCarbonCopy();
                                }
                            }
                        }, {
                            xtype: 'button',
                            text: "修订",
                            hidden: true,
                            id: 'revise',
                            name: 'revise',
                            handler: function () {
                                var info = Ext.getCmp("docState").getValue();

                                if (info != '已发布') {
                                    alert("只有已发布状态可修订！");
                                    return;
                                }
                                Ext.Msg.confirm('提示', '确定要修订到创建状态吗？',
                                    function (btn) {
                                        if (btn == 'yes') {
                                            revise()
                                        }
                                    });
                            }
                        },
                        {
                            xtype: 'button',
                            text: "提交",
                            // width: 120,
                            // height: 30,
                            hidden: true,
                            id: 'commitTop',
                            name: 'commitTop',
                            // margin: '10 0 18 0',
                            handler: function () {

                                let selectionArr = WorkReportGrid.getStore().getTotalCount();
                                checkInfo(selectionArr);
                            }
                        }, {
                            xtype: 'button',
                            text: "删除",
                            // width: 120,
                            // height: 30,
                            hidden: true,
                            id: 'deleteTop',
                            name: 'deleteTop',
                            // margin: '10 0 18 0',
                            handler: function () {
                                deleteDocOrProcess("doc");
                            }
                        }, {
                            xtype: 'button',
                            text: "撤回",
                            // width: 120,
                            // height: 30,
                            hidden: true,
                            id: 'recallTop',
                            name: 'recallTop',
                            // margin: '10 0 18 0',
                            handler: function () {
                                deleteDocOrProcess("process");
                            }
                        }

                    ]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '10 20 0 0',
                    defaults: {margin: '5 20 0 0', labelWidth: 70, border: false},
                    items: [{
                        xtype: 'combobox',
                        width: 250,
                        fieldLabel: '选择抄送人:',
                        // multiSelect: true,
                        //editable: false,
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        disabled: true,
                        hidden: true,
                        disabledCls: 'none',
                        valueField: 'no',
                        //valueField: 'no',
                        displayField: 'userFullName',
                        store: allUserStore_projectPlan1,
                        name: 'carbonCopyText',
                        id: 'carbonCopyText',
                        listeners: {
                            select: function (e) {
                                var carbonCopy = Ext.getCmp("carbonCopyText").getRawValue();
                                //var carbonCopy = Ext.getCmp("carbonCopyText").getValue();
                                var carbonCopyText = Ext.getCmp("carbonCopy").getValue();
                                var values = carbonCopyText.split(",");

                                var carbonCopyAutomatic = Ext.getCmp("carbonCopyAutomatic").getValue();
                                var carbonCopyAutomaticList = carbonCopyAutomatic.split(",");
                                for (var i = 0; i < carbonCopyAutomaticList.length; i++) {
                                    if (carbonCopy == carbonCopyAutomaticList[i]) {
                                        alert("当前选择的人员已经在“已选择抄送人（自动）”中存在！");
                                        return;
                                    }
                                }

                                var isEq = true;
                                debugger
                                for (var i = 0; i < values.length; i++) {
                                    if (carbonCopy == values[i]) {
                                        isEq = false;
                                        return;
                                    }
                                }
                                if (isEq) {
                                    //Ext.getCmp("carbonCopy").setValue(carbonCopyText + ',' + carbonCopy)
                                    saveReport();
                                }
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        width: 550,
                        labelWidth: 100,
                        fieldLabel: '已选择抄送人（手动）:',
                        hidden: true,
                        disabled: true,
                        disabledCls: 'none',
                        name: 'carbonCopy',
                        id: 'carbonCopy',
                        listeners: {
                            blur: function (e) {

                                saveCarbonCopy();
                            }
                        }
                    },{
                        hidden: true,
                        id: 'carbonCopyInfo',
                        html: '“,”分隔',
                        margin: '10 50 0 0', border: false
                    },]
                }
                , {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '10 20 0 0',
                    defaults: {margin: '5 20 0 0', labelWidth: 70, border: false},
                    items: [
                        {
                            xtype: 'textfield',
                            width: 550,
                            labelWidth: 100,
                            fieldLabel: '已选择抄送人（自动）:',
                            hidden: true,
                            readOnly:true,
                            disabled: true,
                            disabledCls: 'none',
                            name: 'carbonCopyAutomatic',
                            id: 'carbonCopyAutomatic',
                            listeners: {
                                blur: function (e) {

                                    saveCarbonCopy();
                                }
                            }
                        }
                        , {
                            hidden: true,
                            id: 'carbonCopyAutomaticInfo',
                            html: '“,”分隔',
                            margin: '10 50 0 0', border: false
                        }
                        ,{
                            xtype: 'button',
                            text: "填写说明",
                            style: {
                                backgroundColor: 'red',
                                color: 'white' // 文字颜色可选白色更清晰
                            },
                            // width: 120,
                            // height: 30,
                            hidden: true,
                            id: 'explanationButton',
                            name: 'explanationButtonW',
                            // margin: '10 0 18 0',
                            handler: function () {
                                explanationButtonWindow.show();
                            }
                        }
                    ]
                }

                , {
                    xtype: 'panel',
                    hidden: true,
                    //layout: 'hbox',
                    id: 'panel2',
                    border: false,
                    margin: '10 20 0 0',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false},
                    items: [
                        //     {
                        //     // html: '<div  >需抄送人员:1.项目工作需抄送给对应的项目管理工程师、开发代表、项目负责人；2.部门工作需抄送给部门主管</div>'
                        //     html: '<div  >' +
                        //         '<h3 style="margin: 0;">需抄送人员：</h3>' +
                        //         '<ol>' +
                        //         '<li>选择待报工的项目后系统会自动抄送该项目的PDT/TDT经理、项目管理工程师、开发代表，项目负责人；</li>' +
                        //         '<li>部门工作需抄送给部门主管；</li>' +
                        //         '<li>用户可以手动选择抄送其他人员；</li>' +
                        //         '</ol>' +
                        //         '</div>'
                        // },
                        {
                            margin: '10 0 0 0',
                            html: '<div style="font-weight:bold;font-size:24px;top:50px;left:50px;background-color: gainsboro;background-size:100%;text-align:center;height: 35px;line-height: 35px;">项目工作</div>'
                        },
                        //     {
                        //     border: false,
                        //     // html: '<div  >指投入项目中的工作，如PDT/TDT产品线项目、Charter开发项目、产品技术支持等。如该工作无具体对应的项目，则选择该工作所属产品线的费用公摊项目。工时单位：小时，包括加班时间。<div/>'
                        //     html: '<div  >' +
                        //         '<h3 style="margin: 0;">说明：</h3>' +
                        //         '<ol>' +
                        //         '<li>指投入项目中的工作，如PDT/TDT产品线项目、Charter开发项目、产品技术支持等；</li>' +
                        //         '<li>如该工作无具体对应的项目，则选择该工作所属产品线的费用公摊项目；</li>' +
                        //         '<li>当默认的项目阶段、活动名称与实际不一致时，请手动调整；</li>' +
                        //         '<li>工时单位：小时，包括加班时间；</li>' +
                        //         '</ol>' +
                        //         '</div>'
                        // },
                        WorkReportGrid,
                        {
                            margin: '10 0 0 0',
                            html: '<div style="font-weight:bold;font-size:24px;top:50px;left:50px;background-color: gainsboro;background-size:100%;text-align:center;height: 35px;line-height: 35px;">部门工作</div>'
                        },
                        // {
                        //     html: '<div style="font-weight:bold;font-size:16px;top:50px;left:50px;text-align:left">部门工时填写(h)</div>'
                        // },
                        // {
                        //     // html: '<div  >指产品线之外的工作，例如：CBB、专利编制、部门能力建设等。工作单位：小时，包括加班时间。当天展开了部门工作，则部门工时不可以为0<div/>'
                        //     html: '<div  >' +
                        //         '<h3 style="margin: 0;">说明：</h3>' +
                        //         '<ol>' +
                        //         '<li>指产品线之外的工作，例如：培训学习、会议、流程/文件处理、技术问题处理等；</li>' +
                        //         '<li>工作单位：小时，包括加班时间；</li>' +
                        //         '<li>当天展开了部门工作，则部门工时不可以为0；</li>' +
                        //         '</ol>' +
                        //         '</div>'
                        // },
                        {
                            xtype: 'numberfield',
                            fieldLabel: '',
                            name: 'manHour1',
                            hidden: true,
                            id: 'manHour1',
                            minValue: '0',
                            maxValue: '24',
                            decimalPrecision: 3,
                            width: 200,
                            disabledCls: 'none',
                            listeners: {
                                blur: function (e) {
                                    var manHour1 = Ext.getCmp("manHour1").getValue();
                                    var itemId = Ext.getCmp("itemId").getValue();
                                    if (manHour1 < 0.1 || manHour1 > 24) {
                                        alert("请输入0.1-24之间数字")
                                        Ext.getCmp("manHour1").setValue(0);
                                    }
                                    var is = checkHour(manHour1, itemId);
                                    //alert(is)
                                    if (!is) {
                                        Ext.getCmp("manHour1").setValue(0);
                                        saveDepartmentReport();
                                    } else {
                                        saveDepartmentReport();
                                    }
                                },
                            }
                        },{
                            xtype: 'numberfield',
                            fieldLabel: '',
                            name: 'manhourOvertime1',
                            hidden: true,
                            id: 'manhourOvertime1',
                            minValue: '0',
                            maxValue: '24',
                            decimalPrecision: 3,
                            width: 200,
                            disabledCls: 'none',
                            listeners: {
                                blur: function (e) {
                                    var manhourOvertime1 = Ext.getCmp("manhourOvertime1").getValue();
                                    var itemId = Ext.getCmp("itemId").getValue();
                                    if (manhourOvertime1 < 0.1 || manhourOvertime1 > 24) {
                                        alert("请输入0.1-24之间数字")
                                        Ext.getCmp("manhourOvertime1").setValue(0);
                                    }
                                    var is = checkHour(manhourOvertime1, itemId);
                                    //alert(is)
                                    if (!is) {
                                        Ext.getCmp("manhourOvertime1").setValue(0);
                                        saveDepartmentReport();
                                    } else {
                                        saveDepartmentReport();
                                    }
                                },
                            }
                        },
                        // {
                        //     html: '<div style="font-weight:bold;font-size:16px;top:50px;left:50px;text-align:left">部门工作内容</div>'
                        // }, {
                        //     html: '<div>简述工作内容，及遇到的问题。</div>'
                        // },
                        departmentWorkGrid,
                        {
                            xtype: 'textarea',
                            fieldLabel: '',
                            hidden: true,
                            name: 'manJobContent1',
                            id: 'manJobContent1',
                            disabledCls: 'none',
                            maxLength: 1200,
                            maxLengthText: "工作内容必须在1200字及以内!",
                            width: 800,
                            height: 300,
                            listeners: {
                                blur: function (e) {
                                    /*debugger
                                    var ex= /^(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0+[13578]|0?1[02])-(0+[1-9]|0?[12][0-9]|0?3[01]))|((0[469]|0?11)-(0+[1-9]|0?[12][0-9]|0?30))|(0+2-(0+[1-9]|0?[1][0-9]|0?2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-0+2-0?29)$/
                                    var s = ex.test(e.getValue());
    */
                                    if (e.getValue().toString().length < 1300) {
                                        saveDepartmentReport();
                                    }
                                },
                            }
                        }, {
                            html: '<HR align=left width=100% SIZE=1>'
                        }, {
                            xtype: 'label',
                            text: '工时合计（h）:0小时',
                            //labelCls:'x-grid-red',
                            //style:{'font-weight':'bold' ,'font-size':'16px','top':'50px','left':'50px','text-align':'left'},
                            //html: '工时统计：0',
                            id: "userWorkHoursCountLable",
                        }, {
                            xtype: 'button',
                            text: "提交",
                            width: 120,
                            height: 30,
                            hidden: true,
                            id: 'commitBottom',
                            name: 'commitBottom',
                            margin: '10 10 18 0',
                            handler: function () {
                                let selectionArr = WorkReportGrid.getStore().getTotalCount();
                                checkInfo(selectionArr);
                            }
                        }, {
                            xtype: 'button',
                            text: "删除",
                            width: 120,
                            height: 30,
                            hidden: true,
                            id: 'deleteBottom',
                            name: 'deleteBottom',
                            margin: '10 10 18 10',
                            handler: function () {
                                deleteDocOrProcess("doc");
                            }
                        }, {
                            xtype: 'button',
                            text: "撤回",
                            width: 120,
                            height: 30,
                            hidden: true,
                            id: 'recallBottom',
                            name: 'recallBottom',
                            margin: '10 0 18 10',
                            handler: function () {
                                deleteDocOrProcess("process");
                            }
                        }
                    ],
                }]
        };

        Ext.define('userWorkHoursTreeModel', {
            extend: "Ext.data.TreeModel",
            fields: [
                'date', 'wid','shouldBeReported','reported','reviewed','correspondingColor'
            ],
            idProperty: 'id'
        });


        var userWorkHoursTreeStore = Ext.create("Ext.data.TreeStore", {
            model: "userWorkHoursTreeModel",
            id: 'userWorkHoursTreeStoreId',
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getTreeByWorkNumber',//请求
                reader: {
                    type: 'json'
                },
                timeout: 1200000
            },
            autoLoad: true,
            root: {
                coreRole: '日报',
                expanded: true
            },
            //倒序排序
            // sorters: [{
            //     property: 'date',
            //     direction: 'desc'
            // }]
        });


        var userWorkHoursTreePanel = Ext.create('Ext.tree.TreePanel', {
            store: userWorkHoursTreeStore,
            id: 'userWorkHoursTreePanel',
            autoWidth: true,
            autoScroll: true,
            rootVisible: false,
            width: 310,
            height: 880,
            viewConfig: {
                enableTextSelection: true,
                // forceFit: false
            },
            columns: [
                // {text: '日期', dataIndex: 'date', xtype: 'treecolumn', width: 200},
                {text: '日期', width: 160,dataIndex: 'date', xtype: 'treecolumn',
                    renderer: function(value,metaData,record,row,col,store){
                        // let color = '#C7CECF';
                        let color = '';
                        // 获取当前行的数据
                        var correspondingColor = record.get('correspondingColor'); // 默认颜色
                        // if("red" == correspondingColor){
                        //     color = '#cf141a';
                        // }
                        // if("yellow" == correspondingColor){
                        //     color = '#cfcd33';
                        // }
                        // if("green" == correspondingColor){
                        //     color = '#1bcf0f';
                        // }

                        if ("red" === correspondingColor) {
                            color = 'rgba(207, 20, 26, 0.6)'; // 红色，透明度为 0.5
                        } else if ("yellow" === correspondingColor) {
                            color = 'rgba(207, 205, 51, 0.5)'; // 黄色，透明度为 0.5
                        } else if ("green" === correspondingColor) {
                            color = 'rgba(27, 207, 15, 0.5)'; // 绿色，透明度为 0.5
                        }

                        metaData.tdAttr = 'style="background-color: ' + color + ';width: 160px;"';
                        return value;
                    }
                },
                {text: '应报', width: 50, dataIndex: 'shouldBeReported', menuDisabled: true, sortable: false},
                {text: '已报', width: 50, dataIndex: 'reported', menuDisabled: true, sortable: false},
                {text: '已审', width: 50, dataIndex: 'reviewed', menuDisabled: true, sortable: false},
            ],
            listeners: {
                'cellclick': function (orgThis, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var id = record.get("wid")+"";
                    if (id && id.includes(";;;qqq")) {
                        // 截取 ";;;qqq" 之后的内容
                        var extractedContent = id.substring(id.indexOf(";;;qqq") + ";;;qqq".length);
                        Ext.getCmp('workDate').setValue(extractedContent);
                        return
                    }

                    if (id != 'root' || id == "" || id == null) {
                        getFormInfoById(id);
                    }
                }
            },
        });

        // 创建一个包含文本的子面板
        var textPanel = Ext.create('Ext.panel.Panel', {
            // title: '提示信息',
            html: '<span style="color: black;">红色：应报还未填报;</span> ' +
                '<span style="color: black;">黄色：已报还未审</span><br> ' +
                '<span style="color: black;">绿色：已报已审;</span> ' +
                '<span style="color: black; ">白色：据实填报。</span>',
            border: false,
            bodyPadding: 10,
            style: {
                backgroundColor: '#f0f0f0' // 可选：设置背景颜色
            }
        });

// 创建一个父容器，将 textPanel 和 userWorkHoursTreePanel 添加到其中
        var parentPanel = Ext.create('Ext.panel.Panel', {
            layout: 'vbox', // 使用垂直布局
            items: [
                textPanel, // 文本面板在上方
                userWorkHoursTreePanel // 树形面板在下方
            ]
        });



/////////////////////////Main Panel items//////////////////////////////////
        this.items = [
            {
                region: 'west',
                border: false,
                split: true,
                // width: 190,
                minWidth: 175,
                maxWidth: 400,
                collapsible: true,
                //collapseMode: 'mini',
                width: 310,
                // items: [userWorkHoursTreePanel]
                items: [parentPanel]
            },
            // {
            //     region: 'center',
            //     collapsible: false,
            //     items: [WorkReportForm],
            //     id: 'centerPanel'
            // }

            {
                xtype: 'panel',  // 定义一个新的panel
                region: 'center',  // 新的panel占据中心区域
                layout: 'fit',  // 使用fit布局来填充区域
                items: [{  // 在这个新的panel中嵌套原有的配置
                    xtype: 'panel',
                    collapsible: false,
                    items: [WorkReportForm],
                    id: 'centerPanel'
                }]
            }

        ]


        Ext.getCmp("userWorkHoursTreePanel").getStore().addListener('load', function (st, rds, opts) {
        });

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {

        }
    }
});


