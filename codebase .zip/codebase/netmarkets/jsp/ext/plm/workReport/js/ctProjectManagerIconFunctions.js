
/**
 * 产品线数据图表
 */
function projectLineQuery() {
    var data = {
        workNumber: Ext.getCmp("userName").getValue(),
        projectName: Ext.getCmp("projectName").getValue(),
        departmentName: Ext.getCmp("departmentName").getValue(),
        productLine: Ext.getCmp("productLine").getValue(),
        dateStart: Ext.getCmp("dateStart").getValue(),
        dateEnd: Ext.getCmp("dateEnd").getValue(),
        projectNumber:Ext.getCmp("projectNumber").getValue(),
        queryField:'productLine'
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getProductChart',
        method: "POST",
        params: {
            data:Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var items = obj.items;
            var xAxisData = items[0];
            var yAxisData = items[1];
            // 初始化 ECharts 实例
            var chart = echarts.init(document.getElementById('projectLine-echarts-container'));
            // ECharts 配置
            var option = {
                title: {
                    text: '产品线工时分布（单位：小时）',
                    left: 'center',
                    top: 20,
                    textStyle: {
                        fontSize: 16,        // 字体大小
                        fontWeight: 'bold',  // 字体粗细
                        // color: '#333'        // 字体颜色
                    }
                },
                tooltip: {
                    trigger: 'item',
                    formatter: function (params) {
                        return '产品线名称：' + params.name + '<br/>工时：' + params.value;
                    },
                    backgroundColor: '#fff',
                    borderColor: '#ddd',
                    borderWidth: 1,
                    confine: true,
                    textStyle: {
                        color: '#333'
                    }
                },
                grid: {
                    left: '10%',
                    right: '10%',
                    bottom: '10%',
                    containLabel: true
                },
                xAxis: {
                    data: xAxisData,
                    axisLabel: {
                        rotate: 45,
                        margin: 10, // 标签与轴线的间距
                        interval: 0,  // 设置为 0 以显示所有标签，或者设置为适当的值以间隔显示
                        textStyle: {
                            fontSize: 10, // X 轴标签字体大小
                            color: '#333' // X 轴标签字体颜色
                        }
                    }
                },
                yAxis: {},
                series: [{
                    name: '产品线',
                    type: 'bar',
                    data: yAxisData,
                    label: {
                        show: true, // 显示标签
                        position: 'top', // 标签显示在顶部
                        // formatter: '{c}' // 格式化标签显示内容
                    }
                }]
            };
            // 使用配置项和数据显示图表
            chart.setOption(option);
        },
        failure: function (response, opts) {
            alert('提交错误：请检查网络！');
        }
    });
}


/**
 * 项目类型数据图表
 */
function projectTypeQuery() {
    var data = {
        workNumber: Ext.getCmp("userName").getValue(),
        projectName: Ext.getCmp("projectName").getValue(),
        departmentName: Ext.getCmp("departmentName").getValue(),
        productLine: Ext.getCmp("productLine").getValue(),
        dateStart: Ext.getCmp("dateStart").getValue(),
        dateEnd: Ext.getCmp("dateEnd").getValue(),
        projectNumber:Ext.getCmp("projectNumber").getValue(),
        queryField:'projectType'
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getProductChart',
        method: "POST",
        params: {
            data:Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var items = obj.items;
            var xAxisData = items[0];
            var yAxisData = items[1];
            // 初始化 ECharts 实例
            var chart = echarts.init(document.getElementById('projectType-echarts-container'));
            // ECharts 配置
            var option = {
                title: {
                    text: '项目类型工时分布（单位：小时）',
                    left: 'center',
                    top: 20,
                    textStyle: {
                        fontSize: 16,        // 字体大小
                        fontWeight: 'bold',  // 字体粗细
                        // color: '#333'        // 字体颜色
                    }
                },
                tooltip: {
                    trigger: 'item',
                    formatter: function (params) {
                        return '项目类型名称：' + params.name + '<br/>工时：' + params.value;
                    },
                    backgroundColor: '#fff',
                    borderColor: '#ddd',
                    borderWidth: 1,
                    confine: true,
                    textStyle: {
                        color: '#333'
                    }
                },
                grid: {
                    left: '10%',
                    right: '10%',
                    bottom: '10%',
                    containLabel: true
                },
                xAxis: {
                    data: xAxisData,
                    axisLabel: {
                        rotate: 45,
                        margin: 10, // 标签与轴线的间距
                        interval: 0,  // 设置为 0 以显示所有标签，或者设置为适当的值以间隔显示
                        textStyle: {
                            fontSize: 10, // X 轴标签字体大小
                            color: '#333' // X 轴标签字体颜色
                        }
                    }
                },
                yAxis: {},
                series: [{
                    name: '项目类型',
                    type: 'bar',
                    data: yAxisData,
                    label: {
                        show: true, // 显示标签
                        position: 'top', // 标签显示在顶部
                        // formatter: '{c}' // 格式化标签显示内容
                    }
                }]
            };
            // 使用配置项和数据显示图表
            chart.setOption(option);
        },
        failure: function (response, opts) {
            alert('提交错误：请检查网络！');
        }
    });
}

/**
 * 项目数据图表
 */
function projectQuery() {
    var data = {
        workNumber: Ext.getCmp("userName").getValue(),
        projectName: Ext.getCmp("projectName").getValue(),
        departmentName: Ext.getCmp("departmentName").getValue(),
        productLine: Ext.getCmp("productLine").getValue(),
        dateStart: Ext.getCmp("dateStart").getValue(),
        dateEnd: Ext.getCmp("dateEnd").getValue(),
        projectNumber:Ext.getCmp("projectNumber").getValue(),
        queryField:'projectName'
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getProductChart',
        method: "POST",
        params: {
            data:Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var items = obj.items;
            var xAxisData = items[0];
            var yAxisData = items[1];
            // 初始化 ECharts 实例
            var chart = echarts.init(document.getElementById('project-echarts-containerR'));
            // ECharts 配置
            var option = {
                title: {
                    text: '项目工时分布（单位：小时）',
                    left: 'center',
                    top: 20,
                    textStyle: {
                        fontSize: 16,        // 字体大小
                        fontWeight: 'bold',  // 字体粗细
                        // color: '#333'        // 字体颜色
                    }
                },
                tooltip: {
                    trigger: 'item',
                    formatter: function (params) {
                        return '项目名称：' + params.name + '<br/>工时：' + params.value;
                    },
                    backgroundColor: '#fff',
                    borderColor: '#ddd',
                    borderWidth: 1,
                    confine: true,
                    textStyle: {
                        color: '#333'
                    }
                },
                grid: {
                    left: '10%',
                    right: '10%',
                    bottom: '20%',
                    containLabel: true
                },
                xAxis: {
                    data: xAxisData,
                    axisLabel: {
                        rotate: 45,
                        margin: 10, // 标签与轴线的间距
                        // interval: 0,  // 设置为 0 以显示所有标签，或者设置为适当的值以间隔显示
                        textStyle: {
                            fontSize: 10, // X 轴标签字体大小
                            color: '#333' // X 轴标签字体颜色
                        }
                    }
                },
                yAxis: {},
                series: [{
                    name: '项目',
                    type: 'bar',
                    data: yAxisData,
                    label: {
                        show: true, // 显示标签
                        position: 'top', // 标签显示在顶部
                        // formatter: '{c}' // 格式化标签显示内容
                    }
                }],
                dataZoom: [
                    {
                        type: 'slider',
                        show: true,
                        xAxisIndex: 0,
                        start: 0,
                        end: 100,
                        handleSize: '8%',
                        handleStyle: {
                            color: '#fff',
                            borderColor: '#aaa',
                            borderWidth: 1
                        },
                        textStyle: {
                            color: '#333'
                        }
                    },
                    {
                        type: 'inside',
                        xAxisIndex: 0
                    }
                ]
            };

            // 使用配置项和数据显示图表
            chart.setOption(option);
        },
        failure: function (response, opts) {
            alert('提交错误：请检查网络！');
        }
    });
}
