Ext.define('PLM.view.ctReportNoticeParSet', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctReportNoticeParSet',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ctReportNoticeParSet',
    initComponent: function () {

        var docStateCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'docStateCombo',
            id: 'docStateCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: 'Y' },
                    { fullName: 'N' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName'
        });

        Ext.define('singleUserQueryGridPendingModel', {
            extend: 'Ext.data.Model',
            fields: ['id','docBranchId','docState','hourLink'],
            idProperty: 'id'
        });

        var singleUserQueryPendingStore = Ext.create('PLM.store.MockItemStore', {
            id: 'singleUserQueryPendingStore',
            model: 'singleUserQueryGridPendingModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/reportNoticeParSetQuery',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: true
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var singleUserQueryPendingGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('singleUserQueryPendingStore'),
            id: 'singleUserQueryPendingGrid',
            titleAlign: 'center',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            viewConfig: {
                enableTextSelection: true
            },
            autoScroll: true,
            region: 'center',
            height: '99%',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '序号', dataIndex: 'docBranchId', flex: 0.3, menuDisabled: true},
                {text: '自动漏报提醒规则', dataIndex: 'hourLink', flex: 1, menuDisabled: true},
                {text: '是否激活', dataIndex: 'docState', flex: 1, menuDisabled: true,editor:docStateCombo},
            ]
        });

        singleUserQueryPendingGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let id = record.get('id');
            let docState = record.get('docState');
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                Ext.getStore('singleUserQueryPendingStore').reload()
            };
            saveData( id, field, value, callbackFn);
        });


        var singleUserQueryPendingForm = {
            xtype: 'form',
            id: 'mainPendingForm',
            width: '100%',
            title: '漏报提醒频率设置',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 2 2 2',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [//第*行
                singleUserQueryPendingGrid
            ]
        };

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [singleUserQueryPendingForm];

        this.callParent();



    },//~End of initComponent
    listeners: {
    },


});


function saveData(id, dataKey,dataValue, callbackFn){
    var insertRecord = {
        id:id,
        key:dataKey,
        value:dataValue,
        tableName:'ZWorkReport'
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/workReport/updateInfoById',
        params: {data:Ext.encode(insertRecord)},
        timeout: 1000000,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.success==true) {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.msg);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}



