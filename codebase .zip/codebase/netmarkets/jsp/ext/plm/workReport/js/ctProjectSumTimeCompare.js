/**
 * 项目计划工时与实际工时对比
 * 描述：项目计划工时与实际工时对比
 */
Ext.define('PLM.view.projectSumTimeCompare', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.projectSumTimeCompare',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'projectSumTimeCompare',
    initComponent: function () {
        var me = this;
        Ext.define('projectSumTimeCompareGridModel', {
            extend: 'Ext.data.Model',
            fields: ['status', 'planHour', 'projectNumber','realityHour', 'productLine', 'percent', 'projectName', 'hour'
                ,'planningProjectName','projectSource'],
            idProperty: 'projectName'
        });

        var projectSumTimeCompareStore = Ext.create('PLM.store.MockItemStore', {
            id: 'projectSumTimeCompareStore',
            model: 'projectSumTimeCompareGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getHourContrastInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectNumber', 'name'
            ],
            idProperty: 'projectNumber'
        });


        // 项目下拉
        var projectStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getProjects',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        // 产品线下拉
        var productLineStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            fields: ['name'],
            id: 'productLineStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllProductLine',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var projectSumTimeCompareGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('projectSumTimeCompareStore'),
            id: 'projectSumTimeCompareGrid',
            //margin: '0 5 5 5',
            //forceFit: true,
            autoWidth: true,
            //border:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '98%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer',width:60, align: 'center'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '项目名称', dataIndex: 'projectName', width: 150, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目编号', dataIndex: 'projectNumber', width: 150, menuDisabled: true},
                {text: '项目来源', dataIndex: 'projectSource', width: 100, menuDisabled: true},
                {text: '规划项目名称', dataIndex: 'planningProjectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '产品线', dataIndex: 'productLine', width: 150, menuDisabled: true},
                {text: '任务书计划投入工时(h)', dataIndex: 'totalPlanNedManHours', width: 160, menuDisabled: true},
                {text: 'WBS计划总工时(h)', dataIndex: 'planHour', width: 140, menuDisabled: true},
                {text: 'WBS截止当日计划工时(h)', dataIndex: 'hour', width: 200, menuDisabled: true},
                {text: '实际工时(h)', dataIndex: 'realityHour', width: 150, menuDisabled: true},
                //{text: '实际工时<截止前一天统计时间>', dataIndex: 'hour', width: 220,  menuDisabled: true},
                {text: '实际工时/WBS计划总工时', dataIndex: 'percent', width: 240, menuDisabled: true},
                {
                    text: '状态', dataIndex: 'status', width: 120, menuDisabled: true,
                    renderer: function (v, m) {
                        if (v == '超计划') {
                            m.css = 'x-grid-red';
                        }
                        return v;
                    }
                },
            ]
        });

        var projectSumTimeCompareForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            title: '项目计划工时与实际工时对比',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{//第*行
                xtype: 'panel',
                layout: 'hbox',
                border: false,
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false, padding: 5},
                items: [{
                    xtype: 'combobox',
                    fieldLabel: '项目名称',
                    margin: '0 0 0 20',
                    id: 'projectName',
                    name: 'projectName',
                    store: projectStore,
                    labelWidth: 70,
                    typeAhead: true,
                    triggerAction: 'all',
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'name',
                    forceSelection: true,
                    allowBlank: true,
                    anyMatch: true
                }, {
                    xtype: 'textfield',
                    fieldLabel: '项目编码',
                    margin: '0 0 0 20',
                    id: 'projectNumber',
                    name: 'projectNumber',
                    labelWidth: 70,
                }, {
                    xtype: 'combobox',
                    fieldLabel: '产品线',
                    labelWidth: 70,
                    margin: '0 0 0 20',
                    store: productLineStore,
                    multiSelect: false,
                    anyMatch: true,
                    editable: false,
                    displayField: 'name',
                    valueField: 'name',
                    id: 'productLine',
                    name: 'productLine',
                }, {
                    iconCls: 'icon icon-search',
                    xtype: 'button',
                    id: "query",
                    margin: '0 0 0 20',
                    text: '查询',
                    handler: function () {
                        getHourContrastInfo();
                    }
                }, {
                    text: '导出',
                    iconCls: 'icon icon-store-export',
                    xtype: 'button',
                    margin: '0 0 0 20',
                    handler: function () {
                        exportReport();
                    }
                }
                    , {
                        iconCls: 'icon icon-store-export',
                        xtype: 'button',
                        id: "exportResultSelect",
                        margin: '0 0 0 20',
                        text: '导出选择的数据',
                        handler : function() {
                            let selectionArr = projectSumTimeCompareGrid.getSelectionModel().getSelection();
                            if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                Ext.Msg.alert("提示", "请选择要导出的数据");
                                return;
                            }
                            //数据组装
                            let lists = new Array();
                            Ext.each(selectionArr, function (record) {
                                let list = new Array();
                                list.push(record.data['projectName'])
                                list.push(record.data['projectNumber'])
                                list.push(record.data['productLine'])
                                lists.push(list)
                            });
                            // alert(lists)
                            // lists = Array.from(new Set(lists));
                            lists = Array.from(new Map(lists.map(item => [JSON.stringify(item), item])).values());
                            exportReport(lists,"select");
                        },
                        scope : this
                    }
                ]
            }, {
                layout: 'hbox',
                border: false,
                items: [{
                    border: false,
                    html: '<b style="color: red">搜索结果不包含当日数据</b>',
                    margin: '0 0 0 815',
                }]
            }, projectSumTimeCompareGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [projectSumTimeCompareForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('projectStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('productLineStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    }
});

function exportReport(lists,select) {
    var data = {};
    if("select" === select){
        data = {
            lists: lists,
            select:select
        };
    }else {
        data = getSearchData();
    }
    // var data = getSearchData();
    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportHourContrastInfo', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        console.log(content.type)
        if (content.type == 'application/json') {
            debugger
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp = new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "项目计划工时与实际工时对比" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    xmlResquest.send(
        "data=" + Ext.encode(data)
    );

}

function getSearchData() {
    var data = {
        projectName: Ext.getCmp("projectName").getValue(),
        productLine: Ext.getCmp("productLine").getValue(),
        projectNumber: Ext.getCmp("projectNumber").getValue(),
    };
    return data;
}

function getHourContrastInfo() {
    Ext.getStore('projectSumTimeCompareStore').load({
        params: {
            projectName: Ext.getCmp("projectName").getValue(),
            productLine: Ext.getCmp("productLine").getValue(),
            projectNumber: Ext.getCmp("projectNumber").getValue(),
        },
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    alert('查询超时！请重试！')
                }
            }
        },
    })
}