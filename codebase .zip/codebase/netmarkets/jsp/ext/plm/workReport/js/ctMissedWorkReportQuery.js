/**
 * 管理员漏填工时查询
 * 描述：查询哪些工作日报未填写，可发邮件通知
 */
Ext.define('PLM.view.missedWorkReportQuery', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.missedWorkReportQuery',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'missedWorkReportQuery',
    initComponent: function () {
        var me = this;


        Ext.define('deptModel', {
            extend: 'Ext.data.Model',
            fields: [
                'deptName'
            ],
        });

        // 部门下拉
        var deptStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'deptModel',
            id: 'deptStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getMissedCombo?type=dept',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });


        Ext.define('postModel', {
            extend: 'Ext.data.Model',
            fields: [
                'postName'
            ],
        });

        // 岗位下拉
        var postStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'postModel',
            id: 'postStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getMissedCombo?type=post',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        Ext.define('userModel', {
            extend: 'Ext.data.Model',
            fields: [
                'no','userFullName'
            ],
        });

        // 成员下拉
        var userStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'userModel',
            id: 'userStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllUser',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });


        Ext.define('missedWorkReportQueryGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'userName', 'userDepartment', 'workNumber', 'missedReport', 'postName'
            ,'shouldBeReported','reported','underreporting'
            ],
            idProperty: 'id'
        });

        var missedWorkReportQueryStore = Ext.create('PLM.store.MockItemStore', {
            id: 'missedWorkReportQueryStore',
            model: 'missedWorkReportQueryGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getMissedReport',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var missedWorkReportQueryGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('missedWorkReportQueryStore'),
            id: 'missedWorkReportQueryGrid',
            //margin: '0 5 5 5',
            //forceFit: true,
            autoWidth: true,
            //border:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '98%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer', text: '序号', width: 60, align: 'center'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '姓名', dataIndex: 'userName', width: 150, menuDisabled: true},
                // {text: '账号', dataIndex: 'workNumber', width: 120, menuDisabled: true},
                {
                    text: '部门', dataIndex: 'userDepartment', width: 120, menuDisabled: true,

                },
                {
                    text: '职位', dataIndex: 'postName', width: 120, menuDisabled: true,
                },
                {text: '应报天数', dataIndex: 'shouldBeReported', width: 150, menuDisabled: true},
                {text: '已报天数', dataIndex: 'reported', width: 150, menuDisabled: true},
                {text: '漏报天数', dataIndex: 'underreporting', width: 150, menuDisabled: true},
                {
                    text: '漏填日期', flex: 1, dataIndex: 'missedReport', width: 400, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                }
            ]
        });


        var missedWorkReportQueryForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            title: '管理员漏填工时查询',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [//第*行
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '10 5 0 20', labelWidth: 100, border: false, padding: 5},
                    items: [
                        {
                            xtype: 'combobox',
                            fieldLabel: '用户名称',
                            id: 'userName',
                            name: 'userName',
                            store: userStore,
                            labelWidth: 70,
                            typeAhead: true,
                            triggerAction: 'all',
                            queryMode: 'local',
                            displayField: 'userFullName',
                            valueField: 'no',
                            forceSelection: true,
                            allowBlank: true,
                            width: 180,
                            anyMatch: true
                        }, {
                            xtype: 'combobox',
                            fieldLabel: '部门名称',
                            id: 'deptName',
                            name: 'deptName',
                            store: deptStore,
                            labelWidth: 70,
                            displayField: 'name',
                            valueField: 'name',
                            width: 180,
                            multiSelect: true,
                            anyMatch: true,
                            editable: false,
                        }, {
                            xtype: 'combobox',
                            fieldLabel: '岗位名称',
                            id: 'postName',
                            name: 'postName',
                            store: postStore,
                            labelWidth: 70,
                            width: 180,
                            displayField: 'postName',
                            valueField: 'postName',
                            multiSelect: true,
                            anyMatch: true,
                            editable: false,
                        }, {
                            xtype: 'datefield',
                            fieldLabel: '开始日期',
                            id: 'dateStart',
                            format: 'Y-m-d',
                            name: 'dateStart',
                            value: Ext.util.Format.date(Ext.Date.add(Ext.Date.getFirstDateOfMonth(new Date()), Ext.Date.MONTH, 0), "Y-m-d"),
                            maxValue: new Date(),
                            labelWidth: 70,
                            width: 200
                        }, {
                            xtype: 'datefield',
                            fieldLabel: '结束日期',
                            id: 'dateEnd',
                            format: 'Y-m-d',
                            name: 'dateEnd',
                            value: new Date(),
                            maxValue: new Date(),
                            labelWidth: 70,
                            width: 200
                        }
                    ]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '10 5 0 20', labelWidth: 100, border: false, padding: 5},
                    items: [
                        {
                            iconCls: 'icon icon-search',
                            xtype: 'button',
                            id: "query",
                            text: '查询',
                            handler: function () {
                                getMissedReport();
                            }
                        }, {
                            iconCls: 'icon icon-store-export',
                            xtype: 'button',
                            id: "exportResult",
                            text: '导出',
                            handler: function () {
                                exportReport();
                            }
                        }

                        , {
                            iconCls: 'icon icon-store-export',
                            xtype: 'button',
                            id: "exportResultSelect",
                            text: '导出选择的数据',
                            handler : function() {
                                let selectionArr = missedWorkReportQueryGrid.getSelectionModel().getSelection();
                                if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                    Ext.Msg.alert("提示", "请选择要导出的数据");
                                    return;
                                }
                                var dateStart = Ext.getCmp("dateStart").getValue();
                                var dateEnd = Ext.getCmp("dateEnd").getValue();
                                if (dateStart == null && dateEnd == null) {
                                    alert("请选择日期");
                                    return false;
                                }
                                if (dateEnd == null) {
                                    dateEnd = new Date();
                                }
                                if (dateStart == null) {
                                    dateStart = new Date().getDay() - 60;
                                }
                                //数据组装
                                let lists = new Array();
                                Ext.each(selectionArr, function (record) {
                                    let list = new Array();
                                    list.push(record.data['workNumber']);
                                    list.push(record.data['userDepartment']);
                                    list.push(record.data['postName']);
                                    list.push(dateStart);
                                    list.push(dateEnd);
                                    lists.push(list)
                                });
                                lists = Array.from(new Map(lists.map(item => [JSON.stringify(item), item])).values());
                                exportReport(lists,"select");
                            },
                            scope : this
                        }

                        , {
                            iconCls: 'icon icon-store-export',
                            xtype: 'button',
                            id: "sendMailBtn",
                            text: '一键通知',
                            handler: function () {
                                debugger

                                Ext.Msg.confirm('提示', '确定要发送信息提醒吗？',
                                    function (btn) {
                                        if (btn == 'yes') {
                                            reportMissedInform(missedWorkReportQueryGrid);
                                        }
                                    })
                            }
                        }, {html: "查询结果为根据管理员配置的工作日历未报工或报工未完成审批的日报"}
                    ]
                }

                , missedWorkReportQueryGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [missedWorkReportQueryForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('deptStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('postStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('userStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    },

});

function exportReport(lists,select) {
    var data = {};
    if("select" === select){
        data = {
            lists: lists,
            select:select
        };
    }else {
        data = getSearchData();
    }
    // var data = getSearchData();
    if (!data) {
        return;
    }
    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportMissedReport', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp = new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "项目漏填工时" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(data)
    );
}

function getMissedReport() {
    var tmpGrid = Ext.getCmp('missedWorkReportQueryGrid');

    var myMask = new Ext.LoadMask({msg: "数据正在处理中，请稍后...", target: tmpGrid});
    myMask.show();
    var data = getSearchData();
    if (!data) {
        return;
    }
    Ext.getStore('missedWorkReportQueryStore').load({
        params: {
            data: Ext.encode(data)
        },
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    alert('查询超时！请重试！')
                }
            } else {
                myMask.hide();
            }
        },
    })
}

function reportMissedInform(missedWorkReportQueryGrid) {
    var data = getSearchData();

    if (!data) {
        return;
    }
    let selectionArr = missedWorkReportQueryGrid.getSelectionModel().getSelection();
    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
        Ext.Msg.alert("提示", "请选择要通知用户");
        return;
    }
    var loadMarsk = new Ext.LoadMask(missedWorkReportQueryGrid, {
        msg: '正在处理数据，请稍候......',
        removeMask: true // 完成后移除
    });
    loadMarsk.show();

    //数据组装
    let obj = new Array();
    Ext.each(selectionArr, function (record) {
        obj.push(record.data['workNumber'])
    });

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/inform',
        method: "POST",
        timeout: 99999999,
        params: {
            data: Ext.encode(data),
            workNumberList:Ext.encode(obj)
        },
        success: function (response, opts) {
            debugger
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                alert(obj['msg']);
                loadMarsk.hide();
            } else {

                if (typeof (obj['msg']) == 'string') {
                    alert(obj['msg']);
                } else {
                    alert('查询超时！请重试！')
                }
            }
        },
        failure: function (response, opts) {
            alert('错误：通知失败，请检查网络！');
        }
    });
}

function getSearchData() {
    var dateStart = Ext.getCmp("dateStart").getValue();
    var dateEnd = Ext.getCmp("dateEnd").getValue();
    if (dateStart == null && dateEnd == null) {
        alert("请选择日期");
        return false;
    }
    if (dateEnd == null) {
        dateEnd = new Date();
    }
    if (dateStart == null) {
        dateStart = new Date().getDay() - 60;
    }

    var data = {
        workNumber: Ext.getCmp("userName").getValue(),
        postName: Ext.getCmp("postName").getValue(),
        deptName: Ext.getCmp("deptName").getValue(),
        dateStart: dateStart,
        dateEnd: dateEnd,
    }

    return data;
}
