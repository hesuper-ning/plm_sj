/**
 * 部门工时统计
 * 描述：管理员查看管理部门下的用户工作日志
 */
Ext.define('PLM.view.departmentManagerQuery', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.departmentManagerQuery',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'departmentManagerQuery',
    initComponent: function () {
        var me = this;
        Ext.define('departmentManagerQueryGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'userName', 'userDepartment', 'workNumber', 'creatorDate', 'HourLink', 'productLine',
                'projectNumber', 'projectName', 'activityName','projectPhase','manHour','manJobContent','natureOfWork',
                'hourLink','planningProjectName','projectSource','lastUpdateTime'],
            idProperty: 'id'
        });
        var departmentManagerQueryStore = Ext.create('PLM.store.MockItemStore', {
            id: 'departmentManagerQueryStore',
            model: 'departmentManagerQueryGridModel',
            pruneModifiedRecords: true,
            timeout: 99200000,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getDepartmentReport',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectNumber', 'name'
            ],
            idProperty: 'projectNumber'
        });

        Ext.define('deptModel', {
            extend: 'Ext.data.Model',
            fields: [
                'name'
            ],
            idProperty: 'name'
        });

        // 部门下拉
        var deptStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'deptModel',
            id: 'deptStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllUserDepartment',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });

        // 项目下拉
        var projectStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getProjects',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });
        // 项目下拉
        var projectStore1 = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectStore1',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getProjects',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });
        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var departmentManagerQueryGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('departmentManagerQueryStore'),
            id: 'departmentManagerQueryGrid',
            //margin: '0 5 5 5',
            //forceFit: true,
            autoWidth: true,
            //border:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            // height: '98%',
            height:620,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer',width:60, align: 'center'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '日期', dataIndex: 'creatorDate', width: 120, menuDisabled: true},
                {text: '姓名', dataIndex: 'userName', width: 120, menuDisabled: true},
                // {text: '账号', dataIndex: 'workNumber', width: 120, menuDisabled: true},
                {text: '部门', dataIndex: 'userDepartment', width: 100, menuDisabled: true},
                {text: '工时文档链接', dataIndex: 'hourLink', width: 100, menuDisabled: true},
                {text: '产品线', dataIndex: 'productLine', width: 100, menuDisabled: true},
                {text: '项目编码', dataIndex: 'projectNumber', width: 100, menuDisabled: true},
                {text: '项目名称', dataIndex: 'projectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目来源', dataIndex: 'projectSource', width: 100, menuDisabled: true},
                {text: '规划项目名称', dataIndex: 'planningProjectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目阶段', dataIndex: 'projectPhase', width: 100, menuDisabled: true},
                {text: '项目活动', dataIndex: 'activityName', width: 100, menuDisabled: true},
                {text: '工作性质', dataIndex: 'natureOfWork', width: 410, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '工时', dataIndex: 'manHour', width: 60, menuDisabled: true},
                {text: '工作内容', dataIndex: 'manJobContent', width: 400, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '最后更新时间', dataIndex: 'lastUpdateTime', width: 100, menuDisabled: true},
            ],
        });


        var departmentManagerQueryForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            title:'部门员工工时统计',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{//第*行
                xtype: 'panel',
                layout: 'hbox',
                border:false,
                defaults: {margin: '5 20 0 0', labelWidth: 100,border:false,padding:5},
                items: [{
                    xtype: 'combobox',
                    fieldLabel: '部门名称',
                    // margin: '0 0 0 20',
                    id: 'departmentName',
                    name: 'departmentName',
                    labelWidth: 70,
                    store:deptStore,
                    multiSelect: true,
                    anyMatch: true,
                    editable: false,
                    displayField: 'name',
                    valueField: 'name',
                },
//                {
//                    xtype: 'combobox',
//                    fieldLabel: '用户名称',
//                    id: 'userName',
//                    name: 'userName',
//                    store: allUserStore_projectPlan,
//                    labelWidth: 70,
//                    typeAhead: true,
//                    triggerAction: 'all',
//                    queryMode: 'local',
//                    displayField: 'userFullName',
//                    valueField: 'no',
//                    forceSelection: true,
//                    allowBlank: true,
//                    anyMatch: true
//                },
                {
                  xtype: 'textfield',
                  fieldLabel: '用户名称',
                  id: 'userName',
                  name: 'userName',
                  labelWidth: 70,
                  typeAhead: true,
                  triggerAction: 'all',
                  queryMode: 'local',
                  valueField: 'no',
                  forceSelection: true,
                  allowBlank: true,
                  anyMatch: true
              },{
                    xtype: 'combobox',
                    fieldLabel: '项目名称',
                    // margin: '0 0 0 20',
                    id: 'projectName',
                    name: 'projectName',
                    store: projectStore,
                    labelWidth: 70,
                    typeAhead: true,
                    triggerAction: 'all',
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'name',
                    forceSelection: true,
                    allowBlank: true,
                    anyMatch: true
                },,{
                    xtype: 'combobox',
                    fieldLabel: '项目编码',
                    // margin: '0 0 0 20',
                    id: 'projectNumber',
                    name: 'projectNumber',
                    store: projectStore1,
                    labelWidth: 70,
                    typeAhead: true,
                    triggerAction: 'all',
                    queryMode: 'local',
                    displayField: 'projectNumber',
                    valueField: 'projectNumber',
                    forceSelection: true,
                    allowBlank: true,
                    anyMatch: true
                }/*,{
                    xtype: 'combobox',
                    fieldLabel: '项目名称',
                    labelWidth: 70,
                    margin: '0 0 0 20',
                    store: projectStore,
                    typeAhead: true,
                    triggerAction: 'all',
                    queryMode: 'local',
                    forceSelection: true,
                    allowBlank: true,
                    anyMatch: true,
                    displayField: 'name',
                    valueField: 'name',
                    id: 'projectName'
                }*/]
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                border:false,
                defaults: {margin: '10 5 0 20', labelWidth: 100,border:false,padding:5},
                items: [{
                    xtype: 'datefield',
                    fieldLabel: '开始日期',
                    id: 'dateStart',
                    format: 'Y-m-d',
                    name: 'dateStart',
                    value: Ext.util.Format.date(Ext.Date.add(Ext.Date.getFirstDateOfMonth(new Date()), Ext.Date.MONTH, 0), "Y-m-d"),
                    labelWidth: 70,
                    width: 220
                },{
                    xtype: 'datefield',
                    fieldLabel: '结束日期',
                    id: 'dateEnd',
                    format: 'Y-m-d',
                    name: 'dateEnd',
                    value: new Date(),
                    labelWidth: 70,
                    width: 220
                }, {
                    iconCls: 'icon icon-search',
                    xtype: 'button',
                    id: "queryUserWorkHoursCount",
                    text: '查询',
                    handler:function () {
                        getReport();
                    }
                }, {
                    iconCls: 'icon icon-store-export',
                    xtype: 'button',
                    id: "exportWorkHoursCountDetails",
                    text: '导出',
                    handler : function () {
                        exportReport();
                    }
                }
                    , {
                        iconCls: 'icon icon-store-export',
                        xtype: 'button',
                        id: "exportWorkHoursCountDetailsSelect",
                        text: '导出选择的数据',
                        handler : function() {
                            let selectionArr = departmentManagerQueryGrid.getSelectionModel().getSelection();
                            if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                Ext.Msg.alert("提示", "请选择要导出的数据");
                                return;
                            }
                            //数据组装
                            let workReportId = new Array();
                            Ext.each(selectionArr, function (record) {
                                workReportId.push(record.data['masterId'])
                            });
                            let workReportItemId = new Array();
                            Ext.each(selectionArr, function (record) {
                                workReportItemId.push(record.data['id'])
                            });
                            // 使用 Set 去除重复的数据
                            workReportId = Array.from(new Set(workReportId));
                            exportReport(workReportId,workReportItemId,"select");
                        },
                        scope : this
                    }
                ,  {
                    xtype: 'label',
                    id: "userWorkHoursCountLable",
                    text: '工时统计：0',
                }]
            },departmentManagerQueryGrid]
        };



/////////////////////////Main Panel items//////////////////////////////////
        this.items = [departmentManagerQueryForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('projectStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            //alert('查询超时！请重试！')
                        }
                    }else {
                        var data = [{ name: '部门工作'}];
                        var sta = Ext.getStore('projectStore')
                        sta.add(0,data)
                        sta.add(data);
                    }
                }
            });
            Ext.getStore('projectStore1').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            //alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('deptStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if(typeof(operation.error)=='string'){
                            alert(operation.error);
                        }else {
                            //alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    },

});

function exportReport(workReportId,workReportItemId,select) {
    var data = {};
    if("select" === select){
        data = {
            workReportId: workReportId,
            workReportItemId: workReportItemId,
            select:select
        };
    }else {
        data = getSearchData();
    }
    // var data = getSearchData();

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportReport', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "部门员工工时"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(data)+"&type=departmentManager&exportType=dept"
    );

}

function getSearchData() {

    var data = {
    	userName: Ext.getCmp("userName").getValue(),
        projectName:Ext.getCmp("projectName").getValue(),
        projectNumber:Ext.getCmp("projectNumber").getValue(),
        departmentName:Ext.getCmp("departmentName").getValue(),
        dateStart:Ext.getCmp("dateStart").getValue(),
        dateEnd:Ext.getCmp("dateEnd").getValue(),
        type:'部门工时'
    };
    return data;
}


function getReport() {
    var data = getSearchData();
    /*if(data.departmentName==null || data.departmentName == ''){
        alert("请选择部门");
        return;
    }*/
    Ext.getStore('departmentManagerQueryStore').proxy.timeout = 99999; // 设置超时时间为10秒
    Ext.getStore('departmentManagerQueryStore').load({
        params: {
            data:Ext.encode(data)
        },
        callback: function (records, operation, success) {
            if (!success) {
                if(typeof(operation.error)=='string'){
                    alert(operation.error);
                }else {
                    alert('查询超时！请重试！')
                }
            }else {
                getSumHour();
            }
        },
    })
}

function getSumHour() {
    var data = getSearchData();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1//workReport/getSumHour',
        method: "POST",
        params: {
            data:Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                Ext.getCmp("userWorkHoursCountLable").setText("工时合计:"+obj['sumHour']+"小时");
            }
        },
        failure: function (response, opts) {
            alert('错误：请检查网络！');
        }
    });
}
