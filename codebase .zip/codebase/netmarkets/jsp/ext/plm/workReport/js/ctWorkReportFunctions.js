/**
 * 获取表单数据
 */
function getFormInfo() {
    Ext.getCmp("approver").setValue("");
    Ext.getCmp("carbonCopy").setValue("");
    Ext.getCmp("carbonCopyAutomatic").setValue("");
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getWorkReportByWorkNumber',
        params: {
            workNumber: userDisplayName,
            creatorDate: Ext.getCmp('workDate').getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                var mainPanel = Ext.getCmp('mainForm');
                if (obj['isNull'] == '0') {
                    mainPanel.getForm().setValues(obj);
                    getGridInfo();
                    getDepartmentWorkGridInfo();
                    getReportItemByProjectName();
                    if (obj['docState'] != '创建' && obj['docState'] != '返工') {
                        Ext.getCmp('addItem').hide();
                        // Ext.getCmp('saveItem').hide();
                        Ext.getCmp('delItem').hide();
                        Ext.getCmp('addDepartmentWork').hide();
                        Ext.getCmp('delDepartmentWork').hide();
                        Ext.getCmp('projectInquiry').hide();
                        Ext.getCmp('workReportUpload').hide();
                        // Ext.getCmp('manJobContent1').setDisabled(true);
                        // Ext.getCmp('manHour1').setDisabled(true);
                        Ext.getCmp('approver').setDisabled(true);
                        Ext.getCmp('carbonCopy').setDisabled(true);
                        Ext.getCmp('carbonCopyAutomatic').setDisabled(true);
                        Ext.getCmp('carbonCopyText').setDisabled(true);
                        if (obj['docState'] == '已发布') {
                            Ext.getCmp('revise').show();
                        }
                    } else {
                        Ext.getCmp('addItem').show();
                        // Ext.getCmp('saveItem').show();
                        Ext.getCmp('delItem').show();

                        Ext.getCmp('addDepartmentWork').show();
                        Ext.getCmp('delDepartmentWork').show();
                        Ext.getCmp('projectInquiry').show();
                        Ext.getCmp('workReportUpload').show();
                        // Ext.getCmp('manJobContent1').setDisabled(false);
                        // Ext.getCmp('manHour1').setDisabled(false);
                        Ext.getCmp('approver').setDisabled(false);
                        Ext.getCmp('carbonCopy').setDisabled(false);
                        Ext.getCmp('carbonCopyAutomatic').setDisabled(false);
                        Ext.getCmp('carbonCopyText').setDisabled(false);
                    }
                    // Ext.getCmp('manJobContent1').show();
                    // Ext.getCmp('manHour1').show();
                    Ext.getCmp('hourLink').show();
                    Ext.getCmp('docState').show();
                    Ext.getCmp('approver').show();
                    Ext.getCmp('carbonCopy').show();
                    Ext.getCmp('carbonCopyAutomatic').show();
                    Ext.getCmp('carbonCopyAutomaticInfo').show();
                    Ext.getCmp('explanationButton').show();
                    Ext.getCmp('carbonCopyText').show();
                    Ext.getCmp('carbonCopyInfo').show();

                    Ext.getCmp('commitBottom').show();
                    Ext.getCmp('commitTop').show();

                    if(obj['docState'] == "创建"){
                        Ext.getCmp('deleteBottom').show();
                        Ext.getCmp('deleteTop').show();
                        Ext.getCmp('recallBottom').hide();
                        Ext.getCmp('recallTop').hide();
                    }
                    if(obj['docState'] == "正在审阅"||obj['docState'] == "已发布"||obj['docState'] == "返工") {
                        if(!(obj['docState'] == "返工")){
                            Ext.getCmp('recallBottom').show();
                            Ext.getCmp('recallTop').show();
                        }
                        Ext.getCmp('deleteBottom').hide();
                        Ext.getCmp('deleteTop').hide();
                    }
                    if(obj['docState'] == "返工") {
                        Ext.getCmp('deleteBottom').show();
                        Ext.getCmp('deleteTop').show();
                    }

                    Ext.getCmp('panel2').show();
                } else {
                    Ext.getCmp('manJobContent1').hide();
                    Ext.getCmp('manHour1').hide();
                    Ext.getCmp('hourLink').hide();
                    Ext.getCmp('docState').hide();
                    Ext.getCmp('approver').hide();
                    Ext.getCmp('carbonCopy').hide();
                    Ext.getCmp('carbonCopyAutomatic').hide();
                    Ext.getCmp('carbonCopyAutomaticInfo').hide();
                    Ext.getCmp('explanationButton').hide();
                    Ext.getCmp('carbonCopyText').hide();
                    Ext.getCmp('carbonCopyInfo').hide();

                    Ext.getCmp('commitBottom').hide();
                    Ext.getCmp('commitTop').hide();
                    Ext.getCmp('deleteBottom').hide();
                    Ext.getCmp('deleteTop').hide();
                    Ext.getCmp('recallBottom').hide();
                    Ext.getCmp('recallTop').hide();


                    Ext.getCmp('panel2').hide();

                    Ext.getCmp('hourLink').setValue("");
                    Ext.getCmp('docState').setValue("");
                    Ext.getCmp("approver").setValue("");
                    Ext.getCmp("carbonCopy").setValue("");
                    Ext.getCmp("carbonCopyAutomatic").setValue("");
                    Ext.getCmp("carbonCopyText").setValue("");
                    Ext.getCmp('panel2').hide();
                }

                //alert(obj['error']);
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

var isCreate = true
/**
 * 判断是否当日创建日报
 */
function isCreateInfo() {
    Ext.Ajax.request({
        scope: this,
        async:false,
        url: '/Windchill/ptc1/workReport/getWorkReportByWorkNumber',
        params: {
            workNumber: userDisplayName,
            creatorDate: Ext.getCmp('workDate').getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                if (obj['isNull'] == '0') {
                    alert("当日已创建日报请检查！")
                    isCreate = false;
                    return isCreate
                }
            }
        }
    })
    return isCreate
}
/**
 * 点击tree获取表单数据
 */
function getFormInfoById(id) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getWorkReportById',
        params: {
            id: id
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                var mainPanel = Ext.getCmp('mainForm');
                mainPanel.getForm().setValues(obj);
                Ext.getCmp('workDate').setValue(obj['date']);
                getGridInfo();
                getReportItemByProjectName();
                Ext.getCmp('panel2').show();

            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

/**
 * 获取grid信息
 */
function getGridInfo() {
    Ext.getStore('WorkReportGridStore').load({
        params: {
            masterId: Ext.getCmp('id').getValue(),
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询grid信息失败，请联系管理员！');
            } else {
                getSumHour();
            }
        }
    })
}


/**
 * 获取项目阶段信息
 */
function getProjectPhase(number) {
    Ext.getStore('projectPhaseStore').load({
        params: {
            projectNumber: number,
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('获取项目阶段信息失败，请联系管理员！');
            }
        }
    })
}

/**
 * 获取项目阶段中活动
 */
function getActivity() {
    Ext.getCmp("activityName").setValue('');
    var number = Ext.getCmp("projectNumber").getValue();
    var projectPhase = Ext.getCmp("projectPhase").getValue();
    Ext.getStore('activityListStores').load({
        params: {
            projectNumber: number,
            phase: projectPhase
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！');
            }
        }
    })
}


/**
 * 创建日报文档
 */
function createDoc() {

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1//workReport/createDaily',
        method: "POST",
        params: {
            workNumber: userDisplayName,
            creatorDate: Ext.getCmp('workDate').getValue(),
        },
        timeout: 99999, // 设置超时时间为10秒 (10000毫秒)
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                alert("创建成功");
                getFormInfo();
                Ext.getCmp("userWorkHoursTreePanel").getStore().reload();
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：创建文档失败，请检查网络！');
        }
    });
}

/**
 * 根据id查询grid中的信息
 * @param id
 */
function getReportItemById(id) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getReportItemById',
        params: {
            id: id
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {

                Ext.getCmp('productLine').setValue(obj['productLine']),
                    Ext.getCmp('projectNumber').setValue(obj['projectNumber']),
                    Ext.getCmp('projectName').setValue(obj['projectName']),
                    Ext.getCmp('activityName').setValue(obj['activityName']),
                    Ext.getCmp('projectPhase').setValue(obj['projectPhase']),
                    Ext.getCmp('projectPhase').setValue(obj['projectPhase']),
                    Ext.getCmp('manHour').setValue(obj['manHour']),
                    Ext.getCmp('manJobContent').setValue(obj['manJobContent'])
                Ext.getCmp('updateId').setValue(obj['id']);
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}


//修改或新增数据
function save(data) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/saveWorkReportItem',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                getFormInfo();

            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：修改日报信息失败，请检查网络！');
        }
    });
}

var is = true

/**
 * 判断工时是否超最大填写工时
 */
function checkHour(manHour, itemId) {
    var masterId = Ext.getCmp('id').getValue();
    var is = true;
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/checkHour',
        method: "POST",
        async: false,
        params: {
            masterId: masterId,
            manHour: manHour,
            itemId: itemId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                is = true
            } else {
                alert(obj['msg']);
                is = false
            }
        },
        failure: function (response, opts) {
            alert('错误： 判断工时失败，请检查网络！');
        }
    });
    return is;
}

/**
 * 根据主表id及日报项目名称获取部门工作信息
 */
function getReportItemByProjectName() {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getReportItemByProjectName',
        params: {
            masterId: Ext.getCmp('id').getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                if (obj['isNull'] == '0') {
                    Ext.getCmp('manHour1').setValue(obj['manHour']);
                    Ext.getCmp('manJobContent1').setValue(obj['manJobContent']);
                    Ext.getCmp('itemId').setValue(obj['id']);
                } else {
                    Ext.getCmp('manHour1').setValue("");
                    Ext.getCmp('manJobContent1').setValue("");
                    Ext.getCmp('itemId').setValue(obj['id']);
                }
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

/**
 * 修改部门工作信息
 */
function saveDepartmentReport() {
    //alert(Ext.getCmp('itemId').getValue());
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/saveDepartmentReport',
        method: "POST",
        params: {
            id: Ext.getCmp('itemId').getValue(),
            carbonCopy: Ext.getCmp('carbonCopyText').getValue(),
            approver: Ext.getCmp('approver').getValue(),
            manHour: Ext.getCmp('manHour1').getValue(),
            manhourOvertime: Ext.getCmp('manhourOvertime1').getValue(),
            manJobContent: Ext.getCmp('manJobContent1').getValue(),
            masterId: Ext.getCmp('id').getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                getReportItemByProjectName();
                getSumHour();
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存项目度量信息失败，请检查网络！');
        }
    });
}

/**
 * 修改日报信息
 */
function saveReport() {
    //alert(Ext.getCmp('itemId').getValue());
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/saveReport',
        method: "POST",
        params: {
            carbonCopy: Ext.getCmp('carbonCopyText').getValue(),
            //approver: Ext.getCmp('approver').getValue(),
            masterId: Ext.getCmp('id').getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {

                console.log(obj['carbonCopy'])
                Ext.getCmp('carbonCopy').setValue(obj['carbonCopy'])
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存项目度量信息失败，请检查网络！');
        }
    });
}

/**
 * 删除
 * @param dataArray
 * @param callback
 */
function deleteData(dataArray, callback) {
    /*var myMask = new Ext.LoadMask(Ext.getBody(), {error: "数据正在处理中，请稍后..."});
    myMask.show();*/
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/delWorkReport',
        method: "POST",
        params: {
            data: Ext.encode(dataArray),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['error']);
                //myMask.hide();
            } else {
                //myMask.hide();
                // alert("数据删除成功");
                callback();
                getFormInfo();
                Ext.getCmp('message').getEl().update('<font style="font-weight:bold;font-style:italic;size: A3;color: darkgrey">应审下发成功...</font>');
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

/**
 *获取项目编号
 */
function getProjectNumber() {
    var projectNumber = Ext.getCmp("projectName").getValue();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/workReport/checkProjectNumber',
        params: {
            projectNumber: projectNumber
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (!obj['success']) {
                if (obj['msg'].toString().concat('null')){
                    alert('请选择正确的项目名称！');
                    Ext.getCmp("projectNumber").setValue('');
                    Ext.getCmp("projectPhase").setValue('');
                    Ext.getCmp("activityName").setValue('');
                    Ext.getCmp("productLine").setValue('');
                    Ext.getCmp("projectName").setValue('');
                }
                return;//中断
            }
            //将值填充
            if (obj['projectNumber'] && obj['projectNumber'].length > 0) {
                Ext.getCmp("projectNumber").setValue(obj['projectNumber']);
            } else if (projectName == '研发中心公共') {
                Ext.getCmp("projectNumber").setValue('999999');
            } else {
                alert('请选择正确的项目名称！');
            }
            Ext.getCmp("productLine").setValue(obj['productLine']);
            Ext.getCmp("projectPhase").setValue('');
            Ext.getCmp("activityName").setValue('');
        },
        failure: function (response, opts) {
            alert('错误：查询编码失败，请检查网络！');
        }
    });
}

function clear() {
    Ext.getCmp('updateId').setValue(""),
        Ext.getCmp('productLine').setValue(""),
        Ext.getCmp('projectNumber').setValue(""),
        Ext.getCmp('projectName').setValue(""),
        Ext.getCmp('activityName').setValue(""),
        Ext.getCmp('projectPhase').setValue(""),
        Ext.getCmp('manHour').setValue(""),
        Ext.getCmp('manJobContent').setValue("")
}

/**
 * 获取合计工时
 */
function getSumHour() {

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/manGetSumHour',
        method: "POST",
        params: {
            masterId: Ext.getCmp('id').getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                //Ext.getCmp("userWorkHoursCountLable").setText('<font color="aqua">工时合计:' + obj['sumHour'] + '小时</font>');
                var va = '<div style="font-weight:bold ;font-size:16px;text-align:left">正常工时+附加工时（h）:' + obj['sumHour'] + '小时</div>'
                document.getElementById('userWorkHoursCountLable').innerHTML = va;
            }
        },
        failure: function (response, opts) {
            alert('错误：请检查网络！');
        }
    });
}

/**
 * 提交
 */
function commit() {
    var carbonCopy = '[' + Ext.getCmp("carbonCopyText").getValue() + ']'
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/commit',
        method: "POST",
        params: {
            branchId: Ext.getCmp("docBranchId").getValue(),
            approver: Ext.getCmp("approver").getValue(),
            carbonCopy: carbonCopy,
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                var mainPanel = Ext.getCmp('mainForm');
                mainPanel.getForm().setValues(obj);
                getFormInfo();
                alert('提交成功！')
            } else {
                alert(obj['error']);
            };
            Ext.getCmp("userWorkHoursTreePanel").getStore().reload();
        },
        failure: function (response, opts) {
            alert('提交错误：请检查网络！');
        }
    });
}

/**
 * 修订
 */
function revise() {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1//workReport/revise',
        method: "POST",
        params: {
            branchId: Ext.getCmp("docBranchId").getValue(),
            id: Ext.getCmp("id").getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                alert('修订成功！');
                location.reload();
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('提交错误：请检查网络！');
        }
    });
}

//修改抄送人
function saveCarbonCopy() {
    /* var myMask = new Ext.LoadMask(Ext.getBody(), {error:"数据正在处理中，请稍后..."});
     myMask.show();*/
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/saveCarbonCopy',
        method: "POST",
        params: {
            masterId: Ext.getCmp('id').getValue(),
            approver: Ext.getCmp("approver").getValue(),
            carbonCopy: Ext.getCmp("carbonCopy").getValue()
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (!obj['success']) {
                alert(obj['error']);
                // myMask.hide();
            } else {
                // myMask.hide();
                //callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据修改失败，请检查网络！')
        }
    });
}

/**
 * 提交时判断
 */
function checkInfo(selectionArr) {
    var approver = Ext.getCmp("approver").getValue();
    var hourLink = Ext.getCmp("hourLink").getValue();
    var docState = Ext.getCmp("docState").getValue();
    var carbonCopy = Ext.getCmp("carbonCopy").getValue();
    var manHour1 = Ext.getCmp("manHour1").getValue();
    var manJobContent1 = Ext.getCmp("manJobContent1").getValue();
    var sf = document.getElementById('userWorkHoursCountLable').innerHTML;
    var index = sf.indexOf("小");
    var cmp = sf.substring(70,index);
    debugger
    //"<div style="font-weight:bold ;font-size:16px;text-align:left">工时合计（h）:1.0小时</div>"
    if (hourLink == '' || hourLink == undefined) {
        alert("请先创建文档")
        return ;
    }
    /*if (approver == '' || approver == undefined) {
        alert("请选择审批人")
        return false;
    }*/
    // if (carbonCopy == '' || carbonCopy == undefined) {
    //     alert("请选择抄送人")
    //     return ;
    // }
    if (docState != '创建' && docState != '返工') {
        alert("只有创建或返工状态可提交")
        return ;
    }
    debugger
    //let selectionArr = WorkReportGrid.getSelectionModel().getSelection();
    // if ((selectionArr == undefined || selectionArr == null || selectionArr == 0) && ((manHour1 == undefined || manHour1 == '' || manHour1 == 0) && (manJobContent1 == '' || manJobContent1 == undefined))) {
    //     alert("请填写日报信息！！！");
    //     return ;
    // }
    // if (((manHour1 == undefined || manHour1 == '' || manHour1 == 0) && (manJobContent1 == '' || manJobContent1 == undefined))){
    //     if ((selectionArr == undefined || selectionArr == null || selectionArr == 0)) {
    //         alert("请填写项目工作信息！！！");
    //         return ;
    //     }
    // }
   if((selectionArr == undefined || selectionArr == null || selectionArr == 0)) {
        // if ((manHour1 == '' || manHour1 == 0 || manHour1 ==undefined) && (manJobContent1 != '' && manJobContent1 != undefined)){
        //     alert("请填写部门工作工时！")
        //     return ;
        // }
        // if ((manJobContent1 == '' || manJobContent1 ==undefined) && (manHour1 != '' && manHour1 !=undefined)){
        //     alert("请填写部门工作内容！")
        //     return ;
        // }
    }else{
       // if ((manHour1 == '' || manHour1 == 0 || manHour1 ==undefined) && (manJobContent1 != '' && manJobContent1 !=undefined)){
       //     alert("请填写部门工作工时！")
       //     return ;
       // }
       // if ((manJobContent1 == '' || manJobContent1 ==undefined) && (manHour1 != '' && manHour1 !=undefined)){
       //     alert("请填写部门工作内容！")
       //     return ;
       // }
   }

    checkSubmit(cmp);

    // if(!(checkSubmitResult == "true")){
    //     alert(checkSubmitResult);
    //     return;
    // }



    // if (cmp > 12) {
    //     Ext.Msg.confirm('提示', '你报工时间超过12小时正常上限，确定继续提交？',
    //         function (btn) {
    //             if (btn == 'yes') {
    //                 commit();
    //             } else {
    //                 return;
    //             }
    //         }, this);
    //
    // }
    // else if (cmp < 8) {
    //     Ext.Msg.confirm('提示', '你报工时间不足8小时正常下限，确定继续提交？',
    //         function (btn) {
    //             if (btn == 'yes') {
    //                 commit();
    //             } else {
    //                 return;
    //             }
    //         }, this);
    // }else {
    //     commit();
    // }
}

/**
 * 获取部门工作grid信息
 */
function getDepartmentWorkGridInfo() {
    Ext.getStore('departmentWorkGridStore').load({
        params: {
            masterId: Ext.getCmp('id').getValue(),
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询grid信息失败，请联系管理员！');
            } else {
                getSumHour();
            }
        }
    })
}

/**
 * 插入数据
 * @param dbTableName
 * @param branchId
 * @param callbackFn
 */
function insertData(masterId, formType, callbackFn){
    var insertRecord = {
        masterId:masterId,
        formType:formType
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/workReport/insertWorkReportInfo',
        params: {data:Ext.encode(insertRecord)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.success==true) {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.msg);
            }
        },
        failure: function (response, opts) {
            alert('错误：新增信息失败，请检查网络！!');
        }
    });
}

/**
 * 保存数据
 * @param dbTableName
 * @param branchId
 * @param callbackFn
 */
function saveData(id, dataKey,dataValue, callbackFn){
    var insertRecord = {
        id:id,
        key:dataKey,
        value:dataValue
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/workReport/updateWorkReportInfo',
        params: {data:Ext.encode(insertRecord)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.success==true) {
                if("projectName" == dataKey){
                    getFormInfo();
                }
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.msg);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 删除文档对象
 * @param dbTableName
 * @param branchId
 * @param callbackFn
 */
function deleteDocOrProcess(deleteType){
    let id = Ext.getCmp('id').getValue();
    let confirmInfo = "";
    let alertInfo = "";
    if("doc" == deleteType){
        confirmInfo = '确认删除文档？';
        alertInfo = '删除成功！';
    }else if("process" == deleteType){
        confirmInfo = '确认撤回文档流程？';
        alertInfo = '撤回文档流程成功！';
    }
    Ext.Msg.confirm('提示', confirmInfo,
        function (btn) {
            if (btn == 'yes') {
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/workReport/deleteDocOrProcess',
                    params: {
                        masterId:id,
                        deleteType:deleteType
                    },
                    success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.success==true) {
                            alert(alertInfo);
                            getFormInfo();
                            if("process" == deleteType){
                                Ext.getCmp('recallBottom').hide();
                                Ext.getCmp('recallTop').hide();
                            }
                            Ext.getCmp("userWorkHoursTreePanel").getStore().reload();
                            // if("doc" == deleteType){
                            //     Ext.getCmp('deleteBottom').hide();
                            //     Ext.getCmp('deleteTop').hide();
                            // }
                        } else {
                            alert(obj.msg);
                        }
                    },
                    failure: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        alert(obj.msg);
                        // alert('错误：保存信息失败，请检查网络！!');
                    }
                });
            } else {
                return;
            }
        }, this);
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion


/**
 * 校验提交
 */
function checkSubmit(cmp) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/checkSubmit',
        method: "POST",
        params: {
            masterId: Ext.getCmp("id").getValue()
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                if (cmp > 12) {
                    Ext.Msg.confirm('提示', '你报工时间超过12小时正常上限，确定继续提交？',
                        function (btn) {
                            if (btn == 'yes') {
                                commit();
                            } else {
                                return;
                            }
                        }, this);

                }
                else if (cmp < 8) {
                    Ext.Msg.confirm('提示', '你报工时间不足8小时正常下限，确定继续提交？',
                        function (btn) {
                            if (btn == 'yes') {
                                commit();
                            } else {
                                return;
                            }
                        }, this);
                }else {
                    commit();
                }
            } else {
                alert(obj['msg'])
            };
        },
        failure: function (response, opts) {
            alert('提交错误：请检查网络！');
        }
    });
}



/**
 * 保存数据
 * @param dbTableName
 * @param branchId
 * @param callbackFn
 */
function isMember(projectNumber, projectName, masterId, callbackFn){
    var insertRecord = {
        projectNumber:projectNumber,
        projectName:projectName,
        masterId:masterId
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/workReport/isMember',
        params: {data:Ext.encode(insertRecord)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.success==true) {
                // if("projectName" == dataKey){
                //     getFormInfo();
                // }
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.msg);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}



