 Ext.define('PLM.view.WorkReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.WorkReport',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,

    id: 'WorkReport',
    initComponent: function () {
        var me = this;
        Ext.define('projectInquiryModel', {
            extend: 'Ext.data.Model',
            fields: [
                'productModel','projectNumber','projectName','productLibraryName','projectStatus','inTheProjectTeam'
            ],
            idProperty: 'projectNumber'
        });

        var projectInquiryStore = Ext.create('Ext.data.Store', {
            id: 'projectInquiryStore',
            model: 'projectInquiryModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/projectInquiry',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            root: {
                expanded: true
            },
            autoLoad: false,
            folderSort: true
        });


        var projectInquiryCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var projectInquiryGrid = Ext.create('Ext.grid.Panel', {
            plugins: [projectInquiryCellEditing],
            store: projectInquiryStore,
            autoWidth: true,
            height: 500,
            id: 'usageInquiryGrid',
            autoScroll: true,
            selModel: {
                mode: 'SINGLE' //可以多选
            },
            enableTextSelection:true,
            selType: 'checkboxmodel',
            columns: [
                {text: '产品型号', width: 130, dataIndex: 'productModel', menuDisabled: true, sortable: false,renderer:showTip},
                {text: '项目编码', width: 120, dataIndex: 'projectNumber', menuDisabled: true, sortable: false,renderer:showTip},
                {text: '项目名称', width: 100, dataIndex: 'projectName', menuDisabled: true, sortable: false,renderer:showTip},
                {text: '产品库名称', width: 200, dataIndex: 'productLibraryName', menuDisabled: true, sortable: false,renderer:showTip},
                {text: '项目状态', width: 100, dataIndex: 'projectStatus', menuDisabled: true, sortable: false,renderer:showTip},
                {text: '是否在项目团队中', width: 130, dataIndex: 'inTheProjectTeam', menuDisabled: true, sortable: false,renderer:showTip}
            ],
            dockedItems: [{
                xtype: 'container',
                dock: 'bottom',
                layout: {
                    type: 'hbox',
                    pack: 'end' // 右对齐
                },
                items: [{
                    xtype: 'button',
                    text: '确定',
                    margin: '10 10 10 0', // 右侧留出 10px 的间距
                    handler: function() {
                        var recordList = projectInquiryGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var partNumber = recordList[0].data.projectNumber;
                            var projectName = recordList[0].data.projectName;
                            var inTheProjectTeam = recordList[0].data.inTheProjectTeam;
                            if("否" == inTheProjectTeam){
                                alert("你不在项目：“"+projectName+"”团队中，请联系相关人员添加进项目团队！");
                                return;
                            }

                            var callbackFn = function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.success==true) {
                                    getGridInfo();
                                }else {
                                    alert(obj.msg)
                                }
                            };
                            // saveData(id, field, value, callbackFn);
                            saveData(projectWorkItemsId, "projectName", partNumber, callbackFn);

                            Ext.getCmp('projectInquiryWindow').close();
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }, {
                    xtype: 'button',
                    text: '取消',
                    margin: '10 10 10 0', // 右侧留出 10px 的间距
                    handler: function() {
                        Ext.getCmp('projectInquiryWindow').close();
                    }
                }]
            }]
        });
        var projectInquiryWindow = Ext.create('Ext.Window', {
            id:'projectInquiryWindow',
            title: '项目高级查询',
            width: 820,
            height: 600,
            autoHeight : true,
            closeAction: 'hide',
            closable:false,
            constrain: true,
            modal:true,
            items:[
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    defaults: {
                        margin: '20 20 20 20'
                    },
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: '产品型号',
                            width: 180,
                            labelWidth: 60,
                            id: 'productType',
                            name: 'productType',
                            // value: partNumber
                        },
                        {
                            xtype: 'button',
                            text: '搜索',
                            width: 70,
                            labelWidth: 60,
                            handler: function() {
                                var productType = Ext.getCmp('productType').getValue();
                                projectInquiryStore.reload({
                                    params: {
                                        productType: productType
                                    }
                                });
                            }
                        },
                    ]
                },
                projectInquiryGrid
            ],
        });

        Ext.define('workReportGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'masterId', 'workNumber', 'productLine', 'projectNumber', 'projectName', 'principals', 'activityName',
                'projectPhase', 'manHour', 'manJobContent'],
            idProperty: 'id'
        });

        var WorkReportGridStore = Ext.create('Ext.data.Store', {
            id: 'WorkReportGridStore',
            model: 'workReportGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getItemsByMasterId',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectNumber', 'name'
            ],
            idProperty: 'projectNumber'
        });


        // // 项目下拉
        // var projectListStore = Ext.create('Ext.data.Store', {
        //     //pageSize: 50,
        //     model: 'ProjectModel',
        //     id: 'projectListStore',
        //     pruneModifiedRecords: true,
        //     autoSync: true,//同步更新
        //     proxy: {
        //         type: 'ajax',
        //         url: '/Windchill/ptc1/workReport/getOwnerProjectList',
        //         reader: {
        //             type: 'json',
        //             rootProperty: 'items'
        //         }
        //     },
        //     autoLoad: false
        // });

        // 项目下拉
        var projectListStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectListStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getOwnerPNAndPLList?type=PN',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: true
        });

        // 产品线下拉
        var projectLineListStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectLineListStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getOwnerPNAndPLList?type=PL',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });

        Ext.define('ProjectPhaseModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectPhase',"projectPhaseVal"
            ],
            idProperty: 'projectPhase'
        });


        // 项目阶段下拉
        var projectPhaseStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectPhaseModel',
            id: 'projectPhaseStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getProjectPhase',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });


        // 项目外项  活动名称
        Ext.define('PlanActivityModel', {
            extend: 'Ext.data.Model',
            fields: [
                'activityName'
            ],
            idProperty: 'activityName'
        });

        var activityListStores = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'PlanActivityModel',
            id: 'activityListStores',
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getWorkReportActivitys',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    messageProperty: 'error'
                }
            },
            autoLoad: false
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });
        var allUserCombo_projectPlan = Ext.create('PLM.common.CtAllUserCombo', {
            store: allUserStore_projectPlan
        });

        //问题添加表单
        var addForm = new Ext.form.Panel({
            xtype: 'form',
            margin: '10 0 0 0',
            id: 'addForm',
            name: 'addForm',
            border: false,
            items: [{
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    xtype: 'combobox',
                    fieldLabel: '<font color=red>*</font>项目名称',
                    margin: '0 20 0 0',
                    queryMode: 'local',
                    enableRegEx:true,
                    displayField: 'name',
                    valueField: 'projectNumber',
                    store: projectListStore,
                    width: 300,
                    id: 'projectName',
                    name: 'projectName',
                    labelWidth: 100,
                    listeners: {
                        /*beforequery: function (e) {
                            var combo = e.combo;

                            if (!e.forceAll) {
                                var value = e.query;
                                combo.store.filterBy(function (record, id) {
                                    var text = record.get(combo.displayField);
                                    return (text.indexOf(value) != -1);
                                });
                                combo.expand();
                                return false;
                            }
                        },*/
                        'select': function () {
                            getProjectNumber();
                        },

                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '<font color=red>*</font>项目编码',
                    margin: '0 20 0 0',
                    width: 300,
                    id: 'projectNumber',
                    name: 'projectNumber',
                    labelWidth: 100,
                    listeners: {
                        'change': function () {
                            var number = Ext.getCmp('projectNumber').getValue();
                            if (number != '') {
                                getProjectPhase(number);
                            }
                        }
                    }

                }, {
                    xtype: 'textfield',
                    fieldLabel: '',
                    hidden: true,
                    margin: '0 20 0 0',
                    width: 300,
                    id: 'updateId',
                    name: 'updateId',
                    labelWidth: 100
                }
                ]
            }, {
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    fieldLabel: '<font color=red>*</font>产品线',
                    xtype: 'displayfield',
                    margin: '0 20 0 0',
                    valueField: '999',
                    width: 300,
                    id: 'productLine',
                    name: 'productLine',
                    labelWidth: 100
                }, {
                    xtype: 'combo',
                    fieldLabel: '<font color=red>*</font>项目阶段(之前)',
                    margin: '0 20 0 0',
                    multiSelect: false,
                    anyMatch: true,
                    editable: false,
                    displayField: 'projectPhase',
                    valueField: 'projectPhaseVal',
                    store: projectPhaseStore,
                    width: 300,
                    id: 'projectPhase',
                    name: 'projectPhase',
                    labelWidth: 100,
                    listeners: {
                        'select': function () {
                            getActivity();
                        }
                    }
                }
                ]
            }, {
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    xtype: 'combo',
                    fieldLabel: '<font color=red>*</font>活动名称',
                    margin: '0 20 0 0',
                    queryMode: 'local',
                    displayField: 'activityName',
                    valueField: 'activityName',
                    store: activityListStores,
                    width: 300,
                    id: 'activityName',
                    name: 'activityName',
                    labelWidth: 100
                }, {
                    xtype: 'numberfield',
                    fieldLabel: '<font color=red>*</font>工时(h)',
                    margin: '0 20 0 0',
                    width: 300,
                    id: 'manHour',
                    name: 'manHour',
                    minValue: '0',
                    maxValue: '16',
                    decimalPrecision: 1,
                    labelWidth: 100,
                    listeners: {
                        blur: function (e) {
                            var manHour = Ext.getCmp("manHour").getValue();
                            var itemId = Ext.getCmp('updateId').getValue();
                            debugger

                            if (manHour < 0.1 || manHour > 24) {
                                alert("请输入0.1-24之间数字")
                                Ext.getCmp("manHour").setValue("");
                            }
                            var is = checkHour(manHour, itemId);
                            if (!is) {
                                Ext.getCmp("manHour").setValue("");
                            }
                        }
                    }
                }]
            }, {
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    xtype: 'textarea',
                    fieldLabel: '<font color=red>*</font>工作内容及遇到的问题或风险',
                    name: 'manJobContent',
                    id: 'manJobContent',
                    maxLength: 1500,
                    maxLengthText: "工作内容必须在1500字及以内!",
                    width: 620,
                    height: 150
                }]
            }, {
                layout: 'hbox',
                border: false,
                margin: '5 5 10 30',
                items: [{
                    margin: '0 10 0 0',
                    xtype: 'button',
                    id: 'save',
                    text: '保存',
                    handler: function () {

                        var data = {
                            id: Ext.getCmp('updateId').getValue(),
                            masterId: Ext.getCmp('id').getValue(),
                            productLine: Ext.getCmp('productLine').getValue(),
                            projectNumber: Ext.getCmp('projectNumber').getValue(),
                            projectName: Ext.getCmp('projectName').getRawValue(),
                            activityName: Ext.getCmp('activityName').getValue(),
                            projectPhase: Ext.getCmp('projectPhase').getValue(),
                            manHour: Ext.getCmp('manHour').getValue(),
                            manJobContent: Ext.getCmp('manJobContent').getValue(),
                        }


                        if (data.productLine == "" || data.projectNumber == "" || data.projectName == null || data.activityName == null
                            || data.projectPhase == null || data.manHour == null || data.manJobContent == "") {
                            alert("弹窗中*号标识为必填项，不允许为空");
                            return;
                        }


                        if (data.manJobContent.toString().length > 1500) {
                            return;
                        }

                        save(data);
                        clear();
                        Ext.getCmp('requireWin2').close();
                    }
                }, {
                    xtype: 'button',
                    id: 'close',
                    text: '取消',
                    handler: function () {
                        clear();
                        Ext.getCmp('requireWin2').close();
                    }
                }]
            }]
        });


        var requireWin2 = Ext.create('Ext.Window', {
            id: 'requireWin2',
            title: '工时信息',
            width: 700,
            //height: 300,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [addForm],
        });

        var WorkReportGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('WorkReportGridStore'),
            id: 'WorkReportGrid',
            //hidden:true,
            margin: '10 10 0 10',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            height: '98%',
            maxHeight: '200',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: { enableTextSelection:true},
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer', width: 40},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '产品线', dataIndex: 'productLine', width: 150, menuDisabled: true,renderer:showTip,
                    editor: allowEdit?{
                        xtype: 'combobox',
                        editable: false,
                        forceSelection: false,
                        displayField: 'name',
                        valueField: 'name',
                        store: projectLineListStore
                    }:false
                },
                {text: '项目名称', dataIndex: 'projectName', width: 150, menuDisabled: true,renderer:showTip,
                    editor: allowEdit?{
                        xtype: 'combobox',
                        editable: true,
                        forceSelection: true,
                        enableRegEx:true,
                        queryMode: 'local',
                        displayField: 'name',
                        valueField: 'projectNumber',
                        store: projectListStore
                    }:false
                },
                {text: '项目编码', dataIndex: 'projectNumber', width: 120, menuDisabled: true,renderer:showTip},
                {text: '项目阶段（前）', dataIndex: 'projectPhase', width: 150, menuDisabled: true,renderer:showTip,
                    editor: allowEdit?{
                        xtype: 'combobox',
                        editable: false,
                        forceSelection: false,
                        displayField: 'projectPhase',
                        valueField: 'projectPhaseVal',
                        store: projectPhaseStore
                    }:false
                },
                {text: '活动名称', dataIndex: 'activityName', width: 150, menuDisabled: true,renderer:showTip,
                    editor: allowEdit?{
                        xtype: 'combobox',
                        editable: true,
                        forceSelection: false,
                        enableRegEx:true,//模糊搜索
                        queryMode: 'local', // 或者 'remote'，根据你的需求
                        displayField: 'activityName',
                        valueField: 'activityName',
                        store: activityListStores
                    }:false
                },
                {text: '工时(h)', dataIndex: 'manHour', width: 120, menuDisabled: true,
                    editor:allowEdit?{
                        xtype: 'numberfield',
                        minValue: '0',
                        maxValue: '16',
                        decimalPrecision: 1,
                        labelWidth: 100
                    }:false
                },
                {
                    text: '工作内容及遇到的问题或风险',
                    flex: 1,
                    editor: allowEdit?'textarea':false,
                    dataIndex: 'manJobContent',
                    rows: 5,
                    width: 300,
                    menuDisabled: true,
                    renderer:showTip,
                    renderer: function (value, meta, record) {
                        // 确保样式支持换行
                        meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                        return value ? value.replace(/\n/g, "<br/>") : '';

                        // meta.style = 'overflow:auto;padding: 3px 6px;text-overflow: ellipsis;white-space: nowrap;white-space:normal;line-height:20px;';
                        // value = value.replace(/\n/g, "<br/>")
                        // return value;
                    }
                },
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    if(!allowEdit){
                        return false;
                    }
                    // var docState = Ext.getCmp('docState').getValue()
                    // if (docState != '创建' && docState != '返工') {
                    //     return false;
                    // }
                },
            },
            tbar: [{
                text: '<span style="font-weight:bold;">添加</span>',
                id: 'addItem',
                iconCls: 'icon icon-add',
                scope: this,
                hidden: !allowEdit,
                handler: function () {
                    // Ext.getStore('projectListStore').load()
                    // requireWin2.show();

                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.success==true) {
                            getGridInfo();
                        }else {
                            getGridInfo();
                            alert(obj.msg);
                        }
                    };
                    insertData(Ext.getCmp('id').getValue(), "", callbackFn);

                }
            },
                {
                    text: '<span style="font-weight:bold;">删除</span>',
                    id: 'delItem',
                    iconCls: 'icon icon-delete',
                    scope: this,
                    hidden: !allowEdit,
                    handler: function () {
                        let selectionArr = WorkReportGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        Ext.Msg.confirm('提示', '确定要删除？',
                            function (btn) {
                                if (btn == 'yes') {
                                    //数据组装
                                    let obj = new Array();
                                    Ext.each(selectionArr, function (record) {
                                        obj.push(record.data['id'])
                                    });
                                    var callbackFn = function (response, opts) {
                                        //tRecord.commit();
                                        Ext.getStore('WorkReportGridStore').reload()
                                        // var obj = Ext.decode(response.responseText);
                                        // getGridInfo();
                                        getFormInfo();
                                    };
                                    deleteData(obj, callbackFn);
                                } else {
                                    return;
                                }
                            }, this);

                    }
                },
                {
                    text: '<span style="font-weight:bold;">项目高级查询</span>',
                    id: 'projectInquiry',
                    iconCls: 'icon icon-search',
                    scope: this,
                    hidden: !allowEdit,
                    handler: function () {
                        var recordList = WorkReportGrid.getSelectionModel().getSelection();
                        if(recordList.length == 0){
                            alert("请选择一条数据！");
                            return;
                        }
                        if(recordList.length > 1){
                            alert("只能选择一条数据！");
                            return;
                        }
                        projectWorkItemsId = recordList[0].data.id;

                        projectInquiryWindow.show();
                    }
                },
                {
                    xtype: 'button',
                    text: '下载导入模板',
                    id: 'downLoadTemplate',
                    iconCls: 'icon icon-download',
                    hidden: !allowEdit,
                    handler: function () {
                        window.location.href = '/Windchill/ptc1/ECRApprovalRecords/downLoadTemplate?templateName=报工导入模版';
                    }
                },
                {
                    xtype:'filefield',
                    buttonOnly: true,
                    id:'workReportUpload',
                    hideLabel: true,
                    hidden: !allowEdit,
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入报工记录</span>',
                    // buttonText: '<span style="width:120px; background-color:white; color:black; padding:5px; display:inline-block; text-align:center;">' +
                    //     '<img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入报工记录</span>',

                    allowBlank: false,
                    scope: this,
                    listeners:{
                        'change':function(fb,newValue,oldValue,opts){
                            if(!newValue){
                                return;
                            }
                            var file = document.querySelector('[id=workReportUpload-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('workReportUpload-button-fileInputEl', file.files[0]);

                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在导入数据，请稍候......',
                                target: WorkReportGrid
                            });

                            // var date = workDate;
                            // var formattedDate = Ext.Date.format(date, 'Y-m-d'); // 格式化为 '年-月-日'

                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/workReport/importWorkReport?masterId=' + Ext.getCmp('id').getValue() + '&workDate=' + workDate,
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function(res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if(!success){
                                    alert(msg);
                                    // Ext.getStore('ecaEBOMStore').load();
                                    // ecaEBOMGrid.getStore().load();
                                }
                                getFormInfo()
                                // WorkReportGrid.getStore().load();
                            }).fail(function(res) {
                                var obj = Ext.decode(res);
                                var msg = obj['msg'];
                                myMask.hide();
                                alert('导入失败！\n'+msg) ;
                            });
                        }
                    }
                },
                '->',]
        });

        WorkReportGrid.on('rowclick', function (view, record, item, index, e){

            if(!allowEdit){
                return false;
            }

            var docState = Ext.getCmp('docState').getValue()
            if (docState != '创建' && docState != '返工') {
                return false;
            }

            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex+2; // 获取单元格的索引，前面隐藏了两列所以加2
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                var productLine = record.get('productLine');
                var projectNumber = record.get('projectNumber');
                var phase = record.get('projectPhase');
                //项目名称下拉
                if (columnName == 'projectName') {
                    Ext.getStore("projectListStore").load(
                        {
                            params: {
                                productLine:productLine,
                                workDate: workDate
                            }
                        }
                    );
                };
                //产品线下拉
                if (columnName == 'productLine') {
                    Ext.getStore("projectLineListStore").load(
                        {
                            params: {
                                workDate: workDate
                            }
                        }
                    );
                }
                //活动名称下拉
                if (columnName == 'activityName') {
                    // if(!phase){
                    //     alert("请先选择“项目阶段（前）”！");
                    //     return;
                    // }
                    Ext.getStore("activityListStores").load(
                        {
                            params: {
                                projectNumber:projectNumber,
                                phase:phase
                            }
                        }
                    );
                };
                //项目阶段（前）下拉
                if (columnName == 'projectPhase') {
                    if(!projectNumber){
                        alert("请先选择“项目名称”！");
                        return;
                    }
                    Ext.getStore("projectPhaseStore").load(
                        {
                            params: {
                                projectNumber:projectNumber
                            }
                        }
                    );
                };
            }
        });

        WorkReportGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let oldValue = e.originalValue;//旧值
            if(value===oldValue||(oldValue===undefined&&value===null)){
                return;
            }
            let id = record.get('id');
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success==true) {
                    getGridInfo();
                }else {
                    alert(obj.msg)
                }
            };

            if(field == 'manHour'){
                if (value < 0.1 || value > 24) {
                    alert("请输入0.1-24之间数字")
                }
                var is = checkHour(value, id);
                if (!is) {
                    saveData(id, field, 0, callbackFn);
                    return;
                }
            }

            saveData(id, field, value, callbackFn);

        });


        Ext.define('departmentWorkGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'masterId', 'workNumber', 'natureOfWork', 'projectNumber', 'projectName', 'principals', 'activityName',
                'projectPhase', 'manHour', 'manJobContent'],
            idProperty: 'id'
        });

        var departmentWorkGridStore = Ext.create('Ext.data.Store', {
            id: 'departmentWorkGridStore',
            model: 'departmentWorkGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getDepartmentWorkByMasterId',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        let natureOfWorkStore = [
            ['培训学习', '培训学习'],
            ['会议', '会议'],
            ['文件/报表处理', '文件/报表处理'],
            ['技术问题处理', '技术问题处理'],
            ['新员工辅导', '新员工辅导'],
            ['其他', '其他']
        ];

        var departmentWorkGridCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var departmentWorkGrid = Ext.create('Ext.grid.Panel', {
            plugins: [departmentWorkGridCellEditing],
            store: Ext.getStore('departmentWorkGridStore'),
            id: 'departmentWorkGrid',
            //hidden:true,
            margin: '10 10 10 10',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            height: '98%',
            maxHeight: '350',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',
            // listeners: {
            //     change: 'onAllCircuitsChecked'
            // },
            viewConfig: { enableTextSelection:true},
            columns: [
                {xtype: 'rownumberer', flex: 0.5,editor: false},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '工作性质', dataIndex: 'natureOfWork', flex: 1, menuDisabled: true,
                    editor: allowEdit?{
                        xtype: 'combobox',
                        editable: false,
                        forceSelection: false,
                        store: natureOfWorkStore
                    }:false
                },
                {text: '工时(h)', dataIndex: 'manHour', flex: 1, menuDisabled: true,
                    editor:allowEdit?{
                        xtype: 'numberfield',
                        minValue: '0',
                        maxValue: '16',
                        decimalPrecision: 1,
                        labelWidth: 100
                    }:false
                },
                {
                    text: '部门工作内容',
                    flex: 4,
                    editor: {
                        xtype: 'textarea',
                        grow: true,  // 使 textarea 自动增长
                        growMin: 1  // 最小行数
                    },
                    wrap: true,  // 启用自动换行
                    dataIndex: 'manJobContent',
                    renderer:showTip,
                    rows: 5,
                    width: 300,
                    menuDisabled: true,
                    renderer: function (value, meta, record) {
                        // 确保样式支持换行
                        meta.style = 'overflow:auto;padding: 3px 6px;white-space: pre-wrap; line-height: 1.5;';
                        return value ? value.replace(/\n/g, "<br/>") : '';
                    },
                    listeners: {
                        edit: function (editor, e) {
                            // 获取当前编辑的 textarea
                            var textarea = e.field;
                            // 监听输入事件，动态调整高度
                            textarea.on('keyup', function () {
                                var rows = textarea.getValue().split('\n').length;
                                textarea.setRows(rows);
                            });
                        }
                    }
                }
            ],
            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    var tField = e.field; //得到修改列
                    if(!allowEdit) {
                        return false;
                    }
                },
            },
            tbar: [
                {
                text: '<span style="font-weight:bold;">添加</span>',
                id: 'addDepartmentWork',
                iconCls: 'icon icon-add',
                    hidden:!allowEdit,
                scope: this,
                handler: function () {
                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.success==true) {
                            // departmentWorkGridStore.load();
                            getDepartmentWorkGridInfo();
                        }else {
                            getDepartmentWorkGridInfo();
                            alert(obj.msg);
                        }
                    };
                    insertData(Ext.getCmp('id').getValue(), "部门工作", callbackFn);
                }
            }, {
                text: '<span style="font-weight:bold;">删除</span>',
                id: 'delDepartmentWork',
                iconCls: 'icon icon-delete',
                    hidden:!allowEdit,
                scope: this,
                handler: function () {
                    let selectionArr = departmentWorkGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    Ext.Msg.confirm('提示', '确定要删除？',
                        function (btn) {
                            if (btn == 'yes') {
                                //数据组装
                                let obj = new Array();
                                Ext.each(selectionArr, function (record) {
                                    obj.push(record.data['id'])
                                });
                                var callbackFn = function () {
                                    //tRecord.commit();
                                    // Ext.getStore('departmentWorkGridStore').reload()
                                    getDepartmentWorkGridInfo();
                                };
                                deleteData(obj, callbackFn);
                            } else {
                                return;
                            }
                        }, this);

                }
            }, '->',]
        });

        departmentWorkGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let id = record.get('id');
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success==true) {
                    getDepartmentWorkGridInfo();
                }else {
                    alert(obj.msg)
                }
            };

            if(field == 'manHour'){
                if (value < 0.1 || value > 24) {
                    alert("请输入0.1-24之间数字")
                }
                var is = checkHour(value, id);
                if (!is) {
                    saveData(id, field, 0, callbackFn);
                    return;
                }
            }

            saveData(id, field, value, callbackFn);

        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });

        var allUserStore_projectPlan1 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan1'
        });


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            width:'100%',
            anchor: '90%',
            border: false,
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            //layout: "anchor",// 整个大的表单是anchor布局
            items: [{//第*行
                xtype: 'panel',
                layout: 'hbox',
                id: 'panel1',
                border: false,
                margin: '30 20 0 0',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false},
                items: [ {
                    xtype: 'displayfield',
                    id: 'id',
                    hidden: true,
                    fieldLabel: ''
                }, {
                    xtype: 'displayfield',
                    id: 'itemId',
                    hidden: true,
                    fieldLabel: ''
                },{
                    xtype: 'displayfield',
                    id: 'docBranchId',
                    width: 220,
                    hidden:true,
                    fieldLabel: ''
                }, {
                    xtype: 'displayfield',
                    id: 'hourLink',
                    width: 220,
                    fieldLabel: '文档编号'
                }, {
                    xtype: 'displayfield',
                    id: 'docState',
                    fieldLabel: '文档状态'
                },{
                    xtype: 'displayfield',
                    id: 'userName',
                    fieldLabel: '提交人'
                }
                    , {
                        xtype: 'button',
                        text: "撤回",
                        width: 120,
                        height: 30,
                        hidden: true,
                        id: 'recallTop',
                        name: 'recallTop',
                        margin: '10 0 18 0',
                        handler: function () {
                            deleteDocOrProcess("process");
                        }
                    }

                ]
            },

                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '10 20 0 0',
                    defaults: {margin: '5 20 0 0', labelWidth: 70, border: false},
                    items: [{
                        xtype: 'combobox',
                        width: 250,
                        fieldLabel: '选择抄送人:',
                        // multiSelect: true,
                        //editable: false,
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        disabled: !allowEdit,
                        // hidden: !allowEdit,
                        disabledCls: 'none',
                        valueField: 'no',
                        //valueField: 'no',
                        displayField: 'userFullName',
                        store: allUserStore_projectPlan1,
                        name: 'carbonCopyText',
                        id: 'carbonCopyText',
                        listeners: {
                            select: function (e) {
                                var carbonCopy = Ext.getCmp("carbonCopyText").getRawValue();
                                //var carbonCopy = Ext.getCmp("carbonCopyText").getValue();
                                var carbonCopyText = Ext.getCmp("carbonCopy").getValue();
                                var values = carbonCopyText.split(",");

                                var carbonCopyAutomatic = Ext.getCmp("carbonCopyAutomatic").getValue();
                                var carbonCopyAutomaticList = carbonCopyAutomatic.split(",");
                                for (var i = 0; i < carbonCopyAutomaticList.length; i++) {
                                    if (carbonCopy == carbonCopyAutomaticList[i]) {
                                        alert("当前选择的人员已经在“已选择抄送人（自动）”中存在！");
                                        return;
                                    }
                                }

                                var isEq = true;
                                debugger
                                for (var i = 0; i < values.length; i++) {
                                    if (carbonCopy == values[i]) {
                                        isEq = false;
                                        return;
                                    }
                                }
                                if (isEq) {
                                    //Ext.getCmp("carbonCopy").setValue(carbonCopyText + ',' + carbonCopy)
                                    saveReport();
                                }
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        width: 550,
                        labelWidth: 100,
                        fieldLabel: '已选择抄送人（手动）:',
                        // hidden: true,
                        disabled: !allowEdit,
                        disabledCls: 'none',
                        name: 'carbonCopy',
                        id: 'carbonCopy',
                        listeners: {
                            blur: function (e) {

                                saveCarbonCopy();
                            }
                        }
                    },{
                        // hidden: true,
                        id: 'carbonCopyInfo',
                        html: '“,”分隔',
                        margin: '10 50 0 0', border: false
                    },]
                }
                , {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '10 20 0 0',
                    defaults: {margin: '5 20 0 0', labelWidth: 70, border: false},
                    items: [
                        {
                            xtype: 'textfield',
                            width: 550,
                            labelWidth: 100,
                            fieldLabel: '已选择抄送人（自动）:',
                            // hidden: true,
                            readOnly:true,
                            disabled: true,
                            disabledCls: 'none',
                            name: 'carbonCopyAutomatic',
                            id: 'carbonCopyAutomatic',
                            listeners: {
                                blur: function (e) {

                                    saveCarbonCopy();
                                }
                            }
                        }
                        , {
                            // hidden: true,
                            id: 'carbonCopyAutomaticInfo',
                            html: '“,”分隔',
                            margin: '10 50 0 0', border: false
                        }
                    ]
                }

                ,

                {
                xtype: 'panel',
                hidden: true,
                //layout: 'hbox',
                id: 'panel2',
                border: false,
                margin: '30 20 0 0',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false},
                items: [{
                    xtype: 'label',
                    id: "userWorkHoursCountLable",
                    text: '工时统计：0',
                },{
                    margin: '30 0 30 0',
                    html: '<div style="font-weight:bold ;font-size:24px;top:50px;left:50px;background-color: gainsboro;background-size:100%;text-align:center;height: 35px;line-height: 35px;">项目工作</div>'
                }, {
                    border: false,
                    html: '指投入PDT/TDT产品线的工作，包括评审，Charter开发、产品技术支持等。如果该工作无对应的项目, 则选择该项目的费用公摊。工时单位：小时，包括加班时间。'
                }, WorkReportGrid,
                    {
                        margin: '30 0 30 0',
                        html: '<div style="font-weight:bold ;font-size:24px;top:50px;left:50px;background-color: gainsboro;background-size:100%;text-align:center;height: 35px;line-height: 35px;">部门工作</div>'
                    },
                    departmentWorkGrid
                    // {
                    //     html: '<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;text-align:left">部门工时填写(h)</div>'
                    // }, {
                    //     html: '指产品线之外的工作，例如：CBB，专利编制，部门能力建设等，工作单位：小时，包括加班时间。'
                    // }, {
                    //     xtype: 'numberfield',
                    //     fieldLabel: '',
                    //     name: 'manHour1',
                    //     id: 'manHour1',
                    //     minValue:'0',
                    //     maxValue:'10000',
                    //     disabled:!allowEdit,
                    //     disabledCls:'none',
                    //     width: 200,
                    //     listeners: {
                    //         blur: function (e) {
                    //             var manHour1 = Ext.getCmp("manHour1").getValue();
                    //             var itemId = Ext.getCmp("itemId").getValue();
                    //             var is = checkHour(manHour1,itemId);
                    //             if (manHour1 < 0.1 || manHour1 > 24) {
                    //                 alert("请输入0.1-24之间数字")
                    //                 Ext.getCmp("manHour1").setValue("");
                    //             }
                    //             //alert(is)
                    //             if (!is) {
                    //                 Ext.getCmp("manHour1").setValue(0);
                    //                 saveDepartmentReport();
                    //             }else {
                    //                 saveDepartmentReport();
                    //             }
                    //         }
                    //     }
                    // }, {
                    //     html: '<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;text-align:left">部门工作内容</div>'
                    // }, {
                    //     html: '简述工作内容，及遇到的问题'
                    // }, {
                    //     xtype: 'textarea',
                    //     disabled:!allowEdit,
                    //     disabledCls:'none',
                    //     fieldLabel: '',
                    //     height:450,
                    //     name: 'manJobContent1',
                    //     id: 'manJobContent1',
                    //     width: 800,
                    //     listeners: {
                    //         blur: function (e) {
                    //             saveDepartmentReport();
                    //         },
                    //     }
                    // }
                ],
            }

            ]
        }]



        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            getFormInfo();
        }
    }
});

/**
 * 获取表单数据
 */
function getFormInfo() {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getWorkReportByBranchId',
        params: {
            branchId: branchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                var mainPanel = Ext.getCmp('mainForm');
                if (obj['isNull'] == '0') {
                    if (!obj.hasOwnProperty('carbonCopyAutomatic')) {
                        obj['carbonCopyAutomatic'] = "";
                    }
                    mainPanel.getForm().setValues(obj);
                    if(obj['docState'] == "正在审阅"||obj['docState'] == "已发布") {
                        Ext.getCmp('recallTop').show();
                    }

                    // 时间戳
                    const creatorDate = obj['creatorDate'];

                    // 创建 Date 对象
                    const date = new Date(creatorDate);

                    // 获取年、月、日
                    const year = date.getFullYear();
                    const month = String(date.getMonth() + 1).padStart(2, '0'); // 月份从0开始，需要加1并格式化为两位
                    const day = String(date.getDate()).padStart(2, '0'); // 日期格式化为两位

                    // 创建格式化后的日期字符串
                    const formattedDate = `${year}-${month}-${day}`;

                    workDate = formattedDate;
                    masterId = obj['id'];
                    approver = obj['approver'];
                    getGridInfo();
                    getReportItemByProjectName();
                    Ext.getCmp('panel2').show();
                } else {
                    Ext.getCmp('hourLink').setValue("");
                    Ext.getCmp('docState').setValue("");
                    Ext.getCmp('panel2').hide();
                }

                //alert(obj['msg']);
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

/**
 * 获取grid信息
 */
function getGridInfo() {
    Ext.getStore('WorkReportGridStore').load({
        params: {
            masterId: Ext.getCmp('id').getValue(),
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询grid信息失败，请联系管理员！');
            }else {
                getSumHour();
            }
        }
    })
}

/**
 * 获取项目阶段信息
 */
function getProjectPhase(number) {
    Ext.getStore('projectPhaseStore').load({
        params: {
            projectNumber: number,
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询grid信息失败，请联系管理员！');
            }
        }
    })
}

/**
 * 获取项目阶段中活动
 */
function getActivity() {

    var number = Ext.getCmp("projectNumber").getValue();
    var projectPhase = Ext.getCmp("projectPhase").getValue();
    Ext.getStore('activityListStores').load({
        params: {
            projectNumber: number,
            phase:projectPhase
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！');
            }
        }
    })
}


/**
 * 根据id查询grid中的信息
 * @param id
 */
function getReportItemById(id) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getReportItemById',
        params: {
            id: id
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {

                Ext.getCmp('productLine').setValue(obj['productLine']),
                Ext.getCmp('projectNumber').setValue(obj['projectNumber']),
                Ext.getCmp('projectName').setValue(obj['projectName']),
                Ext.getCmp('activityName').setValue(obj['activityName']),
                Ext.getCmp('projectPhase').setValue(obj['projectPhase']),
                Ext.getCmp('manHour').setValue(obj['manHour']),
                Ext.getCmp('manJobContent').setValue(obj['manJobContent'])
                Ext.getCmp('updateId').setValue(obj['id']);
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}


//修改或新增数据
function save(data) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/saveWorkReportItem',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                getFormInfo();

            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存项目信息失败，请检查网络！');
        }
    });
}
 var is = true
 /**
  * 判断工时是否超最大填写工时
  */
 function checkHour(manHour,itemId){
    var masterId = Ext.getCmp('id').getValue();
    if (itemId==undefined || itemId==''){
        itemId=1
    }
    var is = true;
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/checkHour',
        method: "POST",
        async : false,
        params: {
            masterId:masterId,
            manHour:manHour,
            itemId:itemId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                is = true
            } else {
                alert(obj['msg']);
                is = false
            }
        },
        failure: function (response, opts) {
            alert('错误：判断工时是否超最大填写工时，请检查网络！');
        }
    });
    return is;
}

 /**
  * 根据主表id及日报项目名称获取部门工作信息
  */
 function getReportItemByProjectName() {
     Ext.getStore('departmentWorkGridStore').load({
         params: {
             masterId: Ext.getCmp('id').getValue(),
         },
         callback: function (records, operation, success) {
             if (!success) {
                 alert('查询grid信息失败，请联系管理员！');
             } else {
                 getSumHour();
             }
         }
     })

    //  //alert(Ext.getCmp('id').getValue())
    // Ext.Ajax.request({
    //     scope: this,
    //     url: '/Windchill/ptc1/workReport/getReportItemByProjectName',
    //     params: {
    //         masterId: Ext.getCmp('id').getValue(),
    //     },
    //     success: function (response, opts) {
    //         var obj = Ext.decode(response.responseText);
    //         if (obj['success']) {
    //             if (obj['isNull'] == '0') {
    //                 Ext.getCmp('manHour1').setValue(obj['manHour']);
    //                 Ext.getCmp('manJobContent1').setValue(obj['manJobContent']);
    //                 Ext.getCmp('itemId').setValue(obj['id']);
    //             } else {
    //                 Ext.getCmp('manHour1').setValue("");
    //                 Ext.getCmp('manJobContent1').setValue("");
    //             }
    //         } else {
    //             alert(obj['msg']);
    //         }
    //     },
    //     failure: function (response, opts) {
    //         alert('错误：保存信息失败，请检查网络！');
    //     }
    // }); //~End of Ajax request
}

 /**
  * 修改部门工作信息
  */
 function saveDepartmentReport() {
    //alert(Ext.getCmp('itemId').getValue());
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/saveDepartmentReport',
        method: "POST",
        params: {
            id: Ext.getCmp('itemId').getValue(),
            manHour: Ext.getCmp('manHour1').getValue(),
            manJobContent: Ext.getCmp('manJobContent1').getValue(),
            masterId: Ext.getCmp('id').getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                getReportItemByProjectName();
                getSumHour();
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存修改部门工作信息失败，请检查网络！');
        }
    });
}

/**
 * 删除
 * @param dataArray
 * @param callback
 */
function deleteData(dataArray, callback) {
    /*var myMask = new Ext.LoadMask(Ext.getBody(), {msg: "数据正在处理中，请稍后..."});
    myMask.show();*/
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/delWorkReport',
        method: "POST",
        params: {
            data: Ext.encode(dataArray),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['msg']);
                //myMask.hide();
            } else {
                //myMask.hide();
                alert("数据删除成功");
                callback();
                // Ext.getCmp('message').getEl().update('<font style="font-weight:bold;font-style:italic;size: A3;color: darkgrey">应审下发成功...</font>');
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

 /**
  *获取项目编号
  */
 function getProjectNumber() {
     var projectNumber = Ext.getCmp("projectName").getValue();
     Ext.Ajax.request({
         url: '/Windchill/ptc1/workReport/checkProjectNumber',
         params: {
             projectNumber: projectNumber
         },
         success: function (response, opts) {
             var obj = Ext.decode(response.responseText);
             if (!obj['success']) {
                 if (obj['msg'].toString().concat('null')){
                     alert('请选择正确的项目名称！');
                     Ext.getCmp("projectNumber").setValue('');
                     Ext.getCmp("projectPhase").setValue('');
                     Ext.getCmp("activityName").setValue('');
                     Ext.getCmp("productLine").setValue('');
                     Ext.getCmp("projectName").setValue('');
                 }
                 return;//中断
             }
             //将值填充
             if (obj['projectNumber'] && obj['projectNumber'].length > 0) {
                 Ext.getCmp("projectNumber").setValue(obj['projectNumber']);
             } else if (projectName == '研发中心公共') {
                 Ext.getCmp("projectNumber").setValue('999999');
             } else {
                 alert('请选择正确的项目名称！');
             }
             Ext.getCmp("productLine").setValue(obj['productLine']);
             Ext.getCmp("projectPhase").setValue('');
             Ext.getCmp("activityName").setValue('');
         },
         failure: function (response, opts) {
             alert('错误：查询编码失败，请检查网络！');
         }
     });
 }
function clear() {
    Ext.getCmp('updateId').setValue(""),
    Ext.getCmp('productLine').setValue(""),
    Ext.getCmp('projectNumber').setValue(""),
    Ext.getCmp('projectName').setValue(""),
    Ext.getCmp('activityName').setValue(""),
    Ext.getCmp('projectPhase').setValue(""),
    Ext.getCmp('manHour').setValue(""),
    Ext.getCmp('manJobContent').setValue("")
}

 /**
  * 获取合计工时
  */
 function getSumHour() {

     Ext.Ajax.request({
         scope: this,
         url: '/Windchill/ptc1//workReport/manGetSumHour',
         method: "POST",
         params: {
             masterId: Ext.getCmp('id').getValue(),
         },
         success: function (response, opts) {
             var obj = Ext.decode(response.responseText);
             if (obj['success']) {
                 Ext.getCmp("userWorkHoursCountLable").setText("工时合计:"+obj['sumHour']+"小时");
             }
         },
         failure: function (response, opts) {
             alert('错误：请检查网络！');
         }
     });
 }

 /**
  * 提交
  */
 function commit() {
     alert(Ext.getCmp("approver").getValue())
     Ext.Ajax.request({
         scope: this,
         url: '/Windchill/ptc1/workReport/commit',
         method: "POST",
         params: {
             branchId: Ext.getCmp("docBranchId").getValue(),
             approver: Ext.getCmp("approver").getValue(),
         },
         success: function (response, opts) {
             var obj = Ext.decode(response.responseText);
             if (obj['success']) {
                 var mainPanel = Ext.getCmp('mainForm');
                 mainPanel.getForm().setValues(obj);
             }
         },
         failure: function (response, opts) {
             alert('提交错误：请检查网络！');
         }
     });
 }

 /**
  * 删除文档对象
  * @param dbTableName
  * @param branchId
  * @param callbackFn
  */
 function deleteDocOrProcess(deleteType){
     let id = Ext.getCmp('id').getValue();
     let confirmInfo = "";
     let alertInfo = "";
     if("doc" == deleteType){
         confirmInfo = '确认删除文档？';
         alertInfo = '删除成功！';
     }else if("process" == deleteType){
         confirmInfo = '确认撤回文档流程？';
         alertInfo = '撤回文档流程成功！';
     }
     Ext.Msg.confirm('提示', confirmInfo,
         function (btn) {
             if (btn == 'yes') {
                 Ext.Ajax.request({
                     url: '/Windchill/ptc1/workReport/deleteDocOrProcess',
                     params: {
                         masterId:id,
                         deleteType:deleteType
                     },
                     success: function (response, opts) {
                         var obj = Ext.decode(response.responseText);
                         if(obj.success==true) {
                             alert(alertInfo);
                             getFormInfo();
                             if("process" == deleteType){
                                 // Ext.getCmp('recallBottom').hide();
                                 Ext.getCmp('recallTop').hide();
                             }
                             // if("doc" == deleteType){
                             //     Ext.getCmp('deleteBottom').hide();
                             //     Ext.getCmp('deleteTop').hide();
                             // }
                         } else {
                             alert(obj.msg);
                         }
                     },
                     failure: function (response, opts) {
                         var obj = Ext.decode(response.responseText);
                         alert(obj.msg);
                         // alert('错误：保存信息失败，请检查网络！!');
                     }
                 });
             } else {
                 return;
             }
         }, this);
 }


 /**
  * 获取部门工作grid信息
  */
 function getDepartmentWorkGridInfo() {
     Ext.getStore('departmentWorkGridStore').load({
         params: {
             masterId: Ext.getCmp('id').getValue(),
         },
         callback: function (records, operation, success) {
             if (!success) {
                 alert('查询grid信息失败，请联系管理员！');
             } else {
                 getSumHour();
             }
         }
     })
 }

 /**
  * 插入数据
  * @param dbTableName
  * @param branchId
  * @param callbackFn
  */
 function insertData(masterId, formType, callbackFn){
     var insertRecord = {
         masterId:masterId,
         formType:formType
     };
     Ext.Ajax.request({
         url: '/Windchill/ptc1/workReport/insertWorkReportInfo',
         params: {data:Ext.encode(insertRecord)},
         success: function (response, opts) {
             var obj = Ext.decode(response.responseText);
             if(obj.success==true) {
                 //回调函数，一般用于后台操作成功后刷新列表
                 if (callbackFn) {
                     callbackFn(response, opts);
                 }
             } else {
                 alert(obj.msg);
             }
         },
         failure: function (response, opts) {
             alert('错误：新增信息失败，请检查网络！!');
         }
     });
 }

 /**
  * 保存数据
  * @param dbTableName
  * @param branchId
  * @param callbackFn
  */
 function saveData(id, dataKey,dataValue, callbackFn){
     var insertRecord = {
         id:id,
         key:dataKey,
         value:dataValue
     };
     Ext.Ajax.request({
         url: '/Windchill/ptc1/workReport/updateWorkReportInfo',
         params: {data:Ext.encode(insertRecord)},
         success: function (response, opts) {
             var obj = Ext.decode(response.responseText);
             if(obj.success==true) {
                 if("projectName" == dataKey){
                     getFormInfo();
                 }
                 //回调函数，一般用于后台操作成功后刷新列表
                 if (callbackFn) {
                     callbackFn(response, opts);
                 }
             } else {
                 alert(obj.msg);
             }
         },
         failure: function (response, opts) {
             alert('错误：保存信息失败，请检查网络！!');
         }
     });
 }

 /**
  * 删除文档对象
  * @param dbTableName
  * @param branchId
  * @param callbackFn
  */
 function deleteDocOrProcess(deleteType){
     let id = Ext.getCmp('id').getValue();
     let confirmInfo = "";
     let alertInfo = "";
     if("doc" == deleteType){
         confirmInfo = '确认删除文档？';
         alertInfo = '删除成功！';
     }else if("process" == deleteType){
         confirmInfo = '确认撤回文档流程？';
         alertInfo = '撤回文档流程成功！';
     }
     Ext.Msg.confirm('提示', confirmInfo,
         function (btn) {
             if (btn == 'yes') {
                 Ext.Ajax.request({
                     url: '/Windchill/ptc1/workReport/deleteDocOrProcess',
                     params: {
                         masterId:id,
                         deleteType:deleteType
                     },
                     success: function (response, opts) {
                         var obj = Ext.decode(response.responseText);
                         if(obj.success==true) {
                             alert(alertInfo);
                             getFormInfo();
                             if("process" == deleteType){
                                 Ext.getCmp('recallBottom').hide();
                                 Ext.getCmp('recallTop').hide();
                             }
                             Ext.getCmp("userWorkHoursTreePanel").getStore().reload();
                             // if("doc" == deleteType){
                             //     Ext.getCmp('deleteBottom').hide();
                             //     Ext.getCmp('deleteTop').hide();
                             // }
                         } else {
                             alert(obj.msg);
                         }
                     },
                     failure: function (response, opts) {
                         var obj = Ext.decode(response.responseText);
                         alert(obj.msg);
                         // alert('错误：保存信息失败，请检查网络！!');
                     }
                 });
             } else {
                 return;
             }
         }, this);
 }

 //region grid单元格悬浮提示
 function showTip(value,metaData,record,row,col,store){
     if(value)
         metaData.tdAttr = 'data-qtip="' + value +'"';
     return value;
 }//endregion

 /**
  * 修改日报信息
  */
 function saveReport() {
     //alert(Ext.getCmp('itemId').getValue());
     Ext.Ajax.request({
         scope: this,
         url: '/Windchill/ptc1/workReport/saveReport',
         method: "POST",
         params: {
             carbonCopy: Ext.getCmp('carbonCopyText').getValue(),
             //approver: Ext.getCmp('approver').getValue(),
             masterId: masterId,
         },
         success: function (response, opts) {
             var obj = Ext.decode(response.responseText);
             if (obj['success']) {

                 console.log(obj['carbonCopy'])
                 Ext.getCmp('carbonCopy').setValue(obj['carbonCopy'])
             } else {
                 alert(obj['error']);
             }
         },
         failure: function (response, opts) {
             alert('错误：保存项目度量信息失败，请检查网络！');
         }
     });
 }

 //修改抄送人
 function saveCarbonCopy() {
     /* var myMask = new Ext.LoadMask(Ext.getBody(), {error:"数据正在处理中，请稍后..."});
      myMask.show();*/
     Ext.Ajax.request({
         scope: this,
         url: '/Windchill/ptc1/workReport/saveCarbonCopy',
         method: "POST",
         params: {
             masterId: masterId,
             approver: approver,
             carbonCopy: Ext.getCmp("carbonCopy").getValue()
         },
         success: function (response, opts) {
             var obj = Ext.decode(response.responseText);
             if (!obj['success']) {
                 alert(obj['error']);
                 // myMask.hide();
             } else {
                 // myMask.hide();
                 //callback();
             }
         },
         failure: function (response, opts) {
             Ext.Msg.alert("错误", '数据修改失败，请检查网络！')
         }
     });
 }