/**
 * 项目工时统计
 * 描述：项目经理查看有权限项目的用户工作日志
 */
Ext.define('PLM.view.projectManagerQuery', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.projectManagerQuery',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'workReport-projectManagerQuery',
        in_objectDesc: '项目工时统计',
    },
    id: 'projectManagerQuery',
    initComponent: function () {
        var me = this;

        Ext.define('projectManagerQueryGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'userName', 'userDepartment', 'workNumber', 'creatorDate', 'HourLink', 'productLine',
                'projectNumber', 'projectName', 'activityName', 'projectPhase', 'manHour', 'manJobContent',
                'hourLink','planningProjectName','projectSource'],
            idProperty: 'id'
        });

        var projectManagerQueryStore = Ext.create('PLM.store.MockItemStore', {
            id: 'projectManagerQueryStore',
            model: 'projectManagerQueryGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getProjectReport',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                },
                timeout: 99999999
            }),
            autoLoad: false
        });

        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectNumber', 'name'
            ],
            idProperty: 'projectNumber'
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });

        // 项目下拉
        var projectStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                // url: '/Windchill/ptc1/workReport/getOwnerProjectList',
                url: '/Windchill/ptc1/workReport/getProjects',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });
        // 部门下拉
        var departmentStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            fields: ['name'],
            id: 'departmentStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllUserDepartment',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });
        // 产品线下拉
        var productLineStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            fields: ['name'],
            id: 'productLineStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllProductLine',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var projectManagerQueryGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('projectManagerQueryStore'),
            id: 'projectManagerQueryGrid',
            //margin: '0 5 5 5',
            // forceFit: true,
            autoWidth: true,
            //border:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            // height: '98%',
            height: 500,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer',width:60, align: 'center'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '日期', dataIndex: 'creatorDate', width: 100, menuDisabled: true},
                {text: '姓名', dataIndex: 'userName', width: 100, menuDisabled: true},
                // {text: '账号', dataIndex: 'workNumber', width: 100, menuDisabled: true},
                {text: '部门', dataIndex: 'userDepartment', width: 100, menuDisabled: true},
                {text: '工时文档链接', dataIndex: 'hourLink', width: 100, menuDisabled: true},
                {text: '产品线', dataIndex: 'productLine', width: 100, menuDisabled: true},
                {text: '项目编码', dataIndex: 'projectNumber', width: 100, menuDisabled: true},
                {text: '项目名称', dataIndex: 'projectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目来源', dataIndex: 'projectSource', width: 100, menuDisabled: true},
                {text: '规划项目名称', dataIndex: 'planningProjectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目阶段', dataIndex: 'projectPhase', width: 100, menuDisabled: true},
                {text: '项目活动', dataIndex: 'activityName', width: 120, menuDisabled: true},
                {text: '工时', dataIndex: 'manHour', width: 60, menuDisabled: true},
                {text: '工作内容', dataIndex: 'manJobContent', width: 500, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
            ],
        });

        //============================================= 柱状图开始 ============================================
        var projectLine = Ext.create('Ext.container.Container', {
            width: 600,
            height: 400,
            layout: 'fit',
            // margin: '30 15 0 50' ,// 设置输入框之间的距离为 10 像素
            items: [{
                xtype: 'component',
                id: 'projectLine-echarts-container',
                autoEl: {
                    tag: 'div',
                    style: {
                        width: '100%',
                        height: '100%'
                    }
                }
            }]
        });




        var projectType = Ext.create('Ext.container.Container', {
            width: 600,
            height: 400,
            layout: 'fit',
            items: [{
                xtype: 'component',
                id: 'projectType-echarts-container',
                autoEl: {
                    tag: 'div',
                    style: {
                        width: '100%',
                        height: '100%'
                    }
                }
            }]
        });

        var project = Ext.create('Ext.container.Container', {
            width: '100%',
            height: 600,
            layout: 'fit',
            items: [{
                xtype: 'component',
                id: 'project-echarts-containerR',
                autoEl: {
                    tag: 'div',
                    style: {
                        width: '100%',
                        height: '100%'
                    }
                }
            }]
        });


        var projectLinePanel = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            width: '50%',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            layout: {
                type: 'hbox',      // 设置布局为水平盒子布局
                align: 'stretch'   // 使子组件在容器中伸展以填充容器
            },
            items:[
                projectLine
            ]
        });

        var projectTypePanel = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            width: '50%',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            layout: {
                type: 'hbox',      // 设置布局为水平盒子布局
                align: 'stretch'   // 使子组件在容器中伸展以填充容器
            },
            items:[
                projectType
            ]
        });

        var projectPanelTop = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            width: '100%',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            layout: {
                type: 'hbox',      // 设置布局为水平盒子布局
                align: 'stretch'   // 使子组件在容器中伸展以填充容器
            },
            items:[
                projectLinePanel,
                projectTypePanel
            ]
        });

        var projectPanel = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            width: '100%',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            layout: {
                type: 'hbox',          // 设置布局为水平盒子布局
                align: 'stretch',      // 使子组件在容器中伸展以填充容器
                pack: 'center'         // 子组件在容器中居中对齐
            },
            items:[
                project
            ]
        });
        //============================================= 柱状图结束 ============================================

        var projectGridPanel = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            width: '100%',
            height: 600,
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            layout: {
                // type: 'hbox',          // 设置布局为水平盒子布局
                align: 'stretch',      // 使子组件在容器中伸展以填充容器
                pack: 'center'         // 子组件在容器中居中对齐
            },
            items:[
                {//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false, padding: 5},
                    items: [{
                        xtype: 'combobox',
                        fieldLabel: '部门名称',
                        // margin: '0 0 0 20',
                        labelWidth: 70,
                        store: departmentStore,
                        queryMode: 'local',
                        displayField: 'name',
                        valueField: 'name',
                        id: 'departmentName',
                        name: 'departmentName',
                    },{
                        xtype: 'combobox',
                        fieldLabel: '用户名称',
                        id: 'userName',
                        name: 'userName',
                        store: allUserStore_projectPlan,
                        labelWidth: 70,
                        typeAhead: true,
                        triggerAction: 'all',
                        queryMode: 'local',
                        displayField: 'userFullName',
                        valueField: 'no',
                        forceSelection: true,
                        allowBlank: true,
                        anyMatch: true
                    },{
                        xtype: 'combobox',
                        fieldLabel: '项目名称',
                        // margin: '0 0 0 20',
                        id: 'projectName',
                        name: 'projectName',
                        store: projectStore,
                        labelWidth: 70,
                        typeAhead: true,
                        triggerAction: 'all',
                        queryMode: 'local',
                        displayField: 'name',
                        valueField: 'name',
                        // valueField: 'number',
                        forceSelection: true,
                        allowBlank: true,
                        anyMatch: true
                    }, {
                        xtype: 'combobox',
                        fieldLabel: '项目编码',
                        // margin: '0 0 0 20',
                        id: 'projectNumber',
                        name: 'projectNumber',
                        store: projectStore,
                        labelWidth: 70,
                        typeAhead: true,
                        triggerAction: 'all',
                        queryMode: 'local',
                        displayField: 'projectNumber',
                        valueField: 'projectNumber',
                        // valueField: 'number',
                        forceSelection: true,
                        allowBlank: true,
                        anyMatch: true
                    },   {
                        xtype: 'combobox',
                        fieldLabel: '产品线',
                        // margin: '0 0 0 20',
                        id: 'productLine',
                        name: 'productLine',
                        store: productLineStore,
                        labelWidth: 70,
                        typeAhead: true,
                        triggerAction: 'all',
                        queryMode: 'local',
                        displayField: 'name',
                        valueField: 'name',
                        forceSelection: true,
                        allowBlank: true,
                        anyMatch: true
                    }]
                }, {//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '10 5 0 20', labelWidth: 100, border: false, padding: 5},
                    items: [{
                        xtype: 'datefield',
                        fieldLabel: '开始日期',
                        id: 'dateStart',
                        format: 'Y-m-d',
                        name: 'dateStart',
                        // value: Ext.util.Format.date(Ext.Date.add(Ext.Date.getFirstDateOfMonth(new Date()), Ext.Date.MONTH, 0), "Y-m-d"),
                        value: Ext.util.Format.date(Ext.Date.add(new Date(), Ext.Date.MONTH, -3), "Y-m-d"),
                        labelWidth: 70,
                        width: 220
                    }, {
                        xtype: 'datefield',
                        fieldLabel: '结束日期',
                        id: 'dateEnd',
                        format: 'Y-m-d',
                        name: 'dateEnd',
                        value: new Date(),
                        labelWidth: 70,
                        width: 220
                    }, {
                        iconCls: 'icon icon-search',
                        xtype: 'button',
                        id: "queryUserWorkHoursCount",
                        text: '查询',
                        handler: function () {
                            getProjectReport();
                            projectLineQuery();
                            projectQuery();
                            projectTypeQuery();
                        }
                    }, {
                        iconCls: 'icon icon-store-export',
                        xtype: 'button',
                        id: "exportWorkHoursCountDetails",
                        text: '导出',
                        handler: function () {
                            exportReport();
                        }
                    }
                        , {
                            iconCls: 'icon icon-store-export',
                            xtype: 'button',
                            id: "exportWorkHoursCountDetailsSelect",
                            text: '导出选择的数据',
                            handler : function() {
                                let selectionArr = projectManagerQueryGrid.getSelectionModel().getSelection();
                                if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                    Ext.Msg.alert("提示", "请选择要导出的数据");
                                    return;
                                }
                                //数据组装
                                let workReportId = new Array();
                                Ext.each(selectionArr, function (record) {
                                    workReportId.push(record.data['masterId'])
                                });
                                let workReportItemId = new Array();
                                Ext.each(selectionArr, function (record) {
                                    workReportItemId.push(record.data['id'])
                                });
                                // 使用 Set 去除重复的数据
                                workReportId = Array.from(new Set(workReportId));
                                exportReport(workReportId,workReportItemId,"select");
                            },
                            scope : this
                        }
                        , {
                            xtype: 'label',
                            id: "userWorkHoursCountLable",
                            text: '工时统计：0',
                        }]
                }, projectManagerQueryGrid
            ]
        });




        var projectManagerQueryForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            title: '项目工时统计',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [
                projectGridPanel,
                projectPanelTop,
                projectPanel,

            ]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [projectManagerQueryForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('projectStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            }),
            Ext.getStore('departmentStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            }),
            Ext.getStore('productLineStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    },

});

function exportReport(workReportId,workReportItemId,select) {
    var data = {};
    if("select" === select){
        data = {
            workReportId: workReportId,
            workReportItemId: workReportItemId,
            select:select
        };
    }else {
        data = getSearchData();
    }
    // var data = getSearchData();

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportReport', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;

        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "项目工时"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    var datastr = Ext.encode(data);
    var datastr1 = datastr.replace("&",";;;qqq");
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
    		"data=" + datastr1   +"&type=projectManager&exportType=projectManager"
    );

}

function getSearchData() {
    var data = {
        workNumber: Ext.getCmp("userName").getValue(),
        projectName: Ext.getCmp("projectName").getValue(),
        departmentName: Ext.getCmp("departmentName").getValue(),
        productLine: Ext.getCmp("productLine").getValue(),
        dateStart: Ext.getCmp("dateStart").getValue(),
        dateEnd: Ext.getCmp("dateEnd").getValue(),
        projectNumber:Ext.getCmp("projectNumber").getValue()
    };
    return data;
}

function getProjectReport() {
    var data = getSearchData();
    Ext.getStore('projectManagerQueryStore').load({
        params: {
            data: Ext.encode(data)
        },
        callback: function (records, operation, success) {
            if (!success) {

                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    alert('查询超时！请重试！')
                }
            } else {
                getSumHour();
            }
        },
    })
}

function getSumHour() {
    var data = getSearchData();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getSumHour',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                Ext.getCmp("userWorkHoursCountLable").setText("工时统计:" + obj['sumHour'] + "小时");
            }
        },
        failure: function (response, opts) {
            alert('错误：请检查网络！');
        }
    });
}
