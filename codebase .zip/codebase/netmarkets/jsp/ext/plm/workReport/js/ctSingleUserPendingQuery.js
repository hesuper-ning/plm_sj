/**
 * 个人工时统计
 * 描述：每个用户查看自己的工作日报
 */
Ext.define('PLM.view.singleUserPendingQuery', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.singleUserPendingQuery',
    border: false,
    autoScroll: true,
    autoWidth: true,
    height: 690,
    // autoHeight: true,
    collapsible: false,
    config: {
        // in_objectKey: 'workReport-singleUserQuery',
        // in_objectDesc: '个人工时统计',
    },
    id: 'singleUserPendingQuery',
    initComponent: function () {
        var me = this;


        Ext.define('ProjectPendingModel', {
            extend: 'Ext.data.Model',
            fields: [
                'name'
            ],
            idProperty: 'name'
        });


        // 项目下拉
        var projectPendingStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectPendingModel',
            id: 'projectPendingStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getProjects',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        // 产品线下拉
        var productLineStorePending = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            fields: ['name'],
            id: 'productLineStorePending',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllProductLine',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        //用户下拉列表
        var allUserStore_projectPlanPending = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });

        // 部门下拉
        var departmentStorePending = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            fields: ['name'],
            id: 'departmentStorePending',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getAllUserDepartment',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });


        Ext.define('singleUserQueryGridPendingModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'userName', 'userDepartment', 'workNumber', 'creatorDate', 'HourLink', 'productLine',
                'projectNumber', 'projectName', 'activityName','projectPhase','manHour','manJobContent','natureOfWork',
                'hourLink','planningProjectName','projectSource'],
            idProperty: 'id'
        });

        var singleUserQueryPendingStore = Ext.create('PLM.store.MockItemStore', {
            id: 'singleUserQueryPendingStore',
            model: 'singleUserQueryGridPendingModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getManReport',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var singleUserQueryPendingGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('singleUserQueryPendingStore'),
            id: 'singleUserQueryPendingGrid',
            //title:'个人工时统计',
            titleAlign: 'center',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            // height: '98%',
            height: 600,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{text: '序号',xtype: 'rownumberer',flex: 0.5, align: 'center'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '日期', dataIndex: 'creatorDate', flex: 1, menuDisabled: true},
                {text: '姓名', dataIndex: 'userName', flex: 1, menuDisabled: true},
                // {text: '账号', dataIndex: 'workNumber', width: 100, menuDisabled: true},
                {text: '部门', dataIndex: 'userDepartment', flex: 1, menuDisabled: true},
                {text: '工时文档链接', dataIndex: 'hourLink', flex: 1, menuDisabled: true},
                {text: '审批状态', dataIndex: 'docState', flex: 1, menuDisabled: true},
                {text: '产品线', dataIndex: 'productLine', flex: 1, menuDisabled: true},
                {text: '项目编码', dataIndex: 'projectNumber', flex: 1, menuDisabled: true},
                {text: '项目名称', dataIndex: 'projectName', flex: 1, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目来源', dataIndex: 'projectSource', flex: 1, menuDisabled: true},
                {text: '规划项目名称', dataIndex: 'planningProjectName', flex: 1, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目阶段', dataIndex: 'projectPhase', flex: 1, menuDisabled: true},
                {text: '项目活动', dataIndex: 'activityName', flex: 1, menuDisabled: true},
                {text: '工作性质', dataIndex: 'natureOfWork', flex: 1.5, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '工时', dataIndex: 'manHour', flex: 0.5, menuDisabled: true},
                {text: '工作内容', dataIndex: 'manJobContent', flex: 3, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
            ]
        });


        var singleUserQueryPendingForm = {
            xtype: 'form',
            id: 'mainPendingForm',
            width: '99%',
            // title: '个人工时统计',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [//第*行
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '10 5 0 5', labelWidth: 100, border: false, padding: 5},
                    items: [
                        {
                            xtype: 'combobox',
                            fieldLabel: '部门名称',
                            // margin: '0 0 0 20',
                            labelWidth: 70,
                            store: departmentStorePending,
                            queryMode: 'local',
                            displayField: 'name',
                            valueField: 'name',
                            id: 'departmentNamePending',
                            name: 'departmentNamePending',
                        },{
                            xtype: 'combobox',
                            fieldLabel: '用户名称',
                            id: 'userNamePending',
                            name: 'userNamePending',
                            store: allUserStore_projectPlanPending,
                            labelWidth: 70,
                            typeAhead: true,
                            triggerAction: 'all',
                            queryMode: 'local',
                            displayField: 'userFullName',
                            valueField: 'no',
                            forceSelection: true,
                            allowBlank: true,
                            anyMatch: true
                        },
                        {
                            xtype: 'combobox',
                            fieldLabel: '项目名称',
                            // margin: '0 0 0 20',
                            id: 'projectPendingName',
                            name: 'projectPendingName',
                            store: projectPendingStore,
                            labelWidth: 70,
                            typeAhead: true,
                            triggerAction: 'all',
                            queryMode: 'local',
                            displayField: 'name',
                            valueField: 'name',
                            forceSelection: true,
                            allowBlank: true,
                            anyMatch: true
                        },{
                            xtype: 'textfield',
                            // margin: '0 0 0 20',
                            labelWidth: 70,
                            fieldLabel: '项目编号',
                            name: 'projectPendingNumber',
                            id: 'projectPendingNumber',
                        },
                        {
                            xtype: 'combobox',
                            fieldLabel: '产品线',
                            // margin: '0 0 0 20',
                            id: 'productLinePending',
                            name: 'productLinePending',
                            store: productLineStorePending,
                            labelWidth: 70,
                            typeAhead: true,
                            triggerAction: 'all',
                            queryMode: 'local',
                            displayField: 'name',
                            valueField: 'name',
                            forceSelection: true,
                            allowBlank: true,
                            anyMatch: true
                        },
                        {
                            xtype: 'combobox',
                            // margin: '0 0 0 20',
                            store: ['是','否'],
                            labelWidth: 100,
                            forceSelection: true,//强制从列表中选择
                            fieldLabel: '是否通过审批',
                            name: 'isPendingApprove',
                            id: 'isPendingApprove',
                        }
                    ]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '10 5 0 5', labelWidth: 100, border: false, padding: 5},
                    items: [
                        {
                            xtype: 'datefield',
                            fieldLabel: '开始日期',
                            id: 'datePendingStart',
                            format: 'Y-m-d',
                            name: 'dateStart',
                            // margin: '0 0 0 20',
                            value: Ext.util.Format.date(Ext.Date.add(Ext.Date.getFirstDateOfMonth(new Date()), Ext.Date.MONTH, 0), "Y-m-d"),
                            labelWidth: 70,
                            // width: 220
                        },{
                            xtype: 'datefield',
                            fieldLabel: '结束日期',
                            id: 'datePendingEnd',
                            format: 'Y-m-d',
                            name: 'dateEnd',
                            // margin: '0 0 0 20',
                            value: new Date(),
                            labelWidth: 70,
                            // width: 220
                        },
                        {
                            iconCls: 'icon icon-search',
                            xtype: 'button',
                            id: "queryUserWorkHoursCountPending",
                            // margin: '0 0 0 20',
                            text: '查询',
                            handler : function () {
                                getManReportPending();
                            }
                        }, {
                            iconCls: 'icon icon-store-export',
                            xtype: 'button',
                            id: "exportWorkHoursCountDetailsPending",
                            // margin: '0 0 0 20',
                            text: '导出',
                            handler : function() {
                                exportManReportPending();
                            },
                            scope : this
                        }
                        , {
                            iconCls: 'icon icon-store-export',
                            xtype: 'button',
                            id: "exportWorkHoursCountDetailsSelectPending",
                            // margin: '0 0 0 20',
                            text: '导出选择的数据',
                            handler : function() {
                                let selectionArr = singleUserQueryPendingGrid.getSelectionModel().getSelection();
                                if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                    Ext.Msg.alert("提示", "请选择要导出的数据");
                                    return;
                                }
                                //数据组装
                                let workReportId = new Array();
                                Ext.each(selectionArr, function (record) {
                                    workReportId.push(record.data['masterId'])
                                });
                                let workReportItemId = new Array();
                                Ext.each(selectionArr, function (record) {
                                    workReportItemId.push(record.data['id'])
                                });
                                // 使用 Set 去除重复的数据
                                workReportId = Array.from(new Set(workReportId));
                                exportManReportSelectPending(workReportId,workReportItemId);
                                // alert(workReportId)
                            },
                            scope : this
                        }
                        , {
                            xtype: 'label',
                            id: "userWorkHoursCountLablePending",
                            text: '',
                        }
                    ]
                }

                , singleUserQueryPendingGrid]
        };

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [singleUserQueryPendingForm];

        this.callParent();



    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('projectPendingStore').load({
                params: {
                    workNumber: userName
                },
                callback: function (records, operation, success) {

                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }else {
                        var data = [{ name: '部门工作'}];
                        var sta = Ext.getStore('projectStore')
                        sta.add(data);
                    }
                }
            });

            Ext.getStore('departmentStorePending').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            }),
                Ext.getStore('productLineStorePending').load({
                    callback: function (records, operation, success) {
                        if (!success) {
                            if (typeof (operation.error) == 'string') {
                                alert(operation.error);
                            } else {
                                alert('查询超时！请重试！')
                            }
                        }
                    }
                });

        }
    },


});

function exportManReportPending() {
    var data = getSearchDataPending();

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportNomReport', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "个人工时"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(data)
    );
}

function getSearchDataPending() {
    var data = {
        workNumber: Ext.getCmp("userNamePending").getValue(),
        projectName:Ext.getCmp("projectPendingName").getValue(),
        projectNumber:Ext.getCmp("projectPendingNumber").getValue(),
        dateStart:Ext.getCmp("datePendingStart").getValue(),
        dateEnd:Ext.getCmp("datePendingEnd").getValue(),
        isApprove:Ext.getCmp("isPendingApprove").getValue(),
        queryType:"pending",

        departmentName:Ext.getCmp("departmentNamePending").getValue(),
        productLine:Ext.getCmp("productLinePending").getValue(),
    };
    return data;
}


function getManReportPending() {
    var data = getSearchDataPending();
    Ext.getStore('singleUserQueryPendingStore').load({
        params: {
            data:Ext.encode(data)
        },
        callback: function (records, operation, success) {
            if (!success) {
                if(typeof(operation.error)=='string'){
                    alert(operation.error);
                }else {
                    alert('查询超时！请重试！')
                }
            }else {
                getSumHourPending();
            }
        },
    })
}

function getSumHourPending() {
    var grid =Ext.getCmp('singleUserQueryPendingGrid').getStore();

    var sum = 0;

    for(var i = 0 ;i< grid.getCount(); i++){
        if(grid.getAt(i).get('manHour')) {
            sum = sum + parseFloat(grid.getAt(i).get('manHour'));
        }
    }
    let s = sum.toFixed(1);
    console.log(s)
    Ext.getCmp("userWorkHoursCountLablePending").setText("工时合计:"+s+"小时");
    /*var data = getSearchData();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getSumHour',
        method: "POST",
        params: {
            data:Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                Ext.getCmp("userWorkHoursCountLable").setText("工时合计:"+obj['sumHour']+"小时");
            }
        },
        failure: function (response, opts) {
            alert('错误：请检查网络！');
        }
    });*/
}

function exportManReportSelectPending(workReportId,workReportItemId) {
    var data = {
        workReportId: workReportId,
        workReportItemId: workReportItemId
    };

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportNomReportSelect', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "待我审批的报工"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(data)
    );
}
