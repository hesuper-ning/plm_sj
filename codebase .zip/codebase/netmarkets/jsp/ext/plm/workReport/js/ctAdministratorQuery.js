/**
 * 管理员全局管理
 * 描述：管理员查看所有用户工时统计
 */
Ext.define('PLM.view.administratorQuery', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.administratorQuery',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'workReport-administratorQuery',
        in_objectDesc: '管理员全局管理',
    },
    id: 'administratorQuery',
    initComponent: function () {
        var me = this;


        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                 'name'
            ],
            idProperty: 'name'
        });


        // 项目下拉
        var projectStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getProjects',
                reader: {
                    type: 'json',
                    root: 'items'
                }
            },
            autoLoad: false
        });

        Ext.define('administratorQueryGridModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'userName', 'userDepartment', 'workNumber', 'creatorDate', 'HourLink', 'productLine',
                'projectNumber', 'projectName', 'activityName','projectPhase','manHour','manJobContent','natureOfWork',
            'hourLink','planningProjectName','projectSource'],
            idProperty: 'id'
        });

        var administratorQueryStore = Ext.create('PLM.store.MockItemStore', {
            id: 'administratorQueryStore',
            model: 'administratorQueryGridModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/workReport/getManReport',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var administratorQueryGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('administratorQueryStore'),
            id: 'administratorQueryGrid',
            titleAlign: 'center',
            //forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '98%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer',width:60, align: 'center'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '日期', dataIndex: 'creatorDate', width: 100, menuDisabled: true},
                {text: '姓名', dataIndex: 'userName', width: 100, menuDisabled: true},
                // {text: '账号', dataIndex: 'workNumber', width: 100, menuDisabled: true},
                {text: '部门', dataIndex: 'userDepartment', width: 100, menuDisabled: true},
                {text: '审批状态', dataIndex: 'docState', width: 100, menuDisabled: true},
                {text: '产品线', dataIndex: 'productLine', width: 100, menuDisabled: true},
                {text: '项目编码', dataIndex: 'projectNumber', width: 100, menuDisabled: true},
                {text: '项目名称', dataIndex: 'projectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目来源', dataIndex: 'projectSource', width: 100, menuDisabled: true},
                {text: '规划项目名称', dataIndex: 'planningProjectName', width: 100, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '项目阶段', dataIndex: 'projectPhase', width: 100, menuDisabled: true},
                {text: '项目活动', dataIndex: 'activityName', width: 100, menuDisabled: true},
                {text: '工时', dataIndex: 'manHour', width: 60, menuDisabled: true},
                {text: '工作内容', dataIndex: 'manJobContent', width: 410, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '工作性质', dataIndex: 'natureOfWork', width: 410, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '工时文档链接', dataIndex: 'hourLink', width: 100, menuDisabled: true},
            ],
            /*tbar:[
                {
                xtype: 'combobox',
                fieldLabel: '项目名称',
                margin: '0 0 0 20',
                id: 'projectName',
                name: 'projectName',
                store: projectStore,
                labelWidth: 70,
                typeAhead: true,
                triggerAction: 'all',
                queryMode: 'local',
                displayField: 'name',
                valueField: 'name',
                forceSelection: true,
                allowBlank: true,
                anyMatch: true
            },{
                xtype: 'textfield',
                labelWidth: 70,
                fieldLabel: '项目编号',
                name: 'projectNumber',
                id: 'projectNumber',
            },{
                xtype: 'combobox',
                store: ['是','否'],
                labelWidth: 80,
                forceSelection: true,//强制从列表中选择
                fieldLabel: '是否通过审批',
                name: 'isApprove',
                id: 'isApprove',
            },{
                xtype: 'datefield',
                fieldLabel: '开始日期',
                id: 'dateStart',
                format: 'Y-m-d',
                name: 'dateStart',
                margin: '0 0 0 20',
                value: Ext.util.Format.date(Ext.Date.add(Ext.Date.getFirstDateOfMonth(new Date()), Ext.Date.MONTH, 0), "Y-m-d"),
                labelWidth: 70,
                width: 220
            },{
                xtype: 'datefield',
                fieldLabel: '结束日期',
                id: 'dateEnd',
                format: 'Y-m-d',
                name: 'dateEnd',
                margin: '0 0 0 20',
                value: new Date(),
                labelWidth: 70,
                width: 220
            }, {
                iconCls: 'icon icon-search',
                xtype: 'button',
                id: "queryUserWorkHoursCount",
                margin: '0 0 0 20',
                text: '查询',
                handler : function () {
                    getManReport();
                }
            }, {
                iconCls: 'icon icon-store-export',
                xtype: 'button',
                id: "exportWorkHoursCountDetails",
                margin: '0 0 0 20',
                text: '导出',
                handler : function() {
                    exportManReport();
                },
                scope : this
            }, {
                xtype: 'label',
                id: "userWorkHoursCountLable",
                text: '',
            }]*/
        });

        var administratorQueryForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            title: '全局管理',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [//第*行
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '10 5 0 20', labelWidth: 100, border: false, padding: 5},
                    items: [{
                        xtype: 'combobox',
                        margin: '0 0 0 20',
                        multiSelect: false,
                        valueField: 'no',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        //editable: false,
                        forceSelection: true,
                        triggerAction: 'all',
                        width: 250,
                        fieldLabel: '用户名称:',
                        store: allUserStore_projectPlan,
                        name: 'userName',
                        id: 'userName',
                    },
                        {
                            xtype: 'combobox',
                            fieldLabel: '项目名称',
                            margin: '0 0 0 20',
                            id: 'projectName',
                            name: 'projectName',
                            store: projectStore,
                            labelWidth: 70,
                            typeAhead: true,
                            triggerAction: 'all',
                            queryMode: 'local',
                            displayField: 'name',
                            valueField: 'name',
                            forceSelection: true,
                            allowBlank: true,
                            anyMatch: true
                        },{
                            xtype: 'textfield',
                            margin: '0 0 0 20',
                            labelWidth: 70,
                            fieldLabel: '项目编号',
                            name: 'projectNumber',
                            id: 'projectNumber',
                        },{
                            xtype: 'combobox',
                            margin: '0 0 0 20',
                            store: ['是','否'],
                            labelWidth: 90,
                            forceSelection: true,//强制从列表中选择
                            fieldLabel: '是否通过审批',
                            name: 'isApprove',
                            id: 'isApprove',
                            width: 150
                        },{
                            xtype: 'datefield',
                            fieldLabel: '开始日期',
                            id: 'dateStart',
                            format: 'Y-m-d',
                            name: 'dateStart',
                            margin: '0 0 0 20',
                            value: Ext.util.Format.date(Ext.Date.add(Ext.Date.getFirstDateOfMonth(new Date()), Ext.Date.MONTH, 0), "Y-m-d"),
                            labelWidth: 70,
                            width: 220
                        },{
                            xtype: 'datefield',
                            fieldLabel: '结束日期',
                            id: 'dateEnd',
                            format: 'Y-m-d',
                            name: 'dateEnd',
                            margin: '0 0 0 20',
                            value: new Date(),
                            labelWidth: 70,
                            width: 220
                        }
                    ]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    defaults: {margin: '10 5 0 20', labelWidth: 100, border: false, padding: 5},
                    items: [
                        {
                            iconCls: 'icon icon-search',
                            xtype: 'button',
                            id: "queryUserWorkHoursCount",
                            margin: '0 0 0 20',
                            text: '查询',
                            handler : function () {
                                getManReport();
                            }
                        }, {
                            iconCls: 'icon icon-store-export',
                            xtype: 'button',
                            id: "exportWorkHoursCountDetails",
                            margin: '0 0 0 20',
                            text: '导出',
                            handler : function() {
                                exportManReport();
                            },
                            scope : this
                        }

                        , {
                            iconCls: 'icon icon-store-export',
                            xtype: 'button',
                            id: "exportWorkHoursCountDetailsSelect",
                            margin: '0 0 0 20',
                            text: '导出选择的数据',
                            handler : function() {
                                let selectionArr = administratorQueryGrid.getSelectionModel().getSelection();
                                if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                    Ext.Msg.alert("提示", "请选择要导出的数据");
                                    return;
                                }
                                //数据组装
                                let workReportId = new Array();
                                Ext.each(selectionArr, function (record) {
                                    workReportId.push(record.data['masterId'])
                                });
                                let workReportItemId = new Array();
                                Ext.each(selectionArr, function (record) {
                                    workReportItemId.push(record.data['id'])
                                });
                                // 使用 Set 去除重复的数据
                                workReportId = Array.from(new Set(workReportId));
                                exportManReportSelect(workReportId,workReportItemId);
                                // alert(workReportId)
                            },
                            scope : this
                        }

                        , {
                            xtype: 'label',
                            id: "userWorkHoursCountLable",
                            text: '',
                        }
                    ]
                }

                , administratorQueryGrid]
        };

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [administratorQueryForm];

        this.callParent();



    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('projectStore').load({
                callback: function (records, operation, success) {

                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }else {
                        var data = [{ name: '部门工作'}];
                        var sta = Ext.getStore('projectStore')
                        sta.add(data);
                    }
                }
            });

        }
    },


});

function exportManReport() {
    var data = getSearchData();

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportNomReport', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "全局数据"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(data)
    );
}

function getSearchData() {
    var data = {
        workNumber: Ext.getCmp("userName").getValue(),
        projectName:Ext.getCmp("projectName").getValue(),
        projectNumber:Ext.getCmp("projectNumber").getValue(),
        dateStart:Ext.getCmp("dateStart").getValue(),
        dateEnd:Ext.getCmp("dateEnd").getValue(),
        isApprove:Ext.getCmp("isApprove").getValue(),
        type:'missedWorkReport',
    };
    return data;
}


function getManReport() {
    var data = getSearchData();
    Ext.getStore('administratorQueryStore').load({
        params: {
            data:Ext.encode(data)
        },
        callback: function (records, operation, success) {
            if (!success) {
                if(typeof(operation.error)=='string'){
                    alert(operation.error);
                }else {
                    alert('查询超时！请重试！')
                }
            }else {
                getSumHour();
            }
        },
    })
}

function getSumHour() {
    var grid =Ext.getCmp('administratorQueryGrid').getStore();

    var sum = 0;

    for(var i = 0 ;i< grid.getCount(); i++){
        if(grid.getAt(i).get('manHour')){
            sum = sum + parseFloat(grid.getAt(i).get('manHour'));
        }
    }
    let s = sum.toFixed(1);
    console.log(s)
    Ext.getCmp("userWorkHoursCountLable").setText("工时合计:"+s+"小时");
    /*var data = getSearchData();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/getSumHour',
        method: "POST",
        params: {
            data:Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                Ext.getCmp("userWorkHoursCountLable").setText("工时合计:"+obj['sumHour']+"小时");
            }
        },
        failure: function (response, opts) {
            alert('错误：请检查网络！');
        }
    });*/
}

function exportManReportSelect(workReportId,workReportItemId) {
    var data = {
        workReportId: workReportId,
        workReportItemId: workReportItemId
    };

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/workReport/exportNomReportSelect', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "个人工时"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(data)
    );
}


