/**
 * 部门工时统计
 * 描述：管理员查看管理部门下的用户工作日志
 */
Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'workReport-departmentManagerQuery',
        in_objectDesc: '部门工时统计',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var projectStore = Ext.create('Ext.data.Store', {
            fields: ['abbr', 'name'],
            data : [
                {"abbr":"A项目", "name":"A项目"},
                {"abbr":"B项目", "name":"B项目"},
                {"abbr":"C项目", "name":"C项目"}
                //...
            ]
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            //margin: '0 5 5 5',
            forceFit: true,
            autoWidth: true,
            //border:false,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '日期', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '姓名', dataIndex: 'data2', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '工号', dataIndex: 'data3', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '部门', dataIndex: 'data4', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '产品线', dataIndex: 'data5', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '项目编码', dataIndex: 'data6', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '项目名称', dataIndex: 'data7', width: 150, editor: 'textfield', menuDisabled: true},
                {text: '项目阶段', dataIndex: 'data8', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '项目活动', dataIndex: 'data9', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '工时', dataIndex: 'data10', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '工作内容', dataIndex: 'data11', width: 500, editor: 'textarea', menuDisabled: true}
            ]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            title:'部门员工工时统计',
            titleAlign: 'center',
            hideLabel: true,
            frame: false,
            //margin: '20 10 20 10',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{//第*行
                xtype: 'panel',
                layout: 'hbox',
                border:false,
                defaults: {margin: '5 20 0 0', labelWidth: 100,border:false,padding:5},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '部门名称',
                    margin: '0 0 0 20',
                    id: 'departmentName',
                    name: 'departmentName',
                    labelWidth: 70,
                },{
                    xtype: 'textfield',
                    fieldLabel: '用户名称',
                    margin: '0 0 0 20',
                    id: 'userName',
                    name: 'userName',
                    labelWidth: 70,
                },{
                    xtype: 'combobox',
                    fieldLabel: '项目名称',
                    labelWidth: 70,
                    margin: '0 0 0 20',
                    store: projectStore,
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'abbr'
                }]
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                border:false,
                defaults: {margin: '10 5 0 20', labelWidth: 100,border:false,padding:5},
                items: [{
                    xtype: 'datefield',
                    fieldLabel: '开始日期',
                    id: 'dateStart',
                    format: 'Y-m-d',
                    name: 'dateStart',
                    //value: new Date(),
                    labelWidth: 70,
                    width: 220
                },{
                    xtype: 'datefield',
                    fieldLabel: '结束日期',
                    id: 'dateEnd',
                    format: 'Y-m-d',
                    name: 'dateEnd',
                    //value: new Date(),
                    labelWidth: 70,
                    width: 220
                }, {
                    iconCls: 'icon icon-search',
                    xtype: 'button',
                    id: "queryUserWorkHoursCount",
                    text: '查询'
                }, {
                    iconCls: 'icon icon-store-export',
                    xtype: 'button',
                    id: "exportWorkHoursCountDetails",
                    text: '导出',
                },  {
                    xtype: 'label',
                    id: "userWorkHoursCountLable",
                    text: '工时统计：90',
                }]
            },mockExampleGrid]
        };



/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

