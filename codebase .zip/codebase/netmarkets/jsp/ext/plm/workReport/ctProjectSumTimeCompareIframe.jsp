<%@ page language="java" import="java.util.*"  contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
%>

<iframe id="example" src="netmarkets/jsp/ext/plm/workReport/ctProjectSumTimeCompare.jsp?oid=<%=oid%>" style="width:98%;height:740px" ></iframe>