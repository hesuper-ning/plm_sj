<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        String userName = CtUserUtil.getCurrentUserAccountName();
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/packages/charts/classic/charts.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js"></script>
    <script type="text/javascript" src="js/ctSingleUserQuery.js?_dc=<%=System.currentTimeMillis()%>"></script>

    <script type="text/javascript" src="js/ctSingleUserReceivedQuery.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctSingleUserPendingQuery.js?_dc=<%=System.currentTimeMillis()%>"></script>

    <script type="text/javascript" src="js/echarts.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>

    //当前用户
    var userName = "<%=userName%>";

    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [ {
                region: 'center',
                //xtype:'DataAuditAnalysisPanel'
                items:[{
                    xtype:'panel',
                    border:false,
                    items:[{
                        xtype:'tabpanel',
                        activeTab: 0,
                        items:[{
                            title: '<font style="font-size:12px">我的工时统计</font>',
                            xtype:'singleUserQuery'
                        },{
                            title: '<font style="font-size:12px">我收到的报工</font>',
                            xtype:'singleUserReceivedQuery'
                        },{
                            title: '<font style="font-size:12px">待我审批的报工</font>',
                            xtype:'singleUserPendingQuery'
                        }
                        ]//~End of tabpanel items
                    }]
                }]//~End of center region items
            }]//~End of viewPort items
        });

        // Ext.create('Ext.container.Viewport', {
        //     layout: 'border',
        //     items: [{
        //         region: 'center',
        //         xtype: 'ctSingleUserQueryPanel'
        //     }]
        // });
    });
</script>
</body>
</html>