<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="ext.plm.workReport.config.CtWorkReportProperties" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workitem = (WorkItem)rf.getReference(oid).getObject();
        WTDocument doc = (WTDocument)workitem.getPrimaryBusinessObject().getObject();
        String docBranchId = doc.getBranchIdentifier()+"";
        //编辑权限判断
        WfAssignedActivity activity = (WfAssignedActivity)workitem.getSource().getObject();
        String actName = activity.getName();

        boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workitem,
                CtWorkReportProperties.getProperty("workReport_allowEdit_roles"));
        System.out.println(allowEdit+actName);
        if (!actName.equals("三江电子-报工流程-重新提交")){
            allowEdit = false;
            System.out.println("审核");
        }
        System.out.println(">>>>>>>>>>allowEdit:"+allowEdit+"actName:"+actName);
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctWorkReportProcess.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <%--<script type="text/javascript" src="js/ctWorkReportFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>--%>
</head>

<body>
<script>
    var branchId = "<%=docBranchId%>";
    var allowEdit = false;
    <%if(allowEdit){ %>
        allowEdit = true;
    <%}%>

    var workDate = "";
    var masterId = "";
    var approver = "";

    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'WorkReport'
            }]
        });
    });
</script>
</body>
</html>