//此类定义了可重用的对象
//=======对象列表=================
//1.User Combobox : PLM.common.CtAllUserCombo



//===========开始  1.CtAllUserCombo 定义==================

Ext.define('PLM.common.CtAllUserStore',{
    extend:'Ext.data.Store',
    alias:'widget.CtAllUserStore',
    fields:['userFullName'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/common/getAllUserNames',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'items',
            //idProperty: 'id',
            messageProperty: 'error'
        }
    }),
    autoLoad:true
});

Ext.define('PLM.common.CtAllUserCombo',{
    extend:'Ext.form.field.ComboBox',
    alias:'widget.CtAllUserCombo',
    typeAhead: true,
    triggerAction: 'all',
    queryMode: 'local',
    displayField: 'userFullName',
    valueField: 'userFullName',
    forceSelection:true,
    allowBlank : false,
    anyMatch: true
});

//hr集成
Ext.define('PLM.hr.CtAllUserStore',{
    extend:'Ext.data.Store',
    alias:'widget.CtAllUserStore',
    fields:['userFullName','no'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/hr/getAllUser',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            //idProperty: 'id',
            messageProperty: 'error'
        }
    }),
    autoLoad:true
});

Ext.define('PLM.hr.CtAllUserCombo',{
    extend:'Ext.form.field.ComboBox',
    alias:'widget.CtAllUserCombo',
    typeAhead: true,
    triggerAction: 'all',
    queryMode: 'local',
    displayField: 'userFullName',
    valueField: 'userFullName',
    forceSelection:true,
    allowBlank : true,
    anyMatch: true
});

//===========结束  1.CtAllUserCombo 定义==================

//===========开始  2.CtContainerUserCombo 定义==================
//在创建store后，需求执行store.load方法设置参数 例如：params:{containerOid:OR:wt.inf.library.WTLibrary:378816},
Ext.define('PLM.common.CtContainerUserStore',{
    extend:'Ext.data.Store',
    alias:'widget.CtContainerUserStore',
    fields:['userFullName'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/common/getCtContainerUserNames',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'items',
            //idProperty: 'id',
            messageProperty: 'error'
        }
    }),
    autoLoad:false
});

Ext.define('PLM.common.CtContainerUserCombo',{
    extend:'Ext.form.field.ComboBox',
    alias:'widget.CtContainerUserCombo',
    typeAhead: true,
    triggerAction: 'all',
    queryMode: 'local',
    displayField: 'userFullName',
    valueField: 'userFullName',
    forceSelection:true,
    allowBlank : false,
    anyMatch: true
});

//===========结束  2.CtContainerUserCombo 定义==================



