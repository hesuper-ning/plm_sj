(function() {
    function getQueryParam(name, queryString) {
        var match = RegExp(name + '=([^&]*)').exec(queryString || location.search);
        return match && decodeURIComponent(match[1]);
    }

    function hasOption(opt) {
        var s = window.location.search;
        var re = new RegExp('(?:^|[&?])' + opt + '(?:[=]([^&]*))?(?:$|[&])', 'i');
        var m = re.exec(s);

        return m ? (m[1] === undefined ? true : m[1]) : false;
    }

    var scriptTags = document.getElementsByTagName('script'),
        defaultTheme = 'neptune',
        defaultRtl = false,
        i = scriptTags.length,
        requires = [
            'Ext.toolbar.Toolbar',
            'Ext.form.field.ComboBox',
            'Ext.form.FieldContainer',
            'Ext.form.field.Radio'

        ],
        defaultQueryString, src, theme, rtl;

    while (i--) {
        src = scriptTags[i].src;
        if (src.indexOf('include-ext.js') !== -1) {
            defaultQueryString = src.split('?')[1];
            if (defaultQueryString) {
                defaultTheme = getQueryParam('theme', defaultQueryString) || defaultTheme;
                defaultRtl = getQueryParam('rtl', defaultQueryString) || defaultRtl;
            }
            break;
        }
    }

    Ext.themeName = theme = getQueryParam('theme') || defaultTheme;

    rtl = getQueryParam('rtl') || defaultRtl;

    if (rtl.toString() === 'true') {
        requires.push('Ext.rtl.*');
        Ext.define('Ext.GlobalRtlComponent', {
            override: 'Ext.AbstractComponent',
            rtl: true
        });
    }

    Ext.require(requires);

    Ext.onReady(function() {
        Ext.getBody().addCls(Ext.baseCSSPrefix + 'theme-' + Ext.themeName);

        if (Ext.isIE6 && theme === 'neptune') {
            Ext.Msg.show({
                title: 'Browser Not Supported',
                msg: 'The Neptune theme is not supported in IE6.',
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.WARNING
            });
        }

        if (hasOption('nocss3')) {
            Ext.supports.CSS3BorderRadius = false;
            Ext.getBody().addCls('x-nbr x-nlg');
        }
        function download() {
            if(controll){
                window.location.href = url;
            }else{
                window.open(url);
            }
        }

        var toolbar;

        setTimeout(function() {
            toolbar = Ext.widget({
                xtype: 'toolbar',
                border: true,
                rtl: false,
                margin: '660 500 0 600',
                id: 'options-toolbar',
                floating: true,
                fixed: true,
                // preventFocusOnActivate: true,
                draggable: {
                    constrain: true
                },
                items: [{  xtype : 'radiogroup',
                    fieldLabel : '是否显示PDT汇总数据',
                    margin: '10 0 0 10',
                    // width: 285,
                    labelWidth: 160,
                    name:'radioPdt',
                    items : [{
                        boxLabel : '是',
                        name:'radioPdt',
                        inputValue : '1',
                        handler: function () {

                        }
                    }, {
                        boxLabel : '否',
                        name:'radioPdt',
                        inputValue : '0',
                        checked:true,
                        handler: function () {

                        }
                    }]
                },{  xtype : 'radiogroup',
                    fieldLabel : '是否显示项目类型汇总数据',
                    margin: '10 0 0 10',
                    labelWidth: 170,
                    name:'radioType',
                    items : [{
                        boxLabel : '是',
                        name:'radioType1',
                        inputValue : '1',
                        handler: function () {

                        }
                    }, {
                        boxLabel : '否',
                        name:'radioType1',
                        inputValue : '0',
                        checked:true,
                        handler: function () {

                        }
                    }]
                }, {
                    xtype: 'button',
                    rtl: false,
                    hidden: !(Ext.repoDevMode || location.href.indexOf('qa.sencha.com') !== -1),
                    enableToggle: true,
                    pressed: rtl,
                    text: 'RTL',
                    margin: '0 5 0 0',
                    listeners: {
                        toggle: function(btn, pressed) {
                            if (pressed) {
                                setParam({ rtl: true });
                            } else {
                                removeParam('rtl');
                            }
                        }
                    }
                }, {
                    xtype: 'tool',
                    type: 'close',
                    rtl: false,
                    handler: function() {
                        toolbar.destroy();
                    }
                }],

                // Extra constraint margins within default constrain region of parentNode
                constraintInsets: '0 -' + (Ext.getScrollbarSize().width + 4) + ' 0 0'
            });
            toolbar.show();
            toolbar.alignTo(
                document.body,
                Ext.optionsToolbarAlign || 'tr-tr',
                [
                    (Ext.getScrollbarSize().width + 400) * (Ext.rootHierarchyState.rtl ? 1 : -1),
                    -(document.body.scrollTop || document.documentElement.scrollTop)
                ]
            );

            var constrainer = function() {
                toolbar.doConstrain();
            };

            Ext.EventManager.onWindowResize(constrainer);
            toolbar.on('destroy', function() {
                Ext.EventManager.removeResizeListener(constrainer);
            });
        }, 100);

    });
})();