Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'mockExampleForm',
        in_objectDesc: '定制的Form表单',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            margin: '20 10 20 10',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '项目编号', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {
                    text: '项目名称', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true,
                    items: {
                        xtype: 'textfield',
                        flex: 1,
                        margin: 2,
                        enableKeyEvents: true,
                        listeners: {
                            keyup: function () {
                                var store = Ext.getStore('mockExampleStore');
                                store.clearFilter();
                                if (this.value) {
                                    store.filter({
                                        property: 'data2',
                                        value: this.value,
                                        anyMatch: true,
                                        caseSensitive: false
                                    });
                                }
                            },
                            buffer: 500
                        }
                    }
                },
                {text: '产品经理', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '项目经理', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '当前阶段', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '延迟天数', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '进度偏差', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险状态', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true}
            ]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'textfield',
                fieldLabel: '标题1',
                padding: '20 15 10 20',
                id: 'att1',
                name: 'att1',
                width: 450,
                listeners: {
                    blur: function (e) {
                        saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    }
                }
            }, {
                xtype: 'textfield',
                fieldLabel: '标题2',
                padding: '0 15 20 20',
                id: 'att2',
                name: 'att2',
                width: 450,
                listeners: {
                    blur: function (e) {
                        saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    }
                }
            }, mockExampleGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

