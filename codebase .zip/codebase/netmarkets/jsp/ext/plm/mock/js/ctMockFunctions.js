/**
 *
 * @param objectKey 表头key
 * @param objectDesc 表描述
 * @param callbackFn 回调函数
 */
function createMockItemData(objectKey,objectDesc,callbackFn) {
    saveMockItemData(objectKey,objectDesc
        ,undefined,undefined,undefined,callbackFn);
}

/**
 * 保存列表中的一个属性(单元格）
 * @param objectKey 表头key
 * @param objectDesc 表描述
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(objectKey,objectDesc,itemId,dataKey,dataValue,callbackFn){

        var returnItemId = undefined;
        var mockRec = {
            objectKey:objectKey,
            objectDesc:objectDesc,
            itemId:itemId,
            dataKey:dataKey,
            dataValue:dataValue
        };

        Ext.Ajax.request({
            url: '/Windchill/ptc1/mock/saveMockItemData',
            params:{
                updateRecord:Ext.encode(mockRec)
            },
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj['success']){
                    returnItemId = obj['returnItemId']; //新增时有用
                    //回调函数，一般用于后台操作成功后刷新列表
                    if(callbackFn){
                        callbackFn();
                    }
                }else{
                    alert(obj['error']);
                }
            },
            failure: function(response, opts) {
                alert('错误：保存信息失败，请检查网络！!');
            }
        }); //~End of Ajax request
    return returnItemId;
}

/**
 * 删除一行数据
 * @param itemId
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 */
function deleteMockItem(deleteItems,callbackFn){

    //包装成array,以适应
    if(!(deleteItems instanceof Array)){
        alert('删除传入参数有错，请包装成Array对象后传入！');
        return;
    }

    Ext.Ajax.request({
        url: '/Windchill/ptc1/mock/deleteMockItems',
        params:{
            deleteItems:Ext.encode(deleteItems)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']){
                //回调函数，一般用于后台操作成功后刷新列表
                if(callbackFn){
                    callbackFn();
                }
            }else{
                alert(obj['error']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


/**
 * 保存表单中的一个属性(表单）
 * @param objectKey 表头key
 * @param objectDesc 表描述
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveObjectData(objectKey,objectDesc,dataKey,dataValue,callbackFn){

    var returnItemId = undefined;
    var mockRec = {
        objectKey:objectKey,
        objectDesc:objectDesc,
        dataKey:dataKey,
        dataValue:dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/mock/saveObjectData',
        params:{
            updateRecord:Ext.encode(mockRec)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']){
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if(callbackFn){
                    callbackFn();
                }
            }else{
                alert(obj['error']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}