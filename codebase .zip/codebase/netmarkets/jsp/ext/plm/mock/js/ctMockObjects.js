//此类定义了可重用的对象，包括右键菜单,store等 （注意，必须配合ctMockFunctions.js使用
//=======对象菜单=================
//1.MockItem Store 定义
//2.Context Menu 定义


//===========开始  1.MockItem Store 定义==================

Ext.define('PLM.store.MockItemStore',{
    extend:'Ext.data.Store',
    alias:'widget.MockItemStore',
    param_objectKey:'',//传入参数objectKey,（不成功）
    fields:['id','masterId','data1','data2','data3','data4','data5','data6','data7','data8','data9'
        ,'data10','data11','data12','data13','data14','data15','data16','data17','data18','data19'
        ,'data20','data21','data22','data23','data24','data25','data26','data27','data28','data29'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/mock/getItems',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'items',
            idProperty: 'id',
            messageProperty: 'error'
        }
    }),
  autoLoad:false
});

//===========结束  1.MockItem Store 定义==================

//===========开始  2.Context Menu 定义==================
Ext.define('PLM.mock.ContextMenu',{
    extend:'Ext.menu.Menu',
    alias:'widget.MockGridMenu',
    config:{
        param_grid: undefined,//传入参数，操作的Grid对象
        param_objectKey:undefined,//传入参数，Grid对象的表key
        param_objectDesc:undefined,//传入参数，Grid对象的表描述
    },
    initComponent:function(){

        if(!this.param_grid.getStore()){
            //通过getStore 判断传入的是否是grid对象
            alert('列表对象没有正确传入！无法生成右键菜单！');
            return;
        }
       // alert('inner param_objectKey='+this.param_objectKey+">>>param_objectDesc="+this.param_objectDesc);

        this.addAction = Ext.create('Ext.Action', {
            iconCls   : 'icon-add',  // Use a URL in the icon config
            text: '添加',
            scope:this,
            handler: function(widget, event) {
                var recordCount = this.param_grid.getStore().getCount();
                //用回调刷新列表
                var cStore = this.param_grid.getStore();
                var callbackFn = function(){
                    cStore.reload();//刷新列表
                }
                var returnItemId = createMockItemData(this.param_objectKey,this.param_objectDesc,callbackFn);
            }
        });


        this.deleteAction = Ext.create('Ext.Action', {
            iconCls: 'icon-delete',
            text: '删除',
            disabled: false,
            scope:this,
            handler: function(widget, event) {
                var deleteItems = new Array();
                var removedRecords = this.param_grid.getSelectionModel().getSelection();

                Ext.each(removedRecords,function(record){
                    deleteItems.push(record.data['id']);
                });
                //用回调刷新列表
                var cStore = this.param_grid.getStore();
                var callbackFn = function(){
                    cStore.reload();//刷新列表
                }
                deleteMockItem(deleteItems,callbackFn);
            }
        });

        this.items=[this.addAction,this.deleteAction];

        this.callParent();

    }//~End of initComponent
});


//===========结束  2.Context Menu 定义==================
