Ext.define('PLM.view.ctEcrApprovalRecordsTablePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctEcrApprovalRecordsTablePanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    height:775,
    // width:'90%',
    // anchor:'100%',
    collapsible: false,
    id: 'ctEcrApprovalRecordsTablePanel',
    initComponent: function (){


//===================================ECR==========================================

        //==================物料变更内容  (非以下字段修改，请将修改的"字段信息及值"在"变更描述中填写，“产品数据工程师收到ECA后手工修改)======
        //物料编码
        var partNumberARecordsECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3
        );
        //物料描述
        var partDescAfterARecordsECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3
        );
        //内部版本
        var internalVersionAfterARecordsECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3
        );
        //新增行
        var addARecordsECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3
        );
        //删除行
        var deleteARecordsECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3
        );
        //==================物料变更内容  (非以下字段修改，请将修改的"字段信息及值"在"变更描述中填写，“产品数据工程师收到ECA后手工修改)======


        //========================EBOM变更内容=======================================================================
        //父项编码
        var parentNumberEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //变更类型
        var changeTypeEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //变更前物料编码
        var partNumberBeforeEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //变更后物料编码
        var partNumberAfterEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //变更后分数
        var fractionAfterEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //变更后数量
        var quantityAfterEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //变更后位号
        var tagNumberAfterEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //变更后BOM备注
        var bomRemarkAfterEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //备注
        var remarksEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //新增行
        var addEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //删除行
        var deleteEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //复制
        var copyEBOMECR = isEditable(
            ebomCharge_node,mbomCharge_node,dateManageMajor_node,submit_change_request,formulate_MBOM_programme,product_data_engineer_confirm_info,design_change_initiation3
            ,mbom_change_manager,product_data_management_supervisor_review3
        );
        //下载导入模板
        var downloadEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //导入EBOM变更内容
        var uploadEBOMECR = isEditable(
            ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation3,product_data_management_supervisor_review3
        );
        //========================EBOM变更内容=======================================================================

        //========================MBOM变更内容=======================================================================
        //父项编码
        var parentNumberMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //变更类型
        var changeTypeMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //变更前物料编码
        var partNumberBeforeMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //变更后物料编码
        var partNumberAfterMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //变更后分数
        var fractionAfterMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //变更后数量
        var quantityAfterMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //变更后位号
        var tagNumberAfterMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //变更后BOM备注
        var bomRemarkAfterMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //备注
        var remarksMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //新增行
        var addMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //删除行
        var deleteMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //粘贴
        var pasteMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //下载导入模板
        var downloadMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //导入MBOM变更内容
        var uploadMBOMECR = isEditable(
            mbomCharge_node,dateManageMajor_node,formulate_MBOM_programme,product_data_engineer_confirm_info,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //========================MBOM变更内容=======================================================================

        //==================单个字段==========================================================================
        //产品型号
        var productModelSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //变更来源
        var changeSourceSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //变更原因描述
        var changeReasonSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //是否需要测试报告
        var needTestReportSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //不需要测试报告原因
        var noTestReportReasonSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //测试报告文件
        var testReportSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //测试报告文件添加文件
        var uploadImageSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //附件
        var annexSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //附件添加文件
        var uploadAnnexSingleFieldECR = isEditable(
            head_node,ebomCharge_node,dateManageMajor_node,submit_change_request,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2
            ,product_data_management_supervisor_review,design_change_initiation3,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
            ,design_change_initiation5,product_data_management_supervisor_review5
        );
        //==================单个字段==========================================================================

        //===================ECR03==================================================================
        //评审人
        var reviewerECR03 = isEditable(

        );
        //评审意见
        var reviewCommentECR03 = isEditable(
            product_engineering_manager_information_gathering,purchasing_manager_auditing,general_change_small_batch_verification_confirmation,pcn_upload
        );
        //===================ECR03==================================================================
        //===================ECR06==================================================================
        //评审人
        var reviewerECR06 = isEditable(

        );
        //评审意见
        var reviewCommentECR06 = isEditable(
            pm_node,tm_node,struTechRep_node,hwTechRep_node,swTechRep_node,qualityRep_node,pcRep_node,change_process_procurement_EMR,mcRep_node
        );
        //===================ECR03==================================================================
        //审批意见ECR04
        var ECR04ApprovalOpinionsECR04 = isEditable(
            preliminary_review_by_department_manager,department_manager_confirm_info,department_manager_review,department_manager_initial_review,department_manager_review3
        );
        //审批意见ECR05
        var ECR05ApprovalOpinionsECR05 = isEditable(
            dateManageMajor_node,product_data_engineer_confirm_info,product_data_management_supervisor_review,product_data_management_supervisor_review3,product_data_management_supervisor_review4
        );
        //审批意见ECR07
        var ECR07ApprovalOpinionsECR07 = isEditable(
            pdt_node,summary_of_ccb_review_comments
        );
        //审批意见ECR08
        var ECR08ApprovalOpinionsECR08 = isEditable(
            ccb_node
        );
        //审批意见ECR09
        var ECR09ApprovalOpinionsECR09 = isEditable(
            consistencyRisk_node,approved_by_the_certification_technical_leader,quick_change1_certification_TLR
        );
        //审批意见ECR10
        var ECR10ApprovalOpinionsECR10 = isEditable(
            consistencyRisk_node,approved_by_the_certification_technical_leader,quick_change1_certification_TLR
        );
        //===================================ECR==========================================



        var personLiableStore = new Ext.data.ArrayStore({
            id: 'personLiableStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var ebompersonLiableCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'ebompersonLiableCom',
            id: 'ebompersonLiableCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: personLiableStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });

        var mbompersonLiableCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'mbompersonLiableCom',
            id: 'mbompersonLiableCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: personLiableStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });

        var ecr03personLiableCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'ecr03personLiableCom',
            id: 'ecr03personLiableCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: personLiableStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });

        var ecr06personLiableCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'ecr06personLiableCom',
            id: 'ecr06personLiableCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: personLiableStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });



        // ================================================详细清单页面开始================================================================================
        Ext.define('showObjectInfoModel', {
            extend: 'Ext.data.Model',
            fields: [
                'objectNumber','version','name','status'
            ],
            idProperty: 'showObjectInfoModel'
        });

        var showObjectInfoStore = Ext.create('Ext.data.Store', {
            model: 'showObjectInfoModel',
            id: 'showObjectInfoStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/getObjectInfo?changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'showObjectInfoModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var showObjectInfoColumns = [
            {text: '编号', dataIndex: 'objectNumber', flex: 1,menuDisabled: true, editor: false,},
            {text: '视图', dataIndex: 'version',flex: 1, editor: false , menuDisabled: true},
            {text: '名称', dataIndex: 'objectName', flex: 1,menuDisabled: true, editor: false},
            {text: '状态', dataIndex: 'status', flex: 1,menuDisabled: true, editor: false}
        ];

        var showObjectInfoGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var showObjectInfoGrid = Ext.create('Ext.grid.Panel', {
            plugins: [showObjectInfoGridEditing],
            store: showObjectInfoStore,
            columns: showObjectInfoColumns,
            id:'showObjectInfoGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            // selType: 'checkboxmodel',
        });


        var showObjectInfo = Ext.create('Ext.Window', {
            id:'showObjectInfo',
            // title: '',
            width: 700,
            height: 340,
            autoHeight : true,
            closeAction: 'hide',
            // closable:false,
            constrain: true,
            modal:true,
            items:[showObjectInfoGrid]
        });
// ================================================详细清单页面结束================================================================================

        //========================================父项编码 开始================================
        Ext.define('parentNumberModel', {
            extend: 'Ext.data.Model',
            fields: ['partNumber','viewName'],
            idProperty: 'id'
        });

        var eBOMParentNumberStore = Ext.create('Ext.data.Store', {
            id: 'eBOMParentNumberStore',
            model: 'parentNumberModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/getParentNumber?changeRequestId='+changeRequestId+"&type=ebom",
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

        var eBOMParentNumberCombo =new Ext.form.field.ComboBox({
            forceSelection: false, //forceSelection 是否能够手填
            name: 'eBOMParentNumberCombo',
            id: 'eBOMParentNumberCombo',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore("eBOMParentNumberStore"),
            valueField: 'formInfo',
            displayField: 'formInfo',
        });

        var mBOMParentNumberStore = Ext.create('Ext.data.Store', {
            id: ' mBOMParentNumberStore',
            model: 'parentNumberModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/getParentNumber?changeRequestId='+changeRequestId+"&type=mbom",
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

        var mBOMParentNumberCombo =new Ext.form.field.ComboBox({
            forceSelection: false, //forceSelection 是否能够手填
            name: 'mBOMParentNumberCombo',
            id: 'mBOMParentNumberCombo',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore(" mBOMParentNumberStore"),
            valueField: 'formInfo',
            displayField: 'formInfo',
        });

        var changeType = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'changeTypeCombo',
            id: 'changeTypeCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '' },
                    { fullName: '增加' },
                    { fullName: '删除' },
                    { fullName: '修改' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName',
            tpl: getXTemplate('fullName')
        });

        //========================================父项编码 结束================================






        //==========================ECR审批记录单个字段赋值============================================
        setEcrSingleFieldValue('ECR04ApprovalOpinions','ECR04ApprovedBy',
            'ECR04ApprovalResults','ECR04ApprovalTime','ECR04ApprovalOpinions');
        setEcrSingleFieldValue('ECR05ApprovalOpinions','ECR05ApprovedBy',
            'ECR05ApprovalResults','ECR05ApprovalTime','ECR05ApprovalOpinions');
        setEcrSingleFieldValue('ECR07ApprovalOpinions','ECR07ApprovedBy',
            'ECR07ApprovalResults','ECR07ApprovalTime','ECR07ApprovalOpinions');
        setEcrSingleFieldValue('ECR08ApprovalOpinions','ECR08ApprovedBy',
            'ECR08ApprovalResults','ECR08ApprovalTime','ECR08ApprovalOpinions');
        setEcrSingleFieldValue('ECR09ApprovalOpinions','ECR09ApprovedBy',
            'ECR09ApprovalResults','ECR09ApprovalTime','ECR09ApprovalOpinions');
        setEcrSingleFieldValue('ECR10ApprovalOpinions','ECR10ApprovedBy',
            'ECR10ApprovalResults','ECR10ApprovalTime','ECR10ApprovalOpinions');

        //2. ECR_变更方案与更改对象 单个字段赋值
        setEcrSingleFieldValue('','SEApprovedBy',
            'SEApprovalResults','SEApprovalTime','SEApprovedBy');
        setEcrSingleFieldValue('','EBOMApprovedBy',
            'EBOMApprovalResults','EBOMApprovalTime','EBOMApprovedBy');
        setEcrSingleFieldValue('','MBOMApprovedBy',
            'MBOMApprovalResults','MBOMApprovalTime','MBOMApprovedBy');


        var singleFieldStore = Ext.create('Ext.data.Store', {
            model: '',
            id: 'singleFieldStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/searchSingleField?changeRequestId=' + changeRequestId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true,

            listeners: {
                load: function (store, records, successful, operation, options) {
                    if (successful) {
                        // 获取返回的数据
                        var singleFields = records[0].getData();
                        ecrSingleFieldId = singleFields.id;
                        //ECR编号
                        var ecrNumber = Ext.getCmp('ecrNumber');
                        if (ecrNumber) {
                            var ecrNumberValue = singleFields.ecrUrl;
                            if (ecrNumberValue != null) {
                                ecrNumber.setValue(ecrNumberValue);
                            }
                        }
                        //ECR编号
                        var ecrName = Ext.getCmp('ecrName');
                        if (ecrName) {
                            var ecrNameValue = singleFields.ecrName;
                            if (ecrNameValue != null) {
                                ecrName.setValue(ecrNameValue);
                            }
                        }
                        //更改类型
                        var changeType = Ext.getCmp('changeType');
                        if (changeType) {
                            var changeTypeValue = singleFields.changeType;
                            if (changeTypeValue != null) {
                                changeType.setValue(changeTypeValue);
                            }
                        }
                        //产品型号
                        var productModel = Ext.getCmp('productModel');
                        if (productModel) {
                            var productModelValue = singleFields.productModel;
                            if (productModelValue != null) {
                                productModel.setValue(productModelValue);
                            }
                        }
                        //变更原因
                        var changeReason = Ext.getCmp('changeReason');
                        if (changeReason) {
                            var changeReasonValue = singleFields.changeReason;
                            if (changeReasonValue != null) {
                                changeReason.setValue(changeReasonValue);
                            }
                        }
                        //变更描述
                        var changeDescription = Ext.getCmp('changeDescription');
                        if (changeDescription) {
                            var changeDescriptionValue = singleFields.changeDescription;
                            if (changeDescriptionValue != null) {
                                changeDescription.setValue(changeDescriptionValue);
                            }
                        }
                        //是否需要测试报告
                        var needTestReport = Ext.getCmp('needTestReport');
                        if (needTestReport) {
                            var needTestReportValue = singleFields.needTestReport;
                            if (needTestReportValue != null) {
                                needTestReport.setValue(needTestReportValue);
                            }
                        }
                        // //测试报告文件
                        // var testReportFile = Ext.getCmp('testReportFile');
                        // if (testReportFile !== 'undefined') {
                        //     var testReportFileValue = singleFields.testReportFile;
                        //     if (testReportFileValue != null) {
                        //         testReportFile.setValue(testReportFileValue);
                        //     }
                        // }
                        //不需要测试报告原因
                        var noTestReportReason = Ext.getCmp('noTestReportReason');
                        if (noTestReportReason) {
                            var noTestReportReasonValue = singleFields.noTestReportReason;
                            if (noTestReportReasonValue != null) {
                                noTestReportReason.setValue(noTestReportReasonValue);
                            }
                        }
                        //申请人
                        var applicant = Ext.getCmp('applicant');
                        if (applicant) {
                            var applicantValue = singleFields.applicant;
                            if (applicantValue != null) {
                                applicant.setValue(applicantValue);
                            }
                        }
                        //申请部门
                        var applicationDepartment = Ext.getCmp('applicationDepartment');
                        if (applicationDepartment) {
                            var applicationDepartmentValue = singleFields.applicationDepartment;
                            if (applicationDepartmentValue != null) {
                                applicationDepartment.setValue(applicationDepartmentValue);
                            }
                        }
                        //申请时间
                        var applicationTime = Ext.getCmp('applicationTime');
                        if(applicationTime!== 'undefined') {
                            var applicationTimeValue = singleFields.applicationTime;
                            if (applicationTimeValue != null) {
                                var dateObj = new Date(applicationTimeValue); // 创建一个 Date 对象
                                var formattedTime = Ext.Date.format(dateObj, 'Y-m-d');
                                applicationTime.setValue(formattedTime);
                            }
                        }
                        // //附件
                        // var annex = Ext.getCmp('annex');
                        // if (applicationDepartment !== 'undefined') {
                        //     var annexValue = singleFields.annex;
                        //     if (annexValue != null) {
                        //         annex.setValue(annexValue);
                        //     }
                        // }
                        //受影响的成品
                        var affectedFinishedProducts = Ext.getCmp('affectedFinishedProducts');
                        if (affectedFinishedProducts) {
                            var affectedFinishedProductsValue = singleFields.affectedFinishedProducts;
                            if (affectedFinishedProductsValue != null) {
                                affectedFinishedProducts.setValue(affectedFinishedProductsValue);
                            }
                        }
                        //待更改物料BOM
                        var changeMaterialBom = Ext.getCmp('changeMaterialBom');
                        if (changeMaterialBom) {
                            var changeMaterialBomValue = singleFields.changeMaterialBom;
                            if (changeMaterialBomValue != null) {
                                changeMaterialBom.setValue(changeMaterialBomValue);
                            }
                        }
                        //图纸文档
                        var drawingDocument = Ext.getCmp('drawingDocument');
                        if (drawingDocument) {
                            var drawingDocumentValue = singleFields.drawingDocument;
                            if (drawingDocumentValue != null) {
                                drawingDocument.setValue(drawingDocumentValue);
                            }
                        }
                        //变更来源
                        var changeSource = Ext.getCmp('changeSource');
                        if (changeSource) {
                            var changeSourceValue = singleFields.changeSource;
                            if (changeSourceValue != null) {
                                changeSource.setValue(changeSourceValue);
                            }
                        }
                    }
                }
            }
        })

        ecrStore = singleFieldStore;
        //==========================ECR审批记录单个字段赋值============================================


//===================================物料变更内容  (非以下字段修改，请将修改的"字段信息及值"在"变更描述中填写，“产品数据工程师收到ECA后手工修改) 开始===============================================================
        Ext.define('affectEPartModel', {
            extend: 'Ext.data.Model',
            fields: ['partNumber','viewName'],
            idProperty: 'id'
        });

        var affectEPartStore = Ext.create('Ext.data.Store', {
            id: 'affectEPartStore',
            model: 'affectEPartModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/getChangePartNumbers?changeRequestId='+changeRequestId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

        var affectEPartCombo =new Ext.form.field.ComboBox({
            forceSelection: false, //forceSelection 是否能够手填
            name: 'affectEPartCombo',
            id: 'affectEPartCombo',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore("affectEPartStore"),
            valueField: 'partNumber',
            displayField: 'partNumber',
        });




        Ext.define('ctEcrApprovalRecordsTableModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','parentNumber','partNumber','partDescBefore','internalVersionBefore','partDescAfter','internalVersionAfter','partUrl'
            ],
            idProperty: 'id'
        });

        this.ctEcrApprovalRecordsTableStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ctEcrApprovalRecordsTableModel',
            id:'ctEcrApprovalRecordsTableStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/searchPartChange?changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var ctEcrApprovalRecordsTableCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ctEcrApprovalRecordsTableGrid = Ext.create('Ext.grid.Panel', {
            plugins: [ctEcrApprovalRecordsTableCellEditing],
            store: Ext.getStore('ctEcrApprovalRecordsTableStore'),
            id: 'ctEcrApprovalRecordsTableGrid',
            // margin: '0 10 0 0',
            title: '物料变更内容  (非以下字段修改，请将修改的"字段信息及值"在"变更描述中填写，“产品数据工程师收到ECA后手工修改)',
            titleAlign: 'center', // 设置标题居中
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:100,
            viewConfig: { enableTextSelection:true},
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            columns: [
                {text: '父项编码', dataIndex: 'parentNumber', flex: 1,editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: setMust('物料编码',partNumberARecordsECR), dataIndex: 'partNumber', flex: 1,
                    editor: partNumberARecordsECR?affectEPartCombo:false, menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('partUrl')) {
                            let changeLink = record.get('partUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {
                    text: '物料变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '物料描述', dataIndex: 'partDescBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '内部版本', dataIndex: 'internalVersionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '物料变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: setRequired('物料描述',partDescAfterARecordsECR), dataIndex: 'partDescAfter', flex: 1,
                            editor: partDescAfterARecordsECR, menuDisabled: true,renderer:showTip},
                        {text: setRequired('内部版本',internalVersionAfterARecordsECR), dataIndex: 'internalVersionAfter', flex: 1,
                            editor: internalVersionAfterARecordsECR, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
            tbar: [
                {
                    xtype: 'button',
                    text: '新增行',
                    // id: 'trialMBOMInsert',
                    iconCls: 'icon icon-add',
                    hidden: addARecordsECR?false:true,
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ECRApprovalRecords/addPartChange?changeRequestId='+changeRequestId,
                            async: false,
                            headers: {'Content-Type': 'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=="success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    Ext.getStore('ctEcrApprovalRecordsTableStore').load();
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行',
                    // id: 'trialMBOMDelete',
                    iconCls: 'icon icon-delete',
                    hidden: deleteARecordsECR?false:true,
                    handler: function () {
                        var selected = ctEcrApprovalRecordsTableGrid.getSelectionModel().getSelection();
                        if (selected.length != 0) {
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    if(i == 0){
                                        ids += id;
                                    }else{
                                        ids += ',' + id;
                                    }
                                }
                            }
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/ECRApprovalRecords/deletePartChange?ids='+ids,
                                async: false,
                                headers: {'Content-Type': 'application/json'},
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=="success") {
                                        //回调函数，一般用于后台操作成功后刷新列表
                                        Ext.getStore('ctEcrApprovalRecordsTableStore').load();
                                    } else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：保存信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }

                    }
                }
                ]
        });

        ctEcrApprovalRecordsTableGrid.on('rowclick', function (view, record, item, index, e){
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'partNumber') {
                    Ext.getStore("affectEPartStore").load();
                }
            }
        });

        ctEcrApprovalRecordsTableGrid.on('cellclick', function (){

        });

        ctEcrApprovalRecordsTableGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECRApprovalRecords/updatePartChange',
                method: 'POST',
                params: {
                    id: id,
                    key: tField,
                    value: tValue
                },
                async: false,
                // headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == "success") {
                        // 成功处理逻辑
                    } else {
                        alert(obj.message);
                    }
                    // 回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('ctEcrApprovalRecordsTableStore').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
            // Ext.Ajax.request({
            //     url: '/Windchill/ptc1/ECRApprovalRecords/updatePartChange?id='+id+'&key='+tField+'&value='+tValue,
            //     async: false,
            //     headers: {'Content-Type': 'application/json'},
            //     success: function (response, opts) {
            //         var obj = Ext.decode(response.responseText);
            //         if(obj.message=="success") {
            //
            //         } else {
            //             alert(obj.message);
            //         }
            //         //回调函数，一般用于后台操作成功后刷新列表
            //         Ext.getStore('ctEcrApprovalRecordsTableStore').load();
            //     },
            //     failure: function (response, opts) {
            //         alert('错误：保存信息失败，请检查网络！!');
            //     }
            // });
        });
//===================================物料变更内容  (非以下字段修改，请将修改的"字段信息及值"在"变更描述中填写，“产品数据工程师收到ECA后手工修改) 结束===============================================================



//===================================EBOM变更内容 开始===============================================================

        Ext.define('EcrEBOMModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','tableType','finishedProductNumber','parentNumber','parentDesc','changeType','partNumberBefore','partDescBefore',
                'tagNumberBefore','bomRemarkBefore', 'fractionBefore','quantityBefore','partNumberAfter','partDescAfter','tagNumberAfter',
                'bomRemarkAfter','fractionAfter','quantityAfter','remarks','responsiblePerson'
            ],
            idProperty: 'EcrEBOMModel'
        });

        var EBOMStore = Ext.create('Ext.data.Store', {
            model: 'EcrEBOMModel',
            id: 'EBOMStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/searchEcrEBomChange?changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'EBOMModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var EBOMColumns = [
            {text: '父项所属成品编码', dataIndex: 'finishedProductNumber', width: 100, editor: false, menuDisabled: true,
                // style: disableNode(start_node)?'color: blue;':''
            },
            {
                text: setMust('父项编码',parentNumberEBOMECR), dataIndex: 'parentNumber', width: 100,
                editor: parentNumberEBOMECR?eBOMParentNumberCombo:false,
                menuDisabled: true,// style: disableNode(start_node)?'color: blue;':''
                renderer: function(value,metaData,record,row,col,store){
                    if(value)
                        metaData.tdAttr = 'data-qtip="' + value +'"';
                    if(record.get('parentUrl')) {
                        let changeLink = record.get('parentUrl');
                        return changeLink;
                    }else {
                        return value;
                    }
                }
            },
            {text: '父项描述', dataIndex: 'parentDesc', width: 100,menuDisabled: true},
            {text: setMust('变更类型',changeTypeEBOMECR), dataIndex: 'changeType', width: 100,
                editor: changeTypeEBOMECR?changeType:false , menuDisabled: true},
            {
                text: '变更前',menuDisabled: true,
                columns: [
                    {
                        text: setRequired('物料编码',partNumberBeforeEBOMECR),
                        dataIndex: 'partNumberBefore', width: 100,
                        editor: partNumberBeforeEBOMECR, menuDisabled: true,
                        renderer: function(value,metaData,record,row,col,store){
                            if(value)
                                metaData.tdAttr = 'data-qtip="' + value +'"';
                            if(record.get('beforeUrl')) {
                                let changeLink = record.get('beforeUrl');
                                return changeLink;
                            }else {
                                return value;
                            }
                        }
                    },
                    {text: '物料描述', dataIndex: 'partDescBefore', width: 100, editor: false, menuDisabled: true},
                    {text: '分数', dataIndex: 'fractionBefore', width: 100, editor: false, menuDisabled: true},
                    {text: '数量', dataIndex: 'quantityBefore', width: 100, editor: false, menuDisabled: true},
                    {text: '位号', dataIndex: 'tagNumberBefore', width: 100, editor: false, menuDisabled: true},
                    {text: 'BOM备注', dataIndex: 'bomRemarkBefore', width: 100, editor: false, menuDisabled: true}
                ]
            },
            {
                text: '变更后',menuDisabled: true,
                columns: [
                    {
                        text: setRequired('物料编码',partNumberAfterEBOMECR),
                        dataIndex: 'partNumberAfter', width: 100,
                        editor: partNumberAfterEBOMECR, menuDisabled: true,
                        renderer: function(value,metaData,record,row,col,store){
                            if(value)
                                metaData.tdAttr = 'data-qtip="' + value +'"';
                            if(record.get('afterUrl')) {
                                let changeLink = record.get('afterUrl');
                                return changeLink;
                            }else {
                                return value;
                            }
                        }
                    },
                    {text: '物料描述', dataIndex: 'partDescAfter', width: 100, editor: false , menuDisabled: true},
                    {text: setRequired('分数',fractionAfterEBOMECR), dataIndex: 'fractionAfter', width: 100, editor: fractionAfterEBOMECR, menuDisabled: true},
                    {text: setRequired('数量',quantityAfterEBOMECR), dataIndex: 'quantityAfter', width: 100, editor: quantityAfterEBOMECR, menuDisabled: true},
                    {text: setRequired('位号',tagNumberAfterEBOMECR), dataIndex: 'tagNumberAfter', width: 100, editor: tagNumberAfterEBOMECR, menuDisabled: true},
                    {text: setRequired('BOM备注',bomRemarkAfterEBOMECR), dataIndex: 'bomRemarkAfter', width: 100, editor: bomRemarkAfterEBOMECR, menuDisabled: true}

                ]
            },
            {text: setRequired('备注',remarksEBOMECR), dataIndex: 'remarks', width: 100, editor: remarksEBOMECR, menuDisabled: true},
            {text: 'EBOM更改负责人', dataIndex: 'responsiblePerson', width: 100, editor:
                false
                // ebompersonLiableCom
                , menuDisabled: true},
            {text: '', dataIndex: '', width: 10, menuDisabled: true}
        ];

        var EBOMGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var EBOMGrid = Ext.create('Ext.grid.Panel', {
            plugins: [EBOMGridEditing],
            store: EBOMStore,
            columns: EBOMColumns,
            id:'EBOMGrid',
            title: 'EBOM变更内容',
            titleAlign: 'center', // 设置标题居中
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true,forceFit: false },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '新增行',
                    // id: 'trialMBOMInsert',
                    iconCls: 'icon icon-add',
                    hidden: addEBOMECR?false:true,
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ECRApprovalRecords/addEcrEBomChange?changeRequestId='+changeRequestId,
                            async: false,
                            headers: {'Content-Type': 'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=="success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    Ext.getStore('EBOMStore').load();
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行',
                    // id: 'trialMBOMDelete',
                    iconCls: 'icon icon-delete',
                    hidden: deleteEBOMECR?false:true,
                    handler: function () {
                        var selected = EBOMGrid.getSelectionModel().getSelection();
                        if (selected.length != 0) {
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    if(i == 0){
                                        ids += id;
                                    }else{
                                        ids += ',' + id;
                                    }
                                }
                            }
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/ECRApprovalRecords/deleteEcrEBomChange?ids='+ids,
                                async: false,
                                headers: {'Content-Type': 'application/json'},
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=="success") {
                                        //回调函数，一般用于后台操作成功后刷新列表
                                        Ext.getStore('EBOMStore').load();
                                    } else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：保存信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '复制',
                    id: 'ecrEBOMInsert',
                    iconCls: 'icon-copy',
                    hidden: copyEBOMECR?false:true,
                    handler: function () {
                        var selected = EBOMGrid.getSelectionModel().getSelection();
                        if (selected.length != 0) {
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    if (i == 0) {
                                        ids += id;
                                    } else {
                                        ids += ',' + id;
                                    }
                                }
                            }
                            copyId = ids;
                        }else {
                            copyId = "";
                            alert("请先选择数据！")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '下载导入模板',
                    id: 'ecrEBOMDelete',
                    iconCls: 'icon icon-download',
                    hidden: downloadEBOMECR?false:true,
                    scope: this,
                    handler: function () {
                        // window.location.href = '/Windchill/ptc1/ec/downLoadTemplate?templateName=MBOM变更内容导入模板';
                        window.location.href = '/Windchill/ptc1/ECRApprovalRecords/downLoadTemplate?templateName=BOM变更导入模板';
                    }
                },
                {
                    xtype:'filefield',
                    buttonOnly: true,
                    // disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                    id:'ecrEBOMupload',
                    hideLabel: true,
                    hidden: uploadEBOMECR?false:true,
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入EBOM变更内容</span>',
                    allowBlank: false,
                    scope: this,
                    listeners:{
                        'change':function(fb,newValue,oldValue,opts){
                            if(!newValue){
                                return;
                            }
                            var boms = "ebom";
                            var file = document.querySelector('[id=ecrEBOMupload-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('ecrEBOMupload-button-fileInputEl', file.files[0]);

                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在导入数据，请稍候......',
                                target: MBOMGrid
                            });

                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/ECRApprovalRecords/importChangeItems?changeRequestId='+changeRequestId+'&changeTableType=EcrEBomChange&type=ebom'+'&workItemOid='+"workItemOid",
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function(res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if(!success){
                                    alert(msg);
                                    // Ext.getStore('EBOMStore').load();
                                    // EBOMGrid.getStore().load();
                                }
                                EBOMGrid.getStore().load();
                            }).fail(function(res) {
                                var obj = Ext.decode(res);
                                var msg = obj['msg'];
                                myMask.hide();
                                alert('导入失败！\n'+msg) ;
                            });
                        }


                    }
                }
            ]
        });

        EBOMGrid.on('beforeedit', function (editor, context) {
        })

        EBOMGrid.on('rowclick', function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'parentNumber'){
                    Ext.getStore("eBOMParentNumberStore").reload();
                }
            }
        })

        EBOMGrid.on('edit',function(editor,e){
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECRApprovalRecords/updateEcrEBomChange?id='+id+'&key='+tField+'&value='+tValue,
                async: false,
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=="success") {

                    } else {
                        alert(obj.message);
                    }
                    //回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('EBOMStore').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
        });
//===================================EBOM变更内容 结束===============================================================

//===================================MBOM变更内容 开始===============================================================
        Ext.define('ecrMBOMModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','tableType','finishedProductNumber','parentNumber','parentDesc','changeType','partNumberBefore','partDescBefore','tagNumberBefore',
                'bomRemarkBefore', 'fractionBefore','quantityBefore','partNumberAfter','partDescAfter','tagNumberAfter','bomRemarkAfter','fractionAfter',
                'quantityAfter','remarks','responsiblePerson'
            ],
            idProperty: 'ecrMBOMModel'
        });

        var ecrMBOMStore = Ext.create('Ext.data.Store', {
            model: 'ecrMBOMModel',
            id: 'ecrMBOMStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/searchEcrMBomChange?changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'ecrMBOMModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var MBOMColumns = [
            {text: '父项所属成品编码', dataIndex: 'finishedProductNumber', width: 100, editor: false, menuDisabled: true,
                // style: disableNode(start_node)?'color: blue;':''
            },
            {
                text: setMust('父项编码',parentNumberMBOMECR), dataIndex: 'parentNumber', width: 100,
                editor: parentNumberMBOMECR?mBOMParentNumberCombo:false,
                menuDisabled: true,// style: disableNode(start_node)?'color: blue;':''
                renderer: function(value,metaData,record,row,col,store){
                    if(value)
                        metaData.tdAttr = 'data-qtip="' + value +'"';
                    if(record.get('parentUrl')) {
                        let changeLink = record.get('parentUrl');
                        return changeLink;
                    }else {
                        return value;
                    }
                }
            },
            {text: '父项描述', dataIndex: 'parentDesc', width: 100,menuDisabled: true},
            {text: setMust('变更类型',changeTypeMBOMECR), dataIndex: 'changeType', width: 100,
                editor: changeTypeMBOMECR?changeType:false , menuDisabled: true},
            {
                text: '变更前',menuDisabled: true,
                columns: [
                    {
                        text: setRequired('物料编码',partNumberBeforeMBOMECR),
                        dataIndex: 'partNumberBefore', width: 100,
                        editor: partNumberBeforeMBOMECR, menuDisabled: true,
                        renderer: function(value,metaData,record,row,col,store){
                            if(value)
                                metaData.tdAttr = 'data-qtip="' + value +'"';
                            if(record.get('beforeUrl')) {
                                let changeLink = record.get('beforeUrl');
                                return changeLink;
                            }else {
                                return value;
                            }
                        }
                    },
                    {text: '物料描述', dataIndex: 'partDescBefore', width: 100, editor: null, menuDisabled: true},
                    {text: '分数', dataIndex: 'fractionBefore', width: 100, editor: false, menuDisabled: true},
                    {text: '数量', dataIndex: 'quantityBefore', width: 100, editor: null, menuDisabled: true},
                    {text: '位号', dataIndex: 'tagNumberBefore', width: 100, editor: null, menuDisabled: true},
                    {text: 'BOM备注', dataIndex: 'bomRemarkBefore', width: 100, editor: null, menuDisabled: true}
                ]
            },
            {
                text: '变更后',menuDisabled: true,
                columns: [
                    {
                        text: setRequired('物料编码',partNumberAfterMBOMECR),
                        dataIndex: 'partNumberAfter', width: 100,
                        editor: partNumberAfterMBOMECR, menuDisabled: true,
                        renderer: function(value,metaData,record,row,col,store){
                            if(value)
                                metaData.tdAttr = 'data-qtip="' + value +'"';
                            if(record.get('afterUrl')) {
                                let changeLink = record.get('afterUrl');
                                return changeLink;
                            }else {
                                return value;
                            }
                        }
                    },
                    {text: '物料描述', dataIndex: 'partDescAfter', width: 100, editor: false , menuDisabled: true},
                    {text: setRequired('分数',fractionAfterMBOMECR), dataIndex: 'fractionAfter', width: 100, editor: fractionAfterMBOMECR, menuDisabled: true},
                    {text: setRequired('数量',quantityAfterMBOMECR), dataIndex: 'quantityAfter', width: 100, editor: quantityAfterMBOMECR, menuDisabled: true},
                    {text: setRequired('位号',tagNumberAfterMBOMECR), dataIndex: 'tagNumberAfter', width: 100, editor: tagNumberAfterMBOMECR, menuDisabled: true},
                    {text: setRequired('BOM备注',bomRemarkAfterMBOMECR), dataIndex: 'bomRemarkAfter', width: 100, editor: bomRemarkAfterMBOMECR, menuDisabled: true}

                ]
            },
            {text: setRequired('备注',remarksMBOMECR), dataIndex: 'remarks', width: 100, editor: remarksMBOMECR, menuDisabled: true},
            {text: 'MBOM更改负责人', dataIndex: 'responsiblePerson', width: 100, editor:
                false
                // mbompersonLiableCom
                , menuDisabled: true},
            {text: '', dataIndex: '', width: 10, menuDisabled: true}
        ];

        var MBOMGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var MBOMGrid = Ext.create('Ext.grid.Panel', {
            plugins: [MBOMGridEditing],
            store: ecrMBOMStore,
            columns: MBOMColumns,
            id:'MBOMGrid',
            title: 'MBOM变更内容',
            titleAlign: 'center', // 设置标题居中
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true,forceFit: false },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '新增行',
                    // id: 'MBOMInsert',
                    iconCls: 'icon icon-add',
                    hidden: addMBOMECR?false:true,
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ECRApprovalRecords/addEcrMBomChange?changeRequestId='+changeRequestId,
                            async: false,
                            headers: {'Content-Type': 'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=="success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    Ext.getStore('ecrMBOMStore').load();
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行',
                    // id: 'MBOMDelete',
                    iconCls: 'icon icon-delete',
                    hidden: deleteMBOMECR?false:true,
                    handler: function () {
                        var selected = MBOMGrid.getSelectionModel().getSelection();
                        if (selected.length != 0) {
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    if(i == 0){
                                        ids += id;
                                    }else{
                                        ids += ',' + id;
                                    }
                                }
                            }
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/ECRApprovalRecords/deleteEcrMBomChange?ids='+ids,
                                async: false,
                                headers: {'Content-Type': 'application/json'},
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=="success") {
                                        //回调函数，一般用于后台操作成功后刷新列表
                                        Ext.getStore('ecrMBOMStore').load();
                                    } else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：保存信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '粘贴',
                    // id: 'ecaMBOMInsert',
                    iconCls: 'icon-paste',
                    hidden: pasteMBOMECR?false:true,
                    handler: function () {
                        // alert(copyId);
                        if (Ext.isEmpty(copyId)) {
                            alert("请先选择要粘贴的数据！");
                        }
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ECRApprovalRecords/pasteChangeItems?id=' + copyId+'&changeRequestId='+changeRequestId,
                            async: false,
                            headers: {'Content-Type': 'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if (obj.message == "success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    Ext.getStore('ecrMBOMStore').load();
                                } else {
                                    alert(obj.message);
                                }
                                copyId = "";
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                                copyId = "";
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '下载导入模板',
                    // id: 'ecaMBOMDelete',
                    iconCls: 'icon icon-download',
                    hidden: downloadMBOMECR?false:true,
                    scope: this,
                    handler : function(){
                        // E:\sanjiangdaima\src\ext\plm\templates\BOM变更导入模板.xlsx
                        //E:\sanjiangdaima\src\ext\plm\newec\CtECRApprovalRecordsController.java
                        window.location.href = '/Windchill/ptc1/ECRApprovalRecords/downLoadTemplate?templateName=BOM变更导入模板';
                    }
                },
                {
                    xtype:'filefield',
                    buttonOnly: true,
                    // disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                    id:'ecrMBOMupload',
                    hideLabel: true,
                    hidden: uploadMBOMECR?false:true,
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入MBOM变更内容</span>',
                    allowBlank: false,
                    scope: this,
                    listeners:{
                        'change':function(fb,newValue,oldValue,opts){
                            if(!newValue){
                                return;
                            }
                            var boms = "mbom";
                            var file = document.querySelector('[id=ecrMBOMupload-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('ecrMBOMupload-button-fileInputEl', file.files[0]);

                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在导入数据，请稍候......',
                                target: MBOMGrid
                            });

                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/ECRApprovalRecords/importChangeItems?changeRequestId='+changeRequestId+'&changeTableType=EcrMBomChange&type=mbom'+'&workItemOid='+"workItemOid",
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function(res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if(!success){
                                    alert(msg);
                                    // Ext.getStore('ecrMBOMStore').load();
                                    // MBOMGrid.getStore().load();
                                }
                                MBOMGrid.getStore().load();
                            }).fail(function(res) {
                                var obj = Ext.decode(res);
                                var msg = obj['msg'];
                                myMask.hide();
                                alert('导入失败！\n'+msg) ;
                            });
                        }


                    }
                }
            ]
        });


        MBOMGrid.on('beforeedit', function (editor, context) {
        })

        MBOMGrid.on('rowclick', function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'parentNumber'){
                    Ext.getStore("mBOMParentNumberStore").reload();
                }
            }
        })

        MBOMGrid.on('edit',function(editor,e){
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECRApprovalRecords/updateEcrMBomChange?id='+id+'&key='+tField+'&value='+tValue,
                async: false,
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=="success") {

                    } else {
                        alert(obj.message);
                    }
                    //回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('ecrMBOMStore').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
        });
//===================================MBOM变更内容 结束===============================================================

//===================================1. ECR_申请人（提交） 开始===============================================================

        var ECR01 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '1. ECR_申请人（提交）',
            // padding:'5',
            margin: '0 10 0 0',
            width:'99.9%',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'ECR编号',
                        id: 'ecrNumber',
                        name: 'ecrNumber',
                        value:'',
                        flex: 1,
                        // width: 200,
                        multiSelect: false,
                        anyMatch: true,
                        editable: false
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'ECR名称',
                        id: 'ecrName',
                        name: 'ecrName',
                        value:'',
                        flex: 1,
                        // width: 200,
                        readOnly:true
                    },, {
                        xtype: 'displayfield',
                        fieldLabel: '更改类型',
                        id: 'changeType',
                        name: 'changeType',
                        value:'',
                        flex: 1,
                        // width: 200,
                        readOnly:true
                    }
                    ]
                },
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: setMust('产品型号',productModelSingleFieldECR),
                            id: 'productModel',
                            name: 'productModel',
                            value:'',
                            readOnly:!productModelSingleFieldECR,
                            flex: 1,
                            listeners: {
                                blur: function(field) {
                                    var productModel = field.getValue();
                                    var callbackFn = function (response, opts) {
                                    };
                                    saveEcrSubmitSingleField("ZEcrInfoTable",ecrSingleFieldId,"productModel",productModel,callbackFn())
                                }
                            }
                        },
                        {
                            xtype: 'combo',
                            fieldLabel: setMust('变更来源',changeSourceSingleFieldECR),
                            id: 'changeSource',
                            name: 'changeSource',
                            readOnly:!changeSourceSingleFieldECR,
                            store: ['降本更换物料',
                                    '缺料启动二供',
                                    '解决品质异常',
                                    '测试标准更新',
                                    '产品定义变更',
                                    '专利侵利',
                                    '产品升级',
                                    '设计缺陷完善',
                                    '其他原因'
                            ], // 下拉框选项数据源
                            editable: false, // 设置为不可编辑，只能从下拉框中选择
                            queryMode: 'local', // 指定查询模式为本地
                            flex: 1,
                            listeners: {
                                select: function(combo, records) {
                                    var changeSource = combo.getValue();
                                    var callbackFn = function (response, opts) {
                                    };
                                    saveEcrSubmitSingleField("ZEcrInfoTable",ecrSingleFieldId,"changeSource",changeSource,callbackFn())
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 120},
                    items: [
                        {
                            xtype: 'textarea',
                            fieldLabel: setMust('变更原因描述',changeReasonSingleFieldECR),
                            id: 'changeReason',
                            name: 'changeReason',
                            readOnly:!changeReasonSingleFieldECR,
                            // value:'',
                            rows: 6,
                            flex: 1,
                            listeners: {
                                blur: function(field) {
                                    var productModel = field.getValue();
                                    var callbackFn = function (response, opts) {
                                    };
                                    saveEcrSubmitSingleField("ZEcrInfoTable",ecrSingleFieldId,"changeReason",productModel,callbackFn())
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 120},
                    items: [
                        // {
                        //     xtype: 'displayfield',
                        //     fieldLabel: '变更描述',
                        //     id: 'changeDescription',
                        //     name: 'changeDescription',
                        //     value:'',
                        //     flex: 1,
                        //
                        // },
                        {
                            xtype: 'combo',
                            fieldLabel: setRequired('是否需要测试报告',needTestReportSingleFieldECR),
                            id: 'needTestReport',
                            name: 'needTestReport',
                            readOnly:!needTestReportSingleFieldECR,
                            store: ['是', '否'], // 下拉框选项数据源
                            editable: false, // 设置为不可编辑，只能从下拉框中选择
                            queryMode: 'local', // 指定查询模式为本地
                            flex: 1,
                            listeners: {
                                select: function(combo, records) {
                                    var needTestReport = combo.getValue();
                                    var callbackFn = function (response, opts) {
                                    };
                                    saveEcrSubmitSingleField("ZEcrInfoTable",ecrSingleFieldId,"needTestReport",needTestReport,callbackFn())
                                }
                            }
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: setRequired('不需要测试报告原因',noTestReportReasonSingleFieldECR),
                            id: 'noTestReportReason',
                            name: 'noTestReportReason',
                            readOnly:!noTestReportReasonSingleFieldECR,
                            value:'',
                            flex: 1,
                            listeners: {
                                blur: function(field) {
                                    var noTestReportReason = field.getValue();
                                    var callbackFn = function (response, opts) {
                                    };
                                    saveEcrSubmitSingleField("ZEcrInfoTable",ecrSingleFieldId,"noTestReportReason",noTestReportReason,callbackFn())
                                }
                            }
                        },
                        {
                            xtype: 'container',
                            layout: 'hbox',
                            flex: 1,
                            items: [
                                {
                                    xtype: 'textfield',
                                    labelWidth: 100,
                                    fieldLabel: setRequired('测试报告文件',testReportSingleFieldECR),
                                    // labelStyle: disableNode(start_node)?'color: blue':'',
                                    width:'0',
                                    readOnly: true
                                },
                                {
                                    xtype: 'button',
                                    text: '添加文件',
                                    iconCls: 'icon icon-uploadImage',
                                    hidden:uploadImageSingleFieldECR?false:true,
                                    handler: function() {
                                        //设置当前列的id与列名和表名
                                        changeRequestId = changeRequestId;
                                        fileColumnId = ecrSingleFieldId;
                                        fileColumnName = 'testReportFile';
                                        uploadTableName = 'ZEcrInfoTable';
                                        //设置grid名称用于上传文件后刷新数据
                                        gridName = 'ctEcrApprovalRecordsTableGrid';
                                        var ECUploadImageWindow = initECUploadImageWindow();
                                        ECUploadImageWindow.show()
                                        // ECUploadImage();
                                    }
                                },
                                {
                                    xtype: 'button',
                                    text: '查看文件',
                                    iconCls: 'icon-showInfo',
                                    handler: function() {
                                        // //设置当前列的id与列名和表名
                                        changeRequestId = changeRequestId;
                                        fileColumnId = ecrSingleFieldId;
                                        fileColumnName = 'testReportFile';
                                        uploadTableName = 'ZEcrInfoTable';
                                        //设置grid名称用于上传文件后刷新数据
                                        gridName = 'ctEcrApprovalRecordsTableGrid';
                                        isDeletionAllowed = uploadImageSingleFieldECR;
                                        // // 刷新当前单元格内文件
                                        // ECRShowFile.show();
                                        // ECShowFiles();
                                        var ECShowFiles = initECShowFiles();
                                        ECShowFiles.show()
                                    }
                                }
                            ]
                        },
                    ]
                },

                // {
                //     xtype: 'panel',
                //     // layout: 'hbox',
                //     border: false,
                //     align: 'stretch',
                //     layout: {
                //         type: 'hbox',
                //         align: 'stretch'
                //     },
                //     defaults: {margin: '5 20 0 0', labelWidth: 120},
                //     items: [
                //         {
                //             xtype: 'container',
                //             layout: 'hbox',
                //             items: [
                //                 {
                //                     xtype: 'textfield',
                //                     labelWidth: 100,
                //                     fieldLabel: setRequired('测试报告文件',testReportSingleFieldECR),
                //                     // labelStyle: disableNode(start_node)?'color: blue':'',
                //                     width:'0',
                //                     readOnly: true
                //                 },
                //                 {
                //                     xtype: 'button',
                //                     text: '添加文件',
                //                     iconCls: 'icon icon-uploadImage',
                //                     hidden:uploadImageSingleFieldECR?false:true,
                //                     handler: function() {
                //                         //设置当前列的id与列名和表名
                //                         changeRequestId = changeRequestId;
                //                         fileColumnId = ecrSingleFieldId;
                //                         fileColumnName = 'testReportFile';
                //                         uploadTableName = 'ZEcrInfoTable';
                //                         //设置grid名称用于上传文件后刷新数据
                //                         gridName = 'ctEcrApprovalRecordsTableGrid';
                //                         var ECUploadImageWindow = initECUploadImageWindow();
                //                         ECUploadImageWindow.show()
                //                         // ECUploadImage();
                //                     }
                //                 },
                //                 {
                //                     xtype: 'button',
                //                     text: '查看文件',
                //                     iconCls: 'icon-showInfo',
                //                     handler: function() {
                //                         // //设置当前列的id与列名和表名
                //                         changeRequestId = changeRequestId;
                //                         fileColumnId = ecrSingleFieldId;
                //                         fileColumnName = 'testReportFile';
                //                         uploadTableName = 'ZEcrInfoTable';
                //                         //设置grid名称用于上传文件后刷新数据
                //                         gridName = 'ctEcrApprovalRecordsTableGrid';
                //                         // // 刷新当前单元格内文件
                //                         // ECRShowFile.show();
                //                         // ECShowFiles();
                //                         var ECShowFiles = initECShowFiles();
                //                         isDeletionAllowed = uploadImageSingleFieldECR;
                //                         ECShowFiles.show()
                //                     }
                //                 }
                //             ]
                //         },
                //     ]
                // },
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '申请人',
                        id: 'applicant',
                        name: 'applicant',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请部门',
                        id: 'applicationDepartment',
                        name: 'applicationDepartment',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请时间',
                        id: 'applicationTime',
                        name: 'applicationTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
                ]
        });
//===================================1. ECR_申请人（提交） 结束===============================================================

//===================================2. ECR_变更方案与更改对象 开始===============================================================
        var annex = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: '附件',
            labelWidth: 120,
            width:'100%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'annex',
            name: 'annex',
            // readOnly:disableNode(start_node)?false:true,
            listeners: {
                // blur: function(field) {
                //     var detailedDesOfChangeContent = field.getValue();
                //     technicalChange(docNumber,"detailedDesOfChangeContent",detailedDesOfChangeContent)
                // }
            }
        });
        var attachmentLink = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: '附件链接',
            labelWidth: 120,
            width:'100%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'attachmentLink',
            name: 'attachmentLink',
            // readOnly:disableNode(start_node)?false:true,
            listeners: {
                // blur: function(field) {
                //     var detailedDesOfChangeContent = field.getValue();
                //     technicalChange(docNumber,"detailedDesOfChangeContent",detailedDesOfChangeContent)
                // }
            }
        });
        var affectedFinishedProducts = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: '受影响的成品',
            labelWidth: 120,
            width: 200,
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'affectedFinishedProducts',
            name: 'affectedFinishedProducts',
            readOnly:true,
            listeners: {
            }
        });
        var changeMaterialBom = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: '待更改物料BOM',
            labelWidth: 120,
            width: 200,
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'changeMaterialBom',
            name: 'changeMaterialBom',
            // readOnly:disableNode(start_node)?false:true,
            listeners: {
                // 添加 click 事件处理函数
            }
        });
        var drawingDocument = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: '图纸文档',
            labelWidth: 120,
            width: 200,
            // width:'100%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'drawingDocument',
            name: 'drawingDocument',
            // readOnly:disableNode(start_node)?false:true,
            listeners: {
                // // 添加 click 事件处理函数
                // focus: function(field, event) {
                //     Ext.getStore('showObjectInfoStore').reload({
                //         params: {
                //             brand: "受影响的成品"
                //         }
                //     });
                //     showObjectInfo.setTitle('图纸文档');
                //     showObjectInfo.show();
                // }
            }
        });

        var ECR02ApprovedBy = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                {
                    xtype: 'panel',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'SE审批人',
                        id: 'SEApprovedBy',
                        name: 'SEApprovedBy',
                        value:'',
                        flex: 1,
                        // width: 200,
                        multiSelect: false,
                        anyMatch: true,
                        editable: false
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'SEApprovalResults',
                        name: 'SEApprovalResults',
                        value:'',
                        flex: 1,
                        // width: 200,
                        readOnly:true
                    },, {
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'SEApprovalTime',
                        name: 'SEApprovalTime',
                        value:'',
                        flex: 1,
                        // width: 200,
                        readOnly:true
                    }
                    ]
                },
                {
                    xtype: 'panel',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: 'EBOM负责人',
                            id: 'EBOMApprovedBy',
                            name: 'EBOMApprovedBy',
                            value:'',
                            flex: 1,
                        },
                        {
                            xtype: 'displayfield',
                            fieldLabel: '审批结果',
                            id: 'EBOMApprovalResults',
                            name: 'EBOMApprovalResults',
                            value:'',
                            flex: 1,
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '审批时间',
                            id: 'EBOMApprovalTime',
                            name: 'EBOMApprovalTime',
                            value:'',
                            flex: 1,

                        }
                    ]
                },
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'MBOM负责人',
                        id: 'MBOMApprovedBy',
                        name: 'MBOMApprovedBy',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'MBOMApprovalResults',
                        name: 'MBOMApprovalResults',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'MBOMApprovalTime',
                        name: 'MBOMApprovalTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
            ]
        });


        var ECR02  = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '2. ECR_变更方案与更改对象',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            layout: 'vbox', // 垂直布局
            // title: '2. ECR_变更方案与更改对象',
            // height: 'auto',
            // style: {
            //     border: '0' // 设置容器的边框样式为零
            // },
            items: [
                // annex,
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 10', labelWidth: 120},
                    items: [
                        {
                            xtype: 'container',
                            layout: 'hbox',
                            items: [
                                {
                                    xtype: 'textfield',
                                    labelWidth: 100,
                                    fieldLabel: setRequired('附件',annexSingleFieldECR),
                                    // labelStyle: disableNode(start_node)?'color: blue':'',
                                    width:'0',
                                    readOnly: true
                                },
                                {
                                    xtype: 'button',
                                    text: '添加文件',
                                    iconCls: 'icon icon-uploadImage',
                                    hidden:uploadAnnexSingleFieldECR?false:true,
                                    handler: function() {
                                        //设置当前列的id与列名和表名
                                        changeRequestId = changeRequestId;
                                        fileColumnId = ecrSingleFieldId;
                                        fileColumnName = 'annex';
                                        uploadTableName = 'ZEcrInfoTable';
                                        //设置grid名称用于上传文件后刷新数据
                                        gridName = 'ctEcrApprovalRecordsTableGrid';
                                        var ECUploadImageWindow = initECUploadImageWindow();
                                        ECUploadImageWindow.show()
                                    }
                                },
                                {
                                    xtype: 'button',
                                    text: '查看文件',
                                    iconCls: 'icon-showInfo',
                                    handler: function() {
                                        // //设置当前列的id与列名和表名
                                        changeRequestId = changeRequestId;
                                        fileColumnId = ecrSingleFieldId;
                                        fileColumnName = 'annex';
                                        uploadTableName = 'ZEcrInfoTable';
                                        //设置grid名称用于上传文件后刷新数据
                                        gridName = 'ctEcrApprovalRecordsTableGrid';
                                        // // 刷新当前单元格内文件
                                        // ECRShowFile.show();
                                        // ECShowFiles();
                                        var ECShowFiles = initECShowFiles();
                                        isDeletionAllowed = uploadAnnexSingleFieldECR;
                                        ECShowFiles.show()
                                    }
                                }
                            ]
                        },
                    ]
                },
                // attachmentLink,
                {
                    xtype: 'panel',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 120},
                    items: [
                        affectedFinishedProducts,
                        {
                            xtype: 'button',
                            text: '查看详细信息',
                            // iconCls: 'icon icon-uploadImage',
                            // hidden:disableNode(start_node)?false:true,
                            handler: function() {
                                Ext.getStore('showObjectInfoStore').reload({
                                    params: {
                                        typeName: "成品"
                                    }
                                });
                                showObjectInfo.setTitle('受影响的成品');
                                showObjectInfo.show();
                            }
                        },
                    ]
                },
                {
                    xtype: 'panel',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 120},
                    items: [
                        changeMaterialBom,
                        {
                            xtype: 'button',
                            text: '查看详细信息',
                            // iconCls: 'icon icon-uploadImage',
                            // hidden:disableNode(start_node)?false:true,
                            handler: function() {
                                Ext.getStore('showObjectInfoStore').reload({
                                    params: {
                                        typeName: "bom"
                                    }
                                });
                                showObjectInfo.setTitle('待更改物料BOM');
                                showObjectInfo.show();
                            }
                        },
                    ]
                },
                // drawingDocument,
                {
                    xtype: 'panel',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 120},
                    items: [
                    drawingDocument,
                    {
                        xtype: 'button',
                        text: '查看详细信息',
                        // iconCls: 'icon icon-uploadImage',
                        // hidden:disableNode(start_node)?false:true,
                        handler: function() {
                            Ext.getStore('showObjectInfoStore').reload({
                                params: {
                                    typeName: "图纸文档"
                                }
                            });
                            showObjectInfo.setTitle('图纸文档');
                            showObjectInfo.show();
                        }
                    },
                    ]
                },




                ctEcrApprovalRecordsTableGrid,
                EBOMGrid,
                MBOMGrid,
                ECR02ApprovedBy
            ]
        });
//===================================2. ECR_变更方案与更改对象 结束===============================================================

//===================================3. ECR_信息收集 开始===============================================================
        Ext.define('ECR03Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'relatedField', "reviewer", 'reviewComment', 'reviewTime'
            ],
            idProperty: 'ECR03Model'
        });

        var ECR03Columns = [
            {text: '相关领域',flex: 0.5, align: 'center',dataIndex: 'relatedField', menuDisabled:true, editor:false
                // ,style: disableNode(execute_processing_feedback)?'color: blue;':''
            },
            // {text: setMust('评审人',reviewerECR03),flex: 1, align: 'center',dataIndex: 'reviewer', menuDisabled:true, editor:reviewerECR03?ecr03personLiableCom:false},
            {text: '评审人',flex: 1, align: 'center',dataIndex: 'reviewer', menuDisabled:true, editor:false},
            {text: setMust('评审意见',reviewCommentECR03),
                flex: 1, align: 'center',dataIndex: 'reviewComment', menuDisabled:true,
                editor:reviewCommentECR03},
            {text: '评审时间',flex: 1, align: 'center',dataIndex: 'reviewTime', menuDisabled:true, editor:false,
                renderer: function (value) {
                if(!value){
                    return "";
                }
                    var dateObj = new Date(value); // 创建一个 Date 对象
                    var formattedTime = Ext.Date.format(dateObj, 'Y-m-d');

                    return formattedTime;
                }
            }
        ];


        var ECR03Store = Ext.create('Ext.data.Store', {
            model: 'ECR03Model',
            id: 'ECR03Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/searchEcrRegularInfo?tableName=informationGathering&changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'ECR03Model',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,

            listeners: {
                load: function() {

                }
            }

        });

        var ECR03GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var ECR03Grid = Ext.create('Ext.grid.Panel', {
            plugins: [ECR03GridEditing],
            store: ECR03Store,
            columns: ECR03Columns,
            // title: '3. ECR_信息收集',
            id:'ECR03Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: true,
            viewConfig: { enableTextSelection:true},
            style: {
                border: '1px solid #CCCCCC' // 添加灰色边框
            },
        });



        var ECR03 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '3. ECR_信息收集',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECR03Grid
            ]
        });


        //根据特定字段的值判断是否禁止编辑
        ECR03Grid.on('beforeedit', function (editor, context) {
            var record = context.record;
            var relatedField = record.get('relatedField');
            // 判断点击的是哪一列，列名
            var columnName = context.column.dataIndex;
            if(!relatedField){
                return false; // 禁止编辑指定列
            }
            if(!activityName){
                return false; // 禁止编辑指定列,,,
            }
            if(activityName === "通用变更_提交更改请求"){
                return true;
            }
            if(activityName==="通用变更_产品工程部经理(信息收集)"&&relatedField==="产品工程部"){
                return true; // 允许编辑操作
            }
            if(activityName==="通用变更_寻源部经理审核(信息收集)"&&relatedField==="采购寻源部"){
                return true; // 允许编辑操作
            }
            if(activityName==="通用变更_研发质量经理审核(信息收集,小批量验证确认)"&&relatedField==="研发质量经理"){
                return true; // 允许编辑操作
            }
            if(activityName==="通用变更_PCN上传"&&relatedField==="PCN"){
                return true; // 允许编辑操作
            }

            return false; // 禁止编辑指定列




            // if (sampleType === '否') {
            //     if(columnName === 'isItASubstituteMaterial'||columnName === 'detailedReasons'||columnName === 'substitutionGroupMaterial'||
            //         columnName === 'alternativeMaterials'||columnName === 'alternativeMaterialsDesc'||columnName === 'alternativeMaterialsSupplier'||
            //         columnName === 'alternativeMaterialsBrand'||columnName === 'originalPrice'||columnName === 'currentPrice'||
            //         columnName === 'lastYearProcurementVolume'||columnName === 'expectedAnnualPriceDifference'){
            //         return false; // 禁止编辑指定列
            //     }
            // }
            // return true; // 允许编辑操作
        });



        ECR03Grid.on('edit',function(editor,e){
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECRApprovalRecords/updateEcrRegularInfo?id='+id+'&dataKey='+tField+'&dataValue='+tValue+'&tableName=informationGathering',
                async: false,
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=="success") {

                    } else {
                        alert(obj.message);
                    }
                    //回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('ECR03Store').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
        });

//===================================3. ECR_信息收集 结束===============================================================

//===================================4. ECR_部门经理 开始===============================================================
        var ECR04ApprovalOpinions  = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: setMust('审批意见',ECR04ApprovalOpinionsECR04),
            labelWidth: 120,
            width:'99%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'ECR04ApprovalOpinions',
            name: 'ECR04ApprovalOpinions',
            readOnly:ECR04ApprovalOpinionsECR04?false:true,
            listeners: {
                blur: function(field) {
                    var ECR04ApprovalOpinions = field.getValue();
                    saveEcrSingleField("ECR04ApprovalOpinions",ECR04ApprovalOpinions)
                }
            }
        });

        var ECR04 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '4. ECR_部门经理',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECR04ApprovalOpinions,
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'ECR04ApprovedBy',
                        name: 'ECR04ApprovedBy',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'ECR04ApprovalResults',
                        name: 'ECR04ApprovalResults',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'ECR04ApprovalTime',
                        name: 'ECR04ApprovalTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
            ]
        });
//===================================4. ECR_部门经理 结束===============================================================

//===================================5. ECR_产品数据管理主管 开始===============================================================

        var ECR05ApprovalOpinions = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: setMust('审批意见',ECR05ApprovalOpinionsECR05),
            labelWidth: 120,
            width:'99%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'ECR05ApprovalOpinions',
            name: 'ECR05ApprovalOpinions',
            readOnly:ECR05ApprovalOpinionsECR05?false:true,
            listeners: {
                blur: function(field) {
                    var ECR05ApprovalOpinions = field.getValue();
                    saveEcrSingleField("ECR05ApprovalOpinions",ECR05ApprovalOpinions)
                }
            }
        });

        var ECR05 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '5. ECR_产品数据管理主管',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECR05ApprovalOpinions,
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'ECR05ApprovedBy',
                        name: 'ECR05ApprovedBy',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'ECR05ApprovalResults',
                        name: 'ECR05ApprovalResults',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'ECR05ApprovalTime',
                        name: 'ECR05ApprovalTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
            ]
        });
//===================================5. ECR_产品数据管理主管 结束===============================================================

//===================================6. ECR_CCB评审 开始===============================================================
        Ext.define('ECR06Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'relatedField', "reviewer", 'reviewComment', 'reviewTime'
            ],
            idProperty: 'ECR06Model'
        });

        var ECR06Columns = [
            {text: '相关领域',flex: 0.5, align: 'center',dataIndex: 'relatedField', menuDisabled:true, editor:false
                // ,style: disableNode(execute_processing_feedback)?'color: blue;':''
            },
            // {text: setMust('评审人',reviewerECR06),flex: 1, align: 'center',dataIndex: 'reviewer', menuDisabled:true, editor:reviewerECR06?ecr06personLiableCom:false},
            {text: '评审人',flex: 1, align: 'center',dataIndex: 'reviewer', menuDisabled:true, editor:false},
            {text: setMust('评审意见',reviewCommentECR06),flex: 1, align: 'center',dataIndex: 'reviewComment', menuDisabled:true, editor:reviewCommentECR06},
            {text: '评审时间',flex: 1, align: 'center',dataIndex: 'reviewTime', menuDisabled:true, editor:false,
                renderer: function (value) {
                    if(!value){
                        return "";
                    }
                    var dateObj = new Date(value); // 创建一个 Date 对象
                    var formattedTime = Ext.Date.format(dateObj, 'Y-m-d');

                    return formattedTime;
                }
            }
        ];


        var ECR06Store = Ext.create('Ext.data.Store', {
            model: 'ECR06Model',
            id: 'ECR06Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/searchEcrRegularInfo?tableName=CBBReview&changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'ECR06Model',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,

            listeners: {
                load: function() {

                }
            }

        });

        var ECR06GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var ECR06Grid = Ext.create('Ext.grid.Panel', {
            plugins: [ECR06GridEditing],
            store: ECR06Store,
            columns: ECR06Columns,
            // title: '6. ECR_CBB评审',
            id:'ECR06Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: true,
            viewConfig: { enableTextSelection:true},
            style: {
                border: '1px solid #CCCCCC' // 添加灰色边框
            },
        });



        var ECR06 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '6. ECR_CCB评审',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECR06Grid
            ]
        });


        //根据特定字段的值判断是否禁止编辑
        ECR06Grid.on('beforeedit', function (editor, context) {
            var record = context.record;
            var relatedField = record.get('relatedField');
            // 判断点击的是哪一列，列名
            var columnName = context.column.dataIndex;
            if (!relatedField) {
                return false; // 禁止编辑指定列
            }
            if (!activityName) {
                return false; // 禁止编辑指定列,,,,,,,,
            }
            if(activityName === "变更流程_设计更改发起"){
                return true;
            }
            if (activityName === "变更流程_产品工程部经理审核" && relatedField === "产品工程领域") {
                return true; // 允许编辑操作
            }
            if (activityName === "变更流程_技术部经理审核" && relatedField === "技术领域") {
                return true; // 允许编辑操作
            }
            if (activityName === "变更流程_结构开发部经理审核" && relatedField === "结构领域") {
                return true; // 允许编辑操作
            }
            if (activityName === "变更流程_硬件开发部经理审核" && relatedField === "硬件领域") {
                return true; // 允许编辑操作
            }
            if (activityName === "变更流程_软件开发部经理审核" && relatedField === "软件领域") {
                return true; // 允许编辑操作
            }
            if (activityName === "变更流程_质量控制部经理审核" && relatedField === "质量领域") {
                return true; // 允许编辑操作
            }
            if (activityName === "变更流程_采购寻源部经理审核" && relatedField === "采购领域-寻源") {
                return true; // 允许编辑操作
            }
            if (activityName === "变更流程_采购执行部经理审核" && relatedField === "采购领域-执行") {
                return true; // 允许编辑操作
            }
            if (activityName === "变更流程_物控部经理审核" && relatedField === "物控领域") {
                return true; // 允许编辑操作
            }

            return false; // 禁止编辑指定列
        })


        ECR06Grid.on('edit',function(editor,e){
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECRApprovalRecords/updateEcrRegularInfo?id='+id+'&dataKey='+tField+'&dataValue='+tValue+'&tableName=CBBReview',
                async: false,
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=="success") {

                    } else {
                        alert(obj.message);
                    }
                    //回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('ECR06Store').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
        });

//===================================6. ECR_CCB评审 结束===============================================================

//===================================7. ECR_CCB评审意见汇总人 开始===============================================================

        var ECR07ApprovalOpinions = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: setMust('审批意见',ECR07ApprovalOpinionsECR07),
            labelWidth: 120,
            width:'99%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'ECR07ApprovalOpinions',
            name: 'ECR07ApprovalOpinions',
            readOnly:ECR07ApprovalOpinionsECR07?false:true,
            listeners: {
                blur: function(field) {
                    var ECR07ApprovalOpinions = field.getValue();
                    saveEcrSingleField("ECR07ApprovalOpinions",ECR07ApprovalOpinions)
                }
            }
        });

        var ECR07 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '7. ECR_CCB评审意见汇总人',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECR07ApprovalOpinions,
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'ECR07ApprovedBy',
                        name: 'ECR07ApprovedBy',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'ECR07ApprovalResults',
                        name: 'ECR07ApprovalResults',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'ECR07ApprovalTime',
                        name: 'ECR07ApprovalTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
            ]
        });
//===================================7. ECR_CCB评审意见汇总人 结束===============================================================

//===================================8. ECR_CCB主任 开始===============================================================

        var ECR08ApprovalOpinions = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: setMust('审批意见',ECR08ApprovalOpinionsECR08),
            labelWidth: 120,
            width:'99%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'ECR08ApprovalOpinions',
            name: 'ECR08ApprovalOpinions',
            readOnly:ECR08ApprovalOpinionsECR08?false:true,
            listeners: {
                blur: function(field) {
                    var ECR08ApprovalOpinions = field.getValue();
                    saveEcrSingleField("ECR08ApprovalOpinions",ECR08ApprovalOpinions)
                }
            }
        });

        var ECR08 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '8. ECR_CCB主任',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECR08ApprovalOpinions,
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'ECR08ApprovedBy',
                        name: 'ECR08ApprovedBy',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'ECR08ApprovalResults',
                        name: 'ECR08ApprovalResults',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'ECR08ApprovalTime',
                        name: 'ECR08ApprovalTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
            ]
        });
//===================================8. ECR_CCB主任 结束===============================================================

//===================================9. ECR_产品管理部一致性审核 开始===============================================================

        var ECR09ApprovalOpinions = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: setMust('审批意见',ECR09ApprovalOpinionsECR09),
            labelWidth: 120,
            width:'99%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'ECR09ApprovalOpinions',
            name: 'ECR09ApprovalOpinions',
            readOnly:ECR09ApprovalOpinionsECR09?false:true,
            listeners: {
                blur: function(field) {
                    var ECR09ApprovalOpinions = field.getValue();
                    saveEcrSingleField("ECR09ApprovalOpinions",ECR09ApprovalOpinions)
                }
            }
        });

        var ECR09 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '9. ECR_产品管理部一致性审核',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECR09ApprovalOpinions,
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'ECR09ApprovedBy',
                        name: 'ECR09ApprovedBy',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'ECR09ApprovalResults',
                        name: 'ECR09ApprovalResults',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'ECR09ApprovalTime',
                        name: 'ECR09ApprovalTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
            ]
        });
//===================================9. ECR_产品管理部一致性审核 结束===============================================================

//===================================10. ECR_认证技术负责人审批 开始===============================================================
        var ECR10ApprovalOpinions = Ext.create('Ext.form.field.Text', {
            margin: '10 5 10 5',
            fieldLabel: setMust('审批意见',ECR10ApprovalOpinionsECR10),
            labelWidth: 120,
            width:'99%',
            // labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'ECR10ApprovalOpinions',
            name: 'ECR10ApprovalOpinions',
            readOnly:ECR10ApprovalOpinionsECR10?false:true,
            listeners: {
                blur: function(field) {
                    var ECR10ApprovalOpinions = field.getValue();
                    saveEcrSingleField("ECR10ApprovalOpinions",ECR10ApprovalOpinions)
                }
            }
        });

        var ECR010 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '10. ECR_认证技术负责人审批',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECR10ApprovalOpinions,
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'ECR10ApprovedBy',
                        name: 'ECR10ApprovedBy',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'ECR10ApprovalResults',
                        name: 'ECR10ApprovalResults',
                        value:'',
                        flex: 1,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'ECR10ApprovalTime',
                        name: 'ECR10ApprovalTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
            ]
        });
//===================================10. ECR_认证技术负责人审批 结束===============================================================




        var ctEcrApprovalRecordsTablePanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            width:'99.9%',
            items:[
                ECR01,
                ECR02,
                ECR03,
                // ECR03Grid,
                ECR04,
                ECR05,
                // ECR06Grid,
                ECR06,
                ECR07,
                ECR08,
                ECR09,
                ECR010
            ]
        });

        this.items = [
            ctEcrApprovalRecordsTablePanel
        ];

        this.callParent();

        //========== 结束  PartChangeGrid================

    }
})

/**
 * 按查询参数查询
 */
function doSearch() {
    var vvv= Ext.getCmp('type').getValue();
    if(Ext.getCmp('type').getValue()==null){
        alert("必须选择查询类型！")
        return;
    }
    // Ext.getStore('alternativeMaterialListStore').load({
    //     params: {
    //         // data: Ext.encode(data)
    //         replacePartNumber: Ext.getCmp('replacePartNumber').getValue(),
    //         type: Ext.getCmp('type').getValue(),
    //     },
    //     callback: function (records, operation, success) {
    //         if (!success) {
    //             var responseText = operation.getResponse().responseText;
    //             var responseObject = Ext.decode(responseText);
    //             alert(responseObject.message);
    //             // alert('查询信息失败，请联系管理员！');
    //         }
    //     }
    // });
}

