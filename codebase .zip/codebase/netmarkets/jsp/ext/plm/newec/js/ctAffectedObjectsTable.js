Ext.define('PLM.view.ctAffectedObjectsTablePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctAffectedObjectsTablePanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    //autoHeight: true,
    collapsible: false,
    height:770,
    id: 'ctAffectedObjectsTablePanel',
    initComponent: function (){

        var affectedSubtypeStore = new Ext.data.ArrayStore({
            id: 'affectedSubtypeStore',
            fields: [
                {name: "subtype"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/newEc/getSubType',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var affectedSubtypeCom = new Ext.form.ComboBox({
            xtype: 'combo',
            fieldLabel: '子类型',
            name: 'affectedSubtypeCom',
            id: 'affectedSubtypeCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: affectedSubtypeStore,
            valueField: 'subtype',
            displayField: 'subtype',
            minChars: 1, //开始查询最小字符数
            mode: 'local', //查询模式  local为本地数据源  remote为远程服务端
            listeners: {
                expand: function(combo) {
                    let type = Ext.getCmp('affectedObjectType').getValue();
                    if(type){
                        affectedSubtypeStore.load({
                            params: {
                                type: type
                            }
                        });
                    }
                }
            }
        });




//========================================受影响对象表============================
        //编号
        var objectNumberAffected = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme
            ,product_data_engineer_confirm_info,design_change_initiation,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3
            ,mbom_change_manager,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4,design_change_initiation5
            ,product_data_management_supervisor_review5
        );
        //版本
        var version = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme,product_data_engineer_confirm_info
            ,design_change_initiation,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4
        );
        //是否需要PCN
        var needPcnAffected = isEditable(
            pcn_upload_node,pcn_upload,upload_pcn4,upload_pcn
        );
        //PCN编号
        var pcnNumberAffected = isEditable(
            pcn_upload_node,pcn_upload,upload_pcn4,upload_pcn
        );
        //说明
        var illustrateAffected = isEditable(
            pcn_upload_node,pcn_upload,upload_pcn4,upload_pcn
        );
        //PR
        var prAffected = isEditable(

        );
        //总数
        var totalAffected = isEditable(

        );
        //已完成数量
        var completedQuantityAffected = isEditable(

        );
        //未完成数量
        var unfinishedQuantityAffected = isEditable(

        );
        //供应商名称
        var supplierAffected = isEditable(
            change_process_procurement_EMR,purchasing_execute_manager_auditing,review_by_the_procurement_execution_manager,review_by_the_procurement_execution_manager4
        );
        //供应商在制
        var suppliersInProductionAffected = isEditable(
            change_process_procurement_EMR,purchasing_execute_manager_auditing,review_by_the_procurement_execution_manager,review_by_the_procurement_execution_manager4
        );
        //供应商实际库存
        var supplierInventoryAffected = isEditable(
            change_process_procurement_EMR,purchasing_execute_manager_auditing,review_by_the_procurement_execution_manager,review_by_the_procurement_execution_manager4
        );
        //三江吸收数量
        var absorptionQuantityAffected = isEditable(
            change_process_procurement_EMR,purchasing_execute_manager_auditing,review_by_the_procurement_execution_manager,review_by_the_procurement_execution_manager4
        );
        //备注
        var remarksAffected = isEditable(
            change_process_procurement_EMR,purchasing_execute_manager_auditing,review_by_the_procurement_execution_manager,review_by_the_procurement_execution_manager4
        );
        //库存
        var rawMaterialInventoryAffected = isEditable(

        );
        //每月平均消耗用量
        var averageMonthlyConsumptionAffected = isEditable(

        );
        //在制
        var inProductionAffected = isEditable(

        );
        //库存
        var finishedProductInventoryAffected = isEditable(

        );
        //已发货（一年内）
        var shippedAffected = isEditable(

        );
        //已录销售订单但未生产
        var unProducedOrdersAffected = isEditable(

        );
        //处理意见
        var handlingOpinionsAffected = isEditable(
            ebomCharge_node,dateManageMajor_node,pdt_node,general_change_ECA_PDMSR,submit_change_request,product_data_engineer_confirm_info,department_manager_confirm_info
            ,design_change_initiation,department_manager_review,design_change_initiation2,product_data_management_supervisor_review,department_manager_initial_review,design_change_initiation3
            ,mbom_change_manager,product_data_management_supervisor_review3,department_manager_review3,design_change_initiation4,department_manager_review4,product_data_management_supervisor_review4
            ,summary_of_ccb_review_comments
        );
        //说明
        var materialHandlingInstructionsAffected = isEditable(
            ebomCharge_node,dateManageMajor_node,pdt_node,general_change_ECA_PDMSR,submit_change_request,product_data_engineer_confirm_info,department_manager_confirm_info
            ,design_change_initiation,department_manager_review,design_change_initiation2,product_data_management_supervisor_review,department_manager_initial_review,design_change_initiation3
            ,mbom_change_manager,product_data_management_supervisor_review3,department_manager_review3,design_change_initiation4,department_manager_review4,product_data_management_supervisor_review4
            ,summary_of_ccb_review_comments
        );
        //小批量验证建议
        var validationSuggestionsAccess = isEditable(
            ebomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,product_data_engineer_confirm_info,mbomCharge_node,formulate_MBOM_programme
        );
        //小批量验证确认
        var productionTrialAffected = isEditable(
            general_change_small_batch_verification_confirmation,change_process_quality_control_MRSBVC,dateManageMajor_node,product_data_engineer_confirm_info
        );



        //试产试用报告编号
        var trialReportNumberAffected = isEditable(

        );
        //下载模板
        var downloadAffected = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme,product_data_engineer_confirm_info
            ,design_change_initiation,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4,design_change_initiation5,product_data_management_supervisor_review5
        );
        //导入变更对象
        var excelImportAffected = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme,product_data_engineer_confirm_info
            ,design_change_initiation,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4,design_change_initiation5,product_data_management_supervisor_review5
        );
        //增加行
        var addAffected = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme,product_data_engineer_confirm_info
            ,design_change_initiation,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4,design_change_initiation5,product_data_management_supervisor_review5
        );
        //删除行
        var deleteAffected = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme,product_data_engineer_confirm_info
            ,design_change_initiation,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager,product_data_management_supervisor_review3
            ,design_change_initiation4,product_data_management_supervisor_review4,design_change_initiation5,product_data_management_supervisor_review5
        );
        //点击刷新集成数据
        var refreshAffected = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,consistencyRisk_node,dateManageMajor_node,change_process_procurement_EMR,mcRep_node,pcRep_node,pcegRep_node
            ,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme,product_data_engineer_confirm_info,manager_of_material_control_department_auditing
            ,purchasing_execute_manager_auditing,purchasing_manager_auditing,design_change_initiation,material_control_department_manager_review,purchasing_department_manager_review
            ,design_change_initiation2,product_data_management_supervisor_review,QCDRP_ECA_procurement_SMR,QCDRP_ECA_procurement_ER,design_change_initiation3,mbom_change_manager
            ,product_data_management_supervisor_review3,procurement_sourcing_manager_reviewed,material_control_department_manager_review3,review_by_the_procurement_execution_manager
            ,quick_change3_procurement_engineer_review,material_control_department_review,BOM_quick_change_ECA_planning_SR,design_change_initiation4,department_manager_review4
            ,product_data_management_supervisor_review4,quick_change4_procurement_sourcing_manager_review,material_control_department_manager_review4,review_by_the_procurement_execution_manager4
            ,quick_change4_procurement_engineer_eview,mbom_material_control_manager
        );
        //同步数据到ECA
        var synchronizeAffectedObjectsToECA = isEditable(
            general_change_ECA_PDMSR
        );
        //是否需要样品确认
        var needSampleConfirmation = isEditable(
            ebomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,product_data_engineer_confirm_info
        );
        //是否需要改模
        var modifyMold = isEditable(
            ebomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,product_data_engineer_confirm_info
        );
        //改模周期（天）
        var moldModificationCycle = isEditable(
            ebomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,product_data_engineer_confirm_info
        );



        //====================================PCN文件开始====================================================================

        Ext.define('affectedPCNModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','pcnNumber','annex'
            ],
            idProperty: 'affectedPCNModel'
        });


        var affectedPCNStore = Ext.create('Ext.data.Store', {
            model: 'affectedPCNModel',
            id: 'affectedPCNStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/pcnInfo/searchPcnInfo?changeRequestId='+changeRequestId+'&tableName=ZAffectedObjectTable',
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'affectedPCNModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var affectedPCNColumns = [
            {text: 'PCN编号', dataIndex: 'pcnNumber', width:120,menuDisabled: true, editor: false},
            {text: '附件',xtype:'actioncolumn', dataIndex: 'annex', width: 200, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden: isEditable(pcn_upload,pcn_upload_node)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            changeRequestId = changeRequestId;
                            // //设置当前列的id与列名和表名
                            fileColumnId = record.data.id;
                            fileColumnName = 'annex';
                            uploadTableName = 'ZPcnInfoTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = '';
                            var ECUploadImageWindow = initECUploadImageWindow();
                            ECUploadImageWindow.show()
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.specification;
                            // if(boolean!=null) {
                            //     return true;
                            // }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            changeRequestId = changeRequestId;
                            //设置当前列的id与列名和表名
                            fileColumnId = record.data.id;
                            fileColumnName = 'annex';
                            uploadTableName = 'ZPcnInfoTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = '';
                            var ECShowFiles = initECShowFiles();
                            ECShowFiles.show()
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.specification;
                            // if(boolean!=null) {
                                return false;
                            // }
                            // return true;
                        }
                    }
                ]
            }
        ];

        var affectedPCNGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var affectedPCNGrid = Ext.create('Ext.grid.Panel', {
            plugins: [affectedPCNGridEditing],
            store: affectedPCNStore,
            columns: affectedPCNColumns,
            id:'affectedPCNGrid',
            autoWidth: true,
            columnLines: true,
            margin: '5 10 2 0',
            selType: 'checkboxmodel',
            // height:'100%',
            height:110,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            tbar: [{
                text: '添加',
                iconCls : 'icon icon-add',
                disabled:false,
                scope: this,
                hidden: isEditable(pcn_upload,pcn_upload_node)?false:true,
                handler : function(){
                    var addRecord = {
                        tableName:"ZAffectedObjectTable",
                        changeRequestId:changeRequestId
                    };
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/pcnInfo/addPcnInfo',
                        params: {addRecord:Ext.encode(addRecord)},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=="success") {
                                //回调函数，一般用于后台操作成功后刷新列表
                                affectedPCNStore.load();
                            } else {
                                alert(obj.message);
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：保存信息失败，请检查网络！!');
                        }
                    });
                }
            },'&nbsp;',{
                text : '删除',
                iconCls : 'icon icon-delete',
                disabled:false,
                scope:this,
                hidden: isEditable(pcn_upload,pcn_upload_node)?false:true,
                handler:function(){
                    var selected = affectedPCNGrid.getSelectionModel().getSelection();
                    if (selected.length != 0) {
                        let ids = '';
                        for (let i = 0; i < selected.length; i++) {
                            let id = selected[i].get('id');
                            if (id) {
                                if(i == 0){
                                    ids += id;
                                }else{
                                    ids += ',' + id;
                                }
                            }
                        }
                        let callbackFn = function (response, opts) {
                            affectedPCNStore.load();
                            affectedPCNGrid.view.refresh();
                        };
                        var deleteRecord = {
                            dbTableName:"ZAffectedObjectTable",
                            ids:ids,
                            changeRequestId:changeRequestId
                        };
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/pcnInfo/deletePcnInfo',
                            params: {deleteRecord:Ext.encode(deleteRecord)},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=="success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    if (callbackFn) {
                                        callbackFn(response, opts);
                                    }
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    } else {
                        alert("请选择一条数据")
                    }
                }
            }]//~end of tbar
        });
        //====================================PCN文件结束====================================================================





//========== 开始  partChangeGrid================
        Ext.define('ctAffectedObjectsTableModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','changeObject','comeFromPotential','objectNumber','version','name','moldSizeNumber','status','objectType','subtype','belongingPdt',
                'specialCustomers','needPcn', 'pcnNumber','illustrate','pr','total','completedQuantity','unfinishedQuantity','supplier',
                'suppliersInProduction','supplierInventory', 'absorptionQuantity', 'rawMaterialInventory','averageMonthlyConsumption','cycleInventory',
                'inProduction','finishedProductInventory','shipped','unProducedOrders', 'handlingOpinions', 'materialHandlingInstructions','modifyMold',
                'moldModificationCycle','productionTrial','trialPerson','trialReportNumber','trialConclusion', 'sampleConfirmation',
                'sampleConfirmationNumber','sampleConfirmationStatus','remarks','objectUrl','detailType','interiorVersion','validationSuggestions'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.ctAffectedObjectsTableStore = Ext.create('Ext.data.Store', {
            model: 'ctAffectedObjectsTableModel',
            id:'ctAffectedObjectsTableStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/newEc/getAffectedObject?changeRequestId=' + changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });

        //PCN编号
        var pcnNumberCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'pcnNumberCombo',
            id: 'pcnNumberCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['pcnNumber']
            },
            valueField: 'pcnNumber',
            displayField: 'pcnNumber'
        });

        //是否是变更对象
        let changeObjectStore = [['是', '是'], ['否', '否']];

        //是否需要PCN
        let needPcnStore = [['是', '是'], ['否', '否']];

        //处理意见
        let handlingOpinionsStore = [['立即切换', '立即切换'], ['自然切换', '自然切换'], ['条件切换', '条件切换'],['配套切换', '配套切换']];

        //是否需要改模
        let modifyMoldStore = [['是', '是'], ['否', '否']];

        //是否需要试产试用
        let productionTrialStore = [['是', '是'], ['否', '否']];

        //小批量验证建议
        let validationSuggestionsStore = [['是', '是'], ['否', '否']];

        //试产试用负责人
        var trialPersonStore = new Ext.data.ArrayStore({
            id: 'trialPersonStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var trialPersonCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'trialPerson',
            id: 'trialPerson',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: trialPersonStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });

        //是否需要样品确认
        let sampleConfirmationStore = [['是', '是'], ['否', '否']];

        //版本
        var versionCombo2 = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'versionCombo2',
            id: 'versionCombo2',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['version']
            },
            valueField: 'version',
            displayField: 'version'
        });

        //试产试用报告编号
        var trialReportNumberCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'trialReportNumberCombo',
            id: 'trialReportNumberCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['trialReportNumber']
            },
            valueField: 'trialReportNumber',
            displayField: 'trialReportNumber'
        });

        //供应商信息
        var supplierNameStore = new Ext.data.ArrayStore({
            id: 'supplierNameStore',
            fields: [
                {name: "supplierName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/supplierNameList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var supplierAffectedCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'supplierAffectedCombo',
            id: 'supplierAffectedCombo',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: supplierNameStore,
            valueField: 'supplierName',
            displayField: 'supplierName',
            minChars : 1,//开始查询最小字符数
            mode : 'local', //查询模式  local为本地数据源  remote为远程服务端
        });


        var ctAffectedObjectsTableCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var ctAffectedObjectsTableGrid = Ext.create('Ext.grid.Panel', {
            plugins: [ctAffectedObjectsTableCellEditing],
            store: Ext.getStore('ctAffectedObjectsTableStore'),
            id: 'ctAffectedObjectsTableGrid',
            margin: '30 10 0 0',
            title: '受影响对象清单：',
            autoWidth: true,
            columnLines: true,
            height:480,
            width:'100%',
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection: true },
            selType: 'checkboxmodel',
            columns: [
                {
                    text: '是否是变更对象',
                    dataIndex: 'changeObject',
                    width: 50,
                    menuDisabled: true,
                    editAccess: false,
                    editor: {
                        xtype: 'combobox',
                        editable: false,
                        forceSelection: false,
                        store: changeObjectStore
                    },
                    renderer:showTip
                    , locked: true
                },
                {
                    text: '是否从潜在受影响物料清单收集',
                    dataIndex: 'comeFromPotential',
                    width: 80,
                    editAccess: false,
                    editor: 'textfield',
                    menuDisabled: true,
                    renderer:showTip
                    , locked: true
                },
                {
                    text: setMust('编号',objectNumberAffected),
                    dataIndex: 'objectNumber', width: 80, editAccess: true,
                    editor: objectNumberAffected?'textfield':false, menuDisabled: true,renderer:showTip,
                    locked: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            var changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {
                    text: setMust('版本',version),
                    dataIndex: 'version',
                    width: 60,
                    editAccess: true,
                    menuDisabled: true,
                    renderer:showTip,
                    editor: version?versionCombo2:false
                    , locked: true
                },
                {text: '名称', dataIndex: 'name', width: 100, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip, locked: true
                    // ,renderer:function(value,metaData,record,row,col,store){
                    //     return '<div style="white-space: normal;">' + value + '</div>' ;
                    // }
                },
                {text: '内部版本', dataIndex: 'interiorVersion', width: 100, editAccess: false, editor: 'textfield',menuDisabled: true,renderer:showTip, locked: true},
                {text: '模具尺寸编号', dataIndex: 'moldSizeNumber', width: 100, editAccess: false, editor: 'textfield',menuDisabled: true,renderer:showTip, locked: true},
                {text: '状态', dataIndex: 'status', width: 60, editAccess: false, editor: true, editor: 'textfield', menuDisabled: true,renderer:showTip, locked: true},
                {text: '对象类型', dataIndex: 'objectType', width: 60, editAccess: false, editor: true, editor: 'textfield', menuDisabled: true,renderer:showTip, locked: true},
                {text: '子类型', dataIndex: 'subtype', width: 60, editAccess: false, editor: true, editor: 'textfield', menuDisabled: true,renderer:showTip, locked: true},
                {text: '所属PDT', dataIndex: 'belongingPdt', width: 80, editAccess: false, editor: true, editor: 'textfield', menuDisabled: true,renderer:showTip, locked: true},
                {
                    text: '样品确认',menuDisabled: true,
                    columns: [
                        {
                            text: setMust('是否需要样品确认',needSampleConfirmation),
                            dataIndex: 'sampleConfirmation',
                            width: 60,
                            editAccess: needSampleConfirmation,
                            menuDisabled: true,renderer:showTip,
                            editor: {
                                xtype: 'combobox',
                                editable: false,
                                forceSelection: false,
                                store: sampleConfirmationStore
                            },
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if('文档' == r.get('objectType') || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 60px;"';
                                }
                                return value;
                            }
                        },
                        {
                            text: '样品确认单号',
                            dataIndex: 'sampleConfirmationNumber',
                            width: 80,
                            editAccess: false,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer:showTip,
                            locked: true,
                            renderer: function(value,metaData,record,row,col,store){
                                var link = record.get('sampleConfirmationNumber');
                                return link
                            },
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if('文档' == r.get('objectType') || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                                }
                                return value;
                            }
                        },
                        {text: '样品确认状态', dataIndex: 'sampleConfirmationStatus', width: 80, editAccess: false, menuDisabled: true,renderer:showTip},
                    ]
                },
                {
                    text: '改模情况',menuDisabled: true,
                    columns: [
                        {
                            text: setMust('是否需要改模', modifyMold),
                            dataIndex: 'modifyMold',
                            width: 60,
                            editAccess: modifyMold,
                            menuDisabled: true,
                            renderer:showTip,
                            editor: {
                                xtype: 'combobox',
                                editable: false,
                                forceSelection: false,
                                store: modifyMoldStore
                            },
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if('文档' == r.get('objectType') || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 60px;"';
                                }
                                return value;
                            }
                        },
                        {
                            text: setMust('改模周期（天）', moldModificationCycle),
                            dataIndex: 'moldModificationCycle',
                            width: 80,
                            editAccess: moldModificationCycle,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer:showTip,
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if('文档' == r.get('objectType') || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                                }
                                return value;
                            }
                        },
                    ]
                },
                {
                    text: 'PCN管理',menuDisabled: true,
                    columns: [
                        {
                            text: '特殊客户', dataIndex: 'specialCustomers', width: 100, editAccess: false, editor: 'textfield',
                            menuDisabled: true,renderer:showTip,
                            renderer: function (value, meta, r) {
                                //不是成品，则底色置灰
                                let color = '#C7CECF';
                                if('成品' != r.get('subtype')){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                                }
                                return value;
                            }
                        },
                        {
                            text: setRequired('是否需要PCN',needPcnAffected),
                            dataIndex: 'needPcn',
                            width: 80,
                            editAccess: true,
                            editor: needPcnAffected?
                                {
                                xtype: 'combobox',
                                editable: false,
                                forceSelection: false,
                                store: needPcnStore
                            }
                            :false
                            ,
                            menuDisabled: true,
                            renderer:showTip,
                            renderer: function (value, meta, r) {
                                //不是成品，则底色置灰
                                let color = '#C7CECF';
                                if('成品' != r.get('subtype')){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                                }
                                return value;
                            }
                        },
                        {
                            text: setRequired('PCN编号',pcnNumberAffected),
                            dataIndex: 'pcnNumber',
                            width: 100,
                            editAccess: true,
                            menuDisabled: true,
                            renderer:showTip,
                            editor: pcnNumberAffected?pcnNumberCombo:false,
                            renderer: function (value, meta, r) {
                                //不是成品，则底色置灰
                                let color = '#C7CECF';
                                if('成品' != r.get('subtype')){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                                }
                                return value;
                            }
                        },
                        {
                            text: setRequired('说明',illustrateAffected), dataIndex: 'illustrate', width: 100,
                            editAccess: true, editor: illustrateAffected, menuDisabled: true,renderer:showTip,
                            renderer: function (value, meta, r) {
                                //不是成品，则底色置灰
                                let color = '#C7CECF';
                                if('成品' != r.get('subtype')){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                                }
                                return value;
                            }
                        },
                    ]
                },
                {
                    text: '信息收集',menuDisabled: true,
                    columns: [
                        {text: '原材料',   menuDisabled: true,
                            columns: [
                                {text: 'PR', dataIndex: 'pr', width: 80, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                {text: 'PO', menuDisabled: true,
                                    columns: [
                                        {text: '总数', dataIndex: 'total', width: 80, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                        {text: '已完成数量', dataIndex: 'completedQuantity', width: 100, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                        {text: '未完成数量', dataIndex: 'unfinishedQuantity', width: 80, editAccess: false,editor: 'textfield', menuDisabled: true,renderer:showTip},
                                    ]
                                },
                                {text: '供应商信息',   menuDisabled: true,
                                    columns: [
                                        {
                                            text: setMust('供应商名称',supplierAffected),
                                            dataIndex: 'supplier',
                                            width: 100,
                                            editAccess: supplierAffected,
                                            editor: supplierAffectedCombo,
                                            menuDisabled: true,
                                            renderer:showTip
                                        },
                                        {text: setMust('供应商在制',suppliersInProductionAffected), dataIndex: 'suppliersInProduction', width: 100, editAccess: true, editor: suppliersInProductionAffected, menuDisabled: true,renderer:showTip},
                                        {text: setMust('供应商实际库存',supplierInventoryAffected), dataIndex: 'supplierInventory', width: 100, editAccess: true, editor: supplierInventoryAffected, menuDisabled: true,renderer:showTip},
                                        {text: setMust('三江吸收数量',absorptionQuantityAffected), dataIndex: 'absorptionQuantity', width: 100, editAccess: true, editor: absorptionQuantityAffected, menuDisabled: true,renderer:showTip},
                                        {text: setRequired('备注',remarksAffected), dataIndex: 'remarks', width: 100, editAccess: true, editor: remarksAffected, menuDisabled: true,renderer:showTip}
                                    ]
                                },
                                {text: setRequired('三江库存',rawMaterialInventoryAffected), dataIndex: 'rawMaterialInventory', width: 100, editAccess: false, editor: rawMaterialInventoryAffected, menuDisabled: true,renderer:showTip},
                                {text: '每月平均消耗用量', dataIndex: 'averageMonthlyConsumption', width: 120, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                {text: '库存（PO已完成数量 + 三江吸收数量 + 库存）可支持生产周期', dataIndex: 'cycleInventory', width: 100, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                            ]
                        },
                        {text: '成品/半成品',    menuDisabled: true,
                            columns: [
                                {text: setRequired('在制',inProductionAffected), dataIndex: 'inProduction', width: 80, editAccess: false, editor: inProductionAffected, menuDisabled: true,renderer:showTip},
                                {text: setRequired('库存',finishedProductInventoryAffected), dataIndex: 'finishedProductInventory', width: 80, editAccess: false, editor: finishedProductInventoryAffected, menuDisabled: true,renderer:showTip},
                                {text: setRequired('已发货（一年内）',shippedAffected), dataIndex: 'shipped', width: 80, editAccess: false, editor: shippedAffected, menuDisabled: true,renderer:showTip},
                                {text: setRequired('已录销售订单但未生产',unProducedOrdersAffected), dataIndex: 'unProducedOrders', width: 80, editAccess: false, editor: unProducedOrdersAffected, menuDisabled: true,renderer:showTip},
                            ]
                        },
                    ]
                },
                {
                    text: '物料处理',menuDisabled: true,
                    columns: [
                        {
                            text: setRequired('处理意见',handlingOpinionsAffected),
                            dataIndex: 'handlingOpinions',
                            width: 100,
                            editAccess: true,
                            menuDisabled: true,
                            renderer:showTip,
                            editor: handlingOpinionsAffected?
                                {
                                xtype: 'combobox',
                                editable: false,
                                forceSelection: false,
                                store: handlingOpinionsStore
                            }
                            :false,
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if((r.get('version') && '原材料' != r.get('subtype') && r.get('version').indexOf('Manufacturing') < 0)
                                    || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                                }
                                return value;
                            }
                        },
                        {
                            text: setRequired('处理意见说明',materialHandlingInstructionsAffected),
                            dataIndex: 'materialHandlingInstructions',
                            width: 100,
                            editAccess: materialHandlingInstructionsAffected,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer:showTip,
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if((r.get('version') && '原材料' != r.get('subtype') && r.get('version').indexOf('Manufacturing') < 0)
                                    || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                                }
                                return value;
                            }
                        },
                    ]
                },
                {
                    text: '小批量验证跟踪结果',menuDisabled: true,
                    columns: [
                        {
                            text: setMust('小批量验证建议',validationSuggestionsAccess),
                            dataIndex: 'validationSuggestions',
                            width: 100,
                            editAccess: validationSuggestionsAccess,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer:showTip,
                            editor: {
                                xtype: 'combobox',
                                editable: false,
                                forceSelection: false,
                                store: validationSuggestionsStore
                            },
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if((r.get('version') && '原材料' != r.get('subtype') && r.get('version').indexOf('Manufacturing') < 0)
                                    || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                                }
                                return value;
                            }
                        },
                        {
                            text: setRequired('小批量验证确认',productionTrialAffected),
                            dataIndex: 'productionTrial',
                            width: 80,
                            editAccess: productionTrialAffected,
                            menuDisabled: true,
                            renderer:showTip,
                            editor: productionTrialAffected?
                                {
                                xtype: 'combobox',
                                editable: false,
                                forceSelection: false,
                                store: productionTrialStore
                            }
                            :false,
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if((r.get('version') && '原材料' != r.get('subtype') && r.get('version').indexOf('Manufacturing') < 0)
                                    || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 80px;"';
                                }
                                return value;
                            }
                        },
                        // {
                        //     text: setRequired('试产试用负责人',productionTrialAffected),
                        //     dataIndex: 'trialPerson',
                        //     width: 100,
                        //     editAccess: productionTrialAffected,
                        //     menuDisabled: true,
                        //     renderer:showTip,
                        //     editor: trialPersonCom
                        // },
                        {
                            text: setRequired('小批量验证流程编号',trialReportNumberAffected),
                            dataIndex: 'trialReportNumber',
                            width: 100,
                            editAccess: trialReportNumberAffected,
                            menuDisabled: true,
                            renderer:showTip,
                            editor: trialReportNumberCombo,
                            renderer: function (value, meta, r) {
                                let color = '#C7CECF';
                                if((r.get('version') && '原材料' != r.get('subtype') && r.get('version').indexOf('Manufacturing') < 0)
                                    || ('原材料' == r.get('subtype') && (r.get('objectNumber') && "139" == r.get('objectNumber').substring(0, 3)))){
                                    meta.tdAttr = 'style="background-color: ' + color + ';width: 100px;"';
                                }
                                return value;
                            }
                        },
                        {
                            text: '小批量验证流程结论',
                            dataIndex: 'trialConclusion',
                            width: 100,
                            editAccess: false,
                            menuDisabled: true,
                            renderer:showTip
                        },
                    ]
                }
            ],
            tbar: [{
                text: '下载模板',
                iconCls : 'icon icon-download',
                disabled:false,
                scope: this,
                hidden: downloadAffected?false:true,
                handler: function () {
                    window.location.href = '/Windchill/template/受影响对象导入模板.xlsx', '', 'width=300,height=200';
                }
            },'&nbsp;',{
                text : '导入变更对象',
                iconCls : 'icon-excelImport',
                disabled:false,
                scope:this,
                hidden: excelImportAffected?false:true,
                handler:function(){
                    importAffectedObjects();
                }
            },'&nbsp;',{
                text : '增加行',
                iconCls : 'icon icon-add',
                disabled:false,
                scope:this,
                hidden: addAffected?false:true,
                handler:function(){
                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.message=='success') {
                            Ext.getStore('ctAffectedObjectsTableStore').load();
                        }else {
                            alert(obj.message);
                        }
                    };
                    insertAffectedObject(callbackFn);
                }
            },'&nbsp;',{
                text : '删除行',
                iconCls : 'icon icon-delete',
                disabled:false,
                scope:this,
                hidden: deleteAffected?false:true,
                handler:function(){
                    let selected = ctAffectedObjectsTableGrid.getSelectionModel().getSelection();
                    if (selected.length === 0) {
                        alert('请选择数据！');
                    } else {
                        function callbackFn() {
                            ctAffectedObjectsTableGrid.getStore().remove(selected);
                            ctAffectedObjectsTableGrid.view.refresh();
                        }
                        let param = [];
                        for (let i = 0; i < selected.length; i++) {
                            let id = selected[i].get('id');
                            if (id) {
                                param[i] = id;
                            }
                        }
                        if (param.length !== 0) {
                            deleteAffectedObjectsData(JSON.stringify(param), callbackFn);
                        }
                    }
                }
            },'&nbsp;',{
                text : '刷新集成数据',
                iconCls : 'icon icon-refresh',
                disabled:false,
                scope:this,
                hidden: refreshAffected?false:true,
                handler:function(){
                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.message=='success') {
                            Ext.getStore('ctAffectedObjectsTableStore').load();
                            Ext.Msg.alert("提示", "刷新成功！");
                        }else {
                            alert(obj.message);
                        }
                    };
                    refreshAffectedObjectsSapData(callbackFn);
                }
            },'&nbsp;',{
                text : '同步数据到ECA',
                iconCls : 'icon icon-refresh',
                disabled:false,
                scope:this,
                hidden: synchronizeAffectedObjectsToECA?false:true,
                handler:function(){
                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.message=='success') {
                            // Ext.getStore('ctAffectedObjectsTableStore').load();
                            Ext.Msg.alert("提示", "刷新成功！");
                        }else {
                            alert(obj.message);
                        }
                        refreshEcaData();
                    };
                    synchronizeAffectedObjects(callbackFn);
                }
            }
            ,'&nbsp;',
            {
                xtype: 'combo',
                fieldLabel: '是否需要改模',
                labelWidth: 80,
                width: 160,
                hidden: isEditable(submit_change_request)?false:true,
                enableKeyEvents: true,
                store: {data:[{modifyMold:'是'},{modifyMold:'否'}]}, // 下拉框的选项数据
                editable: false, // 设置为不可编辑
                valueField: 'modifyMold',
                displayField: 'modifyMold',
                tpl: getXTemplate('modifyMold'),
                listeners:{
                    change: function (combo) {
                        let value = combo.value;
                        if(!value){
                            return;
                        }
                        let selected = ctAffectedObjectsTableGrid.getSelectionModel().getSelection();
                        if (selected.length === 0) {
                            combo.setValue('');
                            alert('请选择数据！');
                        } else {
                            function callbackFn() {
                                combo.setValue('');
                                ctAffectedObjectsTableGrid.getSelectionModel().deselectAll();
                                Ext.getStore('ctAffectedObjectsTableStore').load();
                            }
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let r = selected[i]
                                let id = r.get('id');
                                if (id) {
                                    if(ids == ''){
                                        ids += id;
                                    }else{
                                        ids += "," + id;
                                    }
                                }
                            }
                            if (ids.length > 0) {
                                batchUpdateAffectedObjectsData(ids, 'modifyMold', value, callbackFn);
                            }
                        }
                    }
                }
            },'&nbsp;',
            {
                xtype: 'combo',
                fieldLabel: '小批量验证确认',
                labelWidth: 120,
                width: 200,
                hidden: productionTrialAffected?false:true,
                enableKeyEvents: true,
                store: {data:[{productionTrial:'是'},{productionTrial:'否'}]}, // 下拉框的选项数据
                editable: false, // 设置为不可编辑
                valueField: 'productionTrial',
                displayField: 'productionTrial',
                tpl: getXTemplate('productionTrial'),
                listeners:{
                    change: function (combo) {
                        let value = combo.value;
                        if(!value){
                            return;
                        }
                        let selected = ctAffectedObjectsTableGrid.getSelectionModel().getSelection();
                        if (selected.length === 0) {
                            combo.setValue('');
                            alert('请选择数据！');
                        } else {
                            function callbackFn() {
                                combo.setValue('');
                                ctAffectedObjectsTableGrid.getSelectionModel().deselectAll();
                                Ext.getStore('ctAffectedObjectsTableStore').load();
                            }
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let r = selected[i]
                                let id = r.get('id');
                                if(r.get('version') && r.get('subtype') && r.get('objectNumber')){
                                    //不能编辑的过滤掉
                                    if(r.get('version').indexOf('Manufacturing') < 0 && ('原材料' != r.get('subtype') || "139" == r.get('objectNumber').substring(0, 3))){
                                        continue;
                                    }
                                }
                                if (id) {
                                    if(ids == ''){
                                        ids += id;
                                    }else{
                                        ids += "," + id;
                                    }
                                }
                            }
                            if (ids.length > 0) {
                                batchUpdateAffectedObjectsData(ids, 'productionTrial', value, callbackFn);
                            }
                        }
                    }
                }
            },'&nbsp;',
            {
                xtype: 'combo',
                fieldLabel: '是否需要样品确认',
                labelWidth: 120,
                width: 200,
                enableKeyEvents: true,
                hidden: needSampleConfirmation?false:true,
                store: {data:[{sampleConfirmation:'是'},{sampleConfirmation:'否'}]}, // 下拉框的选项数据
                editable: false, // 设置为不可编辑
                valueField: 'sampleConfirmation',
                displayField: 'sampleConfirmation',
                tpl: getXTemplate('sampleConfirmation'),
                listeners:{
                    change: function (combo) {
                        let value = combo.value;
                        if(!value){
                            return;
                        }
                        let selected = ctAffectedObjectsTableGrid.getSelectionModel().getSelection();
                        if (selected.length === 0) {
                            combo.setValue('');
                            alert('请选择数据！');
                        } else {
                            function callbackFn() {
                                combo.setValue('');
                                ctAffectedObjectsTableGrid.getSelectionModel().deselectAll();
                                Ext.getStore('ctAffectedObjectsTableStore').load();
                            }
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let r = selected[i]
                                let id = r.get('id');
                                //不能编辑的过滤掉
                                if('原材料' != r.get('subtype') || "139" == r.get('objectNumber').substring(0, 3)){
                                    continue;
                                }
                                if (id) {
                                    if(ids == ''){
                                        ids += id;
                                    }else{
                                        ids += "," + id;
                                    }
                                }
                            }
                            if (ids.length > 0) {
                                batchUpdateAffectedObjectsData(ids, 'sampleConfirmation', value, callbackFn);
                            }
                        }
                    }
                }
            },'&nbsp;',
            {
                xtype: 'combo',
                fieldLabel: '处理意见',
                labelWidth: 60,
                width: 160,
                hidden: handlingOpinionsAffected?false:true,
                enableKeyEvents: true,
                store: {data:[{handlingOpinions:'立即切换'},{handlingOpinions:'自然切换'}
                        ,{handlingOpinions:'条件切换'}
                        ,{handlingOpinions:'配套切换'}]}, // 下拉框的选项数据
                editable: false, // 设置为不可编辑
                valueField: 'handlingOpinions',
                displayField: 'handlingOpinions',
                tpl: getXTemplate('handlingOpinions'),
                listeners:{
                    change: function (combo) {
                        let value = combo.value;
                        if(!value){
                            return;
                        }
                        let selected = ctAffectedObjectsTableGrid.getSelectionModel().getSelection();
                        if (selected.length === 0) {
                            combo.setValue('');
                            alert('请选择数据！');
                        } else {
                            function callbackFn() {
                                combo.setValue('');
                                ctAffectedObjectsTableGrid.getSelectionModel().deselectAll();
                                Ext.getStore('ctAffectedObjectsTableStore').load();
                            }
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let r = selected[i]
                                let id = r.get('id');
                                if(r.get('version') && r.get('subtype') && r.get('objectNumber')){
                                    //不能编辑的过滤掉
                                    if(r.get('version').indexOf('Manufacturing') < 0 && ('原材料' != r.get('subtype') || "139" == r.get('objectNumber').substring(0, 3))){
                                        continue;
                                    }
                                }
                                if (id) {
                                    if(ids == ''){
                                        ids += id;
                                    }else{
                                        ids += "," + id;
                                    }
                                }
                            }
                            if (ids.length > 0) {
                                batchUpdateAffectedObjectsData(ids, 'handlingOpinions', value, callbackFn);
                            }
                        }
                    }
                }
            },'&nbsp;',
            {
                xtype: 'combo',
                fieldLabel: '小批量验证建议',
                labelWidth: 90,
                width: 160,
                hidden: validationSuggestionsAccess?false:true,
                enableKeyEvents: true,
                store: {data:[{validationSuggestion:'是'},{validationSuggestion:'否'}]}, // 下拉框的选项数据
                editable: false, // 设置为不可编辑
                valueField: 'validationSuggestion',
                displayField: 'validationSuggestion',
                tpl: getXTemplate('validationSuggestion'),
                listeners:{
                    change: function (combo) {
                        let value = combo.value;
                        if(!value){
                            return;
                        }
                        let selected = ctAffectedObjectsTableGrid.getSelectionModel().getSelection();
                        if (selected.length === 0) {
                            combo.setValue('');
                            alert('请选择数据！');
                        } else {
                            function callbackFn() {
                                combo.setValue('');
                                ctAffectedObjectsTableGrid.getSelectionModel().deselectAll();
                                Ext.getStore('ctAffectedObjectsTableStore').load();
                            }
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let r = selected[i]
                                let id = r.get('id');
                                if(r.get('version') && r.get('subtype') && r.get('objectNumber')){
                                    //不能编辑的过滤掉
                                    if(r.get('version').indexOf('Manufacturing') < 0 && ('原材料' != r.get('subtype') || "139" == r.get('objectNumber').substring(0, 3))){
                                        continue;
                                    }
                                }
                                if (id) {
                                    if(ids == ''){
                                        ids += id;
                                    }else{
                                        ids += "," + id;
                                    }
                                }
                            }
                            if (ids.length > 0) {
                                batchUpdateAffectedObjectsData(ids, 'validationSuggestions', value, callbackFn);
                            }
                        }
                    }
                }
            }
            ]//~end of tbar
        });

        ctAffectedObjectsTableGrid.on('rowclick', function (view, record, item, index, e){
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'pcnNumber') {
                    pcnNumberCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/newEc/getPcnNumberSet?changeRequestId=' + changeRequestId + "&tableType=ZAffectedObjectTable",
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                let pcnNumberList = Ext.decode(response.responseText).data;
                                pcnNumberList.map(function (item) {
                                    pcnNumberCombo.getStore().add({pcnNumber: item});
                                })
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }

                if (columnName == 'version') {
                    let objectNumber = record.get('objectNumber');
                    versionCombo2.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/newEc/getVersion?number=' + objectNumber,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                let versionList = Ext.decode(response.responseText).data;
                                versionList.map(function (item) {
                                    versionCombo2.getStore().add({version: item});
                                })
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }

                if (columnName == 'trialReportNumber') {
                    let objectNumber = record.get('objectNumber');
                    trialReportNumberCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/newEc/getTrialOrderList?partNumber=' + objectNumber,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                let trialReportNumberList = Ext.decode(response.responseText).data;
                                if(trialReportNumberList){
                                    trialReportNumberList.map(function (item) {
                                        trialReportNumberCombo.getStore().add({trialReportNumber: item});
                                    })
                                }
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }

                //供应商
                // var objectNumber = record.get('objectNumber');
                // var objectType = record.get('objectType');
                // if(objectNumber && '部件'== objectType && columnName == 'supplier'){
                //     supplierAffectedCombo.getStore().removeAll();
                //     Ext.Ajax.request({
                //         url: '/Windchill/ptc1/trial/getSupplierByPartNumber?partNumber=' + objectNumber,
                //         method:'GET',
                //         headers: {'Content-Type':'application/json'},
                //         success: function (response, opts) {
                //             var obj = Ext.decode(response.responseText);
                //             if(obj.message=='success') {
                //                 var supplierInfoList = Ext.decode(response.responseText).data;
                //                 if(supplierInfoList){
                //                     supplierInfoList.map(function(item) {
                //                         supplierAffectedCombo.getStore().add({supplierInfo:item.supplierInfo});
                //                     })
                //                 }
                //             }else {
                //                 alert(obj.message)
                //             }
                //         },
                //         failure: function (response, opts) {
                //             alert('错误：删除信息失败，请检查网络！!');
                //         }
                //     });
                // }
            }
        });

        ctAffectedObjectsTableGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            var record = e.record;
            if(!'objectNumber' == f && !'version' == f){
                if(!r.get('objectNumber') || !r.get('version')){
                    Ext.Msg.alert('提示', '请先填写编号！');
                    return false;
                }
            }

            var subtype = record.get('subtype');

            //是否需要PCN\PCN编号\说明
            if('specialCustomers' == f || 'pcnNumber' == f || 'needPcn' == f || 'illustrate' == f){
                if('成品' != subtype){
                    return false;
                }
            }

            //139开头的原材料，不能编辑处理意见，处理意见说明，小批量验证建议，小批量验证确认，小批量验证流程编号，是否需要样品确认，样品确认单号，是否需要改模，改模周期
            if(f == 'handlingOpinions' || f == 'materialHandlingInstructions' || f == 'validationSuggestions'
                || f == 'productionTrial' || f == 'trialReportNumber' || f == 'sampleConfirmation' || f == 'sampleConfirmationNumber'
                || f == 'modifyMold' || f == 'moldModificationCycle'){
                if('文档' == r.get('objectType') || ('原材料' == r.get('subtype') && "139" == r.get('objectNumber').substring(0, 3))){
                    return false;
                }
            }

            //成品/半成品的D视图，不能编辑处理意见，处理意见说明，小批量验证建议，小批量验证确认，小批量验证流程编号
            if(f == 'handlingOpinions' || f == 'materialHandlingInstructions' || f == 'validationSuggestions'
                || f == 'productionTrial' || f == 'trialReportNumber'){
                if('原材料' != r.get('subtype') && r.get('version').indexOf('Manufacturing') < 0){
                    return false;
                }
            }
            return checkEditAccess(e); // 校验字段编辑权限
        });

        ctAffectedObjectsTableGrid.on('edit', function (editor, e) {
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let oldValue = e.originalValue; // 旧值
            let id = record.get('id');
            if (value === oldValue) {
                record.reject();
                return; // 没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.message=='success') {
                    var obj = Ext.decode(response.responseText);
                    e.record.commit();
                    Ext.getStore('ctAffectedObjectsTableStore').load();
                }else {
                    alert(obj.message)
                }
            };
            updateAffectedData(id, field, value, callbackFn);
        });

        var belongingPdtStore2 = new Ext.data.ArrayStore({
            id: 'belongingPdtStore2',
            fields: [
                {name: "belongingPdt"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/newEc/getPDTSet',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var belongingPdtCom2 = new Ext.form.ComboBox({
            xtype: 'combo',
            fieldLabel: '所属PDT',
            name: 'belongingPdtCom2',
            id: 'belongingPdtCom2',
            multiSelect: false,
            editable: false,
            width: 340,
            store: belongingPdtStore2,
            valueField: 'belongingPdt',
            displayField: 'belongingPdt',
            tpl: getXTemplate('belongingPdt')
        });

        var ctAffectedObjectsTablePanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: '1. ECR_申请人（提交）',
            padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            width:'99.9%',
            items:[
                {
                    xtype: 'fieldset',
                    margin: '20 3 15 3',
                    // title: '<font style="font-size:12px">物料替代报表</font>',
                    collapsible: true,
                    defaults: {
                        labelWidth: 100,
                        border: false,
                        anchor: '99%',
                        layout: {
                            type: 'hbox'
                        }
                    },
                    items: [
                        {
                            xtype: 'panel',
                            defaults: {margin: '15 20 20 0', labelWidth: 70},
                            items: [
                                belongingPdtCom2,
                                {
                                    xtype: 'combobox',
                                    fieldLabel: '对象视图',
                                    name: 'affectedObjectView',
                                    id: 'affectedObjectView',
                                    width: 250,
                                    enableKeyEvents: true,
                                    store: {data:[{viewName:''},{viewName:'Design'},{viewName:'Manufacturing'}]}, // 下拉框的选项数据
                                    queryMode: 'local', // 查询模式
                                    editable: false, // 设置为不可编辑
                                    valueField: 'viewName',
                                    displayField: 'viewName',
                                    tpl: getXTemplate('viewName')
                                },
                                {
                                    xtype: 'combobox',
                                    fieldLabel: '对象类型',
                                    name: 'affectedObjectType',
                                    id: 'affectedObjectType',
                                    width: 250,
                                    enableKeyEvents: true,
                                    store: {data:[{affectedObjectType:''},{affectedObjectType:'部件'},{affectedObjectType:'文档'},{affectedObjectType:'图纸'}]}, // 下拉框的选项数据
                                    queryMode: 'local', // 查询模式
                                    editable: false, // 设置为不可编辑
                                    valueField: 'affectedObjectType',
                                    displayField: 'affectedObjectType',
                                    tpl: getXTemplate('affectedObjectType'),
                                    listeners: {
                                        change: function(combo) {
                                            let subTypeCom = Ext.getCmp('affectedSubtypeCom');
                                            if(subTypeCom){
                                                subTypeCom.setValue("");
                                            }
                                        }
                                    }
                                },
                                affectedSubtypeCom,
                                {
                                    xtype:'button',
                                    // margin:'10 0 10 0',
                                    width:70,
                                    text: '搜索（B）',
                                    scope:this,
                                    iconCls: 'icon icon-search',
                                    handler: function() {
                                        affectedDoSearch();
                                    }
                                }
                            ]
                        }
                    ]
                },
                ctAffectedObjectsTableGrid,
                affectedPCNGrid
            ]
        });

        this.items = [
            ctAffectedObjectsTablePanel
        ];

        this.callParent();

        //========== 结束  PartChangeGrid================

    }
})

/**
 * 按查询参数查询
 */
function affectedDoSearch() {
    var params = {
        changeRequestId: changeRequestId,
        pdt: Ext.getCmp('belongingPdtCom2').getValue(),
        viewName: Ext.getCmp('affectedObjectView').getValue(),
        type: Ext.getCmp('affectedObjectType').getValue(),
        subType: Ext.getCmp('affectedSubtypeCom').getValue(),
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/searchAffectedTableData',
        method: 'GET',
        params: {
            param:Ext.encode(params)
        },
        success: function(response) {
            var responseData = Ext.decode(response.responseText);
            // 处理返回的数据

            // 将数据赋值给另一个 store
            Ext.getStore('ctAffectedObjectsTableStore').loadData(responseData.data);
        },
        failure: function(response) {
            // 处理请求失败的情况
        }
    });
}