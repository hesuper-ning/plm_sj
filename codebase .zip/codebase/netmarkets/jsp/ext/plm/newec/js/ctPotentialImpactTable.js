Ext.define('PLM.view.ctPotentialImpactTablePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctPotentialImpactTablePanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:800,
    id: 'ctPotentialImpactTablePanel',
    initComponent: function (){
        var belongingPdtStore = new Ext.data.ArrayStore({
            id: 'belongingPdtStore',
            fields: [
                {name: "belongingPdt"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/newEc/getPDTSet',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var belongingPdtCom = new Ext.form.ComboBox({
            xtype: 'combo',
            fieldLabel: '所属PDT',
            name: 'belongingPdtCom',
            id: 'belongingPdtCom',
            multiSelect: false,
            editable: false,
            width: 330,
            store: belongingPdtStore,
            valueField: 'belongingPdt',
            displayField: 'belongingPdt',
            tpl: getXTemplate('belongingPdt')
        });

        var subtypeStore = new Ext.data.ArrayStore({
            id: 'subtypeStore',
            fields: [
                {name: "subtype"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/newEc/getSubType',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var subtypeCom = new Ext.form.ComboBox({
            xtype: 'combo',
            fieldLabel: '子类型',
            name: 'subtypeCom',
            id: 'subtypeCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            labelWidth: 60,
            width: 180,
            store: subtypeStore,
            valueField: 'subtype',
            displayField: 'subtype',
            minChars: 1, //开始查询最小字符数
            mode: 'local', //查询模式  local为本地数据源  remote为远程服务端
            listeners: {
                expand: function(combo) {
                    subtypeStore.load({
                        params: {
                            type: Ext.getCmp('objectType').getValue(),
                        }
                    });
                }
            }
        });

        //编号
        var objectNumberPotential = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme
            ,product_data_engineer_confirm_info,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager
            ,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
        );

        //版本
        var versionPotential = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme
            ,product_data_engineer_confirm_info,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager
            ,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
        );

        //是否受影响
        var affectedOrNotPotential = isEditable(

        );

        //是否立即变更
        var changeItImmediatelyPotential = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme
            ,product_data_engineer_confirm_info,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager
            ,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
        );

        //处理意见说明
        var opinionExplanationPotential = isEditable(

        );
        //是否需要改模
        var modifyMoldPotential = isEditable(

        );
        //是否需要试产试用
        var productionTrialPotential = isEditable(

        );
        //是否需要样品确认
        var sampleConfirmationPotential = isEditable(

        );
        //增加初始收集对象（B）
        var insertPotential = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme
            ,product_data_engineer_confirm_info,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager
            ,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
        );
        //移除初始收集对象（B）
        var deletePotential = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme
            ,product_data_engineer_confirm_info,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager
            ,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
        );
        //点击刷新集成数据
        var refreshPotential = isEditable(

        );
        //同步数据到受影响对象表格
        var synchronousPotential = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme
            ,product_data_engineer_confirm_info,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager
            ,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
        );
        //重新收集
        var againPotential = isEditable(
            head_node,ebomCharge_node,mbomCharge_node,dateManageMajor_node,general_change_ECA_PDMSR,submit_change_request,formulate_MBOM_programme
            ,product_data_engineer_confirm_info,design_change_initiation2,product_data_management_supervisor_review,design_change_initiation3,mbom_change_manager
            ,product_data_management_supervisor_review3,design_change_initiation4,product_data_management_supervisor_review4
        );




//========== 开始  partChangeGrid================
        Ext.define('ctPotentialImpactTableModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','changeRequestId','initialObject','objectNumber','version','name','moldSizeNumber','associateEMBom','status',
                'objectType','subtype','meetConditions',
                'notClosedProcess','belongingPdt','affectedOrNot','changeItImmediately','opinionExplanation','confirmResume','pr','po',
                'supplier','suppliersInProduction','supplierInventory','absorptionQuantity',
                'rawMaterialInventory','inProduction','finishedProductInventory',
                'shipped','unProducedOrders','modifyMold','productionTrial','sampleConfirmation','objectUrl',
                'parentId','nodePath','collectScenes', 'topParent', 'directParent','interiorVersion'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.ctPotentialImpactTableStore = Ext.create('Ext.data.TreeStore', {
            model: 'ctPotentialImpactTableModel',
            id:'ctPotentialImpactTableStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/newEc/getPotentialAffectedObject',
                method: 'GET',
                extraParams: {
                    changeRequestId:changeRequestId,
                    showView:showView,
                    pdt: pdt,
                    viewName: viewName,
                    type: type,
                    subType: subType,
                    changeObject: changeObject,
                    effectObject: effectObject,
                    objectNumber:objectNumber
                },
                timeout: 99999999,
                reader:{
                    type:'json',
                }
            }),
            root: {
                expanded: true
            },
            autoLoad:true,
            folderSort: true,
            listeners:{
                beforeload: function (store, options) {
                    let param = {
                        changeRequestId:changeRequestId,
                        showView:showView,
                        pdt: pdt,
                        viewName: viewName,
                        type: type,
                        subType: subType,
                        changeObject: changeObject,
                        effectObject: effectObject,
                        objectNumber:objectNumber
                    };
                    Ext.apply(store.proxy.extraParams, param);
                },
                // load: function (store, opts) {
                //     if('view3' == showView){
                //         let tree = Ext.getCmp('ctPotentialImpactTableGrid');
                //         tree.expandAll();
                //     }
                // }
            }
        });

        var ctPotentialImpactTableCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        //版本
        var versionCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'versionCombo',
            id: 'versionCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['version']
            },
            valueField: 'version',
            displayField: 'version'
        });

        //是否初始对象
        let initialObjectStore = [['Y', 'Y'], ['N', 'N']];

        //是否受影响
        let affectedOrNotStore = [['是', '是'], ['否', '否']];

        //是否立即变更
        let changeItImmediatelyStore = [['是', '是'], ['否', '否']];

        //是否需要改模
        let modifyMoldStore = [['是', '是'], ['否', '否']];

        //是否需要试产试用
        let productionTrialStore = [['是', '是'], ['否', '否']];

        //是否需要样品确认
        let sampleConfirmationStore = [['是', '是'], ['否', '否']];

        var ctPotentialImpactTableGrid = Ext.create('Ext.tree.Panel', {
            plugins: [ctPotentialImpactTableCellEditing],
            store: Ext.getStore('ctPotentialImpactTableStore'),
            id: 'ctPotentialImpactTableGrid',
            margin: '30 10 20 0',
            title: '潜在受影响对象清单：',
            rootVisible: false,
            autoWidth: true,
            columnLines: true,
            height:580,
            autoScroll: true,
            border: 0,
            viewConfig: { enableTextSelection: true },
            selType: 'checkboxmodel',
            columns: [
                {
                    text: '初始对象', dataIndex: 'initialObject',
                    width: 40, menuDisabled: true,
                    editAccess: false,
                    // editor: {
                    //     xtype: 'combobox',
                    //     editable: false,
                    //     forceSelection: false,
                    //     store: initialObjectStore
                    // },
                    renderer:showTip
                    , locked: true
                },
                {
                    xtype: 'treecolumn',
                    text: setMust('编号',objectNumberPotential),
                    dataIndex: 'objectNumber',
                    width: 120,
                    editAccess: true,
                    editor: objectNumberPotential, menuDisabled: true, renderer:showTip, locked: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            var changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {
                    text: '来源',
                    dataIndex: 'collectScenes',
                    width: 100,
                    editAccess: false,
                    menuDisabled: true,
                    renderer:showTip,
                    locked: true
                },
                {
                    text: setMust('版本', versionPotential),
                    dataIndex: 'version',
                    width: 60,
                    editAccess: true,
                    menuDisabled: true,
                    renderer:showTip,
                    editor: versionPotential?versionCombo:false
                    , locked: true
                },
                {
                    text: '名称', dataIndex: 'name', width: 60, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip, locked: true
                    // ,renderer:function(value,metaData,record,row,col,store){
                    //     return '<div style="white-space: normal;">' + value + '</div>' ;
                    // }
                },
                {text: '内部版本', dataIndex: 'interiorVersion', width: 80, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip,locked: true},
                {
                    text: '状态', dataIndex: 'status', width: 60, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip, locked: true
                },
                {
                    text: '对象类型', dataIndex: 'objectType', width: 60, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip, locked: true
                },
                {
                    text: '子类型', dataIndex: 'subtype', width: 60, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip, locked: true
                },
                {
                    text: '是否满足变更对象收集条件', dataIndex: 'meetConditions', width: 80, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip, locked: true
                },
                {
                    text: '未关闭流程', dataIndex: 'notClosedProcess', width: 60, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip, locked: true
                },
                {
                    text: '所属PDT', dataIndex: 'belongingPdt', width: 60, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip, locked: true
                },
                {
                    text: '模具尺寸编号', dataIndex: 'moldSizeNumber', width: 80, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip
                },
                {
                    text: '关联EBOM/MBOM', dataIndex: 'associateEMBom', width: 100, editAccess: false, menuDisabled: true,
                    editor: {xtype: 'textfield', selectOnFocus: true},
                    renderer:showTip
                },
                {
                    text: '是否需要变更确认',menuDisabled: true,
                    columns: [
                        {
                            text: setRequired('是否受影响',affectedOrNotPotential),
                            dataIndex: 'affectedOrNot',
                            width: 80,
                            editAccess: true,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer:showTip,
                            editor: affectedOrNotPotential?
                                {
                                xtype: 'combobox',
                                editable: false,
                                forceSelection: false,
                                store: affectedOrNotStore
                            }
                            :false
                        },
                        {
                            text: setRequired('是否确认变更',changeItImmediatelyPotential),
                            dataIndex: 'changeItImmediately',
                            width: 80, editAccess: true,
                            menuDisabled: true,renderer:showTip,
                            editor: changeItImmediatelyPotential?
                                {
                                xtype: 'combobox',
                                editable: false,
                                forceSelection: false,
                                store: changeItImmediatelyStore
                            }
                            :false
                        },
                        // {text: setRequired('处理意见说明',opinionExplanationPotential), dataIndex: 'opinionExplanation', width: 95, editAccess: true,
                        //     editor: opinionExplanationPotential, menuDisabled: true,renderer:showTip},
                        // {
                        //     text: setRequired('是否需要改模',modifyMoldPotential),
                        //     dataIndex: 'modifyMold',
                        //     width: 80,
                        //     menuDisabled: true,renderer:showTip,
                        //     editAccess: true,
                        //     editor: modifyMoldPotential?
                        //         {
                        //             xtype: 'combobox',
                        //             editable: false,
                        //             forceSelection: false,
                        //             store: modifyMoldStore
                        //         }
                        //         :false
                        // },
                        // {
                        //     text: setRequired('是否需要试产试用',productionTrialPotential),
                        //     dataIndex: 'productionTrial',
                        //     width: 110,
                        //     editAccess: true,
                        //     menuDisabled: true,renderer:showTip,
                        //     editor: productionTrialPotential?
                        //         {
                        //             xtype: 'combobox',
                        //             editable: false,
                        //             forceSelection: false,
                        //             store: productionTrialStore
                        //         }
                        //         :false
                        // },
                        // {
                        //     text: setRequired('是否需要样品确认',sampleConfirmationPotential),
                        //     dataIndex: 'sampleConfirmation',
                        //     width: 110,
                        //     editAccess: true,
                        //     menuDisabled: true,renderer:showTip,
                        //     editor: sampleConfirmationPotential?
                        //         {
                        //             xtype: 'combobox',
                        //             editable: false,
                        //             forceSelection: false,
                        //             store: sampleConfirmationStore
                        //         }
                        //         :false
                        // },
                        {
                            text: '确认履历',
                            dataIndex: 'confirmResume',
                            width: 60,
                            editAccess: true,
                            // editor: 'textfield',
                            editor:false,
                            menuDisabled: true,
                            renderer: showTip
                        },
                        {
                            text: 'SAP是否存在',
                            dataIndex: 'sapExist',
                            width: 80,
                            menuDisabled: true
                        },
                    ]
                },
                {
                    text: '信息收集',menuDisabled: true,
                    columns: [
                        {text: '原材料',   menuDisabled: true,
                            columns: [
                                {text: 'PR', dataIndex: 'pr', width: 80, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                {text: 'PO', dataIndex: 'po', width: 80, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                // {text: '供应商信息',   menuDisabled: true,
                                //     columns: [
                                //         {text: '供应商名称', dataIndex: 'supplier', width: 100, editAccess: true, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                //         {text: '供应商在制', dataIndex: 'suppliersInProduction', width: 100, editAccess: true, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                //         {text: '供应商实际库存', dataIndex: 'supplierInventory', width: 100, editAccess: true, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                //         {text: '三江吸收数量', dataIndex: 'absorptionQuantity', width: 100, editAccess: true, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                //     ]
                                // },
                                {text: '库存', dataIndex: 'rawMaterialInventory', width: 80, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                ]
                        },
                        {text: '成品/半成品',    menuDisabled: true,
                            columns: [
                                {text: '在制', dataIndex: 'inProduction', width: 80, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                {text: '库存', dataIndex: 'finishedProductInventory', width: 80, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                {text: '已发货（一年内）', dataIndex: 'shipped', width: 100, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                                {text: '已录销售订单但未生产', dataIndex: 'unProducedOrders', width: 130, editAccess: false, editor: 'textfield', menuDisabled: true,renderer:showTip},
                            ]
                        },
                    ]
                },
            ],
            tbar: [{
                text: '增加初始收集对象（B）',
                iconCls : 'icon icon-add',
                disabled:false,
                scope: this,
                hidden: insertPotential?false:true,
                handler : function(){
                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.message=='success') {
                            Ext.getStore('ctPotentialImpactTableStore').load();
                        }else {
                            alert(obj.message);
                        }
                    };
                    insertPotentialData(callbackFn);
                }
            },'&nbsp;',{
                text : '移除初始收集对象（B）',
                iconCls : 'icon icon-delete',
                disabled:false,
                scope:this,
                hidden: deletePotential?false:true,
                handler:function(){
                    let selected = ctPotentialImpactTableGrid.getSelectionModel().getSelection();
                    if (selected.length === 0) {
                        alert('请选择数据！');
                    } else {
                        function callbackFn() {
                            Ext.getStore('ctPotentialImpactTableStore').load();
                        }
                        let param = [];
                        for (let i = 0; i < selected.length; i++) {
                            let id = selected[i].get('id');
                            if (id) {
                                param[i] = id;
                            }
                        }
                        if (param.length !== 0) {
                            deletePotentialImpactData(JSON.stringify(param), callbackFn);
                        }
                    }
                }
            },
            // '&nbsp;',
            //     {
            //     text : '刷新集成数据',
            //     iconCls : 'icon icon-refresh',
            //     disabled:false,
            //     scope:this,
            //     hidden: refreshPotential?false:true,
            //     handler:function(){
            //         let callbackFn = function (response, opts) {
            //             var obj = Ext.decode(response.responseText);
            //             if(obj.message=='success') {
            //                 Ext.getStore('ctPotentialImpactTableStore').load();
            //                 Ext.Msg.alert("提示", "刷新成功！");
            //             }else {
            //                 alert(obj.message);
            //             }
            //         };
            //         refreshSapData(callbackFn);
            //     }
            // },
            '&nbsp;',{
                text : '同步到受影响对象表格',
                iconCls : 'icon icon-refresh',
                disabled:false,
                scope:this,
                hidden: synchronousPotential?false:true,
                handler:function(){
                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.message=='success') {
                            Ext.getStore('ctAffectedObjectsTableStore').load();
                            Ext.Msg.alert("提示", "同步数据成功！");
                        }else {
                            alert(obj.message);
                        }
                    };
                    refreshAffectedObject(callbackFn);
                }
            },'&nbsp;',{
                text : '重新收集',
                iconCls : 'icon icon-refresh',
                disabled:false,
                scope:this,
                hidden: againPotential?false:true,
                handler:function(){
                    let callbackFn = function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.message=='success') {
                            Ext.getStore('ctPotentialImpactTableStore').load();
                            Ext.Msg.alert("提示", "刷新数据成功！");
                        }else {
                            alert(obj.message);
                        }
                    };
                    refreshCollectObject(callbackFn);
                }
            },'&nbsp;',{
                text : '默认(显示第一层)',
                cls: showView == 'view0'?'highlight-btn':'normal-ec-btn',
                disabled:false,
                id: 'showView0',
                scope:this,
                hidden: againPotential?false:true,
                handler:function(){
                    showView = 'view0';
                    setBtnCls(showView);
                    Ext.getStore('ctPotentialImpactTableStore').load();
                }
            },'&nbsp;',{
                text : '显示第一层&顶层',
                cls: showView == 'view1'?'highlight-btn':'normal-ec-btn',
                disabled:false,
                id: 'showView1',
                scope:this,
                hidden: againPotential?false:true,
                handler:function(){
                    showView = 'view1';
                    setBtnCls(showView);
                    Ext.getStore('ctPotentialImpactTableStore').load();
                }
            },'&nbsp;',{
                text : '显示顶层',
                id: 'showView2',
                cls: showView == 'view2'?'highlight-btn':'normal-ec-btn',
                disabled:false,
                scope:this,
                hidden: againPotential?false:true,
                handler:function(){
                    showView = 'view2';
                    setBtnCls(showView);
                    Ext.getStore('ctPotentialImpactTableStore').load();
                }
            },'&nbsp;',{
                text : '展开所有层',
                id: 'showView3',
                cls: showView == 'view3'?'highlight-btn':'normal-ec-btn',
                disabled:false,
                scope:this,
                hidden: againPotential?false:true,
                handler:function(){
                    showView = 'view3';
                    setBtnCls(showView);
                    Ext.getStore('ctPotentialImpactTableStore').load();
                }
            },'&nbsp;',
            {
                xtype: 'combo',
                fieldLabel: '是否确认变更',
                labelWidth: 80,
                width: 160,
                hidden: changeItImmediatelyPotential?false:true,
                enableKeyEvents: true,
                store: {data:[{changeObject:'是'},{changeObject:'否'}]}, // 下拉框的选项数据
                editable: false, // 设置为不可编辑
                valueField: 'changeObject',
                displayField: 'changeObject',
                tpl: getXTemplate('changeObject'),
                listeners:{
                    change: function (combo) {
                        let value = combo.value;
                        if(!value){
                            return;
                        }
                        let selected = ctPotentialImpactTableGrid.getSelectionModel().getSelection();
                        if (selected.length === 0) {
                            combo.setValue('');
                            alert('请选择数据！');
                        } else {
                            function callbackFn() {
                                combo.setValue('');
                                ctPotentialImpactTableGrid.getSelectionModel().deselectAll();
                                Ext.getStore('ctPotentialImpactTableStore').load();
                            }
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let r = selected[i]
                                let id = r.get('id');
                                if('Y' == r.get('topParent') && 'Y' != r.get('directParent') && '是' == r.get('meetConditions')){
                                    //不可编辑的条目，则跳过
                                    continue;
                                }
                                if (id) {
                                    if(ids == ''){
                                        ids += id;
                                    }else{
                                        ids += "," + id;
                                    }
                                }
                            }
                            if (ids.length > 0) {
                                batchUpdatePotentialAffectedData(ids, 'changeItImmediately', value, callbackFn);
                            }
                        }
                    }
                }
            }
            ]//~end of tbar
        });

        ctPotentialImpactTableGrid.on('rowclick', function (view, record, item, index, e){
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'version') {
                    let objectNumber = record.get('objectNumber');
                    versionCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/newEc/getVersion?number=' + objectNumber,
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                let versionList = Ext.decode(response.responseText).data;
                                versionList.map(function (item) {
                                    versionCombo.getStore().add({version: item});
                                })
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        });

        ctPotentialImpactTableGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值

            //是否立即变更为是，是否受影响不允许编辑
            if(f == 'affectedOrNot' && '是' == r.get('changeItImmediately')){
                Ext.Msg.alert('提示','“是否立即变更”为是，“是否受影响”不允许编辑');
                return false;
            }
            //原材料或成品/半成品的M视图，才能编辑“是否需要试产试用”属性
            if(f == 'productionTrial'){
                if(r.get('version') && r.get('version').indexOf('Manufacturing') < 0 && '原材料' != r.get('subtype')){
                    return false;
                }
            }
            //如果是顶层父项，是否受影响不允许编辑
            if(f == 'affectedOrNot'){
                if('Y' == r.get('topParent') && 'Y' != r.get('directParent')){
                    //Ext.Msg.alert('提示','顶层父项的“是否受影响”不允许编辑');
                    return false;
                }
            }
            //如果是顶层父项，“是否满足变更对象收集条件”为是，“是否立即变更”不允许编辑()
            if(f == 'changeItImmediately'){
                if('Y' == r.get('topParent') && 'Y' != r.get('directParent') && '是' == r.get('meetConditions')){
                    //Ext.Msg.alert('提示','顶层父项的“是否立即变更”不允许编辑');
                    return false;
                }
                if('所有层级父项' == r.get('collectScenes') && '是' == r.get('meetConditions')){
                    return false;
                }
            }
            //不是初始对象的版本字段不能编辑
            if(f == 'version' && 'Y' != r.get('initialObject')){
                return false;
            }
            return checkEditAccess(e); // 校验字段编辑权限
        });

        ctPotentialImpactTableGrid.on('edit', function (editor, e) {
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let oldValue = e.originalValue; // 旧值
            let id = record.get('id');
            if (value === oldValue) {
                record.reject();
                return; // 没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.message=='success') {
                    var obj = Ext.decode(response.responseText);
                    e.record.commit();
                    Ext.getStore('ctPotentialImpactTableStore').load();
                }else {
                    alert(obj.message)
                }
            };
            updatePotentialAffectedData(id, field, value, callbackFn);
        });

        var ctPotentialImpactTablePanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: '1. ECR_申请人（提交）',
            padding:'10',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            width:'99.9%',
            items:[
                {
                    xtype: 'fieldset',
                    margin: '15 3 15 3',
                    // title: '<font style="font-size:12px">物料替代报表</font>',
                    collapsible: true,
                    defaults: {
                        labelWidth: 100,
                        border: false,
                        anchor: '99%',
                        layout: {
                            type: 'hbox'
                        }
                    },
                    items: [
                        {
                            xtype: 'panel',
                            defaults: {margin: '15 20 20 0', labelWidth: 70},
                            items: [
                                // {
                                //     xtype: 'combobox',
                                //     fieldLabel: '所属PDT',
                                //     name: 'belongingPdt',
                                //     id: 'belongingPdt',
                                //     width: 250,
                                //     enableKeyEvents: true,
                                //     store:belongingPdtCom
                                // },
                                belongingPdtCom,
                                {
                                    xtype: 'combobox',
                                    fieldLabel: '对象视图',
                                    name: 'objectView',
                                    id: 'objectView',
                                    width: 170,
                                    enableKeyEvents: true,
                                    store: {data:[{objectView:''},{objectView:'Design'},{objectView:'Manufacturing'}]}, // 下拉框的选项数据
                                    queryMode: 'local', // 查询模式
                                    editable: false, // 设置为不可编辑
                                    valueField: 'objectView',
                                    displayField: 'objectView',
                                    tpl: getXTemplate('objectView')
                                },
                                {
                                    xtype: 'combobox',
                                    fieldLabel: '对象类型',
                                    name: 'objectType',
                                    id: 'objectType',
                                    width: 150,
                                    enableKeyEvents: true,
                                    store: {data:[{objectType:''},{objectType:'部件'},{objectType:'文档'},{objectType:'图纸'}]}, // 下拉框的选项数据
                                    queryMode: 'local', // 查询模式
                                    editable: false, // 设置为不可编辑
                                    valueField: 'objectType',
                                    displayField: 'objectType',
                                    tpl: getXTemplate('objectType'),
                                    listeners: {
                                        change: function(combo) {
                                            let subTypeCom = Ext.getCmp('subtypeCom');
                                            if(subTypeCom){
                                                subTypeCom.setValue("");
                                            }
                                        }
                                    }
                                },
                                subtypeCom,
                                {
                                    xtype: 'textfield',
                                    fieldLabel: '编号',
                                    labelWidth: 50,
                                    width: 150,
                                    id: 'objectNumber',
                                    name: 'objectNumber'
                                },
                                {
                                    xtype: 'combobox',
                                    fieldLabel: '变更对象',
                                    name: 'changeObject',
                                    id: 'changeObject',
                                    labelWidth: 60,
                                    width: 120,
                                    enableKeyEvents: true,
                                    store: {data:[{changeObject:''},{changeObject:'是'},{changeObject:'否'}]}, // 下拉框的选项数据
                                    queryMode: 'local', // 查询模式
                                    editable: false, // 设置为不可编辑
                                    valueField: 'changeObject',
                                    displayField: 'changeObject',
                                    tpl: getXTemplate('changeObject')
                                },
                                {
                                    xtype: 'combobox',
                                    fieldLabel: '受影响对象',
                                    name: 'affectedObjects',
                                    id: 'affectedObjects',
                                    width: 120,
                                    enableKeyEvents: true,
                                    store: {data:[{affectedObjects:''},{affectedObjects:'是'},{affectedObjects:'否'}]}, // 下拉框的选项数据
                                    queryMode: 'local', // 查询模式
                                    editable: false, // 设置为不可编辑
                                    valueField: 'affectedObjects',
                                    displayField: 'affectedObjects',
                                    tpl: getXTemplate('affectedObjects')
                                },
                                {
                                    xtype:'button',
                                    id: 'showView4',
                                    width:70,
                                    text: '搜索（B）',
                                    scope:this,
                                    iconCls: 'icon icon-search',
                                    handler: function() {
                                        pdt = Ext.getCmp('belongingPdtCom').getValue();
                                        viewName = Ext.getCmp('objectView').getValue();
                                        type = Ext.getCmp('objectType').getValue();
                                        subType = Ext.getCmp('subtypeCom').getValue();
                                        changeObject = Ext.getCmp('changeObject').getValue();
                                        effectObject = Ext.getCmp('affectedObjects').getValue();
                                        objectNumber = Ext.getCmp('objectNumber').getValue();
                                        changeRequestId = changeRequestId;
                                        showView = 'view4';
                                        setBtnCls(showView);
                                        Ext.getStore('ctPotentialImpactTableStore').load();
                                    }
                                }
                            ]
                        },
                    ]
                },
                ctPotentialImpactTableGrid
            ]
        });

        this.items = [
            ctPotentialImpactTablePanel
        ];

        this.callParent();
        //========== 结束  PartChangeGrid================
    }
})

/**
 * 按查询参数查询
 */
function doSearch01() {
    // var vvv= Ext.getCmp('type').getValue();
    // if(Ext.getCmp('type').getValue()==null){
    //     alert("必须选择查询类型！")
    //     return;
    // }

    var params = {
        changeRequestId: changeRequestId,
        pdt: Ext.getCmp('belongingPdtCom').getValue(),
        viewName: Ext.getCmp('objectView').getValue(),
        type: Ext.getCmp('objectType').getValue(),
        subType: Ext.getCmp('subtypeCom').getValue(),
        changeObject: Ext.getCmp('changeObject').getValue(),
        effectObject: Ext.getCmp('affectedObjects').getValue(),
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/searchTableData',
        method: 'GET',
        params: {
            param:Ext.encode(params)
        },
        success: function(response) {
            var responseData = Ext.decode(response.responseText);
            // 处理返回的数据

            // 将数据赋值给另一个 store
            Ext.getStore('ctPotentialImpactTableStore').loadData(responseData.data);
        },
        failure: function(response) {
            // 处理请求失败的情况
        }
    });



    // Ext.getStore('ctPotentialImpactTableStore').load({
    //     params: {
    //         pdt: Ext.getCmp('belongingPdtCom').getValue(),
    //         viewName: Ext.getCmp('objectView').getValue(),
    //         type: Ext.getCmp('objectType').getValue(),
    //         subType: Ext.getCmp('subtypeCom').getValue(),
    //         changeObject: Ext.getCmp('changeObject').getValue(),
    //         effectObject: Ext.getCmp('affectedObjects').getValue(),
    //     },
    //     callback: function (records, operation, success) {
    //         if (!success) {
    //             var responseText = operation.getResponse().responseText;
    //             var responseObject = Ext.decode(responseText);
    //             alert(responseObject.message);
    //             // alert('查询信息失败，请联系管理员！');
    //         }
    //     }
    // });
}

