var submit_closedLoop='submit_closedLoop';//变更闭环_ECR闭环流程提交
var change_result_feedback='change_result_feedback';//变更闭环_变更结果执行反馈(质控部)
var change_result_feedback_technology='change_result_feedback_technology';//变更闭环_变更结果执行反馈(技术部)
var process_route_production='process_route_production';//变更闭环_变更结果执行反馈(工艺路线生产版本维护人)
var pcn_manager='pcn_manager';//变更闭环_变更结果执行反馈(PCN负责人)
var production_manager='production_manager';//变更闭环_变更结果执行反馈(生产部经理)
var procurement_executive_manager='procurement_executive_manager';//变更闭环_变更结果执行反馈(采购执行经理)
var procurement_execution_department='procurement_execution_department';//变更闭环_变更结果执行反馈(采购执行部)
var material_control_manager='material_control_manager';//变更闭环_变更结果执行反馈(物控经理)
var financial_supervisor='financial_supervisor';//变更闭环_变更结果执行反馈(财务主管)
var closed_loop_result_inspection='closed_loop_result_inspection';//变更闭环_闭环结果检查

Ext.define('PLM.view.EcclPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.EcclPanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:800,
    id: 'EcclPanel',
    initComponent: function (){
        //====================================受影响对象清单 开始====================================================================
        Ext.define('partChangeModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','version','name','moldSizeNumber','status','objectType','subtype','belongingPdt','pr','totality','completedQuantity',
                'unfinishedQuantity','supplier','supplierInventory','absorptionQuantity','rawMaterialInventory','averageConsumption','productionCycle',
                'inProduction','maintenanceTurnover', 'shipped','unProducedOrders','handlingOpinions','illustrate','productionTrial','trialProductionReport',
                'specialCustomers','requiredPcn','pcnNumber','pcnIllustrate','processChecklist','interiorVersion'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.partChangeStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'partChangeModel',
            id:'partChangeStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getAffectedObject?changeRequestId=' + changeRequestId + "&branchId=" + branchId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });

        //PCN编号
        var pcnNumberCombo1 = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'pcnNumberCombo1',
            id: 'pcnNumberCombo1',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['pcnNumber']
            },
            valueField: 'pcnNumber',
            displayField: 'pcnNumber'
        });

        var partChangeCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var partChangeGrid = Ext.create('Ext.grid.Panel', {
            plugins: [partChangeCellEditing],
            store: Ext.getStore('partChangeStore'),
            id: 'partChangeGrid',
            margin: '20 10 0 0',
            title: '受影响对象清单：',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '编号', dataIndex: 'objectNumber', width: 100,
                    menuDisabled: true, editAccess: false,
                    renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '版本', dataIndex: 'version', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                {text: '名称', dataIndex: 'name', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                {text: '内部版本', dataIndex: 'interiorVersion', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                {text: '模具尺寸编号', dataIndex: 'moldSizeNumber', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                {text: '状态', dataIndex: 'status', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                {text: '对象类型', dataIndex: 'objectType', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                {text: '子类型', dataIndex: 'subtype', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                {text: '所属PDT', dataIndex: 'belongingPdt', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                {
                    text: '信息收集',menuDisabled: true,
                    columns: [
                        {text: '原材料',   menuDisabled: true,
                            columns: [
                                {text: 'PR', dataIndex: 'pr', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                {text: 'PO',  menuDisabled: true,
                                    columns: [
                                        {text: '总数', dataIndex: 'totality', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                        {text: '已完成数量', dataIndex: 'completedQuantity', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                        {text: '未完成数量', dataIndex: 'unfinishedQuantity', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                    ]
                                },
                                {text: '供应商信息',   menuDisabled: true,
                                    columns: [
                                        {text: '供应商名称', dataIndex: 'supplier', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                        {text: '供应商实际库存', dataIndex: 'supplierInventory', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                        {text: '三江吸收数量', dataIndex: 'absorptionQuantity', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                    ]
                                },
                                {text: '库存', dataIndex: 'rawMaterialInventory', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                {text: '每月平均消耗用量', dataIndex: 'averageConsumption', width: 120, editAccess: false, menuDisabled: true,renderer:showTip},
                                {text: '库存（PO已完成数量 + 三江吸收数量 + 库存）可支持生产周期20', dataIndex: 'productionCycle', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                            ]
                        },
                        {text: '成品/半成品',    menuDisabled: true,
                            columns: [
                                {text: '在制', dataIndex: 'inProduction', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                {text: '维修周转', dataIndex: 'maintenanceTurnover', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                {text: '已发货', dataIndex: 'shipped', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                                {text: '已录销售订单但未生产', dataIndex: 'unProducedOrders', width: 130, editAccess: false, menuDisabled: true,renderer:showTip},
                            ]
                        },
                    ]
                },
                {  
                    text: '物料处理',menuDisabled: true,
                    columns: [ 
                        {text: '处理意见', dataIndex: 'handlingOpinions', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                        {text: '处理意见说明', dataIndex: 'illustrate', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                    ]
                },
                {
                    text: '试产跟踪结果',menuDisabled: true,
                    columns: [
                        {text: '是否需要试产', dataIndex: 'productionTrial', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                        {text: '试产报告', dataIndex: 'trialProductionReport', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                    ]
                },
                {
                    text: 'PCN管理',menuDisabled: true,
                    columns: [
                        {text: '特殊客户', dataIndex: 'specialCustomers', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                        {text: '是否需要PCN', dataIndex: 'requiredPcn', width: 100, editAccess: false, menuDisabled: true,renderer:showTip},
                        {
                            text: setRequired('PCN编号',isEditable(submit_closedLoop)),
                            dataIndex: 'pcnNumber',
                            width: 100,
                            editAccess: isEditable(submit_closedLoop),
                            editor: pcnNumberCombo1,
                            menuDisabled: true,
                            renderer:showTip
                        },
                        {
                            text: setRequired('说明',isEditable(submit_closedLoop)),
                            dataIndex: 'pcnIllustrate',
                            width: 100,
                            editAccess: isEditable(submit_closedLoop),
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer:showTip
                        },
                    ]
                },
                {text: '未完成闭环的流程清单', dataIndex: 'processChecklist', width: 200, editAccess: false, menuDisabled: true,renderer:showTip},
            ],
            tbar: []
        });

        partChangeGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var id = tRecord.get('id');
            Ext.Ajax.request({
                url: '/Windchill/ptc1/closedLoop/updateAffectedObject',
                params:{
                    branchId:branchId,
                    id:id,
                    field:tField,
                    value: tValue
                },
                success: function(response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(!obj['success']){
                        tRecord.reject();
                        alert(obj['msg']);
                        return;//中断
                    }
                    Ext.getStore('partChangeStore').load();
                },
                failure: function(response, opts) {
                    alert('网络连接异常，请检查网络！');
                }
            });
        });

        partChangeGrid.on('rowclick', function (view, record, item, index, e){
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'pcnNumber') {
                    pcnNumberCombo1.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/newEc/getPcnNumberSet?changeRequestId=' + changeRequestId + "&tableType=ZClosedLoopObjectTable",
                        method: 'GET',
                        headers: {'Content-Type': 'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                let pcnNumberList = Ext.decode(response.responseText).data;
                                pcnNumberList.map(function (item) {
                                    pcnNumberCombo1.getStore().add({pcnNumber: item});
                                })
                            } else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        });

        partChangeGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });

        //====================================受影响对象清单 结束====================================================================



        //====================================PCN文件开始====================================================================

        Ext.define('PCNModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','pcnNumber','annex'
            ],
            idProperty: 'PCNModel'
        });

        var PCNStore = Ext.create('Ext.data.Store', {
            model: 'PCNModel',
            id: 'PCNStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/pcnInfo/searchPcnInfo?changeRequestId='+changeRequestId+'&tableName=ZClosedLoopObjectTable',
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'PCNModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var PCNColumns = [
            {
                text: 'PCN编号',
                dataIndex: 'pcnNumber',
                width:100,menuDisabled: true,
                editor: false
            },
            {text: '附件',xtype:'actioncolumn', dataIndex: 'annex', width: 100, editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:isEditable(submit_closedLoop)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            changeRequestId = changeRequestId;
                            // //设置当前列的id与列名和表名
                            fileColumnId = record.data.id;
                            fileColumnName = 'annex';
                            uploadTableName = 'ZPcnInfoTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = '';
                            var ECUploadImageWindow = initECUploadImageWindow();
                            ECUploadImageWindow.show()
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.specification;
                            // if(boolean!=null) {
                            //     return true;
                            // }
                            return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            changeRequestId = changeRequestId;
                            //设置当前列的id与列名和表名
                            fileColumnId = record.data.id;
                            fileColumnName = 'annex';
                            uploadTableName = 'ZPcnInfoTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = '';
                            var ECShowFiles = initECShowFiles();
                            ECShowFiles.show()
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.specification;
                            // if(boolean!=null) {
                            return false;
                            // }
                            // return true;
                        }
                    }
                ]
            }
        ];

        var PCNGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var PCNGrid = Ext.create('Ext.grid.Panel', {
            plugins: [PCNGridEditing],
            store: PCNStore,
            columns: PCNColumns,
            id:'retrievalGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            tbar: [{
                text: '添加',
                iconCls : 'icon icon-add',
                disabled:disableNode(submit_closedLoop),
                scope: this,
                handler : function(){
                    var addRecord = {
                        tableName:"ZClosedLoopObjectTable",
                        changeRequestId:changeRequestId
                    };
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/pcnInfo/addPcnInfo',
                        params: {addRecord:Ext.encode(addRecord)},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=="success") {
                                //回调函数，一般用于后台操作成功后刷新列表
                                PCNStore.load();
                            } else {
                                alert(obj.message);
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：保存信息失败，请检查网络！!');
                        }
                    });
                }
            },'&nbsp;',{
                text : '删除',
                iconCls : 'icon icon-delete',
                disabled:disableNode(submit_closedLoop),
                scope:this,
                handler:function(){
                    var selected = PCNGrid.getSelectionModel().getSelection();
                    if (selected.length != 0) {
                        let ids = '';
                        for (let i = 0; i < selected.length; i++) {
                            let id = selected[i].get('id');
                            if (id) {
                                if(i == 0){
                                    ids += id;
                                }else{
                                    ids += ',' + id;
                                }
                            }
                        }
                        let callbackFn = function (response, opts) {
                            PCNStore.load();
                            PCNGrid.view.refresh();
                        };
                        var deleteRecord = {
                            dbTableName:"ZClosedLoopObjectTable",
                            ids:ids,
                            changeRequestId:changeRequestId
                        };
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/pcnInfo/deletePcnInfo',
                            params: {deleteRecord:Ext.encode(deleteRecord)},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=="success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    if (callbackFn) {
                                        callbackFn(response, opts);
                                    }
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    } else {
                        alert("请选择一条数据")
                    }
                }
            }]//~end of tbar
        });
        //====================================PCN文件结束====================================================================

        //====================================2.1 质控部  确认内容 开始====================================================================
        Ext.define('qualityControlDepartmentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','inspectionItems','inspectionResult','inspectionInstruction','uploadRequirement','attachmentUpload'
            ],
            idProperty: 'qualityControlDepartmentModel'
        });

        var qualityControlDepartmentStore = Ext.create('Ext.data.Store', {
            model: 'qualityControlDepartmentModel',
            id: 'qualityControlDepartmentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getClosedLoopConfirm?changeRequestId=' + changeRequestId + "&branchId=" + branchId + "&tableType=qualityControl",
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'qualityControlDepartmentModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var inspectionResultCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'inspectionResultCombo',
            id: 'inspectionResultCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['inspectionItem']
            },
            valueField: 'inspectionItem',
            displayField: 'inspectionItem'
        });

        var qualityControlDepartmentColumns = [
            {text: '点检项目', dataIndex: 'inspectionItems', flex: 1,menuDisabled: true, editAccess: false},
            {
                text: setMust('点检结果',isEditable(change_result_feedback)),
                dataIndex: 'inspectionResult',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(change_result_feedback),
                editor: inspectionResultCombo
            },
            {
                text: setRequired('点检说明',isEditable(change_result_feedback)),
                dataIndex: 'inspectionInstruction',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(change_result_feedback),
                editor: 'textfield'
            },
            {
                text: '相关附件',menuDisabled: true,
                columns: [
                    {
                        text: '附件上传要求',
                        dataIndex: 'uploadRequirement',
                        flex: 1,
                        editAccess: false,
                        editor: 'textfield',
                        menuDisabled: true,
                        renderer:showTip
                    },
                    {
                        text: setRequired('附件上传',isEditable(change_result_feedback)),
                        width: 200, align: 'center',xtype:'actioncolumn', dataIndex: 'attachmentUpload',
                        editAccess: isEditable(change_result_feedback),
                        menuDisabled: true,
                        items: [
                            '->',
                            {
                                iconCls: 'icon icon-uploadImage',
                                tooltip: '添加文件',
                                hidden:disableNode(change_result_feedback),
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    // //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECUploadImageWindow = initECUploadImageWindow();
                                    ECUploadImageWindow.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return true;
                                    // }
                                    // return false;
                                }
                            },
                            '-',
                            {
                                iconCls: 'icon-showInfo',
                                tooltip: '查看文件',
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECShowFiles = initECShowFiles();
                                    ECShowFiles.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return false;
                                    // }
                                    // return true;
                                }
                            }
                        ]
                    }
                ]
            }
        ];

        var qualityControlDepartmentGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var qualityControlDepartmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [qualityControlDepartmentGridEditing],
            store: qualityControlDepartmentStore,
            columns: qualityControlDepartmentColumns,
            id:'qualityControlDepartmentGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            listeners: {
                edit: function (editor, e) {
                    let record = e.record; // 得到当前行所有数据
                    let field = e.field;   // 得到修改列
                    let value = e.value;   // 得到修改列修改后的值
                    let oldValue = e.originalValue; // 旧值
                    let id = record.get('id');
                    if (value === oldValue) {
                        record.reject();
                        return; // 没有修改内容则返回
                    }
                    //成功回调方法
                    function successCallback(data) {
                        qualityControlDepartmentGrid.getStore().reload();
                    }
                    let params = {
                        branchId: branchId,
                        tableType: 'qualityControl',
                        id: id,
                        field: field,
                        value: value
                    };
                    sendRequest('/Windchill/ptc1/closedLoop/updateClosedConfirm', "POST", 'application/x-www-form-urlencoded'
                        , false, params, successCallback);
                }
            }
        });

        var qualityControlDepartmentPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title: '2.1 质控部  确认内容',
            padding: '5',
            collapsible: true,
            collapsed:openPanel(change_result_feedback),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                qualityControlDepartmentGrid,
                {
                    xtype: 'textfield',
                    fieldLabel:setRequired('其他说明',isEditable(change_result_feedback)),
                    readOnly:disableNode(change_result_feedback),
                    margin: '15 0 0 7',
                    id: 'qualityInstruction',
                    name: 'qualityInstruction',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('qualityInstruction', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 20 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'qualityPerson',
                            name: 'qualityPerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'qualityTime',
                            name: 'qualityTime'
                        }
                    ]
                }
            ]
        });

        qualityControlDepartmentGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });

        qualityControlDepartmentGrid.on('cellclick', function(obj,td,cellIndex,record,tr,rowIndex,e,eOpts){
            if(cellIndex == 1){
                if('试产是否合格' == record.get('inspectionItems')){
                    inspectionResultCombo.getStore().removeAll();
                    inspectionResultCombo.getStore().add({
                        inspectionItem: '是'
                    });
                    inspectionResultCombo.getStore().add({
                        inspectionItem: '否'
                    });
                }else{
                    inspectionResultCombo.getStore().removeAll();
                    inspectionResultCombo.getStore().add({
                        inspectionItem: '已完成'
                    });
                    inspectionResultCombo.getStore().add({
                        inspectionItem: '不涉及'
                    });
                }
            }
        });
        //====================================2.1 质控部  确认内容 结束====================================================================

        //====================================2.2 技术部  确认内容 开始====================================================================
        Ext.define('technologyDepartmentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','inspectionItems','inspectionResult','inspectionInstruction','uploadRequirement','attachmentUpload'
            ],
            idProperty: 'technologyDepartmentModel'
        });

        var technologyDepartmentStore = Ext.create('Ext.data.Store', {
            model: 'technologyDepartmentModel',
            id: 'technologyDepartmentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getClosedLoopConfirm?changeRequestId=' + changeRequestId + "&branchId=" + branchId + "&tableType=technology",
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'technologyDepartmentModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        let inspectionResultStore2 = [['已完成', '已完成'], ['不涉及', '不涉及']];

        var technologyDepartmentColumns = [
            {text: '点检项目', dataIndex: 'inspectionItems', flex: 1,menuDisabled: true, editAccess: false},
            {
                text: setMust('点检结果',isEditable(change_result_feedback_technology)),
                dataIndex: 'inspectionResult',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(change_result_feedback_technology),
                editor: {
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: inspectionResultStore2
                }
            },
            {
                text: setRequired('点检说明',isEditable(change_result_feedback_technology)),
                dataIndex: 'inspectionInstruction',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(change_result_feedback_technology),
                editor: 'textfield'
            },
            {
                text: '相关附件',menuDisabled: true,
                columns: [
                    {
                        text: '附件上传要求',
                        dataIndex: 'uploadRequirement',
                        flex: 1,
                        editAccess: false,
                        editor: 'textfield',
                        menuDisabled: true,
                        renderer:showTip
                    },
                    {
                        text: setRequired('附件上传',isEditable(change_result_feedback_technology)),
                        width: 200, align: 'center',
                        xtype:'actioncolumn', dataIndex: 'attachmentUpload', editAccess: false, menuDisabled: true,
                        items: [
                            '->',
                            {
                                iconCls: 'icon icon-uploadImage',
                                tooltip: '添加文件',
                                hidden:disableNode(change_result_feedback_technology),
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    // //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECUploadImageWindow = initECUploadImageWindow();
                                    ECUploadImageWindow.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return true;
                                    // }
                                    // return false;
                                }
                            },
                            '-',
                            {
                                iconCls: 'icon-showInfo',
                                tooltip: '查看文件',
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECShowFiles = initECShowFiles();
                                    ECShowFiles.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return false;
                                    // }
                                    // return true;
                                }
                            }
                        ]
                    }
                ]
            }
        ];

        var technologyDepartmentGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var technologyDepartmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [technologyDepartmentGridEditing],
            store: technologyDepartmentStore,
            columns: technologyDepartmentColumns,
            id:'technologyDepartmentGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            listeners: {
                edit: function (editor, e) {
                    let record = e.record; // 得到当前行所有数据
                    let field = e.field;   // 得到修改列
                    let value = e.value;   // 得到修改列修改后的值
                    let oldValue = e.originalValue; // 旧值
                    let id = record.get('id');
                    if (value === oldValue) {
                        record.reject();
                        return; // 没有修改内容则返回
                    }
                    //成功回调方法
                    function successCallback(data) {
                        technologyDepartmentGrid.getStore().reload();
                    }
                    let params = {
                        branchId: branchId,
                        tableType: 'technology',
                        id: id,
                        field: field,
                        value: value
                    };
                    sendRequest('/Windchill/ptc1/closedLoop/updateClosedConfirm', "POST", 'application/x-www-form-urlencoded'
                        , false, params, successCallback);
                }
            }
        });

        var technologyDepartmentPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title: '2.2 技术部  确认内容',
            padding: '5',
            collapsible: true,
            collapsed:openPanel(change_result_feedback_technology),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                technologyDepartmentGrid,
                {
                    xtype: 'textfield',
                    fieldLabel: setRequired('其他说明',isEditable(change_result_feedback_technology)),
                    readOnly:disableNode(change_result_feedback_technology),
                    margin: '15 0 0 7',
                    id: 'technologyInstruction',
                    name: 'technologyInstruction',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('technologyInstruction', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 20 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'technologyPerson',
                            name: 'technologyPerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'technologyTime',
                            name: 'technologyTime'
                        }
                    ]
                }
            ]
        });

        technologyDepartmentGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });
        //====================================2.2 技术部  确认内容 结束====================================================================


        //====================================2.3 物控部  确认内容 开始====================================================================
        Ext.define('materialControlDepartmentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','inspectionItems','inspectionResult','inspectionInstruction','uploadRequirement','attachmentUpload'
            ],
            idProperty: 'materialControlDepartmentModel'
        });

        var materialControlDepartmentStore = Ext.create('Ext.data.Store', {
            model: 'materialControlDepartmentModel',
            id: 'materialControlDepartmentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getClosedLoopConfirm?changeRequestId=' + changeRequestId + "&branchId=" + branchId + "&tableType=materialControl",
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'materialControlDepartmentModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        let inspectionResultStore3 = [['已完成', '已完成'], ['不涉及', '不涉及']];

        var materialControlDepartmentColumns = [
            {text: '点检项目', dataIndex: 'inspectionItems',  flex: 1,menuDisabled: true, editAccess: false},
            {
                text: setMust('点检结果',isEditable(material_control_manager)),
                dataIndex: 'inspectionResult',
                flex: 1,
                editAccess: isEditable(material_control_manager),
                menuDisabled: true,
                editor: {
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: inspectionResultStore3
                }
            },
            {
                text: '点检说明',
                text: setRequired('点检说明',isEditable(material_control_manager)),
                dataIndex: 'inspectionInstruction',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(material_control_manager),
                editor: 'textfield'
            },
            {
                text: '相关附件',menuDisabled: true,
                columns: [
                    {
                        text: '附件上传要求',
                        dataIndex: 'uploadRequirement',
                        flex: 1,
                        editAccess: false,
                        editor: 'textfield',
                        menuDisabled: true,
                        renderer:showTip
                    },
                    {
                        text: setRequired('附件上传',isEditable(material_control_manager)),
                        width: 200,
                        align: 'center',xtype:'actioncolumn', dataIndex: 'attachmentUpload', editAccess: false, menuDisabled: true,
                        items: [
                            '->',
                            {
                                iconCls: 'icon icon-uploadImage',
                                tooltip: '添加文件',
                                hidden:disableNode(material_control_manager),
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    // //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECUploadImageWindow = initECUploadImageWindow();
                                    ECUploadImageWindow.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return true;
                                    // }
                                    // return false;
                                }
                            },
                            '-',
                            {
                                iconCls: 'icon-showInfo',
                                tooltip: '查看文件',
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECShowFiles = initECShowFiles();
                                    ECShowFiles.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return false;
                                    // }
                                    // return true;
                                }
                            }
                        ]
                    }
                ]
            }
        ];

        var materialControlDepartmentGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var materialControlDepartmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [materialControlDepartmentGridEditing],
            store: materialControlDepartmentStore,
            columns: materialControlDepartmentColumns,
            id:'materialControlDepartmentGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            listeners: {
                edit: function (editor, e) {
                    let record = e.record; // 得到当前行所有数据
                    let field = e.field;   // 得到修改列
                    let value = e.value;   // 得到修改列修改后的值
                    let oldValue = e.originalValue; // 旧值
                    let id = record.get('id');
                    if (value === oldValue) {
                        record.reject();
                        return; // 没有修改内容则返回
                    }
                    //成功回调方法
                    function successCallback(data) {
                        materialControlDepartmentGrid.getStore().reload();
                    }
                    let params = {
                        branchId: branchId,
                        tableType: 'materialControl',
                        id: id,
                        field: field,
                        value: value
                    };
                    sendRequest('/Windchill/ptc1/closedLoop/updateClosedConfirm', "POST", 'application/x-www-form-urlencoded'
                        , false, params, successCallback);
                }
            }
        });

        var materialControlDepartmentPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title: '2.3 物控部  确认内容',
            padding: '5',
            collapsible: true,
            collapsed:openPanel(material_control_manager),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                materialControlDepartmentGrid,
                {
                    xtype: 'textfield',
                    fieldLabel: setRequired('其他说明',isEditable(material_control_manager)),
                    readOnly:disableNode(material_control_manager),
                    margin: '15 0 0 7',
                    id: 'materialInstruction',
                    name: 'materialInstruction',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('materialInstruction', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 20 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'materialPerson',
                            name: 'materialPerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'materialTime',
                            name: 'materialTime'
                        }
                    ]
                }
            ]
        });

        materialControlDepartmentGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });
        //====================================2.3 物控部  确认内容 结束====================================================================


        //====================================2.4 采购寻源部  确认内容 开始====================================================================
        Ext.define('purchasingDepartmentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','inspectionItems','inspectionResult','inspectionInstruction','uploadRequirement','attachmentUpload'
            ],
            idProperty: 'purchasingDepartmentModel'
        });

        var purchasingDepartmentStore = Ext.create('Ext.data.Store', {
            model: 'purchasingDepartmentModel',
            id: 'purchasingDepartmentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getClosedLoopConfirm?changeRequestId=' + changeRequestId + "&branchId=" + branchId + "&tableType=sourcing",
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'purchasingDepartmentModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        let inspectionResultStore4 = [['已完成', '已完成'], ['不涉及', '不涉及']];

        var purchasingDepartmentColumns = [
            {text: '点检项目', dataIndex: 'inspectionItems',  flex: 1,menuDisabled: true, editAccess: false},
            {
                text: setMust('点检结果',isEditable(procurement_execution_department)),
                dataIndex: 'inspectionResult',
                flex: 1,
                editAccess: isEditable(procurement_execution_department),
                menuDisabled: true,
                editor: {
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: inspectionResultStore4
                }
            },
            {
                text: setRequired('点检说明',isEditable(procurement_execution_department)),
                dataIndex: 'inspectionInstruction',
                flex: 1,menuDisabled: true,
                editAccess: isEditable(procurement_execution_department),
                editor: 'textfield'
            },
            {
                text: '相关附件',
                menuDisabled: true,
                columns: [
                    {
                        text: '附件上传要求',
                        dataIndex: 'uploadRequirement',
                        flex: 1,
                        editAccess: false,
                        editor: 'textfield',
                        menuDisabled: true,
                        renderer:showTip
                    },
                    {
                        text: setRequired('附件上传',isEditable(procurement_execution_department)),
                        width: 200, align: 'center',xtype:'actioncolumn', dataIndex: 'attachmentUpload', editAccess: false, menuDisabled: true,
                        items: [
                            '->',
                            {
                                iconCls: 'icon icon-uploadImage',
                                tooltip: '添加文件',
                                hidden:disableNode(procurement_execution_department),
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    // //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECUploadImageWindow = initECUploadImageWindow();
                                    ECUploadImageWindow.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return true;
                                    // }
                                    // return false;
                                }
                            },
                            '-',
                            {
                                iconCls: 'icon-showInfo',
                                tooltip: '查看文件',
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECShowFiles = initECShowFiles();
                                    ECShowFiles.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return false;
                                    // }
                                    // return true;
                                }
                            }
                        ]
                    }
                ]
            }
        ];

        var purchasingDepartmentGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var purchasingDepartmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [purchasingDepartmentGridEditing],
            store: purchasingDepartmentStore,
            columns: purchasingDepartmentColumns,
            id:'purchasingDepartmentGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            listeners: {
                edit: function (editor, e) {
                    let record = e.record; // 得到当前行所有数据
                    let field = e.field;   // 得到修改列
                    let value = e.value;   // 得到修改列修改后的值
                    let oldValue = e.originalValue; // 旧值
                    let id = record.get('id');
                    if (value === oldValue) {
                        record.reject();
                        return; // 没有修改内容则返回
                    }
                    //成功回调方法
                    function successCallback(data) {
                        purchasingDepartmentGrid.getStore().reload();
                    }
                    let params = {
                        branchId: branchId,
                        tableType: 'sourcing',
                        id: id,
                        field: field,
                        value: value
                    };
                    sendRequest('/Windchill/ptc1/closedLoop/updateClosedConfirm', "POST", 'application/x-www-form-urlencoded'
                        , false, params, successCallback);
                }
            }
        });

        var purchasingDepartmentPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title: '2.4 采购寻源部  确认内容',
            padding: '5',
            collapsible: true,
            collapsed:openPanel(procurement_execution_department),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                purchasingDepartmentGrid,
                {
                    xtype: 'textfield',
                    fieldLabel: setRequired('其他说明',isEditable(procurement_execution_department)),
                    readOnly:disableNode(procurement_execution_department),
                    // labelStyle: disableNode(procurement_information_collection)?'color: blue':'',
                    margin: '15 0 0 7',
                    id: 'sourcingInstruction',
                    name: 'sourcingInstruction',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('sourcingInstruction', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 20 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'sourcingPerson',
                            name: 'sourcingPerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'sourcingTime',
                            name: 'sourcingTime'
                        }
                    ]
                }
            ]
        });

        purchasingDepartmentGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });
        //====================================2.4 采购寻源部  确认内容 结束====================================================================


        //====================================2.5 采购执行部  确认内容 开始====================================================================
        Ext.define('procurementExecutionDepartmentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','inspectionItems','inspectionResult','inspectionInstruction','uploadRequirement','attachmentUpload'
            ],
            idProperty: 'procurementExecutionDepartmentModel'
        });

        var procurementExecutionDepartmentStore = Ext.create('Ext.data.Store', {
            model: 'procurementExecutionDepartmentModel',
            id: 'procurementExecutionDepartmentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getClosedLoopConfirm?changeRequestId=' + changeRequestId + "&branchId=" + branchId + "&tableType=execution",
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'procurementExecutionDepartmentModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        let inspectionResultStore5 = [['已完成', '已完成'], ['不涉及', '不涉及']];

        var procurementExecutionDepartmentColumns = [
            {text: '点检项目', dataIndex: 'inspectionItems',  flex: 1,menuDisabled: true, editor: false},
            {
                text: setMust('点检结果',isEditable(procurement_executive_manager)),
                dataIndex: 'inspectionResult',
                flex: 1,
                editAccess: isEditable(procurement_executive_manager),
                menuDisabled: true,
                editor: {
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: inspectionResultStore5
                }
            },
            {
                text: setRequired('点检说明',isEditable(procurement_executive_manager)),
                dataIndex: 'inspectionInstruction',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(procurement_executive_manager),
                editor: 'textfield'
            },
            {
                text: '相关附件',menuDisabled: true,
                columns: [
                    {
                        text: '附件上传要求',
                        dataIndex: 'uploadRequirement',
                        flex: 1,
                        editAccess: false,
                        editor: 'textfield',
                        menuDisabled: true,
                        renderer:showTip
                    },
                    {
                        text: setRequired('附件上传',isEditable(procurement_executive_manager)),
                        width: 200, align: 'center',xtype:'actioncolumn', dataIndex: 'attachmentUpload', editAccess: false, menuDisabled: true,
                        items: [
                            '->',
                            {
                                iconCls: 'icon icon-uploadImage',
                                tooltip: '添加文件',
                                hidden:disableNode(procurement_executive_manager),
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    // //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECUploadImageWindow = initECUploadImageWindow();
                                    ECUploadImageWindow.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return true;
                                    // }
                                    // return false;
                                }
                            },
                            '-',
                            {
                                iconCls: 'icon-showInfo',
                                tooltip: '查看文件',
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECShowFiles = initECShowFiles();
                                    ECShowFiles.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return false;
                                    // }
                                    // return true;
                                }
                            }
                        ]
                    }
                ]
            }
        ];

        var procurementExecutionDepartmentGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var procurementExecutionDepartmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [procurementExecutionDepartmentGridEditing],
            store: procurementExecutionDepartmentStore,
            columns: procurementExecutionDepartmentColumns,
            id:'procurementExecutionDepartmentGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            listeners: {
                edit: function (editor, e) {
                    let record = e.record; // 得到当前行所有数据
                    let field = e.field;   // 得到修改列
                    let value = e.value;   // 得到修改列修改后的值
                    let oldValue = e.originalValue; // 旧值
                    let id = record.get('id');
                    if (value === oldValue) {
                        record.reject();
                        return; // 没有修改内容则返回
                    }
                    //成功回调方法
                    function successCallback(data) {
                        procurementExecutionDepartmentGrid.getStore().reload();
                    }
                    let params = {
                        branchId: branchId,
                        tableType: 'execution',
                        id: id,
                        field: field,
                        value: value
                    };
                    sendRequest('/Windchill/ptc1/closedLoop/updateClosedConfirm', "POST", 'application/x-www-form-urlencoded'
                        , false, params, successCallback);
                }
            }
        });

        var procurementExecutionDepartmentPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title: '2.5 采购执行部  确认内容',
            padding: '5',
            collapsible: true,
            collapsed:openPanel(procurement_executive_manager),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                procurementExecutionDepartmentGrid,
                {
                    xtype: 'textfield',
                    fieldLabel: setRequired('其他说明',isEditable(procurement_executive_manager)),
                    readOnly:disableNode(procurement_executive_manager),
                    // labelStyle: disableNode(procurement_information_collection)?'color: blue':'',
                    // readOnly:disableNode(procurement_information_collection)?false:true,
                    margin: '15 0 0 7',
                    id: 'executionInstruction',
                    name: 'executionInstruction',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('executionInstruction', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 20 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'executionPerson',
                            name: 'executionPerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'executionTime',
                            name: 'executionTime'
                        }
                    ]
                }
            ]
        });

        procurementExecutionDepartmentGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });
        //====================================2.5 采购执行部  确认内容 结束====================================================================


        //====================================2.6 生产部  确认内容 开始====================================================================
        Ext.define('productionDepartmentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','inspectionItems','inspectionResult','inspectionInstruction','uploadRequirement','attachmentUpload'
            ],
            idProperty: 'productionDepartmentModel'
        });

        var productionDepartmentStore = Ext.create('Ext.data.Store', {
            model: 'productionDepartmentModel',
            id: 'productionDepartmentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getClosedLoopConfirm?changeRequestId=' + changeRequestId + "&branchId=" + branchId + "&tableType=production",
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'productionDepartmentModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        let inspectionResultStore6 = [['已完成', '已完成'], ['不涉及', '不涉及']];

        var productionDepartmentColumns = [
            {text: '点检项目', dataIndex: 'inspectionItems',  flex: 1,menuDisabled: true, editAccess: false},
            {
                text: setMust('点检结果',isEditable(production_manager)),
                dataIndex: 'inspectionResult',
                flex: 1,
                editAccess: isEditable(production_manager),
                menuDisabled: true,
                editor: {
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: inspectionResultStore6
                }
            },
            {
                text: setRequired('点检说明',isEditable(production_manager)),
                dataIndex: 'inspectionInstruction',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(production_manager),
                editor: 'textfield'
            },
            {
                text: '相关附件',menuDisabled: true,
                columns: [
                    {
                        text: '附件上传要求',
                        dataIndex: 'uploadRequirement',
                        flex: 1,
                        editAccess: false,
                        editor: 'textfield',
                        menuDisabled: true,
                        renderer:showTip
                    },
                    {
                        text: setRequired('附件上传',isEditable(production_manager)),
                        width: 200,
                        align: 'center',xtype:'actioncolumn', dataIndex: 'attachmentUpload', editAccess: false, menuDisabled: true,
                        items: [
                            '->',
                            {
                                iconCls: 'icon icon-uploadImage',
                                tooltip: '添加文件',
                                hidden:disableNode(production_manager),
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    // //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECUploadImageWindow = initECUploadImageWindow();
                                    ECUploadImageWindow.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return true;
                                    // }
                                    // return false;
                                }
                            },
                            '-',
                            {
                                iconCls: 'icon-showInfo',
                                tooltip: '查看文件',
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECShowFiles = initECShowFiles();
                                    ECShowFiles.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return false;
                                    // }
                                    // return true;
                                }
                            }
                        ]
                    }
                ]
            }
        ];

        var productionDepartmentGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var productionDepartmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [productionDepartmentGridEditing],
            store: productionDepartmentStore,
            columns: productionDepartmentColumns,
            id:'productionDepartmentGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            listeners: {
                edit: function (editor, e) {
                    let record = e.record; // 得到当前行所有数据
                    let field = e.field;   // 得到修改列
                    let value = e.value;   // 得到修改列修改后的值
                    let oldValue = e.originalValue; // 旧值
                    let id = record.get('id');
                    if (value === oldValue) {
                        record.reject();
                        return; // 没有修改内容则返回
                    }
                    //成功回调方法
                    function successCallback(data) {
                        productionDepartmentGrid.getStore().reload();
                    }
                    let params = {
                        branchId: branchId,
                        tableType: 'production',
                        id: id,
                        field: field,
                        value: value
                    };
                    sendRequest('/Windchill/ptc1/closedLoop/updateClosedConfirm', "POST", 'application/x-www-form-urlencoded'
                        , false, params, successCallback);
                }
            }
        });

        var productionDepartmentPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title: '2.6 生产部  确认内容',
            padding: '5',
            collapsible: true,
            collapsed:openPanel(production_manager),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                productionDepartmentGrid,
                {
                    xtype: 'textfield',
                    fieldLabel:setRequired('其他说明',isEditable(production_manager)),
                    readOnly:disableNode(production_manager),
                    margin: '15 0 0 7',
                    id: 'produceInstruction',
                    name: 'produceInstruction',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('produceInstruction', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 20 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'producePerson',
                            name: 'producePerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'produceTime',
                            name: 'produceTime'
                        }
                    ]
                }
            ]
        });

        productionDepartmentGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });
        //====================================2.6 生产部  确认内容 结束====================================================================


        //====================================2.7 产品工程部  确认内容 开始====================================================================
        Ext.define('productEngineeringDepartmentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','inspectionItems','inspectionResult','inspectionInstruction','uploadRequirement','attachmentUpload'
            ],
            idProperty: 'productEngineeringDepartmentModel'
        });

        var productEngineeringDepartmentStore = Ext.create('Ext.data.Store', {
            model: 'productEngineeringDepartmentModel',
            id: 'productEngineeringDepartmentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getClosedLoopConfirm?changeRequestId=' + changeRequestId + "&branchId=" + branchId + "&tableType=engineering",
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'productEngineeringDepartmentModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        let inspectionResultStore7 = [['已完成', '已完成'], ['不涉及', '不涉及']];

        var productEngineeringDepartmentColumns = [
            {
                text: '点检项目',
                dataIndex: 'inspectionItems',
                flex: 1,
                menuDisabled: true,
                editAccess: false
            },
            {
                text: setMust('点检结果',isEditable(process_route_production)),
                dataIndex: 'inspectionResult',
                flex: 1,
                editAccess: isEditable(process_route_production),
                menuDisabled: true,
                editor: {
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: inspectionResultStore7
                }
            },
            {
                text: setRequired('点检说明',isEditable(process_route_production)),
                dataIndex: 'inspectionInstruction',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(process_route_production),
                editor: 'textfield',
            },
            {
                text: '相关附件',menuDisabled: true,
                columns: [
                    {
                        text: '附件上传要求',
                        dataIndex: 'uploadRequirement',
                        flex: 1,
                        editAccess: false,
                        editor: 'textfield',
                        menuDisabled: true,
                        renderer:showTip
                    },
                    {
                        text: setRequired('附件上传',isEditable(process_route_production)),
                        width: 200,
                        align: 'center',xtype:'actioncolumn', dataIndex: 'attachmentUpload', editAccess: false, menuDisabled: true,
                        items: [
                            '->',
                            {
                                iconCls: 'icon icon-uploadImage',
                                tooltip: '添加文件',
                                hidden:disableNode(process_route_production),
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    // //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECUploadImageWindow = initECUploadImageWindow();
                                    ECUploadImageWindow.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return true;
                                    // }
                                    // return false;
                                }
                            },
                            '-',
                            {
                                iconCls: 'icon-showInfo',
                                tooltip: '查看文件',
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECShowFiles = initECShowFiles();
                                    ECShowFiles.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return false;
                                    // }
                                    // return true;
                                }
                            }
                        ]
                    }
                ]
            }
        ];

        var productEngineeringDepartmentGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var productEngineeringDepartmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [productEngineeringDepartmentGridEditing],
            store: productEngineeringDepartmentStore,
            columns: productEngineeringDepartmentColumns,
            id:'productEngineeringDepartmentGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            listeners: {
                edit: function (editor, e) {
                    let record = e.record; // 得到当前行所有数据
                    let field = e.field;   // 得到修改列
                    let value = e.value;   // 得到修改列修改后的值
                    let oldValue = e.originalValue; // 旧值
                    let id = record.get('id');
                    if (value === oldValue) {
                        record.reject();
                        return; // 没有修改内容则返回
                    }
                    //成功回调方法
                    function successCallback(data) {
                        productEngineeringDepartmentGrid.getStore().reload();
                    }
                    let params = {
                        branchId: branchId,
                        tableType: 'engineering',
                        id: id,
                        field: field,
                        value: value
                    };
                    sendRequest('/Windchill/ptc1/closedLoop/updateClosedConfirm', "POST", 'application/x-www-form-urlencoded'
                        , false, params, successCallback);
                }
            }
        });

        var productEngineeringDepartmentPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title: '2.7 产品工程部  确认内容',
            padding: '5',
            collapsible: true,
            collapsed:openPanel(process_route_production),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                productEngineeringDepartmentGrid,
                {
                    xtype: 'textfield',
                    fieldLabel:setRequired('其他说明',isEditable(process_route_production)),
                    readOnly:disableNode(process_route_production),
                    margin: '15 0 0 7',
                    id: 'engineeringInstruction',
                    name: 'engineeringInstruction',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('engineeringInstruction', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 20 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'engineeringPerson',
                            name: 'engineeringPerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'engineeringTime',
                            name: 'engineeringTime'
                        }
                    ]
                }
            ]
        });

        productEngineeringDepartmentGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });
        //====================================2.7 产品工程部  确认内容 结束====================================================================

        //====================================2.8 财务部  确认内容 开始====================================================================
        Ext.define('financeDepartmentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','inspectionItems','inspectionResult','inspectionInstruction','uploadRequirement','attachmentUpload'
            ],
            idProperty: 'financeDepartmentModel'
        });

        var financeDepartmentStore = Ext.create('Ext.data.Store', {
            model: 'financeDepartmentModel',
            id: 'financeDepartmentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/closedLoop/getClosedLoopConfirm?changeRequestId=' + changeRequestId + "&branchId=" + branchId + "&tableType=finance",
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'financeDepartmentModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        let inspectionResultStore8 = [['已完成', '已完成'], ['不涉及', '不涉及']];

        var financeDepartmentColumns = [
            {text: '点检项目', dataIndex: 'inspectionItems',  flex: 1,menuDisabled: true, editAccess: false},
            {
                text: setMust('点检结果',isEditable(financial_supervisor)),
                dataIndex: 'inspectionResult',
                flex: 1,
                editAccess: isEditable(financial_supervisor),
                menuDisabled: true,
                editor: {
                    xtype: 'combobox',
                    editable: false,
                    forceSelection: false,
                    store: inspectionResultStore8
                }
            },
            {
                text: setRequired('点检说明',isEditable(financial_supervisor)),
                dataIndex: 'inspectionInstruction',
                flex: 1,
                menuDisabled: true,
                editAccess: isEditable(financial_supervisor),
                editor: 'textfield'
            },
            {
                text: '相关附件',menuDisabled: true,
                columns: [
                    {
                        text: '附件上传要求',
                        dataIndex: 'uploadRequirement',
                        flex: 1,
                        editAccess: false,
                        editor: 'textfield',
                        menuDisabled: true,
                        renderer:showTip
                    },
                    {
                        text: setRequired('附件上传',isEditable(financial_supervisor)),
                        width: 200,
                        align: 'center',
                        xtype:'actioncolumn',
                        dataIndex: 'attachmentUpload',
                        editor: false,
                        menuDisabled: true,
                        items: [
                            '->',
                            {
                                iconCls: 'icon icon-uploadImage',
                                tooltip: '添加文件',
                                hidden:disableNode(financial_supervisor),
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    // //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECUploadImageWindow = initECUploadImageWindow();
                                    ECUploadImageWindow.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return true;
                                    // }
                                    // return false;
                                }
                            },
                            '-',
                            {
                                iconCls: 'icon-showInfo',
                                tooltip: '查看文件',
                                handler: function(grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    changeRequestId = changeRequestId;
                                    //设置当前列的id与列名和表名
                                    fileColumnId = record.data.id;
                                    fileColumnName = 'attachmentUpload';
                                    uploadTableName = 'ZConfirmContentTable';
                                    //设置grid名称用于上传文件后刷新数据
                                    gridName = '';
                                    var ECShowFiles = initECShowFiles();
                                    ECShowFiles.show()
                                },
                                isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                    // var boolean = record.data.environmentalReport;
                                    // if(boolean!=null) {
                                    //     return false;
                                    // }
                                    // return true;
                                }
                            }
                        ]
                    }
                ]
            }
        ];

        var financeDepartmentGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var financeDepartmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [financeDepartmentGridEditing],
            store: financeDepartmentStore,
            columns: financeDepartmentColumns,
            id:'financeDepartmentGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true},
            listeners: {
                edit: function (editor, e) {
                    let record = e.record; // 得到当前行所有数据
                    let field = e.field;   // 得到修改列
                    let value = e.value;   // 得到修改列修改后的值
                    let oldValue = e.originalValue; // 旧值
                    let id = record.get('id');
                    if (value === oldValue) {
                        record.reject();
                        return; // 没有修改内容则返回
                    }
                    //成功回调方法
                    function successCallback(data) {
                        financeDepartmentGrid.getStore().reload();
                    }
                    let params = {
                        branchId: branchId,
                        tableType: 'finance',
                        id: id,
                        field: field,
                        value: value
                    };
                    sendRequest('/Windchill/ptc1/closedLoop/updateClosedConfirm', "POST", 'application/x-www-form-urlencoded'
                        , false, params, successCallback);
                }
            }
        });

        var financeDepartmentPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title: '2.8 财务部  确认内容',
            padding: '5',
            collapsible: true,
            collapsed:openPanel(financial_supervisor),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                financeDepartmentGrid,
                {
                    xtype: 'textfield',
                    fieldLabel:setRequired('其他说明',isEditable(financial_supervisor)),
                    readOnly:disableNode(financial_supervisor),
                    margin: '15 0 0 7',
                    id: 'financeInstruction',
                    name: 'financeInstruction',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('financeInstruction', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 20 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'financePerson',
                            name: 'financePerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'financeTime',
                            name: 'financeTime'
                        }
                    ]
                }
            ]
        });

        financeDepartmentGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });
        //====================================2.8 财务部  确认内容 结束====================================================================

        //====================================2.9 闭环结论（质量中心）PQA 开始====================================================================
        var closedLoopConclusionPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            title:"2.9 闭环结论（质量中心）PQA",
            padding: '5',
            collapsible: true,
            collapsed:openPanel(closed_loop_result_inspection),
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [
                {
                    xtype: 'textfield',
                    fieldLabel:setRequired('确认结果',isEditable(closed_loop_result_inspection)),
                    readOnly:disableNode(closed_loop_result_inspection),
                    margin: '15 0 0 7',
                    id: 'closeLoopResult',
                    name: 'closeLoopResult',
                    listeners: {
                        blur: function (e) {
                            updateClosedReviewInfo('closeLoopResult', e.getValue());
                        }
                    }
                },
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '10 0 10 20',
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel:setRequired('相关附件',isEditable(closed_loop_result_inspection)),
                            width:'0',
                            readOnly: true
                        },
                        {
                            xtype: 'button',
                            text: '添加文件',
                            iconCls: 'icon icon-uploadImage',
                            hidden:disableNode(closed_loop_result_inspection),
                            handler: function() {
                                changeRequestId = changeRequestId;
                                // //设置当前列的id与列名和表名
                                fileColumnId = closeLoopId;
                                fileColumnName = 'closeLoopAnnex';
                                uploadTableName = 'ZClosedLoopInfoTable';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = '';
                                var ECUploadImageWindow = initECUploadImageWindow();
                                ECUploadImageWindow.show()
                            }
                        },
                        {
                            xtype: 'button',
                            text: '查看文件',
                            iconCls: 'icon-showInfo',
                            handler: function() {
                                changeRequestId = changeRequestId;
                                //设置当前列的id与列名和表名
                                fileColumnId = closeLoopId;
                                fileColumnName = 'closeLoopAnnex';
                                uploadTableName = 'ZClosedLoopInfoTable';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = '';
                                var ECShowFiles = initECShowFiles();
                                ECShowFiles.show()
                            }
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    margin: '15 0 0 0',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '确认人',
                            id: 'closeLoopPerson',
                            name: 'closeLoopPerson'
                        },{
                            xtype: 'displayfield',
                            fieldLabel: '确认时间',
                            margin: '5 0 0 180',
                            id: 'closeLoopTime',
                            name: 'closeLoopTime'
                        }
                    ]
                }
            ]
        });
        //====================================2.9 闭环结论（质量中心）PQA 结束====================================================================

        var ecclPanel2 = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: '2. 闭环确认内容',
            padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                qualityControlDepartmentPanel,
                technologyDepartmentPanel,
                materialControlDepartmentPanel,
                purchasingDepartmentPanel,
                procurementExecutionDepartmentPanel,
                productionDepartmentPanel,
                productEngineeringDepartmentPanel,
                financeDepartmentPanel,
                closedLoopConclusionPanel
            ],
            listeners: {
                'afterrender': function () {
                    function successCallback(data) {
                        if (data) {
                            Ext.getCmp('qualityInstruction').setValue(data.qualityInstruction);
                            Ext.getCmp('qualityPerson').setValue(data.qualityPerson);
                            Ext.getCmp('qualityTime').setValue(data.qualityTime);
                            Ext.getCmp('technologyInstruction').setValue(data.technologyInstruction);
                            Ext.getCmp('technologyPerson').setValue(data.technologyPerson);
                            Ext.getCmp('technologyTime').setValue(data.technologyTime);
                            Ext.getCmp('materialInstruction').setValue(data.materialInstruction);
                            Ext.getCmp('materialPerson').setValue(data.materialPerson);
                            Ext.getCmp('materialTime').setValue(data.materialTime);
                            Ext.getCmp('sourcingInstruction').setValue(data.sourcingInstruction);
                            Ext.getCmp('sourcingPerson').setValue(data.sourcingPerson);
                            Ext.getCmp('sourcingTime').setValue(data.sourcingTime);
                            Ext.getCmp('executionInstruction').setValue(data.executionInstruction);
                            Ext.getCmp('executionPerson').setValue(data.executionPerson);
                            Ext.getCmp('executionTime').setValue(data.executionTime);
                            Ext.getCmp('produceInstruction').setValue(data.produceInstruction);
                            Ext.getCmp('producePerson').setValue(data.producePerson);
                            Ext.getCmp('produceTime').setValue(data.produceTime);
                            Ext.getCmp('engineeringInstruction').setValue(data.engineeringInstruction);
                            Ext.getCmp('engineeringPerson').setValue(data.engineeringPerson);
                            Ext.getCmp('engineeringTime').setValue(data.engineeringTime);
                            Ext.getCmp('financeInstruction').setValue(data.financeInstruction);
                            Ext.getCmp('financePerson').setValue(data.financePerson);
                            Ext.getCmp('financeTime').setValue(data.financeTime);
                            Ext.getCmp('closeLoopResult').setValue(data.closeLoopResult);
                            Ext.getCmp('closeLoopPerson').setValue(data.closeLoopPerson);
                            Ext.getCmp('closeLoopTime').setValue(data.closeLoopTime);
                            closeLoopId = data.id;
                        }
                    }
                    sendRequest('/Windchill/ptc1/closedLoop/getClosedReviewInfo', "POST",
                        'application/x-www-form-urlencoded', false, {changeRequestId:changeRequestId, branchId: branchId}, successCallback);
                }
            }
        });

        var ecclPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: '1. ECR_申请人（提交）',
            padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            width:'99.9%',
            items:[
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    defaults: {margin: '5 20 0 0', labelWidth: 110},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'ECR编号',
                        id: 'ecrNumber_close',
                        name: 'ecrNumber_close',
                        width: 200,
                        editable: false
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'ECR名称',
                        id: 'ecrName_close',
                        name: 'ecrName_close',
                        width: 200,
                        readOnly:true
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '更改类型',
                        id: 'changeType_close',
                        name: 'changeType_close',
                        width: 200,
                        readOnly:true
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '闭环流程文档链接',
                        id: 'docUrl_close',
                        name: 'docUrl_close',
                        width: 200,
                        readOnly:true
                    }
                    ]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [
                        // {
                        //     xtype: 'displayfield',
                        //     fieldLabel: '变更描述',
                        //     id: 'changeDescription_close',
                        //     name: 'changeDescription_close',
                        //     width: 200
                        // },
                        {
                            xtype: 'displayfield',
                            fieldLabel: '变更原因描述',
                            id: 'changeReason_close',
                            name: 'changeReason_close',
                            width: 400
                        },
                        {
                            xtype: 'displayfield',
                            fieldLabel: '附件',
                            id: 'applicationDatea',
                            name: 'applicationDatea',
                            value:'',
                            width: 300
                        }
                    ]
                },
                partChangeGrid,
                PCNGrid,
            ],
            listeners: {
                'afterrender': function () {
                    function successCallback(data) {
                        Ext.getCmp('ecrNumber_close').setValue(data.ecrNumber_close);
                        Ext.getCmp('ecrName_close').setValue(data.ecrName_close);
                        Ext.getCmp('changeType_close').setValue(data.changeType_close);
                        //Ext.getCmp('changeDescription_close').setValue(data.changeDescription_close);
                        Ext.getCmp('changeReason_close').setValue(data.changeReason_close);
                        Ext.getCmp('docUrl_close').setValue(data.docUrl_close);
                    }
                    sendRequest('/Windchill/ptc1/closedLoop/getEcrInfo', "GET", 'application/x-www-form-urlencoded'
                        , false, {changeRequestId: changeRequestId, branchId: branchId}, successCallback);
                }
            }
        });

        var ecclPanel3 = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ecclPanel,
                ecclPanel2
            ]
        });



        this.items = [
            ecclPanel3
        ];

        this.callParent();

        //========== 结束  PartChangeGrid================

    }
})