Ext.define('PLM.view.ctExecutionRecordTablePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctExecutionRecordTablePanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    height:770,
    collapsible: false,
    id: 'ctExecutionRecordTablePanel',
    initComponent: function (){
//========== 开始  partChangeGrid================

// ==============================ECA=======================

//=====================受影响领域及负责人====================
//变更负责人
        var responsiblePersonECR01 = isEditable(

        );
//变更负责人部门经理
        var departmentManagerECR01 = isEditable(

        );
//=====================受影响领域及负责人====================

//=====================物料及EBOM变更ECA开始====================
//试产责任人
        var trialResponsiblePersonEBOMChangeECA = isEditable(

        );
//小批量验证流程编号
        var trialProcessNumberEBOMChangeECA = isEditable(
            confirmation_of_trial_production_results,general_change_ECA_PDMSR
        );
//试产状态
        var trialProductionStatusEBOMChangeECA = isEditable(

        );
//是否同步打样资料
        var synchronizeSampleDataEBOMChangeECA = isEditable(
            EBOM_change_content_and_change_responsible_person,general_change_ECA_PDMSR
        );
//打样资料生效版本
        var effectiveVersionEBOMChangeECA = isEditable(
            EBOM_change_content_and_change_responsible_person,general_change_ECA_PDMSR
        );
//=====================物料及EBOM变更ECA开始====================

//========================物料变更内容==========================
//        物料编码
        var partNumberAfterECA02Material = isEditable(
            general_change_ECA_PDMSR
        );

//物料描述
        var partDescAfterECA02Material = isEditable(
            general_change_ECA_PDMSR
        );
//内部版本
        var internalVersionAfterECA02Material = isEditable(
            general_change_ECA_PDMSR
        );
//是否需要样品确认
        var needSampleConfirmationECA02Material = isEditable(

        );
//样品确认流程编号及状态
        var sampleConfirmationProcessECA02Material = isEditable(
            general_change_sample_confirmation
        );

//        新增行，删除行
        var addOrDeleteECA02Material = isEditable(
            general_change_ECA_PDMSR
        );


//========================物料变更内容==========================

//========================ECAEBOM===============================
//父项编码
        var parentNumberECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更类型
        var changeTypeECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更前物料编码
        var partNumberBeforeECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后物料编码
        var partNumberAfterECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后分数
        var fractionAfterECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后数量
        var quantityAfterECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后位号
        var tagNumberAfterECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后BOM备注
        var bomRemarkAfterECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//备注
        var remarksECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//新增行
        var addECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//删除行
        var deleteECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//复制
        var copyECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//下载导入模板
        var downloadECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//导入EBOM变更内容
        var ecaEBOMuploadECAEBOM = isEditable(
            general_change_ECA_PDMSR
        );
//========================ECAEBOM===============================

//========================MBOM变更ECA===============================
//试产责任人
        var trialResponsiblePersonMBOMChangeECA = isEditable(

        );
//小批量验证流程编号
        var trialProcessNumberMBOMChangeECA = isEditable(
            confirmation_of_trial_production_results,general_change_ECA_PDMSR
        );
//试产状态
        var trialProductionStatusMBOMChangeECA = isEditable(

        );
//========================MBOM变更ECA===============================

//========================MBOM变更内容================================

//父项编码
        var parentNumberECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更类型
        var changeTypeECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更前物料编码
        var partNumberBeforeECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后物料编码
        var partNumberAfterECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后分数
        var fractionAfterECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后数量
        var quantityAfterECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//变更后位号
        var tagNumberAfterECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//BOM备注
        var bomRemarkAfterECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//备注
        var remarksECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//新增行
        var addECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//删除行
        var deleteECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//粘贴
        var pasteECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//下载导入模板
        var downloadECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );
//导入MBOM变更内容
        var ecaMBOMuploadECAMBOM = isEditable(
            general_change_ECA_PDMSR
        );

        //BOM更改生效时间
        var materialControlFeedbackEditable = isEditable(
            material_control_change_response,material_control_department_review,mbom_material_control_manager
        );
//========================MBOM变更内容================================

// ==============================ECA=======================







        var needSampleConfirmation = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'needSampleConfirmation',
            id: 'needSampleConfirmation',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '是' },
                    { fullName: '否' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName'
        });

        var responsiblePersonStore = new Ext.data.ArrayStore({
            id: 'responsiblePersonStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var responsiblePersonCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'responsiblePersonCom',
            id: 'responsiblePersonCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: responsiblePersonStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });


        var departmentManagerStore = new Ext.data.ArrayStore({
            id: 'departmentManagerStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var departmentManagerCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'departmentManagerCom',
            id: 'departmentManagerCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: departmentManagerStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });

        var ebomStore = new Ext.data.ArrayStore({
            id: 'ebomStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var ebomCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'ebomCom',
            id: 'ebomCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: ebomStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });

        var mbomStore = new Ext.data.ArrayStore({
            id: 'mbomStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var mbomCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'mbomCom',
            id: 'mbomCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: mbomStore,
            valueField: 'name',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });


        //========================================父项编码 开始================================
        Ext.define('ECAParentNumberModel', {
            extend: 'Ext.data.Model',
            fields: ['partNumber','viewName'],
            idProperty: 'id'
        });

        var ECAEBOMParentNumberStore = Ext.create('Ext.data.Store', {
            id: 'ECAEBOMParentNumberStore',
            model: 'ECAParentNumberModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/getParentNumber?changeRequestId='+changeRequestId+"&type=ebom",
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

        var ECAEBOMParentNumberCombo =new Ext.form.field.ComboBox({
            forceSelection: false, //forceSelection 是否能够手填
            name: 'ECAEBOMParentNumberCombo',
            id: 'ECAEBOMParentNumberCombo',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore("ECAEBOMParentNumberStore"),
            valueField: 'formInfo',
            displayField: 'formInfo',
        });

        var ECAMBOMParentNumberStore = Ext.create('Ext.data.Store', {
            id: ' ECAMBOMParentNumberStore',
            model: 'ECAParentNumberModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/getParentNumber?changeRequestId='+changeRequestId+"&type=mbom",
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

        var ECAMBOMParentNumberCombo =new Ext.form.field.ComboBox({
            forceSelection: false, //forceSelection 是否能够手填
            name: 'ECAMBOMParentNumberCombo',
            id: 'ECAMBOMParentNumberCombo',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore(" ECAMBOMParentNumberStore"),
            valueField: 'formInfo',
            displayField: 'formInfo',
        });

        var ECAChangeType = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'ECAChangeTypeCombo',
            id: 'ECAChangeTypeCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '' },
                    { fullName: '增加' },
                    { fullName: '删除' },
                    { fullName: '修改' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName',
            tpl: getXTemplate('fullName')
        });

        //========================================父项编码 结束================================













//===================================1. 受影响领域及负责人 开始===============================================================
        Ext.define('ECA01Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'affectedAreas', "related", 'responsiblePerson', 'departmentManager'
            ],
            idProperty: 'ECA01Model'
        });

        var ECA01Columns = [
            {text: 'NO.', width: 60,sortable: false, align: 'center', menuDisabled: true, xtype: 'rownumberer', sortable: false},
            {text: '受影响领域',flex: 0.5,sortable: false, align: 'center',dataIndex: 'affectedAreas', menuDisabled:true, editor:false
                // ,style: disableNode(execute_processing_feedback)?'color: blue;':''
            },
            {text: '是否相关',flex: 1,sortable: false, align: 'center',dataIndex: 'related', menuDisabled:true, editor:false},
            // {text: setMust('变更负责人',responsiblePersonECR01),flex: 1,sortable: false, align: 'center',dataIndex: 'responsiblePerson', menuDisabled:true, editor:responsiblePersonECR01?responsiblePersonCom:false},
            // {text: setMust('变更负责人部门经理',departmentManagerECR01),flex: 1,sortable: false, align: 'center',dataIndex: 'departmentManager', menuDisabled:true,
            //     editor:departmentManagerECR01?departmentManagerCom:false}
            {text: '变更负责人',flex: 1,sortable: false, align: 'center',dataIndex: 'responsiblePerson', menuDisabled:true, editor:false},
            {text: '变更负责人部门经理',flex: 1,sortable: false, align: 'center',dataIndex: 'departmentManager', menuDisabled:true,
                editor:false}
        ];


        var ECA01Store = Ext.create('Ext.data.Store', {
            model: 'ECA01Model',
            id: 'ECA01Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaRegularInfo?tableName=affectedAreasAndHead&changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'ECR03Model',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var ECA01GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var ECA01Grid = Ext.create('Ext.grid.Panel', {
            plugins: [ECA01GridEditing],
            store: ECA01Store,
            columns: ECA01Columns,
            // title: '1. 受影响领域及负责人',
            id:'ECA01Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: true,
            viewConfig: { enableTextSelection:true},
            style: {
                border: '1px solid #CCCCCC' // 添加灰色边框
            },
            // selType: 'checkboxmodel',
        });

        ECA01Grid.on('edit',function(editor,e){
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECAExecutionRecord/updateEcaRegularInfo?id='+id+'&dataKey='+tField+'&dataValue='+tValue+'&activityName='+activityName,
                async: false,
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=="success") {

                    } else {
                        alert(obj.message);
                    }
                    //回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('ECA01Store').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
        });


        //根据特定字段的值判断是否禁止编辑
        ECA01Grid.on('beforeedit', function (editor, context) {
            var record = context.record;
            var related = record.get('related');
            var affectedAreas = record.get('affectedAreas');
            if(!related){
                return false; // 允许编辑操作
            }

            if ((activityName === "通用变更ECA_执行变更(软件文件更改)"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "软件文件更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_执行变更(SIP更改)"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "SIP更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_执行变更(SOP更改)"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "SOP更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_执行变更(技术支持更改)"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "技术支持更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_执行变更(市场更改)"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "市场更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_执行变更(结构图纸更改)"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "结构图纸更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_执行变更(电子图纸更改)"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "电子图纸更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_执行变更(销售更改)"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "销售更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_确认EBOM变更内容"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "物料及EBOM更改") {
                return true; // 允许编辑操作
            }
            if ((activityName === "通用变更ECA_确认MBOM变更内容"||
                activityName === "通用变更ECA_确认EBOM变更内容，确认变更负责人") && affectedAreas === "MBOM更改") {
                return true; // 允许编辑操作
            }


            // if(related){
            //     return true; // 允许编辑操作
            // }


            return false; // 禁止编辑指定列

        });

//===================================1. 受影响领域及负责人 结束===============================================================

        var effectiveVersionStore = new Ext.data.ArrayStore({
            id: 'effectiveVersionStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/ECAExecutionRecord/getEffectiveVersion',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var effectiveVersionCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'effectiveVersionCom',
            id: 'effectiveVersionCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: effectiveVersionStore,
            valueField: 'fullName',
            displayField: 'fullName',
            minChars : 1,//开始查询最小字符数
            mode : 'local', //查询模式  local为本地数据源  remote为远程服务端
        });




        var dynamicOptions = [];
        // let effectiveVersionStore = new Ext.data.ArrayStore({
        //     id: 'effectiveVersionStore',
        //     fields: [
        //         {name:"name"},
        //         {name: "fullName"}
        //     ],
        //     pruneModifiedRecords: true,
        //     proxy: {
        //         type: 'ajax',
        //         url: '/Windchill/ptc1/ECAExecutionRecord/getEffectiveVersion',
        //         reader: {
        //             type: 'json',
        //             rootProperty: 'data'
        //         }
        //     },
        //     autoLoad: false,
        //     listeners: {
        //         load: function(store) {
        //             // 在 Store 加载完成后，将数据存储在 dynamicOptions 变量中
        //             var dataInfo = [];
        //             store.each(function(record) {
        //                 dataInfo.push({
        //                     name: record.get('name'),  // 假设 name 字段作为下拉项的显示文本
        //                     fullName: record.get('fullName')    // 假设 id 字段作为下拉项的值
        //                 });
        //                 // dynamicOptions = [];
        //                 // var fullName = record.get('fullName');
        //                 // // 检查 dynamicOptions 中是否已经存在该 fullName
        //                 // var exists = dynamicOptions.some(function(option) {
        //                 //     return option.fullName === fullName;
        //                 // });
        //                 //
        //                 // // 如果 dynamicOptions 中不存在该 fullName，则添加到 dynamicOptions 中
        //                 // if (!exists) {
        //                 //     dynamicOptions.push({
        //                 //         name: record.get('name'),
        //                 //         fullName: fullName
        //                 //     });
        //                 // }
        //                 // 获取到 combo 组件
        //                 var combo = Ext.getCmp("effectiveVersionCombo"); // 根据实际情况调整 selector
        //
        //                 // 更新 combo 的数据源
        //                 combo.getStore().loadData(dataInfo);
        //
        //             });
        //         }
        //     }
        // });


//===================================2. 物料及EBOM变更ECA开始===============================================================
        Ext.define('EBOMChangeECAModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','tableType','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter','needTrialProduction','trialMaterialNumber',
                'trialResponsiblePerson','trialProcessNumber', 'trialProductionStatus','synchronizeSampleData','effectiveVersion','interiorVersion','interiorVersionAfter',
                'needSampleConfirmation','sampleConfirmationProcess','sampleConfirmationProcessUrl','sampleConfirmationState','sampleConfirmationPartState'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.EBOMChangeECAStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'EBOMChangeECAModel',
            id:'EBOMChangeECAStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=EcaEPartChange'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });

        //是否需要样品确认
        let sampleConfirmationStore = [['是', '是'], ['否', '否']];
        //是否需要样品确认
        let needTrialProductionStore = [['是', '是'], ['否', '否']];


        var EBOMChangeECACellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var EBOMChangeECAGrid = Ext.create('Ext.grid.Panel', {
            plugins: [EBOMChangeECACellEditing],
            store: Ext.getStore('EBOMChangeECAStore'),
            id: 'EBOMChangeECAGrid',
            margin: '0 10 0 0',
            // title: '2. 物料及EBOM变更ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号',
                    dataIndex: 'objectNumber', flex: 1,
                    menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '系统版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '内部版本', dataIndex: 'interiorVersion', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '系统版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '内部版本', dataIndex: 'interiorVersionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '小批量验证',menuDisabled: true,flex: 5,
                    columns: [
                        {text: '小批量验证确认', dataIndex: 'needTrialProduction', flex: 1,
                            editor:false,
                            // editor: {
                            //     xtype: 'combobox',
                            //     editable: false,
                            //     forceSelection: false,
                            //     store: sampleConfirmationStore
                            // },
                            menuDisabled: true,renderer:showTip},
                        //{text: '试产物料编号', dataIndex: 'trialMaterialNumber', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        // {text: setRequired('试产责任人',trialResponsiblePersonEBOMChangeECA), dataIndex: 'trialResponsiblePerson', flex: 1, editor: trialResponsiblePersonEBOMChangeECA?responsiblePersonCom:false, menuDisabled: true,renderer:showTip},
                        {text: setRequired('小批量验证流程编号',trialProcessNumberEBOMChangeECA), dataIndex: 'trialProcessNumber', flex: 1, editor: trialProcessNumberEBOMChangeECA, menuDisabled: true,renderer:showTip},
                        // {text: setRequired('试产状态',trialProductionStatusEBOMChangeECA), dataIndex: 'trialProductionStatus', flex: 1, editor: trialProductionStatusEBOMChangeECA, menuDisabled: true,renderer:showTip},
                        {text: '小批量验证流程状态', dataIndex: 'trialProductionStatus', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                },
                {
                    text: '打样资料同步',menuDisabled: true,flex: 2,
                    columns: [
                        {text: setRequired('是否同步打样资料',synchronizeSampleDataEBOMChangeECA), dataIndex: 'synchronizeSampleData', flex: 1,
                            editor: synchronizeSampleDataEBOMChangeECA?
                                {
                                    xtype: 'combobox',
                                    editable: false,
                                    forceSelection: false,
                                    store: needTrialProductionStore
                                }:false,
                            menuDisabled: true,renderer:showTip},
                        {text: setRequired('打样资料生效版本',effectiveVersionEBOMChangeECA), dataIndex: 'effectiveVersion', flex: 1,
                            editor:
                            effectiveVersionEBOMChangeECA?effectiveVersionCom
                                // {
                                //     xtype: 'combo',
                                //     id:'effectiveVersionCombo',
                                //     editable: false,
                                //     multiSelect: false,
                                //     anyMatch: true,
                                //     // store: effectiveVersionStore,
                                //     store: Ext.create('Ext.data.Store', {
                                //         fields: ['name', 'fullName'],
                                //         data: dynamicOptions  // 将 dynamicOptions 变量作为下拉框的数据源
                                //     }),
                                //     valueField: 'name',
                                //     displayField: 'fullName',
                                //     minChars: 1,//开始查询最小字符数
                                //     mode: 'local', //查询模式  local为本地数据源  remote为远程服务端
                                // }
                            :false
                            , menuDisabled: true,renderer:showTip},
                    ]
                },
                {
                    text: '样品确认',menuDisabled: true,flex: 4,
                    columns: [
                        {text: setRequired('是否需要样品确认',needSampleConfirmationECA02Material), dataIndex: 'needSampleConfirmation', flex: 1, editor: needSampleConfirmationECA02Material?needSampleConfirmation:false, menuDisabled: true,renderer:showTip},
                        {text: setRequired('样品确认流程编号',sampleConfirmationProcessECA02Material), dataIndex: 'sampleConfirmationProcess', flex: 1, editor: sampleConfirmationProcessECA02Material, menuDisabled: true,renderer:showTip,
                            locked: true,
                            renderer: function(value,metaData,record,row,col,store){
                                var link = record.get('sampleConfirmationProcessUrl');
                                return link
                            }
                        },
                        {text: '样品确认流程状态', dataIndex: 'sampleConfirmationState', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '物料确认状态', dataIndex: 'sampleConfirmationPartState', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        EBOMChangeECAGrid.on('cellclick', function (){

        });

        EBOMChangeECAGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('EBOMChangeECAStore').load();
            };
            updateChangeECA(id,"EcaEPartChange",tField,tValue,callbackFn)
        });

        //根据特定字段的值判断是否禁止编辑
        EBOMChangeECAGrid.on('beforeedit', function (editor, context) {
            var record = context.record;
            //是否同步打样资料
            var related = record.get('synchronizeSampleData');
            //是否需要试产
            var needTrialProduction = record.get('needTrialProduction');
            var columnName = context.column.dataIndex;

            if("effectiveVersion" === columnName){
                partNumber = record.data.objectNumber;
                effectiveVersionStore.load(
                    {
                        params: {
                            partNumber: partNumber,
                            changeRequestId:changeRequestId
                        }
                    }
                );
            }

            if("否" === related && "effectiveVersion" === columnName){
                return false; // 禁止编辑指定列
            }
            //为否或者为空则不让填写
            if((!needTrialProduction||"否" === needTrialProduction )
                && ("trialResponsiblePerson" === columnName
                || "trialProcessNumber" === columnName || "trialProductionStatus" === columnName)){
                return false; // 禁止编辑指定列
            }
            return true; // 允许编辑操作

            // // 判断点击的是哪一列，列名
            // var columnName = context.column.dataIndex;
            // if (sampleType === '否') {
            //     if(columnName === 'isItASubstituteMaterial'||columnName === 'detailedReasons'||columnName === 'substitutionGroupMaterial'||
            //         columnName === 'alternativeMaterials'||columnName === 'alternativeMaterialsDesc'||columnName === 'alternativeMaterialsSupplier'||
            //         columnName === 'alternativeMaterialsBrand'||columnName === 'originalPrice'||columnName === 'currentPrice'||
            //         columnName === 'lastYearProcurementVolume'||columnName === 'expectedAnnualPriceDifference'){
            //         return false; // 禁止编辑指定列
            //     }
            // }
            // return true; // 允许编辑操作
        });





//===================================2. 物料及EBOM变更ECA 结束===============================================================


//===================================物料变更内容  (非以下字段修改，请将修改的"字段信息及值"在"变更描述中填写，“产品数据工程师收到ECA后手工修改) 开始===============================================================
        Ext.define('ecaPartNumberModel', {
            extend: 'Ext.data.Model',
            fields: ['partNumber','viewName'],
            idProperty: 'id'
        });

        var ecaPartNumberStore = Ext.create('Ext.data.Store', {
            id: 'ecaPartNumberStore',
            model: 'ecaPartNumberModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECRApprovalRecords/getChangePartNumbers?changeRequestId='+changeRequestId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

        var ecaPartNumberCombo =new Ext.form.field.ComboBox({
            forceSelection: false, //forceSelection 是否能够手填
            name: 'ecaPartNumberCombo',
            id: 'ecaPartNumberCombo',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore("ecaPartNumberStore"),
            valueField: 'partNumber',
            displayField: 'partNumber',
        });



        Ext.define('ECA02MaterialChangeContentModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','parentNumber','partNumber','partDescBefore','internalVersionBefore','partDescAfter','internalVersionAfter',
                'needSampleConfirmation','sampleConfirmationProcess','sampleConfirmationState','sampleConfirmationPartState'
                ,'partUrl'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.ECA02MaterialChangeContentStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ECA02MaterialChangeContentModel',
            id:'ECA02MaterialChangeContentStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchECAPartChange?changeRequestId='+changeRequestId,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                },
                listeners: {
                    exception: function(proxy, response, operation) {
                        // 解析后端返回的错误信息
                        var error = Ext.decode(response.responseText);

                        // 在页面上显示错误信息，可以使用ExtJS的消息框或者直接渲染到页面
                        // Ext.Msg.alert('Error', error.message);
                        alert(error.message);
                    }
                }
            }),
            autoLoad:true
        });

        // Ext.getStore('ECA02MaterialChangeContentStore').on('load', function(store, records, success,operation,message) {
        //     if (success) {
        //         // 数据加载成功
        //         console.log('数据加载成功！');
        //         console.log(records); // 打印加载的数据记录
        //     } else {
        //         // 数据加载失败
        //         console.log('数据加载失败！');
        //     }
        // });



        var ECA02MaterialChangeContentCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ECA02MaterialChangeContentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [ECA02MaterialChangeContentCellEditing],
            store: Ext.getStore('ECA02MaterialChangeContentStore'),
            id: 'ECA02MaterialChangeContentGrid',
            margin: '0 10 0 0',
            title: '物料变更内容  (非以下字段修改，请将修改的"字段信息及值"在"变更描述中填写，“产品数据工程师收到ECA后手工修改)',
            titleAlign: 'center', // 设置标题居中
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {text: '父项编码', dataIndex: 'parentNumber', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: setMust('物料编码',partNumberAfterECA02Material),
                    dataIndex: 'partNumber', flex: 1, editor: partNumberAfterECA02Material?ecaPartNumberCombo:false,
                    menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('partUrl')) {
                            let changeLink = record.get('partUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {
                    text: '物料变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '物料描述', dataIndex: 'partDescBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '内部版本', dataIndex: 'internalVersionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '物料变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: setRequired('物料描述',partDescAfterECA02Material), dataIndex: 'partDescAfter', flex: 1, editor: partDescAfterECA02Material, menuDisabled: true,renderer:showTip},
                        {text: setRequired('内部版本',internalVersionAfterECA02Material), dataIndex: 'internalVersionAfter', flex: 1, editor: internalVersionAfterECA02Material, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
            tbar: [
                {
                    xtype: 'button',
                    text: '新增行',
                    // id: 'trialMBOMInsert',
                    iconCls: 'icon icon-add',
                    hidden: !addOrDeleteECA02Material,
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ECAExecutionRecord/addECAPartChange?changeRequestId='+changeRequestId,
                            async: false,
                            headers: {'Content-Type': 'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=="success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    Ext.getStore('ECA02MaterialChangeContentStore').load();
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行',
                    // id: 'trialMBOMDelete',
                    iconCls: 'icon icon-delete',
                    hidden: !addOrDeleteECA02Material,
                    handler: function () {
                        var selected = ECA02MaterialChangeContentGrid.getSelectionModel().getSelection();
                        if (selected.length != 0) {
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    if(i == 0){
                                        ids += id;
                                    }else{
                                        ids += ',' + id;
                                    }
                                }
                            }
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/ECAExecutionRecord/deleteECAPartChange?ids='+ids,
                                async: false,
                                headers: {'Content-Type': 'application/json'},
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=="success") {
                                        //回调函数，一般用于后台操作成功后刷新列表
                                        Ext.getStore('ECA02MaterialChangeContentStore').load();
                                    } else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：保存信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }

                    }
                }
            ]
        });

        ECA02MaterialChangeContentGrid.on('rowclick', function (view, record, item, index, e){
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if (columnName == 'partNumber') {
                    Ext.getStore("ecaPartNumberStore").load();
                }
            }
        });

        ECA02MaterialChangeContentGrid.on('cellclick', function (){

        });

        ECA02MaterialChangeContentGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECAExecutionRecord/updateECAPartChange?id='+id+'&key='+tField+'&value='+tValue,
                async: false,
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=="success") {

                    } else {
                        alert(obj.message);
                    }
                    //回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('ECA02MaterialChangeContentStore').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
        });
//===================================物料变更内容  (非以下字段修改，请将修改的"字段信息及值"在"变更描述中填写，“产品数据工程师收到ECA后手工修改) 结束===============================================================

//===================================EBOM变更内容 开始===============================================================

        Ext.define('ecaEBOMModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','finishedProductNumber','parentNumber','parentDesc','changeType','partNumberBefore','partDescBefore','tagNumberBefore','bomRemarkBefore',
                'fractionBefore','quantityBefore','partNumberAfter','partDescAfter','tagNumberAfter','bomRemarkAfter','fractionAfter','quantityAfter','remarks','responsiblePerson'
            ],
            idProperty: 'ecaEBOMModel'
        });

        var ecaEBOMStore = Ext.create('Ext.data.Store', {
            model: 'ecaEBOMModel',
            id: 'ecaEBOMStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaEBomChange?changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'ecaEBOMModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var ecaEBOMColumns = [
            {text: '父项所属成品编码', dataIndex: 'finishedProductNumber', width: 100, editor: false, menuDisabled: true,
                // style: disableNode(start_node)?'color: blue;':''
            },
            {
                text: setMust('父项编码',parentNumberECAEBOM),
                dataIndex: 'parentNumber', width: 100,
                editor: parentNumberECAEBOM?ECAEBOMParentNumberCombo:false,
                menuDisabled: true,// style: disableNode(start_node)?'color: blue;':''
                renderer: function(value,metaData,record,row,col,store){
                    if(value)
                        metaData.tdAttr = 'data-qtip="' + value +'"';
                    if(record.get('parentUrl')) {
                        let changeLink = record.get('parentUrl');
                        return changeLink;
                    }else {
                        return value;
                    }
                }
            },
            {text: '父项描述', dataIndex: 'parentDesc', width: 100,menuDisabled: true},
            {text: setMust('变更类型',changeTypeECAEBOM), dataIndex: 'changeType', width: 100, editor: changeTypeECAEBOM?ECAChangeType:false, menuDisabled: true},
            {
                text: '变更前',menuDisabled: true,
                columns: [
                    {
                        text: setRequired('物料编码',partNumberBeforeECAEBOM),
                        dataIndex: 'partNumberBefore', width: 100,
                        editor: partNumberBeforeECAEBOM, menuDisabled: true,
                        renderer: function(value,metaData,record,row,col,store){
                            if(value)
                                metaData.tdAttr = 'data-qtip="' + value +'"';
                            if(record.get('beforeUrl')) {
                                let changeLink = record.get('beforeUrl');
                                return changeLink;
                            }else {
                                return value;
                            }
                        }
                    },
                    {text: '物料描述', dataIndex: 'partDescBefore', width: 100, editor: false, menuDisabled: true},
                    {text: '分数', dataIndex: 'fractionBefore', width: 100, editor: false, menuDisabled: true},
                    {text: '数量', dataIndex: 'quantityBefore', width: 100, editor: false, menuDisabled: true},
                    {text: '位号', dataIndex: 'tagNumberBefore', width: 100, editor: false, menuDisabled: true},
                    {text: 'BOM备注', dataIndex: 'bomRemarkBefore', width: 100, editor: false, menuDisabled: true},
                ]
            },
            {
                text: '变更后',menuDisabled: true,
                columns: [
                    {
                        text: setRequired('物料编码',partNumberAfterECAEBOM),
                        dataIndex: 'partNumberAfter', width: 100,
                        editor: partNumberAfterECAEBOM, menuDisabled: true,
                        renderer: function(value,metaData,record,row,col,store){
                            if(value)
                                metaData.tdAttr = 'data-qtip="' + value +'"';
                            if(record.get('afterUrl')) {
                                let changeLink = record.get('afterUrl');
                                return changeLink;
                            }else {
                                return value;
                            }
                        }
                    },
                    {text: '物料描述', dataIndex: 'partDescAfter', width: 100, editor: false , menuDisabled: true},
                    {text: setRequired('分数',fractionAfterECAEBOM), dataIndex: 'fractionAfter', width: 100, editor: fractionAfterECAEBOM, menuDisabled: true},
                    {text: setRequired('数量',quantityAfterECAEBOM), dataIndex: 'quantityAfter', width: 100, editor: quantityAfterECAEBOM, menuDisabled: true},
                    {text: setRequired('位号',tagNumberAfterECAEBOM), dataIndex: 'tagNumberAfter', width: 100, editor: tagNumberAfterECAEBOM, menuDisabled: true},
                    {text: setRequired('BOM备注',bomRemarkAfterECAEBOM), dataIndex: 'bomRemarkAfter', width: 100, editor: bomRemarkAfterECAEBOM, menuDisabled: true},

                ]
            },
            {text: setRequired('备注',remarksECAEBOM), dataIndex: 'remarks', width: 100, editor: remarksECAEBOM, menuDisabled: true},
            {text: 'EBOM更改负责人', dataIndex: 'responsiblePerson', width: 100, editor: ebomCom, menuDisabled: true},
            {text: '', dataIndex: '', width: 10, menuDisabled: true}
        ];

        var ecaEBOMGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var ecaEBOMGrid = Ext.create('Ext.grid.Panel', {
            plugins: [ecaEBOMGridEditing],
            store: ecaEBOMStore,
            columns: ecaEBOMColumns,
            id:'ecaEBOMGrid',
            title: 'EBOM变更内容',
            titleAlign: 'center', // 设置标题居中
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true,forceFit: false },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '新增行',
                    // id: 'trialMBOMInsert',
                    iconCls: 'icon icon-add',
                    hidden: addECAEBOM?false:true,
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ECAExecutionRecord/addEcaEBomChange?changeRequestId='+changeRequestId,
                            async: false,
                            headers: {'Content-Type': 'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=="success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    Ext.getStore('ecaEBOMStore').load();
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行',
                    // id: 'trialMBOMDelete',
                    iconCls: 'icon icon-delete',
                    hidden: deleteECAEBOM?false:true,
                    handler: function () {
                        var selected = ecaEBOMGrid.getSelectionModel().getSelection();
                        if (selected.length != 0) {
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    if(i == 0){
                                        ids += id;
                                    }else{
                                        ids += ',' + id;
                                    }
                                }
                            }
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/ECAExecutionRecord/deleteEcaEBomChange?ids='+ids,
                                async: false,
                                headers: {'Content-Type': 'application/json'},
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=="success") {
                                        //回调函数，一般用于后台操作成功后刷新列表
                                        Ext.getStore('ecaEBOMStore').load();
                                    } else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：保存信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '复制',
                    id: 'ecaEBOMInsert',
                    iconCls: 'icon-copy',
                    hidden: copyECAEBOM?false:true,
                    handler: function () {
                        var selected = ecaEBOMGrid.getSelectionModel().getSelection();
                        if (selected.length != 0) {
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    if (i == 0) {
                                        ids += id;
                                    } else {
                                        ids += ',' + id;
                                    }
                                }
                            }
                            copyId = ids;
                        }else {
                            copyId = "";
                            alert("请先选择数据！")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '下载导入模板',
                    id: 'ecaEBOMDelete',
                    iconCls: 'icon icon-download',
                    hidden: downloadECAEBOM?false:true,
                    handler: function () {
                        window.location.href = '/Windchill/ptc1/ECRApprovalRecords/downLoadTemplate?templateName=BOM变更导入模板';
                    }
                },
                {
                    xtype:'filefield',
                    buttonOnly: true,
                    // disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                    id:'ecaEBOMupload',
                    hideLabel: true,
                    hidden: ecaEBOMuploadECAEBOM?false:true,
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入EBOM变更内容</span>',
                    allowBlank: false,
                    scope: this,
                    listeners:{
                        'change':function(fb,newValue,oldValue,opts){
                            if(!newValue){
                                return;
                            }
                            var boms = "ebom";
                            var file = document.querySelector('[id=ecaEBOMupload-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('ecaEBOMupload-button-fileInputEl', file.files[0]);

                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在导入数据，请稍候......',
                                target: ecaEBOMGrid
                            });

                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/ECRApprovalRecords/importChangeItems?changeRequestId='+changeRequestId+'&changeTableType=EcaEBomChange&type=ebom'+'&workItemOid='+"workItemOid",
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function(res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if(!success){
                                    alert(msg);
                                    // Ext.getStore('ecaEBOMStore').load();
                                    // ecaEBOMGrid.getStore().load();
                                }
                                ecaEBOMGrid.getStore().load();
                            }).fail(function(res) {
                                var obj = Ext.decode(res);
                                var msg = obj['msg'];
                                myMask.hide();
                                alert('导入失败！\n'+msg) ;
                            });
                        }


                    }
                }
            ]
        });

        ecaEBOMGrid.on('rowclick', function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'parentNumber'){
                    Ext.getStore("ECAEBOMParentNumberStore").reload();
                }
            }
        })

        ecaEBOMGrid.on('edit',function(editor,e){
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECAExecutionRecord/updateEcaEBomChange?id='+id+'&key='+tField+'&value='+tValue,
                async: false,
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=="success") {

                    } else {
                        alert(obj.message);
                    }
                    //回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('ecaEBOMStore').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
        });
//===================================EBOM变更内容 结束===============================================================

//===================================3. MBOM变更ECA  开始===============================================================
        Ext.define('MBOMChangeECAModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','tableType','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter','needTrialProduction','trialMaterialNumber',
                'trialResponsiblePerson','trialProcessNumber', 'trialProductionStatus','synchronizeSampleData','effectiveVersion'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.MBOMChangeECAStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'MBOMChangeECAModel',
            id:'MBOMChangeECAStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=EcaMPartChange'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var MBOMChangeECACellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var MBOMChangeECAGrid = Ext.create('Ext.grid.Panel', {
            plugins: [MBOMChangeECACellEditing],
            store: Ext.getStore('MBOMChangeECAStore'),
            id: 'MBOMChangeECAGrid',
            margin: '0 10 0 0',
            // title: '3. MBOM变更ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber',
                    flex: 1, menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                },
                {
                    text: '小批量验证',menuDisabled: true,flex: 5,
                    columns: [
                        {text: '小批量验证确认', dataIndex: 'needTrialProduction', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        //{text: '试产物料编号', dataIndex: 'trialMaterialNumber', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        // {text: setRequired('试产责任人',trialResponsiblePersonMBOMChangeECA), dataIndex: 'trialResponsiblePerson', flex: 1, editor: trialResponsiblePersonMBOMChangeECA?responsiblePersonCom:false, menuDisabled: true,renderer:showTip},
                        {text: setRequired('小批量验证流程编号',trialProcessNumberMBOMChangeECA), dataIndex: 'trialProcessNumber', flex: 1, editor: trialProcessNumberMBOMChangeECA, menuDisabled: true,renderer:showTip},
                        // {text: setRequired('试产状态',trialProductionStatusMBOMChangeECA), dataIndex: 'trialProductionStatus', flex: 1, editor: trialProductionStatusMBOMChangeECA, menuDisabled: true,renderer:showTip},
                        {text: '小批量验证流程状态', dataIndex: 'trialProductionStatus', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],


        });

        MBOMChangeECAGrid.on('cellclick', function (){

        });

        MBOMChangeECAGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('MBOMChangeECAStore').load();
            };
            updateChangeECA(id,"EcaMPartChange",tField,tValue,callbackFn)
        });

        //根据特定字段的值判断是否禁止编辑
        MBOMChangeECAGrid.on('beforeedit', function (editor, context) {
            var record = context.record;
            //是否需要试产
            var needTrialProduction = record.get('needTrialProduction');
            var columnName = context.column.dataIndex;
            //为否或者为空则不让填写
            if((!needTrialProduction||"否" === needTrialProduction )
                && ("trialProcessNumber" === columnName || "trialProductionStatus" === columnName)){
                return false; // 禁止编辑指定列
            }
            return true; // 允许编辑操作
        });
//===================================3. MBOM变更ECA 结束===============================================================


//===================================MBOM变更内容 开始===============================================================
        Ext.define('ecaMBOMModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','finishedProductNumber','parentNumber','parentDesc','changeType','partNumberBefore','partDescBefore','tagNumberBefore',
                'bomRemarkBefore', 'fractionBefore','quantityBefore','partNumberAfter','partDescAfter','tagNumberAfter','bomRemarkAfter','fractionAfter',
                'quantityAfter', 'remarks','responsiblePerson'
            ],
            idProperty: 'ecaMBOMModel'
        });

        var ecaMBOMStore = Ext.create('Ext.data.Store', {
            model: 'ecaMBOMModel',
            id: 'ecaMBOMStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaMBomChange?changeRequestId='+changeRequestId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'ecaMBOMModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var ecaMBOMColumns = [
            {text: '父项所属成品编码', dataIndex: 'finishedProductNumber', width: 100, editor: false, menuDisabled: true,
                // style: disableNode(start_node)?'color: blue;':''
            },
            {
                text: setMust('父项编码',parentNumberECAMBOM), dataIndex: 'parentNumber',
                width: 100, editor: parentNumberECAMBOM?ECAMBOMParentNumberCombo:false,
                menuDisabled: true,// style: disableNode(start_node)?'color: blue;':''
                renderer: function(value,metaData,record,row,col,store){
                    if(value)
                        metaData.tdAttr = 'data-qtip="' + value +'"';
                    if(record.get('parentUrl')) {
                        let changeLink = record.get('parentUrl');
                        return changeLink;
                    }else {
                        return value;
                    }
                }
            },
            {text: '父项描述', dataIndex: 'parentDesc', width: 100,menuDisabled: true},
            {text: setMust('变更类型',changeTypeECAMBOM), dataIndex: 'changeType', width: 100, editor: changeTypeECAMBOM?ECAChangeType:false, menuDisabled: true},
            {
                text: '变更前',menuDisabled: true,
                columns: [
                    {
                        text: setRequired('物料编码',partNumberBeforeECAMBOM),
                        dataIndex: 'partNumberBefore', width: 100,
                        editor: partNumberBeforeECAMBOM, menuDisabled: true,
                        renderer: function(value,metaData,record,row,col,store){
                            if(value)
                                metaData.tdAttr = 'data-qtip="' + value +'"';
                            if(record.get('beforeUrl')) {
                                let changeLink = record.get('beforeUrl');
                                return changeLink;
                            }else {
                                return value;
                            }
                        }
                    },
                    {text: '物料描述', dataIndex: 'partDescBefore', width: 100, editor: null, menuDisabled: true},
                    {text: '分数', dataIndex: 'fractionBefore', width: 100, editor: false, menuDisabled: true},
                    {text: '数量', dataIndex: 'quantityBefore', width: 100, editor: null, menuDisabled: true},
                    {text: '位号', dataIndex: 'tagNumberBefore', width: 100, editor: null, menuDisabled: true},
                    {text: 'BOM备注', dataIndex: 'bomRemarkBefore', width: 100, editor: null, menuDisabled: true}
                ]
            },
            {
                text: '变更后',menuDisabled: true,
                columns: [
                    {
                        text: setRequired('物料编码',partNumberAfterECAMBOM),
                        dataIndex: 'partNumberAfter', width: 100, editor: partNumberAfterECAMBOM,
                        menuDisabled: true,
                        renderer: function(value,metaData,record,row,col,store){
                            if(value)
                                metaData.tdAttr = 'data-qtip="' + value +'"';
                            if(record.get('afterUrl')) {
                                let changeLink = record.get('afterUrl');
                                return changeLink;
                            }else {
                                return value;
                            }
                        }
                    },
                    {text: '物料描述', dataIndex: 'partDescAfter', width: 100, editor: false , menuDisabled: true},
                    {text: setRequired('分数',fractionAfterECAMBOM), dataIndex: 'fractionAfter', width: 100, editor: fractionAfterECAMBOM, menuDisabled: true},
                    {text: setRequired('数量',quantityAfterECAMBOM), dataIndex: 'quantityAfter', width: 100, editor: quantityAfterECAMBOM, menuDisabled: true},
                    {text: setRequired('位号',tagNumberAfterECAMBOM), dataIndex: 'tagNumberAfter', width: 100, editor: tagNumberAfterECAMBOM, menuDisabled: true},
                    {text: setRequired('BOM备注',bomRemarkAfterECAMBOM), dataIndex: 'bomRemarkAfter', width: 100, editor: bomRemarkAfterECAMBOM, menuDisabled: true}
                ]
            },
            {text: setRequired('备注',remarksECAMBOM), dataIndex: 'remarks', width: 100, editor: remarksECAMBOM, menuDisabled: true},
            {text: 'MBOM更改负责人', dataIndex: 'responsiblePerson', width: 100, editor: mbomCom, menuDisabled: true},
            {text: '', dataIndex: '', width: 10, menuDisabled: true}
        ];

        var ecaMBOMGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var ecaMBOMGrid = Ext.create('Ext.grid.Panel', {
            plugins: [ecaMBOMGridEditing],
            store: ecaMBOMStore,
            columns: ecaMBOMColumns,
            id:'ecaMBOMGrid',
            title: 'MBOM变更内容',
            titleAlign: 'center', // 设置标题居中
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true,forceFit: false },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '新增行',
                    // id: 'MBOMInsert',
                    iconCls: 'icon icon-add',
                    hidden: addECAMBOM?false:true,
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ECAExecutionRecord/addEcaMBomChange?changeRequestId='+changeRequestId,
                            async: false,
                            headers: {'Content-Type': 'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=="success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    Ext.getStore('ecaMBOMStore').load();
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行',
                    // id: 'MBOMDelete',
                    iconCls: 'icon icon-delete',
                    hidden: deleteECAMBOM?false:true,
                    handler: function () {
                        var selected = ecaMBOMGrid.getSelectionModel().getSelection();
                        if (selected.length != 0) {
                            let ids = '';
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    if(i == 0){
                                        ids += id;
                                    }else{
                                        ids += ',' + id;
                                    }
                                }
                            }
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/ECAExecutionRecord/deleteEcaMBomChange?ids='+ids,
                                async: false,
                                headers: {'Content-Type': 'application/json'},
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=="success") {
                                        //回调函数，一般用于后台操作成功后刷新列表
                                        Ext.getStore('ecaMBOMStore').load();
                                    } else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：保存信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '粘贴',
                    // id: 'ecaMBOMInsert',
                    iconCls: 'icon-paste',
                    hidden: pasteECAMBOM?false:true,
                    handler: function () {
                        // alert(copyId);
                        if (Ext.isEmpty(copyId)) {
                            alert("请先选择要粘贴的数据！");
                        }
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ECRApprovalRecords/pasteChangeItems?id=' + copyId+'&changeRequestId='+changeRequestId,
                            async: false,
                            headers: {'Content-Type': 'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if (obj.message == "success") {
                                    //回调函数，一般用于后台操作成功后刷新列表
                                    Ext.getStore('ecaMBOMStore').load();
                                } else {
                                    alert(obj.message);
                                }
                                copyId = "";
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                                copyId = "";
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '下载导入模板',
                    // id: 'ecaMBOMDelete',
                    iconCls: 'icon icon-download',
                    hidden: downloadECAMBOM?false:true,
                    handler: function () {
                        window.location.href = '/Windchill/ptc1/ECRApprovalRecords/downLoadTemplate?templateName=BOM变更导入模板';
                    }
                },
                {
                    xtype:'filefield',
                    buttonOnly: true,
                    // disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                    id:'ecaMBOMupload',
                    hideLabel: true,
                    hidden: ecaMBOMuploadECAMBOM?false:true,
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入MBOM变更内容</span>',
                    allowBlank: false,
                    scope: this,
                    listeners:{
                        'change':function(fb,newValue,oldValue,opts){
                            if(!newValue){
                                return;
                            }
                            var boms = "mbom";
                            var file = document.querySelector('[id=ecaMBOMupload-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('ecaMBOMupload-button-fileInputEl', file.files[0]);

                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在导入数据，请稍候......',
                                target: ecaMBOMGrid
                            });

                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/ECRApprovalRecords/importChangeItems?changeRequestId='+changeRequestId+'&changeTableType=EcaMBomChange&type=mbom'+'&workItemOid='+"workItemOid",
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function(res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if(!success){
                                    alert(msg);
                                    // Ext.getStore('ecaMBOMStore').load();
                                    // ecaMBOMGrid.getStore().load();
                                }
                                ecaMBOMGrid.getStore().load();
                            }).fail(function(res) {
                                var obj = Ext.decode(res);
                                var msg = obj['msg'];
                                myMask.hide();
                                alert('导入失败！\n'+msg) ;
                            });
                        }


                    }
                }
            ]
        });

        ecaMBOMGrid.on('rowclick', function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            if(!cell){
                return;
            }
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'parentNumber'){
                    Ext.getStore("ECAMBOMParentNumberStore").reload();
                }
            }
        })

        ecaMBOMGrid.on('edit',function(editor,e){
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ECAExecutionRecord/updateEcaMBomChange?id='+id+'&key='+tField+'&value='+tValue,
                async: false,
                headers: {'Content-Type': 'application/json'},
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=="success") {

                    } else {
                        alert(obj.message);
                    }
                    //回调函数，一般用于后台操作成功后刷新列表
                    Ext.getStore('ecaMBOMStore').load();
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败，请检查网络！!');
                }
            });
        });
//===================================MBOM变更内容 结束===============================================================

//===================================4. 结构图纸更改ECA  开始===============================================================
        Ext.define('eca04Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eca04Store = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eca04Model',
            id:'eca04Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=eca04'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var eca04CellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eca04Grid = Ext.create('Ext.grid.Panel', {
            plugins: [eca04CellEditing],
            store: Ext.getStore('eca04Store'),
            id: 'eca04Grid',
            margin: '0 10 0 0',
            // title: '4. 结构图纸更改ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber',
                    flex: 1, menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        eca04Grid.on('cellclick', function (){

        });

        eca04Grid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('eca04Store').load();
            };
            updateChangeECA(id,"eca04",tField,tValue,callbackFn)
        });
//===================================4. 结构图纸更改ECA 结束===============================================================

//===================================5. 电子图纸更改任务ECA  开始===============================================================
        Ext.define('eca05Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eca05Store = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eca05Model',
            id:'eca05Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=eca05'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var eca05CellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eca05Grid = Ext.create('Ext.grid.Panel', {
            plugins: [eca05CellEditing],
            store: Ext.getStore('eca05Store'),
            id: 'eca05Grid',
            margin: '0 10 0 0',
            // title: '5. 电子图纸更改任务ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber', flex: 1,
                    menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        eca05Grid.on('cellclick', function (){

        });

        eca05Grid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('eca05Store').load();
            };
            updateChangeECA(id,"eca05",tField,tValue,callbackFn)
        });
//===================================5. 电子图纸更改任务ECA 结束===============================================================

//===================================6. 软件文件更改任务ECA  开始===============================================================
        Ext.define('eca06Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eca06Store = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eca06Model',
            id:'eca06Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=eca06'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var eca06CellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eca06Grid = Ext.create('Ext.grid.Panel', {
            plugins: [eca06CellEditing],
            store: Ext.getStore('eca06Store'),
            id: 'eca06Grid',
            margin: '0 10 0 0',
            // title: '6. 软件文件更改任务ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber',
                    flex: 1, menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        eca06Grid.on('cellclick', function (){

        });

        eca06Grid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('eca05Store').load();
            };
            updateChangeECA(id,"eca05",tField,tValue,callbackFn)
        });
//===================================6. 软件文件更改任务ECA 结束===============================================================

//===================================7. SIP更改任务ECA  开始===============================================================
        Ext.define('eca07Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eca07Store = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eca07Model',
            id:'eca07Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=eca07'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var eca07CellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eca07Grid = Ext.create('Ext.grid.Panel', {
            plugins: [eca07CellEditing],
            store: Ext.getStore('eca07Store'),
            id: 'eca07Grid',
            margin: '0 10 0 0',
            // title: '7. SIP更改任务ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber', flex: 1, menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        eca07Grid.on('cellclick', function (){

        });

        eca07Grid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('eca07Store').load();
            };
            updateChangeECA(id,"eca07",tField,tValue,callbackFn)
        });
//===================================7. SIP更改任务ECA 结束===============================================================

//===================================8. SOP更改任务ECA  开始===============================================================
        Ext.define('eca08Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eca08Store = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eca08Model',
            id:'eca08Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=eca08'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var eca08CellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eca08Grid = Ext.create('Ext.grid.Panel', {
            plugins: [eca08CellEditing],
            store: Ext.getStore('eca08Store'),
            id: 'eca08Grid',
            margin: '0 10 0 0',
            // title: '8. SOP更改任务ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber', flex: 1,
                    menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        eca08Grid.on('cellclick', function (){

        });

        eca08Grid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('eca08Store').load();
            };
            updateChangeECA(id,"eca08",tField,tValue,callbackFn)
        });
//===================================8. SOP更改任务ECA 结束===============================================================

//===================================9. 技术支持更改任务ECA  开始===============================================================
        Ext.define('eca09Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eca09Store = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eca09Model',
            id:'eca09Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=eca09'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var eca09CellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eca09Grid = Ext.create('Ext.grid.Panel', {
            plugins: [eca09CellEditing],
            store: Ext.getStore('eca09Store'),
            id: 'eca09Grid',
            margin: '0 10 0 0',
            // title: '9. 技术支持更改任务ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber',
                    flex: 1, menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        eca09Grid.on('cellclick', function (){

        });

        eca09Grid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('eca09Store').load();
            };
            updateChangeECA(id,"eca09",tField,tValue,callbackFn)
        });
//===================================9. 技术支持更改任务ECA 结束===============================================================


//===================================10. 市场更改任务ECA  开始===============================================================
        Ext.define('eca10Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eca10Store = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eca10Model',
            id:'eca10Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=eca10'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var eca10CellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eca10Grid = Ext.create('Ext.grid.Panel', {
            plugins: [eca10CellEditing],
            store: Ext.getStore('eca10Store'),
            id: 'eca10Grid',
            margin: '0 10 0 0',
            // title: '10. 市场更改任务ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber',
                    flex: 1, menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        eca10Grid.on('cellclick', function (){

        });

        eca10Grid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('eca10Store').load();
            };
            updateChangeECA(id,"eca10",tField,tValue,callbackFn)
        });
//===================================10. 市场更改任务ECA 结束===============================================================

//===================================10. 销售更改任务ECA  开始===============================================================
        Ext.define('eca11Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id','objectNumber','objectDesc','stateBefore','versionBefore','stateAfter','versionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eca11Store = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eca11Model',
            id:'eca11Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ECAExecutionRecord/searchEcaChange?changeRequestId=' + changeRequestId+'&tableType=eca11'+'&taskCompleted='+taskCompleted,
                // params:{
                //     changeRequestId:Ext.encode(changeRequestId),
                // },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });



        var eca11CellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eca11Grid = Ext.create('Ext.grid.Panel', {
            plugins: [eca11CellEditing],
            store: Ext.getStore('eca11Store'),
            id: 'eca11Grid',
            margin: '0 10 0 0',
            // title: '11. 销售更改任务ECA',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            // height:'100%',
            // height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true},
            columns: [
                {
                    text: '对象编号', dataIndex: 'objectNumber',
                    flex: 1, menuDisabled: true,renderer:showTip,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(record.get('objectUrl')) {
                            let changeLink = record.get('objectUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {text: '对象描述', dataIndex: 'objectDesc', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                {
                    text: '变更前',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionBefore', flex: 1, editor: false, menuDisabled: true,renderer:showTip}
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,flex: 2,
                    columns: [
                        {text: '状态', dataIndex: 'stateAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                        {text: '版本', dataIndex: 'versionAfter', flex: 1, editor: false, menuDisabled: true,renderer:showTip},
                    ]
                }
            ],
        });

        eca11Grid.on('cellclick', function (){

        });

        eca11Grid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var id = tRecord.data.id;
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                Ext.getStore('eca11Store').load();
            };
            updateChangeECA(id,"eca11",tField,tValue,callbackFn)
        });
//===================================11. 销售更改任务ECA 结束===============================================================



//===================================12. 物控执行反馈 开始===============================================================

        setEcrSingleFieldValue('materialControlFeedback','ECA12ApprovedBy',
            'ECA12ApprovalResults','ECA12ApprovalTime','materialControlFeedback');

        var materialControlFeedback = Ext.create('Ext.form.field.Date', {
            margin: '10 5 10 5',
            fieldLabel: setMust('BOM更改生效时间', materialControlFeedbackEditable),
            labelWidth: 120,
            Width: 120,
            readOnly:!materialControlFeedbackEditable,
            // width: '99%',
            id: 'materialControlFeedback',
            name: 'materialControlFeedback',
            format: 'Y-m-d', // 设置日期格式，根据需要调整
            listeners: {
                select: function(datePicker, date) {

                    // 当日期被选择时触发此事件
                    if (date) {
                        // 将选择的日期转换为时间戳（毫秒）
                        var timestamp = date.getTime();


                        var today = new Date();
                        var todayYear = today.getFullYear();
                        var todayMonth = today.getMonth();
                        var todayDate = today.getDate();
                        // 获取选择的日期的年月日
                        var chosenYear = date.getFullYear();
                        var chosenMonth = date.getMonth();
                        var chosenDate = date.getDate();

                        // 构建当前日期和选择日期的比较对象
                        var todayObj = new Date(todayYear, todayMonth, todayDate);
                        var chosenDateObj = new Date(chosenYear, chosenMonth, chosenDate);

                        if (chosenDateObj >= todayObj) {

                        } else {
                            alert("请选择一个不晚于今天的日期！")
                            setEcrSingleFieldValue('materialControlFeedback','ECA12ApprovedBy',
                                'ECA12ApprovalResults','ECA12ApprovalTime','materialControlFeedback');
                            return ; // 日期无效
                        }


                        // 调用保存函数，将时间戳传递给后端
                        saveEcrSingleField("materialControlFeedback", timestamp);
                    }
                }
            }
        });

        var materialControlFeedbackPanel = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '物控执行反馈',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                materialControlFeedback,
                {
                    xtype: 'panel',
                    // layout: 'hbox',
                    border: false,
                    align: 'stretch',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'ECA12ApprovedBy',
                        name: 'ECA12ApprovedBy',
                        value:'',
                        flex: 1,
                    },
                    // {
                    //     xtype: 'displayfield',
                    //     fieldLabel: '审批结果',
                    //     id: 'ECA12ApprovalResults',
                    //     name: 'ECA12ApprovalResults',
                    //     value:'',
                    //     flex: 1,
                    // },
                        {
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'ECA12ApprovalTime',
                        name: 'ECA12ApprovalTime',
                        value:'',
                        flex: 1,
                    }
                    ]
                }
            ]
        });
//===================================12. 物控执行反馈 结束===============================================================

        var ECA01 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '1. 受影响领域及负责人',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                ECA01Grid
            ]
        });

        var ECA02 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '2. 物料及EBOM变更ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                EBOMChangeECAGrid,
                ECA02MaterialChangeContentGrid,
                ecaEBOMGrid,
                MBOMChangeECAGrid,
            ]
        });

        var ECA03 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '3. MBOM变更ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                MBOMChangeECAGrid,
                ecaMBOMGrid
            ]
        });

        var ECA04 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '4. 结构图纸更改ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                eca04Grid
            ]
        });

        var ECA05 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '5. 电子图纸更改任务ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                eca05Grid
            ]
        });

        var ECA06 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '6. 软件文件更改任务ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                eca06Grid
            ]
        });

        var ECA07 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '7. SIP更改任务ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                eca07Grid
            ]
        });

        var ECA08 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '8. SOP更改任务ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                eca08Grid
            ]
        });

        var ECA09 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '9. 技术支持更改任务ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                eca09Grid
            ]
        });

        var ECA10 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '10. 市场更改任务ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                eca10Grid
            ]
        });

        var ECA11 = Ext.create('Ext.panel.Panel', {
            xtype:'panel',
            title: '11. 销售更改任务ECA',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            items:[
                eca11Grid
            ]
        });













        var ctExecutionRecordTablePanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            // width:'99.9%',
            items:[
                ECA01,
                ECA02,
                ECA03,
                materialControlFeedbackPanel,
                ECA04,
                ECA05,
                ECA06,
                ECA07,
                ECA08,
                ECA09,
                ECA10,
                ECA11,



                // ECA01Grid,
                // EBOMChangeECAGrid,
                // ECA02MaterialChangeContentGrid,
                // ecaEBOMGrid,
                // MBOMChangeECAGrid,
                // ecaMBOMGrid,
                // eca04Grid,
                // eca05Grid,
                // eca06Grid,
                // eca07Grid,
                // eca08Grid,
                // eca09Grid,
                // eca10Grid,
                // eca11Grid
            ]
        });

        this.items = [
            ctExecutionRecordTablePanel
        ];

        this.callParent();

        //========== 结束  PartChangeGrid================

    }
})

/**
 * 按查询参数查询
 */
function doSearch() {
    var vvv= Ext.getCmp('type').getValue();
    if(Ext.getCmp('type').getValue()==null){
        alert("必须选择查询类型！")
        return;
    }
    // Ext.getStore('alternativeMaterialListStore').load({
    //     params: {
    //         // data: Ext.encode(data)
    //         replacePartNumber: Ext.getCmp('replacePartNumber').getValue(),
    //         type: Ext.getCmp('type').getValue(),
    //     },
    //     callback: function (records, operation, success) {
    //         if (!success) {
    //             var responseText = operation.getResponse().responseText;
    //             var responseObject = Ext.decode(responseText);
    //             alert(responseObject.message);
    //             // alert('查询信息失败，请联系管理员！');
    //         }
    //     }
    // });
}