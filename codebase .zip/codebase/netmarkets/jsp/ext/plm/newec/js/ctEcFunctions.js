var redStarFlag = '<font color=red bold>*</font>';//必填标志
var blueFlagStart = '<font color=blue bold><b>';//可编辑标识
var blueFlagEnd = '</b></font>';


var submit_change_request='submit_change_request';//通用变更_提交更改请求=submit_change_request
var formulate_MBOM_programme='formulate_MBOM_programme';//通用变更_MBOM变更负责人制定MBOM变更方案=formulate_MBOM_programme
var product_data_engineer_confirm_info='product_data_engineer_confirm_info';//通用变更_产品数据管理主管审核方案和收集范围是否一致=product_data_engineer_confirm_info
var data_management_reject='data_management_reject';//通用变更_产品数据管理工程师汇总意见判断是否需要驳回=data_management_reject
var product_engineering_manager_information_gathering='product_engineering_manager_information_gathering';//通用变更_产品工程部经理(信息收集)=product_engineering_manager_information_gathering
var quality_control_manager_review='quality_control_manager_review';//通用变更_研发质量经理审核(信息收集,是否需要试产)=quality_control_manager_review
var pcn_upload='pcn_upload';//通用变更_PCN上传=pcn_upload
var department_manager_confirm_info='department_manager_confirm_info';//通用变更_部门经理确认方案、范围、处理意见=department_manager_confirm_info
var manager_of_material_control_department_auditing='manager_of_material_control_department_auditing';//通用变更_物控部经理审核(信息收集)=manager_of_material_control_department_auditing
var purchasing_manager_auditing='purchasing_manager_auditing';//通用变更_寻源部经理审核(信息收集)=purchasing_manager_auditing
var purchasing_execute_manager_auditing='purchasing_execute_manager_auditing';//通用变更_执行部经理审核(信息收集)=purchasing_execute_manager_auditing
var approved_by_the_certification_technical_leader='approved_by_the_certification_technical_leader';//通用变更_产品一致性确认&认证技术负责人批准=approved_by_the_certification_technical_leader
var product_data_management_engineer_acceptance='product_data_management_engineer_acceptance';//通用变更_产品数据管理工程师竞争接收=product_data_management_engineer_acceptance

var general_change_ECA_PDMSR='general_change_ECA_PDMSR';//通用变更ECA_产品数据管理主管审核=general_change_ECA_PDMSR

var EBOM_change_content_and_change_responsible_person='EBOM_change_content_and_change_responsible_person';//通用变更ECA_确认EBOM变更内容，确认变更负责人=EBOM_change_content_and_change_responsible_person
var EBOM_change_content='EBOM_change_content';//通用变更ECA_确认EBOM变更内容=EBOM_change_content
var MBOM_change_content='MBOM_change_content';//通用变更ECA_确认MBOM变更内容=MBOM_change_content
var designated_trial_production_responsible_person='designated_trial_production_responsible_person';//通用变更ECA_指定试产责任人=designated_trial_production_responsible_person
var confirmation_of_trial_production_results='confirmation_of_trial_production_results';//通用变更ECA_小批量验证结果确认=confirmation_of_trial_production_results

var general_change_small_batch_verification_confirmation='general_change_small_batch_verification_confirmation';//通用变更_研发质量经理审核(信息收集,小批量验证确认)=general_change_small_batch_verification_confirmation

var head_node='head_node';//变更流程_设计更改发起=head_node
var rdRep_node='rdRep_node';//变更流程_开发代表审核=rdRep_node
var ebomCharge_node='ebomCharge_node';//变更流程_EBOM变更负责人制定EBOM变更方案=ebomCharge_node
var mbomCharge_node='mbomCharge_node';//变更流程_MBOM变更负责人制定MBOM变更方案=mbomCharge_node
var consistencyRisk_node='consistencyRisk_node';//变更流程_产品一致性确认&认证技术负责人批准=consistencyRisk_node
var dateManageMajor_node='dateManageMajor_node';//变更流程_产品数据管理主管审核=dateManageMajor_node
var pcn_upload_node='pcn_upload_node';//变更流程_上传PCN=pcn_upload_node
var pm_node='pm_node';//变更流程_产品工程部经理审核=pm_node
var tm_node='tm_node';//变更流程_技术部经理审核=tm_node
var hwTechRep_node='hwTechRep_node';//变更流程_硬件开发部经理审核=hwTechRep_node
var swTechRep_node='swTechRep_node';//变更流程_软件开发部经理审核=swTechRep_node
var struTechRep_node='struTechRep_node';//变更流程_结构开发部经理审核=struTechRep_node
var mcRep_node='mcRep_node';//变更流程_物控部经理审核=mcRep_node
var pcRep_node='pcRep_node';//变更流程_采购寻源部经理审核=pcRep_node
var pcegRep_node='pcegRep_node';//变更流程_采购工程师审核=pcegRep_node
var qualityRep_node='qualityRep_node';//变更流程_质量控制部经理审核=qualityRep_node
var pdt_node='pdt_node';//变更流程_CCB评审意见汇总人汇总评审意见=pdt_node
var ccb_node='ccb_node';//变更流程_CCB方案批准=ccb_node
var ipmt_node='ipmt_node';//变更流程_认证技术负责人批准=ipmt_node
var preliminary_review_by_department_manager='preliminary_review_by_department_manager';//变更流程_部门经理初审=preliminary_review_by_department_manager

var change_process_procurement_EMR='change_process_procurement_EMR';//变更流程_采购执行部经理审核=change_process_procurement_EMR

var head01_node='head01_node';//变更1流程_设计更改发起=head01_node
var dateManageEngineer01_node='dateManageEngineer01_node';//变更1流程_产品数据管理工程师审核=dateManageEngineer01_node
var ipmt01_node='ipmt01_node';//变更1流程-认证技术负责人审核=ipmt01_node
var pcRep01_node='pcRep01_node';//变更1流程-采购部经理审核=pcRep01_node
var mcRep01_node='mcRep01_node';//变更1流程-物控部经理审核=mcRep01_node


var head02_node='head02_node';//变更2流程_设计更改发起=head02_node
var deptManager02_node='deptManager02_node';//变更2流程_部门经理初审=deptManager02_node
var dateManageEngineer02_node='dateManageEngineer02_node';//变更2流程_产品数据管理工程师审核=dateManageEngineer02_node

var head03_node='head03_node';//变更3流程_设计更改发起=head03_node
var deptManager03_node='deptManager03_node';//变更3流程_部门经理初审=deptManager03_node
var formulate03_MBOM_programme='formulate03_MBOM_programme';//变更3流程_MBOM变更负责人制定MBOM变更方案=formulate03_MBOM_programme
var dateManageEngineer03_node='dateManageEngineer03_node';//变更3流程_产品数据管理工程师审核=dateManageEngineer03_node
var fast03_track_promoter='fast03_track_promoter';//BOM快速更改任务ECA-发起人修改EBOM=fast03_track_promoter

var head04_node='head04_node';//变更4流程_设计更改发起=head04_node
var deptManager04_node='deptManager04_node';//变更4流程_部门经理初审=deptManager04_node
var dateManageMajor04_node='dateManageMajor04_node';//变更4流程_产品数据管理主管审核=dateManageMajor04_node
var pcRep04_node='pcRep04_node';//变更4流程_采购部经理审核=pcRep04_node
var mcRep04_node='mcRep04_node';//变更4流程_物控部经理审核=mcRep04_node
var pcegRep04_node='pcegRep04_node';//变更4流程_采购工程师审核=pcegRep04_node
var pdt04_node='pdt04_node';//变更4流程_CCB评审意见汇总人汇总评审意见=pdt04_node
var formulate04_MBOM_programme='formulate04_MBOM_programme';//MBOM辅料快速更改任务ECA_MBOM负责人(处理方式)=formulate04_MBOM_programme




var node_software='node_software';//通用变更ECA_执行变更(软件文件更改)=node_software
var node_sip='node_sip';//通用变更ECA_执行变更(SIP更改)=node_sip
var node_sop='node_sop';//通用变更ECA_执行变更(SOP更改)=node_sop
var node_technicalSupport='node_technicalSupport';//通用变更ECA_执行变更(技术支持更改)=node_technicalSupport
var node_market='node_market';//通用变更ECA_执行变更(市场更改)=node_market
var node_structuralDrawings='node_structuralDrawings';//通用变更ECA_执行变更(结构图纸更改)=node_structuralDrawings
var node_electronicDrawings='node_electronicDrawings';//通用变更ECA_执行变更(电子图纸更改)=node_electronicDrawings
var node_sale='node_sale';//通用变更ECA_执行变更(销售更改)=node_sale


var EBOM_change_content_manage='EBOM_change_content_manage';//通用变更ECA_部门经理审核(EBOM)=EBOM_change_content_manage
var MBOM_change_content_manage='MBOM_change_content_manage';//通用变更ECA_部门经理审核(MBOM)=MBOM_change_content_manage
var node_software_manage='node_software_manage';//通用变更ECA_各领域部门经理审核(软件文件更改)=node_software_manage
var node_sip_manage='node_sip_manage';//通用变更ECA_各领域部门经理审核(SIP更改)=node_sip_manage
var node_sop_manage='node_sop_manage';//通用变更ECA_各领域部门经理审核(SOP更改)=node_sop_manage
var node_technicalSupport_manage='node_technicalSupport_manage';//通用变更ECA_各领域部门经理审核(技术支持更改)=node_technicalSupport_manage
var node_market_manage='node_market_manage';//通用变更ECA_各领域部门经理审核(市场更改)=node_market_manage
var node_structuralDrawings_manage='node_structuralDrawings_manage';//通用变更ECA_各领域部门经理审核(结构图纸更改)=node_structuralDrawings_manage
var node_electronicDrawings_manage='node_electronicDrawings_manage';//通用变更ECA_各领域部门经理审核(电子图纸更改)=node_electronicDrawings_manage
var node_sale_manage='node_sale_manage';//通用变更ECA_各领域部门经理审核(销售更改)=node_sale_manage

var material_control_change_response='material_control_change_response';//通用变更ECA_物控-变更响应=material_control_change_response

var general_change_designated_person_in_charge='general_change_designated_person_in_charge';//通用变更ECA_指定试产、试用、样品确认责任人=general_change_designated_person_in_charge
var general_change_confirm_trial_production='general_change_confirm_trial_production';//通用变更ECA_确认是否需要试产试用=general_change_confirm_trial_production
var general_change_sample_confirmation='general_change_sample_confirmation';//通用变更ECA_样品确认跟进=general_change_sample_confirmation


var design_change_initiation='design_change_initiation';//快速变更1_设计更改发起=design_change_initiation
var department_manager_review='department_manager_review';//快速变更1-部门经理审核=department_manager_review
var material_control_department_manager_review='material_control_department_manager_review';//快速变更1-物控部经理审核=material_control_department_manager_review
var purchasing_department_manager_review='purchasing_department_manager_review';//快速变更1-采购寻源部经理审核=purchasing_department_manager_review
var quick_change1_certification_TLR='quick_change1_certification_TLR';//快速变更1-认证技术负责人审核=quick_change1_certification_TLR

var QCDRP_ECA_procurement_SMR='QCDRP_ECA_procurement_SMR';//图纸文档工艺快速更改任务ECA-采购寻源部经理审核=QCDRP_ECA_procurement_SMR
var QCDRP_ECA_procurement_ER='QCDRP_ECA_procurement_ER';//图纸文档工艺快速更改任务ECA-采购工程师审核=QCDRP_ECA_procurement_ER


var design_change_initiation2='design_change_initiation2';//快速变更2_设计更改发起=design_change_initiation2
var product_data_management_supervisor_review='product_data_management_supervisor_review';//快速变更2_产品数据管理主管审核=product_data_management_supervisor_review
var department_manager_initial_review='department_manager_initial_review';//快速变更2_部门经理初审=department_manager_initial_review

var design_change_initiation3='design_change_initiation3';//快速变更3_设计更改发起=design_change_initiation3
var product_data_management_supervisor_review3='product_data_management_supervisor_review3';//快速变更3_产品数据管理主管审核=product_data_management_supervisor_review3
var mbom_change_manager='mbom_change_manager';//快速变更3_MBOM变更负责人制定MBOM变更方案=mbom_change_manager
var review_by_the_procurement_execution_manager='review_by_the_procurement_execution_manager';//快速变更3_采购执行部经理审核=review_by_the_procurement_execution_manager
var upload_pcn='upload_pcn';//快速变更3_上传PCN=upload_pcn
var department_manager_review3='department_manager_review3';//快速变更3_部门经理审批及确认处理意见=department_manager_review3
var procurement_sourcing_manager_reviewed='procurement_sourcing_manager_reviewed';//快速变更3_采购寻源部经理审核=procurement_sourcing_manager_reviewed
var material_control_department_manager_review3='material_control_department_manager_review3';//快速变更3_物控部经理审核=material_control_department_manager_review3
var quick_change3_procurement_engineer_review='quick_change3_procurement_engineer_review';//快速变更3_采购工程师审核=quick_change3_procurement_engineer_review


var material_control_department_review='material_control_department_review';//BOM快速更改任务ECA-物控部经理审核=material_control_department_review

var BOM_quick_change_ECA_planning_SR='BOM_quick_change_ECA_planning_SR';//BOM快速更改任务ECA-计划专员审核=BOM_quick_change_ECA_planning_SR

var design_change_initiation4='design_change_initiation4';//快速变更4_设计更改发起=design_change_initiation4
var product_data_management_supervisor_review4='product_data_management_supervisor_review4';//快速变更4_产品数据管理主管审核=product_data_management_supervisor_review4
var department_manager_review4='department_manager_review4';//快速变更4_部门经理初审=department_manager_review4
var review_by_the_procurement_execution_manager4='review_by_the_procurement_execution_manager4';//快速变更4_采购执行部经理审核=review_by_the_procurement_execution_manager4
var upload_pcn4='upload_pcn4';//快速变更4_上传PCN=upload_pcn4
var summary_of_ccb_review_comments='summary_of_ccb_review_comments';//快速变更4_CCB评审意见汇总人汇总评审意见及物料处理方式=summary_of_ccb_review_comments
var material_control_department_manager_review4='material_control_department_manager_review4';//快速变更4_物控部经理审核=material_control_department_manager_review4
var quick_change4_procurement_engineer_eview='quick_change4_procurement_engineer_eview';//快速变更4_采购工程师审核=quick_change4_procurement_engineer_eview
var quick_change4_procurement_sourcing_manager_review='quick_change4_procurement_sourcing_manager_review';//快速变更4_采购寻源部经理审核=quick_change4_procurement_sourcing_manager_review

var mbom_material_control_manager='mbom_material_control_manager';//MBOM辅料快速更改任务ECA_物控经理（确认生效日期）=mbom_material_control_manager

var design_change_initiation5='design_change_initiation5';//快速变更5_设计更改发起=design_change_initiation5
var product_data_management_supervisor_review5='product_data_management_supervisor_review5';//快速变更5_产品数据管理主管审核=product_data_management_supervisor_review5

var change_process_quality_control_MRSBVC='change_process_quality_control_MRSBVC';//变更流程_质量控制部经理审核小批量验证确认》》》》变更流程_研发质量经理审核小批量验证确认



/**
 * 判断是否可编辑
 * @param node 节点表单key
 * @returns {boolean}
 */
function isEditable(...node) {
    //return true;
    if (readOnlyPage || taskCompleted) return false;
    let flag = false;
    node.forEach((item, index) => {
        if (item === currentActKey) {
            flag = true;
        }
    });
    return flag;
}

/**
 * 设为必填
 */
function setMust(field, flag) {
    // flag = true;
    if (flag)
        return redStarFlag + blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 设为可填
 */
function setRequired(field, flag) {
    // flag = true;
    if (flag)
        return blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 判断是否可编辑
 * @param node 节点表单key
 */
function disableNode(node) {
    if(taskCompleted == 'true') {
        return true;
    } else {
        if(node == currentActKey) {
            return false;
        } else {
            return true;
        }
    }
};

/**
 * 判断节点表单是否应该展开
 */
function openPanel(...node) {
    //只读页面全打开
    if(readOnlyPage) {
        return false;
    }
    if(isEditable(...node)) {
        return false;
    }else {
        return true;
    }
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion


/**
 * 插入潜在受影响表格数据
 * @param callbackFn
 */
function insertPotentialData(callbackFn){
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/addPotentialAffectedObject',
        params: {changeRequestId:changeRequestId},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 保存列表中的一个属性(单元格）
 * @param itemId
 * @param dataKey
 * @param dataValue
 * @param callbackFn
 */
function updatePotentialAffectedData(itemId,dataKey,dataValue,callbackFn){
    var mockRec = {
        changeRequestId:changeRequestId,
        id:itemId,
        key:dataKey,
        value:dataValue
    };
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在收集数据，请稍候......',
        target: Ext.getCmp('changeViewport'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/updatePotentialAffectedObject',
        params: {updateRecord:Ext.encode(mockRec)},
        timeout: 3600000,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
            loadMarsk.hide();
        }
    });
}

/**
 * 编辑受影响对象
 * @param itemId
 * @param dataKey
 * @param dataValue
 * @param callbackFn
 */
function updateAffectedData(itemId, dataKey, dataValue, callbackFn){
    var mockRec = {
        changeRequestId:changeRequestId,
        id:itemId,
        key:dataKey,
        value:dataValue
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/updateAffectedObject',
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    var column = e.column;//获取编辑列
    if (column.editAccess) {
        return true;
    } else {
        return false;
    }
}

/**
 * 删除潜在受影响对象数据
 * @param dbTableName
 * @param ids
 * @param callbackFn
 */
function deletePotentialImpactData(ids, callbackFn){
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/deletePotentialAffectedObject',
        method: 'DELETE',
        params: ids,
        async: false,
        headers: {'Content-Type': 'application/json'},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 点击刷新集成数据
 * @param callbackFn
 */
function refreshSapData(callbackFn){
    var mockRec = {
        changeRequestId:changeRequestId
    };
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在刷新集成数据，请稍候......',
        target: Ext.getCmp('ctPotentialImpactTableGrid'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/refreshSapData',
        params: {refreshRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
            loadMarsk.hide();
        }
    });
}

/**
 * 点击刷新集成数据
 * @param callbackFn
 */
function refreshAffectedObjectsSapData(callbackFn){
    var mockRec = {
        changeRequestId:changeRequestId
    };
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在刷新集成数据，请稍候......',
        target: Ext.getCmp('ctAffectedObjectsTableGrid'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/refreshAffectedObjectSapData',
        timeout: 3600000,
        params: {refreshRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
            loadMarsk.hide();
        }
    });
}

/**
 * 同步数据到受影响对象表格
 * @param callbackFn
 */
function refreshAffectedObject(callbackFn){
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在同步数据到受影响对象，请稍候......',
        target: Ext.getCmp('ctPotentialImpactTableGrid'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/refreshAffectedObject',
        params: {changeRequestId:changeRequestId, nodeName:currentActKey},
        timeout: 3600000,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
            loadMarsk.hide();
        }
    });
}

/**
 * 重新收集
 * @param callbackFn
 */
function refreshCollectObject(callbackFn){
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在重新收集数据，请稍候......',
        target: Ext.getCmp('ctPotentialImpactTableGrid'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/refreshCollectObject',
        params: {changeRequestId:changeRequestId},
        timeout: 3600000,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
            loadMarsk.hide();
        }
    });
}

/**
 * 插入受影响表格数据
 * @param callbackFn
 */
function insertAffectedObject(callbackFn){
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/addAffectedObject',
        params: {changeRequestId:changeRequestId},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}


// =================================上传文档相关============================================================================

// 定义一个变量来存储 ECUploadImageWindow 的实例
var ECUploadImageWindowFinal;

// 定义一个函数来初始化 ECUploadImageWindow，但只在首次调用时创建实例
function initECUploadImageWindow() {
    if (!ECUploadImageWindowFinal) {
        ECUploadImageWindowFinal = Ext.create('Ext.Window', {
            title: '导入文件',
            width: 550,
            height: 350,
            closeAction: 'hide',
            id: 'ECUploadImageWindow',
            autoScroll: false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: {
                xtype: 'ctNewecUploadPanel',
                id: 'uploadFormPanel' // 为组件设置唯一的 id
            }
        });
    }
    return ECUploadImageWindowFinal;
}

var ECShowFileFinal;
function initECShowFiles() {
    if (ECShowFileFinal) {
        // Ext.getCmp('ECShowGrid').getStore().load(
        //     {
        //     params: {
        //         fileColumnId: fileColumnId,
        //         fileColumnName: fileColumnName,
        //         uploadTableName: uploadTableName
        //     }
        // }
        // );
        // 获取到 Store 对象
        var store = Ext.getCmp('ECShowGrid').getStore();
        // 获取到 HttpProxy 对象
        var httpProxy = store.getProxy();
        httpProxy.setUrl(`/Windchill/ptc1/pcnInfo/searchFileName?fileColumnId=${fileColumnId}&fileColumnName=${fileColumnName}&uploadTableName=${uploadTableName}&changeRequestId=${changeRequestId}`);
        // 调用 store 的 load 方法重新加载数据
        store.load();
    }
    if (!ECShowFileFinal) {
        var ECShowColumns = [
            {text: '文档名称', dataIndex: 'fileName', flex: 1, menuDisabled: true, editor: false}
        ];
        var ECShowStore = Ext.create('Ext.data.Store', {
            fields: ['fileName'],
            id: 'ECShowStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/pcnInfo/searchFileName?fileColumnId='+fileColumnId+'&fileColumnName='+fileColumnName
                +'&uploadTableName='+uploadTableName+'&changeRequestId='+changeRequestId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true,
        });
        var ECShowGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ECShowGrid = Ext.create('Ext.grid.Panel', {
            plugins: [ECShowGridEditing],
            store: ECShowStore,
            columns: ECShowColumns,
            id: 'ECShowGrid',
            autoWidth: true,
            columnLines: true,
            width: '100%',
            height: '100%',
            height: 300,
            multiSelect: false,
            autoScroll: true,
            forceFit: false,
            viewConfig: {
                enableTextSelection: true
            },
            selModel: {
                type: "checkboxmodel",
                mode: 'SINGLE'//单选
                // mode: 'MULTI'//多选
            },
            tbar: [
                {
                    xtype: 'button',
                    text: '下载文件',
                    id: 'showInsert',
                    iconCls: 'icon icon-download',
                    handler: function () {
                        var recordList = ECShowGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var fileName = recordList[0].data.fileName;
                            window.location.href = '/Windchill/ptc1/pcnInfo/downLoadDoc?fileName=' + fileName + '&changeRequestId=' + changeRequestId;
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '删除文件',
                    id: 'showDelete',
                    // hidden:bl,
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        if(!isDeletionAllowed){
                            alert("当前节点不允许删除文件！");
                            return;
                        }
                        var recordList = ECShowGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var fileName = recordList[0].data.fileName;
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/pcnInfo/deleteFiles?fileName=' + fileName + '&changeRequestId=' + changeRequestId +
                                    '&fileColumnId=' + fileColumnId + '&fileColumnName=' + fileColumnName + '&uploadTableName=' + uploadTableName,
                                method: 'POST',
                                headers: {'Content-Type': 'application/json'},
                                // params: JSON.stringify(record.data),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    alert(obj.msg)
                                    ECShowStore.load({
                                        params: {
                                            fileColumnId: fileColumnId,
                                            fileColumnName: fileColumnName,
                                            uploadTableName: uploadTableName
                                        }
                                    });
                                    //刷新表格内的数据
                                    var uploadFormPannel = Ext.getCmp(gridName);
                                    // 获取关联的 Store
                                    var store = uploadFormPannel.getStore();
                                    // 更新 Store 中的数据
                                    store.load();
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '下载全部文件',
                    id: 'downloadAllFile',
                    iconCls: 'icon icon-download',
                    handler: function () {
                        // var store = showGrid.getStore(); // 获取Grid的数据源
                        var store = Ext.getCmp('ECShowGrid').getStore();
                        var allData = store.getData().items; // 获取数据源中的所有数据
                        var concatenatedData = '';

                        if(allData){
                            for(let i = 0;i < allData.length; i++){
                                let rowData = allData[i].data;
                                if(i==0){
                                    concatenatedData = rowData['fileName']
                                }else {
                                    concatenatedData += ";;;qqq" + rowData['fileName'];
                                }
                            }
                        }

                        if (concatenatedData.length != 0) {
                            //     window.location.href = '/Windchill/ptc1/technicalChange/downLoadAllDoc?fileName='+concatenatedData+'&branchId='+branchId;
                            // 创建一个 form 表单
                            var form = document.createElement('form');
                            form.method = 'POST';
                            form.action = '/Windchill/ptc1/pcnInfo/downLoadAllDoc';

                            // 创建一个 input 元素用于存放参数
                            var fileNameInput = document.createElement('input');
                            fileNameInput.type = 'hidden';
                            fileNameInput.name = 'fileName';
                            fileNameInput.value = concatenatedData;
                            form.appendChild(fileNameInput);

                            var branchIdInput = document.createElement('input');
                            branchIdInput.type = 'hidden';
                            branchIdInput.name = 'branchId';
                            branchIdInput.value = changeRequestId;
                            form.appendChild(branchIdInput);
                            // 将表单添加到页面中
                            document.body.appendChild(form);
                            // 提交表单
                            form.submit();

                        } else {
                            alert("当前没有可以下载的文件！")
                        }
                    }
                }
            ]
            // 其他配置项...
        });

        ECShowFileFinal = Ext.create('Ext.Window', {
            id: 'ECShowFile',
            title: '文档操作',
            width: 700,
            //height: 300,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [ECShowGrid],
        });
    }
    return ECShowFileFinal;
}
// =================================上传文档相关============================================================================



/**
 * 删除受影响对象数据
 * @param dbTableName
 * @param ids
 * @param callbackFn
 */
function deleteAffectedObjectsData(ids, callbackFn){
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/deleteAffectedObject',
        method: 'DELETE',
        params: ids,
        async: false,
        headers: {'Content-Type': 'application/json'},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 对Request封装
 * @Param url 请求url
 * @Param method 请求方法'GET' 'POST'
 * @Param async true 请求异步 false 请求步
 * @Param object
 * @Param callback 回调方法
 */
function sendRequest(url, method, headers, async, params, successCallback) {
    Ext.Ajax.request({
        scope: this,
        url: url,
        method: method,
        timeout: 3600000,
        async: async,
        headers: {'Content-Type': headers},
        params: params,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] == 200) {
                if (successCallback) {
                    successCallback(obj.data);
                }
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


/**
 * combobox空白行高度与选项保持一致
 * @param name
 * @returns {Ext.XTemplate}
 */
function getXTemplate(name) {
    return Ext.create('Ext.XTemplate',
        '<tpl for=".">',
        '<div class="x-boundlist-item" style="height:25px">{' + name + '}</div>',
        '</tpl>'
    )
}



/**
 * 保存ECR申请人（提交）表格单个字段的值
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveEcrSubmitSingleField(tableName,id,dataKey,dataValue,callbackFn){
    var mockRec = {
        changeRequestId:changeRequestId,
        tableName:tableName,
        id:id,
        dataKey:dataKey,
        dataValue:dataValue
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/ECRApprovalRecords/updateSingleField',
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}






/**
 * 保存ECR表格单个字段的值
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveEcrSingleField(dataKey,dataValue){
    var mockRec = {
        changeRequestId:changeRequestId,
        dataKey:dataKey,
        dataValue:dataValue
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/ECRApprovalRecords/updateSingleFieldOther',
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                // if (callbackFn) {
                //     callbackFn(response, opts);
                // }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 保存ECR表格单个字段的值
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function setEcrSingleFieldValue(approvalOpinionsKey,approvedByKey,approvalResultsKey,approvalTimeKey,tableName){
    Ext.create('Ext.data.Store', {
        model: '',
        id: 'ECR10SingleFieldStore',
        pruneModifiedRecords: true,
        proxy: new Ext.data.HttpProxy({
            url: '/Windchill/ptc1/ECRApprovalRecords/searchSingleFieldOther?changeRequestId=' + changeRequestId + '&tableName='+tableName,
            method: 'GET',
            reader: {
                type: 'json',
                rootProperty: 'data',
                messageProperty: 'message'
            }
        }),
        autoLoad: true,
        listeners: {
            load: function (store, records, successful, operation, options) {
                if (successful) {
                    if (records.length == 0) {
                        return;
                    }
                    // 获取返回的数据
                    var singleFields = records[0].getData();

                    ecrSingleFieldId = singleFields.id;
                    //审批意见
                    var approvalOpinionsObj = Ext.getCmp(approvalOpinionsKey);
                    if (approvalOpinionsObj) {
                        var ECR10ApprovalOpinionsValue = singleFields.approvalOpinions;
                        if (ECR10ApprovalOpinionsValue != null) {
                            if("materialControlFeedback"===tableName){
                                var timestamp = parseInt(ECR10ApprovalOpinionsValue);
                                var date = new Date(timestamp);
                                var formattedDate = Ext.Date.format(date, 'Y-m-d');
                                approvalOpinionsObj.setValue(formattedDate);
                            }else {
                                approvalOpinionsObj.setValue(ECR10ApprovalOpinionsValue);
                            }
                        }
                    }
                    //审批人
                    var approvedByObj = Ext.getCmp(approvedByKey);
                    if (approvedByObj) {
                        var approvedByValue = singleFields.approvedBy;
                        if (approvedByValue != null) {
                            approvedByObj.setValue(approvedByValue);
                        }
                    }
                    //审批结果
                    var approvalResultsObj = Ext.getCmp(approvalResultsKey);
                    if (approvalResultsObj) {
                        var approvalResultsValue = singleFields.approvalResults;
                        if (approvalResultsValue != null) {
                            approvalResultsObj.setValue(approvalResultsValue);
                        }
                    }
                    //审批时间
                    var approvalTimeObj = Ext.getCmp(approvalTimeKey);
                    if (approvalTimeObj) {
                        var approvalTimeValue = singleFields.approvalTime;
                        if (approvalTimeValue != null) {
                            var dateObj = new Date(approvalTimeValue); // 创建一个 Date 对象
                            var formattedTime = Ext.Date.format(dateObj, 'Y-m-d');
                            approvalTimeObj.setValue(formattedTime);
                        }
                    }
                }
            }
        }
    })
}

/**
 * 更新闭环审批数据
 * @param key
 * @param value
 */
function updateClosedReviewInfo(key, value){
    sendRequest('/Windchill/ptc1/closedLoop/updateClosedReviewInfo',
        "POST", 'application/x-www-form-urlencoded'
        , false, {branchId: branchId, id: closeLoopId, field: key, value: value}, null);
}

/**
 * 导入受影响对象
 */
function importAffectedObjects() {
    uploadAffectedObjectsWindow.show();
}

//导入panel
var uploadFileForm = new Ext.form.Panel({
    layout: 'form',
    id: 'uploadFileForm',
    name: 'uploadFileForm',
    width: 450,
    border: 0,
    tbar: [{
        xtype: 'filefield',
        name: 'userfile',
        id: 'userfile',
        msgTarget: 'side',
        fieldLabel: '上传Excel文件',
        width: 280,
        anchor: '100%',
        buttonText: '选择文件..',
        buttonOnly: false,
        buttonMargin: '5 5 5 5'
    }, {
        xtype: 'button',
        padding: '5 5 5 5',
        id: 'affectedObjects_submit',
        text: '开始导入',
        handler: function () {
            var mainForm = Ext.getCmp('uploadFileForm').getForm();
            var furl = "";  //文件物理地址
            var fname = ""; //文件名称
            furl = Ext.getCmp("userfile").getValue();
            //alert(furl);
            if (furl == "") {
                alert("请先选择文件！");
                return false;
            }
            mainForm.submit({
                scope: this,
                url: '/Windchill/ptc1/newEc/importAffectedObjects?changeRequestId=' + changeRequestId,
                waitMsg: '正在导入......',
                waitTitle: '请等待',
                //method : 'POST',
                success: function (form, action) {
                    var obj = action.result;
                    if (obj.success) {
                        alert("导入成功");
                        window.parent.location.reload();
                    } else {
                        alert(obj.msg);
                    }
                },
                failure: function (form, action) {
                    var obj = action.result;
                    alert(obj.msg);
                }
            });
        }
    }]
});

//导入窗口
var uploadAffectedObjectsWindow = new Ext.create('Ext.Window', {
    title: '导入受影响对象',
    autoHeight: true,
    autoWidth: true,
    closeAction: 'hide',
    y: '10%',
    id: 'uploadAffectedObjectsWindow',
    constrain: true,
    modal: true,
    layout: 'fit',
    items: uploadFileForm
});


/**
 * 编辑变更ECA
 * @param itemId
 * @param dataKey
 * @param dataValue
 * @param callbackFn
 */
function updateChangeECA(itemId, tableType, dataKey, dataValue, callbackFn){
    var mockRec = {
        changeRequestId:changeRequestId,
        id:itemId,
        tableType:tableType,
        key:dataKey,
        value:dataValue
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/ECAExecutionRecord/updateEcaChange',
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });

    /**
     * combobox空白行高度与选项保持一致
     * @param name
     * @returns {Ext.XTemplate}
     */
    function getXTemplate(name) {
        return Ext.create('Ext.XTemplate',
            '<tpl for=".">',
            '<div class="x-boundlist-item" style="height:25px">{' + name + '}</div>',
            '</tpl>'
        )
    }
}


/**
 * 点击同步数据到ECA
 */
function synchronizeAffectedObjects(callbackFn){
    // var mockRec = {
    //     changeRequestId:changeRequestId,
    // };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/ECAExecutionRecord/synchronizeAffectedObjects?changeRequestId='+changeRequestId,
        // params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

function refreshEcaData() {
    var ECA01Grid = Ext.getCmp("ECA01Grid");
    ECA01Grid.getStore().reload();

    var EBOMChangeECAGrid = Ext.getCmp("EBOMChangeECAGrid");
    EBOMChangeECAGrid.getStore().reload();

    var MBOMChangeECAGrid = Ext.getCmp("MBOMChangeECAGrid");
    MBOMChangeECAGrid.getStore().reload();

    var eca04Grid = Ext.getCmp("eca04Grid");
    eca04Grid.getStore().reload();

    var eca05Grid = Ext.getCmp("eca05Grid");
    eca05Grid.getStore().reload();

    var eca06Grid = Ext.getCmp("eca06Grid");
    eca06Grid.getStore().reload();

    var eca07Grid = Ext.getCmp("eca07Grid");
    eca07Grid.getStore().reload();

    var eca08Grid = Ext.getCmp("eca08Grid");
    eca08Grid.getStore().reload();

    var eca09Grid = Ext.getCmp("eca09Grid");
    eca09Grid.getStore().reload();

    var eca10Grid = Ext.getCmp("eca10Grid");
    eca10Grid.getStore().reload();

    var eca11Grid = Ext.getCmp("eca11Grid");
    eca11Grid.getStore().reload();
}

//设置按钮高亮显示
function setBtnCls(showView){
    if(showView == 'view0'){
        Ext.get('showView0').el.dom.style.backgroundColor = '#ffc'; // 设置背景颜色
        Ext.get('showView0').blur();
        Ext.get('showView1').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView2').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView3').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView4').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
    }else if(showView == 'view1'){
        Ext.get('showView0').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView1').el.dom.style.backgroundColor = '#ffc'; // 设置背景颜色
        Ext.get('showView1').blur();
        Ext.get('showView2').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView3').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView4').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
    }
    else if(showView == 'view2'){
        Ext.get('showView0').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView1').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView2').el.dom.style.backgroundColor = '#ffc'; // 设置背景颜色
        Ext.get('showView2').blur();
        Ext.get('showView3').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView4').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
    }else if(showView == 'view3'){
        Ext.get('showView0').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView1').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView2').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView3').el.dom.style.backgroundColor = '#ffc'; // 设置背景颜色
        Ext.get('showView3').blur();
        Ext.get('showView4').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
    }else if(showView == 'view4'){
        Ext.get('showView0').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView1').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView2').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView3').el.dom.style.backgroundColor = '#d0d0d0'; // 设置背景颜色
        Ext.get('showView4').el.dom.style.backgroundColor = '#ffc'; // 设置背景颜色
        Ext.get('showView4').blur();
    }
}

/**
 * 批量更新潜在受影响对象
 * @param itemId
 * @param dataKey
 * @param dataValue
 * @param callbackFn
 */
function batchUpdatePotentialAffectedData(itemId,dataKey,dataValue,callbackFn){
    var mockRec = {
        changeRequestId:changeRequestId,
        ids:itemId,
        key:dataKey,
        value:dataValue
    };
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在更新数据，请稍候......',
        target: Ext.getCmp('ctPotentialImpactTableGrid'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/batchUpdatePotentialAffectedObject',
        params: {updateRecord:Ext.encode(mockRec)},
        timeout: 3600000,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
            loadMarsk.hide();
        }
    });
}

/**
 * 批量更新受影响对象
 * @param itemId
 * @param dataKey
 * @param dataValue
 * @param callbackFn
 */
function batchUpdateAffectedObjectsData(itemId,dataKey,dataValue,callbackFn){
    var mockRec = {
        changeRequestId:changeRequestId,
        ids:itemId,
        key:dataKey,
        value:dataValue
    };
    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在更新数据，请稍候......',
        target: Ext.getCmp('ctAffectedObjectsTableGrid'),
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    Ext.Ajax.request({
        url: '/Windchill/ptc1/newEc/batchUpdateAffectedObject',
        params: {updateRecord:Ext.encode(mockRec)},
        timeout: 3600000,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
            loadMarsk.hide();
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
            loadMarsk.hide();
        }
    });
}