<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.sampleConfirmation.config.CtSampleConfirmationProperties" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="ext.plm.newec.helper.CtAffectedObjectHelper" %>
<%@ page import="ext.plm.newec.config.CtClosedLoopProperties" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String workItemOid = request.getParameter("oid");
        long branchId = 1L;
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(workItemOid).getObject();
        String currentActKey = "";
        String changeRequestId = "";
        boolean taskCompleted = false; //任务是否已完成
        long timestamp = System.currentTimeMillis();
        wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
        String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=VR:wt.part.WTPart:";
        if(obj instanceof WorkItem){
            WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            String actName = activity.getName();
            currentActKey = CtClosedLoopProperties.getActivityKey(actName);
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
            WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
            branchId = doc.getBranchIdentifier();
            changeRequestId = CtAffectedObjectHelper.getChangeRequestId(branchId);
        }else if(obj instanceof WTDocument){
            WTDocument doc = (WTDocument) obj;
            branchId = doc.getBranchIdentifier();
            changeRequestId = CtAffectedObjectHelper.getChangeRequestId(branchId);
        }
    %>
    <script type="text/javascript">

        var isAdmin = false;
        <%if(true){%>
        isAdmin = true;
        <%}%>

        var workItemOid = "<%=workItemOid%>";

        //更改请求vid
        var changeRequestId = "<%=changeRequestId%>";

        var closeLoopId = '';

        var branchId = '<%=branchId%>';

        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";

        //当前的任务完成状态
        var taskCompleted = false;
        <%if(taskCompleted){%>
        taskCompleted = true;
        <%}%>

        var readOnlyPage = false;

    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js/ctNewecUploadPanel.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctEcFunctions.js?_dc=<%="timestamp"%>"></script>
    <script type="text/javascript" src="js/ctEcrApprovalRecordsTable.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctEcaExecutionRecordTable.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctEccl.js?_dc=<%="timestamp"%>"></script>
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            width: "100%",
            height: '100%',
            items: [ {
                region: 'center',
                // items:[{
                //     xtype:'panel',
                //     scrollable: true,
                //     border:false,
                items:[{
                    xtype:'tabpanel',
                    id: 'changeTabPanel',
                    activeTab: 0,
                    listeners: {
                        tabchange: function(tabPanel, newCard, oldCard, eOpts) {
                            // 当 Tab 变更时触发
                            ecrStore.load();
                        }
                    },
                    items:[
                        // {
                        //     title: '<font style="font-size:12px">潜在受影响对象</font>',
                        //     xtype: 'ctPotentialImpactTablePanel'
                        // }
                        // ,{
                        //     scrollable: true,
                        //     title: '<font style="font-size:12px">受影响对象</font>',
                        //     xtype:'ctAffectedObjectsTablePanel'
                        // }
                        //,
                        {
                            scrollable: true,
                            title: '<font style="font-size:12px">ECR审批记录</font>',
                            xtype:'ctEcrApprovalRecordsTablePanel'
                        }
                        ,{
                            scrollable: true,
                            title: '<font style="font-size:12px">ECA执行记录</font>',
                            xtype:'ctExecutionRecordTablePanel'
                        }
                        ,{
                            scrollable: true,
                            title: '<font style="font-size:12px">变更闭环</font>',
                            xtype:'EcclPanel'
                        }
                    ]//~End of tabpanel items
                }]
                //}]//~End of center region items
            }]//~End of viewPort items
        });
        var tabPanel = Ext.getCmp('changeTabPanel');
        tabPanel.setActiveTab(2);
    });
</script>
</body>
</html>