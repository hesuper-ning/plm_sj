<%@ page import="ext.plm.part.config.CtPartConstant" %>
<%@ page import="wt.workflow.engine.WfActivity" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@ page import="ext.plm.part.replacePart.config.CtReplacePartProperties" %>
<%@ page import="wt.change2.WTChangeRequest2" %>
<%@ page import="wt.change2.WTChangeOrder2" %>
<%@ page import="wt.fc.QueryResult" %>
<%@ page import="wt.change2.WTChangeActivity2" %>
<%@ page import="wt.change2.ChangeHelper2" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="ext.plm.ec.CtEcLogic" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="ext.plm.newec.config.CtNewEcProperties" %>
<%@ page import="wt.session.SessionHelper" %>
<%@ page import="wt.org.WTUser" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        boolean isAdmin = CtUserUtil.isInGroup(SessionHelper.getPrincipal(),"Administrators");
        //任务完成标识
        boolean taskCompleted = false;
        String changeRequestOId = request.getParameter("oid");
        String changeRequestId = ""; //VR:wt.change2.WTChangeRequest2:49186110
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(changeRequestOId).getObject();
        String activityName = "";
        String currentActKey = "";
        WTChangeRequest2 changeRequest = null;
        WTUser currentUser = (WTUser) CtUserUtil.getCurrentUser();
        try {
            SessionHelper.manager.setAdministrator();
            if (obj instanceof WorkItem) {
                WorkItem workItem = (WorkItem) obj;
                if (workItem.isComplete()) taskCompleted = true;
                WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
                activityName = activity.getName();
                currentActKey = CtNewEcProperties.getActivityKey(activityName);
                Persistable pbo = workItem.getPrimaryBusinessObject().getObject();
                if (pbo instanceof WTChangeActivity2) {
                    WTChangeActivity2 eca = (WTChangeActivity2) pbo;
                    QueryResult qr = ChangeHelper2.service.getChangeOrder(eca);
                    if(qr.hasMoreElements()){
                        WTChangeOrder2 changeOrder = (WTChangeOrder2) qr.nextElement();
                        QueryResult qr2 = ChangeHelper2.service.getChangeRequest(changeOrder);
                        if(qr2.hasMoreElements()){
                            changeRequest = (WTChangeRequest2) qr2.nextElement();
                            changeRequestId = rf.getReferenceString(changeRequest);
                        }
                    }
                } else if (pbo instanceof WTChangeRequest2) {
                    WTChangeRequest2 ecr = (WTChangeRequest2) pbo;
                    changeRequestId = rf.getReferenceString(ecr);
                } else if(pbo instanceof WTChangeOrder2){
                    WTChangeOrder2 changeOrder = (WTChangeOrder2)obj;
                    QueryResult qr =ChangeHelper2.service.getChangeRequest(changeOrder);
                    if(qr.hasMoreElements()){
                        changeRequest = (WTChangeRequest2)qr.nextElement();
                        changeRequestId = rf.getReferenceString(changeRequest);
                    }
                }
                if(workItem.isComplete()) {
                    taskCompleted = true;
                }
            }else if(obj instanceof wt.change2.WTChangeRequest2) {
                activityName = "ECR只读";
                changeRequest = (WTChangeRequest2)obj;
                changeRequestId = rf.getReferenceString(changeRequest);
            }else if(obj instanceof WTChangeOrder2){
                WTChangeOrder2 changeOrder = (WTChangeOrder2)obj;
                QueryResult qr =ChangeHelper2.service.getChangeRequest(changeOrder);
                if(qr.hasMoreElements()){
                    changeRequest = (WTChangeRequest2)qr.nextElement();
                    changeRequestId = rf.getReferenceString(changeRequest);
                }
            }else if(obj instanceof WTChangeActivity2){
                activityName = "ECA只读";
                WTChangeActivity2 changeActivity2 = (WTChangeActivity2)obj;
                QueryResult qr = ChangeHelper2.service.getChangeOrder(changeActivity2);
                if(qr.hasMoreElements()){
                    WTChangeOrder2 changeOrder = (WTChangeOrder2) qr.nextElement();
                    QueryResult qr2 = ChangeHelper2.service.getChangeRequest(changeOrder);
                    if(qr2.hasMoreElements()){
                        changeRequest = (WTChangeRequest2) qr2.nextElement();
                        changeRequestId = rf.getReferenceString(changeRequest);
                    }
                }
            }
        }finally {
             SessionHelper.manager.setPrincipal(currentUser.getName());
        }


        //String workItemOid = request.getParameter("oid");
        //wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        //WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
        //WfActivity activity = (WfActivity) workItem.getSource().getObject();
        //String activityName = activity.getName();
        //String currentActKey = CtReplacePartProperties.getActivityKey(activityName);
        //WTDocument document = (WTDocument) workItem.getPrimaryBusinessObject().getObject();
        //String docNumber = document.getNumber();
        //String currentActKey = "ReadOnly";

    %>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js/ctEcFunctions.js?_dc=<%="timestamp"%>"></script>
    <script type="text/javascript" src="js/ctPotentialImpactTable.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctAffectedObjectsTable.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctEcrApprovalRecordsTable.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctEcaExecutionRecordTable.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctNewecUploadPanel.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctEccl.js?_dc=<%System.currentTimeMillis();%>"></script>
    <style>
        .custom-title {
            font-size: 12px;
        }
    </style>
    <style type="text/css">
        /*表头换号居中*/
        .x-column-header {  text-align: center; }
        .x-column-header-text-inner {
            white-space: normal;
            line-height: 15px;
            padding-top: 3px !important;
            padding-bottom: 3px !important;
        }
    </style>


</head>

<body>
<script>
    <%--var submit   = <%=submit %>;--%>
    <%--var resultConfirmation  = <%=resultConfirmation%>;--%>
    //当前审批结点key
    var currentActKey = "<%=currentActKey%>";
    //活动名称
    var activityName = "<%=activityName%>";
    //用于保存ECR单个字段的id
    var ecrSingleFieldId = "";
    //用于复制粘贴保存复制列的id
    var copyId = "";

    //上传文件列的id
    var fileColumnId = '';
    //上传文件的列名
    var fileColumnName = '';
    //长传文件的表格
    var uploadTableName = '';
    //设置grid名称用于上传文件后刷新数据
    var gridName = '';

    var branchId = '';

    var closeLoopId = '';

    //是否允许删除文档
    var isDeletionAllowed = false;


    //更改请求vid
    var changeRequestId = "<%=changeRequestId%>";
    //判断当前任务是否已经完成
    var taskCompleted = false;
    <%if(taskCompleted){%>
    taskCompleted = true;
    <%}%>

    var readOnlyPage = false;

    var showView = 'view0';
    var pdt = '';
    var viewName = '';
    var type = '';
    var subType = '';
    var changeObject = '';
    var effectObject = '';
    var objectNumber = '';

    var partNumber = '';

    var ecrStore;

    var isAdmin = false;
    <%if(isAdmin){%>
    isAdmin = true;
    <%}%>

    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.util.CSS.createStyleSheet(".highlight-btn { background-color: #ffc; color: #000; border-color: #000; }", "highlight-btn-style");
        Ext.util.CSS.createStyleSheet(".normal-ec-btn { background-color: #d0d0d0; color: #000; border-color: #000; }", "normal-ec-btn-style");

        Ext.create('Ext.container.Viewport', {
            id: 'changeViewport',
            layout: 'border',
            width: "100%",
            height: '100%',
            items: [ {
                region: 'center',
                // items:[{
                //     xtype:'panel',
                //     scrollable: true,
                //     border:false,
                    items:[{
                        xtype:'tabpanel',
                        id: 'changeTabPanel',
                        activeTab: 0,
                        listeners: {
                            tabchange: function(tabPanel, newCard, oldCard, eOpts) {
                                // 当 Tab 变更时触发
                                if(ecrStore) {
                                    ecrStore.load();
                                }
                            }
                        },
                        items:[
                            {
                                scrollable: true,
                                title: '<font style="font-size:12px">潜在受影响对象</font>',
                                xtype: 'ctPotentialImpactTablePanel'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">受影响对象</font>',
                                xtype:'ctAffectedObjectsTablePanel'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">ECR审批记录</font>',
                                xtype:'ctEcrApprovalRecordsTablePanel'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">ECA执行记录</font>',
                                xtype:'ctExecutionRecordTablePanel'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">变更闭环</font>',
                                xtype:'EcclPanel'
                            }
                        ]//~End of tabpanel items
                    }]
                //}]//~End of center region items
            }]//~End of viewPort items
            ,listeners:{
                'afterrender': function() {
                    var tabPanel = Ext.getCmp('changeTabPanel');
                    if(tabPanel && currentActKey){
                        if('head_node' == currentActKey
                            || 'submit_change_request' == currentActKey
                            || 'formulate_MBOM_programme' == currentActKey || 'design_change_initiation2' == currentActKey
                            ||'design_change_initiation3' == currentActKey || 'design_change_initiation4' == currentActKey
                            ||'MBOM辅料快速更改任务ECA_产品数据管理工程师' == activityName||'MBOM辅料快速更改任务ECA_CCB意见汇总人(确认处理方式)' == activityName
                            ||'图纸文档工艺快速更改任务ECA-部门经理审核' == activityName||'图纸文档工艺快速更改任务ECA-产品数据管理工程师审核' == activityName
                            ||'快速变更5_部门经理初审'  == activityName||'图纸文档工艺快速更改任务ECA-ECA发起人' == activityName
                        ){
                            //潜在受影响对象
                            tabPanel.setActiveTab(0);
                        }
                        else if('pcn_upload_node' == currentActKey || 'change_process_procurement_EMR' == currentActKey|| 'mcRep_node' == currentActKey || 'pcRep_node' == currentActKey
                            || 'pcegRep_node' == currentActKey || 'pdt_node' == currentActKey
                            || 'manager_of_material_control_department_auditing' == currentActKey || 'purchasing_execute_manager_auditing' == currentActKey|| 'purchasing_manager_auditing' == currentActKey
                            || 'product_engineering_manager_information_gathering' == currentActKey|| 'general_change_small_batch_verification_confirmation' == currentActKey || 'pcn_upload' == currentActKey
                            || 'department_manager_confirm_info' == currentActKey || 'design_change_initiation' == currentActKey|| 'material_control_department_manager_review' == currentActKey
                            || 'purchasing_department_manager_review' == currentActKey|| 'department_manager_review' == currentActKey || 'department_manager_initial_review' == currentActKey
                            || 'QCDRP_ECA_procurement_SMR' == currentActKey || 'QCDRP_ECA_procurement_ER' == currentActKey || 'procurement_sourcing_manager_reviewed' == currentActKey
                            || 'material_control_department_manager_review3' == currentActKey || 'review_by_the_procurement_execution_manager' == currentActKey|| 'upload_pcn' == currentActKey
                            || 'quick_change3_procurement_engineer_review' == currentActKey || 'department_manager_review3' == currentActKey|| 'BOM_quick_change_ECA_planning_SR' == currentActKey
                            || 'department_manager_review4' == currentActKey|| 'quick_change4_procurement_sourcing_manager_review' == currentActKey || 'material_control_department_manager_review4' == currentActKey
                            || 'review_by_the_procurement_execution_manager4' == currentActKey || 'quick_change4_procurement_engineer_eview' == currentActKey
                            || 'upload_pcn4'==currentActKey || 'summary_of_ccb_review_comments'==currentActKey
                            || 'design_change_initiation5'==currentActKey || 'product_data_management_supervisor_review5'==currentActKey
                            || 'change_process_quality_control_MRSBVC'==currentActKey
                        ){
                            //受影响对象
                            tabPanel.setActiveTab(1);
                        }else if('preliminary_review_by_department_manager' == currentActKey || 'ebomCharge_node' == currentActKey
                            || 'mbomCharge_node' == currentActKey || 'consistencyRisk_node' == currentActKey
                            || 'dateManageMajor_node'==currentActKey || 'qualityRep_node'==currentActKey
                            || 'hwTechRep_node'==currentActKey || 'struTechRep_node'==currentActKey
                            || 'tm_node'==currentActKey || 'swTechRep_node'==currentActKey
                            || 'pm_node'==currentActKey || 'ccb_node'==currentActKey
                            || 'product_data_engineer_confirm_info'==currentActKey || 'approved_by_the_certification_technical_leader'==currentActKey
                            || 'quick_change1_certification_TLR'==currentActKey || 'product_data_management_supervisor_review'==currentActKey
                            || 'mbom_change_manager'==currentActKey || 'product_data_management_supervisor_review3'==currentActKey
                            || 'product_data_management_supervisor_review4'==currentActKey || '变更流程_开发代表审核'==activityName
                            || '通用变更_产品数据管理主管汇总意见判断是否需要驳回'==activityName|| '通用变更ECA_部门经理审核(EBOM)'==activityName|| '通用变更ECA_部门经理审核(MBOM)'==activityName
                            || '快速变更1_器件工程师审核'==activityName|| '快速变更1_产品数据管理工程师审核'==activityName
                        ){
                            //ECR
                            tabPanel.setActiveTab(2);
                        }else{
                            //ECA
                            tabPanel.setActiveTab(3);
                        }
                    }else if ('ECR只读'==activityName){
                        //ECR
                        tabPanel.setActiveTab(2);
                    }else if ('ECA只读'==activityName){
                        //ECA
                        tabPanel.setActiveTab(3);
                    }
                }
            }
        });
    });
</script>
</body>
</html>