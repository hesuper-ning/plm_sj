<%--sampleApply研发制板--%>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="ext.plm.oaFlow.sampleApply.config.CtSampleApplyProperties" %>
<%@ page import="ext.plm.util.IBAUtil" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
<%
    String oid = request.getParameter("oid");
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WorkItem workItem = (WorkItem)rf.getReference(oid).getObject();
    WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
    String actName = activity.getName();
    String currentActKey = CtSampleApplyProperties.getActivityKey(actName);

   // String currentActKey = CtCertfProperties.getActivityNodeName(actName);
    WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
    long docBranchId = doc.getBranchIdentifier();
//打印页面信息，有用
    System.out.println(">>>>>>>>>ctSampleApply.jsp actName="+actName+">>>>currentActKey="
            +currentActKey+">>>>>docBranchId="+docBranchId+">>>oid="+oid);

    boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workItem,
            CtSampleApplyProperties.getProperty("sample_qualityMetric_allowEdit_roles"));
    //CtQmsProperties.getProperty("qms_qualityMetric_allowEdit_en_roles"));
    //System.out.println(">>>CtSampleApplyProperties.getProperty:"+ CtSampleApplyProperties.getProperty("sample_qualityMetric_allowEdit_roles"));
    //System.out.println("allowEdit>>>>>>>>>>"+allowEdit);
    IBAUtil ibaUtil = new IBAUtil(doc);
    String pcbDocNumber = ibaUtil.getIBAValue("ct_pcbDocNumber");
    if (pcbDocNumber==null||"".equals(pcbDocNumber)){
        pcbDocNumber="NA";
    }

    boolean taskCompleted = false; //任务是否已完成
    if(workItem.isComplete()) {
        taskCompleted = true;
    }
%>

<script type="text/javascript">




</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>

    <script type="text/javascript" src="../commonFunction/uploadFunction/ctShowFilePanel.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../commonFunction/uploadFunction/ctUploadFilePanel.js?_dc=<%System.currentTimeMillis();%>"></script>

    <script type="text/javascript" src="js/ctSampleApply.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctSampleApplyFunctions.js?_dc=<%System.currentTimeMillis();%>"></script>

    <style type="text/css">
        /*表头换号居中*/
        .x-column-header {  text-align: center; }
        .x-column-header-text-inner {
            white-space: normal;
            line-height: 15px;
            padding-top: 3px !important;
            padding-bottom: 3px !important;
        }
    </style>

</head>

<body>
<script>

    var allowEdit = false;
    <%if(allowEdit){ %>
    allowEdit = true;
    <%}%>

    var pcbDocNumber = "<%=pcbDocNumber%>";

    //vid
var docBranchId = "<%=docBranchId%>";

var currentActKey = "<%=currentActKey%>";

var currentActKeyOne = "<%=1%>";

var oid = "<%=oid%>";

    var fileColumnId = '';
    var fileColumnName = '';
    var uploadTableName = '';
    var gridName = '';
    var type = 'doc';
    var branchId = "<%=docBranchId%>";
    var allowMultiple = false;



Ext.onReady(function() {
	 Ext.QuickTips.init();

	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'sampleApply'
		    }]
		});
});
</script>

</body>
</html>