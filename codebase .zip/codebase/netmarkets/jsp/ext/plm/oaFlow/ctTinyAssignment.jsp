<%@page import="ext.plm.certification.config.CtCertfProperties"%>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.qms.config.CtQmsProperties" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="ext.plm.oaFlow.tinyAssignment.config.CtTAProperties" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workItem = (WorkItem)rf.getReference(oid).getObject();
        WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
        String actName = activity.getName();//工作流程节点在名字
        //System.out.println("actName"+actName);

        String currentActKey = CtTAProperties.getActivityNodeName(actName);
        WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);//获取文档
        String containerOid = ext.plm.util.CtWTObjectUtil.getOid(doc.getContainer());//获得容器的id

        //System.out.println(">>>>>>containerOid:"+containerOid);
        long branchId = doc.getBranchIdentifier();//获取文档id

        //编辑权限判断
        boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workItem,
                CtTAProperties.getProperty("tinyAssignment_tinyAssignment_allowEdit_roles"));
        //CtQmsProperties.getProperty("qms_qualityMetric_allowEdit_en_roles"));


//打印页面信息，有用
        System.out.println(">>>>>>>>>ctTinyAssignment.jsp actName="+actName+">>>>currentActKey="+currentActKey
                +">>>>>branchId="+branchId+">>>workItemOid="+oid+">>>>allowEdit："+allowEdit);

        boolean taskCompleted = false; //任务是否已完成
        if(workItem.isComplete()) {
            taskCompleted = true;
        }
    %>

    <script type="text/javascript">

    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js/ctTinyAssignmentFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctTinyAssignment.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <style>
        .tooltip {
            position: absolute;
            background-color: #e2eff9;
            padding: 5px 10px;
            border-radius: 5px;
            z-index: 1000;
            display: none;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /* 水平偏移，垂直偏移，模糊半径，颜色 */
        }
        .colorGrey {
            color: #cfcfcf
        }
    </style>

</head>

<body>
<script>

    //编辑权限
    var allowEdit = false;
    <%if(allowEdit){ %>
    allowEdit = true;
    <%}%>


    var containerOid = "<%=containerOid%>";
    //认证请求vid
    var branchId = "<%=branchId%>";
    //当前结点key
    var currentActKey = "<%=currentActKey%>";
    //当前的任务完成状态
    var taskCompleted = false;
    <%if(taskCompleted){ %>
    taskCompleted = true;
    <%}%>
    //oid
    var oid = "<%=oid%>";

    var containerId = "<%=oid%>";

    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'assignment'
            }]
        });
    });

</script>

</body>
</html>