<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="ext.plm.oaFlow.softwareBurning.config.CtSoftwareBurningProperties,wt.doc.WTDocument,wt.fc.Persistable,wt.workflow.work.WfAssignedActivity"%>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<html>
<head>
<%
    String oid = request.getParameter("oid");
    String workItemOid = oid;
    boolean taskCompleted = false;
    boolean whetherEngineer = false;
    boolean whetherTester = false;
    boolean whetherPDMEngineerReview = false;
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WorkItem workItem = (WorkItem)rf.getReference(oid).getObject();
    if(workItem.isComplete()){
        taskCompleted = true;
    }
    WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
    String actName = activity.getName();
    String actKey = CtSoftwareBurningProperties.getActivityKey(actName);
    String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
    String accountNumber = ext.plm.util.CtUserUtil.getCurrentUserAccountName();
    boolean isInAdminGroup = CtUserUtil.isInGroup(CtUserUtil.getCurrentUser(), "Administrators");
    if(isInAdminGroup){
        accountNumber = workItem.getOwnership().getOwner().getName();
    }
    Persistable pbo = workItem.getPrimaryBusinessObject().getObject();
    WTDocument doc = (WTDocument) pbo;
    String docNumber = doc.getNumber();
    long branchId = doc.getBranchIdentifier();
    if (actName.contains("-工程师审核")) {
        whetherEngineer = true;
    } else if (actName.contains("测试部经理审核")) {
        whetherTester = true;
    } else if (actName.contains("产品数据管理工程师审核") || actName.contains("产品数据管理工程师竞争接收")) {
        whetherPDMEngineerReview = true;
    }
    System.out.println("ctSoftwareBurning.jsp>>>>>>>>>"+"oid>>>>>>>>"+oid+">>>>>>>>>>>actName>>>>>>"+actName+">>>>>>>>>>actKey>>>>>>"+actKey+"===="+whetherEngineer);
    //编辑权限判断
    boolean allowEdit = ext.plm.util.CtWorkFlowUtil.hasEditAccess(workItem,
           CtSoftwareBurningProperties.getProperty("SoftwareBurning_allowEdit_roles"));
%>

<script type="text/javascript">
var workItemOid = "<%=workItemOid%>";
//文档编码
var docNumber = "<%=docNumber%>";
//流程当前节点名称
var actName = "<%=actName%>";
//当前用户全名
var userName ="<%=userName%>";
//文档vid
var docBranchId ="<%=branchId%>";

//节点名称
var actKey = "<%=actKey%>";

//编辑权限
var allowEdit = false;
<%if(allowEdit){ %>
	allowEdit = true;
<%}%>

//活动是否完成
var taskCompleted = false;
<%if(taskCompleted){ %>
taskCompleted = true;
<%}%>

var whetherEngineer = false;
<%if(whetherEngineer){ %>
whetherEngineer = true;
<%}%>

var whetherTester = <%=whetherTester%>;

var whetherPDMEngineerReview = <%=whetherPDMEngineerReview%>;

var accountNumber = '<%=accountNumber%>';


</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctSoftwareBurning.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>

//==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'SoftwareBurningPanel'
		    }]
		});
});

</script>

</body>
</html>