
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="java.util.*,wt.workflow.work.*,wt.fc.Persistable,wt.doc.WTDocument"%>
<%@ page import="ext.plm.certification.config.CtCertfProperties" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="ext.plm.oaFlow.tinyAssignment.config.CtTAProperties" %>
<%@ page import="ext.plm.oaFlow.materialRequisition.config.CtMRProperties" %>
<html>
<head>

    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>>oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WTDocument doc = (WTDocument) rf.getReference(oid).getObject();
        String containerOid = ext.plm.util.CtWTObjectUtil.getOid(doc.getContainer());
        long branchId = doc.getBranchIdentifier();
        boolean taskCompleted = true;
    %>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>

    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js"></script>
    <script type="text/javascript" src="js/ctMaterialRequisition.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctMaterialRequisitionFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
    //编辑权限
    var allowEdit = false;

    var procurementAllowEdit = false;
    var containerOid = "<%=containerOid%>";
    //认证请求vid
    var branchId = "<%=branchId%>";
    //当前的任务完成状态
    var taskCompleted = "<%=taskCompleted%>";
    //oid
    var oid = "<%=oid%>";
    //==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'MaterialRequisitionPanel'
            }]
        });
    });

</script>

</body>
</html>