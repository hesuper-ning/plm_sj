//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//

var submit_node = 'submit_node'
var resubmit_node = 'resubmit_node'
var PDTManager_node = 'PDTManager_node'
var trialFollow_node = 'trialFollow_node'
var qualityFollow_node = 'qualityFollow_node'
var procurementFollow_node = 'procurementFollow_node'
var materialFollow_node = 'materialFollow_node'
var followPlan_node = 'followPlan_node'
var isCarryOut_node = 'isCarryOut_node'
var trialProblem_node = 'trialProblem_node'
var qualityProblem_node = 'qualityProblem_node'
var materialProblem_node = 'materialProblem_node'
var verdictAndProblem_node = 'verdictAndProblem_node'
var managerCheck_node = 'managerCheck_node'
var Check_node='Check_node'

//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ght_dataLoadedFlag = false;

/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */
function disableNode(formkey) {
    if (taskCompleted == 'true') {
        return true;
    } else {
        if (formkey == currentActKey) {
            return false;
        } else {
            return true;
        }
    }
};

//自动保存字段
function autoSaveAtt(attKey, attValue) {
    var data = {
        branchId: branchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKey, //全局变量，当前活动key
        oid: oid
    };
    Ext.Ajax.request({
        scope: this,
        async : false, // FALSE 同步访问，防止后台Master表产生重复数据
        url: '/Windchill/ptc1/trialApply/saveForm',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);

            if (obj.message == "success") {

            } else {
                Ext.Msg.alert("实时保存数据失败", obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName, itemId, dataKey, dataValue, callbackFn) {


    if (dataKey=='endDate'&&dataValue!=null){
        if(dataValue instanceof Date){
            console.log("=====dataValue"+ Ext.Date.format(dataValue,"Y-m-d"));
        }
        dataValue=Ext.Date.format(dataValue,"Y-m-d");
        // dataValue=Ext.util.Format.date(new Date(dataValue,'Y-m-d'));
    }
    var mockRec = {
        oid: oid,
        dbTableName: dbTableName,
        itemId: itemId,
        dataKey: dataKey,
        dataValue: dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/trialApply/updateItemInfo',
        params: {updateRecord: Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == "success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                // alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(tableName, callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/trialApply/insertItemInfo?oid=' + oid,
        params: {
            branchId: branchId,
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == "success") {
                callbackFn();
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

/**
 *    根据部门为grid创建空列
 * @param department 部门
 * @param callbackFn 回调函数
 */
function insertTrialItem(department, callbackFn) {
    Ext.Ajax.request({
        url: '/Windchill/ptc1/trialApply/insertTrialItem?oid=' + oid,
        params: {
            branchId: branchId,
            department: department
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == "success") {
                callbackFn();
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//删除grid信息
function deleteData(tableName, ids, callback) {
    // var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"数据正在处理中，请稍后..."});
    // myMask.show();

    var data = {
        oid: oid,
        tableName: tableName,
        ids: ids
    }

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/fixture/deleteItemData',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message != "success") {
                Ext.Msg.alert("数据删除失败", obj.message);
                // myMask.hide();
            } else {
                // myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

function getPartInfo(partNumber) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/trialApply/getPartInfo',
        params: {
            partNumber: partNumber,
            branchId:branchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);


            if (obj.message == "success") {
                Ext.getCmp("head_productName").setValue(obj.data['name'])
                Ext.getCmp("head_productType").setValue(obj.data['type'])
            } else {
                Ext.Msg.alert("获取物料信息失败", obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}


// 上传按钮 begin
//传入公共的参数，返回上传附件的代码
function uploadFilefield(fileName, text, node, tetx_name) {
    if (text == null || text == "") {
        text = "浏览...";
    }

    var inform = {
        xtype: 'filefield',
        buttonOnly: true,
        disabled: disableNode(node),
        id: fileName,
        name: fileName,
        width:70,
        hideLabel: true,
        // buttonText: '<span style="width:145px;  labelWidth: 100;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + text + '</span>',
        buttonText: '<span style="width:60px; ">'+ text + '</span>',
        allowBlank: false,
        scope: this,
        listeners: {
            'change': function (fb, newValue, oldValue, opts) {
                if (!newValue) {
                    return;
                }
                var file = document.querySelector('[id=' + fileName + '-button-fileInputEl]');
                var formData = new FormData();
                formData.append(fileName + '-button-fileInputEl', file.files[0]);
                fb.reset();//清空表单的值
                var myMask = new Ext.LoadMask({
                    msg: '正在上传，请稍候......',
                    target: this.findParentByType('panel')
                });
                myMask.show();
                $.ajax({
                    url: '/Windchill/ptc1/trialApply/uploadFiles?branchId=' + branchId + '&tetx_name=' + tetx_name + "&node=" + node,
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function (res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if (!success) {
                        alert(msg);
                    } else {
                        var fileName = obj['fileName'];
                        var value = Ext.getCmp(tetx_name).getValue();
                        if (value != null && value != '') {
                            fileName = value + "&nbsp;|&nbsp;" + fileName;
                        }
                        Ext.getCmp(tetx_name).setValue(fileName);
                        autoSaveAtt(tetx_name, fileName);
                    }
                }).fail(function (res) {
                    myMask.hide();
                    alert('上传失败！');
                });
            }
        }
    };
    return inform;
}

//删除附件
function deleteFilefield(branchId, fileName, tetx_name, node) {
    if (disableNode(node)) {
        alert("您没有权限删除该附件！");
        return;
    }
    // var myMask = new Ext.LoadMask({
    // 	msg: '正在删除，请稍候......',
    // 	target:Ext.getCmp('headPanel')
    // });
    // myMask.show();
    Ext.Ajax.request({
        scope: this,
        async: false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url: '/Windchill/ptc1/trialApply/deleteFiles',
        params: {
            branchId: branchId, fileName: fileName
        },
        success: function (response, opts) {
            // myMask.hide();
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if (!success) {
                alert(msg);
            } else {
                var value = Ext.getCmp(tetx_name).getValue();
                var arr = new Array(); //定义一数组
                arr = value.split("|"); //字符分割
                for (i = 0; i < arr.length; i++) {
                    var index = arr[i].indexOf(fileName);
                    if (index > -1) {
                        arr.splice(i, 1);// 删除
                    }
                }
                var result = arr.join("&nbsp;|&nbsp;");
                Ext.getCmp(tetx_name).setValue(result);
                autoSaveAtt(tetx_name, result);
            }
        },
        failure: function (response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });
}

//检查编号是否正确
function getDocLink(number,key) {
    var url = "";
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/trialApply/getDocLink',
        method: "GET",
        params: {
            number:number,
            key:key,
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.success==undefined){
                alert(obj.msg);
            }else {
                url = obj.url;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return url;
}


//检查编号是否正确
function getEcLink(number) {
    var url = "";
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/trialApply/getEcLink',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
            }else {
                console.log(obj["ChangeReason"]+"==="+obj["ChangeDescribe"])
                Ext.getCmp("ChangeNumberLink").setValue(obj["url"])
                Ext.getCmp("ChangeReason").setValue(obj["ChangeReason"])
                autoSaveAtt('ChangeReason', obj["ChangeReason"]);
                Ext.getCmp("ChangeDescribe").setValue(obj["ChangeDescribe"])
                autoSaveAtt('ChangeDescribe', obj["ChangeDescribe"]);
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return url;
}

//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}

//删除grid信息
function deleteData2(tableName, ids, callback) {
    // var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"数据正在处理中，请稍后..."});
    // myMask.show();

    var data = {
        oid: oid,
        tableName: tableName,
        ids: ids
    }

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/trialApply/deleteZMaterialDocItemData',
        method: "POST",
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message != "success") {
                Ext.Msg.alert("数据删除失败", obj.message);
                // myMask.hide();
            } else {
                // myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData2(tableName, callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/trialApply/insertZMaterialDocItemInfo?oid=' + oid,
        params: {
            branchId: branchId,
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == "success") {
                callbackFn();
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//自动保存字段
function autoSaveItemData2(itemId, branchId, itemnumber, callbackFn) {
    var data = {
        branchId: branchId,
        number: itemnumber, //字段key
        oid: itemId
    };
    Ext.Ajax.request({
        scope: this,
        async : false, // FALSE 同步访问，防止后台Master表产生重复数据
        url: '/Windchill/ptc1/trialApply/saveZMaterialDocItemInfo',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);

            if (obj.message == "success") {
            	callbackFn();
            } else {
                Ext.Msg.alert("实时保存数据失败", obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}