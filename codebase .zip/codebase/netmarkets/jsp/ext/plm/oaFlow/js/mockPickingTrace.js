Ext.define('PLM.view.pickingTrace', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.pickingTrace',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">研发领料追踪表</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    config: {
        in_objectKey: 'pickingTrace',
        in_objectDesc: '研发领料追踪表',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            title: '1.提交人',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [{
                border: false,
                html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">代办人信息</div>'
            }, {//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '申请日期',
                    value:'2021-06-29',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '申请人',
                    value:'wcadmin',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '部门',
                    value:'硬件部',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },
                ]//~end of hbox items
            },{
                border: false,
                html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">领用人信息</div>'
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '领用人',
                        name: 'att4',
                        id: 'att4',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '领用部门',
                        name: 'att5',
                        id: 'att5',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'combobox',
                        fieldLabel: '领用地址',
                        name: 'att6',
                        id: 'att6',
                        width: 250,
                       store:[['工厂仓领料','工厂仓领料'],['研发仓领料','研发仓领料']],
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '领用单',
                        name: 'att7',
                        id: 'att7',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '其他情况说明',
                        name: 'att8',
                        id: 'att8',
                        width: 1000,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                title: '2.物料确认',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '确认说明',
                        name: 'att9',
                        id: 'att9',
                        width: 1000,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                title: '3.领料处理信息',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '说明',
                        name: 'att10',
                        id: 'att10',
                        width: 1000,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                title: '4.物料到料信息',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '到料确认',
                        name: 'att12',
                        id: 'att12',
                        width: 1000,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            }//~end of 测试项目
            ]
        }]
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});