/**
 * 研发退料追踪表
 */
Ext.define('PLM.view.pickingReturn', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.pickingReturn',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">研发退料追踪表</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;

        var pickingOrReturnedValue = "";

        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';

        //gird
        var partNumberText = '物料编码';
        var factoryText = '工厂';
        var storagePlaceText = '入库仓位';
        var inspectCountText = '送检数量';
        var storageCountText = '入库数量';
        var remarkText = '备注';
        var inspectionNumberText = '检验批次号';
        var descriptionsText = '检验结果';

        //from
        var projectNumberText = '项目编号';
        var projectNameText = '项目名称';
        var applicantText = '申请人';
        var applyDepartmentText = '需求部门';
        var purposeText = '用途';
        var checkResultText = '质检结果';
        var applicantResultText = '申请人处理结果';
        var projectInitiatingCompanyText = '项目发起公司';

        if (!disableNode(submitReturn_node)) {
            projectNumberText = redStarFlag + blueFlagStart + projectNumberText + blueFlagEnd;
            applicantText = redStarFlag + blueFlagStart + applicantText + blueFlagEnd;
            applyDepartmentText = redStarFlag + blueFlagStart + applyDepartmentText + blueFlagEnd;
            purposeText = redStarFlag + blueFlagStart + purposeText + blueFlagEnd;
            remarkText =  blueFlagStart + remarkText + blueFlagEnd;
            storagePlaceText = redStarFlag + blueFlagStart + storagePlaceText + blueFlagEnd;
            partNumberText = redStarFlag + blueFlagStart + partNumberText + blueFlagEnd;
            factoryText = redStarFlag + blueFlagStart + factoryText + blueFlagEnd;
            inspectCountText = redStarFlag + blueFlagStart + inspectCountText + blueFlagEnd;
            projectNameText = redStarFlag + blueFlagStart + projectNameText + blueFlagEnd;
            projectInitiatingCompanyText = redStarFlag + blueFlagStart + projectInitiatingCompanyText + blueFlagEnd;
        } else if (!disableNode(quality_node)) {
            checkResultText = redStarFlag + blueFlagStart + checkResultText + blueFlagEnd;

            descriptionsText = blueFlagStart + descriptionsText + blueFlagEnd;

            inspectionNumberText = redStarFlag + blueFlagStart + inspectionNumberText + blueFlagEnd;
        } else if (!disableNode(initiator_node)) {
            applicantResultText = redStarFlag + blueFlagStart + applicantResultText + blueFlagEnd;
            remarkText =  blueFlagStart + remarkText + blueFlagEnd;
            storageCountText = redStarFlag + blueFlagStart + storageCountText + blueFlagEnd;
        }

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });
        var allUserCombo_projectPlan = Ext.create('PLM.hr.CtAllUserCombo', {
            store: allUserStore_projectPlan
        });


        Ext.define('pickingModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'partNumber', 'partName', 'storagePlace', 'unit', 'inspectCount', 'storageCount', 'remark'
                , 'inspectionNumber', 'descriptions'],
            idProperty: 'id'
        });

        var pickingStore = Ext.create('Ext.data.Store', {
            id: 'pickingStore',
            model: 'pickingModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/picking/getReturnItem?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        //导入panel
        var uploadForm = new Ext.form.Panel({
            layout: 'form',
            id: 'uploadForm',
            name: 'uploadForm',
            width: 450,
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            border: 0,
            tbar: [{
                xtype: 'filefield',
                name: 'userfile',
                id: 'userfile',
                msgTarget: 'side',
                fieldLabel: '上传Excel文件',
                width: 280,
                anchor: '100%',
                buttonText: '选择文件..',
                buttonOnly: false,
                buttonMargin: '5 5 5 5'
            }, {
                xtype: 'button',
                padding: '5 5 5 5',
                id: 'technic_submit',
                //disabled: existManufacturingViewPart?false:true,
                text: '开始导入',
                handler: function () {
                    var mainForm = Ext.getCmp('uploadForm').getForm();
                    var furl = "";  //文件物理地址
                    var fname = ""; //文件名称
                    furl = Ext.getCmp("userfile").getValue();
                    //alert(furl);
                    if (furl == "") {
                        alert("请先选择文件！");
                        return false;
                    }

                    mainForm.submit({
                        scope: this,
                        url: '/Windchill/ptc1/picking/importReturn?branchId=' + branchId,
                        waitMsg: '正在导入......',
                        waitTitle: '请等待',
                        //method : 'POST',
                        success: function (form, action) {
                            var obj = action.result;
                            if (obj.success) {
                                alert("导入成功");
                                // Ext.getCmp("uploadForm").hide();
                                // refreshProblem();
                                window.parent.location.reload();
                            } else {
                                alert(obj.msg);
                            }
                        },
                        failure: function (form, action) {
                            var obj = action.result;
                            alert(obj.msg);
                        },

                    });
                }
            }]
        });

        //导入窗口
        var uploadPlanWindow = new Ext.create('Ext.Window', {
            title: '导入数据',
            // width: 430,
            autoHeight: true,
            autoWidth: true,
            closeAction: 'hide',
            y: '10%',
            id: 'uploadProblemWindow',
            constrain: true,
            modal: true,
            layout: 'fit',
            //border : 0,
            items: uploadForm
        });

        var purposeCombo = new Ext.form.ComboBox({
            name: 'purposeCombo',
            id: 'purposeCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: ['0008_成品仓', '0003_半成品仓', '0002_原材料仓', '2001_维修仓', '3001_研发仓','1006 生产-五楼贴片线边仓','1009  生产-二楼贴片二车间线边仓'],
        });

        var factoryCombo = new Ext.form.ComboBox({
            name: 'factoryCombo',
            id: 'factoryCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: ['1001_电子-光明分厂', '1002_电子-光明二厂', '1003_电子-光明三厂', '1100_检测-总部', '1200_数据-总部','1300_检测-总部'],
        });


        var pickingGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('pickingStore'),
            id: 'pickingGrid',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: partNumberText, dataIndex: 'partNumber', width: 100, editor: 'textfield'},
                {text: '物料名称', dataIndex: 'partName', width: 100,},
                {text: '单位', dataIndex: 'unit', width: 100,},
                {text: storagePlaceText, dataIndex: 'storagePlace', width: 100, editor: purposeCombo},
                {text: inspectCountText, dataIndex: 'inspectCount', width: 100, editor: 'numberfield',},
                {text: storageCountText, dataIndex: 'storageCount', width: 100, editor: 'numberfield',},
                {text: factoryText, dataIndex: 'factory', width: 100, editor: factoryCombo},
                {text: remarkText, dataIndex: 'remark', width: 100, editor: 'textfield'},
                {text: inspectionNumberText, dataIndex: 'inspectionNumber', width: 100, editor: 'textfield'},
                {text: descriptionsText, dataIndex: 'descriptions', width: 100, editor: 'textfield'},
            ],
            tbar: [
                {
                    text: '新增',
                    iconCls: 'icon-add',
                    id: 'add',
                    name: 'add',
                    hidden: disableNode(submitReturn_node),
                    handler: function () {
                        var callbackFn = function () {
                            Ext.getStore('pickingStore').reload();
                        };
                        insertItemData('ZPickingReturnItem', callbackFn);
                    }
                }, {
                    text: '删除',
                    iconCls: 'icon icon-delete',
                    scope: this,
                    hidden: disableNode(submitReturn_node),
                    handler: function () {
                        let selectionArr = pickingGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('pickingStore').reload()
                        };
                        deleteData('ZPickingReturnItem', obj, callbackFn);
                    }
                }, {

                    text: '导入',
                    iconCls: 'icon-excelImport',
                    hidden: disableNode(submitReturn_node),
                    handler: function () {
                        uploadPlanWindow.show();
                    },
                }, {

                    text: '导出',
                    hidden: disableNode(submitReturn_node),
                    iconCls: 'icon icon-download',
                    handler: function () {
                        this.doExportGridData();
                    },
                    scope: this
                }, {

                    iconCls: 'icon-download ',
                    xtype: 'button',
                    id: "downTemplate",
                    text: '下载模板',
                    hidden: disableNode(submitReturn_node),
                    handler: function () {
                        window.location.href = '/Windchill/template/研发退料导入模板.xlsx', '', 'width=300,height=200';
                    }
                }],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if (!disableNode(submitReturn_node)) {
                       /* if (tField == 'descriptions' ||  tField == 'inspectionNumber') {
                            return false;
                        } else {
                            return true;
                        }*/
                        return true;
                    }
                    if (!disableNode(quality_node)) {
                        if (tField == 'descriptions' || tField == 'inspectionNumber') {
                            return true;
                        } else {
                            return false;
                        }
                    }

                    if (!disableNode(initiator_node)) {
                        if (tField == 'storageCount' || tField == 'remark') {
                            return true;
                        } else {
                            return false;
                        }

                    }
                    return false;
                }
            },
        });

        pickingGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');
                var inspectCount = tRecord.get('inspectCount');
                var storageCount = tRecord.get('storageCount');

                if(tValue!=undefined && tField == 'inspectCount' && inspectCount <= 0){
                    alert("送检数量不能小于等于0");
                    return false;
                }
                /* if(tField == 'storageCount' && storageCount<= 0 ){
                     alert("入库数量不能小于等于0");
                     return false;
                 }*/
                if (tField == 'storageCount' && storageCount > inspectCount) {
                    alert("入库数量不能大于送检数量");
                    return false;
                }

                var callbackFn = function () {
                    Ext.getStore('pickingStore').reload()
                    //tRecord.commit();
                };
                saveMockItemData('ZPickingReturnItem', itemId, tField, tValue, callbackFn);
            });

        var projectNameStore = new Ext.data.ArrayStore({
            id: 'projectNameStore',
            fields: [
                {name:"projectName"},
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/picking/queryProjectList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            title: '1.申请信息',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [
                {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {xtype: 'displayfield', id: 'id', name: 'id', hidden: true},
                        {
                            xtype: 'combobox',
                            fieldLabel: projectNameText,
                            id: 'projectName',
                            name: 'projectName',
                            value:'',
                            width: 350,
                            multiSelect: false,
                            anyMatch: true,
                            disabled: disableNode(submitReturn_node),
                            store: projectNameStore,
                            minChars : 1,//开始查询最小字符数
                            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
                            valueField: 'projectName',
                            displayField: 'projectName',
                            listeners: {
                                select: function(combo, records) {
                                    var value = Ext.getCmp('projectName').getValue();
                                    //触发后台保存
                                    if (ght_dataLoadedFlag) {
                                        autoSaveAtt('projectName', value);
                                        var projectInitiatingCompany = Ext.getCmp('projectInitiatingCompany').getValue();
                                        if(projectInitiatingCompany){
                                            setProjectNumber(value, projectInitiatingCompany, 'N');
                                        }
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'combo',
                            fieldLabel: projectInitiatingCompanyText,
                            name: 'projectInitiatingCompany',
                            id: 'projectInitiatingCompany',
                            disabled: disableNode(submitReturn_node),
                            disabledCls: 'none',
                            multiSelect: false,
                            anyMatch: true,
                            editable: false,
                            store: ['1000-电子公司', '1100-科技公司', '1200-数据公司', '1300-检测公司'],
                            width: 350,
                            listeners: {
                                select: function (e) {
                                    var value = Ext.getCmp('projectInitiatingCompany').getValue();
                                    //触发后台保存
                                    if (ght_dataLoadedFlag) {
                                        autoSaveAtt('projectInitiatingCompany', value);
                                        var projectName = Ext.getCmp('projectName').getValue();
                                        if(projectName){
                                            setProjectNumber(projectName, value, 'N');
                                        }
                                    }
                                }
                            }
                        }
                    ]//~end of hbox items
                },{//第二行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: "项目编号",
                            //disabled: disableNode(submit_node),
                            disabledCls: 'none',
                            name: 'projectNumber',
                            id: 'projectNumber',
                            width: 350
                        }
                    ]//~end of hbox items
                },
                {//第三行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [{
                        xtype: 'combo',
                        multiSelect: false,
                        valueField: 'no',
                        displayField: 'userFullName',
                        anyMatch: true,
                        editable: true,
                        allowBlank: true,
                        store: allUserStore_projectPlan,
                        fieldLabel: applicantText,
                        queryMode: 'local',
                        name: 'applicant',
                        id: 'applicant',
                        disabled: disableNode(submitReturn_node),
                        disabledCls: 'none',
                        width: 350,
                        listeners: {
                            // select: function (e) {
                            //     var value = Ext.getCmp('applicant').getValue();
                            //     //触发后台保存
                            //     autoSaveAtt('applicant',value);
                            //     getDepartment(value);
                            // },
                            select: function (e) {
                                var value = Ext.getCmp('applicant').getValue();
                                //触发后台保存
                                if (ght_dataLoadedFlag) {
                                    debugger
                                    autoSaveAtt('applicant', value);
                                }
                            }

                        }
                    }, {
                        xtype: 'combo',
                        fieldLabel: applyDepartmentText,
                        name: 'applyDepartment',
                        id: 'applyDepartment',
                        disabled: disableNode(submitReturn_node),
                        disabledCls: 'none',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        store: ['1000510000_研发中心', '1000511000_研发管理部', '1000516000_总体技术部',
                            '1000517000_硬件研发部', '1000518000_软件研发部', '1000519000_结构设计部',
                            '1000280000_PDT经理管理部','1000514000_产品工程部','1200530000_IC研发部'],
                        width: 350,
                        listeners: {
                            select: function (e) {
                                var value = Ext.getCmp('applyDepartment').getValue();
                                //触发后台保存

                                autoSaveAtt('applyDepartment', value);

                            }
                        }
                    }
                    ]//~end of hbox items
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [{
                        xtype: 'combo',
                        fieldLabel: "重置仓位",
                        name: 'positionsReset',
                        id: 'positionsReset',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        disabled: disableNode(submitReturn_node),
                        disabledCls: 'none',
                        store: ['0008_成品仓', '0003_半成品仓', '0002_原材料仓', '2001_维修仓', '3001_研发仓','1006 生产-五楼贴片线边仓','1009  生产-二楼贴片二车间线边仓'],
                        width: 350,
                        listeners: {
                            beforeselect: function (e, c) {
                                var s = window.confirm("修改此框后表格中所有仓位都会进行修改是否继续");
                                if (s) {
                                    //获取最新的值
                                    setStorehouse(c.get('field1'), 'ZPickingReturnItem', 'storagePlace');
                                    return true
                                } else {
                                    return false;
                                }
                            }

                        }

                    },{
                        xtype: 'combo',
                        fieldLabel: "重置工厂",
                        name: 'factoryReset',
                        id: 'factoryReset',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        disabled: disableNode(submitReturn_node),
                        disabledCls: 'none',
                        store: ['1001_电子-光明分厂', '1002_电子-光明二厂', '1003_电子-光明三厂', '1100_检测-总部', '1200_数据-总部','1300_检测-总部'],
                        width: 350,
                        listeners: {
                            beforeselect: function (e, c) {
                                var s = window.confirm("修改此框后表格中所有工厂都会进行修改是否继续");
                                if (s) {
                                    //获取最新的值
                                    setStorehouse(c.get('field1'), 'ZPickingReturnItem', 'factory');
                                    return true
                                } else {
                                    return false;
                                }
                            }

                        }

                    }
                    ],

                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 150},
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '研发领料单号',
                            name: 'materialRequisition',
                            id: 'materialRequisition',
                            width: 350
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '研发领料单号(手工填写)',
                            name: 'materialRequisitionManual',
                            id: 'materialRequisitionManual',
                            disabled: disableNode(submitReturn_node),
                            disabledCls: 'none',
                            width: 400,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('materialRequisitionManual').getValue();
                                    //触发后台保存
                                    autoSaveAtt('materialRequisitionManual', value);
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {
                            xtype: 'textareafield',
                            fieldLabel: purposeText,
                            name: 'purpose',
                            id: 'purpose',
                            disabled: disableNode(submitReturn_node),
                            disabledCls: 'none',
                            width: 350,
                            height: 80,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('purpose').getValue();
                                    //触发后台保存
                                    autoSaveAtt('purpose', value);
                                }
                            }
                        }
                    ]
                },
                pickingGrid, {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '2.退料处理信息',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        //layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            disabled: disableNode(quality_node),
                            disabledCls: 'none',
                            xtype: 'textarea',
                            fieldLabel: checkResultText,
                            name: 'checkResult',
                            id: 'checkResult',
                            width: 1000,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('checkResult').getValue();
                                    //触发后台保存
                                    autoSaveAtt('checkResult', value);
                                }
                            }
                        }, {
                            disabled: disableNode(initiator_node),
                            disabledCls: 'none',
                            xtype: 'textarea',
                            fieldLabel: applicantResultText,
                            name: 'applicantResult',
                            id: 'applicantResult',
                            width: 1000,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('applicantResult').getValue();
                                    //触发后台保存
                                    autoSaveAtt('applicantResult', value);
                                }
                            }
                        }
                        ],

                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '3.创建预留单',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [
                            {
                                xtype: 'displayfield',
                                fieldLabel: '预留单号',
                                name: 'singleNumber',
                                id: 'singleNumber',
                                width: 1000,
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('singleNumber').getValue();
                                        //触发后台保存
                                        autoSaveAtt('singleNumber', value);
                                    }
                                }
                            }
                        ]
                    }]
                }//~end of 测试项目
            ]
        }]

        this.callParent();
    },//~End of initComponent

    doExportGridData: function () {
        window.location.href = '/Windchill/ptc1/picking/exportReturn?branchId=' + branchId;
    },
    listeners: {
        'afterrender': function () {


            Ext.getStore('pickingStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/picking/getFormInfo?branchId=' + branchId,

                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == "success") {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj.data);

                        ght_dataLoadedFlag = true
                    } else {
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request


        }
    }
});
