/*
*
* 小批量试产申请及跟踪表
* */
Ext.define('PLM.view.newTrialApply', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.newTrialApply',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">小批量试产申请及跟踪表</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',

    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {
/////////////////////////Panel items//////////////////////////////////

        var projectName="";
        var status="";
        var endDate="";
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var head_trialAmountText = '试产数量';
        var head_endDateText = '期望完成日期';
        var head_testFileNumberText = 'TR5测试报告文件编号';
        var head_testReportText = '是否需要测试报告';
        var head_trialReasonText = '试产原因';
        var announcementsFileRecordText = '试产相关要求及注意事项';
        var trialD_guidelineEndDateText = '01-操作指引预计完成日期';
        var trialD_fixtureEndDateText = '02-工装夹具预计完成日期';
        var trialD_softwareEndDateText = '03-工装软件预计完成日期';
        var trialD_planMeetingDateText = '试产前准备会议时间';
        var trialD_productMeetingRecordText = '产前会议记录';
        var trialD_DescriptionText = '其他说明';
        var qualityD_incomingEndDateText = '01-来料检验操作指导预计完成日期';
        var trialD_finishedEndDateText = '02-成品检验操作指导预计完成日期';
        var qualityD_DescriptionText = '其他说明';
        var purchaseD_mouldEndDateText = '01-模具完成情况预计完成日期';
        var purchaseD_DescriptionText = '其他说明';
        var controlD_partQiSetEndDateText = '01-物料齐套计划预计完成日期';
        var controlD_intoProductionEndDateText = '02-计划投产日期';
        var controlD_inboundEndDateText = '03-计划入库日期';
        var controlD_DescriptionText = '其他说明';
        var controlD_productionOrderNoText = '生产令号(多个";"分割)';
        var trial_suggestText = '试产建议';
        var productionD_startDateText = '生产部开始生产日期';
        var productionD_inboundDateText = '入库日期';
        var productionD_statusNumberText = '&lt; P-1.5.1-T10 小批量试产情况表>文件编号';
        var qualityD_statusNumberText = '&lt; P-1.5.1-T11 小批量试产质量状况表>文件编号';
        var trialD_resultText = '试产结论';
        var trialD_caseRecordText = '试产结论异常情况记录';
        var trialD_finalMeetingDateText = '试产总结会议时间';
        var trialD_finalReportText = 'P-1.5.1-T13 试产总结会议记录';
        var technologyD_statusNumberText = '&lt; P-1.5.1-T15 小批量试产技术状况表>文件编号';

        var trialD_tryProductProblemText = 'P-1.5.1-T12 试产问题点总结';
        var trialD_transProductReviewText = 'P-1.5.1-T14 转量产评审表';
        
        var MaterialDocumentNumberText = '领料单文档编号';
        var MaterialDocumentNameText = '领料单文档名称';
        var MaterialDocumentCreatorText = '领料单创建人';
        var ReservationFormNumberText = '预留单编号';
        
        //可编辑项
        if( !(!disableNode(submit_node) ? !disableNode(resubmit_node) : true)){
            head_trialAmountText =redStarFlag+blueFlagStart+ head_trialAmountText +blueFlagEnd;
            head_endDateText =redStarFlag+blueFlagStart+ head_endDateText +blueFlagEnd;
        }
        if( !(disableNode(submit_node))){
            head_testFileNumberText =redStarFlag+blueFlagStart+ head_testFileNumberText +blueFlagEnd;//disableNode(submit_node)
            head_testReportText =redStarFlag+blueFlagStart+ head_testReportText +blueFlagEnd;//disableNode(submit_node)
            head_trialReasonText =blueFlagStart+ head_trialReasonText +blueFlagEnd;//disableNode(submit_node)
            announcementsFileRecordText = blueFlagStart+ announcementsFileRecordText +blueFlagEnd;

        }
        if( !(disableNode(trialFollow_node))){
            trialD_guidelineEndDateText =redStarFlag+blueFlagStart+ trialD_guidelineEndDateText +blueFlagEnd;
            trialD_fixtureEndDateText =redStarFlag+blueFlagStart+ trialD_fixtureEndDateText +blueFlagEnd;
            trialD_softwareEndDateText =redStarFlag+ blueFlagStart+ trialD_softwareEndDateText +blueFlagEnd;
            trialD_planMeetingDateText =redStarFlag+blueFlagStart+ trialD_planMeetingDateText +blueFlagEnd;
            trialD_DescriptionText =redStarFlag+blueFlagStart+ trialD_DescriptionText +blueFlagEnd;
            trialD_productMeetingRecordText =redStarFlag+blueFlagStart+ trialD_productMeetingRecordText +blueFlagEnd;

        }
        if(!(disableNode(qualityFollow_node))){
            qualityD_incomingEndDateText =redStarFlag+blueFlagStart+ qualityD_incomingEndDateText +blueFlagEnd;
            trialD_finishedEndDateText =redStarFlag+blueFlagStart+ trialD_finishedEndDateText +blueFlagEnd;
            qualityD_DescriptionText =redStarFlag+blueFlagStart+ qualityD_DescriptionText +blueFlagEnd;

        }
        if(!(disableNode(procurementFollow_node))){
            purchaseD_mouldEndDateText =redStarFlag+blueFlagStart+ purchaseD_mouldEndDateText +blueFlagEnd;
            purchaseD_DescriptionText =redStarFlag+blueFlagStart+ purchaseD_DescriptionText +blueFlagEnd;

        }
        if(!(disableNode(materialFollow_node))){
            controlD_partQiSetEndDateText =redStarFlag+blueFlagStart+ controlD_partQiSetEndDateText +blueFlagEnd;
            controlD_intoProductionEndDateText =redStarFlag+blueFlagStart+ controlD_intoProductionEndDateText +blueFlagEnd;
            controlD_inboundEndDateText =redStarFlag+blueFlagStart+ controlD_inboundEndDateText +blueFlagEnd;
            controlD_DescriptionText =redStarFlag+blueFlagStart+ controlD_DescriptionText +blueFlagEnd;
            controlD_productionOrderNoText =redStarFlag+blueFlagStart+ controlD_productionOrderNoText +blueFlagEnd;

        }
         if(!(disableNode(isCarryOut_node))){
            trial_suggestText =redStarFlag+blueFlagStart+ trial_suggestText +blueFlagEnd;

        }
        if(!(disableNode(trialProblem_node))){
            productionD_startDateText =redStarFlag+blueFlagStart+ productionD_startDateText +blueFlagEnd;
            productionD_inboundDateText =redStarFlag+blueFlagStart+ productionD_inboundDateText +blueFlagEnd;
            productionD_statusNumberText =redStarFlag+blueFlagStart+ productionD_statusNumberText +blueFlagEnd;

        }
        if(!(disableNode(materialProblem_node))){
            technologyD_statusNumberText =redStarFlag+blueFlagStart+ technologyD_statusNumberText +blueFlagEnd;
        }
        if(!(disableNode(qualityProblem_node))){
            qualityD_statusNumberText =redStarFlag+blueFlagStart+ qualityD_statusNumberText +blueFlagEnd;
        }
        if(!(disableNode(verdictAndProblem_node))){
            trialD_resultText =redStarFlag+blueFlagStart+ trialD_resultText +blueFlagEnd;
            trialD_finalMeetingDateText =redStarFlag+blueFlagStart+ trialD_finalMeetingDateText +blueFlagEnd;
            trialD_caseRecordText =redStarFlag+blueFlagStart+ trialD_caseRecordText +blueFlagEnd;
            trialD_finalReportText =redStarFlag+blueFlagStart+ trialD_finalReportText +blueFlagEnd;
            trialD_tryProductProblemText =redStarFlag+blueFlagStart+ trialD_tryProductProblemText +blueFlagEnd;
            trialD_transProductReviewText =redStarFlag+blueFlagStart+ trialD_transProductReviewText +blueFlagEnd;
        }
//        MaterialDocumentNumberText = redStarFlag + blueFlagStart + MaterialDocumentNumberText + blueFlagEnd;
//        MaterialDocumentNameText = redStarFlag + blueFlagStart + MaterialDocumentNameText + blueFlagEnd;
//        MaterialDocumentCreatorText = redStarFlag + blueFlagStart + MaterialDocumentCreatorText + blueFlagEnd;
//        ReservationFormNumberText = redStarFlag + blueFlagStart + ReservationFormNumberText + blueFlagEnd;
        

        var me = this;
        //P-1.5.1-T10 小批量试产情况表----typeT10
        //P-1.5.1-T11 小批量试产质量状况表----typeT11
        //P-1.5.1-T15 小批量试产技术状况表----typeT15
        //P-1.2.10.1-T03试报告----typeT03
        //试产总结报告----typeT13
        //////////////////////文件下拉start
        Ext.define('PLM.common.CtDocTypeT10Store',{
            extend:'Ext.data.Store',
            alias:'widget.CtDocTypeT10Store',
            fields:['docNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getDocNumber?type='+'typeT10&oid='+oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });
        Ext.define('PLM.common.CtDocTypeT10Combo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtDocTypeT10Combo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            fieldLabel: productionD_statusNumberText,
            displayField: 'docNumber',
            id:'productionD_statusNumber',
            disabled: disableNode(Check_node),
            labelWidth: 270,
            width: 390,
            valueField: 'docNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('productionD_statusNumber').getValue();
                    var url = getDocLink(value,'productionD_statusNumber');
                    Ext.getCmp('productionD_statusNumberLink').setValue(url);
                    //触发后台保存
                    if(url!=''){
                        autoSaveAtt('productionD_statusNumber', value);
                        autoSaveAtt('productionD_statusNumberLink', url);
                    }else{
                        Ext.getCmp('productionD_statusNumber').setValue('');
                        autoSaveAtt('productionD_statusNumber', '');
                        autoSaveAtt('productionD_statusNumberLink', '');
                    }

                }
            }
        });
        var CtDocTypeT10Store = Ext.create('PLM.common.CtDocTypeT10Store',{
            storeId:'CtDocTypeT10Store'
        });
        var CtDocTypeT10Combo = Ext.create('PLM.common.CtDocTypeT10Combo',{
            store:CtDocTypeT10Store
        });

        Ext.define('PLM.common.CtDocTypeT11Store',{
            extend:'Ext.data.Store',
            alias:'widget.CtDocTypeT11Store',
            fields:['docNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getDocNumber?type='+'typeT11&oid='+oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });
        Ext.define('PLM.common.CtDocTypeT11Combo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtDocTypeT11Combo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            fieldLabel: qualityD_statusNumberText,
            displayField: 'docNumber',
            id:'qualityD_statusNumber',
            labelWidth: 270,
            width: 390,
            valueField: 'docNumber',
            disabled: disableNode(Check_node),
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('qualityD_statusNumber').getValue();
                    var url = getDocLink(value,'qualityD_statusNumber');
                    Ext.getCmp('qualityD_statusNumberLink').setValue(url);
                    //触发后台保存
                    if(url!=''){
                        autoSaveAtt('qualityD_statusNumber', value);
                        autoSaveAtt('qualityD_statusNumberLink', url);
                    }else{
                        Ext.getCmp('qualityD_statusNumber').setValue('');
                        autoSaveAtt('qualityD_statusNumber', '');
                        autoSaveAtt('qualityD_statusNumberLink', '');
                    }


                }
            }
        });
        var CtDocTypeT11Store = Ext.create('PLM.common.CtDocTypeT11Store',{
            storeId:'CtDocTypeT11Store'
        });
        var CtDocTypeT11Combo = Ext.create('PLM.common.CtDocTypeT11Combo',{
            store:CtDocTypeT11Store
        });
        Ext.define('PLM.common.CtDocTypeT15Store',{
            extend:'Ext.data.Store',
            alias:'widget.CtDocTypeT15Store',
            fields:['docNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getDocNumber?type='+'typeT15&oid='+oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });
        Ext.define('PLM.common.CtDocTypeT15Combo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtDocTypeT15Combo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            fieldLabel: technologyD_statusNumberText,
            displayField: 'docNumber',
            id:'technologyD_statusNumber',
            disabled: disableNode(Check_node),
            labelWidth: 270,
            width: 390,
            valueField: 'docNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('technologyD_statusNumber').getValue();
                    var url = getDocLink(value,'technologyD_statusNumber');
                    //触发后台保存
                    if(url!=''){
                        autoSaveAtt('technologyD_statusNumber', value);
                        autoSaveAtt('technologyD_statusNumberLink', url);
                    }else{
                        Ext.getCmp('technologyD_statusNumber').setValue('');
                        autoSaveAtt('technologyD_statusNumber', '');
                        autoSaveAtt('technologyD_statusNumberLink', '');
                    }
                }
            }
        });
        Ext.define('pickingModel2', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'materialDocumentNumber', 'materialDocumentName', 'materialDocumentCreator', 'reservationFormNumber'],
            idProperty: 'id'
        });
        var pickingStore2 = Ext.create('Ext.data.Store', {
            id: 'pickingStore2',
            model: 'pickingModel2',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getZMaterialDocItem?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: true
        });
        var affectedPCNGridEditing2 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var pickingGrid2 = Ext.create('Ext.grid.Panel', {
        	plugins: [affectedPCNGridEditing2],
            store: Ext.getStore('pickingStore2'),
            id: 'pickingGrid2',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            border:1,
//            disabled: disableNode(materialFollow_node),
            height: 300,
            autoScroll: false,
            region: 'center',
            selModel: {
                mode: 'MULTI' //可以多选
            },
//            viewConfig: {
//                enableTextSelection: true,
//                stripeRows: true
//            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: MaterialDocumentNumberText, dataIndex: 'materialDocumentNumber', width: 100, editor: disableNode(submit_node)?null:'textfield'},
                {text: MaterialDocumentNameText, dataIndex: 'materialDocumentName', width: 100, editor: false},
                {text: MaterialDocumentCreatorText, dataIndex: 'materialDocumentCreator', width: 100, editor: false},
                {text: ReservationFormNumberText, dataIndex: 'reservationFormNumber', width: 100, editor: false}
            ],
            tbar: [{
                text: '新增',
                iconCls: 'icon-add',
                id: 'add',
                name: 'add',
                disabled: disableNode(submit_node),
//                hidden: disableNode(materialFollow1_node),
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('pickingStore2').reload();
                    };
                    insertItemData2('ZMaterialDocumentItem', callbackFn);
                }
            }, {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                disabled: disableNode(submit_node),
//                hidden: disableNode(submit_node),
                handler: function () {
                    let selectionArr = pickingGrid2.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    let objdel = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
//                        var rtNumber = record.data['reservationFormNumber'];
//                        if(!(rtNumber == undefined || rtNumber == null)){
//                        	objdel.push(record.data['materialDocumentNumber']);
//                        }
                        
                    });
                    var callbackFn = function () {
                      //tRecord.commit();
                      Ext.getStore('pickingStore2').reload()
                  };
                  deleteData2('ZMaterialDocumentItem', obj, callbackFn);
//                    if(objdel == undefined || objdel == null || objdel.length == 0){
//                    	var callbackFn = function () {
//                            //tRecord.commit();
//                            Ext.getStore('pickingStore2').reload()
//                        };
//                        deleteData2('ZMaterialDocumentItem', obj, callbackFn);
//                    }else{
//                    	let atdelobj = "";
//                    	for (var i = 0; i < objdel.length; i++) {
//							var objd = objdel[i];
//							atdelobj = atdelobj + objd + ","
//						}
//                    	alert("如下文档编号已处理，不能删除（" + atdelobj + "）");
//                    }
                    
                }
            }],

        });
        pickingGrid2.on('edit', function(editor, e) {
			var tRecord = e.record; // 得到当前行所有数据
			var tField = e.field; // 得到修改列
			var tValue = e.value; // 得到修改列修改后值
			var itemId = tRecord.get('id');
			var itemBranchId = tRecord.get('docBranchId');
			var itemnumber = tRecord
					.get('materialDocumentNumber');
			var callbackFn = function() {
				Ext.getStore('pickingStore2').reload()
			};
			autoSaveItemData2(itemId, itemBranchId, itemnumber,
					callbackFn);
		});
        var CtDocTypeT15Store = Ext.create('PLM.common.CtDocTypeT15Store',{
            storeId:'CtDocTypeT15Store'
        });
        var CtDocTypeT15Combo = Ext.create('PLM.common.CtDocTypeT15Combo',{
            store:CtDocTypeT15Store
        });
        Ext.define('PLM.common.CtDocTypeT13Store',{
            extend:'Ext.data.Store',
            alias:'widget.CtDocTypeT13Store',
            fields:['docNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getDocNumber?type='+'typeT13&oid='+oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });
        Ext.define('PLM.common.CtDocTypeT13Combo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtDocTypeT13Combo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            hidden: hideOrShow,
            queryMode: 'remote',
            fieldLabel: trialD_finalReportText,
            displayField: 'docNumber',
            id:'trialD_finalReport',
            margin: '10 0 20 0',
            disabled: disableNode(Check_node),
            labelWidth: 90,
            width: 210,
            valueField: 'docNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('trialD_finalReport').getValue();
                    var url = getDocLink(value,'trialD_finalReport');
                    Ext.getCmp('trialD_finalReportNumberLink').setValue(url);
                    //触发后台保存
                    if(url!=''){
                        autoSaveAtt('trialD_finalReport', value);
                        autoSaveAtt('trialD_finalReportNumberLink', url);
                    }else{
                        Ext.getCmp('trialD_finalReport').setValue('');
                        autoSaveAtt('trialD_finalReport', '');
                        autoSaveAtt('trialD_finalReportNumberLink', '');
                    }
                }
            }
        });
        var CtDocTypeT13Store = Ext.create('PLM.common.CtDocTypeT13Store',{
            storeId:'CtDocTypeT13Store'
        });
        var CtDocTypeT13Combo = Ext.create('PLM.common.CtDocTypeT13Combo',{
            store:CtDocTypeT13Store
        });

        Ext.define('PLM.common.CtDocTypeT03Store',{
            extend:'Ext.data.Store',
            alias:'widget.CtDocTypeT03Store',
            fields:['docNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getDocNumber?type='+'typeT03&oid='+oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });
        Ext.define('PLM.common.CtDocTypeT03Combo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtDocTypeT03Combo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            fieldLabel: head_testFileNumberText,
            displayField: 'docNumber',
            id:'head_testFileNumber',
            margin: '10 0 20 0',
            disabled: disableNode(submit_node),
            labelWidth: 90,
            width: 210,
            valueField: 'docNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('head_testFileNumber').getValue();
                    var url = getDocLink(value,"head_testFileNumber");
                    Ext.getCmp('head_testFileNumberLink').setValue(url);
                    if(url!=''){
                        autoSaveAtt('head_testFileNumber', value);
                        autoSaveAtt('head_testFileNumberLink', url);
                    }else{
                        Ext.getCmp('head_testFileNumber').setValue('');
                        autoSaveAtt('head_testFileNumber', '');
                        autoSaveAtt('head_testFileNumberLink', '');
                    }
                }
            }

        });
        var CtDocTypeT03Store = Ext.create('PLM.common.CtDocTypeT03Store',{
            storeId:'CtDocTypeT03Store'
        });
        var CtDocTypeT03Combo = Ext.create('PLM.common.CtDocTypeT03Combo',{
            store:CtDocTypeT03Store
        });
        //P-1.5.1-T09 产前会议记录
        Ext.define('PLM.common.CtDocTypeT09Store',{
            extend:'Ext.data.Store',
            alias:'widget.CtDocTypeT09Store',
            fields:['docNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getDocNumber?type='+'typeT09&oid='+oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });
        Ext.define('PLM.common.CtDocTypeT09Combo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtDocTypeT09Combo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            fieldLabel: trialD_productMeetingRecordText,
            displayField: 'docNumber',
            id:'trialD_productMeetingRecord',
            margin: '10 0 20 0',
            disabled: disableNode(Check_node),
            labelWidth: 90,
            width: 210,
            valueField: 'docNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('trialD_productMeetingRecord').getValue();
                    var url = getDocLink(value,"trialD_productMeetingRecord");
                    Ext.getCmp('trialD_productMeetingRecordLink').setValue(url);
                    if(url!=''){
                        autoSaveAtt('trialD_productMeetingRecord', value);
                        autoSaveAtt('trialD_productMeetingRecordLink', url);
                    }else{
                        Ext.getCmp('trialD_productMeetingRecord').setValue('');
                        autoSaveAtt('trialD_productMeetingRecord', '');
                        autoSaveAtt('trialD_productMeetingRecordLink', '');
                    }
                }
            }

        });
        var CtDocTypeT09Store = Ext.create('PLM.common.CtDocTypeT09Store',{
            storeId:'CtDocTypeT09Store'
        });
        var CtDocTypeT09Combo = Ext.create('PLM.common.CtDocTypeT09Combo',{
            store:CtDocTypeT09Store
        });

        Ext.define('PLM.common.CtDocTypeT12Store',{
            extend:'Ext.data.Store',
            alias:'widget.CtDocTypeT12Store',
            fields:['docNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getDocNumber?type='+'typeT12&oid='+oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });
        Ext.define('PLM.common.CtDocTypeT12Combo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtDocTypeT12Combo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            hidden: hideOrShow,
            queryMode: 'remote',
            fieldLabel: trialD_tryProductProblemText,
            displayField: 'docNumber',
            id:'trialD_tryProductProblem',
            margin: '10 0 20 0',
            disabled: disableNode(Check_node),
            labelWidth: 90,
            width: 210,
            valueField: 'docNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('trialD_tryProductProblem').getValue();
                    var url = getDocLink(value,"trialD_tryProductProblem");
                    Ext.getCmp('trialD_tryProductProblemLink').setValue(url);
                    if(url!=''){
                        autoSaveAtt('trialD_tryProductProblem', value);
                        autoSaveAtt('trialD_tryProductProblemLink', url);
                    }else{
                        Ext.getCmp('trialD_tryProductProblem').setValue('');
                        autoSaveAtt('trialD_tryProductProblem', '');
                        autoSaveAtt('trialD_tryProductProblemLink', '');
                    }
                }
            }

        });
        var CtDocTypeT12Store = Ext.create('PLM.common.CtDocTypeT12Store',{
            storeId:'CtDocTypeT12Store'
        });
        var CtDocTypeT12Combo = Ext.create('PLM.common.CtDocTypeT12Combo',{
            store:CtDocTypeT12Store
        });
        Ext.define('PLM.common.CtDocTypeT14Store',{
            extend:'Ext.data.Store',
            alias:'widget.CtDocTypeT14Store',
            fields:['docNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getDocNumber?type='+'typeT14&oid='+oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });
        Ext.define('PLM.common.CtDocTypeT14Combo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtDocTypeT14Combo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            fieldLabel: trialD_transProductReviewText,
            displayField: 'docNumber',
            id:'trialD_transProductReview',
            margin: '10 0 20 0',
            disabled: disableNode(verdictAndProblem_node),
            labelWidth: 90,
            width: 210,
            valueField: 'docNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('trialD_transProductReview').getValue();
                    var url = getDocLink(value,"trialD_transProductReview");
                    Ext.getCmp('trialD_transProductReviewLink').setValue(url);
                    if(url!=''){
                        autoSaveAtt('trialD_transProductReview', value);
                        autoSaveAtt('trialD_transProductReviewLink', url);
                    }else{
                        Ext.getCmp('trialD_transProductReview').setValue('');
                        autoSaveAtt('trialD_transProductReview', '');
                        autoSaveAtt('trialD_transProductReviewLink', '');
                    }
                }
            }

        });
        var CtDocTypeT14Store = Ext.create('PLM.common.CtDocTypeT14Store',{
            storeId:'CtDocTypeT14Store'
        });
        var CtDocTypeT14Combo = Ext.create('PLM.common.CtDocTypeT14Combo',{
            store:CtDocTypeT14Store
        });

        //////////////////////文件下拉end
        Ext.define('newTrialItemModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'projectName', 'status', 'endDate'],
            idProperty: 'id'
        });

        Ext.define('trialApplyModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'projectName', 'endDate'],
            idProperty: 'id'
        });

        Ext.define('qualityDeptModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'projectName', 'producer', 'endDate', 'projectName1', 'isNeed', 'endDate1'],
            idProperty: 'id'
        });

        var isCompleteCombo = new Ext.form.ComboBox({
            name: 'isCompleteCombo',
            id: 'isCompleteCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['已完成', '已完成'], ['未完成', '未完成']]
        });

        var newTrialItemStore = Ext.create('Ext.data.Store', {
            id: 'newTrialItemStore',
            model: 'newTrialItemModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trialApply/getNewTrialItem?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var cellEditing2 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var cellEditing3 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var cellEditing4 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var cellEditing5 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var newTrialGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: newTrialItemStore,
            id: 'newTrialGrid',
            margin: '10 0 20 0',
            //forceFit: true,
            //autoWidth: true,
            width: 1500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change:'onAllCircuitsChecked'
            },
            //'id', 'docBranchId', 'projectName', 'status', 'endDate'
            columns: [{xtype: 'rownumberer',width: 20},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '项目', dataIndex: 'projectName', width: 170,editor: disableNode(submit_node)||disableNode(resubmit_node)?'textfield':null},
                {text: '完成状态', dataIndex: 'status', width: 100, editor: disableNode(submit_node)||disableNode(resubmit_node)?isCompleteCombo:null,
                    renderer: function (value,metaData) {

                        if (value != null && value != undefined && value != '') {

                            //提示tip
                            metaData.tdAttr = " data-qtip = '"+value+"'";
                            if(value=='已完成'){
                                value= '<span style="color:#008000;">'+value+'</span>';
                            }else if(value=='未完成'){
                                value= '<span style="color:#FF0000;">'+value+'</span>';
                            }
                            return value;
                        }
                        return value;
                    },},
                {text: '预计提供日期', dataIndex: 'endDate', width: 120, editor:disableNode(submit_node)||disableNode(resubmit_node)? {xtype:'datefield',format:'Y-m-d', minValue:new Date()}:null,menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value){
                            value= selfDateFormat(value)
                        }
                        return value;
                    }},
                {text: '填写说明', dataIndex: 'explain',editor: disableNode(submit_node)||disableNode(resubmit_node)?'textfield':null, width: 550},

            ], tbar: [
                {
                    text: '新增',
                    iconCls : 'icon-add',
                    hidden:!disableNode(submit_node) ? !disableNode(resubmit_node) : true,
                    handler: function () {
                        var callbackFn = function () {
                            Ext.getStore('newTrialItemStore').reload();
                        };
                        insertItemData('ZNewTrialApplyItem', callbackFn);
                    }
                }, {
                    text: '删除',
                    hidden:!disableNode(submit_node) ? !disableNode(resubmit_node) : true,
                    iconCls : 'icon-delete',
                    scope: this,
                    handler: function () {
                        let selectionArr = newTrialGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('newTrialItemStore').reload()
                        };
                        deleteData('ZNewTrialApplyItem', obj, callbackFn);
                    }
                }],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    if(taskCompleted){
                        return  false;
                    }
                    if(disableNode(submit_node)&&disableNode(resubmit_node) ){
                        return  false;
                    }
                    var tField = e.field; //得到修改列
                    let status2=e.record.get("status");
                    projectName = e.record.get("projectName");
                    status = e.record.get("status");
                    endDate = e.record.get("endDate");
                   if(tField=='endDate'&&status2=='已完成'){
                        return false;
                   }
                }
            },
        });


        newTrialGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');
                console.log("====="+e.field);
                console.log("====="+e.value+"======"+projectName);

                if(e.field=="projectName"&&e.value==projectName) {
                    tRecord.commit();
                    return;
                }
                if(e.field=="status"&&e.value==status) {
                    tRecord.commit();
                    return;
                }
                if(e.field=="endDate"&&e.value==endDate) {
                    tRecord.commit();
                    return;
                }

                var callbackFn = function () {
                    Ext.getStore('newTrialItemStore').reload()
                    //tRecord.commit();
                };
                saveMockItemData('ZNewTrialApplyItem', itemId, tField, tValue, callbackFn);

            });

        /*
                trialDeptGrid.on('edit',
                    function (editor, e) {
                        var tRecord = e.record; //得到当前行所有数据
                        var tField = e.field; //得到修改列
                        var tValue = e.value; //得到修改列修改后值
                        var itemId = tRecord.get('id');

                        var callbackFn = function () {
                            tRecord.commit();
                        };
                        saveMockItemData('ZTrialApplyItem', itemId, tField, tValue, callbackFn);

                    });

                purchaseGrid.on('edit',
                    function (editor, e) {
                        var tRecord = e.record; //得到当前行所有数据
                        var tField = e.field; //得到修改列
                        var tValue = e.value; //得到修改列修改后值
                        var itemId = tRecord.get('id');

                        var callbackFn = function () {
                            tRecord.commit();
                        };
                        saveMockItemData('ZTrialApplyItem', itemId, tField, tValue, callbackFn);

                    });

                controlGrid.on('edit',
                    function (editor, e) {
                        var tRecord = e.record; //得到当前行所有数据
                        var tField = e.field; //得到修改列
                        var tValue = e.value; //得到修改列修改后值
                        var itemId = tRecord.get('id');

                        var callbackFn = function () {
                            tRecord.commit();
                        };
                        saveMockItemData('ZTrialApplyItem', itemId, tField, tValue, callbackFn);

                    });

                qualityGrid.on('edit',
                    function (editor, e) {
                        var tRecord = e.record; //得到当前行所有数据
                        var tField = e.field; //得到修改列
                        var tValue = e.value; //得到修改列修改后值
                        var itemId = tRecord.get('id');

                        var callbackFn = function () {
                            tRecord.commit();
                        };
                        saveMockItemData('ZQualityTrialApplyItem', itemId, tField, tValue, callbackFn);

                    });
        */

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            anchor: '92%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [
                {
                    xtype: 'panel',
                    margin: '5 20 5 5',
                    title: '试产申请',
                    collapsible: true,
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false},
                    items: [
                        {//第一行
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [
                                {
                                    xtype: 'displayfield',
                                    fieldLabel: '申请人',
                                    id: 'proposer',
                                    width: 200,
                                    listeners: {
                                        change: function (e) {
                                            var value = Ext.getCmp('proposer').getValue();
                                            //触发后台保存
                                            if (isFlow) {
                                                if (currentActKey=='submit_node') {
                                                    autoSaveAtt('proposer', value);
                                                }
                                            }
                                        }
                                    }
                                }, {
                                    xtype: 'displayfield',
                                    fieldLabel: '申请日期',
                                    id: 'applyDate',
                                    width: 200,
                                    listeners: {
                                        change: function (e) {
                                            var value = Ext.getCmp('applyDate').getValue();
                                            //触发后台保存
                                            if (isFlow) {
                                                if (currentActKey=='submit_node') {
                                                    autoSaveAtt('applyDate', value);
                                                }
                                            }
                                        }
                                    }
                                },
                                {
                                    xtype: 'textfield',
                                    // fieldLabel: '试产数量',
                                    fieldLabel: head_trialAmountText,
                                    name: 'head_trialAmount',
                                    id: 'head_trialAmount',
                                    width: 200,
                                    disabled: !disableNode(submit_node) ? !disableNode(resubmit_node) : true,
                                    disabledCls: 'none',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('head_trialAmount').getValue();
                                            //触发后台保存
                                            autoSaveAtt('head_trialAmount', value);
                                        }
                                    }
                                }, {
                                    xtype: 'datefield',
                                    fieldLabel: head_endDateText,
                                    width: 250,
                                    name: 'head_endDate',
                                    id: 'head_endDate',
                                    disabled: !disableNode(submit_node) ? !disableNode(resubmit_node) : true,
                                    disabledCls: 'none',
                                    format:'Y-m-d',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('head_endDate').getValue();
                                            value = Ext.Date.format(value, 'Y-m-d')
                                            //触发后台保存
                                            autoSaveAtt('head_endDate', value);
                                        }
                                    }
                                }
                            ]//~end of hbox items
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype: 'displayfield',
                                fieldLabel: '物料代码',
                                name: 'head_partCode',
                                id: 'head_partCode',
                                disabled: !disableNode(submit_node) ? !disableNode(resubmit_node) : true,
                                disabledCls: 'none',
                                width: 200,
                                listeners: {
                                    change: function (e) {
                                        var value = Ext.getCmp('head_partCode').getValue();
                                        //触发后台保存
                                        if (isFlow) {
                                            if (currentActKey=='submit_node') {
                                                autoSaveAtt('head_partCode', value);
                                                getPartInfo(value);
                                            }
                                        }
                                    }
                                }
                            }, {
                                xtype: 'displayfield',
                                fieldLabel: '产品名称',
                                name: 'head_productName',
                                id: 'head_productName',
                                width: 200,
                                listeners: {
                                    change: function (e) {
                                        var value = Ext.getCmp('head_productName').getValue();
                                        //触发后台保存
                                        if (isFlow) {
                                            if (currentActKey=='submit_node') {
                                                autoSaveAtt('head_productName', value);
                                            }
                                        }
                                    }
                                }
                            }, {
                                xtype: 'displayfield',
                                fieldLabel: '产品型号',
                                name: 'head_productType',
                                id: 'head_productType',
                                width: 200,
                                listeners: {
                                    change: function (e) {
                                        var value = Ext.getCmp('head_productType').getValue();
                                        //触发后台保存
                                        if (isFlow) {
                                            if (currentActKey=='submit_node') {
                                                autoSaveAtt('head_productType', value);
                                            }
                                        }
                                    }
                                }
                            }, {
                                xtype: 'displayfield',
                                fieldLabel: '所属PDT线',
                                name: 'head_pdtLine',
                                id: 'head_pdtLine',
                                width: 250,
                                disabled: true,
                                disabledCls: 'none',
                                // store: [['01-火灾报警', '01-火灾报警'], ['02-电源监控', '02-电源监控'], ['03-电气火灾', '03-电气火灾'], ['04-防火门', '04-防火门'],
                                //     ['05-应急疏散系统', '05-应急疏散系统'], ['06-气体灭火', '06-气体灭火'], ['07-可燃气体', '07-可燃气体'], ['08-独立式探测器', '08-独立式探测器'],
                                //     ['09-传感器', '09-传感器'], ['10-余压监控系统', '10-余压监控系统'], ['20-楼宇', '20-楼宇'], ['21-监控', '21-监控'],
                                //     ['22-智能家居', '22-智能家居'], ['23-智能锁', '23-智能锁'], ['30-消防物联网产品', '30-消防物联网产品'], ['31-安防物联网产品', '31-安防物联网产品'],
                                //     ['32-物联网火灾探测器', '32-物联网火灾探测器'], ['33-物联网可燃气体探测器', '33-物联网可燃气体探测器'], ['40-系统平台软件', '40-系统平台软件'], ['41-移动客户端软件', '41-移动客户端软件'],
                                //     ['42-产品软件', '42-产品软件'], ['50-工程服务', '50-工程服务'], ['60-研发服务', '60-研发服务'], ['61-技术服务', '61-技术服务'],
                                //     ['62-平台服务', '62-平台服务'], ['70-产品维修', '70-产品维修'], ['71-租赁服务', '71-租赁服务'], ['88-消防', '88-消防'], ['99-安防', '99-安防']],
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('head_pdtLine').getValue();
                                        //触发后台保存
                                        autoSaveAtt('head_pdtLine', value);
                                    }
                                }
                            }
                            ]
                        },
                        {
		                    xtype: 'radiogroup',
		                    fieldLabel: head_testReportText,
		                    name: 'head_testReportTxt',
		                    id: 'head_testReportTxt',
		                    width: 300,
		//                    disabled: disableNode(verdictAndProblem_node),
		                    disabledCls: 'none',
		                    items: [
		                        {inputValue: '是', boxLabel: '是',checked: true,  name: 'head_testReport', disabledCls: 'none'},
		                        {inputValue: '否', boxLabel: '否', name: 'head_testReport', disabledCls: 'none'}
		                    ],
		                    listeners: {
		                        change: function (field, newValue, oldValue) {
		                            if (!ght_dataLoadedFlag) {
		                                //阻止加载时执行后台保存
		                                return;
		                            }
		                            //触发后台保存
		                            var data = newValue.head_testReport;
		                            if(data == "否"){
		                            	 Ext.getCmp("head_testFileNumber").hide();
		                            	 Ext.getCmp("head_testFileNumberLink").hide();
		                            	 
		                            }else{
		                            	Ext.getCmp("head_testFileNumber").show();
		                            	Ext.getCmp("head_testFileNumberLink").show();
		                            }
		                            autoSaveAtt('head_testReport', data);
		                        }
		                    }
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype:CtDocTypeT03Combo,

                                labelWidth: 150,
                                name: 'head_testFileNumber',
                                id: 'head_testFileNumber',
                                width: 300,
                                // disabled: disableNode(submit_node),
                                disabledCls: 'none',

                            },{
                                xtype: 'displayfield',
                                fieldLabel: '文件链接',
                                margin: '15 0 0 0',
                                labelWidth: 80,
                                name: 'head_testFileNumberLink',
                                id: 'head_testFileNumberLink',
                                width: 150,
                            },
                            ]
                        },pickingGrid2,
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [
                                {
                                    xtype: 'textarea',
                                    fieldLabel: head_trialReasonText,
                                    name: 'head_trialReason',
                                    id: 'head_trialReason',
                                    labelWidth: 80,
                                    width: 450,
                                    height: 200,
                                    disabled: disableNode(submit_node),
                                    disabledCls: 'none',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('head_trialReason').getValue();
                                            //触发后台保存
                                            autoSaveAtt('head_trialReason', value);
                                        }
                                    }
                                },
                            ]
                        },  {
                            xtype: 'panel',
                            title: '试产产品信息收集与确认',
                            collapsible: true,
                            layout: 'hbox',
                            //collapsible: true,
                            margin: '5 20 5 5',
                            items: [newTrialGrid,]
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{margin: '5 20 0 0', border: false, html: '资料上传'}, {
                                xtype: 'displayfield',
                                fieldLabel: announcementsFileRecordText,
                                labelWidth: 170,
                            },uploadFilefield("announcementsFile","点击上传","submit_node","announcementsFileRecord"),{
                                xtype:'displayfield',
                                fieldLabel: '附件链接',
                                // disabled:true,
                                labelWidth:70,
                                id:'announcementsFileRecord',
                                name:'announcementsFileRecord',
                                width:'30%',


                            }]
                        }]
                },
                {
                    xtype: 'panel',
                    collapsible: true,
                    title: '试产前准备',
                    //collapsible: true,
                    defaults: {border: false},
                    margin: '5 20 5 5',
                    items: [{
                        xtype: 'panel',
                        title: '01-试产部门',
                        collapsible: true,
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [
                            {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype: 'datefield',
                                fieldLabel: trialD_guidelineEndDateText,
                                labelWidth: 100,
                                name: 'trialD_guidelineEndDate',
                                id: 'trialD_guidelineEndDate',
                                format: 'Y-m-d',
                                width: 250,
                                disabled: disableNode(trialFollow_node),
                                disabledCls: 'none',
                                listeners: {
                                    select: function (e) {
                                        var value = Ext.getCmp('trialD_guidelineEndDate').getValue();

                                        value = Ext.Date.format(value, 'Y-m-d')
                                        //触发后台保存
                                        autoSaveAtt('trialD_guidelineEndDate', value);
                                    }
                                }
                            }, {
                                xtype: 'datefield',
                                fieldLabel: trialD_fixtureEndDateText,
                                labelWidth: 100,
                                name: 'trialD_fixtureEndDate',
                                id: 'trialD_fixtureEndDate',
                                width: 250,
                                format:'Y-m-d',
                                disabled: disableNode(trialFollow_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('trialD_fixtureEndDate').getValue();
                                        value = Ext.Date.format(value, 'Y-m-d')
                                        //触发后台保存
                                        autoSaveAtt('trialD_fixtureEndDate', value);
                                    }
                                }
                            }, {
                                xtype: 'datefield',
                                fieldLabel: trialD_softwareEndDateText,
                                labelWidth: 100,
                                name: 'trialD_softwareEndDate',
                                id: 'trialD_softwareEndDate',
                                width: 250,
                                format: 'Y-m-d',
                                disabled: disableNode(trialFollow_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('trialD_softwareEndDate').getValue();
                                        value = Ext.Date.format(value, 'Y-m-d')
                                        //触发后台保存
                                        autoSaveAtt('trialD_softwareEndDate', value);
                                    }
                                }
                            }
                            ]
                        }
                        ,{
                                xtype: 'panel',
                                layout: 'hbox',
                                border: false,
                                defaults: {margin: '5 20 0 0', labelWidth: 100},
                                items: [
                                    {
                                        xtype: 'datefield',
                                        fieldLabel: trialD_planMeetingDateText,
                                        labelWidth: 100,
                                        name: 'trialD_planMeetingDate',
                                        id: 'trialD_planMeetingDate',
                                        format: 'Y-m-d',
                                        width: 250,
                                        disabled: disableNode(trialFollow_node),
                                        disabledCls: 'none',
                                        listeners: {
                                            blur: function (e) {
                                                var value = Ext.getCmp('trialD_planMeetingDate').getValue();
                                                //触发后台保存
                                                autoSaveAtt('trialD_planMeetingDate', value);
                                            }
                                        }
                                    },{
                                        xtype: CtDocTypeT09Combo,
                                        width: 390,
                                        disabledCls: 'none',
                                    },{
                                        xtype: 'displayfield',
                                        fieldLabel: '文件链接',
                                        margin: '10 0 0 0',
                                        labelWidth: 80,
                                        name: 'trialD_productMeetingRecordLink',
                                        id: 'trialD_productMeetingRecordLink',
                                        width: 150,
                                    },
                                ]
                        }, {
                            xtype: 'textarea',
                            fieldLabel: trialD_DescriptionText,
                            name: 'trialD_Description',
                            id: 'trialD_Description',
                            width: 750,
                            disabled: disableNode(trialFollow_node),
                            disabledCls: 'none',
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('trialD_Description').getValue();
                                    //触发后台保存
                                    autoSaveAtt('trialD_Description', value);
                                }
                            }
                        }]
                    },
                        {
                            xtype: 'panel',
                            //layout: 'hbox',
                            title: '02-质控部',
                            collapsible: true,
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype: 'panel',
                                layout: 'hbox',
                                border: false,
                                defaults: {margin: '5 20 0 0', labelWidth: 100},
                                items: [{
                                    xtype: 'datefield',
                                    fieldLabel: qualityD_incomingEndDateText,
                                    labelWidth: 100,
                                    name: 'qualityD_incomingEndDate',
                                    id: 'qualityD_incomingEndDate',
                                    format: 'Y-m-d',
                                    width: 250,
                                    disabled: disableNode(qualityFollow_node),
                                    disabledCls: 'none',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('qualityD_incomingEndDate').getValue();
                                            value = Ext.Date.format(value, 'Y-m-d')
                                            //触发后台保存
                                            autoSaveAtt('qualityD_incomingEndDate', value);
                                        }
                                    }
                                }, {
                                    xtype: 'datefield',
                                    fieldLabel: trialD_finishedEndDateText,
                                    labelWidth: 100,
                                    name: 'trialD_finishedEndDate',
                                    id: 'trialD_finishedEndDate',
                                    format: 'Y-m-d',
                                    width: 250,
                                    disabled: disableNode(qualityFollow_node),
                                    disabledCls: 'none',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('trialD_finishedEndDate').getValue();
                                            value = Ext.Date.format(value, 'Y-m-d')
                                            //触发后台保存
                                            autoSaveAtt('trialD_finishedEndDate', value);
                                        }
                                    }
                                },
                                ]
                            }, {
                                xtype: 'textarea',
                                fieldLabel: qualityD_DescriptionText,
                                name: 'qualityD_Description',
                                id: 'qualityD_Description',
                                width: 750,
                                disabled: disableNode(qualityFollow_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('qualityD_Description').getValue();
                                        //触发后台保存
                                        autoSaveAtt('qualityD_Description', value);
                                    }
                                }
                            }]
                        }
                        , {
                            xtype: 'panel',
                            //layout: 'hbox',
                            title: '03-采购部',
                            collapsible: true,
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype: 'panel',
                                layout: 'hbox',
                                border: false,
                                defaults: {margin: '5 20 0 0', labelWidth: 100},
                                items: [{
                                    xtype: 'datefield',
                                    fieldLabel: purchaseD_mouldEndDateText,
                                    labelWidth: 100,
                                    name: 'purchaseD_mouldEndDate',
                                    id: 'purchaseD_mouldEndDate',
                                    format: 'Y-m-d',
                                    width: 250,
                                    disabled: disableNode(procurementFollow_node),
                                    disabledCls: 'none',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('purchaseD_mouldEndDate').getValue();
                                            value = Ext.Date.format(value, 'Y-m-d')
                                            //触发后台保存
                                            autoSaveAtt('purchaseD_mouldEndDate', value);
                                        }
                                    }
                                }
                                ]
                            }, {
                                xtype: 'textarea',
                                fieldLabel: purchaseD_DescriptionText,
                                name: 'purchaseD_Description',
                                id: 'purchaseD_Description',
                                width: 750,
                                disabled: disableNode(procurementFollow_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('purchaseD_Description').getValue();
                                        //触发后台保存
                                        autoSaveAtt('purchaseD_Description', value);
                                    }
                                }
                            }]
                        }
                        , {
                            xtype: 'panel',
                            //layout: 'hbox',
                            title: '04-物控部',
                            collapsible: true,
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype: 'panel',
                                layout: 'hbox',
                                border: false,
                                defaults: {margin: '5 20 0 0', labelWidth: 100},
                                items: [{
                                    xtype: 'datefield',
                                    fieldLabel: controlD_partQiSetEndDateText,
                                    labelWidth: 100,
                                    name: 'controlD_partQiSetEndDate',
                                    id: 'controlD_partQiSetEndDate',
                                    format: 'Y-m-d',
                                    width: 250,
                                    disabled: disableNode(materialFollow_node),
                                    disabledCls: 'none',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('controlD_partQiSetEndDate').getValue();
                                            value = Ext.Date.format(value, 'Y-m-d')
                                            //触发后台保存
                                            autoSaveAtt('controlD_partQiSetEndDate', value);
                                        }
                                    }
                                }, {
                                    xtype: 'datefield',
                                    fieldLabel: controlD_intoProductionEndDateText,
                                    labelWidth: 100,
                                    name: 'controlD_intoProductionEndDate',
                                    id: 'controlD_intoProductionEndDate',
                                    format: 'Y-m-d',
                                    width: 250,
                                    disabled: disableNode(materialFollow_node),
                                    disabledCls: 'none',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('controlD_intoProductionEndDate').getValue();
                                            value = Ext.Date.format(value, 'Y-m-d')
                                            //触发后台保存
                                            autoSaveAtt('controlD_intoProductionEndDate', value);
                                        }
                                    }
                                }, {
                                    xtype: 'datefield',
                                    fieldLabel: controlD_inboundEndDateText,
                                    labelWidth: 100,
                                    name: 'controlD_inboundEndDate',
                                    id: 'controlD_inboundEndDate',
                                    format: 'Y-m-d',
                                    width: 250,
                                    disabled: disableNode(materialFollow_node),
                                    disabledCls: 'none',
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('controlD_inboundEndDate').getValue();
                                            value = Ext.Date.format(value, 'Y-m-d')
                                            //触发后台保存
                                            autoSaveAtt('controlD_inboundEndDate', value);
                                        }
                                    }
                                }
                                ]
                            }, {
                                xtype: 'textarea',
                                fieldLabel: controlD_DescriptionText,
                                name: 'controlD_Description',
                                id: 'controlD_Description',
                                width: 400,
                                disabled: disableNode(materialFollow_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('controlD_Description').getValue();
                                        //触发后台保存
                                        autoSaveAtt('controlD_Description', value);
                                    }
                                }
                            }, {
                                xtype: 'textarea',
                                fieldLabel: controlD_productionOrderNoText,
                                labelWidth: 100,
                                name: 'controlD_productionOrderNo',
                                id: 'controlD_productionOrderNo',
                                width: 400,
                                disabled: disableNode(materialFollow_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('controlD_productionOrderNo').getValue();
                                        //触发后台保存
                                        autoSaveAtt('controlD_productionOrderNo', value);
                                    }
                                }
                            },]
                        }
                        , {
                            xtype: 'panel',
                            title: '05-产品工程部经理判定试产能否进行',
                            collapsible: true,
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [ {
                                xtype: 'textarea',
                                fieldLabel:trial_suggestText,
                                name: 'trial_suggest',
                                id: 'trial_suggest',
                                disabled: disableNode(isCarryOut_node),
                                disabledCls: 'none',
                                width: 400,
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('trial_suggest').getValue();
                                        //触发后台保存
                                        autoSaveAtt('trial_suggest', value);
                                    }
                                }
                            }]
                        }]
                }, {
                    xtype: 'panel',
                    title: '试产问题跟进及总结',
                    collapsible: true,
                    items: [{
                        xtype: 'panel',
                        title: '01-生产部',
                        collapsible: true,
                        border: false,
                        defaults: {margin: '5 20 5 0', labelWidth: 100},
                        items: [{
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype: 'datefield',
                                fieldLabel: productionD_startDateText,
                                name: 'productionD_startDate',
                                id: 'productionD_startDate',
                                format: 'Y-m-d',
                                labelWidth: 140,
                                width: 290,
                                disabled: disableNode(trialProblem_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('productionD_startDate').getValue();
                                        value = Ext.Date.format(value, 'Y-m-d')
                                        //触发后台保存
                                        autoSaveAtt('productionD_startDate', value);
                                    }
                                }
                            }, {
                                xtype: 'datefield',
                                fieldLabel: productionD_inboundDateText,
                                name: 'productionD_inboundDate',
                                id: 'productionD_inboundDate',
                                format: 'Y-m-d',
                                width: 250,
                                disabled: disableNode(trialProblem_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('productionD_inboundDate').getValue();
                                        value = Ext.Date.format(value, 'Y-m-d')
                                        //触发后台保存
                                        autoSaveAtt('productionD_inboundDate', value);
                                    }
                                }
                            }]
                        }, {
                            xtype: CtDocTypeT10Combo,
                            width: 390,
                            disabledCls: 'none',

                        },{
                            xtype: 'displayfield',
                            fieldLabel: '文件链接',
                            labelWidth: 80,
                            name: 'productionD_statusNumberLink',
                            id: 'productionD_statusNumberLink',
                            width: 150,
                        },]

                    }, {
                        xtype: 'panel',
                        title: '02-质控部',
                        collapsible: true,
                        border: false,
                        defaults: {margin: '5 20 5 0', labelWidth: 100},
                        items: [{
                            xtype: CtDocTypeT11Combo,
                            labelWidth: 280,
                            width: 400,
                            disabledCls: 'none',

                        },{
                            xtype: 'displayfield',
                            fieldLabel: '文件链接',
                            labelWidth: 80,
                            name: 'qualityD_statusNumberLink',
                            id: 'qualityD_statusNumberLink',
                            width: 150,
                        },]
                    }, {
                        xtype: 'panel',
                        title: '03-技术部',
                        collapsible: true,
                        border: false,
                        defaults: {margin: '5 20 5 0', labelWidth: 100},
                        items: [{
                            xtype: CtDocTypeT15Combo,
                            labelWidth: 270,
                            width: 390,
                            disabledCls: 'none',

                        },{
                            xtype: 'displayfield',
                            fieldLabel: '文件链接',
                            labelWidth: 80,
                            name: 'technologyD_statusNumberLink',
                            id: 'technologyD_statusNumberLink',
                            width: 150,
                        },]
                    }, {
                        xtype: 'panel',
                        title: '04-试产部门',
                        collapsible: true,
                        border: false,
                        defaults: {margin: '5 20 5 0', labelWidth: 100},
                        items: [{
                            xtype: 'radiogroup',
                            fieldLabel: trialD_resultText,
                            name: 'trialD_result',
                            id: 'trialD_result',
                            width: 300,
                            disabled: disableNode(verdictAndProblem_node),
                            disabledCls: 'none',
                            items: [
                                {inputValue: '试产通过', boxLabel: '试产通过', name: 'result', disabledCls: 'none'},
                                {inputValue: '试产不通过', boxLabel: '试产不通过', name: 'result', disabledCls: 'none'}
                            ],
                            listeners: {
                                change: function (field, newValue, oldValue) {
                                    if (!ght_dataLoadedFlag) {
                                        //阻止加载时执行后台保存
                                        return;
                                    }
                                    //触发后台保存
                                    var data = newValue.result;
                                    autoSaveAtt('result', data);
                                }
                            }
                        }, {
                            xtype: 'textarea',
                            fieldLabel: trialD_caseRecordText,
                            name: 'trialD_caseRecord',
                            id: 'trialD_caseRecord',
                            width: 450,
                            disabled: disableNode(verdictAndProblem_node),
                            disabledCls: 'none',
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('trialD_caseRecord').getValue();
                                    //触发后台保存
                                    autoSaveAtt('trialD_caseRecord', value);
                                }
                            }
                        }, {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            defaults: {margin: '5 20 5 0', labelWidth: 100},
                            items: [{
                                xtype: 'datefield',
                                fieldLabel: trialD_finalMeetingDateText,
                                name: 'trialD_finalMeetingDate',
                                id: 'trialD_finalMeetingDate',
                                format: 'Y-m-d',
                                width: 250,
                                disabled: disableNode(verdictAndProblem_node),
                                disabledCls: 'none',
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('trialD_finalMeetingDate').getValue();
                                        value = Ext.Date.format(value, 'Y-m-d')
                                        //触发后台保存
                                        autoSaveAtt('trialD_finalMeetingDate', value);
                                    }
                                }
                            }]
                        },{
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            defaults: {margin: '5 20 5 0', labelWidth: 100},
                            items: [ {
                                xtype: CtDocTypeT12Combo,
                                width: 250,
                                disabledCls: 'none',

                            },{
                                xtype: 'displayfield',
                                fieldLabel: '文件链接',
                                hidden: hideOrShow,
                                margin: '15 0 0 0',
                                labelWidth: 80,
                                name: 'trialD_tryProductProblemLink',
                                id: 'trialD_tryProductProblemLink',
                                width: 150,
                            },]
                        },{
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            defaults: {margin: '5 20 5 0', labelWidth: 100},
                            items: [{
                                xtype: CtDocTypeT13Combo,
                                fieldLabel: '试产总结报告',
                                name: 'trialD_finalReport',
                                id: 'trialD_finalReport',
                                width: 250,
                                disabledCls: 'none',

                            },{
                                xtype: 'displayfield',
                                hidden: hideOrShow,
                                fieldLabel: '文件链接',
                                margin: '25 0 0 0',
                                labelWidth: 80,
                                name: 'trialD_finalReportNumberLink',
                                id: 'trialD_finalReportNumberLink',
                                width: 150,
                            },]
                        },{
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            defaults: {margin: '5 20 5 0', labelWidth: 100},
                            items: [{
                                xtype: CtDocTypeT14Combo,
                                width: 250,
                                disabledCls: 'none',

                            },{
                                xtype: 'displayfield',
                                fieldLabel: '文件链接',
                                margin: '15 0 0 0',
                                labelWidth: 80,
                                name: 'trialD_transProductReviewLink',
                                id: 'trialD_transProductReviewLink',
                                width: 150,
                            },]
                        }
                        ]
                    }]
                }
            ]
        }]
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('newTrialItemStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/trialApply/getFormInfo?branchId=' + branchId,
                params: {
                    currentActKey: currentActKey
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == 'success') {
                        var mainPanel = Ext.getCmp('mainForm');
                        if((obj.data['head_testReport']) == '否'){
                        	 Ext.getCmp("head_testFileNumber").hide();
                        	 Ext.getCmp("head_testFileNumberLink").hide();
                        	 
                        }else{
                        	Ext.getCmp("head_testFileNumber").show();
                        	Ext.getCmp("head_testFileNumberLink").show();
                        }
                        mainPanel.getForm().setValues(obj.data);

                        ght_dataLoadedFlag = true;
                    } else {
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});

/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(dbTableName, callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/certf/insertItemData',
        params: {
            oid: oid,
            dbTableName: dbTableName,
            certfId: certfId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                callbackFn();
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}
//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}