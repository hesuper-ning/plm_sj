//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//

//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ght_dataLoadedFlag = false;
/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */

var ActivityNode_MaterialRequisition_submit='ActivityNode_MaterialRequisition_submit';
var ActivityNode_MaterialRequisition_write='ActivityNode_MaterialRequisition_write';

function disableNode(formkey) {
    if(taskCompleted == 'true') {
        return true;
    } else {
        if(formkey == currentActKey) {
            return false;
        } else {
            return true;
        }
    }
};

/** 复选框设值方法
 * @param {Ext.form.CheckboxGroup} boxGroup
 * @param {String} value
 */
function setCheckboxGroupValues(boxGroup,value){
    //加上逗号匹配更精确，防止窜位
    value = ","+value+",";
    boxGroup.items.each(function (item){
        if(value.indexOf(","+item.name+",") > -1) {
            item.setValue(true);
        }else {
            item.setValue(false);
        }
    });
}

/**
 *保存列表中的一个属性(单元格）
 * @param data
 * @param callbackFn
 */
function saveItemData(data,callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/materialRequisition/saveItemInfo' ,
        params: data,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == "success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//自动保存字段
    function autoSaveAtt(attKey, attValue) {
        var data = {
            branchId: branchId,
            attKey: attKey, //字段key
            attValue: attValue,//字段值
            activityKey: currentActKey, //全局变量，当前活动key
            oid: oid
        };
        Ext.Ajax.request({
            scope: this,
            url: '/Windchill/ptc1/materialRequisition/saveForm',
            params: {
                data: Ext.encode(data)
            },
            success: function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if (obj.message == 'success') {
                } else {
                    alert(obj.message);
                }
            },
            failure: function (response, opts) {
                alert('错误：保存信息失败，请检查网络！');
            }
        }); //~End of Ajax request
    }

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){

    var mockRec = {
        oid:oid,
        dbTableName:dbTableName,
        itemId:itemId,
        dataKey:dataKey,
        dataValue:dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/materialRequisition/saveItemData?oid='+oid,
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {

                alert(obj.message);

            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(tableName,callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/materialRequisition/insertItemData?oid='+oid,
        params: {
            branchId: branchId,
            tableName:tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                callbackFn();
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

function insertItem2Data(tableName,callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/materialRequisition/insertItem2Data?oid='+oid,
        params: {
            branchId: branchId,
            tableName:tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                callbackFn();
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


//删除grid信息
function deleteData(tableName,ids, callback) {

    var data = {
        oid:oid,
        tableName:tableName,
        ids:ids
    }

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/materialRequisition/deleteItemData',
        method: "POST",
        params: {
            data:Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message!="success") {
                Ext.Msg.alert("数据删除失败", obj.message);
            } else {
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });

}



//传入公共的参数，返回上传附件的代码
function uploadFilefield(fileName,text,node,tetx_name){
    if(text==null || text==""){
        text = "浏览...";
    }


    var inform ={
        xtype:'filefield',
        buttonOnly: true,
        id:fileName,
        name:fileName,
        labelWidth:70,
        disabled:!allowEdit,
        hideLabel: true,
        buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>'+text+'</span>',
        allowBlank: false,
        scope: this,
        listeners:{
            'change':function(fb,newValue,oldValue,opts){



                if(!newValue){
                    return;
                }

                var file = document.querySelector('[id='+fileName+'-button-fileInputEl]');
                var formData = new FormData();
                formData.append(fileName+'-button-fileInputEl', file.files[0]);
                fb.reset();//清空表单的值
                var myMask = new Ext.LoadMask({
                    msg: '正在上传，请稍候......',
                    target:this.findParentByType('panel')
                });
                myMask.show();
                $.ajax({
                    url: '/Windchill/ptc1/materialRequisition/uploadFiles?branchId='+branchId+'&tetx_name='+tetx_name+"&node="+node,
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function(res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if(!success){
                        alert(msg);
                    }else {
                        var fileName = obj['fileName'];
                        var value = Ext.getCmp(tetx_name).getValue();
                        if(value != null && value != ''){
                            fileName = value +"&nbsp;|&nbsp;" + fileName;
                        }
                        Ext.getCmp(tetx_name).setValue(fileName);
                        autoSaveAtt(tetx_name, fileName);
                    }
                }).fail(function(res) {
                    myMask.hide();
                    alert('上传失败！') ;
                });
            }
        }
    };
    return inform;
}



//删除附件
function deleteFilefield(branchId,fileName,tetx_name,node) {
    if(!allowEdit){
        alert("您没有权限删除其他用户的附件！");
        return;
    }
    // var myMask = new Ext.LoadMask({
    // 	msg: '正在删除，请稍候......',
    // 	target:Ext.getCmp('headPanel')
    // });
    // myMask.show();
    Ext.Ajax.request({
        scope : this,
        async : false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url : '/Windchill/ptc1/materialRequisition/deleteFiles',
        params : {
            branchId: branchId, fileName: fileName
        },
        success : function(response, opts) {
            // myMask.hide();
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if(!success){
                alert(msg);
            }else {
                var tRecord = Ext.getCmp('materialRequisitionGrid2').getSelectionModel().getSelection()[0];
                var attachmentValue = tRecord.data.attachment;
                var attachmentPathValue = tRecord.data.attachmentPath;
                var arr= new Array(); //定义一数组
                var arr1= new Array(); //定义一数组
                arr=attachmentValue.split("|"); //字符分割
                for (i=0;i<arr.length ;i++ ){
                    var index = arr[i].indexOf(fileName);
                    if (index > -1) {
                        arr.splice(i,1);// 删除
                    }
                }
                arr1=attachmentPathValue.toString().split("|"); //字符分割
                for (i=0;i<arr1.length ;i++ ){
                    var index = arr1[i].indexOf(fileName);
                    if (index > -1) {
                        arr1.splice(i,1);// 删除
                    }
                }
                var result = arr.join("&nbsp;|&nbsp;");
                var result1 = arr1.join("&nbsp;|&nbsp;");
                tRecord.set('attachment',result);
                tRecord.set('attachmentPath',result1);
                var itemId = tRecord.get('id');
                var callbackFn = function () {
                    tRecord.commit();
                };

                saveMockItemData('ZMRSupplierDocInfo',itemId,'attachment',result, callbackFn);
                saveMockItemData('ZMRSupplierDocInfo',itemId,'attachmentPath',result1, callbackFn);
            }
        },
        failure : function(response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });
}

//检查图纸是否存在
function checkOutDrawings(outDrawingsNumber) {

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/materialRequisition/checkOutDrawings',
        params: {
            outDrawingsNumber: outDrawingsNumber
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == 'success') {
                if (obj.data['isExist'] == 'n'){
                    alert("不存在该编号的外发图纸或文档")
                    var tRecord = Ext.getCmp('materialRequisitionGrid2').getSelectionModel().getSelection()[0];
                    var outDrawingsValue = Ext.getCmp('materialRequisitionGrid2').getSelectionModel().getSelection()[0].data.outDrawings;
                    outDrawingsValue = "";
                    tRecord.set('outDrawings',outDrawingsValue);
                }else {
                    var tRecord = Ext.getCmp('materialRequisitionGrid2').getSelectionModel().getSelection()[0];
                    var outDrawingsValue = Ext.getCmp('materialRequisitionGrid2').getSelectionModel().getSelection()[0].data.outDrawings;
                    var itemId = tRecord.get('id');
                    var callbackFn = function () {
                        tRecord.commit();
                    };
                    saveMockItemData('ZMRSupplierDocInfo',itemId,'outDrawings',outDrawingsValue, callbackFn);
                }

            } else {

                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}


/**
 * 获取项目名称
 */
function checkProjectNumber(field,number) {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/picking/checkProjectNumber',
        params:{
            projectNumber: number
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                /*if (obj.data == '<font color=red bold><b>系统中找不到该项目</b></font>'){
                    Ext.getCmp("projectNumber").setValue("")
                    Ext.getCmp("projectName").setValue("")
                    alert("系统中找不到该项目");
                    return
                }*/
                Ext.getCmp("projectName").setValue(obj.data)
                //触发后台保存
                autoSaveAtt(field,number);
            } else {
                Ext.getCmp("projectNumber").setValue("")
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：获取项目信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


function getVersion(number) {
    Ext.getStore('versionStore').load({
        params: {
            number:number,
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！');
            }
        }
    })
}

function  getSystemAttachment(docNumber,version){
    Ext.getStore('attachmentStore').load({
        params: {
            number:docNumber,
            version:version,
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！');
            }
        }
    })
}