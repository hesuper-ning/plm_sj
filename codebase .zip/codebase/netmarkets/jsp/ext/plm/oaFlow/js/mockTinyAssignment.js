Ext.define('PLM.view.assignment', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.assignment',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">微小项目任务书</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    config: {
        in_objectKey: 'assignment',
        in_objectDesc: '微小项目任务书',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;


        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '需求分析人员', dataIndex: 'data1', width: 100, editor: 'textfield'},
                {text: '硬件工程师', dataIndex: 'data2', width: 100, editor: 'textfield'},
                {text: '软件工程师', dataIndex: 'data3', width: 100, editor: 'textfield'},
                {text: '结构工程师', dataIndex: 'data4', width: 100, editor: 'textfield'},
                {text: 'ID工程师', dataIndex: 'data5', width: 100, editor: 'textfield'},
                {text: '测试工程师', dataIndex: 'data6', width: 100, editor: 'textfield'},
                {text: '工艺工程师', dataIndex: 'data7', width: 100, editor: 'textfield'},
                {text: '其他人员', dataIndex: 'data8', width: 100, editor: 'textfield'},
            ]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            title: '1.提交',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '项目名称',
                    name: 'att1',
                    id: 'att1',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '产品型号',
                    name: 'att2',
                    id: 'att2',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '所属PDT产品线',
                    name: 'att3',
                    id: 'att3',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }
                ]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    items: [{//第四行
                        xtype: 'radiogroup',
                        name: 'file1',
                        fieldLabel: '需求来源',
                        width: 350,
                        labelWidth: 100,
                        items: [{
                            inputValue: '内部需求',
                            boxLabel: '内部需求',
                            name: 'r1',
                            checked: true
                        }, {
                            inputValue: '外部需求',
                            boxLabel: '外部需求',
                            name: 'r1',
                        }]
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '部门',
                        name: 'att8',
                        id: 'att8',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '需求人',
                        name: 'att24',
                        id: 'att24',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '客户',
                        name: 'att25',
                        id: 'att25',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '需求人',
                        name: 'att26',
                        id: 'att26',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            } ,{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '具体需求内容',
                        name: 'att9',
                        id: 'att9',
                        width: 800,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{//第四行
                        xtype: 'filefield',
                        name: 'file1',
                        width: 250,
                        buttonText: '浏览',
                        fieldLabel: '文件',
                        labelWidth: 100,
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '被参考产品信息'
                    },{
                        xtype: 'textfield',
                        fieldLabel: '产品名称',
                        name: 'productName',
                        id: 'productName',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '产品型号',
                        name: 'att12',
                        id: 'att12',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 280},
                    items: [{
                        fieldLabel: '在参考产品型号基础上，对以下项目进行修改',
                        xtype: 'checkboxgroup',
                        name: 'aatt225',
                        id: 'aatt225',
                        width: 1000,
                        columns: 8,
                        items: [{
                            inputValue: '电子部分',
                            boxLabel: '电子部分',
                            name: 'r1',
                            checked: true,
                            disabledCls: 'none'
                        }, {
                            inputValue: '结构部分',
                            boxLabel: '结构部分',
                            name: 'r2',
                            disabledCls: 'none'
                        }, {
                            inputValue: '软件部分',
                            boxLabel: '软件部分',
                            name: 'r3',
                            disabledCls: 'none'
                        }, {
                            inputValue: '包装部分',
                            boxLabel: '包装部分',
                            name: 'xxx'
                        }, {
                            inputValue: '产品说明书',
                            boxLabel: '产品说明书',
                            name: 'r4',
                            id: 'r4',
                            disabledCls: 'none'
                        }, {
                            inputValue: '标牌',
                            boxLabel: '标牌',
                            name: 'r5',
                            id: 'r5',
                            disabledCls: 'none'
                        }, {
                            inputValue: '标贴',
                            boxLabel: '标贴',
                            name: 'r6',
                            id: 'r6',
                            disabledCls: 'none'
                        }, {
                            inputValue: '其他',
                            boxLabel: '其他',
                            name: 'r7',
                            id: 'r7',
                            disabledCls: 'none'
                        }]
                    },
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '电子部分详细更改内容',
                        name: 'att14',
                        id: 'att14',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textarea',
                        fieldLabel: '结构部分详细更改内容',
                        name: 'att15',
                        id: 'att15',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, , {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '软件部分详细更改内容',
                        name: 'att16',
                        id: 'att16',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textarea',
                        fieldLabel: '包装部分详细更改内容',
                        name: 'att17',
                        id: 'att17',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '产品说明书详细更改内容',
                        name: 'att18',
                        id: 'att18',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textarea',
                        fieldLabel: '标牌部分详细更改内容',
                        name: 'att19',
                        id: 'att19',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '标贴部分详细更改内容',
                        name: 'att20',
                        id: 'att20',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textarea',
                        fieldLabel: '其他部分详细更改内容',
                        name: 'att21',
                        id: 'att21',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        fieldLabel: '认证需求',
                        xtype: 'checkboxgroup',
                        name: 'aaa',
                        id: 'aaa',
                        width: 500,
                        columns: 4,
                        items: [{
                            inputValue: 'CCC',
                            boxLabel: 'CCC',
                            name: 'r1',
                            checked: true,
                            disabledCls: 'none'
                        }, {
                            inputValue: 'LPCB',
                            boxLabel: '结构部分',
                            name: 'r2',
                            disabledCls: 'none'
                        }, {
                            inputValue: 'UL',
                            boxLabel: 'UL',
                            name: 'r3',
                            disabledCls: 'none'
                        }, {
                            inputValue: 'CE',
                            boxLabel: 'UL',
                            name: 'xxx'
                        }]
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '其他认证需求',
                        name: 'att23',
                        id: 'att23',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: "panel",
                layout: 'hbox',
                defaults: {
                    margin: '5 20 0 0', labelWidth: 100, border: false,
                },
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 150},
                    items: [{
                        xtype: 'checkboxgroup',
                        fieldLabel: '制作过程及时间计划',
                        name: 'aatt22',
                        id: 'aatt22',
                        width: 800,
                        items: [{
                            inputValue: '设计实施',
                            boxLabel: '设计实施',
                            name: 'r1',
                            checked: true,
                            disabledCls: 'none'
                        }, {
                            inputValue: '测试验证',
                            boxLabel: '测试验证',
                            name: 'r2',
                            disabledCls: 'none'
                        }, {
                            inputValue: '试产验证',
                            boxLabel: '试产验证',
                            name: 'r3',
                            disabledCls: 'none'
                        }, {
                            inputValue: 'BOM创建',
                            boxLabel: 'BOM创建',
                            name: 'r4'
                        }, {
                            inputValue: '认证',
                            boxLabel: '认证',
                            name: 'r5',
                            disabledCls: 'none'
                        }, {
                            inputValue: '发布',
                            boxLabel: '发布',
                            name: 'r6',
                            disabledCls: 'none'
                        }]
                    }
                    ],
                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'datefield',
                    fieldLabel: '设计实施',
                    name: 'att237',
                    id: 'att237',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {border: false,html: '<span>至</span>'}, {
                    xtype: 'datefield',
                    name: '417',
                    id: '417',
                    width: 150,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'datefield',
                    fieldLabel: '测试验证',
                    name: 'at1',
                    id: 'at1',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {border: false,html: '<span>至</span>'}, {
                    xtype: 'datefield',
                    name: 'at2',
                    id: 'at2',
                    width: 150,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'datefield',
                    fieldLabel: '试产验证',
                    name: 'at3',
                    id: 'at3',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {border: false,html: '<span>至</span>'}, {
                    xtype: 'datefield',
                    name: 'at4',
                    id: 'at4',
                    width: 150,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'datefield',
                    fieldLabel: 'BOM创建',
                    name: 'at5',
                    id: 'at5',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {border: false,html: '<span>至</span>'}, {
                    xtype: 'datefield',
                    name: 'at6',
                    id: 'at6',
                    width: 150,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'datefield',
                    fieldLabel: '认证',
                    name: 'at7',
                    id: 'at7',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {border: false,html: '<span>至</span>'}, {
                    xtype: 'datefield',
                    name: 'at8',
                    id: 'at8',
                    width: 150,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'datefield',
                    fieldLabel: '发布',
                    name: 'at9',
                    id: 'at9',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {border: false,html: '<span>至</span>'}, {
                    xtype: 'datefield',
                    name: 'at10',
                    id: 'at10',
                    width: 150,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                title:'投入产出收益评估',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '预估投入成本',
                        name: 'att80',
                        id: 'att80',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '预估产出收益',
                        name: 'att240',
                        id: 'att240',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                title:'审批流程',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '拟制',
                        name: 'att800',
                        id: 'att800',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '批准',
                        name: 'att140',
                        id: 'att140',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            }//~end of 测试项目
            ]
        }]
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey()
                                , Ext.getCmp('simpleForm').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});