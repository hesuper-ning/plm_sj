Ext.define('PLM.view.sampleApply', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.sampleApply',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">研发样板制作申请单</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    config: {
        in_objectKey: 'sampleApply',
        in_objectDesc: '研发样板制作申请单',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;


        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: 'PCB名称', dataIndex: 'data1', width: 100, editor: 'textfield'},
                {text: '数量', dataIndex: 'data2', width: 100, editor: 'textfield'},
                {text: '制作方式', dataIndex: 'data3', width: 100, editor: 'textfield'},
                {text: '版本号', dataIndex: 'data4', width: 100, editor: 'textfield'},
                {text: '开刚网', dataIndex: 'data5', width: 100, editor: 'textfield'},
            ]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            title: '1.提交人',
            anchor: '92%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [ {//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '申请日期',
                    value:'2021-06-29',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '申请人',
                    value:'wcadmin',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '申请部门',
                    value:'硬件部',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },
                ]//~end of hbox items
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '预计完成时间',
                    name: 'att1',
                    id: 'att1',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: 'PDT产品分类',
                    name: 'att2',
                    id: 'att2',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '项目订单编码',
                    name: 'att3',
                    id: 'att3',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'textfield',
                    fieldLabel: '项目名称',
                    name: 'att4',
                    id: 'att4',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'textfield',
                    fieldLabel: '产品型号',
                    name: 'att5',
                    id: 'att5',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'combobox',
                    fieldLabel: '是否包含机贴',
                    name: 'att6',
                    id: 'att6',
                    store:[['是','是'],['否','否']],
                    width: 170,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },
                ]
            },{
                border: false,
                html: '<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;background-color: gainsboro;text-align:left">PCB列表</div>'
            },mockExampleGrid,{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{//第四行
                        xtype: 'filefield',
                        name: 'file1',
                        width:500,
                        buttonText:'浏览',
                        fieldLabel: '元器件清单',
                        labelWidth:100,
                    }
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '制作要求及注意事项',
                        name: 'att8',
                        id: 'att8',
                        width: 1000,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '开发代表',
                        name: 'att9',
                        id: 'att9',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: 'PDT经理',
                        name: 'att10',
                        id: 'att10',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                title: '2.产品工程师',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '备料情况反馈',
                        name: 'att11',
                        id: 'att11',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: '预计完成时间',
                        name: 'att12',
                        id: 'att12',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '其他说明',
                        name: 'att13',
                        id: 'att13',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },,{
                xtype: 'panel',
                layout: 'hbox',
                title: '3.技术部',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: 'SMT编程',
                        name: 'att14',
                        id: 'att14',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: '预计完成时间',
                        name: 'att15',
                        id: 'att15',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '其他说明',
                        name: 'att16',
                        id: 'att16',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },,{
                xtype: 'panel',
                layout: 'hbox',
                title: '4.采购部',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '钢网采购情况',
                        name: 'att17',
                        id: 'att17',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: '预计完成时间',
                        name: 'att18',
                        id: 'att18',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '其他物料采购情况',
                        name: 'att19',
                        id: 'att19',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: '预计完成时间',
                        name: 'att20',
                        id: 'att20',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },,{
                xtype: 'panel',
                layout: 'hbox',
                title: '5.物控部',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '钢网套齐时间',
                        name: 'att21',
                        id: 'att21',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: '预计完成时间',
                        name: 'att22',
                        id: 'att22',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '其他说明',
                        name: 'att23',
                        id: 'att23',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },{
                xtype: 'panel',
                title:'6.研发部验收',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100,border: false,},
                items: [ {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '完成情况',
                        name: 'att24',
                        id: 'att24',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            },//~end of 测试项目
            ]
        }]
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey()
                                , Ext.getCmp('simpleForm').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});