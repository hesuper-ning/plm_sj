//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//


var head_node = 'head_node'; //设计更改发起
var pdt_node = 'pdt_node'; //设计更改发起


//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ght_dataLoadedFlag = false;

/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */
function disableNode(formkey) {
    if (taskCompleted === 'true') {
        return false;
    } else {
        if (formkey === currentActKey) {
            return true;
        } else {
            return false;
        }
    }
};

/** 复选框设值方法
 * @param {Ext.form.CheckboxGroup} boxGroup
 * @param {String} value
 */
function setCheckboxGroupValues(boxGroup, value) {
    //加上逗号匹配更精确，防止窜位
    value = "," + value + ",";
    boxGroup.items.each(function (item) {
        if (value.indexOf("," + item.name + ",") > -1) {
            item.setValue(true);
        } else {
            item.setValue(false);
        }
    });
}

//获取部门名称
function getDepartment(dDemander) {

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/tinyAssignment/getDepartmentName',
        params: {
            dDemander: dDemander
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == 'success') {
                Ext.getCmp("department").setValue(obj.data['departmentName']);
                autoSaveAtt('department', obj.data['departmentName']);

            } else {
                Ext.getCmp("department").setValue(null);
                autoSaveAtt('department', null);
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

function tranFlag(flag) {
    if (flag == 'true') {
        return true;
    } else {

        return false;

    }
}

//自动保存字段
function autoSaveAtt(attKey, attValue, isAsync) {
    if (!disableNode(head_node)) return;
    let isAsyncTTT = true;
    if (isAsync === false) isAsyncTTT = false;
    console.log(isAsync, isAsyncTTT);
    // alert(attKey);
    var data = {
        branchId: branchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKey, //全局变量，当前活动key
        oid: containerId
    };
    Ext.Ajax.request({
        scope: this,
        async: isAsyncTTT,
        url: '/Windchill/ptc1/tinyAssignment/saveForm',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == 'success') {

            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

//获取产品型号
function getProductType(productNumber) {

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/tinyAssignment/getProductTypeAndProductName',
        params: {
            productNumber: productNumber
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == 'success') {
                Ext.getCmp("productType").setValue(obj.data['productType']);
                autoSaveAtt('productType', obj.data['productType']);

            } else {
                Ext.getCmp("productType").setValue(null);
                autoSaveAtt('productType', null);
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

//获取产品型号和产品名称
function getProductTypeAndProductName(cProductNumber) {

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/tinyAssignment/getProductTypeAndProductName',
        params: {
            productNumber: cProductNumber
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == 'success') {
                Ext.getCmp("cProductType").setValue(obj.data['productType']);
                Ext.getCmp("cProductName").setValue(obj.data['productName']);
                autoSaveAtt('cProductType', obj.data['productType']);
                autoSaveAtt('cProductName', obj.data['productType']);

            } else {
                Ext.getCmp("productType").setValue(null);
                autoSaveAtt('productType', null);
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

//获取项目名称
function getProjectName(projectNumber) {

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/tinyAssignment/getProjectName',
        params: {
            projectNumber: projectNumber
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == 'success') {
                Ext.getCmp("projectName").setValue(obj.data['projectName']);
                autoSaveAtt('projectName', obj.data['projectName']);

            } else {
                Ext.getCmp("projectName").setValue(null);
                autoSaveAtt('projectName', null);
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

//传入公共的参数，返回上传附件的代码
function uploadFilefield(fileName, text, node, tetx_name) {
    if (text == null || text == "") {
        text = "浏览...";
    }

    var inform = {
        xtype: 'filefield',
        buttonOnly: true,
        disabled: !disableNode(node),
        id: fileName,
        name: fileName,
        labelWidth: 100,
        width: 230,
        hideLabel: true,
        buttonText: '<div style="width:200px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + text + '</div>',
        allowBlank: false,
        scope: this,
        listeners: {
            'change': function (fb, newValue, oldValue, opts) {
                if (!newValue) {
                    return;
                }
                var file = document.querySelector('[id=' + fileName + '-button-fileInputEl]');
                var formData = new FormData();
                formData.append(fileName + '-button-fileInputEl', file.files[0]);
                fb.reset();//清空表单的值
                var myMask = new Ext.LoadMask({
                    msg: '正在上传，请稍候......',
                    target: this.findParentByType('panel')
                });
                myMask.show();
                $.ajax({
                    url: '/Windchill/ptc1/tinyAssignment/uploadFiles?branchId=' + branchId + '&tetx_name=' + tetx_name + "&node=" + node,
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function (res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if (!success) {
                        alert(msg);
                    } else {
                        var fileName = obj['fileName'];
                        var value = Ext.getCmp(tetx_name).getValue();
                        if (value != null && value != '') {
                            fileName = value + "&nbsp;|&nbsp;" + fileName;
                        }
                        Ext.getCmp(tetx_name).setValue(fileName);
                        autoSaveAtt(tetx_name, fileName);
                    }
                }).fail(function (res) {
                    myMask.hide();
                    alert('上传失败！');
                });
            }
        }
    };
    return inform;
}

//删除附件
function deleteFilefield(branchId, fileName, tetx_name) {
    if (!allowEdit) {
        alert("当前没有权限删除附件！");
        return;
    }
    // var myMask = new Ext.LoadMask({
    // 	msg: '正在删除，请稍候......',
    // 	target:Ext.getCmp('headPanel')
    // });
    // myMask.show();
    Ext.Ajax.request({
        scope: this,
        async: false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url: '/Windchill/ptc1/tinyAssignment/deleteFiles',
        params: {
            branchId: branchId, fileName: fileName
        },
        success: function (response, opts) {
            // myMask.hide();

            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if (!success) {
                alert(msg);
            } else {
                let cmp = Ext.getCmp(tetx_name);
                let value = "";
                if (cmp === undefined) {
                    Ext.getCmp('itemUpdateGrid').getStore().each(function (record, index) {
                        // 获取当前记录的所有字段名
                        let fields = record.getData();
                        if (tetx_name.indexOf(fields.id) > -1) {
                            value = fields.fileLink;
                        }
                    })
                } else {
                    value = Ext.getCmp(tetx_name).getValue();
                }

                var arr = new Array(); //定义一数组
                arr = value.split("|"); //字符分割
                for (i = 0; i < arr.length; i++) {
                    var index = arr[i].indexOf(fileName);
                    if (index > -1) {
                        arr.splice(i, 1);// 删除
                    }
                }
                var result = arr.join("&nbsp;|&nbsp;");
                if (cmp === undefined) {

                } else {
                    cmp.setValue(result);
                }
                autoSaveAtt(tetx_name, result);
                Ext.getCmp('itemUpdateGrid').getStore().load();
            }
        },
        failure: function (response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveItemData(dbTableName, itemId, dataKey, dataValue, callbackFn) {

    var returnItemId = undefined;
    var mockRec = {
        oid: containerId,
        dbTableName: dbTableName,
        itemId: itemId,
        dataKey: dataKey,
        dataValue: dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/tinyAssignment/saveItemInfo',
        params: {
            updateRecord: Ext.encode(mockRec)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}

//旧表单中，用于被参考的产品信息的item项的插入
function insertItemData(callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/tinyAssignment/insertItemData?oid=' + containerId,
        params: {
            docBranchId: branchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == "success") {
                callbackFn();
            } else {
                alert(obj['error'] + "9999");
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//删除grid信息
function deleteItemData(tableName, ids, callback) {
    var tmpGrid = Ext.getCmp('tinyAssignmentGrid');

    var myMask = new Ext.LoadMask({msg: "数据正在处理中，请稍后...", target: tmpGrid});
    myMask.show();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/tinyAssignment/deleteItemData',
        method: "POST",
        params: {
            oid: containerId,
            data: Ext.encode(ids),
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['error']);
                myMask.hide();
            } else {
                myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

//获取产品型号
function getWorkTime() {
    debugger;
    var value1 = Ext.getCmp('demandAnalysisQuantity').getValue();
    var value2 = Ext.getCmp('hardwareQuantity').getValue();
    var value3 = Ext.getCmp('softwareQuantity').getValue();
    var value4 = Ext.getCmp('structureQuantity').getValue();
    //var value5 = Ext.getCmp('idEngineerQuantity').getValue();
    //var value6 = Ext.getCmp('testEngineerQuantity').getValue();
    var value6 = Ext.getCmp('testEngineer_testQuantity').getValue();
    var value7 = Ext.getCmp('craftQuantity').getValue();
    var value8 = Ext.getCmp('otherStaffsQuantity').getValue();
    var value9 = Ext.getCmp('packagingQuantity').getValue();
    var value10 = Ext.getCmp('npiQuantity').getValue();
    /*var value11 = Ext.getCmp('electronicsQuantity').getValue();*/
    var value12 = Ext.getCmp('industrialDesignQuantity').getValue();
    var value13 = Ext.getCmp('powerQuantity').getValue();
    var value14 = Ext.getCmp('testEngineer_engineeringQuantity').getValue();
    var value15 = Ext.getCmp('tqcQuantity').getValue();
    var value = value1 * 1000000 + value2 * 1000000 + value3 * 1000000 + value4 * 1000000 + /*value5*/
        +value6 * 1000000 + value7 * 1000000 + value8 * 1000000 + value9 * 1000000
        + value10 * 1000000 + /*value11*/ +value12 * 1000000 + value13 * 1000000 + value14 * 1000000 + value15 * 1000000;
    return value / 1000000;
}

function setSumManDay(day) {


    Ext.getCmp('sumManDay').setValue(day);
    //触发后台保存
    autoSaveAtt('sumManDay', day);
}

//初始化时，设置研发拓展组名单的combobox以及下面的工时 -- 这个combobox改成只选择，不做初始化，所以弃用了
function setExpansionTeamsCombobox_弃用(initialData, userComboboxId, jobEvaluationQuantityComboboxId) {
    if (!initialData[userComboboxId]) {
        //2024/09/15 改为不管人员有没有值都可以填写工作量
        //Ext.getCmp(jobEvaluationQuantityComboboxId).disable();
        //Ext.getCmp(jobEvaluationQuantityComboboxId).setValue('');
    } else {
        Ext.getCmp(jobEvaluationQuantityComboboxId).enable();
        //设置值
        let user = initialData[userComboboxId].split(", ");
        Ext.getCmp(userComboboxId).setValue(user);
    }
}

//初始化时，设置研发拓展组名单的combobox以及下面的工时
function setExpansionTeamsCombobox(initialData, userComboboxId, jobEvaluationQuantityComboboxId) {

}


//编辑研发拓展组名单的combobox以及下面的工时 -- 这个combobox改成只选择，不做初始化，所以弃用了
function setExpansionTeamsValueByCombobox_弃用(e, comboboxId, jobEvaluationQuantityComboboxId) {
    let alertMsg = "";
    let combo = Ext.getCmp(comboboxId);
    let rawValue = Ext.getCmp(comboboxId).getRawValue();
    var selectedValues = combo.getValue(); // 获取选中项的值
    if (!rawValue) {
        Ext.getCmp(comboboxId).setValue('');
        //2024/09/15 改为不管人员有没有值都可以填写工作量
        // Ext.getCmp('demandAnalysisQuantity').setValue('');
        // Ext.getCmp('demandAnalysisQuantity').disable();
        // autoSaveAtt('demandAnalysisQuantity', '');·
    } else {
        if (selectedValues == null) {
            Ext.getCmp(comboboxId).setValue('');
            selectedValues = combo.getValue(); // 获取选中项的值
            alertMsg = "输入数据有误，请从选择框中选择数据";
        }
        Ext.getCmp(jobEvaluationQuantityComboboxId).enable();
    }
    // 获取所有选中的记录
    let selectedRecords = selectedValues.map(value => combo.findRecordByValue(value));
    // 提取每个记录的 'loginName'
    let loginNames = selectedRecords.map(record => record.get('loginName')).join(',');
    //如果存在值则将数据
    let value = Ext.getCmp(comboboxId).getValue();
    let sendValue = '';
    if (value.length > 0) {
        sendValue = '';
        for (let valueKey in value) {
            sendValue = sendValue + value[valueKey] + ", ";
        }
    }
    if (sendValue.length > 0) {
        sendValue = sendValue.substring(0, sendValue.length - 2);
    }
    //触发后台保存
    autoSaveAtt(comboboxId, sendValue);
    autoSaveAtt(comboboxId + "UserName", loginNames);
    if (alertMsg) alert(alertMsg);
}

function setExpansionTeamsValueByCombobox(e, comboboxId, jobEvaluationQuantityComboboxId) {

}

//combobox多选设置
function setValueByMultiSelectCombobox(e, comboboxId) {
    let rawValue = Ext.getCmp(comboboxId).getRawValue();
    if (!rawValue) {
        Ext.getCmp(comboboxId).setValue('');
    }
    //如果存在值则将数据
    let value = Ext.getCmp(comboboxId).getValue();
    let sendValue = '';
    if (value.length > 0) {
        sendValue = '';
        for (let valueKey in value) {
            sendValue = sendValue + value[valueKey] + ",";
        }
    }
    if (sendValue.length > 0) {
        sendValue = sendValue.substring(0, sendValue.length - 1);
    }
    //触发后台保存
    autoSaveAtt(comboboxId, sendValue);
}

//combobox多选初始化
function initialValueByMultiSelectCombobox(initialData, userComboboxId) {
    //设置值
    if (initialData[userComboboxId] !== undefined && initialData[userComboboxId] !== null
        && initialData[userComboboxId] !== 'null'
    ) {
        debugger;
        let user = initialData[userComboboxId].split(",");
        Ext.getCmp(userComboboxId).setValue(user);
    }
}

/**
 * 弹出查询面板：查询产品型号信息
 * @param targetGrid
 */
// region 弹出查询界面

Ext.define('ProductModel', {
    extend: 'Ext.data.Model',
    fields: ['型号', '成品编号', '成品描述']
});

// 创建数据存储
let addForm = Ext.create('Ext.form.Panel', {
    id: 'addExperienceForm',
    name: 'addExperienceForm',
    xtype: 'form',
    border: false,
    items: [
        {
            layout: 'hbox',
            border: false,
            margin: '30 5 10 30',
            items: [
                {
                    xtype: 'textfield',
                    hidden: true,
                    id: 'add_id',
                    name: 'add_id'
                },
                //隐藏参数，点进来的表格数据，用于需要排除的产品型号
                {
                    xtype: 'textfield',
                    margin: '0 20 10 0',
                    width: 250,
                    hidden: true,
                    id: 'gridData',
                    name: 'gridData',
                    labelWidth: 90
                },
                //产品型号
                {
                    xtype: 'textfield',
                    fieldLabel: '<span style="color: red" >*</span>产品型号(加*模糊查询)',
                    margin: '0 20 10 0',
                    width: 300,
                    id: 'add_productName',
                    name: 'add_productName',
                    labelWidth: 150
                },
                //查询
                {
                    xtype: 'button',
                    text: '查询',
                    margin: '0 0 0 30',
                    handler: function () {


                        let form = this.up('form').getForm(); // 获取表单模型
                        if (form.isValid()) { // 检查表单是否有效
                            let formData = form.getValues(); // 获取表单中的所有值
                            console.log(formData);
                            // 在这里处理数据，例如发送到服务器
                            ecContentStore.load(
                                {
                                    params: formData
                                }
                            );
                        }

                    },
                }]
        }
    ]
});

Ext.define('ecContentModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'docBranchId', 'cProductNumber', 'cProductName', 'cProductType'],
    idProperty: 'id'
});

var ecContentStore = Ext.create('Ext.data.Store', {
    model: 'ecContentModel',
    id: 'ecContentStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/tinyAssignment/searchPartByProductType',
        method: 'GET',
        extraParams: {},
        reader: {
            type: 'json',
            root: 'items',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: false
});

var ecContentGrid = Ext.create('Ext.grid.Panel', {
    plugins: false,
    title: '',
    store: ecContentStore,
    id: 'ecContentGrid',
    autoWidth: true,
    autoScroll: true,
    region: 'center',
    height: 220,
    margin: '0 0 20 0',
    multiSelect: false,
    viewConfig: {enableTextSelection: true},
    selModel: Ext.create('Ext.selection.CheckboxModel', {mode: "SIMPLE", showHeaderCheckbox: true}),
    columns: [
        {
            xtype: 'rownumberer',
            text: '序号',
            width: 60,
            align: 'center',
            menuDisabled: true
        },
        {
            text: '产品型号',
            dataIndex: 'cProductType',
            width: 280,
            editor: 'textfield',
            menuDisabled: true,
            renderer: function (value, metaData, record, row, col, store) {
                metaData.tdAttr = 'data-qtip="' + value + '"';
                return value;
            }
        },
        {
            text: '产品编码',
            dataIndex: 'cProductNumber',
            editor: 'textfield',
            width: 280,
            menuDisabled: true,
            renderer: function (value, metaData, record, row, col, store) {
                metaData.tdAttr = 'data-qtip="' + value + '"';
                return value;
            }
        },
        {
            text: '产品名称',
            dataIndex: 'cProductName',
            editor: 'textfield',
            width: 280,
            menuDisabled: true,
            renderer: function (value, metaData, record, row, col, store) {
                metaData.tdAttr = 'data-qtip="' + value + '"';
                return value;
            }
        }

    ],
    listeners: {
        beforeedit: function (editor, obj, e) {
            var tField = obj.field; //得到修改列
            if (!allowEdit) return false;
        },
        edit: function (editor, obj, e) {
            console.log(editor)
            console.log(obj)
            var tRecord = obj.record; //得到当前行所有数据
            var tField = obj.field; //得到修改列
            var tValue = obj.value; //得到修改列修改后值
            var originalValue = obj.originalValue; //得到未修改的值
            var id = tRecord.get('id');

            // 如果旧的值与新的值一致，不做保存操作
            if (originalValue == tValue) {
                tRecord.reject();
                return;
            }

            if (!tRecord.get('branchId')) {
                tRecord['data']['className'] = className;
                tRecord['data']['branchId'] = branchId;
            }
            var params = {
                url: '/Windchill/ptc1/changeModel/content?editField=' + tField,
                method: 'POST',
                params: tRecord['data'],
                successCFN: function (data) {
                    tRecord['data'] = data;
                    tRecord.commit();
                },
                failCFN: function () {
                    tRecord.reject();
                }
            };
            doRequest(params)
        }
    }
});

var requireWin2 = Ext.create('Ext.Window', {
    id: 'requireWin2',
    title: '添加产品型号',
    width: 1050,
    //height: 300,
    autoHeight: true,
    closeAction: 'hide',
    //closable:false,
    x: 200,
    y: 80,    //设置窗口左上角位置
    constrain: true,
    modal: true,
    items: [
        addForm, ecContentGrid
    ],
    buttons: [
        //保存
        {
            xtype: "button",
            text: "添加",
            handler: function () {
                debugger;
                //需要保存的数据
                let saveDataList = [];
                let selection = ecContentGrid.getSelectionModel().getSelection();
                selection.forEach(function (record) {
                    saveDataList.push(record.data);
                });
                //grid的ID用于判断保存到哪一张表
                let id = fromGrid.id;
                let dbTableName = '';
                if (id === 'tinyAssignmentGrid') {
                    dbTableName = 'ZtinyAssignmentNewItem';
                } else if (id === 'tinyAssignmentGrid2') {
                    dbTableName = 'ZtinyAssignmentNewItem2';
                }
                //先定义成功猴的回调函数
                let callbackFn = function () {
                    //刷新被标记的表格数据
                    fromGrid.getStore().reload();
                };
                //调用后台，保存数据
                insertItemDataBySelectData(callbackFn, saveDataList, dbTableName);
                //关闭
                Ext.getCmp('requireWin2').close();
            }
        },
        //取消
        {
            xtype: "button",
            text: "取消",
            handler: function () {
                Ext.getCmp('requireWin2').close();
            }
        }],
    listeners: {
        close: function () {
            Ext.getCmp('addExperienceForm').getForm().reset();
        }
    }


});

let fromGrid; //用于标记是哪个表格点击的，即targetGrid
function showSelectionWindow(targetGrid) {
    fromGrid = targetGrid;
    let gridData = [];
    let store = targetGrid.getStore();
    let records = store.getRange(); // 获取 store 中的所有记录
    records.forEach(function (record) {
        gridData.push(record.data);
    });
    Ext.getCmp('gridData').setValue(Ext.encode(gridData));

    //先清空弹窗的表格
    ecContentStore.loadData([]);
    // 显示弹窗
    requireWin2.show();
}

//参考方法：insertItemData
function insertItemDataBySelectData(callbackFn, saveDataList, dbTableName) {
    debugger;
    Ext.Ajax.request({
        url: '/Windchill/ptc1/tinyAssignment/insertItemDataBySelectData?oid=' + containerId,
        params: {
            docBranchId: branchId,
            saveDataList: Ext.encode(saveDataList),
            dbTableName: dbTableName,
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message === "success") {
                callbackFn();
            } else {
                alert(obj['error'] + "9999");
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}


//endregion

/**
 * 制作过程选择checkbox时触发，取消选择时禁用开始时间，结束时间，并清空值
 */
function changeProcessGroup(checkboxValue, flag, startTime, endTime) {
    Ext.getCmp(startTime).disable();
    Ext.getCmp(endTime).disable();
    if (checkboxValue.indexOf(flag) > -1) {
        Ext.getCmp(startTime).enable();
        Ext.getCmp(endTime).enable();
    } else {
        Ext.getCmp(startTime).setValue();
        Ext.getCmp(endTime).setValue();
        //触发后台保存
        let time = Ext.Date.format("", "Y-m-d");
        autoSaveAtt(startTime, time);
        autoSaveAtt(endTime, time);
    }
}

/**
 * 规划情况：规划内时，展示项目名称和项目编码且必填
 *            规划外时，隐藏项目名称和项目编码，并移除值
 */
function changeValue_planningSituation() {

    let value = Ext.getCmp('planningSituation').getRawValue();
    //如果值为规划内，则规划项目名称 / 规划项目编号字段必填；
    let planningProjectNameLabelEl = document.getElementById("planningProjectNameLabel-innerCt");
    let planningProjectNumberLabelEl = document.getElementById("planningProjectNumberLabel-innerCt");
    let planningProjectNameCmp = Ext.getCmp('planningProjectName');
    let planningProjectNumberCmp = Ext.getCmp('planningProjectNumber');
    if (value === '规划内') {
        planningProjectNameLabelEl.classList.remove('colorGrey');
        planningProjectNumberLabelEl.classList.remove('colorGrey');
        planningProjectNameCmp.setReadOnly(false);
        planningProjectNumberCmp.setReadOnly(false);
    } else {//规划外
        planningProjectNameLabelEl.classList.add('colorGrey');
        planningProjectNumberLabelEl.classList.add('colorGrey');
        planningProjectNameCmp.setReadOnly(true);
        planningProjectNameCmp.setValue();
        planningProjectNumberCmp.setReadOnly(true);
        planningProjectNumberCmp.setValue();
    }

}

/**
 * 选择用户通过下拉
 */
function saveFormForExpansionGroupUserBySelect(e, records) {
    debugger;
    let combo = e;
    let selectedValues = e.getValue();
    let findRecordByValue = combo.findRecordByValue(selectedValues);
    // 提取每个记录的 'loginName'
    //if (records.length > 0) { //多选用这个
    //if (records ) {

    //let selectedRecord = records[0]; // 获取第一个选择的记录 多选？
    //let selectedRecord = findRecordByValue; // 获取第一个选择的记录
    let loginName = findRecordByValue.get('loginName'); // 用户名
    let name = findRecordByValue.get('name'); // 名字

    let comboboxId = e.getId();
    let inputId = comboboxId.replace('_combobox', '');
    let carbonCopyAutomatic = Ext.getCmp(inputId).getValue();
    let carbonCopyAutomaticList = carbonCopyAutomatic.split(",");
    for (let i = 0; i < carbonCopyAutomaticList.length; i++) {
        if (name === carbonCopyAutomaticList[i]) {
            //alert("当前选择的人员已添加");
            return;
        }
    }
    //保存数据
    // alert(attKey);
    let data = {
        branchId: branchId,
        attKey: comboboxId, //字段key
        attValue: name,//字段值
        activityKey: currentActKey, //全局变量，当前活动key
        oid: containerId
    };
    Ext.Ajax.request({
        scope: this,
        async: false,
        url: '/Windchill/ptc1/tinyAssignment/saveFormForExpansionGroupUserBySelect',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            debugger;
            let obj = Ext.decode(response.responseText);
            if (obj.message === 'success') {
                console.log(obj['data']);
                Ext.getCmp(inputId).setValue(obj['data'])
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    });

    //}

}

/**
 * 选择用户通过输入框
 */
function saveFormForExpansionGroupUserByInput(e) {
    let value = e.getValue();
    let id = e.getId();
    let data = {
        branchId: branchId,
        attKey: id, //字段key
        attValue: value,//字段值
        activityKey: currentActKey, //全局变量，当前活动key
        oid: containerId
    };
    Ext.Ajax.request({
        scope: this,
        async: false,
        url: '/Windchill/ptc1/tinyAssignment/saveFormForExpansionGroupUserByInput',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj.message === 'success') {
                console.log(obj['data']);
                e.setValue(obj['data'])
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    });
}


//-----------偏通用
/**
 * 通过鼠标悬浮事件，在鼠标旁边显示提示文字
 */


function showTooltip(a) {

    let tooltipElement = document.getElementById("customTip");
    console.log(a.getValue());
    if (!tooltipElement) {
        tooltipElement = document.createElement('div');
        tooltipElement.className = 'tooltip';
        tooltipElement.id = 'customTip';
        document.body.appendChild(tooltipElement);
    }
    if (a.getValue()) {
        tooltipElement.textContent = a.getValue();
        tooltipElement.style.display = 'block';
        tooltipElement.style.left = event.clientX + 10 + 'px';
        tooltipElement.style.top = event.clientY + 10 + 'px';
    }

    //相关样式
    /*.tooltip {
            position: absolute;
            background-color: #e2eff9;
            padding: 5px 10px;
            border-radius: 5px;
            z-index: 1000;
            display: none;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /!* 水平偏移，垂直偏移，模糊半径，颜色 *!/
        }*/
}

function setShowTip(cmpId) {
    let textField = Ext.getCmp(cmpId);
    if (textField) {
        textField.el.on({
            mouseenter: function () {
                showTooltip(textField);
            },
            mouseleave: function () {
                hideTooltip(textField);
            }
        });
    }
}

/**
 * 通过鼠标移开事件，在隐藏鼠标旁边的文字
 */
function hideTooltip() {
    let tooltipElement = document.getElementById("customTip");
    if (tooltipElement) {
        tooltipElement.style.display = 'none';
    }
}

