var clickRecordData;
var submit_node = "submit_node";//提交
var rd_node = "rd_node";//研发工程师
var tech_node = "tech_node";//检测技术部
var sw_node = "sw_node";//软件研发部
var rdManage_node = "rdManage_node";//研发管理部

//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ct_dataLoadedFlag = false;
Ext.define('PLM.view.SoftwareBurningPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.SoftwareBurningPanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'softwareBurningPanel',
    initComponent: function () {
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var authDaysText = '授权期限(天)';
        var partNumberText = '成品/半成品物料编码';
        var isTestVersionText = '是否为测试版本或特殊软件';
        var batchNumberText = '正常生产批号';
        var toAccessPeopleText= '授权人';
        var softwarePartNumText = '软件物料料号';
        var softwareDocType = '软件文档类型';
        var softwareDocStateText = '软件文档状态';
        var softwareDocNumText = '软件文档编号';
        var softwareDocNumLinkText = '软件文档编号链接';
        var softwareDocVersionsText = '软件文档版本(Bate版本软件适用)';
        var innerVersionText = '软件文档内部版本';``
        var amountText = '数量';
        var otherNumberText = '扩容码';
        var otherDescriptionText = '其他情况说明';
        var softwareDownLoadUserList = '软件下载权限需求人清单';
        var softwareReviewerText = '审核人'; //软件工程师审核
        var softwareReviewCommentText = '审核意见'; //软件工程师审核
        var softwareReviewRemarksText = '备注'; //软件工程师审核
        var testReviewerText = '审核人'; //测试部审核
        var testReviewCommentText = '审核意见'; //测试部审核
        var testReviewRemarksText = '备注'; //测试部审核
        if(!disableNode(submit_node)){
            authDaysText =redStarFlag+blueFlagStart+ authDaysText +blueFlagEnd;
            partNumberText =redStarFlag+ blueFlagStart+ partNumberText +blueFlagEnd;
            isTestVersionText =redStarFlag+blueFlagStart+ isTestVersionText +blueFlagEnd;
            batchNumberText =redStarFlag+blueFlagStart+ batchNumberText +blueFlagEnd;
            otherDescriptionText =blueFlagStart+ otherDescriptionText +blueFlagEnd;
            toAccessPeopleText =blueFlagStart+ toAccessPeopleText +blueFlagEnd;

            softwarePartNumText =blueFlagStart+ softwarePartNumText +blueFlagEnd;
            softwareDocType =blueFlagStart+ softwareDocType +blueFlagEnd;
            softwareDocNumText =redStarFlag+blueFlagStart+ softwareDocNumText +blueFlagEnd;
            amountText =redStarFlag+blueFlagStart+ amountText +blueFlagEnd;
            softwareDocVersionsText =blueFlagStart+ softwareDocVersionsText +blueFlagEnd;
        }

        if (whetherPDMEngineerReview) { //产品工程师
            softwareReviewerText = blueFlagStart + softwareReviewerText + blueFlagEnd;
            otherNumberText = blueFlagStart + otherNumberText + blueFlagEnd;
        }

        if (whetherEngineer) { //软件工程师
            softwareReviewerText = blueFlagStart + softwareReviewerText + blueFlagEnd;
            softwareDocVersionsText = blueFlagStart + softwareDocVersionsText + blueFlagEnd;
            otherNumberText = blueFlagStart + otherNumberText + blueFlagEnd;
            softwareReviewCommentText = blueFlagStart + softwareReviewCommentText + blueFlagEnd;
            softwareReviewRemarksText = blueFlagStart + softwareReviewRemarksText + blueFlagEnd;

        }

        if (whetherTester) { //测试
            testReviewCommentText = blueFlagStart + testReviewCommentText + blueFlagEnd;
            testReviewRemarksText = blueFlagStart + testReviewRemarksText + blueFlagEnd;
        }



        var me = this;

        var emptyPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            padding:'5',
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%'
        });
        //hr集成
        Ext.define('PLM.hr.CtAllUserStoreByNo',{
            extend:'Ext.data.Store',
            alias:'widget.CtAllUserStore',
            fields:['userFullName','userNo'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/hr/getAllUser',
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad:true
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStoreByNo', {
            storeId: 'allUserStore_projectPlan'
        });


        //========== 开始  chipTypeGrid=======================
        //芯片种类表格-Model
        Ext.define('chipTypeModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','docBranchId','softwareDocNum','attachment','softwarePartNum',
                'softwareDocNumLink','softwarePartName','softwareDocVersions','amount', 'innerVersion',
                'softwareDocType','softwareReviewer','softwareReviewComment','softwareReviewRemarks',
                'testReviewer','testReviewComment','testReviewRemarks','softwareDocState',
                'lastTimeReviewer','lastTimeReviewComment','lastTimeReviewRemarks',
            ],
            idProperty: 'id'
        });

        //芯片种类表格-Store
        this.chipTypeStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'chipTypeModel',
            id:'chipTypeStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/softwareBurning/getChipTypeItems',
                params:{
                    docBranchId:Ext.encode(docBranchId),
                },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });
        //软件文档类型-combobox-Store
        let softwareDocTypeStore = new Ext.data.ArrayStore({
            id: 'softwareDocTypeStore',
            fields: ['text'],
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/softwareBurning/getSoftwareDocType',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false,
            listeners: {
                load: function(store, records, successful, operation) {
                    if (!successful) {
                        // 请求失败时处理
                        let responseText = operation.getError().response.responseText;
                        let response = JSON.parse(responseText);
                        alert(response.msg);
                    }
                },
                exception: function(proxy, response, operation) {
                    // 捕获异常并显示错误信息
                    Ext.Msg.alert('错误', '请求出现异常: ' + response.status + ' ' + response.statusText);
                }
            }
        });
        //软件文档类型-combobox
        var softwareDocTypeCombobox = new Ext.form.ComboBox({
            name: 'softwareDocTypeCombobox',
            id: 'softwareDocTypeCombobox',
            multiSelect: false,
            valueField: 'text',
            displayField: 'text',
            anyMatch: true,
            editable: false,
            store: softwareDocTypeStore,
            listeners:{
                beforequery: function (queryPlan) {
                    let p = Ext.encode(clickRecordData);
                    queryPlan.query = p;
                    return true;
                },
            }
        });

        //软件文档编码-combobox-Store
        var docNumberStore = new Ext.data.ArrayStore({
            id: 'docNumberStore',
            fields: ['text'],
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/softwareBurning/getDocNumbers',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });
        //软件文档编码-combobox
        var docNumbers = new Ext.form.ComboBox({
            name: 'docNumbers',
            id: 'docNumbers',
            multiSelect: false,
            valueField: 'text',
            displayField: 'text',
            anyMatch: true,
            editable: false,
            store: docNumberStore,
            listeners:{
                beforequery: function (queryPlan) {
                    let p = Ext.encode(clickRecordData);
                    queryPlan.query = p;
                    return true;
                },
            }
        });
        var query='';
        var versionStore = new Ext.data.ArrayStore({
            id: 'versionStore',
            fields: ['version'],
            autoSync: true,//同步更新
            // pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/softwareBurning/getVersion',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'items',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message',
                    query:query
                },
                params: {
                    docNumber:query
                },
            }),
            autoLoad: false,
            // proxy: {
            //     type: 'ajax',
            //     url: '/Windchill/ptc1/softwareBurning/getVersion',
            //     reader: {
            //         type: 'json',
            //         rootProperty: 'items'
            //     }
            // },
            // autoLoad: false
        });
        var versionComboBox = new Ext.form.ComboBox({
            name: 'versionComboBox',
            id: 'versionComboBox',
            multiSelect: false,
            valueField: 'version',
            displayField: 'version',
            // anyMatch: true,
            editable : false,
            mode:'local',
            queryMode: 'local',
            // mode : 'local',
            store: versionStore
        });

        Ext.define('ctAllUserModel', {
            extend: 'Ext.data.Model',
            fields:['no' ,'riskId']
        });

        //获取使用人名单，全部人
        var theUserStore = Ext.create('PLM.hr.CtAllUserStore',{
            storeId:'theUserStore'
        });


        //用户 Combobox
        var theUserCombo = Ext.create('PLM.common.CtAllUserCombo',{
            width : 250,
            //fieldLabel: head_designatedPerson,
            store:theUserStore,
            name: 'head_designatedPerson',
            id: 'head_designatedPerson',
            displayField: 'userFullName',
            valueField: 'no',
            //disabled: !disableNode(submit_node),
            disabledCls: 'none',
            listeners: {
                select: function (e) {
                    if (allowEdit){
                        var value = Ext.getCmp('head_designatedPerson').getValue();
                        //触发后台保存
                        autoSaveAtt('head_designatedPerson', value);}
                }
            }
        });



        //审核意见 Store
        var reviewCommentStore = Ext.create('Ext.data.Store', {
            fields: ['id', 'name'],
            data: [
                {  name: '通过' },
                {  name: '驳回' },
            ]
        });
        //审核意见 Combobox
        var reviewCommentCombobox = new Ext.form.ComboBox({
            store: reviewCommentStore,
            displayField: 'name',
            valueField: 'name',
        });



        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var flag="true";

        var chipTypeGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('chipTypeStore'),
            id: 'chipTypeGrid',
            margin: '20 10 20 0',
            title: '芯片种类',
            // titleAlign:'center',
            // titleFontSize:16,
            //forceFit: true,
            width:'100%',
            height:300,
            autoScroll: true,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig:{enableTextSelection:true},
            // selModel: Ext.create('Ext.selection.CheckboxModel', {
            //     id: 'chipTypeModel',
            //     mode: "SIMPLE",
            //     showHeaderCheckbox: true
            // }),
            selType: 'checkboxmodel',
            columns: [
                {xtype: 'rownumberer',width:25},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'attachmentPath', menuDisabled: true, hidden: true},
                {text: 'docBranchId', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: softwarePartNumText, dataIndex: 'softwarePartNum', flex:1,editor:disableNode(submit_node)?null:'textfield', menuDisabled: true},
                {text: '物料描述', dataIndex: 'softwarePartDesc', flex:1, menuDisabled: true},
                {text: softwareDocType, dataIndex: 'softwareDocType', flex:1, menuDisabled: true,editor:disableNode(submit_node)?null:softwareDocTypeCombobox},
                {text: softwareDocNumText, dataIndex: 'softwareDocNum', flex:1, menuDisabled: true,editor:disableNode(submit_node)?null:docNumbers},
                {text: softwareDocStateText, dataIndex: 'softwareDocState', flex:0.8, menuDisabled: true},
                {text: softwareDocNumLinkText, dataIndex: 'softwareDocNumLink', flex:1, menuDisabled: true,editor:null},
                {text: softwareDocVersionsText, dataIndex: 'softwareDocVersions', flex:1, menuDisabled: true,editor:(whetherEngineer || submit_node)?versionComboBox:null},
                {text: innerVersionText, dataIndex: 'innerVersion', flex:1, menuDisabled: true,editor:null},
                {text: amountText, dataIndex: 'amount', flex:1, editor:disableNode(submit_node)?null:{xtype:'numberfield',minValue:'0'}, menuDisabled: true},
                {
                    text: otherNumberText,
                    dataIndex: 'attachment',
                    flex: 1,
                    menuDisabled: true,
                    editor: !whetherPDMEngineerReview && !whetherEngineer ? null : {xtype: 'numberfield', minValue: '0'},
                },
                {
                    text: '软件工程师审核',
                    colspan: 3,
                    columns: [
                        {
                            text: softwareReviewerText,
                            dataIndex: 'softwareReviewer',
                            editor: (!whetherPDMEngineerReview && !whetherEngineer) ? null : theUserCombo,
                            flex: 1,
                            renderer: function(value, metaData, record) {
                                return record.get('softwareReviewerText');
                            }
                        },
                        {text: softwareReviewCommentText,dataIndex: 'softwareReviewComment',editor:!whetherEngineer?null:reviewCommentCombobox,flex: 2},
                        {text: softwareReviewRemarksText,dataIndex: 'softwareReviewRemarks',editor:!whetherEngineer?null:'textfield',flex: 1}
                    ]
                },
                {
                    text: '测试部审核',
                    colspan: 3,
                    columns: [
                        {
                            text: testReviewerText,
                            dataIndex: 'testReviewer',
                            editor: null,
                            flex: 1,
                            renderer: function (value, metaData, record) {
                                return record.get('testReviewerText');
                            }
                        },
                        {text: testReviewCommentText, dataIndex: 'testReviewComment',editor:!whetherTester?null:reviewCommentCombobox, flex: 2},
                        {text: testReviewRemarksText, dataIndex: 'testReviewRemarks',editor:!whetherTester?null:'textfield', flex: 1}
                    ]
                },
                {
                    text: '测试部最近一次审核意见',
                    colspan: 3,
                    columns: [
                        {
                            text: '审核人',
                            dataIndex: 'lastTimeReviewer',
                            editor: null,
                            flex: 1,
                            renderer: function (value, metaData, record) {
                                return record.get('lastTimeReviewerText');
                            }
                        },
                        {
                            text: '审核意见',
                            dataIndex: 'lastTimeReviewComment',
                            editor: null,
                            flex: 2
                        },
                        {
                            text: '备注',
                            dataIndex: 'lastTimeReviewRemarks',
                            editor: null,
                            flex: 1
                        }
                    ]
                }
            ],
            tbar: [
                {
                text: '添加',
                iconCls: 'icon icon-add',
                disabled: disableNode(submit_node),
                scope: this,
                handler: function () {
                    var rec = {};
                    this.chipTypeStore.insert(0, rec);
                    cellEditing.startEditByPosition({
                        row: 0,
                        column: 1
                    });
                }
            }, '&nbsp;',
                {
                    text: '删除',
                    iconCls: 'icon icon-delete',
                    disabled: disableNode(submit_node),
                    scope: this,
                    handler: function () {
                        var tmpSm = chipTypeGrid.getSelectionModel().getSelection();
                        if (!tmpSm || tmpSm == '') {
                            Ext.Msg.alert('提示', '未选择任何列，请选择要删除的数据！');
                            return;
                        }

                        var delFn = function () {
                            var deleteItems = new Array();//新增项
                            var sm = chipTypeGrid.getSelectionModel();
                            cellEditing.cancelEdit();
                            var tmpStore = Ext.getStore('chipTypeStore');
                            tmpStore.remove(sm.getSelection());
                            var removedRecords = tmpStore.getRemovedRecords();

                            Ext.each(removedRecords, function (record) {
                                deleteItems.push(record.data);
                            });

                            Ext.Ajax.request({
                                scope: this,
                                url: '/Windchill/ptc1/softwareBurning/deleteChipTypeItems',
                                //params: {submitData:Ext.encode(submitData)},
                                params: {deleteItems: Ext.encode(deleteItems), workItemOid: workItemOid},
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);

                                    if (obj['success']) {
                                        Ext.getCmp('saveStatus').setText('删除成功！');
                                    } else {
                                        alert(obj['msg']);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除失败，请检查网络！');
                                }
                            });
                        };//~end of delFn

                        Ext.Msg.confirm('提示', '确定要删除选中内容？',
                            function (btn) {
                                if (btn == 'yes') {
                                    delFn();
                                } else {
                                    return;
                                }
                            }, this);
                    }
                }, '&nbsp;',
                {
                    xtype: 'filefield',
                    buttonOnly: true,
                    preesed: true,
                    id: 'head_uploadFile',
                    name: 'head_uploadFile',
                    hidden: whetherEngineer ? false : true,
                    // hideLabel: true,
                    buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加附件',
                    allowBlank: false,
                    scope: this,
                    listeners: {
                        'focus': function () {
                            let selectionArr = chipTypeGrid.getSelectionModel().getSelection();
                            if (selectionArr.length == 0) {
                                location.replace(location);

                                alert("未选择添加附件行！");
                                return false;
                            }
                            if (selectionArr.length >= 2) {
                                alert("不支持多行选择添加附件！");
                                location.replace(location);
                                return false;
                            }
                        },
                        'change': function (fb, newValue) {
                            if (!newValue) {
                                return;
                            }
                            let selectionArr = chipTypeGrid.getSelectionModel().getSelection();

                            var softwarePartNum = selectionArr[0].get("softwarePartNum");
                            // store.reload();
                            if (softwarePartNum == '' || softwarePartNum == undefined) {
                                alert("请先填写物料编号!");
                                return;
                            } else if (selectionArr.length == 0) {
                                alert("添加附件失败，未选择添加附件对象!");
                                return;
                            } else if (selectionArr.length >= 2) {
                                alert("不支持多行添加附件操作，请确认要添加的行");
                                return;
                            } else {
                                // selectionArr[0].get("outDrawings");
                                var file = document.querySelector('[id=' + 'head_uploadFile' + '-button-fileInputEl]');
                                var formData = new FormData();
                                formData.append('head_uploadFile' + '-button-fileInputEl', file.files[0]);
                                fb.reset();//清空表单的值
                                var myMask = new Ext.LoadMask({
                                    msg: '正在上传，请稍候......',
                                    target: this.findParentByType('panel')
                                });
                                myMask.show();
                                $.ajax({
                                    url: '/Windchill/ptc1/softwareBurning/uploadFiles?branchId=' + docBranchId + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + 'head_node',
                                    type: 'POST',
                                    cache: false,
                                    data: formData,
                                    processData: false,
                                    contentType: false
                                }).done(function (res) {
                                    myMask.hide();
                                    var obj = Ext.decode(res);
                                    var success = obj['success'];
                                    var msg = obj['msg'];
                                    if (!success) {
                                        alert(msg);
                                    } else {
                                        var fileName = obj['fileName'];
                                        var filePath = obj['filePath'];
                                        var tRecord = chipTypeGrid.getSelectionModel().getSelection()[0];
                                        var attachmentValue = chipTypeGrid.getSelectionModel().getSelection()[0].data.attachment;
                                        var attachmentPath = chipTypeGrid.getSelectionModel().getSelection()[0].data.attachmentPath;
                                        if (attachmentValue != null && attachmentValue != '') {
                                            fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                            filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                        }
                                        tRecord.set('attachment', fileName);
                                        tRecord.set('attachmentPath', filePath);
                                        var callbackFn = function () {
                                            tRecord.commit();
                                        };
                                        var itemId = tRecord.get('id');
                                        updateValue(itemId, 'attachment', fileName, tRecord);
                                        updateValue(itemId, 'attachmentPath', filePath, tRecord);

                                        // saveMockItemData(itemId, 'attachment', fileName, callbackFn);
                                        // saveMockItemData(itemId, 'attachmentPath', filePath, callbackFn);

                                    }
                                }).fail(function (res) {
                                    myMask.hide();
                                    alert('上传失败！');
                                });
                            }
                        }
                    },
                }
            ],
            listeners: {
                change: 'onAllCircuitsChecked',
                'beforeedit': function (editor, context, eOpts) {
                    let columnName = context.column.dataIndex; // 当前列名
                    let tField = context.field; //得到修改列
                    let tValue = context.value; //得到修改列修改后值
                    let record = context.record; // 当前记录
                    let isTestVersion = record.get("isTestVersion");
                    let softwareDocNum = record.get("softwareDocNum"); //文件编号
                    clickRecordData = record.data;
                    let timestamp = Date.now();
                    clickRecordData.nowTimestamp = timestamp;
                    if (tField === "softwareDocVersions" && (isTestVersion === "是" || !submit_node)) {
                        return false;
                    }
                    if (tField === "softwareDocVersions") {
                        query = softwareDocNum;
                        getDocVersion(softwareDocNum);
                    }

                    //只能对自己任务的条目填写意见 软件工程师审核
/*                    if (tField === 'softwareReviewComment' || tField === 'softwareReviewRemarks') {
                        if (accountNumber !== record.get("softwareReviewer")) {
                            return false;
                        }
                    }*/

                    //只能对自己任务的条目填写意见 测试部审核（只有个人，不需要判断）
/*                    if (tField === 'testReviewComment' || tField === 'softwareReviewRemarks') {

                    }*/


                }
            },
        });

        chipTypeGrid.on('cellclick', function (){
            /*if(disableNode(submit_node)){
                return false;
            }else{
                Ext.getCmp('saveStatus').setText('正在编辑...');
            }*/
            // if(tField = 'amount'){
            //     var value = Ext.getCmp('isTestVersion').getValue();
            //
            //     if (value == '否'){
            //         return false;
            //     }
            // }

        });

        //表格编辑事件
        chipTypeGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            var id = tRecord.get('id');

            if(!isNumber(id)) {
                id = '';
            }

            if (tField =='softwarePartNum'&&tValue!=''){
                let queryData = Ext.encode(clickRecordData);
                getDocNumbers(queryData);
            }
            updateValue(id,tField,tValue,tRecord);



        });

        //========== 结束  chipTypeGrid=======================


        var formPanel = {
            xtype: 'form',
            id: 'mainForm',
            title: '软件烧录申请表',
            // titleAlign:'left',
            width: '100%',
            hideLabel: true,
            frame: true,
            layout : "anchor",// 整个大的表单是anchor布局
            border: false,
            items: [
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    border:false,
                    defaults: {margin: '5 20 0 0', labelWidth: 60},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '申请人',
                        id: 'applicant',
                        name: 'applicant',
                        width:300
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请部门',
                        id: 'applyDept',
                        name: 'applyDept',
                        width:300
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请时间',
                        id: 'applyTime',
                        name: 'applyTime',
                        width:300
                    },{
                        xtype: !disableNode(submit_node)?'numberfield':'displayfield',
                        // fieldLabel: '授权期限(天)',
                        fieldLabel: authDaysText,
                        labelWidth: 80,
                        id: 'authDays',
                        name: 'authDays',
                        width:300,
                        minValue:0,
                        maxValue:365,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('authDays').getValue();
                                if (value <= 365) {
                                    saveHeadInfo('authDays', value);
                                }
                            }
                        }
                    }]
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 60},
                    border:false,
                    items: [{
                        xtype: !disableNode(submit_node)?'textfield':'displayfield',
                        labelWidth:130,
                        // fieldLabel: '成品/半成品物料编码',
                        fieldLabel: partNumberText,
                        id: 'partNumber',
                        name: 'partNumber',
                        width:300,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('partNumber').getValue();
                                //触发后台保存
                                saveHeadInfo('partNumber', value);
                            }
                        }
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '物料描述',
                        id: 'partDesc',
                        name: 'partDesc',
                        width:300
                    }]
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 160},
                    border:false,
                    items: [{
                        xtype: !disableNode(submit_node)?'combo':'displayfield',
                        fieldLabel: isTestVersionText,
                        id: 'isTestVersion',
                        name: 'isTestVersion',
                        store:[['是','是'],['否','否']],
                        width:300,
                        listeners: {
                            select: function (e) {
                                var value = Ext.getCmp('isTestVersion').getValue();
                                //触发后台保存
                                saveHeadInfo('isTestVersion', value);
                                //如果为是，授权期限设置为30，并且不可编辑
                                //如果为否，可编辑授权期限，上限为365
                                if (value === '是') {
                                    let authDaysField = Ext.getCmp("authDays");
                                    authDaysField.setValue(60);
                                    saveHeadInfo('authDays', 60);
                                    authDaysField.setReadOnly(true);
                                } else {
                                    let authDaysField = Ext.getCmp("authDays");
                                    authDaysField.setReadOnly(false);
                                }

                            }
                        }
                    },{
                        xtype: !disableNode(submit_node)?'textfield':'displayfield',
                        fieldLabel: batchNumberText,
                        labelWidth: 120,
                        margin: '5 0 0 0',
                        id: 'batchNumber',
                        name: 'batchNumber',
                        width:300,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('batchNumber').getValue();
                                //触发后台保存
                                saveHeadInfo('batchNumber', value);
                            }
                        },
                        renderer: function(value, meta, record) {
                            if(value){
                                value += ' 套';
                            }
                            return value;
                        }
                    },{
                        xtype:'displayfield',
                        hidden:disableNode(submit_node),
                        id:'unit',
                        value:'套'
                    }]
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    border:false,
                    items: [{
                        xtype: !disableNode(submit_node)?'textarea':'displayfield',
                        fieldLabel: otherDescriptionText,
                        id: 'otherDescription',
                        name: 'otherDescription',
                        width:900,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('otherDescription').getValue();
                                //触发后台保存
                                saveHeadInfo('otherDescription', value);
                            }
                        }
                    }]
                },,{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 150},
                    border:false,
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: softwareDownLoadUserList,
                        id: 'softwareDownLoadUserList',
                        name: 'softwareDownLoadUserList',
                        width:900,
                        listeners: {
                        }
                    }]
                },
                // {
                //     xtype: 'panel',
                //     layout: 'hbox',
                //     defaults: {margin: '5 20 0 0', labelWidth: 100},
                //     border:false,
                //     items: [{
                //         xtype: !disableNode(submit_node)?'combobox':'displayfield',
                //         fieldLabel: toAccessPeopleText,
                //         id: 'toAccessPeople',
                //         name: 'toAccessPeople',
                //         store:allUserStore_projectPlan,
                //         valueField: 'userNo',
                //         //valueField: 'no',
                //         displayField: 'userFullName',
                //         width:300,
                //         multiSelect: true,
                //         listeners: {
                //             select: function (e) {
                //                 var carbonCopy = Ext.getCmp("toAccessPeople").getRawValue();
                //                 var carbonCopy2 = Ext.getCmp("toAccessPeople").getValue();
                //                 console.log(carbonCopy+"====="+carbonCopy2);
                //                 // var carbonCopyText = Ext.getCmp("carbonCopy").getValue();
                //                 // var values = carbonCopyText.split(",");
                //                 // var isEq = true;
                //                 // debugger
                //                 // for (var i = 0; i < values.length; i++) {
                //                 //     if (carbonCopy == values[i]) {
                //                 //         isEq = false;
                //                 //         return;
                //                 //     }
                //                 // }
                //                 // if (isEq) {
                //                 //     //Ext.getCmp("carbonCopy").setValue(carbonCopyText + ',' + carbonCopy)
                //                 //     saveReport();
                //                 // }
                //             }
                //         }
                //
                //     },{
                //         xtype: !disableNode(submit_node)?'textfield':'displayfield',
                //         width: 550,
                //         labelWidth: 100,
                //         fieldLabel: '已选择授权人:',
                //         disabledCls: 'none',
                //         name: 'carbonCopy',
                //         id: 'carbonCopy',
                //         listeners:{
                //             blur:function (e) {
                //                 // saveCarbonCopy();
                //             }
                //         }
                //     }
                //     ]
                // },
                chipTypeGrid
            ]
        };

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [formPanel];

        this.callParent();

    },//~End of initComponent
    listeners:{
        'afterrender':function(){


            ct_dataLoadedFlag = false;//加载前标志位设置为false
            //加载表单表头
            Ext.Ajax.request({
                url: '/Windchill/ptc1/softwareBurning/getHeadInfo?docBranchId='+docBranchId,
                success: function(response, opts) {
                    //加载表头信息
                    var obj = Ext.decode(response.responseText);
                    if(!obj['success']){
                        alert(obj['msg']);
                        return;
                    }

                    //设置表单值
                    var mainPanel = Ext.getCmp('mainForm');
                    mainPanel.getForm().setValues(obj['data']);
                    //设置
                    let value = Ext.getCmp('isTestVersion').getValue();
                    //初始化数据时，判断是否为测试版本，如果为是，则授权期不可编辑
                    if (value === '是') {
                        let authDaysField = Ext.getCmp("authDays");
                        authDaysField.setReadOnly(true);
                    }

                    ct_dataLoadedFlag = true;//数据加载后标志位设为true

                },
                failure: function(response, opts) {
                    alert('错误：读取表头信息失败，请检查网络！');
                }
            });
            refreshchipTypeStore();
            // refreshUploadFileStore();
        }//~end of listeners 'afterrender'

    }
});


function isNumber( str ) {
    var reg=/^[0-9]+$/;
    return reg.test(str);
}

//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}

//保存表单信息
function saveHeadInfo(key,value){
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/softwareBurning/saveHeadInfo',
        method:'POST',
        params:{
            workItemOid:workItemOid,
            docBranchId:docBranchId,
            key:key,
            value:value
        },
        success: function(response, opts) {
            var respText = Ext.decode(response.responseText);
            var success = respText['success'];
            var msg = respText['msg'];
            var partDesc = respText['partDesc'];
            if(!success){
                alert(msg);
                window.location.reload();
            }else{
                if(key=="partNumber"){
                    Ext.getCmp("partDesc").setValue(partDesc);
                }
            }
        },
        failure: function(response, opts) {
            alert('错误：保存失败，请检查网络！');
        }
    });
}

//刷新芯片种类列表
function refreshchipTypeStore(){
    Ext.getStore('chipTypeStore').load({
        params:{
            docBranchId:docBranchId
        },
        callback: function(records, operation, success) {
            if(!success){
                alert('查询芯片种类信息失败，请联系管理员！');
            }
        }
    });
}

//刷新文件列表
function refreshUploadFileStore(){
    Ext.getStore('uploadFileStore').load({
        params:{
            docBranchId:docBranchId
        },
        callback: function(records, operation, success) {
            if(!success){
                alert('查询上传文件信息失败，请联系管理员！');
            }
        }
    });
}

/**
 * 判断是否可编辑
 * @param node 节点表单key
 */
function disableNode(node) {
    if(taskCompleted == 'true') {
        return true;
    } else {
        if(node == actKey) {
            return false;
        } else {
            return true;
        }
    }
}

function isNull( str ){
    if (!str) return true;
    if ( str == "" ) return true;
    var regu = "^[ ]+$";
    var re = new RegExp(regu);
    return re.test(str);
}


function getDocNumbers(queryData) {

    Ext.getStore('docNumberStore').load({
        params: {
            query:queryData
        },
        callback: function (records, operation, success) {
            let response = operation.getResponse();
            if (!success) {
                let  responseJson = JSON.parse(response.responseText);
                alert(responseJson.msg);
            }
        }
    })
}


function getDocVersion(docNumber) {


    Ext.getStore('versionStore').load({
        params: {
            docNumber:docNumber
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！');
            }
        }
    })
}


function uploadFilefield(fileName, text, node, tetx_name) {
    if (text == null || text == "") {
        text = "浏览...";
    }

    var inform = {
        xtype: 'filefield',
        buttonOnly: true,
        disabled: disableNode(node),
        id: fileName,
        name: fileName,
        width:70,
        hideLabel: true,
        // buttonText: '<span style="width:145px;  labelWidth: 100;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + text + '</span>',
        buttonText: '<span style="width:60px; ">'+ text + '</span>',
        allowBlank: false,
        scope: this,
        listeners: {

            mouseover:function(){
                console.log("=========");
            },
            'change': function (fb, newValue, oldValue, opts) {
                if (!newValue) {
                    return;
                }
                var file = document.querySelector('[id=' + fileName + '-button-fileInputEl]');
                var formData = new FormData();
                formData.append(fileName + '-button-fileInputEl', file.files[0]);
                fb.reset();//清空表单的值
                var myMask = new Ext.LoadMask({
                    msg: '正在上传，请稍候......',
                    target: this.findParentByType('panel')
                });
                myMask.show();
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/softwareBurning/uploadFiles?branchId=' + docBranchId + '&tetx_name=' + tetx_name + "&node=" + node,
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function (res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if (!success) {
                        alert(msg);
                    } else {
                        var fileName = obj['fileName'];
                        var value = Ext.getCmp(tetx_name).getValue();
                        if (value != null && value != '') {
                            fileName = value + "&nbsp;|&nbsp;" + fileName;
                        }
                        Ext.getCmp(tetx_name).setValue(fileName);
                        autoSaveAtt(tetx_name, fileName);
                    }
                }).fail(function (res) {
                    myMask.hide();
                    alert('上传失败！');
                });
            }
        }
    };
    return inform;
}

function updateValue(id,tField,tValue,tRecord){

    var tempRec ={
        id:id,
        docBranchId:docBranchId,
        key: tField,
        value: tValue,
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/softwareBurning/updateChipTypeItems?workItemOid='+workItemOid,
        params:{
            updatedRecords:Ext.encode(tempRec)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']){
                tRecord.reject();
                alert(obj['msg']);
                return;
            }else{
                refreshchipTypeStore();
            }

        },
        failure: function(response, opts) {
            alert('网络连接异常，请检查网络！');
        }
    });

}


//删除附件
function deleteFilefield(branchId,fileName,path) {
    if(disableNode(rd_node)){
        alert("您没有权限删除其他用户的附件！");
        return;
    }
    Ext.Ajax.request({
        scope : this,
        async : false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url : '/Windchill/ptc1/softwareBurning/deleteFiles',
        params : {
            branchId: branchId,
            fileName: fileName,
            path:path
        },
        success : function(response, opts) {
            // myMask.hide();
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if(!success){
                alert(msg);
            }else {
                var fileName = obj['fileName'];
                var arr= new Array(); //定义一数组
                arr=fileName.split("|"); //字符分割
                for (i=0;i<arr.length ;i++ ){
                    var index = arr[i].indexOf(fileName);
                    if (index > -1) {
                        arr.splice(i,1);// 删除
                    }
                }

                var result = arr.join("&nbsp;|&nbsp;");
                var tRecord =  Ext.getCmp('chipTypeGrid').getSelectionModel().getSelection()[0];
                var attachmentValue = tRecord.data.attachment;
                var attachmentPath = tRecord.data.attachmentPath;
                var arr= new Array(); //定义一数组
                var arr1= new Array(); //定义一数组
                arr=attachmentValue.split("|"); //字符分割
                for (i=0;i<arr.length ;i++ ){
                    var index = arr[i].indexOf(fileName);
                    if (index > -1) {
                        arr.splice(i,1);// 删除
                    }
                }

                arr1=attachmentPath.split("|"); //字符分割
                for (i=0;i<arr1.length ;i++ ){
                    var index = arr1[i].indexOf(fileName);
                    if (index > -1) {
                        arr1.splice(i,1);// 删除
                    }
                }

                var result = arr.join("&nbsp;|&nbsp;");
                var result1 = arr1.join("&nbsp;|&nbsp;");

                tRecord.set('attachment',result);
                tRecord.set('attachmentPath',result1);


                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                updateValue(itemId,'attachment',result,tRecord);
                updateValue(itemId,'attachmentPath',result1,tRecord);
                // saveMockItemData( itemId, 'attachment', result, callbackFn);
                // saveMockItemData( itemId, 'attachmentPath',result1, callbackFn);
            }
        },
        failure : function(response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });


}

/**
 * 修改烧录软件信息
 */
function saveReport() {
    //alert(Ext.getCmp('itemId').getValue());
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/workReport/saveReport',
        method: "POST",
        params: {
            carbonCopy: Ext.getCmp('carbonCopyText').getValue(),
            //approver: Ext.getCmp('approver').getValue(),
            masterId: Ext.getCmp('id').getValue(),
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {

                console.log(obj['carbonCopy'])
                Ext.getCmp('carbonCopy').setValue(obj['carbonCopy'])
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存项目度量信息失败，请检查网络！');
        }
    });
}