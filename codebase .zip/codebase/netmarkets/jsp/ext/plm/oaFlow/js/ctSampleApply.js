/**
 * sampleApply研发制板
 */
Ext.define('PLM.view.sampleApply', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.sampleApply',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">研发样板制作申请单</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    config: {
        in_objectKey: 'sampleApply',
        in_objectDesc: '研发样板制作申请单',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {

/////////////////////////Panel items//////////////////////////////////
        var me = this;


        //必填字体颜色
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var pcbNumberText = '插件半成品代码';
        var pcbNameText = '插件半成品描述';
        var printedNumberText = '印制板编号';
        var printedNameText = '印制板名称';
        var expectedDeliveryTime = 'PCB板预计到料时间';
        var printedInsideNumberText = '印制板内部版本';
        var countText = '数量（PCS）';
        var productionMethodText = '是否需要机贴';
        var versionNumberText = '插件部件（PCBA）版本';
        var openSteelMeshText = '钢网';
        var openSteelMeshCodeText = '钢网文件编号';
        var weldedAttachmentText = '焊接附件文件编号';
        var attachmentText = '附件（资料）需上传产品BOM清单PCB拼板文件，海外产品需上传丝印图';

        var pcbNumberText07 = '插件半成品代码';
        var pcbNameText07 = '插件半成品描述';
        var attachmentText07 = '首件报告';

        var pcbNumberText08 = '插件半成品代码';
        var pcbNameText08 = '插件半成品描述';
        var problemDescription08 = '问题描述';
        var attachment08 = '附件上传';
        var suggestion08 = '问题修改回复';
        var attachmentReply08 = '附件上传';




        //表单
        var head_designatedPerson = '申请人';
        var head_endDate = '期望完成日期';
        var head_projectNumber = '项目编号';
        var head_PDTProductType = 'PDT产品分类';
        var head_productType = '产品型号';

        var head_requireAndAttention = '制作要求及注意事项';

        var trackingNumber = '研发领料跟踪单号(","隔开)';
        var reservedTrackingNumber = '预留单号';
        var stockStatus = '备料情况反馈';
        var cEndDate = '预计完成时间';
        var cOtherHelp = '其他说明';

        var processRouteMaintenanceFeedback = '工艺路线维护反馈';
        var prEndDate = '预计完成时间';
        var prOtherHelp = '其他说明';


        var applicationForSteelMesh = '申请钢网情况';
        var asmEndDate = '预计完成时间';

        var SMTProgramme = 'SMT编程';
        var sEndDate = '预计完成时间';
        var sOtherHelp = '其他说明';

        var steelMeshStatus = '钢网采购情况';
        var pEndDate = '预计完成时间';
        var otherStatus = '其他物料采购情况';
        var oEndDate = '预计完成时间';

        var steelMeshDate = '物料齐套时间';
        var gEndDate = '计划排产日期';
        var productionOrderNumber = '生产令号';
        var gOtherHelp = '其他说明';

        var performance = '完成情况';

        if(allowEdit){
            if(disableNode(submit_node)) {
                pcbNumberText = redStarFlag + blueFlagStart + pcbNumberText + blueFlagEnd;
                printedNumberText = redStarFlag + blueFlagStart + printedNumberText + blueFlagEnd;
                printedInsideNumberText = redStarFlag + blueFlagStart + printedInsideNumberText + blueFlagEnd;

                expectedDeliveryTime = redStarFlag + blueFlagStart + expectedDeliveryTime + blueFlagEnd;

                countText = redStarFlag + blueFlagStart + countText + blueFlagEnd;
                productionMethodText = redStarFlag + blueFlagStart + productionMethodText + blueFlagEnd;
                versionNumberText = redStarFlag + blueFlagStart + versionNumberText + blueFlagEnd;
                openSteelMeshText = redStarFlag + blueFlagStart + openSteelMeshText + blueFlagEnd;
                openSteelMeshCodeText = redStarFlag + blueFlagStart + openSteelMeshCodeText + blueFlagEnd;

                head_designatedPerson = redStarFlag + blueFlagStart + head_designatedPerson + blueFlagEnd;
                head_endDate = redStarFlag + blueFlagStart + head_endDate + blueFlagEnd;
                head_PDTProductType = redStarFlag + blueFlagStart + head_PDTProductType + blueFlagEnd;
                head_projectNumber = redStarFlag + blueFlagStart + head_projectNumber + blueFlagEnd;
                head_productType = redStarFlag + blueFlagStart + head_productType + blueFlagEnd;
                head_requireAndAttention = redStarFlag + blueFlagStart + head_requireAndAttention + blueFlagEnd;
                weldedAttachmentText =  blueFlagStart + weldedAttachmentText + blueFlagEnd;
                attachmentText = redStarFlag + blueFlagStart + attachmentText + blueFlagEnd;
            }else if (disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion)){

                trackingNumber = redStarFlag + blueFlagStart + trackingNumber + blueFlagEnd;
                // reservedTrackingNumber = redStarFlag + blueFlagStart + reservedTrackingNumber + blueFlagEnd;

                stockStatus = redStarFlag + blueFlagStart + stockStatus + blueFlagEnd;
                cEndDate = redStarFlag + blueFlagStart + cEndDate + blueFlagEnd;
                cOtherHelp = blueFlagStart + cOtherHelp + blueFlagEnd;

                // pcbNumberText08 = redStarFlag + blueFlagStart + pcbNumberText08 + blueFlagEnd;
                // // pcbNameText08 = redStarFlag + blueFlagStart + pcbNameText08 + blueFlagEnd;
                // problemDescription08 = redStarFlag + blueFlagStart + problemDescription08 + blueFlagEnd;
                // attachment08 = blueFlagStart + attachment08 + blueFlagEnd;

            }else if (disableNode(TD_node)){

                applicationForSteelMesh = redStarFlag + blueFlagStart + applicationForSteelMesh + blueFlagEnd;
                asmEndDate = redStarFlag + blueFlagStart + asmEndDate + blueFlagEnd;

                SMTProgramme = redStarFlag + blueFlagStart + SMTProgramme + blueFlagEnd;
                sEndDate = redStarFlag + blueFlagStart + sEndDate + blueFlagEnd;
                sOtherHelp = blueFlagStart + sOtherHelp + blueFlagEnd;
            }else if (disableNode(PM_node)){
                steelMeshStatus = redStarFlag + blueFlagStart + steelMeshStatus + blueFlagEnd;
                pEndDate = redStarFlag + blueFlagStart + pEndDate + blueFlagEnd;
                otherStatus = redStarFlag + blueFlagStart + otherStatus + blueFlagEnd;
                oEndDate = redStarFlag + blueFlagStart + oEndDate + blueFlagEnd;
            }else if (disableNode(control_node)){
                steelMeshDate = redStarFlag + blueFlagStart + steelMeshDate + blueFlagEnd;
                gEndDate = redStarFlag + blueFlagStart + gEndDate + blueFlagEnd;
                productionOrderNumber = redStarFlag + blueFlagStart + productionOrderNumber + blueFlagEnd;
                gOtherHelp = blueFlagStart + gOtherHelp + blueFlagEnd;
                // oEndDate = redStarFlag + blueFlagStart + oEndDate + blueFlagEnd;
            }else if (disableNode(RCD_node)||disableNode(reply_to_questions)){
                performance = redStarFlag + blueFlagStart + performance + blueFlagEnd;
            }

            else if (disableNode(routing_maintenance)){
                processRouteMaintenanceFeedback = redStarFlag + blueFlagStart + processRouteMaintenanceFeedback + blueFlagEnd;
                prEndDate = redStarFlag + blueFlagStart + prEndDate + blueFlagEnd;
                prOtherHelp = blueFlagStart + prOtherHelp + blueFlagEnd;
            }else if(disableNode(uploads_first_article_report)){
                attachmentText07 = redStarFlag + blueFlagStart + attachmentText07 + blueFlagEnd;
            }else if(disableNode(upload_issue)||disableNode(applyDeptManager_node)||disableNode(NPI_engineer_opinion)){
                pcbNumberText08 = redStarFlag + blueFlagStart + pcbNumberText08 + blueFlagEnd;
                // pcbNameText08 = redStarFlag + blueFlagStart + pcbNameText08 + blueFlagEnd;
                problemDescription08 = redStarFlag + blueFlagStart + problemDescription08 + blueFlagEnd;
                attachment08 = redStarFlag + blueFlagStart + attachment08 + blueFlagEnd;
            }
            if(disableNode(reply_to_questions)){
                suggestion08 = redStarFlag + blueFlagStart + suggestion08 + blueFlagEnd;
                attachmentReply08 = blueFlagStart + attachmentReply08 + blueFlagEnd;
            }

            if(disableNode(NPI_engineer_opinion)){
                pcbNumberText08 = redStarFlag + blueFlagStart + pcbNumberText08 + blueFlagEnd;
                // pcbNameText08 = redStarFlag + blueFlagStart + pcbNameText08 + blueFlagEnd;
                problemDescription08 = redStarFlag + blueFlagStart + problemDescription08 + blueFlagEnd;
                attachment08 = redStarFlag + blueFlagStart + attachment08 + blueFlagEnd;
            }

        }




        //获取使用人名单，全部人
        var theUserStore = Ext.create('PLM.hr.CtAllUserStore',{
            storeId:'theUserStore'
        });


        var theUserCombo = Ext.create('PLM.common.CtAllUserCombo',{
            width : 250,
            fieldLabel: head_designatedPerson,
            store:theUserStore,
            name: 'head_designatedPerson',
            id: 'head_designatedPerson',
            displayField: 'userFullName',
            valueField: 'no',
            disabled: !disableNode(submit_node),
            disabledCls: 'none',
            listeners: {
                select: function (e) {
                   if (allowEdit){
                    var value = Ext.getCmp('head_designatedPerson').getValue();
                    //触发后台保存
                    autoSaveAtt('head_designatedPerson', value);}
                }
            }
        });
        var ptdTeamGroupCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel: head_PDTProductType,
            readOnly:allowEdit?false:true,
            name: 'head_PDTProductType',
            id: 'head_PDTProductType',
            width: 250,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                // data: [["火灾报警系统产品", "火灾报警系统产品"], ["工业消防报警系统产品", "工业消防报警系统产品"], ["消防应急照明和疏散指示系统产品", "消防应急照明和疏散指示系统产品"],
                //     ["海外火灾报警系统产品", "海外火灾报警系统产品"],["防火门监控系统产品", "防火门监控系统产品"],["海外家用报警器产品", "海外家用报警器产品"],
                //     ["电气火灾监控系统&消防设备电源监控系统产品", "电气火灾监控系统&消防设备电源监控系统产品"],]
                data: [["火灾报警系统产品", "火灾报警系统产品"], ["电气火灾监控&消防设备电源监控系统产品", "电气火灾监控&消防设备电源监控系统产品"], ["防火门监控系统产品", "防火门监控系统产品"],
                    ["消防应急照明和疏散指示系统产品", "消防应急照明和疏散指示系统产品"],["海外火灾报警系统产品", "海外火灾报警系统产品"],["城市更新SDT产品", "城市更新SDT产品"],
                    ["其他", "其他"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                select: function (e) {
                    if (allowEdit){
                    var value = Ext.getCmp('head_PDTProductType').getValue();
                    //触发后台保存
                    autoSaveAtt('head_PDTProductType', value);
                }
            }}
        });

        Ext.define('sampleApplyModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId','attachmentPath', 'pcbNumber', 'pcbVersion', 'pcbName', 'printedNumber', 'printedName','printedInsideNumber','count',
             'productionMethod','openSteelMesh','openSteelMeshCode','weldedAttachment','attachment','expectedDeliveryTime'],
            idProperty: 'id'
        });

        var sampleApplyStore = Ext.create('Ext.data.Store', {
            id: 'sampleApplyStore',
            model: 'sampleApplyModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/sampleApply/getItemByBranchId?docBranchId='+docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var productionMethodCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEdit?false:true,
            name: 'productionMethodGroup',
            id: 'productionMethodGroup',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [ ["否", "否"], ["是", "是"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {
                    if (allowEdit){
                    var tRecord = e.record; //得到当前行所有数据
                    var tField = e.field; //得到修改列
                    var tValue = e.value; //得到修改列修改后值
                    var itemId = tRecord.get('id');

                    var callbackFn = function () {
                        tRecord.commit();
                    };
                    saveItemData(tRecord.data,callbackFn);
                }}
            }
        });

        var openSteelMeshCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEdit?false:true,
            name: 'openSteelMeshGroup',
            id: 'openSteelMeshGroup',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [ ["需要", "需要"], ["不需要", "不需要"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change:  function (editor, e) {
                    if (allowEdit){
                    var tRecord = e.record; //得到当前行所有数据
                    var tField = e.field; //得到修改列
                    var tValue = e.value; //得到修改列修改后值
                    var itemId = tRecord.get('id');

                    var callbackFn = function () {
                        tRecord.commit();
                    };
                    saveItemData(tRecord.data,callbackFn);
                }}
            }
        });

        var versionStore = new Ext.data.ArrayStore({
            id: 'versionStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/sampleApply/getAffectFiles',
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: false
        });

        //版本
        var versionCom = new Ext.form.ComboBox({
            name: 'versionCom',
            id: 'versionCom',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: versionStore,
            valueField: 'displayText',
            displayField: 'displayText'
        });





        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var sampleApplyGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('sampleApplyStore'),
            id: 'sampleApplyGrid',
            title:'PCB列表',
            margin: '10 0 20 0',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
//fields: ['id', 'docBranchId', 'pcbNumber', 'pcbVersion', 'pcbName', 'printedNumber', 'printedName','printedInsideNumber','count',
// 'productionMethod','openSteelMesh','openSteelMeshCode','weldedAttachment','attachment'],
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'attachmentPath', menuDisabled: true, hidden: true},
                {text: pcbNumberText, dataIndex: 'pcbNumber', width: 120, editor: 'textfield'},
                //{text: versionNumberText, dataIndex: 'pcbVersion', width: 180, editor: versionCom},
                {text: pcbNameText, dataIndex: 'pcbName', width: 400},
                {text: printedNumberText, dataIndex: 'printedNumber', width: 100, editor: 'textfield'},
                {text: printedNameText, dataIndex: 'printedName', width: 400,},
                // {text: expectedDeliveryTime, dataIndex: 'expectedDeliveryTime', width: 160,},
                {text: expectedDeliveryTime, dataIndex: 'expectedDeliveryTime',width: 100, editor: disableNode(submit_node) ?  {xtype:'datefield', minValue:new Date(),format:'Y-m-d'}: null,menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        return selfDateFormat(value);
                    } },
                {text: printedInsideNumberText, dataIndex: 'printedInsideNumber', width: 80, editor: 'textfield'},
                {text: countText, dataIndex: 'count', width: 120, editor: 'textfield'},
                {text: productionMethodText, dataIndex: 'productionMethod', width: 70, editor: productionMethodCombo},
                {text: openSteelMeshText, dataIndex: 'openSteelMesh', width: 60, editor: openSteelMeshCombo},
                //{text: openSteelMeshCodeText, dataIndex: 'openSteelMeshCode', width: 120, editor: 'textfield'},
                ///{text: weldedAttachmentText, dataIndex: 'weldedAttachment', width: 140, editor: 'textfield'},
                // {text: attachmentText, dataIndex: 'attachment', width: 400},

                {text: attachmentText,xtype:'actioncolumn', dataIndex: 'attachment', width: 250, editor: false, menuDisabled: true,
                    items: [
                        '->',
                        '-',
                        '-',
                        '-',
                        {
                            iconCls: 'icon icon-uploadImage',
                            tooltip: '添加文件',
                            hidden:disableNode(submit_node)?false:true,
                            handler: function(grid, rowIndex, colIndex) {
                                var record = grid.getStore().getAt(rowIndex);
                                //设置当前列的id与列名和表名
                                fileColumnId = record.get('id');
                                fileColumnName = 'attachment';
                                uploadTableName = 'ZSampleApplyItem';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = 'sampleApplyGrid';
                                allowMultiple = true;
                                var uploadFileWindow = initUploadFileWindow();
                                uploadFileWindow.show()

                            },
                            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                // var boolean = record.data.attachmentReply;
                                // if(boolean!=null) {
                                //     return true;
                                // }
                                // return false;
                            }
                        },
                        '-',
                        {
                            iconCls: 'icon-showInfo',
                            tooltip: '查看文件',
                            handler: function(grid, rowIndex, colIndex) {
                                var record = grid.getStore().getAt(rowIndex);
                                //设置当前列的id与列名和表名
                                fileColumnId = record.get('id');
                                fileColumnName = 'attachment';
                                uploadTableName = 'ZSampleApplyItem';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = 'sampleApplyGrid';

                                var showFiles = initShowFiles();

                                if(disableNode(submit_node)){
                                    Ext.getCmp('showDelete').show();
                                }else {
                                    Ext.getCmp('showDelete').hide();
                                }
                                showFiles.show()
                            },
                            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                var boolean = record.data.attachment;
                                if(boolean!=null) {
                                    return false;
                                }
                                return true;
                            }
                        }
                    ]
                },


            ],
            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    var tField = e.field; //得到修改列

                    if(!disableNode(submit_node)) {
                        return false;
                    }
                    if (tField == 'pcbVersion') {
                        let selectionArr = sampleApplyGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            return;
                        }
                        var number = selectionArr[0].data['pcbNumber']
                        if (!number) {
                            alert("请先填写编号！")
                            return false;
                        } else {
                            getVersion(number);
                        }
                    }
                },
            },
            tbar:[{
                hidden:!disableNode(submit_node),
                text: '新增',
                id:'add',
                name:'add',
                handler:function () {
                    var callbackFn = function () {
                        Ext.getStore('sampleApplyStore').reload();
                    };
                    insertItemData(callbackFn);
                }
            },{
               hidden:!disableNode(submit_node),
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    let selectionArr = sampleApplyGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('sampleApplyStore').reload()
                    };
                    deleteData("ZSampleApplyItem",obj, callbackFn);
                }
            }, '&nbsp;', {

                xtype: 'filefield',
                hidden: !disableNode(submit_node),
                buttonOnly: true,
                id: 'head_uploadFile',
                name: 'head_uploadFile',
                hidden:true,
                hideLabel: true,
                buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加附件',
                allowBlank: false,
                scope: this,
                listeners: {

                    'focus': function () {
                        let selectionArr = sampleApplyGrid.getSelectionModel().getSelection();
                        if (selectionArr.length == 0) {
                            alert("未选择添加附件行！");
                            return;
                        }
                        /*//alert(selectionArr[0].get("attachment"))
                        if (selectionArr[0].get("attachment") != null){
                            alert('只能上传一个附件');
                            return;
                        }*/
                        if (selectionArr.length >= 2) {
                            alert("不支持多行选择添加附件！");
                            return;
                        }

                    },
                    'change': function (fb, newValue) {
                        if (!newValue) {
                            return;
                        }
                        let selectionArr = sampleApplyGrid.getSelectionModel().getSelection();

                       if (selectionArr.length == 0) {
                            alert("添加附件失败，未选择添加附件对象!");
                            return;
                        } else if (selectionArr.length >= 2) {
                            alert("不支持多行添加附件操作，请确认要添加的行");
                            return;
                        } else {

                            var file = document.querySelector('[id=' + 'head_uploadFile' + '-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('head_uploadFile' + '-button-fileInputEl', file.files[0]);
                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在上传，请稍候......',
                                target: this.findParentByType('panel')
                            });


                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/sampleApply/uploadFiles?docBranchId='+docBranchId+'&text_name='+'head_uploadFileRecord'+"&node=" + 'head_node',
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function (res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if (!success) {
                                    alert(msg);
                                } else {
                                    var fileName = obj['fileName'];
                                    var filePath = obj['filePath'];
                                    var tRecord = sampleApplyGrid.getSelectionModel().getSelection()[0];
                                    var attachmentValue = sampleApplyGrid.getSelectionModel().getSelection()[0].data.attachment;
                                    var attachmentPath = sampleApplyGrid.getSelectionModel().getSelection()[0].data.attachmentPath;
                                    if (attachmentValue != null && attachmentValue != '') {
                                        fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                        filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                    }
                                    tRecord.set('attachment', fileName);
                                    tRecord.set('attachmentPath', filePath);
                                    var callbackFn = function () {
                                        tRecord.commit();
                                    };
                                    var itemId = tRecord.get('id');
                                    saveItemData(tRecord.data,callbackFn);
                                    // saveMockItemData(itemId, 'attachment', fileName, callbackFn);
                                    // saveMockItemData(itemId, 'attachmentPath', filePath, callbackFn);

                                }
                                var callbackFn = function () {
                                    //tRecord.commit();
                                    Ext.getStore('sampleApplyGrid').reload();
                                };
                            }).fail(function (res) {
                                myMask.hide();
                                alert('上传失败！');
                            });
                        }
                    }

                }
            }, {
                xtype: 'tbtext',
                text: '',
                id: 'saveStatus2',
                disabled: true
            }],
        });

        sampleApplyGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                if (tField=="pcbNumber"){
                    tRecord.set("pcbVersion","");
                }
                if (tField=="printedNumber"){
                    tRecord.set("printedInsideNumber","");
                }
                var callbackFn = function () {
                    Ext.getStore('sampleApplyStore').reload()
                    //tRecord.commit();
                };

                if("expectedDeliveryTime" == tField){
                    tRecord.data['expectedDeliveryTime']=Ext.util.Format.date(new Date(tRecord.data['expectedDeliveryTime']),'Y-m-d');
                }

                saveItemData(tRecord.data,callbackFn);
            });


        //===========================================7. 质控部首件报告上传（机贴）开始=========================================================================================
        Ext.define('controlDepartmentUploadModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'pcbNumber','pcbName','attachment'],
            idProperty: 'id'
        });

        var controlDepartmentUploadStore = Ext.create('Ext.data.Store', {
            id: 'controlDepartmentUploadStore',
            model: 'controlDepartmentUploadModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/sampleApply/getControlDepartmentUpload?docBranchId='+docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: true
        });

        var controlDepartmentUploadCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var controlDepartmentUploadGrid = Ext.create('Ext.grid.Panel', {
            plugins: [controlDepartmentUploadCellEditing],
            store: Ext.getStore('controlDepartmentUploadStore'),
            id: 'controlDepartmentUploadGrid',
            title:'7. 质控部首件报告上传（机贴）',
            margin: '10 0 20 0',
            autoScroll: true,
            region: 'center',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: pcbNumberText07, dataIndex: 'pcbNumber', width: 180, editor: false},
                {text: pcbNameText07, dataIndex: 'pcbName', width: 600},
                // {text: attachmentText07, dataIndex: 'attachment', width: 120, editor: disableNode(uploads_first_article_report)?true:false},
                {text: attachmentText07,xtype:'actioncolumn', dataIndex: 'attachment', width: 200, editor: false, menuDisabled: true,
                    items: [
                        '->',
                        '-',
                        '-',
                        '-',
                        {
                            iconCls: 'icon icon-uploadImage',
                            tooltip: '添加文件',
                            hidden:disableNode(uploads_first_article_report)?false:true,
                            handler: function(grid, rowIndex, colIndex) {
                                var record = grid.getStore().getAt(rowIndex);
                                //设置当前列的id与列名和表名
                                fileColumnId = record.get('id');
                                fileColumnName = 'attachment';
                                uploadTableName = 'ZControlDepartmentUpload';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = 'controlDepartmentUploadGrid';
                                allowMultiple = false;
                                var uploadFileWindow = initUploadFileWindow();
                                uploadFileWindow.show()

                            },
                            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                var boolean = record.data.attachment;
                                if(boolean!=null) {
                                    return true;
                                }
                                return false;
                            }
                        },
                        '-',
                        {
                            iconCls: 'icon-showInfo',
                            tooltip: '查看文件',
                            handler: function(grid, rowIndex, colIndex) {
                                var record = grid.getStore().getAt(rowIndex);
                                //设置当前列的id与列名和表名
                                fileColumnId = record.get('id');
                                fileColumnName = 'attachment';
                                uploadTableName = 'ZControlDepartmentUpload';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = 'controlDepartmentUploadGrid';

                                var showFiles = initShowFiles();

                                if(disableNode(uploads_first_article_report)){
                                    Ext.getCmp('showDelete').show();
                                }else {
                                    Ext.getCmp('showDelete').hide();
                                }
                                showFiles.show()
                            },
                            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                var boolean = record.data.attachment;
                                if(boolean!=null) {
                                    return false;
                                }
                                return true;
                            }
                        }
                    ]
                },

            ],
        });

        controlDepartmentUploadGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    Ext.getStore('controlDepartmentUploadStore').reload()
                };
                saveGridItemData(itemId,tField, tValue,"ZControlDepartmentUpload",callbackFn);
            });
        //===========================================7. 质控部首件报告上传（机贴）结束=========================================================================================

        //===========================================8. 问题收集表 开始=========================================================================================
        Ext.define('pcbNumberModel', {
            extend: 'Ext.data.Model',
            fields: [
                'number'
            ],
            idProperty: 'number'
        });
        // 项目下拉
        var pcbNumberListStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'pcbNumberModel',
            id: 'pcbNumberListStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/sampleApply/getPcbNumberList?branchId='+docBranchId,
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            autoLoad: true
        });


        Ext.define('problemCollectionFormModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'pcbNumber', 'pcbName', 'proposer', 'department','problemDescription','attachment', 'suggestion','attachmentReply'],
            idProperty: 'id'
        });

        var problemCollectionFormStore = Ext.create('Ext.data.Store', {
            id: 'problemCollectionFormStore',
            model: 'problemCollectionFormModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/sampleApply/getProblemCollectionForm?docBranchId='+docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: true
        });

        var problemCollectionFormCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var problemCollectionFormGrid = Ext.create('Ext.grid.Panel', {
            plugins: [problemCollectionFormCellEditing],
            store: Ext.getStore('problemCollectionFormStore'),
            id: 'problemCollectionFormGrid',
            title:'8. 问题收集表',
            margin: '10 0 20 0',
            autoScroll: true,
            region: 'center',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: pcbNumberText08, dataIndex: 'pcbNumber', width: 180,
                    editor: (disableNode(applyDeptManager_node)||disableNode(upload_issue)||disableNode(NPI_engineer_opinion))?{
                        xtype: 'combobox',
                        editable: true,
                        forceSelection: true,// 只允许选择下拉框中的值
                        queryMode: 'local',
                        displayField: 'number',
                        valueField: 'number',
                        store: pcbNumberListStore
                    }:false
                },
                {text: pcbNameText08, dataIndex: 'pcbName', width: 180},
                {text: "提出人", dataIndex: 'proposer', width: 120},
                {text: "提出部门", dataIndex: 'department', width: 120},
                {text: problemDescription08, dataIndex: 'problemDescription', width: 120, editor: (disableNode(applyDeptManager_node)||disableNode(upload_issue)||disableNode(NPI_engineer_opinion))?true:false},
                // {text: attachment08, dataIndex: 'attachment', width: 120, editor: disableNode(upload_issue)?true:false},

                {text: attachment08,xtype:'actioncolumn', dataIndex: 'attachment', width: 100, editor: false, menuDisabled: true,
                    items: [
                        '->',
                        {
                            iconCls: 'icon icon-uploadImage',
                            tooltip: '添加文件',
                            hidden:(disableNode(applyDeptManager_node)||disableNode(upload_issue)||disableNode(NPI_engineer_opinion))?false:true,
                            handler: function(grid, rowIndex, colIndex) {
                                var record = grid.getStore().getAt(rowIndex);
                                //设置当前列的id与列名和表名
                                fileColumnId = record.get('id');
                                fileColumnName = 'attachment';
                                uploadTableName = 'ZProblemCollectionForm';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = 'problemCollectionFormGrid';
                                allowMultiple = true;

                                var uploadFileWindow = initUploadFileWindow();
                                uploadFileWindow.show()

                            },
                            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                // var boolean = record.data.attachment;
                                // if(boolean!=null) {
                                //     return true;
                                // }
                                // return false;
                            }
                        },
                        '-',
                        {
                            iconCls: 'icon-showInfo',
                            tooltip: '查看文件',
                            handler: function(grid, rowIndex, colIndex) {
                                var record = grid.getStore().getAt(rowIndex);
                                //设置当前列的id与列名和表名
                                fileColumnId = record.get('id');
                                fileColumnName = 'attachment';
                                uploadTableName = 'ZProblemCollectionForm';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = 'problemCollectionFormGrid';

                                var showFiles = initShowFiles();

                                if((disableNode(applyDeptManager_node)||disableNode(upload_issue)||disableNode(NPI_engineer_opinion))){
                                    Ext.getCmp('showDelete').show();
                                }else {
                                    Ext.getCmp('showDelete').hide();
                                }
                                showFiles.show()
                            },
                            isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                var boolean = record.data.attachment;
                                if(boolean!=null) {
                                    return false;
                                }
                                return true;
                            }
                        }
                    ]
                },

                {
                    text: '问题回复',menuDisabled: true,
                    columns: [
                        {text: suggestion08, dataIndex: 'suggestion', width: 200, editor: disableNode(reply_to_questions)?true:false , menuDisabled: true},
                        // {text: attachmentReply08, dataIndex: 'attachmentReply', width: 100, editor: disableNode(reply_to_questions)?true:false , menuDisabled: true},

                        {text: attachmentReply08,xtype:'actioncolumn', dataIndex: 'attachmentReply', width: 100, editor: false, menuDisabled: true,
                            items: [
                                '->',
                                {
                                    iconCls: 'icon icon-uploadImage',
                                    tooltip: '添加文件',
                                    hidden:disableNode(reply_to_questions)?false:true,
                                    handler: function(grid, rowIndex, colIndex) {
                                        var record = grid.getStore().getAt(rowIndex);
                                        //设置当前列的id与列名和表名
                                        fileColumnId = record.get('id');
                                        fileColumnName = 'attachmentReply';
                                        uploadTableName = 'ZProblemCollectionForm';
                                        //设置grid名称用于上传文件后刷新数据
                                        gridName = 'problemCollectionFormGrid';
                                        allowMultiple = true;
                                        var uploadFileWindow = initUploadFileWindow();
                                        uploadFileWindow.show()

                                    },
                                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                        // var boolean = record.data.attachmentReply;
                                        // if(boolean!=null) {
                                        //     return true;
                                        // }
                                        // return false;
                                    }
                                },
                                '-',
                                {
                                    iconCls: 'icon-showInfo',
                                    tooltip: '查看文件',
                                    handler: function(grid, rowIndex, colIndex) {
                                        var record = grid.getStore().getAt(rowIndex);
                                        //设置当前列的id与列名和表名
                                        fileColumnId = record.get('id');
                                        fileColumnName = 'attachmentReply';
                                        uploadTableName = 'ZProblemCollectionForm';
                                        //设置grid名称用于上传文件后刷新数据
                                        gridName = 'problemCollectionFormGrid';

                                        var showFiles = initShowFiles();

                                        if(disableNode(reply_to_questions)){
                                            Ext.getCmp('showDelete').show();
                                        }else {
                                            Ext.getCmp('showDelete').hide();
                                        }
                                        showFiles.show()
                                    },
                                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                                        var boolean = record.data.attachmentReply;
                                        if(boolean!=null) {
                                            return false;
                                        }
                                        return true;
                                    }
                                }
                            ]
                        },

                    ]
                }
            ],

            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    if(!(disableNode(applyDeptManager_node)||disableNode(upload_issue)||disableNode(reply_to_questions)||disableNode(NPI_engineer_opinion))) {
                        return false;
                    }
                },
            },
            tbar:[{
                hidden:!(disableNode(applyDeptManager_node)||disableNode(upload_issue)||disableNode(NPI_engineer_opinion)),
                text: '新增',
                handler:function () {
                    var callbackFn = function () {
                        Ext.getStore('problemCollectionFormStore').reload();
                    };
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/sampleApply/insertProblemCollectionForm?oid='+oid,
                        params: {
                            docBranchId: docBranchId
                        },
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=="success") {
                                callbackFn();
                            } else {
                                alert(obj['error'] + "9999");
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：保存信息失败，请检查网络！!');
                        }
                    }); //~End of Ajax request
                    // insertItemData(callbackFn);
                }
            },{
                hidden:!(disableNode(applyDeptManager_node)||disableNode(upload_issue)||disableNode(NPI_engineer_opinion)),
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    let selectionArr = problemCollectionFormGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('problemCollectionFormStore').reload()
                    };
                    deleteProblemCollectionData("ZProblemCollectionForm",obj, callbackFn);
                }
            }, '&nbsp;',
            ],
        });

        problemCollectionFormGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                if(tField == "pcbNumber"){
                    if (tValue === null || tValue === undefined) {
                        tValue = "";
                    }
                }

                var callbackFn = function () {
                    Ext.getStore('problemCollectionFormStore').reload()
                    //tRecord.commit();
                };
                saveGridItemData(itemId,tField, tValue,"ZProblemCollectionForm",callbackFn);
            });
        //===========================================8. 问题收集表 结束=========================================================================================




        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            title: '1.提交人',
            anchor: '93%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 25 5',
            },

            items: [{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '申请日期',
                    name: 'head_applyDate',
                    id: 'head_applyDate',
                    width: 250,

                },theUserCombo, {
                    xtype: 'displayfield',
                    fieldLabel: '申请部门',
                    name: 'head_applyDepartment',
                    id: 'head_applyDepartment',
                    width: 250,

                },
                ]//~end of hbox items
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{

                    xtype:disableNode(submit_node)?'datefield':'displayfield',
                    fieldLabel: head_endDate,
                    name: 'head_endDate',
                    id: 'head_endDate',
                    format:'Y-m-d',
                    width: 250,

                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('head_endDate').getValue();
                            value = Ext.Date.format(value, 'Y-m-d');
                            //触发后台保存
                            autoSaveAtt('head_endDate', value);
                        }
                    }
                }, ptdTeamGroupCombo, {
                    xtype:disableNode(submit_node)?'textfield':'displayfield',
                    fieldLabel: head_projectNumber,
                    name: 'head_projectNumber',
                    id: 'head_projectNumber',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('head_projectNumber').getValue();
                            //触发后台保存
                            //autoSaveAtt1('head_projectNumber', value);
                            checkProjectNumber('head_projectNumber',value)
                        }
                    }
                },
                ]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [ {
                    xtype:'displayfield',
                    fieldLabel: '项目名称',
                    name: 'head_projectName',
                    id: 'head_projectName',
                    width: 250,
                    listeners: {
                        change: function (e) {
                            var value = Ext.getCmp('head_projectName').getValue();
                            //触发后台保存
                            if (ct_dataLoadedFlag) {
                                autoSaveAtt('head_projectName', value);
                            }
                        }
                    }
                }, {
                    xtype:disableNode(submit_node)?'textfield':'displayfield',
                    fieldLabel: head_productType,
                    name: 'head_productType',
                    id: 'head_productType',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('head_productType').getValue();
                            //触发后台保存
                            autoSaveAtt('head_productType', value);
                        }
                    }
                }, /*{
                    xtype: 'combobox',
                    disabled:!disableNode(submit_node),
                    disabledCls:'none',
                    fieldLabel: '是否包含机贴',
                    name: 'head_isStation',
                    id: 'head_isStation',
                    store: [['是', '是'], ['否', '否']],
                    width: 250,
                    listeners: {
                        select: function (e) {
                            var value = Ext.getCmp('head_isStation').getValue();
                            //触发后台保存
                            autoSaveAtt('head_isStation',value);
                        }
                    }
                },*/]
            },  {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype:'displayfield',
                    disabled:!hasPcbNumber(pcbDocNumber),
                    fieldLabel: '关联PCB制板申请单编号',
                    name: 'pcbDocNumber',
                    id: 'pcbDocNumber',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pcbDocNumber').getValue();
                            //触发后台保存
                            autoSaveAtt('pcbDocNumber', value);
                        }
                    }
                },
                ]
            },sampleApplyGrid,
                /*{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{//第四行
                        xtype:allowEdit?'filefield':'displayfield',
                        name: 'file1',
                        width: 500,
                        buttonText: '浏览',
                        fieldLabel: '元器件清单',
                        labelWidth: 100,
                    }
                    ],

                }]
            },*/
                 {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype:disableNode(submit_node)?'textarea':'displayfield',
                        fieldLabel: head_requireAndAttention,
                        name: 'head_requireAndAttention',
                        id: 'head_requireAndAttention',
                        width: 1000,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('head_requireAndAttention').getValue();
                                //触发后台保存
                                autoSaveAtt('head_requireAndAttention', value);
                            }
                        }
                    },
                    ],

                }]
            }, {
                xtype: 'panel',
                // layout: 'hbox',
                layout: 'vbox', // 改为垂直布局
                title: '2.备料情况（NPI工程师）',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [

                    {
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 120},
                        items: [{
                            xtype:'textarea',
                            fieldLabel: trackingNumber,
                            name: 'trackingNumber',
                            id: 'trackingNumber',
                            width: 500,
                            readOnly: !(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion)), // 设置为只读
                            listeners: {
                                blur: function (e) {
                                    if(!(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion))){
                                        return
                                    }
                                    var value = Ext.getCmp('trackingNumber').getValue();
                                    //触发后台保存
                                    autoSaveAtt('trackingNumber', value);
                                }
                            }
                        }, {
                            xtype:'textarea',
                            fieldLabel: reservedTrackingNumber,
                            name: 'reservedTrackingNumber',
                            id: 'reservedTrackingNumber',
                            width: 500,
                            readOnly: !(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion)), // 设置为只读
                            listeners: {
                                blur: function (e) {
                                    if(!(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion))){
                                        return
                                    }
                                    var value = Ext.getCmp('reservedTrackingNumber').getValue();
                                    //触发后台保存
                                    autoSaveAtt('reservedTrackingNumber', value);
                                }
                            }
                        }
                        ],
                    },

                    {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype:(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion))?'textarea':'displayfield',
                        fieldLabel: stockStatus,
                        name: 'stockStatus',
                        id: 'stockStatus',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('stockStatus').getValue();
                                //触发后台保存
                                autoSaveAtt('stockStatus', value);
                            }
                        }
                    }, {
                        xtype:(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion))?'datefield':'displayfield',
                        fieldLabel: cEndDate,
                        name: 'cEndDate',
                        id: 'cEndDate',
                        format:'Y-m-d',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('cEndDate').getValue();
                                value = Ext.Date.format(value, 'Y-m-d');
                                //触发后台保存
                                autoSaveAtt('cEndDate', value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype:(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion))?'textarea':'displayfield',
                        fieldLabel: cOtherHelp,
                        name: 'cOtherHelp',
                        id: 'cOtherHelp',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('cOtherHelp').getValue();
                                //触发后台保存
                                autoSaveAtt('cOtherHelp', value);
                            }
                        }
                    },
                    ],

                }]
            }, ,

                {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '3.工艺路线维护（工艺工程师）',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 120},
                        items: [{
                            xtype:disableNode(routing_maintenance)?'textarea':'displayfield',
                            fieldLabel: processRouteMaintenanceFeedback,
                            name: 'processRouteMaintenanceFeedback',
                            id: 'processRouteMaintenanceFeedback',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('processRouteMaintenanceFeedback').getValue();
                                    //触发后台保存
                                    autoSaveAtt('processRouteMaintenanceFeedback', value);
                                }
                            }
                        }, {
                            xtype:disableNode(routing_maintenance)?'datefield':'displayfield',
                            fieldLabel: prEndDate,
                            name: 'prEndDate',
                            id: 'prEndDate',
                            format:'Y-m-d',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('prEndDate').getValue();
                                    value = Ext.Date.format(value, 'Y-m-d');
                                    //触发后台保存
                                    autoSaveAtt('prEndDate', value);
                                }
                            }
                        }
                        ],

                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype:disableNode(routing_maintenance)?'textarea':'displayfield',
                            fieldLabel: prOtherHelp,
                            name: 'prOtherHelp',
                            id: 'prOtherHelp',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('prOtherHelp').getValue();
                                    //触发后台保存
                                    autoSaveAtt('prOtherHelp', value);
                                }
                            }
                        },
                        ],

                    }]
                },

                {
                xtype: 'panel',
                layout: 'vbox',
                title: '4. 贴片程序编写（技术部）',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype:disableNode(TD_node)?'textarea':'displayfield',
                        fieldLabel: SMTProgramme,
                        name: 'SMTProgramme',
                        id: 'SMTProgramme',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('SMTProgramme').getValue();
                                //触发后台保存
                                autoSaveAtt('SMTProgramme', value);
                            }
                        }
                    }, {
                        xtype:disableNode(TD_node)?'datefield':'displayfield',
                        fieldLabel: sEndDate,
                        name: 'sEndDate',
                        id: 'sEndDate',
                        format:'Y-m-d',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('sEndDate').getValue();
                                value = Ext.Date.format(value, 'Y-m-d');
                                //触发后台保存
                                autoSaveAtt('sEndDate', value);
                            }
                        }
                    }
                    ],
                },
                    {
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype:disableNode(TD_node)?'textarea':'displayfield',
                            fieldLabel: applicationForSteelMesh,
                            name: 'applicationForSteelMesh',
                            id: 'applicationForSteelMesh',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('applicationForSteelMesh').getValue();
                                    //触发后台保存
                                    autoSaveAtt('applicationForSteelMesh', value);
                                }
                            }
                        }, {
                            xtype:disableNode(TD_node)?'datefield':'displayfield',
                            fieldLabel: asmEndDate,
                            name: 'asmEndDate',
                            id: 'asmEndDate',
                            format:'Y-m-d',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('asmEndDate').getValue();
                                    value = Ext.Date.format(value, 'Y-m-d');
                                    //触发后台保存
                                    autoSaveAtt('asmEndDate', value);
                                }
                            }
                        }
                        ],

                    }

                ]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype:disableNode(TD_node)?'textarea':'displayfield',
                        fieldLabel: sOtherHelp,
                        name: 'sOtherHelp',
                        id: 'sOtherHelp',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('sOtherHelp').getValue();
                                //触发后台保存
                                autoSaveAtt('sOtherHelp', value);
                            }
                        }
                    },
                    ],

                }]
            },  {
                xtype: 'panel',
                layout: 'hbox',
                title: '5.采购部',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype:disableNode(PM_node)?'textarea':'displayfield',
                        fieldLabel: steelMeshStatus,
                        name: 'steelMeshStatus',
                        id: 'steelMeshStatus',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('steelMeshStatus').getValue();
                                //触发后台保存
                                autoSaveAtt('steelMeshStatus', value);
                            }
                        }
                    }, {
                        xtype:disableNode(PM_node)?'datefield':'displayfield',
                        fieldLabel: pEndDate,
                        name: 'pEndDate',
                        id: 'pEndDate',
                        format:'Y-m-d',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('pEndDate').getValue();
                                value = Ext.Date.format(value, 'Y-m-d');
                                //触发后台保存
                                autoSaveAtt('pEndDate', value);
                            }
                        }
                    }
                    ],
                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 120},
                    items: [{
                        xtype:disableNode(PM_node)?'textarea':'displayfield',
                        fieldLabel: otherStatus,
                        name: 'otherStatus',
                        id: 'otherStatus',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('otherStatus').getValue();
                                //触发后台保存
                                autoSaveAtt('otherStatus', value);
                            }
                        }
                    }, {
                        xtype:disableNode(PM_node)?'datefield':'displayfield',
                        fieldLabel: oEndDate,
                        name: 'oEndDate',
                        id: 'oEndDate',
                        format:'Y-m-d',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('oEndDate').getValue();
                                value = Ext.Date.format(value, 'Y-m-d');
                                //触发后台保存
                                autoSaveAtt('oEndDate', value);
                            }
                        }
                    }
                    ],

                }]
            }, , {
                xtype: 'panel',
                layout: 'vbox',
                title: '6.物控部',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype:disableNode(control_node)?'datefield':'displayfield',
                        fieldLabel: steelMeshDate,
                        name: 'steelMeshDate',
                        id: 'steelMeshDate',
                        width: 500,
                        format:'Y-m-d',
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('steelMeshDate').getValue();
                                value = Ext.Date.format(value, 'Y-m-d');
                                //触发后台保存
                                autoSaveAtt('steelMeshDate', value);
                            }
                        }
                    }, {
                        xtype:disableNode(control_node)?'datefield':'displayfield',
                        fieldLabel: gEndDate,
                        name: 'gEndDate',
                        id: 'gEndDate',
                        width: 500,
                        format:'Y-m-d',
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('gEndDate').getValue();
                                value = Ext.Date.format(value, 'Y-m-d');
                                //触发后台保存
                                autoSaveAtt('gEndDate', value);
                            }
                        }
                    }
                    ],

                },

                    {
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype:disableNode(control_node)?'textarea':'displayfield',
                            fieldLabel: productionOrderNumber,
                            name: 'productionOrderNumber',
                            id: 'productionOrderNumber',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('productionOrderNumber').getValue();
                                    //触发后台保存
                                    autoSaveAtt('productionOrderNumber', value);
                                }
                            }
                        }, {
                            xtype:disableNode(control_node)?'textarea':'displayfield',
                            fieldLabel: gOtherHelp,
                            name: 'gOtherHelp',
                            id: 'gOtherHelp',
                            width: 500,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('gOtherHelp').getValue();
                                    //触发后台保存
                                    autoSaveAtt('gOtherHelp', value);
                                }
                            }
                        }
                        ],

                    }

                ]
            },
            //     {
            //     xtype: 'panel',
            //     layout: 'hbox',
            //     defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
            //     items: [{
            //         xtype: 'panel',
            //         layout: 'hbox',
            //         defaults: {margin: '5 20 0 0', labelWidth: 100},
            //         items: [{
            //             xtype:disableNode(control_node)?'textarea':'displayfield',
            //             fieldLabel: gOtherHelp,
            //             name: 'gOtherHelp',
            //             id: 'gOtherHelp',
            //             width: 750,
            //             listeners: {
            //                 blur: function (e) {
            //                     var value = Ext.getCmp('gOtherHelp').getValue();
            //                     //触发后台保存
            //                     autoSaveAtt('gOtherHelp', value);
            //                 }
            //             }
            //         },
            //         ],
            //
            //     }]
            // },
                controlDepartmentUploadGrid,
                problemCollectionFormGrid,


                // {
                //     xtype:'textarea',
                //     fieldLabel: reservedTrackingNumber,
                //     name: 'reservedTrackingNumber',
                //     id: 'reservedTrackingNumber',
                //     width: 750,
                //     readOnly: !(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion)), // 设置为只读
                //     listeners: {
                //         blur: function (e) {
                //             if(!(disableNode(applyDeptManager_node01)||disableNode(NPI_engineer_opinion))){
                //                 return
                //             }
                //             var value = Ext.getCmp('reservedTrackingNumber').getValue();
                //             //触发后台保存
                //             autoSaveAtt('reservedTrackingNumber', value);
                //         }
                //     }
                // }

                {
                xtype: 'panel',
                title: '9.研发部验收',
                layout: 'hbox',
                defaults: {margin: '5 20 30 0', labelWidth: 100, border: false,},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype:'textarea',
                        readOnly: !(disableNode(RCD_node)||disableNode(reply_to_questions)), // 设置为只读
                        // xtype:disableNode(RCD_node)||disableNode(reply_to_questions)?'textarea':'displayfield',
                        fieldLabel: performance,
                        name: 'performance',
                        id: 'performance',
                        width: 750,
                        listeners: {
                            blur: function (e) {
                                if(!(disableNode(RCD_node)||disableNode(reply_to_questions))){
                                    return
                                }
                                var value = Ext.getCmp('performance').getValue();
                                //触发后台保存
                                autoSaveAtt('performance', value);
                            }
                        }
                    },
                    ],

                }]
            },//~end of 测试项目
            ]
        }]
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {

            Ext.getStore('sampleApplyStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            // alert('查询超时！请重试！')
                        }
                    }
                }
            });
            // 查询 form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/sampleApply/getFromByBranchId?docBranchId='+docBranchId,
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message=="success") {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj.data);
                        ct_dataLoadedFlag = true;
                    } else {
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});

function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}