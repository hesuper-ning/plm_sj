/**
 * 研发领料追踪表
 */
Ext.define('PLM.view.pickingTrace', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.pickingTrace',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">研发领料追踪表</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;

        var pickingOrReturnedValue = "";

        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var projectNumberText = '项目编号';
        var deliveryAddressText = '收件地址';
        var projectInitiatingCompanyText = '项目发起公司';
        var projectNameText = '项目名称';
        var applyText = '发起人';
        var applyDepartmentText = '需求部门';
        var positionsResetText = '仓位重置';
        var userFullNameText = '需求人';
        var addresseeText = '收件人';
        var receiveBillText = '其它情况说明';
        var purposeText = '用途';
        var partNumberText = '物料编码';
        var factoryText = '工厂';
        var partNameText = '物料名称';
        var partStatusText = '状态';
        var basicMaterialNumberText = '基础物料编号';
        var basicMaterialNameText = '基础物料名称';
        var totalText = '数量';
        var purposeTwoText = '仓位';
        var remarkText = '备注';
        var pmcResultText = 'PMC处理结果';
        var warehouseResultText = '仓库处理结果';
        var returnInventoryText = '退库单号(多值用英文逗号分隔)';
        var confirmResultText = '确认结果';
        var whetherReturnInventoryText = '是否需要退库';
        if (!disableNode(submit_node)) {
            projectNameText = redStarFlag + blueFlagStart + projectNameText + blueFlagEnd;
            projectNumberText = redStarFlag + blueFlagStart + projectNumberText + blueFlagEnd;
            projectInitiatingCompanyText = redStarFlag + blueFlagStart + projectInitiatingCompanyText + blueFlagEnd;
            factoryText = redStarFlag + blueFlagStart + factoryText + blueFlagEnd;
            applyText = redStarFlag + blueFlagStart + applyText + blueFlagEnd;
            applyDepartmentText = redStarFlag + blueFlagStart + applyDepartmentText + blueFlagEnd;
            userFullNameText = redStarFlag + blueFlagStart + userFullNameText + blueFlagEnd;
            addresseeText = blueFlagStart + addresseeText + blueFlagEnd;
            deliveryAddressText = blueFlagStart + deliveryAddressText + blueFlagEnd;
            receiveBillText = redStarFlag + blueFlagStart + receiveBillText + blueFlagEnd;
            purposeText = redStarFlag + blueFlagStart + purposeText + blueFlagEnd;
            remarkText =  blueFlagStart + remarkText + blueFlagEnd;
            whetherReturnInventoryText = redStarFlag + blueFlagStart + whetherReturnInventoryText + blueFlagEnd;

            partNumberText = redStarFlag + blueFlagStart + partNumberText + blueFlagEnd;
            partNameText = redStarFlag + blueFlagStart + partNameText + blueFlagEnd;
            totalText = redStarFlag + blueFlagStart + totalText + blueFlagEnd;
            purposeTwoText = redStarFlag + blueFlagStart + purposeTwoText + blueFlagEnd;
            basicMaterialNumberText = blueFlagStart + basicMaterialNumberText + blueFlagEnd;
            basicMaterialNameText = blueFlagStart + basicMaterialNameText + blueFlagEnd;
        }
        if (!disableNode(PMC_node)) {
            pmcResultText = redStarFlag + blueFlagStart + pmcResultText + blueFlagEnd;
        }
        if (!disableNode(departmentHeadConfirm_node)) {
            warehouseResultText = redStarFlag + blueFlagStart + warehouseResultText + blueFlagEnd;
        }
        if (!disableNode(engineerCheck_node)) {
            confirmResultText = redStarFlag + blueFlagStart + confirmResultText + blueFlagEnd;
        }
        if(!disableNode(initiate_material_return_node)){
            returnInventoryText = blueFlagStart + returnInventoryText + blueFlagEnd;
        }

        //用户下拉列表
        // var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
        //     storeId: 'allUserStore_projectPlan'
        // });
        // var allUserCombo_projectPlan = Ext.create('PLM.hr.CtAllUserCombo', {
        //     store: allUserStore_projectPlan
        // });

        //需求人下拉列表
        var demandPersonStore = new Ext.data.ArrayStore({
            id: 'demandPersonStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        //收件人下拉列表
        var addresseeStore = new Ext.data.ArrayStore({
            id: 'addresseeStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/queryPersonList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        Ext.define('pickingModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'partNumber', 'partName', 'materialStatus', 'total', 'purpose', 'remark'],
            idProperty: 'id'
        });

        var pickingStore = Ext.create('Ext.data.Store', {
            id: 'pickingStore',
            model: 'pickingModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/picking/getTraceItem?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        // var purposeCombo = new Ext.form.ComboBox({
        //     name: 'purposeCombo',
        //     id: 'purposeCombo',
        //     multiSelect: false,
        //     valueField: 'groupName',
        //     displayField: 'groupName',
        //     anyMatch: true,
        //     editable: false,
        //     store: ['0008_成品仓', '0003_半成品仓', '0002_原材料仓', '2001_维修仓', '3001_研发仓','1006 生产-五楼贴片线边仓','1009  生产-二楼贴片二车间线边仓'],
        // });

        var pickingStore = Ext.create('Ext.data.Store', {
            id: 'pickingStore',
            model: 'pickingModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/picking/getTraceItem?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var purposeStore = new Ext.data.ArrayStore({
            id: 'purposeStore',
            fields: [
                {name:"warehouse"},
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/picking/queryWarehouseList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                },
                extraParams: {
                    factory:  ''
                }
            },
            autoLoad: false
        });

        var purposeCombo = new Ext.form.ComboBox({
            name: 'purposeCombo',
            id: 'purposeCombo',
            multiSelect: false,
            valueField: 'warehouse',
            displayField: 'warehouse',
            anyMatch: true,
            editable: true,
            value:'',
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
            store: purposeStore
        });

        var positionsResetStore = new Ext.data.ArrayStore({
            id: 'positionsResetStore',
            fields: [
                {name:"warehouse"},
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/picking/queryMergeWarehouseList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                },
                extraParams: {
                    branchId:  branchId,
                    query: ''
                }
            },
            autoLoad: true
        });

        var factoryCombo = new Ext.form.ComboBox({
            name: 'factoryCombo',
            id: 'factoryCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: ['1001_电子-光明分厂', '1002_电子-光明二厂', '1003_电子-光明三厂', '1100_检测-总部', '1200_数据-总部','1300_检测-总部']
        });

        //基础物料编号
        var basicMaterialCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'basicMaterialCombo',
            id: 'basicMaterialCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['basicMaterialNumber']
            },
            valueField: 'basicMaterialNumber',
            displayField: 'basicMaterialNumber'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        //导入panel
        var uploadForm = new Ext.form.Panel({
            layout: 'form',
            id: 'uploadForm',
            name: 'uploadForm',
            width: 450,
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            border: 0,
            tbar: [{
                xtype: 'filefield',
                name: 'userfile',
                id: 'userfile',
                msgTarget: 'side',
                fieldLabel: '上传Excel文件',
                width: 280,
                anchor: '100%',
                buttonText: '选择文件..',
                buttonOnly: false,
                buttonMargin: '5 5 5 5'
            }, {
                xtype: 'button',
                padding: '5 5 5 5',
                id: 'technic_submit',
                //disabled: existManufacturingViewPart?false:true,
                text: '开始导入',
                handler: function () {
                    var mainForm = Ext.getCmp('uploadForm').getForm();
                    var furl = "";  //文件物理地址
                    var fname = ""; //文件名称
                    furl = Ext.getCmp("userfile").getValue();
                    //alert(furl);
                    if (furl == "") {
                        alert("请先选择文件！");
                        return false;
                    }

                    mainForm.submit({
                        scope: this,
                        url: '/Windchill/ptc1/picking/importPicking?branchId=' + branchId,
                        waitMsg: '正在导入......',
                        waitTitle: '请等待',
                        //method : 'POST',
                        success: function (form, action) {
                            var obj = action.result;
                            if (obj.success) {
                                alert("导入成功");
                                // Ext.getCmp("uploadForm").hide();
                                // refreshProblem();
                                window.parent.location.reload();
                            } else {
                                alert(obj.msg);
                            }
                        },
                        failure: function (form, action) {
                            var obj = action.result;
                            alert(obj.msg);
                        },

                    });
                }
            }]
        });

        //导入窗口
        var uploadPlanWindow = new Ext.create('Ext.Window', {
            title: '导入数据',
            // width: 430,
            autoHeight: true,
            autoWidth: true,
            closeAction: 'hide',
            y: '10%',
            id: 'uploadProblemWindow',
            constrain: true,
            modal: true,
            layout: 'fit',
            //border : 0,
            items: uploadForm
        });


        var pickingGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('pickingStore'),
            id: 'pickingGrid',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            //['id', 'docBranchId', 'PCBName', 'count', 'productionMethod', 'versionNumber', 'openSteelMesh'],
            columns: [
                {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: partNumberText, dataIndex: 'partNumber', width: 100, editor: 'textfield'},
                {text: partNameText, dataIndex: 'partName', width: 100},
                {text: partStatusText, dataIndex: 'materialStatus', width: 50,},
                {text: basicMaterialNumberText, dataIndex: 'basicMaterialNumber', width: 100, editor: basicMaterialCombo},
                {text: basicMaterialNameText, dataIndex: 'basicMaterialName', width: 100},
                {text: totalText, dataIndex: 'total', width: 100, editor: 'numberfield'},
                {
                    text: factoryText, dataIndex: 'factory', width: 100, editor: factoryCombo

                },
                {
                    text: purposeTwoText, dataIndex: 'purpose', width: 100, editor: purposeCombo,
                    /*renderer: function(value,metaData,record,row,col,store){
                        var temp = new Array();
                        debugger
                        if(value && !Array.isArray(value)){
                            value += ",";
                            var start = 0;
                            var pos = value.indexOf(',');
                            while (pos > -1) {
                                temp.push(value.substr(start, pos-start));
                                start = pos + 1;
                                pos = value.indexOf(',', pos + 1);
                            }
                            record.set("purpose",temp);
                            record.commit();
                        }else{
                            temp = value;
                        }

                        //提示tip
                        metaData.tdAttr = " data-qtip = '"+temp+"'";
                        return temp;
                    }*/
                },
                {text: remarkText, dataIndex: 'remark', width: 100, editor: 'textfield'},
            ],
            tbar: [{
                text: '新增',
                iconCls: 'icon-add',
                id: 'add',
                name: 'add',
                hidden: disableNode(submit_node),
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('pickingStore').reload();
                    };
                    insertItemData('ZPickingItem', callbackFn);
                }
            }, {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                hidden: disableNode(submit_node),
                handler: function () {
                    let selectionArr = pickingGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('pickingStore').reload()
                    };
                    deleteData('ZPickingItem', obj, callbackFn);
                }
            }, {

                text: '导入',
                iconCls: 'icon-excelImport',
                hidden: disableNode(submit_node),
                handler: function () {
                    uploadPlanWindow.show();
                },
            }, {

                text: '导出',
                hidden: disableNode(submit_node),
                iconCls: 'icon icon-download',
                handler: function () {
                    this.doExportGridData();
                },
                scope: this
            }, {

                iconCls: 'icon-download ',
                xtype: 'button',
                id: "downTemplate",
                text: '下载模板',
                hidden: disableNode(submit_node),
                handler: function () {
                    window.location.href = '/Windchill/template/研发领料导入模板.xlsx', '', 'width=300,height=200';
                }
            }, {
                xtype: 'tbtext',
                text: '',
                id: 'saveStatus2',
                disabled: true
            }],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    if (disableNode(submit_node)) {
                        Ext.getCmp('saveStatus2').setText('不允许编辑！');
                        return false;
                    }
                },
                rowclick: function (view, record, item, index, e) {
                    var headerCt = view.getHeaderCt(); // 获取列头组件
                    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
                    var cellIndex = cell.cellIndex; // 获取单元格的索引
                    var partNumber = record.get('partNumber');
                    // 通过单元格索引获取列
                    var column = headerCt.getGridColumns()[cellIndex + 2];
                    if (column) {
                        var columnName = column.dataIndex;
                        if(columnName == 'basicMaterialNumber'){
                            basicMaterialCombo.getStore().removeAll();
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/picking/getBasicMaterialByPartNumber?partNumber=' + partNumber,
                                method:'GET',
                                headers: {'Content-Type':'application/json'},
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        var numberList = Ext.decode(response.responseText).data;
                                        if(numberList){
                                            numberList.map(function(item) {
                                                basicMaterialCombo.getStore().add({basicMaterialNumber:item.basicMaterialNumber});
                                            })
                                        }
                                    }else {
                                        alert(obj.message)
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败，请检查网络！!');
                                }
                            });
                        }

                        if(columnName == 'purpose'){
                            var factory = record.get('factory');
                            if(factory){
                                purposeStore.getProxy().extraParams = {
                                    factory: factory,
                                    query:''
                                };
                                purposeStore.load();
                            }else{
                                Ext.Msg.alert('提示', '请先选择工厂！');
                            }
                        }
                    }
                }
            },
        });

        pickingGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    if (tField == 'partNumber' || tField == 'basicMaterialNumber') {
                        Ext.getStore('pickingStore').reload()
                    }
                    if(tField == 'factory'){
                        Ext.getStore('positionsResetStore').load({
                            params:{
                                query: ''
                            },
                        });
                    }
                    tRecord.commit();
                };
                saveMockItemData('ZPickingItem', itemId, tField, tValue, callbackFn);
            });

        var projectNameStore = new Ext.data.ArrayStore({
            id: 'projectNameStore',
            fields: [
                {name:"projectName"},
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/picking/queryProjectList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            title: '1.申请信息',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [
                {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {xtype: 'displayfield', id: 'id', name: 'id', hidden: true},
                        {
                            xtype: 'combobox',
                            fieldLabel: projectNameText,
                            id: 'projectName',
                            name: 'projectName',
                            value:'',
                            width: 350,
                            multiSelect: false,
                            anyMatch: true,
                            disabled: disableNode(submit_node),
                            store: projectNameStore,
                            minChars : 1,//开始查询最小字符数
                            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
                            valueField: 'projectName',
                            displayField: 'projectName',
                            listeners: {
                                select: function(combo, records) {
                                    var value = Ext.getCmp('projectName').getValue();
                                    //触发后台保存
                                    if (ght_dataLoadedFlag) {
                                        autoSaveAtt('projectName', value);
                                        var projectInitiatingCompany = Ext.getCmp('projectInitiatingCompany').getValue();
                                        if(projectInitiatingCompany){
                                            setProjectNumber(value, projectInitiatingCompany, 'Y');
                                        }
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'combo',
                            fieldLabel: projectInitiatingCompanyText,
                            name: 'projectInitiatingCompany',
                            id: 'projectInitiatingCompany',
                            disabled: disableNode(submit_node),
                            disabledCls: 'none',
                            multiSelect: false,
                            anyMatch: true,
                            editable: false,
                            store: ['1000-电子公司', '1100-科技公司', '1200-数据公司', '1300-检测公司'],
                            width: 350,
                            listeners: {
                                select: function (e) {
                                    var value = Ext.getCmp('projectInitiatingCompany').getValue();
                                    //触发后台保存
                                    if (ght_dataLoadedFlag) {
                                        autoSaveAtt('projectInitiatingCompany', value);
                                        var projectName = Ext.getCmp('projectName').getValue();
                                        if(projectName){
                                            setProjectNumber(projectName, value, 'Y');
                                        }
                                    }
                                }
                            }
                        }
                    ]//~end of hbox items
                }, {//第二行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: "项目编号",
                            //disabled: disableNode(submit_node),
                            disabledCls: 'none',
                            name: 'projectNumber',
                            id: 'projectNumber',
                            width: 350
                        }
                    ]//~end of hbox items
                },
                {//第三行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '发起人',
                            name: 'applicant',
                            id: 'applicant',
                            width: 350,
                            listeners: {
                                select: function (e) {
                                    var value = Ext.getCmp('applicant').getValue();
                                    //触发后台保存
                                    autoSaveAtt('applicant', value);
                                }
                            }
                        }, {
                            xtype: 'displayfield',
                            fieldLabel: '发起日期',
                            name: 'applyDate',
                            id: 'applyDate',
                            width: 350,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('applyDate').getValue();
                                    //触发后台保存
                                    autoSaveAtt('applyDate', value);
                                }
                            }
                        }
                    ]
                },
                {//第四行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [{
                        xtype: 'combo',
                        multiSelect: false,
                        valueField: 'name',
                        displayField: 'fullName',
                        anyMatch: true,
                        editable: true,
                        fieldLabel: userFullNameText,
                        store: demandPersonStore,
                        disabled: disableNode(submit_node),
                        disabledCls: 'none',
                        name: 'recipient',
                        id: 'recipient',
                        value:'',
                        width: 350,
                        minChars : 1,//开始查询最小字符数
                        mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
                        listeners: {
                            select: function (e) {
                                var value = Ext.getCmp('recipient').getValue();
                                if (ght_dataLoadedFlag) {
                                    //触发后台保存
                                    autoSaveAtt('recipient', value);
                                }
                            }
                        }
                    }, {
                        xtype: 'combo',
                        fieldLabel: applyDepartmentText,
                        name: 'applyDepartment',
                        id: 'applyDepartment',
                        disabled: disableNode(submit_node),
                        disabledCls: 'none',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        store: ['1000510000_研发中心', '1000511000_研发管理部', '1000516000_总体技术部', '1000517000_硬件研发部',
                            '1000518000_软件研发部', '1000519000_结构设计部', '1000280000_PDT经理管理部','1000514000_产品工程部'
                            ,'1200530000_IC研发部'],
                        width: 350,
                        listeners: {
                            select: function (e) {
                                var value = Ext.getCmp('applyDepartment').getValue();
                                //触发后台保存
                                if (ght_dataLoadedFlag) {
                                    autoSaveAtt('applyDepartment', value);
                                }
                            }
                        }
                    }
                    ]//~end of hbox items
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [{
                        xtype: 'combo',
                        fieldLabel: positionsResetText,
                        name: 'positionsReset',
                        id: 'positionsReset',
                        multiSelect: false,
                        anyMatch: true,
                        disabled: disableNode(submit_node),
                        disabledCls: 'none',
                        editable: true,
                        valueField: 'warehouse',
                        displayField: 'warehouse',
                        value:'',
                        minChars : 1,//开始查询最小字符数
                        mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
                        //store: ['0008_成品仓', '0003_半成品仓', '0002_原材料仓', '2001_维修仓', '3001_研发仓','1006 生产-五楼贴片线边仓','1009  生产-二楼贴片二车间线边仓'],
                        store:positionsResetStore,
                        width: 350,
                        listeners: {
                            beforeselect: function (e, c) {
                                var s = window.confirm("修改此框后表格中所有仓位都会进行修改是否继续");
                                if (s){
                                    //获取最新的值
                                    setStorehouse(c.get('warehouse'),'ZPickingItem','purpose');
                                    return true
                                }else {
                                    return false;
                                }
                            }
                        }
                    },{
                        xtype: 'combo',
                        fieldLabel: "重置工厂",
                        name: 'factoryReset',
                        id: 'factoryReset',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        disabled: disableNode(submit_node),
                        disabledCls: 'none',
                        store: ['1001_电子-光明分厂', '1002_电子-光明二厂', '1003_电子-光明三厂', '1100_检测-总部', '1200_数据-总部','1300_检测-总部'],
                        width: 350,
                        listeners: {
                            beforeselect: function (e, c) {
                                var s = window.confirm("修改此框后表格中所有工厂都会进行修改是否继续");
                                if (s) {
                                    //获取最新的值
                                    setStorehouse(c.get('field1'), 'ZPickingItem', 'factory');
                                    return true
                                } else {
                                    return false;
                                }
                            }

                        }
                    }],
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {
                            xtype: 'combo',
                            multiSelect: false,
                            valueField: 'name',
                            displayField: 'fullName',
                            anyMatch: true,
                            editable: true,
                            fieldLabel: addresseeText,//收件人
                            store: addresseeStore,
                            disabled: disableNode(submit_node),
                            disabledCls: 'none',
                            typeAhead: true,
                            name: 'addressee',
                            id: 'addressee',
                            width: 350,
                            minChars : 1,//开始查询最小字符数
                            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
                            listeners: {
                                select: function (e) {
                                    var value = Ext.getCmp('addressee').getValue();
                                    if (ght_dataLoadedFlag) {
                                        //触发后台保存
                                        autoSaveAtt('addressee', value);
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'combo',
                            fieldLabel: deliveryAddressText,
                            disabled: disableNode(submit_node),
                            disabledCls: 'none',
                            name: 'deliveryAddress',
                            id: 'deliveryAddress',
                            valueField: 'deliveryAddress',
                            displayField: 'deliveryAddress',
                            anyMatch: true,
                            editable: true,
                            multiSelect: false,
                            store: [["四工业区", "四工业区"], ["光明工厂", "光明工厂"]],
                            width: 350,
                            listeners: {
                                select: function (e) {
                                    var value = Ext.getCmp('deliveryAddress').getValue();
                                    if (ght_dataLoadedFlag) {
                                        //触发后台保存
                                        autoSaveAtt('deliveryAddress', value);
                                    }
                                },
                                blur: function(e) {
                                    var value = Ext.getCmp('deliveryAddress').getValue();
                                    if (ght_dataLoadedFlag) {
                                        //触发后台保存
                                        autoSaveAtt('deliveryAddress', value);
                                    }
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: receiveBillText,//其他情况说明
                        name: 'receiveBill',
                        id: 'receiveBill',
                        disabled: disableNode(submit_node),
                        disabledCls: 'none',
                        width: 700,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('receiveBill').getValue();
                                //触发后台保存
                                autoSaveAtt('receiveBill', value);
                            }
                        }
                    },]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {
                            xtype: 'textarea',
                            fieldLabel: purposeText,
                            name: 'purpose',
                            id: 'purpose',
                            disabled: disableNode(submit_node),
                            disabledCls: 'none',
                            width: 700,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('purpose').getValue();
                                    //触发后台保存
                                    autoSaveAtt('purpose', value);
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 100 0 100', labelWidth: 100},
                    items: [
                        {
                            xtype: 'combo',
                            fieldLabel: whetherReturnInventoryText,//是否需要退库
                            name: 'whetherReturnInventory',
                            id: 'whetherReturnInventory',
                            multiSelect: false,
                            anyMatch: true,
                            editable: false,
                            disabled: disableNode(submit_node),
                            disabledCls: 'none',
                            store: ['是', '否'],
                            width: 350,
                            listeners: {
                                select: function (e) {
                                    var value = Ext.getCmp('whetherReturnInventory').getValue();
                                    if (ght_dataLoadedFlag) {
                                        //触发后台保存
                                        autoSaveAtt('whetherReturnInventory', value);
                                    }
                                }
                            }
                        }
                    ]
                },
                pickingGrid,
                /*{
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '2.领料处理信息',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        //layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            disabled: disableNode(PMC_node) ? disableNode(PMCAndDepartmentHeadConfirm_node) : false,
                            disabledCls: 'none',
                            xtype: 'textarea',
                            fieldLabel: pmcResultText,
                            name: 'pmcResult',
                            id: 'pmcResult',
                            width: 1000,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('pmcResult').getValue();
                                    //触发后台保存
                                    autoSaveAtt('pmcResult', value);
                                }
                            }
                        }, {
                            disabled: disableNode(departmentHeadConfirm_node) ? disableNode(PMCAndDepartmentHeadConfirm_node) : false,
                            disabledCls: 'none',
                            xtype: 'textarea',
                            fieldLabel: warehouseResultText,
                            name: 'warehouseResult',
                            id: 'warehouseResult',
                            width: 1000,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('warehouseResult').getValue();
                                    //触发后台保存
                                    autoSaveAtt('warehouseResult', value);
                                }
                            }
                        }
                        ],
                    }]
                },*/ {
                    xtype: 'panel',
                    //layout: 'hbox',
                    title: '2.到料信息确认',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [
                            {
                                xtype: 'displayfield',
                                fieldLabel: '预留单号',
                                name: 'reserveedNumber',
                                id: 'reserveedNumber',
                                width: 250,
                            },
                            {
                                disabled: false,//disableNode(engineerCheck_node),
                                disabledCls: 'none',
                                xtype: 'textfield',
                                labelWidth: 200,
                                disabled: disableNode(initiate_material_return_node),
                                fieldLabel: returnInventoryText,
                                name: 'returnInventory',
                                id: 'returnInventory',
                                width: 500,
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('returnInventory').getValue();
                                        //显示链接,并将领料单号存到退货单中
                                        setReturnInventoryUrl(value);
                                        //触发后台保存
                                        autoSaveAtt('returnInventory', value);
                                    }
                                }
                            },
                            {
                                xtype: 'displayfield',
                                name: 'returnInventoryUrl',
                                id: 'returnInventoryUrl',
                                width: 400
                            },
                        ]
                    },{//第二行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [ {
                            disabled: disableNode(engineerCheck_node),
                            disabledCls: 'none',
                            xtype: 'textarea',
                            fieldLabel: confirmResultText,
                            name: 'confirmResult',
                            id: 'confirmResult',
                            width: 1000,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('confirmResult').getValue();
                                    //触发后台保存
                                    autoSaveAtt('confirmResult', value);
                                }
                            }
                        },
                        ],

                    }
                    ]
                }//~end of 测试项目
            ]
        }]

        this.callParent();
    },//~End of initComponent

    doExportGridData: function () {
        window.location.href = '/Windchill/ptc1/picking/exportPickings?branchId=' + branchId;
    },
    listeners: {
        'afterrender': function () {


            Ext.getStore('pickingStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/picking/getFormInfo?branchId=' + branchId,

                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == "success") {
                        let data = obj.data;
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(data);

                        var recipientComb = Ext.getCmp('recipient');
                        if(data['recipient']){
                            recipientComb.setRawValue(data['recipient']);
                        }
                        var addresseeComb = Ext.getCmp('addressee');
                        if(data['addressee']){
                            addresseeComb.setRawValue(data['addressee']);
                        }
                        ght_dataLoadedFlag = true
                    } else {
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});
