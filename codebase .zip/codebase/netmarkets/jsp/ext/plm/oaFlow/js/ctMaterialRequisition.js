Ext.define('PLM.view.MaterialRequisitionPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MaterialRequisitionPanel',
    title: '<font style="font-size:18px">物料申购单</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'MaterialRequisitionPanel',
    config: {
        in_objectKey: 'MaterialRequisitionPanel',
        in_objectDesc: '定制的Form表单',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //***************加载表单信息**********************
        var me = this;

        //***************    **********************
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var materialNumberText = '物料编码';
        var materialDescriptionText = '物料描述';
        var amountText = '数量';
        var unitText = '单位';
        var requireDateText = '需求日期<br>Proposed time';
        var estimatedUnitPriceText = '预计单价（元）';
        var theUserText = '使用人';
        var storageLocationText = '存放地点';
        var factoryText = '工厂';
        var storeLocationText = '库存地点';
        var purchaseOrganizationText = '采购组织';
        //文档信息
        var docNumberText = '系统文件编号';
        var versionText = '版本';
        var attachmentText = '附件';
        var systemAttachmentText = '外发系统附件';
        var outFormatRequirementText = '外发格式要求<br/>（中间格式只对epm文件有效）';
        var docDescriptionText = '文档说明';
        //供应商信息
        var tagIdText = '编号';
        var supplierNameText = '供应商名称';
        var supplierEmailText = '供应商邮箱';
        var supplierAccountText = '供应商账号';
        var remarkText = '备注';
        //表单
        var categoryText = '科类分配类别';
        var finishedProductCenterText = '成本中心';
        var orderNumberText = '项目内部订单号';
        var isPDTExpenseGroupText = '是否为PDT项目费用';
        var belongTeamText = '归属团队';
        var panleProjectNumberText = '项目编号';
        var isContainedApparatusGroupText = '是否包含仪器和计量器';
        var isOutSourceGroupText = '是否有文档需外发';
        var reasonText = '申报理由';

        if (!disableNode(ActivityNode_MaterialRequisition_submit)) {
            materialNumberText = redStarFlag + blueFlagStart + materialNumberText + blueFlagEnd;
            materialDescriptionText = blueFlagStart + materialDescriptionText + blueFlagEnd;
            amountText = redStarFlag + blueFlagStart + amountText + blueFlagEnd;
            requireDateText = redStarFlag + blueFlagStart + requireDateText + blueFlagEnd;
            estimatedUnitPriceText = redStarFlag + blueFlagStart + estimatedUnitPriceText + blueFlagEnd;
            theUserText = redStarFlag + blueFlagStart + theUserText + blueFlagEnd;
            storageLocationText = redStarFlag + blueFlagStart + storageLocationText + blueFlagEnd;
            factoryText = redStarFlag + blueFlagStart + factoryText + blueFlagEnd;
            storeLocationText = redStarFlag + blueFlagStart + storeLocationText + blueFlagEnd;
            purchaseOrganizationText = redStarFlag + blueFlagStart + purchaseOrganizationText + blueFlagEnd;
            docNumberText = redStarFlag + blueFlagStart + docNumberText + blueFlagEnd;
            versionText = redStarFlag + blueFlagStart + versionText + blueFlagEnd;
            attachmentText =  blueFlagStart + attachmentText + blueFlagEnd;
            unitText =  blueFlagStart + unitText + blueFlagEnd;
            systemAttachmentText =  blueFlagStart + systemAttachmentText + blueFlagEnd;
            outFormatRequirementText =  redStarFlag +blueFlagStart + outFormatRequirementText + blueFlagEnd;
            docDescriptionText = blueFlagStart + docDescriptionText + blueFlagEnd;
            categoryText = redStarFlag + blueFlagStart + categoryText + blueFlagEnd;
            finishedProductCenterText = redStarFlag + blueFlagStart + finishedProductCenterText + blueFlagEnd;
            orderNumberText = redStarFlag + blueFlagStart + orderNumberText + blueFlagEnd;
            isPDTExpenseGroupText = redStarFlag + blueFlagStart + isPDTExpenseGroupText + blueFlagEnd;
            belongTeamText = redStarFlag + blueFlagStart + belongTeamText + blueFlagEnd;
            isContainedApparatusGroupText = redStarFlag + blueFlagStart + isContainedApparatusGroupText + blueFlagEnd;
            reasonText = redStarFlag + blueFlagStart + reasonText + blueFlagEnd;
            panleProjectNumberText = redStarFlag + blueFlagStart + panleProjectNumberText + blueFlagEnd;
        }
        if (!disableNode(ActivityNode_MaterialRequisition_write)){
            tagIdText = redStarFlag + blueFlagStart + tagIdText + blueFlagEnd;
            supplierNameText = redStarFlag + blueFlagStart + supplierNameText + blueFlagEnd;
            remarkText =  blueFlagStart + remarkText + blueFlagEnd;
            supplierEmailText =  blueFlagStart + remarkText + blueFlagEnd;
            supplierAccountText =  blueFlagStart + supplierAccountText + blueFlagEnd;
        }


        //科类分配类别
        var categoryCombo = new Ext.form.ComboBox({
            fieldLabel: categoryText,
            // typeAhead: true,
            triggerAction: 'all',
            name: 'category',
            editable: false,
            id: 'category',
            lazyRender: true,
            width: 250,
            labelWidth: 100,
            disabledCls: 'none',
            valueField: 'key',
            displayField: 'displayText',
            disabled: disableNode(ActivityNode_MaterialRequisition_submit),
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [['K', 'K-内部订单非必填'], ['1', '1-内部订单必填']]
            }),

            listeners: {
                blur: function (e) {

                    var value = Ext.getCmp('category').getValue();
                    if (value == '1') {
                        // Ext.getCmp('orderNumber').setReadOnly(true);
                        // Ext.getCmp('orderType').setReadOnly(true);
                        Ext.getCmp('orderNumber').setDisabled(false);
                        //Ext.getCmp('orderType').setDisabled(false);
                    } else {
                        Ext.getCmp('orderNumber').setDisabled(true);
                        //Ext.getCmp('orderType').setDisabled(true);
                    }
                    //触发后台保存
                    autoSaveAtt('category', value);
                }
            }
        });

        var categoryComboDisplay = new Ext.form.field.Display({
            labelWidth: 100,
            width: 200,
            fieldLabel: '<font color=red>*</font>科类分配类别',
            // id:'productLine',
            name: 'category'
        });


        //belongTeam
        var belongTeamCombo = new Ext.form.ComboBox({
            fieldLabel: belongTeamText,
            // typeAhead: true,
            triggerAction: 'all',
            forceSelection: true, //forceSelection 是否能够手填
            editable: false,
            name: 'belongTeam',
            id: 'belongTeam',
            disabledCls: 'none',
            disabled: disableNode(ActivityNode_MaterialRequisition_submit),
            lazyRender: true,
            // disabled:true,
            width: 350,
            margin: '0 0 0 10',
            labelWidth: 100,
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [['海外家用报警器', '海外家用报警器'], ['电气火灾&消防设备电源监控', '电气火灾&消防设备电源监控'], ['防火门监控系统', '防火门监控系统'],
                    ['消防应急照明和疏散指示系统', '消防应急照明和疏散指示系统'], ['海外火灾报警系统', '海外火灾报警系统'], ['工业消防报警系统产品', '工业消防报警系统产品'],
                    ['火灾报警系统', '火灾报警系统'], ['技术开发团队', '技术开发团队'], ['线上产品开发团队', '线上产品开发团队']]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('belongTeam').getRawValue();

                    //触发后台保存
                    autoSaveAtt('belongTeam', value);
                }
            }
        });


        var belongTeamComboDisplay = new Ext.form.field.Display({
            labelWidth: 100,
            width: 350,
            margin: '0 0 0 10',
            fieldLabel: '<font color=red>*</font>归属团队',
            name: 'belongTeam'
        });
        //=====================================================================
        //=====================================================================
        // Ext.define('ProjectModel', {
        //     extend: 'Ext.data.Model',
        //     fields: [
        //             'projectNumber', 'name'
        //         ],
        // });
        var projectListStore = Ext.create('Ext.data.Store', {
            fields: [
                'info'
            ],
            id: 'projectListStore',
            // autoSync: true,//同步更新
            // pruneModifiedRecords: true,
            forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/workReport/getOwnerProjectList',
                method: 'GET',
                reader: {
                    type: 'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'items',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var costCenterListStore = Ext.create('Ext.data.Store', {
            fields: [
                'info'
            ],
            id: 'costCenterListStore',
            // autoSync: true,//同步更新
            // pruneModifiedRecords: true,
            forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/materialRequisition/getComBoxInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var orderListStore = Ext.create('Ext.data.Store', {
            fields: [
                'info'
            ],
            id: 'orderListStore',
            // autoSync: true,//同步更新
            // pruneModifiedRecords: true,
            forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/materialRequisition/getComBoxInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var seatListStore = Ext.create('Ext.data.Store', {
            fields: [
                'info'
            ],
            id: 'seatListStore',
            // autoSync: true,//同步更新
            // pruneModifiedRecords: true,
            forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/materialRequisition/getComBoxInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });


        /*var projectListCombo = new Ext.form.field.ComboBox({

            fieldLabel: '<font color=red>*</font>项目名称',
            triggerAction: 'all',
            editable : true,
            allowBlank : true,
            lazyRender:true,
            // triggerAction: 'all',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'productionD_statusNumber',
            name: 'productionD_statusNumber',
            mode: 'local',
            store: projectListStore,
            // valueField: 'name',
            displayField: 'name',
            listeners: {
                blur: function (e) {
                    let displayName='';
                    var value = Ext.getCmp('productionD_statusNumber').getValue();
                    let store = e.getStore();
                    store.each(function(rec){
                        if(rec.get('name') == value){
                            displayName =  rec.get('projectNumber');
                        }
                    });
                    autoSaveAtt('productionD_statusNumber',value);
                    Ext.getCmp('panleProjectNumber').setValue(displayName);
                    autoSaveAtt('panleProjectNumber',displayName);
                }
            }

        });*/

        var projectNameComboDisplay = new Ext.form.field.Display({
            labelWidth: 100,
            width: 350,
            margin: '0 0 0 10',
            fieldLabel: '<font color=red>*</font>项目名称',
            id: 'projectName',
            name: 'projectName',
            listeners: {
                change: function (e) {
                    var value = Ext.getCmp('projectName').getValue();
                    //触发后台保存
                    if (ght_dataLoadedFlag) {
                        autoSaveAtt('projectName', value);
                    }
                }
            }
        });
        //===================获取项目编号开始===================================

        var projectNumberStore = Ext.create('Ext.data.Store', {
            id: 'projectNumberStore',
            // model: 'materialRequisitionModel',
            fields: ['projectNumber'],//对应map的key值
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/materialRequisition/getAllProjectNumber',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',//对应controller返回的数值
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: true
        });

        /*//项目编号
        var projectNumberCombo = new Ext.form.ComboBox({
            fieldLabel: '<font color=red>*</font>项目编号',
            typeAhead: true,
            triggerAction: 'all',
            name: 'projectNumber',
            id: 'projectNumber',
            lazyRender: true,
            width: 200,
            labelWidth: 70,
            margin: '0 0 0 10',
            mode: 'local',
            store: projectNumberStore,
            valueField: 'projectNumber',
            displayField: 'projectNumber',
            disabled: true,
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('projectNumber').getRawValue();
                    //触发后台保存
                    autoSaveAtt('projectNumber', value);
                }
            }
        });*/

        var projectNumberComboDisplay = new Ext.form.field.Display({
            labelWidth: 100,
            width: 200,
            margin: '0 0 0 10',
            fieldLabel: '<font color=red>*</font>项目编号',
            name: 'projectNumber'
        });


        //===================获取项目编号结束===================================
        var materialRequisitionInfoPanel = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: true,
            autoScroll: true,
            items: [{
                border: false,
                layout: 'hbox',
                align: 'middle',
                margin: '10 0 0 10',
                items: [


                    categoryCombo,
                    {
                        xtype: 'combo',
                        width: 200,
                        margin: '0 0 10 10',
                        fieldLabel: finishedProductCenterText,
                        name: 'finishedProductCenter',
                        id: 'finishedProductCenter',
                        labelWidth: 70,
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        store:costCenterListStore,
                        disabledCls: 'none',
                        displayField:'info',
                        disabled: disableNode(ActivityNode_MaterialRequisition_submit),
                        listeners: {
                            select: function (e) {
                                var value = Ext.getCmp('finishedProductCenter').getValue();
                                autoSaveAtt('finishedProductCenter', value);
                            }
                        }
                    },
                    {
                        xtype: 'combo',
                        width: 300,
                        margin: '0 0 10 10',
                        disabledCls: 'none',
                        disabled: disableNode(ActivityNode_MaterialRequisition_submit),
                        fieldLabel:orderNumberText,
                        name: 'orderNumber',
                        id: 'orderNumber',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        store:orderListStore,
                        displayField:'info',
                        labelWidth: 115,
                        listeners: {
                            select: function (e) {
                                var value = Ext.getCmp('orderNumber').getValue();
                                autoSaveAtt('orderNumber', value);
                            }
                        }
                    },
                    // {
                    //     xtype:allowEdit?'textfield':'displayfield',
                    //     width:150,
                    //     margin:'0 0 10 10',
                    //     fieldLabel: '<font color="red">*</font>订单类型',
                    //     name:'orderType',
                    //     id:'orderType',
                    //     labelWidth:75,
                    //     // disabled:true,
                    //     listeners: {
                    //         blur: function (e) {
                    //             var value = Ext.getCmp('orderType').getValue();
                    //             autoSaveAtt('orderType',value);
                    //         }
                    //     }
                    // },
                    {
                        xtype: 'radiogroup',
                        disabledCls: 'none',
                        disabled: disableNode(ActivityNode_MaterialRequisition_submit),
                        margin: '0 0 10 10 ',
                        fieldLabel: isPDTExpenseGroupText,
                        width: 150,
                        name: 'isPDTExpenseGroup',
                        id: 'isPDTExpenseGroup',
                        labelWidth: 130,
                        items: [{
                            inputValue: '是',
                            boxLabel: '是',
                            name: 'isPDTExpense',
                            disabledCls: 'none'
                        }, {
                            inputValue: '否',
                            boxLabel: '否',
                            margin: '0 0 0 10',
                            name: 'isPDTExpense',
                            disabledCls: 'none'
                        }],
                        listeners: {
                            change: function (field, newValue, oldValue) {
                                if (!ght_dataLoadedFlag) {
                                    //阻止加载数据时执行后台保存
                                    return;
                                }
                                if (newValue.isPDTExpense == '是') {
                                    Ext.getCmp('belongTeam').setDisabled(false);
                                    Ext.getCmp('projectNumber').setDisabled(false);
                                } else if (newValue.isPDTExpense == '否' || newValue.isPDTExpense == null) {
                                    Ext.getCmp('belongTeam').setDisabled(true);
                                    Ext.getCmp('projectNumber').setDisabled(true);
                                }
                                //触发后台保存
                                autoSaveAtt('isPDTExpense', newValue.isPDTExpense);
                            },
                        }
                    }
                ]
            }, {
                border: false,
                layout: 'hbox',
                align: 'middle',
                margin: '10 0 0 0',
                items: [

                    belongTeamCombo,

                    // {
                    //     xtype:allowEdit?'combo':'displayfield',
                    //     width:200,
                    //     margin:'0 0 10 10',
                    //     fieldLabel: '<font color="red">*</font>项目名称',
                    //     id:'projectName',
                    //     store: projectListStore,
                    //     valueField: 'projectNumber',
                    //     displayField: 'name',
                    //     name:'projectName',
                    //     labelWidth:70,
                    //     listeners: {
                    //         blur: function (e) {
                    //             let displayName='';
                    //             var value = Ext.getCmp('projectName').getValue();
                    //             var display = Ext.getCmp('projectName').getRawValue();
                    //             console.log("value==="+value)
                    //             console.log("display==="+display)
                    //             autoSaveAtt('projectName',display);
                    //             // autoSaveAtt('projectName',display);
                    //             autoSaveAtt('projectListStore',display);
                    //
                    //             Ext.getCmp('panleProjectNumber').setValue(value);
                    //             autoSaveAtt('panleProjectNumber',value);
                    //         }
                    //     }
                    // },
                    {
                        xtype: 'textfield',
                        // text:'',
                        width: 250,
                        margin: '0 0 10 10',
                        fieldLabel: panleProjectNumberText,
                        id: 'projectNumber',
                        name: 'projectNumber',
                        disabledCls: 'none',
                        disabled: disableNode(ActivityNode_MaterialRequisition_submit),
                        labelWidth: 70,
                        listeners: {
                            blur: function () {
                                var value = Ext.getCmp('projectNumber').getValue();
                                checkProjectNumber('projectNumber', value);
                            }
                        }
                    },
                    projectNameComboDisplay,
                    // allowEdit?projectNumberCombo:projectNumberComboDisplay,
                    {
                        xtype: 'radiogroup',
                        disabledCls: 'none',
                        disabled: disableNode(ActivityNode_MaterialRequisition_submit),
                        margin: '0 0 10 10',
                        fieldLabel: isContainedApparatusGroupText,
                        width: 150,
                        name: 'isContainedApparatusGroup',
                        id: 'isContainedApparatusGroup',
                        labelWidth: 150,
                        items: [{
                            inputValue: '是',
                            boxLabel: '是',
                            name: 'isContainedApparatus',
                            disabledCls: 'none'
                        }, {
                            inputValue: '否',
                            boxLabel: '否',
                            margin: '0 0 0 10',
                            name: 'isContainedApparatus',
                            disabledCls: 'none'
                        }],
                        listeners: {

                            change: function (field, newValue, oldValue) {
                                if (!ght_dataLoadedFlag) {
                                    //阻止加载数据时执行后台保存
                                    return;
                                }

                                //触发后台保存
                                autoSaveAtt('isContainedApparatus', newValue.isContainedApparatus);
                            },
                        }
                    }
                ]
            }, /*{
                xtype: 'radiogroup',
                disabledCls: 'none',
                disabled: disableNode(ActivityNode_MaterialRequisition_submit),
                margin: '0 0 10 10',
                fieldLabel: isOutSourceGroupText,
                width: 50,
                name: 'isOutSourceGroup',
                id: 'isOutSourceGroup',
                labelWidth: 95,
                items: [{
                    inputValue: '是',
                    boxLabel: '是',
                    name: 'isOutSource',
                    disabledCls: 'none'
                }, {
                    inputValue: '否',
                    boxLabel: '否',
                    margin: '0 0 0 10',
                    name: 'isOutSource',
                    disabledCls: 'none'
                }],
                listeners: {
                    change: function (field, newValue, oldValue) {
                        if (!ght_dataLoadedFlag) {
                            //阻止加载数据时执行后台保存
                            return;
                        }
                        //触发后台保存
                        autoSaveAtt('isOutSource', newValue.isOutSource);
                    },
                }
            }*/
                , {
                    border: false,
                    layout: 'hbox',
                    margin: '10 0 20 10',
                    items: [{
                        border: false,
                        xtype: 'textarea',
                        width: 500,
                        fieldLabel: reasonText,
                        id: 'reason',
                        name: 'reason',
                        labelWidth: 100,
                        editable: true,
                        disabledCls: 'none',
                        disabled: disableNode(ActivityNode_MaterialRequisition_submit),
                        value: '',
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('reason').getValue();
                                autoSaveAtt('reason', value);
                            }
                        }
                    }
                    ]
                }
            ]
        };


        // create the Data Store

        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var cellEditing2 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing3 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        Ext.define('PLM.common.CtPartNumberStore', {
            extend: 'Ext.data.Store',
            alias: 'widget.CtPartNumberStore',
            fields: ['partNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/materialRequisition/getAllPartNumber',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });

        Ext.define('PLM.common.CtPartNumberCombo', {
            extend: 'Ext.form.field.ComboBox',
            alias: 'widget.CtPartNumberCombo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'local',
            mode: 'remote',
            displayField: 'partNumber',
            valueField: 'partNumber',
            forceSelection: true,
            minChars: 2,
            allowBlank: true,
            editable: true,
            anyMatch: true
        });
        var CtPartNumberStore = Ext.create('PLM.common.CtPartNumberStore', {
            storeId: 'CtPartNumberStore'
        });
        var partNumberCombo = Ext.create('PLM.common.CtPartNumberCombo', {
            store: CtPartNumberStore
        });

        //===============表格开始======================
        //供应商名称下拉
        var providerStore = Ext.create('Ext.data.Store', {
            fields: ['supplierName'],
            id: 'providerStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/supplier/getSupplierInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    messageProperty: 'error',
                    root: 'data'
                }
            }),
            autoLoad: true
        });

        //临时编号下拉
        var tagStore = Ext.create('Ext.data.Store', {
            fields: ['tagId'],
            id: 'tagStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/materialRequisition/getTagIds?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    messageProperty: 'error',
                    root: 'data'
                }
            }),
            autoLoad: false
        });

        var providerCombo = Ext.create('Ext.form.field.ComboBox', {
            displayField: 'supplierName',
            valueField: 'supplierName',
            store: providerStore,
            id: 'demandType',
            typeAhead: true,
            triggerAction: 'all',
            queryMode: 'local',
            allowBlank: true,
            anyMatch: true
        });
        Ext.define('materialRequisitionModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'materialNumber', 'materialDescription', 'tagId',
                'materialGroup', 'amount', 'unit', 'requireDate', 'estimatedUnitPrice',
                'estimatedUnitAmount', 'theUser', 'storageLocation', 'factory', 'storeLocation', 'purchaseOrganization',
                'projectName'
            ],
            idProperty: 'id'
        });

        //获取使用人名单，全部人
        var theUserStore = Ext.create('PLM.common.CtAllUserStore', {
            storeId: 'theUserStore'
        });

        var theUserCombo = Ext.create('PLM.common.CtAllUserCombo', {
            width: 250,
            store: theUserStore,
            name: "theUser",
            id: "theUser",
        });

        //工厂
        var factoryCombo = new Ext.form.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            name: 'factory',
            id: 'factory',
            lazyRender: true,
            width: 100,
            mode: 'local',
            store: new Ext.data.SimpleStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [['1001', '1001'], ['1002', '1002'], ['1100', '1100'], ['1200', '1200']]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        //编号
        var tagCombo = new Ext.form.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            name: 'tagCombo',
            id: 'tagCombo',
            lazyRender: true,
            width: 100,
            mode: 'local',
            store: tagStore,
            valueField: 'tagId',
            displayField: 'tagId',
        });

        //库存地点
        var storeLocationCombo = new Ext.form.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            name: 'storeLocation',
            id: 'storeLocation',
            lazyRender: true,
            width: 100,
            mode: 'local',
            store: seatListStore,
            valueField: 'info',
            displayField: 'info'
        });

        //采购组织
        var purchaseOrganizationCombo = new Ext.form.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            name: 'purchaseOrganization',
            id: 'purchaseOrganization',
            lazyRender: true,
            width: 100,
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [['1000', '1000'], ['1100', '1100'], ['1200', '1200']]
            }),
            valueField: 'key',
            displayField: 'displayText'
        });

        var materialRequisitionStore = Ext.create('Ext.data.Store', {
            id: 'materialRequisitionStore',
            model: 'materialRequisitionModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/materialRequisition/getItemInfo?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var materialRequisitionGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            margin: '20 0 0 0',
            store: Ext.getStore('materialRequisitionStore'),
            id: 'materialRequisitionGrid',
            //forceFit : true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            maxHeight: 250,
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            // selModel: {
            //     mode: 'MULTI' //可以多选
            // },

            selType: 'checkboxmodel',//有全选勾选框
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '编号', dataIndex: 'tagId', width: 120},
                {text: materialNumberText, dataIndex: 'materialNumber', width: 120, editor: partNumberCombo},
                {
                    text: materialDescriptionText, dataIndex: 'materialDescription', width: 100, editor: 'textfield',
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value)
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        return value;
                    }
                },
                {text: '物料组', dataIndex: 'materialGroup', width: 100, editor: 'displayfield'},
                {
                    text: amountText, dataIndex: 'amount', width: 100, editor: {
                        xtype: 'numberfield',
                        minValue: 0,
                        defaultValue: 0

                    }
                },
                {text: unitText, dataIndex: 'unit', width: 100, editor: 'textfield'},
                {
                    text: requireDateText,
                    dataIndex: 'requireDate',
                    width: 100,
                    editor: new Ext.form.DateField({minValue: new Date(), format: 'Y-m-d',}),
                    menuDisabled: true,
                    align: 'center',
                    renderer: function (value) {
                        if (value != null && value != undefined && value != '') {
                            var date = new Date(value);
                            var time = Ext.Date.format(date, "Y-m-d")
                            return time;
                        }
                        return value;
                    }
                },
                {
                    text:estimatedUnitPriceText, dataIndex: 'estimatedUnitPrice', width: 100, editor:
                        {
                            xtype: 'numberfield',
                            minValue: 0,
                            defaultValue: 0
                        }
                },
                {text: '预计金额（元）', dataIndex: 'estimatedUnitAmount', width: 100},
                {text: theUserText, dataIndex: 'theUser', width: 100, editor: theUserCombo},
                {text: storageLocationText, dataIndex: 'storageLocation', width: 100, editor: 'textfield'},
                {text: factoryText, dataIndex: 'factory', width: 100, editor: factoryCombo},
                {text:storeLocationText, dataIndex: 'storeLocation', width: 100, editor: storeLocationCombo},
                {text: purchaseOrganizationText, dataIndex: 'purchaseOrganization', width: 100, editor: purchaseOrganizationCombo},
            ],

            //表格权限设置
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if (disableNode(ActivityNode_MaterialRequisition_submit)) {
                        return false;
                    }

                },
            },


            tbar: [{
                text: '添加',
                id: 'add',
                name: 'add',
                iconCls: 'icon icon-add',
                scope: this,
                hidden: disableNode(ActivityNode_MaterialRequisition_submit),
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('materialRequisitionStore').reload();
                    };
                    //创建空行,含branchId
                    insertItemData('ZMaterialRequisitionItem', callbackFn);
                }

            }, '&nbsp;', {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                hidden: disableNode(ActivityNode_MaterialRequisition_submit),
                handler: function () {

                    let selectionArr = materialRequisitionGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('materialRequisitionStore').reload()
                    };
                    deleteData('ZMaterialRequisitionItem', obj, callbackFn);
                }
            }]
        });
        materialRequisitionGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');


                if (tField == 'requireDate') {
                    tValue = Ext.Date.format(tValue, "Y-m-d");
                }

                if (tField == 'materialNumber' && tValue != null) {
                    Ext.Ajax.request({
                        scope: this,
                        url: '/Windchill/ptc1/materialRequisition/getMaterialDescriptionAndMaterialGroup',
                        params: {
                            materialNumber: tValue
                        },
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {
                                tRecord.set('materialGroup', obj.data['materialGroup']);
                                tRecord.set('materialDescription', obj.data['materialDescription']);
                                tRecord.set('unit', obj.data['materialUnit']);
                                debugger
                                saveMockItemData('ZMaterialRequisitionItem', itemId, 'materialGroup', obj.data['materialGroup'], callbackFn);
                                saveMockItemData('ZMaterialRequisitionItem', itemId, 'materialDescription', obj.data['materialDescription'], callbackFn);
                                saveMockItemData('ZMaterialRequisitionItem', itemId, 'unit', obj.data['materialUnit'], callbackFn);

                            } else {
                                alert(obj.message);
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：保存信息失败，请检查网络！');
                        }
                    }); //~End of Ajax request
                }

                if (tRecord.get('estimatedUnitPrice') != 'null' && tRecord.get('amount') != 'null') {
                    var estimatedUnitAmountValue = tRecord.get('estimatedUnitPrice') * tRecord.get('amount');
                    tRecord.set('estimatedUnitAmount', estimatedUnitAmountValue);
                    saveMockItemData('ZMaterialRequisitionItem', itemId, 'estimatedUnitAmount', estimatedUnitAmountValue);
                } else {
                    tRecord.set('estimatedUnitAmount', "");
                }

                var callbackFn = function () {
                    tRecord.commit();
                };
                // saveItemData(tRecord.data,callbackFn)
                saveMockItemData('ZMaterialRequisitionItem', itemId, tField, tValue, callbackFn);
            });

        //================================表格结束========================================


        //外发格式要求
        var outFormatRequirementCobo = new Ext.form.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            name: 'outFormatRequirement',
            id: 'outFormatRequirement',
            lazyRender: true,
            width: 100,
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                // data: [['源文件', '源文件'], ['中间格式', '中间格式']]
                data: [['源文件', '源文件'], ['中间格式', '中间格式'], ['源文件和中间格式', '源文件和中间格式']]
            }),
            valueField: 'key',
            displayField: 'displayText'
        });


        Ext.define('materialRequisitionModel2', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'tagId', 'attachmentPath', 'versionState','budget', 'interiorVersion', 'systemAttachment', 'docNumber', 'docName', 'attachment', 'outFormatRequirement'],
            idProperty: 'id'
        });
        Ext.define('materialRequisitionModel3', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'tagId', 'supplierName', 'supplierEmail', 'supplierAccount', 'remark'],
            idProperty: 'id'
        });


        var materialRequisitionStore2 = Ext.create('Ext.data.Store', {
            id: 'materialRequisitionStore2',
            model: 'materialRequisitionModel2',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/materialRequisition/getSupplierDocInfo?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });
        var materialRequisitionStore3 = Ext.create('Ext.data.Store', {
            id: 'materialRequisitionStore3',
            model: 'materialRequisitionModel3',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/materialRequisition/getSupplierInfo?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var versionStore = new Ext.data.ArrayStore({
            id: 'versionStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/supplier/getVersion',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        var attachmentStore = new Ext.data.ArrayStore({
            id: 'attachmentStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/supplier/getSystemAttachment',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        //版本
        var versionCom = new Ext.form.ComboBox({
            name: 'versionCom',
            id: 'versionCom',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: versionStore,
            valueField: 'version',
            displayField: 'version'
        });

        var attachmentCombo = new Ext.form.ComboBox({
            name: 'attachmentCombo',
            id: 'attachmentCombo',
            multiSelect: true,
            valueField: 'attachment',
            displayField: 'attachment',
            anyMatch: true,
            editable: false,
            store: attachmentStore
        });

        var problemTerritoryCombo = new Ext.form.ComboBox({
            name: 'problemTerritoryCombo',
            id: 'problemTerritoryCombo',
            multiSelect: true,
            queryMode: 'local',
            valueField: 'attachment',
            displayField: 'attachment',
            anyMatch: true,
            editable: false,
            store: attachmentStore
        });

        var materialRequisitionGrid2 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing2],
            margin: '20 0 0 0',
            store: materialRequisitionStore2,
            id: 'materialRequisitionGrid2',
            //forceFit : true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            maxHeight: 250,
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            // selModel: {
            //     mode: 'MULTI' //可以多选
            // },

            selType: 'checkboxmodel',//有全选勾选框
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [
                {xtype: 'rownumberer', width: '50'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'attachmentPath', menuDisabled: true, hidden: true},
                {text: '编号', dataIndex: 'tagId', width: 70, menuDisabled: true, editor: tagCombo},
                {text: docNumberText, dataIndex: 'docNumber', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '文档名称', dataIndex: 'docName', width: 100, menuDisabled: true},
                {text: versionText, dataIndex: 'version', width: 100, editor: versionCom, menuDisabled: true},
                {text: '版本状态', dataIndex: 'versionState', width: 100, menuDisabled: true},
                {text: '内部版本', dataIndex: 'interiorVersion', width: 100, menuDisabled: true},
                {text: attachmentText, dataIndex: 'attachment', width: 250, menuDisabled: true},
                {
                    text: systemAttachmentText, dataIndex: 'systemAttachment', width: 250, editor: problemTerritoryCombo, menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        var temp = new Array();
                        if (value=='' || value == undefined || value == null){
                            return '';
                        }
                        if(!Array.isArray(value)){
                            value += ",";
                            var start = 0;
                            var pos = value.indexOf(',');
                            while (pos > -1) {
                                temp.push(value.substr(start, pos-start));
                                start = pos + 1;
                                pos = value.indexOf(',', pos + 1);
                            }
                            record.set("systemAttachment",temp);
                            record.commit();
                        }else{
                            temp = value;
                        }
                        //提示tip
                        metaData.tdAttr = " data-qtip = '"+temp+"'";
                        return temp;
                    }
                },
                {
                    text: outFormatRequirementText,
                    dataIndex: 'outFormatRequirement',
                    width: 150,
                    editor: outFormatRequirementCobo, menuDisabled: true
                },
                {
                    text: docDescriptionText,
                    dataIndex: 'docDescription',
                    width: 100,
                    editor: 'textfield',
                    menuDisabled: true
                },
                {text: '', dataIndex: '', width: 10,},
            ],

            //表格权限设置
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if (disableNode(ActivityNode_MaterialRequisition_submit)) {
                        return false;
                    }else {
                        if (tField == 'version') {
                            let selectionArr = materialRequisitionGrid2.getSelectionModel().getSelection();
                            if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                return;
                            }
                            var number = selectionArr[0].data['docNumber']
                            if (!number) {
                                Ext.getCmp('saveStatus2').setText('请先填写编号！');
                                return false;
                            } else {
                                getVersion(number);
                            }
                        }
                        if (tField == 'systemAttachment') {
                            let selectionArr = materialRequisitionGrid2.getSelectionModel().getSelection();
                            if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                return;
                            }
                            var version = selectionArr[0].data['version']
                            var docNumber = selectionArr[0].data['docNumber']
                            if (!version) {
                                Ext.getCmp('saveStatus2').setText('请先填写版本！');
                                return false;
                            } else {
                                getSystemAttachment(docNumber, version);
                            }
                        }
                        Ext.getCmp('saveStatus2').setText(' ');
                        return true;

                    }


                }
            },

            tbar: [
                {
                    text: '添加',
                    iconCls: 'icon icon-add',
//		            hidden:allowEdit?false:true
                    scope: this,
                    hidden: disableNode(ActivityNode_MaterialRequisition_submit),
                    handler: function () {

                        var callbackFn = function () {
                            Ext.getStore('materialRequisitionStore2').reload();
                        };

                        //创建空行,含branchId
                        insertItem2Data('ZMRSupplierDocInfo', callbackFn);
                    }


                }, '&nbsp;', {
                    text: '删除',
                    iconCls: 'icon icon-delete',
//					hidden:allowEdit?false:true,
                    scope: this,
                    hidden: disableNode(ActivityNode_MaterialRequisition_submit),
                    handler: function () {
                        let selectionArr = materialRequisitionGrid2.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('materialRequisitionStore2').reload();
                        };
                        deleteData('ZMRSupplierDocInfo', obj, callbackFn);
                    }
                }, '&nbsp;', {

                    xtype: 'filefield',
                    hidden: disableNode(ActivityNode_MaterialRequisition_submit),
                    buttonOnly: true,
                    id: 'head_uploadFile',
                    name: 'head_uploadFile',
                    // hidden:true,
                    hideLabel: true,
                    buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加附件',
                    allowBlank: false,
                    scope: this,
                    listeners: {

                        'focus': function () {
                            let selectionArr = materialRequisitionGrid2.getSelectionModel().getSelection();
                            if (selectionArr.length == 0) {
                                alert("未选择添加附件行！");
                                return;
                            }
                            /*//alert(selectionArr[0].get("attachment"))
                            if (selectionArr[0].get("attachment") != null){
                                alert('只能上传一个附件');
                                return;
                            }*/
                            if (selectionArr.length >= 2) {
                                alert("不支持多行选择添加附件！");
                                return;
                            }

                        },
                        'change': function (fb, newValue) {
                            if (!newValue) {
                                return;
                            }
                            let selectionArr = materialRequisitionGrid2.getSelectionModel().getSelection();

                            var outDrawings = selectionArr[0].get("docNumber");
                            // store.reload();
                            if (outDrawings == '' || outDrawings == undefined) {
                                alert("请先填写外发图纸编号!");
                                return;
                            } else if (selectionArr.length == 0) {
                                alert("添加附件失败，未选择添加附件对象!");
                                return;
                            } else if (selectionArr.length >= 2) {
                                alert("不支持多行添加附件操作，请确认要添加的行");
                                return;
                            } else {

                                var file = document.querySelector('[id=' + 'head_uploadFile' + '-button-fileInputEl]');
                                var formData = new FormData();
                                formData.append('head_uploadFile' + '-button-fileInputEl', file.files[0]);
                                fb.reset();//清空表单的值
                                var myMask = new Ext.LoadMask({
                                    msg: '正在上传，请稍候......',
                                    target: this.findParentByType('panel')
                                });


                                myMask.show();
                                $.ajax({
                                    url: '/Windchill/ptc1/materialRequisition/uploadFiles?branchId=' + branchId + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + 'head_node',
                                    type: 'POST',
                                    cache: false,
                                    data: formData,
                                    processData: false,
                                    contentType: false
                                }).done(function (res) {
                                    myMask.hide();
                                    var obj = Ext.decode(res);
                                    var success = obj['success'];
                                    var msg = obj['msg'];
                                    if (!success) {
                                        alert(msg);
                                    } else {
                                        var fileName = obj['fileName'];
                                        var filePath = obj['filePath'];
                                        var tRecord = materialRequisitionGrid2.getSelectionModel().getSelection()[0];
                                        var attachmentValue = materialRequisitionGrid2.getSelectionModel().getSelection()[0].data.attachment;
                                        var attachmentPath = materialRequisitionGrid2.getSelectionModel().getSelection()[0].data.attachmentPath;
                                        if (attachmentValue != null && attachmentValue != '') {
                                            fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                            filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                        }
                                        tRecord.set('attachment', fileName);
                                        tRecord.set('attachmentPath', filePath);
                                        var callbackFn = function () {
                                            tRecord.commit();
                                        };
                                        var itemId = tRecord.get('id');
                                        saveMockItemData("ZMRSupplierDocInfo",itemId, 'attachment', fileName, callbackFn);
                                        saveMockItemData("ZMRSupplierDocInfo",itemId, 'attachmentPath', filePath, callbackFn);

                                    }
                                    var callbackFn = function () {
                                        //tRecord.commit();
                                        Ext.getStore('materialRequisitionGrid2').reload();
                                    };
                                }).fail(function (res) {
                                    myMask.hide();
                                    alert('上传失败！');
                                });
                            }
                        }

                    }
                }, {
                    xtype: 'tbtext',
                    text: '',
                    id: 'saveStatus2',
                    disabled: true
                },{
                    xtype: 'tbtext',
                    text: '<b>本机文件外发时上传到附件列，系统文件编号为：0000041617、0000041618 （同一天发同一个供应商请用不同的编号）</b>',
                    id: 'text',
                    disabled: true
                }]
        });

        var materialRequisitionGrid3 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing3],
            margin: '20 0 0 0',
            store: materialRequisitionStore3,
            id: 'materialRequisitionGrid3',
            //forceFit : true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            maxHeight: 250,
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            // selModel: {
            //     mode: 'MULTI' //可以多选
            // },

            selType: 'checkboxmodel',//有全选勾选框
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: tagIdText, dataIndex: 'tagId', width: 100, editor: tagCombo},
                {text: supplierNameText, dataIndex: 'supplierName', width: 100, editor: providerCombo},
                {text: supplierEmailText, dataIndex: 'supplierEmail', width: 100, editor: null},
                {text: supplierAccountText, dataIndex: 'supplierAccount', width: 100, editor: null},
                {text: remarkText, dataIndex: 'remark', width: 100, editor: 'textfield'},
            ],

            //表格权限设置
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列
                    if (disableNode(ActivityNode_MaterialRequisition_write)) {
                        return false;
                    }else {
                        var flag = true;
                        if (tField == 'supplierEmail' || tField == 'supplierAccount'){
                            providerStore.each(function (record) {
                                var sf = record.get('supplierName');
                                var supplierName = e.record.data.supplierName;
                                if (supplierName == sf){
                                    flag = false
                                    return
                                }
                            })
                        }
                        return flag;
                    }

                }
            },

            tbar: [{
                text: '添加',
                iconCls: 'icon icon-add',
//		            hidden:allowEdit?false:true
                scope: this,
                hidden: disableNode(ActivityNode_MaterialRequisition_write),
                handler: function () {

                    var callbackFn = function () {
                        Ext.getStore('materialRequisitionStore3').reload();
                    };

                    //创建空行,含branchId
                    insertItem2Data('ZMRSupplierInfo', callbackFn);
                }


            }, '&nbsp;', {
                text: '删除',
                iconCls: 'icon icon-delete',
//					hidden:allowEdit?false:true,
                scope: this,
                hidden: disableNode(ActivityNode_MaterialRequisition_write),
                handler: function () {
                    let selectionArr = materialRequisitionGrid3.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('materialRequisitionStore3').reload();
                    };
                    deleteData('ZMRSupplierInfo', obj, callbackFn);
                }
            }]
        });
        materialRequisitionGrid2.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据f
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {

                    if (tField == 'supplierName' || tField == 'docNumber' || tField =='version') {
                        Ext.getStore('materialRequisitionStore2').reload();
                    }
                    tRecord.commit();
                };
                saveMockItemData('ZMRSupplierDocInfo', itemId, tField, tValue, callbackFn);

            });
        materialRequisitionGrid3.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据f
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');


                var callbackFn = function () {
                    if (tField == 'supplierName') {
                        Ext.getStore('materialRequisitionStore3').reload();
                    }
                    tRecord.commit();
                }
                saveMockItemData('ZMRSupplierInfo', itemId, tField, tValue, callbackFn);
            });


        this.items = [materialRequisitionInfoPanel, materialRequisitionGrid, materialRequisitionGrid2, materialRequisitionGrid3];


        this.callParent();
    },//~End of initComponent

    //加载表格数据
    listeners: {
        'afterrender': function () {
            Ext.getStore('materialRequisitionStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            Ext.getStore('materialRequisitionStore2').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            Ext.getStore('materialRequisitionStore3').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            Ext.getStore('costCenterListStore').load({
                params: {
                    type: 'costCenter'
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            Ext.getStore('orderListStore').load({
                params: {
                    type: 'order'
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            Ext.getStore('seatListStore').load({
                params: {
                    type: 'seat'
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            //  form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/materialRequisition/getFormInfo?branchId=' + branchId,
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == 'success') {

                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj.data);

                        let productionD_statusNumber = obj.data.productionD_statusNumber

                        // console.log("aiusvuauvsa===="+projectName)
                        // this.projectListCombo.setValue(projectName);
                        // Ext.getCmp('projectListCombo').set(projectName);
                        ght_dataLoadedFlag = true;//数据加载后标志位设为true
                    } else {
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            });

            Ext.getStore('versionStore').load({
                params: {
                    number:'0',
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        alert('查询信息失败，请联系管理员！');
                    }
                }
            })

            Ext.getStore('attachmentStore').load({
                params: {
                    number:'0',
                    version:'0',
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        alert('查询信息失败，请联系管理员！');
                    }
                }
            });

            //~End of Ajax request
        }
    }

});
