//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//
/**
 * PbcApply研发制板
 */
var submit_node='submit_node'; //测试文档-申请人提交  用于第一个节点操作
var resourceCenter_node='resourceCenter_node';

//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ct_dataLoadedFlag = false;
/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */
function disableNode(formkey) {
    if (!allowEdit == 'true') {
        return false;
    } else {
        if (formkey == currentActKey) {
            return true;
        } else {
            return false;
        }
    }
};

//自动保存字段
function autoSaveAtt(attKey, attValue) {
    var data = {
        docBranchId: docBranchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKeyOne //全局变量，当前活动key
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/pcbApply/autoSaveAtt?oid='+oid,
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);

            if(obj.message==="success") {

            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

/**
 *保存列表中的一个属性(单元格）
 * @param data
 * @param callbackFn
 */
function saveItemData(data,callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/pcbApply/saveItemData?oid='+oid,
        params: data,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/pcbApply/insertItemData?oid='+oid,
        params: {
            docBranchId: docBranchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                callbackFn();
            } else {
                Ext.Msg.alert("保存失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

function deleteData(tableName, ids, callback) {
    var tmpGrid = Ext.getCmp('pcbApplySupplierGrid');

    var myMask = new Ext.LoadMask( {msg: "数据正在处理中，请稍后...", target: tmpGrid});
    myMask.show();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/pcbApply/deleteSupplierItemData',
        method: "POST",
        params: {
            oid: oid,
            data: Ext.encode(ids),
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['error']);
                myMask.hide();
            } else {
                myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}
/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveDocItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){
    var returnItemId = undefined;
    var mockRec = {
        oid:oid,
        dbTableName:dbTableName,
        itemId:itemId,
        dataKey:dataKey,
        dataValue:dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/pcbApply/saveDocItemData',
        params:{
            updateRecord:Ext.encode(mockRec)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);

            if(obj.message==="success") {
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if(callbackFn){
                    callbackFn();
                }
            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}



/**
 *   Doc创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertDocItemData(callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/pcbApply/insertDocItemData?oid='+oid,
        params: {
            docBranchId: docBranchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                callbackFn();
            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//删除grid信息
function deleteDocData(tableName, ids, callback) {
    var tmpGrid = Ext.getCmp('pcbApplyDocGrid');

    var myMask = new Ext.LoadMask( {msg: "数据正在处理中，请稍后...", target: tmpGrid});
    myMask.show();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/pcbApply/deleteDocItemData',
        method: "POST",
        params: {
            oid: oid,
            data: Ext.encode(ids),
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['error']);
                myMask.hide();
            } else {
                myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}
//传入公共的参数，返回上传附件的代码
function uploadFilefield(fileName,text,node,text_name){
    if(text==null || text==""){
        text = "浏览...";
    }

    var inform ={
        xtype:'filefield',
        buttonOnly: true,
        id:fileName,
        name:fileName,
        labelWidth:70,
        disabled:!allowEdit,
        hideLabel: true,
        buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>'+text+'</span>',
        allowBlank: false,
        scope: this,
        listeners:{
            'change':function(fb,newValue,oldValue,opts){
                if(!newValue){
                    return;
                }
                var file = document.querySelector('[id='+fileName+'-button-fileInputEl]');
                var formData = new FormData();
                formData.append(fileName+'-button-fileInputEl', file.files[0]);
                fb.reset();//清空表单的值
                var myMask = new Ext.LoadMask({
                    msg: '正在上传，请稍候......',
                    target:this.findParentByType('panel')
                });
                myMask.show();
                $.ajax({
                    url: '/Windchill/ptc1/pcbApply/uploadFiles?docBranchId='+docBranchId+'&text_name='+text_name+"&node="+node,
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function(res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if(!success){
                        alert(msg);
                    }else {
                        var fileName = obj['fileName'];
                        var value = Ext.getCmp(text_name).getValue();
                        if(value != null && value != ''){
                            fileName = value +"&nbsp;|&nbsp;" + fileName;
                        }
                        Ext.getCmp(text_name).setValue(fileName);
                        autoSaveAtt(text_name, fileName);
                    }
                }).fail(function(res) {
                    myMask.hide();
                    alert('上传失败！') ;
                });
            }
        }
    };
    return inform;
}

//删除附件
function deleteFilefield(branchId,fileName,text_name,node,path) {
    if(!allowEdit){
        alert("您没有权限删除其他用户的附件！");
        return;
    }
    // var myMask = new Ext.LoadMask({
    // 	msg: '正在删除，请稍候......',
    // 	target:Ext.getCmp('headPanel')
    // });
    // myMask.show();
    Ext.Ajax.request({
        scope : this,
        async : false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url : '/Windchill/ptc1/pcbApply/deleteFiles',
        params : {
            docBranchId: docBranchId,
            fileName: fileName,
            path:path
        },
        success : function(response, opts) {
            // myMask.hide();
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if(!success){
                alert(msg);
            }else {

                var tRecord =  Ext.getCmp('pcbApplyDocGrid').getSelectionModel().getSelection()[0];
                var attachmentValue = tRecord.data.attachment;
                var attachmentPathValue = tRecord.data.attachmentPath;
                var arr= new Array(); //定义一数组
                var arr1= new Array(); //定义一数组
                arr=attachmentValue.split("|"); //字符分割
                for (i=0;i<arr.length ;i++ ){
                    var index = arr[i].indexOf(fileName);
                    if (index > -1) {
                        arr.splice(i,1);// 删除
                    }
                }
                arr1=attachmentPathValue.split("|"); //字符分割
                for (i=0;i<arr1.length ;i++ ){
                    var index = arr1[i].indexOf(fileName);
                    if (index > -1) {
                        arr1.splice(i,1);// 删除
                    }
                }

                var result = arr.join("&nbsp;|&nbsp;");
                var result1 = arr1.join("&nbsp;|&nbsp;");
                tRecord.set('attachment',result);
                tRecord.set('attachmentPath',result1);
                var itemId = tRecord.get('id');
                var callbackFn = function () {
                    tRecord.commit();
                };
                saveDocItemData("ZPcbApplyDocItem",itemId,'attachment',result,callbackFn);
                saveDocItemData("ZPcbApplyDocItem",itemId,'attachmentPath',result1,callbackFn);

                /*  var fileName = obj['fileName'];
                  var tRecord = pcbApplyDocGrid.getSelectionModel().getSelection()[0];
                  var docEnclosureValue = pcbApplyDocGrid.getSelectionModel().getSelection()[0].data.docEnclosure;
                  if (docEnclosureValue != null && docEnclosureValue != '') {
                      fileName = docEnclosureValue + "&nbsp;|&nbsp;" + fileName;
                  }
                  tRecord.set('docEnclosure',fileName);
                  var itemId = tRecord.get('id');*/

            }
        },
        failure : function(response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });


}

function autoSaveAtt1(attKey, attValue) {
    var data = {
        docBranchId: docBranchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKeyOne //全局变量，当前活动key
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/pcbApply/autoSaveAtt?oid='+oid,
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message==="success") {
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/pcbApply/getFromByBranchId?docBranchId='+docBranchId,
                    success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if (obj.message=="success") {
                            debugger
                            Ext.getCmp('unit_price').setValue(obj.data['unit_price']);
                            Ext.getCmp('Pcb_filmFee').setValue(obj.data['Pcb_filmFee']);
                            Ext.getCmp('engineering_funds').setValue(obj.data['engineering_funds']);
                            Ext.getCmp('subtotal').setValue(obj.data['subtotal']);
                            Ext.getCmp('allFee').setValue(obj.data['allFee']);
                            Ext.getCmp('head_projectName').setValue(obj.data['head_projectName']);
                        }else {
                            alert(obj.message);
                        }
                    },
                    failure: function (response, opts) {
                        alert('错误：查询信息失败，请检查网络！!');
                    }
                });
            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}
function getVersion(number) {
    Ext.getStore('versionStore').load({
        params: {
            number:number,
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！');
            }
        }
    })
}

function  getSystemAttachment(docNumber,version){
    Ext.getStore('attachmentStore').load({
        params: {
            number:docNumber,
            version:version,
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！');
            }
        }
    })
}
