//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//

//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ght_dataLoadedFlag = false;
/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */
function disableNode(formkey) {
    if (taskCompleted == 'true') {
        return true;
    } else {
        if (formkey == currentActKey) {
            return false;
        } else {
            return true;
        }
    }
};

//自动保存字段
function autoSaveAtt(attKey, attValue) {
    var data = {
        docBranchId: branchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKey //全局变量，当前活动key
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/fixture/autoSaveAtt?oid='+oid,
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);

			if(obj.message=="success") {

            } else {
				Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){

    var mockRec = {
        oid:oid,
        dbTableName:dbTableName,
        itemId:itemId,
        dataKey:dataKey,
        dataValue:dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/fixture/saveItemData?oid='+oid,
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(tableName,callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/fixture/insertItemData?oid='+oid,
        params: {
            branchId: branchId,
            tableName:tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                callbackFn();
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//删除grid信息
function deleteData(tableName,ids, callback) {

    var data = {
        oid:oid,
        tableName:tableName,
        ids:ids
    }

    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/fixture/deleteItemData',
        method: "POST",
        params: {
            data:Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message!="success") {
                Ext.Msg.alert("数据删除失败", obj.message);
            } else {
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}


