Ext.define('PLM.view.fixtureApply', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.fixtureApply',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">工装夹具需求申请单</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    config: {
        in_objectKey: 'fixtureApply',
        in_objectDesc: '工装夹具需求申请单',
        in_objectKey1: 'fixtureApply1',
        in_objectDesc1: '工装夹具需求申请单1',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;


        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var mockExampleStore1 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore1'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '工具夹名称', dataIndex: 'data1', width: 100, editor: 'textfield'},
                {text: '数量', dataIndex: 'data2', width: 100, editor: 'textfield'},
                {text: '单位', dataIndex: 'data3', width: 100, editor: 'textfield'},
                {text: '需求日期', dataIndex: 'data4', width: 100, editor: 'textfield'},
                {text: '预计单价', dataIndex: 'data5', width: 100, editor: 'textfield'},
                {text: '价格', dataIndex: 'data6', width: 100, editor: 'textfield'},
                {text: '使用人', dataIndex: 'data7', width: 100, editor: 'textfield'},
                {text: '工厂', dataIndex: 'data8', width: 100, editor: 'textfield'},
                {text: '库存地点', dataIndex: 'data9', width: 100, editor: 'textfield'},
                {text: '采购组织', dataIndex: 'data10', width: 100, editor: 'textfield'},
            ]
        });

        var mockExampleGrid1 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('mockExampleStore1'),
            id: 'mockExampleGrid1',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '委外名称', dataIndex: 'data1', width: 100, editor: 'textfield'},
                {text: '数量', dataIndex: 'data2', width: 100, editor: 'textfield'},
                {text: '单价', dataIndex: 'data3', width: 100, editor: 'textfield'},
                {text: '委外价格', dataIndex: 'data4', width: 100, editor: 'textfield'},
            ]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        mockExampleGrid1.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [
                {
                    xtype: 'panel',
                    border: false,
                    defaults:{border:false},
                    layout: 'hbox',
                    style: 'margin-left: 5px;padding-left: 5px;',
                    // 第一列中的表项
                    items:[
                        {
                            xtype: 'panel',
                            defaults: {
                                labelWidth: 100,
                                border: false,
                                margin: '5 20 5 5',
                            },
                            items: [{
                                xtype: 'textfield',
                                fieldLabel: '申请部门',
                                name: 'att1',
                                id: 'att1',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            },{
                                xtype: 'panel',
                                layout: 'hbox',
                                items: [{//第四行
                                    xtype: 'radiogroup',
                                    name: 'a',
                                    fieldLabel: '科目分配类别',
                                    width: 180,
                                    labelWidth: 100,
                                    items: [{
                                        inputValue: 'K',
                                        boxLabel: 'K',
                                        name: 'r1',
                                        checked: true
                                    }, {
                                        inputValue: '1',
                                        boxLabel: '1',
                                        name: 'r1',
                                    }]
                                }, {border: false, html: '费用挂成本中心选择“K”，费用挂内部订单选择“1”   sss'}]
                            },
                                {
                                    xtype: 'panel',
                                    layout: 'hbox',
                                    defaults: {
                                        labelWidth: 100,
                                        border: false,
                                        margin: '5 20 5 0',
                                    },
                                    items: [{margin:'25 20 5 0',border: false, html: '项目内部订单号'}, {
                                        xtype: 'panel',
                                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                                        items: [{
                                            xtype: 'combo',
                                            fieldLabel: '项目类型',
                                            multiSelect: false,
                                            anyMatch: true,
                                            editable: false,
                                            emptyText: '==请选择==',
                                            store: [['研发管理部', '研发管理部'], ['销售部', '销售部']],
                                            width: 200,
                                            id: 'c',
                                            name: 'c',
                                            labelWidth: 100,
                                            listeners: {
                                                'select': function () {

                                                }
                                            }
                                        }, {
                                            xtype: 'combo',
                                            fieldLabel: '项目内部订单号',
                                            multiSelect: false,
                                            anyMatch: true,
                                            editable: false,
                                            emptyText: '==请选择==',
                                            store: [['研发管理部', '研发管理部'], ['销售部', '销售部']],
                                            width: 300,
                                            id: 'd',
                                            name: 'd',
                                            labelWidth: 100,
                                            listeners: {
                                                'select': function () {

                                                }
                                            }
                                        }
                                        ]
                                    },]
                                },{
                                    xtype: 'textfield',
                                    fieldLabel: '归属团队',
                                    name: 'att4',
                                    id: 'att4',
                                    width: 250,
                                    listeners: {
                                        blur: function (e) {
                                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                        }
                                    }
                                }
                            ]
                        },{
                            xtype: 'panel',
                            defaults: {
                                labelWidth: 100,
                                border: false,
                                margin: '5 20 5 5',
                            },
                            items: [{
                                xtype: 'textfield',
                                fieldLabel: '申请部门',
                                name: 'att2',
                                id: 'att2',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            },{
                                xtype: 'combo',
                                fieldLabel: '成本中心',
                                multiSelect: false,
                                anyMatch: true,
                                editable: false,
                                store: [['研发管理部', '研发管理部'], ['销售部', '销售部']],
                                width: 250,
                                id: 'b',
                                name: 'b',
                                labelWidth: 100,
                                listeners: {
                                    'select': function () {

                                    }
                                }
                            }, {
                                xtype: 'panel',
                                layout: 'hbox',
                                defaults: {
                                    labelWidth: 100,
                                    border: false,
                                    margin: '25 20 5 0',
                                },
                                items: [{
                                    xtype: 'radiogroup',
                                    name: 'e',
                                    id: 'e',
                                    fieldLabel: '是否为PDT项目费用',
                                    width: 220,
                                    labelWidth: 130,
                                    items: [{
                                        inputValue: '是',
                                        boxLabel: '是',
                                        name: 'r1',
                                        checked: true
                                    }, {
                                        inputValue: '否',
                                        boxLabel: '否',
                                        name: 'r1',
                                    }]
                                }, {
                                    xtype: 'textfield',
                                    name: 'att3',
                                    id: 'att3',
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                        }
                                    }
                                }]
                            }, {
                                xtype: 'panel',
                                layout: 'hbox',
                                defaults: {
                                    labelWidth: 100,
                                    border: false,
                                    margin: '15 20 5 0',
                                },
                                items: [{
                                    xtype: 'textfield',
                                    fieldLabel: '项目编码',
                                    name: 'att5',
                                    id: 'att5',
                                    width: 250,
                                    listeners: {
                                        blur: function (e) {
                                            saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                        }
                                    }
                                }, {border: false, html: '(项目清单列表)', width: 100}]
                            }
                            ]
                        },
                    ]
                },
                {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '申购理由',
                        name: 'att6',
                        id: 'att6',
                        width: 800,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{//第四行
                        xtype: 'textarea',
                        fieldLabel: '用途',
                        name: 'att7',
                        id: 'att7',
                        width: 800,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '要求',
                        name: 'att8',
                        id: 'att8',
                        width: 800,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                title: 'PDT经理审批',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        fieldLabel: '意见',
                        xtype: 'textfield',
                        name: 'att9',
                        id: 'att9',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                title: '申请部门经理审批',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'radiogroup',
                        name: 'f',
                        id: 'f',
                        fieldLabel: '制作类型',
                        width: 200,
                        labelWidth: 80,
                        items: [{
                            inputValue: '委外',
                            boxLabel: '委外',
                            name: 'r1',
                            checked: true
                        }, {
                            inputValue: '自制',
                            boxLabel: '自制',
                            name: 'r1',
                        }]
                    }
                    ],
                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                title: '申请部门上级领导',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '意见',
                        name: 'att10',
                        id: 'att10',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                title: '工装制作人员填写',
                defaults: {margin: '5 20 0 0', border: false,},
                items: [{//第一行
                    items: [mockExampleGrid1, {//制作部门确认需要外协加工
                        xtype: 'radiogroup',
                        name: 'ff',
                        id: 'ff',
                        fieldLabel: '制作部门确认需要外协加工',
                        width: 250,
                        labelWidth: 170,
                        items: [{
                            inputValue: '是',
                            boxLabel: '是',
                            name: 'r1',
                            checked: true
                        }, {
                            inputValue: '否',
                            boxLabel: '否',
                            name: 'r1',
                        }]
                    }
                    ],
                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                title: '技术部经理审核',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '意见',
                        name: 'att11',
                        id: 'att11',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },, {
                xtype: 'panel',
                layout: 'hbox',
                title: '采购经理审核',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '意见',
                        name: 'att12',
                        id: 'att12',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                title: '采购部门确认购置情况',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '意见',
                        name: 'att13',
                        id: 'att13',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                title: '验收人确认验收情况',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                items: [{//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '意见',
                        name: 'att14',
                        id: 'att14',
                        width: 600,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ],

                }]
            },//~end of 测试项目
            ]
        }]
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey()
                                , Ext.getCmp('simpleForm').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore1').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore1').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore1').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey1()
                                , Ext.getCmp('simpleForm').getIn_objectDesc1, callbackFn);
                        }
                    }
                }
            });
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});