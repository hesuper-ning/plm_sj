Ext.define('PLM.view.changeTrialApply', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.changeTrialApply',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">小批量试产申请及跟踪表</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    config: {
        in_objectKey: 'trialApply',
        in_objectDesc: '小批量试产申请及跟踪表',
        in_objectKey1: 'trialApply1',
        in_objectDesc1: '小批量试产申请及跟踪表1',
        in_objectKey2: 'trialApply2',
        in_objectDesc2: '小批量试产申请及跟踪表2',
        in_objectKey3: 'trialApply3',
        in_objectDesc3: '小批量试产申请及跟踪表3',
        in_objectKey5: 'trialApply5',
        in_objectDesc5: '小批量试产申请及跟踪表5',
        in_objectKey4: 'trialApply4',
        in_objectDesc4: '小批量试产申请及跟踪表4',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;


        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var mockExampleStore1 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore1'
        });

        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var mockExampleStore2 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore2'
        });

        var cellEditing2 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var mockExampleStore3 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore3'
        });

        var cellEditing3 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var mockExampleStore4 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore4'
        });

        var cellEditing4 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var mockExampleStore5 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore5'
        });

        var cellEditing5 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var mockExampleGrid2 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing2],
            store: Ext.getStore('mockExampleStore2'),
            id: 'mockExampleGrid2',
            margin: '10 0 20 0',
            //forceFit: true,
            //autoWidth: true,
            width: 900,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid2,
                            param_objectKey: me.in_objectKey2,
                            param_objectDesc: me.in_objectDesc2
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '项目', dataIndex: 'data4', width: 200, editor: 'textfield'},
                {text: '预计完成日期', dataIndex: 'data5', width: 200, editor: 'textfield'},
            ]
        });

        var mockExampleGrid3 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing3],
            store: Ext.getStore('mockExampleStore3'),
            id: 'mockExampleGrid3',
            margin: '10 0 20 0',
            //forceFit: true,
            //autoWidth: true,
            width: 1200,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid3,
                            param_objectKey: me.in_objectKey3,
                            param_objectDesc: me.in_objectDesc3
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '项目', dataIndex: 'data4', width: 200, editor: 'textfield'},
                {text: '制作人', dataIndex: 'data5', width: 200, editor: 'textfield'},
                {text: '预计完成日期', dataIndex: 'data6', width: 200, editor: 'textfield'},
                {text: '项目', dataIndex: 'data7', width: 200, editor: 'textfield'},
                {text: '是否需要', dataIndex: 'data6', width: 200, editor: 'textfield'},
                {text: '预计完成日期', dataIndex: 'data6', width: 200, editor: 'textfield'},
            ]
        });

        var mockExampleGrid4 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing4],
            store: Ext.getStore('mockExampleStore4'),
            id: 'mockExampleGrid4',
            margin: '10 0 20 0',
            //forceFit: true,
            //autoWidth: true,
            width: 900,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid4,
                            param_objectKey: me.in_objectKey4,
                            param_objectDesc: me.in_objectDesc4
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '项目', dataIndex: 'data4', width: 200, editor: 'textfield'},
                {text: '预计完成日期', dataIndex: 'data5', width: 200, editor: 'textfield'},
            ]
        });


        var mockExampleGrid5 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing5],
            store: Ext.getStore('mockExampleStore5'),
            id: 'mockExampleGrid5',
            margin: '10 0 20 0',
            //forceFit: true,
            //autoWidth: true,
            width: 900,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid5,
                            param_objectKey: me.in_objectKey5,
                            param_objectDesc: me.in_objectDesc5
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '项目', dataIndex: 'data4', width: 200, editor: 'textfield'},
                {text: '预计完成日期', dataIndex: 'data5', width: 200, editor: 'textfield'},
            ]
        });


        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            title: '需要费用化采购的物料及数量\n' +
                '- 主要包括发生规格变化的物料',
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            margin: '10 0 20 0',
            //forceFit: true,
            //autoWidth: true,
            width: 900,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '物料编号', dataIndex: 'data1', width: 200, editor: 'textfield'},
                {text: '物料描述', dataIndex: 'data2', width: 200, editor: 'textfield'},
                {text: '数量', dataIndex: 'data3', width: 200, editor: 'textfield'},
                {text: '图纸', dataIndex: 'data4', width: 200, editor: 'textfield'},
            ]
        });

        var mockExampleGrid1 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('mockExampleStore1'),
            id: 'mockExampleGrid1',
            margin: '10 0 20 0',
            //forceFit: true,
            //autoWidth: true,
            width: 1200,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid1,
                            param_objectKey: me.in_objectKey1,
                            param_objectDesc: me.in_objectDesc1
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '项目', dataIndex: 'data5', width: 200, editor: 'textfield'},
                {text: '是否提供', dataIndex: 'data6', width: 200, editor: 'textfield'},
                {text: '预计完成日期', dataIndex: 'data7', width: 200, editor: 'textfield'},
                {text: '项目', dataIndex: 'data8', width: 200, editor: 'textfield'},
                {text: '是否需要', dataIndex: 'data9', width: 200, editor: 'textfield'},
                {text: '预计完成日期', dataIndex: 'data10', width: 200, editor: 'textfield'},
            ]
        });

        mockExampleGrid2.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey2, this.in_objectDesc2, itemId, tField, tValue, callbackFn);

            });

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            title: '1.提交人',
            anchor: '92%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [
                {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '申请人',
                            value: 'wcadmin',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }, {
                            xtype: 'displayfield',
                            fieldLabel: '申请日期',
                            value: '2021-06-29',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        },
                        {
                            xtype: 'textfield',
                            fieldLabel: '试产数量',
                            name: 'att1',
                            id: 'att1',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }, {
                            xtype: 'datefield',
                            fieldLabel: '期望完成日期',
                            width: 250,
                            name: 'att2',
                            id: 'att2',
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }
                    ]//~end of hbox items
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '物料代码',
                        name: 'att3',
                        id: 'att3',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '产品名称',
                        name: 'att4',
                        id: 'att4',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '产品型号',
                        name: 'att5',
                        id: 'att5',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '所属PDT线',
                        name: 'att6',
                        id: 'att6',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }
                    ]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: 'TR5测试报告文件编号',
                        labelWidth: 150,
                        name: 'att7',
                        id: 'att7',
                        width: 450,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },
                        {
                            xtype: 'textfield',
                            fieldLabel: '试产原因',
                            name: 'att8',
                            id: 'att8',
                            labelWidth: 80,
                            width: 450,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        },
                    ]
                },
                {
                    xtype: 'panel',
                    title: '设计更改试产',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '设计变更单号',
                        name: 'att29',
                        id: 'att29',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '产品变更描述（含物料）',
                        name: 'atta29',
                        id: 'atta29',
                        labelWidth: 150,
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '物料变更描述',
                        name: 'attb29',
                        id: 'attb29',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '试产软件版本（需要明确每个芯片对应的软件版本）',
                        name: 'attc29',
                        id: 'attc29',
                        labelWidth: 320,
                        width: 470,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }, {
                        xtype: 'panel',
                        layout: 'hbox',
                        border:false,
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'filefield',
                            fieldLabel: '其他临时技术文件（列明文件名称及版本，并确保文件已由资料室受控分发）',
                            name: 'a29',
                            id: 'a29',
                            labelWidth: 450,
                            width: 700,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }, {
                            xtype: 'textfield',
                            fieldLabel: '文件编号',
                            name: 'afsd29',
                            id: 'afsd29',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]

                    },{
                        xtype:'textfield',
                        fieldLabel:'OA单号',
                        name:'cc',
                        id:'cc',
                        width:250,
                        listeners:{
                            blur:function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'panel',
                        layout: 'hbox',
                        border:false,
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'filefield',
                            fieldLabel: '试产相关要求及注意事项',
                            name: 'ac29',
                            id: 'ac29',
                            labelWidth: 150,
                            width: 350,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }, {
                            xtype: 'textfield',
                            fieldLabel: '文件编号',
                            name: 'acfsd29',
                            id: 'acfsd29',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]

                    },{
                        xtype: 'filefield',
                        fieldLabel: 'Excel 版 BOM\n' +
                            '- 请移除发生规格变化的物料',
                        labelWidth: 170,
                        name: 'actt9',
                        id: 'actt9',
                        width: 370,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },mockExampleGrid,mockExampleGrid1
                    ]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{border: false, html: '资料上传',}, {
                        xtype: 'filefield',
                        fieldLabel: '01-试产相关要求及注意事项',
                        labelWidth: 170,
                        name: 'att9',
                        id: 'att9',
                        width: 370,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                }, {
                    xtype: 'panel',
                    collapsible: true,
                    title: '测试项目Section-02：试产前准备',
                    //collapsible: true,
                    defaults: {border: false},
                    margin: '5 20 5 5',
                    items: [{
                        xtype: 'panel',
                        title:'01-试产部门',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [mockExampleGrid2,{
                            xtype: 'textfield',
                            fieldLabel: '试产前准备会议时间',
                            labelWidth: 100,
                            name: 'att10',
                            id: 'att10',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }, {
                            xtype: 'textarea',
                            fieldLabel: '其他说明',
                            name: 'att11',
                            id: 'att11',
                            width: 750,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]
                    },
                        {
                            xtype: 'panel',
                            //layout: 'hbox',
                            title:'02-质控部',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [mockExampleGrid3,{
                                xtype: 'textarea',
                                fieldLabel: '其他说明',
                                name: 'att12',
                                id: 'att12',
                                width: 750,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }]
                        }
                        ,{
                            xtype: 'panel',
                            //layout: 'hbox',
                            title:'03-采购部',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [mockExampleGrid4,{
                                xtype: 'textfield',
                                fieldLabel: '费用化采购执行结果确认',
                                labelWidth: 100,
                                name: 'att13',
                                id: 'att13',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }, {
                                xtype: 'textarea',
                                fieldLabel: '其他说明',
                                name: 'att14',
                                id: 'att14',
                                width: 750,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }]
                        }
                        ,{
                            xtype: 'panel',
                            //layout: 'hbox',
                            title:'04-物控部',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [mockExampleGrid5,{
                                xtype: 'textfield',
                                fieldLabel: '是否按照申请excel BOM下发工单',
                                labelWidth: 100,
                                name: 'att15',
                                id: 'att15',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }, {
                                xtype: 'textarea',
                                fieldLabel: '其他说明',
                                name: 'att16',
                                id: 'att16',
                                width: 750,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }, {
                                xtype: 'textfield',
                                fieldLabel: '生产令号',
                                labelWidth: 100,
                                name: 'att17',
                                id: 'att17',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }, {
                                xtype: 'textfield',
                                fieldLabel: '物控部经理审批意见',
                                labelWidth: 100,
                                name: 'att18',
                                id: 'att18',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }]
                        }
                        , {
                            xtype: 'panel',
                            title: '05-试产前未完成项目跟进',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype: 'textfield',
                                fieldLabel: '试产前问题总结',
                                name: 'att19',
                                id: 'att19',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }, {
                                xtype: 'radiogroup',
                                fieldLabel: '试产建议',
                                name: '00',
                                id: '00',
                                width: 300,
                                items: [{
                                    inputValue: '正常试产',
                                    boxLabel: '正常试产',
                                    name: 'r1',
                                    checked: true
                                }, {
                                    inputValue: '终止试产',
                                    boxLabel: '终止试产',
                                    name: 'r1',
                                }]
                            }]
                        }]
                }, {
                    xtype: 'panel',
                    title: 'Section-03：试产问题跟进及总结',
                    items: [{
                        xtype: 'panel',
                        title: '01-生产部',
                        border: false,
                        defaults: {margin: '5 20 5 0', labelWidth: 100},
                        items: [{
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [{
                                xtype: 'textfield',
                                fieldLabel: '生产部开始生产日期',
                                name: 'att20',
                                id: 'att20',
                                labelWidth: 140,
                                width: 290,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }, {
                                xtype: 'datefield',
                                fieldLabel: '入库日期',
                                name: 'att21',
                                id: 'att21',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }]
                        }, {
                            xtype: 'textfield',
                            fieldLabel: '<P-1.5.1-T10 小批量试产情况表>文件编号',
                            name: 'att22',
                            id: 'att22',
                            width: 290,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]

                    }, {
                        xtype: 'panel',
                        title: '02-质控部',
                        border: false,
                        defaults: {margin: '5 20 5 0', labelWidth: 100},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '<P-1.5.1-T11 小批量试产质量状况表>文件编号',
                            name: 'att23',
                            id: 'att23',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]
                    }, {
                        xtype: 'panel',
                        title: '03-技术部',
                        border: false,
                        defaults: {margin: '5 20 5 0', labelWidth: 100},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '<P-1.5.1-T15小批量试产技术状况表>文件编号',
                            name: 'att24',
                            id: 'att24',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }]
                    }, {
                        xtype: 'panel',
                        title: '04-试产部门',
                        border: false,
                        defaults: {margin: '5 20 5 0', labelWidth: 100},
                        items: [{
                            xtype: 'radiogroup',
                            fieldLabel: '试产结论',
                            name: 'aa',
                            id: 'aa',
                            width: 300,
                            items: [{
                                inputValue: '试产通过',
                                boxLabel: '试产通过',
                                name: 'r1',
                                checked: true
                            }, {
                                inputValue: '试产不通过',
                                boxLabel: '试产不通过',
                                name: 'r1',
                            }]
                        }, {
                            xtype: 'textfield',
                            fieldLabel: '试产结论异常情况记录',
                            name: 'att25',
                            id: 'att25',
                            width: 250,
                            listeners: {
                                blur: function (e) {
                                    saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                }
                            }
                        }, {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            defaults: {margin: '5 20 5 0', labelWidth: 100},
                            items: [{
                                xtype: 'textfield',
                                fieldLabel: '试产总结会议时间',
                                name: 'att26',
                                id: 'att26',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }, {
                                xtype: 'textfield',
                                fieldLabel: '试产总结报告',
                                name: 'att27',
                                id: 'att27',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }, , {
                                xtype: 'textfield',
                                fieldLabel: '文档编号',
                                name: 'att28',
                                id: 'att28',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        saveObjectData(Ext.getCmp('simpleForm').getIn_objectKey(), Ext.getCmp('simpleForm').getIn_objectDesc(), e.id, e.value);
                                    }
                                }
                            }
                            ]
                        }
                        ]
                    }]
                }
            ]
        }]
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey()
                                , Ext.getCmp('simpleForm').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore1').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey1()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore1').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore1').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey1()
                                , Ext.getCmp('simpleForm').getIn_objectDesc1, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore2').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey2()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore2').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore2').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey2()
                                , Ext.getCmp('simpleForm').getIn_objectDesc2, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore3').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey3()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore3').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore3').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey3()
                                , Ext.getCmp('simpleForm').getIn_objectDesc3, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore4').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey4()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore4').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore4').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey4()
                                , Ext.getCmp('simpleForm').getIn_objectDesc4, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore5').load({
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey5()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore5').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore5').reload()
                            }
                            createMockItemData(Ext.getCmp('simpleForm').getIn_objectKey5()
                                , Ext.getCmp('simpleForm').getIn_objectDesc5, callbackFn);
                        }
                    }
                }
            });
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('simpleForm').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});