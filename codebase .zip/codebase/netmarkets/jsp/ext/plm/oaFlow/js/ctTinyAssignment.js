// 创建 ComboBox 数据源
var comboBoxStore = Ext.create('Ext.data.Store', {
    fields: ['value', 'text'],
    data: [
        {value: '是', text: '是'},
        {value: '否', text: '否'}
    ]
});

let nowRecord = '';

// 创建一个隐藏的文件上传组件
let fileField = Ext.create('Ext.form.field.File', {
    id: 'hiddenFileField',
    buttonText: '选择文件',
    hidden: true, // 隐藏文件上传组件
    listeners: {
        change: function (field, values) {
            debugger;
            let flag = nowRecord.get("id");
            let fileLink = nowRecord.get("fileLink");
            let tetx_name = flag + '_uploadFileRecord';
            let node = head_node;
            let fileName = 'hiddenFileField';

            //上传
            if (!values) return;
            let file = document.querySelector('[id=' + fileName + '-button-fileInputEl]');
            let formData = new FormData();
            formData.append(fileName + '-button-fileInputEl', file.files[0]);
            let myMask = new Ext.LoadMask({
                msg: '正在上传，请稍候......',
                target: this.findParentByType('panel')
            });
            myMask.show();
            $.ajax({
                url: '/Windchill/ptc1/tinyAssignment/uploadFiles?branchId=' + branchId + '&tetx_name=' + tetx_name + "&node=" + node,
                type: 'POST',
                cache: false,
                data: formData,
                processData: false,
                contentType: false
            }).done(function (res) {
                myMask.hide();
                var obj = Ext.decode(res);
                var success = obj['success'];
                var msg = obj['msg'];
                if (!success) {
                    alert(msg);
                    field.reset();//清空表单的值
                } else {
                    var fileName = obj['fileName'];
                    /*var value = Ext.getCmp(tetx_name).getValue();
                    if (value != null && value != '') {
                        fileName = value + "&nbsp;|&nbsp;" + fileName;
                    }
                    Ext.getCmp(tetx_name).setValue(fileName);*/
                    let value = fileLink;
                    if (value != null && value != '') {
                        fileName = value + "&nbsp;|&nbsp;" + fileName;
                    }
                    autoSaveAtt(tetx_name, fileName);
                    Ext.getCmp('itemUpdateGrid').getStore().load();
                    //field.reset();//清空表单的值
                }
            }).fail(function (res) {
                myMask.hide();
                alert('上传失败！');
            });
        }
    }
});


let isLoaded = false;
Ext.define('PLM.view.assignment', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.assignment',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">微小项目任务书</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    height: 780,
    // bodyStyle : 'overflow-x:hidden; overflow-y:scroll',
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {
        let redStarFlag = '<font color=red bold>*</font>'; //必填标志
        let planningProjectNameLabel = '规划项目名称:';
        let planningProjectNumberLabel = '规划项目编号:';
/////////////////////////Panel items//////////////////////////////////
        var me = this;

        //region 第一部分的产品型号 grid组件
        Ext.define('tinyAssignmentModel2', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'cProductNumber', 'cProductName', 'cProductType'],
            idProperty: 'id'
        });

        var tinyAssignmentStore2 = Ext.create('Ext.data.Store', {
            id: 'tinyAssignmentStore2',
            model: 'tinyAssignmentModel2',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/tinyAssignment/getItemInfo2?docBranchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'item',
                    idProperty: 'id',
                    messageProperty: 'error'
                },
            }),
            autoLoad: true
        });

        var tinyAssignmentGrid2 = Ext.create('Ext.grid.Panel', {
            //plugins: [tinyAssignmentCellEditing],
            store: Ext.getStore('tinyAssignmentStore2'),
            id: 'tinyAssignmentGrid2',
            margin: '10 0 20 0',
            forceFit: true,
            //autoWidth: true,
            width: 1222,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
//fields: ['id', 'docBranchId', 'PCBName', 'count', 'productionMethod', 'versionNumber', 'openSteelMesh'],
            columns: [
                {xtype: 'rownumberer', width: 30},
                {text: '序号', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '产品型号', dataIndex: 'cProductType', flex: 2},
                {text: '产品编码', dataIndex: 'cProductNumber', flex: 1, editor: 'textfield'},
                {
                    text: '产品名称', dataIndex: 'cProductName', flex: 6,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value) {
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        }
                        return value
                    }
                },
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if (!disableNode(head_node)) {
                        return false;
                    }

                },
            },
            tbar: [
                //新增
                {
                    hidden: !disableNode(head_node),
                    text: '新增',
                    iconCls: 'icon icon-add',
                    handler: function () {
                        showSelectionWindow(tinyAssignmentGrid2);
                        //注释原来的代码
                        /*var callbackFn = function () {
                            Ext.getStore('tinyAssignmentStore').reload();
                        };
                        insertItemData(callbackFn);*/
                    }
                },
                //删除
                {
                    hidden: !disableNode(head_node),
                    text: '删除',
                    iconCls: 'icon icon-delete',
                    scope: this,
                    handler: function () {
                        let selectionArr = tinyAssignmentGrid2.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('tinyAssignmentStore2').reload()
                        };
                        deleteItemData('ZtinyAssignmentNewItem2', obj, callbackFn);
                    }
                }],
        });

        // 被参考的产品信息 grid组件 endregion

        //region 被参考的产品信息 grid组件
        Ext.define('tinyAssignmentModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'cProductNumber', 'cProductName', 'cProductType'],
            idProperty: 'id'
        });

        var tinyAssignmentStore = Ext.create('Ext.data.Store', {
            id: 'tinyAssignmentStore',
            model: 'tinyAssignmentModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/tinyAssignment/getItemInfo?docBranchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'item',
                    idProperty: 'id',
                    messageProperty: 'error'
                },
            }),
            autoLoad: true
        });

        var tinyAssignmentCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var tinyAssignmentGrid = Ext.create('Ext.grid.Panel', {
            //plugins: [tinyAssignmentCellEditing],
            store: Ext.getStore('tinyAssignmentStore'),
            id: 'tinyAssignmentGrid',
            title: '3. 被参考的产品信息',
            margin: '10 0 20 0',
            forceFit: true,
            //autoWidth: true,
            width: 1222,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
//fields: ['id', 'docBranchId', 'PCBName', 'count', 'productionMethod', 'versionNumber', 'openSteelMesh'],
            columns: [
                {xtype: 'rownumberer', width: 30},
                {text: '序号', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '产品型号', dataIndex: 'cProductType', flex: 2},
                {text: '产品编码', dataIndex: 'cProductNumber', flex: 1, editor: 'textfield'},
                {
                    text: '产品名称', dataIndex: 'cProductName', flex: 6,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value) {
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        }
                        return value
                    }
                },
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if (!disableNode(head_node)) {
                        return false;
                    }

                },
            },
            tbar: [
                //新增
                {
                    hidden: !disableNode(head_node),
                    text: '新增',
                    id: 'docAdd',
                    name: 'docAdd',
                    iconCls: 'icon icon-add',
                    handler: function () {
                        showSelectionWindow(tinyAssignmentGrid);
                        //注释原来的代码
                        /*var callbackFn = function () {
                            Ext.getStore('tinyAssignmentStore').reload();
                        };
                        insertItemData(callbackFn);*/
                    }
                },
                //删除
                {
                    hidden: !disableNode(head_node),
                    text: '删除',
                    iconCls: 'icon icon-delete',
                    scope: this,
                    handler: function () {
                        let selectionArr = tinyAssignmentGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('tinyAssignmentStore').reload()
                        };
                        deleteItemData('ZtinyAssignmentNewItem', obj, callbackFn);
                    }
                }],
        });

        //弃用，不需要通过表格修改了
        /*        tinyAssignmentGrid.on('edit', function (editor, e) {
                    var tRecord = e.record; //得到当前行所有数据
                    var tField = e.field; //得到修改列
                    var tValue = e.value; //得到修改列修改后值
                    var itemId = tRecord.get('id');

                    var callbackFn = function () {
                        Ext.getStore('tinyAssignmentStore').reload()
                    };
                    saveItemData('ZtinyAssignmentNewItem', itemId, tField, tValue, callbackFn);
                });*/

        //备份
        /*        Ext.define('tinyAssignmentModel', {
                    extend: 'Ext.data.Model',
                    fields: ['id', 'docBranchId', 'cProductNumber', 'cProductName', 'cProductType'],
                    idProperty: 'id'
                });

                var tinyAssignmentStore = Ext.create('Ext.data.Store', {
                    id: 'tinyAssignmentStore',
                    model: 'tinyAssignmentModel',
                    pruneModifiedRecords: true,
                    proxy: new Ext.data.HttpProxy({
                        url: '/Windchill/ptc1/tinyAssignment/getItemInfo?docBranchId=' + branchId,
                        method: 'GET',
                        reader: {
                            type: 'json',
                            rootProperty: 'item',
                            idProperty: 'id',
                            messageProperty: 'error'
                        },
                    }),
                    autoLoad: true
                });

                var tinyAssignmentCellEditing = new Ext.grid.plugin.CellEditing({
                    clicksToEdit: 1
                });

                var tinyAssignmentGrid = Ext.create('Ext.grid.Panel', {
                    plugins: [tinyAssignmentCellEditing],
                    store: Ext.getStore('tinyAssignmentStore'),
                    id: 'tinyAssignmentGrid',
                    title: '3. 被参考的产品信息',
                    margin: '10 0 20 0',
                    forceFit: true,
                    autoWidth: true,
                    // width:2500,
                    autoScroll: false,
                    region: 'center',
                    //height: 300,
                    selModel: {
                        mode: 'MULTI' //可以多选
                    },
                    //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
                    viewConfig: {
                        enableTextSelection: true,
                        stripeRows: true,
                    },
                    selType: 'checkboxmodel',
                    listeners: {
                        change: 'onAllCircuitsChecked'
                    },
        //fields: ['id', 'docBranchId', 'PCBName', 'count', 'productionMethod', 'versionNumber', 'openSteelMesh'],
                    columns: [{xtype: 'rownumberer'},
                        {text: '序号', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                        {text: '产品编码', dataIndex: 'cProductNumber', width: 100, editor: 'textfield'},
                        {text: '产品名称', dataIndex: 'cProductName', width: 100},
                        {text: '产品型号', dataIndex: 'cProductType', width: 100},
                    ],
                    listeners: {
                        beforeedit: function (editor, e, eOpts) {
                            var tField = e.field; //得到修改列

                            if (!disableNode(head_node)) {
                                return false;
                            }

                        },
                    },
                    tbar: [{
                        hidden: !disableNode(head_node),
                        text: '新增',
                        id: 'docAdd',
                        name: 'docAdd',
                        iconCls: 'icon icon-add',
                        handler: function () {
                            var callbackFn = function () {
                                Ext.getStore('tinyAssignmentStore').reload();
                            };
                            insertItemData(callbackFn);
                        }
                    }, {
                        hidden: !disableNode(head_node),
                        text: '删除',
                        iconCls: 'icon icon-delete',
                        scope: this,
                        handler: function () {
                            let selectionArr = tinyAssignmentGrid.getSelectionModel().getSelection();
                            if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                Ext.Msg.alert("提示", "请选择要删除的数据");
                                return;
                            }
                            //数据组装
                            let obj = new Array();
                            Ext.each(selectionArr, function (record) {
                                obj.push(record.data['id'])
                            });
                            var callbackFn = function () {
                                //tRecord.commit();
                                Ext.getStore('tinyAssignmentStore').reload()
                            };
                            deleteItemData('ZtinyAssignmentNewItem', obj, callbackFn);
                        }
                    }],
                });

                tinyAssignmentGrid.on('edit',
                    function (editor, e) {
                        var tRecord = e.record; //得到当前行所有数据
                        var tField = e.field; //得到修改列
                        var tValue = e.value; //得到修改列修改后值
                        var itemId = tRecord.get('id');

                        var callbackFn = function () {
                            Ext.getStore('tinyAssignmentStore').reload()
                        };
                        saveItemData('ZtinyAssignmentNewItem', itemId, tField, tValue, callbackFn);
                    });*/
        // 被参考的产品信息 grid组件 endregion

        //region  未启用  5. 在参考产品型号基础上，对以下项目进行修改 grid组件

        Ext.define('itemUpdateModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'name', 'yesOrNo', 'content', 'fileLink']
        });

        // 创建数据存储
        let itemUpdateStore = Ext.create('Ext.data.Store', {
            model: 'itemUpdateModel',
            id: 'itemUpdateStore',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/tinyAssignment/getItemUpdateStore?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false,
            /* data: [
                 { id: 'electronic', name: '电子部分', yesOrNo: '是', content: '修改了某些参数', fileLink: '附件1.pdf' },
                 { id: 'structure', name: '结构部分', yesOrNo: '否', content: '未修改', fileLink: '' },
                 { id: 'software', name: '软件部分', yesOrNo: '是', content: '增加了新的特性', fileLink: '附件2.pdf' },
             ]*/
        });

        itemUpdateStore.load();

        let itemUpdateGrid = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: itemUpdateStore,
            id: 'itemUpdateGrid',
            columns: [
                //标记是哪一行的，用于传参时识别表格中的数据，对应的是哪个input数据，这里的表格数据是键值对的，不是行数据
                {header: 'id', dataIndex: 'id', flex: 1, hidden: true},
                {
                    header: '项目', dataIndex: 'name', width: 100, sortable: false, // 添加这一行来禁止排序
                    renderer: function (value, metaData, record, row, col, store) {
                        let id = record.get('id');
                        let text = '';
                        if (id === 'electronic') text = '电子部分';
                        else if (id === 'structure') text = '结构部分';
                        else if (id === 'software') text = '软件部分';
                        else if (id === 'pack') text = '包装部分';
                        else if (id === 'specification') text = '产品说明书';
                        else if (id === 'scutcheon') text = '标牌';
                        else if (id === 'label') text = '标贴';
                        else if (id === 'else') text = '其他';
                        return text;
                    }
                },
                {
                    header: '是否涉及', dataIndex: 'yesOrNo', width: 90, sortable: false, // 添加这一行来禁止排序
                    editor: {
                        xtype: 'combobox',
                        queryMode: 'local',
                        displayField: 'text',
                        valueField: 'value',
                        store: comboBoxStore,
                        editable: false,
                        forceSelection: true,
                        allowBlank: false
                    },
                },
                {
                    header: '详细更改内容',
                    dataIndex: 'content',
                    flex: 2,
                    editor: 'textfield',
                    sortable: false, // 添加这一行来禁止排序
                    renderer: function (value, metaData, record, row, col, store) {
                        if (value) {
                            metaData.tdAttr = 'data-qtip="' + value + '"';
                        }
                        return value;
                    }
                },
                {
                    header: '上传',
                    dataIndex: 'customUpload',
                    hidden: !disableNode(head_node),
                    width: 70,
                    sortable: false, // 添加这一行来禁止排序
                    renderer: function (value, metaData, record, row, col, store) {
                        let id = record.get('id');
                        let html = `
                                    <img src="/Windchill/netmarkets/images/database_import_16x16.gif" 
                                         style="vertical-align:text-bottom;"/>
                                    `;
                        return html;
                    }
                },
                {
                    text: '文件链接', dataIndex: 'fileLink', flex: 2.5, sortable: false, // 添加这一行来禁止排序,
                    renderer: function (value, metaData, record, row, col, store) {
                        let display = value;
                        if (value) {
                            display = value.replaceAll('|', ' <br>');
                        }
                        return display
                    }
                },

            ],
            height: 300,
            width: '100%',

        });

        //点击
        itemUpdateGrid.on('cellclick', function (grid, rowIndex, colIndex, record) {
            let column = itemUpdateGrid.columns[colIndex];
            let dataIndex = column.dataIndex;
            if (dataIndex === 'customUpload') {
                let yesOrNo = record.get('yesOrNo');
                if (yesOrNo === '否') return;
                nowRecord = record;
                let a = document.getElementById('hiddenFileField-button-fileInputEl');
                a.click();
            }
        });
        //编辑前
        itemUpdateGrid.on('beforeedit', function (editor, e) {
            debugger
            if (!disableNode(head_node)) return false;
            let tRecord = e.record; //得到当前行所有数据
            let tField = e.field; //得到修改列
            let tValue = e.value; //得到修改列修改后值
            let itemId = tRecord.get('id');
            if (tField === 'name') {
                return false;
            }
            if (tField === 'content') {
                let yesOrNo = tRecord.get('yesOrNo');
                if (yesOrNo === '否') {
                    return false;
                }
            }
        });
        //编辑后
        itemUpdateGrid.on('edit', function (editor, e) {
            debugger
            let tRecord = e.record; //得到当前行所有数据
            let tField = e.field; //得到修改列
            let tValue = e.value; //得到修改列修改后值
            let itemId = tRecord.get('id');
            if (tField === 'content') {
                let key = itemId + 'Content'; //例：packContent
                //触发后台保存
                autoSaveAtt(key, tValue);
                itemUpdateStore.load();
            }
            if (tField === 'yesOrNo') {
                //触发后台保存
                let vvv = [];
                itemUpdateGrid.getStore().each(function (record) {
                    var id = record.get('id');
                    var yesOrNo = record.get('yesOrNo');
                    if (yesOrNo === '是') {
                        //将id追加到数组里面，后台保存
                        vvv.push(id);
                    } else {
                        var content = record.get('content');
                        if (content) {
                            let key = itemId + 'Content'; //例：packContent
                            //触发后台保存
                            autoSaveAtt(key, "", false);
                        }
                    }
                });
                let v = vvv.join(',');
                autoSaveAtt('projectUpdateGroup', v, false);
                itemUpdateStore.load();
            }
        });


        // endregion

        Ext.define('assignmentModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'type', 'demandAnalysis', 'hardware', 'software', 'structure', 'idEngineer',
                'testEngineer', 'craft', 'otherStaffs'],
            idProperty: 'id'
        });

        //所属PDT产品线清单
        var productLineStore = Ext.create('Ext.data.Store', {
            id: 'productLineStore',
            model: '',
            pruneModifiedRecords: true,
            //先提供数据，后期需要获取服务器数据，待注释
            fields: ['id', 'name'],


            // TDT
            // Charter开发类项目
            // 研发其他
            data: [
                {"id": "1", "name": "通用消防PDT（通用报警组）"},
              //  {"id": "2", "name": "电气火灾监控系统&消防设备电源监控系统产品"},
              //  {"id": "3", "name": "防火门监控系统产品"},
                {"id": "4", "name": "通用消防PDT（疏散逃生组）"},
                {"id": "5", "name": "海外火灾报警系统产品"},
                // {"id": "6", "name": "城市更新SDT产品"},
                // {"id": "7", "name": "储能SDT产品"},
                // {"id": "8", "name": "工业SDT产品"},
                {"id": "9", "name": "外购品产品管理团队"},
                {"id": "10", "name": "TDT"},
                {"id": "11", "name": "研发其他"},
                {"id": "12", "name": "工业消防PDT"},
                {"id": "13", "name": "消防电气监控系统产品"}
            ],
            // proxy: new Ext.data.HttpProxy({
            //     url: '/Windchill/ptc1/tinyAssignment/getItemInfo?branchId=' + branchId,
            //     method: 'GET',
            //     reader: {
            //         type: 'json',
            //         rootProperty: 'data',
            //         idProperty: 'id',
            //         messageProperty: 'error'
            //     }
            // }),
            autoload: false
        });

        var productLineCombo = new Ext.form.field.ComboBox({
            name: 'productLine'
            , id: "productLine"
            , fieldLabel: '<font color=red>*</font>所属PDT产品线'
            , disabled: !disableNode(head_node)
            , disabledCls: 'none'
            , store: productLineStore //数据来源
            , displayField: "name" //展示值
            , valueField: "id"
            , labelWidth: 100
            , width: 450
            // ,typeAhead : true //自动选择第一项匹配的内容，配合typeAheadDelay可以设置延时的时间
            // ,fuzzySelect : true
            , queryMode: 'local' //取本地数据,若为数据库则修改为remote
            // ,multiSelect : true //支持多选
            // ,forceSelection : true //失去焦点时，选择第一个值
            , triggerAction: 'all'
            , allowBlank: false
            // ,selectOnFocus:true
            , anyMatch: true
            // ,forceSelection:true
            , hidden: false //是否隐藏
            , listeners: {
                blur: function (e) {
                    // var result = getProductChangeApplySum('productLine', e.value);
                    // if (result.length == 0){
                    //     autoSaveAtt('productLine',e.value);
                    // }

                    var value = Ext.getCmp('productLine').getRawValue();

                    //触发后台保存
                    autoSaveAtt('productLine', value);
                }
            }
        });

        var productLineDisplay = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 330,
            // id:'productLine',
            name: 'productLine',
            margin: '-3 0 0 0',
            disabled: !disableNode(head_node),
            disabledCls: 'none',
        });

        //region 规划情况 combobox
        var planningSituationStore = Ext.create('Ext.data.Store', {
            id: 'planningStore',
            model: '',
            pruneModifiedRecords: true,
            fields: ['id', 'name'],
            data: [
                {id: '规划内', name: '规划内'},
                {id: '规划外', name: '规划外'}
            ],
            autoload: false
        });

        var planningSituationCombo = new Ext.form.field.ComboBox({
            name: 'planningSituation'
            , id: "planningSituation"
            , fieldLabel: '<font color=red>*</font>规划情况'
            , disabled: !disableNode(head_node)
            , disabledCls: 'none'
            , store: planningSituationStore //数据来源
            , displayField: "name" //展示值
            , valueField: "id"
            , labelWidth: 100
            , width: 440
            // ,typeAhead : true //自动选择第一项匹配的内容，配合typeAheadDelay可以设置延时的时间
            // ,fuzzySelect : true
            , queryMode: 'local' //取本地数据,若为数据库则修改为remote
            // ,multiSelect : true //支持多选
            // ,forceSelection : true //失去焦点时，选择第一个值
            , triggerAction: 'all'
            , allowBlank: false
            // ,selectOnFocus:true
            , anyMatch: true
            // ,forceSelection:true
            , hidden: false //是否隐藏
            , listeners: {
                blur: function (e) {

                    changeValue_planningSituation();
                    //触发后台保存
                    let value = Ext.getCmp('planningSituation').getRawValue();
                    autoSaveAtt('planningSituation', value);
                }
            }
        });

        var planningSituationDisplay = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 430,
            name: 'planningSituation',
            margin: '-3 0 0 0',
            disabled: !disableNode(head_node),
            disabledCls: 'none',
        });
        //endregion

        //region 是否有认证需求 combobox 弃用
        /*        let isNeedDemandStore = Ext.create('Ext.data.Store', {
                    id: 'planningStore',
                    model: '',
                    pruneModifiedRecords: true,
                    fields: ['id', 'name'],
                    data: [
                        {id: '是', name: '是'},
                        {id: '否', name: '否'}
                    ],
                    autoload: false
                });

                let isNeedDemandCombo = new Ext.form.field.ComboBox({
                    name: 'isNeedDemand'
                    , id: "isNeedDemand"
                    , store: isNeedDemandStore //数据来源
                    , displayField: "name" //展示值
                    , valueField: "id"
                    , labelWidth: 100
                    , width: 180
                    , fieldLabel: '是否有认证需求'
                    // ,typeAhead : true //自动选择第一项匹配的内容，配合typeAheadDelay可以设置延时的时间
                    // ,fuzzySelect : true
                    , queryMode: 'local' //取本地数据,若为数据库则修改为remote
                    , multiSelect: false //支持多选
                    // ,forceSelection : true //失去焦点时，选择第一个值
                    , triggerAction: 'all'
                    , allowBlank: false
                    // ,selectOnFocus:true
                    , anyMatch: true
                    // ,forceSelection:true
                    , hidden: false //是否隐藏
                    , listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('isNeedDemand').getRawValue();
                            //触发后台保存
                            autoSaveAtt('isNeedDemand', value);
                        }
                    }
                });

                let isNeedDemandDisplay = Ext.create('Ext.form.field.Text', {
                    labelWidth: 100,
                    width: 430,
                    name: 'isNeedDemand'
                });*/
        //endregion

        //region 认证需求 combobox
        let demandGroupStore = Ext.create('Ext.data.Store', {
            id: 'planningStore',
            model: '',
            pruneModifiedRecords: true,
            fields: ['id', 'name'],
            data: [
                {"id": "CCC认证", "name": "CCC认证"},
                {"id": "自愿性认证", "name": "自愿性认证"},
                {"id": "防爆认证", "name": "防爆认证"},
                {"id": "船检认证", "name": "船检认证"},
                {"id": "CE认证", "name": "CE认证"},
                {"id": "LPCB认证", "name": "LPCB认证"},
                {"id": "APPLUS认证", "name": "APPLUS认证"},
                {"id": "UL认证", "name": "UL认证"},
                {"id": "无线电发射设备型号核准", "name": "无线电发射设备型号核准"},
                {"id": "电信设备进网许可", "name": "电信设备进网许可"},
                {"id": "计量器具型式批准", "name": "计量器具型式批准"},
                {"id": "技术鉴定", "name": "技术鉴定"},
                {"id": "粉尘认证", "name": "粉尘认证"},
                {"id": "防腐认证", "name": "防腐认证"},
                {"id": "SIL2安全认证", "name": "SIL2安全认证"},
                {"id": "IP等级认证", "name": "IP等级认证"},
                {"id": "无认证需求", "name": "无认证需求"},
                {"id": "其他认证", "name": "其他认证"}
            ],
            autoload: false
        });

        let demandGroupCombo = new Ext.form.field.ComboBox({
            name: 'demandGroup'
            , id: "demandGroup"
            , store: demandGroupStore //数据来源
            , displayField: "name" //展示值
            , valueField: "id"
            , labelWidth: 100
            , width: 500
            , fieldLabel: '认证需求'
            // ,typeAhead : true //自动选择第一项匹配的内容，配合typeAheadDelay可以设置延时的时间
            // ,fuzzySelect : true
            , queryMode: 'local' //取本地数据,若为数据库则修改为remote
            , multiSelect: true //支持多选
            // ,forceSelection : true //失去焦点时，选择第一个值
            , triggerAction: 'all'
            , allowBlank: false
            // ,selectOnFocus:true
            , anyMatch: true
            // ,forceSelection:true
            , hidden: false //是否隐藏
            , listeners: {
                blur: function (e) {
                    let rawValue = e.getRawValue();
                    if (rawValue.indexOf("无认证需求") > -1) {
                        e.setValue(['无认证需求']);
                    }
                    if (rawValue.indexOf("无认证") > -1 && !(rawValue.indexOf("无认证需求") > -1) && rawValue.indexOf(",") > -1) {
                        alert("无认证不能与其他的认证一起选择");
                        return;
                    }
                    //其他认证输入框，如果前面选择了其他认证，才显示输入框
                    let cmp = Ext.getCmp('elseDemand');
                    if (rawValue.indexOf("其他认证") > -1 || rawValue.indexOf("其它认证") > -1) {
                        cmp.setReadOnly(false);
                        let elseDemand_labelTextEl = document.getElementById("elseDemand-labelTextEl");
                        elseDemand_labelTextEl.classList.remove('colorGrey');
                    } else {
                        cmp.setValue("");
                        autoSaveAtt('elseDemand', '');
                        cmp.setReadOnly(true);
                        let elseDemand_labelTextEl = document.getElementById("elseDemand-labelTextEl");
                        elseDemand_labelTextEl.classList.add('colorGrey');
                    }
                    setValueByMultiSelectCombobox(e, 'demandGroup');
                }
            }
        });

        let demandGroupDisplay = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 430,
            disabledCls: 'none',
            fieldLabel: '认证需求',
            name: 'demandGroup',
            id: 'demandGroupDisplay',
            disabled: !disableNode(head_node),

        });
        //endregion

        /* var assignmentStore = Ext.create('Ext.data.Store', {
             id: 'assignmentStore',
             model: 'assignmentModel',
             pruneModifiedRecords: true,
             proxy: new Ext.data.HttpProxy({
                 url: '/Windchill/ptc1/tinyAssignment/getItemInfo?branchId=' + branchId,
                 method: 'GET',
                 reader: {
                     type: 'json',
                     rootProperty: 'data',
                     idProperty: 'id',
                     messageProperty: 'error'
                 }
             }),
             autoLoad: false
         });

         var cellEditing = new Ext.grid.plugin.CellEditing({
             clicksToEdit: 1
         });
     */
        //获取研发拓展组名单，从团队中获取
        //选人的comboboxStore（原来使用的是公用的：PLM.common.CtContainerUserStore）
        Ext.define('ctTinyAssignment.CtContainerUserStore', {
            extend: 'Ext.data.Store',
            alias: 'widget.CtContainerUserStore',
            fields: ['userFullName', 'userFullName_department'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/tinyAssignment/getCtContainerUserNames',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    //idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        //选人的combobox（原来使用的是公用的：PLM.common.CtContainerUserCombo）
        Ext.define('ctTinyAssignment.CtContainerUserCombo', {
            extend: 'Ext.form.field.ComboBox',
            alias: 'widget.CtContainerUserCombo',
            triggerAction: 'all',
            queryMode: 'local',
            displayField: 'display',
            valueField: 'userFullName',
            // 配置 renderer 使得在选择时显示复合信息
            displayTpl: Ext.create('Ext.XTemplate',
                '<tpl for=".">',
                '{userFullName} ',
                '</tpl>'
            ),
            forceSelection: true,
            anyMatch: true,
            //multiSelect: true,
            typeAhead: false,
            allowBlank: true,
            width: 255,
        });

        // 2024/09/15  该store只有fullName，不满足需求，重新定义了一个store
        //var teamMemberStore1 = new Ext.create('PLM.common.CtContainerUserStore', {

        //需求分析人员
        //region 需求分析人员组件
        var teamMemberStore1 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore1'
        });

        teamMemberStore1.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo1 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore1,
            name: "demandAnalysis_combobox",
            id: "demandAnalysis_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMember1 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "demandAnalysis",
            id: "demandAnalysis",
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });

        var teamMemberComboDisplay1 = Ext.create('Ext.form.field.Text', {
            readOnly: !disableNode(head_node),
            labelWidth: 100,
            width: 255,
            name: "demandAnalysis",
        });

        //endregion

        //region 硬件工程师组件
        var teamMemberStore2 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore2'
        });

        teamMemberStore2.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo2 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore2,
            name: "hardware_combobox",
            id: "hardware_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay2 = Ext.create('Ext.form.field.Text', {
            readOnly: !disableNode(head_node),
            labelWidth: 100,
            width: 255,
            name: "hardware",
        });

        var teamMember2 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "hardware",
            id: 'hardware',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 软件工程师组件
        var teamMemberStore3 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore3'
        });

        teamMemberStore3.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo3 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore3,
            name: "softwareEngineer_combobox",
            id: "softwareEngineer_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay3 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "softwareEngineer",
        });

        var teamMember3 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "softwareEngineer",
            id: 'softwareEngineer',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 结构工程师 选人组件
        var teamMemberStore4 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore4'
        });

        teamMemberStore4.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo4 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore4,
            name: "structureEngineer_combobox",
            id: "structureEngineer_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay4 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "structureEngineer",
        });

        var teamMember4 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "structureEngineer",
            id: 'structureEngineer',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });

        //endregion

        //region ID工程师组件  弃用
        var teamMemberStore5 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore5'
        });

        teamMemberStore5.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo5 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore5,
            name: "idEngineer_combobox",
            id: "idEngineer_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay5 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "idEngineer",
            id: 'idEngineer',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 测试工程师组件 弃用改成了 测试工程师(检测)
        /*var teamMemberStore6 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore6'
        });

        teamMemberStore6.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo6 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore6,
            name: "testEngineer",
            id: "testEngineer",
            listeners: {
                blur: function (e) {
                    setExpansionTeamsValueByCombobox(e,
                        'testEngineer',
                        'testEngineerQuantity');
                }
            }
        });

        var teamMemberComboDisplay6 = new Ext.form.field.Display({
            labelWidth: 100,
            width:255,
            name: "testEngineer",
            // id:'productLine',
        });*/
        //endregion

        //region 测试工程师(检测)
        var teamMemberStore6 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore6'
        });

        teamMemberStore6.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo6 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore6,
            name: "testEngineer_test_combobox",
            id: "testEngineer_test_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay6 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "testEngineer_test",
        });

        var teamMember6 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "testEngineer_test",
            id: 'testEngineer_test',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 工艺工程师组件
        var teamMemberStore7 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore7'
        });

        teamMemberStore7.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo7 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore7,
            name: "craft_combobox",
            id: "craft_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay7 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "craft",
        });

        var teamMember7 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "craft",
            id: 'craft',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 其他人员组件
        var teamMemberStore8 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore8'
        });

        teamMemberStore8.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo8 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore8,
            name: "otherStaffs_combobox",
            id: "otherStaffs_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay8 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "otherStaffs",
        });

        var teamMember8 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "otherStaffs",
            id: 'otherStaffs',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 包装工程师 选人组件以及文本显示
        var teamMemberStore9 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore9'
        });

        teamMemberStore9.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo9 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore9,
            name: "packagingEngineer_combobox",
            id: "packagingEngineer_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay9 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "packagingEngineer",
        });

        var teamMember9 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "packagingEngineer",
            id: 'packagingEngineer',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region NPI工程师 选人组件以及文本显示

        var teamMemberStore10 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore10'
        });

        teamMemberStore10.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo10 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore10,
            name: "npiEngineer_combobox",
            id: "npiEngineer_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay10 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "npiEngineer",
        });

        var teamMember10 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "npiEngineer",
            id: 'npiEngineer',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 电子工程师（工程部） 选人组件以及文本显示 弃用

        /*        var teamMemberComboDisplay11 = new Ext.form.field.Display({
                    labelWidth: 100,
                    width:255,
                    name: "electronicsEngineer",
                    // id:'productLine',
                });

                var teamMemberStore11 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
                    storeId: 'teamMemberStore11'
                });

                teamMemberStore11.load({
                    params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
                    callback: function (r, options, success) {
                        if (!success) {
                            alert(options.error);
                        }
                    }
                });

                var teamMemberCombo11 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
                    store: teamMemberStore11,
                    name: "electronicsEngineer",
                    id: "electronicsEngineer",
                    listeners: {
                        blur: function (e) {
                            setExpansionTeamsValueByCombobox(e,
                                'electronicsEngineer',
                                'electronicsQuantity');
                        }
                    }
                });

                var teamMemberComboDisplay11 = new Ext.form.field.Display({
                    labelWidth: 100,
                    width:255,
                    name: "electronicsEngineer",
                    // id:'productLine',
                });*/
        //endregion

//需求分析人员	11工业设计工程师	硬件工程师	软件工程师	结构工程师	包装工程师	11测试工程师(检测)
// 11测试工程师(工程)	  工艺工程师	    NPI工程师	11电源工程师	 11TQC 	其他人员

        //region 工业设计工程师 选人组件以及文本显示 industrialDesignEngineer

        var teamMemberStore12 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore12'
        });

        teamMemberStore12.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo12 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore12,
            name: "industrialDesignEngineer_combobox",
            id: "industrialDesignEngineer_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay12 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "industrialDesignEngineer",
        });

        var teamMember12 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "industrialDesignEngineer",
            id: 'industrialDesignEngineer',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 测试工程师(工程) 选人组件以及文本显示 testEngineer_engineeringQuantity

        var teamMemberStore13 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore13'
        });

        teamMemberStore13.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo13 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore13,
            name: "testEngineer_engineering_combobox",
            id: "testEngineer_engineering_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay13 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "testEngineer_engineering",
        });

        var teamMember13 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "testEngineer_engineering",
            id: 'testEngineer_engineering',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region 电源工程师 选人组件以及文本显示 powerEngineer

        var teamMemberStore14 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore14'
        });

        teamMemberStore14.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo14 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore14,
            name: "powerEngineer_combobox",
            id: "powerEngineer_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay14 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "powerEngineer",
        });

        var teamMember14 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "powerEngineer",
            id: 'powerEngineer',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //region TQC 选人组件以及文本显示 tqc

        var teamMemberStore15 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
            storeId: 'teamMemberStore15'
        });

        teamMemberStore15.load({
            params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
            callback: function (r, options, success) {
                if (!success) {
                    alert(options.error);
                }
            }
        });

        var teamMemberCombo15 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
            store: teamMemberStore15,
            name: "tqcEngineer_combobox",
            id: "tqcEngineer_combobox",
            listeners: {
                blur: function (e, records) {
                    saveFormForExpansionGroupUserBySelect(e, records);
                }
            }
        });

        var teamMemberComboDisplay15 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            readOnly: !disableNode(head_node),
            width: 255,
            name: "tqcEngineer",
        });

        var teamMember15 = Ext.create('Ext.form.field.Text', {
            labelWidth: 100,
            width: 255,
            name: "tqcEngineer",
            id: 'tqcEngineer',
            listeners: {
                blur: function (e) {
                    saveFormForExpansionGroupUserByInput(e);
                }
            }
        });
        //endregion

        //获取需求人名单，全部人
        var dDemanderStore = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'dDemanderStore'
        });

        // dDemanderStore.load({
        //     params:{containerOid:containerOid},//containerOid由页面传入，获得方法a
        //     callback : function(r, options, success) {
        //         if (!success) {
        //             alert(options.error);
        //         }
        //     }
        // });

        /*var dDemanderCombo = Ext.create('Ext.form.field.ComboBox', {
            fieldLabel: '<font color=red>*</font>需求人',
            width: 250,
            disabled: !disableNode(head_node),
            disabledCls: 'none',
            store: dDemanderStore,
            name: "dDemander",
            id: "dDemander",
            displayField: 'userFullName',
            valueField: 'no',
            triggerAction: 'all',
            typeAhead: true,
            selectOnFocus: true,
            forceSelection: true,
            editable: true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            listeners: {
                blur: function (e) {
                    var value = Ext.getCmp('dDemander').getValue();
                    //触发后台保存
                    autoSaveAtt('dDemander', value);
                    if (value == null || value == '' || value == undefined) {
                        Ext.getCmp("department").setValue("");
                        autoSaveAtt('department', "");
                    } else {
                        getDepartment(value);
                    }

                }
            }
        });*/

        var dDemanderComboDisplay = new Ext.form.field.Display({
            fieldLabel: '<font color=red>*</font>需求人',
            labelWidth: 100,
            width: 250,
            name: "dDemander",
        });

        /*var assignmentGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('assignmentStore'),//获取表格数据库信息
            id: 'assignmentGrid',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'type', width: 100,},
                {text: '需求分析人员', dataIndex: 'demandAnalysis', width: 100, editor: 'textfield'},
                {text: '硬件工程师', dataIndex: 'hardware', width: 100, editor: 'textfield'},
                {text: '软件工程师', dataIndex: 'software', width: 100, editor: 'textfield'},
                {text: '结构工程师', dataIndex: 'structure', width: 100, editor: 'textfield'},
                {text: 'ID工程师', dataIndex: 'idEngineer', width: 100, editor: 'textfield'},
                {text: '测试工程师', dataIndex: 'testEngineer', width: 100, editor: 'textfield'},
                {text: '工艺工程师', dataIndex: 'craft', width: 100, editor: 'textfield'},
                {text: '其他人员', dataIndex: 'otherStaffs', width: 100, editor: 'textfield'},
            ],

            //表格权限设置
            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    var tField = e.field; //得到修改列

                    if(!disableNode(head_node)) {
                        return false;
                    }

                },
            }
        });


        assignmentGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveItemData(tRecord.data, callbackFn)

            });*/

        //表单items
        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            title: '1.基本项目信息',
            //anchor: '90%',
            width: '100%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [

                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [
                        {
                            xtype: 'textfield',
                            disabled: !disableNode(head_node),
                            disabledCls: 'none',
                            fieldLabel: '<font color=red>*</font>项目名称',
                            name: 'projectName',
                            id: 'projectName',
                            border: 0,
                            width: 445,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('projectName').getValue();
                                    //触发后台保存
                                    autoSaveAtt('projectName', value);
                                }
                            }

                        },
                        {
                            xtype: 'textfield',
                            disabled: !disableNode(head_node),
                            disabledCls: 'none',
                            fieldLabel: '项目编码',
                            name: 'projectNumber',
                            id: 'projectNumber',
                            border: 0,
                            width: 445,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('projectNumber').getValue();
                                    //触发后台保存
                                    autoSaveAtt('projectNumber', value);
                                }
                            }

                        }
                    ]
                },
                //所属PDT 规划情况
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [
                        {
                            xtype: 'panel',
                            laybox: 'hbox',
                            border: false,
                            items: [productLineCombo]
                        },
                        //规划情况
                        {
                            xtype: 'panel',
                            laybox: 'hbox',
                            border: false,
                            margin: '5 0 0 -5',
                            items: [planningSituationCombo]
                        },
                    ]
                },
                //规划项目名称 规划项目编号
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '0 20 0 0', labelWidth: 120},
                    //hidden:false,
                    id: 'projectNameAndNumber',
                    items: [
                        //规划项目名称
                        {
                            border: false,
                            html: redStarFlag + planningProjectNameLabel,
                            id: 'planningProjectNameLabel',
                            width: 90,
                        },
                        {
                            xtype: 'textfield',
                            disabled: !disableNode(head_node),
                            disabledCls: 'none',
                            name: "planningProjectName",
                            id: 'planningProjectName',
                            width: 340,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('planningProjectName').getValue();
                                    //触发后台保存
                                    autoSaveAtt('planningProjectName', value);
                                }
                            }
                        },
                        //规划项目编号
                        {
                            border: false,
                            html: redStarFlag + planningProjectNumberLabel,
                            id: 'planningProjectNumberLabel',
                            width: 90,
                        },
                        {
                            xtype: 'textfield',
                            disabled: !disableNode(head_node),
                            disabledCls: 'none',
                            name: "planningProjectNumber",
                            id: 'planningProjectNumber',
                            width: 330,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('planningProjectNumber').getValue();
                                    //触发后台保存
                                    autoSaveAtt('planningProjectNumber', value);
                                }
                            }
                        }
                    ]
                },
                /*                //成品编码 - 弃用
                                {
                                    xtype: 'panel',
                                    layout: 'hbox',
                                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                                    items: [{
                                        xtype: 'textfield',
                                        disabled: !disableNode(head_node),
                                        disabledCls: 'none',
                                        fieldLabel: '成品编码 - 弃用吗？',
                                        name: 'productNumber',
                                        id: 'productNumber',
                                        border: false,
                                        width: 1040,
                                        listeners: {
                                            blur: function (e) {
                                                var value = Ext.getCmp('productNumber').getValue();
                                                //触发后台保存
                                                autoSaveAtt('productNumber', value);
                                            }
                                        }
                                    }
                                    ]
                                },
                                //产品型号 - 弃用吗？
                                {
                                    xtype: 'panel',
                                    layout: 'hbox',
                                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                                    items: [{
                                        border: false,
                                        html: '产品型号(多个用半角分号来区分)  - 弃用吗？'
                                    }, {
                                        xtype: 'textfield',
                                        disabled: !disableNode(head_node),
                                        disabledCls: 'none',
                                        name: "productType",
                                        id: 'productType',
                                        width: 830,
                                        listeners: {
                                            blur: function (e) {
                                                var value = Ext.getCmp('productType').getValue();
                                                //触发后台保存
                                                autoSaveAtt('productType', value);
                                            }
                                        }
                                    }
                                    ]
                                },*/

                tinyAssignmentGrid2,

                //2. 需求描述
                {
                    xtype: 'panel',
                    layout: 'vbox',
                    title: '2. 需求描述',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [

                        {
                            xtype: 'radiogroup',
                            disabled: !disableNode(head_node),
                            disabledCls: 'none',
                            fieldLabel: '<font color=red>*</font>需求来源',
                            width: 350,
                            name: 'isSourceGroup',
                            id: 'isSourceGroup',
                            labelWidth: 100,
                            items: [{
                                inputValue: '内部需求',
                                boxLabel: '内部需求',
                                name: 'isSource',
                                disabledCls: 'none'
                            }, {
                                inputValue: '外部需求',
                                boxLabel: '外部需求',
                                name: 'isSource',
                                disabledCls: 'none'
                            }],
                            listeners: {
                                change: function (field, newValue, oldValue) {

                                    if (taskCompleted) {
                                        //阻止加载数据时执行后台保存
                                        return;
                                    }
                                    if (!disableNode(head_node)) {
                                        return;
                                    }
                                    if (newValue.isSource === '内部需求') {
                                        //内部需求
                                        Ext.getCmp('department').disable();
                                        Ext.getCmp('dDemander').enable();
                                        //外部需求
                                        Ext.getCmp('client').disable();
                                        Ext.getCmp('cDemander').disable();
                                        Ext.getCmp('client').setValue('');
                                        Ext.getCmp('cDemander').setValue('');
                                        autoSaveAtt('client', '');
                                        autoSaveAtt('cDemander', '');

                                        let planningProjectNumberLabelEl = document.getElementById("dDemander-labelTextEl");
                                        planningProjectNumberLabelEl.classList.remove('colorGrey');
                                        let departmentEl = document.getElementById("department-labelTextEl");
                                        departmentEl.classList.remove('colorGrey');

                                        let clientLabelEl = document.getElementById("client-labelTextEl");
                                        clientLabelEl.classList.add('colorGrey');
                                        let cDemanderEl = document.getElementById("cDemander-labelTextEl");
                                        cDemanderEl.classList.add('colorGrey');

                                    } else if (newValue.isSource === '外部需求') {
                                        //外部需求
                                        Ext.getCmp('client').enable();
                                        Ext.getCmp('cDemander').enable();
                                        //内部需求
                                        Ext.getCmp('department').disable();
                                        Ext.getCmp('dDemander').setDisabled(true);
                                        Ext.getCmp('department').setValue('');
                                        Ext.getCmp('dDemander').setValue('');
                                        autoSaveAtt('department', '');
                                        autoSaveAtt('dDemander', '');

                                        let planningProjectNumberLabelEl = document.getElementById("dDemander-labelTextEl");
                                        planningProjectNumberLabelEl.classList.add('colorGrey');
                                        let departmentEl = document.getElementById("department-labelTextEl");
                                        departmentEl.classList.add('colorGrey');

                                        let clientLabelEl = document.getElementById("client-labelTextEl");
                                        clientLabelEl.classList.remove('colorGrey');
                                        let cDemanderEl = document.getElementById("cDemander-labelTextEl");
                                        cDemanderEl.classList.remove('colorGrey');


                                        /* Ext.getCmp('department').setValue('');
                                         Ext.getCmp('dDemander').setValue('');*/
                                    }
                                    //触发后台保存
                                    autoSaveAtt('isSource', newValue.isSource);
                                },
                            }
                        },
                        //内部需求
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                            items: [
                                {
                                    xtype: 'panel',
                                    layout: 'hbox',
                                    items: [
                                        {border: false, html: '<span style ="line-height: 22px; ">内部需求：</span>'},
                                        {
                                            xtype: "textfield",
                                            fieldLabel: '<font color=red>*</font>部门',
                                            disabled: true,
                                            disabledCls: 'none',
                                            name: 'department',
                                            id: 'department',
                                            width: 210,
                                            margin: '0 0 0 40px',
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('department').getValue();
                                                    //触发后台保存
                                                    autoSaveAtt('department', value);
                                                },

                                            },
                                        },
                                        {
                                            xtype: 'combo',
                                            multiSelect: false,
                                            valueField: 'no',
                                            displayField: 'userFullName',
                                            anyMatch: true,
                                            editable: true,
                                            allowBlank: true,
                                            store: dDemanderStore,
                                            fieldLabel: '需求人',
                                            queryMode: 'local',
                                            name: 'dDemander',
                                            id: 'dDemander',
                                            disabled: !disableNode(head_node),
                                            disabledCls: 'none',
                                            margin: '0 0 0 40',
                                            width: 310,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('dDemander').getValue();
                                                    //触发后台保存
                                                    autoSaveAtt('dDemander', value);
                                                    if (value == null || value == '' || value == undefined) {
                                                        Ext.getCmp("department").setValue("");
                                                        autoSaveAtt('department', "");
                                                    } else {
                                                        getDepartment(value);
                                                    }

                                                }
                                            }
                                        },
                                    ]
                                }
                            ]
                        },
                        //外部需求
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                            items: [
                                {
                                    xtype: 'panel',
                                    layout: 'hbox',
                                    items: [
                                        //外部需求
                                        {border: false, html: '<span style ="line-height: 22px; ">外部需求：</span>'},
                                        //客户
                                        {
                                            xtype: 'textfield',
                                            disabled: !disableNode(head_node),
                                            disabledCls: 'none',
                                            fieldLabel: '<font color=red>*</font>客户',
                                            name: 'client',
                                            id: 'client',
                                            width: 210,
                                            margin: '0 0 0 40px',
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('client').getValue();
                                                    //触发后台保存
                                                    autoSaveAtt('client', value);
                                                }
                                            }
                                        },
                                        //需求人
                                        {
                                            xtype: 'textfield',
                                            disabled: !disableNode(head_node),
                                            disabledCls: 'none',
                                            fieldLabel: '需求人',
                                            name: 'cDemander',
                                            id: 'cDemander',
                                            width: 310,
                                            margin: '0 0 0 40px',
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('cDemander').getValue();
                                                    //触发后台保存
                                                    autoSaveAtt('cDemander', value);
                                                }
                                            }
                                        },
                                    ]
                                }
                            ]
                        },
                        //需求具体内容
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                            items: [{//第一行
                                xtype: 'panel',
                                layout: 'hbox',
                                width: '100%',
                                defaults: {margin: '5 20 0 0', labelWidth: 100},
                                items: [{
                                    xtype: 'textarea',
                                    disabled: !disableNode(head_node),
                                    disabledCls: 'none',
                                    fieldLabel: '<font color=red>*</font>需求具体内容',
                                    name: 'demandContent',
                                    id: 'demandContent',
                                    height: 180,
                                    width: 1040,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('demandContent').getValue();
                                            //触发后台保存
                                            autoSaveAtt('demandContent', value);
                                        }
                                    }
                                }
                                ],

                            }]
                        },
                        //附件
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                            items: [{//第一行
                                xtype: 'panel',
                                layout: 'hbox',
                                defaults: {margin: '5 20 0 0', labelWidth: 100},
                                items: [
                                    {
                                        xtype: 'panel',
                                        disabledCls: 'none',
                                        //disabled: !disableNode(head_node),
                                        border: false,
                                        layout: 'hbox',
                                        defaults: {margin: '5 20 0 0'},
                                        items: [{
                                            xtype: 'displayfield',
                                            fieldLabel: '<font color=red>*</font>附件',
                                            id: 'head_attatchment',
                                            name: 'head_attatchment',
                                            labelWidth: 150,
                                            width: 150
                                        },
                                            uploadFilefield("head_uploadFile", "文件", head_node, "head_uploadFileRecord"),
                                            {
                                                xtype: 'displayfield',
                                                fieldLabel: '附件链接',
                                                labelWidth: 70,
                                                id: 'head_uploadFileRecord',
                                                name: 'head_uploadFileRecord',
                                                width: 200
                                            }]
                                    },

                                ],

                            }]
                        },
                        /*
                                                {
                                                    xtype: 'panel',
                                                    layout: 'hbox',
                                                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                    items: [{
                                                        xtype: 'panel',
                                                        layout: 'hbox',
                                                        items: [{
                                                            xtype: 'radiogroup',
                                                            disabled: !disableNode(head_node),
                                                            disabledCls: 'none',
                                                            fieldLabel: '<font color=red>*</font>需求来源',
                                                            width: 350,
                                                            name: 'isSourceGroup',
                                                            id: 'isSourceGroup',
                                                            labelWidth: 100,
                                                            items: [{
                                                                inputValue: '内部需求',
                                                                boxLabel: '内部需求',
                                                                name: 'isSource',
                                                                disabledCls: 'none'
                                                            }, {
                                                                inputValue: '外部需求',
                                                                boxLabel: '外部需求',
                                                                name: 'isSource',
                                                                disabledCls: 'none'
                                                            }],
                                                            listeners: {
                                                                change: function (field, newValue, oldValue) {

                                                                    if (taskCompleted) {
                                                                        //阻止加载数据时执行后台保存
                                                                        return;
                                                                    }
                                                                    if (!disableNode(head_node)) {
                                                                        return;
                                                                    }
                                                                    if (newValue.isSource == '内部需求') {
                                                                        Ext.getCmp('client').disable();
                                                                        Ext.getCmp('cDemander').disable();
                                                                        Ext.getCmp('client').setValue('');
                                                                        Ext.getCmp('cDemander').setValue('');
                                                                        Ext.getCmp('department').enable();
                                                                        Ext.getCmp('dDemander').enable();
                                                                    } else if (newValue.isSource == '外部需求') {
                                                                        Ext.getCmp('client').enable();
                                                                        Ext.getCmp('cDemander').enable();
                                                                        Ext.getCmp('department').disable();
                                                                        Ext.getCmp('dDemander').disable();
                                                                        /!* Ext.getCmp('department').setValue('');
                                                                         Ext.getCmp('dDemander').setValue('');*!/
                                                                    }
                                                                    //触发后台保存
                                                                    autoSaveAtt('isSource', newValue.isSource);
                                                                },
                                                            }
                                                        }
                                                        ],

                                                    }]
                                                },
                                                {
                                                    xtype: 'panel',
                                                    layout: 'hbox',
                                                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                    items: [{//第一行
                                                        xtype: 'panel',
                                                        layout: 'hbox',
                                                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                        items: [{
                                                            xtype: "displayfield",
                                                            fieldLabel: '<font color=red>*</font>部门',
                                                            name: 'department',
                                                            id: 'department',
                                                            width: 250,
                                                            listeners: {

                                                                blur: function (e) {
                                                                    var value = Ext.getCmp('department').getValue();
                                                                    //触发后台保存
                                                                    autoSaveAtt('department', value);
                                                                },

                                                            },

                                                        }, {
                                                            xtype: 'combo',
                                                            multiSelect: false,
                                                            valueField: 'no',
                                                            displayField: 'userFullName',
                                                            anyMatch: true,
                                                            editable: true,
                                                            allowBlank: true,
                                                            store: dDemanderStore,
                                                            fieldLabel: '需求人',
                                                            queryMode: 'local',
                                                            name: 'dDemander',
                                                            id: 'dDemander',
                                                            disabled: !disableNode(head_node),
                                                            disabledCls: 'none',
                                                            width: 250,
                                                            listeners: {
                                                                blur: function (e) {
                                                                    var value = Ext.getCmp('dDemander').getValue();
                                                                    //触发后台保存
                                                                    autoSaveAtt('dDemander', value);
                                                                    if (value == null || value == '' || value == undefined) {
                                                                        Ext.getCmp("department").setValue("");
                                                                        autoSaveAtt('department', "");
                                                                    } else {
                                                                        getDepartment(value);
                                                                    }

                                                                }
                                                            }
                                                        },

                                                        ],

                                                    }]
                                                },
                                                {
                                                    xtype: 'panel',
                                                    layout: 'hbox',
                                                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                    items: [{//第一行
                                                        xtype: 'panel',
                                                        layout: 'hbox',
                                                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                        items: [{
                                                            xtype: 'textfield',
                                                            disabled: !disableNode(head_node),
                                                            disabledCls: 'none',
                                                            fieldLabel: '<font color=red>*</font>客户',
                                                            name: 'client',
                                                            id: 'client',
                                                            width: 510,
                                                            listeners: {
                                                                blur: function (e) {
                                                                    var value = Ext.getCmp('client').getValue();
                                                                    //触发后台保存
                                                                    autoSaveAtt('client', value);
                                                                }
                                                            }
                                                        }, {
                                                            xtype: 'textfield',
                                                            disabled: !disableNode(head_node),
                                                            disabledCls: 'none',
                                                            fieldLabel: '需求人',
                                                            name: 'cDemander',
                                                            id: 'cDemander',
                                                            width: 510,
                                                            listeners: {
                                                                blur: function (e) {
                                                                    var value = Ext.getCmp('cDemander').getValue();
                                                                    //触发后台保存
                                                                    autoSaveAtt('cDemander', value);
                                                                }
                                                            }
                                                        },
                                                        ],
                                                    }]
                                                },
                                                {
                                                    xtype: 'panel',
                                                    layout: 'hbox',
                                                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                    items: [{//第一行
                                                        xtype: 'panel',
                                                        layout: 'hbox',
                                                        width: '100%',
                                                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                        items: [{
                                                            xtype: 'textarea',
                                                            disabled: !disableNode(head_node),
                                                            disabledCls: 'none',
                                                            fieldLabel: '<font color=red>*</font>需求具体内容',
                                                            name: 'demandContent',
                                                            id: 'demandContent',
                                                            height: 180,
                                                            width: 1040,
                                                            listeners: {
                                                                blur: function (e) {
                                                                    var value = Ext.getCmp('demandContent').getValue();
                                                                    //触发后台保存
                                                                    autoSaveAtt('demandContent', value);
                                                                }
                                                            }
                                                        }
                                                        ],

                                                    }]
                                                },
                                                {
                                                    xtype: 'panel',
                                                    layout: 'hbox',
                                                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                    items: [{//第一行
                                                        xtype: 'panel',
                                                        layout: 'hbox',
                                                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                        items: [
                                                            {
                                                                xtype: 'panel',
                                                                disabledCls: 'none',
                                                                disabled: !disableNode(head_node),
                                                                border: false,
                                                                layout: 'hbox',
                                                                defaults: {margin: '5 20 0 0'},
                                                                items: [{
                                                                    xtype: 'displayfield',
                                                                    fieldLabel: '<font color=red>*</font>请选择要上传的文件',
                                                                    id: 'head_attatchment',
                                                                    name: 'head_attatchment',
                                                                    labelWidth: 150,
                                                                    width: 150
                                                                }, uploadFilefield("head_uploadFile", "文件", head_node, "head_uploadFileRecord"), {
                                                                    xtype: 'displayfield',
                                                                    fieldLabel: '附件链接',
                                                                    labelWidth: 70,
                                                                    id: 'head_uploadFileRecord',
                                                                    name: 'head_uploadFileRecord',
                                                                    width: 200
                                                                }]
                                                            },

                                                        ],

                                                    }]
                                                },*/
                    ]
                },

                //3. 被参考的产品信息
                tinyAssignmentGrid,
                //4. 认证需求
                {
                    xtype: 'panel',
                    layout: 'vbox',
                    title: '4. 认证需求',
                    defaults: {margin: '5 20 10 0', labelWidth: 100, border: false,},
                    items: [
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                            items: [
                                {
                                    xtype: 'panel',
                                    layout: 'hbox',
                                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                                    items: [
                                        //是否有认证需求 弃用
                                        /*disableNode(head_node) ? isNeedDemandCombo : isNeedDemandDisplay,*/
                                        //认证需求
                                        disableNode(head_node) ? demandGroupCombo : demandGroupDisplay,
                                        /*{
                                            fieldLabel: '认证需求',
                                            xtype: 'checkboxgroup',
                                            // disabled: !disableNode(head_node),
                                            // readOnly: !disableNode(head_node),
                                            name: 'demandGroup',
                                            id: 'demandGroup',
                                            width: 500,
                                            columns: 4,
                                            items: [{
                                                inputValue: 'CCC',
                                                boxLabel: 'CCC',
                                                name: 'CCC',
                                                disabledCls: 'none',
                                            }, {
                                                inputValue: 'LPCB',
                                                boxLabel: 'LPCB',
                                                name: 'LPCB',
                                                disabledCls: 'none',
                                            }, {
                                                inputValue: 'UL',
                                                boxLabel: 'UL',
                                                name: 'UL',
                                                disabledCls: 'none',

                                            }, {
                                                inputValue: 'CE',
                                                boxLabel: 'CE',
                                                name: 'CE',
                                                disabledCls: 'none',
                                            }, {
                                                inputValue: '无认证',
                                                boxLabel: '无认证',
                                                name: '无认证',
                                                disabledCls: 'none',
                                            }],
                                            listeners: {

                                                change: function (field, newValue, oldValue) {

                                                    if (taskCompleted) {

                                                        let raGroup = Ext.getCmp('demandGroup');
                                                        raGroup.items.get(1).disable();
                                                        raGroup.items.get(2).disable();
                                                        raGroup.items.get(3).disable();
                                                        raGroup.items.get(0).disable();
                                                        raGroup.items.get(4).disable();
                                                        //阻止加载时执行后台保存
                                                        return;
                                                    }
                                                    //触发后台保存
                                                    let raGroup = Ext.getCmp('demandGroup');
                                                    raGroup.items.get(1).enable();
                                                    raGroup.items.get(2).enable();
                                                    raGroup.items.get(3).enable();
                                                    raGroup.items.get(0).enable();
                                                    raGroup.items.get(4).enable();

                                                    var checkedDemands = raGroup.getChecked();
                                                    var demandsStr;
                                                    Ext.Array.each(checkedDemands, function (item) {
                                                        if (demandsStr) {
                                                            demandsStr += ',' + item.name;
                                                        } else {
                                                            demandsStr = item.name;
                                                        }
                                                    });
                                                    if (demandsStr == '无认证') {
                                                        raGroup.items.get(1).disable();
                                                        raGroup.items.get(2).disable();
                                                        raGroup.items.get(3).disable();
                                                        raGroup.items.get(0).disable();
                                                        raGroup.items.get(4).enable();
                                                        Ext.getCmp('elseDemand').disable();
                                                    } else if (!demandsStr) {
                                                        raGroup.items.get(1).enable();
                                                        raGroup.items.get(2).enable();
                                                        raGroup.items.get(3).enable();
                                                        raGroup.items.get(0).enable();
                                                        raGroup.items.get(4).enable();
                                                        Ext.getCmp('elseDemand').enable();
                                                    } else {
                                                        raGroup.items.get(4).disable();
                                                    }
                                                    autoSaveAtt('demandGroup', demandsStr);
                                                }
                                            }//~end of listeners
                                        },*/
                                        //其他认证需求
                                        {
                                            xtype: 'textfield',
                                            disabled: !disableNode(head_node),
                                            disabledCls: 'none',
                                            fieldLabel: '其他认证需求',
                                            name: 'elseDemand',
                                            id: 'elseDemand',
                                            width: 400,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('elseDemand').getValue();
                                                    //是否显示无认证的按钮（旧逻辑）
                                                    /*var raGroup = Ext.getCmp('demandGroup');
                                                    if (value) {
                                                        raGroup.items.get(4).disable();
                                                    } else {
                                                        raGroup.items.get(4).enable();
                                                    }*/
                                                    //触发后台保存
                                                    autoSaveAtt('elseDemand', value);
                                                }
                                            }
                                        }
                                    ],

                                }]
                        },
                    ]
                },
                //5. 在参考产品型号基础上，对以下项目进行修改
                {
                    xtype: 'panel',
                    layout: 'vbox',
                    title: '5. 在参考产品型号基础上，对以下项目进行修改',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [
                        fileField,
                        itemUpdateGrid,
                        /*                       {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [
                                                       {//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 280},
                                                       items: [{
                                                           fieldLabel: '<font color=red>*</font>在参考产品型号基础上，对以下项目进行修改',
                                                           xtype: 'checkboxgroup',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           name: 'projectUpdateGroup',
                                                           id: 'projectUpdateGroup',
                                                           width: 1000,
                                                           columns: 8,
                                                           items: [{
                                                               inputValue: '电子部分',
                                                               boxLabel: '电子部分',
                                                               name: 'electronic',
                                                               disabledCls: 'none'
                                                           }, {
                                                               inputValue: '结构部分',
                                                               boxLabel: '结构部分',
                                                               name: 'structure',
                                                               disabledCls: 'none'
                                                           }, {
                                                               inputValue: '软件部分',
                                                               boxLabel: '软件部分',
                                                               name: 'software',
                                                               disabledCls: 'none'
                                                           }, {
                                                               inputValue: '包装部分',
                                                               boxLabel: '包装部分',
                                                               name: 'pack',
                                                               disabledCls: 'none'
                                                           }, {
                                                               inputValue: '产品说明书',
                                                               boxLabel: '产品说明书',
                                                               name: 'specification',
                                                               disabledCls: 'none'
                                                           }, {
                                                               inputValue: '标牌',
                                                               boxLabel: '标牌',
                                                               name: 'scutcheon',
                                                               id: 'scutcheon',
                                                               disabledCls: 'none'
                                                           }, {
                                                               inputValue: '标贴',
                                                               boxLabel: '标贴',
                                                               name: 'label',
                                                               id: 'label',
                                                               disabledCls: 'none'
                                                           }, {
                                                               inputValue: '其他',
                                                               boxLabel: '其他',
                                                               name: 'else',
                                                               id: 'else',
                                                               disabledCls: 'none'
                                                           }],
                                                           listeners: {

                                                               change: function (field, newValue, oldValue) {
                                                                   if (taskCompleted) {
                                                                       //阻止加载时执行后台保存
                                                                       return;
                                                                   }
                                                                   //触发后台保存
                                                                   var raGroup = Ext.getCmp('projectUpdateGroup');
                                                                   var checkedProjects = Ext.getCmp('projectUpdateGroup').getChecked();
                                                                   var projectsStr = '';//必须初始化，防止后面异常
                                                                   Ext.Array.each(checkedProjects, function (item) {
                                                                       if (projectsStr) {
                                                                           projectsStr += ',' + item.name;
                                                                       } else {
                                                                           projectsStr = item.name;
                                                                       }

                                                                   });
                                                                   Ext.getCmp('electronicContent').disable();
                                                                   Ext.getCmp('structureContent').disable();
                                                                   Ext.getCmp('softwareContent').disable();
                                                                   Ext.getCmp('packContent').disable();
                                                                   Ext.getCmp('specificationContent').disable();
                                                                   Ext.getCmp('scutcheonContent').disable();
                                                                   Ext.getCmp('labelContent').disable();
                                                                   Ext.getCmp('elseContent').disable();
                                                                   Ext.getCmp('electronic_uploadFile').disable();
                                                                   Ext.getCmp('structure_uploadFile').disable();
                                                                   Ext.getCmp('software_uploadFile').disable();
                                                                   Ext.getCmp('pack_uploadFile').disable();
                                                                   Ext.getCmp('specification_uploadFile').disable();
                                                                   Ext.getCmp('scutcheon_uploadFile').disable();
                                                                   Ext.getCmp('label_uploadFile').disable();
                                                                   Ext.getCmp('else_uploadFile').disable();
                                                                   if (projectsStr.indexOf('electronic') > -1) {
                                                                       Ext.getCmp('electronicContent').enable();
                                                                       Ext.getCmp('electronic_uploadFile').enable();
                                                                   }
                                                                   if (projectsStr.indexOf('structure') > -1) {
                                                                       Ext.getCmp('structure_uploadFile').enable();
                                                                       Ext.getCmp('structureContent').enable();
                                                                   }
                                                                   if (projectsStr.indexOf('software') > -1) {
                                                                       Ext.getCmp('software_uploadFile').enable();
                                                                       Ext.getCmp('softwareContent').enable();
                                                                   }
                                                                   if (projectsStr.indexOf('pack') > -1) {
                                                                       Ext.getCmp('pack_uploadFile').enable();
                                                                       Ext.getCmp('packContent').enable();
                                                                   }
                                                                   if (projectsStr.indexOf('specification') > -1) {
                                                                       Ext.getCmp('specification_uploadFile').enable();
                                                                       Ext.getCmp('specificationContent').enable();
                                                                   }
                                                                   if (projectsStr.indexOf('scutcheon') > -1) {
                                                                       Ext.getCmp('scutcheon_uploadFile').enable();
                                                                       Ext.getCmp('scutcheonContent').enable();
                                                                   }
                                                                   if (projectsStr.indexOf('label') > -1) {
                                                                       Ext.getCmp('label_uploadFile').enable();
                                                                       Ext.getCmp('labelContent').enable();
                                                                   }
                                                                   if (projectsStr.indexOf('else') > -1) {
                                                                       Ext.getCmp('else_uploadFile').enable();
                                                                       Ext.getCmp('elseContent').enable();
                                                                   }
                                                                   autoSaveAtt('projectUpdateGroup', projectsStr);
                                                               }
                                                           }//~end of listeners
                                                       },
                                                       ],

                                                   }]
                                               },
                                               //电子部分详细更改内容
                                               {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [{//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 100, border: true},
                                                       items: [{
                                                           xtype: 'textarea',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           fieldLabel: '电子部分详细更改内容',
                                                           name: 'electronicContent',
                                                           id: 'electronicContent',
                                                           style: {
                                                               border: '1px solid black',
                                                           },
                                                           width: 600,
                                                           listeners: {
                                                               blur: function (e) {
                                                                   var value = Ext.getCmp('electronicContent').getValue();
                                                                   autoSaveAtt('electronicContent', value);
                                                               }
                                                           }
                                                       }, {
                                                           xtype: 'textarea',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           fieldLabel: '结构部分详细更改内容',
                                                           name: 'structureContent',
                                                           id: 'structureContent',
                                                           style: {
                                                               border: '1px solid black',
                                                           },
                                                           width: 600,
                                                           listeners: {
                                                               blur: function (e) {
                                                                   var value = Ext.getCmp('structureContent').getValue();
                                                                   //触发后台保存
                                                                   autoSaveAtt('structureContent', value);
                                                               }
                                                           }
                                                       }
                                                       ],

                                                   }]
                                               },
                                               {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [{//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                       items: [
                                                           {
                                                               xtype: 'panel',
                                                               disabledCls: 'none',
                                                               // disabled:disableNode(head_node),
                                                               border: false,
                                                               layout: 'hbox',
                                                               defaults: {margin: '5 20 0 0'},
                                                               items: [{
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '请选择要上传的电子部分相关文件',
                                                                   id: 'electronic_attatchment',
                                                                   name: 'electronic_attatchment',
                                                                   labelWidth: 100,
                                   width:255,
                                                               }, uploadFilefield("electronic_uploadFile", "电子部分文件", head_node, "electronic_uploadFileRecord"), {
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '附件链接',
                                                                   labelWidth: 100,
                                                                   id: 'electronic_uploadFileRecord',
                                                                   name: 'electronic_uploadFileRecord',
                                                                   width: 200
                                                               }]
                                                           }, {
                                                               xtype: 'panel',
                                                               disabledCls: 'none',
                                                               // disabled:disableNode(head_node),
                                                               border: false,
                                                               layout: 'hbox',
                                                               defaults: {margin: '5 30 0 0'},
                                                               items: [{
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '请选择要上传的结构部分相关文件',
                                                                   id: 'structure_attatchment',
                                                                   name: 'structure_attatchment',
                                                                   labelWidth: 100,
                                                                   width: 100
                                                               }, uploadFilefield("structure_uploadFile", "结构部分文件", head_node, "structure_uploadFileRecord"), {
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '附件链接',
                                                                   labelWidth: 100,
                                                                   id: 'structure_uploadFileRecord',
                                                                   name: 'structure_uploadFileRecord',
                                                                   width: 200
                                                               }]
                                                           }

                                                       ],

                                                   }]
                                               },
                                               {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [{//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                       items: [{
                                                           xtype: 'textarea',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           fieldLabel: '软件部分详细更改内容',
                                                           name: 'softwareContent',
                                                           id: 'softwareContent',
                                                           style: {
                                                               border: '1px solid black',
                                                           },
                                                           width: 600,
                                                           listeners: {
                                                               blur: function (e) {
                                                                   var value = Ext.getCmp('softwareContent').getValue();
                                                                   //触发后台保存
                                                                   autoSaveAtt('softwareContent', value);
                                                               }
                                                           }
                                                       }, {
                                                           xtype: 'textarea',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           fieldLabel: '包装部分详细更改内容',
                                                           name: 'packContent',
                                                           id: 'packContent',
                                                           style: {
                                                               border: '1px solid black',
                                                           },
                                                           width: 600,
                                                           listeners: {
                                                               blur: function (e) {
                                                                   var value = Ext.getCmp('packContent').getValue();
                                                                   //触发后台保存
                                                                   autoSaveAtt('packContent', value);
                                                               }
                                                           }
                                                       }
                                                       ],

                                                   }]
                                               },
                                               {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [{//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                       items: [
                                                           {
                                                               xtype: 'panel',
                                                               disabledCls: 'none',
                                                               // disabled:disableNode(head_node),
                                                               border: false,
                                                               layout: 'hbox',
                                                               defaults: {margin: '5 20 0 0'},
                                                               items: [{
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '请选择要上传的软件部分相关文件',
                                                                   id: 'software_attatchment',
                                                                   name: 'software_attatchment',
                                                                   labelWidth: 100,
                                   width:255,
                                                               }, uploadFilefield("software_uploadFile", "软件部分相关文件", head_node, "software_uploadFileRecord"), {
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '附件链接',
                                                                   labelWidth: 100,
                                                                   id: 'software_uploadFileRecord',
                                                                   name: 'software_uploadFileRecord',
                                                                   width: 200
                                                               }]
                                                           }, {
                                                               xtype: 'panel',
                                                               disabledCls: 'none',
                                                               // disabled:disableNode(head_node),
                                                               border: false,
                                                               layout: 'hbox',
                                                               defaults: {margin: '5 30 0 0'},
                                                               items: [{
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '请选择要上传的包装部分相关文件',
                                                                   id: 'pack_attatchment',
                                                                   name: 'pack_attatchment',
                                                                   labelWidth: 100,
                                                                   width: 100
                                                               }, uploadFilefield("pack_uploadFile", "包装部分文件", head_node, "pack_uploadFileRecord"), {
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '附件链接',
                                                                   labelWidth: 100,
                                                                   id: 'pack_uploadFileRecord',
                                                                   name: 'pack_uploadFileRecord',
                                                                   width: 200
                                                               }]
                                                           }

                                                       ],

                                                   }]
                                               },
                                               {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [{//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                       items: [{
                                                           xtype: 'textarea',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           fieldLabel: '产品说明书详细更改内容',
                                                           name: 'specificationContent',
                                                           id: 'specificationContent',
                                                           style: {
                                                               border: '1px solid black',
                                                           },
                                                           width: 600,
                                                           listeners: {
                                                               blur: function (e) {
                                                                   var value = Ext.getCmp('specificationContent').getValue();
                                                                   //触发后台保存
                                                                   autoSaveAtt('specificationContent', value);
                                                               }
                                                           }
                                                       }, {
                                                           xtype: 'textarea',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           fieldLabel: '标牌部分详细更改内容',
                                                           name: 'scutcheonContent',
                                                           id: 'scutcheonContent',
                                                           style: {
                                                               border: '1px solid black',
                                                           },
                                                           width: 600,
                                                           listeners: {
                                                               blur: function (e) {
                                                                   var value = Ext.getCmp('scutcheonContent').getValue();
                                                                   //触发后台保存
                                                                   autoSaveAtt('scutcheonContent', value);
                                                               }
                                                           }
                                                       }
                                                       ],

                                                   }]
                                               },
                                               {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [{//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                       items: [
                                                           {
                                                               xtype: 'panel',
                                                               disabledCls: 'none',
                                                               // disabled:disableNode(head_node),
                                                               border: false,
                                                               layout: 'hbox',
                                                               defaults: {margin: '5 20 0 0'},
                                                               items: [{
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '请选择要上传的产品说明书相关文件',
                                                                   id: 'specification_attatchment',
                                                                   name: 'specification_attatchment',
                                                                   labelWidth: 100,
                                   width:255,
                                                               }, uploadFilefield("specification_uploadFile", "产品说明书相关文件", head_node, "specification_uploadFileRecord"), {
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '附件链接',
                                                                   labelWidth: 100,
                                                                   id: 'specification_uploadFileRecord',
                                                                   name: 'specification_uploadFileRecord',
                                                                   width: 200
                                                               }]
                                                           }, {
                                                               xtype: 'panel',
                                                               disabledCls: 'none',
                                                               // disabled:disableNode(head_node),
                                                               border: false,
                                                               layout: 'hbox',
                                                               defaults: {margin: '5 30 0 0'},
                                                               items: [{
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '请选择要上传的标牌部分相关文件',
                                                                   id: 'scutcheon_attatchment',
                                                                   name: 'scutcheon_attatchment',
                                                                   labelWidth: 100,
                                                                   width: 100
                                                               }, uploadFilefield("scutcheon_uploadFile", "标牌部分文件", head_node, "scutcheon_uploadFileRecord"), {
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '附件链接',
                                                                   labelWidth: 100,
                                                                   id: 'scutcheon_uploadFileRecord',
                                                                   name: 'scutcheon_uploadFileRecord',
                                                                   width: 200
                                                               }]
                                                           }

                                                       ],

                                                   }]
                                               },
                                               {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [{//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                       items: [{
                                                           xtype: 'textarea',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           fieldLabel: '标贴部分详细更改内容',
                                                           name: 'labelContent',
                                                           id: 'labelContent',
                                                           style: {
                                                               border: '1px solid black',
                                                           },
                                                           width: 600,
                                                           listeners: {
                                                               blur: function (e) {
                                                                   var value = Ext.getCmp('labelContent').getValue();
                                                                   //触发后台保存
                                                                   autoSaveAtt('labelContent', value);
                                                               }
                                                           }
                                                       }, {
                                                           xtype: 'textarea',
                                                           disabled: !disableNode(head_node),
                                                           disabledCls: 'none',
                                                           fieldLabel: '其他部分详细更改内容',
                                                           name: 'elseContent',
                                                           id: 'elseContent',
                                                           style: {
                                                               border: '1px solid black',
                                                           },
                                                           width: 600,
                                                           listeners: {
                                                               blur: function (e) {
                                                                   var value = Ext.getCmp('elseContent').getValue();
                                                                   //触发后台保存
                                                                   autoSaveAtt('elseContent', value);
                                                               }
                                                           }
                                                       }
                                                       ],

                                                   },]
                                               },
                                               {
                                                   xtype: 'panel',
                                                   layout: 'hbox',
                                                   defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                                                   items: [{//第一行
                                                       xtype: 'panel',
                                                       layout: 'hbox',
                                                       defaults: {margin: '5 20 0 0', labelWidth: 100},
                                                       items: [
                                                           {
                                                               xtype: 'panel',
                                                               disabledCls: 'none',
                                                               // disabled:disableNode(head_node),
                                                               border: false,
                                                               layout: 'hbox',
                                                               defaults: {margin: '5 20 0 0'},
                                                               items: [{
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '请选择要上传的标贴部分相关文件',
                                                                   id: 'label_attatchment',
                                                                   name: 'label_attatchment',
                                                                   labelWidth: 100,
                                   width:255,
                                                               }, uploadFilefield("label_uploadFile", "标贴部分相关文件", head_node, "label_uploadFileRecord"), {
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '附件链接',
                                                                   labelWidth: 100,
                                                                   id: 'label_uploadFileRecord',
                                                                   name: 'label_uploadFileRecord',
                                                                   width: 200
                                                               }]
                                                           }, {
                                                               xtype: 'panel',
                                                               disabledCls: 'none',
                                                               // disabled:disableNode(head_node),
                                                               border: false,
                                                               layout: 'hbox',
                                                               defaults: {margin: '5 30 0 0'},
                                                               items: [{
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '请选择要上传的其他部分相关文件',
                                                                   id: 'else_attatchment',
                                                                   name: 'else_attatchment',
                                                                   labelWidth: 100,
                                                                   width: 100
                                                               }, uploadFilefield("else_uploadFile", "其他部分文件", head_node, "else_uploadFileRecord"), {
                                                                   xtype: 'displayfield',
                                                                   fieldLabel: '附件链接',
                                                                   labelWidth: 100,
                                                                   id: 'else_uploadFileRecord',
                                                                   name: 'else_uploadFileRecord',
                                                                   width: 200
                                                               }]
                                                           }

                                                       ],

                                                   }]
                                               },*/
                    ]
                },

                //6. 项目计划
                {
                    xtype: 'panel',
                    layout: 'vbox',
                    title: '6. 项目计划',
                    defaults: {margin: '5 20 10 0', labelWidth: 100, border: false,},
                    items: [
                        {
                            xtype: "panel",
                            layout: 'hbox',
                            defaults: {
                                margin: '5 20 0 0', labelWidth: 100, border: false,
                            },
                            items: [{//第一行
                                xtype: 'panel',
                                layout: 'hbox',
                                defaults: {margin: '5 20 0 0', labelWidth: 150},
                                items: [
                                    {
                                        xtype: 'checkboxgroup',
                                        fieldLabel: '<font color=red>*</font>项目任务',
                                        disabled: !disableNode(head_node),
                                        disabledCls: 'none',
                                        name: 'processGroup',
                                        id: 'processGroup',
                                        width: 800,
                                        items: [
                                            {
                                                inputValue: '设计实施',
                                                boxLabel: '设计实施',
                                                name: 'implement',
                                                disabledCls: 'none'
                                            },
                                            {
                                                inputValue: '测试验证',
                                                boxLabel: '测试验证',
                                                name: 'test',
                                                disabledCls: 'none'
                                            },
                                            {
                                                inputValue: 'BOM创建',
                                                boxLabel: 'BOM创建',
                                                name: 'BOM',
                                                disabledCls: 'none'
                                            },
                                            {
                                                inputValue: '试产验证',
                                                boxLabel: '试产验证',
                                                name: 'trial',
                                                disabledCls: 'none'
                                            },
                                            {
                                                inputValue: '认证',
                                                boxLabel: '认证',
                                                name: 'certification',
                                                disabledCls: 'none'
                                            },
                                            {
                                                inputValue: '发布',
                                                boxLabel: '发布',
                                                name: 'issue',
                                                disabledCls: 'none'
                                            }],
                                        listeners: {

                                            change: function (field, newValue, oldValue) {
                                                debugger;
                                                if (taskCompleted || !isLoaded) {
                                                    //阻止加载时执行后台保存
                                                    return;
                                                }
                                                //触发后台保存
                                                var checkedProcess = Ext.getCmp('processGroup').getChecked();
                                                var ProcessStr = '';//必须初始化，防止后面异常;
                                                Ext.Array.each(checkedProcess, function (item) {
                                                    if (ProcessStr) {
                                                        ProcessStr += ',' + item.name;
                                                    } else {
                                                        ProcessStr = item.name;
                                                    }

                                                });
                                                changeProcessGroup(ProcessStr, 'implement', 'startImplement', 'endImplement');
                                                changeProcessGroup(ProcessStr, 'test', 'startTest', 'endTest');
                                                changeProcessGroup(ProcessStr, 'BOM', 'startBOM', 'endBOM');
                                                changeProcessGroup(ProcessStr, 'trial', 'startTrial', 'endTrial');
                                                changeProcessGroup(ProcessStr, 'certification', 'startCertf', 'endCertf');
                                                changeProcessGroup(ProcessStr, 'issue', 'startIssue', 'endIssue');
                                                autoSaveAtt('processGroup', ProcessStr);
                                            }
                                        }//~end of listeners
                                    }
                                ],
                            }]
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [
                                {border: false, html: '<div style="margin-top: 2px;">设计实施：</div>'},
                                {

                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    // fieldLabel: '设计实施',
                                    name: 'startImplement',
                                    id: 'startImplement',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('startImplement').getValue();
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('startImplement', time);
                                        }
                                    }
                                },
                                {border: false, html: '<div style="margin-top: 4px;">至</div>'},
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    name: 'endImplement',
                                    id: 'endImplement',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('endImplement').getValue();
                                            var value1 = Ext.getCmp('startImplement').getValue();
                                            if (value1 === null) {
                                                alert("请先填写设计实施的开始时间");
                                                return;
                                            }
                                            if (value1 > value && value != null) {
                                                alert("设计实施的结束时间在开始时间之前，请重新填写");
                                                Ext.getCmp('endImplement').setValue("");
                                                return;
                                            }
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('endImplement', time);
                                        }
                                    }
                                },
                                {border: false, html: '<div style="margin-top: 2px;">测试验证：</div>'},
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    // fieldLabel: '测试验证',
                                    name: 'startTest',
                                    id: 'startTest',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('startTest').getValue();
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('startTest', time);
                                        }
                                    }
                                },
                                {border: false, html: '<div style="margin-top: 4px;">至</div>'},
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    name: 'endTest',
                                    id: 'endTest',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('endTest').getValue();
                                            var value1 = Ext.getCmp('startTest').getValue();
                                            if (value1 === null && value) {
                                                alert("请先填写测试验证的开始时间");
                                                return;
                                            }
                                            if (value1 > value && value != null) {
                                                alert("测试验证的结束时间在开始时间之前，请重新填写");
                                                Ext.getCmp('endTest').setValue("");
                                                return;
                                            }
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('endTest', time);
                                        }
                                    }
                                }
                            ]
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [
                                {border: false, html: '<div style="margin-top: 2px;">BOM创建：</div>'},
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    // fieldLabel: 'BOM创建',
                                    name: 'startBOM',
                                    id: 'startBOM',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('startBOM').getValue();
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('startBOM', time);
                                        }
                                    }
                                },
                                {border: false, html: '<div style="margin-top: 4px;">至</div>'},
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    name: 'endBOM',
                                    id: 'endBOM',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('endBOM').getValue();
                                            var value1 = Ext.getCmp('startBOM').getValue();
                                            if (value1 === null) {
                                                alert("请先填写BOM创建的开始时间");
                                                return;
                                            }
                                            if (value1 > value && value != null) {
                                                alert("BOM创建的结束时间在开始时间之前，请重新填写");
                                                Ext.getCmp('endBOM').setValue("");
                                                return;
                                            }
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('endBOM', time);
                                        }
                                    }
                                },
                                {border: false, html: '<div style="margin-top: 2px;">试产验证：</div>'},
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    // fieldLabel: '试产验证',
                                    name: 'startTrial',
                                    id: 'startTrial',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('startTrial').getValue();
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('startTrial', time);
                                        }
                                    }
                                },
                                {border: false, html: '<div style="margin-top: 4px;">至</div>'},
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    name: 'endTrial',
                                    id: 'endTrial',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('endTrial').getValue();
                                            var value1 = Ext.getCmp('startTrial').getValue();
                                            if (value1 === null) {
                                                alert("请先填写试产验证的开始时间");
                                                return;
                                            }
                                            if (value1 > value && value != null) {
                                                alert("试产验证的结束时间在开始时间之前，请重新填写");
                                                Ext.getCmp('endTrial').setValue("");
                                                return;
                                            }
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('endTrial', time);
                                        }
                                    }
                                },]
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 100},
                            items: [
                                {border: false, html: '<div style="margin-top: 2px;">认证：</div>'},
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    margin: '0 0 0 30',
                                    // fieldLabel: '认证',
                                    name: 'startCertf',
                                    id: 'startCertf',
                                    format: 'Y-m-d',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('startCertf').getValue();
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('startCertf', time);
                                        }
                                    }
                                },
                                {
                                    border: false,
                                    html: '<div style="margin-top: 4px;">至</div>',
                                    margin: '0 0 0 20',
                                },
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    name: 'endCertf',
                                    id: 'endCertf',
                                    format: 'Y-m-d',
                                    margin: '0 0 0 20',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('endCertf').getValue();
                                            var value1 = Ext.getCmp('startCertf').getValue();
                                            if (value1 === null) {
                                                alert("请先填写认证的开始时间");
                                                return;
                                            }
                                            if (value1 > value && value != null) {
                                                alert("认证的结束时间在开始时间之前，请重新填写");
                                                Ext.getCmp('endCertf').setValue("");
                                                return;
                                            }
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('endCertf', time);
                                        }
                                    }
                                },
                                {
                                    border: false,
                                    html: '<div style="margin-top: 2px;">发布：</div>',
                                    margin: '0 0 0 20',
                                },
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    // fieldLabel: '发布',
                                    name: 'startIssue',
                                    id: 'startIssue',
                                    format: 'Y-m-d',
                                    margin: '0 0 0 45',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('startIssue').getValue();
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('startIssue', time);
                                        }
                                    }
                                },
                                {
                                    border: false,
                                    html: '<div style="margin-top: 4px;">至</div>',
                                    margin: '0 0 0 20',
                                },
                                {
                                    xtype: disableNode(head_node) ? 'datefield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    disabledCls: 'none',
                                    name: 'endIssue',
                                    id: 'endIssue',
                                    format: 'Y-m-d',
                                    margin: '0 0 0 20',
                                    //minValue: new Date(),
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('endIssue').getValue();
                                            var value1 = Ext.getCmp('startIssue').getValue();
                                            if (value1 === null) {
                                                alert("请先填写发布的开始时间");
                                                return;
                                            }
                                            if (value1 > value && value != null) {
                                                alert("发布的结束时间在开始时间之前，请重新填写");
                                                Ext.getCmp('endIssue').setValue("");
                                                return;
                                            }
                                            //触发后台保存
                                            var time = Ext.Date.format(value, "Y-m-d")
                                            autoSaveAtt('endIssue', time);

                                        }
                                    }
                                }
                            ]
                            // }, assignmentGrid, {
                        },
                    ]
                },
                //7. 扩展组成员名单及工作量评估
                {
                    xtype: 'panel',
                    layout: 'vbox',
                    title: '7. 扩展组成员名单及工作量评估',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [
                        //原来的布局
                        /*{
                            layout: 'hbox',
                            defaults: {border: false, margin: '5 5 5 5'},
                            items: [
                                //注释原来的布局
                                //第一列
                                {
                                    defaults: {border: false,},
                                    items: [
                                        {
                                            html: '&nbsp;'
                                        },
                                        {
                                            html: '扩展组成员姓名',
                                            margin: '15 5 5 5'
                                        },
                                        {
                                            html: '<font color=red>*</font>工作评估量（人天）',
                                            margin: '15 5 5 5'
                                        },
                                    ]
                                },
                                //第二列 需求分析人员	测试工程师(工程)
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '需求分析人员'}
                                        , disableNode(head_node) ? teamMemberCombo1 : teamMemberComboDisplay1
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'demandAnalysisQuantity',
                                            id: 'demandAnalysisQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('demandAnalysisQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('demandAnalysisQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('demandAnalysisQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('demandAnalysisQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第三列 工业设计工程师	工艺工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '硬件工程师'
                                        }, disableNode(head_node) ? teamMemberCombo2 : teamMemberComboDisplay2,
                                        {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'hardwareQuantity',
                                            id: 'hardwareQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('hardwareQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        value = '';
                                                        Ext.getCmp('hardwareQuantity').setValue("");
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('hardwareQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('hardwareQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第四列 硬件工程师	NPI工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '软件工程师'
                                        }, disableNode(head_node) ? teamMemberCombo3 : teamMemberComboDisplay3, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'softwareQuantity',
                                            id: 'softwareQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('softwareQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('softwareQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('softwareQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    console.log(value);
                                                    autoSaveAtt('softwareQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第五列 软件工程师 电源工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '结构工程师'}
                                        , disableNode(head_node) ? teamMemberCombo4 : teamMemberComboDisplay4
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'structureQuantity',
                                            id: 'structureQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('structureQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('structureQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('structureQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('structureQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第六列   结构工程师   TQC
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '包装工程师'}
                                        , disableNode(head_node) ? teamMemberCombo9 : teamMemberComboDisplay9
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'packagingQuantity',
                                            id: 'packagingQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('packagingQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('packagingQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('packagingQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('packagingQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第六列   包装工程师   电子工程师（工程部）
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: 'ID工程师'
                                        }, disableNode(head_node) ? teamMemberCombo5 : teamMemberComboDisplay5, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'idEngineerQuantity',
                                            id: 'idEngineerQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('idEngineerQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('idEngineerQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('idEngineerQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('idEngineerQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第七列   测试工程师(检测)   其他
                                //测试工程师(检测)
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '测试工程师(检测)'
                                        }, disableNode(head_node) ? teamMemberCombo6 : teamMemberComboDisplay6, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'testEngineerQuantity',
                                            id: 'testEngineerQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('testEngineerQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('testEngineerQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('testEngineerQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('testEngineerQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //工艺工程师 第7列
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '工艺工程师'
                                        }, disableNode(head_node) ? teamMemberCombo7 : teamMemberComboDisplay7, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'craftQuantity',
                                            id: 'craftQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('craftQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        var value = Ext.getCmp('craftQuantity').setValue("");
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('craftQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('craftQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //NPI工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: 'NPI工程师'}
                                        , disableNode(head_node) ? teamMemberCombo10 : teamMemberComboDisplay10, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'npiQuantity',
                                            id: 'npiQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('npiQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('npiQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('npiQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('npiQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //电子工程师（工程部）
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '电子工程师（工程部）'}
                                        , disableNode(head_node) ? teamMemberCombo11 : teamMemberComboDisplay11, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'electronicsQuantity',
                                            id: 'electronicsQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('electronicsQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('electronicsQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('electronicsQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('electronicsQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '其他人员'
                                        }, disableNode(head_node) ? teamMemberCombo8 : teamMemberComboDisplay8, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'otherStaffsQuantity',
                                            id: 'otherStaffsQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('otherStaffsQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('otherStaffsQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('otherStaffsQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {
                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('otherStaffsQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },

                                //工业设计工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '工业设计工程师'}
                                        , disableNode(head_node) ? teamMemberCombo12 : teamMemberComboDisplay12, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'industrialDesignQuantity',
                                            id: 'industrialDesignQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('industrialDesignQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('industrialDesignQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('industrialDesignQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('industrialDesignQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //测试工程师(工程)
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '测试工程师(工程)'}
                                        , disableNode(head_node) ? teamMemberCombo13 : teamMemberComboDisplay13, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'test_engineeringQuantity',
                                            id: 'test_engineeringQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('test_engineeringQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('test_engineeringQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('test_engineeringQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('test_engineeringQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //电源工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '电源工程师'}
                                        , disableNode(head_node) ? teamMemberCombo14 : teamMemberComboDisplay14, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'powerQuantity',
                                            id: 'powerQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('powerQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('powerQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('powerQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('powerQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //TQC
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: 'TQC'}
                                        , disableNode(head_node) ? teamMemberCombo15 : teamMemberComboDisplay15, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'tqcQuantity',
                                            id: 'tqcQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('tqcQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('tqcQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('tqcQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('tqcQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },


                            ]
                        },*/
                        //第一大行
                        {
                            layout: 'hbox',
                            defaults: {border: false, margin: '5 5 5 5'},
                            items: [
                                //第一列 文本
                                {
                                    defaults: {border: false,},
                                    items: [
                                        {html: '&nbsp;'},
                                        disableNode(head_node) ? {html: '查询添加用户:', margin: '15 5 5 5'} : null,
                                        {html: '扩展组成员姓名:', margin: '15 5 5 5'},
                                        {html: '<font color=red>*</font>工作评估量（人天）:', margin: '15 5 5 5'},
                                    ]
                                },
                                //第二列 需求分析人员
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '需求分析人员'}
                                        , disableNode(head_node) ? teamMemberCombo1 : null
                                        , disableNode(head_node) ? teamMember1 : teamMemberComboDisplay1
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'demandAnalysisQuantity',
                                            id: 'demandAnalysisQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('demandAnalysisQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('demandAnalysisQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('demandAnalysisQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('demandAnalysisQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第三列 工业设计工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '工业设计工程师'}
                                        , disableNode(head_node) ? teamMemberCombo12 : null
                                        , disableNode(head_node) ? teamMember12 : teamMemberComboDisplay12
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'industrialDesignQuantity',
                                            id: 'industrialDesignQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('industrialDesignQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('industrialDesignQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('industrialDesignQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('industrialDesignQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第四列 硬件工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '硬件工程师'
                                        }, disableNode(head_node) ? teamMemberCombo2 : null
                                        , disableNode(head_node) ? teamMember2 : teamMemberComboDisplay2
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'hardwareQuantity',
                                            id: 'hardwareQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('hardwareQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        value = '';
                                                        Ext.getCmp('hardwareQuantity').setValue("");
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('hardwareQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('hardwareQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第五列 软件工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '软件工程师'
                                        }
                                        , disableNode(head_node) ? teamMemberCombo3 : null
                                        , disableNode(head_node) ? teamMember3 : teamMemberComboDisplay3
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'softwareQuantity',
                                            id: 'softwareQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('softwareQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('softwareQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('softwareQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    console.log(value);
                                                    autoSaveAtt('softwareQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                            ]
                        },
                        //第二大行
                        {
                            layout: 'hbox',
                            defaults: {border: false, margin: '5 5 5 5'},
                            items: [
                                //第一列 文本
                                {
                                    defaults: {border: false,},
                                    items: [
                                        {html: '&nbsp;'},
                                        disableNode(head_node) ? {html: '查询添加用户:', margin: '15 5 5 5'} : null,
                                        {html: '扩展组成员姓名:', margin: '15 5 5 5'},
                                        {html: '<font color=red>*</font>工作评估量（人天）:', margin: '15 5 5 5'},
                                    ]
                                },
                                //第六列 结构工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '结构工程师'}
                                        , disableNode(head_node) ? teamMemberCombo4 : null
                                        , disableNode(head_node) ? teamMember4 : teamMemberComboDisplay4
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'structureQuantity',
                                            id: 'structureQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('structureQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('structureQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('structureQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('structureQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第七列 包装工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '包装工程师'}
                                        , disableNode(head_node) ? teamMemberCombo9 : null
                                        , disableNode(head_node) ? teamMember9 : teamMemberComboDisplay9
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'packagingQuantity',
                                            id: 'packagingQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('packagingQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('packagingQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('packagingQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('packagingQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第九列 测试工程师(检测)
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '测试工程师(检测)'
                                        }, disableNode(head_node) ? teamMemberCombo6 : null
                                        , disableNode(head_node) ? teamMember6 : teamMemberComboDisplay6
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'testEngineer_testQuantity',
                                            id: 'testEngineer_testQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('testEngineer_testQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('testEngineer_testQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('testEngineer_testQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('testEngineer_testQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第二列 测试工程师(工程)
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '测试工程师(工程)'}
                                        , disableNode(head_node) ? teamMemberCombo13 : null
                                        , disableNode(head_node) ? teamMember13 : teamMemberComboDisplay13
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'testEngineer_engineeringQuantity',
                                            id: 'testEngineer_engineeringQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('testEngineer_engineeringQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('testEngineer_engineeringQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('testEngineer_engineeringQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('testEngineer_engineeringQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                            ]
                        },
                        //第三大行
                        {
                            layout: 'hbox',
                            defaults: {border: false, margin: '5 5 5 5'},
                            items: [
                                //第一列 文本
                                {
                                    defaults: {border: false,},
                                    items: [
                                        {html: '&nbsp;'},
                                        disableNode(head_node) ? {html: '查询添加用户:', margin: '15 5 5 5'} : null,
                                        {html: '扩展组成员姓名:', margin: '15 5 5 5'},
                                        {
                                            html: '<font color=red>*</font>工作评估量（人天）:',
                                            margin: '15 5 5 5'
                                        },
                                    ]
                                },
                                //第三列 工艺工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '工艺工程师'
                                        }, disableNode(head_node) ? teamMemberCombo7 : null
                                        , disableNode(head_node) ? teamMember7 : teamMemberComboDisplay7
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'craftQuantity',
                                            id: 'craftQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('craftQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        var value = Ext.getCmp('craftQuantity').setValue("");
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('craftQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('craftQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第四列 NPI工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: 'NPI工程师'}
                                        , disableNode(head_node) ? teamMemberCombo10 : null
                                        , disableNode(head_node) ? teamMember10 : teamMemberComboDisplay10
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'npiQuantity',
                                            id: 'npiQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('npiQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('npiQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('npiQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('npiQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第五列 电源工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '电源工程师'}
                                        , disableNode(head_node) ? teamMemberCombo14 : null
                                        , disableNode(head_node) ? teamMember14 : teamMemberComboDisplay14
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'powerQuantity',
                                            id: 'powerQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('powerQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('powerQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('powerQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('powerQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第六列 电子工程师（工程部）弃用
                                /*{
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '电子工程师（工程部）'}
                                        , disableNode(head_node) ? teamMemberCombo11 : teamMemberComboDisplay11, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'electronicsQuantity',
                                            id: 'electronicsQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('electronicsQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('electronicsQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('electronicsQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('electronicsQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },*/
                                //第七列 TQC
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: 'TQC'}
                                        , disableNode(head_node) ? teamMemberCombo15 : null
                                        , disableNode(head_node) ? teamMember15 : teamMemberComboDisplay15
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'tqcQuantity',
                                            id: 'tqcQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('tqcQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('tqcQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('tqcQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('tqcQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                            ]
                        },
                        //第四大行
                        {
                            layout: 'hbox',
                            defaults: {border: false, margin: '5 5 5 5'},
                            items: [
                                //第一列 文本
                                {
                                    defaults: {border: false,},
                                    items: [
                                        {html: '&nbsp;'},
                                        disableNode(head_node) ? {html: '查询添加用户:', margin: '15 5 5 5'} : null,
                                        {html: '扩展组成员姓名:', margin: '15 5 5 5'},
                                        {
                                            html: '<font color=red>*</font>工作评估量（人天）:',
                                            margin: '15 5 5 5'
                                        },
                                    ]
                                },
                                //第八列 其他
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '其他人员'
                                        }, disableNode(head_node) ? teamMemberCombo8 : null
                                        , disableNode(head_node) ? teamMember8 : teamMemberComboDisplay8
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                            readOnly: !disableNode(head_node),
                                            width: 255,
                                            name: 'otherStaffsQuantity',
                                            id: 'otherStaffsQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    if (!disableNode(head_node)) return;
                                                    var value = Ext.getCmp('otherStaffsQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('otherStaffsQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('otherStaffsQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {
                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('otherStaffsQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //注释原来的布局
                                /*//第一列
                                {
                                    defaults: {border: false,},
                                    items: [
                                        {
                                            html: '&nbsp;'
                                        },
                                        {
                                            html: '扩展组成员姓名',
                                            margin: '15 5 5 5'
                                        },
                                        {
                                            html: '<font color=red>*</font>工作评估量（人天）',
                                            margin: '15 5 5 5'
                                        },
                                    ]
                                },
                                //第二列 需求分析人员	测试工程师(工程)
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '需求分析人员'}
                                        , disableNode(head_node) ? teamMemberCombo1 : teamMemberComboDisplay1
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'demandAnalysisQuantity',
                                            id: 'demandAnalysisQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('demandAnalysisQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('demandAnalysisQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('demandAnalysisQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('demandAnalysisQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第三列 工业设计工程师	工艺工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '硬件工程师'
                                        }, disableNode(head_node) ? teamMemberCombo2 : teamMemberComboDisplay2,
                                        {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'hardwareQuantity',
                                            id: 'hardwareQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('hardwareQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        value = '';
                                                        Ext.getCmp('hardwareQuantity').setValue("");
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('hardwareQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('hardwareQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第四列 硬件工程师	NPI工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '软件工程师'
                                        }, disableNode(head_node) ? teamMemberCombo3 : teamMemberComboDisplay3, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'softwareQuantity',
                                            id: 'softwareQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('softwareQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('softwareQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('softwareQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    console.log(value);
                                                    autoSaveAtt('softwareQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第五列 软件工程师 电源工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '结构工程师'}
                                        , disableNode(head_node) ? teamMemberCombo4 : teamMemberComboDisplay4
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'structureQuantity',
                                            id: 'structureQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('structureQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('structureQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('structureQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('structureQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第六列   结构工程师   TQC
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '包装工程师'}
                                        , disableNode(head_node) ? teamMemberCombo9 : teamMemberComboDisplay9
                                        , {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'packagingQuantity',
                                            id: 'packagingQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('packagingQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('packagingQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('packagingQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('packagingQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第六列   包装工程师   电子工程师（工程部）
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: 'ID工程师'
                                        }, disableNode(head_node) ? teamMemberCombo5 : teamMemberComboDisplay5, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'idEngineerQuantity',
                                            id: 'idEngineerQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('idEngineerQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('idEngineerQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('idEngineerQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('idEngineerQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //第七列   测试工程师(检测)   其他
                                //测试工程师(检测)
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '测试工程师(检测)'
                                        }, disableNode(head_node) ? teamMemberCombo6 : teamMemberComboDisplay6, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'testEngineerQuantity',
                                            id: 'testEngineerQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('testEngineerQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('testEngineerQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('testEngineerQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('testEngineerQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //工艺工程师 第7列
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '工艺工程师'
                                        }, disableNode(head_node) ? teamMemberCombo7 : teamMemberComboDisplay7, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'craftQuantity',
                                            id: 'craftQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('craftQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        var value = Ext.getCmp('craftQuantity').setValue("");
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('craftQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('craftQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //NPI工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: 'NPI工程师'}
                                        , disableNode(head_node) ? teamMemberCombo10 : teamMemberComboDisplay10, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'npiQuantity',
                                            id: 'npiQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('npiQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('npiQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('npiQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('npiQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //电子工程师（工程部）
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '电子工程师（工程部）'}
                                        , disableNode(head_node) ? teamMemberCombo11 : teamMemberComboDisplay11, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'electronicsQuantity',
                                            id: 'electronicsQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('electronicsQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('electronicsQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('electronicsQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('electronicsQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {
                                            html: '其他人员'
                                        }, disableNode(head_node) ? teamMemberCombo8 : teamMemberComboDisplay8, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'otherStaffsQuantity',
                                            id: 'otherStaffsQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('otherStaffsQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('otherStaffsQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('otherStaffsQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {
                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('otherStaffsQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },

                                //工业设计工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '工业设计工程师'}
                                        , disableNode(head_node) ? teamMemberCombo12 : teamMemberComboDisplay12, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'industrialDesignQuantity',
                                            id: 'industrialDesignQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('industrialDesignQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('industrialDesignQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('industrialDesignQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('industrialDesignQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //测试工程师(工程)
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '测试工程师(工程)'}
                                        , disableNode(head_node) ? teamMemberCombo13 : teamMemberComboDisplay13, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'test_engineeringQuantity',
                                            id: 'test_engineeringQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('test_engineeringQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('test_engineeringQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('test_engineeringQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('test_engineeringQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //电源工程师
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: '电源工程师'}
                                        , disableNode(head_node) ? teamMemberCombo14 : teamMemberComboDisplay14, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'powerQuantity',
                                            id: 'powerQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('powerQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('powerQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('powerQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('powerQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },
                                //TQC
                                {
                                    defaults: {border: false, margin: '5 5 5 5', width: 100},
                                    items: [
                                        {html: 'TQC'}
                                        , disableNode(head_node) ? teamMemberCombo15 : teamMemberComboDisplay15, {
                                            xtype: disableNode(head_node) ? 'numberfield' : 'displayfield',
                                            name: 'tqcQuantity',
                                            id: 'tqcQuantity',
                                            minValue: 0,
                                            listeners: {
                                                blur: function (e) {
                                                    var value = Ext.getCmp('tqcQuantity').getValue();
                                                    //触发后台保存
                                                    if (value < 0) {
                                                        Ext.getCmp('tqcQuantity').setValue("");
                                                        value = '';
                                                    }
                                                    var workItem = getWorkTime()
                                                    if (workItem > 30) {
                                                        Ext.getCmp('tqcQuantity').setValue("");
                                                        alert("总工时大于30,请重新填写");
                                                        value = '';
                                                    } else {

                                                        setSumManDay(workItem);
                                                    }
                                                    autoSaveAtt('tqcQuantity', value);
                                                }
                                            }
                                        }
                                    ]
                                },*/
                            ]
                        },


                        //汇总天
                        {
                            //第一行
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 150},
                            items: [{
                                xtype: 'textfield',
                                readOnly: true,
                                fieldLabel: '<font color=red>*</font>总工作评估量（人天）',
                                name: ' sumManDay',
                                id: 'sumManDay',
                                value: 0,
                                width: 250,
                                listeners: {}
                            },]
                        },
                        //说明
                        {border: false, html: '<span>说明：微小项目，开发测试总工作量不得超过30人天，超过请按维护性项目流程进行立项及开发。\n</span>'},
                    ]
                },
                //8. 投入产出收益评估
                {
                    xtype: 'panel',
                    layout: 'vbox',
                    title: '8. 投入产出收益评估',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [
                        {border: false, html: '<span style="color: red">说明：若显示为0，则代表本项目未产生收益或未更改成本。\n</span>'},
                        //量产点产品目标成本（元）  物料成本（元）   制造成本（元）
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 180},
                            items: [
                                //量产点产品目标成本（元）
                                {
                                    xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    fieldLabel: '<span style="color:red" >*</span>量产点产品目标成本（元）',
                                    name: ' massProductionCost',
                                    id: 'massProductionCost',
                                    minValue: '0',
                                    maxValue: '10000000000',
                                    width: 255,
                                    listeners: {
                                        blur: function (e) {
                                            let value = Ext.getCmp('massProductionCost').getValue();
                                            // 尝试将 value 转换为数字
                                            var numValue = Number(value);
                                            // 检查转换是否成功，并且数值是否大于 0
                                            if (!isNaN(numValue) && numValue >= 0) {
                                                // 触发后台保存
                                                autoSaveAtt('massProductionCost', numValue);
                                            } else {
                                                if (isNaN(numValue)) {
                                                    alert('输入的值无法转换为数字！');
                                                } else {
                                                    alert('输入的值不得小于0！');
                                                }
                                            }
                                        }
                                    }
                                },
                                //物料成本（元）
                                {
                                    xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    fieldLabel: '<span style="color:red" >*</span>物料成本（元）',
                                    name: ' materialCost',
                                    id: 'materialCost',
                                    minValue: '0',
                                    maxValue: '10000000000',
                                    width: 220,
                                    labelWidth: 100,
                                    margin: '5 20 0 80',
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('materialCost').getValue();
                                            // 尝试将 value 转换为数字
                                            var numValue = Number(value);
                                            // 检查转换是否成功，并且数值是否大于 0
                                            if (!isNaN(numValue) && numValue >= 0) {
                                                // 触发后台保存
                                                autoSaveAtt('materialCost', numValue);
                                            } else {
                                                if (isNaN(numValue)) {
                                                    alert('输入的值无法转换为数字！');
                                                } else {
                                                    alert('输入的值不得小于0！');
                                                }
                                            }
                                        }
                                    }
                                },
                                //制造成本（元）
                                {
                                    xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    fieldLabel: '<span style="color:red" >*</span>制造成本（元）',
                                    name: 'manufacturingCost',
                                    id: 'manufacturingCost',
                                    minValue: '0',
                                    maxValue: '10000000000',
                                    width: 220,
                                    labelWidth: 100,
                                    margin: '5 20 0 20',
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('manufacturingCost').getValue();
                                            // 尝试将 value 转换为数字
                                            var numValue = Number(value);
                                            // 检查转换是否成功，并且数值是否大于 0
                                            if (!isNaN(numValue) && numValue >= 0) {
                                                // 触发后台保存
                                                autoSaveAtt('manufacturingCost', numValue);
                                            } else {
                                                if (isNaN(numValue)) {
                                                    alert('输入的值无法转换为数字！');
                                                } else {
                                                    alert('输入的值不得小于0！');
                                                }
                                            }
                                        }
                                    }
                                },
                            ],
                        },
                        //研发费用（万元）
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 180},
                            items: [
                                //研发费用（万元）
                                {
                                    xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    fieldLabel: '<font color=red>*</font>研发费用（万元）',
                                    name: ' inputCost',
                                    id: 'inputCost',
                                    minValue: '0',
                                    maxValue: '10000000000',
                                    width: 255,
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('inputCost').getValue();
                                            // 尝试将 value 转换为数字
                                            var numValue = Number(value);
                                            // 检查转换是否成功，并且数值是否大于 0
                                            if (!isNaN(numValue) && numValue >= 0) {
                                                // 触发后台保存
                                                autoSaveAtt('inputCost', numValue);
                                            } else {
                                                if (isNaN(numValue)) {
                                                    alert('输入的值无法转换为数字！');
                                                } else {
                                                    alert('输入的值不得小于0！');
                                                }
                                            }
                                        }
                                    }
                                },
                            ],
                        },
                        //预估未来产出收益（万元）  预估年限（年）
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            defaults: {margin: '5 20 0 0', labelWidth: 180},
                            items: [
                                //预估未来产出收益（万元）
                                {
                                    xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    fieldLabel: '<font color=red>*</font>预估未来产出收益（万元）',
                                    name: 'outputIncome',
                                    id: 'outputIncome',
                                    // minValue: '0',
                                    maxValue: '10000000000',
                                    width: 255,
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('outputIncome').getValue();
                                            // 尝试将 value 转换为数字
                                            var numValue = Number(value);
                                            // 检查转换是否成功，并且数值是否大于 0
                                            if (!isNaN(numValue) && numValue >= 0) {
                                                // 触发后台保存
                                                autoSaveAtt('outputIncome', numValue);
                                            } else {
                                                if (isNaN(numValue)) {
                                                    alert('输入的值无法转换为数字！');
                                                } else {
                                                    // alert('输入的值不得小于0！');
                                                    autoSaveAtt('outputIncome', numValue);
                                                }
                                            }
                                        }
                                    }
                                },
                                //预估年限（年）
                                {
                                    xtype: disableNode(head_node) ? 'numberfield' : 'textfield',
                                    readOnly: !disableNode(head_node),
                                    fieldLabel: '<span style="color:red" >*</span>预估年限（年）',
                                    name: ' estimatedLifespan',
                                    id: 'estimatedLifespan',
                                    minValue: '0',
                                    maxValue: '10000000000',
                                    width: 220,
                                    labelWidth: 100,
                                    margin: '5 20 0 80',
                                    listeners: {
                                        blur: function (e) {
                                            if (!disableNode(head_node)) return;
                                            var value = Ext.getCmp('estimatedLifespan').getValue();
                                            // 尝试将 value 转换为数字
                                            var numValue = Number(value);
                                            // 检查转换是否成功，并且数值是否大于 0
                                            if (!isNaN(numValue) && numValue >= 0) {
                                                // 触发后台保存
                                                autoSaveAtt('estimatedLifespan', numValue);
                                            } else {
                                                if (isNaN(numValue)) {
                                                    alert('输入的值无法转换为数字！');
                                                } else {
                                                    alert('输入的值不得小于0！');
                                                }
                                            }
                                        }
                                    }
                                },
                            ],
                        }
                    ]
                },

            ]
        }];

        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('tinyAssignmentStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/tinyAssignment/getFormInfo?branchId=' + branchId,
                success: function (response, opts) {

                    var obj = Ext.decode(response.responseText);
                    if (obj.message === 'success') {

                        //初始化表单
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj.data);

                        //初始化规划情况联动
                        changeValue_planningSituation();

                        var raGroup = Ext.getCmp('demandGroup');
                        var demandsStr = obj.data['demandGroup'];

                        //无认证的逻辑（old）
                        /*if (demandsStr == '无认证') {
                            raGroup.items.get(1).disable();
                            raGroup.items.get(2).disable();
                            raGroup.items.get(3).disable();
                            raGroup.items.get(0).disable();
                            raGroup.items.get(4).enable();
                            Ext.getCmp('elseDemand').disable();
                        } else if (!demandsStr) {
                            raGroup.items.get(1).enable();
                            raGroup.items.get(2).enable();
                            raGroup.items.get(3).enable();
                            raGroup.items.get(0).enable();
                            raGroup.items.get(4).enable();
                            Ext.getCmp('elseDemand').enable();
                        } else {
                            raGroup.items.get(4).disable();
                        }*/

                        /*                        if (obj.data['elseDemand']) {
                                                    raGroup.items.get(4).disable();
                                                } else {
                                                    raGroup.items.get(4).enable();
                                                }*/
                        //初始化扩展组成员名单及工作量评估
                        setExpansionTeamsCombobox(obj.data,
                            'demandAnalysis',
                            'demandAnalysisQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'hardware',
                            'hardwareQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'softwareEngineer',
                            'softwareQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'structureEngineer',
                            'structureQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'idEngineer',
                            'idEngineerQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'craft',
                            'craftQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'otherStaffs',
                            'otherStaffsQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'industrialDesignEngineer',
                            'industrialDesignQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'powerEngineer',
                            'powerQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'testEngineer_engineering',
                            'testEngineer_engineeringQuantity');
                        setExpansionTeamsCombobox(obj.data,
                            'tqcEngineer',
                            'tqcQuantity');

                        initialValueByMultiSelectCombobox(obj.data, 'demandGroup');
                        var isSource = obj.data['isSource'];
                        if (isSource === '内部需求') {
                            if (!disableNode(head_node)) {
                                //return;
                            } else {
                                //内部需求
                                Ext.getCmp('department').disable();
                                Ext.getCmp('dDemander').enable();
                                //外部需求
                                Ext.getCmp('client').disable();
                                Ext.getCmp('cDemander').disable();
                                Ext.getCmp('client').setValue('');
                                Ext.getCmp('cDemander').setValue('');
                            }
                        } else if (isSource === '外部需求') {
                            //外部需求
                            Ext.getCmp('client').enable();
                            Ext.getCmp('cDemander').enable();
                            //内部需求
                            Ext.getCmp('department').disable();
                            Ext.getCmp('dDemander').setDisabled(true);
                            Ext.getCmp('department').setValue('');
                            Ext.getCmp('dDemander').setValue('');
                        }

                        if (!disableNode(head_node)) {
                            //内部需求
                            Ext.getCmp('department').disable();
                            Ext.getCmp('dDemander').disable();
                            //外部需求
                            Ext.getCmp('client').disable();
                            Ext.getCmp('cDemander').disable();
                        }
                        //region 旧的5. 在参考产品型号初始化
                        /*var projectsStr = obj.data['projectUpdateGroup'];
                        Ext.getCmp('electronicContent').disable();
                        Ext.getCmp('structureContent').disable();
                        Ext.getCmp('softwareContent').disable();
                        Ext.getCmp('packContent').disable();
                        Ext.getCmp('specificationContent').disable();
                        Ext.getCmp('scutcheonContent').disable();
                        Ext.getCmp('labelContent').disable();
                        Ext.getCmp('elseContent').disable();
                        Ext.getCmp('electronic_uploadFile').disable();
                        Ext.getCmp('structure_uploadFile').disable();
                        Ext.getCmp('software_uploadFile').disable();
                        Ext.getCmp('pack_uploadFile').disable();
                        Ext.getCmp('specification_uploadFile').disable();
                        Ext.getCmp('scutcheon_uploadFile').disable();
                        Ext.getCmp('label_uploadFile').disable();
                        Ext.getCmp('else_uploadFile').disable();
                        if (projectsStr && disableNode(head_node)) {
                            if (projectsStr.indexOf('electronic') > -1) {
                                Ext.getCmp('electronicContent').enable();
                                Ext.getCmp('electronic_uploadFile').enable();
                            }
                            if (projectsStr.indexOf('structure') > -1) {
                                Ext.getCmp('structure_uploadFile').enable();
                                Ext.getCmp('structureContent').enable();
                            }
                            if (projectsStr.indexOf('software') > -1) {
                                Ext.getCmp('software_uploadFile').enable();
                                Ext.getCmp('softwareContent').enable();
                            }
                            if (projectsStr.indexOf('pack') > -1) {
                                Ext.getCmp('pack_uploadFile').enable();
                                Ext.getCmp('packContent').enable();
                            }
                            if (projectsStr.indexOf('specification') > -1) {
                                Ext.getCmp('specification_uploadFile').enable();
                                Ext.getCmp('specificationContent').enable();
                            }
                            if (projectsStr.indexOf('scutcheon') > -1) {
                                Ext.getCmp('scutcheon_uploadFile').enable();
                                Ext.getCmp('scutcheonContent').enable();
                            }
                            if (projectsStr.indexOf('label') > -1) {
                                Ext.getCmp('label_uploadFile').enable();
                                Ext.getCmp('labelContent').enable();
                            }
                            if (projectsStr.indexOf('else') > -1) {
                                Ext.getCmp('else_uploadFile').enable();
                                Ext.getCmp('elseContent').enable();
                            }
                        }
                        var projectUpdateGroup = Ext.getCmp('projectUpdateGroup');
                        setCheckboxGroupValues(projectUpdateGroup, obj.data['projectUpdateGroup']);*/

                        debugger;
                        var ProcessStr = obj.data['processGroup'];
                        Ext.getCmp('startImplement').disable();
                        Ext.getCmp('endImplement').disable();
                        Ext.getCmp('startTest').disable();
                        Ext.getCmp('endTest').disable();
                        Ext.getCmp('startBOM').disable();
                        Ext.getCmp('endBOM').disable();
                        Ext.getCmp('startTrial').disable();
                        Ext.getCmp('endTrial').disable();
                        Ext.getCmp('startCertf').disable();
                        Ext.getCmp('endCertf').disable();
                        Ext.getCmp('startIssue').disable();
                        Ext.getCmp('endIssue').disable();
                        if (ProcessStr && disableNode(head_node)) {
                            if (ProcessStr.indexOf('implement') > -1) {
                                Ext.getCmp('startImplement').enable();
                                Ext.getCmp('endImplement').enable();
                            }
                            if (ProcessStr.indexOf('test') > -1) {
                                Ext.getCmp('startTest').enable();
                                Ext.getCmp('endTest').enable();
                            }
                            if (ProcessStr.indexOf('BOM') > -1) {
                                Ext.getCmp('startBOM').enable();
                                Ext.getCmp('endBOM').enable();
                            }
                            if (ProcessStr.indexOf('trial') > -1) {
                                Ext.getCmp('startTrial').enable();
                                Ext.getCmp('endTrial').enable();
                            }
                            if (ProcessStr.indexOf('certification') > -1) {
                                Ext.getCmp('startCertf').enable();
                                Ext.getCmp('endCertf').enable();
                            }
                            if (ProcessStr.indexOf('issue') > -1) {
                                Ext.getCmp('startIssue').enable();
                                Ext.getCmp('endIssue').enable();
                            }
                        }
                        /*console.log(obj.data);*/
                        //下拉框钩选
                        var processGroup = Ext.getCmp('processGroup');
                        //var demandGroup = Ext.getCmp('demandGroup');

                        setCheckboxGroupValues(processGroup, obj.data['processGroup']);
                        //setCheckboxGroupValues(demandGroup, obj.data['demandGroup']);

                        //初始化认证是否能编辑
                        if (obj.data.demandGroup && !(obj.data.demandGroup.indexOf('其他认证') > 0)) {
                            let cmp = Ext.getCmp('elseDemand');
                            cmp.setReadOnly(true);
                            let elseDemand_labelTextEl = document.getElementById("elseDemand-labelTextEl");
                            elseDemand_labelTextEl.classList.add('colorGrey');
                        }


                        //对输入框增加悬浮展示
                        setShowTip('projectName');
                        setShowTip('elseDemand');
                        setShowTip('productLine');
                        setShowTip('planningProjectName');
                        if (disableNode(head_node)) {
                            setShowTip('demandGroup');
                        } else {
                            setShowTip('demandGroupDisplay');
                        }


                        //endregion
                        isLoaded = true;
                        // taskCompleted = true;//数据加载后标志位设为true
                    } else {
                        alert(obj.message);
                        isLoaded = true;
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

