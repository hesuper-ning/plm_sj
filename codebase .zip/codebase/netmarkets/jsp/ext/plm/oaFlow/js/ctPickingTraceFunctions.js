//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//
var submit_node ='submit_node';//提交
var makeOrder_node ='makeOrder_node';//做单人
var engineerConfirm_node ='engineerConfirm_node';//工程师确认
var departmentHead_node ='departmentHead_node';//部门主管审核
var PMC_node ='PMC_node';//物控审核
var departmentHeadConfirm_node ='departmentHeadConfirm_node';//部门主管确认
var PMCAndDepartmentHeadConfirm_node = 'PMCAndDepartmentHeadConfirm_node';
var engineerCheck_node ='engineerCheck_node';//工程师验收
var confirm_receipt_goods_node = 'confirm_receipt_goods_node';//三江电子-领料流程-确认收货
var initiate_material_return_node = 'initiate_material_return_node';//三江电子-领料流程-发起退料流程及填写单号

//退料
var submitReturn_node = 'submitReturn_node';
var quality_node = 'quality_node';
var initiator_node = 'initiator_node';


//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ght_dataLoadedFlag = false;
/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */
function disableNode(formkey) {
    if(taskCompleted == 'true') {
        return true;
    } else {
        if(formkey == currentActKey) {
            return false;
        } else {
            return true;
        }
    }
};



//自动保存字段
function autoSaveAtt(attKey, attValue) {
    var data = {
        docBranchId: branchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKey //全局变量，当前活动key
    };
    Ext.Ajax.request({
        async : false,
        scope: this,
        url: '/Windchill/ptc1/picking/save?oid='+oid,
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);

            if(obj.message=="success") {
            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){

    var mockRec = {
        oid:oid,
        dbTableName:dbTableName,
        itemId:itemId,
        dataKey:dataKey,
        dataValue:dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/picking/saveTraceItem?oid='+oid,
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(tableName,callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/picking/addItem?oid='+oid,
        params: {
            branchId: branchId,
            tableName:tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                callbackFn();
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//删除grid信息
function deleteData(tableName,ids, callback) {
    var data = {
        oid:oid,
        ids:ids,
        tableName:tableName
    }
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/picking/delTraceItem',
        method: "POST",
        params:{
            data: Ext.encode(data)
        },
        //headers: {'Content-Type':'application/json'},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message!="success") {
                Ext.Msg.alert("数据删除失败", obj.message);
            } else {
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

/**
 * 获取部门信息
 */
function getDepartment(no) {
    Ext.Ajax.request({
        scope: this,
        async: false,
        method: "GET",
        url: '/Windchill/ptc1/hr/getDeptName',
        params: {
            no: no
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message == "success") {
                Ext.getCmp("applyDepartment").setValue(obj.data)
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：获取部门信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

/**
 * 获取项目名称
 */
function setProjectNumber(projectName, projectInitiatingCompany, checkProject) {
    var myMask = new Ext.LoadMask({
        msg: '正在加载项目编号，请稍候......',
        target: Ext.getCmp('mainForm')
    });
    myMask.show();
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/picking/setProjectNumber',
        params:{
            projectName: projectName,
            projectInitiatingCompany: projectInitiatingCompany
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                Ext.getCmp("projectNumber").setValue(obj.data);
                //触发后台保存
                autoSaveAtt("projectNumber", obj.data);
            } else {
                Ext.getCmp("projectNumber").setValue("")
                alert(obj.message);
            }
            myMask.hide();
        },
        failure: function (response, opts) {
            myMask.hide();
            alert('错误：获取项目信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

function setStorehouse(value,table,purpose) {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/picking/setStorehouse',
        params:{
            branchId: branchId,
            positionsReset: value,
            purpose: purpose,
            table: table
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                Ext.getStore('pickingStore').reload();
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：修改仓位信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

function setReturnInventoryUrl(returnInventory){
    Ext.Ajax.request({
        async : false,
        scope: this,
        url: '/Windchill/ptc1/picking/getReturnInventoryUrl',
        params: {
            returnInventory: returnInventory,
            branchId:branchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                Ext.getCmp('returnInventoryUrl').setValue(obj['data']);
                autoSaveAtt('returnInventoryUrl', obj['data']);
            }else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    });
}