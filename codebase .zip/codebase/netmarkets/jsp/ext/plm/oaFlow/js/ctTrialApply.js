Ext.define('PLM.view.trialApply', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.trialApply',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">小批量试产申请及跟踪表</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {


/////////////////////////Panel items//////////////////////////////////
        var me = this;

        Ext.define('fixtureItemModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'fixtureName', 'amount', 'unit', 'requireDate', 'predictPrice',
            'price','fixtureUser','factory','inventorySite','procurementOrg'],
            idProperty: 'id'
        });

        Ext.define('fixtureStaffItemModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'outsourceName', 'amount', 'price', 'outsourcePrice'],
            idProperty: 'id'
        });

        var fixtureItemStore = Ext.create('Ext.data.Store', {
            id: 'fixtureItemStore',
            model: 'fixtureItemModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/fixture/getItemByBranchId?branchId='+branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var fixtureStaffItemStore = Ext.create('Ext.data.Store', {
            id: 'fixtureStaffItemStore',
            model: 'fixtureStaffItemModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/fixture/getStaffItemByBranchId?branchId='+branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var fixtureItemGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('fixtureItemStore'),
            id: 'fixtureItemGrid',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '工具夹名称', dataIndex: 'fixtureName', width: 100, editor: 'textfield'},
                {text: '数量', dataIndex: 'amount', width: 100, editor: 'textfield'},
                {text: '单位', dataIndex: 'unit', width: 100, editor: 'textfield'},
                {text: '需求日期', dataIndex: 'requireDate', width: 100, editor: 'textfield'},
                {text: '预计单价', dataIndex: 'predictPrice', width: 100, editor: 'textfield'},
                {text: '价格', dataIndex: 'price', width: 100, editor: 'textfield'},
                {text: '使用人', dataIndex: 'fixtureUser', width: 100, editor: 'textfield'},
                {text: '工厂', dataIndex: 'factory', width: 100, editor: 'textfield'},
                {text: '库存地点', dataIndex: 'inventorySite', width: 100, editor: 'textfield'},
                {text: '采购组织', dataIndex: 'procurementOrg', width: 100, editor: 'textfield'},
            ],
            tbar:[
                {
                text: '新增',
                id:'add',
                name:'add',
                handler:function () {
                    var callbackFn = function () {
                        Ext.getStore('fixtureItemStore').reload();
                    };
                    insertItemData('ZFixtureItem',callbackFn);
                }
            },{
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    let selectionArr = fixtureItemGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        getSum();
                        Ext.getStore('fixtureItemStore').reload()
                    };
                    deleteData('ZFixtureItem',obj, callbackFn);
                }
            },'->',{
                xtype:'tbtext',
                id:'sum',
                destroyMenu: true,
                text: '',
                reorderable: false
            }],
        });

        var fixtureStaffItemGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('fixtureStaffItemStore'),
            id: 'fixtureStaffItemGrid',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '委外名称', dataIndex: 'outsourceName', width: 100, editor: 'textfield'},
                {text: '数量', dataIndex: 'amount', width: 100, editor: 'textfield'},
                {text: '单价', dataIndex: 'price', width: 100, editor: 'textfield'},
                {text: '委外价格', dataIndex: 'outsourcePrice', width: 100, editor: 'textfield'},
            ],
            tbar:[
                {
                    text: '新增',
                    id:'add1',
                    name:'add1',
                    handler:function () {
                        var callbackFn = function () {
                            Ext.getStore('fixtureStaffItemStore').reload();
                        };
                        insertItemData('ZFixtureStaffItem',callbackFn);
                    }
                },{
                    text: '删除',
                    iconCls: 'icon icon-delete',
                    scope: this,
                    handler: function () {
                        let selectionArr = fixtureStaffItemGrid.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            getSum();
                            Ext.getStore('fixtureStaffItemStore').reload()
                        };
                        deleteData('ZFixtureStaffItem',obj, callbackFn);
                    }
                }],
        });

        fixtureItemGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    getSum();
                    tRecord.commit();
                };
                saveMockItemData('ZFixtureItem',itemId,tField,tValue, callbackFn);

            });

        fixtureStaffItemGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData('ZFixtureStaffItem',itemId,tField,tValue, callbackFn);

            });

        this.items = [{
            xtype: 'form',
            id: 'mainForm',
            //padding:'5',
            anchor: '90%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [
                {
                    xtype: 'panel',
                    border: false,
                    defaults: {border: false},
                    layout: 'hbox',
                    style: 'margin-left: 5px;padding-left: 5px;',
                    // 第一列中的表项
                    items: [
                        {
                            xtype: 'panel',
                            defaults: {
                                labelWidth: 100,
                                border: false,
                                margin: '5 20 5 5',
                            },
                            items: [{
                                xtype: 'textfield',
                                fieldLabel: '申请部门',
                                name: 'head_department',
                                id: 'head_department',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('head_department').getValue();
                                        //触发后台保存
                                        autoSaveAtt('head_department', value);
                                    }
                                }
                            }, {
                                xtype: 'panel',
                                layout: 'hbox',
                                items: [{//第四行
                                    xtype: 'radiogroup',
                                    name: 'head_subjectType',
                                    id: 'head_subjectType',
                                    fieldLabel: '科目分配类别',
                                    width: 180,
                                    labelWidth: 100,
                                    items: [
                                        {inputValue: 'K',boxLabel: 'K', name: 'val', checked: true, disabledCls: 'none'},
                                        {inputValue: '1', boxLabel: '1', name: 'val', disabledCls: 'none'}
                                    ],
                                    listeners : {
                                        change : function(field,newValue,oldValue){
                                            if(!ght_dataLoadedFlag) {
                                                //阻止加载时执行后台保存
                                                return;
                                            }
                                            //触发后台保存
                                            var data = newValue.quoteFile;
                                            autoSaveAtt('head_subjectType',data);
                                        }
                                    }
                                }, {border: false, html: '费用挂成本中心选择“K”，费用挂内部订单选择“1”   sss'}]
                            },
                                {
                                    xtype: 'panel',
                                    layout: 'hbox',
                                    defaults: {
                                        labelWidth: 100,
                                        border: false,
                                        margin: '5 20 5 0',
                                    },
                                    items: [{margin: '25 20 5 0', border: false, html: '项目内部订单号'}, {
                                        xtype: 'panel',
                                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                                        items: [{
                                            xtype: 'combo',
                                            fieldLabel: '项目类型',
                                            multiSelect: false,
                                            anyMatch: true,
                                            editable: false,
                                            emptyText: '==请选择==',
                                            store: [['研发管理部', '研发管理部'], ['销售部', '销售部']],
                                            width: 200,
                                            id: 'head_projectType',
                                            name: 'head_projectType',
                                            labelWidth: 100,
                                            listeners: {
                                                'select': function () {
                                                    var value = Ext.getCmp('head_projectType').getValue();
                                                    //触发后台保存
                                                    autoSaveAtt('head_projectType', value);
                                                }
                                            }
                                        }, {
                                            xtype: 'combo',
                                            fieldLabel: '项目内部订单号',
                                            multiSelect: false,
                                            anyMatch: true,
                                            editable: false,
                                            emptyText: '==请选择==',
                                            store: [['研发管理部', '研发管理部'], ['销售部', '销售部']],
                                            width: 300,
                                            id: 'head_projectOrderNumber',
                                            name: 'head_projectOrderNumber',
                                            labelWidth: 100,
                                            listeners: {
                                                'select': function () {
                                                    var value = Ext.getCmp('head_projectOrderNumber').getValue();
                                                    //触发后台保存
                                                    autoSaveAtt('head_projectOrderNumber', value);
                                                }
                                            }
                                        }
                                        ]
                                    },]
                                }, {
                                    xtype: 'textfield',
                                    fieldLabel: '归属团队',
                                    name: 'head_team',
                                    id: 'head_team',
                                    width: 250,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('head_team').getValue();
                                            //触发后台保存
                                            autoSaveAtt('head_team', value);
                                        }
                                    }
                                }
                            ]
                        }, {
                            xtype: 'panel',
                            defaults: {
                                labelWidth: 100,
                                border: false,
                                margin: '5 20 5 5',
                            },
                            items: [{
                                xtype: 'datefield',
                                fieldLabel: '日期',
                                format: 'Y-m-d',
                                name: 'head_date',
                                id: 'head_date',
                                width: 250,
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('head_date').getValue();
                                        //触发后台保存
                                        autoSaveAtt('head_date', value);
                                    },
                                }
                            }, {
                                xtype: 'combo',
                                fieldLabel: '成本中心',
                                multiSelect: false,
                                anyMatch: true,
                                editable: false,
                                store: [['研发管理部', '研发管理部'], ['销售部', '销售部']],
                                width: 250,
                                id: 'head_costCenter',
                                name: 'head_costCenter',
                                labelWidth: 100,
                                listeners: {
                                    'select': function () {
                                        var value = Ext.getCmp('head_costCenter').getValue();
                                        //触发后台保存
                                        autoSaveAtt('head_costCenter', value);
                                    }
                                }
                            }, {
                                xtype: 'panel',
                                layout: 'hbox',
                                defaults: {
                                    labelWidth: 100,
                                    border: false,
                                    margin: '25 20 5 0',
                                },
                                items: [{
                                    xtype: 'radiogroup',
                                    name: 'head_isProjectCost',
                                    id: 'head_isProjectCost',
                                    fieldLabel: '是否为PDT项目费用',
                                    width: 220,
                                    labelWidth: 130,
                                    items: [
                                        {inputValue: '是', boxLabel: '是', name: 'r1', checked: true},
                                        {inputValue: '否', boxLabel: '否', name: 'r1',}
                                    ],
                                    listeners : {
                                        change : function(field,newValue,oldValue){
                                            if(!ght_dataLoadedFlag) {
                                                //阻止加载时执行后台保存
                                                return;
                                            }
                                            //触发后台保存
                                            var data = newValue.quoteFile;
                                            autoSaveAtt('head_isProjectCost',data);
                                        }
                                    }
                                }, {
                                    xtype: 'textfield',
                                    name: 'head_otherProjectCost',
                                    id: 'head_otherProjectCost',
                                    width: 150,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('head_otherProjectCost').getValue();
                                            //触发后台保存
                                            autoSaveAtt('head_otherProjectCost', value);
                                        }
                                    }
                                }]
                            }, {
                                xtype: 'panel',
                                layout: 'hbox',
                                defaults: {
                                    labelWidth: 100,
                                    border: false,
                                    margin: '15 20 5 0',
                                },
                                items: [{
                                    xtype: 'textfield',
                                    fieldLabel: '项目编码',
                                    name: 'head_projectNumber',
                                    id: 'head_projectNumber',
                                    width: 250,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('head_projectNumber').getValue();
                                            //触发后台保存
                                            autoSaveAtt('head_projectNumber', value);
                                        }
                                    }
                                }, {border: false, html: '(项目清单列表)', width: 100}]
                            }
                            ]
                        },
                    ]
                },
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'textarea',
                            fieldLabel: '申购理由',
                            name: 'head_reason',
                            id: 'head_reason',
                            width: 800,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('head_projectNumber').getValue();
                                    //触发后台保存
                                    autoSaveAtt('head_projectNumber', value);
                                }
                            }
                        }
                        ],

                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{//第四行
                            xtype: 'textarea',
                            fieldLabel: '用途',
                            name: 'head_use',
                            id: 'head_use',
                            width: 800,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('head_use').getValue();
                                    //触发后台保存
                                    autoSaveAtt('head_use', value);
                                }
                            }
                        }
                        ],

                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'textarea',
                            fieldLabel: '要求',
                            name: 'hred_require',
                            id: 'hred_require',
                            width: 800,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('hred_require').getValue();
                                    //触发后台保存
                                    autoSaveAtt('hred_require', value);
                                }
                            }
                        }
                        ],
                    }]
                }, fixtureItemGrid, {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: 'PDT经理审批',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            fieldLabel: '意见',
                            xtype: 'textfield',
                            name: 'pdtMgr_opinion',
                            id: 'pdtMgr_opinion',
                            width: 300,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('pdtMgr_opinion').getValue();
                                    //触发后台保存
                                    autoSaveAtt('pdtMgr_opinion', value);
                                }
                            }
                        },
                        ],

                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '申请部门经理审批',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'radiogroup',
                            name: 'dMgr_opinion',
                            id: 'dMgr_opinion',
                            fieldLabel: '制作类型',
                            width: 200,
                            labelWidth: 80,
                            items: [{
                                inputValue: '委外',
                                boxLabel: '委外',
                                name: 'r1',
                                checked: true
                            }, {
                                inputValue: '自制',
                                boxLabel: '自制',
                                name: 'r1',
                            }]
                        }
                        ],
                        listeners : {
                            change : function(field,newValue,oldValue){
                                if(!ght_dataLoadedFlag) {
                                    //阻止加载时执行后台保存
                                    return;
                                }
                                //触发后台保存
                                var data = newValue.quoteFile;
                                autoSaveAtt('dMgr_opinion',data);
                            }
                        }
                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '申请部门上级领导',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '意见',
                            name: 'superior_opinion',
                            id: 'superior_opinion',
                            width: 600,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('superior_opinion').getValue();
                                    //触发后台保存
                                    autoSaveAtt('superior_opinion', value);
                                }
                            }
                        }
                        ],

                    }]
                }, {
                    xtype: 'panel',
                    title: '工装制作人员填写',
                    defaults: {margin: '5 20 0 0', border: false,},
                    items: [{//第一行
                        items: [ {//制作部门确认需要外协加工
                            xtype: 'radiogroup',
                            name: 'staff_opinion',
                            id: 'staff_opinion',
                            fieldLabel: '制作部门确认需要外协加工',
                            width: 250,
                            labelWidth: 170,
                            items: [{
                                inputValue: '是',
                                boxLabel: '是',
                                name: 'r1',
                                checked: true
                            }, {
                                inputValue: '否',
                                boxLabel: '否',
                                name: 'r1',
                            }],

                        },fixtureStaffItemGrid
                        ],
                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '技术部经理审核',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '意见',
                            name: 'technical_opinion',
                            id: 'technical_opinion',
                            width: 600,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('technical_opinion').getValue();
                                    //触发后台保存
                                    autoSaveAtt('technical_opinion', value);
                                }
                            }
                        }
                        ],

                    }]
                }, , {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '采购经理审核',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '意见',
                            name: 'PM_opinion',
                            id: 'PM_opinion',
                            width: 600,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('PM_opinion').getValue();
                                    //触发后台保存
                                    autoSaveAtt('PM_opinion', value);
                                }
                            }
                        }
                        ],

                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '采购部门确认购置情况',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '意见',
                            name: 'PM_affirm_opinion',
                            id: 'PM_affirm_opinion',
                            width: 600,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('PM_affirm_opinion').getValue();
                                    //触发后台保存
                                    autoSaveAtt('PM_affirm_opinion', value);
                                }
                            }
                        }
                        ],

                    }]
                }, {
                    xtype: 'panel',
                    layout: 'hbox',
                    title: '验收人确认验收情况',
                    defaults: {margin: '5 20 0 0', labelWidth: 100, border: false,},
                    items: [{//第一行
                        xtype: 'panel',
                        layout: 'hbox',
                        defaults: {margin: '5 20 0 0', labelWidth: 100},
                        items: [{
                            xtype: 'textfield',
                            fieldLabel: '意见',
                            name: 'caPerson_opinion',
                            id: 'caPerson_opinion',
                            width: 600,
                            listeners: {
                                blur: function (e) {
                                    var value = Ext.getCmp('caPerson_opinion').getValue();
                                    //触发后台保存
                                    autoSaveAtt('caPerson_opinion', value);
                                }
                            }
                        }
                        ],

                    }]
                },//~end of 测试项目
            ]
        }]
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('fixtureItemStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }else {
                        getSum();
                    }
                }
            });
            Ext.getStore('fixtureStaffItemStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/fixture/getFormInfo?branchId=' + branchId,
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == 'success') {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj.data);

                        ght_dataLoadedFlag = true;
                    } else {
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }

});

//获取合计价格x
function getSum() {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/fixture/getSumPrice',
        method: "get",
        params: {
            branchId: branchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                var sum = obj.data;
                Ext.getCmp("sum").setText(sum);
            } else {
                alert("获取合计价格失败："+obj.message);
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '获取合计价格失败，请检查网络！')
        }
    });
}