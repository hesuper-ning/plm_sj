//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//
/**
 * sampleApply研发制板
 */
var submit_node='submit_node'; //测试文档-申请人提交  用于第一个节点操作
var RD_node='RD_node';//
var PDTManager_node='PDTManager_node';
var applyDeptManager_node='applyDeptManager_node';
var TD_node='TD_node';
var PM_node='PM_node';
var control_node='control_node';
var RCD_node='RCD_node';

var routing_maintenance='routing_maintenance';
var uploads_first_article_report='uploads_first_article_report';
var upload_issue='upload_issue';
var reply_to_questions='reply_to_questions';

var applyDeptManager_node01='applyDeptManager_node01';

var NPI_engineer_opinion='NPI_engineer_opinion';

//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ct_dataLoadedFlag = false;
/**
 * 判断是否可编辑
 * @param formkey 节点表单key
 */
function disableNode(formkey) {
    if (!allowEdit == 'true') {
        return false;
    } else {
        if (formkey == currentActKey) {
            return true;
        } else {
            return false;
        }
    }
};
function hasPcbNumber(formkey) {
    if (!allowEdit === 'true') {
        return false;
    } else {
        if (formkey === "NA") {
            return false;
        } else {
            return true;
        }
    }
};


//自动保存字段
function autoSaveAtt(attKey, attValue) {
    var data = {
        docBranchId: docBranchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKeyOne //全局变量，当前活动key
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/sampleApply/autoSaveAtt?oid='+oid,
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
			if(obj.message==="success") {
			    if("trackingNumber" == attKey){
                    refreshPanel();
                }
            } else {
                refreshPanel();
				Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}

//刷新页面数据
function refreshPanel(){
    // 查询 form表单数据
    Ext.Ajax.request({
        url: '/Windchill/ptc1/sampleApply/getFromByBranchId?docBranchId='+docBranchId,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj.message=="success") {
                var mainPanel = Ext.getCmp('mainForm');
                mainPanel.getForm().setValues(obj.data);
                ct_dataLoadedFlag = true;
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：查询信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

 /**
 *保存列表中的一个属性(单元格）
 * @param data
 * @param callbackFn
 */
function saveItemData(data,callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/sampleApply/saveItemData?oid='+oid,
        params: data,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


/**
 *    grid创建空列
 * @param dbTableName 表名
 * @param callbackFn 回调函数
 */
function insertItemData(callbackFn) {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/sampleApply/insertItemData?oid='+oid,
        params: {
			docBranchId: docBranchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                callbackFn();
            } else {
                alert(obj['error'] + "9999");
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}

//删除grid信息
function deleteData(tableName, ids, callback) {
    var tmpGrid = Ext.getCmp('sampleApplyGrid');
    var myMask = new Ext.LoadMask( {msg: "数据正在处理中，请稍后...", target: tmpGrid});
    myMask.show();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/sampleApply/deleteItemData?oid='+oid,
        method: "POST",
        params: {
            oid: oid,
            data: Ext.encode(ids),
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['error']);
                myMask.hide();
            } else {
                myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

//传入公共的参数，返回上传附件的代码
function uploadFilefield(fileName,text,node,text_name){
    if(text==null || text==""){
        text = "浏览...";
    }

    var inform ={
        xtype:'filefield',
        buttonOnly: true,
        id:fileName,
        name:fileName,
        labelWidth:100,
        width:230,
        disabled:!allowEdit,
        hideLabel: true,
        buttonText: '<div style="width:100px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>'+text+'</div>',
        allowBlank: false,
        scope: this,
        listeners:{
            'change':function(fb,newValue,oldValue,opts){
                if(!newValue){
                    return;
                }
                var file = document.querySelector('[id='+fileName+'-button-fileInputEl]');
                var formData = new FormData();
                formData.append(fileName+'-button-fileInputEl', file.files[0]);
                fb.reset();//清空表单的值
                var myMask = new Ext.LoadMask({
                    msg: '正在上传，请稍候......',
                    target:this.findParentByType('panel')
                });
                myMask.show();
                $.ajax({
                    url: '/Windchill/ptc1/sampleApply/uploadFiles?docBranchId='+docBranchId+'&text_name='+text_name+"&node="+node,
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function(res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if(!success){
                        alert(msg);
                    }else {
                        var fileName = obj['fileName'];
                        var value = Ext.getCmp(text_name).getValue();
                        if(value != null && value != ''){
                            fileName = value +"&nbsp;|&nbsp;" + fileName;
                        }
                        Ext.getCmp(text_name).setValue(fileName);
                        autoSaveAtt(text_name, fileName);
                    }
                }).fail(function(res) {
                    myMask.hide();
                    alert('上传失败！') ;
                });
            }
        }
    };
    return inform;
}

//删除附件
function deleteFilefield(branchId,fileName,text_name,node) {
    if(!allowEdit){
        alert("您没有权限删除其他用户的附件！");
        return;
    }
    // var myMask = new Ext.LoadMask({
    // 	msg: '正在删除，请稍候......',
    // 	target:Ext.getCmp('headPanel')
    // });
    // myMask.show();
    Ext.Ajax.request({
        scope : this,
        async : false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url : '/Windchill/ptc1/sampleApply/deleteFiles',
        params : {
            docBranchId: docBranchId,
            fileName: fileName
        },
        success : function(response, opts) {
            // myMask.hide();
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if(!success){
                alert(msg);
            }else {
                var value = Ext.getCmp(text_name).getValue();
                var arr= new Array(); //定义一数组
                arr=value.split("|"); //字符分割
                for (i=0;i<arr.length ;i++ ){
                    var index = arr[i].indexOf(fileName);
                    if (index > -1) {
                        arr.splice(i,1);// 删除
                    }
                }
                var result = arr.join("&nbsp;|&nbsp;");
                Ext.getCmp(text_name).setValue(result);
                autoSaveAtt(text_name, result);
            }
        },
        failure : function(response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });
}
function saveObjectData(id,dataKey,dataValue,callbackFn){
    var returnItemId = undefined;
    Ext.Ajax.request({
        url: '/Windchill/ptc1/sampleApply/saveItemData',
        params:{
            id:id,
            dataKey:dataKey,
            dataValue:dataValue,
            oid:oid
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success"){
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if(callbackFn){
                    callbackFn();
                }
            }else{
                alert(obj['error']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}

//自动保存字段
function autoSaveAtt1(attKey, attValue) {
    var data = {
        docBranchId: docBranchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKeyOne //全局变量，当前活动key
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/sampleApply/autoSaveAtt?oid='+oid,
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message==="success") {
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/sampleApply/getFromByBranchId?docBranchId='+docBranchId,
                    success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if (obj.message=="success") {
                            Ext.getCmp('head_projectName').setValue(obj.data['head_projectName']);
                        } else {
                            alert(obj.message);
                        }
                    },
                    failure: function (response, opts) {
                        alert('错误：查询信息失败，请检查网络！!');
                    }
                });
            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}


function getVersion(number) {
    Ext.getStore('versionStore').load({
        params: {
            param:number,
        },
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询信息失败，请联系管理员！');
            }
        }
    })
}


/**
 * 获取项目名称
 */
function checkProjectNumber(field,number) {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/picking/checkProjectNumber',
        params:{
            projectNumber: number
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                Ext.getCmp("head_projectName").setValue(obj.data)
                //触发后台保存
                autoSaveAtt1(field,number);
            } else {
                Ext.getCmp("head_projectNumber").setValue("")
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：获取项目信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
}


//删除grid信息
function deleteProblemCollectionData(tableName, ids, callback) {
    var tmpGrid = Ext.getCmp('sampleApplyGrid');
    var myMask = new Ext.LoadMask( {msg: "数据正在处理中，请稍后...", target: tmpGrid});
    myMask.show();
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/sampleApply/deleteProblemCollectionForm?oid='+oid,
        method: "POST",
        params: {
            oid: oid,
            data: Ext.encode(ids),
            tableName: tableName
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("数据删除失败", obj['error']);
                myMask.hide();
            } else {
                myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert("错误", '数据删除失败，请检查网络！')
        }
    });
}

//自动保存字段
function saveGridItemData(id,attKey, attValue,tableName,callbackFn) {
    var data = {
        id: id,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        tableName:tableName
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/sampleApply/saveGridDate?oid='+oid,
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);

            if(obj.message==="success") {
                if(callbackFn){
                    callbackFn();
                }
            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}















