/**
 * PbcApply研发制板
 */
Ext.define('PLM.view.pcbApply', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.pcbApply',
    border: false,
    layout: 'anchor',
    title: '&nbsp;<font style="font-size:18px">PCB制板申请单</font>',
    autoWidth: true,
    autoHeight: true,
    autoScroll: true,
    collapsible: false,
    id: 'simpleForm',
    config: {
        in_objectKey: 'pcbApply',
        in_objectDesc: 'pcb申请单',
    },
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },

    initComponent: function () {

/////////////////////////Panel items//////////////////////////////////
        var me = this;

        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';

        var docNumberText = '系统文件编号';
        var tagIdText = '编号';
        var docDescriptionText = '文档说明';
        var versionText = '版本(请选择)';
        var versionStartText = '版本状态';
        var attachmentText = '附件';
        var outFormatRequirementText = '外发格式要求<br/>（中间格式只对epm文件有效）';
        var systemAttachmentText = '外发系统附件';;
        var budgetText = '预算(元)';

        var supplierGrid_name = '供应商名称';
        var supplierGrid_code = '供应商编号';
        var supplierGrid_email = '供应商邮箱';
        var supplierGrid_price = '供应商报价';
        var supplierGrid_arriveDate = '预计到板时间';
        var supplierGrid_remark = '备注';


        var addPcbDoc = '如为加做，请填写参考PCB制板申请单号';
        var isApplyGroup = '是否需要执行研发样板制作申请';
        var head_designatedPerson = '样板指定负责人';
        var building_slab = '板层';
        var gold_fee = '沉金费';
        var painting_fee = '光绘费';
        var isSourceGroup = '加急';
        var building_slabMode = '拼板方式(1set=?PCS):';
        var panelsNumber = '拼板数量:';
        var finished_productSizeLong = '成品尺寸(平方毫米):';

        if (disableNode(submit_node)) {
            docNumberText = redStarFlag + blueFlagStart + docNumberText + blueFlagEnd;
            versionText = redStarFlag + blueFlagStart + versionText + blueFlagEnd;
            docDescriptionText = blueFlagStart + docDescriptionText + blueFlagEnd;
            attachmentText = blueFlagStart + attachmentText + blueFlagEnd;
            outFormatRequirementText = redStarFlag + blueFlagStart + outFormatRequirementText + blueFlagEnd;
            systemAttachmentText =   blueFlagStart + systemAttachmentText + blueFlagEnd;

            supplierGrid_name = redStarFlag + blueFlagStart + supplierGrid_name + blueFlagEnd;
            supplierGrid_code = redStarFlag + blueFlagStart + supplierGrid_code + blueFlagEnd;
            supplierGrid_email = redStarFlag + blueFlagStart + supplierGrid_email + blueFlagEnd;
            supplierGrid_remark = blueFlagStart + supplierGrid_remark + blueFlagEnd;

            addPcbDoc =   blueFlagStart + addPcbDoc + blueFlagEnd;
            isApplyGroup = redStarFlag + blueFlagStart + isApplyGroup + blueFlagEnd;
            head_designatedPerson =   blueFlagStart + head_designatedPerson + blueFlagEnd;
            building_slab = redStarFlag + blueFlagStart + building_slab + blueFlagEnd;
            gold_fee = redStarFlag + blueFlagStart + gold_fee + blueFlagEnd;
            //painting_fee = redStarFlag + blueFlagStart + painting_fee + blueFlagEnd;
            isSourceGroup = redStarFlag + blueFlagStart + isSourceGroup + blueFlagEnd;
            building_slabMode = redStarFlag + blueFlagStart + building_slabMode + blueFlagEnd;
            panelsNumber = redStarFlag + blueFlagStart + panelsNumber + blueFlagEnd;
            finished_productSizeLong = redStarFlag + blueFlagStart + finished_productSizeLong + blueFlagEnd;
        } else if (disableNode(resourceCenter_node)) {
            supplierGrid_price = blueFlagStart + supplierGrid_price + blueFlagEnd;
            supplierGrid_arriveDate = blueFlagStart + supplierGrid_arriveDate + blueFlagEnd;
        }


        //获取使用人名单，全部人
        var theUserStore = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'theUserStore'
        });

        //外发格式要求
        var outFormatRequirementCobo = new Ext.form.ComboBox({
            name: 'productLines',
            id: 'productLines',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [['源文件', '源文件'], ['中间格式', '中间格式'], ['源文件和中间格式', '源文件和中间格式']]
            }),
            valueField: 'key',
            displayField: 'displayText'
        });

        var versionStore = new Ext.data.ArrayStore({
            id: 'versionStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/pcbApply/getVersion',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        var attachmentStore = new Ext.data.ArrayStore({
            id: 'attachmentStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/supplier/getSystemAttachment',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        //版本
        var versionCom = new Ext.form.ComboBox({
            name: 'versionCom',
            id: 'versionCom',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: versionStore,
            valueField: 'version',
            displayField: 'version'
        });

        var attachmentCombo = new Ext.form.ComboBox({
            name: 'attachmentCombo',
            id: 'attachmentCombo',
            multiSelect: true,
            valueField: 'attachment',
            displayField: 'attachment',
            anyMatch: true,
            editable: false,
            store: attachmentStore
        });


        Ext.define('supplierDocModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'tagId', 'attachmentPath', 'versionState','budget', 'interiorVersion', 'systemAttachment', 'docNumber', 'docName', 'attachment', 'outFormatRequirement'],
            idProperty: 'id'
        });


        var supplierDocStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'supplierDocModel',
            id: 'supplierDocStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/pcbApply/getSupplierItemInfo?branchId=' + docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var theUserCombo = Ext.create('PLM.common.CtAllUserCombo', {
            //readOnly: allowEdit ? false : true,
            disabled: !disableNode(submit_node),
            disabledCls: 'none',
            width: 250,
            fieldLabel: head_designatedPerson,
            store: theUserStore,
            name: 'head_designatedPerson',
            id: 'head_designatedPerson',
            displayField: 'userFullName',
            valueField: 'no',
            listeners: {
                change: function (e) {
                    if (allowEdit === true) {
                        var value = Ext.getCmp('head_designatedPerson').getValue();
                        //触发后台保存
                        autoSaveAtt('head_designatedPerson', value);
                    }
                }
            }
        });

        Ext.define('pcbApplyDocModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'docNumber', 'docName', 'docVersion', 'docEnclosure', 'docRemarks'],
            idProperty: 'id'
        });

        var pcbApplyDocStore = Ext.create('Ext.data.Store', {
            id: 'pcbApplyDocStore',
            model: 'pcbApplyDocModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/pcbApply/getDocItemByBranchId?docBranchId=' + docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var DocCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var pcbApplyDocGrid = Ext.create('Ext.grid.Panel', {
            plugins: [DocCellEditing],
            store: Ext.getStore('pcbApplyDocStore'),
            id: 'pcbApplyDocGrid',
            title: '文档列表',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
//fields: ['id', 'docBranchId', 'PCBName', 'count', 'productionMethod', 'versionNumber', 'openSteelMesh'],
            columns: [
                {xtype: 'rownumberer', width: '50'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'attachmentPath', menuDisabled: true, hidden: true},
                {text: '编号', dataIndex: 'tagId', width: 70, menuDisabled: true},
                {text: docNumberText, dataIndex: 'docNumber', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '文档名称', dataIndex: 'docName', width: 100, menuDisabled: true},
                {text: versionText, dataIndex: 'version', width: 100, editor: versionCom, menuDisabled: true},
                {text: '版本状态', dataIndex: 'versionState', width: 100, menuDisabled: true},
                {text: '内部版本', dataIndex: 'interiorVersion', width: 100, menuDisabled: true},
               /* {text: budgetText, dataIndex: 'budget', width: 100, editor:{
                        xtype: 'numberfield',
                        anchor: '100%',
                        decimalPrecision: 5,
                        //minValue: 0
                    }, menuDisabled: true},*/
                {text: attachmentText, dataIndex: 'attachment', width: 250, menuDisabled: true},
                {
                    text: systemAttachmentText,
                    dataIndex: 'systemAttachment',
                    width: 250,
                    editor: attachmentCombo,
                    menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        var temp = new Array();
                        if (value == '' || value == undefined || value == null) {
                            return '';
                        }
                        if (!Array.isArray(value)) {
                            value += ",";
                            var start = 0;
                            var pos = value.indexOf(',');
                            while (pos > -1) {
                                temp.push(value.substr(start, pos - start));
                                start = pos + 1;
                                pos = value.indexOf(',', pos + 1);
                            }
                            record.set("systemAttachment", temp);
                            record.commit();
                        } else {
                            temp = value;
                        }
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + temp + "'";
                        return temp;
                    }
                },
                {
                    text: outFormatRequirementText,
                    dataIndex: 'outFormatRequirement',
                    width: 160,
                    editor: outFormatRequirementCobo, menuDisabled: true
                },
                {
                    text: docDescriptionText,
                    dataIndex: 'docDescription',
                    width: 100,
                    editor: 'textfield',
                    menuDisabled: true
                },
                {text: '', dataIndex: '', width: 10,},
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得到修改列

                    if (allowEdit) {

                        /*if (currentActKey == 'submit_node') {*/

                            if (tField == 'version') {
                                let selectionArr = pcbApplyDocGrid.getSelectionModel().getSelection();
                                if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                    return;
                                }
                                var number = selectionArr[0].data['docNumber']
                                if (!number) {
                                    Ext.getCmp('saveStatus2').setText('请先填写编号！');
                                    return false;
                                } else {
                                    getVersion(number);
                                }
                            }
                            if (tField == 'systemAttachment') {
                                let selectionArr = pcbApplyDocGrid.getSelectionModel().getSelection();
                                if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                                    return;
                                }
                                var version = selectionArr[0].data['version']
                                var docNumber = selectionArr[0].data['docNumber']
                                if (!version) {
                                    Ext.getCmp('saveStatus2').setText('请先填写版本！');
                                    return false;
                                } else {
                                    getSystemAttachment(docNumber, version);
                                }
                            }
                            Ext.getCmp('saveStatus2').setText(' ');
                            return true;

                        /*} else*/ if (currentActKey == 'procurement_node') {
                            return false;
                        } else {
                            Ext.getCmp('saveStatus2').setText('不允许编辑');
                            return false
                        }
                    } else {
                        Ext.getCmp('saveStatus2').setText('不允许编辑');
                        return false
                    }

                },
            },
            tbar: [{
                hidden: !disableNode(submit_node),
                text: '新增',
                id: 'docAdd',
                name: 'docAdd',
                iconCls: 'icon icon-add',
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('pcbApplyDocStore').reload();
                    };
                    insertDocItemData(callbackFn);
                }
            }, {
                hidden: !disableNode(submit_node),
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    let selectionArr = pcbApplyDocGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('pcbApplyDocStore').reload()
                    };
                    deleteDocData('ZPcbApplyDocItem', obj, callbackFn);
                }
            }, {
                xtype: 'filefield',
                hidden: !disableNode(submit_node),
                buttonOnly: true,
                id: 'head_uploadFile',
                name: 'head_uploadFile',
                // hidden:true,
                hideLabel: true,
                buttonText: '<img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>' + '添加附件',
                allowBlank: false,
                scope: this,
                listeners: {

                    'focus': function () {
                        let selectionArr = pcbApplyDocGrid.getSelectionModel().getSelection();
                        if (selectionArr.length == 0) {
                            alert("未选择添加附件行！");
                            return;
                        }
                        /*//alert(selectionArr[0].get("attachment"))
                        if (selectionArr[0].get("attachment") != null){
                            alert('只能上传一个附件');
                            return;
                        }*/
                        if (selectionArr.length >= 2) {
                            alert("不支持多行选择添加附件！");
                            return;
                        }

                    },
                    'change': function (fb, newValue) {
                        if (!newValue) {
                            return;
                        }
                        let selectionArr = pcbApplyDocGrid.getSelectionModel().getSelection();

                        var outDrawings = selectionArr[0].get("docNumber");
                        // store.reload();
                        if (outDrawings == '' || outDrawings == undefined) {
                            alert("请先填写外发图纸编号!");
                            return;
                        } else if (selectionArr.length == 0) {
                            alert("添加附件失败，未选择添加附件对象!");
                            return;
                        } else if (selectionArr.length >= 2) {
                            alert("不支持多行添加附件操作，请确认要添加的行");
                            return;
                        } else {

                            var file = document.querySelector('[id=' + 'head_uploadFile' + '-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('head_uploadFile' + '-button-fileInputEl', file.files[0]);
                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在上传，请稍候......',
                                target: this.findParentByType('panel')
                            });


                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/supplier/uploadFiles?branchId=' + docBranchId + '&tetx_name=' + 'head_uploadFileRecord' + "&node=" + 'head_node',
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function (res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if (!success) {
                                    alert(msg);
                                } else {
                                    var fileName = obj['fileName'];
                                    var filePath = obj['filePath'];
                                    var tRecord = pcbApplyDocGrid.getSelectionModel().getSelection()[0];
                                    var attachmentValue = pcbApplyDocGrid.getSelectionModel().getSelection()[0].data.attachment;
                                    var attachmentPath = pcbApplyDocGrid.getSelectionModel().getSelection()[0].data.attachmentPath;
                                    if (attachmentValue != null && attachmentValue != '') {
                                        fileName = attachmentValue + "&nbsp;|&nbsp;" + fileName;
                                        filePath = attachmentPath + "&nbsp;|&nbsp;" + filePath;
                                    }
                                    tRecord.set('attachment', fileName);
                                    tRecord.set('attachmentPath', filePath);
                                    var callbackFn = function () {
                                        tRecord.commit();
                                    };
                                    var itemId = tRecord.get('id');
                                    saveDocItemData("ZPcbApplyDocItem",itemId, 'attachment', fileName, callbackFn);
                                    saveDocItemData("ZPcbApplyDocItem",itemId, 'attachmentPath', filePath, callbackFn);

                                }
                                var callbackFn = function () {
                                    //tRecord.commit();
                                    Ext.getStore('pcbApplyDocGrid').reload();
                                };
                            }).fail(function (res) {
                                myMask.hide();
                                alert('上传失败！');
                            });
                        }
                    }

                }
            },{
                xtype: 'tbtext',
                text: '',
                id: 'saveStatus2',
                disabled: true
            }],
        });

        pcbApplyDocGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    Ext.getStore('pcbApplyDocStore').reload()
                };
                saveDocItemData('ZPcbApplyDocItem', itemId, tField, tValue, callbackFn);
            });


        //供应商名称下拉
        var supplierNameStore = Ext.create('Ext.data.Store', {
            fields: ['supplierName'],
            id: 'supplierNameStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/supplier/getSupplierInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    messageProperty: 'error',
                    root: 'data'
                }
            }),
            autoLoad: true
        });

        var supplierNameCombo =  Ext.create('Ext.form.field.ComboBox', {
            name: 'supplierNameCombo',
            id: 'supplierNameCombo',
            store: supplierNameStore,
            valueField: 'supplierName',
            displayField: 'supplierName',
            width: 300,
            typeAhead: true,
            triggerAction: 'all',
            queryMode: 'local',
            allowBlank: true,
            anyMatch: true
        });


        Ext.define('pcbApplySupplierModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId','tagId', 'supplierName', 'supplierEmail', 'supplierCode', 'supplierPrice', 'endDate', 'pcbRemarks'],
            idProperty: 'id'
        });

        var pcbApplySupplierStore = Ext.create('Ext.data.Store', {
            id: 'pcbApplySupplierStore',
            model: 'pcbApplySupplierModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/pcbApply/getItemByBranchId?docBranchId=' + docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        //临时编号下拉
        var tagStore = Ext.create('Ext.data.Store', {
            fields: ['tagId'],
            id: 'tagStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/pcbApply/getTagIds?branchId=' + docBranchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    messageProperty: 'error',
                    root: 'data'
                }
            }),
            autoLoad: false
        });
        //编号
        var tagCombo = new Ext.form.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            name: 'tagCombo',
            id: 'tagCombo',
            lazyRender: true,
            width: 100,
            mode: 'local',
            store: tagStore,
            valueField: 'tagId',
            displayField: 'tagId',
        });

        var supplierCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var pcbApplySupplierGrid = Ext.create('Ext.grid.Panel', {
            plugins: [supplierCellEditing],
            store: Ext.getStore('pcbApplySupplierStore'),
            id: 'pcbApplySupplierGrid',
            title: 'PCB供应商列表',
            margin: '10 0 20 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: false,
            region: 'center',
            //height: 300,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
//fields: ['id', 'docBranchId', 'PCBName', 'count', 'productionMethod', 'versionNumber', 'openSteelMesh'],
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '编号', dataIndex: 'tagId', width: 100, editor: tagCombo},
                {text: supplierGrid_name, dataIndex: 'supplierName', width: 100, editor: supplierNameCombo},
                {text: supplierGrid_code, dataIndex: 'supplierCode', width: 100, editor: 'textfield'},
                {text: supplierGrid_email, dataIndex: 'supplierEmail', width: 100, editor: 'textfield'},
                {
                    text: supplierGrid_price,
                    dataIndex: 'supplierPrice',
                    width: 100,
                    editor:  'textfield' ,
                },
                {
                    text: supplierGrid_arriveDate,
                    dataIndex: 'endDate',
                    width: 100,
                    editor: new Ext.form.DateField({format: 'Y-m-d', minValue: new Date(),}),
                    menuDisabled: true,
                    align: 'center',
                    renderer: function (value) {
                        if (value != null && value != undefined && value != '') {
                            var date = new Date(value);
                            var time = Ext.Date.format(date, "Y-m-d")
                            return time;
                        }
                    }

                },
                {text: supplierGrid_remark, dataIndex: 'pcbRemarks', width: 100, editor: 'textfield'},

            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.field; //得中间格式到修改列
                    if (!disableNode(submit_node) && !disableNode(resourceCenter_node)) {
                        return false;
                    }else {
                        if (disableNode(submit_node)) {
                            var flag = false;
                            if (tField != 'supplierPrice' && tField != 'endDate') {
                                if (tField == 'supplierEmail' || tField == 'supplierCode') {
                                    supplierNameStore.each(function (record) {
                                        var sf = record.get('supplierName');
                                        var supplierName = e.record.data.supplierName;
                                        if (supplierName == sf) {
                                            flag = false
                                            return
                                        }else {
                                            flag = true
                                            return
                                        }
                                    })
                                }else {
                                    flag = true
                                    return
                                }
                                return flag;
                            }
                        }else if (disableNode(resourceCenter_node)) {
                            if (tField == 'supplierPrice' || tField == 'endDate'){
                                return true
                            }
                        }
                        return false
                    }

                },
            },
            tbar: [{
                hidden: !disableNode(submit_node),
                text: '新增',
                id: 'add',
                name: 'add',
                iconCls: 'icon icon-add',
                handler: function () {
                    var callbackFn = function () {
                        Ext.getStore('pcbApplySupplierStore').reload();
                    };
                    insertItemData(callbackFn);
                }
            }, {
                hidden: !disableNode(submit_node),
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    let selectionArr = pcbApplySupplierGrid.getSelectionModel().getSelection();
                    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                        Ext.Msg.alert("提示", "请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    Ext.each(selectionArr, function (record) {
                        obj.push(record.data['id'])
                    });
                    var callbackFn = function () {
                        //tRecord.commit();
                        Ext.getStore('pcbApplySupplierStore').reload()
                    };
                    deleteData('ZPcbApplySupplierItem', obj, callbackFn);
                }
            }],
        });

        pcbApplySupplierGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    Ext.getStore('pcbApplySupplierStore').reload()
                };
                saveItemData(tRecord.data, callbackFn);
            });


        var mainPanel = {
            xtype: 'form',
            id: 'mainForm',
            anchor: '93%',
            border: false,
            defaults: {
                labelWidth: 100,
                border: false,
                margin: '5 20 5 5',
            },
            items: [{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 80},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '项目编号',
                    name: 'head_projectNumber',
                    id: 'head_projectNumber',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('head_projectNumber').getValue();
                            //触发后台保存
                            autoSaveAtt1('head_projectNumber', value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '项目名称',
                    name: 'head_projectName',
                    id: 'head_projectName',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('head_projectName').getValue();
                            //触发后台保存
                            autoSaveAtt('head_projectName', value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '产品型号',
                    name: 'head_productType',
                    id: 'head_productType',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('head_productType').getValue();
                            //触发后台保存
                            autoSaveAtt('head_productType', value);
                        }
                    }
                },]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 80},
                items:
                    [{
                        xtype: disableNode(submit_node) ? 'textfield' : 'displayfield',
                        fieldLabel: addPcbDoc,
                        name: 'addPcbDoc',
                        id: 'addPcbDoc',
                        width: 250,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('addPcbDoc').getValue();
                                //触发后台保存
                                autoSaveAtt('addPcbDoc', value);
                            }


                        }
                    }, {
                        xtype: 'radiogroup',
                        disabled: !disableNode(submit_node),
                        disabledCls: 'none',
                        fieldLabel: isApplyGroup,
                        name: 'isApplyGroup',
                        id: 'isApplyGroup',
                        width: 250,
                        labelWidth: 100,
                        items: [{
                            inputValue: '是',
                            boxLabel: '是',
                            name: 'isApply',
                            disabledCls: 'none'
                        }, {
                            inputValue: '否',
                            boxLabel: '否',
                            name: 'isApply',
                            disabledCls: 'none'
                        },], listeners: {
                            change: function (field, newValue, oldValue) {
                                if (!ct_dataLoadedFlag) {
                                    //加载阻止数据时执行后台保存
                                    return;
                                }
                                //触发后台保存
                                autoSaveAtt('isApply', newValue.isApply);
                            },
                        },

                    }, theUserCombo,]
            }, {
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100, border: false},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {border: false, margin: '5 20 0 0', labelWidth: 100},
                    items: [{html: '到板时间说明:正常时间，2层4天；4层7天；6或者8层9天',}
                    ],

                }]
            },]
        };

        var panelOne = {
            xtype: 'form',
            id: 'formOne',
            defaults: {border: false, margin: '5 5 5 5'},
            items: [{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {border: false, margin: '5 5 5 5'},
                items: [{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {border: false, margin: '5 5 5 5'},
                    items: [
                        //第一列
                        {
                            defaults: {border: false,},
                            items: [
                                {
                                    html: building_slab
                                }, {
                                    xtype: 'combobox',
                                    disabled: !disableNode(submit_node),
                                    disabledCls: 'none',
                                    name: 'building_slab',
                                    id: 'building_slab',
                                    margin: '15 5 0 0',
                                    store: [['2L', '2L'], ['4L', '4L'], ['6L', '6L'], ['8L', '8L']],
                                    width: 100,
                                    listeners: {
                                        change: function (e) {
                                            if (allowEdit === true) {
                                                var value = Ext.getCmp('building_slab').getValue();
                                                var raGroup = Ext.getCmp('isSourceGroup');
                                                raGroup.items.get(1).enable();
                                                raGroup.items.get(2).enable();
                                                raGroup.items.get(3).enable();
                                                raGroup.items.get(4).enable();
                                                if (value == '2L') {
                                                    raGroup.items.get(3).disable();
                                                    raGroup.items.get(4).disable();
                                                } else if (value == '4L') {
                                                    raGroup.items.get(1).disable();
                                                    raGroup.items.get(2).disable();
                                                } else if (value == '6L' || value == '8L') {
                                                    raGroup.items.get(1).disable();
                                                    raGroup.items.get(2).disable();
                                                    raGroup.items.get(3).disable();
                                                }
                                                //触发后台保存
                                                autoSaveAtt1('building_slab', value);
                                            }


                                        }
                                    }
                                },

                            ]

                        }, {
                            defaults: {border: false,},
                            items: [
                                {
                                    html: '单价(0.07元/平方CM)'
                                }, {
                                    xtype: 'displayfield',
                                    name: 'unit_price',
                                    id: 'unit_price',
                                    margin: '15 5 0 0',
                                    width: 100,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('unit_price').getValue();
                                            //触发后台保存
                                            autoSaveAtt('unit_price', value);
                                        }
                                    }
                                },{
                                    xtype: 'displayfield',
                                    name: 'unit_price_basic',
                                    id: 'unit_price_basic',
                                    hidden:true
                                },

                            ]

                        }, {
                            defaults: {border: false,},
                            items: [
                                {
                                    html: '菲林费(0.36元/平方CM)',
                                }, {
                                    xtype: 'displayfield',
                                    name: 'Pcb_filmFee',
                                    id: 'Pcb_filmFee',
                                    margin: '15 5 0 0',
                                    width: 100,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('Pcb_filmFee').getValue();
                                            //触发后台保存
                                            autoSaveAtt('Pcb_filmFee', value);
                                        }
                                    }
                                },{
                                    xtype: 'displayfield',
                                    name: 'Pcb_filmFee_basic',
                                    id: 'Pcb_filmFee_basic',
                                    hidden:true
                                },
                            ]
                        }, {
                            defaults: {border: false,},
                            items: [{
                                html: '工程费用',
                            }, {

                                xtype: 'displayfield',
                                name: 'engineering_funds',
                                id: 'engineering_funds',
                                margin: '15 5 0 0',
                                width: 100,
                                listeners: {
                                    blur: function (e) {
                                        var value = Ext.getCmp('engineering_funds').getValue();
                                        //触发后台保存
                                        autoSaveAtt('engineering_funds', value);
                                    }
                                }


                            },]
                        }, {
                            defaults: {border: false,},
                            items: [

                                {
                                    html: '小计',
                                }, {
                                    xtype: 'displayfield',
                                    name: 'subtotal',
                                    id: 'subtotal',
                                    margin: '15 5 0 0',
                                    width: 100,
                                    listeners: {
                                        blur: function (e) {
                                            var value = Ext.getCmp('subtotal').getValue();
                                            //触发后台保存
                                            autoSaveAtt('subtotal', value);
                                        }
                                    }
                                }
                            ]

                        }, {
                            defaults: {border: false,},
                            items: [

                                {
                                    html: gold_fee,
                                }, {
                                    xtype: 'combobox',
                                    disabled: !disableNode(submit_node),
                                    disabledCls: 'none',
                                    name: 'gold_fee',
                                    id: 'gold_fee',
                                    margin: '15 5 0 0',
                                    store: [['0', '0'], ['100', '100']],
                                    width: 100,
                                    listeners: {
                                        change: function (e) {
                                            if (allowEdit === true) {
                                                var value = Ext.getCmp('gold_fee').getValue();
                                                //触发后台保存
                                                autoSaveAtt1('gold_fee', value);
                                            }
                                        }
                                    }
                                }
                            ]

                        }, {
                            defaults: {border: false,},
                            items: [

                                {
                                    html: painting_fee,
                                }, {
                                    xtype: 'displayfield',
                                    name: 'painting_fee',
                                    value:'0',
                                    disabledCls: 'none',
                                    id: 'painting_fee',
                                    margin: '15 5 0 0',
                                    width: 100,
                                    listeners: {
                                    }
                                }
                            ]

                        },
                    ]
                },]
            },
                {
                    xtype: 'radiogroup',
                    disabled: !disableNode(submit_node),
                    disabledCls: 'none',
                    fieldLabel: isSourceGroup,
                    width: 600,
                    name: 'isSourceGroup',
                    id: 'isSourceGroup',
                    labelWidth: 100,
                    items: [{
                        inputValue: '不加急',
                        boxLabel: '不加急',
                        name: 'isSource',
                    }, {
                        inputValue: '加急24H',
                        boxLabel: '加急24H',
                        name: 'isSource',
                    }, {
                        inputValue: '加急48H',
                        boxLabel: '加急48H',
                        name: 'isSource',
                    }, {
                        inputValue: '加急72H',
                        boxLabel: '加急72H',
                        name: 'isSource',
                    }, {
                        inputValue: '加急96H',
                        boxLabel: '加急96H',
                        name: 'isSource',
                    },], listeners: {
                        change: function (field, newValue, oldValue) {
                            if (!ct_dataLoadedFlag) {
                                //加载阻止数据时执行后台保存
                                return;
                            }
                            //触发后台保存
                            autoSaveAtt1('isSource', newValue.isSource);
                        },
                    },

                },
                {
                    layout: 'hbox',
                    defaults: {border: false, margin: '5 5 5 5'},
                    items: [{
                        html: building_slabMode,
                        margin: '15 5 3 0',
                    }, {
                        xtype: disableNode(submit_node) ? 'textfield' : 'displayfield',
                        name: 'building_slabMode',
                        id: 'building_slabMode',
                        margin: '15 5 3 0',
                        width: 100,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('building_slabMode').getValue();
                                //触发后台保存
                                autoSaveAtt1('building_slabMode', value);
                            }
                        },
                    }, {
                        html: '拼板数量:<font color=red>*</font>',
                        margin: '15 5 3 0'
                    }, {
                        xtype: disableNode(submit_node) ? 'numberfield' : 'displayfield',
                        name: 'panelsNumber',
                        id: 'panelsNumber',
                        decimalPrecision: 0,
                        minValue:1,
                        margin: '15 5 3 0',
                        width: 200,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('panelsNumber').getValue();
                                //触发后台保存
                                autoSaveAtt1('panelsNumber', value);
                            },
                        }
                    }, {
                        html: finished_productSizeLong,
                        margin: '15 5 3 0'
                    }, {
                        xtype: disableNode(submit_node) ? 'numberfield' : 'displayfield',
                        name: 'finished_productSizeLong',
                        id: 'finished_productSizeLong',
                        margin: '15 5 3 0',
                        minValue:0.01,
                        width: 100,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('finished_productSizeLong').getValue();
                                //触发后台保存
                                autoSaveAtt1('finished_productSizeLong', value);
                            }
                        }
                    }, {
                        html: 'mm*',
                        margin: '15 5 3 0'
                    }, {
                        xtype: disableNode(submit_node) ? 'numberfield' : 'displayfield',
                        name: 'finished_productSizeWide',
                        id: 'finished_productSizeWide',
                        margin: '15 5 3 0',
                        minValue:0.01,
                        width: 100,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('finished_productSizeWide').getValue();
                                //触发后台保存
                                autoSaveAtt1('finished_productSizeWide', value);
                            }
                        }
                    }, {
                        html: 'mm',
                        margin: '15 5 3 0'
                    }]

                }, {
                    xtype: 'displayfield',
                    fieldLabel: '总计',
                    name: 'allFee',
                    id: 'allFee',
                    margin: '15 15 15 15',
                    width: 250,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('allFee').getValue();
                            //触发后台保存
                            autoSaveAtt('allFee', value);
                        }
                    }
                }]
            //~end of 测试项目


        }
        var fieldSet2 = {
            xtype: 'fieldset',
            title: '文档',
            collapsible: true,
            items: [pcbApplyDocGrid]
        }

        var fieldSet = {
            xtype: 'fieldset',
            title: '费用计算',
            collapsible: true,
            items: [panelOne],
        }

        var fieldSet1 = {
            xtype: 'fieldset',
            title: '供应商选择',
            collapsible: true,
            items: [pcbApplySupplierGrid]
        }

        this.items = [mainPanel, fieldSet2, fieldSet, fieldSet1];
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('pcbApplySupplierStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            //文档信息
            Ext.getStore('pcbApplyDocStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            ct_dataLoadedFlag = false;
            // 查询 form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/pcbApply/getFromByBranchId?docBranchId=' + docBranchId,
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj.message == "success") {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj.data);
                        var formOne = Ext.getCmp('formOne');
                        formOne.getForm().setValues(obj.data);
                        /* var formTwo = Ext.getCmp('formTwo');
                         formTwo.getForm().setValues(obj.data);*/
                        ct_dataLoadedFlag = true;
                    } else {
                        alert(obj.message);
                    }

                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request


        }
    }

});