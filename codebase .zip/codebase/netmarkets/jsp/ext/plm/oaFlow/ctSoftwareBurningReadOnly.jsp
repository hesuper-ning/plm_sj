<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="wt.workflow.work.*,wt.fc.Persistable,wt.doc.WTDocument,wt.inf.container.WTContainer,wt.projmgmt.admin.Project2"%>
<%@ page import="ext.plm.util.CtUserUtil" %>
<html>
<head>
<%
String oid = request.getParameter("oid");
wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
wt.doc.WTDocument doc = (wt.doc.WTDocument)rf.getReference(oid).getObject();
String docNumber = doc.getNumber();
String userName = CtUserUtil.getCurrentUserDisplayName();
//将文档的大版本branchId作为主键id
String branchId = doc.getBranchIdentifier()+"";
wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
 String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=";
 
%>

<script type="text/javascript">
	//文档编码
	var docNumber = "<%=docNumber%>";
	//流程当前节点名称
	var actName = "NA";
	//当前用户全名
	var userName ="<%=userName%>";
	//文档vid
	var docBranchId ="<%=branchId%>";
	//url前缀
	var urlPathPrefix ="<%=urlPathPrefix%>";
	//节点名称
	var actKey = "NA";

	var workItemOid = "NA";
	//编辑权限
	var allowEdit = false;
	var whetherEngineer = false;

	var taskCompleted = true;

	var whetherTester = false;

	var accountNumber = "";

	var whetherPDMEngineerReview = false;


</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
	<link rel="stylesheet" type="text/css"
		  href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
	<!-- ExtJS -->
	<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
	<script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
	<script type="text/javascript" src="js/ctSoftwareBurning.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>
// ==============layout define area=================================//
Ext.onReady(function() {
	 Ext.QuickTips.init();
	
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'SoftwareBurningPanel'
		    }]
		});
});
</script>
</body>
</html>