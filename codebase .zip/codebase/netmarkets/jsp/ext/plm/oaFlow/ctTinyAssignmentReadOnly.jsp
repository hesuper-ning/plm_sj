<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="wt.doc.WTDocument"%>
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>>oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WTDocument doc = (WTDocument) rf.getReference(oid).getObject();
        String containerOid = ext.plm.util.CtWTObjectUtil.getOid(doc.getContainer());
        long branchId = doc.getBranchIdentifier();
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctTinyAssignmentFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctTinyAssignment.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <style>
        .tooltip {
            position: absolute;
            background-color: #e2eff9;
            padding: 5px 10px;
            border-radius: 5px;
            z-index: 1000;
            display: none;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /* 水平偏移，垂直偏移，模糊半径，颜色 */
        }
        .colorGrey {
            color: #cfcfcf
        }
    </style>

</head>

<body>
<script>

    var containerOid = "<%=containerOid%>";
    //编辑权限
    var allowEdit = false;
    var currentActKey = "1";
    //容器id
    var containerId = "<%=oid%>";
    var branchId ='<%= branchId %>';
    var taskCompleted = true;
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'assignment'
            }]
        });
    });
</script>
</body>
</html>