<%--sampleApply研发制板--%>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="ext.plm.oaFlow.pcbApply.config.CtPcbApplyProperties" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        // String currentActKey = CtCertfProperties.getActivityNodeName(actName);
        WTDocument doc = (WTDocument) rf.getReference(oid).getObject();
        long docBranchId = doc.getBranchIdentifier();
//打印页面信息，有用
    %>

    <script type="text/javascript">




    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctPcbApply.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctPcbApplyFunctions.js?_dc=<%System.currentTimeMillis();%>"></script>

</head>

<body>
<script>
    var allowEdit = false;
    //vid
    var docBranchId = "<%=docBranchId%>";
    var currentActKey = "";

    var currentActKeyOne = "<%=1%>";

    var oid = "<%=oid%>";

    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'pcbApply'
            }]
        });
    });
</script>

</body>
</html>