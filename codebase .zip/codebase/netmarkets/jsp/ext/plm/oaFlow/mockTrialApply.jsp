<%@page import="ext.plm.util.IBAUtil"%>
<%@ page import="wt.doc.WTDocument" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
<%
    String oid = request.getParameter("oid");
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    WTDocument document = (WTDocument) rf.getReference(oid).getObject();
    IBAUtil ibaUtil = new IBAUtil(document);
    String selectType = ibaUtil.getIBAValue("selectType");
    String number = ibaUtil.getIBAValue("name");
    System.out.println(">>>>>>>>类型"+selectType+"文档"+document.getBranchIdentifier()+"--"+document.getName()
            +"--"+number);
%>

<script type="text/javascript">

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js"></script>
    <script type="text/javascript" src="js/mockNewTrialApply.js?_dc<%System.currentTimeMillis();%>"></script>

</head>

<body>
<script>



Ext.onReady(function() {
	 Ext.QuickTips.init();

	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
		        xtype: 'newTrialApply'
		    }]
		});
});

</script>

</body>
</html>