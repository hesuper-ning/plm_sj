<%--sampleApply研发制板--%>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="ext.plm.oaFlow.pcbApply.config.CtPcbApplyProperties" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workItem = (WorkItem)rf.getReference(oid).getObject();
        WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
        String actName = activity.getName();
        String currentActKey = CtPcbApplyProperties.getActivityKey(actName);

        WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
        long docBranchId = doc.getBranchIdentifier();

        boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workItem,
                CtPcbApplyProperties.getProperty("sample_qualityMetric_allowEdit_roles"));
        System.out.println(">>>>>>>>>ctPcbApply.jsp jsp actName="+actName+">>>>currentActKey="
                +">>>>>docBranchId="+docBranchId+">>>oid="+oid+">>allowEdit="+allowEdit);

    %>

    <script type="text/javascript">


    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctPcbApply.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctPcbApplyFunctions.js?_dc<%System.currentTimeMillis();%>"></script>

</head>

<body>
<script>

    var allowEdit = false;
    <%if(allowEdit){ %>
    allowEdit = true;
    <%}%>

    //vid
    var docBranchId = "<%=docBranchId%>";

    var currentActKey = "<%=currentActKey%>";

    var currentActKeyOne = "<%=1%>";

    var oid = "<%=oid%>"

    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'pcbApply'
            }]
        });
    });
</script>

</body>
</html>