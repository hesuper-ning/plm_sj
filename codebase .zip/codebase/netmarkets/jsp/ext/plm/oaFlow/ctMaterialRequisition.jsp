<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@page import="java.util.*,wt.workflow.work.*,wt.fc.Persistable,wt.doc.WTDocument"%>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="ext.plm.oaFlow.materialRequisition.config.CtMRProperties" %>
<html>
<head>

    <%
        String oid = request.getParameter("oid");
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workItem = (WorkItem)rf.getReference(oid).getObject();
        WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
        String actName = activity.getName();//工作流程节点的名字
        System.out.println("actName"+actName);

        String currentActKey = CtMRProperties.getActivityNodeName(actName);
        WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);//获取文档
        String containerOid = ext.plm.util.CtWTObjectUtil.getOid(doc.getContainer());//获得容器的id

        System.out.println(">>>>>>containerOid:"+containerOid);
        long branchId = doc.getBranchIdentifier();//获取文档id

        //编辑权限判断
        boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workItem,
                CtMRProperties.getProperty("materialRequisition_materialRequisition_allowEdit_roles"));

        boolean procurementAllowEdit = CtWorkFlowUtil.hasEditAccess(workItem,
                CtMRProperties.getProperty("materialRequisition_materialRequisition_allowEdit1_roles"));
        System.out.println(">>>>>>>>>>allowEdit="+allowEdit + ">>>>>>>procurementAllowEdit=" + procurementAllowEdit);


        //打印页面信息，有用
        System.out.println(">>>>>>>>> ec jsp actName="+actName+">>>>currentActKey="+currentActKey
                +">>>>>branchId="+branchId+">>>workItemOid="+oid);

        boolean taskCompleted = false; //任务是否已完成
        if(workItem.isComplete()) {
            taskCompleted = true;
        }
    %>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <!-- ExtJS -->

    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>

<%--    <script type="text/javascript" src="../mock/js/ctMockFunctions.js"></script>--%>
<%--    <script type="text/javascript" src="../mock/js/ctMockObjects.js"></script>--%>
    <script type="text/javascript" src="js/ctMaterialRequisition.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctMaterialRequisitionFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script>
    //编辑权限
    var allowEdit = false;
    <%if(allowEdit){ %>
    allowEdit = true;
    <%}%>

    var procurementAllowEdit = false;
    <%if(procurementAllowEdit){ %>
    procurementAllowEdit = true;
    <%}%>


    var containerOid = "<%=containerOid%>";
    //认证请求vid
    var branchId = "<%=branchId%>";
    //当前结点key
    var currentActKey = "<%=currentActKey%>";
    //当前的任务完成状态
    var taskCompleted = "<%=taskCompleted%>";
    //oid
    var oid = "<%=oid%>";
    //==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'MaterialRequisitionPanel'
            }]
        });
    });

</script>

</body>
</html>