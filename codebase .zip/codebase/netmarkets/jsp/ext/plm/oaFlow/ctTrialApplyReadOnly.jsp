<%@ page import="ext.plm.util.CtWTObjectUtil"%>
<%@ page import="ext.plm.util.IBAUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="java.util.Date" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.ZoneId" %>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<html>
<head>
<%
    String oid = request.getParameter("oid");
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();

    WTDocument doc = (WTDocument) CtWTObjectUtil.getObjectByOid(oid);

    IBAUtil ibaUtil = new IBAUtil(doc);
    String selectType = ibaUtil.getIBAValue("ct_Trialproductiontype");
    long docBranchId = doc.getBranchIdentifier();
//打印页面信息，有用
    System.out.println(">>>>>>>>> ctTrialApplyReadOnly.jsp >>>>>docBranchId="+docBranchId+">>>oid="+oid + ">>>selectType="+selectType);

    Date date = doc.getCreateTimestamp();
    System.out.println("doc.getCreateTimestamp()======>>>>"+doc.getCreateTimestamp());
    // 要检查的日期
    LocalDate dateToCheck = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(); // 示例日期

    // 设定的基准日期
    LocalDate referenceDate = LocalDate.of(2024, 9, 10);

    // 检查日期是否在基准日期之前
    boolean hideOrShow = dateToCheck.isBefore(referenceDate);

%>

<script type="text/javascript">

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctChangeTrialApply.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctNewTrialApply.js?_dc<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctTrialApplyFunctions.js?_dc<%System.currentTimeMillis();%>"></script>

</head>

<body>
<script>


    var branchId = "<%=docBranchId%>";
    var oid = "<%=oid%>";
    //当前审批结点key
    var currentActKey = "";
    //当前的任务完成状态
    var taskCompleted = true;

    var isFlow = false;
    console.log("<%=selectType%>")

    var hideOrShow = true;
    <%if(hideOrShow){ %>
    hideOrShow = false;
    <%}%>

Ext.onReady(function() {
	 Ext.QuickTips.init();
	 Ext.create('Ext.container.Viewport', {
		    layout: 'border',
		    items: [{
		        region: 'center',
                xtype: "<%=selectType%>"=='新产品试产'?'newTrialApply':'changeTrialApply'
                // xtype: 'newTrialApply'
		    }]
		});
});

</script>

</body>
</html>