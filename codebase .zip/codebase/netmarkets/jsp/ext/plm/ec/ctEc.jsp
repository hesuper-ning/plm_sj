<%@ page import="ext.plm.ec.config.CtEcConstant" %>
<%@ page import="ext.plm.ec.config.CtEcProperties" %>
<%@ page import="ext.plm.util.IBAUtil" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page import="wt.session.SessionHelper" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<%--   变更表单  流程表单 --%>
    <%
        boolean isAdmin = CtUserUtil.isInGroup(SessionHelper.getPrincipal(),"变更表单管理员");
        String workItemOid = request.getParameter("oid");
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
        WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
        String actName = activity.getName();
        String currentActKey = CtEcProperties.getActivityKey(actName);
        wt.change2.WTChangeRequest2 changeRequest = ext.plm.util.CtEcUtil.getChangeRequest(workItem);
        IBAUtil ibaUtil = new IBAUtil(changeRequest);
        String changeType = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_changeType);
        String changeRequestId = rf.getReferenceString(changeRequest);//Vid
        long timestamp = System.currentTimeMillis();
        System.out.println(">>>>>>>>> ec jsp actName="+actName+">>>>currentActKey="+currentActKey
                +">>>>>changeRequestId="+changeRequestId+">>>workItemOid="+workItemOid);

        boolean taskCompleted = false; //任务是否已完成
        if(workItem.isComplete()) {
            taskCompleted = true;
        }

    %>
    <script type="text/javascript">

        var isAdmin = false;
        <%if(isAdmin){%>
          isAdmin = true;
        <%}%>
        //更改类型
        var changeType = "<%=changeType%>";

        var workItemOid = "<%=workItemOid%>";

        //更改请求vid
        var changeRequestId = "<%=changeRequestId%>";

        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";

        //当前的任务完成状态
        var taskCompleted = false;
        <%if(taskCompleted){%>
            taskCompleted = true;
        <%}%>

        var readOnlyPage = false;

        // var url= "/Windchill/netmarkets/jsp/ext/plm/formexport/ctExportForm.jsp?changeRequestId="+changeRequestId;
        // var controll = false;// 下载表单
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctEc.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctEcFunctions.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>


</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'EcPanel',
            }]
        });
    });
</script>
</body>
</html>