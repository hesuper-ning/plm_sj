<%@ page import="ext.plm.ec.config.CtEcConstant" %>
<%@ page import="ext.plm.util.IBAUtil" %>
<%@ page import="wt.change2.ChangeHelper2" %>
<%@ page import="wt.change2.WTChangeActivity2" %>
<%@ page import="wt.change2.WTChangeOrder2" %>
<%@ page import="wt.change2.WTChangeRequest2" %>
<%@ page import="wt.fc.QueryResult" %>
<%@ page import="wt.session.SessionHelper" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<%--  变更表单  只读表单  --%>
    <%
        boolean isAdmin = CtUserUtil.isInGroup(SessionHelper.getPrincipal(),"变更表单管理员");
        String changeRequestOId = request.getParameter("oid");
        String changeRequestId = ""; //VR:wt.change2.WTChangeRequest2:49186110
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(changeRequestOId).getObject();
        WTChangeRequest2 changeRequest = null;
        if(obj instanceof wt.change2.WTChangeRequest2) {
            changeRequest = (WTChangeRequest2)obj;
            changeRequestId = rf.getReferenceString(changeRequest);
        }else if(obj instanceof WTChangeOrder2){
            WTChangeOrder2 changeOrder = (WTChangeOrder2)obj;
            QueryResult qr =ChangeHelper2.service.getChangeRequest(changeOrder);
            if(qr.hasMoreElements()){
                changeRequest = (WTChangeRequest2)qr.nextElement();
                changeRequestId = rf.getReferenceString(changeRequest);
            }
        }else if(obj instanceof WTChangeActivity2){
            WTChangeActivity2 changeActivity2 = (WTChangeActivity2)obj;
            QueryResult qr = ChangeHelper2.service.getChangeOrder(changeActivity2);
            if(qr.hasMoreElements()){
                WTChangeOrder2 changeOrder = (WTChangeOrder2) qr.nextElement();
                QueryResult qr2 = ChangeHelper2.service.getChangeRequest(changeOrder);
                if(qr2.hasMoreElements()){
                   changeRequest = (WTChangeRequest2) qr2.nextElement();
                   changeRequestId = rf.getReferenceString(changeRequest);
                }
            }
        }
        IBAUtil ibaUtil = new IBAUtil(changeRequest);
        String changeType = ibaUtil.getIBAValue(CtEcConstant.Ct_IBA_changeType);
        String currentActKey = "ReadOnly";
        System.out.println(">>>>currentActKey="+currentActKey+">>>>>changeRequestId="+changeRequestId);
        long timestamp = System.currentTimeMillis();

    %>
    <script type="text/javascript">

        var isAdmin = false;
        <%if(isAdmin){%>
            isAdmin = true;
        <%}%>
        //更改类型
        var changeType = "<%=changeType%>";


        //更改请求vid
        var changeRequestId = "<%=changeRequestId%>";

        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";

        //当前的任务完成状态
        var taskCompleted = true;

        var readOnlyPage = true;

        // var url= "/Windchill/netmarkets/jsp/ext/plm/formexport/ctExportForm.jsp?changeRequestId="+changeRequestId;
        // var controll = false;// 下载表单
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctEc.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctEcFunctions.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>

</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'EcPanel',
            }]
        });
    });
</script>
</body>
</html>