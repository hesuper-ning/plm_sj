//*************************************************************************//
//*********************JS Functions*********************************//
//*************************************************************************//
var head_node='head_node'; //设计更改发起
var rdRep_node = 'rdRep_node';//RD代表   （暂时RD代表兼职SE）
var ebomCharge_node = 'ebomCharge_node';//EBOM变更负责人审核
var mbomCharge_node = 'mbomCharge_node';//MBOM变更负责人审核
var consistencyRisk_node ='consistencyRisk_node';//产品一致性风险识别
var struTechRep_node ='struTechRep_node';//结构技术代表审核
var elecTechRep_node ='elecTechRep_node';//电子技术代表审核
var swTechRep_node ='swTechRep_node';//软件技术代表审核
var hwTechRep_node ='hwTechRep_node';//硬件技术代表审核
var processTechRep_node ='processTechRep_node';//工艺技术代表审核
var pcRep_node ='pcRep_node';//采购代表审核
var pcegRep_node='pcegRep_node';//采购工程师审核
var dateManageEngineer_node ='dateManageEngineer_node';//数据管理工程师审核
var dateManageMajor_node ='dateManageMajor_node';//产品数据管理主管审核
var deviceEngineer_node ='deviceEngineer_node';//器件工程师审核
var mnfRep_node ='mnfRep_node';//制造代表审核
var qualityRep_node ='qualityRep_node';//质量代表审核
var mcRep_node ='mcRep_node';//物控代表审核
var pm_node ='pm_node';//产品工程部经理审核
var tm_node ='tm_node';//技术部经理审核
var pdt2_node ='pdt2_node';//变更流程_PDT经理审核
var pdt_node ='pdt_node';//变更流程_CCB评审意见汇总人汇总评审意见
var ccb_node ='ccb_node';//CCB主任批准
var ipmt_node ='ipmt_node';//IPMT副主任方案批准
var result_node ='result_node';//变更监控与闭环
var eCaEbomCharge_node ='eCaEbomCharge_node';//EBOM更改任务ECA_EBOM负责人
var eCaEbomCharge2_node ='eCaEbomCharge2_node';//EBOM更改任务ECA_EBOM负责人 再次确认EBOM更改方案
var eCaDataProcessor_node ='eCaDataProcessor_node';//EBOM更改任务ECA_资料员
var eCaTrialRespon_node ='eCaTrialRespon_node';//EBOM更改任务ECA_试产责任人
var eCaDataProcessor2_node ='eCaDataProcessor2_node';//EBOM更改任务ECA_资料员审核
var mCaEbomCharge_node ='mCaEbomCharge_node';//MBOM更改任务ECA_EBOM负责人
var mCaMbomCharge_node ='mCaMbomCharge_node';//MBOM更改任务ECA_MBOM负责人 再次确认MBOM更改方案
var mCaPdt_node ='mCaPdt_node';//MBOM更改任务ECA_PDT经理批准
var mCaDataProcessor_node ='mCaDataProcessor_node';//MBOM更改任务ECA_产品数据管理工程师
var mCaMCM_node ='mCaMCM_node';//MBOM更改任务ECA_物控经理审批
var mCaMCRep_node ='mCaMCRep_node';//MBOM更改任务ECA_物控代表审批
var mCaPCRep_node ='mCaPCRep_node';//MBOM更改任务ECA_采购代表审批
var mCaQCRep_node ='mCaQCRep_node';//MBOM更改任务ECA_质控代表审批
var mCaTechnology_node ='mCaTechnology_node';//MBOM更改任务ECA_技术代表审批
var mCaProduction_node ='mCaProduction_node';//MBOM更改任务ECA_生产代表审批
var mCaFinance_node ='mCaFinance_node';//MBOM更改任务ECA_财务代表审批
var mCaGylxscbb_node ='mCaGylxscbb_node';//MBOM更改任务ECA_工艺路线生产版本
var ignore_node = 'ignore_node';//MBOM更改任务ECA_MBOM负责人确认BOM数据正确性


//数据加载标志位，控制radioGroup的change事件，防止加载时触发后台保存
var ct_dataLoadedFlag = false;

//更改类型适用场景
var quickChange1_Scene =  ' - 仅适用于修改原材料在已生效状态、半成品在试产/量产转态下的属性，且修改的属性不影响T开头的技术类交付文件<br>'+
	 				' - 属性更改字段：物料描述、研发描述（各拼接属性字段）';
var quickChange2_Scene =  ' - 修改文档（例如：工艺单独更改），不影响物料，库存、采购订单，销售订单，BOM<br>'+
					' - 使用变更流程或修订二选一（图纸、文档）<br>'+
					' - 使用变更流程或修订二选一（试产工艺文件、量产工艺文件）';
var quickChange3_Scene =  ' - BOM勘误等';
var quickChange4_Scene =  ' - 只影响MBOM的调层、辅料用量调整，增加删除<br>' +
					' - 受影响对象只有M视图的物料';


//************开始****公共方法***************************//

function showTip(value,metaData,record,row,col,store){
	if(value)
		metaData.tdAttr = 'data-qtip="' + value +'"';
	return value;
}

function isNull( str ){
	if (!str) return true;
	if ( str == "" ) return true;
	var regu = "^[ ]+$";
	var re = new RegExp(regu);
	return re.test(str);
}

function isNumber( str ) {
	var reg=/^[0-9]+$/;
	return reg.test(str);
}

var updateTip = function (field) {
	var id = field.getEl().dom.id;
	var val = field.getValue();
	if(isNull(val)){
		return;
	}
	Ext.QuickTips.init();
	// 将一些配置属性应用到此单态
		Ext.apply(Ext.QuickTips.getQuickTip(), {
			maxWidth: 200,
			minWidth: 100,
			showDelay: 50,
			trackMouse: true
		});
	 Ext.QuickTips.register({
		 target: id,//在哪个html元素上显示
		 text: val,//具体要提示的东西
		 width: 200
	 })
};

/**
 * 是否是对应变更类型
 * @param changeType 更改类型
 */
function isChangeType(type) {
	if(changeType.length<5){
		return true;
	}
	if(changeType.indexOf(type)>-1){
		return true;
	}else{
		return false;
	}
};


/**
 * 判断是否可编辑
 * @param node 节点表单key
 */
function disableNode(node) {
	if(taskCompleted == 'true') {
		return true;
	} else {
		if(node == currentActKey) {
			return false;
		} else {
			return true;
		}
	}
};

/**
 * 判断节点表单是否应该展开
 */
function openPanel(node) {
	
	//只读页面全打开
	if(readOnlyPage) {
		return true;
	}
	if(disableNode(node)) {
		return false;
	}else {
		return true;
	}
}



//*********************开始*****表单处理部分*********************************//

//自动保存字段
function autoSaveAtt(attKey,attValue){
	
	 var tempRec = {
			 changeRequestId:changeRequestId,
			 attKey:attKey, //字段key
			 attValue:attValue,//字段值
	     	 activityKey:currentActKey //全局变量，当前活动key
	     };
	     
	     Ext.Ajax.request({
	      		   scope:this,
	      		   async : false, // FALSE 同步访问，防止后台ZEcFormMaster表产生重复数据
	  			   url: '/Windchill/ptc1/ec/autoSaveAtt',
	  			   params:{
	  				   updatedRecords:Ext.encode(tempRec)
	  			   },
	  			   success: function(response, opts) {
	  				      var obj = Ext.decode(response.responseText);
	  				      if(obj['success']){
	  				      }else{
	  				    	  alert(obj['msg']);
	  				      }
	  				},
	  			   failure: function(response, opts) {
	  				    alert('错误：保存信息失败，请检查网络！');
	  			   }
	  			}); //~End of Ajax request
}


//*********************结束*****表单处理部分*********************************//

//*********************开始*****更改内容列表*********************************//





//刷新MBOM变更列表
function refreshMBomChangeStore(){
	Ext.getStore('mBomChangeStore').load({
		  params:{
			  changeRequestId:changeRequestId,
			  type:"mbom"
		  },
			callback: function(records, operation, success) {
		        if(!success){
		        	alert('查询MBOM更改对象列表信息失败，请联系管理员！');
		        }
			}
	});
}
//刷新EBOM变更列表
function refreshEBomChangeStore(){
	Ext.getStore('eBomChangeStore').load({
		params:{
			changeRequestId:changeRequestId,
			type:"ebom"
		},
		callback: function(records, operation, success) {
			if(!success){
				alert('查询EBOM更改对象列表信息失败，请联系管理员！');
			}
		}
	});
}

//刷新物料变更列表
function refreshPartChangeStore(){
	Ext.getStore('partChangeStore').load({
		params:{
			changeRequestId:changeRequestId,
		},
		callback: function(records, operation, success) {
			if(!success){
				alert('查询物料变更内容失败，请联系管理员！');
			}
		}
	});
}

//*********************结束*****更改内容列表*********************************//

//*********************开始*****PCR 采购分析列表*********************************//
//刷新采购分析列表
function refreshPcrMaterialItemsStore(){
	Ext.getStore('pcrMaterialItemsStore').load({
		  params:{
			  changeRequestId:changeRequestId
				},
			callback: function(records, operation, success) {
		        if(!success){
		        	alert('查询采购分析列表信息失败，请联系管理员！');
		        }
			}
	});
}

/**
 * 更改对象信息保存
 * @param tRecord
 */
function doPcrMaterialNumberSave(tRecord){
	var id = tRecord.get('id');
	if(!isNumber(id)){
		id = '';
	}
	var materialNumber = tRecord.get('partNumber');
	var materialName = tRecord.get('partName');
	
	//物料描述没读取成功，说明物料编码不对
	 if(!materialName){
     	alert('请先填入正确的物料编码！');
     	tRecord.reject();
     	return;
     }
     
	 var tempRec = {
			 	id:id,
			 	changeRequestId:changeRequestId,//全局变量
			 	materialNumber:materialNumber,
			 	materialName:materialName
	     };
	     
	     Ext.Ajax.request({
	      		   scope:this,
	  			   url: '/Windchill/ptc1/ec/savePcrMaterialNumber',
	  			   params:{
	  				   updatedRecords:Ext.encode(tempRec)
	  			   },
	  			   success: function(response, opts) {
	  				      var obj = Ext.decode(response.responseText);
	  				      if(obj['success']){
	  				      	if(id!=''){
								tRecord.commit();
							}else{
								//刷新列表store
								refreshPcrMaterialItemsStore();
							}
	  				      	Ext.getCmp('savePcrStatus').setText('保存成功！');
	  				      }else{
	  				    	  alert(obj['msg']);
	  				      }
	  				},
	  			   failure: function(response, opts) {
	  				   alert('错误：保存采购分析信息失败，请检查网络！');
	  			   }
	  			}); //~End of Ajax request
}

/**
 * 采购分析 列表实时保存 （除物料编码列）
 * @param tRecord
 * @param tField
 * @param tValue
 * @param callbackFn
 */
function doPcrMaterialFieldSave(tRecord,tField,tValue,callbackFn){
	
	var id = tRecord.get('id');
	if(!isNumber(id)){
		id='';
	}
	var materialName = tRecord.get('partName');
	
	//更改前后的名称都没有，说明没填正确的对象编码，不允许保存其他列
	 if(!materialName){
     	alert('请先填入正确的物料编码！');
     	tRecord.reject();
     	return;
     }
     
	 var tempRec = {
	     		id:id, //得到当前行所有数据
	     		key:tField, //得到修改列
	     		value:tValue //得到修改列修改后值
	     };
	     
	     Ext.Ajax.request({
	      		   scope:this,
	  			   url: '/Windchill/ptc1/ec/savePcrMaterialField',
	  			   params:{
	  				   updatedRecords:Ext.encode(tempRec)
	  			   },
	  			   success: function(response, opts) {
	  				      var obj = Ext.decode(response.responseText);
	  				      if(obj['success']){
	  				      	if(id!=''){
								tRecord.commit();
							}else{
								refreshPcrMaterialItemsStore();
							}
	  				    	Ext.getCmp('savePcrStatus').setText('保存成功！');

	  				      }else{
	  				    	  alert(obj['msg']);
	  				      }
	  				},
	  			   failure: function(response, opts) {
	  				   alert('错误：保存采购分析信息失败，请检查网络！');
	  			   }
	  			}); //~End of Ajax request
}

//*********************结束*****PCR 采购分析列表*********************************//

//*********************开始*****PMC 物控分析列表*********************************//
//刷新库存和计划分析列表
function refreshPmcMaterialItemsStore(){
	Ext.getStore('pmcMaterialItemsStore').load({
		params:{
			changeRequestId:changeRequestId
		},
		callback: function(records, operation, success) {
			if(!success){
				alert('查询物控分析列表信息失败，请联系管理员！');
			}
		}
	});
}



/**
* 更改对象信息保存
* @param tRecord
*/
function doPmcMaterialNumberSave(tRecord){
	var id = tRecord.get('id');
	var materialNumber = tRecord.get('partNumber');
	var materialName = tRecord.get('partName');
	
	//物料描述没读取成功，说明物料编码不对
	if(!materialName){
   	alert('请先填入正确的物料编码！');
   	return;
   }
   
	 var tempRec = {
			 	id:id,
			 	changeRequestId:changeRequestId,//全局变量
			 	materialNumber:materialNumber,
			 	materialName:materialName
	     };
	     
	     Ext.Ajax.request({
	      		   scope:this,
	  			   url: '/Windchill/ptc1/ec/savePmcMaterialNumber',
	  			   params:{
	  				   updatedRecords:Ext.encode(tempRec)
	  			   },
	  			   success: function(response, opts) {
	  				      var obj = Ext.decode(response.responseText);
	  				      if(obj['success']){
	  				    	tRecord.commit();
	  				    	Ext.getCmp('savePmcStatus').setText('保存成功！');
	  				    	//刷新列表store
	  				    	refreshPmcMaterialItemsStore();
	  				      }else{
	  				    	  alert(obj['msg']);
	  				      }
	  				},
	  			   failure: function(response, opts) {
	  				   alert('错误：保存采购分析信息失败，请检查网络！');
	  			   }
	  			}); //~End of Ajax request
}

/**
* 采购分析 列表实时保存 （除物料编码列）
* @param tRecord
* @param tField
* @param tValue
* @param callbackFn
*/
function doPmcMaterialFieldSave(tRecord,tField,tValue,callbackFn){
	
	var id = tRecord.get('id');
	var materialName = tRecord.get('materialName');
	
	//更改前后的名称都没有，说明没填正确的对象编码，不允许保存其他列
	 if(!materialName){
   	alert('请先填入正确的物料编码！');
   	tRecord.set(tField,'');//设回空值
   	return;
   }
   
	 var tempRec = {
	     		id:id, //得到当前行所有数据
	     		key:tField, //得到修改列
	     		value:tValue //得到修改列修改后值
	     };
	     
	     Ext.Ajax.request({
	      		   scope:this,
	  			   url: '/Windchill/ptc1/ec/savePmcMaterialField',
	  			   params:{
	  				   updatedRecords:Ext.encode(tempRec)
	  			   },
	  			   success: function(response, opts) {
	  				      var obj = Ext.decode(response.responseText);
	  				      if(obj['success']){
	  				    	tRecord.commit();
	  				    	Ext.getCmp('savePmcStatus').setText('保存成功！');
	  				    	if(callbackFn){
	  				    		callbackFn();
	  				    	}
	  				      }else{
	  				    	  alert(obj['msg']);
	  				      }
	  				},
	  			   failure: function(response, opts) {
	  				   alert('错误：保存采购分析信息失败，请检查网络！');
	  			   }
	  			}); //~End of Ajax request
}

//*********************结束*****PMC库存和计划信息*********************************//


//*********************开始*****PDT评审团队审批意见*********************************//
//刷新库存和计划分析列表
function refreshPdtAuditInfoStore(){
	Ext.getStore('pdtAuditInfoStore').load({
		params:{
			changeRequestId:changeRequestId
		},
		callback: function(records, operation, success) {
			if(!success){
				alert('查询PDT审批信息失败，请联系管理员！');
			}
		}
	});
}

// 上传按钮 begin
//传入公共的参数，返回上传附件的代码
function uploadFilefield(fileName,text,node,tetx_name){
	if(text==null || text==""){
		text = "浏览...";
	}

	var inform ={
					xtype:'filefield',
					buttonOnly: true,
					id:fileName,
					name:fileName,
					labelWidth:70,
					hideLabel: true, 
					buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>'+text+'</span>',
					allowBlank: false,
					scope: this,
					listeners:{
						'change':function(fb,newValue,oldValue,opts){
							if(!newValue){
								return;
							}
							var file = document.querySelector('[id='+fileName+'-button-fileInputEl]');
							var formData = new FormData();
							formData.append(fileName+'-button-fileInputEl', file.files[0]);
							fb.reset();//清空表单的值
							var myMask = new Ext.LoadMask({
								msg: '正在上传，请稍候......',
								target:this.findParentByType('panel')
							});
							myMask.show();
							$.ajax({
								url: '/Windchill/ptc1/ec/uploadFiles?changeRequestId='+changeRequestId+'&tetx_name='+tetx_name+"&node="+node,
								type: 'POST',
								cache: false,
								data: formData,
								processData: false,
								contentType: false
							}).done(function(res) {
								myMask.hide();
								var obj = Ext.decode(res);
								var success = obj['success'];
								var msg = obj['msg'];
								if(!success){
									alert(msg);
								}else {
									var fileName = obj['fileName'];
									var value = Ext.getCmp(tetx_name).getValue();
									if(value != null && value != ''){
										fileName = value +"&nbsp;|&nbsp;" + fileName;
									}
									Ext.getCmp(tetx_name).setValue(fileName);
									autoSaveAtt(tetx_name, fileName);
								}
							}).fail(function(res) {
								myMask.hide();
								alert('上传失败！') ;
							});
						}
					}
	};
	return inform;
}

//删除附件
function deleteFilefield(changeRequestId,fileName,tetx_name,node) {
	if(disableNode(node)){
		alert("您没有权限删除其他用户的附件！");
		return;
	}
	// var myMask = new Ext.LoadMask({
	// 	msg: '正在删除，请稍候......',
	// 	target:Ext.getCmp('headPanel')
	// });
	// myMask.show();
	Ext.Ajax.request({
		scope : this,
		async : false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
		url : '/Windchill/ptc1/ec/deleteFiles',
		params : {
			changeRequestId:changeRequestId,fileName:fileName
		},
		success : function(response, opts) {
			// myMask.hide();
			var obj = Ext.decode(response.responseText);
			var success = obj['success'];
			var msg = obj['msg'];
			if(!success){
				alert(msg);
			}else {
				var value = Ext.getCmp(tetx_name).getValue();
				var arr= new Array(); //定义一数组 
				arr=value.split("|"); //字符分割 
				for (i=0;i<arr.length ;i++ ){
					var index = arr[i].indexOf(fileName);
					if (index > -1) {
						arr.splice(i,1);// 删除
					}
				} 
				var result = arr.join("&nbsp;|&nbsp;");
				Ext.getCmp(tetx_name).setValue(result);
				autoSaveAtt(tetx_name, result);
			}
		},
		failure : function(response, opts) {
			// myMask.hide();
			alert('错误：删除附件失败，请检查网络！');
		}
	}); 
}

/**

 刷新表单
 */
function refreshHeadInfo() {
	Ext.Ajax.request({
		scope: this,
		url: '/Windchill/ptc1/ec/refreshHeadInfo',
		method: "POST",
		params: {
			changeRequestId: changeRequestId
		},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if (obj['success']) {
				alert(obj['msg']);
				//设置表单值
				var mainPanel = Ext.getCmp('mainForm');
				mainPanel.getForm().setValues(obj);
			} else {
				alert(obj['msg']);
			}
		},
		failure: function (response, opts) {
			alert('刷新失败，请检查网络！');
		}
	});
}


var win ='';
function showWindows(title,message){
	if(win){
		win.close();
		win ='';
		return;
	}
	win = Ext.create('Ext.window.Window',{  
        id:'mywin',   //如果给组件加了一个id，那么这个组件就会被Ext所管理  
        title:title+'示例',  
        height:200, 
        bodyStyle:'background-color:#ffffff',
        width:500,  
        renderTo:Ext.getBody(),
        items:[{
        	xtype : 'displayfield',
			value : message
        }],
//        closeAction : 'hide',
    	closable : true,// 是否有关闭
    	collapsible : true,// 可折叠
    	listeners: {'close':{fn: makesure}},
        maximizable :true // 显示bai最大化按钮在右上角
    });  
	win.show();
}
function makesure(){
	win ='';
}

/**
 * 导出
 */
function exportBomDifferent(partNumbers) {
	// 获取XMLHttpRequest
	var xmlHttpRequest = new XMLHttpRequest();
	//  发起请求
	xmlHttpRequest.open("POST", '/Windchill/ptc1/bom/exportBomDifferent?changeRequestId='+changeRequestId, true);
	// 设置请求头类型
	xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
	xmlHttpRequest.responseType = "blob";
	//  返回
	xmlHttpRequest.onload = function (oEvent) {
		var content = xmlHttpRequest.response;
		if (content.type == 'application/json') {
			content.text().then(res => {
				alert(Ext.decode(res).message)
			})
		} else {
			var timestamp =new Date().getTime();
			// 组装a标签
			var elink = document.createElement("a");
			// 设置下载文件名
			var fileNamePrefix = 'EBOM和MBOM差异';
			elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
			elink.style.display = "none";
			var blob = new Blob([content]);
			elink.href = URL.createObjectURL(blob);
			document.body.appendChild(elink);
			elink.click();
			document.body.removeChild(elink);
		}
	};
	xmlHttpRequest.send(JSON.stringify(partNumbers));
}
//************结束****提示信息***************************//
