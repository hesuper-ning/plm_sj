Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'EcMock',
        in_objectDesc: '变更表单',
        in_objectKey2: 'EcMock-changeDifferenceGrid',
        in_objectDesc2: 'MBOM变更内容',
        in_objectKey3: 'EcMock-changeProductGrid',
        in_objectDesc3: '更改产品信息',
        in_objectKey4: 'EcMock-changeMaterialGrid',
        in_objectDesc4: '更改原材料信息',
        in_objectKey5: 'EcMock-changeDifferenceGrid2',
        in_objectDesc5: 'EBOM变更内容',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;


       //===========开始 列表部分=======================
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            title: '变更内容',
            titleAlign:'center',
            id: 'mockExampleGrid',
            margin: '20 10 20 10',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},

                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        //===========结束 列表部分=======================
        //========== 开始  ecBOMChangeGrid   ================

        var changeGridStore = Ext.create('PLM.store.MockItemStore', {
            id: 'changeGridStore'
        });

        var cellEditing2 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ecChangeGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing2],
            store: Ext.getStore('changeGridStore'),
            id: 'ecChangeGrid',
            margin: '20 10 20 0',
            title: 'MBOM变更内容',
            titleAlign:'center',
            titleFontSize:16,
            //forceFit: true,
            width:'100%',
            height:500,
            autoScroll: true,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: ecChangeGrid,
                            param_objectKey: me.in_objectKey2,
                            param_objectDesc: me.in_objectDesc2
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '成品编码', dataIndex: 'data18', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '父项编码', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '父项描述', dataIndex: 'data2', width: 100, editor: 'textfield', menuDisabled: true},
                {
                    text: '变更前',menuDisabled: true,width:600,
                    columns: [
                        {text: '物料编码', dataIndex: 'data3', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '物料描述', dataIndex: 'data4', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '位号', dataIndex: 'data5', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '数量', dataIndex: 'data6', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '替代料编码', dataIndex: 'data7', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '优先级', dataIndex: 'data8', width: 100, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,width:600,
                    columns: [
                        {text: '物料编码', dataIndex: 'data9', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '物料描述', dataIndex: 'data10', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '位号', dataIndex: 'data11', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '数量', dataIndex: 'data12', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '替代料编码', dataIndex: 'data13', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '优先级', dataIndex: 'data14', width: 100, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {text: '变更类型', dataIndex: 'data15', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '库存处理初步意见', dataIndex: 'data16', width: 150, editor: 'textfield', menuDisabled: true},
                {text: '备注', dataIndex: 'data17', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ]
        });

        ecChangeGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey2, this.in_objectDesc2, itemId, tField, tValue, callbackFn);

            });

        //========== 结束  ecBOMChangeGrid================

        //========== 开始  ecBOMChangeGrid2================

        var changeGridStore2 = Ext.create('PLM.store.MockItemStore', {
            id: 'changeGridStore2'
        });

        var cellEditing5 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ecChangeGrid2 = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing5],
            store: Ext.getStore('changeGridStore2'),
            id: 'ecChangeGrid2',
            margin: '20 10 20 0',
            title: 'EBOM变更内容',
            titleAlign:'center',
            titleFontSize:16,
            //forceFit: true,
            width:'100%',
            height:500,
            autoScroll: true,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: ecChangeGrid2,
                            param_objectKey: me.in_objectKey5,
                            param_objectDesc: me.in_objectDesc5
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '成品编码', dataIndex: 'data16', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '父项编码', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '父项描述', dataIndex: 'data2', width: 100, editor: 'textfield', menuDisabled: true},
                {
                    text: '变更前',menuDisabled: true,width:600,
                    columns: [
                        {text: '物料编码', dataIndex: 'data3', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '物料描述', dataIndex: 'data4', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '位号', dataIndex: 'data5', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '数量', dataIndex: 'data6', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '替代料编码', dataIndex: 'data7', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '优先级', dataIndex: 'data8', width: 100, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,width:600,
                    columns: [
                        {text: '物料编码', dataIndex: 'data9', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '物料描述', dataIndex: 'data10', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '位号', dataIndex: 'data11', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '数量', dataIndex: 'data12', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '替代料编码', dataIndex: 'data13', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '优先级', dataIndex: 'data14', width: 100, editor: 'textfield', menuDisabled: true},
                    ]
                },
                {text: '变更类型', dataIndex: 'data15', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ]
        });

        ecChangeGrid2.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey5, this.in_objectDesc5, itemId, tField, tValue, callbackFn);

            });

        //========== 结束  ecBOMChangeGrid2================




        //========== 开始  changeProductGrid================

        var changeProductGridStore = Ext.create('PLM.store.MockItemStore', {
            id: 'changeProductGridStore'
        });

        var cellEditing3 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var changeProductGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing3],
            store: Ext.getStore('changeProductGridStore'),
            id: 'changeProductGrid',
            margin: '10 10 20 0',
            // title: '需要更改的产品信息',
            //forceFit: true,
            height:300,
            width:'100%',
            autoScroll: true,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: changeProductGrid,
                            param_objectKey: me.in_objectKey3,
                            param_objectDesc: me.in_objectDesc3
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '物料编码', dataIndex: 'data1', width: 150, editor: 'textfield', menuDisabled: true},
                {text: '物料描述', dataIndex: 'data2', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '库存量', dataIndex: 'data3', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '在外采购订单（PO）', dataIndex: 'data4', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '在外采购（PR）', dataIndex: 'data5', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '供应商名称', dataIndex: 'data6', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '供应商备货', dataIndex: 'data7', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '备注', dataIndex: 'data8', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ]
        });

        changeProductGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey3, this.in_objectDesc3, itemId, tField, tValue, callbackFn);

            });

        //========== 结束  changeProductGrid================

        //========== 开始  changeMaterialGrid================

        var changeMaterialGridStore = Ext.create('PLM.store.MockItemStore', {
            id: 'changeMaterialGridStore'
        });

        var cellEditing4 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var changeMaterialGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing4],
            store: Ext.getStore('changeMaterialGridStore'),
            id: 'changeMaterialGrid',
            margin: '10 10 20 0',
            // title: '需要更改的物料信息',
            height:300,
            width:'100%',
            autoScroll: true,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: changeMaterialGrid,
                            param_objectKey: me.in_objectKey4,
                            param_objectDesc: me.in_objectDesc4
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '物料编码', dataIndex: 'data1', width: 150, editor: 'textfield', menuDisabled: true},
                {text: '物料描述', dataIndex: 'data2', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '库存量', dataIndex: 'data3', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '在制量', dataIndex: 'data4', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '维修周转品数量', dataIndex: 'data5', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '销售订单量', dataIndex: 'data6', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ]
        });

        changeMaterialGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey4, this.in_objectDesc4, itemId, tField, tValue, callbackFn);

            });

        //========== 结束  changeMaterialGrid================


        //表头
        var headPanel =  {
            xtype: 'panel',
            //title: '组织架构',
            padding: '5',
            border: false,
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{
                html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_申请人（提交）</div>'
                },
                {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: 'ECR编号',
                        id: 'att1',
                        name: 'att1',
                        //value:'05430',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: 'ECR名称',
                        id: 'att2',
                        name: 'att2',
                        //value:'05430',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                },
                {//第二行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '更改类型',
                        id: 'att3',
                        name: 'att3',
                        //value:'05430',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: '更改类别',
                        id: 'att4',
                        name: 'att4',
                        //value:'05430',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                },{//第三行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '变更原因',
                        id: 'att5',
                        name: 'att5',
                        //value:'05430',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    },{
                        xtype: 'textfield',
                        fieldLabel: '变更描述',
                        id: 'att6',
                        name: 'att6',
                        //value:'05430',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                },{//第三行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '产品型号',
                        id: 'att7',
                        name: 'att7',
                        //value:'05430',
                        width: 300,
                        // listeners: {
                        //     blur: function (e) {
                        //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        //     }
                        // }
                    }]
                },{//第四行
                    xtype: 'filefield',
                    name: 'file1',
                    width:500,
                    buttonText:'浏览',
                    fieldLabel: '上传附件',
                    labelWidth:100,
                },{//第五行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 60},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '申请人',
                        id: 'att100',
                        name: 'att100',
                        value:'申请人1',
                        width:300
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请部门',
                        id: 'att101',
                        name: 'att101',
                        value:'申请部门1',
                        width:300
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请时间',
                        id: 'att102',
                        name: 'att102',
                        value:'2021-09-09',
                        width:300
                    }]
                },{//第六行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批结束时间',
                        id: 'att103',
                        name: 'att103',
                        value:'2021-08-09'

                    }]
                },{
                html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_SE、EBOM负责人、MBOM负责人（变更方案与更改对象）</div>'
            },{//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '受影响的成品',
                        id: 'att8',
                        name: 'att8',
                        //value:'05430',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                },{//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '需更改的物料、BOM',
                        id: 'att9',
                        name: 'att9',
                        //value:'05430',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                },{//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '图纸文档',
                        id: 'att10',
                        name: 'att10',
                        //value:'05430',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                },{//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: 'EBOM更改方案',
                        id: 'att11',
                        name: 'att11',
                        //value:'05430',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                            }
                        }
                    }]
                },ecChangeGrid2,
                ecChangeGrid,
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'SE审批人',
                        id: 'att110',
                        name: 'att110',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att300',
                        name: 'att300',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att111',
                        name: 'att111',
                        value:'2021-02-09',
                        width: 300,

                    }]
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'EBOM负责人',
                        id: 'att113',
                        name: 'att113',
                        value:'负责人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att201',
                        name: 'att201',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att114',
                        name: 'att114',
                        value:'2021-09-02',
                        width: 300,

                    }]
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'MBOM负责人',
                        id: 'att115',
                        name: 'att115',
                        value:'负责人2',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att202',
                        name: 'att202',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att116',
                        name: 'att116',
                        value:'2021-09-02',
                        width: 300,

                    }]
                },
                {
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_产品管理部（一致性）</div>'
            },{
                xtype: 'textarea',
                labelWidth: 100,
                fieldLabel: '一致性风险识别意见',
                name: 'att12',
                id: 'att12',
                width: 800,
                listeners: {
                    blur: function (e) {
                        saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    }
                }
            },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att117',
                        name: 'att117',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att203',
                        name: 'att203',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att118',
                        name: 'att118',
                        value:'2021-02-02',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：制造代表</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att13',
                    id: 'att13',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att119',
                        name: 'att119',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att204',
                        name: 'att204',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att120',
                        name: 'att120',
                        value:'2021-02-03',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：结构代表</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att14',
                    id: 'att14',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'radiogroup',
                        fieldLabel: '是否涉及模具的更改',
                        labelWidth:130,
                        name: 'r1',
                        id: 'r1',
                        width:300,
                        columns:[70,70],
                        items: [
                            { boxLabel: '是', name: 'r11', inputValue: '是',checked:true ,disabledCls:'none'},
                            { boxLabel: '否', name: 'r11', inputValue: '否' , disabledCls:'none'},
                        ]
                    }]
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att121',
                        name: 'att121',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att205',
                        name: 'att205',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att122',
                        name: 'att122',
                        value:'2021-03-04',
                        width: 300,

                    }]
                }, {
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：电子代表</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att15',
                    id: 'att15',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att123',
                        name: 'att123',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att206',
                        name: 'att206',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att124',
                        name: 'att124',
                        value:'2021-02-03',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：硬件代表</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att16',
                    id: 'att16',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att125',
                        name: 'att125',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att207',
                        name: 'att207',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att126',
                        name: 'att126',
                        value:'2021-09-03',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：软件代表</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att30',
                    id: 'att30',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att127',
                        name: 'att127',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att208',
                        name: 'att208',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att128',
                        name: 'att128',
                        value:'2021-08-23',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：工艺代表</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att17',
                    id: 'att17',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att129',
                        name: 'att129',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att209',
                        name: 'att209',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att130',
                        name: 'att130',
                        value:'2021-04-03',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：质量代表</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att18',
                    id: 'att18',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att131',
                        name: 'att131',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att210',
                        name: 'att210',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att132',
                        name: 'att132',
                        value:'2021-09-20',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：数据管理工程师</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att19',
                    id: 'att19',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att133',
                        name: 'att133',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att211',
                        name: 'att211',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att134',
                        name: 'att134',
                        value:'2021-02-20',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：采购代表</div>'
                },changeProductGrid,{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att20',
                    id: 'att20',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att135',
                        name: 'att135',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att212',
                        name: 'att212',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att136',
                        name: 'att136',
                        value:'2021-09-02',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_CCB评审团队：物控代表</div>'
                },changeMaterialGrid,{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att21',
                    id: 'att21',
                    width: 800,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att200',
                        name: 'att200',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att213',
                        name: 'att213',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att137',
                        name: 'att137',
                        value:'2021-09-02',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_PDT经理（ECR批准）</div>'
                },
                {
                    html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;text-align:left">成品处理方案</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '1.库存成品处理方案',
                    name: 'att22',
                    id: 'att22',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '2.在制品的处理方案',
                    name: 'att23',
                    id: 'att23',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '3.维修周转品的处理方案',
                    name: 'att24',
                    id: 'att24',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '4.已发货产品处理方案',
                    name: 'att25',
                    id: 'att25',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '5.已录销售订单但未生产的产品处理方案',
                    name: 'att26',
                    id: 'att26',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                },{
                    html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;text-align:left">拟更改物料处理方案</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '1.库存物料的处理方案',
                    name: 'att27',
                    id: 'att27',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '2.在外采购订单(PO)的处理方案',
                    name: 'att28',
                    id: 'att28',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '3.在外采购订单(PR)的处理方案',
                    name: 'att29',
                    id: 'att29',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                        }
                    }

                },{
                    xtype: 'textarea',
                    labelWidth: 150,
                    fieldLabel: '4.供应商的处理方案',
                    name: 'att220',
                    id: 'att220',
                    rows:2,
                    width: 900,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }

                },{//第四行
                    xtype: 'filefield',
                    name: 'file11',
                    width:500,
                    buttonText:'浏览',
                    fieldLabel: '上传附件',
                    labelWidth:100,
                },{//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'radiogroup',
                        fieldLabel: '是否需要进行小批量验证',
                        labelWidth:150,
                        name: 'r2',
                        id: 'r2',
                        width:400,
                        columns:[50,50],
                        items: [
                            { boxLabel: '是', name: 'r21', inputValue: '是',checked:true ,disabledCls:'none'},
                            { boxLabel: '否', name: 'r21', inputValue: '否' , disabledCls:'none'},
                        ]
                    }]
                },{
                    xtype: 'radiogroup',
                    fieldLabel: '试产验证类型',
                     labelWidth:120,
                    name: 'r3',
                    id: 'r3',
                    width:500,
                    columns:[170,200],
                    items: [
                        { boxLabel: '新品验证(产品工程部)', name: 'r31', inputValue: 'V1',checked:true ,disabledCls:'none'},
                        { boxLabel: '设计更改验证(技术部)', name: 'r31', inputValue: 'V2' , disabledCls:'none'},
                    ]
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '评审意见',
                    name: 'att138',
                    id: 'att138',
                    width: 500,
                    rows:2,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att139',
                        name: 'att139',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att214',
                        name: 'att214',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att140',
                        name: 'att140',
                        value:'2021-02-02',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_IPMT副主任审批（ECR批准）</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att141',
                    id: 'att141',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att142',
                        name: 'att142',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att215',
                        name: 'att215',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att143',
                        name: 'att143',
                        value:'2021-03-02',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">EBOM更改任务ECA_EBOM负责人（EBOM更改信息）</div>'
                },{
                    xtype: 'filefield',
                    name: 'file2',
                    width:600,
                    fieldLabel: '提供附件',
                    buttonText: '浏览',
                    labelWidth:110,
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att144',
                    id: 'att144',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att145',
                        name: 'att145',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att216',
                        name: 'att216',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att146',
                        name: 'att146',
                        value:'2021-02-03',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">EBOM更改任务ECA_资料员(如需要试产，则直接更改SAP试产BOM；如不需要试产，则更改EBOM数据，同步等待结构/电子图纸更改)</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att147',
                    id: 'att147',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att148',
                        name: 'att148',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att217',
                        name: 'att217',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att149',
                        name: 'att149',
                        value:'2021-09-09',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">EBOM更改任务ECA_试产责任人（判定试产结论）</div>'
                },{
                    xtype: 'textfield',
                    fieldLabel: '小批量试产验证文档编号',
                    id: 'att150',
                    name: 'att150',
                    //value:'05430',
                    width: 300,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                xtype: 'radiogroup',
                fieldLabel: '试产结论',
                labelWidth:100,
                name: 'r4',
                id: 'r4',
                width:600,
                columns:[100,180],
                items: [
                    { boxLabel: '试产合格', name: 'r41', inputValue: 'A',checked:true ,disabledCls:'none'},
                    { boxLabel: '不合格,修改方案再次试产', name: 'r41', inputValue: 'B' , disabledCls:'none'},
                ]
            },{
                xtype: 'textarea',
                labelWidth: 100,
                fieldLabel: '不合格结论',
                name: 'att151',
                id: 'att151',
                width: 800,
                // listeners: {
                //     blur: function (e) {
                //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                //     }
                // }
            },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att152',
                        name: 'att152',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att218',
                        name: 'att218',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att153',
                        name: 'att153',
                        value:'2021-02-09',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">EBOM更改任务ECA_资料员审核(更改EBOM数据，同步等待结构/电子图纸更改)</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att154',
                    id: 'att154',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att155',
                        name: 'att155',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att219',
                        name: 'att219',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att156',
                        name: 'att156',
                        value:'2021-09-02',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">MBOM更改任务ECA_EBOM负责人（确认EBOM更改完成）</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '处理方式',
                    name: 'att157',
                    id: 'att157',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att158',
                        name: 'att158',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att220',
                        name: 'att220',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att159',
                        name: 'att159',
                        value:'2021-08-08',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">MBOM更改任务ECA_MBOM负责人（更改MBOM数据及库存处理方式）</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '处理方式',
                    name: 'att160',
                    id: 'att160',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att161',
                        name: 'att161',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att221',
                        name: 'att221',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att162',
                        name: 'att162',
                        value:'2021-04-03',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">MBOM更改任务ECA_PDT经理批准（确认库存处理方式）</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '处理方式意见',
                    name: 'att163',
                    id: 'att163',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att164',
                        name: 'att164',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att222',
                        name: 'att222',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att165',
                        name: 'att165',
                        value:'2021-06-05',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">MBOM更改任务ECA_物控经理（BOM更改生效日期）</div>'
                },{
                    xtype: 'datefield',
                    labelWidth: 120,
                    format:'Y-m-d',
                    fieldLabel: 'BOM更改生效时间',
                    value:'2021-03-02',
                    name: 'att166',
                    id: 'att166',
                    width: 400,

                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '审批意见',
                    name: 'att167',
                    id: 'att167',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att168',
                        name: 'att168',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att223',
                        name: 'att223',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att169',
                        name: 'att169',
                        value:'2021-08-02',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">MBOM更改任务ECA_物控/采购/质控（更改方案执行反馈）</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '变更方案执行反馈',
                    name: 'att170',
                    id: 'att170',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '物控审批人',
                        id: 'att171',
                        name: 'att171',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att224',
                        name: 'att224',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att172',
                        name: 'att172',
                        value:'2021-09-02',
                        width: 300,

                    }]
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '变更方案执行反馈',
                    name: 'att173',
                    id: 'att173',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '采购审批人',
                        id: 'att174',
                        name: 'att174',
                        value:'审批人2',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att225',
                        name: 'att225',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att175',
                        name: 'att175',
                        value:'2021-04-02',
                        width: 300,

                    }]
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '变更方案执行反馈',
                    name: 'att176',
                    id: 'att176',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '质控审批人',
                        id: 'att177',
                        name: 'att177',
                        value:'审批人3',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att226',
                        name: 'att226',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att178',
                        name: 'att178',
                        value:'2021-05-02',
                        width: 300,

                    }]
                },{
                    html:'<div style="font-weight:bold ;font-size:16px;top:50px;left:50px;background-color: gainsboro;text-align:left">ECR_变更监控与闭环</div>'
                },{
                    xtype: 'textarea',
                    labelWidth: 100,
                    fieldLabel: '监控结果',
                    name: 'att179',
                    id: 'att179',
                    width: 800,
                    // listeners: {
                    //     blur: function (e) {
                    //         saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    //     }
                    // }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'att180',
                        name: 'att180',
                        value:'审批人1',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'att227',
                        name: 'att227',
                        value:'通过',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'att181',
                        name: 'att181',
                        value:'2021-03-20',
                        width: 300,

                    }]
                }

            ]
        };


        var ecrFormPanel = {
            xtype: 'form',
            id: 'mainForm',
            title: '变更表单信息',
            titleAlign:'center',
            titleFontSize :18,
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            items: [headPanel]
        };

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [ecrFormPanel];
        // this.items = [{
        //     xtype: 'tabpanel',
        //     height: '100%',
        //     header: false,
        //     plain: true,
        //     collapsible: true,
        //     split: true,
        //     activeTab: 0,
        //     items:[
        //         {
        //             title:'变更表单',
        //             border: false,
        //             items:ecrFormPanel
        //         },{
        //             title:'BOM差异列表',
        //             items:ecChangeGrid
        //         }
        //     ]
        // }]

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {

            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc(), callbackFn);
                        }
                    }
                }
            });

            Ext.getStore('changeGridStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey2()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('changeGridStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('changeGridStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey2()
                                , Ext.getCmp('MockExample').getIn_objectDesc2(), callbackFn);
                        }
                    }
                }
            });

            Ext.getStore('changeProductGridStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey3()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('changeProductGridStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('changeProductGridStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey3()
                                , Ext.getCmp('MockExample').getIn_objectDesc3(), callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('changeGridStore2').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey5()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('changeGridStore2').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('changeGridStore2').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey5()
                                , Ext.getCmp('MockExample').getIn_objectDesc5(), callbackFn);
                        }
                    }
                }
            });

            Ext.getStore('changeMaterialGridStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey4()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('changeMaterialGridStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('changeMaterialGridStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey4()
                                , Ext.getCmp('MockExample').getIn_objectDesc4(), callbackFn);
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

