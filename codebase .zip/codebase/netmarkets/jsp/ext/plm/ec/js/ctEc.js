Ext.define('PLM.view.EcPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.EcPanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ecPanel',
    initComponent: function () {
        var me = this;

        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';

        var objValue = "";
        var readOnly = true;
        var type = "";
        //*****弹窗显示值或填写******//
        var editPanel =  Ext.create('Ext.panel.Panel', {
            title: '',
            width: 100,
            id:'editPanel',
            region:'center',
            autoWidth:true,
            items:[{
                xtype:'textarea',
                fieldLabel: '内容',
                id:'editValue',
                width:400,
                height:200,
                maxLength:3000,
                margin:"5 10 0 20",
                labelWidth: 40,
                listeners:{
                    blur:function(){

                    }
                }
            },{
                xtype:'textfield',
                fieldLabel: 'tField',
                id:'tField',
                width:380,
                height:250,
                margin:"5 10 0 40",
                labelWidth: 60,
                hidden:true
            }]
        });

        //********显示值或填写值窗口*********//
        var editWindow = new Ext.Window({
            id: 'editWindow',
            title: '',
            width: 480,
            height: 350,
            draggable: false,
            modal: true,
            closeAction: 'hide',
            items: [editPanel],
            layout:'fit',
            bbar:['->', {
                text: '保存',
                id:"determine",
                handler: function() {
                    if(!readOnly){
                        var value = Ext.getCmp("editValue").getValue();
                        if(value.length>3000){
                            alert("长度不能超过3000字符!");return;
                        }
                        var key = Ext.getCmp("tField").getValue();
                        var id = objValue.get('id');
                        var tempRec = {
                            id:id, //得到当前行所有数据
                            key:key, //得到修改列
                            value:value, //得到修改列修改后值
                            changeRequestId:changeRequestId,
                            type:type
                        };

                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/ec/saveChangeListField',
                            params:{
                                updatedRecords:Ext.encode(tempRec),
                                workItemOid:workItemOid
                            },
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj['success']){

                                }else{
                                    alert(obj['msg']);
                                }
                                refreshEBomChangeStore();
                                refreshMBomChangeStore();
                            },
                            failure: function(response, opts) {
                                alert('错误：保存失败，请检查网络！');
                            }
                        });
                    }
                    editWindow.hide();
                    objValue="";
                    readOnly=true;
                    type="";
                }
            }]
        });

        Ext.define('affectEPartModel', {
            extend: 'Ext.data.Model',
            fields: ['partNumber','viewName'],
            idProperty: 'id'
        });

        var affectEPartStore = Ext.create('Ext.data.Store', {
            id: 'affectEPartStore',
            model: 'affectEPartModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getAffectedEPart?changeRequestId='+changeRequestId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

        var affectEPartCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            name: 'affectEPartCombo',
            id: 'affectEPartCombo',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore("affectEPartStore"),
            valueField: 'partNumber',
            displayField: 'partNumber',
        });

        var emptyPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            padding:'5',
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%'
        });

        //========== 开始  partChangeGrid================
        Ext.define('partChangeModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','changeRequestId','parentNumber','partNumber','partNameBefore','innerVersionBefore'
                ,'partNameAfter','innerVersionAfter'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.partChangeStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'partChangeModel',
            id:'partChangeStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getPartChangeItems',
                params:{
                    changeRequestId:Ext.encode(changeRequestId),
                },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });



        var partChangeCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var partChangeGrid = Ext.create('Ext.grid.Panel', {
            plugins: [partChangeCellEditing],
            store: Ext.getStore('partChangeStore'),
            id: 'partChangeGrid',
            margin: '20 10 20 0',
            title: '物料变更内容<br>（非以下字段修改，请将修改的"字段信息及值"在“变更描述”中填写，“产品数据工程师”收到ECA后手工修改）',
            titleAlign:'center',
            titleFontSize:16,
            //forceFit: true,
            width:'100%',
            height:'100%',
            autoScroll: true,
            viewConfig:{enableTextSelection:true},
            selModel: Ext.create('Ext.selection.CheckboxModel', {
                id: 'partChangeModel',
                mode: "SIMPLE",
                showHeaderCheckbox: true
            }),
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: 'changeRequestId', dataIndex: 'changeRequestId', menuDisabled: true, hidden: true},
                {text: '父项编码', dataIndex: 'parentNumber', flex: 2, menuDisabled: true
                    ,renderer:showTip
                },
                {text: '物料编码', dataIndex: 'partNumber', flex: 1, editor: disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更1")||disableNode(head_node)||taskCompleted)?null:affectEPartCombo, menuDisabled: true
                    ,renderer:showTip
                },
                {
                    text: '物料变更前',menuDisabled: true,flex: 4,
                    columns: [
                        {text: '物料描述', dataIndex: 'partNameBefore',flex: 3, editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '内部版本', dataIndex: 'innerVersionBefore', flex: 1, editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                    ]
                },
                {
                    text: '物料变更后',menuDisabled: true,flex: 6,
                    columns: [
                        {text: '物料描述', dataIndex: 'partNameAfter', flex: 3, editor: disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更1")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '内部版本(此字段“软件”物料不填写)', dataIndex: 'innerVersionAfter', flex: 3, editor: disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更1")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                    ]
                },
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ],
            tbar: [{
                text: '添加',
                iconCls : 'icon icon-add',
                disabled:disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更1")||disableNode(head_node)||taskCompleted),
                scope: this,
                handler : function(){
                    var rec = new partChangeModel({

                    });
                    this.partChangeStore.insert(0, rec);
                    partChangeCellEditing.startEditByPosition({
                        row: 0,
                        column: 1
                    });
                }
            },'&nbsp;',{
                text : '删除',
                iconCls : 'icon icon-delete',
                disabled:disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更1")||disableNode(head_node)||taskCompleted),
                scope:this,
                handler:function(){
                    var tmpSm = partChangeGrid.getSelectionModel().getSelection();
                    if(!tmpSm||tmpSm==''){
                        Ext.Msg.alert('提示','未选择任何列，请选择要删除的数据！');
                        return;
                    }

                    var delFn = function(){
                        var deleteItems = new Array();//新增项
                        var sm = partChangeGrid.getSelectionModel();
                        partChangeCellEditing.cancelEdit();
                        var tmpStore = Ext.getStore('partChangeStore');
                        tmpStore.remove(sm.getSelection());
                        var removedRecords = tmpStore.getRemovedRecords();

                        Ext.each(removedRecords,function(record){
                            deleteItems.push(record.data);
                        });
                        /*var submitData = {
                         deleteItems: Ext.encode(deleteItems)
                        };*/
                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/ec/deletePartChangeItems',
                            //params: {submitData:Ext.encode(submitData)},
                            params: {deleteItems:Ext.encode(deleteItems),workItemOid:workItemOid},
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);

                                if(obj['success']) {
                                    Ext.getCmp('savePartChangeStatus').setText('删除成功！');
                                }else{
                                    alert(obj['msg']);
                                }
                            },
                            failure: function(response, opts) {
                                alert('错误：删除失败，请检查网络！');
                            }
                        });
                    };//~end of delFn

                    Ext.Msg.confirm('提示','确定要删除选中内容？',
                        function(btn){
                            if(btn =='yes'){
                                delFn();
                            }else{
                                return;
                            }
                        },this);
                }
            },'&nbsp;',{
                text:'',
                id:'savePartChangeStatus',
                disabled:true
            }]//~end of tbar
        });

        partChangeGrid.on('cellclick', function (){
            if(disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更1")||disableNode(head_node)||taskCompleted)){

            }else{
                Ext.getCmp('savePartChangeStatus').setText('正在编辑...');
            }
        });

        partChangeGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var id = tRecord.get('id');
            if(!isNumber(id)) {
                id = '';
            }
            if('partNumber'==tField){
                var tempRec ={
                    id:id,
                    changeRequestId:changeRequestId,
                    value: tValue,
                    key:tField
                }
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/ec/savePartChangeItems',
                    params:{
                        updatedRecords:Ext.encode(tempRec),
                        workItemOid:workItemOid
                    },
                    success: function(response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(!obj['success']){
                            tRecord.reject();
                            alert(obj['msg']);
                            return;//中断
                        }
                        refreshPartChangeStore();
                    },
                    failure: function(response, opts) {
                        alert('网络连接异常，请检查网络！');
                    }
                });
            }else{
                //非对象编码字段的编辑，要求此行已持久化
                if(!id||id==''){
                    alert('请先填入正确的物料编码！');
                    tRecord.reject();
                }else{
                    var partNumber = tRecord.get('partNumber');
                    if(!partNumber){
                        alert('请先填入正确的物料编码！');
                        tRecord.reject();
                        return;
                    }
                    var tempRec = {
                        id:id, //得到当前行所有数据
                        key:tField, //得到修改列
                        value:tValue, //得到修改列修改后值
                        changeRequestId:changeRequestId,
                    };

                    Ext.Ajax.request({
                        scope:this,
                        url: '/Windchill/ptc1/ec/savePartChangeItems',
                        params:{
                            updatedRecords:Ext.encode(tempRec),
                            workItemOid:workItemOid
                        },
                        success: function(response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj['success']){
                                tRecord.commit();
                                Ext.getCmp('savePartChangeStatus').setText('保存成功！');
                            }else{
                                alert(obj['msg']);
                                refreshPartChangeStore();
                                return;
                            }
                        },
                        failure: function(response, opts) {
                            alert('错误：保存信息失败，请检查网络！');
                        }
                    });
                }

            }

        });

        //========== 结束  PartChangeGrid================

        //========== 开始  eBOMChangeGrid=======================
        Ext.define('eBomNeedModel', {
            extend: 'Ext.data.Model',
            fields: ['formInfo'],
            idProperty: 'id'
        });

        var eBomNeedStore = Ext.create('Ext.data.Store', {
            id: 'eBomNeedStore',
            model: 'eBomNeedModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getBomList?changeRequestId='+changeRequestId+'&type=ebom',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: true
        });

        var eBomNeedCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            name: 'eBomGroup',
            id: 'eBomGroup',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore("eBomNeedStore"),
            valueField: 'formInfo',
            displayField: 'formInfo',
        });


        Ext.define('eBomChangeModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','changeRequestId','endPartNumber','parentNumber','parentName','childNumberBefore','childNameBefore','bitNumberBefore','bomRemarksBefore','amountBefore',
                'replaceNumberBefore','priorityBefore','childNumberAfter','childNameAfter','bitNumberAfter','bomRemarksAfter','amountAfter','replaceNumberAfter',
                'priorityAfter','changeType'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.eBomChangeStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'eBomChangeModel',
            id:'eBomChangeStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getChangeItems',
                params:{
                    changeRequestId:Ext.encode(changeRequestId),
                    type:"ebom"
                },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });



        var eBomChangeCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var eBomChangeGrid = Ext.create('Ext.grid.Panel', {
            plugins: [eBomChangeCellEditing],
            store: Ext.getStore('eBomChangeStore'),
            id: 'eBomChangeGrid',
            margin: '20 10 20 0',
            title: 'EBOM变更内容',
            titleAlign:'center',
            titleFontSize:16,
            //forceFit: true,
            width:'100%',
            height:'100%',
            //height:330,
            autoScroll: true,
            viewConfig:{enableTextSelection:true},
            selModel: Ext.create('Ext.selection.CheckboxModel', {
                id: 'eBomChangeModel',
                mode: "SIMPLE",
                showHeaderCheckbox: true
            }),
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: 'changeRequestId', dataIndex: 'changeRequestId', menuDisabled: true, hidden: true},
                {text: '父项所属成品编码', dataIndex: 'endPartNumber', width: 150, menuDisabled: true
                    ,renderer:showTip
                },
                {text: '父项编码', dataIndex: 'parentNumber', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:eBomNeedCombo, menuDisabled: true
                    ,renderer:showTip
                },
                {text: '父项描述', dataIndex: 'parentName', width: 100,menuDisabled: true
                    ,renderer:showTip
                },
                {text: '变更类型', dataIndex: 'changeType', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:{
                        xtype : 'combo',
                        editable : false,
                        forceSelection:true,
                        store : [['增加','增加'],['删除','删除'],['修改','修改']],
                        mode : 'local'
                    } , menuDisabled: true
                    ,renderer:showTip
                },
                {
                    text: '变更前',menuDisabled: true,
                    columns: [
                        {text: '物料编码', dataIndex: 'childNumberBefore', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '物料描述', dataIndex: 'childNameBefore', width: 100, editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '位号', dataIndex: 'bitNumberBefore', width: 100, editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: 'BOM备注', dataIndex: 'bomRemarksBefore', width: 100, editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '数量', dataIndex: 'amountBefore', width: 100, editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '替代组编号', dataIndex: 'replaceNumberBefore', width: 100, editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '替代组优先级', dataIndex: 'priorityBefore', width: 100, editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,
                    columns: [
                        {text: '物料编码', dataIndex: 'childNumberAfter', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '物料描述', dataIndex: 'childNameAfter', width: 100, editor: null , menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '位号(不超过3000个字符)', dataIndex: 'bitNumberAfter', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: 'BOM备注', dataIndex: 'bomRemarksAfter', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '数量', dataIndex: 'amountAfter', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:{xtype:'numberfield',decimalPrecision:8}, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '替代组编号', dataIndex: 'replaceNumberAfter', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '替代组优先级', dataIndex: 'priorityAfter', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:{xtype:'numberfield',minValue:1}, menuDisabled: true
                            ,renderer:showTip
                        },
                    ]
                },
                {text: '备注', dataIndex: 'remark', width: 100, editor: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                    ,renderer:showTip
                },
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ],
            listeners:{
                cellclick:function(obj,td,cellIndex,record,tr,rowIndex,e,eOpts){
                    if(cellIndex=='16'){//变更后位号
                        var orgObjName = record.get('childNameBefore');
                        var newObjName = record.get('childNameAfter');
                        var parentNumber = record.get('parentNumber');
                        //更改前后的名称都没有，说明没填正确的对象编码，不允许编辑
                        if(!orgObjName&&!newObjName&&!parentNumber&&cellIndex=='16'){
                            alert('请先填入正确的父项编码,变更后物料编码！');
                            return false;
                        }
                        var id = record.get("id");
                        if(!isNumber(id))id="";
                        if(!id){//未保存到数据库 说明物料编码列都未填写  不允许编辑
                            alert("请先填写正确的物料编码!");
                            return false;
                        }
                        objValue=record;
                        type="ebom";
                        if(!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)){
                            readOnly=true;
                        }else{
                            readOnly=false;
                        }
                        editWindow.show();
                        Ext.getCmp("editValue").setReadOnly(readOnly);
                        Ext.getCmp("editValue").setValue(record.get("bitNumberAfter"));
                        Ext.getCmp("tField").setValue("bitNumberAfter");
                    }else if(cellIndex=='9'){//变更前位号
                        readOnly=true;
                        editWindow.show();
                        Ext.getCmp("editValue").setReadOnly(readOnly);
                        Ext.getCmp("editValue").setValue(record.get("bitNumberBefore"));
                        Ext.getCmp("tField").setValue("bitNumberBefore");
                    }
                },
                beforeedit: function (editor, e, eOpts) {
                    if(!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)){
                        return false;
                    }else{
                        if(e.field == 'bitNumberAfter'){
                            //控制在弹窗填写
                            return false;
                        }
                    }

                }
            },
            tbar: [{
                text: '添加',
                iconCls : 'icon icon-add',
                disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                scope: this,
                handler : function(){
                    Ext.Ajax.request({
                        scope:this,
                        url: '/Windchill/ptc1/ec/insertBomChangeItems',
                        params: {changeRequestId:changeRequestId,type:"ebom",workItemOid:workItemOid},
                        success: function(response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj['success']) {

                            }else{
                                alert(obj['msg']);
                            }
                            refreshEBomChangeStore();
                        },
                        failure: function(response, opts) {
                            alert('错误：添加失败，请检查网络！');
                        }
                    });
                }
            },'&nbsp;',{
                text : '删除',
                iconCls : 'icon icon-delete',
                disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                scope:this,
                handler:function(){
                    var tmpSm = eBomChangeGrid.getSelectionModel().getSelection();
                    if(!tmpSm||tmpSm==''){
                        Ext.Msg.alert('提示','未选择任何列，请选择要删除的数据！');
                        return;
                    }

                    var delFn = function(){
                        var deleteItems = new Array();//新增项
                        var sm = eBomChangeGrid.getSelectionModel();
                        eBomChangeCellEditing.cancelEdit();
                        var tmpStore = Ext.getStore('eBomChangeStore');
                        tmpStore.remove(sm.getSelection());
                        var removedRecords = tmpStore.getRemovedRecords();

                        Ext.each(removedRecords,function(record){
                            deleteItems.push(record.data);
                        });
                        /*var submitData = {
                         deleteItems: Ext.encode(deleteItems)
                        };*/
                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/ec/deleteChangeItems',
                            //params: {submitData:Ext.encode(submitData)},
                            params: {deleteItems:Ext.encode(deleteItems),type:"ebom",workItemOid:workItemOid},
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);

                                if(obj['success']) {
                                    Ext.getCmp('saveEbomStatus').setText('删除成功！');
                                }else{
                                    alert(obj['msg']);
                                }
                            },
                            failure: function(response, opts) {
                                alert('错误：删除失败，请检查网络！');
                            }
                        });
                    };//~end of delFn

                    Ext.Msg.confirm('提示','确定要删除选中内容？',
                        function(btn){
                            if(btn =='yes'){
                                delFn();
                            }else{
                                return;
                            }
                        },this);
                }
            },'&nbsp;',{
                xtype:'filefield',
                buttonOnly: true,
                disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                id:'upload1',
                hideLabel: true,
                hidden:true,
                buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/> Excel导入</span>',
                allowBlank: false,
                scope: this,
                listeners:{
                    'change':function(fb,newValue,oldValue,opts){
                        if(!newValue){
                            return;
                        }
                        var boms = Ext.getCmp('head_affectedBOMs').getValue();
                        var file = document.querySelector('[id=upload1-button-fileInputEl]');
                        var formData = new FormData();
                        formData.append('upload1-button-fileInputEl', file.files[0]);

                        fb.reset();//清空表单的值
                        var myMask = new Ext.LoadMask({
                            msg: '正在导入数据，请稍候......',
                            target: eBomChangeGrid
                        });

                        myMask.show();
                        $.ajax({
                            url: '/Windchill/ptc1/ec/importChangeItems?changeRequestId='+changeRequestId+'&boms='+boms+'&type=ebom'+'&workItemOid='+workItemOid,
                            type: 'POST',
                            cache: false,
                            data: formData,
                            processData: false,
                            contentType: false
                        }).done(function(res) {
                            myMask.hide();
                            var obj = Ext.decode(res);
                            var success = obj['success'];
                            var msg = obj['msg'];
                            if(!success){
                                alert(msg);
                            }else {
                                refreshEBomChangeStore();
                            }
                        }).fail(function(res) {
                            myMask.hide();
                            alert('导入失败！') ;
                        });
                    }


                }
            },'&nbsp;',{
                text: 'Excel导出',
                hidden:true,
                iconCls : 'icon icon-store-export',
                disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                scope: this,
                handler : function(){
                    var gridSize = eBomChangeGrid.getStore().getTotalCount();
                    if(gridSize == 0){
                        alert("列表没数据,请不用导出！");
                        return;
                    }
                    window.location.href="/Windchill/ptc1/ec/exportChangeItems?changeRequestId="+changeRequestId+"&type=ebom";
                }
            },'&nbsp;',{
                text: '下载模板',
                xtype: 'button',
                hidden:true,
                iconCls : 'icon icon-download',
                disabled:!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted),
                scope: this,
                handler : function(){
                    window.location.href =
                        '/Windchill/ptc1/ec/downLoadTemplate?templateName=EBOM变更内容导入模板';
                }
            },'&nbsp;',{
                text:'',
                id:'saveEbomStatus',
                disabled:true
            }]//~end of tbar
        });

        eBomChangeGrid.on('cellclick', function (){
            if(!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)){

            }else{
                Ext.getCmp('saveEbomStatus').setText('正在编辑...');
            }
        });

        eBomChangeGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var id = tRecord.get('id');
            if(!isNumber(id)) {
                id = '';
            }
            var boms = Ext.getCmp('head_affectedBOMs').getValue();
            //物料编码列编辑
            if('childNumberBefore'==tField||'childNumberAfter'==tField||'parentNumber'==tField){
                var tempRec ={
                    id:id,
                    changeRequestId:changeRequestId,
                    objNumber: tValue,
                    mark:tField,
                    type:"ebom"
                }
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/ec/checkChangeObj',
                    params:{
                        updatedRecords:Ext.encode(tempRec),
                        workItemOid:workItemOid
                    },
                    success: function(response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(!obj['success']){
                            tRecord.reject();
                            alert(obj['msg']);
                            return;//中断
                        }
                        refreshEBomChangeStore();
                    },
                    failure: function(response, opts) {
                        alert('网络连接异常，请检查网络！');
                    }
                });
            }else{
                //非对象编码字段的编辑，要求此行已持久化
                if(!id||id==''){
                    alert('请先填入正确的物料编码！');
                    tRecord.reject();
                }else{
                    var orgObjName = tRecord.get('childNameBefore');
                    var newObjName = tRecord.get('childNameAfter');
                    var parentName = tRecord.get('parentName');
                    //更改前后的名称都没有，说明没填正确的对象编码，不允许保存其他列
                    if(!orgObjName&&!newObjName&&!parentName){
                        alert('请先填入正确的物料编码！');
                        tRecord.reject();
                        return;
                    }
                    var tempRec = {
                        id:id, //得到当前行所有数据
                        key:tField, //得到修改列
                        value:tValue, //得到修改列修改后值
                        changeRequestId:changeRequestId,
                        boms:boms,
                        type:"ebom"
                    };

                    Ext.Ajax.request({
                        scope:this,
                        url: '/Windchill/ptc1/ec/saveChangeListField',
                        params:{
                            updatedRecords:Ext.encode(tempRec),
                            workItemOid:workItemOid
                        },
                        success: function(response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj['success']){
                                tRecord.commit();
                                Ext.getCmp('saveStatus').setText('保存成功！');
                            }else{
                                alert(obj['msg']);
                                refreshEBomChangeStore();
                                return;
                            }
                        },
                        failure: function(response, opts) {
                            alert('错误：保存信息失败，请检查网络！');
                        }
                    });
                }

            }

        });

        //========== 结束  eBOMChangeGrid================

        //========== 开始  mBOMChangeGrid   ================

        Ext.define('mBomNeedModel', {
            extend: 'Ext.data.Model',
            fields: ['formInfo'],
            idProperty: 'id'
        });

        var mBomNeedStore = Ext.create('Ext.data.Store', {
            id: 'mBomNeedStore',
            model: 'mBomNeedModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getBomList?changeRequestId='+changeRequestId+'&type=mbom',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: true
        });

        var mBomNeedCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            name: 'mBomGroup',
            id: 'mBomGroup',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store:Ext.getStore("mBomNeedStore"),
            valueField: 'formInfo',
            displayField: 'formInfo',
        });

        Ext.define('mBomChangeModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','changeRequestId','endPartNumber','parentNumber','parentName','childNumberBefore','childNameBefore','bitNumberBefore','bomRemarksBefore','amountBefore',
                'replaceNumberBefore','priorityBefore','childNumberAfter','childNameAfter','bitNumberAfter','bomRemarksAfter','amountAfter','replaceNumberAfter',
                'priorityAfter','changeType','stockProcessView','remark'
            ],
            idProperty: 'id',
        });

        // create the Data Store
        this.mBomChangeStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'mBomChangeModel',
            id:'mBomChangeStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getChangeItems',
                params:{
                    changeRequestId:Ext.encode(changeRequestId),
                    type:"mbom"
                },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });



        var mBomChangeCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mBomChangeGrid = Ext.create('Ext.grid.Panel', {
            plugins: [mBomChangeCellEditing],
            store: Ext.getStore('mBomChangeStore'),
            id: 'mBomChangeGrid',
            margin: '20 10 20 0',
            title: 'MBOM变更内容',
            titleAlign:'center',
            titleFontSize:16,
            //forceFit: true,
            width:'100%',
            height:'100%',
            autoScroll: true,
            viewConfig:{enableTextSelection:true},
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: 'changeRequestId', dataIndex: 'changeRequestId', menuDisabled: true, hidden: true},
                {text: '父项所属成品编码', dataIndex: 'endPartNumber', width: 150, menuDisabled: true
                    ,renderer:showTip
                },
                {text: '父项编码', dataIndex: 'parentNumber', width: 100, editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:mBomNeedCombo, menuDisabled: true
                    ,renderer:showTip
                },
                {text: '父项描述', dataIndex: 'parentName', width: 100, menuDisabled: true
                    ,renderer:showTip
                },
                {text: '变更类型', dataIndex: 'changeType', width: 100, editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:{
                        xtype : 'combo',
                        editable : false,
                        forceSelection:true,
                        store : [['增加','增加'],['删除','删除'],['修改','修改']],
                        mode : 'local'
                    }, menuDisabled: true
                    ,renderer:showTip
                },
                {
                    text: '变更前',menuDisabled: true,
                    columns: [
                        {text: '物料编码', dataIndex: 'childNumberBefore',  editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '物料描述', dataIndex: 'childNameBefore',  editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '位号', dataIndex: 'bitNumberBefore', editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: 'BOM备注', dataIndex: 'bomRemarksBefore', editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '数量', dataIndex: 'amountBefore',  editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '替代组编号', dataIndex: 'replaceNumberBefore',editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '替代组优先级', dataIndex: 'priorityBefore', editor: null, menuDisabled: true
                            ,renderer:showTip
                        },
                    ]
                },
                {
                    text: '变更后',menuDisabled: true,
                    columns: [
                        {text: '物料编码', dataIndex: 'childNumberAfter',  editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '物料描述', dataIndex: 'childNameAfter',  editor: null , menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '位号(不超过3000个字符)', dataIndex: 'bitNumberAfter',  editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: 'BOM备注', dataIndex: 'bomRemarksAfter',  editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '数量', dataIndex: 'amountAfter', editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:{xtype:'numberfield',decimalPrecision:8}, menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '替代组编码', dataIndex: 'replaceNumberAfter', editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                            ,renderer:showTip
                        },
                        {text: '替代组优先级', dataIndex: 'priorityAfter', editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:{xtype:'numberfield',minValue:1}, menuDisabled: true
                            ,renderer:showTip
                        }
                    ]
                },

                // {text: '库存处理初步意见', dataIndex: 'stockProcessView', width: 150, editor: disableNode(mbomCharge_node)&&disableNode(rdRep_node)?null:'textfield', menuDisabled: true},
                {text: '备注', dataIndex: 'remark', width: 100, editor: !isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)?null:'textfield', menuDisabled: true
                    ,renderer:showTip
                },
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ],
            listeners:{
                cellclick:function(obj,td,cellIndex,record,tr,rowIndex,e,eOpts){
                    if(cellIndex=='16'){//变更后位号
                        var orgObjName = record.get('childNameBefore');
                        var newObjName = record.get('childNameAfter');
                        var parentNumber = record.get('parentNumber');
                        //更改前后的名称都没有，说明没填正确的对象编码，不允许编辑
                        if(!orgObjName&&!newObjName&&!parentNumber&&cellIndex=='16'){
                            alert('请先填入正确的父项编码,变更后物料编码！');
                            return false;
                        }
                        var id = record.get("id");
                        if(!isNumber(id))id="";
                        if(!id){//未保存到数据库 说明物料编码列都未填写  不允许编辑
                            alert("请先填写正确的物料编码!");
                            return false;
                        }
                        objValue=record;
                        type="mbom";
                        if(!isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)){
                            readOnly=true;
                        }else{
                            readOnly=false;
                        }
                        editWindow.show();
                        Ext.getCmp("editValue").setReadOnly(readOnly);
                        Ext.getCmp("editValue").setValue(record.get("bitNumberAfter"));
                        Ext.getCmp("tField").setValue("bitNumberAfter");
                    }else if(cellIndex=='9'){//变更前位号
                        readOnly=true;
                        editWindow.show();
                        Ext.getCmp("editValue").setReadOnly(readOnly);
                        Ext.getCmp("editValue").setValue(record.get("bitNumberBefore"));
                        Ext.getCmp("tField").setValue("bitNumberBefore");
                    }
                },
                beforeedit: function (editor, e, eOpts) {
                    if(!isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)){
                        return false;
                    }else{
                        if(e.field == 'bitNumberAfter'){
                            //控制在弹窗填写
                            return false;
                        }
                    }

                }
            },
            tbar: [{
                text: '添加',
                iconCls : 'icon icon-add',
                disabled:!isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted),
                scope: this,
                handler : function(){
                    Ext.Ajax.request({
                        scope:this,
                        url: '/Windchill/ptc1/ec/insertBomChangeItems',
                        params: {changeRequestId:changeRequestId,type:"mbom",workItemOid:workItemOid},
                        success: function(response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj['success']) {

                            }else{
                                alert(obj['msg']);
                            }
                            refreshMBomChangeStore();
                        },
                        failure: function(response, opts) {
                            alert('错误：添加失败，请检查网络！');
                        }
                    });
                }
            },'&nbsp;',{
                text : '删除',
                iconCls : 'icon icon-delete',
                disabled:!isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted),
                scope:this,
                handler:function(){
                    var tmpSm = mBomChangeGrid.getSelectionModel().getSelection();
                    if(!tmpSm||tmpSm==''){
                        Ext.Msg.alert('提示','未选择任何列，请选择要删除的数据！');
                        return;
                    }

                    var delFn = function(){
                        var deleteItems = new Array();//新增项
                        var sm = mBomChangeGrid.getSelectionModel();
                        mBomChangeCellEditing.cancelEdit();
                        var tmpStore = Ext.getStore('mBomChangeStore');
                        tmpStore.remove(sm.getSelection());

                        var removedRecords = tmpStore.getRemovedRecords();

                        Ext.each(removedRecords,function(record){
                            deleteItems.push(record.data);
                        });


                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/ec/deleteChangeItems',
                            params: {deleteItems:Ext.encode(deleteItems),type:"mbom",workItemOid:workItemOid},
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj['success']) {
                                    Ext.getCmp('saveMbomStatus').setText('删除成功！');
                                }else{
                                    alert(obj['msg']);
                                }
                            },
                            failure: function(response, opts) {
                                alert('错误：删除失败，请检查网络！');
                            }
                        });
                    };//~end of delFn

                    Ext.Msg.confirm('提示','确定要删除选中内容？',
                        function(btn){
                            if(btn =='yes'){
                                delFn();
                            }else{
                                return;
                            }
                        },this);
                }
            },'&nbsp;',{
                xtype:'filefield',
                buttonOnly: true,
                disabled:!isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted),
                id:'upload2',
                hideLabel: true,
                hidden:true,
                buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/> Excel导入</span>',
                allowBlank: false,
                scope: this,
                listeners:{
                    'change':function(fb,newValue,oldValue,opts){
                        if(!newValue){
                            return;
                        }
                        var boms = Ext.getCmp('head_affectedBOMs').getValue();
                        var file = document.querySelector('[id=upload2-button-fileInputEl]');
                        var formData = new FormData();
                        formData.append('upload2-button-fileInputEl', file.files[0]);
                        fb.reset();//清空表单的值
                        var myMask = new Ext.LoadMask({
                            msg: '正在导入数据，请稍候......',
                            target: mBomChangeGrid
                        });

                        myMask.show();
                        $.ajax({
                            url: '/Windchill/ptc1/ec/importChangeItems?changeRequestId='+changeRequestId+'&boms='+boms+'&type=mbom'+'&workItemOid='+workItemOid,
                            type: 'POST',
                            cache: false,
                            data: formData,
                            processData: false,
                            contentType: false
                        }).done(function(res) {
                            myMask.hide();
                            var obj = Ext.decode(res);
                            var success = obj['success'];
                            var msg = obj['msg'];
                            if(!success){
                                alert(msg);
                            }else {
                                refreshMBomChangeStore();
                            }
                        }).fail(function(res) {
                            myMask.hide();
                            alert('导入失败！') ;
                        });
                    }


                }
            },'&nbsp;',{
                text: 'Excel导出',
                hidden:true,
                iconCls : 'icon icon-store-export',
                disabled:!isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted),
                scope: this,
                handler : function(){
                    var gridSize = mBomChangeGrid.getStore().getTotalCount();
                    if(gridSize == 0){
                        alert("列表没数据,请不用导出！");
                        return;
                    }
                    window.location.href="/Windchill/ptc1/ec/exportChangeItems?changeRequestId="+changeRequestId+"&type=mbom";
                }
            },'&nbsp;',{
                text: '下载模板',
                hidden:true,
                iconCls : 'icon icon-download',
                disabled:!isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted),
                scope: this,
                handler : function(){
                    window.location.href = '/Windchill/ptc1/ec/downLoadTemplate?templateName=MBOM变更内容导入模板';
                }
            },'&nbsp;',{
                text:'',
                id:'saveMbomStatus',
                disabled:true
            }, '&nbsp;', {
                text: '导出EBOM/MBOM差异',
                iconCls: 'icon icon-excelExport',
                hidden:disableNode(ignore_node),
                scope: this,
                handler : function(){
                    let grid = Ext.getCmp('mBomChangeGrid');
                    //校验是否有选择数据
                    var tmpSm = grid.getSelectionModel().getSelection();
                    if (!tmpSm || tmpSm == '') {
                        Ext.Msg.alert('提示', '请选择要导出的物料！');
                        return;
                    }
                    let numbers;
                    for(let i = 0;i < tmpSm.length;i++){
                        let rowData = tmpSm[i].getData();
                        let partNumber = rowData['parentNumber'];
                        if(i == 0){
                            numbers = partNumber;
                        }else{
                            numbers += ',' + partNumber;
                        }
                    }
                    exportBomDifferent(numbers)
                }
            }
            ]//~end of tbar
        });

        mBomChangeGrid.on('cellclick', function (){
            if(!isAdmin&&disableNode(mbomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更4")||disableNode(head_node)||taskCompleted)){

            }else{
                Ext.getCmp('saveMbomStatus').setText('正在编辑...');
            }

        });

        mBomChangeGrid.on('edit', function (editor, e) {

            var tRecord = e.record; //得到当前行所有数据
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var id = tRecord.get('id');

            if(!isNumber(id)) {
                id = '';
            }
            var boms = Ext.getCmp('head_affectedBOMs').getValue();
            //物料编码列编辑
            if('childNumberBefore'==tField||'childNumberAfter'==tField||'parentNumber'==tField){
                var tempRec ={
                    id:id,
                    changeRequestId:changeRequestId,
                    objNumber: tValue,
                    mark:tField,
                    type:"mbom"
                }
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/ec/checkChangeObj',
                    params:{
                        updatedRecords:Ext.encode(tempRec),
                        workItemOid:workItemOid
                    },
                    success: function(response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(!obj['success']){
                            alert(obj['msg']);
                            tRecord.reject();
                            return;//中断
                        }
                        refreshMBomChangeStore();
                    },
                    failure: function(response, opts) {
                        alert('网络异常，请检查网络！');
                    }
                });
            }else{
                //非对象编码字段的编辑，要求此行已持久化
                if(!id||id==''){
                    alert('请先填入正确的物料编码！');
                    tRecord.reject();
                }else{
                    //触发后台保存
                    var orgObjName = tRecord.get('childNameBefore');
                    var newObjName = tRecord.get('childNameAfter');
                    var parentNumber = tRecord.get('parentNumber');
                    //更改前后的名称都没有，说明没填正确的对象编码，不允许保存其他列
                    if(!orgObjName&&!newObjName&&!parentNumber){
                        alert('请先填入正确的物料编码！');
                        tRecord.reject();
                        return;
                    }
                    var tempRec = {
                        id:id, //得到当前行所有数据
                        key:tField, //得到修改列
                        value:tValue, //得到修改列修改后值
                        changeRequestId:changeRequestId,
                        boms:boms,
                        type:"mbom"
                    };

                    Ext.Ajax.request({
                        scope:this,
                        url: '/Windchill/ptc1/ec/saveChangeListField',
                        params:{
                            updatedRecords:Ext.encode(tempRec),
                            workItemOid:workItemOid
                        },
                        success: function(response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj['success']){
                                tRecord.commit();
                                Ext.getCmp('saveMbomStatus').setText('保存成功！');
                            }else{
                                alert(obj['msg']);
                                refreshMBomChangeStore();
                                return;
                            }
                        },
                        failure: function(response, opts) {
                            alert('错误：保存信息失败，请检查网络！');
                        }
                    });//~End of Ajax request
                }

            }

        });

        //========== 结束  mBOMChangeGrid================


        //========== 开始  采购 pcrMaterialItemsGrid ================
        Ext.define('pcrMaterialItemsModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','partNumber','partName','stock','po','pr','supplierName','supplierStockUp','remark'
            ],
            idProperty: 'id'
        });
        // create the Data Store
        this.pcrMaterialItemsStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'pcrMaterialItemsModel',
            id:'pcrMaterialItemsStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getPcrMaterialItems',
                params:{
                    changeRequestId:Ext.encode(changeRequestId)
                },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            sorters: [{
                property: 'num',
                direction: 'ASC'
            }],
            autoLoad:false
        });


        var pcrCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var pcrMaterialItemsGrid = Ext.create('Ext.grid.Panel', {
            plugins: [pcrCellEditing],
            title: '',
            store:Ext.getStore('pcrMaterialItemsStore'),
            id:'pcrMaterialItemsGrid',
            //forceFit : true,
            width:'100%',
            // width:2500,
            autoScroll:true,
            margin: '10 10 20 0',
            region:'center',
            height:'100%',
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig:{enableTextSelection:true},
            selType: 'checkboxmodel',
            columns: [
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '物料编码', dataIndex: 'partNumber', flex:1, editor:null, menuDisabled: true},
                {text: '物料描述', dataIndex: 'partName', flex:1, editor: null, menuDisabled: true},
                {text: '库存量', dataIndex: 'stock', flex:1, editor: null, menuDisabled: true},
                {text: '在外采购订单（PO）', dataIndex: 'po', flex:1, editor: null, menuDisabled: true},
                {text: '在外采购需求（PR）', dataIndex: 'pr', flex:1, editor: null, menuDisabled: true},
                {text: redStarFlag+blueFlagStart+'供应商名称'+blueFlagEnd, dataIndex: 'supplierName', flex:1, editor:disableNode(pcegRep_node)?null:'textfield', menuDisabled: true},
                {text: redStarFlag+blueFlagStart+'供应商备货'+blueFlagEnd, dataIndex: 'supplierStockUp', flex:1, editor:disableNode(pcegRep_node)?null:'textfield', menuDisabled: true},
                {text: blueFlagStart+'备注'+blueFlagEnd, dataIndex: 'remark', flex:1, editor:disableNode(pcegRep_node)?null:'textfield', menuDisabled: true},
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ],
            tbar: [/*{  不允许添加
                text: '添加',
                iconCls : 'icon icon-add',
                disabled:disableNode(pcRep_node),
                scope: this,
                handler : function(){
                    var rec = new pcrMaterialItemsModel({
                        partNumber:''
                    });
                    this.pcrMaterialItemsStore.insert(0, rec);
                    pcrCellEditing.startEditByPosition({
                        row: 0,
                        column: 2
                    });
                }
            },'&nbsp;',*/
                {
                    text: '自动加入受影响物料',
                    iconCls : 'icon icon-excel',
                    disabled:disableNode(pcRep_node),
                    scope: this,
                    handler : function(){
                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/ec/autoAddPcrMaterials',
                            params:{
                                changeRequestId:Ext.encode(changeRequestId),
                                workItemOid:workItemOid
                            },
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj['success']){
                                    refreshPcrMaterialItemsStore();
                                }else{
                                    alert(obj['msg']);
                                }
                            },
                            failure: function(response, opts) {
                                alert('错误：自动添加受影响物料失败，请检查网络！');
                            }
                        }); //~End of Ajax request
                    }//~end of handler
                },'&nbsp;',{
                    text : '删除',
                    iconCls : 'icon icon-delete',
                    disabled:disableNode(pcRep_node),
                    scope:this,
                    handler:function(){

                        var tmpSm = pcrMaterialItemsGrid.getSelectionModel().getSelection();
                        if(!tmpSm||tmpSm==''){
                            Ext.Msg.alert('提示','未选择任何列，请选择要删除的数据！');
                            return;
                        }

                        var delFn = function(){
                            var deleteItems = new Array();//新增项
                            var sm = pcrMaterialItemsGrid.getSelectionModel();
                            pcrCellEditing.cancelEdit();
                            var tmpStore = Ext.getStore('pcrMaterialItemsStore');
                            tmpStore.remove(sm.getSelection());

                            var removedRecords = tmpStore.getRemovedRecords();

                            Ext.each(removedRecords,function(record){
                                deleteItems.push(record.data);
                            });

                            Ext.Ajax.request({
                                scope:this,
                                url: '/Windchill/ptc1/ec/deletePcrMatItems',
                                params: {deleteItems:Ext.encode(deleteItems),workItemOid:workItemOid},
                                success: function(response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj['success']) {
                                        Ext.getCmp('savePCrStatus').setText('删除成功！');
                                    }else{
                                        alert(obj['msg']);
                                    }
                                },
                                failure: function(response, opts) {
                                    alert('错误：删除失败，请检查网络！');
                                }
                            });
                        };//~end of delFn

                        Ext.Msg.confirm('提示','确定要删除选中内容？',
                            function(btn){
                                if(btn =='yes'){
                                    delFn();
                                }else{
                                    return;
                                }
                            },this);
                    }
                },'&nbsp;',{
                    text:'',
                    id:'savePcrStatus',
                    disabled:true
                }]//~end of tbar

        });

        pcrMaterialItemsGrid.on('cellclick', function (){
            if(disableNode(pcRep_node)){

            }else{
                Ext.getCmp('savePcrStatus').setText('正在编辑...');
            }
        });

        //实时保存列单元格
        pcrMaterialItemsGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var id = tRecord.get('id');
            if(!isNumber(id)) {
                id = '';
            }
            //物料编码列编辑
            if('partNumber'==tField){
                var parts = Ext.getCmp('head_affectedEndParts').getValue(); // 受影响成品
                var boms = Ext.getCmp('head_affectedBOMs').getValue(); // 受影响Bom
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/ec/checkMaterialNumber',
                    params:{
                        partNumber: tValue,
                        changeRequestId:changeRequestId,
                        boms:parts+','+boms,
                        workItemOid:workItemOid
                    },
                    success: function(response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(!obj['success']){
                            alert(obj['msg']);
                            return;//中断
                        }

                        //将值填充入record中,注意ext4.2要用record.set方法才能刷新渲染
                        tRecord.set("partNumber", obj['partNumber']);

                        //开始后台保存编码及名称列
                        doPcrMaterialNumberSave(tRecord);

                    },
                    failure: function(response, opts) {
                        alert('错误：查询物料编码失败，请检查网络！');
                    }
                });
            }else{
                //非对象编码字段的编辑，要求此行已持久化
                if(!id||id==''){
                    alert('请先填入正确的物料编码,再编辑其他列！');
                }else{
                    //触发后台保存
                    doPcrMaterialFieldSave(tRecord,tField,tValue);
                }

            }//~end of if('partNumber'==tField)

        });
        //============== 结束 采购 pcrMaterialItemsGrid ================


        //========== 开始 物控 pmcMaterialItemsGrid ===================
        Ext.define('pmcMaterialItemsModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','partNumber','partName','stock','inMaking','maintain','salesOrder'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.pmcMaterialItemsStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'pmcMaterialItemsModel',
            id:'pmcMaterialItemsStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getPmcMaterialItems',
                params:{
                    changeRequestId:Ext.encode(changeRequestId)
                },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            sorters: [{
                property: 'num',
                direction: 'ASC'
            }],
            autoLoad:false
        });


        var pmcCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var pmcMaterialItemsGrid = Ext.create('Ext.grid.Panel', {
            plugins: [pmcCellEditing],
            title: '',
            store: Ext.getStore('pmcMaterialItemsStore'),
            id:'pmcMaterialItemsGrid',
            margin: '10 10 20 0',
            height:'100%',
            width:'100%',
            autoScroll: true,
            region:'center',
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig:{enableTextSelection:true},
            selType: 'checkboxmodel',
            columns: [
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '物料编码', dataIndex: 'partNumber', flex:1, editor: null, menuDisabled: true},
                {text: '物料描述', dataIndex: 'partName', flex:1, editor: null, menuDisabled: true},
                {text: '库存量', dataIndex: 'stock', flex:1, editor: null, menuDisabled: true},
                {text: '在制量', dataIndex: 'inMaking', flex:1, editor: null, menuDisabled: true},
                {text: '维修周转品数量', dataIndex: 'maintain', flex:1, editor: null, menuDisabled: true},
                {text: '已录销售订单但未生产', dataIndex: 'salesOrder', flex:1, editor: null, menuDisabled: true},
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ],
            tbar: [/*{
                text: '添加',
                iconCls : 'icon icon-add',
                disabled:disableNode(mcRep_node),
                scope: this,
                handler : function(){
                    var rec = new pmcMaterialInfoModel({
                        partNumber:''
                    });
                    this.pmcMaterialItemsStore.insert(0, rec);
                    pmcCellEditing.startEditByPosition({
                        row: 0,
                        column: 3
                    });
                }
            },'&nbsp;',*/{
                text: '自动加入受影响物料',
                iconCls : 'icon icon-excel',
                disabled:disableNode(mcRep_node),
                scope: this,
                handler : function(){
                    Ext.Ajax.request({
                        scope:this,
                        url: '/Windchill/ptc1/ec/autoAddPmcMaterials',
                        params:{
                            changeRequestId:Ext.encode(changeRequestId),
                            workItemOid:workItemOid
                        },
                        success: function(response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj['success']){
                                refreshPmcMaterialItemsStore();
                            }else{
                                alert(obj['msg']);
                            }
                        },
                        failure: function(response, opts) {
                            alert('错误：自动添加受影响物料失败，请检查网络！');
                        }
                    }); //~End of Ajax request
                }//~end of handler
            },'&nbsp;',{
                text : '删除',
                iconCls : 'icon icon-delete',
                disabled:disableNode(mcRep_node),
                scope:this,
                handler:function(){

                    var tmpSm = pmcMaterialItemsGrid.getSelectionModel().getSelection();
                    if(!tmpSm||tmpSm==''){
                        Ext.Msg.alert('提示','未选择任何列，请选择要删除的数据！');
                        return;
                    }

                    var delFn = function(){
                        var deleteItems = new Array();//新增项
                        var sm = pmcMaterialItemsGrid.getSelectionModel();
                        pcrCellEditing.cancelEdit();
                        var tmpStore = Ext.getStore('pmcMaterialItemsStore');
                        tmpStore.remove(sm.getSelection());

                        var removedRecords = tmpStore.getRemovedRecords();

                        Ext.each(removedRecords,function(record){
                            deleteItems.push(record.data);
                        });

                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/ec/deletePmcMatItems',
                            params: {deleteItems:Ext.encode(deleteItems),workItemOid:workItemOid},
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);

                                if(obj['success']) {
                                    Ext.getCmp('savePmcStatus').setText('删除成功！');
                                }else{
                                    alert(obj['msg']);
                                }
                            },
                            failure: function(response, opts) {
                                alert('错误：删除失败，请检查网络！');
                            }
                        });
                    };//~end of delFn

                    Ext.Msg.confirm('提示','确定要删除选中内容？',
                        function(btn){
                            if(btn =='yes'){
                                delFn();
                            }else{
                                return;
                            }
                        },this);
                }//~end of delete handler
            },'&nbsp;',{
                text:'',
                id:'savePmcStatus',
                disabled:true
            }]//~end of tbar

        });

        pmcMaterialItemsGrid.on('cellclick', function (){
            if(disableNode(mcRep_node)){

            }else{
                Ext.getCmp('savePmcStatus').setText('正在编辑...');
            }

        });

        //实时保存列单元格
        pmcMaterialItemsGrid.on('edit', function (editor, e) {
            var tRecord = e.record; //得到当前行所有数据
            var tField = e.field; //得到修改列
            var tValue = e.value; //得到修改列修改后值
            let oldValue = e.originalValue;//旧值
            if ((tValue == oldValue) || (tValue == null && oldValue == '') || (tValue == '' && oldValue == null)) {
                return;//没有修改内容则返回
            }
            var id = tRecord.get('id');
            if(!isNumber(id)) {
                id = '';
            }
            //物料编码列编辑
            if('partNumber'==tField){
                var parts = Ext.getCmp('head_affectedEndParts').getValue(); // 受影响成品
                var boms = Ext.getCmp('head_affectedBOMs').getValue(); // 受影响Bom
                Ext.Ajax.request({
                    url: '/Windchill/ptc1/ec/checkMaterialNumber',
                    params:{
                        partNumber: tValue,
                        changeRequestId:changeRequestId,
                        boms:parts+','+boms,
                        workItemOid:workItemOid
                    },
                    success: function(response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(!obj['success']){
                            alert(obj['msg']);
                            return;//中断
                        }

                        //将值填充入record中,注意ext4.2要用record.set方法才能刷新渲染
                        tRecord.set("partName", obj['materialName']);

                        //开始后台保存编码及名称列
                        doPmcMaterialNumberSave(tRecord);

                    },
                    failure: function(response, opts) {
                        alert('错误：查询物料编码失败，请检查网络！');
                    }
                });
            }else{
                //非对象编码字段的编辑，要求此行已持久化
                if(!id||id==''){
                    alert('请先填入正确的物料编码,再编辑其他列！');
                }else{
                    //触发后台保存
                    doPmcMaterialFieldSave(tRecord,tField,tValue);
                }

            }//~end of if('partNumber'==tField)

        });
        //========== 结束  pmcMaterialItemsGrid================



        //========== 开始   pdtAuditInfoGrid ================
        Ext.define('pdtAuditInfoModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','auditUser','auditTime','auditComment'
            ],
            idProperty: 'id'
        });
        // create the Data Store
        this.pdtAuditInfoStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'pdtAuditInfoModel',
            id:'pdtAuditInfoStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/ec/getPdtAuditInfo',
                params:{
                    changeRequestId:Ext.encode(changeRequestId)
                },
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });

        var pdtAuditInfoGrid = Ext.create('Ext.grid.Panel', {
            title: 'PDT经理审批信息',
            titleAlign:'center',
            store:Ext.getStore('pdtAuditInfoStore'),
            id:'pdtAuditInfoGrid',
            //forceFit : true,
            width:'100%',
            // width:2500,
            autoScroll:true,
            margin: '10 10 20 0',
            region:'center',
            height:300,
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig:{enableTextSelection:true},
            // selType: 'checkboxmodel',
            columns: [
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '审批人', dataIndex: 'auditUser', flex:1, editor:null, menuDisabled: true},
                {text: '审批时间', dataIndex: 'auditTime', flex:1, editor: null, menuDisabled: true},
                {text: '审批信息', dataIndex: 'auditComment', flex:3, editor: null, menuDisabled: true},
                {text: '', dataIndex: '', width: 10, menuDisabled: true}
            ]
        });
        //========== 结束   pdtAuditInfoGrid ================//


        var store1 = [['图纸、文档更改、物料基础视图变更(不影响BOM)','图纸、文档更改、物料基础视图变更(不影响BOM)'],['试产工艺变更','试产工艺变更'],
            ['量产工艺变更','量产工艺变更'],['BOM变更(试产辅料变更)','BOM变更(试产辅料变更)'],['BOM变更(量产辅料变更)','BOM变更(量产辅料变更)']
        ];
        var store2 = [['BOM变更(硬件变更)','BOM变更(硬件变更)'],['BOM变更(软件变更)','BOM变更(软件变更)'],
            ['BOM变更(结构变更)','BOM变更(结构变更)'],['BOM变更(包装变更)','BOM变更(包装变更)'],['BOM变更(多领域变更)','BOM变更(多领域变更)']];

        var changeTypeStore = [['快速变更1（原材料、半成品基础视图更改,仅限物料描述、研发描述（各拼接属性字段））','快速变更1（原材料、半成品基础视图更改,仅限物料描述、研发描述（各拼接属性字段））'],
            ['快速变更2（技术类图纸、技术类文档、试产工艺文件、量产工艺文件变更）','快速变更2（技术类图纸、技术类文档、试产工艺文件、量产工艺文件变更）'],
            ['快速变更3（BOM快速变更）','快速变更3（BOM快速变更）'],
            ['快速变更4（BOM勘误、试产辅料变更、量产辅料变更）','快速变更4（BOM勘误、试产辅料变更、量产辅料变更）'],
            ['完整变更1（BOM变更：硬件）','完整变更1（BOM变更：硬件）'],
            ['完整变更2（BOM变更：软件）','完整变更2（BOM变更：软件）'],
            ['完整变更3（BOM变更：结构）','完整变更3（BOM变更：结构）'],
            ['完整变更4（BOM变更：包装）','完整变更4（BOM变更：包装）'],
            ['完整变更5（BOM变更：多领域）','完整变更5（BOM变更：多领域）']];

        var submitPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            id:'submitPanel',
            title: 'ECR_申请人（提交）',
            padding:'5',
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[
                {//第一行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'ECR编号',
                        id: 'head_ecrNumber',
                        name: 'head_ecrNumber',
                        width: 620,
                    },{
                        xtype: 'displayfield',
                        fieldLabel: 'ECR名称',
                        id: 'head_ecrName',
                        name: 'head_ecrName',
                        width: 620,
                    }]
                },
                {//第二行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        // xtype: disableNode(head_node)&&disableNode(rdRep_node)?'displayfield':'combo',
                        // fieldLabel: disableNode(head_node)&&disableNode(rdRep_node)?'更改类型':redStarFlag+blueFlagStart+'更改类型'+blueFlagEnd,
                        xtype: 'displayfield',
                        fieldLabel: '更改类型',
                        id: 'head_changeType',
                        name: 'head_changeType',
                        width: 620
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '产品型号',
                        id: 'head_productModel',
                        name: 'head_productModel',
                        width: 620,
                    }]
                },{//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '适用场景',
                        id: 'head_applicableScene',
                        name: 'head_applicableScene',
                        width: 2000
                    }]
                },{//第三行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: disableNode(head_node)&&disableNode(dateManageMajor_node)?'displayfield':'textarea',
                        // xtype: 'displayfield',
                        fieldLabel: disableNode(head_node)&&disableNode(dateManageMajor_node)?'变更原因':redStarFlag+blueFlagStart+'变更原因'+blueFlagEnd,
                        // fieldLabel: '变更原因',
                        id: 'head_changeReason',
                        name: 'head_changeReason',
                        width: 620,
                        listeners: {
                            // render : function(p) {
                            //     p.getEl().on('mouseover', function(p1) {
                            //         updateTip(p);
                            //     });
                            // },
                            blur: function (e) {
                                var value = Ext.getCmp('head_changeReason').getValue();
                                //触发后台保存
                                autoSaveAtt('head_changeReason',value);
                            }
                        }
                    },{
                        xtype: disableNode(head_node)&&disableNode(dateManageMajor_node)?'displayfield':'textarea',
                        // xtype: 'displayfield',
                        fieldLabel: disableNode(head_node)&&disableNode(dateManageMajor_node)?'变更描述':redStarFlag+blueFlagStart+'变更描述'+blueFlagEnd,
                        // fieldLabel: '变更描述',
                        id: 'head_changeDesc',
                        name: 'head_changeDesc',
                        width: 620,
                        listeners: {
                            // render : function(p) {
                            //     p.getEl().on('mouseover', function(p1) {
                            //         updateTip(p);
                            //     });
                            // },
                            blur: function (e) {
                                var value = Ext.getCmp('head_changeDesc').getValue();
                                //触发后台保存
                                autoSaveAtt('head_changeDesc',value);
                            }
                        }
                    }]
                },{
                    xtype: 'panel',
                    padding:'2 10 2 10',
                    disabledCls:'none',
                    // disabled:disableNode(head_node),
                    hidden:isChangeType("快速变更1")||isChangeType("快速变更2"),
                    border:false,
                    layout:'hbox',
                    defaults:{ margin:'5 20 0 0',labelWidth:60},
                    items:[{//第四行
                        xtype: 'radiogroup',
                        margin:'5 340 0 0',
                        disabled: disableNode(head_node),
                        disabledCls:'none',
                        fieldLabel: disableNode(head_node)?'是否需要测试报告':redStarFlag+blueFlagStart+'是否需要测试报告'+blueFlagEnd,
                        width: 300,
                        name: 'isSourceGroup',
                        id: 'isSourceGroup',
                        labelWidth: 160,
                        items: [{
                            inputValue: '是',
                            boxLabel: '是',
                            name: 'isSource',
                            disabledCls: 'none'
                        }, {
                            inputValue: '否',
                            boxLabel: '否',
                            name: 'isSource',
                            disabledCls: 'none'
                        }],
                        listeners: {
                            change: function (field, newValue, oldValue) {
                                if (!ct_dataLoadedFlag) {
                                    //阻止加载数据时执行后台保存
                                    return;
                                }
                                var value = newValue.isSource;
                                //触发后台保存
                                autoSaveAtt('isSource', value);
                                if(value&&"是"==value){
                                    Ext.getCmp("head_uploadFile").setDisabled(false);
                                    Ext.getCmp("head_noNeedReason").setDisabled(true);
                                    Ext.DomQuery.selectNode('label[for=head_noNeedReason-inputEl]').innerHTML='不需要测试报告原因';
                                    Ext.DomQuery.selectNode('label[id=head_attatchment-labelEl]').innerHTML=redStarFlag+blueFlagStart+'测试报告文件'+blueFlagEnd;
                                }else{
                                    Ext.getCmp("head_uploadFile").setDisabled(true);
                                    Ext.getCmp("head_noNeedReason").setDisabled(false);
                                    Ext.DomQuery.selectNode('label[for=head_noNeedReason-inputEl]').innerHTML=redStarFlag+blueFlagStart+'不需要测试报告原因'+blueFlagEnd;
                                    Ext.DomQuery.selectNode('label[id=head_attatchment-labelEl]').innerHTML='测试报告文件';
                                }
                            },
                        }
                    },{//第四行
                        xtype: 'radiogroup',
                        hidden:isChangeType("快速变更"),
                        disabled: disableNode(head_node)&disableNode(ebomCharge_node),
                        disabledCls:'none',
                        fieldLabel: disableNode(head_node)&disableNode(ebomCharge_node)?'试产建议':redStarFlag+blueFlagStart+'试产建议'+blueFlagEnd,
                        width: 230,
                        name: 'trialSuggestGroup',
                        id: 'trialSuggestGroup',
                        labelWidth: 95,
                        items: [{
                            inputValue: '是',
                            boxLabel: '是',
                            name: 'trialSuggest',
                            disabledCls: 'none'
                        }, {
                            inputValue: '否',
                            boxLabel: '否',
                            name: 'trialSuggest',
                            disabledCls: 'none'
                        }],
                        listeners: {
                            change: function (field, newValue, oldValue) {
                                if (!ct_dataLoadedFlag) {
                                    //阻止加载数据时执行后台保存
                                    return;
                                }
                                var value = newValue.trialSuggest;
                                //触发后台保存
                                autoSaveAtt('trialSuggest', value);
                                autoSaveAtt('isNeedSmallCheck',value);
                            },
                        }
                    }]
                },{
                    xtype: 'panel',
                    padding:'2 10 2 10',
                    disabledCls:'none',
                    hidden:isChangeType("快速变更1")||isChangeType("快速变更2"),
                    // disabled:disableNode(head_node),
                    border:false,
                    layout:'hbox',
                    defaults:{ margin:'5 20 0 0',labelWidth:60},
                    items:[{
                        xtype: 'displayfield',
                        fieldLabel: '测试报告文件',
                        id: 'head_attatchment',
                        name: 'head_attatchment',
                        width: 50
                    },disableNode(head_node)&&disableNode(dateManageMajor_node)?null:uploadFilefield("head_uploadFile","点击上传",currentActKey,"head_uploadFileRecord"),{
                        xtype:'displayfield',
                        fieldLabel: '附件链接',
                        labelWidth:70,
                        id:'head_uploadFileRecord',
                        name:'head_uploadFileRecord',
                        width:'30%'
                    }]
                },{//第五行
                    xtype: 'panel',
                    layout: 'hbox',
                    hidden:isChangeType("快速变更1")||isChangeType("快速变更2"),
                    defaults: {margin: '5 20 0 0', labelWidth: 60},
                    items: [{
                        xtype: disableNode(head_node)&&disableNode(dateManageMajor_node)?'displayfield':'textarea',
                        fieldLabel: '不需要测试报告原因',
                        disabledCls:'none',
                        id: 'head_noNeedReason',
                        name: 'head_noNeedReason',
                        width: 500,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('head_noNeedReason').getValue();
                                autoSaveAtt('head_noNeedReason',value);
                            }
                        }
                    }]
                },{//第五行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 60},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '申请人',
                        id: 'head_applicant',
                        name: 'head_applicant',
                        width:300
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请部门',
                        id: 'head_applyDept',
                        name: 'head_applyDept',
                        width:300
                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请时间',
                        id: 'head_applyTime',
                        name: 'head_applyTime',
                        width:300
                    }]
                },{//第六行
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批结束时间',
                        id: 'head_auditTime',
                        name: 'head_auditTime',
                    }]
                }]
        });
        var ecPlanAndChangeObjPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_变更方案与更改对象',
            padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{//第*行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    iconCls: 'icon icon-refresh',
                    xtype:'button',
                    text: '刷新表单',
                    id: 'refreshHeadInfo',
                    name: 'refreshHeadInfo',
                    handler:function () {
                        refreshHeadInfo();
                    }
                }]
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype:'displayfield',
                    fieldLabel: '受影响的成品',
                    id: 'head_affectedEndParts',
                    name: 'head_affectedEndParts',
                    width: 500,
                }]
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '需更改的物料、BOM',
                    id: 'head_affectedBOMs',
                    name: 'head_affectedBOMs',
                    width: 500,

                }]
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '图纸文档',
                    id: 'head_affectedDocs',
                    name: 'head_affectedDocs',
                    width: 500,

                }],
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 2 0', labelWidth: 100},
                items: [{
                    xtype: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?'displayfield':'textarea',
                    fieldLabel: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?'EBOM更改方案':redStarFlag+blueFlagStart+'EBOM更改方案'+blueFlagEnd,
                    id: 'rdRep_ebomChangePlan',
                    name: 'rdRep_ebomChangePlan',
                    hidden:isChangeType("快速变更1")||isChangeType("快速变更2")||isChangeType("快速变更4"),
                    width: 500,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('rdRep_ebomChangePlan').getValue();
                            autoSaveAtt('rdRep_ebomChangePlan',value);
                        }
                    }
                }]
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 2 0', labelWidth: 100},
                items: [{
                    xtype: 'panel',
                    padding:'2 10 2 10',
                    disabledCls:'none',
                    border:false,
                    layout:'hbox',
                    defaults:{ margin:'5 20 0 0',labelWidth:60},
                    items:[{
                        xtype: 'displayfield',
                        fieldLabel: !isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?'附件':blueFlagStart+'附件'+blueFlagEnd,
                        id: 'head_attatchment1',
                        name: 'head_attatchment1',
                        width: 50
                    },!isAdmin&&disableNode(ebomCharge_node)&&disableNode(dateManageMajor_node)&&(!isChangeType("快速变更3")||disableNode(head_node)||taskCompleted)?null:uploadFilefield("head_uploadFile1","点击上传",currentActKey,"head_uploadFileRecord1"),{
                        xtype:'displayfield',
                        fieldLabel: '附件链接',
                        labelWidth:70,
                        id:'head_uploadFileRecord1',
                        name:'head_uploadFileRecord1',
                        width:'30%'
                    }]}]
            },isChangeType("完整变更")||isChangeType("快速变更1")?partChangeGrid:null,
                isChangeType("完整变更")||isChangeType("快速变更3")?eBomChangeGrid:null,
                isChangeType("完整变更")||isChangeType("快速变更3")||isChangeType("快速变更4")?mBomChangeGrid:null,
                {
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    hidden:isChangeType("快速变更1")||isChangeType("快速变更2")||isChangeType("快速变更3"),
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'SE审批人',
                        id: 'rdRep_auditUser',
                        name: 'rdRep_auditUser',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'rdRep_auditResult',
                        name: 'rdRep_auditResult',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'rdRep_auditTime',
                        name: 'rdRep_auditTime',
                        value:'',
                        width: 300,

                    }]
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    hidden:isChangeType("快速变更1")||isChangeType("快速变更2")||isChangeType("快速变更3"),
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'EBOM负责人',
                        id: 'ebomCharge_auditUser',
                        name: 'ebomCharge_auditUser',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'ebomCharge_auditResult',
                        name: 'ebomCharge_auditResult',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'ebomCharge_auditTime',
                        name: 'ebomCharge_auditTime',
                        value:'',
                        width: 300,

                    }]
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    hidden:isChangeType("快速变更1")||isChangeType("快速变更2")||isChangeType("快速变更3"),
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'MBOM负责人',
                        id: 'mbomCharge_auditUser',
                        name: 'mbomCharge_auditUser',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'mbomCharge_auditResult',
                        name: 'mbomCharge_auditResult',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'mbomCharge_auditTime',
                        name: 'mbomCharge_auditTime',
                        value:'',
                        width: 300,

                    }]
                }
            ]
        });
        var consistencyRiskPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_产品管理部（一致性）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(consistencyRisk_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(consistencyRisk_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(consistencyRisk_node)?'一致性风险识别意见':redStarFlag+blueFlagStart+'一致性风险识别意见'+blueFlagEnd,
                name: 'consistencyRisk_comment',
                id: 'consistencyRisk_comment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('consistencyRisk_comment').getValue();
                        autoSaveAtt('consistencyRisk_comment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'consistencyRisk_auditUser',
                    name: 'consistencyRisk_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'consistencyRisk_auditResult',
                    name: 'consistencyRisk_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'consistencyRisk_auditTime',
                    name: 'consistencyRisk_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var mnfPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：制造领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(mnfRep_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(mnfRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mnfRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'mnfRep_auditComment',
                id: 'mnfRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mnfRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('mnfRep_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'mnfRep_auditUser',
                    name: 'mnfRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mnfRep_auditResult',
                    name: 'mnfRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mnfRep_auditTime',
                    name: 'mnfRep_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var structPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：结构领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(struTechRep_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(struTechRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(struTechRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'struTechRep_auditComment',
                id: 'struTechRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('struTechRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('struTechRep_auditComment',value);
                    }
                }
            },{//第*行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'radiogroup',
                    fieldLabel: disableNode(struTechRep_node)?'是否涉及模具的更改':redStarFlag+blueFlagStart+'是否涉及模具的更改'+blueFlagEnd,
                    labelWidth:130,
                    disabledCls:'none',
                    disabled:disableNode(struTechRep_node),
                    name: 'struTechRep_isMoldChange',
                    id: 'struTechRep_isMoldChange',
                    width:300,
                    columns:[70,70],
                    items: [
                        { boxLabel: '是', name: 'isMoldChange', inputValue: '是'},
                        { boxLabel: '否', name: 'isMoldChange', inputValue: '否'},
                    ],
                    listeners : {
                        change : function(field,newValue,oldValue){
                            if(!ct_dataLoadedFlag) {
                                //加载阻止数据时执行后台保存
                                return;
                            }
                            //触发后台保存
                            var data = newValue.isMoldChange;
                            autoSaveAtt('isMoldChange',data);
                        }
                    }
                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'struTechRep_auditUser',
                    name: 'struTechRep_auditUser',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'struTechRep_auditResult',
                    name: 'struTechRep_auditResult',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'struTechRep_auditTime',
                    name: 'struTechRep_auditTime',
                    width: 300,

                }]
            }]
        });
        var elecPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：电子领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(elecTechRep_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(elecTechRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(elecTechRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'elecTechRep_auditComment',
                id: 'elecTechRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('elecTechRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('elecTechRep_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'elecTechRep_auditUser',
                    name: 'elecTechRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'elecTechRep_auditResult',
                    name: 'elecTechRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'elecTechRep_auditTime',
                    name: 'elecTechRep_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var hwPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：硬件领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(hwTechRep_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(hwTechRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(hwTechRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'hwTechRep_auditComment',
                id: 'hwTechRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('hwTechRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('hwTechRep_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'hwTechRep_auditUser',
                    name: 'hwTechRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'hwTechRep_auditResult',
                    name: 'hwTechRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'hwTechRep_auditTime',
                    name: 'hwTechRep_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var pmPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：产品工程领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(pm_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(pm_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(pm_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'pm_auditComment',
                id: 'pm_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('pm_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('pm_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'pm_auditUser',
                    name: 'pm_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'pm_auditResult',
                    name: 'pm_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'pm_auditTime',
                    name: 'pm_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var tmPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：技术领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(tm_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(tm_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(tm_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'tm_auditComment',
                id: 'tm_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('tm_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('tm_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'tm_auditUser',
                    name: 'tm_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'tm_auditResult',
                    name: 'tm_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'tm_auditTime',
                    name: 'tm_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var swPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：软件领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(swTechRep_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[ {
                xtype: disableNode(swTechRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(swTechRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'swTechRep_auditComment',
                id: 'swTechRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('swTechRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('swTechRep_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'swTechRep_auditUser',
                    name: 'swTechRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'swTechRep_auditResult',
                    name: 'swTechRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'swTechRep_auditTime',
                    name: 'swTechRep_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var processPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：工艺领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(processTechRep_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(processTechRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(processTechRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'processTechRep_auditComment',
                id: 'processTechRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('processTechRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('processTechRep_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'processTechRep_auditUser',
                    name: 'processTechRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'processTechRep_auditResult',
                    name: 'processTechRep_auditResult',
                    value:'2021-04-03',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'processTechRep_auditTime',
                    name: 'processTechRep_auditTime',
                    width: 300,

                }]
            },]
        });
        var qualityPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：质量领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(qualityRep_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(qualityRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(qualityRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'qualityRep_auditComment',
                id: 'qualityRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('qualityRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('qualityRep_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'qualityRep_auditUser',
                    name: 'qualityRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'qualityRep_auditResult',
                    name: 'qualityRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'qualityRep_auditTime',
                    name: 'qualityRep_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var dateManageEngineerPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：数据管理领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(dateManageEngineer_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(dateManageEngineer_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(dateManageEngineer_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'dateManageEngineer_auditComment',
                id: 'dateManageEngineer_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('dateManageEngineer_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('dateManageEngineer_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'dateManageEngineer_auditUser',
                    name: 'dateManageEngineer_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'dateManageEngineer_auditResult',
                    name: 'dateManageEngineer_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'dateManageEngineer_auditTime',
                    name: 'dateManageEngineer_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });

        var dateManageMajorPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：数据管理领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(dateManageMajor_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(dateManageMajor_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(dateManageMajor_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'dateManageMajor_auditComment',
                id: 'dateManageMajor_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('dateManageMajor_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('dateManageMajor_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'dateManageMajor_auditUser',
                    name: 'dateManageMajor_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'dateManageMajor_auditResult',
                    name: 'dateManageMajor_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'dateManageMajor_auditTime',
                    name: 'dateManageMajor_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var deviceEngineerPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：器件领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(deviceEngineer_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(deviceEngineer_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(deviceEngineer_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'deviceEngineer_auditComment',
                id: 'deviceEngineer_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('deviceEngineer_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('deviceEngineer_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'deviceEngineer_auditUser',
                    name: 'deviceEngineer_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'deviceEngineer_auditResult',
                    name: 'deviceEngineer_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'deviceEngineer_auditTime',
                    name: 'deviceEngineer_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var pcPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：采购领域',
            padding:'5',
            collapsible:true,
            collapsed:!(openPanel(pcRep_node) || openPanel(pcegRep_node)),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[pcrMaterialItemsGrid,{
                xtype: disableNode(pcRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(pcRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'pcRep_auditComment',
                id: 'pcRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('pcRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('pcRep_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'pcRep_auditUser',
                    name: 'pcRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'pcRep_auditResult',
                    name: 'pcRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'pcRep_auditTime',
                    name: 'pcRep_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var mcPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：物控领域',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(mcRep_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[pmcMaterialItemsGrid,{
                xtype: disableNode(mcRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mcRep_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'mcRep_auditComment',
                id: 'mcRep_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mcRep_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('mcRep_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'mcRep_auditUser',
                    name: 'mcRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mcRep_auditResult',
                    name: 'mcRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mcRep_auditTime',
                    name: 'mcRep_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });

        var pdt2Panel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审团队：PDT经理',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(pdt2_node)&&!openPanel(pdt_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[
                pdtAuditInfoGrid
            ]
        });
        var pdtPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB评审意见汇总人',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(pdt_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[
                {
                    html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;text-align:left">成品处理方案</div>'
                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'1.库存成品处理方案':redStarFlag+blueFlagStart+'1.库存成品处理方案'+blueFlagEnd,
                    name: 'pdt_endItemsPlan1',
                    id: 'pdt_endItemsPlan1',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_endItemsPlan1').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_endItemsPlan1',value);
                        }
                    }

                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'2.在制品的处理方案':redStarFlag+blueFlagStart+'2.在制品的处理方案'+blueFlagEnd,
                    name: 'pdt_endItemsPlan2',
                    id: 'pdt_endItemsPlan2',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_endItemsPlan2').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_endItemsPlan2',value);
                        }
                    }

                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'3.维修周转品的处理方案':redStarFlag+blueFlagStart+'3.维修周转品的处理方案'+blueFlagEnd,
                    name: 'pdt_endItemsPlan3',
                    id: 'pdt_endItemsPlan3',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_endItemsPlan3').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_endItemsPlan3',value);
                        }
                    }

                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'4.已发货产品处理方案':redStarFlag+blueFlagStart+'4.已发货产品处理方案'+blueFlagEnd,
                    name: 'pdt_endItemsPlan4',
                    id: 'pdt_endItemsPlan4',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_endItemsPlan4').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_endItemsPlan4',value);
                        }
                    }

                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'5.已录销售订单但未生产的产品处理方案':redStarFlag+blueFlagStart+'5.已录销售订单但未生产的产品处理方案'+blueFlagEnd,
                    name: 'pdt_endItemsPlan5',
                    id: 'pdt_endItemsPlan5',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_endItemsPlan5').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_endItemsPlan5',value);
                        }
                    }

                },{
                    html:'<div style="font-weight:bold ;font-size:14px;top:50px;left:50px;text-align:left">拟更改物料处理方案</div>'
                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'1.库存物料的处理方案':redStarFlag+blueFlagStart+'1.库存物料的处理方案'+blueFlagEnd,
                    name: 'pdt_materialPlan1',
                    id: 'pdt_materialPlan1',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_materialPlan1').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_materialPlan1',value);
                        }
                    }

                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'2.在外采购订单(PO)的处理方案':redStarFlag+blueFlagStart+'2.在外采购订单(PO)的处理方案'+blueFlagEnd,
                    name: 'pdt_materialPlan2',
                    id: 'pdt_materialPlan2',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_materialPlan2').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_materialPlan2',value);
                        }
                    }

                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'3.在外采购订单(PR)的处理方案':redStarFlag+blueFlagStart+'3.在外采购订单(PR)的处理方案'+blueFlagEnd,
                    name: 'pdt_materialPlan3',
                    id: 'pdt_materialPlan3',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_materialPlan3').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_materialPlan3',value);
                        }
                    }

                },{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 150,
                    fieldLabel: disableNode(pdt_node)?'4.供应商的处理方案':redStarFlag+blueFlagStart+'4.供应商的处理方案'+blueFlagEnd,
                    name: 'pdt_materialPlan4',
                    id: 'pdt_materialPlan4',
                    rows:2,
                    width: 900,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_materialPlan4').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_materialPlan4',value);
                        }
                    }

                },{
                    xtype: 'panel',
                    padding:'2 10 2 10',
                    disabledCls:'none',
                    border:false,
                    layout:'hbox',
                    defaults:{ margin:'5 20 0 0',labelWidth:60},
                    items:[{
                        xtype: 'displayfield',
                        fieldLabel: disableNode(pdt_node)?'附件':redStarFlag+blueFlagStart+'附件'+blueFlagEnd,
                        id: 'pdt_attatchment',
                        name: 'pdt_attatchment',
                        width: 50
                    },uploadFilefield("pdt_uploadFile","点击上传",pdt_node,"pdt_uploadFileRecord"),{
                        xtype:'displayfield',
                        fieldLabel: '附件链接',
                        labelWidth:70,
                        id:'pdt_uploadFileRecord',
                        name:'pdt_uploadFileRecord',
                        width:'30%'
                    }]
                },{//第*行
                    xtype: 'panel',
                    layout: 'hbox',
                    hidden:isChangeType("快速变更"),
                    defaults: {margin: '5 20 20 0', labelWidth: 100},
                    items: [{
                        xtype: 'radiogroup',
                        fieldLabel: disableNode(pdt_node)?'是否需要进行小批量验证':redStarFlag+blueFlagStart+'是否需要进行小批量验证'+blueFlagEnd,
                        disabled:disableNode(pdt_node),
                        disabledCls:'none',
                        labelWidth:150,
                        name: 'pdt_isNeedSmallCheck',
                        id: 'pdt_isNeedSmallCheck',
                        width:400,
                        columns:[50,50],
                        items: [
                            { boxLabel: '是', name: 'isNeedSmallCheck', inputValue: '是'},
                            { boxLabel: '否', name: 'isNeedSmallCheck', inputValue: '否'},
                        ],
                        listeners : {
                            change : function(field,newValue,oldValue){
                                if(!ct_dataLoadedFlag) {
                                    //加载阻止数据时执行后台保存
                                    return;
                                }
                                //触发后台保存
                                var data = newValue.isNeedSmallCheck;
                                autoSaveAtt('isNeedSmallCheck',data);
                            }
                        }
                    }]
                },/*{
                    xtype: 'radiogroup',
                    fieldLabel: '试产验证类型',
                    labelWidth:120,
                    disabled:disableNode(pdt_node),
                    disabledCls:'none',
                    name: 'pdt_trialCheckType',
                    id: 'pdt_trialCheckType',
                    width:500,
                    columns:[170,200],
                    items: [
                        { boxLabel: '新品验证(产品工程部)', name: 'trialCheckType', inputValue: 'V1'},
                        { boxLabel: '设计更改验证(技术部)', name: 'trialCheckType', inputValue: 'V2'},
                    ],
                    listeners : {
                        change : function(field,newValue,oldValue){
                            if(!ct_dataLoadedFlag) {
                                //加载阻止数据时执行后台保存
                                return;
                            }
                            //触发后台保存
                            var data = newValue.trialCheckType;
                            autoSaveAtt('trialCheckType',data);
                        }
                    }
                },*/{
                    xtype: disableNode(pdt_node)?'displayfield':'textarea',
                    labelWidth: 100,
                    fieldLabel: disableNode(pdt_node)?'评审意见':redStarFlag+blueFlagStart+'评审意见'+blueFlagEnd,
                    name: 'pdt_auditComment',
                    id: 'pdt_auditComment',
                    width: 500,
                    rows:2,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('pdt_auditComment').getValue();
                            //触发后台保存
                            autoSaveAtt('pdt_auditComment',value);
                        }
                    }
                },{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '审批人',
                        id: 'pdt_auditUser',
                        name: 'pdt_auditUser',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批结果',
                        id: 'pdt_auditResult',
                        name: 'pdt_auditResult',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '审批时间',
                        id: 'pdt_auditTime',
                        name: 'pdt_auditTime',
                        value:'',
                        width: 300,

                    }]
                }]
        });

        var ccbPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_CCB主任（ECR批准）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(ccb_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(ccb_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(ccb_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'ccb_auditComment',
                id: 'ccb_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('ccb_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('ccb_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'ccb_auditUser',
                    name: 'ccb_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'ccb_auditResult',
                    name: 'ccb_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'ccb_auditTime',
                    name: 'ccb_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });

        var ipmtPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_认证技术负责人审批（ECR批准）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(ipmt_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(ipmt_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(ipmt_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'ipmt_auditComment',
                id: 'ipmt_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('ipmt_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('ipmt_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'ipmt_auditUser',
                    name: 'ipmt_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'ipmt_auditResult',
                    name: 'ipmt_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'ipmt_auditTime',
                    name: 'ipmt_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var eCaEbomChargePanel2 = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'EBOM更改任务ECA_EBOM负责人（再次确认EBOM更改方案）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(eCaEbomCharge2_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(eCaEbomCharge2_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(eCaEbomCharge2_node)?'处理方式':redStarFlag+blueFlagStart+'处理方式'+blueFlagEnd,
                name: 'eCaEbomCharge2_handling',
                id: 'eCaEbomCharge2_handling',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('eCaEbomCharge2_handling').getValue();
                        //触发后台保存
                        autoSaveAtt('eCaEbomCharge2_handling',value);
                    }
                }
            },{
                xtype: 'panel',
                padding:'2 10 2 10',
                disabledCls:'none',
                border:false,
                layout:'hbox',
                defaults:{ margin:'5 20 0 0',labelWidth:60},
                items:[{//第四行
                    xtype: 'radiogroup',
                    disabled: disableNode(eCaEbomCharge2_node),
                    disabledCls:'none',
                    fieldLabel: disableNode(eCaEbomCharge2_node)?'ECR方案是否有变化':redStarFlag+blueFlagStart+'ECR方案是否有变化'+blueFlagEnd,
                    width: 350,
                    name: 'isEcrPlanChange2',
                    id: 'isEcrPlanChange2',
                    labelWidth: 200,
                    items: [{
                        inputValue: '是',
                        boxLabel: '是',
                        name: 'isEcrChange2',
                        disabledCls: 'none'
                    }, {
                        inputValue: '否',
                        boxLabel: '否',
                        name: 'isEcrChange2',
                        disabledCls: 'none'
                    }],
                    listeners: {
                        change: function (field, newValue, oldValue) {
                            if (!ct_dataLoadedFlag) {
                                //阻止加载数据时执行后台保存
                                return;
                            }
                            var value = newValue.isEcrChange2;
                            //触发后台保存
                            autoSaveAtt('isEcrChange2', value);
                            if(value&&"是"==value){
                                Ext.getCmp("eCaEbomCharge2_uploadFile").setDisabled(false);
                                Ext.DomQuery.selectNode('label[id=eCaEbomCharge2_attatchment-labelEl]').innerHTML=redStarFlag+blueFlagStart+'ECR《变更前后方案》附件'+blueFlagEnd;
                            }else{
                                Ext.getCmp("eCaEbomCharge2_uploadFile").setDisabled(true);
                                Ext.DomQuery.selectNode('label[id=eCaEbomCharge2_attatchment-labelEl]').innerHTML='ECR《变更前后方案》附件';
                            }
                        },
                    }
                }]
            },{
                xtype: 'panel',
                padding:'2 10 2 10',
                disabledCls:'none',
                border:false,
                layout:'hbox',
                defaults:{ margin:'5 20 0 0',labelWidth:60},
                items:[{
                    xtype: 'displayfield',
                    fieldLabel: 'ECR《变更前后方案》附件',
                    id: 'eCaEbomCharge2_attatchment',
                    name: 'eCaEbomCharge2_attatchment',
                    labelWidth:200
                },uploadFilefield("eCaEbomCharge2_uploadFile","点击上传",eCaEbomCharge2_node,"eCaEbomCharge2_uploadFileRecord"),{
                    xtype:'displayfield',
                    fieldLabel: '附件链接',
                    labelWidth:70,
                    id:'eCaEbomCharge2_uploadFileRecord',
                    name:'eCaEbomCharge2_uploadFileRecord',
                    width:'30%'
                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'eCaEbomCharge2_auditUser',
                    name: 'eCaEbomCharge2_auditUser',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'eCaEbomCharge2_auditResult',
                    name: 'eCaEbomCharge2_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'eCaEbomCharge2_auditTime',
                    name: 'eCaEbomCharge2_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var eCaEbomChargePanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'EBOM更改任务ECA_EBOM负责人（EBOM更改信息）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(eCaEbomCharge_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: 'panel',
                padding:'2 10 2 10',
                disabledCls:'none',
                border:false,
                layout:'hbox',
                defaults:{ margin:'5 20 0 0',labelWidth:60},
                items:[{
                    xtype: 'displayfield',
                    fieldLabel: disableNode(eCaEbomCharge_node)?'附件':blueFlagStart+'附件'+blueFlagEnd,
                    id: 'eCaEbomCharge_attatchment',
                    name: 'eCaEbomCharge_attatchment',
                    width: 50
                },uploadFilefield("eCaEbomCharge_uploadFile","点击上传",eCaEbomCharge_node,"eCaEbomCharge_uploadFileRecord"),{
                    xtype:'displayfield',
                    fieldLabel: '附件链接',
                    labelWidth:70,
                    id:'eCaEbomCharge_uploadFileRecord',
                    name:'eCaEbomCharge_uploadFileRecord',
                    width:'30%'
                }]
            },{
                xtype: disableNode(eCaEbomCharge_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(eCaEbomCharge_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'eCaEbomCharge_auditComment',
                id: 'eCaEbomCharge_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('eCaEbomCharge_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('eCaEbomCharge_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'eCaEbomCharge_auditUser',
                    name: 'eCaEbomCharge_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'eCaEbomCharge_auditResult',
                    name: 'eCaEbomCharge_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'eCaEbomCharge_auditTime',
                    name: 'eCaEbomCharge_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var eCaDataProcessorPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'EBOM更改任务ECA_资料员(如需要试产，则直接更改SAP试产BOM；如不需要试产，则更改EBOM数据，同步等待结构/电子图纸更改)',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(eCaDataProcessor_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(eCaDataProcessor_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(eCaDataProcessor_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'eCaDataProcessor_auditComment',
                id: 'eCaDataProcessor_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('eCaDataProcessor_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('eCaDataProcessor_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'eCaDataProcessor_auditUser',
                    name: 'eCaDataProcessor_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'eCaDataProcessor_auditResult',
                    name: 'eCaDataProcessor_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'eCaDataProcessor_auditTime',
                    name: 'eCaDataProcessor_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var eCaTrialResponPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'EBOM更改任务ECA_试产责任人（判定试产结论）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(eCaTrialRespon_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype:'textfield',
                    labelWidth: 750,
                    xtype: disableNode(eCaTrialRespon_node)?'displayfield':'textfield',
                    fieldLabel: disableNode(eCaTrialRespon_node)?'小批量试产验证文档编号（对应文档类型：F-ME-005_新产品小批量试产申请及跟踪，多次试产的文档编号请使用“,”隔开）':redStarFlag+blueFlagStart+'小批量试产验证文档编号（对应文档类型：F-NE-005_新产品小批量试产申请及跟踪，多次试产的文档编号请使用“,”隔开）'+blueFlagEnd,
                    id: 'eCaTrialRespon_smallTrialCheckDocNum',
                    name: 'eCaTrialRespon_smallTrialCheckDocNum',
                    //value:'05430',
                    width: 1050,
                    listeners: {
                        blur: function (e) {
                            var value = Ext.getCmp('eCaTrialRespon_smallTrialCheckDocNum').getValue();
                            //触发后台保存
                            autoSaveAtt('eCaTrialRespon_smallTrialCheckDocNum',value);
                        }
                    }
                },]
            },{
                xtype:'displayfield',
                fieldLabel:'文档链接',
                id: 'eCaTrialRespon_smallTrialCheckDocUrl',
                name: 'eCaTrialRespon_smallTrialCheckDocUrl',
                width: 300,
            },{
                xtype: 'radiogroup',
                fieldLabel: disableNode(eCaTrialRespon_node)?'试产结论':redStarFlag+blueFlagStart+'试产结论'+blueFlagEnd,
                labelWidth:100,
                disabled:disableNode(eCaTrialRespon_node),
                disabledCls:'none',
                name: 'eCaTrialRespon_trialConclusion',
                id: 'eCaTrialRespon_trialConclusion',
                width:600,
                columns:[100,180],
                items: [
                    { boxLabel: '试产合格', name: 'trialConclusion', inputValue: 'V1'},
                    { boxLabel: '不合格,修改方案再次试产', name: 'trialConclusion', inputValue: 'V2'},
                ],
                listeners : {
                    change : function(field,newValue,oldValue){
                        if(!ct_dataLoadedFlag) {
                            //加载阻止数据时执行后台保存
                            return;
                        }
                        //触发后台保存
                        var data = newValue.trialConclusion;
                        autoSaveAtt('trialConclusion',data);
                    }
                }
            },{
                xtype: disableNode(eCaTrialRespon_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(eCaTrialRespon_node)?'不合格原因':blueFlagStart+'不合格原因'+blueFlagEnd,
                name: 'eCaTrialRespon_ngConclusion',
                id: 'eCaTrialRespon_ngConclusion',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('eCaTrialRespon_ngConclusion').getValue();
                        //触发后台保存
                        autoSaveAtt('eCaTrialRespon_ngConclusion',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'eCaTrialRespon_auditUser',
                    name: 'eCaTrialRespon_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'eCaTrialRespon_auditResult',
                    name: 'eCaTrialRespon_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'eCaTrialRespon_auditTime',
                    name: 'eCaTrialRespon_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var eCaDataProcessor2Panel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'EBOM更改任务ECA_资料员审核(更改EBOM数据，同步等待结构/电子图纸更改)',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(eCaDataProcessor2_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(eCaDataProcessor2_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(eCaDataProcessor2_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'eCaDataProcessor2_auditComment',
                id: 'eCaDataProcessor2_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('eCaDataProcessor2_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('eCaDataProcessor2_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'eCaDataProcessor2_auditUser',
                    name: 'eCaDataProcessor2_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'eCaDataProcessor2_auditResult',
                    name: 'eCaDataProcessor2_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'eCaDataProcessor2_auditTime',
                    name: 'eCaDataProcessor2_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var mCaEbomChargePanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'MBOM更改任务ECA_EBOM负责人（确认EBOM更改完成）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(mCaEbomCharge_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(mCaEbomCharge_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaEbomCharge_node)?'处理方式':redStarFlag+blueFlagStart+'处理方式'+blueFlagEnd,
                name: 'mCaEbomCharge_handling',
                id: 'mCaEbomCharge_handling',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaEbomCharge_handling').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaEbomCharge_handling', value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'mCaEbomCharge_auditUser',
                    name: 'mCaEbomCharge_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaEbomCharge_auditResult',
                    name: 'mCaEbomCharge_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaEbomCharge_auditTime',
                    name: 'mCaEbomCharge_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var mCaMbomChargePanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'MBOM更改任务ECA_MBOM负责人（更改MBOM数据及库存处理方式，再次确认MBOM更改方案）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(mCaMbomCharge_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(mCaMbomCharge_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaMbomCharge_node)?'处理方式':redStarFlag+blueFlagStart+'处理方式'+blueFlagEnd,
                name: 'mCaMbomCharge_handling',
                id: 'mCaMbomCharge_handling',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaMbomCharge_handling').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaMbomCharge_handling',value);
                    }
                }
            },{
                xtype: 'panel',
                padding:'2 10 2 10',
                disabledCls:'none',
                border:false,
                layout:'hbox',
                defaults:{ margin:'5 20 0 0',labelWidth:60},
                items:[{//第四行
                    xtype: 'radiogroup',
                    disabled: disableNode(mCaMbomCharge_node),
                    disabledCls:'none',
                    fieldLabel: 'ECR方案是否有变化',
                    width: 350,
                    name: 'isEcrPlanChange',
                    id: 'isEcrPlanChange',
                    labelWidth: 200,
                    items: [{
                        inputValue: '是',
                        boxLabel: '是',
                        name: 'isEcrChange',
                        disabledCls: 'none'
                    }, {
                        inputValue: '否',
                        boxLabel: '否',
                        name: 'isEcrChange',
                        disabledCls: 'none'
                    }],
                    listeners: {
                        change: function (field, newValue, oldValue) {
                            if (!ct_dataLoadedFlag) {
                                //阻止加载数据时执行后台保存
                                return;
                            }
                            var value = newValue.isEcrChange;
                            //触发后台保存
                            autoSaveAtt('isEcrChange', value);
                            if(value&&"是"==value){
                                Ext.getCmp("mCaMbomCharge_uploadFile").setDisabled(false);
                                Ext.DomQuery.selectNode('label[id=mCaMbomCharge_attatchment-labelEl]').innerHTML=redStarFlag+blueFlagStart+'ECR《变更前后方案》附件'+blueFlagEnd;
                            }else{
                                Ext.getCmp("mCaMbomCharge_uploadFile").setDisabled(true);
                                Ext.DomQuery.selectNode('label[id=mCaMbomCharge_attatchment-labelEl]').innerHTML='ECR《变更前后方案》附件';
                            }
                        },
                    }
                }]
            },{
                xtype: 'panel',
                padding:'2 10 2 10',
                disabledCls:'none',
                border:false,
                layout:'hbox',
                defaults:{ margin:'5 20 0 0',labelWidth:60},
                items:[{
                    xtype: 'displayfield',
                    fieldLabel: 'ECR《变更前后方案》附件',
                    id: 'mCaMbomCharge_attatchment',
                    name: 'mCaMbomCharge_attatchment',
                    labelWidth:200
                },uploadFilefield("mCaMbomCharge_uploadFile","点击上传",mCaMbomCharge_node,"mCaMbomCharge_uploadFileRecord"),{
                    xtype:'displayfield',
                    fieldLabel: '附件链接',
                    labelWidth:70,
                    id:'mCaMbomCharge_uploadFileRecord',
                    name:'mCaMbomCharge_uploadFileRecord',
                    width:'30%'
                }]
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'mCaMbomCharge_auditUser',
                    name: 'mCaMbomCharge_auditUser',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaMbomCharge_auditResult',
                    name: 'mCaMbomCharge_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaMbomCharge_auditTime',
                    name: 'mCaMbomCharge_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var mCaPdtPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'MBOM更改任务ECA_PDT经理批准（确认库存处理方式）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(mCaPdt_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(mCaPdt_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaPdt_node)?'处理方式意见':redStarFlag+blueFlagStart+'处理方式意见'+blueFlagEnd,
                name: 'mCaPdt_auditComment',
                id: 'mCaPdt_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaPdt_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaPdt_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'mCaPdt_auditUser',
                    name: 'mCaPdt_auditUser',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaPdt_auditResult',
                    name: 'mCaPdt_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaPdt_auditTime',
                    name: 'mCaPdt_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });

        var mCaDataProcessorPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'MBOM更改任务ECA_产品数据管理工程师',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(mCaDataProcessor_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(mCaDataProcessor_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaDataProcessor_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'mCaDataProcessor_auditComment',
                id: 'mCaDataProcessor_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaDataProcessor_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaDataProcessor_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'mCaDataProcessor_auditUser',
                    name: 'mCaDataProcessor_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaDataProcessor_auditResult',
                    name: 'mCaDataProcessor_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaDataProcessor_auditTime',
                    name: 'mCaDataProcessor_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var mCaMCMPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'MBOM更改任务ECA_物控经理（BOM更改生效日期）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(mCaMCM_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(mCaMCM_node)?'displayfield':'datefield',
                labelWidth: 120,
                format:'Y-m-d',
                fieldLabel: disableNode(mCaMCM_node)?'BOM更改生效时间':redStarFlag+blueFlagStart+'BOM更改生效时间'+blueFlagEnd,
                value:'',
                name: 'mCaMCM_bomChangeEffectTime',
                id: 'mCaMCM_bomChangeEffectTime',
                width: 400,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaMCM_bomChangeEffectTime').getValue();
                        var time = Ext.Date.format(value, "Y-m-d");
                        //触发后台保存
                        autoSaveAtt('mCaMCM_bomChangeEffectTime',time);
                    }
                }

            },{
                xtype: disableNode(mCaMCM_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaMCM_node)?'审批意见':redStarFlag+blueFlagStart+'审批意见'+blueFlagEnd,
                name: 'mCaMCM_auditComment',
                id: 'mCaMCM_auditComment',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaMCM_auditComment').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaMCM_auditComment',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'mCaMCM_auditUser',
                    name: 'mCaMCM_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaMCM_auditResult',
                    name: 'mCaMCM_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaMCM_auditTime',
                    name: 'mCaMCM_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var mCaFeedbackPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'MBOM更改任务ECA_物控/采购/质控/技术/生产/财务（更改方案执行反馈）',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(mCaMCRep_node)&&!openPanel(mCaPCRep_node)&&!openPanel(mCaQCRep_node)&&!openPanel(mCaTechnology_node)&&!openPanel(mCaProduction_node)&&!openPanel(mCaFinance_node)&&!openPanel(mCaGylxscbb_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(mCaMCRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaMCRep_node)?'变更方案执行反馈':redStarFlag+blueFlagStart+'变更方案执行反馈'+blueFlagEnd,
                name: 'mCaMCRep_feedback',
                id: 'mCaMCRep_feedback',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaMCRep_feedback').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaMCRep_feedback',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '物控审批人',
                    id: 'mCaMCRep_auditUser',
                    name: 'mCaMCRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaMCRep_auditResult',
                    name: 'mCaMCRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaMCRep_auditTime',
                    name: 'mCaMCRep_auditTime',
                    value:'',
                    width: 300,

                }]
            },{
                xtype: disableNode(mCaPCRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaPCRep_node)?'变更方案执行反馈':redStarFlag+blueFlagStart+'变更方案执行反馈'+blueFlagEnd,
                name: 'mCaPCRep_feedback',
                id: 'mCaPCRep_feedback',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaPCRep_feedback').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaPCRep_feedback',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '采购审批人',
                    id: 'mCaPCRep_auditUser',
                    name: 'mCaPCRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaPCRep_auditResult',
                    name: 'mCaPCRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaPCRep_auditTime',
                    name: 'mCaPCRep_auditTime',
                    value:'',
                    width: 300,

                }]
            },{
                xtype: disableNode(mCaQCRep_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaQCRep_node)?'变更方案执行反馈':redStarFlag+blueFlagStart+'变更方案执行反馈'+blueFlagEnd,
                name: 'mCaQCRep_feedback',
                id: 'mCaQCRep_feedback',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaQCRep_feedback').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaQCRep_feedback',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '质控审批人',
                    id: 'mCaQCRep_auditUser',
                    name: 'mCaQCRep_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaQCRep_auditResult',
                    name: 'mCaQCRep_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaQCRep_auditTime',
                    name: 'mCaQCRep_auditTime',
                    value:'',
                    width: 300,

                }]
            },{
                xtype: disableNode(mCaTechnology_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaTechnology_node)?'变更方案执行反馈':redStarFlag+blueFlagStart+'变更方案执行反馈'+blueFlagEnd,
                name: 'mCaTechnology_feedback',
                id: 'mCaTechnology_feedback',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaTechnology_feedback').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaTechnology_feedback',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '技术审批人',
                    id: 'mCaTechnology_auditUser',
                    name: 'mCaTechnology_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaTechnology_auditResult',
                    name: 'mCaTechnology_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaTechnology_auditTime',
                    name: 'mCaTechnology_auditTime',
                    value:'',
                    width: 300,

                }]
            },{
                xtype: disableNode(mCaProduction_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaProduction_node)?'变更方案执行反馈':redStarFlag+blueFlagStart+'变更方案执行反馈'+blueFlagEnd,
                name: 'mCaProduction_feedback',
                id: 'mCaProduction_feedback',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaProduction_feedback').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaProduction_feedback',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '生产审批人',
                    id: 'mCaProduction_auditUser',
                    name: 'mCaProduction_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaProduction_auditResult',
                    name: 'mCaProduction_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaProduction_auditTime',
                    name: 'mCaProduction_auditTime',
                    value:'',
                    width: 300,

                }]
            },{
                xtype: disableNode(mCaFinance_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(mCaFinance_node)?'变更方案执行反馈':redStarFlag+blueFlagStart+'变更方案执行反馈'+blueFlagEnd,
                name: 'mCaFinance_feedback',
                id: 'mCaFinance_feedback',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaFinance_feedback').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaFinance_feedback',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '财务审批人',
                    id: 'mCaFinance_auditUser',
                    name: 'mCaFinance_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaFinance_auditResult',
                    name: 'mCaFinance_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaFinance_auditTime',
                    name: 'mCaFinance_auditTime',
                    value:'',
                    width: 300,

                }]
            },{
                xtype: disableNode(mCaGylxscbb_node)?'displayfield':'textarea',
                labelWidth: 100,
                hidden:!isChangeType("快速变更4")&&!isChangeType("完整变更"),
                fieldLabel: disableNode(mCaGylxscbb_node)?'工艺路线生产版本执行反馈':redStarFlag+blueFlagStart+'变更方案执行反馈'+blueFlagEnd,
                name: 'mCaGylxscbb_feedback',
                id: 'mCaGylxscbb_feedback',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('mCaGylxscbb_feedback').getValue();
                        //触发后台保存
                        autoSaveAtt('mCaGylxscbb_feedback',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                hidden:!isChangeType("快速变更4")&&!isChangeType("完整变更"),
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '工艺路线生产版本维护人',
                    id: 'mCaGylxscbb_auditUser',
                    name: 'mCaGylxscbb_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'mCaGylxscbb_auditResult',
                    name: 'mCaGylxscbb_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'mCaGylxscbb_auditTime',
                    name: 'mCaGylxscbb_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });
        var resultPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'ECR_变更监控与闭环',
            padding:'5',
            collapsible:true,
            collapsed:!openPanel(result_node),
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items:[{
                xtype: disableNode(result_node)?'displayfield':'textarea',
                labelWidth: 100,
                fieldLabel: disableNode(result_node)?'监控结果':redStarFlag+blueFlagStart+'监控结果'+blueFlagEnd,
                name: 'result_ecResult',
                id: 'result_ecResult',
                width: 800,
                listeners: {
                    blur: function (e) {
                        var value = Ext.getCmp('result_ecResult').getValue();
                        //触发后台保存
                        autoSaveAtt('result_ecResult',value);
                    }
                }
            },{
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: '审批人',
                    id: 'result_auditUser',
                    name: 'result_auditUser',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批结果',
                    id: 'result_auditResult',
                    name: 'result_auditResult',
                    value:'',
                    width: 300,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '审批时间',
                    id: 'result_auditTime',
                    name: 'result_auditTime',
                    value:'',
                    width: 300,

                }]
            }]
        });



        var ecrFormPanel = {
            xtype: 'form',
            id: 'mainForm',
            title: '变更表单信息',
            titleAlign:'center',
            width: '100%',
            hideLabel: true,
            frame: true,
            layout : "anchor",// 整个大的表单是anchor布局
            // border: false,
            items: [
                submitPanel,           //ECR_申请人（提交）
                ecPlanAndChangeObjPanel,      //ECR_SE、EBOM负责人、MBOM负责人（变更方案与更改对象）
                isChangeType("完整变更")?consistencyRiskPanel:null,               //ECR_产品管理部（一致性）
                isChangeType("完整变更1")||isChangeType("完整变更3")||isChangeType("完整变更4")||isChangeType("完整变更5")?pmPanel:null,    //ECR_CCB评审团队：产品工程领域
                isChangeType("完整变更1")||isChangeType("完整变更3")||isChangeType("完整变更4")||isChangeType("完整变更5")?tmPanel:null,    //ECR_CCB评审团队：技术领域
                // mnfPanel,          //ECR_CCB评审团队：制造领域
                isChangeType("完整变更1")||isChangeType("完整变更3")||isChangeType("完整变更4")||isChangeType("完整变更5")?structPanel:null,        //ECR_CCB评审团队：结构领域
                // elecPanel,         //ECR_CCB评审团队：电子领域
                isChangeType("完整变更1")||isChangeType("完整变更3")||isChangeType("完整变更2")||isChangeType("完整变更5")?hwPanel:null,           //ECR_CCB评审团队：硬件领域
                isChangeType("完整变更1")||isChangeType("完整变更3")||isChangeType("完整变更2")||isChangeType("完整变更5")?swPanel:null,           //ECR_CCB评审团队：软件领域
                // processPanel,      //ECR_CCB评审团队：工艺领域
                isChangeType("完整变更")?qualityPanel:null,      //ECR_CCB评审团队：质量领域
                !isChangeType("快速变更1")?dateManageMajorPanel:dateManageEngineerPanel,       //ECR_CCB评审团队：数据管理领域
                isChangeType("快速变更1")||isChangeType("完整变更3")?deviceEngineerPanel:null,//ECR_CCB评审团队：器件领域
                isChangeType("完整变更1")||isChangeType("完整变更3")||isChangeType("完整变更4")||isChangeType("完整变更5")||isChangeType("快速变更4")?pcPanel:null,         //ECR_CCB评审团队：采购领域
                isChangeType("完整变更1")||isChangeType("完整变更2")||isChangeType("完整变更3")||isChangeType("完整变更4")||isChangeType("完整变更5")||isChangeType("快速变更4")?mcPanel:null,           //ECR_CCB评审团队：物控领域
                //isChangeType("完整变更")?pdt2Panel:null,       //变更流程_PDT经理审核
                isChangeType("完整变更")||isChangeType("快速变更4")?pdtPanel:null,      //ECR_CCB评审意见汇总人
                isChangeType("完整变更")?ccbPanel:null,      //ECR_CCB主任（ECR批准）
                isChangeType("完整变更")?ipmtPanel:null,     //ECR_IPMT副主任审批（ECR批准）
                isChangeType("完整变更")?eCaEbomChargePanel:null,  //EBOM更改任务ECA_EBOM负责人（EBOM更改信息）
                isChangeType("完整变更")?eCaDataProcessorPanel:null,       //EBOM更改任务ECA_资料员(如需要试产，则直接更改SAP试产BOM；如不需要试产，则更改EBOM数据，同步等待结构/电子图纸更改)
                isChangeType("完整变更")?eCaTrialResponPanel:null,      //EBOM更改任务ECA_试产责任人（判定试产结论）
                isChangeType("完整变更")?eCaEbomChargePanel2:null,//EBOM更改任务ECA_EBOM负责人（再次确认EBOM变更方案）
                isChangeType("完整变更")?eCaDataProcessor2Panel:null, //EBOM更改任务ECA_资料员审核(更改EBOM数据，同步等待结构/电子图纸更改)
                isChangeType("完整变更")?mCaEbomChargePanel:null,     //MBOM更改任务ECA_EBOM负责人（确认EBOM更改完成）
                isChangeType("完整变更")?mCaMbomChargePanel:null,             //MBOM更改任务ECA_MBOM负责人（更改MBOM数据及库存处理方式）
                isChangeType("完整变更")||isChangeType("快速变更4")?mCaPdtPanel:null,      //MBOM更改任务ECA_PDT经理批准（确认库存处理方式）
                isChangeType("完整变更")?mCaDataProcessorPanel:null, //MBOM更改任务ECA_产品数据管理工程师
                isChangeType("完整变更")||isChangeType("快速变更4")?mCaMCMPanel:null,              //MBOM更改任务ECA_物控经理（BOM更改生效日期）
                isChangeType("完整变更")||isChangeType("快速变更4")?mCaFeedbackPanel:null,         //MBOM更改任务ECA_物控/采购/质控（更改方案执行反馈）
                isChangeType("完整变更")?resultPanel:null            //ECR_变更监控与闭环
            ]
        };

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [ecrFormPanel];

        this.callParent();

    },//~End of initComponent
    listeners:{
        'afterrender':function(){
            ct_dataLoadedFlag = false;//加载前标志位设置为false
            //加载变更表头
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ec/getHeadInfo?changeRequestId='+changeRequestId,
                success: function(response, opts) {
                    //加载表头信息
                    var obj = Ext.decode(response.responseText);

                    if(!obj['success']){
                        alert(obj['msg']);
                        return;
                    }

                    //设置表单值
                    var mainPanel = Ext.getCmp('mainForm');
                    mainPanel.getForm().setValues(obj);
                    ct_dataLoadedFlag = true;//数据加载后标志位设为true

                    var redStarFlag = '<font color=red bold>*</font>'; //必填标志
                    var blueFlagStart = '<font color=blue bold><b>';
                    var blueFlagEnd = '</b></font>';

                    //适用场景没有值  隐藏
                    if(!obj['head_applicableScene']){
                        Ext.getCmp("head_applicableScene").hide();
                    }
                    if(!disableNode(head_node)&&!(isChangeType("快速变更1")||isChangeType("快速变更2"))){
                        var isSource  = Ext.getCmp("isSourceGroup").getValue().isSource;
                        if(isSource){
                            if("是"==isSource){
                                Ext.getCmp("head_uploadFile").setDisabled(false);
                                Ext.getCmp("head_noNeedReason").setDisabled(true);
                                Ext.DomQuery.selectNode('label[for=head_noNeedReason-inputEl]').innerHTML='不需要测试报告原因';
                                Ext.DomQuery.selectNode('label[id=head_attatchment-labelEl]').innerHTML=redStarFlag+blueFlagStart+'测试报告文件'+blueFlagEnd;
                            }else{
                                Ext.getCmp("head_uploadFile").setDisabled(true);
                                Ext.getCmp("head_noNeedReason").setDisabled(false);
                                Ext.DomQuery.selectNode('label[for=head_noNeedReason-inputEl]').innerHTML=redStarFlag+blueFlagStart+'不需要测试报告原因'+blueFlagEnd;
                                Ext.DomQuery.selectNode('label[id=head_attatchment-labelEl]').innerHTML='测试报告文件';
                            }
                        }
                    }else if(!disableNode(mCaMbomCharge_node)){
                        var isEcrChange  = Ext.getCmp("isEcrPlanChange").getValue().isEcrChange;
                        if(isEcrChange&&"是"==isEcrChange){
                            Ext.getCmp("mCaMbomCharge_uploadFile").setDisabled(false);
                            Ext.DomQuery.selectNode('label[id=mCaMbomCharge_attatchment-labelEl]').innerHTML=redStarFlag+blueFlagStart+'ECR《变更前后方案》附件'+blueFlagEnd;
                        }else{
                            Ext.getCmp("mCaMbomCharge_uploadFile").setDisabled(true);
                            Ext.DomQuery.selectNode('label[id=mCaMbomCharge_attatchment-labelEl]').innerHTML='ECR《变更前后方案》附件';
                        }
                    }else if(!disableNode(eCaEbomCharge2_node)){
                        var isEcrChange2  = Ext.getCmp("isEcrPlanChange2").getValue().isEcrChange2;
                        if(isEcrChange2&&"是"==isEcrChange2){
                            Ext.getCmp("eCaEbomCharge2_uploadFile").setDisabled(false);
                            Ext.DomQuery.selectNode('label[id=eCaEbomCharge2_attatchment-labelEl]').innerHTML=redStarFlag+blueFlagStart+'ECR《变更前后方案》附件'+blueFlagEnd;
                        }else{
                            Ext.getCmp("eCaEbomCharge2_uploadFile").setDisabled(true);
                            Ext.DomQuery.selectNode('label[id=eCaEbomCharge2_attatchment-labelEl]').innerHTML='ECR《变更前后方案》附件';
                        }
                    }
                },
                failure: function(response, opts) {
                    alert('错误：读取变更表头信息失败，请检查网络！');
                }
            });
            refreshPartChangeStore();
            refreshEBomChangeStore();
            refreshMBomChangeStore();
            refreshPcrMaterialItemsStore();
            refreshPmcMaterialItemsStore();
            refreshPdtAuditInfoStore();
        }//~end of listeners 'afterrender'

    },
});

