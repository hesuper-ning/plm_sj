<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>in CtBomToolPlugin.jsp oid="+oid);
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="js/ctMainBoardPanel.js"></script>
    <script type="text/javascript" src="js/ctCenterPanel.js"></script>
    <script type="text/javascript" src="js/ctWestPanel.js"></script>
    <script type="text/javascript" src="js/ctSouthPanel.js"></script>
    <script type="text/javascript" src="js/ctProjectListPanel.js"></script>
    <script type="text/javascript" src="js/ctTaskListPanel.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockFunctions.js"></script>
    <script type="text/javascript" src="../mock/js/ctMockObjects.js"></script>

</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'MainBoardPanel'
            }]
        });
    });
</script>
</body>
</html>