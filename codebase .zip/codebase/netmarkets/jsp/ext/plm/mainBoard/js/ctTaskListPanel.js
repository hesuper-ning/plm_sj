Ext.define('PLM.view.TaskListPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.TaskListPanel',
    border:false,
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    config:{
        in_objectKey: 'mainBoard_task_list',
        in_objectDesc: '主页定制中的流程任务列表',
    },
    id: 'taskListPanel',
    initComponent:function(){

        var me = this;

        var taskListStore = Ext.create('PLM.store.MockItemStore',{
            id:'taskListStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var taskListGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store:Ext.getStore('taskListStore'),
            id:'taskListGrid',
            margin:'20 10 20 10',
            forceFit : true,
            autoWidth : true,
            // width:2500,
            autoScroll:true,
            region:'center',
            height:'100%',
            selModel: {
                mode:'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection:true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function(view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu',{
                            param_grid:taskListGrid,
                            param_objectKey:me.in_objectKey,
                            param_objectDesc:me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
           // selType: 'checkboxmodel',
            listeners: {
                change:'onAllCircuitsChecked'
            },
            columns: [{ xtype: 'rownumberer'},
                { text: '',  dataIndex: 'id',menuDisabled:true, hidden:true },
                { text: '',  dataIndex: 'masterId',menuDisabled:true, hidden:true },
                { text: '图标',  dataIndex: 'data1',width:100,editor:'textfield',menuDisabled:true},
                { text: '名称',  dataIndex: 'data2',width:120,editor:'textfield',menuDisabled:true,
                    items    : {
                        xtype: 'textfield',
                        flex : 1,
                        margin: 2,
                        enableKeyEvents: true,
                        listeners: {
                            keyup: function() {
                                var store = Ext.getStore('taskListStore');
                                store.clearFilter();
                                if (this.value) {
                                    store.filter({
                                        property     : 'data2',
                                        value         : this.value,
                                        anyMatch      : true,
                                        caseSensitive : false
                                    });
                                }
                            },
                            buffer: 500
                        }
                    }},
                {text: '主题',dataIndex: 'data3',width: 80,editor:'textfield',menuDisabled: true},
                {text: '状态',dataIndex: 'data4',width: 80,editor:'textfield',menuDisabled: true},
                {text: '所有者',dataIndex: 'data5',width: 80,editor:'textfield',menuDisabled: true},
                {text: '角色',dataIndex: 'data6',width: 80,editor:'textfield',menuDisabled: true},
                {text: '已逾期',dataIndex: 'data7',width: 80,editor:'textfield',menuDisabled: true},
                {text: '最后期限',dataIndex: 'data8',width: 80,editor:'textfield',menuDisabled: true}
            ]
        });
        taskListGrid.on('edit',
            function(editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function(){
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey,this.in_objectDesc, itemId, tField,tValue,callbackFn);

            });

        var projectPanel = {
            items:[taskListGrid]
        }


/////////////////////////Main Panel items//////////////////////////////////
        this.items=[projectPanel];

        this.callParent();

    },//~End of initComponent
    listeners:{
        'afterrender':function () {
            Ext.getStore('taskListStore').load({
                params: {
                    objectKey:Ext.getCmp('taskListPanel').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if(typeof(operation.error)=='string'){
                            alert(operation.error);
                        }else {
                            alert('查询超时！请重试！')
                        }
                    }else{
                        //无数据时自动添加一条空数据
                        if( Ext.getStore('taskListStore').getCount() ==0){
                            var callbackFn = function(){Ext.getStore('taskListStore').reload()}
                            createMockItemData(Ext.getCmp('taskListPanel').getIn_objectKey()
                                ,Ext.getCmp('taskListPanel').getIn_objectDesc,callbackFn);
                        }

                    }
                }
            })
        }
    }
});

