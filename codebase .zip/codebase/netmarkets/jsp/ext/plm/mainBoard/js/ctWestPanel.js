Ext.define('PLM.view.WestPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.WestPanel',
    border:false,
    split: true,
    width: 200,
    minWidth: 175,
    maxWidth: 400,
    collapsible: true,
   // margin: '35 0 5 5',
    layout: {
        type: 'accordion',
        animate: false
    },
    id: 'westPanel',
    initComponent:function(){

        //=======开始 待办任务==========
        var taskStore = Ext.create('Ext.data.JsonStore', {
            fields:['menuItem','panelId'],
            data:[{
                'menuItem':'工作流任务',
                'panelId':'TaskListPanel'
            },{
                'menuItem':'项目任务',
                'panelId':'TaskListPanel'
            }],
        });

        var taskGrid = Ext.create('Ext.grid.Panel',{
            store:taskStore,
            title: '',
            border:false,
            hideHeaders:true,
            forceFit : true,
            columns:[
                { text: '',  hidden:true, dataIndex:'panelId', align:'center', menuDisabled:true},
                { text: '',  dataIndex:'menuItem', align:'center', menuDisabled:true}

            ],
            listeners:{
                scope:this,
                'cellclick':function(thisObj, td, cellIndex, record, tr, rowIndex){
                    var panel = {
                        xtype:record.get('panelId')
                    }
                    Ext.getCmp('centerPanel').removeAll();
                    Ext.getCmp('centerPanel').add(panel);
                }
            }//~end of listeners
        })

        //=======结束 待办任务==========


        //=======开始 项目管理==========
        var projectStore = Ext.create('Ext.data.JsonStore', {
            fields:['menuItem','panelId'],
            data:[{
                'menuItem':'项目总览',
                'panelId':'ProjectListPanel'
            },{
                'menuItem':'项目报表'
            }],
        });

        var projectGrid = Ext.create('Ext.grid.Panel',{
            store:projectStore,
            title: '',
            border:false,
            hideHeaders:true,
            forceFit : true,
            columns:[{ text: '',  dataIndex:'menuItem',align:'center',menuDisabled:true}],
            listeners:{
                scope:this,
                'cellclick':function(thisObj, td, cellIndex, record, tr, rowIndex){
                    var panel = {
                        xtype:record.get('panelId')
                    }

                    Ext.getCmp('centerPanel').removeAll();
                    Ext.getCmp('centerPanel').add(panel);
                }
            }//~end of listeners
        })



        //=======结束 项目管理==========





/////////////////////////Main Panel items//////////////////////////////////
        this.items=[{
            title:'我的任务',
            border:false,
            autoScroll:true,
            iconCls:'settings',
            items:[taskGrid]
        },{
            title:'项目管理',
            autoScroll:true,
            border:false,
            iconCls:'nav',
            items:[projectGrid]

        },{
            title:'需求管理',
            border:false,
            autoScroll:true,
            iconCls:'settings'
        },];

        this.callParent();

    }//~End of initComponent
});

