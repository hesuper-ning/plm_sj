Ext.define('PLM.view.SouthPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.SouthPanel',
    border:false,
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    collapsed:true,
   // margin: '35 0 5 5',
    id: 'southPanel',
    initComponent:function(){
   //=============开始 部件信息==============================
        var partStore = Ext.create('Ext.data.JsonStore', {
            //pageSize: 50,
            fields:['name','amount','percent'],
            id:'partStore',
            data:[{
                "name": "正在工作:200",
                "amount": "200",
                "percent": "20%"
            },
                {
                    "name": "研发:200",
                    "amount": "200",
                    "percent": "20%"
                },
                {
                    "name": "试制:300",
                    "amount": "300",
                    "percent": "30%"
                },
                {
                    "name": "量产:400",
                    "amount": "400",
                    "percent": "40%"
                }],
            autoLoad:true
        });

        var partChart = Ext.create('Ext.chart.Chart',{
            xtype: 'chart',
            animate: true,
            shadow: false,
            store: partStore,
            width:200,
            height:150,
            legend: {
                position: 'right'
            },
           // insetPadding: 60,
             //   theme: 'Base:gradients',
            series: [{
                type: 'pie',
                field: 'amount',
                showInLegend: true,
                //donut: donut,
                highlight: {
                    segment: {
                        margin: 10
                    }
                },
                label: {
                    field: 'name',
                    display: 'rotate',//"outside" | "rotate"
                    contrast: true,
                    font: '8px Arial'
                }
            }]
        });
    //=============结束 部件信息==============================

        //=============开始 项目信息==============================
        var projectStore = Ext.create('Ext.data.JsonStore', {
            //pageSize: 50,
            fields:['name','amount','percent'],
            id:'partStore',
            data:[{
                "name": "未启动:10",
                "amount": "10",
                "percent": "20%"
            },
                {
                    "name": "正在运行:20",
                    "amount": "20",
                    "percent": "40%"
                },
                {
                    "name": "已结项:20",
                    "amount": "20",
                    "percent": "40%"
                }],
            autoLoad:true
        });

        var projectChart = Ext.create('Ext.chart.Chart',{
            xtype: 'chart',
            animate: true,
            shadow: false,
            store: projectStore,
            width:200,
            height:150,
             legend: {
                 position: 'right'
             },
            // insetPadding: 60,
            //   theme: 'Base:gradients',
            series: [{
                type: 'pie',
                field: 'amount',
                showInLegend: true,
                //donut: donut,
                highlight: {
                    segment: {
                        margin: 10
                    }
                },
                label: {
                    field: 'name',
                    display: 'rotate',//"outside" | "rotate"
                    contrast: true,
                    font: '8px Arial'
                }
            }]
        });

        var projectMonthStore = Ext.create('Ext.data.JsonStore', {
            //pageSize: 50,
            fields:['name','data1'],
            id:'partStore',
            data:[{ "name": "1月","data1": "10"},
                { "name": "2月","data1": "12"},
                { "name": "3月","data1": "15"},
                { "name": "4月","data1": "17"},
                { "name": "5月","data1": "22"},
                { "name": "6月","data1": "25"},
                { "name": "7月","data1": "9"}
                ],
            autoLoad:true
        });

        var projectMonthChart = Ext.create('Ext.chart.Chart', {
            style: 'background:#fff',
            animate: true,
            shadow: true,
            width:450,
            height:150,
            store: projectMonthStore,
            axes: [{
                type: 'Numeric',
                position: 'left',
                fields: ['data1'],
                label: {
                    renderer: Ext.util.Format.numberRenderer('0,0')
                },
               // title: '数量',
                grid: true,
                minimum: 0
            }, {
                type: 'Category',
                position: 'bottom',
                // title: '项目启动',
                fields: ['name']
            }],
            series: [{
                type: 'column',
                axis: 'left',
                highlight: true,
                tips: {
                    trackMouse: true,
                    width: 140,
                    height: 28,
                    renderer: function(storeItem, item) {
                        this.setTitle(storeItem.get('name') + ': ' + storeItem.get('data1') + ' $');
                    }
                },
                label: {
                    display: 'insideEnd',
                    'text-anchor': 'middle',
                    field: 'data1',
                    renderer: Ext.util.Format.numberRenderer('0'),
                    orientation: 'vertical',
                    color: '#333'
                },
                xField: 'name',
                yField: 'data1'
            }]
        });

        //=============结束 项目信息==============================
/////////////////////////Main Panel items//////////////////////////////////
        this.items=[{
            layout:'hbox',
            border:false,
            items:[{
                //第一列
                width:300,
                border:false,
                layout:'anchor',
                items:[partChart,{
                    html:'物料信息',
                    margin:'0 0 0 50',
                    border:false
                }]
            },{
                //第二列
                width:300,
                border:false,
                items:[projectChart,{
                    html:'项目信息',
                    margin:'0 0 0 50',
                    border:false
                }]
            },{
                width:500,
                border:false,
                items:[projectMonthChart,{
                    html:'项目启动分布',
                    margin:'0 0 0 50',
                    border:false
                }]
            }]
        }];

        this.callParent();

    }//~End of initComponent
});

