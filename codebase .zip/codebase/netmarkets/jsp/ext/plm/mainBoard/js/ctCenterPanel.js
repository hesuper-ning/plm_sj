Ext.define('PLM.view.CenterPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.CenterPanel',
    border:false,
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    title:'主内容',
    id: 'centerPanel',
    initComponent:function(){



/////////////////////////Main Panel items//////////////////////////////////
        this.items=[{
            xtype:'ProjectListPanel'
        }

           ];

        this.callParent();

    }//~End of initComponent
});

