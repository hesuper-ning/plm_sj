Ext.define('PLM.view.MainBoardPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.MainBoardPanel',
    border:false,
    layout: {
        type: 'border',
        padding: Ext.themeName === 'neptune' ? 8 : 5 // match padding to theme splitter size
    },
    defaults: {
        collapsible: true,
        split      : true
    },
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'mainBoardPanel',
    initComponent:function(){


    //var westPanel = Ext.create('PLM.view.WestPanel')

/////////////////////////Main Panel items//////////////////////////////////
        this.items=[
            {
                xtype : 'SouthPanel',
                collapsible:false,
                //title       : '信息汇总',
                region      : 'south',
                collapseMode: 'mini', //header|mini
                //margins     : '0 5 5 5', // TRBL
                height      : '30%'
            },
            {
                xtype : 'WestPanel',
                title       : '菜单',
                region      : 'west',
                //collapseMode: 'mini',
                //margins     : '0 0 0 5', // TRBL
                width       : 100

            },
            {
                title  : '公告栏',
                region : 'east',
                html   : 'East',
                collapseMode: 'mini',
                collapsed:true,
                //margins: '0 5 0 0', // TRBL
                width  : 100
            },{
                region     : 'center',
                collapsible: false,
                height      : '70%',
                xtype: 'CenterPanel',
                id:'centerPanel'
            }];

        this.callParent();

    }//~End of initComponent
});

