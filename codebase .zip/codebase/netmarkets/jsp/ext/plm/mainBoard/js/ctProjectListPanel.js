Ext.define('PLM.view.ProjectListPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.ProjectListPanel',
    border:false,
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    config:{
        in_objectKey: 'mainBoard_project_list',
        in_objectDesc: '主页定制中的项目列表',
    },
    id: 'projectListPanel',
    initComponent:function(){

        var me = this;

        var projectListStore = Ext.create('PLM.store.MockItemStore',{
            id:'projectListStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var projectListGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store:Ext.getStore('projectListStore'),
            id:'projectListGrid',
            margin:'20 10 20 10',
            forceFit : true,
            autoWidth : true,
            // width:2500,
            autoScroll:true,
            region:'center',
            height:'100%',
            selModel: {
                mode:'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection:true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function(view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu',{
                            param_grid:projectListGrid,
                            param_objectKey:me.in_objectKey,
                            param_objectDesc:me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
           // selType: 'checkboxmodel',
            listeners: {
                change:'onAllCircuitsChecked'
            },
            columns: [{ xtype: 'rownumberer'},
                { text: '',  dataIndex: 'id',menuDisabled:true, hidden:true },
                { text: '',  dataIndex: 'masterId',menuDisabled:true, hidden:true },
                { text: '项目编号',  dataIndex: 'data1',width:100,editor:'textfield',menuDisabled:true},
                { text: '项目名称',  dataIndex: 'data2',width:120,editor:'textfield',menuDisabled:true,
                    items    : {
                        xtype: 'textfield',
                        flex : 1,
                        margin: 2,
                        enableKeyEvents: true,
                        listeners: {
                            keyup: function() {
                                var store = Ext.getStore('projectListStore');
                                store.clearFilter();
                                if (this.value) {
                                    store.filter({
                                        property     : 'data2',
                                        value         : this.value,
                                        anyMatch      : true,
                                        caseSensitive : false
                                    });
                                }
                            },
                            buffer: 500
                        }
                    }},
                {text: '产品经理',dataIndex: 'data3',width: 80,editor:'textfield',menuDisabled: true},
                {text: '项目经理',dataIndex: 'data4',width: 80,editor:'textfield',menuDisabled: true},
                {text: '当前阶段',dataIndex: 'data5',width: 80,editor:'textfield',menuDisabled: true},
                {text: '延迟天数',dataIndex: 'data6',width: 80,editor:'textfield',menuDisabled: true},
                {text: '进度偏差',dataIndex: 'data7',width: 80,editor:'textfield',menuDisabled: true},
                {text: '风险状态',dataIndex: 'data8',width: 80,editor:'textfield',menuDisabled: true}
            ]
        });
        projectListGrid.on('edit',
            function(editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function(){
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey,this.in_objectDesc, itemId, tField,tValue,callbackFn);

            });


        var projectPanel = {
            items:[projectListGrid]
        }


/////////////////////////Main Panel items//////////////////////////////////
        this.items=[projectPanel];

        this.callParent();

    },//~End of initComponent
    listeners:{
        'afterrender':function () {
            Ext.getStore('projectListStore').load({
                params: {
                    objectKey:this.getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if(typeof(operation.error)=='string'){
                            alert(operation.error);
                        }else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            })
        }
    }
});

