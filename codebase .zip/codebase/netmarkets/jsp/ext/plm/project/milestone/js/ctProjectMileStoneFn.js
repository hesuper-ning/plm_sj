/**
 * 是否有编辑权限
 * @returns {isEditable|boolean}
 */
function hasEditAccess() {
    return isEditable && !isComplete && !isReadOnlyPage;
}

/**
 * 获取表头信息
 */
function getHeadInfo() {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/project/milestone/getHeadInfo?branchId=' + branchId,
        method: "GET",
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['status'] === 200) {
                Ext.getCmp('projectMileForm').getForm().setValues(obj['data']);
                setCheckRadioGroupValues(Ext.getCmp('milestoneWfType'), obj['data']['milestoneWfType'])
                Ext.getCmp('changeDesc').setDisabled(obj['data']['milestoneWfType'] !== '变更');
            } else {
                Ext.Msg.alert('提示', obj['message']);
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert('提示', '错误：查询里程碑表单内容失败，请检查网络！');
        }
    });
}

/**
 * 更新表头信息
 * @param key
 * @param value
 */
function updateHeadInfo(key, value) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/project/milestone/updateHeadInfo',
        method: "POST",
        params: {
            branchId: branchId,
            key: key,
            value: value
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('提示', obj['message']);
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert('提示', '错误：查询里程碑表单内容失败，请检查网络！');
        }
    });
}

/** 设值radioGroup
 * @param {Ext.form.RadioboxGroup} radioGroup
 * @param {String} value
 */
function setCheckRadioGroupValues(radioGroup, value) {
    //加上逗号匹配更精确，防止窜位
    value = "," + value + ",";
    radioGroup.items.each(function (item) {
        if (value.indexOf("," + item.inputValue + ",") > -1) {
            item.setValue(true);
        } else {
            item.setValue(false);
        }
    });
}

/**
 * 更新里程碑信息
 * @param data
 * @param successCallback
 * @param failCallback
 */
function updateMilestone(data, successCallback, failCallback) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/project/milestone/updateMilestone',
        method: "POST",
        headers: {'Content-Type': 'application/json'},
        params: JSON.stringify(data),
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('提示', obj['message']);
                failCallback();
            } else {
                successCallback(obj['data']);
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert('提示', '错误：保存里程碑内容失败，请检查网络！');
            failCallback();
        }
    });
}

/**
 * 新增里程碑
 * @param data
 * @param successCallback
 * @param failCallback
 */
function addMilestone(data, successCallback) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/project/milestone/addMilestone',
        method: "POST",
        headers: {'Content-Type': 'application/json'},
        params: JSON.stringify(data),
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('提示', obj['message']);
            } else {
                successCallback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert('提示', '错误：新增里程碑内容失败，请检查网络！');
        }
    });
}

/**
 * 删除选中的里程碑
 * @param param
 * @param successCallback
 */
function deleteMilestones(param, successCallback) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/project/milestone/deleteMilestones',
        method: "DELETE",
        headers: {'Content-Type': 'application/json'},
        params: JSON.stringify(param),
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('提示', obj['message']);
            } else {
                successCallback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert('提示', '错误：删除里程碑内容失败，请检查网络！');
        }
    });
}

/**
 * 获取表头信息
 */
function getMilestonePointInfo() {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/project/milestone/getMilestonePointInfo?branchId=' + branchId,
        method: "GET",
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['status'] === 200) {
                Ext.getCmp('milestoneForm').getForm().setValues(obj['data']);
            } else {
                Ext.Msg.alert('提示', obj['message']);
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert('提示', '错误：查询里程碑表单内容失败，请检查网络！');
        }
    });
}

/**
 * 刷新里程碑计划
 * @param successCallback
 */
function refreshMilestone(successCallback) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/project/milestone/refreshMilestone?branchId=' + branchId,
        method: "POST",
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('提示', obj['message']);
            } else {
                successCallback();
            }
        },
        failure: function (response, opts) {
            Ext.Msg.alert('提示', '错误：刷新里程碑失败，请检查网络！');
        }
    });
}

function setDisabledDates() {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/ctPlan/getDisabledDates',
        method: 'GET',
        timeout: 99999999,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                alert(obj['message']);
            }
            let grid = Ext.getCmp('milestoneGrid');
            let finishDateColumn = grid.getColumns()[10];
            finishDateColumn.getEditor().setDisabledDates(obj['data']);
        },
        failure: function (response, opts) {
            alert('错误：查询非工作日失败，请检查网络！');
        }
    }); // ~End of Ajax request
}