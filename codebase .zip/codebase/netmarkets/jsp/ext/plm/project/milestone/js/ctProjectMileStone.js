Ext.define('PLM.view.ProjectMileStone', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ProjectMileStone',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'ProjectMileStone',
        in_objectDesc: '里程碑节点表单',
    },
    id: 'ProjectMileStone',
    initComponent: function () {

        let planActivityStore = Ext.create('Ext.data.Store', {
            fields: ['key', 'value'],
            id: 'planActivityStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/project/milestone/getProjectActivities?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });

        var addPanel = new Ext.create("Ext.form.Panel", {
            items: [{
                xtype: 'combobox',
                store: planActivityStore,
                displayField: 'value',
                margin: '20 5 5 5',
                valueField: 'key',
                triggerAction: 'all',
                fieldLabel: '项目活动',
                width: 380,
                id: 'combo_planActivity',
                allowBlank: true,
                selectOnFocus: true,
                lazyRender: true,
                forceSelection: true,
                queryMode: 'local',
                tpl: Ext.create('Ext.XTemplate',
                    '<tpl for=".">',
                    '<div class="x-boundlist-item" style="height:21px">{value}</div>',
                    '</tpl>'
                ),
                editable: true,
                anyMatch: true
            }, {
                xtype: 'combobox',
                store: new Ext.data.Store({
                    fields: ['key', 'value'],
                    data: [['', ''], ['里程碑时间修改', '里程碑时间修改'], ['将活动设置为里程碑', '将活动设置为里程碑'],
                        ['将里程碑设置为活动', '将里程碑设置为活动'], ['里程碑删除', '里程碑删除'],
                        ['未修改', '未修改']]
                }),
                displayField: 'value',
                margin: '10 5 5 5',
                valueField: 'key',
                triggerAction: 'all',
                fieldLabel: '操作',
                //hidden: !isChange,
                width: 380,
                id: 'combo_operation',
                allowBlank: true,
                editable: true,
                selectOnFocus: true,
                lazyRender: true,
                forceSelection: true,
                queryMode: 'local',
                tpl: Ext.create('Ext.XTemplate',
                    '<tpl for=".">',
                    '<div class="x-boundlist-item" style="height:21px">{value}</div>',
                    '</tpl>'
                ),
                anyMatch: true
            }]
        });

        var newMilestoneWindow = Ext.create('Ext.Window', {
            title: '新增里程碑',
            width: 400,
            height: 250,
            //autoHeight : true,
            //autoWidth : true,
            closeAction: 'hide',
            id: 'win_newMilestoneWindow',
            autoScroll: false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: addPanel,
            buttons: [{
                xtype: "button",
                text: "确定",
                handler: function () {
                    let activityCombo = Ext.getCmp('combo_planActivity');
                    let activityId = activityCombo.getValue();
                    if (activityId == null || activityId === '') {
                        Ext.Msg.alert('提示', '请选择项目活动');
                        return;
                    }
                    let operation = Ext.getCmp('combo_operation').getValue();
                    if (operation == null || operation === '') {
                        Ext.Msg.alert('提示', '请选择操作');
                        return;
                    }
                    let data = {
                        branchId: branchId,
                        activityId: activityCombo.getValue(),
                        milestoneName: activityCombo.getRawValue(),
                        operation: operation
                    };
                    let successCallback = function () {
                        Ext.getCmp('milestoneGrid').getStore().load();
                        Ext.getCmp('win_newMilestoneWindow').close();
                    };
                    addMilestone(data, successCallback);
                }
            }, {
                xtype: "button",
                text: "取消",
                handler: function () {
                    newMilestoneWindow.close();
                }
            }],
            listeners: {
                beforeshow: function () {
                    Ext.getCmp('combo_planActivity').clearValue();
                    Ext.getCmp('combo_operation').setValue('将活动设置为里程碑');
                }
            }
        });


        //**********表头信息*************
        let basicInfoPanel = Ext.create('Ext.form.Panel', {
            xtype: 'form',
            title: '里程碑点表单',
            margin: '0 0 10 0',
            //height: 310,
            //border: false,
            id: 'projectMileForm',
            defaults: {
                border: true
            },
            items: [{
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">项目信息</font>',
                collapsible: true,
                border: true,
                defaults: {
                    border: false
                },
                items: [{
                    xtype: 'panel',
                    layout: {
                        type: 'hbox'
                    },
                    defaults: {
                        border: false,
                        labelWidth: 80,
                        width: 300,
                        margin: '5 5 10 5'
                    },
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '项目编号',
                        id: 'projectNumber',
                        name: 'projectNumber'
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '项目名称',
                        id: 'projectNameUrl',
                        name: 'projectNameUrl'
                    }]
                }]
            }, {
                xtype: 'panel',
                border: false,
                items: [{
                    xtype: 'panel',
                    border: false,
                    layout: {
                        type: 'hbox'
                    },
                    items: [{
                        xtype: 'label',
                        width: 125,
                        margin: '37 0 0 10',
                        text: '申请或变更说明：'
                    }, {
                        xtype: 'radiogroup',
                        id: 'milestoneWfType',
                        name: 'milestoneWfType',
                        defaults: {
                            margin: '30 10 10 10',
                            width: 90,
                            readOnly: true
                        },
                        items: [{
                            boxLabel: '首次申请',
                            name: 'milestoneWfType',
                            inputValue: '首次申请',
                            disabledCls: 'none'
                        }, {
                            boxLabel: '变更',
                            name: 'milestoneWfType',
                            inputValue: '变更',
                            disabledCls: 'none'
                        }]
                    }, {
                        xtype: 'label',
                        width: 65,
                        margin: '35 0 0 10',
                        text: '变更描述：'
                    }, {
                        xtype: 'textarea',
                        margin: '0 0 0 10',
                        width: 500,
                        readOnly: !hasEditAccess(),
                        id: 'changeDesc',
                        name: 'changeDesc',
                        listeners: {
                            blur: function (e) {
                                updateHeadInfo('changeDesc', e.value)
                            }
                        }
                    }]
                }]
            }, {
                xtype: 'panel',
                layout: {
                    type: 'hbox'
                },
                hidden: !isVRProject || !isChange,
                defaults: {
                    border: false,
                    margin: '5 5 10 10',
                },
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: 'PDCP实际完成时间',
                    labelWidth: 130,
                    width: 300,
                    id: 'pdcpActualFinishDate',
                    name: 'pdcpActualFinishDate'
                }, {
                    xtype: 'displayfield',
                    labelWidth: 230,
                    fieldLabel: 'PDCP评审通过的LDCP计划完成时间',
                    id: 'lacpFinishDateAfterPdcp',
                    name: 'lacpFinishDateAfterPdcp'
                }]
            }]
        });

        Ext.define('milestoneModel', {
            extend: 'Ext.data.Model',
            fields: [
                {name: 'id', type: 'int'},
                {name: 'branchId', type: 'int'},
                {name: 'activityId', type: 'int'},
                {name: 'milestoneName', type: 'string'},
                {name: 'operation', type: 'string'},
                {name: 'originalFinishDate', type: 'date'},
                {name: 'changeBeforeFinishDate', type: 'date'},
                {name: 'changeAfterFinishDate', type: 'date'},
                {name: 'days', type: 'int'},
                {name: 'deviation', type: 'number'},
                {name: 'remark', type: 'string'}
            ],
            idProperty: 'id'
        });

        let milestoneStore = Ext.create('Ext.data.Store', {
            model: 'milestoneModel',
            id: 'milestoneStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/project/milestone/getMilestoneList?branchId=' + branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });

        let cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        let milestoneGrid = Ext.create('Ext.grid.Panel', {
            id: 'milestoneGrid',
            store: milestoneStore,
            plugins: cellEditing,
            viewConfig: {
                forceFit: true
            },
            selModel: Ext.create('Ext.selection.CheckboxModel', {
                mode: "SIMPLE",
                checkOnly: true,
                showHeaderCheckbox: true
            }),
            title: '里程碑计划',
            collapsible: false,
            autoScroll: true,
            animCollapse: false,
            height: 540,
            width: window.innerWidth - 10,
            columns: [{
                text: 'ID',
                dataIndex: 'id',
                menuDisabled: true,
                hidden: true
            }, {
                text: 'branchId',
                dataIndex: 'branchId',
                menuDisabled: true,
                hidden: true
            }, {
                text: 'activityId',
                dataIndex: 'activityId',
                menuDisabled: true,
                hidden: true
            }, {
                text: '序号',
                align: 'center',
                menuDisabled: true,
                width: 70,
                xtype: 'rownumberer'
            }, {
                text: '里程碑点',
                dataIndex: 'milestoneName',
                align: 'center',
                menuDisabled: true,
                sortable: false,
                width: 400,
                renderer: function (value, meta, record) {
                    meta.style = 'white-space:normal;word-break:break-all;';
                    return value;
                }
            }, {
                text: hasEditAccess() ? '<span style="color: blue; "><b>*</b></span><span style="color: blue; ">操作</span>' : '操作',
                dataIndex: 'operation',
                align: 'center',
                //hidden: !isChange,
                menuDisabled: true,
                sortable: false,
                hidden: !isChange,
                width: 200,
                editor: {
                    xtype: 'combobox',
                    store: new Ext.data.Store({
                        fields: ['key', 'value'],
                        data: [['', ''], ['里程碑时间修改', '里程碑时间修改'], ['将活动设置为里程碑', '将活动设置为里程碑'],
                            ['将里程碑设置为活动', '将里程碑设置为活动'], ['里程碑删除', '里程碑删除'], ['未修改', '未修改']]
                    }),
                    displayField: 'value',
                    valueField: 'value',
                    triggerAction: 'all',
                    allowBlank: true,
                    forceSelection: true,
                    editable: false,
                    mode: 'local',
                    tpl: Ext.create('Ext.XTemplate',
                        '<tpl for=".">',
                        '<div class="x-boundlist-item" style="height:21px">{value}</div>',
                        '</tpl>'
                    )
                }
            }, {
                text: '初始计划完成时间',
                dataIndex: 'originalFinishDate',
                align: 'center',
                menuDisabled: true,
                sortable: false,
                width: 150,
                xtype: 'datecolumn',
                format: 'Y-m-d',
                renderer: function (value) {
                    var timeStr = value;
                    if (value != null && value !== '') {
                        var date = new Date(value);
                        timeStr = Ext.Date.format(date, "Y-m-d")
                    }
                    return timeStr;
                }
            }, {
                text: hasEditAccess() ? '<span style="color: blue; ">备注</span>' : '备注',
                dataIndex: 'remark',
                align: 'center',
                menuDisabled: true,
                hidden: isChange,
                sortable: false,
                width: 300,
                editor: {
                    xtype: 'textfield'
                }
            }, {
                text: '变更计划',
                hidden: !isChange,
                columns: [{
                    text: '变更前时间',
                    dataIndex: 'changeBeforeFinishDate',
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    width: 150,
                    xtype: 'datecolumn',
                    format: 'Y-m-d',
                    renderer: function (value) {
                        var timeStr = value;
                        if (value != null && value !== '') {
                            var date = new Date(value);
                            timeStr = Ext.Date.format(date, "Y-m-d")
                        }
                        return timeStr;
                    }
                }, {
                    text: hasEditAccess() && isChange ? '<span style="color: blue; "><b>*</b></span><span style="color: blue; ">变更后时间</span>' : '变更后时间',
                    dataIndex: 'changeAfterFinishDate',
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    width: 150,
                    xtype: 'datecolumn',
                    format: 'Y-m-d',
                    editor: {
                        xtype: 'datefield',
                        format: 'Y-m-d',
                        selectOnFocus: true,
                        allowBlank: false,
                        blankText: '时间不能为空'
                    },
                    renderer: function (value, meta, record) {
                        var timeStr = value;
                        if (value != null && value !== '') {
                            var date = new Date(value);
                            timeStr = Ext.Date.format(date, "Y-m-d")
                        }
                        if (record.get('changeBeforeFinishDate') > record.get('changeAfterFinishDate')) {
                            timeStr = '<span style="color: limegreen"><b>' + timeStr + '</b></span>'
                        } else if (record.get('changeBeforeFinishDate') < record.get('changeAfterFinishDate')) {
                            timeStr = '<span style="color: red"><b>' + timeStr + '</b></span>'
                        }
                        return timeStr;
                    }
                }, {
                    text: '差异(天)',
                    dataIndex: 'days',
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    width: 100
                }, {
                    text: '偏差率',
                    dataIndex: 'deviation',
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    width: 100,
                    renderer: function (v) {
                        if (v != null && v !== '') {
                            return parseFloat(v) + " %"
                        } else {
                            return v;
                        }
                    }
                }, {
                    text: hasEditAccess() && isChange ? '<span style="color: blue; ">变更备注</span>' : '变更备注',
                    dataIndex: 'remark',
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    width: 300,
                    editor: {
                        xtype: 'textfield'
                    }
                }]
            }],
            tbar: [{
                text: '刷新',
                iconCls: 'icon icon-refresh',
                hidden: !hasEditAccess() || isChange,
                handler: function () {
                    let successCallback = function () {
                        let grid = Ext.getCmp('milestoneGrid');
                        grid.getStore().load();
                    };
                    refreshMilestone(successCallback);
                }
            }, {
                text: '新增',
                iconCls: 'icon icon-add',
                hidden: !hasEditAccess() || !isChange,
                handler: function () {
                    newMilestoneWindow.show();
                }
            }, {
                text: '删除',
                iconCls: 'icon icon-delete',
                hidden: !hasEditAccess() || !isChange,
                handler: function () {
                    let grid = Ext.getCmp('milestoneGrid');
                    let selected = grid.getSelectionModel().getSelection();
                    if (selected.length === 0) {
                        Ext.Msg.alert('提示', "请选择相应数据");
                        return;
                    }
                    let confirmCallback = function (confirmParam) {
                        if (confirmParam !== 'yes') {
                            return;
                        }
                        var param = [];
                        for (let i = 0; i < selected.length; i++) {
                            param[i] = selected[i].get('id');
                        }
                        let successCallback = function () {
                            grid.getStore().load();
                        };
                        deleteMilestones(param, successCallback);
                    };
                    Ext.Msg.confirm('提示', '您确定要删除吗?', confirmCallback);
                }
            }],
            listeners: {
                edit: function (editor, e) {
                    var r = e.record; //得到当前行所有数据
                    var f = e.field; //得到修改列
                    var v = e.value; //得到修改列修改后值\
                    var rowIdx = e.rowIdx;
                    var oldValue = e.originalValue; //旧值
                    if ((oldValue == null || oldValue === '') && (v === '' || v == null)) {
                        r.set(f, oldValue);
                        return;
                    }

                    let param = r.data;
                    param['originalFinishDate'] = Ext.util.Format.date(param['originalFinishDate'], 'Y-m-d H:i:s');
                    param['changeBeforeFinishDate'] = Ext.util.Format.date(param['changeBeforeFinishDate'], 'Y-m-d H:i:s');
                    param['changeAfterFinishDate'] = Ext.util.Format.date(param['changeAfterFinishDate'], 'Y-m-d H:i:s');

                    let successCallback = function (data) {
                        console.log(data);
                        r['data'] = data;
                        r.commit();
                        if (isChange && f === 'changeAfterFinishDate') {
                            getMilestonePointInfo();
                        }
                    };

                    let failCallback = function () {
                        r.reject();
                    };

                    updateMilestone(param, successCallback, failCallback);
                },
                beforeedit: function (editor, e) {
                    if (!hasEditAccess()) {
                        return false;
                    }
                    let field = e.field;
                    let record = e.record;
                    //非变更，不允许编辑变更后日期
                    if (!isChange && field === 'changeAfterFinishDate') {
                        return false;
                    }
                    //变更，不允许编辑计划完成时间
                    if (isChange && field === 'originalFinishDate') {
                        return false;
                    }
                    //先选择操作 remark
                    if ((field === 'changeAfterFinishDate' || field === 'remark') && (record.get('operation') == null || record.get('operation') === '')) {
                        Ext.Msg.alert('提示', '请先选择操作');
                        return false;
                    }
                    //里程碑时间修改， 将活动设置为里程碑才需要修改变更后时间
                    if (field === 'changeAfterFinishDate' && record.get('operation') !== '里程碑时间修改' && record.get('operation') !== '将活动设置为里程碑') {
                        return false;
                    }
                }
            },
            bbar: Ext.create('Ext.PagingToolbar', {
                id: 'milestonePagingToolbar',
                store: milestoneStore,
                name: 'milestonePagingToolbar',
                displayInfo: true,
                hidden: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空",
                listeners: {
                    //点击下一页清除活动列表数据
                    change: function (t, p, e) {

                    }
                }
            }),//~End bbar
        });

        window.addEventListener('resize', function () {
            Ext.getCmp('milestoneGrid').setWidth(window.innerWidth - 10);
        });

        //**********里程碑点信息*************
        let milestonePanel = Ext.create('Ext.form.Panel', {
            xtype: 'form',
            title: '里程碑点',
            hidden: !isChange,
            id: 'milestoneForm',
            defaults: {
                border: true
            },
            items: [{
                xtype: 'panel',
                border: false,
                items: [{
                    xtype: 'panel',
                    border: false,
                    layout: {
                        type: 'hbox'
                    },
                    defaults: {
                        margin: '0 10 0 10',
                    },
                    items: [{
                        xtype: 'displayfield',
                        width: 300,
                        labelWidth: 150,
                        id: 'firstOriginalFinishDate',
                        fieldLabel: '初始版本首个里程碑'
                    }, {
                        xtype: 'displayfield',
                        width: 300,
                        labelWidth: 150,
                        id: 'lastOriginalFinishDate',
                        fieldLabel: '初始版本最后里程碑'
                    }, {
                        xtype: 'displayfield',
                        width: 300,
                        labelWidth: 150,
                        id: 'duration',
                        fieldLabel: '初始版本项目周期(天)'
                    }]
                }, {
                    xtype: 'panel',
                    border: false,
                    layout: {
                        type: 'hbox'
                    },
                    defaults: {
                        margin: '0 10 0 10',
                    },
                    items: [{
                        xtype: 'displayfield',
                        width: 300,
                        labelWidth: 150,
                        fieldLabel: '项目开工会日期(或项目开始日期)',
                        id: 'projectStartDate'
                    }, {
                        xtype: 'displayfield',
                        width: 300,
                        labelWidth: 150,
                        fieldLabel: '整体偏差率',
                        id: 'deviation'
                    }]
                }]
            }]
        });

        this.items = [basicInfoPanel, milestoneGrid, milestonePanel];
        this.callParent();
    },
    listeners: {
        'afterrender':

            function () {
                getHeadInfo();
                if (isChange) {
                    getMilestonePointInfo();
                }
                setDisabledDates();
            }
    }
});
