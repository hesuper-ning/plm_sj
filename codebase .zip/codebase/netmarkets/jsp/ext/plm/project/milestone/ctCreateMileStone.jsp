<%@ page import="com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinitionMaster" %>
<%@ page language="java" import="ext.plm.adminTool.configCenter.manager.CtConfigCenterManager" pageEncoding="UTF-8" %>
<%@ page import="ext.plm.adminTool.configCenter.manager.CtPropertyConfig" %>
<%@ page import="ext.plm.project.assocProduct.CtAssocProductHelper" %>
<%@ page import="ext.plm.project.milestone.CtMilestoneConstant" %>
<%@ page import="ext.plm.project.milestone.CtMilestoneLogic" %>
<%@ page import="ext.plm.util.CtFolderUtil" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="org.apache.commons.lang3.StringUtils" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.fc.PersistenceHelper" %>
<%@ page import="wt.fc.QueryResult" %>
<%@ page import="wt.folder.Folder" %>
<%@ page import="wt.pdmlink.PDMLinkProduct" %>
<%@ page import="wt.projmgmt.admin.Project2" %>
<%@ page import="wt.query.QuerySpec" %>
<%@ page import="wt.query.SearchCondition" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String projectOid = request.getParameter("oid");
        String folderOid = null;
        String productOid = null;
        String docNumber = null;
        String docType = null;
        boolean hasMainProduct = false;
        Project2 project = (Project2) CtWTObjectUtil.getObjectByOid(projectOid);
        //获取关联的主产品库
        PDMLinkProduct product = CtAssocProductHelper.getInstance().getMainProductByProject(project);
        if (product != null) {
            CtPropertyConfig ctPropertyConfig = CtConfigCenterManager.getInstance().loadProperty("MilestoneWfConfig");
            Folder folder = CtFolderUtil.getFolder(ctPropertyConfig.getValue("milestonePath"), product);
            folderOid = CtWTObjectUtil.getOid(folder);
            hasMainProduct = true;
            productOid = CtWTObjectUtil.getOid(product);
        }
        //获取项目关联的里程碑文档
        WTDocument doc = CtMilestoneLogic.getInstance().getMilestoneDocByProject(project);
        boolean hasMilestoneDoc = false;
        if (doc != null) {
            hasMilestoneDoc = true;
            docNumber = doc.getNumber();
        }
        //获取类型全路径
        QuerySpec qs = new QuerySpec(WTTypeDefinitionMaster.class);
        SearchCondition sc = new SearchCondition(WTTypeDefinitionMaster.class, WTTypeDefinitionMaster.DISPLAY_NAME_KEY, SearchCondition.EQUAL, CtMilestoneConstant.MILESTONE_DOC_TYPE);
        qs.appendWhere(sc);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        while (qr.hasMoreElements()) {
            WTTypeDefinitionMaster master = (WTTypeDefinitionMaster) qr.nextElement();
            if (!StringUtils.isNotEmpty(master.getDeleted_id())) {
                docType = master.getIntHid();
                docType = docType.replace("wt.doc.WTDocument|", "");
                break;
            }
        }
    %>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>创建里程碑文档</title>
</head>
<body>
<style>
</style>
<script>
    var hasMainProduct = <%=hasMainProduct%>;
    var hasMilestoneDoc = <%=hasMilestoneDoc%>;
    if (!hasMainProduct) {
        alert("当前项目没有关联主产品库");
        window.close();
    } else if (hasMilestoneDoc) {
        alert("当前项目已创建里程碑流程[" + "<%=docNumber%>" + ']');
        window.close();
    } else {
        location.href = "/Windchill/ptc1/document/create?ContainerOid=" + "<%=productOid%>" +
            "&wizardActionClass=ext.plm.processor.doc.CtDocCreateProcessor" +
            "&wizardActionMethod=execute" +
            "&actionName=create" +
            "&portlet=poppedup" +
            "&context=" + "<%="comp$folderbrowser_table$" + folderOid + "$"%>" +
            "&oid=" + "<%=folderOid%>" +
            "&projectOid=" + "<%=projectOid%>" +
            "&docType=" + "<%=docType%>" +
            "&AjaxEnabled=row" +
            "&u8=1";
    }
</script>
</body>
</html>
