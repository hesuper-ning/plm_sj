<%@ page import="ext.plm.adminTool.configCenter.manager.CtConfigCenterManager" %>
<%@ page import="ext.plm.adminTool.configCenter.manager.CtPropertyConfig" %>
<%@ page import="ext.plm.project.CtProjectHelper" %>
<%@ page import="ext.plm.project.milestone.CtMilestoneLogic" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.projmgmt.admin.Project2" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="java.util.List" %>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        // 表单编辑权限
        boolean isEditable = false;
        boolean isComplete = false;
        boolean isReadOnlyPage = false;
        boolean isChange = false;
        boolean isVRProject = false;
        long branchId = 0L;

        String oid = request.getParameter("oid");
        Persistable persistable = CtWTObjectUtil.getObjectByOid(oid);
        if (persistable instanceof WorkItem) {
            WorkItem workItem = (WorkItem) persistable;
            WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
            WTDocument doc = (WTDocument) workItem.getPrimaryBusinessObject().getObject();
            branchId = doc.getBranchIdentifier();
            isComplete = workItem.isComplete();
            CtPropertyConfig propertyConfig = CtConfigCenterManager.getInstance().loadProperty("MilestoneWfConfig");
            List<String> allowEditNodes = propertyConfig.getValues("allowEditNodes");
            isEditable = allowEditNodes.contains(activity.getName());
            isChange = !"A".equals(doc.getVersionIdentifier().getValue());
            Project2 project = CtMilestoneLogic.getInstance().getProjectBytMilestoneDoc(doc);
            if (project != null) {
                isVRProject = CtProjectHelper.getInstance().isVRProject(project);
            }
        } else {
            WTDocument doc = (WTDocument) persistable;
            Project2 project = CtMilestoneLogic.getInstance().getProjectBytMilestoneDoc(doc);
            if (project != null) {
                isVRProject = CtProjectHelper.getInstance().isVRProject(project);
            }
            branchId = doc.getBranchIdentifier();
            isReadOnlyPage = true;
            isChange = !"A".equals(doc.getVersionIdentifier().getValue());
        }
    %>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css?ver=1.0.0"/>
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="js/ctProjectMileStoneFn.js?ver=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctProjectMileStone.js?ver=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<style>
    .classDiv1 {
        font-size: 21px;
        color: red;
    }
</style>
<script>
    // ==============layout define area=================================//
    var isEditable = <%=isEditable%>;
    var isComplete = <%=isComplete%>;
    var isReadOnlyPage = <%=isReadOnlyPage%>;
    var isChange = <%=isChange%>;
    var branchId = <%=branchId%>;
    var isVRProject = <%=isVRProject%>;
    console.log(isChange);
    console.log(isVRProject);
    Ext.onReady(function () {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ProjectMileStone'
            }]
        });
    });
</script>
</body>
</html>
