<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.workflow.engine.WfActivity" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="ext.plm.temporaryTechnicalChanges.config.CtTechnicalChangeProperties" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        long timestamp = System.currentTimeMillis();
        boolean taskCompleted = false; //任务是否已完成
        boolean collapsedValue = false;
        String oid = request.getParameter("oid");
        String activityName = "";
        String currentActKey = "";
        String docNumber = "";
        String branchId = "";
                Persistable p = CtWTObjectUtil.getObjectByOid(oid);
        if(p instanceof WorkItem){
            WorkItem workItem = (WorkItem) CtWTObjectUtil.getObjectByOid(oid);
            WfActivity activity = (WfActivity) workItem.getSource().getObject();
            activityName = activity.getName();
            currentActKey = CtTechnicalChangeProperties.getActivityKey(activityName);
            WTDocument document = (WTDocument) workItem.getPrimaryBusinessObject().getObject();
            docNumber = document.getNumber();
            branchId = document.getBranchIdentifier()+"";
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
        }
        if(p instanceof WTDocument){
            WTDocument document = (WTDocument)p;
            docNumber = document.getNumber();
            branchId = document.getBranchIdentifier()+"";
            collapsedValue = true;
        }





    %>
    <script type="text/javascript">
        var docNumber = '<%=docNumber%>';
        var branchId = '<%=branchId%>';

        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";

        var collapsedValue = <%=collapsedValue%>;

        //列ID
        var fileColumnId = '';
        //列名
        var fileColumnName = '';
        //下载文件名称
        var uploadTableName = '';
        var gridName = '';
        //单一字段表ID
        var singleFieldId = '';

        //当前的任务完成状态
        var taskCompleted = false;
        <%if(taskCompleted){%>
        taskCompleted = true;
        <%}%>

        var readOnlyPage = false;

        // E:\sanjiangdaima\src\ext\plm\temporaryTechnicalChanges\bo\CtTechnicalChangeBo.java
        // E:\sanjiangdaima\src\ext\plm\part\replacePart\config\CtTechnicalChangeProperties
        // var url= "/Windchill/netmarkets/jsp/ext/plm/formexport/ctExportForm.jsp?changeRequestId="+changeRequestId;
        // var controll = false;// 下载表单
    </script>
        <%--<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">--%>
        <%--<link rel="stylesheet" type="text/css"--%>
        <%--      href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">--%>
        <%--<link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />--%>
        <%--<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>--%>
        <%--<script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>--%>
        <%--<script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>--%>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>

        <script type="text/javascript" src="js/ctTemporaryTechnicalChanges.js?_dc=<%=timestamp%>"></script>
        <script type="text/javascript" src="js/ctTemporaryTechnicalChangesFn.js?_dc=<%=timestamp%>"></script>
        <script type="text/javascript" src="js/uploadFilePanel.js?_dc=<%=timestamp%>"></script>
            <style>
                .x-form-item-label-default {
                    text-align: center;
                }
            </style>

</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            // margin: '10 10 10 10',
            items: [{
                region: 'center',
                xtype: 'ctTemporaryTechnicalChanges',
            }]
        });
    });
</script>
</body>
</html>