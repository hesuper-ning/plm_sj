Ext.define('PLM.view.ctTemporaryTechnicalChanges', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctTemporaryTechnicalChanges',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ctTemporaryTechnicalChanges',
    initComponent: function () {


        var isItLockedBOMCombo = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'isItLockedBOMCombo',
            id: 'isItLockedBOMCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '' },
                    { fullName: '是' },
                    { fullName: '否' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName',
            tpl: getXTemplate('fullName')
        });

        // =================================上传文档相关============================================================================

        //上传文件窗口
        var uploadImageWindow = Ext.create('Ext.Window', {
            title: '导入文件',
            width: 550,
            height: 350,
            //autoHeight : true,
            //autoWidth : true,
            closeAction: 'hide',
            id: 'uploadImageWindow',
            autoScroll: false,
            //closable:false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: {
                xtype: 'uploadFilePanel'
            }
        });

        var showColumns = [
            {text: '文档名称', dataIndex: 'fileName', flex: 1, menuDisabled: true, editor: false}
        ];



        var showStore = Ext.create('Ext.data.Store', {
            fields: ['fileName'],
            id: 'showStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/technicalChange/searchFileName?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false,
        });



        var showGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var showGrid = Ext.create('Ext.grid.Panel', {
            plugins: [showGridEditing],
            store: showStore,
            columns: showColumns,
            id:'showGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: {
                enableTextSelection: true
            },
            selModel: {
                type: "checkboxmodel",
                mode: 'SINGLE'//单选
                // mode: 'MULTI'//多选
            },
            tbar: [
                {
                    xtype: 'button',
                    text: '下载文件',
                    id: 'showInsert',
                    iconCls: 'icon icon-download',
                    handler: function () {
                        var recordList = showGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var fileName = recordList[0].data.fileName;
                            window.location.href = '/Windchill/ptc1/technicalChange/downLoadDoc?fileName='+fileName+'&branchId='+branchId;
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '删除文件',
                    id: 'showDelete',
                    hidden:disableNode(start_node)||disableNode(execute_processing_feedback)?false:true,
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        if("technicalChangeProduct,technicalChange,rawMaterial".includes(uploadTableName)){
                            if(!disableNode(start_node)){
                                alert("当前节点不允许删除该文件");
                                return;
                            }
                        }
                        if(("technicalChangeOther" === uploadTableName)){
                            if(!disableNode(execute_processing_feedback)){
                                alert("当前节点不允许删除该文件!");
                                return;
                            }
                        }
                        var recordList = showGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var fileName = recordList[0].data.fileName;
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/technicalChange/deleteFiles?fileName='+fileName+'&docNumber='+docNumber+
                                    '&fileColumnId='+fileColumnId+'&fileColumnName='+fileColumnName+'&uploadTableName='+uploadTableName,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                // params: JSON.stringify(record.data),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    alert(obj.msg)
                                    showStore.load({
                                        params: {
                                            fileColumnId: fileColumnId,
                                            fileColumnName: fileColumnName,
                                            uploadTableName:uploadTableName
                                        }
                                    });
                                    //刷新表格内的数据
                                    var uploadFormPannel = Ext.getCmp(gridName);
                                    // 获取关联的 Store
                                    var store = uploadFormPannel.getStore();
                                    // 更新 Store 中的数据
                                    store.load();
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '下载全部文件',
                    id: 'showAllInsert',
                    iconCls: 'icon icon-download',
                    handler: function () {
                        var recordList = showGrid.getSelectionModel().getSelection();

                        var store = showGrid.getStore(); // 获取Grid的数据源
                        var allData = store.getData().items; // 获取数据源中的所有数据
                        var concatenatedData = '';

                        if(allData){
                            for(let i = 0;i < allData.length; i++){
                                let rowData = allData[i].data;
                                if(i==0){
                                    concatenatedData = rowData['fileName']
                                }else {
                                    concatenatedData += ";;;qqq" + rowData['fileName'];
                                }
                            }
                        }

                        if (concatenatedData.length != 0) {
                            //     window.location.href = '/Windchill/ptc1/technicalChange/downLoadAllDoc?fileName='+concatenatedData+'&branchId='+branchId;
                            // 创建一个 form 表单
                            var form = document.createElement('form');
                            form.method = 'POST';
                            form.action = '/Windchill/ptc1/technicalChange/downLoadAllDoc';

                            // 创建一个 input 元素用于存放参数
                            var fileNameInput = document.createElement('input');
                            fileNameInput.type = 'hidden';
                            fileNameInput.name = 'fileName';
                            fileNameInput.value = concatenatedData;
                            form.appendChild(fileNameInput);

                            var branchIdInput = document.createElement('input');
                            branchIdInput.type = 'hidden';
                            branchIdInput.name = 'branchId';
                            branchIdInput.value = branchId;
                            form.appendChild(branchIdInput);
                            // 将表单添加到页面中
                            document.body.appendChild(form);
                            // 提交表单
                            form.submit();

                        } else {
                            alert("当前没有可以下载的文件！")
                        }
                    }
                },
            ]
            // 其他配置项...
        });

        var showFile = Ext.create('Ext.Window', {
            id:'show1',
            title: '文档操作',
            width: 700,
            //height: 300,
            autoHeight : true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal:true,
            items:[showGrid],
        });
        // =================================上传文档相关============================================================================


        // ================================================相关成品半成品收集开始================================================================================
        Ext.define('collectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'partNumber','describe','partState'
            ],
            idProperty: 'collectModel'
        });

        var collectStore = Ext.create('Ext.data.Store', {
            model: 'collectModel',
            id: 'collectStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/collectProduct',
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'collectModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false,
        });

        var collectColumns = [
            {text: '成品/半成品编码', dataIndex: 'partNumber', flex: 1,menuDisabled: true, editor: false,},
            {text: '成品/半成品描述', dataIndex: 'describe',flex: 1, editor: false , menuDisabled: true}
        ];

        var collectGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var collectGrid = Ext.create('Ext.grid.Panel', {
            plugins: [collectGridEditing],
            store: collectStore,
            columns: collectColumns,
            id:'collectGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:300,
            multiSelect : false,
            viewConfig: {
                enableTextSelection: true
            },
            autoScroll: true,
            forceFit: false,
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '确定（B）',
                    id: 'collectInsert',
                    iconCls: 'icon icon-add',
                    handler: function () {
                        var relatedMaterials =  Ext.getCmp('partNumber').getValue();
                        var recordList = collectGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for (var i = 0; i < recordList.length; i++) {
                                updateArr.push(recordList[i].data.partNumber)
                            }
                            // 添加遮罩
                            Ext.getBody().mask('正在处理，请稍候...');
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/insertCollectProduct?docNumber='+docNumber+'&relatedMaterials='+relatedMaterials,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                timeout: 1000000,
                                success: function (response, opts) {
                                    // 移除遮罩
                                    Ext.getBody().unmask();
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        relatedRawMaterialsStore.load();
                                        relatedProductsStore.load();
                                        trialMBOMStore.load();
                                        collect.close();
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {

                                    // 移除遮罩
                                    Ext.getBody().unmask();

                                    alert('错误：添加信息失败!!!');
                                }
                            });
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '取消（B）',
                    id: 'collectDelete',
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        collect.close();
                    }
                }
            ]
        });


        var collect = Ext.create('Ext.Window', {
            id:'collect',
            title: '相关成品半成品收集（M视图）',
            width: 700,
            height: 400,
            autoHeight : true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal:true,
            items:[
                {
                    xtype: 'displayfield',
                    fieldLabel: '原材料编码',
                    id: 'partNumber',
                    name: 'partNumber',
                    value:'',
                    // width: 200,

                },{
                    xtype: 'displayfield',
                    fieldLabel: '原材料描述',
                    id: 'describe',
                    name: 'describe',
                    value:'',
                    // width: 300,

                },
                collectGrid
            ]
        });
// ================================================相关成品半成品收集结束================================================================================


        Ext.Ajax.request({
            url: '/Windchill/ptc1/searchTechnicalChange?docNumber='+docNumber,
            method:'POST',
            headers: {'Content-Type':'application/json'},
            success: function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.message=='success') {
                    var technicalChange = Ext.decode(response.responseText).data;
                    // 获取文本输入框组件
                    //路由
                    var route = Ext.getCmp('route');
                    if(route!== 'undefined') {
                        var routeValue = technicalChange.route;
                        if (routeValue != null) {
                            // 设置输入框的值为 '新的值'
                            route.setValue(routeValue.split(","));
                        }
                    }
                    //产品更改类别
                    var productChangeCategory = Ext.getCmp('productChangeCategory');
                    if(productChangeCategory!== 'undefined') {
                        var productChangeCategoryValue = technicalChange.productChangeCategory;
                        if (productChangeCategoryValue != null) {
                            productChangeCategory.setValue(productChangeCategoryValue.split(","));
                        }
                    }

                    //更改原因
                    var reasonForChange = Ext.getCmp('reasonForChange');
                    if(reasonForChange!== 'undefined') {
                        var reasonForChangeValue = technicalChange.reasonForChange;
                        if (reasonForChangeValue != null) {
                            reasonForChange.setValue(reasonForChangeValue);
                        }
                    }

                    //更改内容详细说明
                    var detailedDesOfChangeContent = Ext.getCmp('detailedDesOfChangeContent');
                    if(detailedDesOfChangeContent!== 'undefined') {
                        var detailedDesOfChangeContentValue = technicalChange.detailedDesOfChangeContent;
                        if (detailedDesOfChangeContentValue != null) {
                            detailedDesOfChangeContent.setValue(detailedDesOfChangeContentValue);
                        }
                    }

                    //在途
                    var inTransit = Ext.getCmp('inTransit');
                    if(inTransit!== 'undefined') {
                        var inTransitValue = technicalChange.inTransit;
                        if (inTransitValue != null) {
                            inTransit.setValue(inTransitValue);
                        }
                    }

                    //在制
                    var inProduction = Ext.getCmp('inProduction');
                    if(inProduction!== 'undefined') {
                        var inProductionValue = technicalChange.inProduction;
                        if (inProductionValue != null) {
                            inProduction.setValue(inProductionValue);
                        }
                    }

                    //库存
                    var inventory = Ext.getCmp('inventory');
                    if(inventory!== 'undefined') {
                        var inventoryValue = technicalChange.inventory;
                        if (inventoryValue != null) {
                            inventory.setValue(inventoryValue);
                        }
                    }

                    //申请人
                    var applicant = Ext.getCmp('applicant');
                    if(applicant!== 'undefined') {
                        var applicantValue = technicalChange.applicant;
                        if (applicantValue != null) {
                            applicant.setValue(applicantValue);
                        }
                    }

                    //申请部门
                    var applicationDepartment = Ext.getCmp('applicationDepartment');
                    if(applicationDepartment!== 'undefined') {
                        var applicationDepartmentValue = technicalChange.applicationDepartment;
                        if (applicationDepartmentValue != null) {
                            applicationDepartment.setValue(applicationDepartmentValue);
                        }
                    }

                    //申请日期
                    var applicationDate = Ext.getCmp('applicationDate');
                    if(applicationDate!== 'undefined') {
                        var applicationDateValue = technicalChange.applicationDate;
                        if (applicationDateValue != null) {
                            var dateObj = new Date(applicationDateValue); // 创建一个 Date 对象
                            var formattedTime = Ext.Date.format(dateObj, 'Y-m-d H:i:s');
                            applicationDate.setValue(formattedTime);
                        }
                    }
                    // alert('relatedAccessories')
                    // //相关附件
                    // var relatedAccessories = Ext.getCmp('relatedAccessories');
                    // if(relatedAccessories!== 'undefined') {
                    //     var relatedAccessoriesValue = technicalChange.relatedAccessories;
                    //     if (relatedAccessoriesValue != null) {
                    //
                    //         relatedAccessories.setValue(relatedAccessoriesValue);
                    //     }
                    // }
                    // alert('采购审批结果')
                    // //采购审批结果
                    // var purchaseResult = Ext.getCmp('purchaseResult');
                    // if(purchaseResult!== 'undefined') {
                    //     var purchaseResultValue = technicalChange.purchaseResult;
                    //     if (purchaseResultValue !== 'undefined') {
                    //         purchaseResult.setValue(purchaseResultValue);
                    //     }
                    // }

                    //采购审批意见
                    var purchaseIllustrate = Ext.getCmp('purchaseIllustrate');
                    if(purchaseIllustrate!== 'undefined') {
                        var purchaseIllustrateValue = technicalChange.purchaseIllustrate;
                        if (purchaseIllustrateValue != null) {
                            purchaseIllustrate.setValue(purchaseIllustrateValue);
                        }
                    }

                    //采购审批人
                    var purchaseApprovedBy = Ext.getCmp('purchaseApprovedBy');
                    if(purchaseApprovedBy!== 'undefined') {
                        var purchaseApprovedByValue = technicalChange.purchaseApprovedBy;
                        if (purchaseApprovedByValue != null) {
                            purchaseApprovedBy.setValue(purchaseApprovedByValue);
                        }
                    }

                    //采购审批时间
                    var purchaseApprovalTime = Ext.getCmp('purchaseApprovalTime');
                    if(purchaseApprovalTime!== 'undefined') {
                        var purchaseApprovalTimeValue = technicalChange.purchaseApprovalTime;
                        if (purchaseApprovalTimeValue != null) {
                            var dateObj = new Date(purchaseApprovalTimeValue); // 创建一个 Date 对象
                            var formattedTime = Ext.Date.format(dateObj, 'Y-m-d H:i:s');
                            purchaseApprovalTime.setValue(formattedTime);
                        }
                    }

                    //物控审批意见
                    var materialControlIllustrate = Ext.getCmp('materialControlIllustrate');
                    if(materialControlIllustrate!== 'undefined') {
                        var materialControlIllustrateValue = technicalChange.materialControlIllustrate;
                        if (materialControlIllustrateValue != null) {
                            materialControlIllustrate.setValue(materialControlIllustrateValue);
                        }
                    }

                    //物控审批人
                    var materialControlApprovedBy = Ext.getCmp('materialControlApprovedBy');
                    if(materialControlApprovedBy!== 'undefined') {
                        var materialControlApprovedByValue = technicalChange.materialControlApprovedBy;
                        if (materialControlApprovedByValue != null) {
                            materialControlApprovedBy.setValue(materialControlApprovedByValue);
                        }
                    }

                    //物控审批时间
                    var materialControlApprovalTime = Ext.getCmp('materialControlApprovalTime');
                    if(materialControlApprovalTime!== 'undefined') {
                        var materialControlApprovalTimeValue = technicalChange.materialControlApprovalTime;
                        if (materialControlApprovalTimeValue != null) {
                            var dateObj = new Date(materialControlApprovalTimeValue); // 创建一个 Date 对象
                            var formattedTime = Ext.Date.format(dateObj, 'Y-m-d H:i:s');
                            materialControlApprovalTime.setValue(formattedTime);
                        }
                    }

                    //资料室锁定BOM处理结果
                    var referenceRoomResult = Ext.getCmp('referenceRoomResult');
                    if(referenceRoomResult!== 'undefined') {
                        var referenceRoomResultValue = technicalChange.referenceRoomResult;
                        if (referenceRoomResultValue != null) {
                            referenceRoomResult.setValue(referenceRoomResultValue);
                        }
                    }

                    //资料室审批人
                    var referenceRoomApprovedBy = Ext.getCmp('referenceRoomApprovedBy');
                    if(referenceRoomApprovedBy!== 'undefined') {
                        var referenceRoomApprovedByValue = technicalChange.referenceRoomApprovedBy;
                        if (referenceRoomApprovedByValue != null) {
                            referenceRoomApprovedBy.setValue(referenceRoomApprovedByValue);
                        }
                    }

                    //资料室审批时间
                    var referenceRoomApprovalTime = Ext.getCmp('referenceRoomApprovalTime');
                    if(referenceRoomApprovalTime!== 'undefined') {
                        var referenceRoomApprovalTimeValue = technicalChange.referenceRoomApprovalTime;
                        if (referenceRoomApprovalTimeValue != null) {
                            var dateObj = new Date(referenceRoomApprovalTimeValue); // 创建一个 Date 对象
                            var formattedTime = Ext.Date.format(dateObj, 'Y-m-d H:i:s');
                            referenceRoomApprovalTime.setValue(formattedTime);
                        }
                    }

                    //发起人处理意见
                    var handlingOpinions = Ext.getCmp('handlingOpinions');
                    if(handlingOpinions!== 'undefined') {
                        var handlingOpinionsValue = technicalChange.handlingOpinions;
                        if (handlingOpinionsValue != null) {
                            handlingOpinions.setValue(handlingOpinionsValue);
                        }
                    }

                    //发起人是否需要正式变更
                    var doWeNeedFormalChanges = Ext.getCmp('doWeNeedFormalChanges');
                    if(doWeNeedFormalChanges!== 'undefined') {
                        var doWeNeedFormalChangesValue = technicalChange.doWeNeedFormalChanges;
                        if (doWeNeedFormalChangesValue != null) {
                            doWeNeedFormalChanges.setValue(doWeNeedFormalChangesValue);
                        }
                    }

                    //发起人变更单号
                    var changeOrderNumber = Ext.getCmp('changeOrderNumber');
                    if(changeOrderNumber!== 'undefined') {
                        var changeOrderNumberValue = technicalChange.changeOrderNumber;
                        if (changeOrderNumberValue != null) {
                            changeOrderNumber.setValue(changeOrderNumberValue);
                        }
                    }

                    //发起人审批人
                    var initiateApprovedBy = Ext.getCmp('initiateApprovedBy');
                    if(changeOrderNumber!== 'undefined') {
                        var initiateApprovedByValue = technicalChange.initiateApprovedBy;
                        if (initiateApprovedByValue != null) {
                            initiateApprovedBy.setValue(initiateApprovedByValue);
                        }
                    }

                    //发起人审批时间
                    var initiateApprovalTime = Ext.getCmp('initiateApprovalTime');
                    if(initiateApprovalTime!== 'undefined') {
                        var initiateApprovalTimeValue = technicalChange.initiateApprovalTime;
                        if (initiateApprovalTimeValue != null) {
                            var dateObj = new Date(initiateApprovalTimeValue); // 创建一个 Date 对象
                            var formattedTime = Ext.Date.format(dateObj, 'Y-m-d H:i:s');
                            initiateApprovalTime.setValue(formattedTime);
                        }
                    }

                    //资料室确认确认结果
                    var confirmResults = Ext.getCmp('confirmResults');
                    if(confirmResults!== 'undefined') {
                        var confirmResultsValue = technicalChange.confirmResults;
                        if (confirmResultsValue != null) {
                            confirmResults.setValue(confirmResultsValue);
                        }
                    }

                    //资料室说明
                    var dataRoomDescription = Ext.getCmp('dataRoomDescription');
                    if(dataRoomDescription!== 'undefined') {
                        var dataRoomDescriptionValue = technicalChange.dataRoomDescription;
                        if (dataRoomDescriptionValue != null) {
                            dataRoomDescription.setValue(dataRoomDescriptionValue);
                        }
                    }


                    //资料室确认审批人
                    var approvedBy = Ext.getCmp('approvedBy');
                    if(approvedBy!== 'undefined') {
                        var approvedByValue = technicalChange.approvedBy;
                        if (approvedByValue != null) {
                            approvedBy.setValue(approvedByValue);
                        }
                    }

                    //资料室确认审批时间
                    var approvalTime = Ext.getCmp('approvalTime');
                    if(approvalTime!== 'undefined') {
                        var approvalTimeValue = technicalChange.approvalTime;
                        if (approvalTimeValue != null) {
                            var dateObj = new Date(approvalTimeValue); // 创建一个 Date 对象
                            var formattedTime = Ext.Date.format(dateObj, 'Y-m-d H:i:s');
                            approvalTime.setValue(formattedTime);
                        }
                    }
                }else {
                    alert(obj.message)
                }
            },
            failure: function (response, opts) {
                alert('错误：查询信息失败！！！');
            }
        });

        //---------------------------------------- 临时技术更改单个字段表 --------------------------------------------------------
        var route = Ext.create('Ext.form.field.ComboBox', {
            fieldLabel:  (disableNode(start_node) ? '<span style="color: red;">*</span> ' : '')+'路由',
            labelWidth: 50,
            labelStyle: disableNode(start_node)?'color: blue':'',
            width: 250,
            // width: '20%',
            id: 'route',
            name: 'route',
            readOnly:disableNode(start_node)?false:true,
            margin: '0 200 0 20',
            multiSelect: true,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '立即更改' },
                    { fullName: 'BOM锁定' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName',
            listeners: {
                select: function(combo, records) {
                    var route =  combo.getValue();
                    route = route.join(',');
                    technicalChange(docNumber,"route",route)
                }
            }
        });


        var productChangeCategory = Ext.create('Ext.form.field.ComboBox', {
            fieldLabel: (disableNode(start_node) ? '<span style="color: red;">*</span> ' : '')+'产品更改类别',
            id: 'productChangeCategory',
            name: 'productChangeCategory',
            readOnly:disableNode(start_node)?false:true,
            labelWidth: 100,
            labelStyle: disableNode(start_node)?'color: blue':'',
            width: 250,
            // width: '20%',
            margin: '0 200 0 20',
            multiSelect: true,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '硬件' },
                    { fullName: '软件' },
                    { fullName: '结构' },
                    { fullName: '其他' },
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName',
            listeners: {
                select: function(combo, records) {
                    var productChangeCategory =  combo.getValue();
                    productChangeCategory = productChangeCategory.join(',');
                    technicalChange(docNumber,"productChangeCategory",productChangeCategory)
                }
            }
        });

        var reasonForChange  = Ext.create('Ext.form.field.TextArea', {
            margin: '0 200 0 20',
            fieldLabel: (disableNode(start_node) ? '<span style="color: red;">*</span> ' : '')+'更改原因',
            labelWidth: 70,
            width:850,
            labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'reasonForChange',
            name: 'reasonForChange',
            readOnly:disableNode(start_node)?false:true,
            listeners: {
                blur: function(field) {
                    var reasonForChange = field.getValue();
                    technicalChange(docNumber,"reasonForChange",reasonForChange)
                }
            }
        });

        var detailedDesOfChangeContent = Ext.create('Ext.form.field.TextArea', {
            margin: '0 200 0 20',
            fieldLabel: (disableNode(start_node) ? '<span style="color: red;">*</span> ' : '')+'更改内容详细说明',
            labelWidth: 120,
            width:850,
            labelStyle: disableNode(start_node)?'color: blue':'',
            id: 'detailedDesOfChangeContent',
            name: 'detailedDesOfChangeContent',
            readOnly:disableNode(start_node)?false:true,
            listeners: {
                blur: function(field) {
                    var detailedDesOfChangeContent = field.getValue();
                    technicalChange(docNumber,"detailedDesOfChangeContent",detailedDesOfChangeContent)
                }
            }
        });




        var firstLine  = {
            xtype: 'form',
            // title: '1、临时更改描述',
            id: 'firstLine',
            width: '100%',
            hideLabel: true,
            frame: false,
            border: false,
            layout: "anchor",
            items: [
                {
                    xtype: 'container',
                    layout: 'hbox',
                    defaultType: 'textfield',
                    margin: '10 0 10 10',
                    items: [
                        route,  reasonForChange
                    ]
                },{
                    xtype: 'container',
                    layout: 'hbox',
                    defaultType: 'textfield',
                    margin: '10 0 10 10',
                    items: [
                        productChangeCategory, detailedDesOfChangeContent
                    ]
                },{
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '10 0 10 20',
                    items: [
                        {
                            xtype: 'textfield',
                            labelWidth: 300,
                            fieldLabel: (disableNode(start_node) ? '<span style="color: red;">*</span> ' : '')+'相关附件（验证文件，如会议纪要、自测报告等）',
                            labelStyle: disableNode(start_node)?'color: blue':'',
                            width:'0',
                            readOnly: true
                        },
                        {
                            xtype: 'button',
                            text: '添加文件',
                            iconCls: 'icon icon-uploadImage',
                            hidden:disableNode(start_node)?false:true,
                            handler: function() {
                                //设置当前列的id与列名和表名
                                fileColumnId = docNumber;
                                fileColumnName = 'relatedAccessories';
                                uploadTableName = 'technicalChange';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = 'relatedRawMaterialsGrid';

                                uploadImageWindow.show();
                            }
                        },
                        {
                            xtype: 'button',
                            text: '查看文件',
                            iconCls: 'icon-showInfo',
                            handler: function() {
                                //设置当前列的id与列名和表名
                                fileColumnId = docNumber;
                                fileColumnName = 'relatedAccessories';
                                uploadTableName = 'technicalChange';
                                //设置grid名称用于上传文件后刷新数据
                                gridName = 'relatedRawMaterialsGrid';
                                // 刷新当前单元格内文件
                                showStore.load({
                                    params: {
                                        fileColumnId: fileColumnId,
                                        fileColumnName: fileColumnName,
                                        uploadTableName:uploadTableName
                                    }
                                });
                                showFile.show();
                            }
                        }
                    ]
                }
            ]
        };
        var firstLinePanel  = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: '1、临时更改描述',
            // padding:'5',
            // collapsed:disableNode(start_node)||disableNode(execute_processing_feedback)||collapsedValue?false:true,
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            width: '100%',
            anchor:'100%',
            defaults: {
                labelWidth: 80,
                border: false
            },
            items:[
                firstLine
            ]
        });


        //---------------------------------------- 相关物料 --------------------------------------------------------
        Ext.define('relatedRawMaterialsModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id',
                'serialNumber',
                "partNumber",
                "version",
                "partState",
                'describe',
                'specialCustomers',
                'pCN',
                'pCNPath'
            ],
            idProperty: 'relatedRawMaterialsModel'
        });


        var relatedRawMaterialsColumns = [
            {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
            {text: (disableNode(start_node) ? '<span style="color: red;">*</span> ' : '')+'物料编码', flex: 1,align: 'center',dataIndex: 'partNumber', menuDisabled:true,
                editor:disableNode(start_node)?true:false,style: disableNode(start_node)?'color: blue;':''},
            {text: '版本（视图）', flex: 1,align: 'center',dataIndex: 'version', menuDisabled:true, editor:false},
            {text: '状态', flex: 1,align: 'center',dataIndex: 'partState', menuDisabled:true, editor:false},
            {text: '物料描述', flex: 1,align: 'center',dataIndex: 'describe', menuDisabled:true, editor:false},
            {text: '内部版本/软件版次信息',flex: 1, align: 'center',dataIndex: 'internalVersion', menuDisabled:true, editor:false},
            {text: '变更后内部版本/软件版次信息',flex: 1, align: 'center',dataIndex: 'internalVersionAfter', menuDisabled:true,
                editor:disableNode(start_node)?true:false,style: disableNode(start_node)?'color: blue;':''},
            {text: '变更后资料',width: 200, align: 'center',xtype:'actioncolumn', dataIndex: 'informationAfterChange', editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:disableNode(start_node)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'informationAfterChange';
                            uploadTableName = 'rawMaterial';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'relatedRawMaterialsGrid';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.environmentalReport;
                            // if(boolean!=null) {
                            //     return true;
                            // }
                            // return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'informationAfterChange';
                            uploadTableName = 'rawMaterial';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'relatedRawMaterialsGrid';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.environmentalReport;
                            // if(boolean!=null) {
                            //     return false;
                            // }
                            // return true;
                        }
                    }
                ]
            }
        ];


        var relatedRawMaterialsStore = Ext.create('Ext.data.Store', {
            model: 'relatedRawMaterialsModel',
            id: 'relatedRawMaterialsStore',
            name:'relatedRawMaterialsStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/searchRawMaterial?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'relatedProductsModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,

            listeners: {
                load: function() {

                }
            }

        });

        var relatedRawMaterialsGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var relatedRawMaterialsGrid = Ext.create('Ext.grid.Panel', {
            plugins: [relatedRawMaterialsGridEditing],
            store: relatedRawMaterialsStore,
            columns: relatedRawMaterialsColumns,
            id:'relatedRawMaterialsGrid',
            title: '相关原材料、半成品(外购机箱、组件等)',
            // autoWidth: true,
            columnLines: true,
            height:300,
            width: '100%',
            multiSelect : false,
            // autoScroll: true,
            forceFit: false,
            style: {
                border: '1px solid #CCCCCC' // 添加灰色边框
            },
            viewConfig: { enableTextSelection:true,forceFit: false },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '增加物料（B）',
                    id: 'relatedRawMaterialsInsert',
                    iconCls: 'icon icon-add',
                    hidden: disableNode(start_node)?false:true,
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/insertRawMaterial?docNumber='+docNumber,
                            method:'POST',
                            headers: {'Content-Type':'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success') {
                                    relatedRawMaterialsStore.load();
                                }else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：新增信息失败!!!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除物料（B）',
                    id: 'relatedRawMaterialsDelete',
                    iconCls: 'icon icon-delete',
                    hidden: disableNode(start_node)?false:true,
                    handler: function () {
                        var recordList = relatedRawMaterialsGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for(var i = 0; i<recordList.length; i++){
                                updateArr.push(recordList[i].data.id)
                            };
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/deleteRawMaterial?docNumber='+docNumber,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        var obj = Ext.decode(response.responseText);
                                        alert("成功删除" + obj.data + "条信息！")
                                        relatedRawMaterialsStore.load();
                                        relatedProductsStore.load();
                                        trialMBOMStore.load();
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败!!!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },{
                    xtype: 'button',
                    text: '收集相关（半）成品（M视图）',
                    id: 'relatedRawMaterialsDelete1',
                    iconCls: 'icon icon-add',
                    hidden: disableNode(start_node)?false:true,
                    handler: function () {
                        var selectedRecords = relatedRawMaterialsGrid.getSelectionModel().getSelection();
                        if (selectedRecords.length == 0||selectedRecords.length>1) {
                            alert("只能选择一条数据！");
                            return;
                        }
                        var partNumber = selectedRecords[0].data.partNumber;
                        var describe = selectedRecords[0].data.describe;
                        Ext.getCmp('partNumber').setValue(partNumber);
                        Ext.getCmp('describe').setValue(describe);
                        Ext.getStore('collectStore').reload({
                            params: {
                                partNumber: partNumber
                            }
                        });
                        collect.show();

                    }
                },
            ]
        });

        relatedRawMaterialsGrid.on('edit',function(editor,e){
            var idx = e.rowIdx
            var record = relatedRawMaterialsGrid.getStore().getAt(idx);
            Ext.Ajax.request({
                url: '/Windchill/ptc1/saveRawMaterial',
                method:'POST',
                headers: {'Content-Type':'application/json'},
                params: JSON.stringify(record.data),
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        var obj = Ext.decode(response.responseText);
                        e.record.commit();
                        relatedRawMaterialsStore.load();
                        trialMBOMStore.load();
                    }else {
                        relatedRawMaterialsStore.load();
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    relatedRawMaterialsStore.load();
                    alert('错误：修改信息失败，请检查网络！!');
                }
            });
        });


//---------------------------------------- 相关成品/半成品 --------------------------------------------------------
        Ext.define('relatedProductsModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id',
                'serialNumber',
                "partNumber",
                "version",
                "partState",
                'describe',
                'specialCustomers',
                'pCN',
                'pCNPath',
                'relatedMaterials'
            ],
            idProperty: 'relatedProductsModel'
        });


        var relatedProductsColumns = [
            {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
            {text: (disableNode(start_node) ? '<span style="color: red;">*</span> ' : '')+'物料编码', flex: 1,align: 'center',dataIndex: 'partNumber', menuDisabled:true, editor:disableNode(start_node)?true:false,style: disableNode(start_node)?'color: blue;':''},
            {text: '版本（视图）', flex: 1,align: 'center',dataIndex: 'version', menuDisabled:true, editor:false},
            {text: '状态', flex: 1,align: 'center',dataIndex: 'partState', menuDisabled:true, editor:false},
            {text: '物料描述', flex: 1,align: 'center',dataIndex: 'describe', menuDisabled:true, editor:false},
            {text: '是否锁定BOM', flex: 1,align: 'center',dataIndex: 'isItLockedBOM', menuDisabled:true, editor:disableNode(start_node)?isItLockedBOMCombo:false,style: disableNode(start_node)?'color: blue;':''},
            {text: '特殊客户',flex: 1, align: 'center',dataIndex: 'specialCustomers', menuDisabled:true, editor:false},
            {text: 'PCN',width: 200, align: 'center',xtype:'actioncolumn', dataIndex: 'pCN', editor: false, menuDisabled: true,
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:disableNode(start_node)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('serialNumber');
                            fileColumnName = 'pCN';
                            uploadTableName = 'technicalChangeProduct';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'relatedProductsGrid';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.environmentalReport;
                            // if(boolean!=null) {
                            //     return true;
                            // }
                            // return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('serialNumber');
                            fileColumnName = 'pCN';
                            uploadTableName = 'technicalChangeProduct';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'relatedProductsGrid';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.environmentalReport;
                            // if(boolean!=null) {
                            //     return false;
                            // }
                            // return true;
                        }
                    }
                ]
            },
            {text: '相关物料',flex: 1, align: 'center',dataIndex: 'relatedMaterials', menuDisabled:true, editor:false}
        ];


        var relatedProductsStore = Ext.create('Ext.data.Store', {
            model: 'relatedProductsModel',
            id: 'relatedProductsStore',
            name:'relatedProductsStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/searchTechnicalChangeProduct?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'relatedProductsModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,

            listeners: {
                load: function() {

                }
            }

        });

        var relatedProductsGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var relatedProductsGrid = Ext.create('Ext.grid.Panel', {
            plugins: [relatedProductsGridEditing],
            store: relatedProductsStore,
            columns: relatedProductsColumns,
            id:'relatedProductsGrid',
            title: '相关成品/半成品',
            // autoWidth: true,
            columnLines: true,
            height:300,
            width: '100%',
            multiSelect : false,
            // autoScroll: true,
            forceFit: false,
            style: {
                border: '1px solid #CCCCCC' // 添加灰色边框
            },
            viewConfig: { enableTextSelection:true,forceFit: false },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '增加产品（B）',
                    id: 'relatedProductsInsert',
                    iconCls: 'icon icon-add',
                    hidden: disableNode(start_node)?false:true,
                    handler: function () {
                        Ext.getCmp('relatedProductsInsert').setDisabled(true);
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/insertTechnicalChangeProduct?docNumber='+docNumber,
                            method:'POST',
                            headers: {'Content-Type':'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success') {
                                    relatedProductsStore.load();
                                }else {
                                    alert(obj.message);
                                }
                                Ext.getCmp('relatedProductsInsert').setDisabled(false);
                            },
                            failure: function (response, opts) {
                                Ext.getCmp('relatedProductsInsert').show();
                                alert('错误：新增信息失败!!!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除产品（B）',
                    id: 'relatedProductsDelete',
                    iconCls: 'icon icon-delete',
                    hidden: disableNode(start_node)?false:true,
                    handler: function () {
                        var recordList = relatedProductsGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for(var i = 0; i<recordList.length; i++){
                                updateArr.push(recordList[i].data.serialNumber)
                            };
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/deleteTechnicalChangeProduct?docNumber='+docNumber,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        var obj = Ext.decode(response.responseText);
                                        alert("成功删除" + obj.data + "条信息！")
                                        relatedProductsStore.load();
                                        trialMBOMStore.load();
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败!!!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }
            ]
        });

        relatedProductsGrid.on('edit',function(editor,e){
            var idx = e.rowIdx
            var record = relatedProductsGrid.getStore().getAt(idx);
            Ext.Ajax.request({
                url: '/Windchill/ptc1/saveTechnicalChangeProduct',
                method:'POST',
                headers: {'Content-Type':'application/json'},
                params: JSON.stringify(record.data),
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        var obj = Ext.decode(response.responseText);
                        e.record.commit();
                        relatedProductsStore.load();
                        trialMBOMStore.load();
                    }else {
                        relatedProductsStore.load();
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    relatedProductsStore.load();
                    alert('错误：修改信息失败，请检查网络！!');
                }
            });
        });

        //根据特定字段的值判断是否禁止编辑
        relatedProductsGrid.on('beforeedit', function (editor, context) {
            var record = context.record;
            var route = Ext.getCmp('route').getValue()
            if(!route){
                return true; // 允许编辑操作
            }
            // 判断点击的是哪一列，列名
            var columnName = context.column.dataIndex;
            if (!route.includes("BOM锁定")&& columnName === 'isItLockedBOM') {
                return false; // 禁止编辑指定列
            }
            return true; // 允许编辑操作
        });





        var displayField = Ext.create('Ext.form.field.Display', {
            padding: '10px', // 设置文本内容的内边距
            margin: '30 15 50 10' ,// 设置输入框之间的距离为 10 像素
            value: '物料处理意见' ,// 设置要展示的文本内容
            width: 50
        });
        // 创建垂直布局的容器
        var leftContainer = Ext.create('Ext.container.Container', {
            layout: 'vbox',
            // height: 'auto',
            height: '100%',
            style: {
                border: '1px solid black' // 设置容器的边框样式为 1 像素宽的黑色实线边框
            },
            width: '5%',
            items: [displayField]
        });

        // 创建输入框
        var inTransit  = Ext.create('Ext.form.field.Text', {
            fieldLabel: (disableNode(start_node)||disableNode(department_manager_review) ? '<span style="color: red;">*</span> ' : '')+'在途',
            labelSeparator: '',
            labelStyle: disableNode(start_node)||disableNode(department_manager_review)?'color: blue':'',
            id: 'inTransit',
            name: 'inTransit',
            readOnly:disableNode(start_node)||disableNode(department_manager_review)?false:true,
            style: {
                border: '1px solid black' // 设置容器的边框样式为 1 像素宽的黑色实线边框
            },
            width: '100%',
            labelWidth: 50,
            height: '33%',
            margin: '0 2 0 0' ,// 设置输入框之间的距离为 10 像素
            emptyText: '（隔离 / 返工 / 不处理等）',
            listeners: {
                blur: function(field) {
                    var inTransit = field.getValue();
                    technicalChange(docNumber,"inTransit",inTransit)
                }
            }
        });

        var inProduction = Ext.create('Ext.form.field.Text', {
            fieldLabel: (disableNode(start_node)||disableNode(department_manager_review) ? '<span style="color: red;">*</span> ' : '')+'在制',
            labelSeparator: '',
            labelStyle: disableNode(start_node)||disableNode(department_manager_review)?'color: blue':'',
            id: 'inProduction',
            name: 'inProduction',
            readOnly:disableNode(start_node)||disableNode(department_manager_review)?false:true,
            style: {
                borderTop: '2px solid black',  // 设置上边框为2像素宽的黑色实线边框
                borderBottom: '1px solid black', // 设置下边框为1像素宽的黑色实线边框
                borderLeft: '1px solid black',   // 设置左边框为1像素宽的黑色实线边框
                borderRight: '2px solid black'    // 设置右边框为1像素宽的黑色实线边框
            },
            width: '100%',
            labelWidth: 50,
            height: '33%',
            margin: '0 2 0 0' ,// 设置输入框之间的距离为 10 像素
            emptyText: '（隔离 / 返工 / 不处理等）',
            listeners: {
                blur: function(field) {
                    var inProduction = field.getValue();
                    technicalChange(docNumber,"inProduction",inProduction)
                }
            }
        });

        var inventory = Ext.create('Ext.form.field.Text', {
            fieldLabel: (disableNode(start_node)||disableNode(department_manager_review) ? '<span style="color: red;">*</span> ' : '')+'库存',
            labelSeparator: '',
            labelStyle: disableNode(start_node)||disableNode(department_manager_review)?'color: blue':'',
            id: 'inventory',
            name: 'inventory',
            readOnly:disableNode(start_node)||disableNode(department_manager_review)?false:true,
            style: {
                border: '1px solid black' // 设置容器的边框样式为 1 像素宽的黑色实线边框
            },
            width: '100%',
            labelWidth: 50,
            height: '34%',
            margin: '0 2 0 0' ,// 设置输入框之间的距离为 10 像素
            emptyText: '（隔离 / 返工 / 不处理等）',
            listeners: {
                blur: function(field) {
                    var inventory = field.getValue();
                    technicalChange(docNumber,"inventory",inventory)
                }
            }
        });

        // 创建垂直布局的容器
        var leftContainer1 = Ext.create('Ext.container.Container', {
            layout: 'vbox',
            height: '100%',
            margin: '0 0 0 0', // 设置输入框之间的距离为 10 像素
            style: {
                borderTop: '1px solid black',  // 设置上边框为2像素宽的黑色实线边框
                borderBottom: '2px solid black', // 设置下边框为1像素宽的黑色实线边框
                borderLeft: '1px solid black',   // 设置左边框为1像素宽的黑色实线边框
                borderRight: '2px solid black'    // 设置右边框为1像素宽的黑色实线边框
            },
            width: '95%',
            items: [inTransit,inProduction,inventory]
        });

        // 创建水平布局的容器
        var container1 = Ext.create('Ext.container.Container', {
            layout: 'hbox',
            // height: 'auto',
            height: 100,
            margin: '10 5 10 5', // 设置输入框之间的距离为 10 像素
            style: {
                border: '1px solid black' // 设置容器的边框样式为 1 像素宽的黑色实线边框
            },
            items: [leftContainer, leftContainer1]
        });


        //---------------------------------------- 试用MBOM --------------------------------------------------------

        var parentNumberCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'parentNumberCom',
            id: 'parentNumberCom',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['parentNumber']
            },
            valueField: 'fullName',
            displayField: 'fullName'
        });

        var changeType = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'changeTypeCombo',
            id: 'changeTypeCombo',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '' },
                    { fullName: '增加' },
                    { fullName: '删除' },
                    { fullName: '修改' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName',
            tpl: getXTemplate('fullName')
        });


        var supplierNameStore = new Ext.data.ArrayStore({
            id: 'supplierNameStore',
            fields: [
                {name: "supplierName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/supplierNameList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var supplierNameCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'supplierNameCom',
            id: 'supplierNameCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: supplierNameStore,
            valueField: 'supplierName',
            displayField: 'supplierName',
            minChars : 0,//开始查询最小字符数
            mode : 'local', //查询模式  local为本地数据源  remote为远程服务端
        });


        var supplierNameByPartNumberStore = new Ext.data.ArrayStore({
            id: 'supplierNameByPartNumberStore',
            fields: [
                {name: "supplierName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/common/supplierNameListByPartNumber',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });

        // // 创建一个真正的数据存储对象
        // var supplierNameByPartNumberStore = Ext.create('Ext.data.Store', {
        //     fields: ['supplierName'],
        //     data: [] // 初始化为空数组
        // });
        var supplierNameByPartNumberCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'supplierNameByPartNumberCom',
            id: 'supplierNameByPartNumberCom',
            multiSelect: true,
            anyMatch: true,
            editable: false,
            store: supplierNameByPartNumberStore,
            valueField: 'supplierName',
            displayField: 'supplierName',
            // minChars : 0,//开始查询最小字符数
            mode : 'local', //查询模式  local为本地数据源  remote为远程服务端
            listeners: {
                select: function(combo, records) {
                    var route =  combo.getValue();
                    route = route.join(',');
                    return route;
                }
            }
        });




        Ext.define('trialMBOMModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','parentNumber','referenceRelationship','parentName','changeType',
                'childNumberBefore','childNameBefore','amountBefore','bitNumberBefore','internalVersionBefore','bomRemarksBefore','supplierIdBefore',
                'childNumberAfter','childNameAfter','amountAfter','bitNumberAfter','internalVersionAfter','bomRemarksAfter','supplierIdAfter',
                'remark'
            ],
            idProperty: 'trialMBOMModel'
        });

        var trialMBOMStore = Ext.create('Ext.data.Store', {
            model: 'trialMBOMModel',
            id: 'trialMBOMStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/searchTechnicalChangeOnTrial?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'trialMBOMModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var trialMBOMColumns = [
            {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
            {text: '父项编码', dataIndex: 'parentNumber', flex: 1, editor: disableNode(start_node)?parentNumberCom:false, menuDisabled: true,
                style: disableNode(start_node)?'color: blue;':'',renderer:showTip
            },
            // {text: '引用关系', dataIndex: 'referenceRelationship', width: 300,menuDisabled: true,renderer:showTip},
            {text: '父项描述', dataIndex: 'parentName', flex: 1,menuDisabled: true,renderer:showTip},
            {text: '变更类型', dataIndex: 'changeType', flex: 1, editor: disableNode(start_node)?changeType:false ,
                menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
            },
            {
                text: '变更前',menuDisabled: true,flex: 7,
                columns: [
                    {text: '物料编码', dataIndex: 'childNumberBefore', flex: 1, editor: disableNode(start_node)?true:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
                    },
                    {text: '物料描述', dataIndex: 'childNameBefore', flex: 1, editor: null, menuDisabled: true,renderer:showTip
                    },
                    {text: '数量', dataIndex: 'amountBefore', flex: 1, editor: null, menuDisabled: true,renderer:showTip
                    },
                    {text: '位号', dataIndex: 'bitNumberBefore', flex: 1, editor: null, menuDisabled: true,renderer:showTip
                    },
                    {text: '内部版本', dataIndex: 'internalVersionBefore', flex: 1, editor: null, menuDisabled: true,renderer:showTip
                    },
                    {text: 'BOM备注', dataIndex: 'bomRemarksBefore', flex: 1, editor: null, menuDisabled: true,renderer:showTip
                    },
                    {text: '供应商', dataIndex: 'supplierIdBefore', flex: 1, editor: disableNode(start_node)?supplierNameCom:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
                    }
                ]
            },
            {
                text: '变更后',menuDisabled: true,flex: 7,
                columns: [
                    {text: '物料编码', dataIndex: 'childNumberAfter', flex: 1, editor: disableNode(start_node)?true:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
                    },
                    {text: '物料描述', dataIndex: 'childNameAfter', flex: 1, editor: false , menuDisabled: true,renderer:showTip
                    },
                    {text: '数量', dataIndex: 'amountAfter', flex: 1, editor: disableNode(start_node)?{xtype:'numberfield',decimalPrecision:8}:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
                    },
                    {text: '位号', dataIndex: 'bitNumberAfter', flex: 1, editor: disableNode(start_node)?true:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
                    },
                    {text: '内部版本', dataIndex: 'internalVersionAfter', flex: 1, editor: disableNode(start_node)?true:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
                    },
                    {text: 'BOM备注', dataIndex: 'bomRemarksAfter', flex: 1, editor: disableNode(start_node)?true:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
                    },
                    {text: '供应商', dataIndex: 'supplierIdAfter', flex: 1, editor: disableNode(start_node)?supplierNameCom:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip
                    }

                ]
            },
            {text: '备注', dataIndex: 'remark', flex: 1, editor: disableNode(start_node)?true:false, menuDisabled: true,style: disableNode(start_node)?'color: blue;':'',renderer:showTip},
            {text: '', dataIndex: '', flex: 0.01, menuDisabled: true}
        ];

        var trialMBOMGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var trialMBOMGrid = Ext.create('Ext.grid.Panel', {
            plugins: [trialMBOMGridEditing],
            store: trialMBOMStore,
            columns: trialMBOMColumns,
            id:'trialMBOMGrid',
            autoWidth: true,
            columnLines: true,
            width:'100%',
            height:'100%',
            height:200,
            multiSelect : false,
            autoScroll: true,
            forceFit: false,
            viewConfig: { enableTextSelection:true,forceFit: false },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '新增行',
                    id: 'trialMBOMInsert',
                    iconCls: 'icon icon-add',
                    hidden: disableNode(start_node)?false:true,
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/insertTechnicalChangeOnTrial?docNumber='+docNumber,
                            method:'POST',
                            headers: {'Content-Type':'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success') {
                                    trialMBOMStore.load();
                                }else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：新增信息错误！！！');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行',
                    id: 'trialMBOMDelete',
                    iconCls: 'icon icon-delete',
                    hidden: disableNode(start_node)?false:true,
                    handler: function () {
                        var recordList = trialMBOMGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for(var i = 0; i<recordList.length; i++){
                                updateArr.push(recordList[i].data.id)
                            };
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/deleteTechnicalChangeOnTrial?docNumber='+docNumber,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        trialMBOMStore.remove(recordList);
                                        var obj = Ext.decode(response.responseText);
                                        alert("成功删除" + obj.data + "条信息！")
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '导出更改后BOM（B）',
                    id: 'trialMBOMExport',
                    iconCls : 'icon icon-store-export',
                    // hidden: disableNode(start_node)?false:true,
                    handler: function () {
                        exportUpdateBOM();
                    }
                }
            ]
        });



        trialMBOMGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            var idx = e.rowIdx
            var record = trialMBOMGrid.getStore().getAt(idx);
            Ext.Ajax.request({
                url: '/Windchill/ptc1/saveTechnicalChangeOnTrial',
                method:'POST',
                headers: {'Content-Type':'application/json'},
                params: JSON.stringify(record.data),
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        var obj = Ext.decode(response.responseText);
                        e.record.commit();
                        trialMBOMStore.load();
                    }else {
                        alert(obj.message)
                    }
                },
                failure: function (response, opts) {
                    alert('错误：保存信息失败！！！');
                }
            });

        });

        // 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
        trialMBOMGrid.on('rowclick', function(view, record, item, index, e) {

            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex+1; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName=='parentNumber'){
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/searchParentNumberList?docNumber='+docNumber,
                        method:'POST',
                        timeout: 1000000,
                        headers: {'Content-Type':'application/json'},
                        // params: JSON.stringify(record.data),
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                parentNumberCom.getStore().removeAll();
                                var parentNumberList = Ext.decode(response.responseText).data;
                                var store = Ext.create('Ext.data.Store', {
                                    fields: ['parentNumber'], // 定义数据字段
                                    data: parentNumberList.map(function(item) {
                                        parentNumberCom.getStore().add({ fullName: item });
                                    })
                                });
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }

        });


        var trialMBOMPanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: '3、试用MBOM',
            // padding:'5',
            // collapsed:disableNode(start_node)||disableNode(execute_processing_feedback)||collapsedValue?false:true,
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                // labelWidth: 80,
                // border: false
            },
            items:[
                trialMBOMGrid
                ,{
                    xtype: 'panel',
                    layout: 'hbox',
                    defaults: {margin: '5 20 0 0', labelWidth: 100},
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '申请人',
                        id: 'applicant',
                        name: 'applicant',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请部门',
                        id: 'applicationDepartment',
                        name: 'applicationDepartment',
                        value:'',
                        width: 300,

                    },{
                        xtype: 'displayfield',
                        fieldLabel: '申请日期',
                        id: 'applicationDate',
                        name: 'applicationDate',
                        value:'',
                        width: 300,

                    }]
                }
            ]
        });


        var relatedRawMaterials  = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: '2、相关物料',
            // padding:'5',
            // collapsed:disableNode(start_node)||disableNode(execute_processing_feedback)||collapsedValue?false:true,
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            width: '100%',
            anchor:'100%',
            defaults: {
                labelWidth: 80,
                border: false
            },
            items:[
                relatedRawMaterialsGrid,relatedProductsGrid,container1
            ]
        });


        var basicInformation  = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'S01：基础信息',
            // padding:'5',
            // collapsed:disableNode(start_node)||disableNode(execute_processing_feedback)||collapsedValue?false:true,
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            width: '100%',
            anchor:'100%',
            defaults: {
                labelWidth: 80,
                border: false
            },
            items:[
                firstLinePanel,
                relatedRawMaterials,
                trialMBOMPanel
            ]
        });


        //---------------------------------------- 采购信息收集 --------------------------------------------------------

        Ext.define('purchaseModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id',
                'serialNumber',
                "partNumber",
                'describe',
                'inventory',
                'externalPO',
                'externalPR',
                'supplier',
                'supplierStocking',
                'notes'
            ],
            idProperty: 'purchaseModel'
        });

        var purchaseColumns = [
            {text: '序号', flex: 0.5, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
            // {text: '序号',hidden:true,flex: 0.5, align: 'center',dataIndex: 'serialNumber', menuDisabled:true, editor:false},
            {text: '物料编码',flex: 1, align: 'center',dataIndex: 'partNumber', menuDisabled:true, editor:false},
            {text: '物料描述',flex: 1, align: 'center',dataIndex: 'describe', menuDisabled:true, editor:false},
            {text: '库存量',flex: 1, align: 'center',dataIndex: 'inventory', menuDisabled:true, editor:false},
            {text: '在外采购订单（PO）',flex: 1, align: 'center',dataIndex: 'externalPO', menuDisabled:true, editor:false},
            {text: '在外采购需求（PR）',flex: 1, align: 'center',dataIndex: 'externalPR', menuDisabled:true, editor:false},
            {text: '供应商名称',flex: 1, align: 'center',dataIndex: 'supplier', menuDisabled:true, editor:disableNode(procurement_execution_manager_information_collection)?supplierNameByPartNumberCom:false
                ,style: disableNode(procurement_execution_manager_information_collection)?'color: blue;':'',renderer:showTip
            },
            {text: (disableNode(procurement_execution_manager_information_collection) ? '<span style="color: red;">*</span> ' : '')+'供应商订单外库存',flex: 1, align: 'center',dataIndex: 'supplierStocking', menuDisabled:true, editor:disableNode(procurement_execution_manager_information_collection)?true:false
                ,style: disableNode(procurement_execution_manager_information_collection)?'color: blue;':''},
            {text: '备注',flex: 1, align: 'center',dataIndex: 'notes', menuDisabled:true, editor:disableNode(procurement_execution_manager_information_collection)?true:false
                ,style: disableNode(procurement_execution_manager_information_collection)?'color: blue;':'',renderer:showTip}
        ];


        var purchaseStore = Ext.create('Ext.data.Store', {
            model: 'purchaseModel',
            id: 'purchaseStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/searchTechnicalChangePurchase?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'purchaseModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,

            listeners: {
                load: function() {

                }
            }

        });

        var purchaseGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var purchaseGrid = Ext.create('Ext.grid.Panel', {
            plugins: [purchaseGridEditing],
            store: purchaseStore,
            columns: purchaseColumns,
            id:'purchaseGrid',
            autoWidth: true,
            columnLines: true,
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: true,
            viewConfig: {
                enableTextSelection: true
            },
            style: {
                border: '1px solid #CCCCCC' // 添加灰色边框
            },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '自动加入受影响物料（B）',
                    id: 'purchaseInsert',
                    hidden: disableNode(procurement_information_collection)||disableNode(procurement_execution_manager_information_collection)?false:true,
                    iconCls: 'icon icon-add',
                    handler: function () {

                        // 显示遮罩
                        var mask = new Ext.LoadMask({
                            msg: '加载中，请稍候...',
                            target: Ext.getCmp('purchaseGrid') // 可以根据实际情况更改 target
                        });
                        mask.show();

                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/insertTechnicalChangePurchase?docNumber='+docNumber,
                            method:'POST',
                            headers: {'Content-Type':'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success') {
                                    purchaseStore.load();
                                }else {
                                    alert(obj.message);
                                }
                                // 请求完成后隐藏遮罩
                                mask.hide();
                            },
                            failure: function (response, opts) {
                                alert('错误：自动加入受影响物料失败！！！');
                                // 请求完成后隐藏遮罩
                                mask.hide();
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除（B）',
                    id: 'purchaseDelete',
                    hidden: disableNode(procurement_information_collection)||disableNode(procurement_execution_manager_information_collection)?false:true,
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        var recordList = purchaseGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for(var i = 0; i<recordList.length; i++){
                                updateArr.push(recordList[i].data.serialNumber)
                            };
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/deleteTechnicalChangePurchase?docNumber='+docNumber,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        purchaseGrid.remove(recordList);
                                        var obj = Ext.decode(response.responseText);
                                        alert("成功删除" + obj.data + "条信息！")
                                        purchaseStore.load();
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败！！！');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }
            ]
        });

        purchaseGrid.on('edit',function(editor,e){
            var idx = e.rowIdx

            let record1 = e.record; // 得到当前行所有数据
            let fieldName = e.field;   // 得到修改列
            let newValue = e.value;   // 得到修改列修改后的值


            // 检查编辑的字段是否为需要转换的字段，这里假设是 'supplierStocking' 字段
            if (fieldName === 'supplier') {
                // 如果新值是一个集合，则将集合转换为字符串
                if (Ext.isArray(newValue)) {
                    // 将集合转换为以逗号分隔的字符串
                    newValue = newValue.join(',');
                    // 更新记录的值为字符串
                    record1.set(fieldName, newValue);
                }
            }


            var record = purchaseGrid.getStore().getAt(idx);
            Ext.Ajax.request({
                url: '/Windchill/ptc1/saveTechnicalChangePurchase',
                method:'POST',
                headers: {'Content-Type':'application/json'},
                params: JSON.stringify(record.data),
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        var obj = Ext.decode(response.responseText);
                        e.record.commit();
                        purchaseStore.load();
                    }else {
                        purchaseStore.load();
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    purchaseStore.load();
                    alert('错误：保存信息错误！！！');
                }
            });
        });

        // 监听Grid的itemclick事件
        purchaseGrid.on('rowclick', function(view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 获取点击行的供应商字段数据
            var partNumber = record.get('partNumber');

            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName=='supplier'){

                    var supplier = record.get('supplier');
                    // 使用 split() 方法将字符串拆分为数组
                    if(supplier){
                        var previouslySelectedValues = supplier.split(',');
                    }


                    supplierNameByPartNumberStore.load({
                        params: {
                            partNumber: partNumber
                        },
                        callback: function(records, operation, success) {
                            if (success) {
                                // 重新加载成功后，设置默认选中的值为选中状态
                                if(supplier) {
                                    supplierNameByPartNumberCom.setValue(previouslySelectedValues);
                                }
                            }
                        }
                    });


                    // // 设置 ComboBox 的初始值
                    // supplierNameByPartNumberCom.setValue(previouslySelectedValues);


                    // supplierNameByPartNumberCom.getStore().removeAll();
                    // Ext.Ajax.request({
                    //     url: '/Windchill/ptc1/common/supplierNameListByPartNumber?partNumber='+partNumber,
                    //     method:'GET',
                    //     headers: {'Content-Type':'application/json'},
                    //     // params: JSON.stringify(record.data),
                    //     success: function (response, opts) {
                    //         var obj = Ext.decode(response.responseText);
                    //         if(obj.message=='success') {
                    //             // var parentNumberList = Ext.decode(response.responseText).data;
                    //             // var store = Ext.create('Ext.data.Store', {
                    //             //     fields: ['supplierName'], // 定义数据字段
                    //             //     data: parentNumberList.map(function(item) {
                    //             //         supplierNameByPartNumberCom.getStore().add({ supplierName: item });
                    //             //     })
                    //             // });
                    //
                    //             var parentNumberList = Ext.decode(response.responseText).data;
                    //
                    //             // 创建一个空的数据数组
                    //             var data = [];
                    //
                    //             // 遍历后端返回的数据，将每个供应商名称添加到数据数组中
                    //             Ext.each(parentNumberList, function(item) {
                    //                 data.push({
                    //                     supplierName: item.supplierName
                    //                 });
                    //             });
                    //
                    //             // 创建一个Store，将数据数组加载到Store中
                    //             var store = Ext.create('Ext.data.Store', {
                    //                 fields: ['supplierName'], // 定义数据字段
                    //                 data: data // 加载数据数组到Store中
                    //             });
                    //
                    //             // 更新ComboBox的Store
                    //             supplierNameByPartNumberCom.bindStore(store);
                    //             // 重新加载ComboBox的数据
                    //             supplierNameByPartNumberCom.reset();
                    //
                    //
                    //         }else {
                    //             alert(obj.message)
                    //         }
                    //     },
                    //     failure: function (response, opts) {
                    //         alert('错误：删除信息失败，请检查网络！!');
                    //     }
                    // });
                }
            }


        });


        //---------------------------------------- 物控信息收集 --------------------------------------------------------

        Ext.define('materialControlModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id',
                'serialNumber',
                "partNumber",
                'describe',
                'inventory',
                'workInProgress',
                'maintenanceTurnoverPart',
                'soldButNotProduced',
                'notes'
            ],
            idProperty: 'materialControlModel'
        });

        var materialControlColumns = [
            {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
            {text: '序号',hidden:true,flex: 0.5, align: 'center',dataIndex: 'serialNumber', menuDisabled:true, editor:false},
            {text: '物料编码',flex: 1, align: 'center',dataIndex: 'partNumber', menuDisabled:true, editor:false},
            {text: '物料描述',flex: 1, align: 'center',dataIndex: 'describe', menuDisabled:true, editor:false},
            {text: '库存量',flex: 1, align: 'center',dataIndex: 'inventory', menuDisabled:true, editor:false},
            {text: '在制品',flex: 1, align: 'center',dataIndex: 'workInProgress', menuDisabled:true, editor:false},
            {text: '维修周转品',flex: 1, align: 'center',dataIndex: 'maintenanceTurnoverPart', menuDisabled:true, editor:false},
            {text: '已录销售订单但未生产',flex: 1, align: 'center',dataIndex: 'soldButNotProduced', menuDisabled:true, editor:false},
            {text: '备注',flex: 1, align: 'center',dataIndex: 'notes', menuDisabled:true, editor:disableNode(collection_of_material_control_information)?true:false
                ,style: disableNode(collection_of_material_control_information)?'color: blue;':''}
        ];


        var materialControlStore = Ext.create('Ext.data.Store', {
            model: 'materialControlModel',
            id: 'materialControlStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/searchTechnicalChangeMaterialControl?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'materialControlModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,

            listeners: {
                load: function() {

                }
            }

        });

        var materialControlGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var materialControlGrid = Ext.create('Ext.grid.Panel', {
            plugins: [materialControlGridEditing],
            store: materialControlStore,
            columns: materialControlColumns,
            id:'materialControlGrid',
            autoWidth: true,
            columnLines: true,
            height:300,
            multiSelect : false,
            autoScroll: true,
            forceFit: true,
            viewConfig: {
                enableTextSelection: true
            },
            style: {
                border: '1px solid #CCCCCC' // 添加灰色边框
            },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '自动加入受影响物料（B）',
                    id: 'materialControlInsert',
                    hidden: disableNode(collection_of_material_control_information)?false:true,
                    iconCls: 'icon icon-add',
                    handler: function () {

                        // 显示遮罩
                        var mask = new Ext.LoadMask({
                            msg: '加载中，请稍候...',
                            target: Ext.getCmp('materialControlGrid') // 可以根据实际情况更改 target
                        });
                        mask.show();

                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/insertTechnicalChangeMaterialControl?docNumber='+docNumber,
                            method:'POST',
                            timeout: 100000, // 设置超时时间为 100 秒，单位是毫秒
                            headers: {'Content-Type':'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success') {
                                    materialControlStore.load();
                                }else {
                                    alert(obj.message);
                                }
                                // 请求完成后隐藏遮罩
                                mask.hide();
                            },
                            failure: function (response, opts) {
                                alert('错误：自动加入受影响物料失败！！！');
                                // 请求完成后隐藏遮罩
                                mask.hide();
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除（B）',
                    id: 'materialControlDelete',
                    hidden: disableNode(collection_of_material_control_information)?false:true,
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        var recordList = materialControlGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for(var i = 0; i<recordList.length; i++){
                                updateArr.push(recordList[i].data.serialNumber)
                            };
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/deleteTechnicalChangeMaterialControl?docNumber='+docNumber,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        purchaseGrid.remove(recordList);
                                        var obj = Ext.decode(response.responseText);
                                        alert("成功删除" + obj.data + "条信息！")
                                        materialControlStore.load();
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败！！！');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }
            ]
        });

        materialControlGrid.on('edit',function(editor,e){
            var idx = e.rowIdx
            var record = materialControlGrid.getStore().getAt(idx);
            Ext.Ajax.request({
                url: '/Windchill/ptc1/saveTechnicalChangeMaterialControl',
                method:'POST',
                headers: {'Content-Type':'application/json'},
                params: JSON.stringify(record.data),
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        var obj = Ext.decode(response.responseText);
                        e.record.commit();
                        materialControlStore.load();
                    }else {
                        materialControlStore.load();
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    materialControlStore.load();
                    alert('错误：保存信息错误！！！');
                }
            });
        });



        //---------------------------------------- 其他领域执行反馈 --------------------------------------------------------

        var personLiableStore = new Ext.data.ArrayStore({
            id: 'personLiableStore',
            fields: [
                {name:"name"},
                {name: "fullName"}
            ],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/personLiableList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var personLiableCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'personLiableCom',
            id: 'personLiableCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: personLiableStore,
            valueField: 'name',
            displayField: 'fullName',
            forceSelection: true,// 只允许选择下拉框中的项
            minChars : 1,//开始查询最小字符数
            mode : 'remote', //查询模式  local为本地数据源  remote为远程服务端
        });


        var relatedFieldsStore = new Ext.data.ArrayStore({
            id: 'relatedFieldsStore',
            fields: ["relatedFields"],
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/relatedFieldsList',
                reader: {
                    type: 'json',
                    rootProperty: 'data'
                }
            },
            autoLoad: false
        });
        var relatedFieldsCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'relatedFieldsCom',
            id: 'relatedFieldsCom',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: relatedFieldsStore,
            valueField: 'relatedFields',
            displayField: 'relatedFields'
        });


        Ext.define('otherAreasModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id',
                'relatedFields',
                "approvalPersonnel",
                'executionFeedback',
                'relatedAccessories',
                'approvalTime'
            ],
            idProperty: 'otherAreasModel'
        });
        // disableNode(execute_processing_feedback)?relatedFieldsCom:
        var otherAreasColumns = [
            {text: '审批人员',flex: 1, align: 'center',dataIndex: 'approvalPersonnel', menuDisabled:true, editor:disableNode(execute_processing_feedback)?personLiableCom:false
                ,style: disableNode(execute_processing_feedback)?'color: blue;':''
            },
            {text: '所属部门',flex: 1, align: 'center',dataIndex: 'relatedFields', menuDisabled:true, editor:false
                // ,style: disableNode(execute_processing_feedback)?'color: blue;':''
            },
            {text: (disableNode(execute_processing_feedback) ? '<span style="color: red;">*</span> ' : '')+'执行反馈',flex: 1, align: 'center',dataIndex: 'executionFeedback', menuDisabled:true, editor:disableNode(execute_processing_feedback)?true:false
                ,style: disableNode(execute_processing_feedback)?'color: blue;':''},
            // {text: '相关附件',flex: 1, align: 'center',dataIndex: 'relatedAccessories', menuDisabled:true, editor:false
            //     ,style: disableNode(execute_processing_feedback)?'color: blue;':''},

            {text: '相关附件',width: 200, align: 'center',xtype:'actioncolumn', dataIndex: 'relatedAccessories', editor: false, menuDisabled: true,
                style: disableNode(execute_processing_feedback)?'color: blue;':'',
                items: [
                    '->',
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:disableNode(execute_processing_feedback)?false:true,
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'relatedAccessories';
                            uploadTableName = 'technicalChangeOther';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'otherAreasGrid';

                            uploadImageWindow.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.environmentalReport;
                            // if(boolean!=null) {
                            //     return true;
                            // }
                            // return false;
                        }
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'relatedAccessories';
                            uploadTableName = 'technicalChangeOther';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'otherAreasGrid';
                            // 刷新当前单元格内文件
                            showStore.load({
                                params: {
                                    fileColumnId: fileColumnId,
                                    fileColumnName: fileColumnName,
                                    uploadTableName:uploadTableName
                                }
                            });
                            showFile.show();
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            // var boolean = record.data.environmentalReport;
                            // if(boolean!=null) {
                            //     return false;
                            // }
                            // return true;
                        }
                    }
                ]
            },

            {text: '审批时间',flex: 1, align: 'center',dataIndex: 'approvalTime', menuDisabled:true, editor:false}
        ];


        var otherAreasStore = Ext.create('Ext.data.Store', {
            model: 'otherAreasModel',
            id: 'otherAreasStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/searchTechnicalChangeOther?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'otherAreasModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,

            listeners: {
                load: function() {

                }
            }

        });

        var otherAreasGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var otherAreasGrid = Ext.create('Ext.grid.Panel', {
            plugins: [otherAreasGridEditing],
            store: otherAreasStore,
            columns: otherAreasColumns,
            id:'otherAreasGrid',
            // autoWidth: true,
            columnLines: true,
            height:300,
            width: '100%',
            multiSelect : false,
            // autoScroll: true,
            forceFit: false,
            style: {
                border: '1px solid #CCCCCC' // 添加灰色边框
            },
            viewConfig: { enableTextSelection:true,
                //上传文件列宽调整
                forceFit: false },
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '增加行（B）',
                    id: 'otherAreasInsert',
                    hidden: disableNode(execute_processing_feedback)?false:true,
                    iconCls: 'icon icon-add',
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/insertTechnicalChangeOther?docNumber='+docNumber,
                            method:'POST',
                            headers: {'Content-Type':'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success') {
                                    otherAreasStore.load();
                                }else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：新增信息错误！！！');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行（B）',
                    id: 'otherAreasDelete',
                    hidden: disableNode(execute_processing_feedback)?false:true,
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        var recordList = otherAreasGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for(var i = 0; i<recordList.length; i++){
                                updateArr.push(recordList[i].data.id)
                            };
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/deleteTechnicalChangeOther?docNumber='+docNumber,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        otherAreasGrid.remove(recordList);
                                        var obj = Ext.decode(response.responseText);
                                        alert("成功删除" + obj.data + "条信息！")
                                        otherAreasStore.load();
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败！！！');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }
            ]
        });

        otherAreasGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            var idx = e.rowIdx;
            let field = e.field;   // 得到修改列
            var record = otherAreasGrid.getStore().getAt(idx);
            Ext.Ajax.request({
                url: '/Windchill/ptc1/saveTechnicalChangeOther?fieldName='+field,
                method:'POST',
                headers: {'Content-Type':'application/json'},
                params: JSON.stringify(record.data),
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if(obj.message=='success') {
                        var obj = Ext.decode(response.responseText);
                        e.record.commit();
                        otherAreasStore.load();
                    }else {
                        otherAreasStore.load();
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    otherAreasStore.load();
                    alert('错误：保存信息错误！！！');
                }
            });
        });


        //根据特定字段的值判断是否禁止编辑
        otherAreasGrid.on('beforeedit', function (editor, context) {
            var record = context.record;
            var approvalTime = record.get('approvalTime');
            // 判断点击的是哪一列，列名
            var columnName = context.column.dataIndex;
            if (approvalTime) {
                return false; // 禁止编辑指定列
            }
            return true; // 允许编辑操作
        });




        var handlingOpinions = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'S02：各领域处理意见',
            // padding:'5',
            //面板是否展开false为展开
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                labelWidth: 80,
                border: false
            },
            items:[
                {
                    xtype: 'panel',
                    title: '1. 采购信息收集',
                    collapsed:disableNode(procurement_information_collection)||disableNode(procurement_execution_manager_information_collection)||collapsedValue?false:true,
                    collapsible:true,
                    titleCollapse:true,
                    hideCollapseTool:true,
                    style: {
                        border: '1px solid #CCCCCC' // 添加灰色边框
                    },
                    items: [
                        purchaseGrid,
                        // {
                        //     xtype: 'textarea',
                        //     fieldLabel: '说明',
                        //     labelStyle: disableNode(procurement_information_collection)?'color: blue':'',
                        //     readOnly:disableNode(procurement_information_collection)?false:true,
                        //     margin: '15 0 0 7',
                        //     id: 'purchaseIllustrate',
                        //     name: 'purchaseIllustrate',
                        //     value: '',
                        //     listeners: {
                        //         blur: function(field) {
                        //             var purchaseIllustrate = field.getValue();
                        //             technicalChange(docNumber,"purchaseIllustrate",purchaseIllustrate)
                        //         }
                        //
                        //     }
                        // },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            margin: '15 20 0 0',
                            items: [
                                {
                                    xtype: 'displayfield',
                                    fieldLabel: '审批人',
                                    id: 'purchaseApprovedBy',
                                    name: 'purchaseApprovedBy',
                                    value:''
                                },{
                                    xtype: 'displayfield',
                                    fieldLabel: '审批时间',
                                    margin: '5 0 0 180',
                                    id: 'purchaseApprovalTime',
                                    name: 'purchaseApprovalTime',
                                    value:''
                                }]
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    title: '2. 物控信息收集',
                    collapsed:disableNode(collection_of_material_control_information)||collapsedValue?false:true,
                    collapsible:true,
                    titleCollapse:true,
                    hideCollapseTool:true,
                    items: [
                        materialControlGrid,
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            margin: '15 20 0 0',
                            items: [
                                {
                                    xtype: 'displayfield',
                                    fieldLabel: '审批人',
                                    id: 'materialControlApprovedBy',
                                    name: 'materialControlApprovedBy',
                                    value:'',
                                    width: 300,

                                },{
                                    xtype: 'displayfield',
                                    fieldLabel: '审批时间',
                                    id: 'materialControlApprovalTime',
                                    name: 'materialControlApprovalTime',
                                    value:'',
                                    width: 300,

                                }]
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    title: '3. 资料室锁定BOM',
                    collapsed:disableNode(BOM_lock)||collapsedValue?false:true,
                    collapsible:true,
                    titleCollapse:true,
                    hideCollapseTool:true,
                    items: [

                        {
                            xtype: 'textarea',
                            fieldLabel: '处理结果',
                            readOnly:disableNode(BOM_lock)?false:true,
                            margin: '15 200 0 7',
                            id: 'referenceRoomResult',
                            name: 'referenceRoomResult',
                            value:'',
                            emptyText: '（SAP系统跨工厂状态改为：96）',
                            width: 300,
                            listeners: {
                                blur: function(field) {
                                    var referenceRoomResult = field.getValue();
                                    technicalChange(docNumber,"referenceRoomResult",referenceRoomResult)
                                }
                            }
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            margin: '15 20 0 0',
                            items: [
                                {
                                    xtype: 'displayfield',
                                    fieldLabel: '审批人',
                                    id: 'referenceRoomApprovedBy',
                                    name: 'referenceRoomApprovedBy',
                                    value:'',
                                    width: 300,

                                },{
                                    xtype: 'displayfield',
                                    fieldLabel: '审批时间',
                                    id: 'referenceRoomApprovalTime',
                                    name: 'referenceRoomApprovalTime',
                                    value:'',
                                    width: 300,

                                }]
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    title: '4. 其他领域执行反馈',
                    collapsed:disableNode(execute_processing_feedback)||collapsedValue?false:true,
                    collapsible:true,
                    titleCollapse:true,
                    hideCollapseTool:true,
                    // margin: '5 20 5 5',
                    items: [
                        otherAreasGrid
                    ]
                }

            ]
        });


        var temporaryChangeClosedLoop = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            title: 'S03：临时变更闭环',
            // padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            anchor:'100%',
            defaults: {
                labelWidth: 80,
                border: false
            },
            items:[
                {
                    xtype: 'panel',
                    title: '1. 发起人意见',
                    collapsed:disableNode(formal_change_opinion)||collapsedValue?false:true,
                    collapsible:true,
                    titleCollapse:true,
                    hideCollapseTool:true,
                    style: {
                        border: '1px solid #CCCCCC' // 添加灰色边框
                    },
                    items: [
                        {
                            xtype: 'textarea',
                            fieldLabel: '处理意见',
                            readOnly:disableNode(formal_change_opinion)?false:true,
                            labelStyle: disableNode(formal_change_opinion)?'color: blue':'',
                            margin: '15 0 0 7',
                            id: 'handlingOpinions',
                            name: 'handlingOpinions',
                            value:'',
                            width: 300,
                            listeners: {
                                blur: function(field) {
                                    var handlingOpinions = field.getValue();
                                    technicalChange(docNumber,"handlingOpinions",handlingOpinions)
                                }
                            }
                        },

                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            align: 'left',
                            margin: '15 0 0 7',
                            items: [
                                {
                                    xtype: 'combobox',
                                    fieldLabel: (disableNode(formal_change_opinion) ? '<span style="color: red;">*</span> ' : '')+'是否需要正式变更',
                                    labelStyle: disableNode(formal_change_opinion)?'color: blue':'',
                                    readOnly:disableNode(formal_change_opinion)?false:true,
                                    id: 'doWeNeedFormalChanges',
                                    name: 'doWeNeedFormalChanges',
                                    labelWidth: 150,
                                    multiSelect: false,
                                    anyMatch: true,
                                    editable: false,
                                    store: {
                                        data: [
                                            { fullName: '是' },
                                            { fullName: '否' }
                                        ],
                                        fields: ['fullName']
                                    },
                                    valueField: 'fullName',
                                    displayField: 'fullName',
                                    listeners: {
                                        select: function(combo, records) {
                                            var doWeNeedFormalChanges =  combo.getValue();
                                            technicalChange(docNumber,"doWeNeedFormalChanges",doWeNeedFormalChanges)
                                        }
                                    }
                                },
                                {
                                    xtype: 'textfield',
                                    fieldLabel: '变更单号',
                                    id: 'changeOrderNumber',
                                    name: 'changeOrderNumber',
                                    labelStyle: disableNode(formal_change_opinion)?'color: blue':'',
                                    readOnly:disableNode(formal_change_opinion)?false:true,
                                    value: '',
                                    listeners: {
                                        // change: function(field, newValue, oldValue) {
                                        //     var changeOrderNumber = field.getValue();
                                        //     technicalChange(docNumber,"changeOrderNumber",changeOrderNumber)
                                        // }
                                        blur: function(field) {
                                            var changeOrderNumber = field.getValue();
                                            if(changeOrderNumber===""){
                                                return;
                                            }
                                            technicalChange(docNumber,"changeOrderNumber",changeOrderNumber)
                                        }
                                    }
                                }
                            ]
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            align: 'left',
                            defaults: {margin: '15 0 0 0', labelWidth: 100},
                            items: [
                                {
                                    xtype: 'displayfield',
                                    fieldLabel: '审批人',
                                    id: 'initiateApprovedBy',
                                    name: 'initiateApprovedBy',
                                    value:''
                                },{
                                    xtype: 'displayfield',
                                    margin: '5 0 0 210',
                                    fieldLabel: '审批时间',
                                    id: 'initiateApprovalTime',
                                    name: 'initiateApprovalTime',
                                    value:''
                                }]
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    title: '2. 资料室确认',
                    collapsed:disableNode(data_room_review)||collapsedValue?false:true,
                    collapsible:true,
                    titleCollapse:true,
                    hideCollapseTool:true,
                    items: [
                        {
                            xtype: 'textarea',
                            fieldLabel: '确认结果',
                            margin: '15 200 10 7',
                            id: 'confirmResults',
                            name: 'confirmResults',
                            labelStyle: disableNode(data_room_review)?'color: blue':'',
                            readOnly:disableNode(data_room_review)?false:true,
                            value:'',
                            width: 300,
                            emptyText: '（变更是否已到ECA / BOM是否已解锁）',
                            listeners: {
                                blur: function(field) {
                                    var confirmResults = field.getValue();
                                    technicalChange(docNumber,"confirmResults",confirmResults)
                                }
                            }
                        },
                        {
                            xtype: 'panel',
                            layout: 'hbox',
                            border: false,
                            margin: '15 20 20 0',
                            items: [
                                {
                                    xtype: 'displayfield',
                                    fieldLabel: '审批人',
                                    id: 'approvedBy',
                                    name: 'approvedBy',
                                    value:'',
                                    width: 300
                                },{
                                    xtype: 'displayfield',
                                    fieldLabel: '审批时间',
                                    id: 'approvalTime',
                                    name: 'approvalTime',
                                    value:'',
                                    width: 300
                                }]
                        }
                    ]
                }
            ]
        });




        this.items = [
            basicInformation,
            // relatedRawMaterials,
            handlingOpinions,
            temporaryChangeClosedLoop
        ];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {

        }
    }











});

























