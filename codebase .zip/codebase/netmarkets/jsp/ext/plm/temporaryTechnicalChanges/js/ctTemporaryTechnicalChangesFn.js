// 模板函数，根据条件动态生成列头文本
function generateHeaderTextWithRedStar(name) {
    var redStar = disableNode(start_node) ? '<span style="color: red;">*</span> ' : ''; // 根据条件生成红色星号
    return redStar + name;
}


var start_node='start_node'; //提交节点/重新提交
var department_manager_review='department_manager_review';//部门经理审核
var procurement_information_collection='procurement_information_collection';//采购信息收集
var collection_of_material_control_information='collection_of_material_control_information';//物控信息收集
var BOM_lock='BOM_lock';//BOM锁定
var execute_processing_feedback='execute_processing_feedback';//执行处理反馈
var formal_change_opinion='formal_change_opinion';//发起人填写正式更改意见
var data_room_review='data_room_review';//资料室审核

var procurement_execution_manager_information_collection='procurement_execution_manager_information_collection';//生产紧急协调单-采购执行部经理信息收集


/**
 * 判断是否可编辑
 * @param node 节点表单key
 */
function disableNode(node) {
    if(taskCompleted) {
        return false;
    } else {
        if(node == currentActKey) {
            return true;
        } else {
            return false;
        }
    }
};









/**
 * 单一字段
 * @param params 参数参数
 */
function technicalChange(docNumber,key,value) {

    Ext.Ajax.request({
        scope: this,
        async: false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url: '/Windchill/ptc1/technicalChange',
        params: {docNumber:docNumber,key: key,value: value},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['message'];
            if(!(msg==="success")){
                alert(msg);
            }
            // if (!success) {
            //     alert(msg);
            // } else {
            // }
        },
        failure: function (response, opts) {
            // myMask.hide();
            alert('错误：保存信息失败！！！');
        }
    });

}
/**
 * 查询制造商
 * @param params 参数参数
 */
function doSearch() {
    var multiplePartStore = Ext.getStore('multiplePartStore');
    var params = getParams();
    multiplePartStore.load({
        params: params,
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    alert('查询超时！请重试！')
                }
            } else {

            }
        }
    });
}

/**
 * 获取查询参数
 */
function getParams() {
    var params = {
        partNumber: Ext.getCmp('partNumber').getValue()
    };
    return params;
}





function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}

/**
 * 导出
 */
function doExport() {

    Ext.Ajax.request({
        url: '/Windchill/ptc1/bom/exportBom',
        method:'GET',
        headers: {'Content-Type':'application/json'},
        params: {
            partOid:'373268'
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=='success') {

            }else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });

}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion


function deleteFilefield(branchId, fileName, tetx_name, node, type, serialNumber) {
    Ext.Msg.confirm('提示','确定要删除选中文件？',
        function(btn){
            if(btn =='yes'){
                deleteFile(branchId, fileName, tetx_name, node, type,serialNumber)
            }else{
                return;
            }
        },this
    );
}

//删除附件
function deleteFile(docNumber, fileName, tetx_name, node, type, serialNumber) {
    var file = '';
    var path = '';
    if (taskCompleted == 'true') {
        return;
    }
    if (type == 'trialPlan') {

    }else if(type == 'technicalDocument'){

    }

    Ext.Ajax.request({
        scope: this,
        async: false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url: '/Windchill/ptc1/technicalChange/deleteFiles',
        params: {
            docNumber: docNumber, fileName: fileName,type:type,serialNumber:serialNumber,tetx_name:tetx_name
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['message'];

            if (!(msg==="success")) {
                alert(msg);
            } else {
                if(tetx_name === 'PCN'){
                    var relatedProductsGrid = Ext.getCmp('relatedProductsGrid');
                    relatedProductsGrid.getStore().load();
                }
                if(tetx_name === 'otherAreas'){
                    var otherAreasGrid = Ext.getCmp('otherAreasGrid');
                    otherAreasGrid.getStore().load();
                }
                if(tetx_name === 'relatedAccessories') {
                    var value = Ext.getCmp(tetx_name).getValue();
                    var arr = new Array(); //定义一数组
                    arr = value.split("|"); //字符分割
                    for (i = 0; i < arr.length; i++) {
                        var index = arr[i].indexOf(fileName);
                        if (index > -1) {
                            arr.splice(i, 1);// 删除
                        }
                    }
                    var result = arr.join("&nbsp;|&nbsp;");
                    var relatedAccessories = Ext.getCmp('relatedAccessories');
                    if (relatedAccessories !== 'undefined') {
                        relatedAccessories.setValue(result);
                        technicalChange(docNumber, "relatedAccessories", result);
                    }
                }

            }
        },
        failure: function (response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });
}


/**
 * 导出更改后BOM
 */
function exportUpdateBOM() {
    // 获取XMLHttpRequest
    var xmlHttpRequest = new XMLHttpRequest();
    //  发起请求
    xmlHttpRequest.open("POST", '/Windchill/ptc1/technicalChange/exportUpdateBOM?docNumber=' + docNumber, true);
    // 设置请求头类型
    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
    xmlHttpRequest.responseType = "blob";
    //  返回
    xmlHttpRequest.onload = function (oEvent) {
        var content = xmlHttpRequest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).message)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            var fileNamePrefix = '更改后BOM';
            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }
    };
    xmlHttpRequest.send();
}

/**
 * combobox空白行高度与选项保持一致
 * @param name
 * @returns {Ext.XTemplate}
 */
function getXTemplate(name) {
    return Ext.create('Ext.XTemplate',
        '<tpl for=".">',
        '<div class="x-boundlist-item" style="height:25px">{' + name + '}</div>',
        '</tpl>'
    )
}



