Ext.define('PLM.view.CtIpdProcessComplianceSecOneReview', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtIpdProcessComplianceSecOneReview',
    border: false,
    autoScroll: true,
    autoWidth: true,
    height: 588,
    collapsible: false,
    id: 'CtIpdProcessComplianceSecOneReview',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                	  xtype: 'displayfield',
                      fieldLabel: '<font style="font-size:12px">统计月份</font>',
                      value: '<font style="font-size:18px">'+ currentMonth +'</font>',
                      margin: '5 0 5 10',
                      labelWidth: 90,
                      width: 400
                    },
                    {
                        xtype:'tabpanel',
                        id: 'ipdProcessComplianceSecOneTabPanel',
                        activeTab: 0,
                        items:[
                            {
                                title: '<font style="font-size:12px">点击显示VR项目</font>',
                                xtype: 'ctDisplayVRProjectInfo'
                            }
                            ,
                            {
                                scrollable: true,
                                title: '<font style="font-size:12px">点击显示C项目</font>',
                                xtype:'ctDisplayCProjectInfo'
                            }
                        ]//~End of tabpanel items
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    }
});