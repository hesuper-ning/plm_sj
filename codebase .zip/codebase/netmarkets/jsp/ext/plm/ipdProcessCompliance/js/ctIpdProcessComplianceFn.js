var redStarFlag = '<font color=red bold>*</font>';//必填标志
var blueFlagStart = '<font color=blue bold><b>';//可编辑标识
var blueFlagEnd = '</b></font>';

var SUMMARY_NODE='ipdprocesscompliance_summary_node';
var BONUSANDDEDUCTION_NODE='ipdprocesscompliance_BonusAndDeduction_node';
var CONFIRMATIONITEM_NODE='ipdprocesscompliance_confirmationItem_node';
var MAKECOPY_NODE='ipdprocesscompliance_makecopy_node';

//表格beforeedit校验
function checkBeforeEdit(editor, e) {
   /* let field = e.field;
    let value = e.value;
    let record = e.record;*/
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
   
    /*let reviewer = record.get('reviewer');
    if(!(reviewer == userName)){
    	if((currentActKey == 'keydeliver_toReview_node') && (field == 'palnDefect')){
    		
    	}else if(((currentActKey == 'keydeliver_chiefReviewerFeedback_node') ||
    			(currentActKey == 'keydeliver_fillReviewComments_node'))
    			&& (field == 'reviewTypeComments' || field == 'palnDefect' || field == 'reviewComments')){
    		//alert('评审人是本人才能编辑！');
       	 	return false;
    	}
    }*/
    return checkEditAccess(e);
}
/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    //if(isAdmin) return true;
    var column = e.column;//获取编辑列
    if(column.editAccess){
        return true;
    }else{
        return false;
    }
    return true;
}
/**
 * 设为必填
 */
function setMust(field, flag) {
    if (flag)
        return redStarFlag + blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 设为可填
 */
function setRequired(field, flag) {
    if (flag)
        return blueFlagStart + field + blueFlagEnd;
    else
        return field;
}
/**
 * 判断是否可编辑
 * @param node 节点表单key
 * @returns {boolean}
 */
function isEditable(...node) {
    //return true;
    if (readOnlyPage || taskCompleted) return false;
    let flag = false;
    node.forEach((item, index) => {
        if (item === currentActKey) {
            flag = true;
        }
    });
    return flag;
}
//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion

/**
 * 对Request封装
 * @Param url 请求url
 * @Param method 请求方法'GET' 'POST'
 * @Param async true 请求异步 false 请求步
 * @Param object
 * @Param callback 回调方法
 */
function sendRequest(url, method, headers, async, params, successCallback, failCallback) {
    Ext.Ajax.request({
        scope: this,
        url: url,
        method: method,
        timeout: 600000,
        async: async,
        headers: {'Content-Type': headers},
        params: params,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
                if (failCallback) {
                    failCallback();
                }
            } else {
                if (successCallback) {
                    successCallback(obj.data);
                }
            }
        },
        failure: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj&&obj['message']) {
                Ext.Msg.alert('错误', obj['message']);
            }else{
                Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
            }
            if (failCallback != null && failCallback !== '') {
                failCallback();
            }
        }
    }); //~End of Ajax request
}

function updateDeductBonusPointsInfo(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
    	CtIpdDeductBonusPointsBo.getStore().reload(
                {
                params: {
               	 showProjectNumber: allprojectNumber
                }
            }
            );
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/IpdProcessCompliance/updateDeductBonusPointsInfo', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value,branchId: branchId},
        successCallback, failCallback);
}
function basicFormData(vl){
	Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/IpdProcessCompliance/getIpdProcessComplianceBasis?branchId=' + branchId 
        + "&currentYM=" + currentMonth + "&showProjectNumber=" + allprojectNumber,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var data = obj.data;
//            let form = Ext.getCmp('transferProblemForm');
//            if (form !== undefined) {
//                form.getForm().setValues(data);
//            }
            Ext.getCmp('projectNumber1').setValue(data.projectNumber1);
     		Ext.getCmp('projectName1').setValue(data.projectName1);
         	Ext.getCmp('productLine1').setValue(data.productLine1);
         	Ext.getCmp('allScore').setValue(data.allScore);
         	Ext.getCmp('planComple').setValue(data.planComple);
         	Ext.getCmp('actualComple').setValue(data.actualComple);
         	Ext.getCmp('submissionRate').setValue(data.submissionRate+"%");
         	Ext.getCmp('planCompleTw').setValue(data.planCompleTw);
         	Ext.getCmp('actualCompleTw').setValue(data.actualCompleTw);
         	Ext.getCmp('reviewRate').setValue(data.reviewRate);
         	
         	Ext.getCmp('reduceScore').setValue(data.reduceScore);
         	Ext.getCmp('addScore').setValue(data.addScore);
         	
         	Ext.getCmp('averageScoreTh').setValue(data.averageScoreTh);
         	Ext.getCmp('averageScoreFo').setValue(data.averageScoreFo);
            if(obj.message==="success") {} else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    });
}
/**
 * 加载Form表单
 */
function loadBasisFormData(vl) {
	Ext.getCmp('projectNumber1').setValue("");
	Ext.getCmp('projectName1').setValue("");
  	Ext.getCmp('productLine1').setValue("");
  	Ext.getCmp('allScore').setValue("");
  	Ext.getCmp('planComple').setValue("");
  	Ext.getCmp('actualComple').setValue("");
  	Ext.getCmp('submissionRate').setValue("");
  	Ext.getCmp('planCompleTw').setValue("");
  	Ext.getCmp('actualCompleTw').setValue("");
  	Ext.getCmp('reviewRate').setValue("");
  	Ext.getCmp('reduceScore').setValue("");
  	Ext.getCmp('addScore').setValue("");
  	Ext.getCmp('averageScoreTh').setValue("");
  	Ext.getCmp('averageScoreFo').setValue("");
    ctFileSubmitInfoListBo.getStore().reload(
            {
            params: {
           	 showProjectNumber: allprojectNumber
            }
        }
        );
 	KeyDeliverableReviewListBo.getStore().reload(
            {
            params: {
           	 showProjectNumber: allprojectNumber
            }
        }
        );
 	keyDeliverablesReviewEffListBo.getStore().reload(
            {
            params: {
           	 showProjectNumber: allprojectNumber
            }
        }
        );
 	keyDeliverablesOfDeliveryListBo.getStore().reload(
            {
            params: {
           	 showProjectNumber: allprojectNumber
            }
        }
        );
 	CtIpdDeductBonusPointsBo.getStore().reload(
            {
            params: {
           	 showProjectNumber: allprojectNumber
            }
        }
        );
 	CtIpdAddBonusPointsBo.getStore().reload(
            {
            params: {
           	 showProjectNumber: allprojectNumber
            }
        }
        );

 	setTimeout(function() {
 		basicFormData(vl);
 	}, 2000);
}