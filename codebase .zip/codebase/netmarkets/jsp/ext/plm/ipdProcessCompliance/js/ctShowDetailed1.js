let ctContentEditing1 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});
Ext.define('ctFileSubmitInfoListModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'belongActivities', 'deliveryName', 'responsibler','planCompleTimeReview',
             'actualCompleTimeReview'],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctFileSubmitInfoListModel',
    storeId: 'ctFileSubmitInfoListStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/IpdProcessCompliance/getIpdDeliverablesReviewInfo?branchId=' + branchId + "&ltype=1&currentYM=" + currentMonth,
        method: 'GET',
        params: {
       	    showProjectNumber: allprojectNumber,
       	    currentYM:  currentMonth
        },
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: false
});

let ctFileSubmitInfoListBo = Ext.create('Ext.grid.Panel', {
	autoWidth:true,
	plugins: [ctContentEditing1],
    id: 'ctFileSubmitInfoListBo',
    store: Ext.data.StoreManager.lookup('ctFileSubmitInfoListStore'),
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 50, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 100, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 100, dataIndex: 'branchId', hidden: true, align: 'center'},
        {text: '所属活动', width: 300, dataIndex: 'belongActivities', editAccess: true,align: 'center',editor: false, renderer:showTip},
        {text: '可交付结果名称', width: 350, dataIndex: 'deliveryName',editAccess: true,  align: 'center', editor: false,renderer:showTip},
        {text: '负责人', width: 100, dataIndex: 'responsibler', editAccess: true, align: 'center',editor: false, renderer:showTip},
        {text: '目标时间（计划完成时间）', width: 150, dataIndex: 'planCompleTimeReview', editAccess: true, align: 'center', editor: false,renderer:showTip},
        {text: '实际时间（实际完成时间）', width: 150, dataIndex: 'actualCompleTimeReview', editAccess: true, align: 'center', editor: false,renderer:showTip}
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引
            var partNumber = record.get('partNumber');
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'supplierNumber'){
                    supplierCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getSupplierByPartNumber?partNumber=' + partNumber,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        supplierCombo.getStore().add({supplierInfo:item.supplierInfo});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
        	updateDeductBonusPointsInfo(editor, e);
        }
    }
});

let ctFileSubmitInfoScoreBo =  Ext.create('Ext.form.Panel', {
    id:'ctFileSubmitInfoScoreBo',
    autoWidth:true,
    xtype: 'form',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
		{
		    xtype: 'panel',
		    layout: 'hbox',
		    defaults: {margin: '5 5 5 5', labelWidth: 135},
		    items: [
		{
			xtype: 'displayfield',
			fieldLabel: '计划完成',
			labelAlign: 'right',
			id: 'planComple',
		    name: 'planComple',
			value: ' ',
			mode : 'local',
			menuDisabled:true,
			width: 200,
		},{
			xtype: 'displayfield',
			fieldLabel: '实际完成',
			labelAlign: 'right',
			id: 'actualComple',
		    name: 'actualComple',
			value: ' ',
			mode : 'local',
			menuDisabled:true,
			width: 200,
		},{
			xtype: 'displayfield',
			fieldLabel: '提交率',
			labelAlign: 'right',
			id: 'submissionRate',
		    name: 'submissionRate',
			value: ' ',
			mode : 'local',
			menuDisabled:true,
			width: 100,
		}	
    ]
}  
           
           
           

    ],
    listeners: {
       
    }
});
let ctFileSubmitInfoBo =  Ext.create('Ext.panel.Panel', {
    title: '1. 文件提交',
    id:'ctFileSubmitInfoBo',
    width:'100%',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
//    anchor: '100%',
    defaults: {
//    padding: '2 10 2 10',
        border: false
    },
    items:[
        ctFileSubmitInfoScoreBo,ctFileSubmitInfoListBo
    ],
    listeners:{
        'afterrender': function () {
        	
        }
    }
});
//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {
    if (value != null && value != undefined && value != '') {
        var date = new Date(value);
        var time = Ext.Date.format(date, "Y-m-d")
        return time;
    }
    return value;
    
}


