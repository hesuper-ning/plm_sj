let ctContentEditing11 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});
Ext.define('IpdDeductBonusPointsModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'projectData', 'eventDescription', 'referAttachment',
    'relatedLinks'],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'IpdDeductBonusPointsModel',
    storeId: 'IpdDeductBonusPointsStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/IpdProcessCompliance/getIpdProcessComplianceDeductBonusPoints?branchId=' + branchId + '&itemType=reduce&currentYM=' + currentMonth,
        method: 'GET',
        params: {
       	    showProjectNumber: allprojectNumber
        },
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: false
});

let CtIpdDeductBonusPointsBo = Ext.create('Ext.grid.Panel', {
	autoWidth:true,
	plugins: [ctContentEditing11],
    id: 'CtIpdDeductBonusPointsBo',
    store: Ext.data.StoreManager.lookup('IpdDeductBonusPointsStore'),
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 150, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 100, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 100, dataIndex: 'branchId', hidden: true, align: 'center'},
        {text: '扣分项目', width: 200, dataIndex: 'projectData', editAccess: true,align: 'center',editor: 'textfield', renderer:showTip},
        {text: '事件描述', width: 500, dataIndex: 'eventDescription',editAccess: true,  align: 'center', editor: 'textfield',renderer:showTip},
//        {text: '参考附件', width: 150, dataIndex: 'referAttachment', editAccess: true, align: 'center',editor: 'textfield', renderer:showTip},
        {text: '参考附件',xtype:'actioncolumn', dataIndex: 'referAttachment', width: 180, editor: false, menuDisabled: true,
            items: [
                '->',
                '-',
                '-',
                '-',
                {
                    iconCls: 'icon icon-uploadImage',
                    tooltip: '添加文件',
                    hidden:false,
                   // hidden:disableNode(submit_node)?false:true,
                    handler: function(grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        fileColumnId = record.get('id');
                        fileColumnName = 'referAttachment';
                        uploadTableName = 'ZIpdDeductBonusPointsTable';
                        //设置grid名称用于上传文件后刷新数据
                        gridName = 'CtIpdDeductBonusPointsBo';
                        allowMultiple = true;
                        var uploadFileWindow = initUploadFileWindow();
                        uploadFileWindow.show()

                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                         var boolean = record.data.attachmentReply;
                         if(boolean!=null) {
                             return true;
                         }
                         return false;
                    }
                },
                '-',
                {
                    iconCls: 'icon-showInfo',
                    tooltip: '查看文件',
                    handler: function(grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        fileColumnId = record.get('id');
                        fileColumnName = 'referAttachment';
                        uploadTableName = 'ZIpdDeductBonusPointsTable';
                        //设置grid名称用于上传文件后刷新数据
                        gridName = 'CtIpdDeductBonusPointsBo';

                        var showFiles = initShowFiles();

                        if(true){
                            Ext.getCmp('showDelete').show();
                        }else {
                            Ext.getCmp('showDelete').hide();
                        }
                        showFiles.show()
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var boolean = record.data.referAttachment;
                        if(boolean!=null) {
                            return false;
                        }
                        return true;
                    }
                }
            ]
        },
        {text: '相关链接', width: 150, dataIndex: 'relatedLinks', editAccess: true, align: 'center', editor: 'textfield',renderer:showTip}
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            hidden:!isEditable(SUMMARY_NODE,BONUSANDDEDUCTION_NODE,CONFIRMATIONITEM_NODE),
            handler: function () {
                ctContentEditing11.cancelEdit();
                function successCallback(data) {
                    let store = CtIpdDeductBonusPointsBo.getStore();
                    store.insert(store.getCount(), data);
                    CtIpdDeductBonusPointsBo.view.refresh();
                    CtIpdDeductBonusPointsBo.getStore().reload(
                         {
                         params: {
                        	 showProjectNumber: allprojectNumber
                         }
                     }
                     );
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/IpdProcessCompliance/saveDeductBonusPointsInfo', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId,itemType:'reduce',showProjectNumber:allprojectNumber,currentYM:currentMonth}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            hidden:!isEditable(SUMMARY_NODE,BONUSANDDEDUCTION_NODE,CONFIRMATIONITEM_NODE),
            handler: function () {
                let selected = CtIpdDeductBonusPointsBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                    	CtIpdDeductBonusPointsBo.getStore().remove(selected);
                    	CtIpdDeductBonusPointsBo.view.refresh();
                    	CtIpdDeductBonusPointsBo.getStore().reload();
                    }
                    function failCallback() {
                    }
                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                        /*let reviewer = selected[i].get('reviewer');
                        if(reviewer != userDisplayName){
                        	 alert('只能删除自己创建的数据！');
                        	 return ;
                        }
                        let attachmentName = selected[i].get('attachmentName');
                        if(attachmentName){
                        	alert('请先删除附件里上传的数据');
                        	return ;
                        }*/
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/IpdProcessCompliance/deleteDeductBonusPointsInfo', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        } 
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引
            var partNumber = record.get('partNumber');
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'supplierNumber'){
                    supplierCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getSupplierByPartNumber?partNumber=' + partNumber,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        supplierCombo.getStore().add({supplierInfo:item.supplierInfo});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
        	updateDeductBonusPointsInfo(editor, e);
        }
    }
});

let ctShowDetailedReduceUnBo =  Ext.create('Ext.form.Panel', {
    id:'ctShowDetailedReduceUnBo',
    autoWidth:true,
    xtype: 'form',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
{
//	xtype: 'textfield',
	xtype: 'displayfield',
	fieldLabel: '得分',
	labelAlign: 'right',
	id: 'reduceScore',
    name: 'reduceScore',
//    disabled : !isEditable(REVIEWERANDREVIEWFORMAT_NODE),
	value: ' ',
	mode : 'local',
	menuDisabled:true,
	width: 300,
}
    ],
    listeners: {
       
    }
});
let ctShowDetailedReduceBo =  Ext.create('Ext.panel.Panel', {
    title: '5. 不符合扣分',
    id:'ctShowDetailedReduceBo',
    width:'100%',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
//    anchor: '100%',
    defaults: {
//        padding: '2 10 2 10',
        border: false
    },
    items:[
        ctShowDetailedReduceUnBo,CtIpdDeductBonusPointsBo
    ],
    listeners:{
        'afterrender': function () {
        	
        }
    }
});
//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {
    if (value != null && value != undefined && value != '') {
        var date = new Date(value);
        var time = Ext.Date.format(date, "Y-m-d")
        return time;
    }
    return value;
    
}


