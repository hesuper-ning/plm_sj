
// 定义一个变量来存储 ECUploadImageWindow 的实例
var uploadFileWindowFinal;

// 定义一个函数来初始化 ECUploadImageWindow，但只在首次调用时创建实例
function initUploadFileWindow() {
    if (!uploadFileWindowFinal) {
        uploadFileWindowFinal = Ext.create('Ext.Window', {
            title: '导入文件',
            width: 550,
            height: 350,
            closeAction: 'hide',
            id: 'uploadFileWindow',
            autoScroll: false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: {
                xtype: 'ctUploadPanel',
                // id: 'uploadFormPanel' // 为组件设置唯一的 id
            }
        });
    }
    return uploadFileWindowFinal;
}

var showFileFinal;
function initShowFiles() {
    if (showFileFinal) {
        // 获取到 Store 对象
        var store = Ext.getCmp('showGrid').getStore();
        // 获取到 HttpProxy 对象
        var httpProxy = store.getProxy();
        httpProxy.setUrl(`/Windchill/ptc1/common/searchFileName?fileColumnId=${fileColumnId}&fileColumnName=${fileColumnName}&uploadTableName=${uploadTableName}`);
        // 调用 store 的 load 方法重新加载数据
        store.load();
    }
    if (!showFileFinal) {
        var showColumns = [
            {text: '文档名称', dataIndex: 'fileName', flex: 1, menuDisabled: true, editor: false}
        ];
        var showStore = Ext.create('Ext.data.Store', {
            fields: ['fileName'],
            id: 'showStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/common/searchFileName?fileColumnId='+fileColumnId+'&fileColumnName='+fileColumnName
                    +'&uploadTableName='+uploadTableName+'&branchId='+branchId,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true,
        });
        var showGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var showGrid = Ext.create('Ext.grid.Panel', {
            plugins: [showGridEditing],
            store: showStore,
            columns: showColumns,
            id: 'showGrid',
            autoWidth: true,
            columnLines: true,
            width: '100%',
            height: '100%',
            height: 300,
            multiSelect: false,
            autoScroll: true,
            forceFit: false,
            viewConfig: {
                enableTextSelection: true
            },
            selModel: {
                type: "checkboxmodel",
                mode: 'SINGLE'//单选
                // mode: 'MULTI'//多选
            },
            tbar: [
                {
                    xtype: 'button',
                    text: '下载文件',
                    id: 'showInsert',
                    iconCls: 'icon icon-download',
                    handler: function () {
                        var recordList = showGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var fileName = recordList[0].data.fileName;
                            window.location.href = '/Windchill/ptc1/common/downLoadDoc?fileName=' + fileName + '&branchId=' + branchId + '&type=' +type;
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '删除文件',
                    id: 'showDelete',
                    // hidden:bl,
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        // if(isDeletionAllowed){
                        //     alert("当前节点不允许删除文件！");
                        //     return;
                        // }
                        var recordList = showGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            var fileName = recordList[0].data.fileName;
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/common/deleteFiles?fileName=' + fileName + '&branchId=' + branchId +
                                    '&fileColumnId=' + fileColumnId + '&fileColumnName=' + fileColumnName + '&uploadTableName=' + uploadTableName + '&type=' +type,
                                method: 'POST',
                                headers: {'Content-Type': 'application/json'},
                                // params: JSON.stringify(record.data),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    alert(obj.msg)
                                    showStore.load();
                                    // showStore.load({
                                    //     params: {
                                    //         fileColumnId: fileColumnId,
                                    //         fileColumnName: fileColumnName,
                                    //         uploadTableName: uploadTableName
                                    //     }
                                    // });
                                    //刷新表格内的数据
                                    var uploadFormPannel = Ext.getCmp(gridName);
                                    // 获取关联的 Store
                                    var store = uploadFormPannel.getStore();
                                    // 更新 Store 中的数据
//                                    store.load();
                                    CtIpdDeductBonusPointsBo.getStore().reload(
                                            {
                                            params: {
                                           	 showProjectNumber: allprojectNumber
                                            }
                                        }
                                        );
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: '下载全部文件',
                    id: 'downloadAllFile',
                    iconCls: 'icon icon-download',
                    handler: function () {
                        // var store = showGrid.getStore(); // 获取Grid的数据源
                        var store = showGrid.getStore();
                        var allData = store.getData().items; // 获取数据源中的所有数据
                        var concatenatedData = '';

                        if(allData){
                            for(let i = 0;i < allData.length; i++){
                                let rowData = allData[i].data;
                                if(i==0){
                                    concatenatedData = rowData['fileName']
                                }else {
                                    concatenatedData += ";;;qqq" + rowData['fileName'];
                                }
                            }
                        }

                        if (concatenatedData.length != 0) {
                            //     window.location.href = '/Windchill/ptc1/technicalChange/downLoadAllDoc?fileName='+concatenatedData+'&branchId='+branchId;
                            // 创建一个 form 表单
                            var form = document.createElement('form');
                            form.method = 'POST';
                            form.action = '/Windchill/ptc1/common/downLoadAllDoc';

                            // 创建一个 input 元素用于存放参数
                            var fileNameInput = document.createElement('input');
                            fileNameInput.type = 'hidden';
                            fileNameInput.name = 'fileName';
                            fileNameInput.value = concatenatedData;
                            form.appendChild(fileNameInput);

                            var branchIdInput = document.createElement('input');
                            branchIdInput.type = 'hidden';
                            branchIdInput.name = 'branchId';
                            branchIdInput.value = branchId;
                            form.appendChild(branchIdInput);

                            var typeInput = document.createElement('input');
                            typeInput.type = 'hidden';
                            typeInput.name = 'type';
                            typeInput.value = type;
                            form.appendChild(typeInput);

                            // 将表单添加到页面中
                            document.body.appendChild(form);
                            // 提交表单
                            form.submit();

                        } else {
                            alert("当前没有可以下载的文件！")
                        }
                    }
                }
            ]
            // 其他配置项...
        });

        showFileFinal = Ext.create('Ext.Window', {
            id: 'showFile',
            title: '文档操作',
            width: 700,
            //height: 300,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [showGrid],
        });
    }
    return showFileFinal;
}