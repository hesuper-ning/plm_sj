Ext.define('PLM.view.ctDisplayTwoVRProjectInfo', {
	    extend: 'Ext.panel.Panel',
	    alias: 'widget.ctDisplayTwoVRProjectInfo',
	    border: false,
	    autoScroll: true,
	    autoWidth: true,
	    autoHeight: true,
	    collapsible: false,
	    id: 'ctDisplayTwoVRProjectInfo',
	    initComponent: function () {
	        Ext.define('ctDisplayTwoVRProjectModel', {
	            extend: 'Ext.data.Model',
	            fields: [
					'id','projectNumber','projectName','productLine',
					'relatedMile','executeStatus','pdcpPlannedTime','mileStoneNameEnd',
					'planCompleteTimeEnd','actualCompleteTimeEnd','mileStoneNameIng',
					'planCompleteTimeIng','deviationRate'
	            ],
	            idProperty: 'ctDisplayTwoVRProjectModel'
	        });

	        // 查询 Store
	        var ctDisplayTwoVRProjectStore = Ext.create('Ext.data.Store', {
	            pageSize: 100,
	            model: 'ctDisplayTwoVRProjectModel',
	            id:'ctDisplayTwoVRProjectStore',
	            pruneModifiedRecords: true,
	            proxy: new Ext.data.HttpProxy({
	            	url: '/Windchill/ptc1/IpdProcessCompliance/getCtScheduleDeviationRateVR?branchId=' + branchId + "&currentYM=" + currentMonth,
	                method:'POST',
	                timeout: 90000000,
	                reader:{
	                    type:'json',
	                    rootProperty: 'data',
	                    totalProperty: 'totalCount',
	                    idProperty: 'ctDisplayTwoVRProjectModel',
	                    messageProperty: 'massage'
	                }
	            }),
	            autoLoad:true
	        });

	        var cellEditing = new Ext.grid.plugin.CellEditing({
	            clicksToEdit: 1
	        });

	        var ctDisplayTwoCProjectListGrid = Ext.create('Ext.grid.Panel', {
	            plugins: cellEditing,
	            store:ctDisplayTwoVRProjectStore,
	            autoWidth : true,
	            autoScroll:true,
	            height:500,
	            viewConfig:{enableTextSelection:true, forceFit : false},
	            /*listeners: {
	            	rowclick: function (view, record, item, index, e) {
	                    var headerCt = view.getHeaderCt(); // 获取列头组件
	                    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
	                    var cellIndex = cell.cellIndex; // 获取单元格的索引
//	                    var partNumber = record.get('projectNumber');
	                    // 通过单元格索引获取列
	                    var column = headerCt.getGridColumns()[cellIndex + 1];
	                    if (column) {
	                        var columnName = column.dataIndex;
	                        if(columnName == 'projectNumber'){
	                        	  allprojectNumber = record.get("projectNumber");
	                         	  allprojectName = record.get("projectName");
	                         	  allprojectLine = record.get("productLine");
	                         	  allprojectScore = "100";
	                         	  transferProblemWindow.show();
	                         	if(Ext.getCmp('projectNumber1')){
	                         		Ext.getCmp('projectNumber1').setValue(allprojectNumber);
	                         		Ext.getCmp('projectName1').setValue(allprojectName);
	                             	Ext.getCmp('productLine1').setValue(allprojectLine);
	                             	Ext.getCmp('score1').setValue(allprojectScore);
	                         	}
	                 			loadBasisFormData(allprojectNumber);
	                         	
	                        }
	                    }
	                }
	            },*/
	            columns: [
	                      new Ext.grid.RowNumberer({
	                          align:"center",
	                          width : 30,
	                          renderer:function(value, metaData, record, rowIdx, colIdx, store) {
	                              return rowIdx + 1;
	                          }
	                      }),
	                      { text: 'id',dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
	                      { text: '产品线',dataIndex: 'productLine',width:200 ,menuDisabled:true,renderer:showTip},
	                      { text: '项目编码',dataIndex: 'projectNumber',width:100 ,menuDisabled:true,renderer:showTip},
	                      { text: '项目名称',dataIndex: 'projectName',width:250 ,menuDisabled:true,renderer:showTip},
	                      { text: '相关里程碑',dataIndex: 'relatedMile',width:100 ,menuDisabled:true,renderer:showTip},
	                      { text: '相关里程碑执行状况',dataIndex: 'executeStatus',width:100 ,menuDisabled:true,renderer:showTip},
	                      {
	                          text: '<b>相关数据</b>',
	                          columns: [
								{ text: 'PDCP计划时间',dataIndex: 'pdcpPlannedTime',width:110 ,menuDisabled:true,renderer:showTip},
								{
			                          text: '<b>当月完成里程碑</b>',
			                          columns: [
										{ text: '里程碑名称',dataIndex: 'mileStoneNameEnd',width:110 ,menuDisabled:true,renderer:showTip},
										{ text: '计划完成时间',dataIndex: 'planCompleteTimeEnd',width:110 ,menuDisabled:true,renderer:showTip},
										{ text: '实际完成时间',dataIndex: 'actualCompleteTimeEnd',width:110 ,menuDisabled:true,renderer:showTip}
			                                    ],
			                          menuDisabled:true
			                      },
			                      {
			                          text: '<b>当月进行中里程碑</b>',
			                          columns: [
										{ text: '里程碑名称',dataIndex: 'mileStoneNameIng',width:110 ,menuDisabled:true,renderer:showTip},
										{ text: '计划完成时间',dataIndex: 'planCompleteTimeIng',width:110 ,menuDisabled:true,renderer:showTip}
										     ],
			                          menuDisabled:true
			                      },
								{ text: '偏差率',dataIndex: 'deviationRate',width:110 ,menuDisabled:true,renderer:showTip}
	                                    ],
	                          menuDisabled:true
	                      }
	                      
	                      ]
	        });





	// ========================Items Area======================//

	        this.items=[ctDisplayTwoCProjectListGrid];
	        this.callParent();

	    },// ~End of initComponent
	});


	//region grid单元格悬浮提示
	function showTip(value,metaData,record,row,col,store){
	    if(value)
	        metaData.tdAttr = 'data-qtip="' + value +'"';
	    return value;
	}
	//日期 renderer,防止IE下日期显示异常
	function selfDateFormat(value) {

	    if(value instanceof Date){
	        return Ext.Date.format(value,"Y-m-d");
	    }
	    return value;
	}
