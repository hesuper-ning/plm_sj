Ext.define('PLM.view.ctDisplayTwoExportInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctDisplayTwoExportInfo',
//    title: '<font style="font-size:15px">筛选视图</font>',
    border: false,
    layout: 'anchor',
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ctDisplayTwoExportInfo',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //树的列模型
        Ext.define('ctIpdAllProgressDeviationRateModel', {
            extend: 'Ext.data.Model',
            fields: ['ymShow','belongingtoYear','belongingtoMouth','productLine','projectNumber','projectName',
                     'relatedMile','executeStatus','pdcpPlannedTime','mileStoneNameEnd','planCompleteTimeEnd',
                'actualCompleteTimeEnd','mileStoneNameIng','planCompleteTimeIng','deviationRate',
                'costAmount','costweight','weightDeviationRate'],
            idProperty: 'partPath'
        });

        var ctIpdAllProgressDeviationRateStore = Ext.create('Ext.data.TreeStore', {
            id: 'ctIpdAllProgressDeviationRateStore',
            model: 'ctIpdAllProgressDeviationRateModel',
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/reportForms/getIpdCompUnDeviationRateReport',
                method: 'GET',
                timeout: 99999999,
                reader: {
                    type: 'json'
                }
            }),
            root: {
                expanded: true
            },
            listeners: {
                beforeload: function (store, opts) {
                    let data = {
                        oid: '',
                        type: '',
                        state: '',
                        commonParam: ''
                    };
                    Ext.apply(store.proxy.extraParams, data);
                }
            },
            autoLoad: false,
            folderSort: true
        });

        var ctIpdAllProgressDeviationRateGrid = Ext.create('Ext.tree.Panel', {
            store: ctIpdAllProgressDeviationRateStore,
            // 隐藏默认的根节点
            //renderTo: Ext.getBody(),
            rootVisible: false,
            height: 800,
            autoWidth: true,
            expanded: true,
            border: 0,
            id: 'ctIpdAllProgressDeviationRateGrid',
            autoScroll: true,
            //plugins: [cellEditing],
            viewConfig: {enableTextSelection: true},
            // width:1180,
            // selModel: Ext.create('Ext.selection.CheckboxModel', {
            //             //     mode: "SIMPLE",
            //             //     showHeaderCheckbox: true,
            //             //     checkOnly: true,
            //             //     listeners: {
            //             //         beforeselect: function (obj, record, index) {
            //             //             if (record.get('purchaseType') !== 'F') {
            //             //                 return false;
            //             //             }
            //             //         }
            //             //     }
            //             // }),
            // bodyStyle : 'overflow-x:scroll;
            // overflow-y:scroll',
            //title: '库存列表',
            columns: [],
            //tbar: [
                // {
                //     text: '查询',
                //     iconCls: 'icon icon-search',
                //     handler: function () {
                //         var bomNum = Ext.getCmp('partListCombo2').getValue();
                //         var setNum = Ext.getCmp('setNum').getValue();
                //         var division = Ext.getCmp('division').getValue();
                //         if (bomNum == null || bomNum === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         if (setNum == null || setNum === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         if (division == null || division === '') {
                //             alert('查询参数都不能为空');
                //             return;
                //         }
                //         //getBomInventoryInfo(bomNum, setNum, division);
                //     }
                // }
            //],
            listeners: {
                afterrender: function (t) {
                    // //选择器， 为所有表格添加
                    // var selector = ".x-column-header";
                    // //选择器， 可以为指定的表格添加头部样式内容需要添加id属性，例如id为 firstGrid 那选择器的值如下：
                    // //var selector = "#firstGrid-bodyWrap .x-column-header"
                    // var elments = Ext.select(selector, true);
                    // elments.each(function (el) {
                    //     el.setStyle("font-size", '5px');
                    //     el.setStyle("line-height", '5px');
                    // }, this);
                }
            }
        });

        this.items = [
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">搜索条件</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100, border: false, anchor: '98%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 0 20',
                            labelWidth: 50
                        },
                        items: [
							{
							    xtype: 'combobox',
							    fieldLabel: '类型',
							    name: 'prjjtype9',
							    id: 'prjjtype9',
							    margin: '0 10 5 0',
							    labelWidth: 60,
							    width: 300,
							    value:'VR',
							    enableKeyEvents: true,
							    store: ['VR', 'C'], // 下拉框的选项数据
							    queryMode: 'local', // 查询模式
							    editable: false // 设置为不可编辑
							}   
                        ]
                    },{
                        xtype: 'panel',
                        defaults: {
                            margin: '10 0 0 20',
                            labelWidth: 50
                        },
                        items: [
                            {
                                xtype: 'button',
                                margin: '0 10 5 0',
                                text: '导出',
                                id:'materialSubstitutionReportExport9',
                                iconCls: 'icon icon-exportExcel',
                                handler: function () {
                                	var prjjtype3Q = Ext.getCmp('prjjtype9').getValue();
                                    window.location.href = '/Windchill/ptc1/IpdProcessCompliance/exportCtScheduleDeviationRateReport?branchId=' + branchId + "&currentYM=" + currentMonth + '&prjtype=' + prjjtype3Q;
                                },
                                scope: this
                            }
                        ]
                    }
                ]
            }
        ];
        this.callParent();
    },// ~End of initComponent
    listeners: {
        'beforerender': function () {
        },
        'afterrender': function () {
            //doSearch();
        }
    }

});
