let ctShowBasicInfoBo =  Ext.create('Ext.form.Panel', {
    title: '1、基本情况',
    id:'ctShowBasicInfoBo',
    autoWidth:true,
    xtype: 'form',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[{
		layout : 'hbox',
		border : false,
		margin : '5 5 10 30',
		items : [ {
			xtype : 'displayfield',
			fieldLabel : '项目编码',
			margin : '0 10 0 0',
			queryMode : 'local',
			enableRegEx : true,
			width : 150,
			id : 'projectNumber1',
			name : 'projectNumber1',
			labelWidth : 60
		}, {
			xtype : 'displayfield',
			fieldLabel : '项目名称',
			margin : '0 10 0 0',
			queryMode : 'local',
			enableRegEx : true,
			width : 400,
			id : 'projectName1',
			name : 'projectName1',
			labelWidth : 60
		}, {
			xtype : 'displayfield',
			fieldLabel : '产品线',
			margin : '0 10 0 0',
			queryMode : 'local',
			enableRegEx : true,
			width : 400,
			id : 'productLine1',
			name : 'productLine1',
			labelWidth : 50
		}, {
			xtype : 'displayfield',
			fieldLabel : '得分',
			margin : '0 10 0 0',
			queryMode : 'local',
			enableRegEx : true,
			width : 80,
			id : 'allScore',
			name : 'allScore',
			labelWidth : 50
		} ]
	}],
    listeners:{
        'afterrender': function () {
        
        }
    }
});
