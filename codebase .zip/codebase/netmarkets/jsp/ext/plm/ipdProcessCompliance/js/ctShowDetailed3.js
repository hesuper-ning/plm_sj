let ctContentEditing3 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});
Ext.define('keyDeliverablesReviewEffListModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'belongActivities', 'deliveryName', 'responsibler','scoreReview'],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'keyDeliverablesReviewEffListModel',
    storeId: 'keyDeliverablesReviewEffListStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/IpdProcessCompliance/getIpdDeliverablesReviewInfo?branchId=' + branchId + "&ltype=3&currentYM=" + currentMonth,
        method: 'GET',
        params: {
       	    showProjectNumber: allprojectNumber,
       	    currentYM:  currentMonth
        },
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: false
});

let keyDeliverablesReviewEffListBo = Ext.create('Ext.grid.Panel', {
	autoWidth:true,
	plugins: [ctContentEditing3],
    id: 'keyDeliverablesReviewEffListBo',
    store: Ext.data.StoreManager.lookup('keyDeliverablesReviewEffListStore'),
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 100, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 100, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 100, dataIndex: 'branchId', hidden: true, align: 'center'},
        {text: '所属活动', width: 200, dataIndex: 'belongActivities', editAccess: true,align: 'center',editor: false, renderer:showTip},
        {text: '可交付结果名称', width: 300, dataIndex: 'deliveryName',editAccess: true,  align: 'center', editor: false,renderer:showTip},
        {text: '负责人', width: 200, dataIndex: 'responsibler', editAccess: true, align: 'center',editor: false, renderer:showTip},
        {text: '有效性得分', width: 200, dataIndex: 'scoreReview', editAccess: true, align: 'center', editor: false,renderer:showTip}
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引
            var partNumber = record.get('partNumber');
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'supplierNumber'){
                    supplierCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getSupplierByPartNumber?partNumber=' + partNumber,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        supplierCombo.getStore().add({supplierInfo:item.supplierInfo});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
        	updateDeductBonusPointsInfo(editor, e);
        }
    }
});

let keyDeliverablesReviewEffScoreBo =  Ext.create('Ext.form.Panel', {
    id:'keyDeliverablesReviewEffScoreBo',
    autoWidth:true,
    xtype: 'form',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
{
	xtype: 'displayfield',
	fieldLabel: '平均得分',
	labelAlign: 'right',
	id: 'averageScoreTh',
    name: 'averageScoreTh',
	value: ' ',
	mode : 'local',
	menuDisabled:true,
	width: 300,
}
    ],
    listeners: {
       
    }
});
let keyDeliverablesReviewEffBo =  Ext.create('Ext.panel.Panel', {
    title: '3. 关键交付物评审有效性',
    id:'keyDeliverablesReviewEffBo',
    width:'100%',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
//    anchor: '100%',
    defaults: {
//    padding: '2 10 2 10',
        border: false
    },
    items:[
        keyDeliverablesReviewEffScoreBo,keyDeliverablesReviewEffListBo
    ],
    listeners:{
        'afterrender': function () {
        	
        }
    }
});
//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {
    if (value != null && value != undefined && value != '') {
        var date = new Date(value);
        var time = Ext.Date.format(date, "Y-m-d")
        return time;
    }
    return value;
    
}


