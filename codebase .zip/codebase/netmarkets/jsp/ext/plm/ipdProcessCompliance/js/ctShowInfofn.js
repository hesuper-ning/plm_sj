
var transferProblemForm = new Ext.form.Panel({
	xtype : 'form',
	margin : '10 0 0 0',
	border : false,
	height : 600,
	autoScroll : true,
	items : [ ctShowBasicInfoBo,ctFileSubmitInfoBo,KeyDeliverableReviewBo,keyDeliverablesReviewEffBo,keyDeliverablesOfDeliveryBo, ctShowDetailedReduceBo,ctShowDetailedAddBo ],
	listeners : {
		'render' : function() {
			
		},
		'afterrender' : function() {}
	}
})

var transferProblemWindow = Ext.create('Ext.Window', {
id:'transferProblemWindow',
//title: '添加问题',
width: 1200,
autoWidth : true,
//height: 300,
autoHeight : true,
closeAction: 'hide',
//closable:false,
constrain: true,
modal:true,
items:[transferProblemForm],
});