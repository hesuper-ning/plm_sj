Ext.define('PLM.view.ctDisplayCProjectInfo', {
	    extend: 'Ext.panel.Panel',
	    alias: 'widget.ctDisplayCProjectInfo',
	    border: false,
	    autoScroll: true,
	    autoWidth: true,
	    autoHeight: true,
	    collapsible: false,
	    id: 'ctDisplayCProjectInfo',
	    initComponent: function () {
	        Ext.define('ctDisplayCProjectModel', {
	            extend: 'Ext.data.Model',
	            fields: [
					'id','projectNumber','projectName','specialProcessProjects','productLine',
					'pqa','iPDPocessCompliance','fileScoreRate','keyDeliverableRateScore','keyDeEffectivenessEvaluation','keyDeTimelinessScore',
					'deductPoints','bonusPoints'
	            ],
	            idProperty: 'ctDisplayCProjectModel'
	        });

	        // 查询 Store
	        var ctDisplayCProjectStore = Ext.create('Ext.data.Store', {
	            pageSize: 100,
	            model: 'ctDisplayCProjectModel',
	            id:'ctDisplayCProjectStore',
	            pruneModifiedRecords: true,
	            proxy: new Ext.data.HttpProxy({
	            	url: '/Windchill/ptc1/IpdProcessCompliance/getIpdProcessComplianceC?branchId=' + branchId + "&currentYM=" + currentMonth,
	                method:'POST',
	                timeout: 90000000,
	                reader:{
	                    type:'json',
	                    rootProperty: 'data',
	                    totalProperty: 'totalCount',
	                    idProperty: 'ctDisplayCProjectModel',
	                    messageProperty: 'massage'
	                }
	            }),
	            autoLoad:true
	        });

	        var cellEditing = new Ext.grid.plugin.CellEditing({
	            clicksToEdit: 1
	        });

	        var ctDisplayCProjectListGrid = Ext.create('Ext.grid.Panel', {
	            plugins: cellEditing,
	            store:ctDisplayCProjectStore,
	            autoWidth : true,
	            autoScroll:true,
	            height:500,
	            viewConfig:{enableTextSelection:true, forceFit : false},
	            listeners: {
	            	rowclick: function (view, record, item, index, e) {
	                    var headerCt = view.getHeaderCt(); // 获取列头组件
	                    var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
	                    var cellIndex = cell.cellIndex; // 获取单元格的索引
//	                    var partNumber = record.get('projectNumber');
	                    // 通过单元格索引获取列
	                    var column = headerCt.getGridColumns()[cellIndex + 1];
	                    if (column) {
	                        var columnName = column.dataIndex;
	                        if(columnName == 'projectNumber'){
	                        	  allprojectNumber = record.get("projectNumber");
	                         	  /*allprojectName = record.get("projectName");
	                         	  allprojectLine = record.get("productLine");
	                         	  allprojectScore = "100";*/
	                         	  transferProblemWindow.show();
	                         	/*if(Ext.getCmp('projectNumber1')){
	                         		Ext.getCmp('projectNumber1').setValue(allprojectNumber);
	                         		Ext.getCmp('projectName1').setValue(allprojectName);
	                             	Ext.getCmp('productLine1').setValue(allprojectLine);
	                             	Ext.getCmp('score1').setValue(allprojectScore);
	                         	}*/
	                 			loadBasisFormData(allprojectNumber);
	                         	
	                        }
	                    }
	                }
	            },
	            columns: [
	                      new Ext.grid.RowNumberer({
	                          align:"center",
	                          width : 30,
	                          renderer:function(value, metaData, record, rowIdx, colIdx, store) {
	                              return rowIdx + 1;
	                          }
	                      }),
	                      { text: 'id',dataIndex: 'id',width:100 ,menuDisabled:true,hidden:true},
	                      { text: '项目编码',dataIndex: 'projectNumber',width:100 ,menuDisabled:true,renderer:showTip},
	                      { text: '项目名称',dataIndex: 'projectName',width:250 ,menuDisabled:true,renderer:showTip},
	                      { text: '是否为特殊流程项目',dataIndex: 'specialProcessProjects',width:100 ,menuDisabled:true,renderer:showTip},
	                      { text: '产品线',dataIndex: 'productLine',width:200 ,menuDisabled:true,renderer:showTip},
	                      { text: 'PQA',dataIndex: 'pqa',width:80 ,menuDisabled:true,renderer:showTip},
	                      { text: 'IPD流程符合度',dataIndex: 'iPDPocessCompliance',width:100 ,menuDisabled:true,renderer:showTip,
							  renderer: function (value, meta, record) {
								  if(value){
									  let bfValue = value+'%';
									  return bfValue;
								  }
								  return value;
							  }},
	                      {
	                          text: '<b>子项得分</b>',
	                          columns: [
								{ text: '文件提交率得分',dataIndex: 'fileScoreRate',width:110 ,menuDisabled:true,renderer:showTip},
								{ text: '关键交付件评审率得分',dataIndex: 'keyDeliverableRateScore',width:110 ,menuDisabled:true,renderer:showTip},
								{ text: '关键交付物评审有效性评价',dataIndex: 'keyDeEffectivenessEvaluation',width:110 ,menuDisabled:true,renderer:showTip},
								{ text: '关键交付件交付及时性得分',dataIndex: 'keyDeTimelinessScore',width:110 ,menuDisabled:true,renderer:showTip},
								{ text: '不符合项扣分',dataIndex: 'deductPoints',width:110 ,menuDisabled:true,renderer:showTip},
								{ text: '加分项',dataIndex: 'bonusPoints',width:110 ,menuDisabled:true,renderer:showTip}
	                                    ],
	                          menuDisabled:true
	                      }
	                      
	                      
	                      ]
	        });





	// ========================Items Area======================//

	        this.items=[ctDisplayCProjectListGrid];
	        this.callParent();

	    },// ~End of initComponent
	});


	//region grid单元格悬浮提示
	function showTip(value,metaData,record,row,col,store){
	    if(value)
	        metaData.tdAttr = 'data-qtip="' + value +'"';
	    return value;
	}
	//日期 renderer,防止IE下日期显示异常
	function selfDateFormat(value) {

	    if(value instanceof Date){
	        return Ext.Date.format(value,"Y-m-d");
	    }
	    return value;
	}

