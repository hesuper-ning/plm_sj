Ext.define('PLM.view.CtIpdProcessComplianceReview', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtIpdProcessComplianceReview',
    border: false,
    autoScroll: true,
    autoWidth: true,
    height: 588,
    collapsible: false,
    id: 'CtIpdProcessComplianceReview',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        xtype:'tabpanel',
                        id: 'ipdProcessComplianceTabPanel',
                        activeTab: 0,
                        items:[
                            {
                                title: '<font style="font-size:12px">IPD流程符合度</font>',
                                xtype: 'CtIpdProcessComplianceSecOneReview'
                            }
                            ,
                            {
                                scrollable: true,
                                title: '<font style="font-size:12px">项目进度偏差率</font>',
                                xtype:'CtIpdProcessComplianceSecSecReview'
                            }
                        ]//~End of tabpanel items
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    }
});