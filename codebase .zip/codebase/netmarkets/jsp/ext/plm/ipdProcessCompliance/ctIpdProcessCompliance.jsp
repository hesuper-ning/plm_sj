<%@ page import="ext.plm.ipdProcessCompliance.config.IpdProcessComProperties" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page import="wt.org.WTUser" %>
<%@ page import="wt.pdmlink.PDMLinkProduct" %>
<%@ page import="ext.plm.util.CtVersionUtil" %>
<%@ page import="java.util.Date" %>
<%@ page import="ext.plm.ipdProcessCompliance.IpdProcessComplianceHelper" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<%--   交付件评审表单 --%>
    <%
        String workItemOid = request.getParameter("oid");
        long branchId = 1L;
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(workItemOid).getObject();
        String currentActKey = "";
        String docProductName = "";
        boolean taskCompleted = false; //任务是否已完成
        long timestamp = System.currentTimeMillis();
        boolean readOnlyPage = false;
        String docTypeName = "";
        String docName = "";
        String docNumber = "";
        String versionInfo = "";
        String containerId = "";
        String userName = "";
        Date date = new Date();
        //String currentMonth = "2024-" + (date.getMonth() + 1);
        if(obj instanceof WorkItem){
            WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            String actName = activity.getName();
            currentActKey = IpdProcessComProperties.getActivityKey(actName);
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
            WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
            docProductName = doc.getContainerName();
            docTypeName = CtWTObjectUtil.getTypeViewName(doc);
            branchId = doc.getBranchIdentifier();
            docName = doc.getName();
            docNumber = doc.getNumber();
            versionInfo = CtVersionUtil.getVersionInfo(doc);
            containerId = "OR:wt.pdmlink.PDMLinkProduct:" + doc.getContainer().getPersistInfo().getObjectIdentifier().getId();
            userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
           // String name = ext.plm.util.CtUserUtil.getCurrentUserAccountName();
            //获取工作负责人  如果是管理员就将当前用户改为工作负责人
            /* if (userName.equals("wcadmin")) {
                adminUser = workItem.getOwnership().getOwner().getFullName();
            }else {
                adminUser=userName;
            } */
        }else{
            WTDocument doc = (WTDocument)CtWTObjectUtil.getObjectByOid(workItemOid);
            if(null != doc){
            	branchId = doc.getBranchIdentifier();
            }
            /* else{
            	 String branchIdStr = workItemOid.substring(workItemOid.lastIndexOf(":") + 1);
                 branchId = Long.valueOf(branchIdStr);
                 
            } */
            readOnlyPage = true;
        }
        String currentMonth = IpdProcessComplianceHelper.getCurrentYM(branchId+"");
    %>

    <script type="text/javascript">
        var imgs = '';
        var projectNumberinit='';
        var docProductName = "<%=docProductName%>";
        var docTypeName = "<%=docTypeName%>" + "评审";
        var docName = "<%=docName%>" ;
        var docNumber = "<%=docNumber%>";
        var versionInfo = "<%=versionInfo%>";
        var containerId = "<%=containerId%>";
        var workItemOid = "<%=workItemOid%>";
        var branchId ='<%= branchId %>';
        //当前用户全名
        var userName = "<%=userName%>";
        var currentMonth="<%=currentMonth%>";
        var userDisplayName = "<%=userName%>";
        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";
        //当前的任务完成状态
        var taskCompleted = false;
        <%if(taskCompleted){%>
            taskCompleted = true;
        <%}%>
        var readOnlyPage = <%=readOnlyPage%>;
        var loadFormFlag = true;
        var fileColumnId = '';
        var fileColumnName = '';
        var uploadTableName = '';
        var gridName = '';
        var type = 'doc';
        //问题编号
        var problemId = "";
        
        var allprojectNumber = "";
        var allprojectName = "";
        var allprojectLine = "";
        var allprojectScore = "";
    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    
   <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
   <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
   <script type="text/javascript" src="js/ctShowFilePanel.js?_dc=<%System.currentTimeMillis();%>"></script>
   <script type="text/javascript" src="js/ctUploadFilePanel.js?_dc=<%System.currentTimeMillis();%>"></script>
   <script type="text/javascript" src="js/uploadImagePanel.js?_dc=<%=timestamp%>"></script>
  
  
    <script type="text/javascript" src="js/ctShowBasicInfo.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctIpdProcessComplianceFn.js?_dc=<%=timestamp%>"></script>
  
   <script type="text/javascript" src="js/ctShowDetailed1.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctShowDetailed2.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctShowDetailed3.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctShowDetailed4.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctShowDetailed5.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctShowDetailed6.js?_dc=<%=timestamp%>"></script>

   <script type="text/javascript" src="js/ctShowInfofn.js?_dc=<%=timestamp%>"></script>
 
   <script type="text/javascript" src="js/ctIpdProcessComplianceSecOneReview.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctIpdProcessComplianceSecSecReview.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctIpdProcessComplianceThrOneReview.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctIpdProcessComplianceThrTwoReview.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctIpdProcessComplianceThrThrReview.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctIpdProcessComplianceThrForReview.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctIpdProcessComplianceThrFiveReview.js?_dc=<%=timestamp%>"></script>
   <script type="text/javascript" src="js/ctIpdProcessCompliance.js?_dc=<%=timestamp%>"></script>
   
   
  
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.apply(Ext.QuickTips.getQuickTip(), {
            dismissDelay: 120000
        });
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'CtIpdProcessComplianceReview',
            }]
        });
    });
</script>
</body>
</html>