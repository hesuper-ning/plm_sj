<%@ page import="ext.plm.projectBudget.config.CtProjectBudgetProperties" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        String workItemOid = oid;
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workItem = (WorkItem) rf.getReference(oid).getObject();
        WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
        String actName = activity.getName();
        WTDocument doc = (WTDocument)workItem.getPrimaryBusinessObject().getObject();
        //将文档的大版本branchId作为主键id
        String docBranchId = doc.getBranchIdentifier()+"";
//        wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
//        String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=";
//        String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
        boolean allowEdit = false;
        boolean allowImport = false;
        String allowEdit_activityName = CtProjectBudgetProperties.getProperty("allowEdit_ActivityName");
        String allowImport_activityName = CtProjectBudgetProperties.getProperty("allowImport_ActivityName");
        if(!workItem.isComplete()){
            if(allowEdit_activityName.contains(actName)){
                allowEdit = true;
            }
            if(allowImport_activityName.contains(actName)){
                allowImport = true;
            }
        }

    %>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="js/ctProjectBudget.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctProjectBudgetFunctions.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
</head>

<body>
<script>
    var workItemOid = "<%=workItemOid%>";
    //文档vid
    var docBranchId = "<%=docBranchId%>";

    var allowEdit = false;
    <%if(allowEdit){%>
        allowEdit = true;
    <%}%>
    //是否可以导入
    var allowImport = false;
    <%if(allowImport){%>
        allowImport = true;
    <%}%>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ProjectBudgetPanel'
            }]
        });
    });
</script>
</body>
</html>