<%@ page import="wt.doc.WTDocument" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WTDocument doc = (WTDocument) rf.getReference(oid).getObject();
        //将文档的大版本branchId作为主键id
        String docBranchId = doc.getBranchIdentifier()+"";
        boolean allowImport = false;
    %>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="js/ctProjectBudget.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctProjectBudgetFunctions.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
</head>

<body>
<script>
    //文档vid
    var docBranchId = "<%=docBranchId%>";

    var allowEdit = false;
    //是否可以导入
    var allowImport = false;
    //是否可以导入
    var allowImport = false;

    var workItemOid = 'NA';
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ProjectBudgetPanel'
            }]
        });
    });
</script>
</body>
</html>