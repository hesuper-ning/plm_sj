<%@ page language="java" import="java.util.*"  contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>


<iframe id="ctOtherSubjectBudgetQueryIframe" src="netmarkets/jsp/ext/plm/projectBudget/ctOtherSubjectBudgetQuery.jsp?" style="width:98%;height:800px" ></iframe>
