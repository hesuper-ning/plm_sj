Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
   // autoWidth: true,
   // autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'otherSubjectBudgetQuery',
        in_objectDesc: '其它科目预算与成本执行',
    },
    id: 'MockExample',


    initComponent: function () {
        var me = this;
        var otherSubjectBudgetQueryStore = Ext.create('PLM.store.MockItemStore', {
            id: 'otherSubjectBudgetQueryStore'
        });

        this.title = '其它科目预算与成本执行'

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });



        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('otherSubjectBudgetQueryStore'),
            id: 'mockExampleGrid',
            margin: '10 0 0 0',
            //autoWidth: true,
            autoScroll: true,
            region: 'center',
            height: 450,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },


            columns: [{text:'序号',xtype: 'rownumberer', width: 40},
                {text: '成本科目', dataIndex: 'data1', width: 120, editor: 'textfield',},
                {
                    text: '汇总',
                    columns: [
                        {text: '预算', dataIndex: 'data2', width: 80, editor: 'textfield',},
                        {text: '实际', dataIndex: 'data3', width: 80, editor: 'textfield',},
                        {text: '预算实用率', dataIndex: 'data4', width: 80, editor: 'textfield',},
                        {text: '偏差率', dataIndex: 'data5', width: 80, editor: 'textfield',}
                    ]
                },{
                    text: 'Start-TR2',
                    columns: [
                        {text: '预算', dataIndex: 'data6', width: 80, editor: 'textfield',},
                        {text: '实际', dataIndex: 'data7', width: 80, editor: 'textfield',},
                        {text: '预算实用率', dataIndex: 'data8', width: 80, editor: 'textfield',},
                        {text: '偏差率', dataIndex: 'data9', width: 80, editor: 'textfield',}
                    ]
                },{
                    text: 'TR2-PDCP',
                    columns: [
                        {text: '预算', dataIndex: 'data10', width: 80, editor: 'textfield',},
                        {text: '实际', dataIndex: 'data11', width: 80, editor: 'textfield',},
                        {text: '预算实用率', dataIndex: 'data12', width: 80, editor: 'textfield',},
                        {text: '偏差率', dataIndex: 'data13', width: 80, editor: 'textfield',}
                    ]
                },{
                    text: 'PDCP-TR4',
                    columns: [
                        {text: '预算', dataIndex: 'data14', width: 80, editor: 'textfield',},
                        {text: '实际', dataIndex: 'data15', width: 80, editor: 'textfield',},
                        {text: '预算实用率', dataIndex: 'data16', width: 80, editor: 'textfield',},
                        {text: '偏差率', dataIndex: 'data17', width: 80, editor: 'textfield',}
                    ]
                },{
                    text: 'TR4-TR5',
                    columns: [
                        {text: '预算', dataIndex: 'data18', width: 80, editor: 'textfield',},
                        {text: '实际', dataIndex: 'data19', width: 80, editor: 'textfield',},
                        {text: '预算实用率', dataIndex: 'data20', width: 80, editor: 'textfield',},
                        {text: '偏差率', dataIndex: 'data21', width: 80, editor: 'textfield',}
                    ]
                },{
                    text: 'TR5-TR6',
                    columns: [
                        {text: '预算', dataIndex: 'data22', width: 80, editor: 'textfield',},
                        {text: '实际', dataIndex: 'data23', width: 80, editor: 'textfield',},
                        {text: '预算实用率', dataIndex: 'data24', width: 80, editor: 'textfield',},
                        {text: '偏差率', dataIndex: 'data25', width: 80, editor: 'textfield',}
                    ]
                },{
                    text: 'TR6-End',
                    columns: [
                        {text: '预算', dataIndex: 'data26', width: 80, editor: 'textfield',},
                        {text: '实际', dataIndex: 'data27', width: 80, editor: 'textfield',},
                        {text: '预算实用率', dataIndex: 'data28', width: 80, editor: 'textfield',},
                        {text: '偏差率', dataIndex: 'data29', width: 80, editor: 'textfield',}
                    ]
                },
                {text: '', dataIndex: '', width: 10}
            ]
        });





        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('otherSubjectBudgetQueryStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('otherSubjectBudgetQueryStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('otherSubjectBudgetQueryStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
        }
    }
});

