Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'userCostBudget',
        in_objectDesc: '人力成本科目预算',
        in_objectKey1: 'otherSubjectBudget',
        in_objectDesc1: '其它成本科目预算',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var userCostBudgetStore = Ext.create('PLM.store.MockItemStore', {
            id: 'userCostBudgetStore'
        });

        var otherSubjectBudgetStore = Ext.create('PLM.store.MockItemStore', {
            id: 'otherSubjectBudgetStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var userCostBudgetGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('userCostBudgetStore'),
            selType: 'checkboxmodel',
            id: 'userCostBudgetGrid',
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 500,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: userCostBudgetGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{text:'',xtype: 'rownumberer',width:20},
                {text: '部门', dataIndex: 'data1', width: 150, editor: 'textfield'},
                {text: '工程师分类', dataIndex: 'data2', width: 150, editor: 'textfield'},

                {
                    text: '汇总',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data3', width: 100,align: 'center', editor: 'textfield',}
                    ]
                },{
                    text: 'Start-TR2',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data4', width: 100,align: 'center', editor: 'textfield',}
                    ]
                },{
                    text: 'TR2-PDCP',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data5', width: 100,align: 'center', editor: 'textfield',}
                    ]
                },{
                    text: 'PDCP-TR4',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data6', width: 100,align: 'center', editor: 'textfield',}
                    ]
                },{
                    text: 'TR4-TR5',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data7', width: 100, align: 'center',editor: 'textfield',}
                    ]
                },{
                    text: 'TR5-TR6',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data8', width: 100,align: 'center', editor: 'textfield',}
                    ]
                },{
                    text: 'TR6-End',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data9', width: 100,align: 'center', editor: 'textfield',}
                    ]
                },
                {text: '', dataIndex: '', width: 150}
            ]
        });
        userCostBudgetGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var otherSubjectBudgetGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('otherSubjectBudgetStore'),
            selType: 'checkboxmodel',
            id: 'otherSubjectBudgetGrid',
            autoWidth: true,
            autoScroll: true,
            region: 'center',
            height: 500,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: otherSubjectBudgetGrid,
                            param_objectKey: me.in_objectKey1,
                            param_objectDesc: me.in_objectDesc1
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },

            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{text:'',xtype: 'rownumberer',width:20},
                {text: '部门', dataIndex: 'data1', columnWidth:0.1, width: 120, editor: 'textfield'},
                {
                    text: '汇总',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data2', width: 100,align: 'center', editor: 'textfield',}
                    ]
                },{
                    text: 'Start-TR2',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data3', width: 100, align: 'center',editor: 'textfield',}
                    ]
                },{
                    text: 'TR2-PDCP',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data4', width: 100, align: 'center',editor: 'textfield',}
                    ]
                },{
                    text: 'PDCP-TR4',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data5', width: 100, align: 'center',editor: 'textfield',}
                    ]
                },{
                    text: 'TR4-TR5',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data6', width: 100, align: 'center',editor: 'textfield',}
                    ]
                },{
                    text: 'TR5-TR6',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data7', width: 100,align: 'center', editor: 'textfield',}
                    ]
                },{
                    text: 'TR6-End',width: 100,
                    columns: [
                        {text: '预算', dataIndex: 'data8', width: 100, align: 'center',editor: 'textfield',}
                    ]
                },
                {text: '', dataIndex: '', columnWidth:0.9}
            ]
        });
        otherSubjectBudgetGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey1, this.in_objectDesc1, itemId, tField, tValue, callbackFn);

            });

        var tabs = Ext.widget('tabpanel', {
            renderTo: document.body,
            activeTab: 0,
            plain: true,
            height:'98%',
            defaults :{
                autoScroll: true,
                bodyPadding: 0
            },
            items: [{
                title: '人力成本科目预算',
                items:userCostBudgetGrid
            },{
                title: '其他成本科目预算',
                items: otherSubjectBudgetGrid
            }]
        });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{

            }, tabs]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('userCostBudgetStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('userCostBudgetStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('userCostBudgetStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });

            Ext.getStore('otherSubjectBudgetStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey1()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('otherSubjectBudgetStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('otherSubjectBudgetStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey1()
                                , Ext.getCmp('MockExample').getIn_objectDesc1, callbackFn);
                        }
                    }
                }
            })
        }
    }

});

