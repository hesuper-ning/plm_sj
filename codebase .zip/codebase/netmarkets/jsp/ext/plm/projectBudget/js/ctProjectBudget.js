Ext.define('PLM.view.ProjectBudgetPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ProjectBudgetPanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'projectBudgetPanel',
    initComponent: function () {
        Ext.define('UserCostBudgetModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','docBranchId','department','gather','engineerClassification','startTotr2','tr2Topdcp'
                ,'pdcpTotr4','tr4Totr5','tr5Totr6','tr6Toend'
            ],
            idProperty: 'id'+'department'+'engineerClassification'
        });
        // create the Data Store
        this.userCostBudgetStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'UserCostBudgetModel',
            id:'userCostBudgetStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/projectBudget/getUserCostBudget',
                params:{
                    docBranchId:Ext.encode(docBranchId)
                },
                method:'GET',
                reader:{
                    type:'json',
                    root: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id'+'department'+'engineerClassification',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });

        var userCostBudgetCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var userCostBudgetGrid = Ext.create('Ext.grid.Panel', {
            plugins: [userCostBudgetCellEditing],
            store: Ext.getStore('userCostBudgetStore'),
            // selType: 'checkboxmodel',
            id: 'userCostBudgetGrid',
            autoWidth: true,
            autoScroll: true,
            invalidateScrollerOnRefresh : false,
            region: 'center',
            height: 500,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //sortInfo:{field:'department',direction:'ASC'},
            viewConfig:{enableTextSelection:true},
            columns: [//{text:'',xtype: 'rownumberer',width:50},
                {text: '部门', dataIndex: 'department', width: 150, },
                {text: '工程师分类', dataIndex: 'engineerClassification', width: 150, sortable:false},

                {
                    text: '汇总',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'gather', width: 100,align: 'center',sortable:false}
                    ]
                },{
                    text: 'Start-TR2',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'startTotr2', width: 100,align: 'center',sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'TR2-PDCP',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'tr2Topdcp', width: 100,align: 'center', sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'PDCP-TR4',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'pdcpTotr4', width: 100,align: 'center', sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'TR4-TR5',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'tr4Totr5', width: 100, align: 'center',sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'TR5-TR6',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'tr5Totr6', width: 100,align: 'center', sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'TR6-End',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'tr6Toend', width: 100,align: 'center',sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },
                {text: '', dataIndex: '', width: 150}
            ],

        tbar:[{
            xtype:'filefield',
            buttonOnly: true,
            hidden:!allowImport,
            id:'upload1',
            hideLabel: true,
            buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/> Excel导入</span>',
            allowBlank: false,
            scope: this,
            listeners:{
            'change':function(fb,newValue,oldValue,opts){
                if(!newValue){
                    return;
                }
                var file = document.querySelector('[id=upload1-button-fileInputEl]');
                var formData = new FormData();
                formData.append('upload1-button-fileInputEl', file.files[0]);
                fb.reset();

                var myMask = new Ext.LoadMask({
                    msg: '正在导入数据，请稍候......',
                    target: userCostBudgetGrid
                });

                myMask.show();
                $.ajax({
                    url: '/Windchill/ptc1/projectBudget/importUserCostBudget?docBranchId='+docBranchId,
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function(res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if(!success){
                        alert(msg);
                    }else {
                        refreshUserCostBudgetStore();
                    }
                }).fail(function(res) {
                    myMask.hide();
                    alert('导入失败！') ;
                });
            }


        }
        },
        '&nbsp;',{
            text: 'Excel导出',
            iconCls : 'icon icon-store-export',
            hidden:!allowImport,
            scope: this,
            handler : function(){
                var gridSize = userCostBudgetGrid.getStore().getTotalCount();
                if(gridSize == 0){
                    alert("列表没数据,请不用导出！");
                    return;
                }
                window.location.href="/Windchill/ptc1/projectBudget/exportUserCostBudget?docBranchId="+docBranchId;
            }
        },'&nbsp;',{
            text: '下载模板',
            iconCls : 'icon icon-download',
            hidden:!allowImport,
            scope: this,
            handler : function(){
                window.location.href =
                    '/Windchill/ptc1/projectBudget/downLoadTemplate?templateName=人力成本科目预算导入模板';
            }
        },'&nbsp;',{
            text:'',
            id:'saveStatus1',
            disabled:true
        }]
        });
        userCostBudgetGrid.on('beforeedit',
            function (editor, e) {
                if(!allowEdit){
                    Ext.getCmp("saveStatus1").setText("不能编辑");
                    return false;
                }
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var id = tRecord.get('id');
                if(id == 0){
                    Ext.getCmp("saveStatus1").setText("不能编辑汇总行数据");
                    return false;
                }
            });
        userCostBudgetGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var id = tRecord.get('id');
                if(id!=0){
                    updateUserCostBudget(id,tField,tValue,tRecord);
                }
        });


        Ext.define('OtherSubjectBudgetModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','docBranchId','department','departmentDesc','gather','startTotr2','tr2Topdcp'
                ,'pdcpTotr4','tr4Totr5','tr5Totr6','tr6Toend'
            ],
            idProperty: 'id'
        });
        // create the Data Store
        this.otherSubjectBudgetStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'OtherSubjectBudgetModel',
            id:'otherSubjectBudgetStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/projectBudget/getOtherSubjectBudget',
                params:{
                    docBranchId:Ext.encode(docBranchId)
                },
                method:'GET',
                reader:{
                    type:'json',
                    root: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false
        });

        var otherSubjectBudgetCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var otherSubjectBudgetGrid = Ext.create('Ext.grid.Panel', {
            plugins: [otherSubjectBudgetCellEditing],
            store: Ext.getStore('otherSubjectBudgetStore'),
            // selType: 'checkboxmodel',
            id: 'otherSubjectBudgetGrid',
            autoWidth: true,
            autoScroll: true,
            invalidateScrollerOnRefresh : false,//刷新时固定滚动条
            region: 'center',
            height: 500,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig:{enableTextSelection:true},
            columns: [//{text:'',xtype: 'rownumberer',width:50},
                {text: '成本科目', dataIndex: 'department', columnWidth:0.1, width: 120,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        if(record.get('departmentDesc')){
                            var tip =  record.get('departmentDesc');
                            metaData.tdAttr = " data-qtip = '"+tip+"'";
                        }
                        return value;

                    }
                },
                {
                    text: '汇总',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'gather', width: 100,align: 'center'}
                    ]
                },{
                    text: 'Start-TR2',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'startTotr2', width: 100, align: 'center',sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'TR2-PDCP',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'tr2Topdcp', width: 100, align: 'center',sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'PDCP-TR4',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'pdcpTotr4', width: 100, align: 'center',sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'TR4-TR5',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'tr4Totr5', width: 100, align: 'center',sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'TR5-TR6',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'tr5Totr6', width: 100,align: 'center', sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },{
                    text: 'TR6-End',width: 100,
                    columns: [
                        {text: '预算/元', dataIndex: 'tr6Toend', width: 100, align: 'center',sortable:false,
                            editor: {
                                xtype:'textfield',
                                regex:/^[-+]?[\d]+$/,
                                regexText:'请输入正确的正整数!',
                            }
                        }
                    ]
                },
                {text: '', dataIndex: '', columnWidth:0.9}
            ],

            tbar:[{
                xtype:'filefield',
                buttonOnly: true,
                hidden:!allowImport,
                id:'upload2',
                hideLabel: true,
                buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/> Excel导入</span>',
                //allowBlank: false,
                scope: this,
                listeners:{
                    'change':function(fb,newValue,oldValue,opts){
                        if(!newValue){
                            return;
                        }
                        var file = document.querySelector('[id=upload2-button-fileInputEl]');
                        var formData = new FormData();
                        formData.append('upload2-button-fileInputEl', file.files[0]);
                        fb.reset();

                        var myMask = new Ext.LoadMask({
                            msg: '正在导入数据，请稍候......',
                            target: otherSubjectBudgetGrid
                        });
                        myMask.show();
                        $.ajax({
                            url: '/Windchill/ptc1/projectBudget/importOtherSubjectBudget?docBranchId='+docBranchId,
                            type: 'POST',
                            cache: false,
                            data: formData,
                            processData: false,
                            contentType: false
                        }).done(function(res) {
                            myMask.hide();
                            var obj = Ext.decode(res);
                            var success = obj['success'];
                            var msg = obj['msg'];
                            if(!success){
                                alert(msg);
                            }else {
                                refreshOtherSubjectBudgetStore();
                            }
                        }).fail(function(res) {
                            myMask.hide();
                            alert('导入失败！') ;
                        });
                    }

                }

            },
                '&nbsp;',{
                    text: 'Excel导出',
                    iconCls : 'icon icon-store-export',
                    hidden:!allowImport,
                    scope: this,
                    handler : function(){
                        var gridSize = otherSubjectBudgetGrid.getStore().getTotalCount();
                        if(gridSize == 0){
                            alert("列表没数据,请不用导出！");
                            return;
                        }
                        window.location.href="/Windchill/ptc1/projectBudget/exportOtherSubjectBudget?docBranchId="+docBranchId;
                    }
                },'&nbsp;',{
                    text: '下载模板',
                    iconCls : 'icon icon-download',
                    hidden:!allowImport,
                    scope: this,
                    handler : function(){
                        window.location.href =
                            '/Windchill/ptc1/projectBudget/downLoadTemplate?templateName=其他成本科目预算导入模板';
                    }
                },'&nbsp;',{
                    text:'',
                    id:'saveStatus2',
                    disabled:true
                }]
        });

        otherSubjectBudgetGrid.on('beforeedit',
            function (editor, e) {
                if(!allowEdit){
                    Ext.getCmp("saveStatus2").setText("不能编辑");
                    return false;
                }
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var id = tRecord.get('id');
                if(id == 0){
                    Ext.getCmp("saveStatus2").setText("不能编辑汇总行数据");
                    return false;
                }
            });
        otherSubjectBudgetGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var id = tRecord.get('id');
                updateOtherSubjectBudget(id,tField,tValue,tRecord);
            });

        var tabs = Ext.widget('tabpanel', {
            renderTo: document.body,
            activeTab: 0,
            plain: true,
            // height:'98%',
            defaults :{
                // autoScroll: true,
                bodyPadding: 0
            },
            items: [{
                title: '人力成本科目预算',
                items:userCostBudgetGrid
            },{
                title: '其他成本科目预算',
                items: otherSubjectBudgetGrid
            }]
        });

        var projectBudgetForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{

            }, tabs]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [tabs];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            refreshUserCostBudgetStore();
            refreshOtherSubjectBudgetStore();
        }
    }

});




