Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'partCostQuery',
        in_objectDesc: '物料成本查询',
    },
    id: 'MockExample',


    initComponent: function () {
        var me = this;
        var partCostQueryStore = Ext.create('PLM.store.MockItemStore', {
            id: 'partCostQueryStore'
        });

        this.title = '物料成本报表查询'

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });



        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('partCostQueryStore'),
            id: 'mockExampleGrid',
            margin: '10 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '98%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },


            columns: [{xtype: 'rownumberer'},

                    {text: '料号', dataIndex: 'data1', width: 100, editor: 'textfield',},
                    {text: '名称', dataIndex: 'data2', width: 100, editor: 'textfield'},
                    {text: '物料描述', dataIndex: 'data3', width: 100, editor: 'textfield',},
                    {text: '单位', dataIndex: 'data4', width: 100,editor: 'textfield'},
                    {text: '数量', dataIndex: 'data5', width: 100,editor: 'textfield'},
                    {text: '源', dataIndex: 'data6', width: 100,editor: 'textfield'},
                    {text: '采购单价', dataIndex: 'data7', width: 100,editor: 'textfield'},
                    {text: '加工费用', dataIndex: 'data8', width: 100,editor: 'textfield'},
                    {text: '委外费用', dataIndex: 'data9', width: 100,editor: 'textfield'},

            ]
        });



        var mockExampleForm = {
            title:'查询参数',
            xtype: 'fieldset',
            id: 'mainForm',
            width: '98%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '15 0 10 10',
                items: [{
                    margin: '0 20 0 0',
                    fieldLabel: '成品料号',
                    labelWidth: 70,
                    name: 'partNumber',
                    allowBlank: false,
                    width: 200,
                }, {
                    margin: '0 20 0 0',
                    fieldLabel: '产品型号',
                    labelWidth: 70,
                    name: 'productModel',
                    width: 200,
                },{
                    margin: '0 20 0 0',
                    fieldLabel: '项目状态',
                    labelWidth: 70,
                    name: 'phone',
                    width: 200,
                }]
                },{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'button',
                margin: '10 0 0 10',
                items: [{
                    margin: '0 20 10 0',
                    text: '查询',
                    name: 'phone',
                    width: 50,
                },{
                    margin: '0 20 10 0',
                    text: '导出',
                    name: 'phone',
                    width: 50,
                }]
            }]
        };

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm, mockExampleGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('partCostQueryStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('partCostQueryStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('partCostQueryStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
        }
    }
});

