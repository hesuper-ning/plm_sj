Ext.define('PLM.view.PartCostQueryPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.PartCostQueryPanel',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'partCostQueryPanel',
    initComponent: function () {
        var me = this;

        //================== 开始  partCostQueryGrid ======================
        Ext.define('partCostQueryModel', {
            extend: "Ext.data.TreeModel",
            fields: [
                'partNumber','partName','unit','amount','factory','price'
                ,'zPrice','cPrice','mPrice','storage'
            ],
            idProperty: 'a'
        });
        var partCostQueryStore = Ext.create("Ext.data.TreeStore", {
            model: "partCostQueryModel",
            id:'partCostQueryStore',
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/projectBudget/getPartCostDetails',
                reader: {
                    type:'json',
                    rootProperty: 'items',
                    // totalProperty: 'totalCount',
                    // idProperty: 'id',
                    messageProperty: 'msg'
                }
            },
            autoLoad: false,
            root: {
                expanded: true
            },
            //倒序排序
            sorters:[{
                property:'partNumber',
                direction:'desc'
            }]

        });
        var partCostQueryGrid = Ext.create('Ext.tree.TreePanel', {
            store: partCostQueryStore,
            id: 'partCostQueryGrid',
            autoWidth: true,
            autoScroll: true,
            rootVisible: false,
            width: '100%',
            height: 500,
            viewConfig: {enableTextSelection: true, forceFit: false},
            columns: [
                {text: '物料代码', dataIndex: 'partNumber', flex:1,xtype: 'treecolumn'},
                {text: '物料描述', dataIndex: 'partName', flex:1},
                {text: '计量单位', dataIndex: 'unit', flex:1},
                //{text: '数量', dataIndex: 'amount',flex:1},
                {text: '工厂', dataIndex: 'factory',flex:1},
                {text: '用量', dataIndex: 'amount',flex:1},
                {text: 'BOM材料实际成本', dataIndex: 'price', flex:1},
                {text: 'BOM材料标准成本', dataIndex: 'zPrice', flex:1},
                {text: 'BOM材料采购价格', dataIndex: 'cPrice', flex:1},
                {text: 'BOM制造成本', dataIndex: 'mPrice', flex:1},
                {text: '可用库存', dataIndex: 'storage', flex:1},
                {text: '', dataIndex: '', flex:0.2}
            ],
            listeners: {

            },
        });





        var queryParameter = {
            title:'查询参数',
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '10 0 10 10',
                items: [{
                    margin: '0 20 0 0',
                    fieldLabel: '<font color="red">*</font><font color="blue">物料代码</font>',
                    labelWidth: 70,
                    id:'endPartNumber',
                    name: 'endPartNumber',
                    allowBlank: false,
                    width: 300,
                },{
                    xtype:'combo',
                    margin: '0 20 0 0',
                    fieldLabel: '<font color="red">*</font><font color="blue">BOM状态</font>',
                    store:[["0","样机BOM"],["1","量产BOM"],["2","试产BOM"]],
                    editable:false,
                    labelWidth: 70,
                    name: 'bomUsage',
                    id: 'bomUsage',
                    width: 200,
                }/*,{
                    margin: '0 20 0 0',
                    fieldLabel: '项目状态',
                    labelWidth: 70,
                    name: 'phone',
                    width: 200,
                }*/]
            },{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'button',
                margin: '20 0 0 10',
                items: [{
                    margin: '0 20 10 0',
                    text: '查询',
                    name: 'search',
                    width: 100,
                    handler:function () {
                        doSearch();
                    }
                },{
                    margin: '0 20 10 0',
                    text: '导出查询记录',
                    name: 'exportSearchRecord',
                    hidden:!allowExport,
                    width: 100,
                    handler:function () {
                        window.location.href="/Windchill/ptc1/projectBudget/exportPartCostQueryRecord";
                    }
                },{
                    margin: '0 20 10 0',
                    text: '申请授权',
                    name: 'createAuthDoc',
                    width: 100,
                    handler:function () {
                        var url = "/Windchill/ptc1/document/create?AjaxEnabled=row" +
                            "&wizardActionClass=ext.plm.processor.doc.CtDocCreateProcessor&wizardActionMethod=execute" +
                            "&actionName=create&portlet=poppedup&context=comp%24folderbrowser_table%24" +
                            wtLibraryOid +
                            "&docType=com.fhsj.Doc_fhsj|com.fhsj.Doc_cw|com.fhsj.Doc_cbcxsqsq";
                        window.parent.window.open (url, 'newwindow', 'height='+(window.outerHeight-100)+', width='+(window.outerWidth/2)+', top=0, left='+(window.outerWidth/2)+', toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no');
                    }
                }]
            }]
        };



/////////////////////////Main Panel items//////////////////////////////////
        this.items = [queryParameter, partCostQueryGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {

        }
    }
});

//查询物料成本
function doSearch(){
    var endPartNumber = Ext.getCmp('endPartNumber').getValue();
    var bomUsage = Ext.getCmp('bomUsage').getValue();
    if(!endPartNumber||!bomUsage){
        alert("请输入成品料号和BOM状态！");
        return;
    }
    if(!endPartNumber.startsWith("2")&&!endPartNumber.startsWith("3")){
        alert("只能查询2或3开头的物料!");
        return;
    }
    Ext.getStore('partCostQueryStore').load({
        params:{
            endPartNumber:endPartNumber,
            bomUsage:bomUsage
        },
        callback: function(records, operation, success) {
            if(!success){
                alert(operation.getError());
            }else{

            }
        }
    });
}



