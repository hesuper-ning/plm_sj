﻿<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page import="ext.plm.util.CtACLUtil" %>
<%@ page import="wt.session.SessionHelper" %>
<%@ page import="ext.plm.util.CtProjectUtil" %>
<%@ page import="ext.plm.projectBudget.CtProjectBudgetLogic" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String currentUserName = CtUserUtil.getCurrentUserDisplayName();
        boolean allowExport = false;
        //"管理员"组下的用户有权限导出记录
        if(CtUserUtil.isInGroup(SessionHelper.getPrincipal(),"管理员")){
            allowExport = true;
        }


        //A14_临时权限申请 存储库oid
        String wtLibraryOid = CtProjectBudgetLogic.getWTLibraryOid();

    %>
    <script>

        var currentUserName = "<%=currentUserName%>";

        var wtLibraryOid = "<%=wtLibraryOid%>";

        var allowExport = false;
        <%if(allowExport){ %>
            allowExport = true;
        <%}%>
		console.log("当前用户>>>>>>>>>"+currentUserName+"导出权限>>>>>>"+allowExport);
    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <style type="text/css">
        .x-tree-icon {
            background-image: url(/Windchill/netmarkets/images/part.gif);
        }
    </style>
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="js/ctPartCostQuery.js?_dc=<%System.currentTimeMillis();%>"></script>
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'PartCostQueryPanel'
            }]
        });
    });
</script>
</body>
</html>