<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>


<iframe id="ctHumanResourceIframe" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"
        src="netmarkets/jsp/ext/plm/replacePart/ctMaterialSubstitutionReportPlugin.jsp?" style="width:98%;height:900px" ></iframe>

<script type="text/javascript">
    var iframe = document.getElementById("ctExportPartInfoIframe");
    iframe.style.height = window.innerHeight*80/100 + 'px';
</script>
