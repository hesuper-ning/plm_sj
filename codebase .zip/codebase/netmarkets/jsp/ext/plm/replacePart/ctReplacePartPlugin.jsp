<%@page import="wt.fc.ReferenceFactory"%>
<%@page import= "wt.projmgmt.admin.Project2"%>
<%--<%@page import= "ext.angelProject.util.PntProjectUtil"%>--%>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.workflow.engine.WfActivity" %>
<%@ page import="wt.workflow.engine.WfProcess" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.part.WTPart" %>
<%@ page import="ext.plm.util.IBAUtil" %>
<%@ page language="java" contentType="text/html; charset=utf-8"
         pageEncoding="utf-8"%>

<%
    String oid = request.getParameter("oid");//此oid有可能为workItem oid，也可能为WTDocument oid
    wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
    Object obj = rf.getReference(oid).getObject();

    String partNumber = "";
    boolean isSubstitutionGroupMaterial = true;
    boolean isAlternativeMaterials = true;
    if(obj instanceof WTPart) {
        WTPart part = (WTPart) obj;
        partNumber = part.getNumber();
        IBAUtil ibaUtilReplacePart = new IBAUtil(part);
        String replacePart = ibaUtilReplacePart.getIBAValue("ct_basicmaterial");
        if("是".equals(replacePart)){
            isAlternativeMaterials = false;
        }else {
            isSubstitutionGroupMaterial = false;
        }
    }
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <script type="text/javascript">

        //部件编码
        var partNumber  = "<%=partNumber%>";
        //基础物料
        var isAlternativeMaterials  = <%=isAlternativeMaterials%>;
        //集群物料
        var isSubstitutionGroupMaterial  = <%=isSubstitutionGroupMaterial%>;

    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <%--<script type="text/javascript" src="js/ctEc.js?_dc=<%=timestamp%>"></script>--%>
    <script type="text/javascript" src="js/ctReplacePart.js?_dc=<%="timestamp"%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
</head>

<body>


</body>
</html>




