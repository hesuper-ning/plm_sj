Ext.define('PLM.view.ProblemShareInfo', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ProblemShareInfo',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'ProblemShareInfo',
    initComponent: function () {
        Ext.define('alternativeMaterialListModel', {
            extend: 'Ext.data.Model',
            fields: [
                'substitutionGroupMaterial', 'state', 'describe', 'alternativeMaterials', 'stateT','describeT','mainMaterial','association'
            ],
            idProperty: 'alternativeMaterialListModel'
        });

        // 查询 Store
        var alternativeMaterialListStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'alternativeMaterialListModel',
            id:'alternativeMaterialListStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/replacePart/materialSubstitutionReport',
                method:'GET',
                timeout: 600000,
                reader:{
                    type:'json',
                    root: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'alternativeMaterialListModel',
                    messageProperty: 'massage'
                }
            }),
            autoLoad:true
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var alternativeMaterialListGrid = Ext.create('Ext.grid.Panel', {
            plugins: cellEditing,
            store:alternativeMaterialListStore,
            autoWidth : true,
            autoScroll:true,
            height:400,
            id:'alternativeMaterialListGrid',
            viewConfig:{enableTextSelection:true, forceFit : false},
            columns: [
                { text: '集群物料编码',flex: 1, dataIndex: 'substitutionGroupMaterial', width: 50, align: 'center',menuDisabled: true},
                {text: '集群物料供应商',  align: 'center', flex: 1,dataIndex: 'colonyPartSupplier', menuDisabled:true, editor:false},
                { text: '状态',flex: 1,  dataIndex: 'state' , width:100, align: 'center',menuDisabled: true},
                { text: '物料描述',flex: 1,  dataIndex: 'describe', width:100, align: 'center',menuDisabled: true},
                { text: '基础物料编码',flex: 1,  dataIndex: 'alternativeMaterials',width:100, align: 'center',menuDisabled: true},
                { text: '基础物料供应商', align: 'center', flex: 1, dataIndex: 'replacePartSupplier', menuDisabled:true, editor:false},
                { text: '状态',flex: 1,  dataIndex: 'stateT' , width:100, align: 'center',menuDisabled: true},
                { text: '物料描述',flex: 1,  dataIndex: 'describeT' , width:100, align: 'center',menuDisabled: true},
                { text: '是否主物料',flex: 1,  dataIndex: 'mainMaterial' , width:100, align: 'center',menuDisabled: true},
                { text: '类型',flex: 1,  dataIndex: 'association' , width:100, align: 'center',menuDisabled: true}
            ]
        });





//========================Items Area======================//

        this.items=[
            {
                xtype: 'fieldset',
                margin: '5 3 10 3',
                title: '<font style="font-size:12px">物料替代报表</font>',
                collapsible: true,
                defaults: {
                    labelWidth: 100,
                    border: false,
                    anchor: '99%',
                    layout: {
                        type: 'hbox'
                    }
                },
                items: [
                    {
                    xtype: 'panel',
                    defaults: {margin: '5 20 20 0', labelWidth: 70},
                    items: [
                        {
                            xtype: 'textfield',
                            fieldLabel: '物料编码',
                            name: 'replacePartNumber',
                            id: 'replacePartNumber',
                            width: 250,
                            enableKeyEvents: true
                        },
                        {
                            xtype: 'combobox',
                            fieldLabel: '查询类型',
                            name: 'type',
                            id: 'type',
                            width: 250,
                            enableKeyEvents: true,
                            store: ['当前有效', '历史记录', '曾经存在'], // 下拉框的选项数据
                            queryMode: 'local', // 查询模式
                            editable: false // 设置为不可编辑
                        },
                        {
                            xtype:'button',
                            // margin:'10 0 10 0',
                            width:70,
                            text: '查询',
                            scope:this,
                            iconCls: 'icon icon-search',
                            handler: function() {
                                doSearch();
                            }
                        },
                        // {
                        //     xtype: 'button',
                        //     text: '导出为Excel文件',
                        //     id:'materialSubstitutionReportExport',
                        //     iconCls: 'icon icon-exportExcel',
                        //     handler: function () {
                        //         window.location.href = '/Windchill/ptc1/replacePart/materialSubstitutionReportExport?replacePartNumber=' + Ext.getCmp('replacePartNumber').getValue()+'&type='+Ext.getCmp('type').getValue();
                        //     },
                        //     scope: this
                        // }
                        {
                            xtype: 'button',
                            text: '导出为Excel文件',
                            id: 'materialSubstitutionReportExport',
                            iconCls: 'icon icon-exportExcel',
                            handler: function () {
                                //增加遮罩
                                var loadMarsk = new Ext.LoadMask({
                                    msg:'正在收集数据，请稍候......',
                                    target: Ext.getCmp('alternativeMaterialListGrid'),
                                    removeMask: true // 完成后移除
                                });
                                loadMarsk.show();

                                // 获取参数值
                                var replacePartNumber = Ext.getCmp('replacePartNumber').getValue();
                                var type = Ext.getCmp('type').getValue();

                                // 构建请求URL
                                var url = '/Windchill/ptc1/replacePart/materialSubstitutionReportExport?replacePartNumber=' + replacePartNumber + '&type=' + type;

                                // 发送请求
                                Ext.Ajax.request({
                                    url: url,
                                    method: 'GET',
                                    timeout: 99999999,
                                    success: function (response, opts) {
                                        // 请求成功后移除遮罩层
                                        loadMarsk.hide();

                                        // 处理响应（例如，下载文件）
                                        window.location.href = url;
                                    },
                                    failure: function (response, opts) {
                                        // 请求失败后移除遮罩层
                                        loadMarsk.hide();

                                        // 处理失败情况
                                        alert('错误', '导出失败，请重试。');
                                    }
                                });
                            },
                            scope: this
                        }
                    ]
                }]
            },


            alternativeMaterialListGrid];

        this.callParent();

    },//~End of initComponent
});

/**
 * 按查询参数查询
 */
function doSearch() {
    var vvv= Ext.getCmp('type').getValue();
    if(Ext.getCmp('type').getValue()==null){
        alert("必须选择查询类型！")
        return;
    }
    Ext.getStore('alternativeMaterialListStore').load({
        params: {
            // data: Ext.encode(data)
            replacePartNumber: Ext.getCmp('replacePartNumber').getValue(),
            type: Ext.getCmp('type').getValue(),
        },
        callback: function (records, operation, success) {
            if (!success) {
                var responseText = operation.getResponse().responseText;
                var responseObject = Ext.decode(responseText);
                alert(responseObject.message);
                // alert('查询信息失败，请联系管理员！');
            }
        }
    });
}
