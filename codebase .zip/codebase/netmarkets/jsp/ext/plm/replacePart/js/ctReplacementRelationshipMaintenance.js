Ext.define('PLM.view.ReplacementRelationshipMaintenance', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ReplacementRelationshipMaintenance',
    border: false,
    autoScroll: true,
    autoWidth: true,
    height:830,
    collapsible: false,
    id: 'ReplacementRelationshipMaintenance',
    initComponent: function () {

        // 相关物料确认流程
        var titt = Ext.create('Ext.container.Container', {
            layout: 'hbox', // 水平布局
            height:20,
            margin: '10 0 10 10',
            style: {
                border: '0'  // 设置容器的边框样式为零
            },
            items: [{
                xtype: 'displayfield', // 查询条件输入框
                readOnly: true,
                fieldLabel: '相关物料确认流程',
                labelWidth: 120,
                id: 'queryField1'
            }]
        });
        //
        // var queryField = Ext.getCmp('queryField1'); // 获取文本框实例，'queryField1' 为文本框的 ID
        // queryField.setValue('<a href="https://www.baidu.com" target="_blank">点击这里</a>'); // 设置文本框的值


        // 获取后端数据，并赋值给文本链接框
        Ext.Ajax.request({
            url: '/Windchill/ptc1/replacePart/searchReplacePartSingleFieldBo?docNumber='+docNumber,
            method: 'GET',
            success: function(response) {
                var data = Ext.JSON.decode(response.responseText).data;
                var docLink = '';
                if(data) {
                    var sampleConfirmationNumber = data.sampleConfirmationNumber;
                    var sampleConfirmationBranchId = data.sampleConfirmationBranchId;

                    if (sampleConfirmationNumber && sampleConfirmationBranchId) {
                        docLink = "<a href='" + urlPathPrefix + sampleConfirmationBranchId + "' target='_blank' >"
                            + sampleConfirmationNumber + "</a>";
                    }
                }


                var queryField = Ext.getCmp('queryField1'); // 获取文本框实例，'queryField1' 为文本框的 ID
                queryField.setValue(docLink); // 设置文本框的值
            },
            failure: function(response) {

            }
        });





        var passOrNot = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'passOrNot',
            id: 'passOrNot',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '是' },
                    { fullName: '否' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName'
        });

        Ext.define('alternativeGroupMaterialTableModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id',
                'serialNumber',
                "substitutionGroupMaterial",
                'state',
                'describe',
                'systemVersion',
                'internalVersion',
                'passOrNot'
            ],
            idProperty: 'alternativeGroupMaterialTableModel'
        });

        var alternativeGroupMaterialTableColumns = [
            {text: '序号', align: 'center', flex: 1,dataIndex: 'serialNumber', menuDisabled:true, editor:false},
            {text: '集群物料', align: 'center', flex: 1, dataIndex: 'substitutionGroupMaterial', menuDisabled:true, editor:disableNode(start_node)?true:'',
                style: disableNode(start_node)?'color: blue;':'',

                renderer: function(value,metaData,record,row,col,store){
                    return record.get('partURL');
                }

            },
            {text: '状态', align: 'center', flex: 1, dataIndex: 'state', menuDisabled:true, editor:false},
            {text: '描述', align: 'center', flex: 1, dataIndex: 'describe', menuDisabled:true, editor:false},
            {text: '系统版本',  align: 'center', flex: 1,dataIndex: 'systemVersion', menuDisabled:true, editor:false},
            {text: '供应商',  align: 'center', flex: 1,dataIndex: 'colonyPartSupplier', menuDisabled:true, editor:false},
            {text: '内部版本', align: 'center', flex: 1, dataIndex: 'internalVersion', menuDisabled:true, editor:false},
            // {text: generateHeaderTextWithRedStar('试用是否通过'), align: 'center',  flex: 1,dataIndex: 'passOrNot', menuDisabled:true, editor:disableNode(trialResults_node)?passOrNot:'',
            //     style: disableNode(trialResults_node)?'color: blue;':''
            // }
        ];






        var alternativeGroupMaterialTableStore = Ext.create('Ext.data.Store', {
            model: 'alternativeGroupMaterialTableModel',
            id: 'alternativeGroupMaterialTableStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/replacePart/searchAlternativeGroupMaterialTable?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'alternativeGroupMaterialTableModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,

            listeners: {
                load: function() {
                    substitutionRelationshipTableStore.load();
                }
            }

        });

        var alternativeGroupMaterialTableGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var alternativeGroupMaterialTableGrid = Ext.create('Ext.grid.Panel', {
            plugins: [alternativeGroupMaterialTableGridEditing],
            store: alternativeGroupMaterialTableStore,
            columns: alternativeGroupMaterialTableColumns,
            id:'alternativeGroupMaterialTableGrid',
            title: '集群物料表',
            columnLines: true,
            height:200,
            width:'100%',
            multiSelect : false,
            autoScroll: true,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true,forceFit: false },
            // viewConfig:{enableTextSelection:true,forceFit: false},
            // viewConfig: { forceFit: false },
            tbar: [
                {
                    xtype: 'button',
                    text: '新增集群物料行',
                    //||disableNode(trialResults_node)
                    hidden: disableNode(start_node)?false:true,
                    id: 'alternativeGroupMaterialTableInsert',
                    iconCls: 'icon icon-add',
                    handler: function () {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/replacePart/insertAlternativeGroupMaterialTable?docNumber='+docNumber,
                            method:'POST',
                            headers: {'Content-Type':'application/json'},
                            // params: JSON.stringify(data),
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success') {
                                    // Ext.getCmp('alternativeGroupMaterialTableGrid').getStore().insert(n, p);
                                    alternativeGroupMaterialTableStore.load();
                                }else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除集群物料行',
                    //||disableNode(trialResults_node)
                    hidden: disableNode(start_node)?false:true,
                    id: 'alternativeGroupMaterialTableDelete',
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        var recordList = alternativeGroupMaterialTableGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for(var i = 0; i<recordList.length; i++){
                                updateArr.push(recordList[i].data.id)
                            };
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/replacePart/deleteAlternativeGroupMaterialTable?docNumber='+docNumber,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        // alternativeGroupMaterialTableStore.remove(recordList);
                                        alternativeGroupMaterialTableStore.load();
                                        var obj = Ext.decode(response.responseText);
                                        substitutionRelationshipTableStore.load();
                                        alert("成功删除" + obj.data + "条信息！")
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败，请检查网络！!');
                                }
                            });
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }
            ]
        });

        alternativeGroupMaterialTableGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let id = record.get('id');
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.message=='success') {
                    var obj = Ext.decode(response.responseText);
                    e.record.commit();
                    substitutionRelationshipTableStore.load();
                    alternativeGroupMaterialTableStore.load();
                }else {
                    alternativeGroupMaterialTableStore.load();
                    alert(obj.message)
                }
            };
            saveSingleField01("alternativeGroupMaterialTable", id, field, value, callbackFn);




            // if (e.originalValue === e.value) {
            //     return;
            // }
            // var idx = e.rowIdx
            // var record = alternativeGroupMaterialTableGrid.getStore().getAt(idx);
            // Ext.Ajax.request({
            //     url: '/Windchill/ptc1/replacePart/saveAlternativeGroupMaterialTable',
            //     method:'POST',
            //     headers: {'Content-Type':'application/json'},
            //     params: JSON.stringify(record.data),
            //     success: function (response, opts) {
            //         var obj = Ext.decode(response.responseText);
            //         if(obj.message=='success') {
            //             var obj = Ext.decode(response.responseText);
            //             e.record.commit();
            //             //修改替代组物料后在后端同时修改替代关系表，修改完成后重新加载数据
            //             substitutionRelationshipTableStore.load();
            //             alternativeGroupMaterialTableStore.load();
            //         }else {
            //             alternativeGroupMaterialTableStore.load();
            //             alert(obj.message);
            //         }
            //     },
            //     failure: function (response, opts) {
            //         alternativeGroupMaterialTableStore.load();
            //         alert('错误：修改信息失败，请检查网络！!');
            //     }
            // });
        });



        var storeNumberCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'storeNumberCom',
            id: 'storeNumberCom',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                ],
                fields: ['serialNumber']
            },
            valueField: 'fullName',
            displayField: 'fullName'
        });

        var alternativeMaterialsCom = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'alternativeMaterialsCom',
            id: 'alternativeMaterialsCom',
            multiSelect: false,
            anyMatch: true,
            editable: true,
            store: {
                data: [
                ],
                fields: ['alternativeMaterials']
            },
            valueField: 'fullName',
            displayField: 'fullName'
        });


        var mainMaterialEditor = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'mainMaterialEditor',
            id: 'mainMaterialEditor',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '是' },
                    { fullName: '否' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName'
        });


        var relatedOperations = new Ext.form.ComboBox({
            xtype: 'combo',
            name: 'relatedOperations',
            id: 'relatedOperations',
            multiSelect: false,
            anyMatch: true,
            editable: false,
            store: {
                data: [
                    { fullName: '移除替代关系' },
                    { fullName: '新增替代关系' }
                ],
                fields: ['fullName']
            },
            valueField: 'fullName',
            displayField: 'fullName',
            tpl: getXTemplate('fullName')
        });



        Ext.define('substitutionRelationshipTableModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id',
                'relatedOperations',
                'existingSubstitutionRelationship',
                'serialNumber',
                "substitutionGroupMaterial",
                'state',
                'describe',
                'systemVersion',
                'internalVersion',
                'alternativeMaterials',
                'stateT',
                'describeT',
                'systemVersionT',
                'internalVersionT',
                'mainMaterial'
            ],
            idProperty: 'substitutionRelationshipTableModel'
        });

        var substitutionRelationshipTableColumns = [
            {text: '相关操作', align: 'center', flex: 1, dataIndex: 'relatedOperations', menuDisabled:true, editor:disableNode(start_node)?relatedOperations:'',
                style: disableNode(start_node)?'color: blue;':''
            },
            {text: '是否是现存替代关系', align: 'center', flex: 1, dataIndex: 'substitutionRelationship', menuDisabled:true, editor:false},
            {text: generateHeaderTextWithRedStar('序号'), align: 'center', flex: 1, dataIndex: 'serialNumber', menuDisabled:true, editor:disableNode(start_node)?storeNumberCom:'',
                style: disableNode(start_node)?'color: blue;':''
            },
            {text: '集群物料', align: 'center', flex: 1, dataIndex: 'substitutionGroupMaterial', menuDisabled:true, editor:false,
                renderer: function(value,metaData,record,row,col,store){
                    return record.get('substitutionGroupMaterialURL');
                }
            },
            {text: '状态', align: 'center', flex: 1, dataIndex: 'state', menuDisabled:true, editor:false},
            {text: '描述', align: 'center', flex: 1, dataIndex: 'describe', menuDisabled:true, editor:false},
            {text: '系统版本', align: 'center', flex: 1, dataIndex: 'systemVersion', menuDisabled:true, editor:false},
            {text: '内部版本', align: 'center', flex: 1, dataIndex: 'internalVersion', menuDisabled:true, editor:false},
            {text: generateHeaderTextWithRedStar('基础物料'), align: 'center', flex: 1, dataIndex: 'alternativeMaterials', menuDisabled:true, editor:disableNode(start_node)?alternativeMaterialsCom:'',
                style: disableNode(start_node)?'color: blue;':'',
                renderer: function(value,metaData,record,row,col,store){
                    return record.get('alternativeMaterialsURL');
                }
            },
            {text: '状态', align: 'center', flex: 1, dataIndex: 'stateT', menuDisabled:true, editor:false},
            {text: '描述', align: 'center', flex: 1, dataIndex: 'describeT', menuDisabled:true, editor:false},
            {text: '系统版本', align: 'center', flex: 1, dataIndex: 'systemVersionT', menuDisabled:true, editor:false},
            {text: '供应商', align: 'center', flex: 1, dataIndex: 'replacePartSupplier', menuDisabled:true, editor:false},
            {text: '内部版本', align: 'center', flex: 1, dataIndex: 'internalVersionT', menuDisabled:true, editor:false},
            {text: '是否主料', align: 'center', flex: 1, dataIndex: 'mainMaterial', menuDisabled:true, editor:disableNode(start_node)?mainMaterialEditor:'',
                style: disableNode(start_node)?'color: blue;':''
            },
        ];

        var substitutionRelationshipTableGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var substitutionRelationshipTableStore = Ext.create('Ext.data.Store', {
            model: 'substitutionRelationshipTableModel',
            id: 'substitutionRelationshipTableStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/replacePart/searchSubstitutionRelationshipTable?docNumber='+docNumber,
                method:'GET',
                timeout: 600000,
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'substitutionRelationshipTableModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false,
        });



        var substitutionRelationshipTableGrid = Ext.create('Ext.grid.Panel', {
            plugins: [substitutionRelationshipTableGridEditing],
            store: substitutionRelationshipTableStore,
            columns: substitutionRelationshipTableColumns,
            id:'substitutionRelationshipTableGrid',
            title: '替代关系表',
            columnLines: true,
            height:400,
            width:'100%',
            multiSelect : false,
            autoScroll: true,
            selType: 'checkboxmodel',
            viewConfig: { enableTextSelection:true,forceFit: false },
            // viewConfig:{enableTextSelection:true},
            tbar: [
                {
                    xtype: 'button',
                    text: '增加行',
                    id: 'substitutionRelationshipTableInsert',
                    //||disableNode(trialResults_node)
                    hidden: disableNode(start_node)?false:true,
                    iconCls: 'icon icon-add',
                    handler: function () {
                        var n = substitutionRelationshipTableGrid.getStore().getCount();
                        var p = {
                        }
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/replacePart/insertSubstitutionRelationshipTable?docNumber='+docNumber,
                            method:'POST',
                            headers: {'Content-Type':'application/json'},
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success') {
                                    Ext.getCmp('substitutionRelationshipTableGrid').getStore().insert(n, p);
                                    substitutionRelationshipTableStore.load();
                                }else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！!');
                            }
                        });
                    }
                },
                {
                    xtype: 'button',
                    text: '删除行',
                    id: 'substitutionRelationshipTableDelete',
                    //||disableNode(trialResults_node)
                    hidden: disableNode(start_node)?false:true,
                    iconCls: 'icon icon-delete',
                    handler: function () {
                        var recordList = substitutionRelationshipTableGrid.getSelectionModel().getSelection();
                        if (recordList.length != 0) {
                            let updateArr = new Array();
                            for(var i = 0; i<recordList.length; i++){
                                updateArr.push(recordList[i].data.id)
                            };
                            Ext.Ajax.request({
                                url: '/Windchill/ptc1/replacePart/deleteSubstitutionRelationshipTable?docNumber='+docNumber,
                                method:'POST',
                                headers: {'Content-Type':'application/json'},
                                params: JSON.stringify(updateArr),
                                success: function (response, opts) {
                                    var obj = Ext.decode(response.responseText);
                                    if(obj.message=='success') {
                                        substitutionRelationshipTableStore.load();
                                        // substitutionRelationshipTableStore.remove(recordList);
                                        alert("成功删除"+obj.data+"条信息！");
                                    }else {
                                        alert(obj.message);
                                    }
                                },
                                failure: function (response, opts) {
                                    alert('错误：删除信息失败，请检查网络！!');
                                }
                            });
                            // substitutionRelationshipTableStore.load();
                        } else {
                            alert("请选择一条数据")
                        }
                    }
                }
            ]
        });



        substitutionRelationshipTableGrid.on('edit',function(editor,e){
            if (e.originalValue === e.value) {
                return;
            }
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let id = record.get('id');
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.message=='success') {
                    var obj = Ext.decode(response.responseText);
                    e.record.commit();
                }else {
                    // alert(obj.message)
                }
                substitutionRelationshipTableStore.load();
            };
            saveSingleField02("substitutionRelationshipTable", id, field, value, callbackFn);







            // if (e.originalValue === e.value) {
            //     return;
            // }
            // var idx = e.rowIdx
            // var record = substitutionRelationshipTableGrid.getStore().getAt(idx);
            // Ext.Ajax.request({
            //     url: '/Windchill/ptc1/replacePart/saveSubstitutionRelationshipTable',
            //     method:'POST',
            //     headers: {'Content-Type':'application/json'},
            //     params: JSON.stringify(record.data),
            //     success: function (response, opts) {
            //         var obj = Ext.decode(response.responseText);
            //         if(obj.message=='success') {
            //             var obj = Ext.decode(response.responseText);
            //             e.record.commit();
            //             // //修改替代组物料后在后端同时修改试用记录，修改完成后重新加载数据
            //             // substitutionRelationshipTableStore.load();
            //             substitutionRelationshipTableStore.load();
            //             trialRecordStore.load();
            //         }else {
            //             alert(obj.message)
            //         }
            //     },
            //     failure: function (response, opts) {
            //         alert('错误：删除信息失败，请检查网络！!');
            //     }
            // });

        });

        // 监听Grid的itemclick事件，点击行时触发,查找替代组物料表的序号
        substitutionRelationshipTableGrid.on('rowclick', function(view, record, item, index, e) {

            var clickedData = record.getData(); // 获取点击的行数据
            var substitutionRelationship = clickedData.substitutionRelationship;
            var newOptions = [];
            if (substitutionRelationship=="Y") {
                // 根据点击的行数据设置新的下拉选项
                newOptions = [
                    { fullName: '' },
                    { fullName: '移除替代关系' }
                ];
            } else {
                // 根据其他条件设置不同的下拉选项
                newOptions = [
                    // { fullName: '移除替代关系' },
                    { fullName: '' },
                    { fullName: '新增替代关系' }
                ];
            }
            relatedOperations.getStore().setData(newOptions);

            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引

            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName=='serialNumber'){
                    //刷新序号下拉值
                    storeNumberCom.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/replacePart/searchSerialNumberList?docNumber='+docNumber,
                        method:'POST',
                        headers: {'Content-Type':'application/json'},
                        // params: JSON.stringify(record.data),
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var storeNumberList = Ext.decode(response.responseText).data;
                                storeNumberList.map(function(item) {
                                    storeNumberCom.getStore().add({ fullName: item });
                                })
                                // var store = Ext.create('Ext.data.Store', {
                                //     fields: ['serialNumber'], // 定义数据字段
                                //     data: storeNumberList.map(function(item) {
                                //         storeNumberCom.getStore().add({ fullName: item });
                                //     })
                                // });
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }


            // //样品确认流程中顺利完成物料确认的物料的基础物料清单
            // alternativeMaterialsCom.getStore().removeAll();
            // Ext.Ajax.request({
            //     url: '/Windchill/ptc1/replacePart/searchSerialNumberList?docNumber='+docNumber,
            //     method:'POST',
            //     headers: {'Content-Type':'application/json'},
            //     // params: JSON.stringify(record.data),
            //     success: function (response, opts) {
            //         var obj = Ext.decode(response.responseText);
            //         if(obj.message=='success') {
            //             var alternativeMaterialsList = Ext.decode(response.responseText).data;
            //             var store = Ext.create('Ext.data.Store', {
            //                 fields: ['alternativeMaterials'], // 定义数据字段
            //                 data: alternativeMaterialsList.map(function(item) {
            //                     alternativeMaterialsCom.getStore().add({ fullName: item });
            //                 })
            //             });
            //         }else {
            //             alert(obj.message)
            //         }
            //     },
            //     failure: function (response, opts) {
            //         alert('错误：删除信息失败，请检查网络！!');
            //     }
            // });
        });

        substitutionRelationshipTableGrid.on('beforeedit', function (editor, context) {
            var record = context.record;
            var substitutionRelationship = record.get('substitutionRelationship');

            // 判断点击的是哪一列
            var columnName = context.column.dataIndex;

            if (substitutionRelationship === 'Y' && columnName !== 'relatedOperations' && columnName !== 'mainMaterial') {
                return false; // 禁止编辑指定列
            }

            return true; // 允许编辑操作
            // var record = context.record; // 获取编辑的行数据
            // var substitutionRelationship = record.get('substitutionRelationship'); // 获取特定字段的值
            // // var serialNumber = record.get('serialNumber');
            // // if (serialNumber === 'T1') {
            // //     return false; // 返回 false 来禁止编辑操作
            // // }
            // // 根据特定字段的值判断是否禁止编辑
            // if (substitutionRelationship === 'Y') {
            //     return false; // 返回 false 来禁止编辑操作
            // }
            //
            // return true; // 允许编辑操作
        });





        Ext.define('trialRecordModel', {
            extend: 'Ext.data.Model',
            fields: [
                'docNumber',
                'semiProductNumber',
                'semiProductDesc',
                'productNumber',
                "productDesc",
                'partNumber',
                'partDesc',
                'partVersion',
                'supplierNumber',
                'numberOfUses',
                'trialQuantity',
                'trialStatus',
                'version'
            ],
            idProperty: 'trialRecordModel'
        });

        var trialRecordColumns = [
            {text: '试用流程单号', align: 'center', flex: 1, dataIndex: 'docNumber', menuDisabled:true, editor:relatedOperations},
            {text: '试用物料编码', align: 'center', flex: 1, dataIndex: 'partNumber', menuDisabled:true, editor:false},
            {text: '试用物料描述', align: 'center', flex: 1, dataIndex: 'partDesc', menuDisabled:true, editor:storeNumberCom},
            {text: '系统版本', align: 'center', flex: 1, dataIndex: 'version', menuDisabled:true, editor:false},
            {text: '内部版本', align: 'center', flex: 1, dataIndex: 'partVersion', menuDisabled:true, editor:false},
            {text: '供应商名称', align: 'center', flex: 1, dataIndex: 'supplierNumber', menuDisabled:true, editor:false},
            {text: '半成品编码', align: 'center', flex: 1, dataIndex: 'semiProductNumber', menuDisabled:true, editor:false},
            {text: '半成品描述', align: 'center', flex: 1, dataIndex: 'semiProductDesc', menuDisabled:true, editor:false},
            {text: '成品编码', align: 'center', flex: 1, dataIndex: 'productNumber', menuDisabled:true, editor:true},
            {text: '成品物料描述', align: 'center', flex: 1, dataIndex: 'productDesc', menuDisabled:true, editor:false},
            {text: '试用次数', align: 'center', flex: 1, dataIndex: 'numberOfUses', menuDisabled:true, editor:false},
            {text: '试用数量', align: 'center', flex: 1, dataIndex: 'trialQuantity', menuDisabled:true, editor:false},
            {text: '试用状态', align: 'center', flex: 1, dataIndex: 'trialStatus', menuDisabled:true, editor:false}
        ];

        var trialRecordStore = Ext.create('Ext.data.Store', {
            model: 'trialRecordModel',
            id: 'trialRecordStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/replacePart/getTrialCombination?docNumber='+docNumber,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'trialRecordModel',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });



        var trialRecordGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var trialRecordGrid = Ext.create('Ext.grid.Panel', {
            plugins: [trialRecordGridEditing],
            store: trialRecordStore,
            columns: trialRecordColumns,
            id:'trialRecordGrid',
            title: '试用记录',
            columnLines: true,
            height:200,
            width:'100%',
            multiSelect : false,
            autoScroll: true,
            // selType: 'checkboxmodel',
            viewConfig: { forceFit: false },
            viewConfig:{enableTextSelection:true},
        });


        trialRecordGrid.on('edit',function(editor,e){
            // var idx = e.rowIdx
            // var record = trialRecordGrid.getStore().getAt(idx);
            // Ext.Ajax.request({
            //     url: '/Windchill/ptc1/replacePart/saveSubstitutionRelationshipTable',
            //     method:'POST',
            //     headers: {'Content-Type':'application/json'},
            //     params: JSON.stringify(record.data),
            //     success: function (response, opts) {
            //         var obj = Ext.decode(response.responseText);
            //         if(obj.message=='success') {
            //             var obj = Ext.decode(response.responseText);
            //             e.record.commit();
            //             trialRecordStore.load();
            //         }else {
            //             alert(obj.message)
            //         }
            //     },
            //     failure: function (response, opts) {
            //         alert('错误：删除信息失败，请检查网络！!');
            //     }
            // });

        });


        var submitPanel = Ext.create('Ext.panel.Panel', {
            xtype: 'panel',
            id: 'submitPanel',
            // title: '流程发起/试用结果确认',
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            height:800,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            autoScroll: true,
            items: [
                titt,
                alternativeGroupMaterialTableGrid,substitutionRelationshipTableGrid
                ,trialRecordGrid
            ]
        });









        this.items = [
            submitPanel
            // titt,
            // alternativeGroupMaterialTableGrid,substitutionRelationshipTableGrid
            // ,trialRecordGrid
        ];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {

        }
    }
});

/**
 * 查询制造商
 * @param params 参数参数
 */
function doSearch() {
    var multiplePartStore = Ext.getStore('multiplePartStore');
    var params = getParams();
    multiplePartStore.load({
        params: params,
        callback: function (records, operation, success) {
            if (!success) {
                if (typeof (operation.error) == 'string') {
                    alert(operation.error);
                } else {
                    alert('查询超时！请重试！')
                }
            } else {

            }
        }
    });
}

/**
 * 获取查询参数
 */
function getParams() {
    var params = {
        partNumber: Ext.getCmp('partNumber').getValue()
    };
    return params;
}

// 模板函数，根据条件动态生成列头文本
function generateHeaderTextWithRedStar(name) {
    var redStar = disableNode(start_node) ? '<span style="color: red;">*</span> ' : ''; // 根据条件生成红色星号
    if(name === "试用是否通过"){
        redStar = disableNode(trialResults_node) ? '<span style="color: red;">*</span> ' : ''; // 根据条件生成红色星号
    }

    return redStar + name;
}