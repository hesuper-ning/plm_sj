Ext.define('Pnt.view.ReplacePart',{
    extend:'Ext.panel.Panel',
    alias:'widget.ReplacePart',
    border:false,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'ReplacePart',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent:function(){

        Ext.define('replacePartModel', {
            extend: 'Ext.data.Model',
            fields: [
                'substitutionGroupMaterial','alternativeMaterialsNumber', 'describeT', 'ctBrand', 'supplierId', 'mainMaterial'
                ,'docNumber','modifiedTime','modifiedUser'
            ],
            idProperty: 'replacePartModel'
        });

        // 查询 Store
        var replacePartStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'replacePartModel',
            id:'replacePartStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/replacePart/replacePart?partNumber=' + partNumber,
                method:'GET',
                //timeout: 9000000,
                reader:{
                    type:'json',
                    root: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'replacePartModel',
                    messageProperty: 'massage'
                }
            }),
            autoLoad:true
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var replacePartGrid = Ext.create('Ext.grid.Panel', {
            plugins: cellEditing,
            store:replacePartStore,
            title: '替代物料清单',
            autoWidth : true,
            autoScroll:true,
            height:400,
            listeners: {
                celldblclick:function(table, td, cellIndex, record){
                    var fileName;
                    fileName=table.getHeaderAtIndex(cellIndex).dataIndex;
                    var data = record.get(fileName);//单元格value
                    alert(data);
                }
            },
            viewConfig:{enableTextSelection:true, forceFit : false},
            columns: [
                { text: '集群物料编码',hidden:isAlternativeMaterials,flex: 1, dataIndex: 'substitutionGroupMaterial', width: 50, align: 'center', menuDisabled: true},
                { text: '基础物料编码',hidden:isSubstitutionGroupMaterial,flex: 1, dataIndex: 'alternativeMaterialsNumber', width: 50, align: 'center', menuDisabled: true},
                { text: '替代物料描述',flex: 1,  dataIndex: 'describeT' , width:100, align: 'center', menuDisabled: true},
                { text: '品牌',flex: 1,  dataIndex: 'ctBrand', width:100, align: 'center', menuDisabled: true},
                { text: '供应商',flex: 1,  dataIndex: 'supplierId',width:100, align: 'center',renderer:showTip, menuDisabled: true},
                { text: '是否是主料',hidden:isSubstitutionGroupMaterial,flex: 1,  dataIndex: 'mainMaterial' , width:100, align: 'center', menuDisabled: true},
                { text: '上次修改时间',flex: 1, dataIndex: 'modifiedTime', width: 50, align: 'center'},
                { text: '修改者',flex: 1,  dataIndex: 'modifiedUser' , width:100, align: 'center'},
                { text: '相关流程链接',flex: 1,  dataIndex: 'docNumber', width:100, align: 'center'}
                ]
        });



        Ext.define('replacePartChangeModel', {
            extend: 'Ext.data.Model',
            fields: [
                'modifiedTime', 'modifiedUser', 'docNumber','branchId','path'
            ],
            idProperty: 'replacePartChangeModel'
        });

        // 查询 Store
        var replacePartChangeStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'replacePartChangeModel',
            id:'replacePartChangeStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/replacePart/replacePartChange?partNumber=' + partNumber,
                method:'GET',
                //timeout: 9000000,
                reader:{
                    type:'json',
                    root: 'data',
                    totalProperty: 'totalCount',
                    idProperty: 'replacePartChangeModel',
                    messageProperty: 'massage'
                }
            }),
            autoLoad:true
        });


        var replacePartChangeGrid = Ext.create('Ext.grid.Panel', {
            plugins: cellEditing,
            store:replacePartChangeStore,
            title: '替代物料更改',
            autoWidth : true,
            autoScroll:true,
            height:400,
            listeners: {
                celldblclick:function(table, td, cellIndex, record){
                    var fileName;
                    fileName=table.getHeaderAtIndex(cellIndex).dataIndex;
                    var data = record.get(fileName);//单元格value
                    alert(data);
                }
            },
            viewConfig:{enableTextSelection:true, forceFit : false},
            columns: [
                { text: '上次修改时间',flex: 1, dataIndex: 'modifiedTime', width: 50, align: 'center'},
                { text: '修改者',flex: 1,  dataIndex: 'modifiedUser' , width:100, align: 'center'},
                { text: '相关流程链接',flex: 1,  dataIndex: 'path', width:100, align: 'center'}
            ]
        });




//========================Items Area======================//

        this.items=[replacePartGrid,replacePartChangeGrid];
        this.callParent();
    },//~End of initComponent

    listeners:{
        //'afterrender':function(){}
    },

//================Function area===================//

});

//==============主入口=================================//
Ext.onReady(function() {
    Ext.QuickTips.init();

    Ext.create('Ext.container.Viewport', {
        layout: 'border',
        items: [ {
            region: 'center',
            items:[{
                // title: '<font style="font-size:12px">问题报表</font>',
                xtype:'ReplacePart'
            }]//~End of center region items
        }]//~End of viewPort items
    });

});

function hasContent(value) {
    if(value != null && value.toString() != '') {
        return true;
    } else {
        return false;
    }
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion