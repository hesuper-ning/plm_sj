
var start_node='start_node'; //提交节点
var trialResults_node = 'trialResults_node';//试用结果确认




/**
 * 判断是否可编辑
 * @param node 节点表单key
 */
function disableNode(node) {
        if(taskCompleted) {
                return false;
        } else {
                if(node == currentActKey) {
                        return true;
                } else {
                        return false;
                }
        }
};


/**
 * 是否是对应节点
 * @param changeType 更改类型
 */
function correspondentNode (type) {
        return false;
};


/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveSingleField01(dbTableName,itemId,dataKey,dataValue,callbackFn){
        var mockRec = {
                dbTableName:dbTableName,
                itemId:itemId,
                dataKey:dataKey,
                dataValue:dataValue,
                docNumber:docNumber
        };
        Ext.Ajax.request({
                url: '/Windchill/ptc1/replacePart/saveAlternativeGroupMaterialTable',
                params: {updateRecord:Ext.encode(mockRec)},
                success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.message=="success") {
                                //回调函数，一般用于后台操作成功后刷新列表
                                if (callbackFn) {
                                        callbackFn(response, opts);
                                }
                        } else {
                                alert(obj.message);
                        }
                },
                failure: function (response, opts) {
                        alert('错误：保存信息失败，请检查网络！!');
                }
        });
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveSingleField02(dbTableName,itemId,dataKey,dataValue,callbackFn){
        var mockRec = {
                dbTableName:dbTableName,
                itemId:itemId,
                dataKey:dataKey,
                dataValue:dataValue,
                docNumber:docNumber
        };
        Ext.Ajax.request({
                url: '/Windchill/ptc1/replacePart/saveSubstitutionRelationshipTable',
                params: {updateRecord:Ext.encode(mockRec)},
                success: function (response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj.message=="success") {

                        } else {
                                alert(obj.message);
                        }
                        //回调函数，一般用于后台操作成功后刷新列表
                        if (callbackFn) {
                                callbackFn(response, opts);
                        }
                },
                failure: function (response, opts) {
                        alert('错误：保存信息失败，请检查网络！!');
                }
        });
}










/**
 * combobox空白行高度与选项保持一致
 * @param name
 * @returns {Ext.XTemplate}
 */
function getXTemplate(name) {
        return Ext.create('Ext.XTemplate',
            '<tpl for=".">',
            '<div class="x-boundlist-item" style="height:25px">{' + name + '}</div>',
            '</tpl>'
        )
}