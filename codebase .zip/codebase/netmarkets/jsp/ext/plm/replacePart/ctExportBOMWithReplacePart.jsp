<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@ page import="wt.part.WTPart" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="ext.plm.adTool.CtAdToolLogic" %>
<%@ page import="com.alibaba.fastjson.JSONObject" %>
<%@ page import="java.net.URLDecoder" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        // 解码
        oid = URLDecoder.decode(oid, "UTF-8");
        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
        String partOid = part.getPersistInfo().getObjectIdentifier().getId()+"";
    %>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
</head>
<body>
<script>

    var partOid  = "<%=partOid%>";
    // ==============layout define area=================================//
    Ext.onReady(function() {

        var downloadFrame = document.createElement('iframe');
        downloadFrame.style.display = 'none';
        downloadFrame.src = '/Windchill/ptc1/bom/exportBom?partOid='+partOid;
        document.body.appendChild(downloadFrame);

        // 监听 iframe 的加载完成事件
        Ext.get(downloadFrame).on('load', function() {
            // 下载完成后关闭窗口
            window.close();
        });

    });
</script>
</body>
</html>