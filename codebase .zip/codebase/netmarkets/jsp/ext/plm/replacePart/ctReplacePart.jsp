
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
%>

<iframe id="ctHumanResourceIframe" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"
        src="netmarkets/jsp/ext/plm/replacePart/ctReplacePartPlugin.jsp?oid=<%=oid%>" style="width:98%;height:900px" ></iframe>

