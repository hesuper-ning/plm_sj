<%@ page import="ext.plm.part.config.CtPartConstant" %>
<%@ page import="wt.workflow.engine.WfActivity" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@ page import="ext.plm.part.replacePart.config.CtReplacePartProperties" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String docNumber = "";
        WfActivity activity = null;
        String currentActKey = "";
        boolean taskCompleted = false; //任务是否已完成
        String workItemOid = request.getParameter("oid");
        long branchId = 1L;
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        String oid = request.getParameter("oid");

        wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
        String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/tcomp/infoPage?oid=VR:wt.doc.WTDocument:";

        //WorkItem workItem = (WorkItem) CtWTObjectUtil.getObjectByOid(oid);
        Object obj = rf.getReference(workItemOid).getObject();
        if(obj instanceof WorkItem){
            WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
            activity = (WfActivity) workItem.getSource().getObject();
            WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
            branchId = doc.getBranchIdentifier();
            String activityName = activity.getName();
            currentActKey = CtReplacePartProperties.getActivityKey(activityName);
            WTDocument document = (WTDocument) workItem.getPrimaryBusinessObject().getObject();
            docNumber = document.getNumber();
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
        }else if(obj instanceof WTDocument){
            WTDocument doc = (WTDocument) obj;
            branchId = doc.getBranchIdentifier();
            docNumber = doc.getNumber();
        }

    %>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js/ctReplacementRelationshipMaintenance.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctDisposalOfRelatedMaterials.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctReplacePartFunction.js?_dc=<%=System.currentTimeMillis()%>"></script>

    <style>
        .custom-title {
            font-size: 12px;
        }
    </style>


</head>

<body>
<script>
    var docNumber = '<%=docNumber%>';

    //url前缀
    var urlPathPrefix ="<%=urlPathPrefix%>";
    <%--var submit   = <%=submit %>;--%>
    <%--var resultConfirmation  = <%=resultConfirmation%>;--%>
    //当前审批结点key
    var currentActKey = "<%=currentActKey%>";
    //判断当前任务是否已经完成
    var taskCompleted = false;
    <%if(taskCompleted){%>
    taskCompleted = true;
    <%}%>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [ {
                region: 'center',
                items:[{
                    xtype:'panel',
                    height:850,
                    scrollable: false,
                    border:false,
                    items:[{
                        xtype:'tabpanel',
                        activeTab: 0,
                        items:[{
                            title: '<font style="font-size:12px">替代关系维护</font>',
                            height:850,
                            xtype: 'ReplacementRelationshipMaintenance'
                        }
                        // ,{
                        //     // xtype:'panel',
                        //     scrollable: true,
                        //     title: '<font style="font-size:12px">相关物料处置</font>',
                        //     xtype:'DisposalOfRelatedMaterials'
                        // }
                        ]//~End of tabpanel items
                    }]
                }]//~End of center region items
            }]//~End of viewPort items
        });
    });
</script>
</body>
</html>







<%--<%@page import="wt.fc.ReferenceFactory"%>--%>
<%--<%@page import="wt.fc.ReferenceFactory"%>--%>
<%--<%@ page import="wt.workflow.engine.WfActivity" %>--%>
<%--<%@ page import="wt.doc.WTDocument" %>--%>
<%--<%@ page import="ext.plm.util.CtWTObjectUtil" %>--%>
<%--<%@ page import="wt.workflow.work.WorkItem" %>--%>
<%--<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>--%>
<%--<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">--%>

<%--<html>--%>
<%--<head>--%>

<%--    <%--%>
<%--        String oid = request.getParameter("oid");--%>
<%--        ReferenceFactory rf = new ReferenceFactory();--%>

<%--        wt.org.WTPrincipal principal =  wt.session.SessionHelper.manager.getPrincipal();--%>
<%--        wt.org.WTUser wtuser = (wt.org.WTUser)principal;--%>
<%--        String currentUserName = wtuser.getFullName();--%>
<%--        String currentUserNameId = wtuser.getName();--%>
<%--        boolean isManager = true;//PntCostLogic.isProjectManager(p, wtuser);--%>
<%--        boolean isAuthority = true;//PntCostLogic.hasAuthority(p, wtuser, "RWD_CostManager");--%>
<%--        boolean isAdmin = true;--%>

<%--        WorkItem workItem = (WorkItem) CtWTObjectUtil.getObjectByOid(oid);--%>
<%--        WfActivity activity = (WfActivity) workItem.getSource().getObject();--%>
<%--        String activityName = activity.getName();--%>
<%--        WTDocument document = (WTDocument) workItem.getPrimaryBusinessObject().getObject();--%>
<%--        String docNumber = document.getNumber();--%>


<%--    %>--%>


<%--    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">--%>
<%--    <link rel="stylesheet" type="text/css"--%>
<%--          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />--%>
<%--    <link rel="stylesheet" type="text/css"--%>
<%--          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">--%>
<%--    <!-- ExtJS -->--%>
<%--    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>--%>
<%--    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>--%>
<%--    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>--%>
<%--    <script type="text/javascript" src="js/ctReplacementRelationshipMaintenance.js?_dc=<%=System.currentTimeMillis()%>"></script>--%>
<%--    <script type="text/javascript" src="js/ctDisposalOfRelatedMaterials.js?_dc=<%=System.currentTimeMillis()%>"></script>--%>


<%--</head>--%>

<%--<body>--%>
<%--<script type="text/javascript">--%>
<%--    //当前用户--%>
<%--    var docNumber = '<%=docNumber%>';--%>
<%--    var currentUser = '<%=currentUserName%>';--%>
<%--    //是否是存储库管理员--%>
<%--    var isManager = "<%=isManager%>";--%>
<%--    //项目oid--%>
<%--    var PROJECTOID = "<%=oid%>";--%>
<%--    //项目oid--%>
<%--    var projectId = "<%=oid%>";--%>
<%--    //专门的角色权限--%>
<%--    var isAuthority = "<%=isAuthority%>";--%>

<%--    //管理员--%>
<%--    var isAdmin = "<%=isAdmin%>";--%>

<%--    function checkNodeEnable() {--%>
<%--        var flag = false;--%>
<%--        if(isManager == "true" || isAdmin == "true") {--%>
<%--            flag = true;--%>
<%--        }--%>
<%--        return flag;--%>
<%--    }--%>

<%--    function checkNodeAuthority() {--%>
<%--        var flag = false;--%>
<%--        if(isAuthority == "true") {--%>
<%--            flag = true;--%>
<%--        }--%>
<%--        return flag;--%>
<%--    }--%>

<%--    //==============主入口=================================//--%>
<%--    Ext.onReady(function() {--%>
<%--        Ext.QuickTips.init();--%>
<%--        Ext.create('Ext.container.Viewport', {--%>
<%--            layout: 'border',--%>
<%--            // height:20000,--%>
<%--            items: [ {--%>
<%--                region: 'center',--%>
<%--                items:[{--%>
<%--                    xtype:'panel',--%>
<%--                    scrollable: true,--%>
<%--                    border:false,--%>
<%--                    items:[{--%>
<%--                        xtype:'tabpanel',--%>
<%--                        activeTab: 0,--%>
<%--                        items:[{--%>
<%--                            title: '<font style="font-size:12px">替代关系维护</font>',--%>
<%--                            xtype:'ReplacementRelationshipMaintenance'--%>
<%--                        },{--%>
<%--                            title: '<font style="font-size:12px">相关物料处置</font>',--%>
<%--                            xtype:'DisposalOfRelatedMaterials'--%>
<%--                        }--%>
<%--                        ]//~End of tabpanel items--%>
<%--                    }]--%>
<%--                }]//~End of center region items--%>
<%--            }]//~End of viewPort items--%>
<%--        });--%>
<%--    });--%>

<%--</script>--%>

<%--</body>--%>
<%--</html>--%>