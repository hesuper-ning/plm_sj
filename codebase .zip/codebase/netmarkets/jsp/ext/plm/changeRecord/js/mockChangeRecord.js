Ext.define('PLM.view.MockChangeRecord', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockChangeRecord',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'mockChangeRecord',
        in_objectDesc: '变更记录',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var ctPDMDocStore = Ext.create('Ext.data.Store', {
            // pageSize: 1,
            fields:['id' ,'docType','docName','docNumber','docStatus','docVersion'],

            id: 'ctPDMDocStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/projectMileStone/getAssocProductDoc?oid='+oid,
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: ctPDMDocStore,
            id: 'mockExampleGrid',
            margin: '20 10 20 10',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            // selType: 'checkboxmodel',
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{text:'序号', width:45,xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '类型', dataIndex: 'docType', width: 100, editor: null, menuDisabled: true},
                {text: '文档名称', dataIndex: 'docName', width: 80, editor: null, menuDisabled: true},
                {text: '文档编码', dataIndex: 'docNumber', width: 80, editor: null, menuDisabled: true},
                {text: '文档状态', dataIndex: 'docStatus', width: 80, editor: null, menuDisabled: true},
                {text: '文档版本', dataIndex: 'docVersion', width: 80, editor: null, menuDisabled: true},
            ]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                // saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'textfield',
                fieldLabel: '标题1',
                padding: '20 15 10 20',
                id: 'att1',
                name: 'att1',
                width: 450,
                listeners: {
                    blur: function (e) {
                        saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    }
                }
            }, {
                xtype: 'textfield',
                fieldLabel: '标题2',
                padding: '0 15 20 20',
                id: 'att2',
                name: 'att2',
                width: 450,
                listeners: {
                    blur: function (e) {
                        saveObjectData(Ext.getCmp('MockExample').getIn_objectKey(), Ext.getCmp('MockExample').getIn_objectDesc(), e.id, e.value);
                    }
                }
            }, mockExampleGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleGrid];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            // Ext.Ajax.request({
            //     method: 'GET',
            //     url: '/Windchill/ptc1/projectMileStone/getAssocProductDoc?oid='+oid,
            //     // params: {
            //     //     oid:oid,
            //     // },
            //     success: function (response, opts) {
            //         var obj = Ext.decode(response.responseText);
            //         if (obj.message == 'success') {
            //             var mainPanel = Ext.getCmp('mainForm');
            //             mainPanel.getForm().setValues(obj.data);
            //
            //             ght_dataLoadedFlag = true;
            //         } else {
            //             alert(obj.message);
            //         }
            //     },
            //     failure: function (response, opts) {
            //         alert('错误：查询信息失败，请检查网络！!');
            //     }
            // }); //~End of Ajax request
            Ext.getStore('ctPDMDocStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            // Ext.Ajax.request({
            //     url: '/Windchill/ptc1/mock/getObject',
            //     params: {
            //         objectKey: Ext.getCmp('MockExample').getIn_objectKey()
            //     },
            //     success: function (response, opts) {
            //         var obj = Ext.decode(response.responseText);
            //         if (obj['success']) {
            //             var mainPanel = Ext.getCmp('mainForm');
            //             mainPanel.getForm().setValues(obj);
            //         } else {
            //             alert(obj['error']);
            //         }
            //     },
            //     failure: function (response, opts) {
            //         alert('错误：查询信息失败，请检查网络！!');
            //     }
            // }); //~End of Ajax request
        }
    }
});

