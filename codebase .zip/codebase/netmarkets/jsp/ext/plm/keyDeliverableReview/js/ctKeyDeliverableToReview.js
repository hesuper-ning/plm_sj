let ctKeyDeliverableToReviewBo =  Ext.create('Ext.form.Panel', {
    title: '4. 复核',
    id:'ctKeyDeliverableToReviewBo',
    autoWidth:true,
    xtype: 'form',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
     {
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
					{
						xtype : 'combo',
						fieldLabel: setMust('评审结论',(disableNode(TOREVIEW_NODE)||disableNode(EXAMINE_NODE))),
						labelAlign: 'right',
						id: 'reviewConclusion',
					    name: 'reviewConclusion',
					    disabled:!(disableNode(TOREVIEW_NODE)||disableNode(EXAMINE_NODE)),
						value: ' ',
						store : [['通过','通过'],['不通过', '不通过']],
						mode : 'local',
						menuDisabled:true,
						width: 300,
	    	            listeners: {
	    	                blur: function (e) {
	    	                    var value = Ext.getCmp('reviewConclusion').getValue();
	    	                    //触发后台保存
	    	                    autoSaveAtt('reviewConclusion', value);
	    	                }
	    	            }
					},{
						  xtype: 'textarea',
						  fieldLabel: setRequired('说明',(disableNode(TOREVIEW_NODE)||disableNode(EXAMINE_NODE))),
                          labelAlign: 'right',
                          disabled:!(disableNode(TOREVIEW_NODE)||disableNode(EXAMINE_NODE)),
                          //margin: '15 15 0 7',
                          id: 'reviewExplain',
                          name: 'reviewExplain',
                          value:'',
                          //emptyText: '（SAP系统跨工厂状态改为：96）',
                          width: 1100,
                          listeners: {
  	    	                blur: function (e) {
  	    	                    var value = Ext.getCmp('reviewExplain').getValue();
  	    	                    //触发后台保存
  	    	                    autoSaveAtt('reviewExplain', value);
  	    	                }
  	    	            }
					}    
				/*	,{
	    	        	xtype: 'textfield',
	    	            fieldLabel: '说明',
	    	            labelAlign: 'right',
	    	            id: 'reviewExplain',
	    	            name: 'reviewExplain',
	    	            disabled:!(disableNode(TOREVIEW_NODE)||disableNode(EXAMINE_NODE)),
	    	            width: 1100,
	    	            listeners: {
	    	                blur: function (e) {
	    	                    var value = Ext.getCmp('reviewExplain').getValue();
	    	                    //触发后台保存
	    	                    autoSaveAtt('reviewExplain', value);
	    	                }
	    	            }
	    	        }*/
            ]
        },{
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
                {
    	        	xtype: 'displayfield',
    	            fieldLabel: '复核人',
    	            labelAlign: 'right',
    	            id: 'reviewChiefExaminer',
    	            name: 'reviewChiefExaminer',
    	            width: 300
    	        },
                {
                    xtype: 'displayfield',
                    fieldLabel: '审核日期',
                    labelAlign: 'right',
                    id: 'revieAauditDate',
                    name: 'revieAauditDate',
                    width: 300
                }
            ]
        }
    ],
    listeners:{
        'afterrender': function () {
   
        }
    }
});