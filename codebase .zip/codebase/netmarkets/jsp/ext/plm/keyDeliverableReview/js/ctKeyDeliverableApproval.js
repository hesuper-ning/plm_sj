let ctKeyDeliverableApprovalBo =  Ext.create('Ext.form.Panel', {
    title: '6. 批准人批准',
    id:'ctKeyDeliverableApprovalBo',
    autoWidth:true,
    xtype: 'form',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
     {
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
					{
						xtype : 'combo',
						fieldLabel: setMust('批准意见',disableNode(APPROVAL_NODE)),
						labelAlign: 'right',
						id: 'approvalOpinion',
					    name: 'approvalOpinion',
						value: ' ',
						store : [['通过','通过'],['不通过', '不通过']],
						mode : 'local',
						menuDisabled:true,
						disabled:!disableNode(APPROVAL_NODE),
						width: 300,
	    	            listeners: {
	    	                blur: function (e) {
	    	                    var value = Ext.getCmp('approvalOpinion').getValue();
	    	                    //触发后台保存
	    	                    autoSaveAtt('approvalOpinion', value);
	    	                }
	    	            }
					},    
					{
	    	        	xtype: 'textfield',
	    	            fieldLabel: setRequired('说明',disableNode(APPROVAL_NODE)),
	    	            labelAlign: 'right',
	    	            id: 'approvalExplain',
	    	            disabled:!disableNode(APPROVAL_NODE),
	    	            name: 'approvalExplain',
	    	            width: 600,
	    	            listeners: {
	    	                blur: function (e) {
	    	                    var value = Ext.getCmp('approvalExplain').getValue();
	    	                    //触发后台保存
	    	                    autoSaveAtt('approvalExplain', value);
	    	                }
	    	            }
	    	        }
            ]
        },{
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
                {
    	        	xtype: 'displayfield',
    	            fieldLabel: '批准人',
    	            labelAlign: 'right',
    	            id: 'approver',
    	            name: 'approver',
    	            width: 300
    	        },
                {
                    xtype: 'displayfield',
                    fieldLabel: '审核日期',
                    labelAlign: 'right',
                    id: 'approvalAuditDate',
                    name: 'approvalAuditDate',
                    width: 300
                }
            ]
        }
    ],
    listeners:{
        
    }
});