let ctKeyDeliverableBasisBo =  Ext.create('Ext.form.Panel', {
    title: '1、基本情况',
    id:'ctKeyDeliverableBasisBo',
    autoWidth:true,
    xtype: 'form',
//    collapsible: true,
//    collapseToolText: '折叠',
//    expandToolText: '展开',
//    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
     {
	    xtype: 'panel',
	    layout: 'hbox',
	    defaults: {margin: '5 5 5 5', labelWidth: 135},
	    items: [
	        {
	        	xtype: 'textfield',
	            fieldLabel: '<font color=red>*</font>评审主题',
	            labelAlign: 'right',
	            id: 'reviewTitle',
	            name: 'reviewTitle',
	            hidden: true,
	            disabled:!disableNode(SUBMIT_NODE),
	            width: 600,
	            listeners: {
	                blur: function (e) {
	                    var value = Ext.getCmp('reviewTitle').getValue();
	                    //触发后台保存
	                    autoSaveAtt('reviewTitle', value);
	                }
	            }
	        }
	        ]
	 }, 
     {
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
                {
                    xtype: 'displayfield',
                    fieldLabel: '交付件编号',
                    labelAlign: 'right',
                    id: 'deliveryNumber',
                    name: 'deliveryNumber',
                    width: 300
                },
                {
                    xtype: 'displayfield',
                    fieldLabel: '交付件名称',
                    labelAlign: 'right',
                    id: 'deliveryName',
                    name: 'deliveryName',
                    width: 300
                },
                {
                    xtype: 'displayfield',
                    fieldLabel: '交付件类型',
                    labelAlign: 'right',
                    id: 'deliveryType',
                    name: 'deliveryType',
                    width: 300
                }
            ]
        },{
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
                {
                    xtype: 'displayfield',
                    fieldLabel: '项目编号',
                    labelAlign: 'right',
                    id: 'projectNumber',
                    name: 'projectNumber',
                    width: 300
                },
                {
                    xtype: 'displayfield',
                    fieldLabel: '项目名称',
                    labelAlign: 'right',
                    id: 'projectName',
                    name: 'projectName',
                    width: 300
                },
                {
					xtype : 'combo',
					multiSelect : false,
					valueField : 'projectPhase',
					displayField : 'projectPhase',
					anyMatch : true,
					fieldLabel : '<font color=red>*</font>项目阶段',
					labelAlign: 'right',
					store : projectPhaseStore,
					// disabled: disableNode(submit_node),
					disabled : !isEditable(SUBMIT_NODE),
					//disabledCls : 'none',
					name : 'projectPhase',
					id : 'projectPhase',
					width : 300,
					listeners : {
						select : function(e) {
							var value = Ext.getCmp('projectPhase').getValue();
	    	                //触发后台保存
	    	                autoSaveAtt('projectPhase', value);
						}
					}
				}
               /* {
                    xtype: 'displayfield',
                    fieldLabel: '项目阶段',
                    labelAlign: 'right',
                    id: 'projectPhase',
                    name: 'projectPhase',
                    width: 300
                }*/
            ]
        },{
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
                {
                	xtype: 'textfield',
                    fieldLabel: '<font color=red>*</font>产品型号/版本',
                    labelAlign: 'right',
                    id: 'belongingPV',
                    name: 'belongingPV',
                    disabled:!disableNode(SUBMIT_NODE),
                    width: 300,
    	            listeners: {
    	                blur: function (e) {
    	                    var value = Ext.getCmp('belongingPV').getValue();
    	                    //触发后台保存
    	                    autoSaveAtt('belongingPV', value);
    	                }
    	            }
                }
            ]
        },{
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
                {
                    xtype: 'displayfield',
                    fieldLabel: '拟制人',
                    labelAlign: 'right',
                    id: 'proposedPerson',
                    name: 'proposedPerson',
                    width: 300
                },
                 {
					xtype : 'combobox',
					multiSelect : false,
					// valueField: 'no',
					valueField : 'fullName',
					displayField : 'fullName',
					anyMatch : true,
					//editable : true,
					fieldLabel : '<font color=red>*</font>项目管理工程师',
					labelAlign: 'right',
					store : managEngineerPersonStore,
					disabled: !isEditable(SUBMIT_NODE),
					//disabledCls : 'none',
					name : 'projectManagEngineer',
					id : 'projectManagEngineer',
					//value : '',
					width : 300,
					minChars : 1,// 开始查询最小字符数
					mode : 'remote', // 查询模式 local为本地数据源 remote为远程服务端				
					listeners : {
						select : function(e) {
							var value = Ext.getCmp('projectManagEngineer').getValue();
	    	                //触发后台保存
	    	                autoSaveAtt('projectManagEngineer', value);
						}
					}
				}, 
				{
					xtype : 'combo',
					multiSelect : false,
					valueField : 'fullName',
					displayField : 'fullName',
					anyMatch : true,
					fieldLabel : '<font color=red>*</font>PQA',
					labelAlign: 'right',
					store : pqaPersonStore,
					// disabled: disableNode(submit_node),
					disabled : !isEditable(SUBMIT_NODE),
					//disabledCls : 'none',
					name : 'pqa',
					id : 'pqa',
					value : '',
					width : 300,
					minChars : 1,// 开始查询最小字符数
					mode : 'remote', // 查询模式 local为本地数据源 remote为远程服务端
					listeners : {
						select : function(e) {
								var value = Ext.getCmp('pqa').getValue();
		    	                //触发后台保存
		    	                autoSaveAtt('pqa', value);
						}
					}
				}
            ]
        },{
            xtype: 'panel',
            layout: 'hbox',
            defaults: {margin: '5 5 5 5', labelWidth: 135},
            items: [
                {
                    xtype: 'displayfield',
                    fieldLabel: '流程发起日期',
                    labelAlign: 'right',
                    id: 'processLaunchDate',
                    name: 'processLaunchDate',
                    width: 300
                }
            ]
        }
    ],
    listeners:{
        'afterrender': function () {
        
        }
    }
});
