let ctContentEditing5 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});


Ext.define('KeyDeliverableExecuteModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'evaluationProcess', 'assessmentElement', 'fixedScore',
    'score', 'remark'],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'KeyDeliverableExecuteModel',
    storeId: 'KeyDeliverableExecuteStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/keyDeliverable/getKeyDeliverableExecute?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

let ctDeliveryEvaluationBo = Ext.create('Ext.grid.Panel', {
	plugins: [ctContentEditing5],
    id: 'ctDeliveryEvaluationBo',
    autoWidth:true,
    store: Ext.data.StoreManager.lookup('KeyDeliverableExecuteStore'),
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 80, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 100, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 100, dataIndex: 'branchId', hidden: true, align: 'center'},
        {text: '评价环节', width: 180, dataIndex: 'evaluationProcess', align: 'center', renderer:showTip},
        {text: '评价要素', width: 900, dataIndex: 'assessmentElement', align: 'center', renderer:showTip},
        {text: '分值', width: 100, dataIndex: 'fixedScore', align: 'center', renderer:showTip},
        {text: setMust('得分',isEditable(PROCESSAUDITANDPROBLEMFOLLOW_NODE)), width: 100, dataIndex: 'score', align: 'center',editAccess: isEditable(PROCESSAUDITANDPROBLEMFOLLOW_NODE), editor: 'textfield', renderer:showTip},
        {text: setRequired('备注',isEditable(PROCESSAUDITANDPROBLEMFOLLOW_NODE)), width: 100, dataIndex: 'remark', align: 'center',editAccess: isEditable(PROCESSAUDITANDPROBLEMFOLLOW_NODE),editor: 'textfield', renderer:showTip}
        /*{
            text: setRequired('内部版本',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 60,
            dataIndex: 'partVersion',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },*/
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
        	updateExecuteCombination(editor, e);
        }
    }
});

let ctDeliveryReviewExecutionBo =  Ext.create('Ext.form.Panel', {
    id:'ctDeliveryReviewExecutionBo',
    autoWidth:true,
    xtype: 'form',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
           {
                  xtype: 'panel',
                  layout: 'hbox',
                  defaults: {margin: '5 5 5 5', labelWidth: 135},
                  items: [
                      {
                          xtype: 'displayfield',
                          fieldLabel: '文件页数（需求规格书统计行数）',
                          labelAlign: 'right',
                          id: 'fileNumberPages',
                          name: 'fileNumberPages',
                          width: 300
                      },
                      {
                          xtype: 'displayfield',
                          fieldLabel: '缺陷数',
                          labelAlign: 'right',
                          id: 'numberDefects',
                          name: 'numberDefects',
                          width: 300
                      },
                      {
                          xtype: 'displayfield',
                          fieldLabel: '缺陷密度',
                          labelAlign: 'right',
                          id: 'defectDensity',
                          name: 'defectDensity',
                          width: 300
                      }
                  ]
              },{
                  xtype: 'panel',
                  layout: 'hbox',
                  defaults: {margin: '5 5 5 5', labelWidth: 135},
                  items: [
                      {
                          xtype: 'displayfield',
                          fieldLabel: '得分',
                          labelAlign: 'right',
                          id: 'numberScore',
                          name: 'numberScore',
                          width: 300
                      },
                      {
                          xtype: 'displayfield',
                          fieldLabel: 'PQA',
                          labelAlign: 'right',
                          id: 'evaluationPQA',
                          name: 'evaluationPQA',
                          width: 300
                      },
                      {
                          xtype: 'displayfield',
                          fieldLabel: '审核日期',
                          labelAlign: 'right',
                          id: 'evaluationAuditDate',
                          name: 'evaluationAuditDate',
                          width: 300
                      }
                  ]
              }
          
    ]
});


let ctDeliveryReviewExecutionEvaluationBo =  Ext.create('Ext.panel.Panel', {
    title: '5. 交付件评审执行情况评价表',
    id:'ctDeliveryReviewExecutionEvaluationBo',
    autoWidth:true,
    xtype: 'panel',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
        ctDeliveryEvaluationBo,ctDeliveryReviewExecutionBo
    ],
    listeners:{
        'afterrender': function () {
        	
        }
    }
});
