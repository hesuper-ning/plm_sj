Ext.define('PLM.view.KeyDeliverableReview', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.KeyDeliverableReview',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'keyDeliverableReview',
    initComponent: function (){
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        items: [ctKeyDeliverableBasisBo,ctKeyDeliverableReviewAndExpertsBo,ctKeyDeliverableErrorCorrectionBo,
                                ctKeyDeliverableToReviewBo,ctDeliveryReviewExecutionEvaluationBo,ctKeyDeliverableApprovalBo
                        ]
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners:{
    	'afterrender': function () {
        	loadBasisFormData();
        }
    }
});