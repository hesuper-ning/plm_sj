let ctContentEditing1 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});



Ext.define('KeyDeliverableReviewModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'reviewExperts', 'chiefExaminer', 'post',
    'department', 'opinionCount', 'OpinionsAdoptedCount'],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'KeyDeliverableReviewModel',
    storeId: 'KeyDeliverableReviewStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/keyDeliverable/getKeyDeliverableReview?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//物料编码
var partNumberStore = Ext.create('Ext.data.Store', {
    fields: ['partNumber'],
    id: 'partNumberStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getSampleConfirmationFormPartNumber?branchId='+branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }),
    autoLoad: false
});

let chiefExaminerStore = [['是', '是'], ['否', '否']];
let ctKeyDeliverableCombinationBo = Ext.create('Ext.grid.Panel', {
	plugins: [ctContentEditing1],
    id: 'ctKeyDeliverableCombinationBo',
    autoWidth:true,
    store: Ext.data.StoreManager.lookup('KeyDeliverableReviewStore'),
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 150, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 100, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 100, dataIndex: 'branchId', hidden: true, align: 'center'},
        {text: '评审专家', width: 250, dataIndex: 'reviewExperts',editAccess: isEditable(REVIEWERANDREVIEWFORMAT_NODE),editor: 
        /*{
            xtype: 'combobox',
            valueField : 'name',
			displayField : 'fullName',
			value:'',
			anyMatch : true,
			editable : true,
            forceSelection: false,
            store : teamMemberStore10
        },*/ 
        	teamMemberCombo10,
        align: 'center', renderer:showTip},
        {text: '是否是主审人', width: 150, dataIndex: 'chiefExaminer',editAccess: isEditable(REVIEWERANDREVIEWFORMAT_NODE), align: 'center',editor: {
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: chiefExaminerStore
        }, renderer:showTip},
        {text: '职务', width: 200, dataIndex: 'post', align: 'center', renderer:showTip},
        {text: '部门', width: 200, dataIndex: 'department', align: 'center', renderer:showTip},
        {text: '意见提出数', width: 200, dataIndex: 'opinionCount', align: 'center', renderer:showTip},
        {text: '意见采纳数', width: 200, dataIndex: 'opinionsAdoptedCount', align: 'center', renderer:showTip}
        /*{
            text: setRequired('内部版本',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 60,
            dataIndex: 'partVersion',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },*/
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled : !isEditable(REVIEWERANDREVIEWFORMAT_NODE),
            handler: function () {
                ctContentEditing1.cancelEdit();
                function successCallback(data) {
                    let store = ctKeyDeliverableCombinationBo.getStore();
                    store.insert(store.getCount(), data);
                    ctKeyDeliverableCombinationBo.getStore().reload();
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/keyDeliverable/saveKeyDeliverableReview', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled : !isEditable(REVIEWERANDREVIEWFORMAT_NODE),
            handler: function () {
                let selected = ctKeyDeliverableCombinationBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                        ctKeyDeliverableCombinationBo.getStore().remove(selected);
                        ctKeyDeliverableCombinationBo.view.refresh();
                        ctKeyDeliverableCombinationBo.getStore().reload();
                    }
                    function failCallback() {
                    }
                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/keyDeliverable/deleteKeyDeliverableReview', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引
            var partNumber = record.get('partNumber');
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'supplierNumber'){
                    supplierCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getSupplierByPartNumber?partNumber=' + partNumber,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        supplierCombo.getStore().add({supplierInfo:item.supplierInfo});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
        	updateReviewCombination(editor, e);
        }
    }
});

let ctKeyDeliverableCombinationBo2 =  Ext.create('Ext.form.Panel', {
    id:'ctKeyDeliverableCombinationBo2',
    autoWidth:true,
    xtype: 'form',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
{
	xtype : 'combo',
	fieldLabel: '评审形式',
	labelAlign: 'right',
	id: 'reviewFormat',
    name: 'reviewFormat',
    disabled : !isEditable(REVIEWERANDREVIEWFORMAT_NODE),
	value: ' ',
	store : [['线上','线上'],['线下', '线下']],
	mode : 'local',
	menuDisabled:true,
	width: 300,
	listeners : {
		select : function(e) {
			var value = Ext.getCmp('reviewFormat').getValue();
            //触发后台保存
            autoSaveAtt('reviewFormat', value);
		}
	}
}
    ],
    listeners: {
       
    }
});

let ctKeyDeliverableReviewAndExpertsBo =  Ext.create('Ext.panel.Panel', {
    title: '2. 主审人预审意见及评审专家',
    id:'ctKeyDeliverableReviewAndExpertsBo',
    autoWidth:true,
    xtype: 'panel',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
        ctKeyDeliverableCombinationBo2,ctKeyDeliverableCombinationBo
    ],
    listeners:{
        'afterrender': function () {
        	
        }
    }
});
