var redStarFlag = '<font color=red bold>*</font>';//必填标志
var blueFlagStart = '<font color=blue bold><b>';//可编辑标识
var blueFlagEnd = '</b></font>';

var SUBMIT_NODE='keydeliver_submit_node';
var EXAMINE_NODE='keydeliver_examine_node';
var REVIEWERANDREVIEWFORMAT_NODE='keydeliver_reviewerAndReviewFormat_node';
var CHIEFREVIEWERFEEDBACK_NODE='keydeliver_chiefReviewerFeedback_node';
var UPDATEDELIVERABLES_NODE='keydeliver_updateDeliverables_node';
var FILLREVIEWCOMMENTS_NODE='keydeliver_fillReviewComments_node';
var REPLYTOREVIEWCOMMENTS_NODE='keydeliver_replyToReviewComments_node';
var TOREVIEW_NODE='keydeliver_toReview_node';
var CREATEPROBLEM_NODE='keydeliver_createProblem_node';
var PROCESSAUDITANDPROBLEMFOLLOW_NODE='keydeliver_processAuditAndProblemFollow_node';
var APPROVAL_NODE='keydeliver_approval_node';
var COMPETITIVERECEPTIONANDIMPORT_NODE='keydeliver_competitiveReceptionAndImport_node';

//表格beforeedit校验
function checkBeforeEdit(editor, e) {
   /* let field = e.field;
    let value = e.value;
    let record = e.record;*/
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
   
    let reviewer = record.get('reviewer');
    if(!(reviewer == userName)){
    	if((currentActKey == 'keydeliver_toReview_node') && (field == 'palnDefect')){
    		
    	}else if(((currentActKey == 'keydeliver_chiefReviewerFeedback_node') ||
    			(currentActKey == 'keydeliver_fillReviewComments_node'))
    			&& (field == 'reviewTypeComments' || field == 'palnDefect' || field == 'reviewComments')){
    		//alert('评审人是本人才能编辑！');
       	 	return false;
    	}
    }
    return checkEditAccess(e);
}
//项目阶段下拉
var projectPhaseStore = new Ext.data.ArrayStore({
    id: 'projectPhaseStore',
    fields: [
        {name:"projectPhaseVal"},
        {name: "projectPhase"}
    ],
    pruneModifiedRecords: true,
    extraParams: {
        'projectNumber': '',
    },
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/keyDeliverable/getProjectPhase' ,
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});

var projectPhaseStore = new Ext.data.ArrayStore({
    id: 'projectPhaseStore',
    fields: [
        {name:"projectPhaseVal"},
        {name: "projectPhase"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/keyDeliverable/getProjectPhase',
        extraParams: {
        	projectNumber: projectNumberinit
        },
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    listeners: {
        beforeload: function(store, operation) {
        	projectNumberinit = Ext.getCmp('projectNumber').getValue();
            var params = operation.getParams();
            params.projectNumber = projectNumberinit; // 添加新的参数，如果需要的话
        },
        load: function(store, records, successful, operation, options) {
            if (successful) {
               /* let projectNumber = Ext.getCmp('projectNumber');
                if(projectNumber){
                    let value = projectNumber.getValue();
                    if(value){
                        versionCom.setValue(value);
                    }
                }*/
            }
        }
    },
    autoLoad: false
});

/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    //if(isAdmin) return true;
    var column = e.column;//获取编辑列
    if(column.editAccess){
        return true;
    }else{
        return false;
    }
    return true;
}

/**
 * 设为必填
 */
function setMust(field, flag) {
    if (flag)
        return redStarFlag + blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 设为可填
 */
function setRequired(field, flag) {
    if (flag)
        return blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion

/**
 * 判断是否可编辑
 * @param node 节点表单key
 * @returns {boolean}
 */
function isEditable(...node) {
    //return true;
    if (readOnlyPage || taskCompleted) return false;
    let flag = false;
    node.forEach((item, index) => {
        if (item === currentActKey) {
            flag = true;
        }
    });
    return flag;
}

/**
 * 判断是否可编辑
 * @param node 节点表单key
 */
function disableNode(...node) {
    if(readOnlyPage || taskCompleted) {
        return false;
    } else {
        if(node == currentActKey) {
            return true;
        } else {
            return false;
        }
    }
};
/**
 * 判断节点表单是否应该展开
 */
function openPanel(...node) {
    //只读页面全打开
    if(readOnlyPage) {
        return false;
    }
    if(isEditable(...node)) {
        return false;
    }else {
        return true;
    }
}

/**
 * 回显格式化日期格式
 * @param value
 * @returns {*|string}
 */
function renderDateField(value) {
    var timeStr = value;
    if(value != null && value != undefined && value != ''){
        var date = new Date(value);
        timeStr = Ext.Date.format(date,"Y-m-d")
    }
    return timeStr;
}

//传入公共的参数，返回上传附件的代码
function uploadFilefield(fileName,text,node,tetx_name,type){
    if(text==null || text==""){
        text = "浏览...";
    }
    var inform ={
        xtype:'filefield',
        buttonOnly: true,
        id:fileName,
        name:fileName,
        labelWidth:70,
        disabled:!isEditable(Initiate_Trial_Node,Department_Manager_Review_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
        hideLabel: true,
        buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>'+text+'</span>',
        allowBlank: false,
        scope: this,
        listeners:{
            'change':function(fb,newValue,oldValue,opts){
                if(!newValue){
                    return;
                }
                var file = document.querySelector('[id='+fileName+'-button-fileInputEl]');
                var formData = new FormData();
                formData.append(fileName+'-button-fileInputEl', file.files[0]);
                fb.reset();//清空表单的值
                var myMask = new Ext.LoadMask({
                    msg: '正在上传，请稍候......',
                    target:this.findParentByType('panel')
                });
                myMask.show();
                $.ajax({
                    url: '/Windchill/ptc1/trial/uploadFiles?branchId='+branchId+'&tetx_name='+tetx_name+"&node="+node+"&type="+type+"&id=",
                    type: 'POST',
                    cache: false,
                    data: formData,
                    processData: false,
                    contentType: false
                }).done(function(res) {
                    myMask.hide();
                    var obj = Ext.decode(res);
                    var success = obj['success'];
                    var msg = obj['msg'];
                    if(!success){
                        alert(msg);
                    }else {
                        var fileName = obj['fileName'];
                        var value = Ext.getCmp(tetx_name).getValue();
                        if(value != null && value != ''){
                            fileName = value +"&nbsp;|&nbsp;" + fileName;
                        }
                        Ext.getCmp(tetx_name).setValue(fileName);
                        autoSaveBasis(tetx_name, fileName);
                    }
                }).fail(function(res) {
                    myMask.hide();
                    alert('上传失败！') ;
                });
            }
        }
    };
    return inform;
}

//自动保存字段
function autoSaveBasis(attKey, attValue) {
    var data = {
        branchId: branchId,
        key: attKey, //字段key
        value: attValue//字段值
    };
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/trial/updateTrialBasis',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);

            if(obj.message==="success") {

            } else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}
//转问题下拉列表
var demandPersonStore = new Ext.data.ArrayStore({
    id: 'demandPersonStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/common/queryPersonList',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});
/**
 * 加载Form表单
 */
function loadBasisFormData() {
    // Ext.Ajax.timeout = 99999999999999999999;
    Ext.Ajax.request({
        scope: this,
        timeout:99999999999999999999,
        url: '/Windchill/ptc1/keyDeliverable/getKeyDeliverableBasis?branchId=' + branchId,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var data = obj.data;
            let form = Ext.getCmp('ctKeyDeliverableBasisBo');
            if (form !== undefined) {
                form.getForm().setValues(data);
            }
            let form5 = Ext.getCmp('ctKeyDeliverableApprovalBo');
            if (form5 !== undefined) {
            	form5.getForm().setValues(data);
            }
                
           /* let form2 = Ext.getCmp('ctKeyDeliverableCombinationBo2');
            if (form2 !== undefined) {
                form2.getForm().setValues(data);
            }*/
            let form6 = Ext.getCmp('ctKeyDeliverableCombinationBo2');
            if (form6 !== undefined) {
                form6.getForm().setValues(data);
            }
            
            let form3 = Ext.getCmp('ctKeyDeliverableToReviewBo');
            if (form3 !== undefined) {
                form3.getForm().setValues(data);
            }
            
            let form4 = Ext.getCmp('ctDeliveryReviewExecutionBo');
            if (form4 !== undefined) {
                form4.getForm().setValues(data);
            }
            
            if(obj.message==="success") {} else {
                Ext.Msg.alert("实时保存数据失败",obj.message);
            }
        },
        failure: function (response, opts) {
            debugger;
            var obj = Ext.decode(response.responseText);
            alert('错误：保存信息失败，请检查网络！');
        }
    });
}

function deleteFilefield(branchId, fileName, tetx_name, node, type, id) {
    Ext.Msg.confirm('提示','确定要删除选中文件？',
        function(btn){
            if(btn =='yes'){
                deleteFile(branchId, fileName, tetx_name, node, type,id)
            }else{
                return;
            }
        },this
    );
}

//删除附件
function deleteFile(branchId, fileName, tetx_name, node, type, id) {
    var file = '';
    var path = '';
    if (taskCompleted) {
        return;
    }
    if (type == 'trialPlan') {
        if (!isEditable(Initiate_Trial_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'trialPlanFile';
        path = 'trialPlanFilePath';
    }else if(type == 'technicalDocument'){
        if (!isEditable(Update_Confirm_Trial_Plan_Submit_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'attachmentFile';
        path = 'attachmentPath';
    }else if(type == 'PQE'){
        if (!isEditable(PQE_Confirmation)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'reportFilePqe';
        path = 'reportFilePathPqe';
    }else if(type == 'IPQC'){
        if (!isEditable(IPQC_Approval_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'reportFileIPQc';
        path = 'reportFilePathIPQc';
    }else if(type == 'TechnicalTest'){
        if (!isEditable(Technical_Department_Engineer_Approval_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'reportFileTechnology';
        path = 'reportFilePathTechnology';
    }else if(type == 'annexFile'){
        if (!isEditable(Incoming_Inspection_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'annexFile';
    }else if(type == 'annexFile_1'){
        if (!isEditable(Approval_By_Team_Leader_Node)){
            alert("当前节点无法删除请在指定节点删除")
            return;
        }
        file = 'annexFile';
    }


    Ext.Ajax.request({
        scope: this,
        async: false, // ASYNC 是否异步( TRUE 异步 , FALSE 同步)
        url: '/Windchill/ptc1/trial/deleteFiles',
        params: {
            branchId: branchId, fileName: fileName,type:type
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var success = obj['success'];
            var msg = obj['msg'];
            if (!success) {
            } else {
                if (type == 'trialPlan') {
                    var value = Ext.getCmp(tetx_name).getValue();
                    var arr= new Array(); //定义一数组
                    arr=value.split("|"); //字符分割
                    for (i=0;i<arr.length ;i++ ){
                        var index = arr[i].indexOf(fileName);
                        if (index > -1) {
                            arr.splice(i,1);// 删除
                        }
                    }
                    var result = arr.join("&nbsp;|&nbsp;");
                    Ext.getCmp(tetx_name).setValue(result);
                    autoSaveBasis(tetx_name, '');
                }else if(type == 'technicalDocument'){
                    var tRecord =  Ext.getCmp('ctTechnicalDocumentBo').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                        tRecord.set(path, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctTechnicalDocumentBo').getStore().reload();
                    };
                    saveMockItemData("ZTechnicalDocumentTable",id,'attachmentFile','',callbackFn);
                    saveMockItemData("ZTechnicalDocumentTable",id,'attachmentPath','',callbackFn);
                }else if(type == 'PQE'){
                    var tRecord =  Ext.getCmp('ctFollowUpTrialTwoBo1').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                        tRecord.set(path, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctFollowUpTrialTwoBo1').getStore().reload();
                    };
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFilePqe','',callbackFn);
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFilePathPqe','',callbackFn);
                }else if(type == 'IPQC'){
                    var tRecord =  Ext.getCmp('ctFollowUpTrialTwoBo2').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                        tRecord.set(path, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctFollowUpTrialTwoBo2').getStore().reload();
                    };
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFileIPQc','',callbackFn);
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFilePathIPQc','',callbackFn);
                }else if(type == 'TechnicalTest'){
                    var tRecord =  Ext.getCmp('ctFollowUpTrialTwoBo3').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                        tRecord.set(path, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctFollowUpTrialTwoBo3').getStore().reload();
                    };
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFileTechnology','',callbackFn);
                    saveMockItemData("ZFollowUpTrialTwoTable",id,'reportFilePathTechnology','',callbackFn);
                }else if(type == 'annexFile'){
                    var tRecord =  Ext.getCmp('ctIncomingInspectionBo').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctIncomingInspectionBo').getStore().reload();
                    };
                    saveMockItemData("ZIncomingInspectionTable",id,'annexFile','',callbackFn);
                }else if(type == 'annexFile_1'){
                    var tRecord =  Ext.getCmp('ctFollowUpTrialBo').getSelectionModel().getSelection()[0];
                    if(!tRecord){
                        Ext.Msg.alert('提示', '请先选中要删除附件的行！');
                    }
                    if(tRecord != undefined){
                        tRecord.set(file, "");
                    }
                    var callbackFn = function () {
                        tRecord.commit();
                        Ext.getCmp('ctFollowUpTrialBo').getStore().reload();
                    };
                    saveMockItemData("ZFollowUpTrialTable",id,'annexFile','',callbackFn);
                }
            }
        },
        failure: function (response, opts) {
            // myMask.hide();
            alert('错误：删除附件失败，请检查网络！');
        }
    });
}

/**
 * 对Request封装
 * @Param url 请求url
 * @Param method 请求方法'GET' 'POST'
 * @Param async true 请求异步 false 请求步
 * @Param object
 * @Param callback 回调方法
 */
function sendRequest(url, method, headers, async, params, successCallback, failCallback) {
    Ext.Ajax.request({
        scope: this,
        url: url,
        method: method,
        timeout: 600000,
        async: async,
        headers: {'Content-Type': headers},
        params: params,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
                if (failCallback) {
                    failCallback();
                }
            } else {
                if (successCallback) {
                    successCallback(obj.data);
                }
            }
        },
        failure: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj&&obj['message']) {
                Ext.Msg.alert('错误', obj['message']);
            }else{
                Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
            }
            if (failCallback != null && failCallback !== '') {
                failCallback();
            }
        }
    }); //~End of Ajax request
}
/**
 * 更新主审人
 * @param editor
 * @param e
 * 
 */
function updateReviewCombination(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    if (field === 'reviewExperts' && (value == undefined || value == '' || value == null)) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
    	Ext.getCmp('ctKeyDeliverableCombinationBo').getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/keyDeliverable/updateKeyDeliverableReview', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value,branchId: branchId},
        successCallback, failCallback);
}
function updateErrorCombination(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
   /* let reviewer = record.get('reviewer');
    if(!(reviewer == userName)){
    	if((currentActKey == 'keydeliver_toReview_node') && (field == 'palnDefect')){
    		
    	}else{
    		alert('评审人是本人才能编辑！');
       	 	return ;
    	}
    }*/
    function successCallback(data) {
       /* if(field == 'tQCOpinion' || field == 'trialConclusion'){
            ctTrialResultBo.getStore().reload();
            ctDemandPlanBo.getStore().reload();
            ctIncomingInspectionBo.getStore().reload();
            ctTrialResultBo.getStore().reload();
        }else{*/
    	ctKeyDeliverableErrorBo.getStore().reload();
        //}
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/keyDeliverable/updateKeyDeliverableErrorCollection', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}
/**
 * 更新物料试用组合安排
 * @param editor
 * @param e
 * 
 */
function updateExecuteCombination(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    if("score" == field){
    	var regex = /^[-+]?[\d]+$/;
        if(!(regex.test(value)) || value < 0){
            Ext.Msg.alert('提示', '请填写正整数！');
            record.reject();
            ctKeyDeliverableCombinationBo.getStore().reload();
            return;
        	
        }
        var numValue = Number(value);
        let fixedScore = record.get('fixedScore');
        var numfixedScore = Number(fixedScore);
        if(numfixedScore < numValue){
        	Ext.Msg.alert('提示', '不能大于分值！');
        	record.reject();
        	/*record.set("score","");
        	record.commit();*/
            ctKeyDeliverableCombinationBo.getStore().reload();
            return;
        }
    }
    function successCallback(data) {
       /* if(field == 'tQCOpinion' || field == 'trialConclusion'){
            ctTrialResultBo.getStore().reload();
            ctDemandPlanBo.getStore().reload();
            ctIncomingInspectionBo.getStore().reload();
            ctTrialResultBo.getStore().reload();
        }else{*/
            ctKeyDeliverableCombinationBo.getStore().reload();
        //}
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/keyDeliverable/updateKeyDeliverableExecute', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}


/**
 * 更新技术文档
 * @param editor
 * @param e
 */
function updateTechnicalDocument(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctTechnicalDocumentBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTechnicalDocument', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value, branchId:branchId},
        successCallback, failCallback);
}

/**
 * 更新试用MBOM
 * @param editor
 * @param e
 */
function updateTrialMBom(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctTrialMBomBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTrialMBom', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value, branchId: branchId},
        successCallback, failCallback);
}

/**
 * 更新需求文档
 * @param editor
 * @param e
 */
function updateDemandPlan(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctDemandPlanBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateDemandPlan', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value, branchId: branchId},
        successCallback, failCallback);
}

/**
 * 更新质量控制部来料检验情况
 * @param editor
 * @param e
 */
function updateIncomingInspection(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctIncomingInspectionBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateIncomingInspection', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value, branchId:branchId},
        successCallback, failCallback);
}

/**
 * 更新试用执行标准
 * @param editor
 * @param e
 */
function updateTrialStandard(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctTrialStandardBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTrialStandard', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 更新试用过程跟进表1
 * @param editor
 * @param e
 */
function updateFollowUpTrial(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctFollowUpTrialBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateFollowUpTrial', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 更新试用过程跟进表2
 * @param editor
 * @param e
 */
function updateFollowUpTrialTwo(editor, e, successCallback) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateFollowUpTrialTwo', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 更新物料试用结果
 * @param editor
 * @param e
 */
function updateTrialResult(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctTrialResultBo.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/trial/updateTrialResult', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName,itemId,dataKey,dataValue,callbackFn){
    var mockRec = {
        oid:workItemOid,
        dbTableName:dbTableName,
        itemId:itemId,
        dataKey:dataKey,
        dataValue:dataValue
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/trial/saveItemData?oid=' + workItemOid,
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}

/**
 * 导出更改后BOM
 */
function exportUpdateBOM() {
    // 获取XMLHttpRequest
    var xmlHttpRequest = new XMLHttpRequest();
    //  发起请求
    xmlHttpRequest.open("POST", '/Windchill/ptc1/trial/exportUpdateBOM?branchId=' + branchId, true);
    // 设置请求头类型
    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
    xmlHttpRequest.responseType = "blob";
    //  返回
    xmlHttpRequest.onload = function (oEvent) {
        var content = xmlHttpRequest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).message)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            var fileNamePrefix = '更改后BOM';
            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }
    };
    xmlHttpRequest.send();
}

//需求人下拉列表
var managEngineerPersonStore = new Ext.data.ArrayStore({
    id: 'managEngineerPersonStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/keyDeliverable/getPersonLiableList?branchId=' + branchId + '&type=1',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});

var pqaPersonStore = new Ext.data.ArrayStore({
    id: 'pqaPersonStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/keyDeliverable/getPersonLiableList?branchId=' + branchId + '&type=2',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});
var reviewExpertsPersonStore = new Ext.data.ArrayStore({
    id: 'reviewExpertsPersonStore',
    fields: [
        {name:"name"},
        {name: "fullName"}
    ],
    pruneModifiedRecords: true,
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/keyDeliverable/getPersonLiableList?branchId=' + branchId + '&type=3',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    },
    autoLoad: false
});
/**
 * combobox空白行高度与选项保持一致
 * @param name
 * @returns {Ext.XTemplate}
 */
function getXTemplate(name) {
    return Ext.create('Ext.XTemplate',
        '<tpl for=".">',
        '<div class="x-boundlist-item" style="height:25px">{' + name + '}</div>',
        '</tpl>'
    )
}
//自动保存字段
function autoSaveAtt(attKey, attValue) {
    var data = {
    	branchId: branchId,
        attKey: attKey, //字段key
        attValue: attValue,//字段值
        activityKey: currentActKey, //全局变量，当前活动key
        dbTableName:"1"
    };
    Ext.Ajax.request({
        scope: this,
        async: false,
        url: '/Windchill/ptc1/keyDeliverable/autoSaveAtt',
        params: {
            data: Ext.encode(data)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request
}
//检查风险编号是否正确
function checkRiskNumber(number) {
    var isCorrect = true;
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/checkRiskNumber',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
                isCorrect = false;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return isCorrect;
}
/**
 * 保存列表中的一个属性(单元格）
 * @param dbTableName 表名
 * @param itemId 行数据id
 * @param dataKey 属性key
 * @param dataValue 属性值
 * @param callbackFn 回调函数,Ajax调用成功后才执行的任务，比如刷新列表
 * @returns {undefined}
 */
function saveMockItemData(dbTableName, itemId, dataKey, dataValue, callbackFn) {

    var returnItemId = undefined;
    var mockRec = {
        oid: oid,
        dbTableName: dbTableName,
        itemId: itemId,
        dataKey: dataKey,
        dataValue: dataValue
    };

    Ext.Ajax.request({
        url: '/Windchill/ptc1/certf/saveItemData',
        params: {
            updateRecord: Ext.encode(mockRec)
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                returnItemId = obj['returnItemId']; //新增时有用
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn();
                }
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    }); //~End of Ajax request
    return returnItemId;
}
Ext.define('ProjectModel', {
    extend: 'Ext.data.Model',
    fields: [
        'projectNumber', 'name'
    ],
    idProperty: 'projectNumber'
});
//检查问题编号是否正确
function checkProblemNumber(number) {
    var isCorrect = true;
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/checkProblemNumber',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
                isCorrect = false;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return isCorrect;
}
// 项目下拉
var projectListStore = Ext.create('Ext.data.Store', {
    //pageSize: 50,
    model: 'ProjectModel',
    id: 'projectListStore',
    pruneModifiedRecords: true,
    autoSync: true,//同步更新
    proxy: {
        type: 'ajax',
        url: '/Windchill/ptc1/problemMgt/getProjectInfo',
        reader: {
            type: 'json',
            rootProperty: 'items'
        }
    },
    autoLoad: false
});
//hr集成
Ext.define('PLM.hr.CtAllUserStore',{
    extend:'Ext.data.Store',
    alias:'widget.CtAllUserStore',
    fields:['userFullName','no'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/hr/getAllUser',
        method:'GET',
        reader:{
            type:'json',
            rootProperty: 'data',
            //idProperty: 'id',
            messageProperty: 'error'
        }
    }),
    autoLoad:true
});
//用户下拉列表
var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan'
});
var allUserStore_projectPlan1 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan1'
});
var allUserStore_projectPlan2 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan2'
});
var allUserStore_projectPlan3 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan3'
});
var allUserStore_projectPlan4 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan4'
});
var allUserStore_projectPlan5 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan5'
});
var allUserStore_projectPlan6 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan6'
});
var allUserStore_projectPlan7 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan7'
});
var allUserStore_projectPlan8 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan8'
});
var allUserStore_projectPlan9 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan9'
});
var allUserStore_projectPlan10 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan10'
});
var allUserStore_projectPlan11 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan11'
});
var allUserStore_projectPlan12 = Ext.create('PLM.hr.CtAllUserStore', {
    storeId: 'allUserStore_projectPlan12'
});
//上传图片窗口
var uploadImageWindow = Ext.create('Ext.Window', {
    title: '导入图片',
    width: 550,
    height: 350,
    //autoHeight : true,
    //autoWidth : true,
    closeAction: 'hide',
    id: 'uploadImageWindow',
    autoScroll: false,
    //closable:false,
    constrain: true,
    layout: 'fit',
    modal: true,
    items: {
        xtype: 'uploadImagePanel'
    }
});

/*
清空表单的值
 */
function clear() {
    //Ext.getCmp('description').setValue(""),
        Ext.getCmp('problemTerritory').setValue(""),
        Ext.getCmp('problemGrade').setValue(""),
        //Ext.getCmp('projectPhase').setValue(""),
        Ext.getCmp('optimizeStrategy').setValue(""),
       // Ext.getCmp('planFinishDate').setValue(""),
        Ext.getCmp('analysis').setValue(""),
        Ext.getCmp('badProportion').setValue(""),
        Ext.getCmp('problemSource').setValue(""),
        Ext.getCmp('relatedProblemNumber').setValue(""),
        Ext.getCmp('temporaryMeasures').setValue(""),
        //Ext.getCmp('creator').setValue(""),
        Ext.getCmp('softwareCharger').setValue(""),
        Ext.getCmp('hardwareCharger').setValue(""),
        Ext.getCmp('craftCharger').setValue(""),
        Ext.getCmp('fabricCharger').setValue(""),
        Ext.getCmp('testCharger').setValue(""),
        Ext.getCmp('qualityCharger').setValue(""),
        Ext.getCmp('purchaseCharger').setValue(""),
        Ext.getCmp('makeCharger').setValue(""),
        Ext.getCmp('bazaarCharger').setValue(""),
        Ext.getCmp('elseCharger').setValue("")
    Ext.getCmp('affirmCheck').setValue("")
    Ext.getCmp('pqaCheck').setValue("")
}
/**
 * 添加
 */
function save(data,approvalId) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/addProblem',
        params: {
            data: Ext.encode(data),
            imgs: imgs
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                var problemNumber = obj['problemNumber'];
                handlingRelationships(problemNumber,approvalId)
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

function handlingRelationships(problemNum,approvalId) {
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/keyDeliverable/dealRelationships',
        params: {
        	problemNum: problemNum,
        	approvalId: approvalId,
        	branchId: branchId
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                alert('问题创建成功');
                Ext.getStore('KeyDeliverableErrorStore').reload();
                Ext.getCmp('transferProblemWindow').close();
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

//获取研发拓展组名单，从团队中获取
//选人的comboboxStore（原来使用的是公用的：PLM.common.CtContainerUserStore）
Ext.define('ctTinyAssignment.CtContainerUserStore', {
    extend: 'Ext.data.Store',
    alias: 'widget.CtContainerUserStore',
    fields: ['userFullName', 'userFullName_department'],
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/tinyAssignment/getCtContainerUserNames',
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'items',
            //idProperty: 'id',
            messageProperty: 'error'
        }
    }),
    autoLoad: false
});
//选人的combobox（原来使用的是公用的：PLM.common.CtContainerUserCombo）
Ext.define('ctTinyAssignment.CtContainerUserCombo', {
    extend: 'Ext.form.field.ComboBox',
    alias: 'widget.CtContainerUserCombo',
    triggerAction: 'all',
    queryMode: 'local',
    displayField: 'display',
    valueField: 'loginName',
    // 配置 renderer 使得在选择时显示复合信息
    displayTpl: Ext.create('Ext.XTemplate',
        '<tpl for=".">',
        '{userFullName} ',
        '</tpl>'
    ),
    forceSelection: true,
    anyMatch: true,
    //multiSelect: true,
    typeAhead: false,
    allowBlank: true,
    width: 255,
});
var teamMemberStore10 = new Ext.create('ctTinyAssignment.CtContainerUserStore', {
    storeId: 'teamMemberStore10'
});

teamMemberStore10.load({
    params: {containerOid: containerOid},//containerOid由页面传入，获得方法a
    callback: function (r, options, success) {
        if (!success) {
            alert(options.error);
        }
    }
});

var teamMemberCombo10 = Ext.create('ctTinyAssignment.CtContainerUserCombo', {
    store: teamMemberStore10,
    name: "npiEngineer_combobox",
    id: "npiEngineer_combobox",
    listeners: {
        blur: function (e, records) {
            //saveFormForExpansionGroupUserBySelect(e, records);
        }
    }
});