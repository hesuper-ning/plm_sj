let ctContentEditing7 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});
Ext.define('KeyDeliverableErrorModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'branchId', 'reviewComments', 'attachmentName', 'reviewTypeComments',
    'palnDefect', 'reviewer', 'optimizationPlan','effectDescription','transferProblem',
    'problemConscientiouser','technologicalProcess','plannedCompleTime'],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'KeyDeliverableErrorModel',
    storeId: 'KeyDeliverableErrorStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/keyDeliverable/getKeyDeliverableErrorCollection?branchId=' + branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

//物料编码
var partNumberStore = Ext.create('Ext.data.Store', {
    fields: ['partNumber'],
    id: 'partNumberStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/trial/getSampleConfirmationFormPartNumber?branchId='+branchId,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }),
    autoLoad: false
});


let ctKeyDeliverableErrorBo = Ext.create('Ext.grid.Panel', {
	plugins: [ctContentEditing7],
    id: 'ctKeyDeliverableErrorBo',
    autoWidth:true,
    store: Ext.data.StoreManager.lookup('KeyDeliverableErrorStore'),
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 150, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 100, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'branchId', width: 100, dataIndex: 'branchId', hidden: true, align: 'center'},
        { text: setMust('评审意见',isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE)), width: 200, dataIndex: 'reviewComments',editAccess:isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE), editor: 'textfield', align: 'center', renderer:showTip},
      //  {text: '附件', width: 200, dataIndex: 'attachmentName',editAccess: true, editor: 'textfield', align: 'center', renderer:showTip},
        {text: setRequired('附件',isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE)),xtype:'actioncolumn', dataIndex: 'attachmentName', width: 250, editor: false, menuDisabled: true,
            items: [
                '->',
                '-',
                '-',
                '-',
                {
                    iconCls: 'icon icon-uploadImage',
                    tooltip: '添加文件',
                    hidden:isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE)?false:true,
                   // hidden:disableNode(submit_node)?false:true,
                    handler: function(grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        fileColumnId = record.get('id');
                        fileColumnName = 'attachmentName';
                        uploadTableName = 'ZKeyDeliverableApprovalTable';
                        //设置grid名称用于上传文件后刷新数据
                        gridName = 'ctKeyDeliverableErrorBo';
                        allowMultiple = true;
                        var uploadFileWindow = initUploadFileWindow();
                        uploadFileWindow.show()

                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                         var boolean = record.data.attachmentReply;
                         if(boolean!=null) {
                             return true;
                         }
                         return false;
                    }
                },
                '-',
                {
                    iconCls: 'icon-showInfo',
                    tooltip: '查看文件',
                    handler: function(grid, rowIndex, colIndex) {
                        var record = grid.getStore().getAt(rowIndex);
                        //设置当前列的id与列名和表名
                        fileColumnId = record.get('id');
                        fileColumnName = 'attachmentName';
                        uploadTableName = 'ZKeyDeliverableApprovalTable';
                        //设置grid名称用于上传文件后刷新数据
                        gridName = 'ctKeyDeliverableErrorBo';

                        var showFiles = initShowFiles();

                        if(!disableNode(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE)){
                            Ext.getCmp('showDelete').show();
                        }else {
                            Ext.getCmp('showDelete').hide();
                        }
                        showFiles.show()
                    },
                    isDisabled: function (view ,rowIndex,colIndex, item,record) {
                        var boolean = record.data.attachmentName;
                        if(boolean!=null) {
                            return false;
                        }
                        return true;
                    }
                }
            ]
        },

        
        {text: setMust('评审意见类型',isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE)), width: 150, dataIndex: 'reviewTypeComments',editAccess: isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE), align: 'center',editor: {
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: [['问题点', '问题点'], ['优化点', '优化点']]
        }, renderer:showTip},
        {text: setMust('是否属于方案本身缺陷',isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE,TOREVIEW_NODE,PROCESSAUDITANDPROBLEMFOLLOW_NODE)), width: 150, dataIndex: 'palnDefect',editAccess: isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE,TOREVIEW_NODE,PROCESSAUDITANDPROBLEMFOLLOW_NODE), align: 'center',editor: {
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: [['是', '是'], ['否', '否']]
        }, renderer:showTip},
        {text: '评审人', width: 150, dataIndex: 'reviewer', align: 'center', renderer:showTip},
        {text: setMust('优化方案',isEditable(REPLYTOREVIEWCOMMENTS_NODE)), width: 150, dataIndex: 'optimizationPlan',editAccess: isEditable(REPLYTOREVIEWCOMMENTS_NODE), align: 'center',editor: {
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: [['采纳', '采纳'], ['拒绝', '拒绝']]
        }, renderer:showTip},
        {text: setMust('优化执行效果说明',isEditable(REPLYTOREVIEWCOMMENTS_NODE)),width: 150, dataIndex: 'effectDescription', align: 'center',editAccess: isEditable(REPLYTOREVIEWCOMMENTS_NODE), editor: 'textfield', renderer:showTip},
        {text: setMust('是否转问题',isEditable(REPLYTOREVIEWCOMMENTS_NODE)),width: 150, dataIndex: 'transferProblem',editAccess: isEditable(REPLYTOREVIEWCOMMENTS_NODE), align: 'center',editor: {
            xtype: 'combobox',
            editable: false,
            forceSelection: false,
            store: [['是', '是'], ['否', '否']]
        }, renderer:showTip},
        {text: setRequired('转问题负责人',isEditable(REPLYTOREVIEWCOMMENTS_NODE)), width: 150, dataIndex: 'problemConscientiouser',editAccess: isEditable(REPLYTOREVIEWCOMMENTS_NODE), align: 'center',editor: {
            xtype: 'combobox',
            editable: false,
            multiSelect: false,
            valueField: 'name',
            displayField: 'fullName',
            anyMatch: true,
            editable: true,
            forceSelection: false,
            store: demandPersonStore
        }, renderer:showTip},
        {text: setRequired('转问题流程',isEditable(CREATEPROBLEM_NODE)), width: 150, dataIndex: 'technologicalProcess', align: 'center'},
        //{text: '计划完成时间', width: 150, dataIndex: 'plannedCompleTime',editAccess: true, editor: 'textfield', align: 'center', renderer:showTip}
        //{text: '计划完成时间', width: 150, dataIndex: 'plannedCompleTime',editAccess: true, editor: 'textfield', align: 'center',renderer: selfDateFormat}
        {text: setRequired('计划完成时间',isEditable(REPLYTOREVIEWCOMMENTS_NODE)),dataIndex: 'plannedCompleTime',width:150 ,editAccess: isEditable(REPLYTOREVIEWCOMMENTS_NODE),editor: {xtype:'datefield',format:'Y-m-d'},menuDisabled:true,
        	renderer: function(value,metaData,record,row,col,store){
        		 if(value){
                     value= selfDateFormat(value)
                 }
                 return value;
			}},
        /*{
            text: setRequired('内部版本',isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node)),
            width: 60,
            dataIndex: 'partVersion',
            align: 'center',
            editAccess:isEditable(Initiate_Trial_Node,Update_Confirm_Trial_Plan_Material_Control_Node,Update_Confirm_Trial_Plan_Submit_Node),
            editor: {xtype: 'textfield', selectOnFocus: true}
            , renderer:showTip
        },*/
    ],
    tbar: [
        {
            text: '添加行',
            iconCls: 'icon icon-add',
            disabled:!isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE),
            handler: function () {
                ctContentEditing1.cancelEdit();
                function successCallback(data) {
                    let store = ctKeyDeliverableErrorBo.getStore();
                    store.insert(store.getCount(), data);
                    ctKeyDeliverableErrorBo.getStore().reload();
                }
                function failCallback() {
                }
                sendRequest('/Windchill/ptc1/keyDeliverable/saveKeyDeliverableErrorCollection', 'POST', "application/x-www-form-urlencoded",
                    false, {branchId: branchId}, successCallback, failCallback);
            },
            scope: this
        },
        {
            text: '删除行',
            iconCls: 'icon icon-delete',
            disabled:!isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE),
            handler: function () {
                let selected = ctKeyDeliverableErrorBo.getSelectionModel().getSelection();
                if (selected.length === 0) {
                    alert('请选择数据！');
                } else {
                    function successCallback() {
                    	ctKeyDeliverableErrorBo.getStore().remove(selected);
                    	ctKeyDeliverableErrorBo.view.refresh();
                    	ctKeyDeliverableErrorBo.getStore().reload();
                    }
                    function failCallback() {
                    }
                    let param = [];
                    for (let i = 0; i < selected.length; i++) {
                        let id = selected[i].get('id');
                        if (id) {
                            param[i] = id;
                        }
                        let reviewer = selected[i].get('reviewer');
                        if(reviewer != userDisplayName){
                        	 alert('只能删除自己创建的数据！');
                        	 return ;
                        }
                        let attachmentName = selected[i].get('attachmentName');
                        if(attachmentName){
                        	alert('请先删除附件里上传的数据');
                        	return ;
                        }
                    }
                    if (param.length !== 0) {
                        sendRequest('/Windchill/ptc1/keyDeliverable/deleteKeyDeliverableErrorCollection', 'DELETE',
                            'application/json', false, JSON.stringify(param), successCallback, failCallback);
                    }
                }
            },
            scope: this
        } ,{
        	text: '导出excel模板',
            iconCls: 'icon icon-store-export',
            /*xtype: 'button',
            margin: '10 20 10 20',
            text: '下载模板',
            iconCls : 'icon icon-store-export',*/
            disabled:!isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,REPLYTOREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE),
            scope: this,
            //hidden:false,
            handler : function(){
                window.location.href = '/Windchill/template/导入评审意见模板.xlsx', '', 'width=300,height=200';
            }
        }, {

            text: '导入评审意见',
            iconCls: 'icon-excelImport',
            id: "excelInputData",
            disabled:!isEditable(CHIEFREVIEWERFEEDBACK_NODE,FILLREVIEWCOMMENTS_NODE,COMPETITIVERECEPTIONANDIMPORT_NODE),
            handler: function () {
            	uploadKeyDeliverableWindow.show();
            }
        }, {

            text: '转问题流程',
            iconCls: 'icon icon-partConfigCreate',
            id: "transferProblemProcess",
            disabled:!isEditable(CREATEPROBLEM_NODE),
            handler: function () {
            	 let selected = ctKeyDeliverableErrorBo.getSelectionModel().getSelection();
                 if (selected.length === 0) {
                     alert('请选择数据！');
                 } else if (selected.length === 1) {
                	 let rowData = selected[0].getData();
                     let transferProblem = rowData['transferProblem'];
                     let reviewer = rowData['problemConscientiouser'];
                     if(!(reviewer == userName)){
                    	 alert('只有转问题负责人才可以转');
                    	 return ;
                     }
                	 if("是" == transferProblem){
                		 transferProblemWindow.show();
                	 }else{
                		 alert('只能选择是否转问题为是的数据！');
                		 return;
                	 }
                 }else{
                	 alert('只能选择一条数据！');
                 }
            }
        }
    ],
    listeners: {
        rowclick: function (view, record, item, index, e) {
            var headerCt = view.getHeaderCt(); // 获取列头组件
            var cell = e.getTarget(view.cellSelector); // 获取点击的单元格
            var cellIndex = cell.cellIndex; // 获取单元格的索引
            var partNumber = record.get('partNumber');
            // 通过单元格索引获取列
            var column = headerCt.getGridColumns()[cellIndex + 2];
            if (column) {
                var columnName = column.dataIndex;
                if(columnName == 'supplierNumber'){
                    supplierCombo.getStore().removeAll();
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/trial/getSupplierByPartNumber?partNumber=' + partNumber,
                        method:'GET',
                        headers: {'Content-Type':'application/json'},
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=='success') {
                                var combinationNumberList = Ext.decode(response.responseText).data;
                                if(combinationNumberList){
                                    combinationNumberList.map(function(item) {
                                        supplierCombo.getStore().add({supplierInfo:item.supplierInfo});
                                    })
                                }
                            }else {
                                alert(obj.message)
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：删除信息失败，请检查网络！!');
                        }
                    });
                }
            }
        },
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
        	updateErrorCombination(editor, e);
        }
    }
});

let ctKeyDeliverableErrorCorrectionBo =  Ext.create('Ext.panel.Panel', {
    title: '3. 评审意见及改善方案纠正项',
    id:'ctKeyDeliverableErrorCorrectionBo',
    autoWidth:true,
    xtype: 'panel',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    defaults: {
        padding: '2 10 2 10',
        labelWidth: 100,
        border: false
    },
    items:[
        ctKeyDeliverableErrorBo
    ],
    listeners:{
        'afterrender': function () {
        	
        }
    }
});
//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {
    if (value != null && value != undefined && value != '') {
        var date = new Date(value);
        var time = Ext.Date.format(date, "Y-m-d")
        return time;
    }
    return value;
    
}

//导入panel
var uploadFileForm = new Ext.form.Panel({
  layout: 'form',
  id: 'uploadFileForm',
  name: 'uploadFileForm',
  width: 450,
  border: 0,
  tbar: [{
      xtype: 'filefield',
      name: 'userfile',
      id: 'userfile',
      msgTarget: 'side',
      fieldLabel: '上传Excel文件',
      width: 280,
      anchor: '100%',
      buttonText: '选择文件..',
      buttonOnly: false,
      buttonMargin: '5 5 5 5'
  }, {
      xtype: 'button',
      padding: '5 5 5 5',
      id: 'certifiedProducts_submit',
      text: '开始导入',
      handler: function () {
          var mainForm = Ext.getCmp('uploadFileForm').getForm();
          var furl = "";  //文件物理地址
          var fname = ""; //文件名称
          furl = Ext.getCmp("userfile").getValue();
          //alert(furl);
          if (furl == "") {
              alert("请先选择文件！");
              return false;
          }
          mainForm.submit({
              scope: this,
              url: '/Windchill/ptc1/keyDeliverable/importKeyDeliverable?branchId=' + branchId,
              waitMsg: '正在导入......',
              waitTitle: '请等待',
              //method : 'POST',
              success: function (form, action) {
                  var obj = action.result;
                  if (obj.success) {
                      alert("导入成功");
                      window.parent.location.reload();
                  } else {
                      alert(obj.msg);
                  }
              },
              failure: function (form, action) {
                  var obj = action.result;
                  alert(obj.msg);
              }
          });
      }
  }]
});
//导入窗口
var uploadKeyDeliverableWindow = new Ext.create('Ext.Window', {
    title: '导入问题',
    autoHeight: true,
    autoWidth: true,
    closeAction: 'hide',
    y: '10%',
    id: 'uploadKeyDeliverableWindow',
    constrain: true,
    modal: true,
    layout: 'fit',
    items: uploadFileForm
});

	 //问题添加表单
    var transferProblemForm = new Ext.form.Panel({
            xtype: 'form',
            margin: '10 0 0 0',
            border: false,
            height: 600,
            autoScroll: true,
            items: [
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [
                        {
                            xtype: 'displayfield',
                            fieldLabel: '所属产品库',
                            margin: '0 20 0 0',
                            queryMode: 'local',
                            enableRegEx: true,
                            width: 300,
                            id: 'PDMLinkProductName',
                            name: 'PDMLinkProductName',
                            labelWidth: 100,
                            value: docProductName
                        },
                    ]
                },
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题领域',
                        margin: '0 20 0 0',
                        valueField: 'groupName',
                        displayField: 'groupName',
                        multiSelect: true,
                        anyMatch: true,
                        editable: false,
                        store: [['软件', '软件'], ['硬件', '硬件'], ['工艺', '工艺'],
                            ['结构', '结构'], ['测试', '测试'], ['质量', '质量'],
                            ['采购', '采购'], ['制造', '制造'], ['市场', '市场'],
                            ['其他', '其他']],
                        width: 300,
                        id: 'problemTerritory',
                        name: 'problemTerritory',
                        labelWidth: 100,
                        listeners: {
                            change: function (e) {
                                var territory = Ext.getCmp("problemTerritory").getValue();
                                territory.indexOf("软件") != -1 ? Ext.getCmp("softwareCharger").show() : Ext.getCmp("softwareCharger").hide();
                                territory.indexOf("硬件") != -1 ? Ext.getCmp("hardwareCharger").show() : Ext.getCmp("hardwareCharger").hide();
                                territory.indexOf("工艺") != -1 ? Ext.getCmp("craftCharger").show() : Ext.getCmp("craftCharger").hide();
                                territory.indexOf("结构") != -1 ? Ext.getCmp("fabricCharger").show() : Ext.getCmp("fabricCharger").hide();
                                territory.indexOf("测试") != -1 ? Ext.getCmp("testCharger").show() : Ext.getCmp("testCharger").hide();
                                territory.indexOf("质量") != -1 ? Ext.getCmp("qualityCharger").show() : Ext.getCmp("qualityCharger").hide();
                                territory.indexOf("采购") != -1 ? Ext.getCmp("purchaseCharger").show() : Ext.getCmp("purchaseCharger").hide();
                                territory.indexOf("制造") != -1 ? Ext.getCmp("makeCharger").show() : Ext.getCmp("makeCharger").hide();
                                territory.indexOf("市场") != -1 ? Ext.getCmp("bazaarCharger").show() : Ext.getCmp("bazaarCharger").hide();
                                territory.indexOf("其他") != -1 ? Ext.getCmp("elseCharger").show() : Ext.getCmp("elseCharger").hide();
                            }
                        }
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题来源（领域）',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [['研发', '研发'], ['质量', '质量'], ['工艺', '工艺'], ['测试', '测试'],
                            ['客诉', '客诉'], ['售后质量', '售后质量'], ['制程异常', '制程异常'], ['用户体验', '用户体验']],
                        width: 300,
                        id: 'problemSource',
                        name: 'problemSource',
                        labelWidth: 100
                    }
                    ]
                },

                , {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '项目名称',
                        margin: '0 20 0 0',
                        multiSelect: false,
                       // valueField: 'projectNumber',
                        //displayField: 'name',
                        //store: projectListStore,
                        anyMatch: true,
                        editable: false,
                        width: 300,
                        id: 'projectName1',
                        name: 'projectName1',
                        labelWidth: 100,
                       /* listeners: {
                            change: function (combo, newValue, oldValue) {
                                Ext.getCmp('projectNumber1').setValue(newValue)
                            }
                        }*/
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '项目编号',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        anyMatch: true,
                        editable: false,
                        width: 300,
                        id: 'projectNumber1',
                        name: 'projectNumber1',
                        labelWidth: 100,
                    }
                    ]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '<font color=red>*</font>项目阶段',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        //valueField: 'groupName',
                        //displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        /*store: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"], ["TR4-TR4A", "TR4-TR4A"],
                            ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"],['量产阶段','量产阶段']],*/
                        width: 300,
                        id: 'projectPhase1',
                        name: 'projectPhase1',
                        labelWidth: 100
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题级别',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [['严重', '严重'], ['一般', '一般'], ['轻微', '轻微'],
                            ['N/A', 'N/A']],
                        width: 300,
                        id: 'problemGrade',
                        name: 'problemGrade',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [/*{
                    xtype: 'combo',
                    fieldLabel: '<font color=red>*</font>问题承担者',
                    margin: '0 20 0 0',
                    multiSelect: false,
                    valueField: 'userFullName',
                    displayField: 'userFullName',
                    anyMatch: true,
                    editable: false,
                    store: allUserStore_projectPlan,
                    width: 300,
                    id: 'charger',
                    name: 'charger',
                    labelWidth: 100
                },*/ {
                        xtype: 'displayfield',
                        fieldLabel: '<font color=red>*</font>问题提出者',
                        margin: '0 20 0 0',
                       // valueField: 'userFullName',
                       // displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        //store: allUserStore_projectPlan,
                        width: 300,
                        id: 'creator',
                        name: 'creator',
                        labelWidth: 100
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '<font color=red>*</font>问题来源（评审）',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        //valueField: 'groupName',
                        //displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                       /* store: [['非评审', '非评审'], ['原理图及PCB评审', '原理图及PCB评审'], ['结构评审', '结构评审'],['软件评审', '软件评审']
                            ,['总体方案评审', '总体方案评审'],['需求规格评审', '需求规格评审'],['TR评审', 'TR评审']],*/
                        width: 300,
                        id: 'problemSourceTerritory',
                        name: 'problemSourceTerritory',
                        labelWidth: 100,
                        value:docTypeName
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '<font color=red>*</font>计划完成时间',
                        margin: '0 20 0 0',
                        width: 300,
                        minValue: new Date(),
                        format: 'Y-m-d',
                        id: 'planFinishDate',
                        name: 'planFinishDate',
                        labelWidth: 100
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '相关问题编号',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'relatedProblemNumber',
                        name: 'relatedProblemNumber',
                        labelWidth: 100,
                        listeners: {
                            blur: function (e) {
                                /*var value = Ext.getCmp('relatedProblemNumber').getValue();
                                //验证编号是否正确
                                if (value != "")
                                    var isCorrect = checkProblemNumber(value);
                                if (!isCorrect) {
                                    Ext.getCmp('relatedProblemNumber').setValue("");
                                }*/
                            }
                        }
                    }
                    ]
                },
                /* {
                     layout: 'hbox',
                     border: false,
                     margin: '5 5 10 30',
                     items: [{
                         xtype: 'textfield',
                         fieldLabel: '成品编号',
                         margin: '0 20 0 0',
                         width: 300,
                         id: 'endPartNumber',
                         name: 'endPartNumber',
                         labelWidth: 100,
                         listeners: {
                             blur: function (e) {
                                 var value = Ext.getCmp('endPartNumber').getValue();
                                 //验证编号是否正确
                                 var isCorrect = checkPartNumber(value);
                                 if (!isCorrect) {
                                     Ext.getCmp('endPartNumber').setValue("");
                                 } else {
                                     //产品型号获取
                                     var productNumber = getProductNumber(value);
                                     Ext.getCmp('productNumber').setValue(productNumber);
                                 }
                             }
                         }
                     }, {
                         xtype: 'displayfield',
                         fieldLabel: '产品型号',
                         margin: '0 20 0 0',
                         width: 300,
                         id: 'productNumber',
                         name: 'productNumber',
                         labelWidth: 100
                     }
                     ]
                 },*/
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'numberfield',
                        fieldLabel: '不良比例（%）',
                        margin: '0 20 0 0',
                        width: 300,
                        minValue: 0,
                        maxValue: 100,
                        id: 'badProportion',
                        name: 'badProportion',
                        labelWidth: 100
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '风险编号',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'riskNumber',
                        name: 'riskNumber',
                        labelWidth: 100,
                        listeners: {
                            blur: function (e) {
                                /*var value = Ext.getCmp('riskNumber').getValue();
                                //验证编号是否正确
                                if (value != "")
                                    var isCorrect = checkRiskNumber(value);
                                if (!isCorrect) {
                                    Ext.getCmp('riskNumber').setValue("");
                                }*/
                            }
                        }
                    },
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>PQA',
                        id: 'pqaCheck',
                        name: 'pqaCheck',
                        margin: '0 20 0 0',
                        valueField: 'userFullName',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        store: allUserStore_projectPlan11,
                        labelWidth: 100,
                        width: 300,
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>开发代表',
                        id: 'affirmCheck',
                        name: 'affirmCheck',
                        margin: '0 20 0 0',
                        valueField: 'userFullName',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        store: allUserStore_projectPlan12,
                        labelWidth: 100,
                        width: 300,
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        layout: 'hbox',
                        border: false,
                        margin: '5 5 10 30',
                        items: [{
                            xtype: 'button',
                            text: "图片上传",
                            margin: '0 20 0 0',
                            width: 260,
                            id: 'sctp',
                            name: 'sctp',
                            handler: function () {
                                uploadImageWindow.show();
                            }
                        }]
                    }]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>问题摘要',
                        maxLength: 1200,
                        maxLengthText: "问题描述必须在500字及以内!",
                        width: 620,
                        id: 'summaryOfIssues',
                        name: 'summaryOfIssues',
                        labelWidth: 100
                    }
                    ]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>问题描述',
                        maxLength: 1200,
                        maxLengthText: "问题描述必须在1200字及以内!",
                        width: 620,
                        id: 'description',
                        name: 'description',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>初步原因分析',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "初步原因分析必须在1200字及以内!",
                        id: 'analysis',
                        name: 'analysis',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '<font color=red>*</font>初步对策',
                        margin: '0 20 0 0',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "初步对策必须在1200字及以内!",
                        id: 'optimizeStrategy',
                        name: 'optimizeStrategy',
                        labelWidth: 100
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '临时措施',
                        margin: '0 20 0 0',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "临时措施必须在1200字及以内!",
                        id: 'temporaryMeasures',
                        name: 'temporaryMeasures',
                        labelWidth: 100
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'fieldset',
                        title: '领域问题责任人',
                        // hidden:allowEdit?false:true,
                        padding: '5',
                        collapsed: true,
                        collapsible: true,
                        titleCollapse: false,
                        hideCollapseTool: false,
                        anchor: '100%',
                        defaults: {
                            padding: '2 10 2 10',
                            labelWidth: 100,
                            border: false
                        },
                        items: [
                            {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>硬件领域问题承担者',
                                    id: 'hardwareCharger',
                                    name: 'hardwareCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan1,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>软件领域问题承担者',
                                    id: 'softwareCharger',
                                    name: 'softwareCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan2,
                                    labelWidth: 130,
                                    margin: '0 0 0 30',
                                    width: 280,

                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>结构领域问题承担者',
                                    id: 'fabricCharger',
                                    name: 'fabricCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan3,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>工艺领域问题承担者',
                                    id: 'craftCharger',
                                    name: 'craftCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan4,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,

                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>测试领域问题承担者',
                                    id: 'testCharger',
                                    name: 'testCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan5,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>质量领域问题承担者',
                                    id: 'qualityCharger',
                                    name: 'qualityCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan6,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>采购领域问题承担者',
                                    id: 'purchaseCharger',
                                    name: 'purchaseCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan7,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>制造领域问题承担者',
                                    id: 'makeCharger',
                                    name: 'makeCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan8,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>市场领域问题承担者',
                                    id: 'bazaarCharger',
                                    name: 'bazaarCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan9,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>其他领域问题承担者',
                                    id: 'elseCharger',
                                    name: 'elseCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan10,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            },]
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        margin: '0 10 0 0',
                        xtype: 'button',
                        id: 'save',
                        text: '保存',
                        handler: function () {
                            var data = {
                                containerId: containerId,
                                description: Ext.getCmp('description').getValue(),
                                problemTerritory: Ext.getCmp('problemTerritory').getValue(),
                                problemGrade: Ext.getCmp('problemGrade').getValue(),
                                projectPhase1: Ext.getCmp('projectPhase1').getValue(),
                                optimizeStrategy: Ext.getCmp('optimizeStrategy').getValue(),
                                pqaCheck: Ext.getCmp('pqaCheck').getValue(),
                                //charger: Ext.getCmp('charger').getValue(),
                                creator: Ext.getCmp('creator').getValue(),
                                planFinishDate: Ext.getCmp('planFinishDate').getValue(),
                                analysis: Ext.getCmp('analysis').getValue(),
                                badProportion: Ext.getCmp('badProportion').getValue(),
                                problemSource: Ext.getCmp('problemSource').getValue(),
                                riskNumber: Ext.getCmp('riskNumber').getValue(),
                                relatedProblemNumber: Ext.getCmp('relatedProblemNumber').getValue(),
                                temporaryMeasures: Ext.getCmp('temporaryMeasures').getValue(),
                                /*endPartNumber: Ext.getCmp('endPartNumber').getValue(),
                                productNumber: Ext.getCmp('productNumber').getValue(),*/
                                softwareCharger: Ext.getCmp('softwareCharger').getValue(),
                                hardwareCharger: Ext.getCmp('hardwareCharger').getValue(),
                                craftCharger: Ext.getCmp('craftCharger').getValue(),
                                fabricCharger: Ext.getCmp('fabricCharger').getValue(),
                                testCharger: Ext.getCmp('testCharger').getValue(),
                                qualityCharger: Ext.getCmp('qualityCharger').getValue(),
                                purchaseCharger: Ext.getCmp('purchaseCharger').getValue(),
                                makeCharger: Ext.getCmp('makeCharger').getValue(),
                                bazaarCharger: Ext.getCmp('bazaarCharger').getValue(),
                                elseCharger: Ext.getCmp('elseCharger').getValue(),
                                affirmCheck: Ext.getCmp('affirmCheck').getValue(),
                                problemSourceTerritory: Ext.getCmp('problemSourceTerritory').getValue(),
                                problemInput: userDisplayName,

                                projectNumber:Ext.getCmp('projectNumber').getValue(),
                                projectName:Ext.getCmp('projectName').getRawValue(),
                                summaryOfIssues:Ext.getCmp('summaryOfIssues').getValue()
                            }


                            if (data.summaryOfIssues == "" ||data.description == "" || data.problemTerritory == null || data.problemGrade == null || data.projectPhase1 == null || data.optimizeStrategy == ""
                                || data.planFinishDate == "" || data.analysis == "" || data.problemSource == null|| data.problemSourceTerritory == null ||/* data.productNumber == "" || */data.pqaCheck == null ||
                                data.creator == null || data.affirmCheck == null) {
                                alert("弹窗中*号标识为必填项，不允许为空");
                                return;
                            }

                            var split = data.problemTerritory.toString().split(',');
                            for (let i = 0; i < split.length; i++) {
                                if (split[i] == '软件') {
                                    var value = Ext.getCmp("softwareCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '硬件') {
                                    var value = Ext.getCmp("hardwareCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '工艺') {
                                    var value = Ext.getCmp("craftCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '结构') {
                                    var value = Ext.getCmp("fabricCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '测试') {
                                    var value = Ext.getCmp("testCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '质量') {
                                    var value = Ext.getCmp("qualityCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '采购') {
                                    var value = Ext.getCmp("purchaseCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '制造') {
                                    var value = Ext.getCmp("makeCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '市场') {
                                    var value = Ext.getCmp("bazaarCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '其他') {
                                    var value = Ext.getCmp("elseCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                }
                            }

                            var t = '软件,硬件,工艺,结构,测试,质量,采购,制造,市场,其他';
                            var ts = t.split(',')
                            let newArray = [];
                            for (let i = 0; i < ts.length; i++) {
                                if (!split.includes(ts[i])) {
                                    newArray.push(ts[i]);
                                }
                                ;
                            }
                            for (let i = 0; i < newArray.length; i++) {
                                if (newArray[i] == '软件') {
                                    data.softwareCharger = '';
                                } else if (newArray[i] == '硬件') {
                                    data.hardwareCharger = '';

                                } else if (newArray[i] == '工艺') {
                                    data.craftCharger = '';

                                } else if (newArray[i] == '结构') {
                                    data.fabricCharger = '';

                                } else if (newArray[i] == '测试') {
                                    data.testCharger = '';

                                } else if (newArray[i] == '质量') {
                                    data.qualityCharger = '';

                                } else if (newArray[i] == '采购') {
                                    data.purchaseCharger = '';

                                } else if (newArray[i] == '制造') {
                                    data.makeCharger = '';

                                } else if (newArray[i] == '市场') {
                                    data.bazaarCharger = '';

                                } else if (newArray[i] == '其他') {
                                    data.elseCharger = '';
                                }
                            }
                            let selected = ctKeyDeliverableErrorBo.getSelectionModel().getSelection();
                   		    let rowData = selected[0].getData();
                   		    let approverId = rowData['id'];
                            save(data,approverId);
                            clear();
                        }
                    }, {
                        xtype: 'button',
                        id: 'close',
                        text: '取消',
                        handler: function () {
                            clear();
                            Ext.getCmp('transferProblemWindow').close();
                        }
                    }]
                }] ,listeners: {
                    'afterrender': function () {
                    	Ext.getCmp('projectName1').setValue(Ext.getCmp('projectName').getValue());
                    	Ext.getCmp('projectNumber1').setValue(Ext.getCmp('projectNumber').getValue());
                    	Ext.getCmp('projectPhase1').setValue(Ext.getCmp('projectPhase').getValue());
                    	let selected = ctKeyDeliverableErrorBo.getSelectionModel().getSelection();
               		    let rowData = selected[0].getData();
                        let plannedCompleTime = rowData['plannedCompleTime'];
                        let reviewer = rowData['reviewer'];
                        let reviewComments = rowData['reviewComments'];
                        Ext.getCmp('planFinishDate').setValue(plannedCompleTime.split("T")[0]);
                        Ext.getCmp('creator').setValue(reviewer);
                        let description = '**关键交付件评审意见转问题**\r\n' + docName + '  / ' + docNumber +' / ' + versionInfo + '\r\n评审人：' + reviewer+ '\r\n评审意见：' + reviewComments;
                        Ext.getCmp('description').setValue(description);
                        
                        Ext.getCmp('pqaCheck').setValue(Ext.getCmp('pqa').getValue());
                    }
                }
        })

var transferProblemWindow = Ext.create('Ext.Window', {
    id:'transferProblemWindow',
    title: '添加问题',
    width: 700,
    //height: 300,
    autoHeight : true,
    closeAction: 'hide',
    //closable:false,
    constrain: true,
    modal:true,
    items:[transferProblemForm],
});
