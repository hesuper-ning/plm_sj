
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
%>

<iframe id="ctBudgetCostReportIframe" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"
        src="netmarkets/jsp/ext/plm/finance/ctBudgetCostReport.jsp?oid=<%=oid%>" style="width:98%;height:900px" ></iframe>

<script type="text/javascript">
    var iframe = document.getElementById("ctBudgetCostReportIframe");
    iframe.style.height = window.innerHeight*80/100 + 'px';
</script>