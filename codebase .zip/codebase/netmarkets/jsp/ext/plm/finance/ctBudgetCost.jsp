<%@ page import="ext.plm.trialProcess.config.CtTrialProperties" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="ext.plm.finance.CtFinanceHelper" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="ext.plm.finance.config.CtFinanceProperties" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<%-- 预算成本流程表单 --%>
    <%
        String workItemOid = request.getParameter("oid");
        long branchId = 1L;
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(workItemOid).getObject();
        String currentActKey = "";
        boolean taskCompleted = false; //任务是否已完成
        long timestamp = System.currentTimeMillis();
        boolean readOnlyPage = false;
        if(obj instanceof WorkItem){
            WorkItem workItem = (WorkItem)rf.getReference(workItemOid).getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            String actName = activity.getName();
            currentActKey = CtFinanceProperties.getActivityKey(actName);
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
            WTDocument doc = ext.plm.util.CtDocUtil.getChangeRequest(workItem);
            branchId = doc.getBranchIdentifier();
        }else{
            WTDocument doc = (WTDocument)CtWTObjectUtil.getObjectByOid(workItemOid);
            if(null != doc){
                branchId =  doc.getBranchIdentifier();
            }
            readOnlyPage = true;
        }

        int year = CtFinanceHelper.getProductLifeCycle(branchId);
    %>

    <script type="text/javascript">
        var workItemOid = "<%=workItemOid%>";
        var branchId ='<%= branchId %>';
        //当前审批结点key
        var currentActKey = "<%=currentActKey%>";
        //当前的任务完成状态
        var taskCompleted = false;
        <%if(taskCompleted){%>
            taskCompleted = true;
        <%}%>
        var readOnlyPage = <%=readOnlyPage%>;
        var loadFormFlag = true;
        var year = <%=year%>;

        var fileColumnId = '';
        var fileColumnName = '';
        var uploadTableName = '';
        var gridName = '';
        var type = 'doc';
        var allowMultiple = false;
    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js/ctFinanceFunctions.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="../commonFunction/uploadFunction/ctShowFilePanel.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="../commonFunction/uploadFunction/ctUploadFilePanel.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBD001.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBD002.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBD003.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBD004.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBD005.js?_dc=<%=timestamp%>"></script>
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.apply(Ext.QuickTips.getQuickTip(), {
            dismissDelay: 120000
        });

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            width: "100%",
            height: '100%',
            items: [ {
                region: 'center',
                items:[{
                    xtype:'tabpanel',
                    activeTab: 0,
                    items:[
                        {
                            title: '<font style="font-size:12px">项目基础信息汇总表-BD001</font>',
                            xtype: 'ctBD001'
                        }
                        ,{
                            scrollable: true,
                            title: '<font style="font-size:12px">利润预算表-BD002</font>',
                            xtype: 'ctBD002'
                        }
                        ,{
                            scrollable: true,
                            title: '<font style="font-size:12px">销售毛利预算表-BD003</font>',
                            xtype: 'ctBD003'
                        }
                        ,{
                            scrollable: true,
                            title: '<font style="font-size:12px">人力费用预算表-BD004</font>',
                            xtype: 'ctBD004'
                        }
                        ,{
                            scrollable: true,
                            title: '<font style="font-size:12px">开发费用预算表-BD005</font>',
                            xtype: 'ctBD005'
                        }
                    ]
                }]
            }]
        });
    });
</script>
</body>
</html>