<%@ page import="ext.plm.trialProcess.config.CtTrialProperties" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="ext.plm.finance.CtFinanceHelper" %>
<%@ page import="ext.plm.finance.CtFinanceLogic" %>
<%@ page import="java.util.List" %>
<%@ page import="com.alibaba.fastjson.JSONObject" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<%-- 项目预算与成本报表 --%>
    <%
        String oid = request.getParameter("oid");
        long timestamp = System.currentTimeMillis();
        //当前项目的里程碑名称集合
        //List<String> milestoneNameList = CtFinanceLogic.getInstance().getMilestoneNameList(oid);
    %>

    <script type="text/javascript">
        var oid = "<%=oid%>";
        <%--var milestoneList = <%= JSONObject.toJSONString(milestoneNameList) %>;--%>
    </script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js/ctFinanceFunctions.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBB001.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBB002.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="js/ctBB003.js?_dc=<%=timestamp%>"></script>
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.apply(Ext.QuickTips.getQuickTip(), {
            dismissDelay: 120000
        });

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            width: "100%",
            height: '100%',
            items: [ {
                region: 'center',
                items:[{
                    xtype:'tabpanel',
                    activeTab: 0,
                    items:[
                        {
                            title: '<font style="font-size:12px">人力费用预算执行报表</font>',
                            xtype: 'ctBB001'
                        }
                        ,{
                            scrollable: true,
                            title: '<font style="font-size:12px">开发费用预算执行报表</font>',
                            xtype: 'ctBB002'
                        }
                        ,{
                            scrollable: true,
                            title: '<font style="font-size:12px">产品目标成本与实际成本</font>',
                            xtype: 'ctBB003'
                        }
                    ]
                }]
            }]
        });
    });
</script>
</body>
</html>