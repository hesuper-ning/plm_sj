var redStarFlag = '<font color=red bold>*</font>';//必填标志
var blueFlagStart = '<font color=blue bold><b>';//可编辑标识
var blueFlagEnd = '</b></font>';


var enter_node='enter_node'; //三江电子-研发项目预算编制与录入流程-项目预算录入
var submit_node='submit_node';//三江电子-研发项目预算变更流程-提交

var track_submit_node = 'track_submit_node';//三江-开发代表审核流程-提交


/**
 * 判断是否可编辑
 * @param node 节点表单key
 * @returns {boolean}
 */
function isEditable(...node) {
    //return true;
    if (readOnlyPage || taskCompleted) return false;
    let flag = false;
    node.forEach((item, index) => {
        if (item === currentActKey) {
            flag = true;
        }
    });
    return flag;
}

/**
 * 设为必填
 */
function setMust(field, flag) {
    // flag = true;
    if (flag)
        return redStarFlag + blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 设为可填
 */
function setRequired(field, flag) {
    // flag = true;
    if (flag)
        return blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 判断是否可编辑
 * @param node 节点表单key
 */
function disableNode(node) {
    if(taskCompleted == 'true') {
        return true;
    } else {
        if(node == currentActKey) {
            return false;
        } else {
            return true;
        }
    }
}
/**
 * 判断节点表单是否应该展开
 */
function openPanel(...node) {
    //只读页面全打开
    if(readOnlyPage) {
        return false;
    }
    if(isEditable(...node)) {
        return false;
    }else {
        return true;
    }
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion

/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    var column = e.column;//获取编辑列
    if (column.editAccess) {
        return true;
    } else {
        return false;
    }
}

function updateBD002Annex(itemId, dataKey, dataValue, callbackFn){
    var mockRec = {
        id:itemId,
        key:dataKey,
        value:dataValue
    };
    Ext.Ajax.request({
        url: '/Windchill/ptc1/finance/updateBD002Annex',
        params: {updateRecord:Ext.encode(mockRec)},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                //回调函数，一般用于后台操作成功后刷新列表
                if (callbackFn) {
                    callbackFn(response, opts);
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！!');
        }
    });
}
var showProductWindow;
function initShowProducts(type) {
    if (showProductWindow) {
        // 获取到 Store 对象
        var store = Ext.getCmp('showProductsGrid').getStore();
        // 获取到 HttpProxy 对象
        var httpProxy = store.getProxy();
        httpProxy.setUrl(`/Windchill/ptc1/finance/getProductInfo?branchId=${branchId}&type=${type}`);
        // 调用 store 的 load 方法重新加载数据
        store.load();
    }
    if (!showProductWindow) {
        var showProductsColumns = [
            {text: '产品编码',sortable: false, align: 'center',dataIndex: 'productCode', width:120, menuDisabled:true, editor:false},
            {text: '产品描述',sortable: false, align: 'center',dataIndex: 'productDescription', width:300, menuDisabled:true, editor:false},
            {text: '参数类型',sortable: false, align: 'center',dataIndex: 'parameterType', width:180, menuDisabled:true, editor:false},
            {text: year+"年",sortable: false, align: 'center',dataIndex: 'year1', width:100, menuDisabled:true, editor:false},
            {text: (year+1)+"年",sortable: false, align: 'center',dataIndex: 'year2', width:100, menuDisabled:true, editor:false},
            {text: (year+2)+"年",sortable: false, align: 'center',dataIndex: 'year3', width:100, menuDisabled:true, editor:false},
            {text: (year+3)+"年",sortable: false, align: 'center',dataIndex: 'year4', width:100, menuDisabled:true, editor:false},
            {text: (year+4)+"年",sortable: false, align: 'center',dataIndex: 'year5', width:100, menuDisabled:true, editor:false},
            {text: (year+5)+"年",sortable: false, align: 'center',dataIndex: 'year6', width:100, menuDisabled:true, editor:false}
        ];

        Ext.define('showProductsModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'productCode', "productDescription", 'parameterType', 'year1',
                'year2','year3','year4','year5','year6'
            ],
            idProperty: 'id'
        });

        var showProductsStore = Ext.create('Ext.data.Store', {
            model: 'showProductsModel',
            id: 'showProductsStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getProductInfo?branchId='+branchId+'&type='+type,
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    messageProperty: 'message'
                }
            }),
            autoLoad: true,
        });
        var showProductsGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var showProductsGrid = Ext.create('Ext.grid.Panel', {
            plugins: [showProductsGridEditing],
            store: showProductsStore,
            columns: showProductsColumns,
            id: 'showProductsGrid',
            autoWidth: true,
            columnLines: true,
            width: '100%',
            height: '100%',
            height: 300,
            multiSelect: false,
            autoScroll: true,
            forceFit: false,
            viewConfig: {
                enableTextSelection: true
            }
            //,
            // selModel: {
            //     type: "checkboxmodel",
            //     mode: 'SINGLE'//单选
            //     // mode: 'MULTI'//多选
            // }
        });

        showProductWindow = Ext.create('Ext.Window', {
            id: 'showFile',
            title: '产品信息',
            width: 800,
            //height: 300,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [showProductsGrid],
        });
    }
    return showProductWindow;
}

/**
 * 导出
 */
function exportBD() {
    // 获取XMLHttpRequest
    var xmlHttpRequest = new XMLHttpRequest();
    //  发起请求
    xmlHttpRequest.open("POST", '/Windchill/ptc1/finance/exportBD?branchId=' + branchId, true);
    // 设置请求头类型
    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
    xmlHttpRequest.responseType = "blob";
    //  返回
    xmlHttpRequest.onload = function (oEvent) {
        var content = xmlHttpRequest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).message)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            var fileNamePrefix = '项目预算';
            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }
    };
    xmlHttpRequest.send();
}

/**
 * 对Request封装
 * @Param url 请求url
 * @Param method 请求方法'GET' 'POST'
 * @Param async true 请求异步 false 请求步
 * @Param object
 * @Param callback 回调方法
 */
function sendRequest(url, method, headers, async, params, successCallback, failCallback) {
    Ext.Ajax.request({
        scope: this,
        url: url,
        method: method,
        timeout: 600000,
        async: async,
        headers: {'Content-Type': headers},
        params: params,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
                if (failCallback) {
                    failCallback();
                }
            } else {
                if (successCallback) {
                    successCallback(obj.data);
                }
            }
        },
        failure: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj && obj['message']) {
                Ext.Msg.alert('错误', obj['message']);
            } else {
                Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
            }
            if (failCallback != null && failCallback !== '') {
                failCallback();
            }
        }
    }); //~End of Ajax request
}

/**
 * 更新产品目标成本分解与跟踪表
 * @param editor
 * @param e
 */
function updateTargetCost(editor, e, successCallback) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/finance/updateTargetCost', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

/**
 * 千分位显示
 * @param num
 * @returns {string}
 */
function formatAmount(num) {
    var parts = num.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}