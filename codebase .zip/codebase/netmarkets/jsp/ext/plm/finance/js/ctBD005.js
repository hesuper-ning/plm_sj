Ext.define('PLM.view.ctBD005', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctBD005',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctBD005',
    initComponent: function () {

        Ext.define('BD005Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'costType', "summary", 'extraMilestoneBudget', 'startTr2',
                'tr2Pdcp', 'pdcpTr4', 'tr4Tr5', 'tr5Tr6', 'tr6End'
            ],
            idProperty: 'id'
        });

        var BD005Columns = [
            {
                text: '费用类型',
                sortable: false,
                align: 'center',
                dataIndex: 'costType',
                width:200,
                menuDisabled:true,
                editor:false,
                renderer: function (value,metaData) {
                    if (value != null && value != undefined && value != '') {
                        let tip;
                        if(value=='产品检测费'){
                            tip = '<span style="color:#121280;">质量监督检验机构对企业产品进行监督检验时，向被检单位收取的费用，包括：测试费、标志费、认证费等。</span>';
                        }else if(value=='产品试制模具费'){
                            tip = '<span style="color:#121280;">企业委托外单位制作模具发生的费用，包括手板费、模型款等。</span>';
                        }else if(value=='公杂费'){
                            tip = '<span style="color:#121280;">主要包含办公费、差旅费、车辆费、交通费、招待费、印刷费、运输费、会议费等。</span>';
                        }else if(value=='技术协作费'){
                            tip = '<span style="color:#121280;">企业在研发过程中，由于自身专业或力量限制无法完成的部分,通过协作的方式交由其他单位协助完成项目而支付的一定费用。</span>';
                        }else if(value=='开发材料费'){
                            tip = '<span style="color:#121280;">企业用于研究开发新产品、新技术所购买的材料而发生的费用，包括印制电路板费等。</span>';
                        }else if(value=='其他'){
                            tip = '<span style="color:#121280;">分类中未包含的其他费用，主要包括销售推广费，会议费等。</span>';
                        }else if(value=='物料消耗'){
                            tip = '<span style="color:#121280;">产品研发、生产过程中费用化的原材料消耗。</span>';
                        }else if(value=='专利登记及年费'){
                            tip = '<span style="color:#121280;">企业申请授予专利权后，在办理登记手续时应缴纳的专利登记费和授予专利当年的年费。</span>';
                        }else if(value=='间接费用'){
                            tip = '<span style="color:#121280;">主要指资产计提的折旧或摊销。</span>';
                        }else{
                            tip = '<span style="color:#121280;">' + value + '</span>';
                        }
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + tip + "'";
                        return value;
                    }
                    return value;
                }
            },
            {
                text: '汇总',
                sortable: false,
                align: 'center',
                dataIndex: 'summary',
                width: 150,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: '里程碑外预算',
                sortable: false,
                align: 'center',
                dataIndex: 'extraMilestoneBudget',
                width: 150,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'Start-TR2',
                sortable: false,
                align: 'center',
                dataIndex: 'startTr2',
                width: 150,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'TR2-PDCP',
                sortable: false,
                align: 'center',
                dataIndex: 'tr2Pdcp',
                width: 150,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'PDCP-TR4',
                sortable: false,
                align: 'center',
                dataIndex: 'pdcpTr4',
                width: 150,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'TR4-TR5',
                sortable: false,
                align: 'center',
                dataIndex: 'tr4Tr5',
                width: 150,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'TR5-TR6',
                sortable: false,
                align: 'center',
                dataIndex: 'tr5Tr6',
                width: 150,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'TR6-End',
                sortable: false,
                align: 'center',
                dataIndex: 'tr6End',
                width: 150,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            }
        ];

        var BD005Store = Ext.create('Ext.data.Store', {
            model: 'BD005Model',
            id: 'BD005Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBD005?branchId=' + branchId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var BD005GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BD005Grid = Ext.create('Ext.grid.Panel', {
            plugins: [BD005GridEditing],
            store: BD005Store,
            columns: BD005Columns,
            id:'BD005Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
            tbar: [
                // {
                //     xtype: 'button',
                //     text: '下载导入模板',
                //     buttonOnly: true,
                //     id: 'downloadBD005Template',
                //     iconCls: 'icon-download',
                //     //hidden: downloadECAEBOM?false:true,
                //     handler: function () {
                //         window.location.href = '/Windchill/ptc1/finance/downLoadTemplate?templateName=开发费用预算表-BD005导入模板';
                //     }
                // },
                // {
                //     xtype:'filefield',
                //     buttonOnly: true,
                //     id:'upload-BD005',
                //     hideLabel: true,
                //     //hidden: ecaEBOMuploadECAEBOM?false:true,
                //     buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入数据</span>',
                //     allowBlank: false,
                //     scope: this,
                //     listeners:{
                //         'change':function(fb, newValue, oldValue, opts){
                //             if(!newValue){
                //                 return;
                //             }
                //             var file = document.querySelector('[id=upload-BD005-button-fileInputEl]');
                //             var formData = new FormData();
                //             formData.append('upload-BD005-button-fileInputEl', file.files[0]);
                //             fb.reset();//清空表单的值
                //             var myMask = new Ext.LoadMask({
                //                 msg: '正在导入数据，请稍候......',
                //                 target: BD005Grid
                //             });
                //             myMask.show();
                //             $.ajax({
                //                 url: '/Windchill/ptc1/finance/importBD?branchId=' + branchId + '&tabName=BD005',
                //                 type: 'POST',
                //                 cache: false,
                //                 data: formData,
                //                 processData: false,
                //                 contentType: false
                //             }).done(function(res) {
                //                 myMask.hide();
                //                 var obj = Ext.decode(res);
                //                 var success = obj['success'];
                //                 var msg = obj['msg'];
                //                 if(!success){
                //                     alert(msg);
                //                 }
                //                 BD005Grid.getStore().load();
                //             }).fail(function(res) {
                //                 var obj = Ext.decode(res);
                //                 var msg = obj['msg'];
                //                 myMask.hide();
                //                 alert('导入失败！\n'+msg) ;
                //             });
                //         }
                //     }
                // }
            ]
        });

        this.items = [
            BD005Grid
        ];
        this.callParent();
    }
});




