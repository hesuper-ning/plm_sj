Ext.define('PLM.view.ctBB002', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctBB002',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctBB002',
    initComponent: function () {
        var BB002Fields = ['id', 'costType', "budgetAmount", 'actualAmount', 'implementationRate',
            "budgetAmount1", 'actualAmount1', 'implementationRate1'
            ];
        //动态列
        // let dataIndexArray = [];
        // for(let i = 0;i < milestoneList.length;i++){
        //     dataIndexArray.push('budgetAmount' + (i+2));
        //     dataIndexArray.push('actualAmount' + (i+2));
        //     dataIndexArray.push('implementationRate' + (i+2));
        // }
        // Array.prototype.push.apply(BB002Fields, dataIndexArray);

        Ext.define('BB002Model', {
            extend: 'Ext.data.Model',
            fields: BB002Fields,
            idProperty: 'id'
        });

        var BB002Columns = [
            {text: '费用类型',sortable: false, align: 'center',dataIndex: 'costType', width:120, menuDisabled:true, editor:false},
            {
                text: '汇总',
                columns:[
                    {
                        text: '预算金额',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budgetAmount',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '执行金额',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'actualAmount',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算执行率',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'implementationRate',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    }
                ]
            },
            // {
            //     text: '里程碑外预算与成本',
            //     columns:[
            //         {text: '预算金额',sortable: false, align: 'center',dataIndex: 'budgetAmount1', width:80, menuDisabled:true, editor:false},
            //         {text: '执行金额',sortable: false, align: 'center',dataIndex: 'actualAmount1', width:80, menuDisabled:true, editor:false},
            //         {text: '预算执行率',sortable: false, align: 'center',dataIndex: 'implementationRate1', width:80, menuDisabled:true, editor:false}
            //     ]
            // }
        ];

        //动态列
        // let j = 1;
        // milestoneList.forEach(milestone => {
        //     j = j+1;
        //     BB002Columns.push(
        //         {
        //             text: milestone,
        //             columns:[
        //                 {text: '预算金额',sortable: false, align: 'center',dataIndex: 'budgetAmount'+j, width:80, menuDisabled:true, editor:false},
        //                 {text: '执行金额',sortable: false, align: 'center',dataIndex: 'actualAmount'+j, width:80, menuDisabled:true, editor:false},
        //                 {text: '预算执行率',sortable: false, align: 'center',dataIndex: 'implementationRate'+j, width:80, menuDisabled:true, editor:false}
        //             ]
        //         }
        //     )
        // });

        var BB002Store = Ext.create('Ext.data.Store', {
            model: 'BB002Model',
            id: 'BB002Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBudgetReport?reportType=getDevelopmentCostBudget&oid=' + oid,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var BB002GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BB002Grid = Ext.create('Ext.grid.Panel', {
            plugins: [BB002GridEditing],
            store: BB002Store,
            columns: BB002Columns,
            id:'BB002Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
        });

        this.items = [
            BB002Grid
        ];
        this.callParent();
    }
});




