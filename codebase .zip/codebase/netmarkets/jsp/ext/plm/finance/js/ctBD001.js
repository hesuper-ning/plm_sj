Ext.define('PLM.view.ctBD001', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctBD001',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctBD001',
    initComponent: function () {

        Ext.define('BD001Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'project', "predictedSituation", 'company', 'remarks'
            ],
            idProperty: 'id'
        });

        var BD001Columns = [
            {text: '项目',sortable: false, align: 'center',dataIndex: 'project', width:180, menuDisabled:true, editor:false},
            {text: '预测情况',sortable: false, align: 'center',dataIndex: 'predictedSituation', width:300, menuDisabled:true, editor:false},
            //{text: '单位',sortable: false, align: 'center',dataIndex: 'company', width:180, menuDisabled:true, editor:false},
            {text: '备注',sortable: false, align: 'center',dataIndex: 'remarks', width:600, menuDisabled:true, editor:false}
        ];

        var BD001Store = Ext.create('Ext.data.Store', {
            model: 'BD001Model',
            id: 'BD001Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBD001?branchId=' + branchId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var BD001GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BD001Grid = Ext.create('Ext.grid.Panel', {
            plugins: [BD001GridEditing],
            store: BD001Store,
            columns: BD001Columns,
            id:'BD001Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '下载导入模板',
                    buttonOnly: true,
                    id: 'downloadBD001Template',
                    iconCls: 'icon-download',
                    hidden: !isEditable(enter_node,submit_node),
                    handler: function () {
                        window.location.href = '/Windchill/ptc1/finance/downLoadTemplate?templateName=PLM研发预算导入模板';
                    }
                },
                {
                    xtype:'filefield',
                    buttonOnly: true,
                    id:'upload-BD001',
                    hideLabel: true,
                    hidden: !isEditable(enter_node,submit_node),
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入数据</span>',
                    allowBlank: false,
                    scope: this,
                    listeners:{
                        'change':function(fb, newValue, oldValue, opts){
                            if(!newValue){
                                return;
                            }
                            var file = document.querySelector('[id=upload-BD001-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('upload-BD001-button-fileInputEl', file.files[0]);
                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在导入数据，请稍候......',
                                target: BD001Grid
                            });
                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/finance/importBD?branchId=' + branchId + '&tabName=BD001',
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function(res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if(!success){
                                    alert(msg);
                                }
                                //刷新整个页面，重置其他页签的表头
                                location.reload();
                                //BD001Grid.getStore().load();
                            }).fail(function(res) {
                                var obj = Ext.decode(res);
                                var msg = obj['msg'];
                                myMask.hide();
                                alert('导入失败！\n'+msg) ;
                            });
                        }
                    }
                },
                {
                    text: '导出',
                    iconCls: 'icon icon-excelExport',
                    //disabled: !isEditable(maintenance_bom_node),
                    handler: function () {
                        let count = Ext.getStore('BD001Store').getCount();
                        if (count == 0) {
                            Ext.Msg.alert('提示', '请先导入数据！');
                            return;
                        }
                        //导出
                        exportBD();
                    },
                    scope: this
                }
            ]
        });

        this.items = [
            BD001Grid
        ];
        this.callParent();
    }
});




