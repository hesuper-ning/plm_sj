Ext.define('PLM.view.ctBD002', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctBD002',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctBD002',
    initComponent: function () {
        Ext.define('BD002AnnexModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'annex', "remarks"
            ],
            idProperty: 'id'
        });

        var BD002AnnexColumns = [
            {
                text: setRequired('附件', isEditable(enter_node, submit_node)),
                xtype:'actioncolumn',
                width: 200,
                sortable: false,
                align: 'center',
                dataIndex: 'annex',
                menuDisabled:true,
                editor:false,
                items: [
                    {
                        iconCls: 'icon icon-uploadImage',
                        tooltip: '添加文件',
                        hidden:!isEditable(enter_node,submit_node),
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'annex';
                            uploadTableName = 'ZFinanceBD002AnnexTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'BD002AnnexGrid';
                            allowMultiple = true;
                            var uploadFileWindow = initUploadFileWindow();
                            uploadFileWindow.show()

                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {}
                    },
                    '-',
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看文件',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            fileColumnId = record.get('id');
                            fileColumnName = 'annex';
                            uploadTableName = 'ZFinanceBD002AnnexTable';
                            //设置grid名称用于上传文件后刷新数据
                            gridName = 'BD002AnnexGrid';
                            var showFiles = initShowFiles();

                            // if(disableNode(submit_node)){
                            //     Ext.getCmp('showDelete').show();
                            // }else {
                            //     Ext.getCmp('showDelete').hide();
                            // }
                            showFiles.show()
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item,record) {
                            var boolean = record.data['annex'];
                            if(boolean!=null) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            },
            {
                text: setRequired('备注', isEditable(enter_node, submit_node)),
                width: 500,
                sortable: false,
                align: 'center',
                dataIndex: 'remarks',
                menuDisabled:true,
                editAccess: isEditable(enter_node, submit_node),
                editor: 'textfield'
            }
        ];

        var BD002AnnexStore = Ext.create('Ext.data.Store', {
            model: 'BD002AnnexModel',
            id: 'BD002AnnexStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBD002Annex?branchId=' + branchId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var BD002AnnexGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BD002AnnexGrid = Ext.create('Ext.grid.Panel', {
            plugins: [BD002AnnexGridEditing],
            store: BD002AnnexStore,
            columns: BD002AnnexColumns,
            id:'BD002AnnexGrid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
            tbar: []
        });

        BD002AnnexGrid.on('beforeedit', function (editor, e) {
            let field = e.field;
            let value = e.value;
            let record = e.record;
            return checkEditAccess(e);
        });

        BD002AnnexGrid.on('edit', function (editor, e) {
            let record = e.record; // 得到当前行所有数据
            let field = e.field;   // 得到修改列
            let value = e.value;   // 得到修改列修改后的值
            let oldValue = e.originalValue; // 旧值
            let id = record.get('id');
            if (value === oldValue) {
                record.reject();
                return; // 没有修改内容则返回
            }
            var callbackFn = function (response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.message=='success') {
                    var obj = Ext.decode(response.responseText);
                    e.record.commit();
                    Ext.getStore('BD002AnnexStore').load();
                }else {
                    alert(obj.message)
                }
            };
            updateBD002Annex(id, field, value, callbackFn);
        });

        Ext.define('BD002Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'project', "lifeCycle0", 'lifeCycle1', 'lifeCycle2', 'lifeCycle3', 'lifeCycle4', 'lifeCycle5',
                'total', 'remarks'
            ],
            idProperty: 'id'
        });

        var BD002Columns = [
            {text: '项目',sortable: false, align: 'center',dataIndex: 'project', width: 200, menuDisabled:true, editor:false},
            {
                text: year + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'lifeCycle0',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 1) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'lifeCycle1',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 2) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'lifeCycle2',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 3) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'lifeCycle3',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 4) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'lifeCycle4',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 5) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'lifeCycle5',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: '合计',
                sortable: false,
                align: 'center',
                dataIndex: 'total',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {text: '备注',sortable: false, align: 'center',dataIndex: 'remarks', width: 180, menuDisabled:true, editor:false},
            {
                text: '查看产品',
                xtype:'actioncolumn',
                sortable: false,
                align: 'center',
                width: 100,
                menuDisabled:true,
                editor:false,
                items: [
                    {
                        iconCls: 'icon-showInfo',
                        tooltip: '查看产品',
                        handler: function(grid, rowIndex, colIndex) {
                            var record = grid.getStore().getAt(rowIndex);
                            //设置当前列的id与列名和表名
                            let type = record.get('project');
                            var showProduct = initShowProducts(type);
                            showProduct.show()
                        },
                        isDisabled: function (view ,rowIndex,colIndex, item, record) {
                            let project = record.data['project'];
                            if(project.indexOf('销售收入') > -1 || project.indexOf('直销收入') > -1
                                || project.indexOf('经销收入') > -1 || project.indexOf('销售成本') > -1) {
                                return false;
                            }
                            return true;
                        }
                    }
                ]
            }
        ];

        var BD002Store = Ext.create('Ext.data.Store', {
            model: 'BD002Model',
            id: 'BD002Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBD002?branchId=' + branchId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var BD002GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BD002Grid = Ext.create('Ext.grid.Panel', {
            plugins: [BD002GridEditing],
            store: BD002Store,
            columns: BD002Columns,
            id:'BD002Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
            margin: '20, 0, 0, 0',
            tbar: [
                // {
                //     xtype: 'button',
                //     text: '下载导入模板',
                //     iconCls: 'icon icon-download',
                //     //hidden: downloadECAEBOM?false:true,
                //     handler: function () {
                //         window.location.href = '/Windchill/ptc1/finance/downLoadTemplate?templateName=利润预算表-BD002导入模板';
                //     }
                // },
                // {
                //     xtype:'filefield',
                //     buttonOnly: true,
                //     id:'upload-BD002',
                //     hideLabel: true,
                //     //hidden: ecaEBOMuploadECAEBOM?false:true,
                //     buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入数据</span>',
                //     allowBlank: false,
                //     scope: this,
                //     listeners:{
                //         'change':function(fb, newValue, oldValue, opts){
                //             if(!newValue){
                //                 return;
                //             }
                //             var file = document.querySelector('[id=upload-BD002-button-fileInputEl]');
                //             var formData = new FormData();
                //             formData.append('upload-BD002-button-fileInputEl', file.files[0]);
                //             fb.reset();//清空表单的值
                //             var myMask = new Ext.LoadMask({
                //                 msg: '正在导入数据，请稍候......',
                //                 target: BD002Grid
                //             });
                //             myMask.show();
                //             $.ajax({
                //                 url: '/Windchill/ptc1/finance/importBD?branchId=' + branchId + '&tabName=BD002',
                //                 type: 'POST',
                //                 cache: false,
                //                 data: formData,
                //                 processData: false,
                //                 contentType: false
                //             }).done(function(res) {
                //                 myMask.hide();
                //                 var obj = Ext.decode(res);
                //                 var success = obj['success'];
                //                 var msg = obj['msg'];
                //                 if(!success){
                //                     alert(msg);
                //                 }
                //                 BD002Grid.getStore().load();
                //             }).fail(function(res) {
                //                 var obj = Ext.decode(res);
                //                 var msg = obj['msg'];
                //                 myMask.hide();
                //                 alert('导入失败！\n'+msg) ;
                //             });
                //         }
                //     }
                // }
            ]
        });

        this.items = [
            BD002AnnexGrid,BD002Grid
        ];
        this.callParent();
    }
});




