Ext.define('PLM.view.ctBB001', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctBB001',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctBB001',
    initComponent: function () {
        var BB001Fields = ['id', 'type1', "type2", 'plannedWorkingHours', 'actualWorkingHours',
            'utilizationRate', 'budgetAmount', 'actualAmount', 'implementationRate',
            'plannedWorkingHours1', 'actualWorkingHours1', 'utilizationRate1', 'budgetAmount1',
            'actualAmount1', 'implementationRate1'];
        //动态列
        // let dataIndexArray = [];
        // for(let i = 0;i < milestoneList.length;i++){
        //     dataIndexArray.push('plannedWorkingHours' + (i+2));
        //     dataIndexArray.push('actualWorkingHours' + (i+2));
        //     dataIndexArray.push('utilizationRate' + (i+2));
        //     dataIndexArray.push('budgetAmount' + (i+2));
        //     dataIndexArray.push('actualAmount' + (i+2));
        //     dataIndexArray.push('implementationRate' + (i+2));
        // }
        // Array.prototype.push.apply(BB001Fields, dataIndexArray);

        Ext.define('BB001Model', {
            extend: 'Ext.data.Model',
            fields: BB001Fields,
            idProperty: 'id'
        });

        var BB001Columns = [
            {
                text: '工程师分类',
                columns:[
                    {text: '',sortable: false, align: 'center',dataIndex: 'type1', width:120, menuDisabled:true, editor:false},
                    {text: '',sortable: false, align: 'center',dataIndex: 'type2', width:120, menuDisabled:true, editor:false},
                ]
            },
            {
                text: '汇总',
                columns:[
                    {
                        text: '计划工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'plannedWorkingHours',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '实际工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'actualWorkingHours',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '工时使用率',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'utilizationRate',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算金额',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budgetAmount',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '实际金额',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'actualAmount',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算执行率',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'implementationRate',
                        width: 80,
                        menuDisabled: true,
                        editor: false,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    }
                ]
            },
            // {
            //     text: '里程碑外阶段',
            //     columns:[
            //         {text: '计划工时',sortable: false, align: 'center',dataIndex: 'plannedWorkingHours1', width:80, menuDisabled:true, editor:false},
            //         {text: '实际工时',sortable: false, align: 'center',dataIndex: 'actualWorkingHours1', width:80, menuDisabled:true, editor:false},
            //         {text: '工时使用率',sortable: false, align: 'center',dataIndex: 'utilizationRate1', width:80, menuDisabled:true, editor:false},
            //         {text: '预算金额',sortable: false, align: 'center',dataIndex: 'budgetAmount1', width:80, menuDisabled:true, editor:false},
            //         {text: '实际金额',sortable: false, align: 'center',dataIndex: 'actualAmount1', width:80, menuDisabled:true, editor:false},
            //         {text: '预算执行率',sortable: false, align: 'center',dataIndex: 'implementationRate1', width:80, menuDisabled:true, editor:false}
            //     ]
            // }
        ];

        //动态列
        // let j = 1;
        // milestoneList.forEach(milestone => {
        //     j = j+1;
        //     BB001Columns.push(
        //         {
        //             text: milestone,
        //             columns:[
        //                 {text: '计划工时',sortable: false, align: 'center',dataIndex: 'plannedWorkingHours'+j, width:80, menuDisabled:true, editor:false},
        //                 {text: '实际工时',sortable: false, align: 'center',dataIndex: 'actualWorkingHours'+j, width:80, menuDisabled:true, editor:false},
        //                 {text: '工时使用率',sortable: false, align: 'center',dataIndex: 'utilizationRate'+j, width:80, menuDisabled:true, editor:false},
        //                 {text: '预算金额',sortable: false, align: 'center',dataIndex: 'budgetAmount'+j, width:80, menuDisabled:true, editor:false},
        //                 {text: '实际金额',sortable: false, align: 'center',dataIndex: 'actualAmount'+j, width:80, menuDisabled:true, editor:false},
        //                 {text: '预算执行率',sortable: false, align: 'center',dataIndex: 'implementationRate'+j, width:80, menuDisabled:true, editor:false}
        //             ]
        //         }
        //     )
        // });

        var BB001Store = Ext.create('Ext.data.Store', {
            model: 'BB001Model',
            id: 'BB001Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBudgetReport?reportType=getHumanResourceBudget&oid=' + oid,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true
        });

        var BB001GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BB001Grid = Ext.create('Ext.grid.Panel', {
            plugins: [BB001GridEditing],
            store: BB001Store,
            columns: BB001Columns,
            id:'BB001Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
        });

        this.items = [
            BB001Grid
        ];
        this.callParent();
    }
});




