Ext.define('PLM.view.ctTargetCost', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctTargetCost',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctTargetCost',
    initComponent: function () {

        Ext.define('targetCostModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'partNumber', "partDesc", 'costProject', 'charterCost', 'pdcpCost', 'tr2Cost', 'tr4Cost' , 'tr5Cost', 'tr6Cost'
                ,'stepCount' ,'targetLadder', 'stepCost'
            ],
            idProperty: 'id'
        });

        var targetCostColumns = [
            {
                text: setMust('成品编码', isEditable(track_submit_node)),
                sortable: false,
                align: 'center',
                dataIndex: 'partNumber',
                width:120,
                menuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            },
            {text: '成品描述',sortable: false, align: 'center',dataIndex: 'partDesc', width:200, menuDisabled:true, editAccess:false},
            {
                text: setRequired('成本项目', isEditable(track_submit_node)),
                sortable: false,
                align: 'center',
                dataIndex: 'costProject',
                width:120,
                menuDisabled:true,
                editAccess: true,
                editor:{
                    xtype: 'combo',
                    editable: false,
                    typeAhead: false,
                    store : [['BOM成本-电子','BOM成本-电子'],['BOM成本-结构', 'BOM成本-结构'],['BOM成本-包装', 'BOM成本-包装']
            ,['BOM成本-其他', 'BOM成本-其他'],['制造成本-委外加工', '制造成本-委外加工'],['制造成本-制造费用', '制造成本-制造费用']],
                    mode : 'local'
                },
            },
            {
                text: setRequired('Charter目标成本', isEditable(track_submit_node)),
                sortable: false,
                align: 'center',
                dataIndex: 'charterCost',
                width:120,
                menuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            },
            {
                text: setRequired('PDCP成本', isEditable(track_submit_node)),
                sortable: false, align: 'center',dataIndex: 'pdcpCost', width:120,
                enuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            },
            {
                text: setRequired('TR2成本', isEditable(track_submit_node)),
                sortable: false,
                align: 'center',dataIndex: 'tr2Cost', width:120,
                menuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            },
            {
                text: setRequired('TR4成本', isEditable(track_submit_node)),
                sortable: false,
                align: 'center',dataIndex: 'tr4Cost', width:120,
                menuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            },
            {
                text: setRequired('TR5成本', isEditable(track_submit_node)),
                sortable: false, align: 'center',dataIndex: 'tr5Cost',
                width:120, menuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            },
            {
                text: setRequired('TR6成本', isEditable(track_submit_node)),
                sortable: false, align: 'center',
                dataIndex: 'tr6Cost', width:120, menuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            },
            {
                text: setRequired('阶梯数量', isEditable(track_submit_node)),
                sortable: false, align: 'center',dataIndex: 'stepCount',
                width:120,
                menuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            },
            {
                text: setRequired('是否目标阶梯', isEditable(track_submit_node)),
                sortable: false,
                align: 'center',
                dataIndex: 'targetLadder',
                width:120,
                menuDisabled:true,
                editAccess: true,
                editor:{
                    xtype: 'combo',
                    editable : false,
                    typeAhead:false,
                    store : [['是', '是'],['否', '否']],
                    mode : 'local'
                },
            },
            {
                text: setRequired('阶梯成本', isEditable(track_submit_node)),
                sortable: false, align: 'center',
                dataIndex: 'stepCost',
                width:120, menuDisabled:true,
                editAccess: true,
                editor: {xtype: 'textfield', selectOnFocus: true}
            }
        ];

        var targetCostStore = Ext.create('Ext.data.Store', {
            model: 'targetCostModel',
            id: 'targetCostStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getTargetCost?branchId=' + branchId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var targetCostGridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var targetCostGrid = Ext.create('Ext.grid.Panel', {
            plugins: [targetCostGridEditing],
            store: targetCostStore,
            columns: targetCostColumns,
            id:'targetCostGrid',
            autoWidth: true,
            columnLines: true,
            height:450,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            selType: 'checkboxmodel',
            tbar: [
                {
                    xtype: 'button',
                    text: '下载导入模板',
                    buttonOnly: true,
                    id: 'downloadTargetCostTemplate',
                    iconCls: 'icon-download',
                    hidden: !isEditable(track_submit_node),
                    handler: function () {
                        window.location.href = '/Windchill/ptc1/finance/downLoadTemplate?templateName=产品目标成本分解与跟踪表导入模板';
                    }
                },
                {
                    xtype:'filefield',
                    buttonOnly: true,
                    id:'upload-TargetCost',
                    hideLabel: true,
                    hidden: !isEditable(track_submit_node),
                    buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入数据</span>',
                    allowBlank: false,
                    scope: this,
                    listeners:{
                        'change':function(fb, newValue, oldValue, opts){
                            if(!newValue){
                                return;
                            }
                            var file = document.querySelector('[id=upload-TargetCost-button-fileInputEl]');
                            var formData = new FormData();
                            formData.append('upload-TargetCost-button-fileInputEl', file.files[0]);
                            fb.reset();//清空表单的值
                            var myMask = new Ext.LoadMask({
                                msg: '正在导入数据，请稍候......',
                                target: targetCostGrid
                            });
                            myMask.show();
                            $.ajax({
                                url: '/Windchill/ptc1/finance/importBD?branchId=' + branchId + '&tabName=targetCost',
                                type: 'POST',
                                cache: false,
                                data: formData,
                                processData: false,
                                contentType: false
                            }).done(function(res) {
                                myMask.hide();
                                var obj = Ext.decode(res);
                                var success = obj['success'];
                                var msg = obj['msg'];
                                if(!success){
                                    alert(msg);
                                }
                                //刷新整个页面，重置其他页签的表头
                                targetCostGrid.getStore().load();
                            }).fail(function(res) {
                                var obj = Ext.decode(res);
                                var msg = obj['msg'];
                                myMask.hide();
                                alert('导入失败！\n'+msg) ;
                            });
                        }
                    }
                },
                // {
                //     text: '导出',
                //     iconCls: 'icon icon-excelExport',
                //     //disabled: !isEditable(maintenance_bom_node),
                //     handler: function () {
                //         let count = Ext.getStore('BD001Store').getCount();
                //         if (count == 0) {
                //             Ext.Msg.alert('提示', '请先导入数据！');
                //             return;
                //         }
                //         //导出
                //         exportBD();
                //     },
                //     scope: this
                // }
                {
                    text: '添加行',
                    iconCls: 'icon icon-add',
                    disabled: !isEditable(track_submit_node),
                    handler: function () {
                        targetCostGridEditing.cancelEdit();
                        function successCallback(data) {
                            let store = targetCostGrid.getStore();
                            store.insert(store.getCount(), data);
                        }
                        function failCallback() {
                        }
                        sendRequest('/Windchill/ptc1/finance/saveTargetCost', 'POST', "application/x-www-form-urlencoded",
                            false, {branchId: branchId}, successCallback, failCallback);
                    },
                    scope: this
                },
                {
                    text: '删除行',
                    iconCls: 'icon icon-delete',
                    disabled:!isEditable(track_submit_node),
                    handler: function () {
                        let selected = targetCostGrid.getSelectionModel().getSelection();
                        if (selected.length === 0) {
                            alert('请选择数据！');
                        } else {
                            function successCallback() {
                                targetCostGrid.getStore().remove(selected);
                                targetCostGrid.view.refresh();
                            }

                            function failCallback() {
                            }
                            let param = [];
                            for (let i = 0; i < selected.length; i++) {
                                let id = selected[i].get('id');
                                if (id) {
                                    param[i] = id;
                                }
                            }
                            if (param.length !== 0) {
                                sendRequest('/Windchill/ptc1/finance/deleteTargetCost', 'DELETE',
                                    'application/json', false, JSON.stringify(param), successCallback, failCallback);
                            }
                        }
                    },
                    scope: this
                }
            ],
            listeners:{
                beforeedit: function (editor, e) {
                    var r = e.record; // 得到当前行所有数据
                    var f = e.field; // 得到修改列
                    var v = e.value; // 得到修改列修改后值

                    if(f == 'stepCount' || f == 'targetLadder' || f == 'stepCost'){
                        let costProject = r.get('costProject');
                        if(!costProject){
                            Ext.Msg.alert('提示', '请先选择“成本项目”！');
                            return false;
                        }
                        if(costProject.indexOf('BOM成本') > -1){
                            return false;
                        }
                    }
                    return checkEditAccess(e);
                },
                edit: function (editor, e) {
                    function successCallback(data) {
                        targetCostGrid.getStore().reload();
                    }
                    updateTargetCost(editor, e, successCallback);
                }
            }
        });

        this.items = [
            targetCostGrid
        ];
        this.callParent();
    }
});




