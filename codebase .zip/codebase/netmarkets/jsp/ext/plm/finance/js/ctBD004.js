Ext.define('PLM.view.ctBD004', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctBD004',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctBD004',
    initComponent: function () {

        Ext.define('BD004Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'type1', "type2", 'workingHours0', 'budget0', 'workingHours1', 'budget1', 'workingHours2', 'budget2'
                , 'workingHours3', 'budget3', 'workingHours4', 'budget4', 'workingHours5', 'budget5', 'workingHours6', 'budget6'
                , 'workingHours7', 'budget7', '', '', '', '', '', ''
            ],
            idProperty: 'id'
        });

        var BD004Columns = [
            {
                text: '工程师分类',
                columns:[
                    {text: '',sortable: false, align: 'center',dataIndex: 'type1', width:180, menuDisabled:true, editor:false},
                    {text: '',sortable: false, align: 'center',dataIndex: 'type2', width:180, menuDisabled:true, editor:false},
                ]
            },
            {
                text: '预计工时',
                sortable: false,
                align: 'center',
                dataIndex: 'workingHours0',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: '预算',
                sortable: false,
                align: 'center',
                dataIndex: 'budget0',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: '里程碑外预算',
                columns:[
                    {
                        text: '预计工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'workingHours1',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budget1',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                ]
            },
            {
                text: 'Start-TR2',
                columns:[
                    {
                        text: '预计工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'workingHours2',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budget2',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                ]
            },
            {
                text: 'TR2-PDCP',
                columns:[
                    {
                        text: '预计工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'workingHours3',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budget3',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                ]
            },
            {
                text: 'PDCP-TR4',
                columns:[
                    {
                        text: '预计工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'workingHours4',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budget4',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                ]
            },
            {
                text: 'TR4-TR5',
                columns:[
                    {
                        text: '预计工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'workingHours5',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budget5',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                ]
            },
            {
                text: 'TR5-TR6',
                columns:[
                    {
                        text: '预计工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'workingHours6',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budget6',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                ]
            },
            {
                text: 'TR6-End',
                columns:[
                    {
                        text: '预计工时',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'workingHours7',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '预算',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'budget7',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right',
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                ]
            }
        ];

        var BD004Store = Ext.create('Ext.data.Store', {
            model: 'BD004Model',
            id: 'BD004Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBD004?branchId=' + branchId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var BD004GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BD004Grid = Ext.create('Ext.grid.Panel', {
            plugins: [BD004GridEditing],
            store: BD004Store,
            columns: BD004Columns,
            id:'BD004Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
            tbar: [
                // {
                //     xtype: 'button',
                //     text: '下载导入模板',
                //     buttonOnly: true,
                //     id: 'downloadBD004Template',
                //     iconCls: 'icon-download',
                //     //hidden: downloadECAEBOM?false:true,
                //     handler: function () {
                //         window.location.href = '/Windchill/ptc1/finance/downLoadTemplate?templateName=人力费用预算表-BD004导入模板';
                //     }
                // },
                // {
                //     xtype:'filefield',
                //     buttonOnly: true,
                //     id:'upload-BD004',
                //     hideLabel: true,
                //     //hidden: ecaEBOMuploadECAEBOM?false:true,
                //     buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入数据</span>',
                //     allowBlank: false,
                //     scope: this,
                //     listeners:{
                //         'change':function(fb, newValue, oldValue, opts){
                //             if(!newValue){
                //                 return;
                //             }
                //             var file = document.querySelector('[id=upload-BD004-button-fileInputEl]');
                //             var formData = new FormData();
                //             formData.append('upload-BD004-button-fileInputEl', file.files[0]);
                //             fb.reset();//清空表单的值
                //             var myMask = new Ext.LoadMask({
                //                 msg: '正在导入数据，请稍候......',
                //                 target: BD004Grid
                //             });
                //             myMask.show();
                //             $.ajax({
                //                 url: '/Windchill/ptc1/finance/importBD?branchId=' + branchId + '&tabName=BD004',
                //                 type: 'POST',
                //                 cache: false,
                //                 data: formData,
                //                 processData: false,
                //                 contentType: false
                //             }).done(function(res) {
                //                 myMask.hide();
                //                 var obj = Ext.decode(res);
                //                 var success = obj['success'];
                //                 var msg = obj['msg'];
                //                 if(!success){
                //                     alert(msg);
                //                 }
                //                 BD004Grid.getStore().load();
                //             }).fail(function(res) {
                //                 var obj = Ext.decode(res);
                //                 var msg = obj['msg'];
                //                 myMask.hide();
                //                 alert('导入失败！\n'+msg) ;
                //             });
                //         }
                //     }
                // }
            ]
        });

        this.items = [
            BD004Grid
        ];
        this.callParent();
    }
});




