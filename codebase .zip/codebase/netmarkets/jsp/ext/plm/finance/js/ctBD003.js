Ext.define('PLM.view.ctBD003', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctBD003',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctBD003',
    initComponent: function () {

        Ext.define('BD003Model', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'productCode', "productDescription", 'parameterType', 'year1',
                'year2','year3','year4','year5','year6', 'summary'
            ],
            idProperty: 'id'
        });

        var BD003Columns = [
            {text: '产品编码',sortable: false, align: 'center',dataIndex: 'productCode', width:120, menuDisabled:true, editor:false},
            {text: '产品描述',sortable: false, align: 'center',dataIndex: 'productDescription', width:300, menuDisabled:true, editor:false},
            {text: '参数类型',sortable: false, align: 'center',dataIndex: 'parameterType', width:180, menuDisabled:true, editor:false},
            {
                text: '汇总',
                sortable: false,
                align: 'center',
                dataIndex: 'summary',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: year + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'year1',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 1) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'year2',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 2) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'year3',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 3) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'year4',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 4) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'year5',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: (year + 5) + "年",
                sortable: false,
                align: 'center',
                dataIndex: 'year6',
                width: 100,
                menuDisabled: true,
                editor: false
                ,
                align: 'right',
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            }
        ];

        var BD003Store = Ext.create('Ext.data.Store', {
            model: 'BD003Model',
            id: 'BD003Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBD003?branchId=' + branchId,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:true,
        });

        var BD003GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BD003Grid = Ext.create('Ext.grid.Panel', {
            plugins: [BD003GridEditing],
            store: BD003Store,
            columns: BD003Columns,
            id:'BD003Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
            tbar: [
                // {
                //     xtype: 'button',
                //     text: '下载导入模板',
                //     buttonOnly: true,
                //     iconCls: 'icon-download',
                //     //hidden: downloadECAEBOM?false:true,
                //     handler: function () {
                //         window.location.href = '/Windchill/ptc1/finance/downLoadTemplate?templateName=销售毛利预算表-BD003导入模板';
                //     }
                // },
                // {
                //     xtype:'filefield',
                //     buttonOnly: true,
                //     id:'upload-BD003',
                //     hideLabel: true,
                //     //hidden: ecaEBOMuploadECAEBOM?false:true,
                //     buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/excel_import.gif" style="vertical-align:text-bottom;"/> 导入数据</span>',
                //     allowBlank: false,
                //     scope: this,
                //     listeners:{
                //         'change':function(fb, newValue, oldValue, opts){
                //             if(!newValue){
                //                 return;
                //             }
                //             var file = document.querySelector('[id=upload-BD003-button-fileInputEl]');
                //             var formData = new FormData();
                //             formData.append('upload-BD003-button-fileInputEl', file.files[0]);
                //             fb.reset();//清空表单的值
                //             var myMask = new Ext.LoadMask({
                //                 msg: '正在导入数据，请稍候......',
                //                 target: BD003Grid
                //             });
                //             myMask.show();
                //             $.ajax({
                //                 url: '/Windchill/ptc1/finance/importBD?branchId=' + branchId + '&tabName=BD003',
                //                 type: 'POST',
                //                 cache: false,
                //                 data: formData,
                //                 processData: false,
                //                 contentType: false
                //             }).done(function(res) {
                //                 myMask.hide();
                //                 var obj = Ext.decode(res);
                //                 var success = obj['success'];
                //                 var msg = obj['msg'];
                //                 if(!success){
                //                     alert(msg);
                //                 }
                //                 BD003Grid.getStore().load();
                //             }).fail(function(res) {
                //                 var obj = Ext.decode(res);
                //                 var msg = obj['msg'];
                //                 myMask.hide();
                //                 alert('导入失败！\n'+msg) ;
                //             });
                //         }
                //     }
                // }
            ]
        });

        this.items = [
            BD003Grid
        ];
        this.callParent();
    }
});




