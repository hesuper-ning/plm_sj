Ext.define('PLM.view.ctBB003', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctBB003',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:450,
    id: 'ctBB003',
    initComponent: function () {
        var BB003Fields = ['id', 'partNumber', "partDesc", 'costProject', 'stepCount',
            'charterCost', 'pdcpCost', 'tr2Cost', 'tr4Cost', 'tr5Cost', 'tr6Cost', 'actualCost', 'productionQuantity'
            ];

        Ext.define('BB003Model', {
            extend: 'Ext.data.Model',
            fields: BB003Fields,
            idProperty: 'id'
        });

        var BB003Columns = [
            {text: '编码',sortable: false, align: 'center',dataIndex: 'partNumber', width:80, menuDisabled:true, editor:false},
            {text: '描述',sortable: false, align: 'center',dataIndex: 'partDesc', width:260, menuDisabled:true, editor:false},
            {text: '成本项目',sortable: false, align: 'center',dataIndex: 'costProject', width:120, menuDisabled:true, editor:false},
            {
                text: '阶梯数量',
                sortable: false,
                align: 'center',
                dataIndex: 'stepCount',
                width: 80,
                menuDisabled: true,
                editor: false
                ,
                align: 'right'
                ,
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'Charter目标成本',
                sortable: false,
                align: 'center',
                dataIndex: 'charterCost',
                width: 120,
                menuDisabled: true,
                editor: false
                ,
                align: 'right'
                ,
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'PDCP目标成本',
                sortable: false,
                align: 'center',
                dataIndex: 'pdcpCost',
                width: 120,
                menuDisabled: true,
                editor: false
                ,
                align: 'right'
                ,
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'TR2成本',
                sortable: false,
                align: 'center',
                dataIndex: 'tr2Cost',
                width: 80,
                menuDisabled: true,
                editor: false
                ,
                align: 'right'
                ,
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'TR4成本',
                sortable: false,
                align: 'center',
                dataIndex: 'tr4Cost',
                width: 80,
                menuDisabled: true,
                editor: false
                ,
                align: 'right'
                ,
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'TR5成本',
                sortable: false,
                align: 'center',
                dataIndex: 'tr5Cost',
                width: 80,
                menuDisabled: true,
                editor: false
                ,
                align: 'right'
                ,
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: 'TR6成本',
                sortable: false,
                align: 'center',
                dataIndex: 'tr6Cost',
                width: 80,
                menuDisabled: true,
                editor: false
                ,
                align: 'right'
                ,
                renderer: function (value) {
                    if (value && value !== '') {
                        value = formatAmount(value);
                    }
                    return value;
                }
            },
            {
                text: '实际数据',
                columns:[
                    {
                        text: '实际成本',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'actualCost',
                        width: 80,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right'
                        ,
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    },
                    {
                        text: '实际生产数量',
                        sortable: false,
                        align: 'center',
                        dataIndex: 'productionQuantity',
                        width: 100,
                        menuDisabled: true,
                        editor: false
                        ,
                        align: 'right'
                        ,
                        renderer: function (value) {
                            if (value && value !== '') {
                                value = formatAmount(value);
                            }
                            return value;
                        }
                    }
                ]
            }
        ];

        var BB003Store = Ext.create('Ext.data.Store', {
            model: 'BB003Model',
            id: 'BB003Store',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/finance/getBudgetReport?reportType=getProductCost&oid=' + oid,
                method:'GET',
                timeout: 300000,
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad: false,
            listeners: {
                beforeload: function(store, operation, eOpts) {
                    BB003Grid.getEl().mask({
                        xtype: 'loadmask'
                    });
                    Ext.MessageBox.show({
                        title: '提示',
                        msg: '正在加载数据，请稍候...',
                        icon: Ext.MessageBox.INFO,
                        closable: false,//去掉右上方的关闭按钮
                        draggable: false
                    });
                },
                load: function(store, records, successful, operation, eOpts) {
                    BB003Grid.getEl().unmask();
                    Ext.MessageBox.hide();
                }
            }
        });

        var BB003GridEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var BB003Grid = Ext.create('Ext.grid.Panel', {
            plugins: [BB003GridEditing],
            store: BB003Store,
            columns: BB003Columns,
            id:'BB003Grid',
            autoWidth: true,
            columnLines: true,
            // height:300,
            multiSelect : false,
            autoScroll: true,
            viewConfig: {enableTextSelection:true},
            // selType: 'checkboxmodel',
        });

        this.items = [
            BB003Grid
        ];
        this.callParent();
    },
    listeners:{
        'afterrender':function(cmp) {
            Ext.getStore('BB003Store').reload();
        }
    }
});




