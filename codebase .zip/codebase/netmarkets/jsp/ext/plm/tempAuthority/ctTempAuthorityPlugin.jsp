<%@ page import="java.sql.*,
                 java.util.ArrayList,
                 java.util.*,
                 wt.part.WTPart,
                 wt.fc.ReferenceFactory,
                 wt.fc.Persistable,
                 ext.plm.util.*,
                 ext.plm.common.*,
                 wt.type.TypedUtilityServiceHelper,
                 org.json.*,
                 wt.vc.wip.WorkInProgressHelper,
                 wt.vc.wip.Workable,
                 com.ptc.windchill.enterprise.change2.commands.RelatedChangesQueryCommands,
                 wt.change2.WTChangeRequest2,
                 wt.change2.Changeable2,
                 wt.fc.QueryResult,
                 wt.doc.WTDocument,
                 wt.epm.EPMDocument,
                 wt.maturity.PromotionNotice,
                 wt.change2.WTChangeActivity2"
         pageEncoding="utf-8" %>
<%@ page import="com.ptc.netmarkets.util.beans.*"
%>
<%@ page import="com.ptc.netmarkets.util.misc.*"
%>
<%@ page import="com.ptc.netmarkets.util.wizard.*,java.io.*"
%>
<%@ page import="com.ptc.windchill.classproxy.ConsoleClassProxy"
%>
<%@ page import="com.ptc.netmarkets.object.objectResource,
                 com.ptc.netmarkets.model.*,
                 com.ptc.netmarkets.role.NmRoleHelper,
                 com.ptc.netmarkets.user.NmUserHelper,
                 com.ptc.netmarkets.projectPlan.NmProjectPlanCommands,
                 com.ptc.core.ui.validation.*,
                 com.ptc.core.components.forms.FormResult,
                 com.ptc.core.components.forms.FormResultAction,
                 java.util.*"
%>
<%@ page import="java.util.ResourceBundle"
%>
<%@ page import="com.ptc.core.meta.common.TypeIdentifier" %>
<%@ page import="wt.type.ClientTypedUtility" %>
<%@ page import="com.ptc.core.lwc.common.view.TypeDefinitionReadView" %>
<%@ page import="com.ptc.core.lwc.server.TypeDefinitionServiceHelper" %>
<%@ page import="java.text.DateFormat" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="wt.folder.FolderHelper" %>
<%@ page import="com.alibaba.fastjson.JSON" %>
<%@ page import="wt.org.WTPrincipal" %>
<%@ page import="wt.session.SessionHelper" %>
<jsp:useBean id="wtcontext" class="wt.httpgw.WTContextBean" scope="request"/>
<%
    //
    wtcontext.setRequest(request);

%>
<jsp:useBean id="nmcontext" class="com.ptc.netmarkets.util.beans.NmContextBean" scope="request"/>
<%
    //
    request.setCharacterEncoding("UTF-8");
    if (request.getParameter("portlet") != null)
        nmcontext.setPortlet(request.getParameter("portlet"));
    nmcontext.setRequest(request);
    nmcontext.setResponse(response);
    nmcontext.adjustContext(request);
%>
<jsp:useBean id="localeBean" class="com.ptc.netmarkets.util.beans.NmLocaleBean" scope="request"/>
<jsp:useBean id="sessionBean" class="com.ptc.netmarkets.util.beans.NmSessionBean" scope="session"/>
<%
    sessionBean.setDoneCB(false);
    NmCommandBean cb1 = new NmCommandBean();
    cb1.setInBeginJsp(true);
    cb1.setOpenerCompContext(request.getParameter("compContext"));
    cb1.setOpenerElemAddress(NmCommandBean.convert(request.getParameter("openerElemAddress")));
    cb1.setCompContext(NmCommandBean.convert(request.getParameter("compContext")));
    cb1.setElemAddress(NmCommandBean.convert(request.getParameter("elemAddress")));
    cb1.setSessionBean(sessionBean);
    cb1.setRequest(request);
    cb1.setResponse(response);
    cb1.setOut(out);
    cb1.setWtcontextBean(wtcontext);
    cb1.setContextBean(nmcontext);
    List<Persistable> list = new ArrayList<>();
    ReferenceFactory renferenceFactory = new ReferenceFactory();
    ArrayList oidList = cb1.getSelectedOidForPopup();
    if(oidList.size()>0){
        for (int i = 0; i < oidList.size(); i++) {
            Object obj = oidList.get(i);
            NmOid nmOid = (NmOid) obj;
            String objectId = nmOid.toString();
            Persistable persistable = renferenceFactory.getReference(
                    nmOid.toString()).getObject();
            list.add(persistable);
        }
    }else {
        String oid = cb1.getRequest().getParameter("oid").replace("%3A", ":");
        Persistable refObject = CtWTObjectUtil.getObjectByOid(oid);
        if (refObject != null) {
            if (refObject instanceof WTDocument || refObject instanceof EPMDocument || refObject instanceof WTPart) {
                list.add(refObject);
            }
        }
    }
    JSONArray dataList = new JSONArray();

    String error = "";
    String number = "";
    DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    //忽略权限
    WTPrincipal principal = SessionHelper.manager.getPrincipal();
    SessionHelper.manager.setAdministrator();
    try {
        for (int i = 0; i < list.size(); i++) {
            Persistable persistable = list.get(i);
            String objectId = CtWTObjectUtil.getVid(persistable);
            TypeIdentifier doc_tid = ClientTypedUtility.getTypeIdentifier(persistable);
            TypeDefinitionReadView tdrv = TypeDefinitionServiceHelper.service.getTypeDefView(doc_tid);
            String type = ClientTypedUtility.getExternalTypeIdentifier(persistable);
            String typeViewName = tdrv.getDisplayName();
            JSONObject map = new JSONObject();
            if (persistable instanceof WTDocument) {
                WTDocument doc = (WTDocument) persistable;
                IBAUtil util = new IBAUtil(doc);
                map.put("objectId", objectId);
                map.put("type", type);

                map.put("displayText", typeViewName);
                map.put("fileNumber", doc.getNumber());
                map.put("fileName", doc.getName());
                map.put("fileType", typeViewName);
                map.put("fileVersion", util.getIBAValue("mkt_banben"));
                map.put("version", CtVersionUtil.getVersionInfo(doc));
                map.put("fileStatus", doc.getLifeCycleState().getDisplay(Locale.CHINA));
                map.put("containerName", doc.getContainerName());
                String path = doc.getLocation();
                path = path.replaceFirst("/Default", "");
                if (!CtFormatUtil.hasContent(path)) {
                    path = "/";
                }
                map.put("filePath", path);
                map.put("fileCreator", doc.getCreatorFullName());
                map.put("fileCreateTime", format.format(doc.getCreateTimestamp()));
                dataList.put(map);
            } else if (persistable instanceof EPMDocument) {
                EPMDocument epm = (EPMDocument) persistable;
                IBAUtil util = new IBAUtil(epm);
                map.put("objectId", objectId);
                map.put("type", type);
                map.put("displayText", typeViewName);
                map.put("fileName", epm.getName());
                map.put("fileVersion", util.getIBAValue("mkt_banben"));
                map.put("version", CtVersionUtil.getVersionInfo(epm));
                map.put("fileStatus", epm.getLifeCycleState().getDisplay(Locale.CHINA));
                map.put("containerName", epm.getContainerName());
                map.put("fileNumber", epm.getNumber());
                map.put("fileType", typeViewName);
                String path = epm.getLocation();
                path = path.replaceFirst("/Default", "");
                if (!CtFormatUtil.hasContent(path)) {
                    path = "/";
                }
                map.put("filePath", path);
                map.put("fileCreator", epm.getCreatorFullName());
                map.put("fileCreateTime", format.format(epm.getCreateTimestamp()));
                dataList.put(map);
            } else if (persistable instanceof WTPart) {
                WTPart part = (WTPart) persistable;
                map.put("partNumber", part.getNumber());
                map.put("partVid", CtWTObjectUtil.getVid(part));
                dataList.put(map);
            }
        }
    } finally {
        SessionHelper.manager.setPrincipal(principal.getName());//恢复权限
    }
    response.setCharacterEncoding("UTF-8");
    String jsonString = dataList.toJSONString();
    String containerOid = request.getParameter("ContainerOid");
    String folderOid = request.getParameter("oid");
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

<head>
    <title>创建临时权限</title>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css"/>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <!-- ExtJS -->
    <script type="text/javascript">
        var JSONDATA = <%=jsonString%>;
        if (JSONDATA == null && JSONDATA == undefined) {
            JSONDATA = '[]';
        }
        var ContainerOid = "<%=containerOid%>";
        var FolderOid = "<%=folderOid%>";

    </script>
    <script type="text/javascript"
            src="/Windchill/netmarkets/jsp/ext/plm/tempAuthority/js/ctTempAuthorityPanel_fn.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript"
            src="/Windchill/netmarkets/jsp/ext/plm/tempAuthority/js/ctTempAuthorityPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>
<body>

<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {xtype:'panel',
                    region: 'center',
                    border:false,
                    items:[{
                      //title: '文件权限申请单',
                        xtype: 'TempAuthorityPanel'
                    }]
                }

                ]
        });
    });
</script>
</body>
</html>

