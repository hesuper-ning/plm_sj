<%@ page import="wt.fc.ReferenceFactory" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.change2.WTChangeReview" %>
<%@ page import="java.util.Locale" %>
<%@ page import="ext.plm.tempAuthority.CtTempAuthorityLogic" %>
<%@ page import="wt.org.WTUser" %>
<%@ page language="java" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
    ReferenceFactory rf = new ReferenceFactory();
    Persistable per = rf.getReference(oid).getObject();
//    workItem = (WorkItem)per;
//    Persistable obj = CtWorkFlowUtil.getPbo((WorkItem) per);
//    oid = rf.getReferenceString(obj);
    WTUser wtuser = (WTUser) wt.session.SessionHelper.manager.getPrincipal();
    boolean allowEdit = false;


    if (per instanceof WTChangeReview) {

        WTChangeReview review = (WTChangeReview) per;
        String state = review.getLifeCycleState().getDisplay(Locale.CHINA);
        if (CtTempAuthorityLogic.isOrgAdministator(wtuser)) {
            allowEdit = true;
        }
        if (state.equals("正在工作") || state.equals("返工")) {
            if (wtuser.getName().equalsIgnoreCase(review.getCreatorName())) {
                allowEdit = true;
            }
        }
    }


%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

<head>

    <%

    %>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css"/>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/tempAuthority/js/ctTempAuthorityPanel_fn.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/tempAuthority/js/ctTempAuthorityWfPluginPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script type="text/javascript">
    var Oid = "<%=oid%>";
    var AllowEdit = false;
    var processEdit = false;
<%--    <%if(allowEdit){ %>--%>
<%--    AllowEdit = true;--%>
<%--    <%}%>--%>
    <%--var AllowEdit = "<%=allowEdit%>";--%>

</script>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {xtype:'panel',
                    region: 'center',
                    border:false,
                    items:[{
                        //title: '文件权限申请单',
                        xtype: 'TempAuthorityWfPluginPanel'
                    }]
                }
            ]
        });
    });
</script>
</body>
</html>

