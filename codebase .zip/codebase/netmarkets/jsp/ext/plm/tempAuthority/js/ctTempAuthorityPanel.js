let partVid = "";
let partRefType ="";
Ext.define('PLM.view.TempAuthorityPanel', {
	extend:'Ext.panel.Panel',
	alias:'widget.TempAuthorityPanel',
	border: false,
	collapsible: false,
    // autoWidth:true,
 	// autoHeight:true,
	initComponent:function(){
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var authorityTypeText = '权限设置';
        var tempAuthorityNameText = '流程名称';
        var tempAuthorityRemarkText = '说明';
        var tempAuthorityNeedDateText = '授予结束日期';
        var docNumber = '';
        authorityTypeText =blueFlagStart+ authorityTypeText +blueFlagEnd;
        tempAuthorityNameText =blueFlagStart+ tempAuthorityNameText +blueFlagEnd;
        tempAuthorityRemarkText =blueFlagStart+ tempAuthorityRemarkText +blueFlagEnd;
        tempAuthorityNeedDateText =blueFlagStart+ tempAuthorityNeedDateText +blueFlagEnd;
			 var tempAuthorityTypeCombo = new Ext.form.ComboBox({
				    typeAhead: true,
				    triggerAction: 'all',
				    lazyRender:true,
				    width:100,
				    allowBlank: false,
				    //disabled:!checkNodeEnable(),
				    id:'tempAuthorityTypeCombo',
				 	name : 'tempAuthorityTypeCombo',
				    mode: 'local',
				    store: new Ext.data.ArrayStore({
				        id: 0,
				        fields: [
				            'key',
				            'displayText'
				        ],
                        data: [['读取', '读取'], ['下载', '下载']/*, ['升版修订', '升版修订']*/]
				    }),
				    valueField: 'key',
				    displayField: 'displayText',
				    selectOnFocus:true,
					editable : false,
				    listeners:{
				        change: function (filed, newValue, oldValue, op) {

			            }
				    }
				});

		var cellEditing = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});

	    //页面
		Ext.define('tempAuthorityFileModel', {
	        extend: 'Ext.data.Model',
	        fields: [
                'id', 'oid', 'objectId', 'fileNumber', 'fileName', 'fileType', 'filePath', 'authorityType', 'containerName', 'type'
				, 'fileCreator', 'fileCreateTime', 'fileVersion', 'version', 'fileStatus'
				, 'partVid', 'partRefType','materialdescription','partNumber'
	        ],
	        idProperty: 'id'
	    });


		//region：表格数据
		var tempAuthorityFileStore = new Ext.data.Store({
			storeId:'tempAuthorityFileStore',
			model:'tempAuthorityFileModel',
			pruneModifiedRecords: true,
			data: JSONDATA
			/*proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/costManage/getNewExportGeneral',
                method:'GET',
                reader:{
                    type:'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:false*/
		});
		//endregion

		//region：物料编码Combobox
		//模型
		Ext.define('comboboxModel', {
			extend: 'Ext.data.Model',
			fields: ['key', 'displayText', 'fileNumber', 'fileName', 'fileType', 'filePath', 'authorityType', 'containerName', 'type'
				, 'fileCreator', 'fileCreateTime', 'fileVersion', 'version', 'fileStatus'
				, 'partVid', 'partRefType','materialdescription','partNumber'],
			idProperty: 'id'
		});
		//数据
		let partVidStore =  new Ext.data.Store({
			storeId : 'partVidStore',
			model:'comboboxModel',
			pruneModifiedRecords: true,
			proxy : new Ext.data.HttpProxy({
				url : '/Windchill/ptc1/tempAuthority/getPart',
				method:'GET',
				reader : {
					type:'json',
					root: 'items',
					idProperty: 'id',
					messageProperty: 'msg'
				}
			}),
			autoLoad : false,
			listeners: {
/*				load: function(store, records, successful, operation, eOpts) {
					if (successful) {
						// 数据加载成功，你可以在这里操作 Store 或访问数据
						console.log('数据加载成功，记录数：', records.length);
						// 例如，遍历 Store 中的所有记录
						store.each(function(record) {
							console.log(record); // 替换 'someFieldName' 为你的实际字段名
						});

						// 其他基于加载数据的操作...
					} else {
						// 数据加载失败
						console.error('数据加载失败');
					}
				}*/
			}
		});

		// Combobox
		let partVidCombobox = new Ext.form.ComboBox({
			typeAhead: false,
			store: partVidStore,
			triggerAction: 'all',
			name: 'partVidCombobox',
			id: 'partVidCombobox',
			hideTrigger: true,
			editable: true,
			allowBlank: false,
			lazyRender: true,
			repeatTriggerClick: true,
			mode: 'remote',
			minChars: 5,
			queryParam: 'param',
			//width:250,
			//labelWidth:70,
			selectOnFocus: true,
			valueField: 'key',
			forceSelection: true,
			displayField: 'displayText',
			listeners: {

			}
		});

		// endregion


		//region：Combobox

		//数据
		let partRefTypeStore =  new Ext.data.Store({
			storeId : 'partRefTypeStore',
			model:'comboboxModel',
			pruneModifiedRecords: true,
			proxy : new Ext.data.HttpProxy({
				url : '/Windchill/ptc1/tempAuthority/getPartRefType',
				method:'GET',
				reader : {
					type:'json',
					root: 'items',
					idProperty: 'id',
					messageProperty: 'msg'
				}
			}),
			async: false,
			autoLoad : false,
			listeners: {

			}
		});

		//物料相关类型 Combobox
		let partRefTypeCombobox = new Ext.form.ComboBox({
			name: 'partRefTypeCombobox',
			id: 'partRefTypeCombobox',
			valueField: 'partRefType',
			displayField: 'partRefType',
			queryMode: 'remote',
			anyMatch: true,
			typeAhead: true,
			forceSelection: true,
			triggerAction: 'all',
			allowBlank: true,
			store: partRefTypeStore,
			editable:false,
			queryParam: 'param',
			listeners: {
				beforequery: function(queryPlan) {
					let date = {};
					date.partVid = partVid;
					let p = Ext.encode(date);
					console.log(p);
					queryPlan.query=p;
					return true;
				},
			}
		});

		// endregion



		//对象列表
		Ext.define('affectFileModel', {
			extend: 'Ext.data.Model',
            fields: ['key', 'displayText', 'fileNumber', 'fileName', 'fileType', 'filePath', 'authorityType', 'containerName', 'type'
				, 'fileCreator', 'fileCreateTime', 'fileVersion', 'version', 'fileStatus'
				, 'partVid', 'partRefType','materialdescription','partNumber'],
			idProperty: 'id'
		});
		var affectFileStore =  new Ext.data.Store({
			storeId : 'affectFileStore',
			model:'affectFileModel',
			pruneModifiedRecords: true,
			proxy : new Ext.data.HttpProxy({
				url : '/Windchill/ptc1/tempAuthority/getAffectFiles',
				method:'GET',
				reader : {
					type:'json',
					root: 'items',
					idProperty: 'id',
					messageProperty: 'msg'

				}
			}),
			autoLoad : false,
			listeners: {
			}
		});

		var affectFileCombo = new Ext.form.ComboBox({
			typeAhead: false,
			store: affectFileStore,
			triggerAction: 'all',
			name: 'affectFileCombo',
			id: 'affectFileCombo',
			hideTrigger: true,
			editable:true,
			allowBlank: false,
			lazyRender:true,
			repeatTriggerClick : true,
			mode: 'remote',
			minChars: 5,
			queryParam: 'param',
			//width:250,
			//labelWidth:70,
			selectOnFocus:true,
			valueField: 'key',
			forceSelection: true,
			displayField: 'displayText' ,
			listeners: {
				beforequery: function(queryPlan) {
					let date = {};
					date.partVid = partVid;
					date.partRefType = partRefType;
					date.query = queryPlan.query;
					let p = Ext.encode(date);
					queryPlan.query=p;
					return true;
				},
			}
		});

	    var tempAuthorityFileGrid = Ext.create('Ext.grid.Panel', {
	        plugins: cellEditing,
	        id:'tempAuthorityFileGrid',
			//title: '文件权限申请单',
	        // columnLines: true,
			// forceFit: true,
			height : 350,
			// autoScroll: true,
			// bodyStyle : 'overflow-x:auto; overflow-y:scroll',
			region: 'center',
	        store: tempAuthorityFileStore,
	        columns: [
				/*new Ext.grid.RowNumberer({header: "序号",width: 40,align: 'center',renderer:function(value,metadata,record,rowIndex){
						return　rowIndex　+　1;
					}}),*/
	            { text: 'ID',  dataIndex: 'id',hidden:true },
				{ text: 'oid',  dataIndex: 'oid',hidden:true },
                {text: 'type', dataIndex: 'type', hidden: true},
				{ text: 'objectId',  dataIndex: 'objectId',hidden:true },
				{
					text: '物料编号',
					width: 150,
					dataIndex: 'partNumber',
					menuDisabled: true,
					editor: partVidCombobox,
					renderer: function (value, meta, record) {
						let displayName = value;
						if (value) {
							let store = partVidCombobox.getStore();
							store.each(function (rec) {
								if (rec.get('key') === value) {
									displayName = rec.get('displayText');
								}
							});
						}
						return displayName;
					}
				},
				{
					text: '物料描述',
					width: 250,
					dataIndex: 'materialdescription',
					menuDisabled: true
				},
				{
					text: '文档类型',
					width: 100,
					dataIndex: 'partRefType',
					menuDisabled: true,
					editor: partRefTypeCombobox,
					renderer: function (value, meta, record) {
						let displayName = value;
						// displayName=getDisplayName(value);
						if (value) {
							let activieStore = partRefTypeCombobox.getStore();
							activieStore.each(function (rec) {
								if (rec.get('key') == value) {
									displayName = rec.get('displayText');
								}
							});
						}
						return displayName;
					}
				},
                {
                    text: '文件编号',
                    width: 100,
                    dataIndex: 'fileNumber',
                    editor: affectFileCombo,
                    renderer: function (value, meta, record) {
							var displayName = value;
						    // displayName=getDisplayName(value);
							if(value){
								var activieStore = affectFileCombo.getStore();
								activieStore.each(function(rec){
									if(rec.get('key') == value){
										displayName =  rec.get('displayText') ;
									}
								});
							}
							return displayName;
					}},
	            { text: '名称', width:300,dataIndex: 'fileName'},
                {
                    // text: '权限设置',
                    text: authorityTypeText,
                    width: 100,
                    dataIndex: 'authorityType',
                    menuDisabled: true,
                    editor: tempAuthorityTypeCombo,
					renderer: function (value, meta, record) {
                        return value;
                    }
                },
				{text: '版本', width: 100, dataIndex: 'fileVersion', menuDisabled: true},
				{text: '系统版本', width: 100, dataIndex: 'version', menuDisabled: true},
				{text: '状态', width: 100, dataIndex: 'fileStatus', menuDisabled: true},
                {text: '类型', width: 100, dataIndex: 'fileType', menuDisabled: true},
                {text: '上下文', width: 100, dataIndex: 'containerName', menuDisabled: true},
                {text: '路径', width: 150, dataIndex: 'filePath', menuDisabled: true},
                {text: '创建人', width: 120, dataIndex: 'fileCreator', menuDisabled: true},
                {text: '创建时间', width: 200, dataIndex: 'fileCreateTime', menuDisabled: true}

	            //{ text: '备注',width:150, dataIndex: 'remark',menuDisabled:true, editor: {allowBlank: false,selectOnFocus:true}}
	        ],
	        // autoWidth : true,
            // autoHeight: true,
	        tbar: [{
	        		text : '添加',
	        		iconCls : 'icon icon-add',
	        		scope:this,
                	handler:function(){
	                	  cellEditing.cancelEdit();
	                		// 创建入库数据
	                         var newRecord = Ext.create('tempAuthorityFileModel', {
								 id:'',
								 oid: '',
								 objectId:'',
                                 type: '',
								 fileNumber:'',
								 fileName:'',
								 fileType:'',
								 fileVersion: '',
								 version: '',
								 fileStatus: '',
								 filePath: '',
								 fileCreator: '',
								 fileCreateTime: '',
                                 containerName: '',
                                 authorityType: ''
	                         });
	                         tempAuthorityFileStore.insert(0, newRecord);
	                         cellEditing.startEdit(0, 0);
	                  	 }
	               },'&nbsp;',{
	                	   text : '删除',
	                       iconCls : 'icon icon-delete',
		   	        	   scope:this,
		   	        	   handler:function(){
		   	        		   var sm = tempAuthorityFileGrid.getSelectionModel();
		   	        		   cellEditing.cancelEdit();
							   tempAuthorityFileStore.remove(sm.getSelection());
		   	        	   }
		   	           }
	                ],
			listeners: {
				'beforeedit': function (editor, e, eOpts) {
					var f = e.field;
					var r = e.record;
					//fileNumber只能编辑一次
					if (f === 'fileNumber') {
						if (r.get('fileNumber')) {
							return false;
						} else {
							setQuery(r);
							getFileNumberStore(partVid, partRefType);
						}
					} else if (f === 'partRefType') {
						if (r.get('fileNumber') ) {
							return false;
						}else {
							setQuery(r);
						}
					} else if (f === "partNumber") {
						if (r.get('fileNumber') ) {
							return false;
						}
					}
				}
			}
	    });

		tempAuthorityFileGrid.on('edit', function (editor, e) {
			if (e.value == null) {
				return;
			}
			if (e.originalValue == e.value) {
				return;
			}
			var r = e.record; //得到当前行所有数据
			var f = e.field; //得到修改列
			var v = e.value; //得到修改列修改后值
			let number=r.get('fileNumber')
			console.log(e.field+"=======")
			if(f=="authorityType"&&number==''){
				alert("请先填写编号");
				e.record.set("authorityType","")
				return;
			}
			if(f=="authorityType"&&v=="升版修订"){

                Ext.Ajax.request({
                    scope:this,
                    url: '/Windchill/ptc1/tempAuthority/checkWhetherSelect?number='+number,
                    method:'POST',
                    // params:tRecord,
                    // params:JSON.stringify(tRecord),
                    success: function(response, opts) {
                        var obj = Ext.decode(response.responseText);
                        console.log("===="+JSON.stringify(obj));
                        if(obj.msg=="error"){

                        }else if(obj.msg=="nice"){
                            alert("请把该用户添加到该文档对应库下");
							e.record.set("authorityType","")
							r.commit();
                        }else{
							alert("选择失败");
						}
                    },
                    failure: function(response, opts) {

                        alert('错误：更新风险表单字段失败，请检查网络！');
                        callbackFn();
                    }
                });
				// checkWhetherSelect(number);
			}

			//创建时，选择文件编号，更新数据到表格行数据
			affectFileStore.each(function(rec){
				if(rec.get('key') == r.get('fileNumber')){
					displayName =  rec.get('displayText') ;
					e.record.data['objectId'] = rec.get('key');
					e.record.data['fileName'] = rec.get('fileName');
					e.record.data['fileType'] = rec.get('fileType');
					e.record.data['fileVersion'] = rec.get('fileVersion');
					e.record.data['version'] = rec.get('version');
					e.record.data['fileStatus'] = rec.get('fileStatus');
					e.record.data['filePath'] = rec.get('filePath');
					e.record.data['fileCreator'] = rec.get('fileCreator');
					e.record.data['fileCreateTime'] = rec.get('fileCreateTime');
                    e.record.data['containerName'] = rec.get('containerName');
                    e.record.data['type'] = rec.get('type');
					r.endEdit();
					r.commit();
				}

			});
            if (affectFileStore.getCount() > 0) {
                //affectFileStore.remove();
			}
            //创建时，选择物料编码，更新行数据
			partVidStore.each(function(rec){
				if(rec.get('key') === r.get('partNumber')){
					e.record.data['partVid'] = rec.get('key');
					e.record.data['materialdescription'] = rec.get('materialdescription');
					r.endEdit();
					r.commit();
				}
			});
			//创建时，选择物料编码，更新行数据
			partRefTypeStore.each(function(rec){
				if(rec.get('key') === r.get('partNumber')){
					e.record.data['partRefType'] = rec.get('partRefType');
					r.endEdit();
					r.commit();
				}
			});
            r.commit();
		});

/////////////////////////Panel items//////////////////////////////////
		this.items=[{
			xtype: 'fieldset',
			margin:'5 3 10 3',
			title: '<font style="font-size:12px">基础信息</font>',
			collapsible: true,
			whith:300,
			defaults: {
				labelWidth: 100,
				border:false,
				anchor: '98%',
				layout: {
					type: 'hbox'
				}
			},
			items:[{
				xtype:'form',
				layout:'form',
				//layout: 'column',   //布局方式

				padding:'10 10 10 10',
				id:'mainForm',
				name:'mainForm',
				//height:460, //注意一定要给高度固定值才会出滚动条
				autoScroll: true,
				border:false,
				items:[{
					xtype:'textfield',
					fieldLabel: tempAuthorityNameText,
					emptyText:'命名规则:资料域类型-用途。举例：结构资料-外协加工',
					name: 'tempAuthorityName',
					id: 'tempAuthorityName',
					width:250,
					enableKeyEvents:true
				},{
					xtype:'textfield',
					fieldLabel: tempAuthorityRemarkText,
					name: 'tempAuthorityRemark',
					id: 'tempAuthorityRemark',
					width:250,
					enableKeyEvents:true
				}, {
                    xtype:'datefield',
                    fieldLabel: tempAuthorityNeedDateText,
					minValue:new Date(),
                    format:'Y-m-d',
                    name: 'tempAuthorityNeedDate',
                    id: 'tempAuthorityNeedDate',
                    width:250,
                    enableKeyEvents:true
                },{
					xtype:'datefield',
					fieldLabel: '申请日期从',
					format:'Y-m-d',
					name: 'tempAuthorityStartDate',
					id: 'tempAuthorityStartDate',
					width:250,
                    hidden: true,
					enableKeyEvents:true
				},{
					xtype:'datefield',
                    fieldLabel: '授予结束日期',
					format:'Y-m-d',
					name: 'tempAuthorityEndDate',
					id: 'tempAuthorityEndDate',
					width:250,
                    hidden: true,
					enableKeyEvents:true
				}, {
					xtype:'button',
					padding: '5 5 5 5',
					id:'temAuthoritySubmit',
					//disabled: existManufacturingViewPart?false:true,
					text: '确认',
					handler:function() {
						var orgRec; //临时记录
						var newFileRecords = new Array(); //添加记录
						var newFolderRecords = new Array(); //添加记录
						var newRecordsOrg = tempAuthorityFileStore.getNewRecords();

						//判断是否存在空
						var errorMes = '' ;
                        if (Ext.getCmp('tempAuthorityName').getValue() == null || Ext.getCmp('tempAuthorityName').getValue() == '') {
                            errorMes += "请输入流程名称！\n ";
                        }

                        if (Ext.getCmp('tempAuthorityNeedDate').getValue() == null || Ext.getCmp('tempAuthorityNeedDate').getValue() == '') {

                        	errorMes += "请输入授予结束日期！\n ";
                        }
						let selectDate=Ext.getCmp('tempAuthorityNeedDate').getValue();
						let date=new Date();
						console.log("==>>selectDate"+selectDate+"==>>date"+date+"======");
						console.log(selectDate>date);

						for(var i=0; i<tempAuthorityFileStore.getCount(); i++) {
							orgRec = tempAuthorityFileStore.getAt(i).data;

							if(orgRec.fileNumber == "" || orgRec.fileNumber == null) {
                                errorMes += "文件列表中请填写第" + (i + 1) + "行的文件编号! \n "
							}


                            if (orgRec.authorityType == "" || orgRec.authorityType == null) {
                                errorMes += "文件列表中请选择第" + (i + 1) + "行的权限! \n ";
							}

						}
						if(errorMes.length > 0) {
							alert(errorMes);
							return;
						}
						//收集添加记录
						for(var i=0, l= tempAuthorityFileStore.getCount(); i<l; i++){
							orgRec = tempAuthorityFileStore.getAt(i).data;
							var tempRec = {
								id:'',
								oid:'',
								objectId:orgRec.objectId,
								fileNumber:orgRec.fileNumber,
                                authorityType: orgRec.authorityType,
								partVid: orgRec.partVid,
								partRefType: orgRec.partRefType
							};
							newFileRecords[newFileRecords.length] = tempRec;
						}

						Ext.Ajax.request({
							scope:this,
							url: '/Windchill/ptc1/tempAuthority/createTempAuthority',
							params:{
								containerOid:ContainerOid,
								folderOid:FolderOid,
								tempAuthorityName: Ext.getCmp('tempAuthorityName').getValue(),
								tempAuthorityRemark: Ext.getCmp('tempAuthorityRemark').getValue(),
								tempAuthorityNeedDate: Ext.getCmp('tempAuthorityNeedDate').getValue(),
                                //tempAuthorityStartDate: Ext.getCmp('tempAuthorityStartDate').getValue(),
                                //tempAuthorityEndDate: Ext.getCmp('tempAuthorityEndDate').getValue(),
                                fileRecords: Ext.encode(newFileRecords)
							},
							success: function(response, opts) {
								var obj = Ext.decode(response.responseText);
								if(obj['success']){
									alert(obj['msg']);
									//重新加载库存信息
                                    if (obj['url'] != null && obj['url'] != '') {
                                        parent.window.close();
                                        parent.window.opener.location = obj['url'];

                                    } else {
                                        parent.window.opener.location.reload();
                                        parent.window.close();
                                    }

								}else{
									alert(obj['msg']);
								}
							},
							failure: function(response, opts) {
								alert('错误：查询入库信息失败，请检查网络！');
							}
						}); //~End of Ajax request

					}
				}]
			}]
			},{xtype:'panel',
			region: 'center',
			border:false,
			items:[
                tempAuthorityFileGrid
			]}];

		this.callParent();
	}//~End of initComponent

////////////////////////Function area//////////////////////////


});


function checkWhetherSelect(number) {


}

function getDisplayName(value) {
	var displayName = '';
	Ext.Ajax.request({
		scope: this,
		async: false,
		method: "GET",
		url: '/Windchill/ptc1/tempAuthority/getDisplayName',
		params: {
			value: value
		},
		success: function (response, opts) {
			var obj = Ext.decode(response.responseText);
			if (obj.success == true) {
				console.log('fffff'+obj.displayText);
				displayName = obj.displayText;
			} else {
				alert(obj.msg);
			}
		},
		failure: function (response, opts) {
			alert('错误：获取信息失败，请检查网络！!');
		}
	}); //~End of Ajax request
	return displayName;
}