/**
 * 设置用于combobox级联查询的数据
 * @param r
 */
function setQuery(r) {

    if(r.get('partVid')){
        partVid = r.get('partVid');
    }else {
        partVid = "";
    }

    if(r.get('partRefType')){
        partRefType = r.get('partRefType');
    }else {
        partRefType = "";
    }
}

function getFileNumberStore(partVid, partRefType) {
    //在affectFileCombo设置监听，如果有partVid，affectFileCombo设置监听阻止发送请求
    let affectFileCombo = Ext.getCmp('affectFileCombo');
    if (partVid) {//如果有partVid，设置为不可编辑，通过ajax加载store
        affectFileCombo.setEditable(false);
    } else { //如果没有partVid，设置为可编辑
        affectFileCombo.setEditable(true);
    }

}


function updateTempAuthorityInfo(key, value) {
    let tempAuthorityFileStore=Ext.getStore('ctRiskAssessStore');
    let errorMes='';
    // for (var i = 0; i < tempAuthorityFileStore.getCount(); i++) {
    // 	let orgRec = tempAuthorityFileStore.getAt(i).data;
    //
    // 	if (orgRec.fileNumber == "" || orgRec.fileNumber == null) {
    // 		errorMes += "文件列表中请填写第" + (i + 1) + "行的文件编号! \n"
    // 	}
    //
    // 	if (orgRec.authorityType == "" || orgRec.authorityType == null) {
    // 		errorMes += "文件列表中请选择第" + (i + 1) + "行的权限! \n";
    // 	}
    //
    // }
    if (errorMes.length > 0) {
        alert(errorMes);
        return;
    }
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/tempAuthority/updateTempAuthorityInfo',
        params: {
            oid: Oid,
            key: key, //得到修改列
            value: value //得到修改列修改后值
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {

            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request} //~End of save handler
}

