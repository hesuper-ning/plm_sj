<%@ page import="wt.fc.ReferenceFactory" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.change2.WTChangeReview" %>
<%@ page import="java.util.Locale" %>
<%@ page import="ext.plm.tempAuthority.CtTempAuthorityLogic" %>
<%@ page import="wt.org.WTUser" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.project.Role" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page import="wt.org.WTPrincipal" %>
<%@ page language="java" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
    ReferenceFactory rf = new ReferenceFactory();
    Persistable per = rf.getReference(oid).getObject();
    WorkItem workItem =null;
    workItem = (WorkItem)per;
    WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
    String activitynName = activity.getName();
    Persistable obj = CtWorkFlowUtil.getPbo((WorkItem) per);
    oid = rf.getReferenceString(obj);
    WTUser wtuser = (WTUser) wt.session.SessionHelper.manager.getPrincipal();
    boolean allowEdit = false;
    boolean processEdit = false;



    if (obj instanceof WTChangeReview) {

        WTChangeReview review = (WTChangeReview) obj;
        String state = review.getLifeCycleState().getDisplay(Locale.CHINA);
        if (CtTempAuthorityLogic.isOrgAdministator(wtuser)) {
            allowEdit = true;
        }
        if (state.equals("正在工作") || state.equals("返工")) {
            if (wtuser.getName().equalsIgnoreCase(review.getCreatorName())) {
                allowEdit = true;
            }
        }
    }
    String roleCN = workItem.getRole().getLocalizedMessage(Locale.CHINA);
    System.out.println(roleCN);
    if (roleCN.contains("工作负责人") || roleCN.contains("部门经理") || roleCN.contains("数据管理工程师")) {
        String ownerUser = workItem.getOwnership().getOwner().getName();
        WTPrincipal currentUser = CtUserUtil.getCurrentUser();
        String nowUser = CtUserUtil.getCurrentUser().getName();
        if (CtUserUtil.isInGroup(currentUser, "Administrators")) {
            processEdit = true;
        } else if (nowUser.equals(ownerUser)) {
            processEdit = true;
        }

    }

    if (workItem.isComplete()){
        allowEdit = false;
    };

%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

<script type="text/javascript">
    var Oid = "<%=oid%>";
    var AllowEdit = false;
    <%if(allowEdit){ %>
    AllowEdit = true;
    <%}%>
    var processEdit = <%=processEdit%>;
    <%--var AllowEdit = "<%=allowEdit%>";--%>

</script>
<head>

    <%

    %>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css"/>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/tempAuthority/js/ctTempAuthorityPanel_fn.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/tempAuthority/js/ctTempAuthorityWfPluginPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>

<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {xtype:'panel',
                    region: 'center',
                    border:false,
                    items:[{
                        //title: '文件权限申请单',
                        xtype: 'TempAuthorityWfPluginPanel'
                    }]
                }
            ]
        });
    });
</script>
</body>
</html>

