<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@page import="ext.plm.qms.config.CtQmsProperties,wt.workflow.work.WorkItem,wt.doc.WTDocument,ext.plm.util.*"%>
<%@ page import="java.util.Locale" %>
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>>>>>>>>>>oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workitem = (WorkItem)rf.getReference(oid).getObject();
        WTDocument doc = (WTDocument)workitem.getPrimaryBusinessObject().getObject();
        long branchId = doc.getBranchIdentifier();
        //编辑权限判断
        boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workitem,
                CtQmsProperties.getProperty("qms_qualityMetric_allowEdit_roles"));
                //CtQmsProperties.getProperty("qms_qualityMetric_allowEdit_en_roles"));
        IBAUtil docIba = new IBAUtil(doc);
        //获取项目编号
        String projectNumber = docIba.getIBAValue("ct_ItemNumber");
        //获取项目阶段
        String projectPhase = docIba.getIBAValue("Ct_ProjectPhase");
        System.out.println(">>>>>>>>>>"+allowEdit);
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctQmsFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctQualityMetric.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>
    //编辑权限
    var allowEdit = false;
    <%if(allowEdit){ %>
    allowEdit = true;
    <%}%>
    //项目编号
    var projectNumber = "<%=projectNumber%>";
    //项目阶段
    var projectPhase = "<%=projectPhase%>";
    var branchId ='<%= branchId %>';
    var oid ='<%= oid %>';


    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'qualityMetric'
            }]
        });
    });
</script>
</body>
</html>