<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@page import="ext.plm.qms.config.CtQmsProperties,ext.plm.util.CtWorkFlowUtil,ext.plm.util.IBAUtil,wt.doc.WTDocument"%>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="java.util.List" %>
<%@ page import="ext.plm.util.CtUserUtil" %>
<%@ page import="wt.fc.PersistentReference" %>
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();

        System.out.println(">>>>>>>>>>>>oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workitem = (WorkItem)rf.getReference(oid).getObject();
        WTDocument doc = (WTDocument)workitem.getPrimaryBusinessObject().getObject();
        long branchId = doc.getBranchIdentifier();

        WfAssignedActivity activity = (WfAssignedActivity)workitem.getSource().getObject();
        String actName = activity.getName();
        String actKey = CtQmsProperties.getActivityNodeName(actName);
        boolean allowEdit = CtWorkFlowUtil.hasEditAccess(workitem,
                CtQmsProperties.getProperty("qmsTrReport_allowEdit_roles"));

        //获取工作负责人  如果是管理员就将当前用户改为工作负责人
        if (userName.equals("wcadmin")) {
            userName = workitem.getOwnership().getOwner().getFullName();
        }
        System.out.println("工作负责人>>>>>>>>>>>>"+userName);

        IBAUtil docIba = new IBAUtil(doc);
        //获取项目编号
        String projectNumber = docIba.getIBAValue("ct_ItemNumber");
        //获取项目阶段
        String projectPhase = docIba.getIBAValue("Ct_ProjectPhase");

    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
<%--    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>--%>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctTrReview.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctQmsFunctions.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/ctTrReviewSingle.js?_dc=<%=System.currentTimeMillis()%>"></script>

    <style type="text/css">
        .x-grid-red {
            color: #FF0000;
        }

        .x-grid-green {
            color: green;
        }
    </style>
</head>

<body>

<script>


    //编辑权限
    var allowEdit = false;
    <%if(allowEdit){ %>
    allowEdit = true;
    <%}%>
    //容器id
    var containerId = "<%=oid%>";
    var oid = "<%=oid%>";
    var branchId = "<%=branchId%>";
    //项目编号
    var projectNumber = "<%=projectNumber%>";
    //项目阶段
    var projectPhase = "<%=projectPhase%>";
    //当前用户
    var userName = "<%=userName%>";
    //活动key
    var actKey = "<%=actKey%>"
    var id = ""
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'trReView'
            }]
        });
    });
</script>
</body>
</html>