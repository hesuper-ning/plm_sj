Ext.define('PLM.view.trReView', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.trReView',
    border: false,
    autoScroll: false,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'trReView',
    initComponent: function () {
        var me = this;

        var userDisplayName = "";

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });
        var allUserCombo_projectPlan = Ext.create('PLM.hr.CtAllUserCombo', {
            store: allUserStore_projectPlan
        });
//用户下拉列表
        // var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
        //     storeId: 'allUserStore_projectPlan'
        // });
        Ext.define('ctAllUserModel', {
            extend: 'Ext.data.Model',
            fields:['no' ,'riskId']
        });
        var ctAllUserStore = Ext.create('Ext.data.Store', {
            model: 'ctAllUserModel',
            id: 'ctAllUserStore',
            autoSync: true,//同步更新
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/hr/getAllUser',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });
        // var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
        //     storeId: 'allUserStore_projectPlan'
        // });
        var allUserCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : true,
            allowBlank : true,
            // triggerAction: 'all',
            queryMode: 'local',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'hiddenName',
            // name: 'hiddenName',
            mode: 'remote',
            store: ctAllUserStore,
            valueField: 'no',
            displayField: 'userFullName',

        });

        //问题数据
        Ext.define('ctProblemMgtModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'containerId', 'docBranchId', 'problemNumber', 'description', 'creator', 'problemTerritory', 'problemGrade',
                'optimizeStrategy', 'charger', 'planFinishDate', 'startDate', 'processLink', 'projectPhase', 'analysis', 'imgs',
                'badProportion', 'problemSource', 'oaNumber', 'riskNumber', 'relatedProblemNumber', 'optimizeResult',
                'verifyReportOrNot', 'verifyReportLink', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'problemStatus',
                'confirmExplain', 'creatorDate', 'isShare', "temporaryMeasures", "endPartNumber", "productNumber", 'shareLink'],
            idProperty: 'id'
        });

        //初始化加载数据
        var problemStore = Ext.create('Ext.data.Store', {
            //pageSize: 5,
            model: 'ctProblemMgtModel',
            id: 'problemStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/problemMgt/trGetProblem',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        Ext.define('ctProblemVerifyModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'docBranchId', 'problemTerritory', 'undertaker', 'optimizeStrategy', 'planFinishDate', 'optimizeResult',
                'verifyReportLink', 'verifyReportNumber', 'realitySolveDate', 'noChangeCause', 'verifyExplain', 'isAssign'],
            idProperty: 'id'
        });

        var problemVerifyStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctProblemVerifyModel',
            id: 'problemVerifyStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1//problemMgt/getProblemVerifyInfo',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'items',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });


        Ext.define('ctQualityMetricModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'projectNumber', 'domain', 'role', 'projectPhase', 'metricItem', 'formulas', 'unit',
                'targetVal', 'principal', 'actualResult', 'isStandard', 'reasonAnalysis', 'improvementMeasures', 'sumTime'],
            idProperty: 'id'
        });

        var projectMetricStore = Ext.create('Ext.data.Store', {
            id: 'projectMetricStore',
            model: 'ctQualityMetricModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/qualityMetric/getItems',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });
        projectMetricStore.on('beforeload', function (store, options) {
            var data = {
                projectNumber: projectNumber,
                userName: userDisplayName,
                projectPhase: projectPhase
            };
            Ext.apply(projectMetricStore.proxy.extraParams, data);
        });

        Ext.define('trReviewModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'projectNumber', 'docBranchId', 'trDot', 'role', 'principal', 'domain', 'reviewElements', 'remark', 'trType'
                , 'SelfTestResult', 'SelfTestExplain', 'operationGuide'],
            idProperty: 'id'
        });
        var trReviewStore = Ext.create('Ext.data.Store', {
            id: 'trReviewStore',
            model: 'trReviewModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trReview/getTrReview',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });
        trReviewStore.on('beforeload', function (store, options) {
            var data = {
                branchId: branchId,
                projectNumber: projectNumber,
                userName: userDisplayName,
                projectPhase: projectPhase
            };
            Ext.apply(trReviewStore.proxy.extraParams, data);
        });

        Ext.define('CtQualityStandardModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'projectNumber', 'role', 'branchId', 'cruxNode', 'qualityTarget', 'require', 'principals'
                , 'actualResult', 'isStandard', 'reasonAnalysis', 'improvementMeasures'],
            idProperty: 'id'
        });
        var qualityStandardStore = Ext.create('Ext.data.Store', {
            id: 'qualityStandardStore',
            model: 'CtQualityStandardModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/qualityStandard/getItems',
                method: 'GET',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });
        qualityStandardStore.on('beforeload', function (store, options) {
            var data = {
                projectNumber: projectNumber,
                userName: userDisplayName,
                projectPhase: projectPhase
            };
            Ext.apply(qualityStandardStore.proxy.extraParams, data);
        });


        Ext.define('ctRiskAssessModel', {
            extend: 'Ext.data.Model',
            fields: ['id', 'riskId','riskCreatPeople', 'evaluationDept', 'proposedTime', 'projectPhase', 'riskCategory', 'riskDescription', 'riskEffect', 'severity', 'occurrence',
                'detection', 'levelOfRisk', 'responseCategories', 'actionsForRisk', 'ownerDept', 'owner', 'plannedFinishDate', 'currentStatus', 'severity2',
                'occurrence2', 'detection2', 'whetherPass', 'levelOfRisk2', 'businessStatus', 'riskHappenedOrNot', 'pqaEnsure', 'pqaRemark', 'branchId', 'creator'],
            idProperty: 'id'
        });

        var riskStore = Ext.create('Ext.data.Store', {
            // pageSize: 1,
            model: 'ctRiskAssessModel',
            id: 'riskStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/trReview/getRisk?projectNumber=' + projectNumber,
                method: 'GET',
                reader: {
                    type: 'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var isStandardCombo = new Ext.form.ComboBox({
            name: 'isStandardCombo',
            id: 'isStandardCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: [['达标', '达标'], ['未达标', '未达标']]
        });

        //项目阶段
        var projectPhaseCombo = new Ext.form.ComboBox({
            name: 'projectPhaseCombo',
            id: 'projectPhaseCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//TR2， TR4，TR4A, TR5, TR6
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'groupName',
                    'groupName'
                ],
                data: [['TR2', 'TR2'], ['TR4', 'TR4'], ['TR4A', 'TR4A'],
                    ['TR5', 'TR5'], ['TR6', 'TR6']]
            }),
        });

        //自检结果
        var selfTestResultCombo = new Ext.form.ComboBox({
            name: 'selfTestResultCombo',
            id: 'selfTestResultCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'groupName',
                    'groupName'
                ],
                data: [['是', '是'], ['否', '否'], ['免', '免']]
            }),
        });


        //角色
        var roleCombo = new Ext.form.ComboBox({
            name: 'roleCombo',
            id: 'roleCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable: false,//TR2， TR4，TR4A, TR5, TR6
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'groupName',
                    'groupName'
                ],
                data: [['开发代表', '开发代表'], ['制造代表', '制造代表'], ['认证工程师', '认证工程师'],
                    ['PQA', 'PQA'], ['项目管理', '项目管理'], ['财务代表', '财务代表'], ['测试代表', '测试代表'],
                    ['市场代表', '市场代表'], ['SE或SE指定专家', 'SE或SE指定专家'], ['技术支持代表', '技术支持代表'],
                    ['测试小组组长', '测试小组组长'], ['PME', 'PME'], ['采购代表', '采购代表'], ['工业设计工程师', '工业设计工程师'],]
            }),
        });

//========可编辑列头显示控制============
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        //========字段定义=============
        var actualValTest = '实际值';
        var isStandardTest = '是否达标';
        var varianceAnalysisTest = '偏差分析';

        var domainTest = '领域';
        var reviewElementsTest = '评审要素';
        var operationGuideTest = '评审操作指导';
        var trTypeTest = '类别';
        var remarkTest = '备注项';
        var roleTest = '角色';
        var principalTest = '责任人';
        var selfTestResultTest = '自检结果';
        var selfTestExplainTest = '自检说明';

        var actualResultTest = '实际结果';
        var isStandardTest = '是否达标';
        var reasonAnalysisTest = '原因分析';
        var improvementMeasuresTest = '改进措施';
        if (!allowEdit) {
            if (actKey == 'ActivityNode_QmsTrReview_CreatorSubmit') {
                domainTest = redStarFlag + blueFlagStart + domainTest + blueFlagEnd;
                reviewElementsTest = redStarFlag + blueFlagStart + reviewElementsTest + blueFlagEnd;
                operationGuideTest = blueFlagStart + operationGuideTest + blueFlagEnd;
                trTypeTest = redStarFlag + blueFlagStart + trTypeTest + blueFlagEnd;
                remarkTest = blueFlagStart + remarkTest + blueFlagEnd;
                roleTest = redStarFlag + blueFlagStart + roleTest + blueFlagEnd;
                principalTest = redStarFlag + blueFlagStart + principalTest + blueFlagEnd;
            } else if (actKey == 'ActivityNode_QmsStandard_ReviewSelfInspectionResults') {
                actualValTest = redStarFlag + blueFlagStart + actualValTest + blueFlagEnd;
                isStandardTest = redStarFlag + blueFlagStart + isStandardTest + blueFlagEnd;
                actualValTest = blueFlagStart + actualValTest + blueFlagEnd;

                selfTestResultTest = redStarFlag + blueFlagStart + selfTestResultTest + blueFlagEnd;
                selfTestExplainTest = blueFlagStart + selfTestExplainTest + blueFlagEnd;

                actualResultTest = redStarFlag + blueFlagStart + actualResultTest + blueFlagEnd;
                isStandardTest = redStarFlag + blueFlagStart + isStandardTest + blueFlagEnd;
                reasonAnalysisTest = redStarFlag + blueFlagStart + reasonAnalysisTest + blueFlagEnd;
            }

        }


        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var ProblemVerifyGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('problemVerifyStore'),
            id: 'ProblemVerifyGrid',
            margin: '20 0 0 0',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            autoScroll: true,
            //region: 'center',
            height: 550,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {
                    text: '子问题处理',
                    columns: [
                        {
                            text: '领域',
                            dataIndex: 'problemTerritory',
                            width: 100,
                            menuDisabled: true,
                        },
                        {text: '子问题承担者', dataIndex: 'undertaker', width: 100, menuDisabled: true,},
                        {
                            text: '初步对策',
                            dataIndex: 'optimizeStrategy',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '计划解决时间',
                            dataIndex: 'planFinishDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '改善结论',
                            dataIndex: 'optimizeResult',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '验证报告编号',
                            dataIndex: 'verifyReportNumber',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '检验报告链接',
                            dataIndex: 'verifyReportLink',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '实际解决时间',
                            dataIndex: 'realitySolveDate',
                            width: 100,
                            menuDisabled: true,
                        },
                        {
                            text: '不整改原因',
                            dataIndex: 'noChangeCause',
                            width: 100,
                            menuDisabled: true,
                        },
                    ],
                },
                {
                    text: '子问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'verifyExplain', width: 100, menuDisabled: true,},
                    ]
                },
                {text: '是否分配人', dataIndex: 'isAssign', width: 100, menuDisabled: true},

            ],
        });


        var followUp = Ext.create('Ext.Window', {
            id: 'followUp',
            title: '子问题跟进',
            width: 1200,
            height: 400,
            autoHeight: true,
            closeAction: 'hide',
            //closable:false,
            constrain: true,
            modal: true,
            items: [ProblemVerifyGrid],
        });

        var ProblemMgtGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('problemStore'),
            id: 'ProblemMgtGrid',
            margin: '20 0 0 0',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            //region: 'center',
            height: 550,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            selType: 'checkboxmodel',
            tbar: [{
                text: '问题跟进信息',
                scope: this,
                handler: function () {
                    var newDocItems = new Array();
                    var removedRecords = ProblemMgtGrid.getSelectionModel().getSelection();

                    if (removedRecords == undefined || removedRecords == null || removedRecords.length == 0) {
                        alert("请选择对应的问题！");
                        return;
                    } else if (removedRecords.length > 1) {
                        alert("一次只能选择一个问题！");
                        return;
                    } else if (removedRecords[0].get('problemStatus') == '已开启') {
                        alert("问题未启动，请先启动问题！");
                        return;
                    }
                    followUp.show();
                    if (removedRecords[0].get("oaNumber") != undefined) {
                        getProblemVerifyInfo(removedRecords[0].get("problemNumber"));
                    } else {
                        getProblemVerifyInfo(removedRecords[0].get("docBranchId"));
                    }
                }
            }
            ],
            columns: [{xtype: 'rownumberer', width: 40},
                {
                    text: '问题提出',
                    columns: [
                        {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'containerId', menuDisabled: true, hidden: true},
                        {text: '', dataIndex: 'problemInput', menuDisabled: true, hidden: true},
                        {text: '问题编号', dataIndex: 'problemNumber', width: 120,},
                        {text: '问题提出者', dataIndex: 'creator', width: 100,},
                        {
                            text: '问题领域', dataIndex: 'problemTerritory', width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                var temp = new Array();
                                if (value == '' || value == undefined || value == null) {
                                    return '';
                                }
                                if (!Array.isArray(value)) {
                                    value += ",";
                                    var start = 0;
                                    var pos = value.indexOf(',');
                                    while (pos > -1) {
                                        temp.push(value.substr(start, pos - start));
                                        start = pos + 1;
                                        pos = value.indexOf(',', pos + 1);
                                    }
                                    record.set("problemTerritory", temp);
                                    record.commit();
                                } else {
                                    temp = value;
                                }
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + temp + "'";
                                return temp;
                            }
                        },
                        {text: '问题级别', dataIndex: 'problemGrade', width: 100,},
                        {
                            text: '问题描述',
                            dataIndex: 'description',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '初步原因分析',
                            dataIndex: 'analysis',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '初步对策', dataIndex: 'optimizeStrategy', width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '临时措施',
                            dataIndex: 'temporaryMeasures',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '计划完成时间',
                            dataIndex: 'planFinishDate',
                            width: 120,
                            menuDisabled: true,

                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                            }
                        },
                        {text: '发起日期', dataIndex: 'startDate', width: 100,},
                        {text: '流程链接', dataIndex: 'processLink', width: 100},
                        {text: '项目阶段', dataIndex: 'projectPhase', width: 100,},
                        {text: 'PQA', dataIndex: 'pqaCheck', width: 100,},
                        {text: '开发代表', dataIndex: 'affirmCheck', width: 100,},
                        {
                            text: '图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: [
                                '->', {
                                    iconCls: 'icon-showImage',
                                    tooltip: '浏览图片',
                                    handler: function (grid, rowIndex, colIndex) {
                                        var record = grid.getStore().getAt(rowIndex);
                                        var problemNumber = record.get('problemNumber');//Ext.id();
                                        problemId = problemNumber;
                                        containerId = record.get('containerId');
                                        problemStatus = record.get('problemStatus');
                                        var list = null;
                                        var flag = false;
                                        //loadMarsk.show();
                                        Ext.Ajax.request({
                                            url: '/Windchill/ptc1/problem/showImage?containerId=' + containerId + '&problemId=' + problemId,
                                            success: function (response, opts) {
                                                var obj = Ext.decode(response.responseText);
                                                if (obj['success']) {
                                                    list = obj['items'];
                                                    store.removeAll();
                                                    for (i in list) {
                                                        //alert(list[i].name);
                                                        store.add({
                                                            name: list[i].name,
                                                            type: list[i].type,
                                                            size: list[i].size,
                                                            lastmod: list[i].lastmod,
                                                            file: '1',
                                                            src: list[i].src,
                                                            width: list[i].width,
                                                            height: list[i].height,
                                                            trueWidth: list[i].width,
                                                            trueHeight: list[i].height,
                                                            display: '1',
                                                            uploaded: false,
                                                            absolute: false,
                                                            top: '10',
                                                            left: '10'
                                                        });
                                                        flag = true;
                                                    }
                                                    if (!flag) {
                                                        //loadMarsk.hide();
                                                        alert('该问题没有配图');
                                                        return;
                                                    }
                                                    viewPhoto(store.getAt(0));
                                                    //loadMarsk.hide();
                                                } else {
                                                    alert(obj['msg'] + "图片");
                                                    //oadMarsk.hide();
                                                }
                                            },
                                            failure: function (response, opts) {
                                                alert('错误：删除失败，请检查网络！');
                                                //loadMarsk.hide();
                                            }
                                        });//~End of request
                                        //loadMarsk.hide();
                                    }
                                }, '->']
                        },
                        {
                            text: '不良比例（%）',
                            dataIndex: 'badProportion',
                            width: 120,
                            menuDisabled: true,
                            minValue: 0
                        },
                        {text: '问题来源', dataIndex: 'problemSource', width: 100,},
                        {text: '成品编号', dataIndex: 'endPartNumber', width: 100,},
                        {text: '产品编号', dataIndex: 'productNumber', width: 100,},
                        {text: 'OA编号', dataIndex: 'oaNumber', width: 100,},
                        {text: '风险编号', dataIndex: 'riskNumber', width: 100,},
                        {text: '相关问题编号', dataIndex: 'relatedProblemNumber', width: 100,},
                        {text: '软件领域问题承担者', dataIndex: 'softwareCharger', width: 140},
                        {text: '硬件领域问题承担者', dataIndex: 'hardwareCharger', width: 140},
                        {text: '工艺领域问题承担者', dataIndex: 'craftCharger', width: 140},
                        {text: '结构领域问题承担者', dataIndex: 'fabricCharger', width: 140},
                        {text: '测试领域问题承担者', dataIndex: 'testCharger', width: 140},
                        {text: '质量领域问题承担者', dataIndex: 'qualityCharger', width: 140},
                        {text: '采购领域问题承担者', dataIndex: 'purchaseCharger', width: 140},
                        {text: '制造领域问题承担者', dataIndex: 'makeCharger', width: 140},
                        {text: '市场领域问题承担者', dataIndex: 'bazaarCharger', width: 140},
                        {text: '其他领域问题承担者', dataIndex: 'elseCharger', width: 140},
                    ]
                },
                /* {
                    text: '问题处理',
                    columns: [
                        {text: '改善结论', dataIndex: 'optimizeResult', width: 100,},
                        {text: '验证报告链接', dataIndex: 'verifyReportLink', width: 100,},
                        {text: '实际解决时间', dataIndex: 'realitySolveDate', width: 100,},
                        {text: '不整改原因', dataIndex: 'noChangeCause', width: 100,},
                    ]
                }, {
                    text: '问题验证',
                    columns: [
                        {text: '验证说明', dataIndex: 'verifyExplain', width: 100,},
                    ]
                },*/ {
                    text: '问题结论',
                    columns: [
                        {text: '问题状态', dataIndex: 'problemStatus', width: 100,},
                        {
                            text: '确认说明',
                            dataIndex: 'confirmExplain',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                    ]
                }, {
                    text: '知识库共享',
                    columns: [{
                        text: '共享', width: 100, dataIndex: 'isShare', menuDisabled: true, value: '已共享',
                        renderer: function (value) {
                            if (value == "1") {
                                value = '已共享'
                            } else {
                                value = "未共享"
                            }
                            return value;
                        }
                    },
                        {
                            text: '补充信息',
                            dataIndex: 'replenish',
                            width: 100,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            }
                        },
                        {
                            text: '补充信息图片操作项',
                            xtype: 'actioncolumn',
                            width: 85,
                            menuDisabled: true,
                            region: 'center',
                            items: ['->', {
                                iconCls: 'icon-showImage',
                                tooltip: '浏览图片',
                                handler: function (grid, rowIndex, colIndex) {
                                    var record = grid.getStore().getAt(rowIndex);
                                    var problemNumber = record.get('problemNumber');//Ext.id();
                                    problemId = problemNumber + '经验知识库';
                                    containerId = record.get('containerId');
                                    problemStatus = record.get('problemStatus');
                                    var list = null;
                                    var flag = false;
                                    //loadMarsk.show();
                                    Ext.Ajax.request({
                                        url: '/Windchill/ptc1/problem/showImage?containerId=' + containerId + '&problemId=' + problemId,
                                        success: function (response, opts) {
                                            var obj = Ext.decode(response.responseText);
                                            if (obj['success']) {
                                                list = obj['items'];
                                                store.removeAll();
                                                for (i in list) {
                                                    //alert(list[i].name);
                                                    store.add({
                                                        name: list[i].name,
                                                        type: list[i].type,
                                                        size: list[i].size,
                                                        lastmod: list[i].lastmod,
                                                        file: '1',
                                                        src: list[i].src,
                                                        width: list[i].width,
                                                        height: list[i].height,
                                                        trueWidth: list[i].width,
                                                        trueHeight: list[i].height,
                                                        display: '1',
                                                        uploaded: false,
                                                        absolute: false,
                                                        top: '10',
                                                        left: '10'
                                                    });
                                                    flag = true;
                                                }
                                                if (!flag) {
                                                    //loadMarsk.hide();
                                                    alert('该问题没有配图');
                                                    return;
                                                }
                                                viewPhoto(store.getAt(0));
                                                //loadMarsk.hide();
                                            } else {
                                                alert(obj['msg'] + "图片");
                                                //oadMarsk.hide();
                                            }
                                        },
                                        failure: function (response, opts) {
                                            alert('错误：删除失败，请检查网络！');
                                            //loadMarsk.hide();
                                        }
                                    });//~End of request
                                    //loadMarsk.hide();
                                }
                            }, '->']
                        },
                        {text: '共享文档链接', dataIndex: 'shareLink', width: 100,}
                    ]
                },
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    return false;
                },
            }
        });

        var projectMetricPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('projectMetricStore'),
            id: 'projectMetricPanel',

            /* forceFit: true,
             autoWidth: true,
             // width:2500,
             autoScroll: true,*/
            //region: 'center',
            height: 550,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer', width: 30},
                //['id' ,'projectNumber','role','projectPhase','metricItem','formulas','unit',
                //                 'targetVal','principal' ,'sumTime'],
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'projectNumber', menuDisabled: true, hidden: true},
                {text: '领域', dataIndex: 'domain', width: 100, menuDisabled: true},
                {text: '项目阶段', dataIndex: 'projectPhase', width: 80, menuDisabled: true},
                {text: '度量项', dataIndex: 'metricItem', width: 220, menuDisabled: true},
                {
                    text: '定义及计算公式', dataIndex: 'formulas', width: 250, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '单位', dataIndex: 'unit', width: 80, menuDisabled: true},
                {text: '目标值', dataIndex: 'targetVal', width: 100, /*editor: 'textfield',*/ menuDisabled: true,},
                {text: '角色', dataIndex: 'role', width: 110,/* editor:roleCombo,*/ menuDisabled: true},
                {
                    text: '度量责任人',
                    dataIndex: 'principal',
                    width: 110,
                    editor: allUserCombo_projectPlan,
                    menuDisabled: true
                },
                {text: '实际值', dataIndex: 'actualVal', width: 110, editor: 'textfield', menuDisabled: true},
                {text: '是否达标', dataIndex: 'isStandard', width: 110, editor: isStandardCombo, menuDisabled: true},
                {text: '偏差分析', dataIndex: 'varianceAnalysis', width: 110, editor: 'textfield', menuDisabled: true},
                {text: '统计时间', dataIndex: 'sumTime', width: 110, editor: 'textfield', menuDisabled: true},
            ],
            tbar: [
                {
                    text: '显示个人',
                    scope: this,
                    id: 'displayUser',
                    handler: function () {
                        userDisplayName = userName;
                        Ext.getStore('projectMetricStore').reload();
                        Ext.getCmp("displayUser").hide();
                        Ext.getCmp("displayAll").show();
                    }
                }, {
                    text: '显示全部',
                    scope: this,
                    id: 'displayAll',
                    hidden: true,
                    handler: function () {
                        userDisplayName = "";
                        Ext.getStore('projectMetricStore').reload();
                        Ext.getCmp("displayUser").show();
                        Ext.getCmp("displayAll").hide();
                    }
                }, {
                    xtype: 'tbtext',
                    text: '',
                    id: 'saveStatus',
                    disabled: true
                }
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {

                    var tField = e.record;
                    var tField2 = e.field; //得到修改列
                    if (!allowEdit) {
                        Ext.getCmp('saveStatus').setText('不可编辑！');
                        return false;
                    } else {
                    	if('principal' == tField2 && actKey == 'ActivityNode_QmsTrReview_CreatorSubmit'){
                        	return true;
                        }else if (actKey == 'ActivityNode_QmsStandard_ReviewSelfInspectionResults') {
                            if (userName != tField.get('principal')) {
                                Ext.getCmp('saveStatus').setText('只能编辑自己负责的行！');
                                return false;
                            } else {
                                Ext.getCmp('saveStatus').setText('');
                                return true;
                            }
                        }
                        return false;
                    }
                },
            }
        });

        var trReviewPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('trReviewStore'),
            id: 'trReviewPanel',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            //autoScroll: true,
            //region: 'center',
            height: 550,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer', width: 30},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'docBranchId', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'projectNumber', menuDisabled: true, hidden: true},
                {text: 'TR点', dataIndex: 'trDot', width: 100,  menuDisabled: true},
                {text: '领域', dataIndex: 'domain', width: 120, editor: 'textfield',  menuDisabled: true},
                {
                    text: '评审要素',
                    dataIndex: 'reviewElements',
                    width: 200,
                    editor: 'textarea',
                    align: 'left',
                    menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {
                    text: '评审操作指导',
                    dataIndex: 'operationGuide',
                    width: 220,

                    editor: 'textarea',
                    menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '类别', dataIndex: 'trType', width: 80, editor: 'textfield',  menuDisabled: true},
                {
                    text: '备注项',
                    dataIndex: 'remark',
                    width: 220,
                    editor: 'textfield',

                    menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        //提示tip
                        metaData.tdAttr = " data-qtip = '" + value + "'";
                        return value;
                    }
                },
                {text: '角色', dataIndex: 'role', width: 120, editor: roleCombo,  menuDisabled: true},
                {
                    text: '责任人',
                    dataIndex: 'principal',
                    width: 80,
                    editor: allUserCombo_projectPlan,

                    menuDisabled: true
                },
                {
                    text: '自检结果',
                    dataIndex: 'selfTestResult',
                    width: 80,
                    editor: selfTestResultCombo,

                    menuDisabled: true,
                    renderer: function (v, m) {
                        if (v == '否') {
                            m.css = 'x-grid-red';
                        } else if (v == '免') {
                            m.css = 'x-grid-green';
                        }
                        return v;
                    }
                },
                {
                    text: '自检说明',
                    dataIndex: 'selfTestExplain',
                    width: 220,

                    editor: 'textarea',
                    menuDisabled: true
                },
                //{text: '', dataIndex: '', flex:1},
            ],
            tbar: [
                {
                    hidden: actKey == 'ActivityNode_QmsTrReview_CreatorSubmit' ? false : actKey == 'ActivityNode_QmsStandard_PQA' ? false : true,
                    iconCls: 'icon-add',
                    xtype: 'button',
                    text: '添加',
                    handler: function () {
                        Ext.Ajax.request({
                            scope: this,
                            url: '/Windchill/ptc1/trReview/addTrReview',
                            params: {
                                oid: oid,
                                branchId: branchId
                            },
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if (obj.message == 'success') {
                                    Ext.getStore('trReviewStore').reload();
                                } else {
                                    alert(obj.message);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：保存信息失败，请检查网络！');
                            }
                        }); //~End of Ajax request
                        // Ext.getCmp('requireWin').close();
                    }
                },
                {
                    hidden: actKey == 'ActivityNode_QmsTrReview_CreatorSubmit' ? false : actKey == 'ActivityNode_QmsStandard_PQA' ? false : true,
                    iconCls: 'icon-delete',
                    xtype: 'button',
                    text: '删除',
                    handler: function () {
                        let selectionArr = trReviewPanel.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('trReviewStore').reload()
                        };
                        deleteTrReview(obj, callbackFn);

                    }
                },{
                    //hidden: actKey == 'ActivityNode_QmsTrReview_CreatorSubmit' ? false : actKey == 'ActivityNode_QmsStandard_PQA' ? false : true,
                    iconCls: 'icon icon-download',
                    xtype: 'button',
                    text: '导出',
                    handler: function () {
                        window.location.href = '/Windchill/ptc1/trReview/exporTrReviews?branchId='+ branchId +
                            '&projectNumber=' + projectNumber+ '&userName='+ userDisplayName +'&projectPhase='+ projectPhase
                    }
                }, {
                    text: '显示个人',
                    scope: this,
                    id: 'displayUser1',
                    handler: function () {
                        userDisplayName = userName;
                        Ext.getStore('trReviewStore').reload();
                        Ext.getCmp("displayUser1").hide();
                        Ext.getCmp("displayAll1").show();
                    }
                }, {
                    text: '显示全部',
                    scope: this,
                    id: 'displayAll1',
                    hidden: true,
                    handler: function () {
                        userDisplayName = "";
                        Ext.getStore('trReviewStore').reload();
                        Ext.getCmp("displayAll1").hide();
                        Ext.getCmp("displayUser1").show();
                    }
                }, {
                    xtype: 'tbtext',
                    text: '',
                    id: 'saveStatus2',
                    disabled: true
                }
            ],
            listeners: {
                cellclick: function (grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    if (cellIndex > 0 && cellIndex < 6) {
                        id = record.get("id");
                        var myWindow = Ext.create('Ext.Window', {
                            id: 'workReportWin',
                            title: '详细信息',
                            width: 700,
                            autoHeight: true,
                            closeAction: 'destroy',
                            //closable:false,
                            constrain: true,
                            modal: true,
                            items: [{xtype: 'TrReviewSingle'}]
                        });
                        myWindow.show();

                    }
                },

                beforeedit: function (editor, e, eOpts) {
                    var tField = e.record;

                    if (!allowEdit) {
                        Ext.getCmp('saveStatus2').setText('不可编辑！');
                        return false;
                    } else {
                        if (actKey == 'ActivityNode_QmsTrReview_CreatorSubmit') {
                            if (e.field == 'selfTestResult' || e.field == 'selfTestExplain') {
                                return false;
                            } else {
                                return true
                            }
                        } else if (actKey == 'ActivityNode_QmsStandard_ReviewSelfInspectionResults') {
                            if (userName != tField.get('principal')) {
                                Ext.getCmp('saveStatus2').setText('只能编辑自己负责的行！');
                                return false;
                            } else {
                                if (e.field == 'selfTestResult' || e.field == 'selfTestExplain') {
                                    Ext.getCmp('saveStatus2').setText('');
                                    return true
                                } else {
                                    return false;
                                }
                            }
                        }
                        return false
                    }
                },
            }

        });

        var qualityStandardPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('qualityStandardStore'),
            id: 'qualityStandardPanel',
            /*forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,*/
            region: 'center',
            height: 550,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer', width: 30},
                /**['id' ,'projectNumber','role','branchId','cruxNode','qualityTarget','require','principals','principalSection'
                 ,'actualResult','isStandard','reasonAnalysis','improvementMeasures'],*/
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'projectNumber', menuDisabled: true, hidden: true},
                {text: '关键节点', dataIndex: 'cruxNode', width: 80, menuDisabled: true},
                {text: '角色', dataIndex: 'role', width: 100, menuDisabled: true},
                {text: '质量指标', dataIndex: 'qualityTarget', width: 220, menuDisabled: true},
                {text: '描述', dataIndex: 'describe', width: 250, menuDisabled: true},
                {text: '要求', dataIndex: 'require', width: 230, menuDisabled: true},
                {
                    text: '度量责任人',
                    dataIndex: 'principal',
                    width: 120,
                    editor: allUserCombo_projectPlan,
                    menuDisabled: true
                },
               /* {text: '度量责任人', dataIndex: 'principal', width: 120, menuDisabled: true},*/
                {text: '实际结果', dataIndex: 'actualResult', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '是否达标', dataIndex: 'isStandard', width: 120, editor: isStandardCombo, menuDisabled: true},
                {text: '原因分析', dataIndex: 'reasonAnalysis', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '改进措施', dataIndex: 'improvementMeasures', width: 120, editor: 'textfield', menuDisabled: true},
            ],
            tbar: [
                {
                    text: '显示个人',
                    scope: this,
                    id: 'displayUser2',
                    handler: function () {
                        userDisplayName = userName;
                        Ext.getStore('qualityStandardStore').reload();
                        Ext.getCmp("displayUser2").hide();
                        Ext.getCmp("displayAll2").show();
                    }
                }, {
                    text: '显示全部',
                    scope: this,
                    id: 'displayAll2',
                    hidden: true,
                    handler: function () {
                        userDisplayName = "";
                        Ext.getStore('qualityStandardStore').reload();
                        Ext.getCmp("displayUser2").show();
                        Ext.getCmp("displayAll2").hide();
                    }
                }, {
                    xtype: 'tbtext',
                    text: '',
                    id: 'saveStatus1',
                    disabled: true
                }
                /*{
                hidden: !allowEdit,
                iconCls: 'icon-add',
                xtype: 'button',
                text: '添加',
                id: 'addData1',
                handler: function () {
                    Ext.Ajax.request({
                        scope: this,
                        url: '/Windchill/ptc1/qualityStandard/addQualityStandard',
                        params: {
                            oid: oid,
                            branchId: branchId
                        },
                        success: function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (obj.message == 'success') {

                                Ext.getStore('qualityStandardStore').reload();
                                //
                                // Ext.getCmp('workReportWin').close();
                            } else {
                                alert(obj.message);
                            }
                        },
                        failure: function (response, opts) {
                            alert('错误：保存信息失败，请检查网络！');
                        }
                    }); //~End of Ajax request
                    // Ext.getCmp('requireWin').close();
                }
            },
                {
                    hidden: !allowEdit,
                    iconCls: 'icon-delete',
                    xtype: 'button',
                    text: '删除',
                    id: 'removeData1',
                    handler: function () {
                        let selectionArr = qualityStandardPanel.getSelectionModel().getSelection();
                        if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
                            Ext.Msg.alert("提示", "请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr, function (record) {
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('qualityStandardStore').reload()
                        };
                        deleteQualityStandard(obj, callbackFn);

                    }
                }*/],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    var tField = e.record;
                    var tField3 = e.field; //得到修改列
                    if (!allowEdit) {
                        Ext.getCmp('saveStatus1').setText('不可编辑！');
                        return false;
                    } else {
                    	if('principal' == tField3 && actKey == 'ActivityNode_QmsTrReview_CreatorSubmit'){
                        	return true;
                        }else if (actKey == 'ActivityNode_QmsStandard_ReviewSelfInspectionResults') {
                            if (userName != tField.get('principal')) {
                                Ext.getCmp('saveStatus1').setText('只能编辑自己负责的行！');
                                return false;
                            } else {
                                Ext.getCmp('saveStatus1').setText('');
                                return true;
                            }
                        }
                        return false;
                    }

                },
            }
        });

        var riskManagementPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('riskStore'),
            id: 'riskManagementPanel',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: 550,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            /*columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '评价', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '提出', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '项目', dataIndex: 'projectPhase', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险描述', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '潜在风险影响', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '严重', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '发生', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '探刻度', dataIndex: 'data9', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险', dataIndex: 'data10', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险', dataIndex: 'data11', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '应对措施', dataIndex: 'data12', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险应对措施', dataIndex: 'actionsForRisk', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '负责人', dataIndex: 'owner', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '预计完成', dataIndex: 'plannedFinishDate', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险描述', dataIndex: 'riskDescription', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '潜在风险影响', dataIndex: 'riskEffect', width: 80, editor: 'textfield', menuDisabled: true},
            ]*/
            columns: [{xtype: 'rownumberer', width: 30},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {
                    text: '风险提出', columns: [
                        {text: '风险ID', dataIndex: 'riskId', width: 100, editor: 'textfield', menuDisabled: true},
                        {text: '风险识别人', dataIndex: 'riskCreatPeople',width: 120, menuDisabled: true,  align: 'center'},
                        {
                            text: '提出时间<br>Proposed time',
                            dataIndex: 'proposedTime',
                            width: 120,
                            editor: new Ext.form.DateField({minValue: new Date(), format: 'Y-m-d',}),
                            menuDisabled: true,

                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                                return value;
                            }
                        },
                        {
                            text: '项目阶段<br>Project phase  ',
                            dataIndex: 'projectPhase',
                            width: 120,
                            menuDisabled: true,
                            align: 'center',
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                        },
                        {
                            text: '风险类型<br>Risk category',
                            dataIndex: 'riskCategory',
                            width: 120,
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                            align: 'center'
                        },
                        {
                            text: '风险描述<br>Risk description',
                            dataIndex: 'riskDescription',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                            align: 'center'
                        },
                        {
                            text: '潜在风险影响、失效后果<br>Risk Effect',
                            dataIndex: 'riskEffect',
                            width: 140,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                            align: 'center'
                        },
                        {
                            text: '严重度<br>Severity (S) ',
                            dataIndex: 'severity',
                            width: 120,
                            menuDisabled: true,

                        },
                        {
                            text: '发生度<br>Occurrence (O)',
                            dataIndex: 'occurrence',
                            width: 120,
                            menuDisabled: true,

                        },
                        {
                            text: '探测度<br>Detection (D)',
                            dataIndex: 'detection',
                            width: 120,
                            menuDisabled: true,

                        },
                        {
                            text: '风险优先级<br>AP',
                            dataIndex: 'levelOfRisk',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                            align: 'center'
                        },
                        {
                            text: '应对措施类别<br>Response categories',
                            dataIndex: 'responseCategories',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                            align: 'center'
                        },
                        {
                            text: '风险应对措施<br>Actions for risk',
                            dataIndex: 'actionsForRisk',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                            align: 'center'
                        },
                        {
                            text: '责任部门',
                            dataIndex: 'ownerDept',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,
                            align: 'center'
                        },
                        {
                            text: '责任人<br>Owner',
                            dataIndex: 'owner',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,

                            renderer: function (value, meta, record) {
                                // sleep(1000);
                                debugger
                                let displayName = value;
                                if(value){
                                    let riskByPurchaseAsscessStore = allUserCombo.getStore();
                                    riskByPurchaseAsscessStore.each(function(rec){
                                        if(rec.get('no') == value){
                                            displayName =  rec.get('userFullName');
                                        }
                                    });
                                }
                                return displayName;
                            }
                        },
                        {
                            text: '预计完成日期<br>Planned finish date',
                            dataIndex: 'plannedFinishDate',
                            width: 120,
                            editor: new Ext.form.DateField({minValue: new Date(), format: 'Y-m-d',}),
                            menuDisabled: true,

                        },
                    ],
                },
                {
                    text: '风险更进', columns: [
                        {
                            text: '措施实施进展<br>Current status',
                            dataIndex: 'currentStatus',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,
                            renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                            align: 'center'
                        },
                        {
                            text: '严重度<br>Severity (S) ',
                            dataIndex: 'severity2',
                            width: 120,
                            menuDisabled: true,
                            align: 'center'
                        },
                        {
                            text: '发生度<br>Occurrence (O) ',
                            dataIndex: 'occurrence2',
                            width: 120,
                            menuDisabled: true,
                            align: 'center'
                        },
                        {
                            text: '探测度<br>Detection (D)',
                            dataIndex: 'detection2',
                            width: 120,
                            menuDisabled: true,
                            align: 'center'
                        },
                        {
                            text: '风险是否发生<br>Risk happened or not',
                            dataIndex: 'riskHappenedOrNot',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,
                            align: 'center'
                        },
                        {
                            text: '问题ID',
                            dataIndex: 'problemId',
                            width: 120,
                            editor: 'textfield',
                            menuDisabled: true,
                            align: 'center'
                        },
                    ],
                },
                {
                    text: '风险确认', columns: [
                        {text: '当前状态', dataIndex: 'businessStatus', width: 120, menuDisabled: true, align: 'center'},
                        {
                            text: '实际完成时间',
                            dataIndex: 'pqaEnsure',
                            width: 120,
                            editor: new Ext.form.DateField({minValue: new Date(), format: 'Y-m-d',}),
                            menuDisabled: true,

                            renderer: function (value) {
                                if (value != null && value != undefined && value != '') {
                                    var date = new Date(value);
                                    var time = Ext.Date.format(date, "Y-m-d")
                                    return time;
                                }
                                return value;
                            }
                        },
                        {text: 'PQA备注', dataIndex: 'pqaRemark', width: 120, menuDisabled: true, renderer: function (value, metaData, record, row, col, store) {
                                //提示tip
                                metaData.tdAttr = " data-qtip = '" + value + "'";
                                return value;
                            },
                            align: 'center'}
                    ],
                },
            ],
            tbar:[
                {
                    xtype: 'tbtext',
                    text: '',
                    id: 'riskLink',
                    disabled: true
                }
            ],
            listeners: {
                beforeedit: function (editor, e, eOpts) {
                    return false;

                },
            }
        });


        projectMetricPanel.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    //tRecord.commit();
                    Ext.getStore('projectMetricStore').reload()
                };
                updateData('ZQualityMetric', itemId, tField, tValue, tRecord, callbackFn);

            });
        trReviewPanel.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');


                var callbackFn = function () {
                    if (tField == 'principal') {
                        Ext.getStore('trReviewStore').reload()
                    }
                    tRecord.commit();
                };
                updateData('ZTrReview', itemId, tField, tValue, tRecord, callbackFn);

            });
        qualityStandardPanel.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    //tRecord.commit();
                    Ext.getStore('qualityStandardStore').reload()
                };
                updateData('ZQualityStandard', itemId, tField, tValue, tRecord, callbackFn);

            });


        var tabs2 = Ext.widget('tabpanel', {
            renderTo: document.body,
            activeTab: 0,
            plain: true,
            //autoScroll: true,
            height: '100%',
            defaults: {
                //autoScroll: true,
                bodyPadding: 0
            },
            items: [{
                title: 'TR评审表',
                items: trReviewPanel
            }, {
                title: '项目度量表',
                items: projectMetricPanel
            }, {
                title: '质量标准表',
                items: qualityStandardPanel
            }, {
                title: '风险管理表',
                items: riskManagementPanel,
            }, {
                title: '项目研发过程问题跟踪',
                items: ProblemMgtGrid
            }]
        });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{}, tabs2]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('problemStore').load({
                params: {
                    projectNumber: projectNumber,
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('projectMetricStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('trReviewStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('qualityStandardStore').load({
                params: {projectNumber: projectNumber},
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('riskStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            getRiskLink();
        }
    }
});


function getRiskLink() {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/trReview/getRiskLink',
        method:"POST",
        params:{
            projectNumber:projectNumber
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=='success'){
                Ext.getCmp("riskLink").setText('风险文档链接：'+obj.data);
                console.log(obj.data)
            }else{
                alert(obj.message);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存项目度量信息失败，请检查网络！');
        }
    });
}