Ext.define('PLM.view.qualityMetric', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.qualityMetric',
    border: false,
    autoScroll: false,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'qualityMetric',
    initComponent: function () {
        var me = this;

        Ext.define('ctQualityMetricModel', {
            extend: 'Ext.data.Model',
            fields:['id' ,'projectNumber','domain','role','projectPhase','metricItem','formulas','unit',
                'targetVal','principal' ,'sumTime'],
            idProperty: 'id'
        });

        Ext.define('CtQualityStandardModel', {
            extend: 'Ext.data.Model',
            fields:['id' ,'projectNumber','role','branchId','cruxNode','qualityTarget','describe','require','principal'],
            idProperty: 'id'
        });

        //========可编辑列头显示控制============
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';


        var domainText = '领域';
        var projectPhaseText = '项目阶段';
        var metricItemText = '度量项';
        var formulasText = '定义及计算公式';
        var unitText = '单位';
        var targetValText = '目标值';
        var roleText = '角色';
        var principalText = '度量责任人';

        var cruxNodeText = '关键节点';
        var qualityTargetText = '质量指标';
        var describeText = '描述';
        var requireText = '要求';

        if(allowEdit){
            roleText = redStarFlag+blueFlagStart+roleText+blueFlagEnd
            domainText = redStarFlag+blueFlagStart+domainText+blueFlagEnd
            projectPhaseText = redStarFlag+blueFlagStart+projectPhaseText+blueFlagEnd
            metricItemText = redStarFlag+blueFlagStart+metricItemText+blueFlagEnd
            formulasText = blueFlagStart+formulasText+blueFlagEnd
            unitText = redStarFlag+blueFlagStart+unitText+blueFlagEnd
            targetValText = redStarFlag+blueFlagStart+targetValText+blueFlagEnd
            principalText = redStarFlag+blueFlagStart+principalText+blueFlagEnd
            cruxNodeText = redStarFlag+blueFlagStart+cruxNodeText+blueFlagEnd
            qualityTargetText = redStarFlag+blueFlagStart+qualityTargetText+blueFlagEnd
            describeText = blueFlagStart+describeText+blueFlagEnd
            requireText = redStarFlag+blueFlagStart+requireText+blueFlagEnd
        }


        var qualityMetricStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'ctQualityMetricModel',
            id: 'qualityMetricStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/qualityMetric/getItems?branchId='+branchId,
                method: 'GET',
                reader: {
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var qualityStandardStore = Ext.create('Ext.data.Store', {
            pageSize: 1,
            model: 'CtQualityStandardModel',
            id: 'qualityStandardStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/qualityStandard/getItems?branchId='+branchId,
                method: 'GET',
                reader: {
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'error'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });
        var allUserCombo_projectPlan = Ext.create('PLM.hr.CtAllUserCombo', {
            store: allUserStore_projectPlan
        });

        //项目阶段
        var projectPhaseCombo = new Ext.form.ComboBox({
            name : 'projectPhaseCombo',
            id : 'projectPhaseCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable : false,//TR2， TR4，TR4A, TR5, TR6
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'groupName',
                    'groupName'
                ],
                data:  [['TR2', 'TR2'],['TR4', 'TR4'],['TR4A', 'TR4A'],
                    ['TR5', 'TR5'],['TR6','TR6']]
            }),
        });

        //领域
        var territoryCombo = new Ext.form.ComboBox({
            name : 'territoryCombo',
            id : 'territoryCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable : false,//TR2， TR4，TR4A, TR5, TR6
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'groupName',
                    'groupName'
                ],
                data:  [['软件', '软件'],['硬件', '硬件'],['结构', '结构'],
                    ['产品工程', '产品工程'],['测试','测试'],['PDT','PDT']]
            }),
        });

        //角色
        var roleCombo = new Ext.form.ComboBox({
            name : 'roleCombo',
            id : 'roleCombo',
            multiSelect: false,
            valueField: 'groupName',
            displayField: 'groupName',
            anyMatch: true,
            editable : false,//TR2， TR4，TR4A, TR5, TR6
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'groupName',
                    'groupName'
                ],
                data:  [['开发代表', '开发代表'],['制造代表', '制造代表'],['认证工程师', '认证工程师'],
                    ['PQA', 'PQA'],['项目管理','项目管理'],['财务代表','财务代表'],['测试代表','测试代表'],
                    ['市场代表', '市场代表'],['SE或SE指定专家', 'SE或SE指定专家'],['技术支持代表', '技术支持代表'],
                    ['测试小组组长', '测试小组组长'],['PME', 'PME'],['采购代表', '采购代表'],['工业设计工程师', '工业设计工程师'],]
            }),
        });

        var qualityMetricGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: qualityMetricStore,
            selType: 'checkboxmodel',
            id: 'qualityMetricGrid',
            forceFit: true,
            autoWidth: true,
            //width:1550,
            autoScroll: true,
            //region: 'center',
            height: 550,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
            },
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            tbar: [
                {
                    hidden:!allowEdit,
                    iconCls: 'icon-add',
                    xtype: 'button',
                    text: '添加',
                    id: 'addData',
                    handler: function(){
                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/qualityMetric/addQualityMetric',
                            params:{
                                oid:oid,
                                branchId:branchId,
                                projectNumber:projectNumber
                            },
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success'){

                                    Ext.getStore('qualityMetricStore').reload();
                                    //
                                    // Ext.getCmp('workReportWin').close();
                                }else{
                                    alert(obj.message);
                                }
                            },
                            failure: function(response, opts) {
                                alert('错误：保存信息失败，请检查网络！');
                            }
                        }); //~End of Ajax request
                        // Ext.getCmp('requireWin').close();
                    }
                },
                {
                    hidden:!allowEdit,
                    iconCls: 'icon-delete',
                    xtype: 'button',
                    text: '删除',
                    id: 'removeData',
                    handler: function () {
                        let selectionArr = qualityMetricGrid.getSelectionModel().getSelection();
                        if (selectionArr==undefined||selectionArr==null||selectionArr.length==0){
                            Ext.Msg.alert("提示","请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr,function(record){
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('qualityMetricStore').reload()
                        };
                        deleteQualityMetric(obj,callbackFn);

                    }
                }

            ],
            columns: [{xtype: 'rownumberer',width:25},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'projectNumber', menuDisabled: true, hidden: true},
                {text: domainText, dataIndex: 'domain', width: 80, editor: territoryCombo, menuDisabled: true},
                {text: projectPhaseText, dataIndex: 'projectPhase', width: 80,  editor:projectPhaseCombo, menuDisabled: true},
                {text: metricItemText, dataIndex: 'metricItem', width: 280,  editor: 'textfield', menuDisabled: true},
                {text: formulasText, dataIndex: 'formulas', width: 280, editor: 'textfield', menuDisabled: true},
                {text: unitText, dataIndex: 'unit', width: 60, editor: 'textfield', menuDisabled: true},
                {text: targetValText, dataIndex: 'targetVal', width: 120, editor: 'textfield', menuDisabled: true},
                {text: roleText, dataIndex: 'role', width: 120, editor: roleCombo, menuDisabled: true},
                {text: principalText, dataIndex: 'principal', width: 150, editor: allUserCombo_projectPlan, menuDisabled: true},
                //{text: '', dataIndex: '', flex:1},
            ],
            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    var tField = e.field; //得到修改列
                    if(!allowEdit) {
                        return false;
                    }
                },
            }
        });

        qualityMetricGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var id = tRecord.get('id');
                var callbackFn = function () {
                    Ext.getStore('qualityMetricStore').reload()
                    //tRecord.commit();
                    // Ext.getCmp('message').getEl().update('<font style="font-weight:bold;font-style:italic;size: A3;color: darkgrey">保存成功...</font>');
                };
                updateQuality('ZQualityMetric',id,tField,tValue,tRecord,callbackFn);
            });

        var qualityStandardGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('qualityStandardStore'),
            selType: 'checkboxmodel',
            id: 'qualityStandardGrid',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            //region: 'center',
            height: 550,
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
            },
            tbar: [
                {
                    hidden:!allowEdit,
                    iconCls: 'icon-add',
                    xtype: 'button',
                    text: '添加',
                    id: 'addData1',
                    handler: function(){
                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/qualityStandard/addQualityStandard',
                            params:{
                                oid:oid,
                                branchId:branchId,
                                projectNumber:projectNumber
                            },
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(obj.message=='success'){

                                    Ext.getStore('qualityStandardStore').reload();
                                    //
                                    // Ext.getCmp('workReportWin').close();
                                }else{
                                    alert(obj.message);
                                }
                            },
                            failure: function(response, opts) {
                                alert('错误：保存信息失败，请检查网络！');
                            }
                        }); //~End of Ajax request
                        // Ext.getCmp('requireWin').close();
                    }
                },
                {
                    hidden:!allowEdit,
                    iconCls: 'icon-delete',
                    xtype: 'button',
                    text: '删除',
                    id: 'removeData1',
                    handler: function () {
                        let selectionArr = qualityStandardGrid.getSelectionModel().getSelection();
                        if (selectionArr==undefined||selectionArr==null||selectionArr.length==0){
                            Ext.Msg.alert("提示","请选择要删除的数据");
                            return;
                        }
                        //数据组装
                        let obj = new Array();
                        Ext.each(selectionArr,function(record){
                            obj.push(record.data['id'])
                        });
                        var callbackFn = function () {
                            //tRecord.commit();
                            Ext.getStore('qualityStandardStore').reload()
                        };
                        deleteQualityStandard(obj,callbackFn);

                    }
                }
            ],
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer',width:25},
                //'id' ,'role','branchId','cruxNode','qualityTarget','require','principals','principalSection'
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'projectNumber', menuDisabled: true, hidden: true},
                {text: cruxNodeText, dataIndex: 'cruxNode', width: 30,  editor: projectPhaseCombo,menuDisabled: true},
                {text: roleText, dataIndex: 'role', width: 35, editor: roleCombo,  menuDisabled: true},
                {text: qualityTargetText, dataIndex: 'qualityTarget', width: 100, editor: 'textfield',  menuDisabled: true},
                {text: describeText, dataIndex: 'describe', width: 100,  editor: 'textfield', menuDisabled: true},
                {text: requireText, dataIndex: 'require', width: 80, editor: 'textfield', menuDisabled: true},
                {text: principalText, dataIndex: 'principal', width:90, editor: allUserCombo_projectPlan, menuDisabled: true},
            ],
            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    var tField = e.field; //得到修改列

                    if(!allowEdit) {
                        return false;
                    }

                },
            }
        });
        qualityStandardGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var id = tRecord.get('id');
                var callbackFn = function () {
                    Ext.getStore('qualityStandardStore').reload()
                    //tRecord.commit();
                };
                updateQuality('ZQualityStandard',id,tField,tValue,tRecord,callbackFn);
            });

        var tabs2 = Ext.widget('tabpanel', {
            renderTo: document.body,
            activeTab: 0,
            plain: true,
            height:'100%',
            defaults :{
                autoScroll: false,
                bodyPadding: 0
            },
            items: [{
                title: '项目质量标准',
                items:qualityStandardGrid
            },{
                title: '项目度量',
                items: qualityMetricGrid
            }]
        });


        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [tabs2,]
        };




/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('qualityMetricStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
            Ext.getStore('qualityStandardStore').load({
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    }
                }
            });
        }
    }
});

