
//TR修改
function updateData (tableName,id,tField,tValue,tRecord,callbackFn) {
    var data = {
        oid:oid,
        key:tField,
        value:tValue,
        id:id,
        tableName,tableName
    }
    Ext.Ajax.request({
        scope:this,

        url: '/Windchill/ptc1/qualityMetric/updateData',
        method:"POST",
        params:{
            data:Ext.encode(data)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=='success'){
                callbackFn()
            }else{
                alert(obj.message);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存项目度量信息失败，请检查网络！');
        }
    });
}

//质量修改
function updateQuality (tableName,id,tField,tValue,tRecord,callbackFn) {
    var data = {
        oid:oid,
        key:tField,
        value:tValue,
        id:id,
        tableName,tableName
    }
    Ext.Ajax.request({
        scope:this,

        url: '/Windchill/ptc1/qualityMetric/updateQuality',
        method:"POST",
        params:{
            data:Ext.encode(data)
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=='success'){
                callbackFn()
            }else{
                alert(obj.message);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存项目度量信息失败，请检查网络！');
        }
    });
}


//删除
function deleteQualityMetric(dataArray,callback) {
    /*var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"数据正在处理中，请稍后..."});
    myMask.show();*/
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/qualityMetric/deleteData',
        method: "POST",
        params: {
            oid:oid,
            data:Ext.encode(dataArray),
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj.message=='success') {
                Ext.Msg.alert("数据删除失败",obj.message);
               // myMask.hide();
            }else{
               // myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'数据删除失败，请检查网络！')
        }
    });
}

//删除
function deleteQualityStandard(dataArray,callback) {
    /*var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"数据正在处理中，请稍后..."});
    myMask.show();*/
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/qualityStandard/deleteData',
        method: "POST",
        params: {
            oid:oid,
            data:Ext.encode(dataArray),
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj.message=='success') {
                //myMask.hide();
                Ext.Msg.alert("数据删除失败",obj.message);

            }else{
                //myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'数据删除失败，请检查网络！')
        }
    });
}


//删除
function deleteTrReview(dataArray,callback) {
    /*var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"数据正在处理中，请稍后..."});
    myMask.show();*/
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/trReview/delTrReview',
        method: "POST",
        params: {
            data:Ext.encode(dataArray),
        },
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj.message=='success') {
                //myMask.hide();
                Ext.Msg.alert("数据删除失败",obj.message);

            }else{
                //myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'数据删除失败，请检查网络！')
        }
    });
}