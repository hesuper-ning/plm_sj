Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'qualityStandardForm',
        in_objectDesc: '定制的Form表单',
        in_objectKey1: 'projectMetricForm',
        in_objectDesc1: '定制的Form表单',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var qualityStandardStore = Ext.create('PLM.store.MockItemStore', {
            id: 'qualityStandardStore'
        });

        var projectMetricStore = Ext.create('PLM.store.MockItemStore', {
            id: 'projectMetricStore'
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var cellEditing1 = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        //导入panel
        var uploadForm =  new Ext.form.Panel({
            layout:'form',
            id:'uploadForm',
            name:'uploadForm',
            width:450,
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            border:0,
            tbar:[{
                xtype: 'filefield',
                name: 'userfile',
                id:'userfile',
                msgTarget: 'side',
                fieldLabel: '上传Excel文件',
                width: 280,
                anchor: '100%',
                buttonText: '选择文件..',
                buttonOnly: false,
                buttonMargin : '5 5 5 5'
            },{
                xtype:'button',
                padding: '5 5 5 5',
                id:'technic_submit',
                //disabled: existManufacturingViewPart?false:true,
                text: '开始导入',
                handler:function() {
                    var mainForm = Ext.getCmp('uploadForm').getForm();
                    var furl = "";  //文件物理地址
                    var fname=""; //文件名称
                    furl = Ext.getCmp("userfile").getValue();
                    //alert(furl);
                    if(furl == "") {
                        alert("请先选择文件！");
                        return false;
                    }

                    mainForm.submit({
                        //url:'/Windchill/ptc1/problemManage/importProblem?libraryId='+libraryOid+'&containerOid='+containerOid,
                        waitMsg : '正在导入......',
                        waitTitle : '请等待',
                        // method : 'POST',
                        success: function(form,action) {
                            var obj = action.result;
                            if(obj.success) {
                                alert("obj.msgcg");
                                // Ext.getCmp("uploadForm").hide();
                                // refreshProblem();
                                window.parent.location.reload();
                            } else {
                                alert("obj.msgsb");
                            }
                        },
                        failure: function(form,action) {
                            var obj = action.result;
                            alert("yc");
                        },
                        scope : this
                    });
                }
            }]
        });

        //导入窗口
        var uploadPlanWindow = new Ext.create('Ext.Window', {
            title: '批量导入问题',
            // width: 430,
            autoHeight : true,
            autoWidth : true,
            closeAction: 'hide',
            y: '10%',
            id:'uploadProblemWindow',
            constrain: true,
            modal:true,
            layout:'fit',
            //border : 0,
            items: uploadForm
        });

        var qualityStandardGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: Ext.getStore('qualityStandardStore'),
            selType: 'checkboxmodel',
            id: 'qualityStandardGrid',

            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: qualityStandardGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            tbar: [
                {
                    hidden:allowEdit?false:true,
                    iconCls : 'icon-add',
                    xtype: 'button',
                    text: '添加',
                    id:'addData',
                },
                {
                    hidden:allowEdit?false:true,
                    iconCls : 'icon-delete',
                    xtype: 'button',
                    text: '删除',
                    id:'removeData',
                },{
                    hidden:allowEdit?false:true,
                    text : '导入',
                    handler : function() {
                        uploadPlanWindow.show();
                    },
                    scope : this
                }

            ],
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '角色', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '项目阶段', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '度量项', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '定义及计算公式', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '单位', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '目标值', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '度量责任人', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '统计时间', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true}
            ],
            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    var tField = e.field; //得到修改列

                    if(!allowEdit) {
                        return false;
                    }

                },
            }
        });
        qualityStandardGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var projectMetricGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing1],
            store: Ext.getStore('projectMetricStore'),
            selType: 'checkboxmodel',
            id: 'projectMetricGrid',

            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: projectMetricGrid,
                            param_objectKey: me.in_objectKey1,
                            param_objectDesc: me.in_objectDesc1
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            tbar: [
                {
                    hidden:allowEdit?false:true,
                    iconCls : 'icon-add',
                    xtype: 'button',
                    text: '添加',
                    id:'addData1',
                },
                {
                    hidden:allowEdit?false:true,
                    iconCls : 'icon-delete',
                    xtype: 'button',
                    text: '删除',
                    id:'removeData1',
                }
            ],
            listeners: {
                change: 'onAllCircuitsChecked'
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '关键节点', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '角色', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '度量指标', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '要求', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '责任人', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '责任部门', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
            ],
            listeners: {
                beforeedit:function  (editor,  e,  eOpts)  {
                    var tField = e.field; //得到修改列

                    if(!allowEdit) {
                        return false;
                    }

                },
            }
        });
        projectMetricGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey1, this.in_objectDesc1, itemId, tField, tValue, callbackFn);

            });

        var tabs2 = Ext.widget('tabpanel', {
            renderTo: document.body,
            activeTab: 0,
            plain: true,
            height:'98%',
            defaults :{
                autoScroll: true,
                bodyPadding: 0
            },
            items: [{
                title: '项目质量标准',
                items:projectMetricGrid
            },{
                title: '项目度量',
                items: qualityStandardGrid
            }]
        });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{

            }, tabs2]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('qualityStandardStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('qualityStandardStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('qualityStandardStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });

            Ext.getStore('projectMetricStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey1()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('projectMetricStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('projectMetricStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey1()
                                , Ext.getCmp('MockExample').getIn_objectDesc1, callbackFn);
                        }
                    }
                }
            })
        }
    }

});

