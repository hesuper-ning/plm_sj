Ext.define('PLM.view.TrReviewSingle', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.TrReviewSingle',
    border: false,
    autoScroll: true,
    // autoWidth: true,
    // autoHeight: true,
    // collapsible: false,
    config: {
        in_objectKey: 'TrReviewSingle',
        in_objectDesc: 'TR单页面信息',
    },
    id: 'TrReviewSingle',
    initComponent: function () {
        var me = this;


        var viewPanel = new Ext.form.Panel({
            xtype: 'form',
            margin: '10 0 0 0',
            border: false,
            items: [
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'TR点',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'trDot',
                        name: 'trDot',
                        labelWidth: 100
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '领域',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'domain',
                        name: 'domain',
                        labelWidth: 100
                    }
                    ]
                },  {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '类别',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'trType',
                        name: 'trType',
                        labelWidth: 100
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '备注项',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'remark',
                        name: 'remark',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        margin: '0 20 0 0',
                        fieldLabel: '角色',
                        width: 300,
                        id: 'role',
                        name: 'role',
                        labelWidth: 100
                    },{
                        xtype: 'displayfield',
                        margin: '0 20 0 0',
                        fieldLabel: '责任人',
                        width: 300,
                        id: 'principal',
                        name: 'principal',
                        labelWidth: 100
                    }
                    ]
                },{
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '自检结果',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'selfTestResult',
                        name: 'selfTestResult',
                        labelWidth: 100
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: '自检说明',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'selfTestExplain',
                        name: 'selfTestExplain',
                        labelWidth: 100
                    }
                    ]
                },{
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '评审要素',
                        margin: '0 20 0 0',
                        width: 630,
                        id: 'reviewElements',
                        name: 'reviewElements',
                        labelWidth: 100,

                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: '评审操作指导',
                        margin: '0 20 0 0',
                        width: 630,
                        id: 'operationGuide',
                        name: 'operationGuide',
                        labelWidth: 100
                    }
                    ]
                },]
        });

        var viewForm = {
            xtype: 'form',
            id: 'viewForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [viewPanel]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [viewForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            console.log(Ext.getCmp('TrReviewSingle').getIn_objectKey());
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/trReview/getTrReviewById',
                method: 'GET',
                params: {
                    id: id
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);

                    if (obj['message'] == 'success') {
                        var mainPanel = Ext.getCmp('viewForm');
                        mainPanel.getForm().setValues(obj.data);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

