Ext.define('PLM.view.MockExample', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.MockExample',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'mockExampleForm',
        in_objectDesc: '定制的Form表单',
        in_objectKey1: 'mockExampleForm1',
        in_objectDesc1: '定制的Form表单1',
        in_objectKey2: 'mockExampleForm2',
        in_objectDesc2: '定制的Form表单2',
        in_objectKey3: 'mockExampleForm3',
        in_objectDesc3: '定制的Form表单3',
        in_objectKey4: 'mockExampleForm4',
        in_objectDesc4: '定制的Form表单4',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });
        var mockExampleStore1 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore1'
        });
        var mockExampleStore2 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore2'
        });
        var mockExampleStore3 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore3'
        });
        var mockExampleStore4 = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore4'
        });


        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var issueTrackingPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('mockExampleStore'),
            id: 'issueTrackingPanel',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: issueTrackingPanel,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '状态', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '发现阶段', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '问题来源', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '问题描述', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '问题等级', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '提出时间', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '原因分析', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '改善措施', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '责任领域', dataIndex: 'data9', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '责任人', dataIndex: 'data10', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '计划解决时间', dataIndex: 'data11', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '进展', dataIndex: 'data12', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '实际解决时间', dataIndex: 'data13', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '是否超期', dataIndex: 'data14', width: 80, editor: 'textfield', menuDisabled: true},
            ]
        });

        var projectQualityPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('mockExampleStore1'),
            id: 'projectQualityPanel',

            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: projectQualityPanel,
                            param_objectKey: me.in_objectKey1,
                            param_objectDesc: me.in_objectDesc1
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '角色', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '项目阶段', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '度量项', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '定义及计算公式', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '单位', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '目标值', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '度量责任人', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '统计时间', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true},
            ]
        });

        var trReviewPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('mockExampleStore2'),
            id: 'trReviewPanel',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: trReviewPanel,
                            param_objectKey: me.in_objectKey2,
                            param_objectDesc: me.in_objectDesc2
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: 'TR点', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '角色', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '责任人', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '检查项', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '类别', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '自检结果', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '自检说明', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '备注项', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true}
            ]
        });

        var qualityStandardPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('mockExampleStore3'),
            id: 'qualityStandardPanel',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: qualityStandardPanel,
                            param_objectKey: me.in_objectKey3,
                            param_objectDesc: me.in_objectDesc3
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '关键节点', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '领域&角色', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '质量指标', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '要求', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '责任人', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '责任部门', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '实际结果', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '是否达标', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '原因分析', dataIndex: 'data9', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '改进措施', dataIndex: 'data10', width: 80, editor: 'textfield', menuDisabled: true},
            ]
        });

        var riskManagementPanel = Ext.create('Ext.grid.Panel', {
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1
                })
            ],
            store: Ext.getStore('mockExampleStore4'),
            id: 'riskManagementPanel',
            forceFit: true,
            autoWidth: true,
            // width:2500,
            autoScroll: true,
            region: 'center',
            height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: riskManagementPanel,
                            param_objectKey: me.in_objectKey4,
                            param_objectDesc: me.in_objectDesc4
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            selType: 'checkboxmodel',

            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '评价', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                {text: '提出', dataIndex: 'data2', width: 120, editor: 'textfield', menuDisabled: true},
                {text: '项目', dataIndex: 'data3', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险', dataIndex: 'data4', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险描述', dataIndex: 'data5', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '潜在风险影响', dataIndex: 'data6', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '严重', dataIndex: 'data7', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '发生', dataIndex: 'data8', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '探刻度', dataIndex: 'data9', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险', dataIndex: 'data10', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险', dataIndex: 'data11', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '应对措施', dataIndex: 'data12', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险应对措施', dataIndex: 'data13', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '负责人', dataIndex: 'data14', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '预计完成', dataIndex: 'data15', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '风险描述', dataIndex: 'data16', width: 80, editor: 'textfield', menuDisabled: true},
                {text: '潜在风险影响', dataIndex: 'data17', width: 80, editor: 'textfield', menuDisabled: true},
            ]
        });

        issueTrackingPanel.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });
        projectQualityPanel.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });
        trReviewPanel.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });
        qualityStandardPanel.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });
        riskManagementPanel.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var tabs2 = Ext.widget('tabpanel', {
            renderTo: document.body,
            activeTab: 0,
            plain: true,
            height:'100%',
            defaults :{
                autoScroll: true,
                bodyPadding: 0
            },
            items: [{
                title: '项目度量表',
                items:projectQualityPanel
            },{
                title: 'TR评审表',
                items:trReviewPanel
            },{
                title: '质量标准表',
                items:qualityStandardPanel
            },{
                title: '风险管理表',
                items:riskManagementPanel
            },{
                title: '项目研发过程问题跟踪',
                items:issueTrackingPanel
            }]
        });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{

            }, tabs2]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore1').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey1()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore1').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore1').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey1()
                                , Ext.getCmp('MockExample').getIn_objectDesc1, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore2').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey2()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore2').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore2').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey2()
                                , Ext.getCmp('MockExample').getIn_objectDesc2, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore3').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey3()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore3').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore3').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey3()
                                , Ext.getCmp('MockExample').getIn_objectDesc3, callbackFn);
                        }
                    }
                }
            });
            Ext.getStore('mockExampleStore4').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey4()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore4').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore4').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey4()
                                , Ext.getCmp('MockExample').getIn_objectDesc4, callbackFn);
                        }
                    }
                }
            });
        }
    }
});

