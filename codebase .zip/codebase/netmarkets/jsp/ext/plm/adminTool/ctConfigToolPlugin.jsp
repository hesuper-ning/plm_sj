<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        System.out.println(">>>in CtBomToolPlugin.jsp oid="+oid);
    %>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="js/ctConfigToolPanel.js"></script>
    <script type="text/javascript" src="js/jquery-2.0.0.min.js"></script>
</head>

<body>
<script type="javascript">
    //记录点击的更节点，做定点展开
    var rootNode;
    //记录父节点ID，做定点展开
    var parentNodes;
</script>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ConfigToolPanel'
            }]
        });
    });
</script>
</body>
</html>