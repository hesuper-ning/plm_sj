<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page language="java" pageEncoding="UTF-8"%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />

    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/adminTool/configCenter/js/ctConfigCenterPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/adminTool/configCenter/js/ctPropertyConfigPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/adminTool/configCenter/js/ctMultiAttributeConfigPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/adminTool/configCenter/js/ctConfigCenterFunction.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>

<body>
<script type="text/javascript">


</script>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {xtype:'ConfigCenterPanel',
                    region: 'center'
                }
            ]
        });
    });
</script>
</body>
</html>

