Ext.define('MultiAttributeConfigModel', {
    extend: 'Ext.data.Model',
    fields: [
        'id', 'configMenuId'
    ],
    idProperty: 'id'
});

var multiAttributeConfigStore = Ext.create('Ext.data.Store', {
    model: 'MultiAttributeConfigModel',
    id: 'multiAttributeConfigStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/adminTool/configCenter/multiAttribute',
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            totalProperty: 'totalCount',
            idProperty: 'id',
            messageProperty: 'msg'
        }
    }),
    autoLoad: false
});

this.cellEditing2 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});
columns = [
    {text: 'id', dataIndex: 'id', menuDisabled: true, hidden: true},
    {text: 'configMenuId', dataIndex: 'configMenuId', menuDisabled: true, hidden: true}
];
var addMultiAttributeConfigWin;
var multiAttributeConfigGrid = Ext.create('Ext.grid.Panel', {
    plugins: [this.cellEditing2],
    id:'multiAttributeConfigGrid',
    // title: '配置详情',
    // hidden:true,
    store: Ext.data.StoreManager.lookup('multiAttributeConfigStore'),
    autoWidth: true,
    autoScroll: true,
    region: 'center',
    forceFit:true,
    //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
    viewConfig: {enableTextSelection: true},
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        showHeaderCheckbox: true
    }),
    columns: columns,
    tbar: [{
        text: '编辑列',
        iconCls : 'icon icon-save',
        scope: this,
        handler : function(){
            addMultiAttributeConfigWin = Ext.create('Ext.Window', {
                title: '编辑列',
                width: 800,
                //height: 300,
                autoHeight: true,
                closeAction: 'hide',
                //closable:false,
                constrain: true,
                modal: true,
                items: [{
                    xtype: addMultiAttributeConfigPanel
                }]
            });
            addMultiAttributeConfigWin.show();
        }
    },{
        text: '添加',
        iconCls : 'icon icon-add',
        scope: this,
        handler : function(){
            var rec = new Object();
            multiAttributeConfigStore.insert(0, rec);
        }
    },{
        text : '删除',
        iconCls : 'icon icon-delete',
        scope:this,
        handler:function(){
            var delFn = function(){
                var deleteItems = new Array();//删除项
                var sm = multiAttributeConfigGrid.getSelectionModel();

                var tmpStore = Ext.getStore('multiAttributeConfigStore');
                tmpStore.remove(sm.getSelection());

                var removedRecords = tmpStore.getRemovedRecords();

                Ext.each(removedRecords,function(record){
                    deleteItems.push(record.data.id);
                });

                batchDeleteMultiAttributeConfig(deleteItems)
            };//~end of delFn

            Ext.Msg.confirm('提示','确定要删除选中内容？',
                function(btn){
                    if(btn =='yes'){
                        delFn();
                    }else{
                        return;
                    }
                },this);
        }
    }],
    listeners:{

    }

});
multiAttributeConfigGrid.on('edit',function(editor,e){
    var tRecord = e.record; //得到当前行所有数据
    var tField = e.field; //得到修改列
    var tValue = e.value; //得到修改列修改后值
    saveMultiAttributeConfigItems(tRecord,tField,tValue);
});

Ext.define('stringDefinitionModel', {
    extend: 'Ext.data.Model',
    fields: [
        'id', 'configMenuId','innerName','displayName'
    ],
    idProperty: 'id'
});

var stringDefinitionStore = Ext.create('Ext.data.Store', {
    model: 'stringDefinitionModel',
    id: 'stringDefinitionStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/adminTool/configCenter/stringDefinition',
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            totalProperty: 'totalCount',
            idProperty: 'id',
            messageProperty: 'msg'
        }
    }),
    autoLoad: false
});

this.cellEditing3 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var stringDefinitionGrid = Ext.create('Ext.grid.Panel', {
    plugins: [this.cellEditing3],
    id:'stringDefinitionGrid',
    // title: '配置详情',
    // hidden:true,
    store: Ext.data.StoreManager.lookup('stringDefinitionStore'),
    autoWidth: true,
    autoScroll: true,
    region: 'center',
    forceFit:true,
    //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
    viewConfig: {enableTextSelection: true},
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        id: 'stringDefinitionModel',
        showHeaderCheckbox: true
    }),
    columns: [
        {text: 'id', dataIndex: 'id', menuDisabled: true, hidden: true},
        {text: 'configMenuId', dataIndex: 'configMenuId', menuDisabled: true, hidden: true},
        {text: '显示名称', dataIndex: 'displayName',editor: 'textfield', menuDisabled: true},
        {text: '内部名称', dataIndex: 'innerName',editor: 'textfield', menuDisabled: true}
    ],
    tbar: [{
        text: '添加',
        iconCls : 'icon icon-add',
        scope: this,
        handler : function(){
            var rec = new Object();
            rec.configMenuId=Ext.getCmp('nodeId2').getValue();
            stringDefinitionStore.insert(0, rec);
        }
    },{
        text : '删除',
        iconCls : 'icon icon-delete',
        scope:this,
        handler:function(){
            var deleteItems = new Array();
            var sm = stringDefinitionGrid.getSelectionModel();

            var tmpStore = Ext.getStore('stringDefinitionStore');
            tmpStore.remove(sm.getSelection());
        }
    }],
    listeners:{

    }

});

var addMultiAttributeConfigPanel = Ext.create('Ext.panel.Panel', {
    xtype: 'form',
    border: false,
    items: [stringDefinitionGrid,{
        xtype: 'button',
        text: '保存',
        margin: '10 5 10 60',
        scope: this,
        handler: function () {
            Ext.Msg.confirm('提示', '是否要保存配置？',
                function (btn) {
                    if (btn == 'yes') {
                       let items= stringDefinitionStore.data.items;
                       if (items){
                           let errorMsg="";
                           let data=new Array();
                           for (let i=0;i<items.length;i++){
                               let obj=items[i].data;

                               if (obj.id && obj.id.indexOf("stringDefinitionModel")>=0){
                                   obj.id=null;
                               }

                               let rowCount=i+1;
                               if (!obj.displayName){
                                   errorMsg+="第"+rowCount+"行：显示名称为空！\r\n";
                               }
                               if (!obj.innerName){
                                   errorMsg+="第"+rowCount+"行：内部名称为空！\r\n";
                               }
                               data.push(obj);
                           }
                           if (errorMsg!==""){
                               alert(errorMsg);
                               return;
                           }
                           batchSaveStringDefinition(data,addMultiAttributeConfigWin,Ext.getCmp('nodeId2').getValue());
                       }
                    } else {
                        return;
                    }
                }, this);

        }
    }]
});

var multiAttributeConfigPanel = {
    xtype: 'panel',
    autoWidth:true,
    autoHeight:true,
    id:"multiAttributeConfigPanel",
    title: '节点详情',
    hidden:true,
    items: [{
        layout: 'hbox',
        border: false,
        margin: '10 5 10 20',
        items: [{
            xtype: 'textfield',
            margin: '0 20 0 0',
            disabled: true,
            fieldLabel: '节点名称',
            labelWidth: 70,
            width: 400,
            id: 'nodeName2'
        }, {
            xtype: 'textfield',
            margin: '0 20 0 0',
            disabled: true,
            fieldLabel: '节点内部名称',
            labelWidth: 90,
            width: 400,
            id: 'nodeInnerName2'
        }, {
            xtype: 'textfield',
            fieldLabel: 'nodeId',
            hidden: true,
            labelWidth: 30,
            width: 300,
            id: 'nodeId2',
            name: 'nodeId2'
        }, {
            xtype: 'textfield',
            fieldLabel: 'nodeParentId',
            labelWidth: 30,
            hidden: true,
            width: 300,
            id: 'nodeParentId2',
            name: 'nodeParentId2'
        }]
    },{
        layout: 'hbox',
        border: false,
        margin: '10 5 10 20',
        items: [{
            xtype:'button',
            id:'edit2',
            margin: '10 0 0 0',
            text: '编辑',
            handler:function () {
                Ext.getCmp('nodeName2').setDisabled(false);
                Ext.getCmp('nodeInnerName2').setDisabled(false);
                Ext.getCmp('saveInfo2').enable();
            }
        },{
            xtype:'button',
            id:'saveInfo2',
            margin:'10 0 0 10',
            disabled:true,
            text: '保存',
            handler:function () {
                //获取节点id
                var nodeName = Ext.getCmp('nodeName2').getValue();
                var nodeInnerName = Ext.getCmp('nodeInnerName2').getValue();
                var nodeParentId = Ext.getCmp('nodeParentId2').getValue();
                var nodeId = Ext.getCmp('nodeId2').getValue();

                var data = {
                    id:nodeId,
                    text:nodeName,
                    innerName:nodeInnerName,
                    parentId:nodeParentId
                };
                updateConfigNode(data,true);
            }
        }]
    },multiAttributeConfigGrid]
};

