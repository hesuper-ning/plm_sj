<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@page import="wt.workflow.work.WorkItem,wt.doc.WTDocument"%>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%
    String oid = request.getParameter("oid");
%>

<iframe id="<%=oid%>" src="netmarkets/jsp/ext/plm/adminTool/configCenter/ctConfigCenter.jsp?oid=<%=oid%>" style="width:98%;height:800px" ></iframe>