/**
 * 新增菜单节点
 * @param parentId
 */
function addConfigNode(parentId,multiAttributeStatus) {
    var data = {
        parentId:parentId,
        innerName:Ext.getCmp('innerName').getValue(),
        text:Ext.getCmp('displayName').getValue(),
        multiAttributeStatus:multiAttributeStatus
    };

    var jsonStr = Ext.encode(data);

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/menu',
        headers:{'Content-Type':'application/json'},
        method:"POST",
        jsonData:jsonStr,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.status===200) {
                refreshConfigTree();
            }else{
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            alert('错误：添加节点失败，请检查网络！');
        }
    });

}

/**
 * 更新菜单节点
 * @param data
 * @param isMulti
 */
function updateConfigNode(data,isMulti) {
    var jsonStr = Ext.encode(data);

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/menu',
        headers:{'Content-Type':'application/json'},
        method:"PUT",
        jsonData:jsonStr,
        success: function(response, opts) {
            setDisabled(isMulti);
            var obj = Ext.decode(response.responseText);
            if(obj.status===200) {
                refreshConfigTree();
            }else{
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            setDisabled(isMulti);
            alert('错误：添加节点失败，请检查网络！');
        }
    });

}

function setDisabled(isMulti) {
    if (isMulti){
        Ext.getCmp('nodeName2').setDisabled(true);
        Ext.getCmp('nodeInnerName2').setDisabled(true);
        Ext.getCmp('saveInfo2').disable();
    }else {
        Ext.getCmp('nodeName').setDisabled(true);
        Ext.getCmp('nodeInnerName').setDisabled(true);
        Ext.getCmp('saveInfo').disable();
    }
}

/**
 * 刷新菜单配置树
 */
function refreshConfigTree() {
    Ext.getStore('configTreeStore').load({
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.error);
            }
        }
    });
}

/**
 * 删除菜单配置节点
 * @param id
 */
function deleteConfigNode(id) {
    let ids=new Array();
    ids.push(id);

    var jsonStr = Ext.encode(ids);

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/menu/batch',
        headers:{'Content-Type':'application/json'},
        method:"DELETE",
        jsonData:jsonStr,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.status===200) {
                refreshConfigTree();
            }else{
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            alert('错误：删除节点失败，请检查网络！');
        }
    });
}

/**
 * 刷新property配置gird
 * @param menuId
 */
function refreshConfigPropertyStore(menuId) {
    Ext.getStore('configPropertyStore').load({
        params:{menuId:menuId},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.error);
            }
        }
    });
}

/**
 * 保存property配置
 * @param tRecord
 */
function saveConfigPropertyItems(tRecord) {

    let configMenuId = Ext.getCmp('nodeId').getValue();
    let id = tRecord.get("id");
    if (id.indexOf("configPropertyModel")>=0){
        id=null;
    }
    var data = {
        configMenuId:configMenuId,
        id:id,
        propertyKey:tRecord.get("propertyKey"),
        propertyValue:tRecord.get("propertyValue"),
        splitChart:tRecord.get("splitChart"),
        remark:tRecord.get("remark")
    };

    var jsonStr = Ext.encode(data);

    if (id){
        updatePropertyConfig(jsonStr,tRecord);
    }else {
        createPropertyConfig(jsonStr,tRecord);
    }
}

/**
 * 更新property配置
 * @param jsonStr
 * @param tRecord
 */
function updatePropertyConfig(jsonStr,tRecord) {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/property',
        headers:{'Content-Type':'application/json'},
        method:"PUT",
        jsonData:jsonStr,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.status===200) {
                tRecord.commit();
            }else{
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            alert('错误：更新配置失败，请检查网络！');
        }
    });
}

/**
 * 新增property配置
 * @param jsonStr
 * @param tRecord
 */
function createPropertyConfig(jsonStr,tRecord) {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/property',
        headers:{'Content-Type':'application/json'},
        method:"POST",
        jsonData:jsonStr,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.status===200) {
                tRecord.set("id",obj.data);
                tRecord.commit();
            }else{
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            alert('错误：新增配置失败，请检查网络！');
        }
    });
}

/**
 * 批量删除property配置
 * @param ids
 */
function batchDeletePropertyConfig(ids) {
    var jsonStr = Ext.encode(ids);

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/property/batch',
        headers:{'Content-Type':'application/json'},
        method:"DELETE",
        jsonData:jsonStr,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.status!==200) {
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            alert('错误：删除配置失败，请检查网络！');
        }
    });
}

/**
 * 刷新多属性配置gird
 * @param menuId
 */
function refreshMultiAttributeConfigStore(menuId) {
    Ext.getStore('multiAttributeConfigStore').load({
        params:{menuId:menuId},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.error);
            }
        }
    });
}

/**
 * 刷新多属性配置 StringDefinition
 * @param menuId
 */
function refreshStringDefinitionStoreStore(menuId) {
    Ext.getStore('stringDefinitionStore').load({
        params:{menuId:menuId},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.error);
            }
            let dataItems=new Array();
            for (let i=0;i<records.length;i++){
                dataItems.push(records[i].data);
            }
            refreshColumn(dataItems,menuId);
        }
    });
}

/**
 * 保存多属性配置
 * @param tRecord
 * @param tField
 * @param tValue
 */
function saveMultiAttributeConfigItems(tRecord,tField,tValue) {
    let configMenuId = Ext.getCmp('nodeId2').getValue();
    let id = tRecord.get("id");
    if (id.indexOf("MultiAttributeConfigModel")>=0){
        id=null;
    }
    //通过tField获取id
    let items= stringDefinitionStore.data.items;
    console.log(items);

    let strDefinitionId="";
    for (let i=0;i<items.length;i++){
        let obj=items[i].data;
        if (tField===obj.innerName){
            strDefinitionId=obj.id;
            break;
        }
    }
    var data = {
        configMenuId:configMenuId,
        id:id,
        strDefinitionId:strDefinitionId,
        value:tValue
    };

    var jsonStr = Ext.encode(data);

    saveMultiAttributeConfig(jsonStr,tRecord);
}

/**
 * 保存多属性配置
 * @param jsonStr
 * @param tRecord
 */
function saveMultiAttributeConfig(jsonStr,tRecord) {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/multiAttribute',
        headers:{'Content-Type':'application/json'},
        method:"POST",
        jsonData:jsonStr,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.status===200) {
                tRecord.set("id",obj.data);
                tRecord.commit();
            }else{
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            alert('错误：更新配置失败，请检查网络！');
        }
    });
}

/**
 * 批量删除多属性配置
 * @param ids
 */
function batchDeleteMultiAttributeConfig(ids) {
    var jsonStr = Ext.encode(ids);

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/multiAttribute/batch',
        headers:{'Content-Type':'application/json'},
        method:"DELETE",
        jsonData:jsonStr,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.status!==200) {
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            alert('错误：删除配置失败，请检查网络！');
        }
    });
}

/**
 * 批量保存多属性配置key
 * @param dataItems
 * @param addMultiAttributeConfigWin
 * @param configMenuId
 */
function batchSaveStringDefinition(dataItems,addMultiAttributeConfigWin,configMenuId) {
    var jsonStr = Ext.encode(dataItems);

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/stringDefinition/batch',
        headers:{'Content-Type':'application/json'},
        method:"POST",
        jsonData:jsonStr,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.status===200) {
                addMultiAttributeConfigWin.hide();
                refreshStringDefinitionStoreStore(configMenuId);
            }else{
                alert(obj['message']);
            }
        },
        failure: function(response, opts) {
            alert('错误：保存配置失败，请检查网络！');
        }
    });
}

/**
 * 刷新表格列
 * @param dataItems
 * @param configMenuId
 */
function refreshColumn(dataItems,configMenuId) {
    var fields=['id', 'configMenuId'];
    columns = [
        {text: 'id', dataIndex: 'id', menuDisabled: true, hidden: true},
        {text: 'configMenuId', dataIndex: 'configMenuId', menuDisabled: true, hidden: true}
    ];
    for (let i=0;i<dataItems.length;i++){
        let data = dataItems[i];
        columns.push({
            text: data.displayName,dataIndex: data.innerName,menuDisabled: true,editor: 'textfield'
        });
        fields.push(data.innerName);
    }
    MultiAttributeConfigModel.addFields(fields);

    Ext.getCmp('multiAttributeConfigGrid').reconfigure(Ext.getStore("multiAttributeConfigStore"),columns);

    Ext.getCmp('multiAttributeConfigGrid').updateLayout();

    refreshMultiAttributeConfigStore(configMenuId);
}