Ext.define('PLM.view.ConfigCenterPanel', {
    extend:'Ext.panel.Panel',
    alias:'widget.ConfigCenterPanel',
    autoWidth:true,
    border: false,
    layout: {
        type: 'border'
    },
    autoHeight:true,
    initComponent:function(){

        Ext.define('configTreeModel', {
            extend: 'Ext.data.TreeModel',
            fields: [
                'id', 'parentId', 'innerName', 'text'
            ],
            idProperty: 'id'
        });

        var configTreeStore = Ext.create('Ext.data.TreeStore', {
            model: 'configTreeModel',
            id: 'configTreeStore',
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/adminTool/configCenter/menu',//请求
                reader: {
                    type: 'json',
                    messageProperty: 'msg'
                },
                listeners:{
                    exception: function(proxy, response, options) {
                        // requestMessageProcessor(proxy, response);
                        var obj = Ext.decode(response.responseText);
                        if (obj.status!==200){
                            alert(obj['message']);
                        }
                    }
                }
            },
            autoLoad: true
        });
        var addConfigNodeWin;
        var configTreePanel = Ext.create('Ext.tree.Panel', {
            xtype: 'check-tree',
            store: configTreeStore,
            rootVisible: false,
            expanded: true,
            id:'configTreePanel',
            tbar: [{
                text: '添加',
                iconCls: 'icon icon-add',
                scope: this,
                handler: function () {
                    Ext.getCmp('parentId').setValue("");
                    Ext.getCmp('id').setValue("");
                    Ext.getCmp('innerName').setValue("");
                    Ext.getCmp('displayName').setValue("");
                    Ext.getCmp('multiAttributeStatus').setValue("");

                    var node = configTreePanel.getSelectionModel().getSelection()[0];
                    console.log(node);
                    if (node.data.parentId==='root'){
                        Ext.getCmp('parentId').setValue(node.data.id);
                        Ext.getCmp('multiAttributeStatus').setValue(node.data.multiAttributeStatus);
                        addConfigNodeWin = Ext.create('Ext.Window', {
                            title: '添加节点',
                            width: 800,
                            //height: 300,
                            autoHeight: true,
                            closeAction: 'hide',
                            //closable:false,
                            constrain: true,
                            modal: true,
                            items: [{
                                xtype: addConfigNodePanel
                            }]
                        });
                        addConfigNodeWin.show();
                    }
                }
            },  {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    var node = configTreePanel.getSelectionModel().getSelection()[0];
                    if (node==undefined||node==null){
                        alert("请选择需要删除节点！");
                        return;
                    }
                    var id = node.data.id;
                    var msgInfo ="是否要删除此节点";
                    if (node.childNodes.length>0){
                        msgInfo="是否要删除此节点及子节点";
                    }

                    Ext.Msg.confirm('提示', msgInfo,
                        function (btn) {
                            if (btn == 'yes') {
                                deleteConfigNode(id);
                            } else {
                                return;
                            }
                        }, this);

                }
            }],
            listeners: {
                'cellclick': function (orgThis, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    if (record.get("parentId")==='root'){
                        Ext.getCmp('mainForm').hide();
                        return;
                    }
                    Ext.getCmp('mainForm').show();
                    var id = record.get("id");
                    var multiAttributeStatus = record.get("multiAttributeStatus");
                    console.log(multiAttributeStatus);
                    if (multiAttributeStatus===0){
                        Ext.getCmp('nodeName').setValue(record.get("text"));
                        Ext.getCmp('nodeId').setValue(record.get("id"));
                        Ext.getCmp('nodeParentId').setValue(record.get("parentId"));
                        Ext.getCmp('nodeInnerName').setValue(record.get("innerName"));

                        Ext.getCmp('configNodePanel').show();
                        Ext.getCmp('multiAttributeConfigPanel').hide();
                        refreshConfigPropertyStore(id)
                    }else {
                        Ext.getCmp('nodeName2').setValue(record.get("text"));
                        Ext.getCmp('nodeId2').setValue(record.get("id"));
                        Ext.getCmp('nodeParentId2').setValue(record.get("parentId"));
                        Ext.getCmp('nodeInnerName2').setValue(record.get("innerName"));

                        Ext.getCmp('configNodePanel').hide();
                        Ext.getCmp('multiAttributeConfigPanel').show();

                        refreshStringDefinitionStoreStore(id);
                    }


                }
            }
        });

        var addConfigNodePanel = Ext.create('Ext.panel.Panel', {
            xtype: 'form',
            border: false,
            items: [{
                layout: 'hbox',
                border: false,
                margin: '30 5 10 60',
                items:[{
                        xtype: 'textfield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color="red">*</font>显示名称',
                        labelWidth: 70,
                        width: 300,
                        id: 'displayName',
                        name: 'displayName'
                    },{
                        xtype: 'textfield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color="red">*</font>内部名称',
                        labelWidth: 70,
                        width: 300,
                        id: 'innerName',
                        name: 'innerName'
                    }]
            }, {
                xtype: 'textfield',
                fieldLabel: 'id',
                hidden: true,
                labelWidth: 30,
                width: 300,
                id: 'id',
                name: 'id'
            }, {
                xtype: 'textfield',
                fieldLabel: 'parentId',
                labelWidth: 30,
                hidden: true,
                width: 300,
                id: 'parentId',
                name: 'parentId'
            },{
                xtype: 'textfield',
                fieldLabel: 'multiAttributeStatus',
                labelWidth: 30,
                hidden: true,
                width: 300,
                id: 'multiAttributeStatus',
                name: 'multiAttributeStatus'

            },{
                xtype: 'button',
                text: '保存',
                margin: '10 5 10 60',
                scope: this,
                handler: function () {
                    Ext.Msg.confirm('提示', '是否要增加节点？',
                        function (btn) {
                            if (btn == 'yes') {
                                var parentId = Ext.getCmp('parentId').getValue();
                                var multiAttributeStatus = Ext.getCmp('multiAttributeStatus').getValue();
                                if (Ext.getCmp('innerName').getValue()==""){
                                    alert("内部名称不能为空！")
                                }else if (Ext.getCmp('displayName').getValue()==""){
                                    alert("节点名称不能为空！")
                                }else {
                                    addConfigNode(parentId,multiAttributeStatus);
                                    addConfigNodeWin.hide();
                                }
                            } else {
                                return;
                            }
                        }, this);

                }
            }]
        });

        this.items = [{
            xtype: 'panel',
            region: 'west',
            //margins     : '0 0 0 5', // TRBL
            width:'25%',
            items:[configTreePanel]
        },{
            xtype: 'panel',
            id:'mainForm',
            region: 'center',
            margin: '0 0 0 10',
            width:'75%',
            hidden:true,
            items: [configNodePanel,multiAttributeConfigPanel]
        }];

        this.callParent();
    }
});