Ext.define('configPropertyModel', {
    extend: 'Ext.data.Model',
    fields: [
        'id', 'configMenuId', 'propertyKey', 'propertyValue', 'splitChart', 'remark'
    ],
    idProperty: 'id'
});

var configPropertyStore = Ext.create('Ext.data.Store', {
    model: 'configPropertyModel',
    id: 'configPropertyStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1//adminTool/configCenter/property',
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            totalProperty: 'totalCount',
            idProperty: 'id',
            messageProperty: 'msg'
        }
    }),
    autoLoad: false
});

this.cellEditing = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

var configPropertyGrid = Ext.create('Ext.grid.Panel', {
    plugins: [this.cellEditing],
    id: 'configPropertyGrid',
    // title: '配置详情',
    // hidden:true,
    store: Ext.data.StoreManager.lookup('configPropertyStore'),
    autoScroll: true,
    height: 600,
    region: 'center',
    forceFit: true,
    //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
    viewConfig: {enableTextSelection: true},
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        id: 'configPropertyModel',
        showHeaderCheckbox: true
    }),
    columns: [
        {text: 'id', dataIndex: 'id', menuDisabled: true, hidden: true},
        {text: 'configMenuId', dataIndex: 'configMenuId', menuDisabled: true, hidden: true},
        {text: '配置名称', dataIndex: 'propertyKey', editor: 'textfield', menuDisabled: true},
        {
            text: '配置值', dataIndex: 'propertyValue', editor: 'textfield', menuDisabled: true,
            renderer: function (value, metaData) {
                metaData.tdAttr = 'data-qtip="' + value + '"';
                return value;
            }
        },
        {text: '分隔符', dataIndex: 'splitChart', editor: 'textfield', menuDisabled: true},
        {text: '备注', dataIndex: 'remark', editor: 'textfield', menuDisabled: true}
    ],
    tbar: [{
        text: '添加',
        iconCls: 'icon icon-add',
        scope: this,
        handler: function () {
            var rec = new Object();
            configPropertyStore.insert(0, rec);
        }
    }, {
        text: '删除',
        iconCls: 'icon icon-delete',
        scope: this,
        handler: function () {
            var delFn = function () {
                var deleteItems = new Array();//删除项
                var sm = configPropertyGrid.getSelectionModel();

                var tmpStore = Ext.getStore('configPropertyStore');
                tmpStore.remove(sm.getSelection());

                var removedRecords = tmpStore.getRemovedRecords();

                Ext.each(removedRecords, function (record) {
                    deleteItems.push(record.data.id);
                });

                batchDeletePropertyConfig(deleteItems)
            };//~end of delFn

            Ext.Msg.confirm('提示', '确定要删除选中内容？',
                function (btn) {
                    if (btn == 'yes') {
                        delFn();
                    } else {
                        return;
                    }
                }, this);
        }
    }],
    listeners: {}

});
configPropertyGrid.on('edit', function (editor, e) {
    var tRecord = e.record; //得到当前行所有数据
    saveConfigPropertyItems(tRecord);
});

var configNodePanel = {
    xtype: 'panel',
    autoWidth: true,
    autoScroll: true,
    id: "configNodePanel",
    hidden: true,
    title: '节点详情',
    items: [{
        layout: 'hbox',
        border: false,
        margin: '10 5 10 20',
        items: [{
            xtype: 'textfield',
            margin: '0 20 0 0',
            disabled: true,
            fieldLabel: '节点名称',
            labelWidth: 70,
            width: 400,
            id: 'nodeName'
        }, {
            xtype: 'textfield',
            margin: '0 20 0 0',
            disabled: true,
            fieldLabel: '节点内部名称',
            labelWidth: 90,
            width: 400,
            id: 'nodeInnerName'
        }, {
            xtype: 'textfield',
            fieldLabel: 'nodeId',
            hidden: true,
            labelWidth: 30,
            width: 300,
            id: 'nodeId',
            name: 'nodeId'
        }, {
            xtype: 'textfield',
            fieldLabel: 'nodeParentId',
            labelWidth: 30,
            hidden: true,
            width: 300,
            id: 'nodeParentId',
            name: 'nodeParentId'
        }]
    }, {
        layout: 'hbox',
        border: false,
        margin: '10 5 10 20',
        items: [{
            xtype: 'button',
            id: 'edit',
            margin: '10 0 0 0',
            text: '编辑',
            handler: function () {
                Ext.getCmp('nodeName').setDisabled(false);
                Ext.getCmp('nodeInnerName').setDisabled(false);
                Ext.getCmp('saveInfo').enable();
            }
        }, {
            xtype: 'button',
            id: 'saveInfo',
            margin: '10 0 0 10',
            disabled: true,
            text: '保存',
            handler: function () {
                //获取节点id
                var nodeName = Ext.getCmp('nodeName').getValue();
                var nodeInnerName = Ext.getCmp('nodeInnerName').getValue();
                var nodeParentId = Ext.getCmp('nodeParentId').getValue();
                var nodeId = Ext.getCmp('nodeId').getValue();

                var data = {
                    id: nodeId,
                    text: nodeName,
                    innerName: nodeInnerName,
                    parentId: nodeParentId
                };
                updateConfigNode(data, false);
            }
        }]
    }, configPropertyGrid]
};