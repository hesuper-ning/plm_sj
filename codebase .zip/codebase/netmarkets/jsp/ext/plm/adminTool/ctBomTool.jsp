<%@ page language="java" import="java.util.*"  contentType="text/html; charset=utf-8" pageEncoding="UTF-8"%>

<%
    String oid = request.getParameter("oid");
%>

<iframe id="bomToolPlugin" src="netmarkets/jsp/ext/plm/adminTool/ctBomToolPlugin.jsp?oid=<%=oid%>" style="width:98%;height:530px" ></iframe>