Ext.define('PLM.view.ConfigToolPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ConfigToolPanel',
    title: '配置中心',
    border: false,
    layout: {
        type: 'border',
        padding: Ext.themeName === 'neptune' ? 8 : 5 // match padding to theme splitter size
    },
    defaults: {
        collapsible: true,
        split      : true
    },
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'configToolPanel',
    initComponent: function () {
        //****************树形配置表单**********************//
        Ext.define('configTreeModel', {
            extend: 'Ext.data.TreeModel',
            fields: [
                'id', 'fatherId', 'innerKey', 'text', 'remark'
            ],
            idProperty: 'id'
        });

        var configTreeStore = Ext.create('Ext.data.TreeStore', {
            //pageSize: 50,
            model: 'configTreeModel',
            id: 'configTreeStore',
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/adminTool/configCenter/getConfigNode',//请求
                reader: {
                    type: 'json',
                    messageProperty: 'msg'
                },
                listeners:{
                    exception: function(proxy, response, options) {
                        // requestMessageProcessor(proxy, response);
                        var obj = Ext.decode(response.responseText);
                        if (!obj['success']){
                            alert(obj['msg']);
                        }
                    }
                }
            },

            autoLoad: true,
            root: {
                text: '配置文件管理',
                expanded: true
            },
            sorters: [{
                property: 'leaf',
                direction: 'ASC'
            }, {
                property: 'text',
                direction: 'ASC'
            }]
        });
        var addConfigNodeWin;
        var configTreePanel = Ext.create('Ext.tree.Panel', {
            xtype: 'check-tree',
            store: configTreeStore,
            rootVisible: false,
            useArrows: true,
            id:'configTreePanel',
            tbar: [{
                xtype: 'button',
                text: '展开',
                handler: function () {
                    configTreePanel.expandAll();
                }
            }, {
                xtype: 'button',
                text: '折叠',
                handler: function () {
                    configTreePanel.collapseAll();
                }
            },{
                xtype:'filefield',
                buttonOnly: true,
                id:'upload1',
                hideLabel: true,
                buttonText: '<span style="width:120px;"><img src="/Windchill/netmarkets/images/database_import_16x16.gif" style="vertical-align:text-bottom;"/>Excel导入</span>',
                allowBlank: false,
                scope: this,
                listeners:{
                    'change':function(fb,v){
                        var file = document.querySelector('[id=upload1-button-fileInputEl]');
                        console.log(file);
                        var formData = new FormData();
                        formData.append('file', file.files[0]);
                        fb.reset();//清空表单的值
                        var loadMarsk = new Ext.LoadMask(document.body, {
                            msg:'正在导入数据，请稍候......',
                            removeMask:true // 完成后移除
                        });
                        loadMarsk.show();

                        $.ajax({
                            url: '/Windchill/ptc1/adminTool/configCenter/importConfigInfo',
                            type: 'POST',
                            cache: false,
                            data: formData,
                            processData: false,
                            contentType: false
                        }).done(function(res) {
                            loadMarsk.hide();

                            var obj = Ext.decode(res);

                            var success = obj['success'];
                            var msg = obj['msg'];
                            if(!success){
                                alert(msg);
                            }else {
                                refreshConfigTree();
                            }
                        }).fail(function(res) {
                            loadMarsk.hide();
                            alert('上传失败！') ;
                        });
                        loadMarsk.hide();
                    }
                }
            },{
                xtype: 'button',
                text: '下载模板',
                handler: function () {
                    window.location.href = '/Windchill/ptc1/adminTool/configCenter/downloadTemplate';
                }
            }, {
                text: '添加',
                iconCls: 'icon icon-add',
                scope: this,
                handler: function () {
                    //清空值
                    Ext.getCmp('nodeName').setValue("");
                    Ext.getCmp('remark').setValue("");
                    Ext.getCmp('fatherId').setValue("");
                    Ext.getCmp('innerKey').setValue("");
                    Ext.getCmp('existRootNode').setValue("");

                    var node = configTreePanel.getSelectionModel().getSelection()[0];
                    //是否根节点
                    var existRootNode = false;
                    if (node!=undefined&&node!=null){
                        var fatherId = node.data.id;
                        Ext.getCmp('fatherId').setValue(fatherId);
                    }else{
                        existRootNode = true;
                    }
                    Ext.getCmp('existRootNode').setValue(existRootNode);

                    addConfigNodeWin = Ext.create('Ext.Window', {
                        title: '添加节点',
                        width: 800,
                        //height: 300,
                        autoHeight: true,
                        closeAction: 'hide',
                        //closable:false,
                        constrain: true,
                        modal: true,
                        items: [{
                            xtype: addConfigNodePanel
                        }]
                    });
                    addConfigNodeWin.show();
                }
            }, '&nbsp;', {
                text: '删除',
                iconCls: 'icon icon-delete',
                scope: this,
                handler: function () {
                    var node = configTreePanel.getSelectionModel().getSelection()[0];
                    if (node==undefined||node==null){
                        alert("请选择需要删除节点！");
                        return;
                    }
                    var id = node.data.id;
                    var msgInfo ="是否要删除此节点";
                    if (node.childNodes.length>0){
                        msgInfo="是否要删除此节点及子节点";
                    }

                    Ext.Msg.confirm('提示', msgInfo,
                        function (btn) {
                            if (btn == 'yes') {
                               deleteConfigNode(id);
                            } else {
                                return;
                            }
                        }, this);


                }
            }],
            listeners: {
                'cellclick': function (orgThis, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var id = record.get("id");
                    var fatherId = record.get("fatherId");
                    var leaf = record.get("leaf");
                    rootNode = record;
                    //叶子节点显示信息
                    showConfigInfo(id, leaf);
                    Ext.getCmp('masterId').setValue(id);
                    //清空信息
                    // Ext.getCmp('key').setValue("");
                    Ext.getCmp('value').setValue("");
                    Ext.getCmp('templateRemark').setValue("");
                    Ext.getCmp('configId').setValue("");
                    Ext.getCmp('saveInfo').disable();

                    //加载配置名称下拉框,只有叶子节点才可以编辑数据
                    if (leaf){
                        Ext.getCmp('value').setReadOnly(false);
                        Ext.getCmp('templateRemark').setReadOnly(false);
                        Ext.getCmp('configNameCombo').editable = true;
                        Ext.getCmp('configTemplateGrid').setVisible(true);
                        Ext.getCmp('configTemplatePanel').setVisible(true);
                        refreshConfigName(id);
                    }else {
                        Ext.getCmp('value').setReadOnly(true);
                        Ext.getCmp('templateRemark').setReadOnly(true);
                        Ext.getCmp('configNameCombo').editable = false;
                        Ext.getCmp('configTemplateGrid').setVisible(false);
                        Ext.getCmp('configTemplatePanel').setVisible(false);
                    }
                    getParentNods(rootNode);
                }
            }
        });

        //****************树形配置表单--添加节点**********************//
        var addConfigNodePanel = Ext.create('Ext.panel.Panel', {
            xtype: 'form',
            border: false,
            items: [{
                layout: 'hbox',
                border: false,
                margin: '30 5 10 60',
                items: [{
                    xtype: 'textfield',
                    margin: '0 20 0 0',
                    fieldLabel: '<font color="red">*</font>节点名称',
                    labelWidth: 70,
                    width: 300,
                    id: 'nodeName',
                    name: 'nodeName'
                }, {
                    xtype: 'textfield',
                    margin: '0 20 0 0',
                    fieldLabel: '<font color="red">*</font>内部名称',
                    labelWidth: 70,
                    width: 300,
                    id: 'innerKey',
                    name: 'innerKey'
                }, {
                    xtype: 'textfield',
                    fieldLabel: 'existRootNode',
                    hidden: true,
                    labelWidth: 30,
                    width: 300,
                    id: 'existRootNode',
                    name: 'existRootNode'
                }, {
                    xtype: 'textfield',
                    fieldLabel: 'fatherId',
                    labelWidth: 30,
                    hidden: true,
                    width: 300,
                    id: 'fatherId',
                    name: 'fatherId'
                }]
            }, {
                layout: 'hbox',
                border: false,
                margin: '30 5 10 60',
                items: [{
                    xtype: 'textfield',
                    margin: '0 20 0 0',
                    fieldLabel: '<font color="red">*</font>节点说明',
                    labelWidth: 70,
                    width: 300,
                    id: 'remark',
                    name: 'remark'
                }, {
                    xtype: 'button',
                    text: '保存',
                    margin: '0 20 0 0',
                    scope: this,
                    handler: function () {
                        Ext.Msg.confirm('提示', '是否要增加节点？',
                            function (btn) {
                                if (btn == 'yes') {
                                    var fatherId = Ext.getCmp('fatherId').getValue();
                                    var existRootNode = Ext.getCmp('existRootNode').getValue();
                                    if (Ext.getCmp('innerKey').getValue()==""){
                                        alert("内部名称不能为空！")
                                    }else if (Ext.getCmp('nodeName').getValue()==""){
                                        alert("节点名称不能为空！")
                                    }else if (Ext.getCmp('remark').getValue()==""){
                                        alert("节点说明不能为空！")
                                    }else {
                                        addConfigNode(fatherId, existRootNode);
                                        addConfigNodeWin.hide();

                                    }
                                } else {
                                    return;
                                }
                            }, this);



                    }
                }]
            }]
        });

        //****************节点配置表头详细信息---配置名称下拉值**********************//
        var key = "";
        Ext.define('configNameModel', {
            extend: 'Ext.data.Model',
            fields: [
                'storeId', 'storeName'
            ],
            idProperty: 'id'
        });

      var  configNameStore = new Ext.data.Store({
            storeId:'configNameStore',
            model:'configNameModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/adminTool/configCenter/getConfigName',
                method:'GET',
                reader:{
                    type:'json',
                    idProperty: 'id',
                    root:'items',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });

        var configNameCombo = new Ext.form.field.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            width:250,
            queryMode: 'local',
            displayField: 'storeName',
            valueField: 'storeId',
            forceSelection:false,
            allowBlank : false,
            anyMatch: false,
            store:configNameStore,
            id:'configNameCombo',
            listeners:{
                select:function (combo, record, index) {
                    //获取配置信息id
                    var configTemplateId = record[0].data.storeId;
                    key = record[0].data.storeName;
                    //通过id获取详细信息
                    var items = configTemplateStore.data.items;
                    for (var i=0;i<items.length;i++){
                        var item = items[i];
                        if (configTemplateId == item.data.id){
                            Ext.getCmp('value').setValue(item.data.value);
                            Ext.getCmp('templateRemark').setValue(item.data.remark);
                            Ext.getCmp('configId').setValue(configTemplateId);
                        }
                    }
                },
                blur:function (record) {
                    //判断是不是下拉的值
                    if (record.displayTplData==null){
                        var isClean = true;
                        var items = configNameStore.data.items;
                        for (var i=0;i<items.length;i++){
                            var name = items[i].data.storeName;
                            var configTemplateId = items[i].data.storeId;
                            if (name == record.lastValue){
                                //通过id获取详细信息
                                var items = configTemplateStore.data.items;
                                for (var i=0;i<items.length;i++){
                                    var item = items[i];
                                    if (configTemplateId == item.data.id){
                                        Ext.getCmp('value').setValue(item.data.value);
                                        Ext.getCmp('templateRemark').setValue(item.data.remark);
                                        Ext.getCmp('configId').setValue(configTemplateId);
                                    }
                                }
                                isClean=false;
                            }
                        }
                        if (isClean){
                            //如果不是就清空值
                            Ext.getCmp('value').setValue("");
                            Ext.getCmp('templateRemark').setValue("");
                            Ext.getCmp('configId').setValue("");
                        }

                        key = record.lastValue;
                    }
                }
            }
        });

        //****************节点配置表头详细信息**********************//
        var configNodePanel = {
            xtype: 'fieldset',
            autoWidth:true,
            autoHeight:true,
            frame: false,
            title: '节点详情',
            collapsible: true,
            items: [{
                layout: 'hbox',
                border: false,
                margin: '10 5 10 20',
                items: [{
                    xtype: 'textfield',
                    margin: '0 20 0 0',
                    readOnly: true,
                    fieldLabel: '节点名称',
                    labelWidth: 70,
                    width: 400,
                    id: 'nodeInfoName'
                }, {
                    xtype: 'textfield',
                    margin: '0 20 0 0',
                    readOnly: true,
                    fieldLabel: '节点内部名称',
                    labelWidth: 90,
                    width: 400,
                    id: 'innerKeyInfo'
                }]
            },{
                layout: 'hbox',
                border: false,
                margin: '10 5 10 20',
                items: [{
                    xtype: 'textarea',
                    margin: '0 20 0 0',
                    readOnly:true,
                    fieldLabel: '节点说明',
                    labelWidth: 70,
                    width: 400,
                    id: 'nodeRemark'
                },{
                    xtype:'button',
                    id:'edit',
                    margin: '60 0 0 0',
                    text: '编辑',
                    handler:function () {
                        Ext.getCmp('nodeInfoName').setReadOnly(false);
                        Ext.getCmp('nodeRemark').setReadOnly(false);
                        Ext.getCmp('saveInfo').enable();
                    }
                },{
                    xtype:'button',
                    id:'saveInfo',
                    margin:'60 0 0 10',
                    text: '保存',
                    handler:function () {
                        //获取节点id
                        var id = Ext.getCmp('masterId').getValue();
                        if(id==undefined||id==""){
                            alert("请选择节点！");
                            return;
                        }
                        var nodeRemark = Ext.getCmp('nodeRemark').getValue();
                        var nodeName = Ext.getCmp('nodeInfoName').getValue();

                        var loadMarsk = new Ext.LoadMask(document.body, {
                            msg:'正在更新，请稍候......',
                            removeMask:true // 完成后移除
                        });
                        loadMarsk.show();
                        var data = {
                            id:id,
                            text:nodeName,
                            remark:nodeRemark
                        }
                        var jsonStr = Ext.encode(data);
                        Ext.Ajax.request({
                            scope:this,
                            url: '/Windchill/ptc1/adminTool/configCenter/updateConfigNode',
                            method:'Get',
                            params: {data:jsonStr},
                            success: function(response, opts) {
                                var obj = Ext.decode(response.responseText);
                                if(!obj['success']) {
                                    alert(obj['msg']);
                                }else {
                                    Ext.getCmp('saveInfo').disable();
                                    Ext.getCmp('nodeInfoName').setReadOnly(true);
                                    Ext.getCmp('nodeRemark').setReadOnly(true);
                                }
                            },
                            failure: function(response, opts) {
                                alert('错误：更新节点信息失败，请检查网络！');
                            }
                        });
                        loadMarsk.hide();
                    }
                }]
            }]
        }

        //****************节点配置表单信息**********************//
        Ext.define('configTemplateModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'masterId', 'key', 'value', 'remark', 'deleted', 'createDate',
                'createUser', 'updateDate', 'updateUser'
            ],
            idProperty: 'id'
        });

        var configTemplateStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'configTemplateModel',
            id: 'configTemplateStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/adminTool/configCenter/getConfigTemplate',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });

        this.cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var configTemplateGrid = Ext.create('Ext.grid.Panel', {
            plugins: [this.cellEditing],
            id:'configTemplateGrid',
            title: '配置详情',
            hidden:true,
            store: Ext.data.StoreManager.lookup('configTemplateStore'),
            id: 'configTemplateGrid',
            autoWidth: true,
            autoScroll: true,
            region: 'center',
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {enableTextSelection: true},
            columns: [
                {text: 'id', dataIndex: 'id', width: 100, menuDisabled: true, hidden: true},
                {text: 'masterId', dataIndex: 'masterId', width: 100, menuDisabled: true, hidden: true},
                {text: '配置名称', dataIndex: 'key', width: 150, menuDisabled: true},
                {text: '配置值', dataIndex: 'value', width: 150, menuDisabled: true},
                {text: '备注', dataIndex: 'remark', width: 150, menuDisabled: true},
                {text: '创建者', dataIndex: 'createUser', width: 100, menuDisabled: true},
                {text: '创建日期', dataIndex: 'createDate', width: 120, menuDisabled: true},
                {text: '修改者', dataIndex: 'updateUser', width: 100, menuDisabled: true},
                {text: '修改日期', dataIndex: 'updateDate', width: 120, menuDisabled: true},
                {
                    text: '删除', dataIndex: 'create', width: 120, menuDisabled: true,
                    renderer: function (value, metaData, record, rowIndex, colIndex, store) {
                        var id =  '"'+record.get('id')+'"';
                        var masterId =  '"'+record.get('masterId')+'"'
                        var but = "<input type='button' value='删除' style='width:60px;height:20px;' onclick='deleteConfigInfo("+id+","+masterId+")'>";
                        return but;
                    }
                }
            ],
            listeners:{
                'cellclick':function (obj,td,cellIndex,record,tr,rowIndex,e,eOpts) {
                    var key = record.data.key;
                    var value = record.data.value;
                    var remark = record.data.remark;
                    var id = record.data.id;
                    var masterId = record.data.masterId;
                    Ext.getCmp('configNameCombo').setValue(key);
                    Ext.getCmp('configNameCombo').setRawValue(key);
                    // Ext.getCmp('key').setValue(key);
                    Ext.getCmp('value').setValue(value);
                    Ext.getCmp('templateRemark').setValue(remark);
                    Ext.getCmp('configId').setValue(id);
                    Ext.getCmp('masterId').setValue(masterId);
                }
            }
        });

        //****************添加节点配置表单信息**********************//
        var configTemplatePanel = {
            xtype: 'fieldset',
            collapsible: true,
            autoWidth:true,
            autoHeight:true,
            title: '增加配置',
            id:'configTemplatePanel',
            hidden:true,
            align: 'middle',
            items: [{
                layout: 'hbox',
                border: false,
                margin: '10 5 10 20',
                items: [{
                    xtype:'label',
                    text:"*",
                    style:'color:red'
                },{
                    xtype:'label',
                    text:"配置名称:"
                },{
                    xtype: configNameCombo,
                    width: 500,
                    readOnly:true,
                    // fieldLabel: '<font color="red">*</font>配置名称',
                    id: 'key',
                    name: 'key',
                    labelWidth: 70
                }, {
                    xtype: 'textfield',
                    margin: '0 0 0 40',
                    width: 300,
                    readOnly:true,
                    fieldLabel: '<font color="red">*</font>配置值',
                    name: 'value',
                    id: 'value',
                    labelWidth: 50
                }]

            }, {
                layout: 'hbox',
                border: false,
                margin: '10 5 10 20',
                items: [{
                    xtype: 'textfield',
                    width: 300,
                    margin: '10 0 0 10',
                    readOnly:true,
                    fieldLabel: '<font color="red">*</font>备注',
                    name: 'templateRemark',
                    id: 'templateRemark',
                    labelWidth: 40
                },{
                    xtype: 'textfield',
                    fieldLabel: 'masterId',
                    labelWidth: 30,
                    hidden: true,
                    width: 300,
                    id: 'masterId',
                    name: 'masterId'
                },{
                    xtype: 'textfield',
                    fieldLabel: 'configId',
                    labelWidth: 30,
                    hidden: true,
                    width: 300,
                    id: 'configId',
                    name: 'configId'
                }, {
                    xtype: 'button',
                    text: '保存',
                    margin: '10 0 0 40',
                    handler: function () {
                        var msg = "是否要增加配置?"
                        //判断是不是新增字段
                        var id = Ext.getCmp('configId').getValue(); //配置信息的ID
                        if (id!=undefined&&id!=""){
                            msg = "是否要修改配置?"
                        }
                        Ext.Msg.confirm('提示', msg,
                            function (btn) {
                                if (btn == 'yes') {
                                    var masterId = Ext.getCmp('masterId').getValue();
                                    if(masterId==""||masterId=="<empty string>"){
                                        alert("请选择对应节点！")
                                    }else if (key==""){
                                        alert("配置名称不能为空！")
                                    }else if (Ext.getCmp('value').getValue()==""){
                                        alert("配置值不能为空！")
                                    }else if (Ext.getCmp('templateRemark').getValue()==""){
                                        alert("备注不能为空！")
                                    }else {
                                        updateConfigTemplateInfo(masterId,key);
                                    }
                                } else {
                                    return;
                                }
                            }, this);
                    }
                }]
            }]
        };

/////////////////////////Main Panel items//////////////////////////////////
        this.items = [{
            xtype: 'panel',
            region: 'west',
            //margins     : '0 0 0 5', // TRBL
            width:'35%',
            items:[configTreePanel]
        },{
            xtype: 'panel',
            id:'mainForm',
            region: 'center',
            margin: '0 0 0 10',
            hideLabel: true,
            // frame : true,
            layout: "anchor",// 整个大的表单是anchor布局
            width:'65%',
            items: [configNodePanel, configTemplatePanel, configTemplateGrid]
        }];

        this.callParent();


    }//~End of initComponent
});

//*************function******************//

//显示对应节点详细配置信息
function showConfigInfo(id, leaf) {
    //查询节点详细信息
    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/adminTool/configCenter/getConfigNodeInfo',
        method: 'GET',
        params: {id: id},
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            var result = obj.result;
            var nodeRemark = result.remark;
            var nodeName = result.text;
            var innerKey = result.innerKey;
            // var remark = result.text;
            if (obj['success']) {
                Ext.getCmp('nodeRemark').setValue(nodeRemark);
                Ext.getCmp('nodeInfoName').setValue(nodeName);
                Ext.getCmp('innerKeyInfo').setValue(innerKey);
            } else {
                alert(obj['msg']);
            }
        },
        failure: function (response, opts) {
            alert('错误：查询节点详细信息失败，请检查网络！');
        }
    });
    refreshConfigTemplate(id);
}

//刷新节点配置信息
function refreshConfigTemplate(id) {
    //查询节点对应的所有配置信息
    Ext.getStore('configTemplateStore').load({
        params: {masterId: id},
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.error);
            }
        }
    });
}

//刷新树形表单
function refreshConfigTree() {
    Ext.getStore('configTreeStore').load({
        callback: function (records, operation, success) {
            if (!success) {
                alert(operation.error);
            }
            expandNode(records)
        }
    });
}

//获取当前节点以及父节点的ID
function getParentNods(node) {
    parentNodes = [];
    while (node!=undefined&&node!=null){
        parentNodes.push(node.id);
        node = node.parentNode;
    }
    console.log(parentNodes);
}

//展开节点
function expandNode(nodes) {
    for (var i=0;i<nodes.length;i++){
        var node = nodes[i];
       var childNodes = node.childNodes;
       if (parentNodes.indexOf(node.id)!=-1){
           node.expand();
       }
       if (childNodes!=undefined&&childNodes!=null){
           expandNode(childNodes);
       }
    }
}

//添加配置节点
function addConfigNode(fatherId, existRootNode) {
    var loadMarsk = new Ext.LoadMask(document.body, {
        msg:'正在创建，请稍候......',
        removeMask:true // 完成后移除
    });
    loadMarsk.show();

    var data = {
        fatherId:Ext.getCmp('fatherId').getValue(),
        existRootNode:Ext.getCmp('existRootNode').getValue(),
        text:Ext.getCmp('nodeName').getValue(),
        remark:Ext.getCmp('remark').getValue(),
        leaf:true,//默认创建的为叶子节点
        innerKey:Ext.getCmp('innerKey').getValue()
    }

    var jsonStr = Ext.encode(data);

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/addConfigNode',
        method:'Get',
        params: {data:jsonStr},
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']) {
                refreshConfigTree();
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：添加节点失败，请检查网络！');
        }
    });

    loadMarsk.hide();
}

//删除节点
function deleteConfigNode(id) {
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/deleteConfigNode',
        method:'Get',
        params: {id:id},
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']) {
                refreshConfigTree();
                refreshConfigTemplate(id);
                refreshConfigName(id);
                //清空panel的值
                Ext.getCmp('nodeName').setValue("");
                Ext.getCmp('nodeRemark').setValue("");
                Ext.getCmp('value').setValue("");
                Ext.getCmp('templateRemark').setValue("");
                Ext.getCmp('configId').setValue("");
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：添加节点失败，请检查网络！');
        }
    });
}

//添加节点配置信息
function updateConfigTemplateInfo(masterId,key) {
    var loadMarsk = new Ext.LoadMask(document.body, {
        msg:'正在更新，请稍候......',
        removeMask:true // 完成后移除
    });
    loadMarsk.show();

    //判断是不是新增字段
    var id = Ext.getCmp('configId').getValue(); //配置信息的ID
    var isAdd = true;
    if (id!=undefined&&id!=""){
        isAdd=false;
    }
    var data = {
        masterId:masterId,
        key:key,
        value:Ext.getCmp('value').getValue(),
        remark:Ext.getCmp('templateRemark').getValue(),
        id:id,
        isAdd:isAdd
    }

    var jsonStr = Ext.encode(data);

    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/adminTool/configCenter/updateConfigTemplateInfo',
        method:'Get',
        params: {data:jsonStr},
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj['success']) {
                refreshConfigTemplate(masterId);
                refreshConfigName(masterId);
                //清空panel的值
                Ext.getCmp('configNameCombo').setValue("");
                Ext.getCmp('configNameCombo').setRawValue("");
                Ext.getCmp('value').setValue("");
                Ext.getCmp('templateRemark').setValue("");
                Ext.getCmp('configId').setValue("");
            }else{
                alert(obj['msg']);
            }
        },
        failure: function(response, opts) {
            alert('错误：添加节点失败，请检查网络！');
        }
    });

    loadMarsk.hide();
}


//刷新配置名称
function refreshConfigName(masterId) {
    Ext.getStore('configNameStore').load({
        params:{masterId:masterId},
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询配置名称失败，请联系管理员！');
            }
        }
    });
}

//删除配置信息
function deleteConfigInfo(id,masterId) {
    Ext.Msg.confirm('提示', '是否要删除',
        function (btn) {
            if (btn == 'yes') {
                var loadMarsk = new Ext.LoadMask(document.body, {
                    msg:'正在删除，请稍候......',
                    removeMask:true // 完成后移除
                });
                loadMarsk.show();

                Ext.Ajax.request({
                    scope:this,
                    url: '/Windchill/ptc1/adminTool/configCenter/deleteConfigInfo',
                    method:'Get',
                    params: {id:id,masterId:masterId},
                    success: function(response, opts) {
                        var obj = Ext.decode(response.responseText);
                        if(obj['success']) {
                            refreshConfigTemplate(masterId);
                            refreshConfigName(masterId);
                        }else{
                            alert(obj['msg']);
                        }
                    },
                    failure: function(response, opts) {
                        alert('错误：添加节点失败，请检查网络！');
                    }
                });

                loadMarsk.hide();
            } else {
                return;
            }
        }, this);


}