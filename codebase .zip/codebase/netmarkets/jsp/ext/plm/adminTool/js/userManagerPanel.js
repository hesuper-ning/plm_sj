Ext.require([
    'Ext.grid.*',
    'Ext.data.*',
    'Ext.ux.grid.FiltersFeature',
    'Ext.toolbar.Paging',
    'Ext.ux.ajax.JsonSimlet',
    'Ext.ux.ajax.SimManager'
]);
Ext.define('Pnt.view.UserManagerPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.UserManagerPanel',
	border:false,
	//title:'<font style="font-size:18px">PLM用户任务管理</font>',
    autoWidth:true,
 	autoHeight:true,
     collapsible: false,
     id: 'userManagerPanel',
     fieldDefaults: {
         msgTarget: 'side',
         labelWidth: 75
     },
	initComponent:function(){
		
		var cellEditing = new Ext.grid.plugin.CellEditing({
			clicksToEdit: 1
		});
		
		Ext.define('userWorkItemModel', {
		    extend: 'Ext.data.Model',
		    fields: [
		        'id', 'workName', 'workSubject', 
		        'subjectState', 'workDate', 'subjectDate',
		        'contianer', 'role', 'processCreate'
		    ],
		    idProperty: 'id'
		});

		// create the Data Store
		var userWorkItemStore = Ext.create('Ext.data.Store', {
		    //pageSize: 100,
		    model: 'userWorkItemModel',
		    id:'userWorkItemStore',
		    pruneModifiedRecords: true,
		    proxy: new Ext.data.HttpProxy({
		        url: '/Windchill/ptc1/adminTool/userManager/getUserWorkItems?',
		        method:'GET',
		        timeout: 9000000,
		        reader:{
		        	type:'json',
		        	root: 'items',
		            totalProperty: 'totalCount',
		            idProperty: 'id',
				    messageProperty: 'msg'
		        }
		    }),
		    autoLoad:false
		});

		
		var userWorkItemGrid = Ext.create('Ext.grid.Panel', {
			plugins: cellEditing,
		    //title: '一般费用开销数据表',
		    store:userWorkItemStore,
		    //forceFit : true,
		    id:'userWorkItemGrid',
		    autoWidth : true,
		    autoScroll:true,
			height:500,
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig:{enableTextSelection:true, forceFit : false},
			selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SIMPLE",showHeaderCheckbox:true}),
		    columns: [
			        { text: 'ID',  dataIndex: 'id',hidden:true}, 
			        { text: '名称', width:200, dataIndex: 'workName',menuDisabled:true},
		            { text: '主题', width:200, dataIndex: 'workSubject' ,menuDisabled:true},
		            { text: '状态',  dataIndex: 'subjectState',menuDisabled:true},
		            { text: '已分配', width:120, dataIndex: 'workDate',menuDisabled:true},
		            { text: '主题修改日期', width:120, dataIndex: 'subjectDate',menuDisabled:true},
		            { text: '上下文', width:150, dataIndex: 'contianer',menuDisabled:true},
		            { text: '角色',  dataIndex: 'role',menuDisabled:true},
		            { text: '流程发起人',  dataIndex: 'processCreate',menuDisabled:true}
		        ],
		     tbar: [{
					text : '完成任务',
					iconCls: 'icon icon-apply',
					handler : function() {
						var recordRow = userWorkItemGrid.getSelectionModel().getSelection();
						var idArray = new Array();
						if(recordRow.length==0){
							alert("至少选择一条记录！");
						}
						else{
							for(var i=0;i<recordRow.length;i++){
								var orgRec = recordRow[i].data;
								var tempRec = {
	    	            				   id:orgRec.id,
	    	            				   workName:orgRec.workName
	    	            		   };
	    	            		   idArray[idArray.length] = tempRec;
							}
							Ext.Ajax.request({
								scope:this,
								url: '/Windchill/ptc1/adminTool/userManager/finishWorkItems',
								params:{
									itemRecords:Ext.encode(idArray)							 
								},
								success: function(response, opts) {
									var obj = Ext.decode(response.responseText);
									if(obj['success']){
										alert("活动完成");
										Ext.getStore('userWorkItemStore').reload();	    	
									}else{
							    	  alert(obj['msg']);
									}
								},
								failure: function(response, opts) {
									alert('错误：完成活动失败，请检查网络！');
								}
							}); 
						}
					},
					scope : this
				},{
					text : '重新指派',
					iconCls: 'icon icon-add',
					handler : function() {
						var newUser = Ext.getCmp('workItem_newUser').getValue();
						var recordRow = userWorkItemGrid.getSelectionModel().getSelection();
						var idArray = new Array();
						if(recordRow.length==0){
							alert("至少选择一条记录！");
						}else if(newUser==undefined||newUser==""){
							alert("请输入重新指派的用户账户!");
						} else{
							for(var i=0;i<recordRow.length;i++){
								var orgRec = recordRow[i].data;
								var tempRec = {
	    	            				   id:orgRec.id,
	    	            				   name:newUser
	    	            		   };
	    	            		   idArray[idArray.length] = tempRec;
							}
							Ext.Ajax.request({
								scope:this,
								url: '/Windchill/ptc1/adminTool/userManager/reassignWorkItems',
								params:{
									itemRecords:Ext.encode(idArray)							 
								},
								success: function(response, opts) {
									var obj = Ext.decode(response.responseText);
									if(obj['success']){
										alert("指派完成");
										Ext.getStore('userWorkItemStore').reload();	    	
									}else{
							    	  alert(obj['msg']);
									}
								},
								failure: function(response, opts) {
									alert('错误：指派失败，请检查网络！');
								}
							}); 
						}
					},
					scope : this
				},{
      	    		xtype:'textfield',
      	    		fieldLabel: '指派的用户',
      	            name: 'workItem_newUser',
      	            id: 'workItem_newUser',
      	            width:200,
      	            enableKeyEvents:true 
      	        	},{
					text : '导出列表',
					iconCls: 'icon icon-download',
					hidden:true,
					handler : function() {
						//this.doExportGridData(problemReportGrid);
					},
					scope : this
				}]/*,
		     bbar: Ext.create('Ext.PagingToolbar', {
			    	//pageSize: 2,
			        store: userWorkItemStore,
			        displayInfo: true,
			        displayMsg: '当前显示 {0} - {1} ，共 {2}',
			        emptyMsg: "查询结果为空"
			 })//~End bbar
*/		});
		
		Ext.define('userCheckOutModel', {
		    extend: 'Ext.data.Model',
		    fields: [
		        'id', 'name', 'number', 'type',
		        'version', 'state', 'modifyDate',
		        'container'
		    ],
		    idProperty: 'id'
		});

		// create the Data Store
		var userCheckOutStore = Ext.create('Ext.data.Store', {
		    //pageSize: 100,
		    model: 'userCheckOutModel',
		    id:'userCheckOutStore',
		    pruneModifiedRecords: true,
		    proxy: new Ext.data.HttpProxy({
		        url: '/Windchill/ptc1/adminTool/userManager/getUserCheckOutObjects?',
		        method:'GET',
		        timeout: 9000000,
		        reader:{
		        	type:'json',
		        	root: 'items',
		            totalProperty: 'totalCount',
		            idProperty: 'id',
				    messageProperty: 'msg'
		        }
		    }),
		    autoLoad:false
		});

		var userCheckOutGrid = Ext.create('Ext.grid.Panel', {
			//plugins: cellEditing,
		    //title: '一般费用开销数据表',
		    store:userCheckOutStore,
		    //forceFit : true,
		    id:'userCheckOutGrid',
		    autoWidth : true,
		    autoScroll:true,
			height:500,
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig:{enableTextSelection:true, forceFit : false},
			selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SIMPLE",showHeaderCheckbox:true}),
		    columns: [
			        { text: 'ID',  dataIndex: 'id',hidden:true,menuDisabled:true,},
			        { text: '名称',  dataIndex: 'name',menuDisabled:true},
		            { text: '编号',  dataIndex: 'number' ,menuDisabled:true},
		            { text: '版本',  dataIndex: 'version',menuDisabled:true},
		            { text: '数据类型',  dataIndex: 'type',menuDisabled:true},
		            { text: '状态',  dataIndex: 'state',menuDisabled:true},
		            { text: '上次修改日期', dataIndex: 'modifyDate',menuDisabled:true},
		            { text: '上下文',  dataIndex: 'container',menuDisabled:true}
		        ],
		     tbar: [{
					text : '撤销检出',
					iconCls: 'icon icon-uncheckout',
					handler : function() {
						var recordRow = userCheckOutGrid.getSelectionModel().getSelection();
						var idArray = new Array();
						if(recordRow.length==0){
							alert("至少选择一条记录！");
						}
						else{
							for(var i=0;i<recordRow.length;i++){
								var orgRec = recordRow[i].data;
								var tempRec = {
										number:orgRec.number,
										type:orgRec.type
	    	            		   };
	    	            		   idArray[idArray.length] = tempRec;
							}
							Ext.Ajax.request({
								scope:this,
								url: '/Windchill/ptc1/adminTool/userManager/revokeCheckOut',
								params:{
									itemRecords:Ext.encode(idArray)							 
								},
								success: function(response, opts) {
									var obj = Ext.decode(response.responseText);
									if(obj['success']){
										alert("撤销完成");
										Ext.getStore('userCheckOutStore').reload();	    	
									}else{
							    	  alert(obj['msg']);
									}
								},
								failure: function(response, opts) {
									alert('错误：撤销失败，请检查网络！');
								}
							}); 
						}
					},
					scope : this
				}]/*,
		     bbar: Ext.create('Ext.PagingToolbar', {
			    	//pageSize: 2,
			        store: userCheckOutStore,
			        displayInfo: true,
			        displayMsg: '当前显示 {0} - {1} ，共 {2}',
			        emptyMsg: "查询结果为空"
			 })//~End bbar
			 */
		});
		
		Ext.define('userContainerModel', {
		    extend: 'Ext.data.Model',
		    fields: [
		        'id','containerOid','contianer', 'containerType', 'roleKey',
		        'roleName', 'state'
		    ],
		    idProperty: 'id'
		});

		// create the Data Store
		var userContainerStore = Ext.create('Ext.data.Store', {
		    //pageSize: 100,
		    model: 'userContainerModel',
		    id:'userContainerStore',
		    pruneModifiedRecords: true,
		    proxy: new Ext.data.HttpProxy({
		        url: '/Windchill/ptc1/adminTool/userManager/getUserContainers?',
		        method:'GET',
		        timeout: 9000000,
		        reader:{
		        	type:'json',
		        	root: 'items',
		            totalProperty: 'totalCount',
		            idProperty: 'id',
				    messageProperty: 'msg'
		        }
		    }),
		    autoLoad:false
		});
		
		 var filters = {
			        ftype: 'filters',
			        // encode and local configuration options defined previously for easier reuse
			        encode: false, // json encode the filter query
			        local: true,   // defaults to false (remote filtering)

			        // Filters are most naturally placed in the column definition, but can also be
			        // added here.
			        filters: [{
			            type: 'boolean',
			            dataIndex: 'visible'
			        }]
			    };

		var userContainerGrid = Ext.create('Ext.grid.Panel', {
			//plugins: cellEditing,
		    //title: '一般费用开销数据表',
		    store:userContainerStore,
		    //forceFit : true,
		    id:'userContainerGrid',
		    autoWidth : true,
		    autoScroll:true,
			height:500,
			features: [filters],
			multiSelect : true, // 多选
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig:{enableTextSelection:true, forceFit : false},
			selModel:Ext.create('Ext.selection.CheckboxModel'),
		    columns: [
			        { text: 'ID',  dataIndex: 'id',hidden:true},
			        { text: '上下文Oid',  dataIndex: 'containerOid',hidden:true},
			        { text: '上下文名称',  dataIndex: 'contianer',menuDisabled:true,
						items:{
							xtype: 'textfield',
							flex : 1,
							margin: 2,
							enableKeyEvents: true,
							listeners: {
								keyup: function() {
									var store = userContainerStore;
									store.clearFilter();
									if (this.value) {
										store.filter({
											property     : 'contianer',
											value         : this.value,
											anyMatch      : true,
											caseSensitive : false
										});
									}
								},
								buffer: 500
							}
						}
			        },
		            { text: '上线文类型',  dataIndex: 'containerType' , menuDisabled:true,
						items:{
							xtype: 'textfield',
							flex : 1,
							margin: 2,
							enableKeyEvents: true,
							listeners: {
								keyup: function() {
									var store = userContainerStore;
									store.clearFilter();
									if (this.value) {
										store.filter({
											property     : 'containerType',
											value         : this.value,
											anyMatch      : true,
											caseSensitive : false
										});
									}
								},
								buffer: 500
							}
						}
					},
		            { text: '角色key',  dataIndex: 'roleKey',hidden:true },
		            { text: '所在角色',  dataIndex: 'roleName', menuDisabled:true,
						items:{
							xtype: 'textfield',
							flex : 1,
							margin: 2,
							enableKeyEvents: true,
							listeners: {
								keyup: function() {
									var store = userContainerStore;
									store.clearFilter();
									if (this.value) {
										store.filter({
											property     : 'containerType',
											value         : this.value,
											anyMatch      : true,
											caseSensitive : false
										});
									}
								},
								buffer: 500
							}
						}
					},
		            { text: '状态',  dataIndex: 'state',menuDisabled:true,
						items:{
							xtype: 'textfield',
							flex : 1,
							margin: 2,
							enableKeyEvents: true,
							listeners: {
								keyup: function() {
									var store = userContainerStore;
									store.clearFilter();
									if (this.value) {
										store.filter({
											property     : 'containerType',
											value         : this.value,
											anyMatch      : true,
											caseSensitive : false
										});
									}
								},
								buffer: 500
							}
						}
					}
		        ],
		     tbar: [{
					text : '替换角色人员',
					iconCls: 'icon icon-add',
					handler : function() {
						var recordRow = userContainerGrid.getSelectionModel().getSelection();
						var newUser = Ext.getCmp('role_newUser').getValue();
						var idArray = new Array();
						if(recordRow.length==0){
							alert("至少选择一条记录！");
						}else if(newUser==undefined||newUser==""){
							alert("请输入重新指派的用户账户!");
						} else{
							for(var i=0;i<recordRow.length;i++){
								var orgRec = recordRow[i].data;
								var tempRec = {
										name:Ext.getCmp('workItem_userName').getValue(),
										fullName:Ext.getCmp('workItem_userFullName').getValue(),
										newName:newUser,
										containerOid:orgRec.containerOid,
										containerType:orgRec.containerType,
										roleKey:orgRec.roleKey										
	    	            		   };
	    	            		   idArray[idArray.length] = tempRec;
							}
							Ext.Ajax.request({
								scope:this,
								url: '/Windchill/ptc1/adminTool/userManager/updateUserFormTeam',
								params:{
									itemRecords:Ext.encode(idArray)							 
								},
								success: function(response, opts) {
									var obj = Ext.decode(response.responseText);
									if(obj['success']){
										alert("替换完成！");
										Ext.getStore('userContainerStore').reload();	    	
									}else{
							    	  alert(obj['msg']);
									}
								},
								failure: function(response, opts) {
									alert('错误：从团队删除失败，请检查网络！');
								}
							}); 
						}
					},
					scope : this
				},{
      	    		xtype:'textfield',
      	    		fieldLabel: '新的用户',
      	            name: 'role_newUser',
      	            id: 'role_newUser',
      	            width:200,
      	            enableKeyEvents:true 
      	        	},{
					text : '导出列表',
					iconCls: 'icon icon-download',
					hidden:true,
					handler : function() {
						//this.doExportGridData(problemReportGrid);
					},
					scope : this
				},'->', {
					text : '从团队角色清除',
					iconCls: 'icon icon-download',
					handler : function() {
						var recordRow = userContainerGrid.getSelectionModel().getSelection();
						var idArray = new Array();
						if(recordRow.length==0){
							alert("至少选择一条记录！");
						} else{
							for(var i=0;i<recordRow.length;i++){
								var orgRec = recordRow[i].data;
								var tempRec = {
										name:Ext.getCmp('workItem_userName').getValue(),
										fullName:Ext.getCmp('workItem_userFullName').getValue(),									
										containerOid:orgRec.containerOid,
										containerType:orgRec.containerType,
										roleKey:orgRec.roleKey										
	    	            		   };
	    	            		   idArray[idArray.length] = tempRec;
							}
							Ext.Ajax.request({
								scope:this,
								url: '/Windchill/ptc1/adminTool/userManager/deleteUserFormTeam',
								params:{
									itemRecords:Ext.encode(idArray)							 
								},
								success: function(response, opts) {
									var obj = Ext.decode(response.responseText);
									if(obj['success']){
										alert("从团队删除完成");
										Ext.getStore('userContainerStore').reload();	    	
									}else{
							    	  alert(obj['msg']);
									}
								},
								failure: function(response, opts) {
									alert('错误：从团队删除失败，请检查网络！');
								}
							}); 
						}
					},
					scope : this
				}]/*,
		     bbar: Ext.create('Ext.PagingToolbar', {
			    	//pageSize: 2,
			        store: userContainerStore,
			        displayInfo: true,
			        displayMsg: '当前显示 {0} - {1} ，共 {2}',
			        emptyMsg: "查询结果为空"
			 })//~End bbar
*/		});
		
		Ext.define('userGroupModel', {
		    extend: 'Ext.data.Model',
		    fields: [
		        'id', 'groupID', 'groupName'
		    ],
		    idProperty: 'id'
		});

		// create the Data Store
		var userGroupStore = Ext.create('Ext.data.Store', {
		    //pageSize: 100,
		    model: 'userGroupModel',
		    id:'userGroupStore',
		    pruneModifiedRecords: true,
		    proxy: new Ext.data.HttpProxy({
		        url: '/Windchill/ptc1/adminTool/userManager/getUserGroups?',
		        method:'GET',
		        timeout: 9000000,
		        reader:{
		        	type:'json',
		        	root: 'items',
		            totalProperty: 'totalCount',
		            idProperty: 'id',
				    messageProperty: 'msg'
		        }
		    }),
		    autoLoad:false
		});

		var userGroupGrid = Ext.create('Ext.grid.Panel', {
			//plugins: cellEditing,
		    //title: '一般费用开销数据表',
		    store:userGroupStore,
		    //forceFit : true,
		    id:'userGroupGrid',
		    autoWidth : true,
		    autoScroll:true,
			height:500,
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig:{enableTextSelection:true, forceFit : false},
			selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SIMPLE",showHeaderCheckbox:true}),
		    columns: [
		            { text: 'id',  dataIndex: 'id',hidden:true},  
			        { text: 'groupID',  dataIndex: 'groupID',hidden:true}, 
			        { text: '所在组',  dataIndex: 'groupName', width:200,menuDisabled:true}
		        ],
		     tbar: [{
					text : '从组中移除',
					iconCls: 'icon icon-download',
					handler : function() {
						var recordRow = userGroupGrid.getSelectionModel().getSelection();
						var idArray = new Array();
						if(recordRow.length==0){
							alert("至少选择一条记录！");
						}
						else{
							for(var i=0;i<recordRow.length;i++){
								var orgRec = recordRow[i].data;
								var tempRec = {
										name:Ext.getCmp('workItem_userName').getValue(),
										fullName:Ext.getCmp('workItem_userFullName').getValue(),
										groupID:orgRec.groupID									
	    	            		   };
	    	            		   idArray[idArray.length] = tempRec;
							}
							Ext.Ajax.request({
								scope:this,
								url: '/Windchill/ptc1/adminTool/userManager/deleteUserFormGroup',
								params:{
									itemRecords:Ext.encode(idArray)							 
								},
								success: function(response, opts) {
									var obj = Ext.decode(response.responseText);
									if(obj['success']){
										alert("从组删除完成");
										Ext.getStore('userGroupStore').reload();	    	
									}else{
							    	  alert(obj['msg']);
									}
								},
								failure: function(response, opts) {
									alert('错误：从组删除失败，请检查网络！');
								}
							}); 
						}
					},
					scope : this
				},{
					text : '替换组人员',
					iconCls: 'icon icon-add',
					handler : function() {
						var newUser = Ext.getCmp('group_newUser').getValue();
						var recordRow = userGroupGrid.getSelectionModel().getSelection();
						var idArray = new Array();
						if(recordRow.length==0){
							alert("至少选择一条记录！");
						}else if(newUser==undefined||newUser==""){
							alert("请输入替换用户的账户！")
						} else{
							for(var i=0;i<recordRow.length;i++){
								var orgRec = recordRow[i].data;
								var tempRec = {
										name:Ext.getCmp('workItem_userName').getValue(),
										fullName:Ext.getCmp('workItem_userFullName').getValue(),
										newName:newUser,
										groupID:orgRec.groupID									
	    	            		   };
	    	            		   idArray[idArray.length] = tempRec;
							}
							Ext.Ajax.request({
								scope:this,
								url: '/Windchill/ptc1/adminTool/userManager/updateUserFormGroup',
								params:{
									itemRecords:Ext.encode(idArray)							 
								},
								success: function(response, opts) {
									var obj = Ext.decode(response.responseText);
									if(obj['success']){
										alert("替换完成！");
										Ext.getStore('userGroupStore').reload();	    	
									}else{
							    	  alert(obj['msg']);
									}
								},
								failure: function(response, opts) {
									alert('错误：从组删除失败，请检查网络！');
								}
							}); 
						}
					},
					scope : this
				},{
      	    		xtype:'textfield',
      	    		fieldLabel: '新的用户',
      	            name: 'group_newUser',
      	            id: 'group_newUser',
      	            width:200,
      	            enableKeyEvents:true 
      	        	},{
					text : '导出列表',
					iconCls: 'icon icon-download',
					hidden:true,
					handler : function() {
						//this.doExportGridData(problemReportGrid);
					},
					scope : this
				}]/*,
		     bbar: Ext.create('Ext.PagingToolbar', {
			    	//pageSize: 2,
			        store: userGroupStore,
			        displayInfo: true,
			        displayMsg: '当前显示 {0} - {1} ，共 {2}',
			        emptyMsg: "查询结果为空"
			 })//~End bbar
*/		});
				
/////////////////////////Panel items//////////////////////////////////
		this.items=[{
			xtype: 'fieldset',
    		margin:'5 3 10 3',
            title: '<font style="font-size:12px">查询参数</font>',
            collapsible: true,
            defaults: {
                labelWidth: 100,
                border:false,
                anchor: '98%',
                layout: {
                    type: 'hbox'
                }
            },
			items:[{
	        	xtype: 'panel',
	            defaults:{ margin:'5 20 0 0',labelWidth:70},
	        	items:[{
      	    		xtype:'textfield',
      	    		fieldLabel: '用户名',
      	            name: 'workItem_userName',
      	            id: 'workItem_userName',
      	            width:200,
      	            enableKeyEvents:true,
      	            listeners:{  
      	            	scope:this,
      	                'specialkey':function(field,e)  
      	                {  
      	                	if(e.getKey() == Ext.EventObject.ENTER)  
      	                    {  
      	                        this.doSearch();
      	                    }  
      	                }  
      	            } 
      	        	}, {
      	    		xtype:'textfield',
      	    		fieldLabel: '全名',
      	            name: 'workItem_userFullName',
      	            id: 'workItem_userFullName',
      	            width:200,
      	            enableKeyEvents:true,
      	            listeners:{  
      	            	scope:this,
      	                'specialkey':function(field,e)  
      	                {  
      	                	if(e.getKey() == Ext.EventObject.ENTER)  
      	                    {  
      	                        this.doSearch();
      	                    }  
      	                }  
      	            } 
      	        	}]
				},{
		        	xtype:'panel',
		        	items:[{
			            xtype:'button',
			            margin:'10 0 10 0',
			            width:70,
			        	text: '查询',
			        	scope:this,
		                iconCls: 'icon icon-search',
			            handler: function() {
			            	this.doSearch();
			            }
		        	}]
		        }
		        ]
		},{
      		xtype:'tabpanel',
    		header: false,
    		collapsible: true,
        	split: true,
        	height:900,
    		activeTab: 0,
	        items:[{
	            title: '用户任务',
	            items:userWorkItemGrid
	        } ,{
	        	title: '检出的工作',
	        	items:userCheckOutGrid
	        } ,{
	        	title: '所在上下文',
	        	items:userContainerGrid
	        } ,{
	        	title: '所在组',
	        	items:userGroupGrid
	        }
	        ]//~End of tabpanel items
        }
		];
		
		this.callParent();
	},//~End of initComponent
	
	listeners:{
		'afterrender':function(){}
	},

////////////////////////Function area//////////////////////////
	
	doExportGridData: function(grid) {
		 /*if(grid.getSelectionModel().getSelection().length <= 0) {
			   alert('下载之前，请先选中行！');
			   return;
		   }
		 var orgRec; // 临时记录
		 var exportRecords = new Array();// 修改记录
		 var selectRecordsOrg = grid.getSelectionModel().getSelection(); //获取选中列
		 for(var i=0, l= selectRecordsOrg.length; i<l; i++){
  		     orgRec = selectRecordsOrg[i].data;
	   		 var tempRec = {
						'0-项目编号' : orgRec.projectNumber,
						'1-产品名称': orgRec.productName,
						'2-部件名称' : orgRec.partName,
						'3-问题编号' : orgRec.problemNumber,
						'4-问题类型': orgRec.problemType,
						'5-问题发现者': orgRec.problemsDiscoverer,
						'6-问题提出者': orgRec.problemsAuthor,
						'7-问题解决者': orgRec.problemsSolver,
						'8-问题点概述': orgRec.briefOfProblems,
						'9-改善方法简述': orgRec.methodOfImprove,
						'10-计划完成时间': orgRec.problemsPlanEndData,
						'11-实际完成时间':orgRec.actualEndDate
						//'': orgRec.projectTeam,
						
					};
	   		exportRecords[exportRecords.length] = tempRec;
  	   	}
		 Ext.Ajax.request({
		   		   url: '/Windchill/ptc1/dataReport/exportProblemManagerData',
		   		   params:{
		   			exportRecords:Ext.encode(exportRecords)
		   		   },
			   		success: function(response, opts) {
			   			window.location.href='exportProblemManagerData.jsp';
			   		},
   			   	failure: function(response, opts) {
			 			alert('错误：导出失败，请检查网络！');
			 		}
  			});//~End of request
*/		
		},
	/**
	 * 按查询参数查询
	 */
	doSearch: function(){

		var data = {
				fullName:Ext.getCmp('workItem_userFullName').getValue(),
				name:Ext.getCmp('workItem_userName').getValue()
		};
		Ext.getStore('userWorkItemStore').load({
			params:{
				data:Ext.encode(data)
				},
			callback: function(records, operation, success) {
		        if(!success){
		        	alert('查询用户任务信息失败，请联系管理员！');
		        }
			}
		});
		Ext.getStore('userCheckOutStore').load({
			params:{
				data:Ext.encode(data)
				},
			callback: function(records, operation, success) {
		        if(!success){
		        	alert('查询检出数据信息失败，请联系管理员！');
		        }
			}
		});
		Ext.getStore('userContainerStore').load({
			params:{
				data:Ext.encode(data)
				},
			callback: function(records, operation, success) {
		        if(!success){
		        	alert('查询上下文信息失败，请联系管理员！');
		        }
			}
		});
		
		Ext.getStore('userGroupStore').load({
			params:{
				data:Ext.encode(data)
				},
			callback: function(records, operation, success) {
		        if(!success){
		        	alert('查询用户组信息失败，请联系管理员！');
		        }
			}
		});
	},
	/**
     * Finds all strings that matches the searched value in each grid cells.
     * @private
     */
     onTextFieldChange: function() {
         var me = Ext.getCmp('userContainerGrid'),
             count = 0;

         me.view.refresh();

         me.searchValue = this.getSearchValue();
         me.indexes = [];
         me.currentIndex = null;

         if (me.searchValue !== null) {
             me.searchRegExp = new RegExp(me.searchValue, 'g' + (me.caseSensitive ? '' : 'i'));
             
             
             me.store.each(function(record, idx) {
                 var td = Ext.fly(me.view.getNode(idx)).down('td'),
                     cell, matches, cellHTML;
                 while(td) {
                     cell = td.down('.x-grid-cell-inner');
                     matches = cell.dom.innerHTML.match(me.tagsRe);
                     cellHTML = cell.dom.innerHTML.replace(me.tagsRe, me.tagsProtect);
                     
                     // populate indexes array, set currentIndex, and replace wrap matched string in a span
                     cellHTML = cellHTML.replace(me.searchRegExp, function(m) {
                        count += 1;
                        if (Ext.Array.indexOf(me.indexes, idx) === -1) {
                            me.indexes.push(idx);
                        }
                        if (me.currentIndex === null) {
                            me.currentIndex = idx;
                        }
                        return '<span class="x-livesearch-match">' + m + '</span>';
                     });
                     // restore protected tags
                     Ext.each(matches, function(match) {
                        cellHTML = cellHTML.replace(me.tagsProtect, match); 
                     });
                     // update cell html
                     cell.dom.innerHTML = cellHTML;
                     td = td.next();
                 }
             }, me);

             // results found
             if (me.currentIndex !== null) {
                 me.getSelectionModel().select(me.currentIndex);
             }
         }

         // no results found
         if (me.currentIndex === null) {
             me.getSelectionModel().deselectAll();
         }

         // force textfield focus
         Ext.getCmp('searchField').focus();
     },
     
     /**
      * In normal mode it returns the value with protected regexp characters.
      * In regular expression mode it returns the raw value except if the regexp is invalid.
      * @return {String} The value to process or null if the textfield value is blank or invalid.
      * @private
      */
     getSearchValue: function() {
         var me = Ext.getCmp('userContainerGrid'),
             value = Ext.getCmp('searchField').getValue();
             
         if (value === '') {
             return null;
         }
         if (!me.regExpMode) {
             value = value.replace(me.regExpProtect, function(m) {
                 return '\\' + m;
             });
         } else {
             try {
                 new RegExp(value);
             } catch (error) {
                 return null;
             }
             // this is stupid
             if (value === '^' || value === '$') {
                 return null;
             }
         }

         return value;
     },
     /**
      * Selects the previous row containing a match.
      * @private
      */   
     onPreviousClick: function() {
         var me = Ext.getCmp('userContainerGrid'),
             idx;
             
         if ((idx = Ext.Array.indexOf(me.indexes, me.currentIndex)) !== -1) {
             me.currentIndex = me.indexes[idx - 1] || me.indexes[me.indexes.length - 1];
             me.getSelectionModel().select(me.currentIndex);
          }
     },
     
     /**
      * Selects the next row containing a match.
      * @private
      */    
     onNextClick: function() {
          var me = Ext.getCmp('userContainerGrid'),
              idx;
              
          if ((idx = Ext.Array.indexOf(me.indexes, me.currentIndex)) !== -1) {
             me.currentIndex = me.indexes[idx + 1] || me.indexes[0];
             me.getSelectionModel().select(me.currentIndex);
          }
     }
	
});

