Ext.define('PLM.view.BomToolPanel',{
    extend:'Ext.panel.Panel',
    alias:'widget.BomToolPanel',
    border:false,
    layout:'anchor',
    autoScroll:true,
    autoWidth:true,
    autoHeight:true,
    collapsible: false,
    id: 'bomToolPanel',
    initComponent:function(){

//===================开始 1. 批量BOM导入 =====================


       var importHistoryBomPanel = Ext.create('Ext.panel.Panel',{
            bodyPadding: 10,
           items:[{
                xtype:'panel',
               width:'70%',
               margin:'0 0 20 0',
                //collapsible: true,
                frame:false,
                html:'说明：按Excel 格式批量导入BOM'
            },{
                xtype: 'form',
               margin:'0 0 20 0',
               width:'70%',
                items:[{
                    xtype: 'filefield',
                    id: 'form-file',
                    emptyText: '选择Excel批量导入文件',
                    fieldLabel: '文件',
                    name: 'photo-path',
                    buttonText: '',
                    buttonConfig: {
                        iconCls: 'icon-compute'
                    }
                }],
                buttons:[{
                    text: '开始执行',
                    handler: function(){
                        var form = this.up('form').getForm();
                        /*if(form.isValid()){
                            form.submit({
                                url: '/Windchill/ptc1/adminTool/importHistoryBom',
                                waitMsg: '正在处理...',
                                success: function(fp, o) {
                                    //msg('Success', tpl.apply(o.result));
                                    Ext.getCmp('importBomResult').html = '测试结果';
                                }
                            });
                        }*/
                        //Ext.getCmp('importBomResult').html = '测试结果';
                    }
                }]//~end of buttons
            },{
                //xtype:'framed-panels',
               width:'70%',
                xtype:'panel',
               frame:false,
                //collapsible: true,
                title:'运行结果',
                id:'importBomResult',
                html:'ffffff'
            }]//~end of panel items
       });


//===================结束 1. 批量BOM导入 =====================


//===================开始 2. 按编码前缀批量导出BOM =====================
        var exportBomByNumber = Ext.create('Ext.panel.Panel',{
            items:[{
                title:'批量导入BOM',
                items:[{html:'test'}]
            }]
        });


//===================结束 2. 按编码前缀批量导出BOM =====================

/////////////////////////Main Panel items//////////////////////////////////
        this.items=[{
            xtype:'tabpanel',
            height: '100%',
            header: false,
            collapsible: true,
            split: true,
            activeTab: 0,
            items:[{
                xtype:'panel',
                height: '100%',
                header: false,
                title:"批量导入BOM",
                collapsible: true,
                split: true,
                items:[importHistoryBomPanel]
                //items:[{html:'aaaaa'}]
            },{
                xtype:'panel',
                height: '100%',
                header: false,
                title:"按编号前缀导出BOM",
                collapsible: true,
                split: true,
                items:[{html:'ssss'}]
            }]
        }];

        this.callParent();

    }//~End of initComponent
});

