
<%-- //////////////////Start - HTML Area //////////////////// --%>

<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>

<%-- //////////////////End - HTML Area //////////////////// --%>
<%
String oid = request.getParameter("oid");
%>
<!DOCTYPE iframe PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head><title>PLM用户任务管理</title></head>
</html>
<iframe id="userManagerQueryPlugin" src="netmarkets/jsp/ext/plm/adminTool/userManagerQueryPlugin.jsp?oid=<%=oid %>"  style="width:98%;height:660px" ></iframe>