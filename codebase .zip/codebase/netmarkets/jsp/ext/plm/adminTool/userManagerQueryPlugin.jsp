<%@page import="wt.fc.ReferenceFactory"%>
<%@ page language="java" contentType="text/html; charset=utf-8"
    pageEncoding="utf-8"%>
    
<%
 String oid = request.getParameter("oid");
ReferenceFactory rf = new ReferenceFactory();

wt.org.WTPrincipal principal =  wt.session.SessionHelper.manager.getPrincipal();
wt.org.WTUser wtuser = (wt.org.WTUser)principal;
String currentUserName = wtuser.getFullName();
String currentUserNameId = wtuser.getName();
boolean isManager = true;//PntCostLogic.isProjectManager(p, wtuser);
boolean isAuthority = true;//PntCostLogic.hasAuthority(p, wtuser, "RWD_CostManager");
boolean isAdmin = true;
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<script type="text/javascript">
//当前用户
var currentUser = '<%=currentUserName%>';
//是否是存储库管理员
var isManager = "<%=isManager%>";
//项目oid
 var PROJECTOID = "<%=oid%>";

//专门的角色权限
var isAuthority = "<%=isAuthority%>";

//管理员
var isAdmin = "<%=isAdmin%>";

function checkNodeEnable() {
	var flag = false;
	if(isManager == "true" || isAdmin == "true") {
		flag = true;
	}
	return flag;
}

function checkNodeAuthority() {
	var flag = false;
	if(isAuthority == "true") {
		flag = true;
	}
	return flag;
}

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	
	     <!-- ExtJS -->
    
	<link rel="stylesheet" type="text/css"
	href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/css/ext-all.css">
	 <link href="/Windchill/netmarkets/css/plm/ctLibraryManagement.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
   <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>

 	<script type="text/javascript" src="js/userManagerPanel.js"></script>
    <script type="text/javascript">

	  //==============主入口=================================//
	  Ext.onReady(function() {
	  Ext.QuickTips.init();
	  Ext.create('Ext.container.Viewport', {
	      layout: 'border',
	      items: [ {
	          region: 'center',
	          items:[{
	        	  title: '<font style="font-size:12px">PLM用户管理报表</font>',		    	            
	              xtype:'UserManagerPanel'
	        }]//~End of center region items
	      }]//~End of viewPort items
	  });
	
	  });
    </script>
</head>

<body>


</body>
</html>