<%@page import="wt.fc.ReferenceFactory"%>
<%@page import="wt.fc.ReferenceFactory"%>
<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>
<head>

    <%
        String oid = request.getParameter("oid");
        ReferenceFactory rf = new ReferenceFactory();

        wt.org.WTPrincipal principal =  wt.session.SessionHelper.manager.getPrincipal();
        wt.org.WTUser wtuser = (wt.org.WTUser)principal;
        String currentUserName = wtuser.getFullName();
        String currentUserNameId = wtuser.getName();
        boolean isManager = true;//PntCostLogic.isProjectManager(p, wtuser);
        boolean isAuthority = true;//PntCostLogic.hasAuthority(p, wtuser, "RWD_CostManager");
        boolean isAdmin = true;
    %>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
    href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="js/dataAuditAnalysisPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
 	 <script type="text/javascript" src="js/dataChangeAnalysisPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>
 	 <script type="text/javascript" src="js/projectDocProcessPanel.js?_dc=<%=System.currentTimeMillis()%>"></script>


</head>

<body>
<script type="text/javascript">
    //当前用户
    var currentUser = '<%=currentUserName%>';
    //是否是存储库管理员
    var isManager = "<%=isManager%>";
    //项目oid
    var PROJECTOID = "<%=oid%>";
    //项目oid
    var projectId = "<%=oid%>";
    //专门的角色权限
    var isAuthority = "<%=isAuthority%>";

    //管理员
    var isAdmin = "<%=isAdmin%>";

    function checkNodeEnable() {
        var flag = false;
        if(isManager == "true" || isAdmin == "true") {
            flag = true;
        }
        return flag;
    }

    function checkNodeAuthority() {
        var flag = false;
        if(isAuthority == "true") {
            flag = true;
        }
        return flag;
    }

    //==============主入口=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        /*Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'departmentManagerQuery'
            }]
        });*/
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [ {
                region: 'center',
                //xtype:'DataAuditAnalysisPanel'
                items:[{
                    xtype:'panel',
                    border:false,
                    items:[{
                        xtype:'tabpanel',
                        activeTab: 0,
                        items:[{
                            title: '<font style="font-size:12px">数据审核流程统计表</font>',
                            xtype:'DataAuditAnalysisPanel'
                        },{
                            title: '<font style="font-size:12px">数据变更流程统计表</font>',
                            xtype:'DataChangeAnalysisPanel'
                        },{
                           title: '<font style="font-size:12px">文档流程统计</font>',
                           xtype:'ProjectDocProcessPanel'
                       }]//~End of tabpanel items
                    }]
                }]//~End of center region items
            }]//~End of viewPort items
        });
    });

</script>

</body>
</html>