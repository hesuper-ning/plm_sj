<%@page import="ext.plm.processReport.report.CtDataReportLogic"%>
<%@page import="org.json.JSONArray"%>
<%--<%@page import="ext.angelProject.util.CtJasonUtil"%>--%>
<%
	response.setCharacterEncoding("UTF-8");
%>
<%@ page import="java.util.List,java.io.OutputStream, java.util.HashMap"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%
	String fileName = "数据审核流程报表";
	response.setContentType("application/msexcel");
	response.setHeader("Content-Disposition", "attachment;filename="
	+ java.net.URLEncoder.encode(fileName, "UTF-8") + ".xlsx");
	response.setHeader("Cache-Control", "no-cache");
	OutputStream os = response.getOutputStream();
	List<HashMap<String,Object>> exportRecords = (List<HashMap<String,Object>>)request.getSession().getAttribute(("auditAnalysisList"));
	CtDataReportLogic.exportAuditData(os, exportRecords);
	os.flush();
	os.close();
	out.clear();
	out = pageContext.pushBody();
%>