<%@page import="ext.plm.processReport.report.CtDataReportLogic,ext.plm.processReport.report.bo.CtDataAuditAnalysisBo"%>
<%
	response.setCharacterEncoding("UTF-8");
%>
<%@ page import="java.io.OutputStream,java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%
	String fileName = "数据审核流程统计报表";
	response.setContentType("application/msexcel");
	response.setHeader("Content-Disposition", "attachment;filename="
	+ java.net.URLEncoder.encode(fileName, "UTF-8") + ".xlsx");
	response.setHeader("Cache-Control", "no-cache");
	OutputStream os = response.getOutputStream();
	List<CtDataAuditAnalysisBo> list = (List<CtDataAuditAnalysisBo>) request.getSession().getAttribute(
	"dataAuditAnalysis"); 
	/* String processNumber = "";
	String processName = "";
	String processState = "";
	String createUser = "";
	String containerName = "";
	String createDate_start = "";
	String createDate_end = "";
	if (CtFormatUtil.hasContent(request.getParameter("processNumber"))) {
		processNumber = request.getParameter("processNumber");
	}
	if (CtFormatUtil.hasContent(request.getParameter("processName"))) {
		processName = request.getParameter("processName");
	}
	if (CtFormatUtil.hasContent(request.getParameter("processState"))) {
		processState = request.getParameter("processState");
	}
	if (CtFormatUtil.hasContent(request.getParameter("createUser"))) {
		createUser = request.getParameter("createUser");
	}
	if (CtFormatUtil.hasContent(request.getParameter("containerName"))) {
		containerName = request.getParameter("containerName");
	}
	if (CtFormatUtil.hasContent(request.getParameter("processState"))) {
		processState = request.getParameter("processState");
	}
	if (CtFormatUtil.hasContent(request.getParameter("createDate_start"))) {
		createDate_start = request.getParameter("createDate_start");
	}
	if (CtFormatUtil.hasContent(request.getParameter("createDate_end"))) {
		createDate_end = request.getParameter("createDate_end");
	}
	HashMap<String, Object> headInfo = new HashMap<String, Object>();
	headInfo.put("processNumber", processNumber);
	headInfo.put("processName", processName);
	headInfo.put("processState", processState);
	headInfo.put("createUser", createUser);
	headInfo.put("containerName", containerName);
	headInfo.put("createDate_start", createDate_start);
	headInfo.put("createDate_end", createDate_end); */
	
	CtDataReportLogic.exportAllAuditData(os, list);

	os.flush();
	os.close();
	out.clear();
	out = pageContext.pushBody();
%>