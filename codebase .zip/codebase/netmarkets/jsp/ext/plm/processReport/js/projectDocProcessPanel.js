Ext.define('PLM.view.ProjectDocProcessPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ProjectDocProcessPanel',
    border: false,
    autoWidth: true,
    //autoHeight:true,
    height: 880,
    title: '<font style="font-size:15px">文档流程统计</font>',
    collapsible: false,
    id: 'ProjectDocProcessPanel',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        //文档类型列表
        Ext.define('docTypeModel', {
            extend: 'Ext.data.Model',
            fields: ['key', 'displayText'],
            idProperty: 'id'
        });
        var docTypeStore = new Ext.data.Store(
            {
                storeId: 'docTypeStore',
                model: 'docTypeModel',
                pruneModifiedRecords: true,
                proxy: new Ext.data.HttpProxy(
                    {
                        url: '/Windchill/ptc1/docProcess/getDocTypeList',
                        method: 'GET',
                        reader: {
                            type: 'json',
                            root: 'items',
                            idProperty: 'id',
                            messageProperty: 'msg'
                        }
                    }),
                autoLoad: true,
            });
        //状态列表
        Ext.define('stateModel', {
            extend: 'Ext.data.Model',
            fields: ['value', 'display'],
            idProperty: 'id'
        });
        var stateStore = new Ext.data.Store(
            {
                storeId: 'stateStore',
                model: 'stateModel',
                pruneModifiedRecords: true,
                proxy: new Ext.data.HttpProxy(
                    {
                        url: '/Windchill/ptc1/docProcess/getState?type=doc',
                        method: 'GET',
                        reader: {
                            type: 'json',
                            root: 'data',
                            idProperty: 'id',
                            messageProperty: 'msg'
                        }
                    }),
                autoLoad: true,
            });
        var docTypeStoreCombo = new Ext.form.ComboBox({
            typeAhead: true,
            fieldLabel: '文档类型',
            store: docTypeStore,
            triggerAction: 'all',
            name: 'docTypeStoreCombo',
            id: 'docTypeStoreCombo',
            editable: true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 200,
            labelWidth: 70,
            selectOnFocus: true,
            forceSelection: true,
            valueField: 'displayText',
            displayField: 'displayText'
        });

        var stateCombo = new Ext.form.ComboBox({
            typeAhead: true,
            fieldLabel: '状态',
            store: stateStore,
            triggerAction: 'all',
            name: 'txt_state',
            id: 'txt_state',
            editable: true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 200,
            labelWidth: 70,
            selectOnFocus: true,
            forceSelection: true,
            valueField: 'display',
            displayField: 'display'
        });

        Ext.define('ProjectModel', {
            extend: 'Ext.data.Model',
            fields: [
                'projectNumber', 'name'
            ],
            idProperty: 'id'
        });


        // 项目下拉
        var projectListStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'ProjectModel',
            id: 'projectListStore',
            pruneModifiedRecords: true,
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/docProcess/getAllProject',
                reader: {
                    type: 'json',
                    root: 'data',
                    rootProperty: 'id'
                }
            },
            autoLoad: true
        });

        var projectListCombo = new Ext.form.ComboBox({
            typeAhead: true,
            fieldLabel: '项目名称',
            store: projectListStore,
            triggerAction: 'all',
            name: 'txt_containerName',
            id: 'txt_containerName',
            editable: true,
            enableRegEx:true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 200,
            labelWidth: 70,
            selectOnFocus: true,
            forceSelection: true,
            valueField: 'name',
            displayField: 'name'
        });

        var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });

        var userCombo = new Ext.form.ComboBox({
            typeAhead: false,
            fieldLabel: '创建者',
            store: allUserStore_projectPlan,
            triggerAction: 'all',
            enableRegEx:true,
            name: 'txt_creator',
            id: 'txt_creator',
            editable: true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 220,
            labelWidth: 70,
            selectOnFocus: true,
            forceSelection: true,
            valueField: 'userFullName',
            displayField: 'userFullName'
        });


        //开始时间
        var startTime = new Ext.form.DateField({
            allowBlank: false,
            id: 'startDate',
            name: 'startDate',
            labelWidth: 70,
            margin: '5 10 10 0',
            width: 200,
            fieldLabel: '开始时间',
            format: 'Y-m-d'
        });

        //结束时间
        var endTime = new Ext.form.DateField({
            allowBlank: false,
            id: 'endDate',
            name: 'endDate',
            labelWidth: 80,
            width: 210,
            margin: '5 10 10 0',
            fieldLabel: '&nbsp;&nbsp;&nbsp;到',
            format: 'Y-m-d'
        });


        Ext.define('projectDocProcessModel', {
            extend: 'Ext.data.Model',
            fields: ['key', 'displayText'],
            idProperty: 'id'
        });
        var projectDocProcessStore = new Ext.data.Store({
            storeId: 'projectDocProcessStore',
            model: 'projectDocProcessModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/dataReport/getAllContainer',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'msg'

                }
            }),
            autoLoad: true,
            listeners: {}
        });



        var projectDocProcessCombo = new Ext.form.ComboBox({
            typeAhead: true,
            fieldLabel: '上下文',
            store: projectDocProcessStore,
            triggerAction: 'all',
            name: 'projectDocProcessCombo',
            id: 'projectDocProcessCombo',
            editable: true,
            allowBlank: false,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            labelWidth: 70,
            width: 200,
            enableRegEx:true,
            selectOnFocus: true,
            valueField: 'displayText',
            displayField: 'displayText'
        });

        //审核详情
        Ext.define('detailsModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'projectId', 'rowId', 'activityName', 'responsibleUser', 'roleName',
                'vote', 'remarks', 'finishUser', 'taskReceptionTime',
                'finishTime', 'isOverdue', 'overdueCycle','deadline','actualCycle'
            ],
            idProperty: 'id'
        });
        // create the Data Store
        var detailsStore = Ext.create('Ext.data.Store', {
            pageSize: 100,
            model: 'detailsModel',
            id: 'detailsStore',
            pruneModifiedRecords: true,
            autoLoad: false
        });

        var detailsColumn = [
            {text: 'ID', dataIndex: 'id', hidden: true},
            {text: '项目ID', dataIndex: 'projectId', hidden: true},
            {text: '序号', dataIndex: 'rowId', align: 'center', width: 40, xtype: 'rownumberer'},
            {text: '任务名称', dataIndex: 'activityName', width: 250},
            {text: '负责人', dataIndex: 'responsibleUser', width: 100},
            {text: '角色', dataIndex: 'roleName', width: 180},
            {text: '投票', dataIndex: 'vote'},
            {text: '备注', dataIndex: 'remarks'},
            {text: '完成者', dataIndex: 'finishUser'},
            {text: '任务接收时间', dataIndex: 'taskReceptionTime', width: 160},
            {text: '完成时间', dataIndex: 'finishTime', width: 160},
            {text: '是否逾期', dataIndex: 'isOverdue', width: 120 },
            { text: '实际周期（天）',  dataIndex: 'actualCycle', width: 120 },
            { text: '标准周期（天）',  dataIndex: 'deadline', width: 120  },
            {text: '逾期周期（天）', dataIndex: 'overdueCycle', width: 120 }
        ];

        // create the Data Grid
        var detailsGrid = Ext.create('Ext.grid.Panel', {
            //title: '一般费用开销数据表',
            store: detailsStore,
            //forceFit : true,
            autoWidth: true,
            autoScroll: true,
            title: '审核详情(当选中多条流程时，审核详情区域只显示最后选中流程的审核详情)',
            height: 250,
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {enableTextSelection: true, forceFit: false},
            selModel: Ext.create('Ext.selection.CheckboxModel', {mode: "SIMPLE", showHeaderCheckbox: true}),
            columns: detailsColumn/*,
		        bbar: Ext.create('Ext.PagingToolbar', {
			    	pageSize: 300,
			        store: detailsStore,
			        displayInfo: true,
			        displayMsg: '当前显示 {0} - {1} ，共 {2}',
			        emptyMsg: "查询结果为空"
		        })//~End bbar
*/
        });


        //文档流程信息
        Ext.define('projectDocModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'projectId', 'rowId', 'containerName', 'docNumber', 'docName', 'processName',
                'processOid', 'state', 'creator', 'processStartTime', 'processEndTime',
                'rejectionCount', 'auditCycle', 'docType', 'currentNode', 'currentResponsibleUser','link'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        var projectDocStore = Ext.create('Ext.data.Store', {
            pageSize: 500,
            model: 'projectDocModel',
            id: 'projectDocStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/docProcess/getDocProcessInfo?projectId=' + projectId,
                method: 'GET',
                timeout: 90000000,
                reader: {
                    type: 'json',
                    root: 'data.resultData',
                    totalProperty: 'data.total',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });
        //初始化参数
        projectDocStore.on('beforeload', function (store, options) {
            var data = {
                docNumber: Ext.getCmp('txt_docNumber').getValue(),
                docName: Ext.getCmp('txt_docName').getValue(),
                //containerName: Ext.getCmp('txt_containerName').getValue(),
                state: Ext.getCmp('txt_state').getValue(),
                creator: Ext.getCmp('txt_creator').getValue(),
                docType: Ext.getCmp('docTypeStoreCombo').getValue(),
                containerName: Ext.getCmp('projectDocProcessCombo').getValue(),
                startDate: Ext.util.Format.date(Ext.getCmp('startDate').getValue(), 'Y-m-d'),
                endDate: Ext.util.Format.date(Ext.getCmp('endDate').getValue(), 'Y-m-d')
            };
            Ext.apply(projectDocStore.proxy.extraParams, data);
        });
        // create the Data Grid
        var projectDocGrid = Ext.create('Ext.grid.Panel', {
            store: projectDocStore,
            //forceFit : true,
            autoWidth: true,
            autoScroll: true,
            title: '文档流程信息',
            height: 250,
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {enableTextSelection: true, forceFit: false},
            selModel: Ext.create('Ext.selection.CheckboxModel',
                {
                    mode: "SIMPLE",
                    showHeaderCheckbox: true,
                    listeners: {
                        select: function (model, record, index) {
                            /*var record = projectDocGrid.getStore().getAt(index);
                            var data = record.data.detailInfoBoList;
                            //var data = obj['data'];
                            detailsStore.removeAll();
                            detailsStore.add(data);
                            detailsGrid.reconfigure(detailsStore,detailsColumn);*/
                            var tmpGrid = Ext.getCmp('projectDocGrid');

                           /* var myMask = new Ext.LoadMask( {msg: "数据正在处理中，请稍后...", target: tmpGrid});
                            myMask.show();
                            var myMask = new Ext.LoadMask(document.body, {
                                msg:'正在处理数据，请稍候......',
                                removeMask:true // 完成后移除
                            });
                            myMask.show() ;*/
                            Ext.Ajax.request({
                                scope: this,
                                url: '/Windchill/ptc1/docProcess/getDocProcessDetailInfo?processOid=' + record.get('processOid'),
                                success: function (response, opts) {
                                     var obj = Ext.decode(response.responseText);
                                     debugger
                                    var data = obj['data'];
                                    detailsStore.removeAll();
                                    detailsStore.add(data);
                                    detailsGrid.reconfigure(detailsStore, detailsColumn);
                                },
                                failure: function (response, opts) {
                                    //myMask.hide() ;
                                    alert("查询流程信息失败，请检查网络");
                                }
                            });

                        }
                    }
                }),
            columns: [
                {text: 'ID', dataIndex: 'id', hidden: true},
                {text: '项目ID', dataIndex: 'projectId', hidden: true},
                //{text: '序号', dataIndex: 'rowId', align: 'center', width: 40, xtype: 'rownumberer'},
                {text: '上下文', dataIndex: 'containerName', width: 200},
                {text: '文档编号', dataIndex: 'docNumber', width: 100},
                {text: '文档名称', dataIndex: 'link', width: 200},
                {text: '工作流名称', dataIndex: 'processName', width: 200},
                {text: 'processOid', dataIndex: 'processOid', hidden: true},
                {text: '状态', dataIndex: 'state'},
                {text: '创建人', dataIndex: 'creator'},
                //{text: '当前节点', dataIndex: 'currentNode'},
                //{text: '当前负责人', dataIndex: 'currentResponsibleUser'},
                {text: '流程开始时间', dataIndex: 'processStartTime', width: 160},
                {text: '流程结束时间', dataIndex: 'processEndTime', width: 160},
                {text: '驳回次数', dataIndex: 'rejectionCount'},
                {text: '评审周期（天）', dataIndex: 'auditCycle',width:100},
                {text: '文档类型', dataIndex: 'docType', width: 160}
            ],
            tbar: [
            //     {
            //     text: '导出选中行',
            //     iconCls: 'icon icon-download',
            //     handler: function () {
            //         /*exportSelect(projectDocGrid);
            //         return;*/
            //         let selectionArr = projectDocGrid.getSelectionModel().getSelection();
            //         if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
            //             Ext.Msg.alert("提示", "请选择要导出的数据");
            //             return;
            //         }
            //         var loadMarsk = new Ext.LoadMask(projectDocGrid, {
            //             msg: '正在处理数据，请稍候......',
            //             removeMask: true // 完成后移除
            //         });
            //         loadMarsk.show();
            //
            //         //数据组装
            //         let obj = new Array();
            //         Ext.each(selectionArr, function (record) {
            //             obj.push(record.data['id'])
            //         });
            //
            //         Ext.Ajax.request({
            //             scope: this,
            //             timeout: 600000,
            //             url: '/Windchill/ptc1/docProcess/exportSelectProcessInfo?projectId=' + projectId,
            //             params: {
            //                 data: Ext.encode(obj)
            //             },
            //             success: function (response, opts) {
            //                 var obj = Ext.decode(response.responseText);
            //                 var path = obj['path'];
            //                 if (path == null || path == '') {
            //                     alert("没有数据");
            //                 } else {
            //                     window.open(path);
            //                 }
            //                 loadMarsk.hide();
            //             },
            //             failure: function (response, opts) {
            //                 loadMarsk.hide();
            //                 alert("导出流程信息失败，请检查网络");
            //
            //             }
            //         });
            //
            //     }
            // },{
            //     text: '导出全部行',
            //     iconCls: 'icon icon-download',
            //     handler: function () {
            //         /*exportAll(projectDocGrid);
            //         return;*/
            //         var loadMarsk = new Ext.LoadMask(projectDocGrid, {
            //             msg: '正在处理数据，请稍候......',
            //             removeMask: true // 完成后移除
            //         });
            //         loadMarsk.show();
            //         var createDate_start = "";
            //         var createDate_end = "";
            //         var d1, d2;
            //         if (Ext.getCmp('startDate').getValue() != null && Ext.getCmp('endDate').getValue() != null) {
            //             d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));
            //             d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));
            //             if (d1 >= d2) {
            //                 alert("开始时间不能大于结束时间！");
            //                 return;
            //             }
            //         }
            //         var store = Ext.getStore('projectDocStore');
            //         var data = {
            //             docNumber: Ext.getCmp('txt_docNumber').getValue(),
            //             docName: Ext.getCmp('txt_docName').getValue(),
            //             //containerName: Ext.getCmp('txt_containerName').getValue(),
            //             state: Ext.getCmp('txt_state').getValue(),
            //             creator: Ext.getCmp('txt_creator').getValue(),
            //             docType: Ext.getCmp('docTypeStoreCombo').getValue(),
            //             containerName: Ext.getCmp('projectDocProcessCombo').getValue(),
            //             startDate: Ext.util.Format.date(Ext.getCmp('startDate').getValue(), 'Y-m-d'),
            //             endDate: Ext.util.Format.date(Ext.getCmp('endDate').getValue(), 'Y-m-d'),
            //             limit: store.getTotalCount(),
            //             start: 0,
            //         };
            //
            //         var tempRec = {
            //
            //         };
            //         Ext.Ajax.request({
            //             scope: this,
            //             timeout: 600000,
            //             url: '/Windchill/ptc1/docProcess/exportOneProcessInfo?projectId=' + projectId,
            //             params: {
            //                 data: Ext.encode(data)
            //             },
            //             success: function (response, opts) {
            //                 var obj = Ext.decode(response.responseText);
            //                 var path = obj['path'];
            //                 if (path == null || path == '') {
            //                     alert("没有数据");
            //                 } else {
            //                     window.open(path);
            //                 }
            //                 loadMarsk.hide();
            //             },
            //             failure: function (response, opts) {
            //                 loadMarsk.hide();
            //                 alert("导出流程信息失败，请检查网络");
            //
            //             }
            //         });
            //     }
            // },
            ],
            bbar: Ext.create('Ext.PagingToolbar', {
                id: 'pagingTool',
                store: projectDocStore,
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空"
            }),//~End bbar
            scope: this

        });


//---------------------   Itimes   --------------------------//		
        this.items = [{
            xtype: 'fieldset',
            margin: '5 3 10 3',
            title: '<font style="font-size:12px">查询参数</font>',
            collapsible: true,
            defaults: {
                labelWidth: 100,
                border: false,
                anchor: '98%',
                layout: {
                    type: 'hbox'
                }
            },
            items: [{
                xtype: 'panel',
                defaults: {margin: '5 20 0 0', labelWidth: 70},
                items: [projectDocProcessCombo, {
                    xtype: 'textfield',
                    fieldLabel: '文档编号',
                    name: 'txt_docNumber',
                    id: 'txt_docNumber',
                    width: 200,
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doSearch();
                            }
                        }
                    }
                }, userCombo/*{
                    xtype: 'textfield',
                    fieldLabel: '创建人',
                    name: 'txt_creator',
                    id: 'txt_creator',
                    width: 200,
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doSearch();
                            }
                        }
                    }
                }*/,
                    /*{
                    xtype: 'textfield',
                    fieldLabel: '状态',
                    name: 'txt_state',
                    id: 'txt_state',
                    width: 200,
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doSearch();
                            }
                        }
                    }
                }*/stateCombo, docTypeStoreCombo]
            }, {
                xtype: 'panel',
                defaults: {margin: '5 20 0 0', labelWidth: 70},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '文档名称',
                    name: 'txt_docName',
                    id: 'txt_docName',
                    width: 200,
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doSearch();
                            }
                        }
                    }
                },startTime,
                    endTime, ]
            }, /*{
                xtype: 'panel',
                defaults: {margin: '5 45 20 70', labelWidth: 70},
                items: [startTime,
                    endTime, ]
            },*/ {
                xtype: 'panel',
                items: [{
                    xtype: 'button',
                    margin: '10 0 10 0',
                    width: 70,
                    text: '查询',
                    scope: this,
                    iconCls: 'icon icon-search',
                    handler: function () {
                        this.doSearch();
                        var pagingbar = Ext.getCmp('pagingTool');
                        pagingbar.moveFirst();
                    }
                }]
            }]
        },
            projectDocGrid,
            detailsGrid
        ];
        this.callParent();
    },//~End of initComponent
    listeners: {
        'afterrender': function () {
        }
    },

//---------------------Function area----------------------------//
    /**
     * 按查询参数查询
     */
    doSearch: function () {
        var createDate_start = "";
        var createDate_end = "";
        var d1, d2;
        if (Ext.getCmp('startDate').getValue() != null && Ext.getCmp('endDate').getValue() != null) {
            d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));
            d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));
            if (d1 >= d2) {
                alert("开始时间不能大于结束时间！");
                return;
            }
        }
        var store = Ext.getStore('projectDocStore');

        var data = {
            docNumber: Ext.getCmp('txt_docNumber').getValue(),
            docName: Ext.getCmp('txt_docName').getValue(),
            //containerName: Ext.getCmp('txt_containerName').getValue(),
            state: Ext.getCmp('txt_state').getValue(),
            creator: Ext.getCmp('txt_creator').getValue(),
            docType: Ext.getCmp('docTypeStoreCombo').getValue(),
            containerName: Ext.getCmp('projectDocProcessCombo').getValue(),
            startDate: Ext.util.Format.date(Ext.getCmp('startDate').getValue(), 'Y-m-d'),
            endDate: Ext.util.Format.date(Ext.getCmp('endDate').getValue(), 'Y-m-d')
        };
        store.reload({
            params: {
                data: Ext.encode(data)
            },
            callback: function (records, operation, success) {
                if (!success) {
                    alert('查询数据审核流程信息失败，请联系管理员！');
                }
            }
        });
    }



});

function exportAll(projectDocGrid) {

    var loadMarsk = new Ext.LoadMask(projectDocGrid, {
        msg: '正在处理数据，请稍候......',
        removeMask: true // 完成后移除
    });
    loadMarsk.show();
    var createDate_start = "";
    var createDate_end = "";
    var d1, d2;
    if (Ext.getCmp('startDate').getValue() != null && Ext.getCmp('endDate').getValue() != null) {
        d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));
        d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));
        if (d1 >= d2) {
            alert("开始时间不能大于结束时间！");
            return;
        }
    }
    var data = {
        docNumber: Ext.getCmp('txt_docNumber').getValue(),
            docName: Ext.getCmp('txt_docName').getValue(),
            //containerName: Ext.getCmp('txt_containerName').getValue(),
            state: Ext.getCmp('txt_state').getValue(),
            creator: Ext.getCmp('txt_creator').getValue(),
            docType: Ext.getCmp('docTypeStoreCombo').getValue(),
            containerName: Ext.getCmp('projectDocProcessCombo').getValue(),
            startDate: Ext.util.Format.date(Ext.getCmp('startDate').getValue(), 'Y-m-d'),
            endDate: Ext.util.Format.date(Ext.getCmp('endDate').getValue(), 'Y-m-d')
    }

    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/docProcess/exportProcessInfo', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                loadMarsk.hide();
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "文档流程信息"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
            loadMarsk.hide();
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(data)
    );

}

function exportSelect(projectDocGrid) {
    let selectionArr = projectDocGrid.getSelectionModel().getSelection();
    if (selectionArr == undefined || selectionArr == null || selectionArr.length == 0) {
        Ext.Msg.alert("提示", "请选择要导出的数据");
        return;
    }
    var loadMarsk = new Ext.LoadMask(projectDocGrid, {
        msg: '正在处理数据，请稍候......',
        removeMask: true // 完成后移除
    });
    loadMarsk.show();

    //数据组装
    let obj = new Array();
    Ext.each(selectionArr, function (record) {
        obj.push(record.data['id'])
    });


    // 获取XMLHttpRequest
    var xmlResquest = new XMLHttpRequest();
    //  发起请求
    xmlResquest.open("POST", '/Windchill/ptc1/docProcess/exportSelProcessInfo', true);
    // 设置请求头类型
    xmlResquest.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8\n");
    xmlResquest.responseType = "blob";
    //  返回
    xmlResquest.onload = function (oEvent) {
        var content = xmlResquest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                loadMarsk.hide();
                alert(Ext.decode(res).error)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            elink.download = "文档流程信息"+timestamp+".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
            loadMarsk.hide();
        }

    };
    //data: {"userName":"","projectName":null,"departmentName":"","productLine":"","dateStart":"2021-08-29T00:00:00","dateEnd":"2021-09-13T20:18:07"}
    xmlResquest.send(
        "data=" + Ext.encode(obj)
    );

}
