Ext.define('Pnt.view.DataAuditAnalysisPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.DataAuditAnalysisPanel',
	border:false,
	title:'<font style="font-size:18px">数据变更流程统计表</font>',
	autoWidth:true,
	autoHeight:true,
	collapsible: false,
	id: 'dataAuditAnalysisPanel',
	fieldDefaults: {
		msgTarget: 'side',
		labelWidth: 75
	},
	initComponent:function(){
		//------------------------------嵌入的表单---------start----------------//
//Model for the inside grid store
		Ext.define('dataAuditReportModel', {
			extend: 'Ext.data.Model',
			fields: [
				'id', 'processNumber', 'processName', 'workName', 'workCharge', 'roleName', 'vote',
				'remark', 'workFinisher', 'workReceiveDate', 'startDate', 'finishDate', 'overDue', 'auditCycle','deadline','actualCycle'
			],
			idProperty: 'id'
		});
		// function displayInnerGrid(renderId, record) {



			//dummy data for the inside grid
			var dataAuditReportStore = Ext.create('Ext.data.Store', {
				//pageSize: 100,
				model: 'dataAuditReportModel',
				id:'dataAuditReportStore',
				pruneModifiedRecords: true,
				proxy: new Ext.data.HttpProxy({
					url: '/Windchill/ptc1/dataReport/getDataAuditReport',
					method:'GET',
					reader:{
						type:'json',
						root: 'items',
						totalProperty: 'totalCount',
						idProperty: 'id',
						messageProperty: 'msg'
					}
				}),
				autoLoad:false
			});

			var dataAuditReportGrid = Ext.create('Ext.grid.Panel', {
				title: '审核详情(当选中多条流程时，审核详情区域只显示最后选中流程的审核详情)',
				store:dataAuditReportStore,
				//forceFit : true,
				autoWidth : true,
				columnLines: true,
				autoScroll: true,
				height:250,
				selModel: {
					selType: 'cellmodel'
				},
				//frame: false,
				iconCls: 'icon-grid',
				//bodyStyle : 'overflow-x:hidden; overflow-y:scroll',
				viewConfig:{enableTextSelection:true},
				//selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SIMPLE",showHeaderCheckbox:true}),
				columns: [
					{xtype: 'rownumberer',width:40},
					{ text: 'ID',  dataIndex: 'id', menuDisabled:true,hidden:true},
					//{ text: '审核流程编号',  dataIndex: 'processNumber', menuDisabled:true},
					//{ text: '流程名称',  dataIndex: 'processName', menuDisabled:true },
					{ text: '任务名称',  dataIndex: 'workName', menuDisabled:true,width:250 },
					{ text: '工作负责人',  dataIndex: 'workCharge', menuDisabled:true },
					{ text: '角色',  dataIndex: 'roleName' ,menuDisabled:true,width:200},
					{ text: '投票',  dataIndex: 'vote',menuDisabled:true},
					{ text: '备注',  dataIndex: 'remark',menuDisabled:true},
					{ text: '完成者',  dataIndex: 'workFinisher',menuDisabled:true},
					{ text: '任务接收时间',  dataIndex: 'workReceiveDate' ,menuDisabled:true,width:160},
					{ text: '完成时间',  dataIndex: 'finishDate',menuDisabled:true,width:160,},
					{ text: '是否逾期',  dataIndex: 'overDue', menuDisabled:true , width: 120},
					{ text: '实际周期（天）',  dataIndex: 'actualCycle', menuDisabled:true , width: 120},
					{ text: '标准周期（天）',  dataIndex: 'deadline', menuDisabled:true , width: 120},
					{ text: '逾期周期（天）',  dataIndex: 'auditCycle',menuDisabled:true, width: 120,
						renderer:function(value,metaData,record,row,col,store){
							if(typeof(value) == 'string') {
								if(value.charAt(0) != "0") {
									var linkHtml = '<font color="red">'+value+'</font>';
									return linkHtml;
								} else {
									return value;
								}
							} else {
								if(value >= 1) {
									var linkHtml = '<font color="red">'+value+'</font>';
									return linkHtml;
								} else {
									return value;
								}
							}

						}}
				]
			});
		// }


		/*function destroyInnerGrid(record) {

			var parent = document.getElementById(record.get('processId'));
			var child = parent.firstChild;

			while (child) {
				child.parentNode.removeChild(child);
				child = child.nextSibling;
			}

		}*/

		//------------------------------嵌入的表单---------end----------------//

		//获取所有容器
		Ext.define('dataAuditAnalysisContainerModel', {
			extend: 'Ext.data.Model',
			fields : ['key','displayText'],
			idProperty: 'id'
		});
		var dataAuditAnalysisContainerStore =  new Ext.data.Store({
			storeId : 'dataAuditAnalysisContainerStore',
			model:'dataAuditAnalysisContainerModel',
			pruneModifiedRecords: true,
			proxy : new Ext.data.HttpProxy({
				url : '/Windchill/ptc1/dataReport/getAllContainer',
				method:'GET',
				reader : {
					type:'json',
					root: 'items',
					idProperty: 'id',
					messageProperty: 'msg'

				}
			}),
			autoLoad : true,
			listeners: {
			}
		});

		var dataAuditAnalysisContainerCombo = new Ext.form.ComboBox({
			typeAhead: true,
			fieldLabel: '上下文',
			store: dataAuditAnalysisContainerStore,
			triggerAction: 'all',
			name: 'dataAuditAnalysisContainerCombo',
			id: 'dataAuditAnalysisContainerCombo',
			editable:true,
			enableRegEx:true,
			allowBlank: false,
			lazyRender:true,
			repeatTriggerClick : true,
			queryMode: 'local',
			width:250,
			labelWidth:70,
			selectOnFocus:true,
			valueField: 'displayText',
			displayField: 'displayText'
		});

		//状态列表
		Ext.define('analysisStateModel', {
			extend: 'Ext.data.Model',
			fields: ['value', 'display'],
			idProperty: 'id'
		});
		var stateStore = new Ext.data.Store(
			{
				storeId: 'stateStore',
				model: 'analysisStateModel',
				pruneModifiedRecords: true,
				proxy: new Ext.data.HttpProxy(
					{
						url: '/Windchill/ptc1/docProcess/getState?type=promotionNotice',
						method: 'GET',
						reader: {
							type: 'json',
							root: 'data',
							idProperty: 'id',
							messageProperty: 'msg'
						}
					}),
				autoLoad: true,
			});
		var stateCombo = new Ext.form.ComboBox({
			typeAhead: true,
			fieldLabel: '状态',
			store: stateStore,
			triggerAction: 'all',
			name: 'report_processState',
			id: 'report_processState',
			editable: true,
			allowBlank: true,
			lazyRender: true,
			repeatTriggerClick: true,
			queryMode: 'local',
			width: 250,
			labelWidth: 100,
			selectOnFocus: true,
			forceSelection: true,
			valueField: 'display',
			displayField: 'display'
		});

		var workflowNameStore = new Ext.data.Store(
			{
				storeId: 'workflowNameStore',
				pruneModifiedRecords: true,
				proxy: new Ext.data.HttpProxy(
					{
						url: '/Windchill/ptc1/docProcess/getWorkflowName?type='+'PromotionNotice',
						method: 'GET',
						reader: {
							type: 'json',
							root: 'data',
							idProperty: 'id',
							messageProperty: 'msg'
						}
					}),
				autoLoad: true,
			});
		var workflowNameCombo = new Ext.form.ComboBox({
			typeAhead: true,
			fieldLabel: '工作流名称',
			store: workflowNameStore,
			triggerAction: 'all',
			name: 'report_processName',
			id: 'report_processName',
			editable: true,
			allowBlank: true,
			lazyRender: true,
			repeatTriggerClick: true,
			queryMode: 'local',
			width: 250,
			labelWidth: 100,
			selectOnFocus: true,
			forceSelection: true,
			valueField: 'WORKFLOWNAME',
			displayField: 'WORKFLOWNAME'
		});

		var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
			storeId: 'allUserStore_projectPlan'
		});

		var userCombo = new Ext.form.ComboBox({
			typeAhead: false,
			fieldLabel: '升级创建者',
			store: allUserStore_projectPlan,
			triggerAction: 'all',
			name: 'report_createUser',
			id: 'report_createUser',
			editable: true,
			allowBlank: true,
			lazyRender: true,
			repeatTriggerClick: true,
			queryMode: 'local',
			width: 250,
			labelWidth: 100,
			selectOnFocus: true,
			forceSelection: true,
			valueField: 'userFullName',
			displayField: 'userFullName'
		});



		Ext.define('dataAuditAnalysisModel', {
			extend: 'Ext.data.Model',
			fields: [
				'id', 'processId', 'processNumber', 'processName', 'workflowName', 'processCreator', 'processStartTime',
				'processFinishDate', 'rejectCount', 'auditCycle', 'state', 'containerName','link'
			],
			idProperty: 'id'
		});

		// create the Data Store
		var dataAuditAnalysisStore = Ext.create('Ext.data.Store', {
			pageSize: 2000,
			model: 'dataAuditAnalysisModel',
			id:'dataAuditAnalysisStore',
			pruneModifiedRecords: true,
			proxy: new Ext.data.HttpProxy({
				url: '/Windchill/ptc1/dataReport/getDataAuditAnalysis',
				timeout: 9000000,
				method:'GET',
				reader:{
					type:'json',
					root: 'data.resultData',
					totalProperty: 'data.total',
					idProperty: 'id',
					messageProperty: 'msg'
				}
			}),
			autoLoad:false
		});

		dataAuditAnalysisStore.on('beforeload', function(store, options) {
			var data = {
				processNumber:Ext.getCmp('report_processNumber').getValue(),
				workflowName:Ext.getCmp('report_processName').getValue(),
				state:Ext.getCmp('report_processState').getValue(),
				processCreator:Ext.getCmp('report_createUser').getValue(),
				containerName:Ext.getCmp('dataAuditAnalysisContainerCombo').getValue(),
				processStartTime:Ext.util.Format.date(Ext.getCmp('report_dateStart').getValue(), 'Y-m-d H:i:s'),
				processFinishDate:Ext.util.Format.date(Ext.getCmp('report_dateEnd').getValue(), 'Y-m-d H:i:s')
			};
			Ext.apply(dataAuditAnalysisStore.proxy.extraParams, data);
		});

		var dataAuditAnalysisGrid = Ext.create('Ext.grid.Panel', {
			//title: '数据变更流程统计表',
			store:dataAuditAnalysisStore,
			//forceFit : true,
			autoWidth : true,
			height:250,
			/* selModel: {
                 selType: 'cellmodel'
             }, */
			selModel: Ext.create('Ext.selection.CheckboxModel',
				{
					mode: "SIMPLE",
					showHeaderCheckbox: true,
					listeners: {
						select: function (model, record, index) {
							Ext.getStore('dataAuditReportStore').reload({
								params: {
									processId: record.get('processId')
								},
								callback: function (records, operation, success) {
									if (!success) {
										alert('查询审核详情失败，请联系管理员！');
									}
								}
							});
						}
					}
				}),
			collapsible: true,
			animCollapse: false,
			title: '数据审核流程统计表',
			//renderTo: Ext.getBody() ,
			columns: [
				{ text: 'ID',  dataIndex: 'id', menuDisabled:true,hidden:true},
				{ text: 'ID',  dataIndex: 'processId', menuDisabled:true,hidden:true},
				{ text: '升级流程编号',  dataIndex: 'processNumber',width:100, menuDisabled:true},
				{ text: '升级流程名称',  dataIndex: 'link', menuDisabled:true ,width:260},
				{ text: '工作流名称',  dataIndex: 'workflowName', menuDisabled:true ,width:260},
				{ text: '状态',  dataIndex: 'state', menuDisabled:true },
				{ text: '升级创建者',  dataIndex: 'processCreator', menuDisabled:true },
				{ text: '流程开始时间',  dataIndex: 'processStartTime' ,menuDisabled:true,width:160},
				{ text: '流程完成时间',  dataIndex: 'processFinishDate',menuDisabled:true,width:160,},
				{ text: '驳回次数',  dataIndex: 'rejectCount',menuDisabled:true},
				{ text: '数据评审周期（天）',  dataIndex: 'auditCycle',width:100,menuDisabled:true,
					renderer:function(value,metaData,record,row,col,store){
						if(typeof(value) == 'string') {
							if(value.charAt(0) != "0") {
								var linkHtml = '<font color="red">'+value+'</font>';
								return linkHtml;
							} else {
								return value;
							}
						} else {
							if(value >= 1) {
								var linkHtml = '<font color="red">'+value+'</font>';
								return linkHtml;
							} else {
								return value;
							}
						}

					}},
				{ text: '上下文',  dataIndex: 'containerName',menuDisabled:true,width:160}
			],
			tbar: [
			// {
			// 	text : '导出选中行',
			// 	iconCls: 'icon icon-download',
			// 	handler : function() {
			// 		this.doExportAuditData(dataAuditAnalysisGrid);
			// 	},
			// 	scope : this
			// }, {
			// 	text : '导出全部行',
			// 	iconCls: 'icon icon-download',
			// 	handler : function() {
			// 		var createDate_start = "";
			// 		var createDate_end = "";
			// 		var d1,d2;
			// 		if(Ext.getCmp('report_dateStart').getValue() != null) {
			// 			createDate_start = Ext.getCmp('report_dateStart').getValue().toString();
			// 		}
			// 		if(Ext.getCmp('report_dateEnd').getValue() != null) {
			// 			createDate_end = Ext.getCmp('report_dateEnd').getValue().toString();
			// 		}
			// 		if(Ext.getCmp('report_dateStart').getValue() != null && Ext.getCmp('report_dateEnd').getValue() != null) {
			// 			d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));
			// 			d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));
			// 			if(d1 >=d2) {
			// 				alert("开始时间不能大于结束时间！");
			// 				return ;
			// 			}
			// 		}
			//
			// 		var processNumber = Ext.getCmp('report_processNumber').getValue();
			// 		var workflowName = Ext.getCmp('report_processName').getValue();
			// 		var processState = Ext.getCmp('report_processState').getValue();
			// 		var createUser = Ext.getCmp('report_createUser').getValue();
			// 		var containerName = Ext.getCmp('dataAuditAnalysisContainerCombo').getValue();
			// 		createDate_start = Ext.getCmp('report_dateStart').getValue();
			// 		createDate_end = Ext.getCmp('report_dateEnd').getValue();
			// 		var	startDate = "";
			// 		var	endDate = "";
			// 		if(createDate_start != null) {
			// 			startDate = Ext.Date.format(new Date(createDate_start),'Y-m-d');
			// 		}
			// 		if(createDate_end != null) {
			// 			endDate = Ext.Date.format(new Date(createDate_end),'Y-m-d');
			// 		}
			// 		var loadMarsk = new Ext.LoadMask(dataAuditAnalysisGrid, {
			// 			msg: '正在处理数据，请稍候......',
			// 			removeMask: true // 完成后移除
			// 		});
			// 		loadMarsk.show();
			//
			// 		window.location.href="exportAllAuditAnalysis.jsp?processNumber=" + processNumber + "&workflowName=" + workflowName +
			// 			"&processState=" + processState + "&processCreator=" + createUser + "&containerName=" + containerName;
			// 		+ "&processStartTime=" + startDate + "&processFinishDate=" + endDate;
			// 		loadMarsk.hide();
			// 	},
			// 	scope : this
			// }
			],
			bbar: Ext.create('Ext.PagingToolbar', {
				//pageSize: 2,
				store: dataAuditAnalysisStore,
				displayInfo: true,
				displayMsg: '当前显示 {0} - {1} ，共 {2}',
				emptyMsg: "查询结果为空"
			})//~End bbar
		});

		/*dataAuditAnalysisGrid.view.on('expandBody', function (rowNode, record, expandRow, eOpts) {
			displayInnerGrid(record.get('processId'), record);
		});

		dataAuditAnalysisGrid.view.on('collapsebody', function (rowNode, record, expandRow, eOpts) {
			destroyInnerGrid(record);
		});

		dataAuditAnalysisGrid.render(Ext.getBody());*/
		/*dataAuditAnalysisGrid.setHeight(window.innerHeight);
        dataAuditAnalysisGrid.setWidth(window.innerWidth);  
        Ext.EventManager.onWindowResize(function () {  
            dataAuditAnalysisGrid.setHeight(window.innerHeight);  
            dataAuditAnalysisGrid.setWidth(window.innerWidth);  
        });  */


/////////////////////////Panel items//////////////////////////////////
		this.items=[{
			xtype: 'fieldset',
			margin:'5 3 10 3',
			title: '<font style="font-size:12px">查询参数</font>',
			collapsible: true,
			defaults: {
				labelWidth: 100,
				border:false,
				anchor: '99%',
				layout: {
					type: 'hbox'
				}
			},
			items:[{
				xtype: 'panel',
				defaults:{ margin:'5 20 0 0',labelWidth:70},
				items:[{xtype:'textfield',
					fieldLabel: '升级编号',
					name: 'report_processNumber',
					id: 'report_processNumber',
					width:250,
					enableKeyEvents:true,
					listeners:{
						scope:this,
						'specialkey':function(field,e)
						{
							if(e.getKey() == Ext.EventObject.ENTER)
							{
								this.doSearch();
							}
						}
					}
				},workflowNameCombo/* {xtype:'textfield',
					fieldLabel: '工作流名称',
					name: 'report_processName',
					id: 'report_processName',
					width:250,
					enableKeyEvents:true,
					listeners:{
						scope:this,
						'specialkey':function(field,e)
						{
							if(e.getKey() == Ext.EventObject.ENTER)
							{
								this.doSearch();
							}
						}
					}
				}*/,userCombo
					/*,{xtype:'textfield',
					fieldLabel: '升级创建者',
					name: 'report_createUser',
					id: 'report_createUser',
					width:250,
					enableKeyEvents:true,
					listeners:{
						scope:this,
						'specialkey':function(field,e)
						{
							if(e.getKey() == Ext.EventObject.ENTER)
							{
								this.doSearch();
							}
						}
					}
				}*/,stateCombo,
					/*{xtype:'textfield',
						fieldLabel: '状态',
						name: 'report_processState',
						id: 'report_processState',
						width:250,
						enableKeyEvents:true,
						listeners:{
							scope:this,
							'specialkey':function(field,e)
							{
								if(e.getKey() == Ext.EventObject.ENTER)
								{
									this.doSearch();
								}
							}
						}
					}*/]
			}
			/*,{
				xtype: 'panel',
				defaults:{ margin:'5 20 0 0',labelWidth:70},
				items:[
					{xtype:'textfield',
					fieldLabel: '升级创建者',
					name: 'report_createUser',
					id: 'report_createUser',
					width:250,
					enableKeyEvents:true,
					listeners:{
						scope:this,
						'specialkey':function(field,e)
						{
							if(e.getKey() == Ext.EventObject.ENTER)
							{
								this.doSearch();
							}
						}
					}
				},
					{xtype:'textfield',
					fieldLabel: '状态',
					name: 'report_processState',
					id: 'report_processState',
					width:250,
					enableKeyEvents:true,
					listeners:{
						scope:this,
						'specialkey':function(field,e)
						{
							if(e.getKey() == Ext.EventObject.ENTER)
							{
								this.doSearch();
							}
						}
					}
				}]
			}*/
				,{
				xtype: 'panel',
				defaults:{ margin:'5 20 0 0',labelWidth:70},
				items:[dataAuditAnalysisContainerCombo,{
					xtype:'datefield',
					//border:false,
					labelWidth:70,
					width:250,
					fieldLabel:'开始日期从:',
					format:'Y-m-d',
					id:'report_dateStart',
					name:'report_dateStart',
					listeners:{
						scope:this,
						'specialkey':function(field,e)
						{
							if(e.getKey() == Ext.EventObject.ENTER)
							{
								this.doLaborCostSearch();
							}
						}
					}
				},
					{
						xtype:'datefield',
						//border:false,
						labelWidth:70,
						width:250,
						fieldLabel:'&nbsp;&nbsp;&nbsp;&nbsp;到:',
						format:'Y-m-d',
						id:'report_dateEnd',
						name:'report_dateEnd',
						listeners:{
							scope:this,
							'specialkey':function(field,e)
							{
								if(e.getKey() == Ext.EventObject.ENTER)
								{
									this.doLaborCostSearch();
								}
							}
						}
					}]
			},
				/*{xtype: 'panel',
				defaults:{ margin:'5 20 0 0',labelWidth:70},
				items:[
					{
					xtype:'datefield',
					//border:false,
					labelWidth:70,
					width:250,
					fieldLabel:'开始日期从:',
					format:'Y-m-d',
					id:'report_dateStart',
					name:'report_dateStart',
					listeners:{
						scope:this,
						'specialkey':function(field,e)
						{
							if(e.getKey() == Ext.EventObject.ENTER)
							{
								this.doLaborCostSearch();
							}
						}
					}
				},
					{
					xtype:'datefield',
					//border:false,
					labelWidth:70,
					width:250,
					fieldLabel:'&nbsp;&nbsp;&nbsp;&nbsp;到:',
					format:'Y-m-d',
					id:'report_dateEnd',
					name:'report_dateEnd',
					listeners:{
						scope:this,
						'specialkey':function(field,e)
						{
							if(e.getKey() == Ext.EventObject.ENTER)
							{
								this.doLaborCostSearch();
							}
						}
					}
				}]
			},*/{
				xtype:'panel',
				items:[{
					xtype:'button',
					margin:'10 0 10 0',
					width:70,
					text: '查询',
					scope:this,
					iconCls: 'icon icon-search',
					handler: function() {
						this.doSearch();
					}
				}]
			}
			]
		},
			dataAuditAnalysisGrid,dataAuditReportGrid
		];

		this.callParent();
	},//~End of initComponent

	listeners:{
		'afterrender':function(){}
	},

////////////////////////Function area//////////////////////////
	doExportAuditData: function(grid) {
		if(grid.getSelectionModel().getSelection().length <= 0) {
			alert('下载之前，请先选中行！');
			return;
		}
		var loadMarsk = new Ext.LoadMask(grid, {
			msg: '正在处理数据，请稍候......',
			removeMask: true // 完成后移除
		});
		loadMarsk.show();
		var orgRec; // 临时记录
		var exportRecords = new Array();// 修改记录
		var selectRecordsOrg = grid.getSelectionModel().getSelection(); //获取选中列
		for(var i=0, l= selectRecordsOrg.length; i<l; i++){
			orgRec = selectRecordsOrg[i].data;
			var tempRec = {
				'processId' : orgRec.processId,
				'0-升级流程编号' : orgRec.processNumber,
				'1-升级流程名称': orgRec.processName,
				'2-工作流名称' : orgRec.workflowName,
				'3-状态' : orgRec.state,
				'4-流程创建者': orgRec.processCreator,
				'5-流程开始时间': orgRec.processStartTime,
				'6-流程完成时间': orgRec.processFinishDate,
				'7-驳回次数': orgRec.rejectCount,
				'8-数据评审周期': orgRec.auditCycle,
				'9-上下文': orgRec.containerName
				//'': orgRec.projectTeam,

			};
			exportRecords[exportRecords.length] = tempRec;
		}
		Ext.Ajax.request({
			url: '/Windchill/ptc1/dataReport/exportSelectAuditAnalysisData',
			params:{
				exportRecords:Ext.encode(exportRecords)
			},
			success: function(response, opts) {
				window.location.href='exportAuditAnalysisData.jsp';
				loadMarsk.hide();
			},
			failure: function(response, opts) {
				alert('错误：导出失败，请检查网络！');
			}
		});//~End of request

	},

	/**
	 * 按查询参数查询
	 */
	doSearch: function(){

		var createDate_start = "";
		var createDate_end = "";
		var d1,d2;
		if(Ext.getCmp('report_dateStart').getValue() != null) {
			createDate_start = Ext.getCmp('report_dateStart').getValue().toString();
		}
		if(Ext.getCmp('report_dateEnd').getValue() != null) {
			createDate_end = Ext.getCmp('report_dateEnd').getValue().toString();
		}
		if(Ext.getCmp('report_dateStart').getValue() != null && Ext.getCmp('report_dateEnd').getValue() != null) {
			d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));
			d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));
			if(d1 >=d2) {
				alert("开始时间不能大于结束时间！");
				return ;
			}
		}

		var data = {
			processNumber:Ext.getCmp('report_processNumber').getValue(),
			workflowName:Ext.getCmp('report_processName').getValue(),
			state:Ext.getCmp('report_processState').getValue(),
			processCreator:Ext.getCmp('report_createUser').getValue(),
			containerName:Ext.getCmp('dataAuditAnalysisContainerCombo').getValue(),
			createDateStart:Ext.getCmp('report_dateStart').getValue(),
			createDateEnd:Ext.getCmp('report_dateEnd').getValue()
		};
		Ext.getStore('dataAuditAnalysisStore').reload({
			params:{
				data:data
			},
			callback: function(records, operation, success) {
				if(!success){
					alert('查询数据审核流程信息失败，请联系管理员！');
				}
			}
		});
	}

});

