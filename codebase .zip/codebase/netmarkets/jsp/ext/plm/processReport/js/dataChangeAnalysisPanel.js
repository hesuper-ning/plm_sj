Ext.define('Pnt.view.DataChangeAnalysisPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.DataChangeAnalysisPanel',
    border: false,
    title: '<font style="font-size:18px">数据变更流程统计表</font>',
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'dataChangeAnalysisPanel',
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {

        /*Ext.define('dataChangeAnalysisUserModel', {
            extend: 'Ext.data.Model',
            fields : ['parentId','id','key','displayText'],

            idProperty: 'id'
        });
        var dataChangeAnalysisUserStore =  new Ext.data.Store({
            storeId : 'dataChangeAnalysisUserStore',
            model:'dataChangeAnalysisUserModel',
            pruneModifiedRecords: true,
            proxy : new Ext.data.HttpProxy({
                url : '/Windchill/ptc1/dataReport/getAllState',
                method:'GET',
                reader : {
                    type:'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'msg'

                }
            }),
            autoLoad : true,
             listeners: {
             }
        });

        var dataChangeAnalysisUserCombo = new Ext.form.ComboBox({
            typeAhead: true,
            store: dataChangeAnalysisUserStore,
            triggerAction: 'all',
            fieldLabel: '状态',
            name: 'dataChangeAnalysisUserCombo',
            id: 'dataChangeAnalysisUserCombo',
            editable:false,
            allowBlank: false,
            lazyRender:true,
            repeatTriggerClick : true,
            queryMode: 'local',
            width:250,
            selectOnFocus:true,
            valueField: 'key',
            displayField: 'displayText'
        });
        */

        //------------------------------嵌入的表单---------start----------------//
        //Model for the inside grid store
        Ext.define('dataChangeReportModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'processNumber', 'processName', 'workName', 'workCharge', 'roleName', 'vote',
                'remark', 'workFinisher', 'workReceiveDate', 'startDate', 'finishDate', 'overDue', 'auditCycle','deadline','actualCycle'
            ],
            idProperty: 'id'
        });


        //dummy data for the inside grid
        var dataChangeReportStore = Ext.create('Ext.data.Store', {
            //pageSize: 100,
            model: 'dataChangeReportModel',
            id: 'dataChangeReportStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/dataReport/getDataChangeReport',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    totalProperty: 'totalCount',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });

        var dataChangeReportGrid = Ext.create('Ext.grid.Panel', {
            title: '审核详情(当选中多条流程时，审核详情区域只显示最后选中流程的审核详情)',
            store: dataChangeReportStore,
           // forceFit: true,
            autoWidth: true,
            columnLines: true,
            height:250,
            autoScroll: true,
            selModel: {
                selType: 'cellmodel'
            },
            frame: false,
            iconCls: 'icon-grid',
            //bodyStyle : 'overflow-x:hidden; overflow-y:scroll',
            viewConfig: {enableTextSelection: true},
            //selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SINGLE",showHeaderCheckbox:true}),
            columns: [
                {xtype: 'rownumberer',width:40},
                //{ text: 'ID',  dataIndex: 'id', menuDisabled:true,hidden:true},
                //{ text: '审核流程编号',  dataIndex: 'processNumber', menuDisabled:true},
                //{ text: '流程名称',  dataIndex: 'processName', menuDisabled:true },
                {text: '任务名称', dataIndex: 'workName', menuDisabled: true,width:250},
                {text: '工作负责人', dataIndex: 'workCharge', menuDisabled: true},
                {text: '角色', dataIndex: 'roleName', menuDisabled: true,width:200},
                {text: '投票', dataIndex: 'vote', menuDisabled: true},
                {text: '备注', dataIndex: 'remark', menuDisabled: true},
                {text: '完成者', dataIndex: 'workFinisher', menuDisabled: true},
                //{ text: '创建时间',  dataIndex: 'startDate',menuDisabled:true},
                {text: '任务接收时间', dataIndex: 'workReceiveDate', menuDisabled: true,width:160},
                {
                    text: '完成时间', dataIndex: 'finishDate', menuDisabled: true,width:160,
                },
                {text: '是否逾期', dataIndex: 'overDue', menuDisabled: true, width: 120},
                { text: '实际周期（天）',  dataIndex: 'actualCycle', menuDisabled:true , width: 120},
                { text: '标准周期（天）',  dataIndex: 'deadline', menuDisabled:true , width: 120},
                {
                    text: '逾期周期（天）', dataIndex: 'auditCycle', width: 120, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (typeof (value) == 'string') {
                            if (value.charAt(0) != "0") {
                                var linkHtml = '<font color="red">' + value + '</font>';
                                return linkHtml;
                            } else {
                                return value;
                            }
                        } else {
                            if (value >= 1) {
                                var linkHtml = '<font color="red">' + value + '</font>';
                                return linkHtml;
                            } else {
                                return value;
                            }
                        }

                    }
                }
            ]
            /*bbar: Ext.create('Ext.PagingToolbar', {
                //pageSize: 2,
                store: dataChangeReportStore,
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空"
            })//~End bbar
            */
        });

        /*  dataChangeReportGrid.getEl().swallowEvent([
                      'mousedown', 'mouseup', 'click',
                      'contextmenu', 'mouseover', 'mouseout',
                      'dblclick', 'mousemove'
                  ]); */


        //------------------------------嵌入的表单---------end----------------//

        //获取所有容器
        Ext.define('dataChangeAnalysisContainerModel', {
            extend: 'Ext.data.Model',
            fields: ['key', 'displayText'],
            idProperty: 'id'
        });
        var dataChangeAnalysisContainerStore = new Ext.data.Store({
            storeId: 'dataChangeAnalysisContainerStore',
            model: 'dataChangeAnalysisContainerModel',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/dataReport/getAllContainer',
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'items',
                    idProperty: 'id',
                    messageProperty: 'msg'

                }
            }),
            autoLoad: true,
            listeners: {}
        });
        //状态列表
        Ext.define('changeStateModel', {
            extend: 'Ext.data.Model',
            fields: ['value', 'display'],
            idProperty: 'id'
        });
        var stateStore = new Ext.data.Store(
            {
                storeId: 'stateStore',
                model: 'changeStateModel',
                pruneModifiedRecords: true,
                proxy: new Ext.data.HttpProxy(
                    {
                        url: '/Windchill/ptc1/docProcess/getState?type=change',
                        method: 'GET',
                        reader: {
                            type: 'json',
                            root: 'data',
                            idProperty: 'id',
                            messageProperty: 'msg'
                        }
                    }),
                autoLoad: true,
            });


        var dataChangeAnalysisContainerCombo = new Ext.form.ComboBox({
            typeAhead: true,
            fieldLabel: '上下文',
            store: dataChangeAnalysisContainerStore,
            triggerAction: 'all',
            name: 'dataChangeAnalysisContainerCombo',
            id: 'dataChangeAnalysisContainerCombo',
            editable: true,
            allowBlank: false,
            lazyRender: true,
            enableRegEx:true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 250,
            labelWidth: 70,
            selectOnFocus: true,
            valueField: 'displayText',
            displayField: 'displayText'
        });

        var stateCombo = new Ext.form.ComboBox({
            typeAhead: true,
            fieldLabel: '状态',
            store: stateStore,
            triggerAction: 'all',
            name: 'analysis_processState',
            id: 'analysis_processState',
            editable: true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 250,
            labelWidth: 100,
            selectOnFocus: true,
            forceSelection: true,
            valueField: 'display',
            displayField: 'display'
        });

        var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });

        var userCombo = new Ext.form.ComboBox({
            typeAhead: false,
            fieldLabel: '变更创建者',
            store: allUserStore_projectPlan,
            triggerAction: 'all',
            name: 'analysis_createUser',
            id: 'analysis_createUser',
            editable: true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 250,
            labelWidth: 100,
            selectOnFocus: true,
            forceSelection: true,
            valueField: 'userFullName',
            displayField: 'userFullName'
        });

        var workflowNameStore = new Ext.data.Store(
            {
                storeId: 'workflowNameStore',
                pruneModifiedRecords: true,
                proxy: new Ext.data.HttpProxy(
                    {
                        url: '/Windchill/ptc1/docProcess/getWorkflowName?type='+'change',
                        method: 'GET',
                        reader: {
                            type: 'json',
                            root: 'data',
                            idProperty: 'id',
                            messageProperty: 'msg'
                        }
                    }),
                autoLoad: true,
            });
        var workflowNameCombo = new Ext.form.ComboBox({
            typeAhead: true,
            fieldLabel: '工作流名称',
            store: workflowNameStore,
            triggerAction: 'all',
            name: 'analysis_processName',
            id: 'analysis_processName',
            editable: true,
            allowBlank: true,
            lazyRender: true,
            repeatTriggerClick: true,
            queryMode: 'local',
            width: 250,
            labelWidth: 100,
            selectOnFocus: true,
            forceSelection: true,
            valueField: 'workflowName',
            displayField: 'workflowName'
        });


        Ext.define('dataChangeAnalysisModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id', 'processId', 'processNumber', 'processName', 'workflowName', 'processCreator', 'processStartTime',
                'processFinishDate', 'rejectCount', 'auditCycle', 'state', 'containerName','link'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        var dataChangeAnalysisStore = Ext.create('Ext.data.Store', {
            pageSize: 1500,
            model: 'dataChangeAnalysisModel',
            id: 'dataChangeAnalysisStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/dataReport/getDataChangeAnalysis',
                timeout: 9000000,
                method: 'GET',
                reader: {
                    type: 'json',
                    root: 'data.resultData',
                    totalProperty: 'data.total',
                    idProperty: 'processId',
                    messageProperty: 'msg'
                }
            }),
            autoLoad: false
        });

        dataChangeAnalysisStore.on('beforeload', function (store, options) {
            var data = {
                processNumber: Ext.getCmp('analysis_processNumber').getValue(),
                workflowName: Ext.getCmp('analysis_processName').getValue(),
                state: Ext.getCmp('analysis_processState').getValue(),
                processCreator: Ext.getCmp('analysis_createUser').getValue(),
                containerName: Ext.getCmp('dataChangeAnalysisContainerCombo').getValue(),
                processStartTime: Ext.util.Format.date(Ext.getCmp('analysis_dateStart').getValue(), 'Y-m-d H:i:s'),
                processFinishDate: Ext.util.Format.date(Ext.getCmp('analysis_dateEnd').getValue(), 'Y-m-d H:i:s')
            };
            Ext.apply(dataChangeAnalysisStore.proxy.extraParams, data);
        });

        var dataChangeAnalysisGrid = Ext.create('Ext.grid.Panel', {
            //title: '数据变更流程统计表',
            store: dataChangeAnalysisStore,
            /*
            height:350,
            bodyStyle : 'overflow-x:hidden; overflow-y:scroll',
            viewConfig:{enableTextSelection:true},
            selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SINGLE",showHeaderCheckbox:true}),*/
            //autoWidth: true,
            //forceFit: true,
            autoWidth: true,
            height: 250,
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {enableTextSelection: true, forceFit: false},
            selModel: Ext.create('Ext.selection.CheckboxModel',
                {
                    mode: "SIMPLE",
                    showHeaderCheckbox: true,
                    listeners: {
                        select: function (model, record, index) {
                            Ext.getStore('dataChangeReportStore').reload({
                                params: {
                                    processId: record.get('processId')
                                },
                                callback: function (records, operation, success) {
                                    if (!success) {
                                        alert('查询审核详情失败，请联系管理员！');
                                    }
                                }
                            });
                        }
                    }
                }),
            //autoScroll: true,
            collapsible: true,
            animCollapse: false,
            title: '数据变更流程统计表',
            //iconCls: 'icon-grid',
            //renderTo: Ext.getBody()  ,

            columns: [
               // {text: 'ID', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: 'ID', dataIndex: 'processId', menuDisabled: true, hidden: true},
                {text: '变更流程编号', dataIndex: 'processNumber', width: 100, menuDisabled: true},
                {text: '变更流程名称', dataIndex: 'link', menuDisabled: true,width:260},
                //{text: 'link', dataIndex: 'link', menuDisabled: true},
                {text: '工作流名称', dataIndex: 'workflowName', menuDisabled: true,width:260},
                {text: '状态', dataIndex: 'state', menuDisabled: true},
                {text: '变更创建者', dataIndex: 'processCreator', menuDisabled: true},
                {text: '流程开始时间', dataIndex: 'processStartTime', menuDisabled: true,width:160},
                {
                    text: '流程完成时间', dataIndex: 'processFinishDate', menuDisabled: true,width:160
                },

                {text: '驳回次数', dataIndex: 'rejectCount', menuDisabled: true},
                {
                    text: '变更评审周期（天）', dataIndex: 'auditCycle',width:150, menuDisabled: true,
                    renderer: function (value, metaData, record, row, col, store) {
                        if (typeof (value) == 'string') {
                            if (value.charAt(0) != "0") {
                                var linkHtml = '<font color="red">' + value + '</font>';
                                return linkHtml;
                            } else {
                                return value;
                            }
                        } else {
                            if (value >= 1) {
                                var linkHtml = '<font color="red">' + value + '</font>';
                                return linkHtml;
                            } else {
                                return value;
                            }
                        }

                    }
                },
                {text: '上下文', dataIndex: 'containerName', menuDisabled: true}
            ],
            tbar: [
                // {
                //     text: '导出选中行',
                //     iconCls: 'icon icon-download',
                //     handler: function () {
                //         this.doExportChangeData(dataChangeAnalysisGrid);
                //     },
                //     scope: this
                // }, {
                //     text: '导出全部行',
                //     iconCls: 'icon icon-download',
                //     handler: function () {
                //         /*if (Ext.getCmp('analysis_dateStart').getValue() == null) {
                //             alert("请输入创建起点时间！");
                //             return;
                //         }
                //         if (Ext.getCmp('analysis_dateEnd').getValue() == null) {
                //             alert("请输入创建完成时间！");
                //             return;
                //         }*/
                //
                //         var createDate_start = "";
                //         var createDate_end = "";
                //         var d1, d2;
                //         if (Ext.getCmp('analysis_dateStart').getValue() != null) {
                //             createDate_start = Ext.getCmp('analysis_dateStart').getValue().toString();
                //         }
                //         if (Ext.getCmp('analysis_dateEnd').getValue() != null) {
                //             createDate_end = Ext.getCmp('analysis_dateEnd').getValue().toString();
                //         }
                //         if (Ext.getCmp('analysis_dateStart').getValue() != null && Ext.getCmp('analysis_dateEnd').getValue() != null) {
                //             d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));
                //             d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));
                //             if (d1 >= d2) {
                //                 alert("开始时间不能大于结束时间！");
                //                 return;
                //             }
                //         }
                //         var processNumber = Ext.getCmp('analysis_processNumber').getValue();
                //         var workflowName = Ext.getCmp('analysis_processName').getValue();
                //         var processState = Ext.getCmp('analysis_processState').getValue();
                //         var createUser = Ext.getCmp('analysis_createUser').getValue();
                //         var containerName = Ext.getCmp('dataChangeAnalysisContainerCombo').getValue();
                //         createDate_start = Ext.getCmp('analysis_dateStart').getValue();
                //         createDate_end = Ext.getCmp('analysis_dateEnd').getValue();
                //         var startDate = "";
                //         var endDate = "";
                //         if (createDate_start != null) {
                //             startDate = Ext.Date.format(new Date(createDate_start), 'Y-m-d');
                //         }
                //         if (createDate_end != null) {
                //             endDate = Ext.Date.format(new Date(createDate_end), 'Y-m-d');
                //         }
                //
                //         var loadMarsk = new Ext.LoadMask(dataChangeAnalysisGrid,{
                //             msg: '正在导入数据，请稍候......',
                //         });
                //         loadMarsk.show();
                //         window.location.href = "exportAllChangeAnalysis.jsp?processNumber=" + processNumber + "&workflowName=" + workflowName +
                //             "&state=" + processState + "&processCreator=" + createUser + "&containerName=" + containerName;
                //         +"&processStartTime=" + startDate + "&processFinishDate=" + endDate;
                //         loadMarsk.hide();
                //     },
                //     scope: this
                // }
                ],
            bbar: Ext.create('Ext.PagingToolbar', {
                //pageSize: 2,
                store: dataChangeAnalysisStore,
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空"
            })//~End bbar
        });


/////////////////////////Panel items//////////////////////////////////
        this.items = [{
            xtype: 'fieldset',
            margin: '5 3 10 3',
            title: '<font style="font-size:12px">查询参数</font>',
            collapsible: true,
            defaults: {
                labelWidth: 100,
                border: false,
                anchor: '98%',
                layout: {
                    type: 'hbox'
                }
            },
            items: [{
                xtype: 'panel',
                defaults: {margin: '5 20 0 0', labelWidth: 70},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: '变更编号',
                    name: 'analysis_processNumber',
                    id: 'analysis_processNumber',
                    width: 250,
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doSearch();
                            }
                        }
                    }
                },workflowNameCombo /*{
                    xtype: 'textfield',
                    fieldLabel: '工作流名称',
                    name: 'analysis_processName',
                    id: 'analysis_processName',
                    width: 250,
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doSearch();
                            }
                        }
                    }
                }*/,userCombo
                    /*{
                        xtype: 'textfield',
                        fieldLabel: '变更创建者',
                        name: 'analysis_createUser',
                        id: 'analysis_createUser',
                        width: 250,
                        enableKeyEvents: true,
                        listeners: {
                            scope: this,
                            'specialkey': function (field, e) {
                                if (e.getKey() == Ext.EventObject.ENTER) {
                                    this.doSearch();
                                }
                            }
                        }
                    }*/, stateCombo,workflowNameCombo,/*{
                        xtype: 'textfield',
                        fieldLabel: '状态',
                        name: 'analysis_processState',
                        id: 'analysis_processState',
                        width: 250,
                        enableKeyEvents: true,
                        listeners: {
                            scope: this,
                            'specialkey': function (field, e) {
                                if (e.getKey() == Ext.EventObject.ENTER) {
                                    this.doSearch();
                                }
                            }
                        }
                    }*/]
            },
                /*{
                xtype: 'panel',
                defaults: {margin: '5 20 0 0', labelWidth: 70},
                items: [
                    {
                    xtype: 'textfield',
                    fieldLabel: '变更创建者',
                    name: 'analysis_createUser',
                    id: 'analysis_createUser',
                    width: 250,
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doSearch();
                            }
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: '状态',
                    name: 'analysis_processState',
                    id: 'analysis_processState',
                    width: 250,
                    enableKeyEvents: true,
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doSearch();
                            }
                        }
                    }
                }]
            },*/ {
                xtype: 'panel',
                defaults: {margin: '5 20 0 0', labelWidth: 70},
                items: [dataChangeAnalysisContainerCombo,{
                    xtype: 'datefield',
                    //border:false,
                    labelWidth: 70,
                    width: 250,
                    fieldLabel: '开始日期从:',
                    format: 'Y-m-d',
                    id: 'analysis_dateStart',
                    name: 'analysis_dateStart',
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doLaborCostSearch();
                            }
                        }
                    }
                }, {
                    xtype: 'datefield',
                    //border:false,
                    labelWidth: 70,
                    width: 250,
                    fieldLabel: '&nbsp;&nbsp;&nbsp;&nbsp;到:',
                    format: 'Y-m-d',
                    id: 'analysis_dateEnd',
                    name: 'analysis_dateEnd',
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doLaborCostSearch();
                            }
                        }
                    }
                }]
            }, /*{
                xtype: 'panel',
                defaults: {margin: '5 20 0 0', labelWidth: 70},
                items: [{
                    xtype: 'datefield',
                    //border:false,
                    labelWidth: 70,
                    width: 250,
                    fieldLabel: '开始日期从:',
                    format: 'Y-m-d',
                    id: 'analysis_dateStart',
                    name: 'analysis_dateStart',
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doLaborCostSearch();
                            }
                        }
                    }
                }, {
                    xtype: 'datefield',
                    //border:false,
                    labelWidth: 70,
                    width: 250,
                    fieldLabel: '&nbsp;&nbsp;&nbsp;&nbsp;到:',
                    format: 'Y-m-d',
                    id: 'analysis_dateEnd',
                    name: 'analysis_dateEnd',
                    listeners: {
                        scope: this,
                        'specialkey': function (field, e) {
                            if (e.getKey() == Ext.EventObject.ENTER) {
                                this.doLaborCostSearch();
                            }
                        }
                    }
                }
                    ]
            }, */{
                xtype: 'panel',
                items: [{
                    xtype: 'button',
                    margin: '10 0 10 0',
                    width: 70,
                    text: '查询',
                    scope: this,
                    iconCls: 'icon icon-search',
                    handler: function () {
                        this.doSearch();
                    }
                }]
            }
            ]
        },
            dataChangeAnalysisGrid,dataChangeReportGrid
        ];

        this.callParent();
    },//~End of initComponent

    listeners: {
        'afterrender': function () {
        }
    },

////////////////////////Function area//////////////////////////
    doExportChangeData: function (grid) {
        if (grid.getSelectionModel().getSelection().length <= 0) {
            alert('下载之前，请先选中行！');
            return;
        }
        var loadMarsk = new Ext.LoadMask(grid, {
            msg: '正在处理数据，请稍候......',
            removeMask: true // 完成后移除
        });
        loadMarsk.show()
        var orgRec; // 临时记录
        var exportRecords = new Array();// 修改记录
        var selectRecordsOrg = grid.getSelectionModel().getSelection(); //获取选中列
        for (var i = 0, l = selectRecordsOrg.length; i < l; i++) {
            orgRec = selectRecordsOrg[i].data;
            var tempRec = {
                'processId': orgRec.processId,
                '0-变更流程编号': orgRec.processNumber,
                '1-变更流程名称': orgRec.processName,
                '2-工作流名称': orgRec.workflowName,
                '3-状态': orgRec.state,
                '4-流程创建者': orgRec.processCreator,
                '5-流程开始时间': orgRec.processStartTime,
                '6-流程完成时间': orgRec.processFinishDate,
                '7-驳回次数': orgRec.rejectCount,
                '8-数据评审周期': orgRec.auditCycle,
                '9-上下文': orgRec.containerName
                //'': orgRec.projectTeam,

            };
            exportRecords[exportRecords.length] = tempRec;
        }
        Ext.Ajax.request({
            url: '/Windchill/ptc1/dataReport/exportSelectChangeAnalysisData',
            params: {
                exportRecords: Ext.encode(exportRecords)
            },
            success: function (response, opts) {
                window.location.href = 'exportChangeAnalysisData.jsp';
                loadMarsk.hide();
            },
            failure: function (response, opts) {
                alert('错误：导出失败，请检查网络！');
            }
        });//~End of request

    },

    /**
     * 按查询参数查询
     */
    doSearch: function () {

        var createDate_start = "";
        var createDate_end = "";
        var d1, d2;
        if (Ext.getCmp('analysis_dateStart').getValue() != null) {
            createDate_start = Ext.getCmp('analysis_dateStart').getValue().toString();
        }
        if (Ext.getCmp('analysis_dateEnd').getValue() != null) {
            createDate_end = Ext.getCmp('analysis_dateEnd').getValue().toString();
        }
        if (Ext.getCmp('analysis_dateStart').getValue() != null && Ext.getCmp('analysis_dateEnd').getValue() != null) {
            d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));
            d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));
            if (d1 >= d2) {
                alert("开始时间不能大于结束时间！");
                return;
            }
        }

        var data = {
            processNumber: Ext.getCmp('analysis_processNumber').getValue(),
            workflowName: Ext.getCmp('analysis_processName').getValue(),
            state: Ext.getCmp('analysis_processState').getValue(),
            processCreator: Ext.getCmp('analysis_createUser').getValue(),
            containerName: Ext.getCmp('dataChangeAnalysisContainerCombo').getValue(),
            createDateStart: Ext.getCmp('analysis_dateStart').getValue(),
            createDateSnd: Ext.getCmp('analysis_dateEnd').getValue()
        };
        Ext.getStore('dataChangeAnalysisStore').reload({
            params: {
                data: Ext.encode(data)
            },
            callback: function (records, operation, success) {
                if (!success) {
                    alert('查询数据变更流程信息失败，请联系管理员！');
                }
            }
        });
    }

});

