Ext.define('PLM.view.ProjectDocProcessPanel',{
	extend:'Ext.panel.Panel',
	alias:'widget.ProjectDocProcessPanel',
	border:false,
    autoWidth:true,
 	//autoHeight:true,
 	height:880,
	title : '<font style="font-size:15px">文档流程统计</font>',
     collapsible: false,
     id: 'ProjectDocProcessPanel',
     fieldDefaults: {
         msgTarget: 'side',
         labelWidth: 75
     },
	initComponent:function(){
		
		//开始时间
		var startTime =new Ext.form.DateField({
    		allowBlank: false,
    		id : 'startDate',
    		name : 'startDate',
    		labelWidth : 70,
    		margin:'5 10 10 0',
    		width : 200,
    		fieldLabel: '开始时间',
    		format: 'Y-m-d'
        });
		
		//结束时间
		var endTime =new Ext.form.DateField({
    		allowBlank: false,
    		id : 'endDate',
    		name : 'endDate',
    		labelWidth : 80,
    		width : 210,
    		margin:'5 10 10 0',
    		fieldLabel: '&nbsp;&nbsp;&nbsp;到',
    		format: 'Y-m-d'
        });
		
		//审核详情
		Ext.define('detailsModel', {
		    extend: 'Ext.data.Model',
		    fields: [
				'id', 'projectId', 'rowId', 'activityName', 'responsibleUser', 'roleName',
				'vote', 'remarks' ,'finishUser', 'taskReceptionTime',
				'finishTime', 'isOverdue','overdueCycle'
		    ],
		    idProperty: 'id'
		});
		// create the Data Store
		var detailsStore = Ext.create('Ext.data.Store', {
		    pageSize: 100,
		    model: 'detailsModel',
		    id:'detailsStore',
		    pruneModifiedRecords: true,
		    autoLoad:false
		});
		
		var detailsColumn = [
		 			        { text: 'ID',  dataIndex: 'id',hidden:true}, 
					        { text: '项目ID',  dataIndex: 'projectId',hidden:true}, 
					        { text: '序号',  dataIndex: 'rowId',align : 'center',width:40,  xtype : 'rownumberer'}, 
					        { text: '任务名称',  dataIndex: 'activityName' , width:180},
				            { text: '负责人',  dataIndex: 'responsibleUser', width:180},
				            { text: '角色',  dataIndex: 'roleName', width:180},
				            { text: '投票',  dataIndex: 'vote'},
				            { text: '备注',  dataIndex: 'remarks'},
				            { text: '完成者', dataIndex: 'finishUser'},
				            { text: '任务接收时间',  dataIndex: 'taskReceptionTime'},	
		  	                { text: '完成时间',  dataIndex: 'finishTime'},	
				            { text: '是否逾期', dataIndex: 'isOverdue'},
			  	            { text: '逾期周期', dataIndex: 'overdueCycle'}
				        ];
		
		// create the Data Grid
		var detailsGrid = Ext.create('Ext.grid.Panel', {
		    //title: '一般费用开销数据表',
		    store:detailsStore,
		    //forceFit : true,
		    autoWidth : true,
		    autoScroll:true,
		    title : '审核详情',
			height:250,
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig:{enableTextSelection:true, forceFit : false},
			selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"SIMPLE",showHeaderCheckbox:true}),
		    columns: detailsColumn,
		    bbar: Ext.create('Ext.PagingToolbar', {
		    	pageSize: 300,
		        store: detailsStore,
		        displayInfo: true,
		        displayMsg: '当前显示 {0} - {1} ，共 {2}',
		        emptyMsg: "查询结果为空"
	        })//~End bbar
		});
		
		
		//文档流程信息
		Ext.define('projectDocModel', {
		    extend: 'Ext.data.Model',
		    fields: [
				'id', 'projectId', 'rowId', 'projectName','docNumber', 'docName', 'processName',
				'processOid','state', 'creator' ,'currentNode','currentResponsibleUser','processStartTime', 
				'processEndTime', 'rejectionCount', 'auditCycle'
		    ],
		    idProperty: 'id'
		});

		// create the Data Store
		var projectDocStore = Ext.create('Ext.data.Store', {
		    pageSize: 50,
		    model: 'projectDocModel',
		    id:'projectDocStore',
		    pruneModifiedRecords: true,
		    proxy: new Ext.data.HttpProxy({
		        url: '/Windchill/ptc1/docProcess/getDocProcessInfo?projectId=' + projectId,
		        method:'GET',
		        timeout: 9000000,
		        reader:{
		        	type:'json',
		        	root: 'items',
		            totalProperty: 'totalCount',
		            idProperty: 'id',
				    messageProperty: 'msg'
		        }
		    }),
		    autoLoad:true
		});
		//初始化参数
		projectDocStore.on('beforeload', function(store, options) {  
			var data = {
					docNumber:Ext.getCmp('txt_docNumber').getValue(),
					docName:Ext.getCmp('txt_docName').getValue(),
					projectName:projectName,
					state:Ext.getCmp('txt_state').getValue(),
					creator:Ext.getCmp('txt_creator').getValue(),
					startDate:Ext.util.Format.date(Ext.getCmp('startDate').getValue(), 'Y-m-d'),
					endDate:Ext.util.Format.date(Ext.getCmp('endDate').getValue(), 'Y-m-d')
			}; 
		        Ext.apply(projectDocStore.proxy.extraParams, data);  
		});
		// create the Data Grid
		var projectDocGrid = Ext.create('Ext.grid.Panel', {
		    store:projectDocStore,
		    //forceFit : true,
		    autoWidth : true,
		    autoScroll:true,
		    title : '文档流程信息',
			height:250,
			//bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
			viewConfig:{enableTextSelection:true, forceFit : false},
			selModel:Ext.create('Ext.selection.CheckboxModel',
					{	mode:"SINGLE",
						showHeaderCheckbox:true,
						listeners: {
							select: function(model,record,index) {
								var loadMarsk = new Ext.LoadMask(document.body, {    
									msg:'正在处理数据，请稍候......',    
									removeMask:true // 完成后移除    
								});
								loadMarsk.show() ;
								Ext.Ajax.request({
									scope : this,
									url: '/Windchill/ptc1/docProcess/getDocProcessDetailInfo?processOid='+record.get('processOid'),
									success : function(response,opts) {
										var obj = Ext.decode(response.responseText);
										var data = obj['items'];
										detailsStore.removeAll();
										detailsStore.add(data);
										detailsGrid.reconfigure(detailsStore,detailsColumn);
										loadMarsk.hide() ;
									},
									failure : function(response,opts) {
										loadMarsk.hide() ;
										alert("查询流程信息失败，请检查网络");
									}
								});
								
							}
						}
					}),
		    columns: [
			        { text: 'ID',  dataIndex: 'id',hidden:true}, 
			        { text: '项目ID',  dataIndex: 'projectId',hidden:true}, 
			        { text: '序号',  dataIndex: 'rowId',align : 'center',width:40,  xtype : 'rownumberer'}, 
			        { text: '项目名称',  dataIndex: 'projectName' , width:200},
			        { text: '文档编号',  dataIndex: 'docNumber' , width:100},
		            { text: '文档名称',  dataIndex: 'docName', width:200},
		            { text: '工作流名称',  dataIndex: 'processName',width:200},
		            { text: 'processOid',  dataIndex: 'processOid',hidden:true},
		            { text: '状态',  dataIndex: 'state'},
		            { text: '创建人', dataIndex: 'creator'},
		            { text: '当前节点', dataIndex: 'currentNode'},
		            { text: '当前负责人', dataIndex: 'currentResponsibleUser'},
		            { text: '流程开始时间',  dataIndex: 'processStartTime'},	
  	                { text: '流程结束时间',  dataIndex: 'processEndTime'},	
		            { text: '驳回次数', dataIndex: 'rejectionCount'},
	  	            { text: '评审周期', dataIndex: 'auditCycle'}
		        ],
		        tbar : [{
					text : '导出当前项目报表',
					iconCls : 'icon icon-download',
					handler : function() {
						var loadMarsk = new Ext.LoadMask(document.body, {    
							msg:'正在处理数据，请稍候......',    
							removeMask:true // 完成后移除    
						});
						loadMarsk.show() ;
						var createDate_start = "";
						var createDate_end = "";
						var d1,d2;
						if(Ext.getCmp('startDate').getValue() != null && Ext.getCmp('endDate').getValue() != null) {			
							d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));  		
							d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));   
							if(d1 >=d2) {  
								   alert("开始时间不能大于结束时间！");  
								   return ;  
							} 
						}
						var store = Ext.getStore('projectDocStore');
						Ext.Ajax.request({
							scope : this,
							url: '/Windchill/ptc1/docProcess/exportOneProcessInfo?projectId=' + projectId,
							params : {
								docNumber:Ext.getCmp('txt_docNumber').getValue(),
								docName:Ext.getCmp('txt_docName').getValue(),
								projectName:projectName,
								state:Ext.getCmp('txt_state').getValue(),
								creator:Ext.getCmp('txt_creator').getValue(),
								startDate:Ext.util.Format.date(Ext.getCmp('startDate').getValue(), 'Y-m-d'),
								endDate:Ext.util.Format.date(Ext.getCmp('endDate').getValue(), 'Y-m-d'),
								begin:0,
								total:store.getTotalCount()
							},
							success : function(response,opts) {
								var obj = Ext.decode(response.responseText);
								var path = obj['path'];
								if(path == null || path == '') {
									alert("没有数据");
								} else {
									window.open(path);
								}
								loadMarsk.hide() ;
							},
							failure : function(response,opts) {
								loadMarsk.hide() ;
								alert("导出流程信息失败，请检查网络");
								
							}
						});
					}
		        }],
		        bbar: Ext.create('Ext.PagingToolbar', {
		        	id:'pagingTool',
			        store: projectDocStore,
			        displayInfo: true,
			        displayMsg: '当前显示 {0} - {1} ，共 {2}',
			        emptyMsg: "查询结果为空"
		        }),//~End bbar
				scope : this
		        
	});

		
		
//---------------------   Itimes   --------------------------//		
		this.items=[{
			xtype: 'fieldset',
    		margin:'5 3 10 3',
            title: '<font style="font-size:12px">查询参数</font>',
            collapsible: true,
            defaults: {
                labelWidth: 100,
                border:false,
                anchor: '98%',
                layout: {
                    type: 'hbox'
                }
            },
			items:[{
	        	xtype: 'panel',
	            defaults:{ margin:'5 20 0 0',labelWidth:70},
	        	items:[/*{
	        		xtype:'textfield',
      	    		fieldLabel: '项目名称',
      	            name: 'txt_projectName',
      	            id: 'txt_projectName',
      	            width:200,
      	            enableKeyEvents:true,
      	            listeners:{  
      	            	scope:this,
      	                'specialkey':function(field,e)  
      	                {  
      	                	if(e.getKey() == Ext.EventObject.ENTER)  
      	                    {  
      	                        this.doSearch();
      	                    }  
      	                }  
      	            } 
	        	},*/{
	        		xtype:'textfield',
      	    		fieldLabel: '文档编号',
      	            name: 'txt_docNumber',
      	            id: 'txt_docNumber',
      	            width:200,
      	            enableKeyEvents:true,
      	            listeners:{  
      	            	scope:this,
      	                'specialkey':function(field,e)  
      	                {  
      	                	if(e.getKey() == Ext.EventObject.ENTER)  
      	                    {  
      	                        this.doSearch();
      	                    }  
      	                }  
      	            } 
	        	}, {
	        		xtype:'textfield',
      	    		fieldLabel: '创建人',
      	            name: 'txt_creator',
      	            id: 'txt_creator',
      	            width:200,
      	            enableKeyEvents:true,
      	            listeners:{  
      	            	scope:this,
      	                'specialkey':function(field,e)  
      	                {  
      	                	if(e.getKey() == Ext.EventObject.ENTER)  
      	                    {  
      	                        this.doSearch();
      	                    }  
      	                }  
      	            } 		
	        	}]},{
		        	xtype: 'panel',
		            defaults:{ margin:'5 20 0 0',labelWidth:70},
		        	items:[{
		        		xtype:'textfield',
	      	    		fieldLabel: '文档名称',
	      	            name: 'txt_docName',
	      	            id: 'txt_docName',
	      	            width:200,
	      	            enableKeyEvents:true,
	      	            listeners:{  
	      	            	scope:this,
	      	                'specialkey':function(field,e)  
	      	                {  
	      	                	if(e.getKey() == Ext.EventObject.ENTER)  
	      	                    {  
	      	                        this.doSearch();
	      	                    }  
	      	                }  
	      	            } 
		        	}, {
		        		xtype:'textfield',
	      	    		fieldLabel: '状态',
	      	            name: 'txt_state',
	      	            id: 'txt_state',
	      	            width:200,
	      	            enableKeyEvents:true,
	      	            listeners:{  
	      	            	scope:this,
	      	                'specialkey':function(field,e)  
	      	                {  
	      	                	if(e.getKey() == Ext.EventObject.ENTER)  
	      	                    {  
	      	                        this.doSearch();
	      	                    }  
	      	                }  
	      	            } 		
		        	}]},{
						xtype: 'panel',
						items : [startTime,
						         endTime]
		        	},{
		        	xtype:'panel',
		        	items:[{
			            xtype:'button',
			            margin:'10 0 10 0',
			            width:70,
			        	text: '查询',
			        	scope:this,
		                iconCls: 'icon icon-search',
			            handler: function() {
			            	this.doSearch();
			            	var pagingbar = Ext.getCmp('pagingTool');
			            	pagingbar.moveFirst();
			            }
		        	}]	
		        }]},
		            projectDocGrid,
		            detailsGrid
		];
		this.callParent();
	},//~End of initComponent
	listeners:{
		'afterrender':function(){}
	},
	
//---------------------Function area----------------------------//
	/**
	 * 按查询参数查询
	 */
	doSearch: function(){
		var createDate_start = "";
		var createDate_end = "";
		var d1,d2;
		if(Ext.getCmp('startDate').getValue() != null && Ext.getCmp('endDate').getValue() != null) {			
			d1 = new Date(Date.parse(createDate_start.replace(/-/g, "/")));  		
			d2 = new Date(Date.parse(createDate_end.replace(/-/g, "/")));   
			if(d1 >=d2) {  
				   alert("开始时间不能大于结束时间！");  
				   return ;  
			} 
		}
		var store = Ext.getStore('projectDocStore');
		var data = {
				docNumber:Ext.getCmp('txt_docNumber').getValue(),
				docName:Ext.getCmp('txt_docName').getValue(),
				projectName:projectName,
				state:Ext.getCmp('txt_state').getValue(),
				creator:Ext.getCmp('txt_creator').getValue(),
				startDate:Ext.util.Format.date(Ext.getCmp('startDate').getValue(), 'Y-m-d'),
				endDate:Ext.util.Format.date(Ext.getCmp('endDate').getValue(), 'Y-m-d')
		};
		store.reload({
			params:{
				data:Ext.encode(data)
				},
			callback: function(records, operation, success) {
		        if(!success){
		        	alert('查询数据审核流程信息失败，请联系管理员！');
		        }
			}
		});
	}
	
});

