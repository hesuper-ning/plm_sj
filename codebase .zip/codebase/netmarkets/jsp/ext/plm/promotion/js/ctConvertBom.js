
let ctContentEditing1 = new Ext.grid.plugin.CellEditing({
    clicksToEdit: 1
});

Ext.define('ctConvertBomModel', {
    extend: 'Ext.data.Model',
    fields: ['id', 'pnId', 'partNumber', 'developDesc', 'convertMView', 'manufacturingNumber', 'lastTimeCheck', 'illustrate'
        , 'convertBom', 'implementationStatus', 'flagRed', 'partType'],
    idProperty: 'id'
});

Ext.create('Ext.data.Store', {
    model: 'ctConvertBomModel',
    storeId: 'ctConvertBomStore',
    pruneModifiedRecords: true,
    proxy: new Ext.data.HttpProxy({
        url: '/Windchill/ptc1/bom/queryConvertBomInfo?workItemOid=' + workItemOid,
        method: 'GET',
        reader: {
            type: 'json',
            rootProperty: 'data',
            idProperty: 'id',
            messageProperty: 'message'
        }
    }),
    autoLoad: true
});

let convertBomStore = [
    ['是', '是'],
    ['否', '否']];

let tipsPanel =  Ext.create('Ext.panel.Panel', {
    title: '',
    id:'tipsPanel',
    hidden: partPage,
    autoWidth:true,
    anchor: '100%',
    items: [
        {
            html:'<p style="color:red">1、单独作为升级对象的半成品，且无成品引用，则整行数据标记红色；\n' +
                '2、M视图与E视图料号不一致，M视图物料编码标记红色（如也包含一致，也显示红色）</p>'
        }
    ]
});

//转BOM表格
let ctConvertBomGrid = Ext.create('Ext.grid.Panel', {
    id: 'ctConvertBomGrid',
    store: Ext.data.StoreManager.lookup('ctConvertBomStore'),
    forceFit: false,
    height: 600,
    autoWidth: true,
    title: '',
    collapsible: true,
    collapseToolText: '折叠',
    expandToolText: '展开',
    titleCollapse: true,
    hideCollapseTool: false,
    anchor: '100%',
    plugins: [ctContentEditing1],
    viewConfig: {
        enableTextSelection: true
    },
    selModel: Ext.create('Ext.selection.CheckboxModel', {
        mode: 'SIMPLE',
        checkOnly: true,
        showHeaderCheckbox: true
        // ,
        // listeners: {
        //     beforeselect: function (grid, record) {
        //         if (record.get('convertMView') == '是') {
        //             return false;
        //         } else {
        //             return true;
        //         }
        //     }
        // }
    }),
    autoScroll: false,
    columns: [
        {text: '序号', width: 60, align: 'center', menuDisabled: false, xtype: 'rownumberer', sortable: false},
        {text: 'id', width: 120, dataIndex: 'id', hidden: true, align: 'center'},
        {text: 'pnId', width: 120, dataIndex: 'pnId', hidden: true, align: 'center'},
        {
            text: '类型',
            width: 180,
            dataIndex: 'partType',
            menuDisabled: false,
            align: 'center',
            editAccess: false,
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 180px;"';
                }
                //根据后台传入的标识，字体设置为红色
                let flagRed = record.get('flagRed');
                if(value && 'Y' == flagRed){
                    let redValue = "<span style='color:red;'>"+value+"</span>";
                    return redValue;
                }
                return value;
            }
        },
        {
            text: '料号',
            width: 120,
            dataIndex: 'partNumber',
            menuDisabled: false,
            align: 'center',
            editAccess: false,
            editor: {xtype: 'textfield', selectOnFocus: true},
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 120px;"';
                }

                let flagRed = record.get('flagRed');
                if(value && 'Y' == flagRed){
                    let redValue = "<span style='color:red;'>"+value+"</span>";
                    return redValue;
                }
                return value;
            }
        },
        {
            text: '研发描述',
            width: 260,
            dataIndex: 'developDesc',
            menuDisabled: false,
            align: 'center',
            editAccess: false,
            editor: {xtype: 'textfield', selectOnFocus: true},
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 260px;"';
                }

                let flagRed = record.get('flagRed');
                if(value && 'Y' == flagRed){
                    let redValue = "<span style='color:red;'>"+value+"</span>";
                    return redValue;
                }
                return value;
            }
        },
        {
            text: '是否已转M视图',
            width: 150,
            dataIndex: 'convertMView',
            menuDisabled: false,
            align: 'center',
            editAccess: false,
            editor: {xtype: 'textfield', selectOnFocus: true},
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 150px;"';
                }

                let flagRed = record.get('flagRed');
                if(value && 'Y' == flagRed){
                    let redValue = "<span style='color:red;'>"+value+"</span>";
                    return redValue;
                }
                return value;
            }
        },
        {
            text: 'M视图物料编码',
            width: 200,
            dataIndex: 'manufacturingNumber',
            menuDisabled: false,
            align: 'center',
            editAccess: false,
            editor: {xtype: 'textfield', selectOnFocus: true},
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 200px;"';
                }

                let flagRed = record.get('flagRed');
                let redValue = "<span style='color:red;'>"+value+"</span>";
                if(value && 'Y' == flagRed){
                    return redValue;
                }
                let partNumber = record.get('partNumber');
                if(partNumber && value){
                    if(value.indexOf(',') != -1){
                        return redValue;
                    }else{
                        let number = value.substr(0, value.indexOf('('));
                        if(number != partNumber){
                            return redValue;
                        }
                    }
                }
                return value;
            }
        },
        {
            text: '上次是否勾选',
            width: 150,
            dataIndex: 'lastTimeCheck',
            menuDisabled: false,
            align: 'center',
            editAccess: false,
            editor: {xtype: 'textfield', selectOnFocus: true},
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 150px;"';
                }

                let flagRed = record.get('flagRed');
                if(value && 'Y' == flagRed){
                    let redValue = "<span style='color:red;'>"+value+"</span>";
                    return redValue;
                }
                return value;
            }
        },
        {
            text: setRequired('不转MBOM说明',isEditable(maintenance_bom_node)),
            width: 150,
            dataIndex: 'illustrate',
            menuDisabled: false,
            align: 'center',
            editAccess:isEditable(maintenance_bom_node),
            editor: {xtype: 'textfield', selectOnFocus: true},
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 150px;"';
                }

                let flagRed = record.get('flagRed');
                if(value && 'Y' == flagRed){
                    let redValue = "<span style='color:red;'>"+value+"</span>";
                    return redValue;
                }
                return value;
            }
        },
        {
            text: setMust('本次是否转',isEditable(maintenance_bom_node)),
            width: 120,
            dataIndex: 'convertBom',
            menuDisabled: false,
            align: 'center',
            editAccess:isEditable(maintenance_bom_node),
            editor: {xtype: 'textfield', selectOnFocus: true},
            editor: {
                xtype: 'combobox',
                editable: false,
                forceSelection: false,
                store: convertBomStore,
            },
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 120px;"';
                }

                let flagRed = record.get('flagRed');
                if(value && 'Y' == flagRed){
                    let redValue = "<span style='color:red;'>"+value+"</span>";
                    return redValue;
                }
                return value;
            }
        },
        {
            text: '执行状况',
            width: 200,
            dataIndex: 'implementationStatus',
            menuDisabled: false,
            align: 'center',
            editAccess: false,
            editor: {xtype: 'textfield', selectOnFocus: true},
            renderer: function (value, meta, record) {
                //如果已转M视图为是，则本行底色置灰
                let color = '#C7CECF';
                if(record.get('convertMView') == '是'){
                    meta.tdAttr = 'style="background-color: ' + color + ';width: 200px;"';
                }

                let flagRed = record.get('flagRed');
                if(value && 'Y' == flagRed){
                    let redValue = "<span style='color:red;'>"+value+"</span>";
                    return redValue;
                }
                return value;
            }
        }
    ],
    tbar: [
        {
            text: '<font color=red bold><b style="font-size:15px">转MBOM</b></font>',
            iconCls: 'icon icon-partConfigCreate',
            disabled: !isEditable(maintenance_bom_node),
            handler: function () {
                ctContentEditing1.cancelEdit();
                convertBom();
            },
            scope: this
        },
        {
            text: '导出EBOM/MBOM差异',
            iconCls: 'icon icon-excelExport',
            disabled: !isEditable(maintenance_bom_node),
            handler: function () {
                ctContentEditing1.cancelEdit();
                let grid = Ext.getCmp('ctConvertBomGrid');
                //校验是否有选择数据
                var tmpSm = grid.getSelectionModel().getSelection();
                if (!tmpSm || tmpSm == '') {
                    Ext.Msg.alert('提示', '请选择要导出的物料！');
                    return;
                }
                let numbers;
                for(let i = 0;i < tmpSm.length;i++){
                    let rowData = tmpSm[i].getData();
                    let partNumber = rowData['partNumber'];
                    if(i == 0){
                        numbers = partNumber;
                    }else{
                        numbers += ',' + partNumber;
                    }
                }
                //导出
                exportBomDifferent(numbers);
            },
            scope: this
        }
    ],
    listeners: {
        beforeedit: function (editor, e) {
            return checkBeforeEdit(editor, e);
        },
        edit: function (editor, e) {
            updateConvertBomData(editor, e);
        }
    }
});


