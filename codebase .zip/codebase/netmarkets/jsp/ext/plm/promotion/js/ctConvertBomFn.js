var redStarFlag = '<font color=red bold>*</font>';//必填标志
var blueFlagStart = '<font color=blue bold><b>';//可编辑标识
var blueFlagEnd = '</b></font>';
let maintenance_bom_node = "maintenance_bom_node";

/**
 * 设为必填
 */
function setMust(field, flag) {
    if (flag)
        return redStarFlag + blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 设为可填
 */
function setRequired(field, flag) {
    if (flag)
        return blueFlagStart + field + blueFlagEnd;
    else
        return field;
}

/**
 * 回显格式化日期格式
 * @param value
 * @returns {*|string}
 */
function renderDateField(value) {
    var timeStr = value;
    if(value != null && value != undefined && value != ''){
        var date = new Date(value);
        timeStr = Ext.Date.format(date,"Y-m-d")
    }
    return timeStr;
}

/**
 * 对Request封装
 * @Param url 请求url
 * @Param method 请求方法'GET' 'POST'
 * @Param async true 请求异步 false 请求步
 * @Param object
 * @Param callback 回调方法
 */
function sendRequest(url, method, headers, async, params, successCallback, failCallback) {
    Ext.Ajax.request({
        scope: this,
        url: url,
        method: method,
        timeout: 600000,
        async: async,
        headers: {'Content-Type': headers},
        params: params,
        success: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj['status'] !== 200) {
                Ext.Msg.alert('错误', obj['message']);
                if (failCallback) {
                    failCallback();
                }
            } else {
                if (successCallback) {
                    successCallback(obj.data);
                }
            }
        },
        failure: function (response, opts) {
            let obj = Ext.decode(response.responseText);
            if (obj&&obj['message']) {
                Ext.Msg.alert('错误', obj['message']);
            }else{
                Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
            }
            if (failCallback != null && failCallback !== '') {
                failCallback();
            }
        }
    }); //~End of Ajax request
}

//更新转BOM表格数据
function updateConvertBomData(editor, e) {
    let record = e.record; // 得到当前行所有数据
    let field = e.field;   // 得到修改列
    let value = e.value;   // 得到修改列修改后的值
    let oldValue = e.originalValue; // 旧值
    let id = record.get('id');
    if (value === oldValue) {
        record.reject();
        return; // 没有修改内容则返回
    }
    function successCallback(data) {
        ctConvertBomGrid.getStore().reload();
    }
    function failCallback() {
        record.reject();
    }
    sendRequest('/Windchill/ptc1/bom/updateConvertBomInfo', 'POST',
        'application/x-www-form-urlencoded', false, {id: id, key: field, value: value},
        successCallback, failCallback);
}

//表格beforeedit校验
function checkBeforeEdit(editor, e) {
    let field = e.field;
    let value = e.value;
    let record = e.record;
    if(record.get('convertMView') == '是'){
        return false;
    }
    return checkEditAccess(e);
}

/**
 * 判断grid编辑权限
 * @param e
 * @returns {boolean}
 */
function checkEditAccess(e) {
    //if(isAdmin) return true;
    var column = e.column;//获取编辑列
    if(column.editAccess){
        return true;
    }else{
        return false;
    }
    return true;
}

/**
 * 判断是否可编辑
 * @param node 节点表单key
 * @returns {boolean}
 */
function isEditable(...node) {
    //if (isAdmin) return true;
    if (readOnlyPage || taskCompleted) return false;
    let flag = false;
    node.forEach((item, index) => {
        if (item === currentActKey) {
            flag = true;
        }
    });
    return flag;
}

/**
 * combobox空白行高度与选项保持一致
 * @param name
 * @returns {Ext.XTemplate}
 */
function getXTemplate(name) {
    return Ext.create('Ext.XTemplate',
        '<tpl for=".">',
        '<div class="x-boundlist-item" style="height:25px">{' + name + '}</div>',
        '</tpl>'
    )
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion

//region表单字段悬浮提示
var updateTip = function (field) {
    var id = field.getEl().dom.id;
    var val = field.getValue();
    if(isNull(val)){
        return;
    }
    Ext.QuickTips.init();
    // 将一些配置属性应用到此单态
    Ext.apply(Ext.QuickTips.getQuickTip(), {
        maxWidth: 200,
        minWidth: 100,
        showDelay: 50,
        trackMouse: true
    });
    Ext.QuickTips.register({
        target: id,//在哪个html元素上显示
        text: val,//具体要提示的东西
        width: 200
    })
}//endregion


function convertBom(){
    let grid = Ext.getCmp('ctConvertBomGrid');
    //校验是否有选择数据
    var tmpSm = grid.getSelectionModel().getSelection();
    if(!tmpSm || tmpSm==''){
        Ext.Msg.alert('提示','请选择要转MBOM的物料！');
        return;
    }
    let numbers;
    for(let i = 0;i < tmpSm.length;i++){
        let rowData = tmpSm[i].getData();
        let partNumber = rowData['partNumber'];
        //校验已转M视图的物料为“是”的物料不能再选
        // if('是' == rowData['convertMView']){
        //     Ext.Msg.alert('提示', '“是否已转M视图”为“是”的物料，' + rowData['partNumber'] + '不能再转MBOM！');
        //     return;
        // }
        if('是' == rowData['convertBom'] && '是' != rowData['convertMView']){
            if(!numbers){
                numbers = partNumber;
            }else{
                numbers += ',' + partNumber;
            }
        }
    }
    if(!numbers){
        Ext.Msg.alert('提示','请选择“是否已转M视图”不为“是”,并且“本次是否转”为“是”的物料！');
        return;
    }

    let items = grid.getStore().getData().items;
    if(items){
        for(let i = 0;i < items.length; i++){
            let rowData = items[i].data;
            //校验“本次是否转BOM”必填
            if('是' != rowData['convertMView'] && !rowData['convertBom']){
                Ext.Msg.alert('提示', '除了已转M视图的物料，所有行的“本次是否转”字段必填！');
                return;
            }
            //校验“本次是否转BOM”为否，则不转MBOM说明必填
            if(rowData['convertBom'] == '否' && (!rowData['illustrate'] || rowData['illustrate'] == '')){
                Ext.Msg.alert('提示', '“本次是否转BOM”为否，则“不转MBOM说明”必填！');
                return;
            }
        }
    }

    //增加遮罩
    var loadMarsk = new Ext.LoadMask({
        msg:'正在导入数据，请稍候......',
        target: Ext.getCmp('CtConvertBomPanel'),
        removeMask:true // 完成后移除
    });
    loadMarsk.show();
    Ext.Ajax.request({
        scope: this,
        url: "/Windchill/ptc1/bom/convertBom",
        method: "POST",
        async: false,
        params: {
            numbers: numbers,
            workItemOid: workItemOid
        },
        success: function (response, opts) {
            loadMarsk.hide();
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success"){
                //刷新表单数据
                let store = grid.getStore();
                store.reload();
                Ext.Msg.alert('提示', '转MBOM成功!');
            }else{
                Ext.Msg.alert('提示', obj.message);
            }
        },
        failure: function (response, opts) {
            loadMarsk.hide();
            Ext.Msg.alert("错误", "请求信息失败，请检查网络！");
        }
    });
}

/**
 * 导出
 */
function exportBomDifferent(partNumbers) {
    // 获取XMLHttpRequest
    var xmlHttpRequest = new XMLHttpRequest();
    //  发起请求
    xmlHttpRequest.open("POST", '/Windchill/ptc1/bom/exportBomDifferent', true);
    // 设置请求头类型
    xmlHttpRequest.setRequestHeader("Content-type", "application/json; charset=UTF-8\n");
    xmlHttpRequest.responseType = "blob";
    //  返回
    xmlHttpRequest.onload = function (oEvent) {
        var content = xmlHttpRequest.response;
        if (content.type == 'application/json') {
            content.text().then(res => {
                alert(Ext.decode(res).message)
            })
        } else {
            var timestamp =new Date().getTime();
            // 组装a标签
            var elink = document.createElement("a");
            // 设置下载文件名
            var fileNamePrefix = 'EBOM和MBOM差异';
            elink.download = fileNamePrefix + "-" + timestamp + ".xlsx";
            elink.style.display = "none";
            var blob = new Blob([content]);
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click();
            document.body.removeChild(elink);
        }
    };
    xmlHttpRequest.send(JSON.stringify(partNumbers));
}
