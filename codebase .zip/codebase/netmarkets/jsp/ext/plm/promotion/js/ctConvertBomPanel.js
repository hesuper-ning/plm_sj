Ext.define('PLM.view.CtConvertBomPanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CtConvertBomPanel',
    border: false,
    autoScroll: false,
    bodyStyle : 'overflow-x:hidden; overflow-y:scroll',
    title: '',
    titleAlign: 'center',
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    id: 'CtConvertBomPanel',
    initComponent: function () {
        this.items = [
            {
                xtype: 'panel',
                header: false,
                collapsible: true,
                split: true,
                autoHeight: true,
                activeTab: 0,
                items: [
                    {
                        items: [tipsPanel, ctConvertBomGrid]
                    }
                ]
            }
        ];
        this.callParent();
    },
    listeners: {
    }
});