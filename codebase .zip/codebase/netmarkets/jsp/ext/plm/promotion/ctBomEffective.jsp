<%@ page import="ext.plm.bom.config.CtBomConfig" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.part.WTPart" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.maturity.PromotionNotice" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        //（成品/半成品、试产专用成品）设计BOM生效流程
        String oid = request.getParameter("oid");
        String currentActKey = "";
        String activityName="";
        String proOid="";
        boolean taskCompleted = false; //任务是否已完成
        boolean partPage = false;//部件页面
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(oid).getObject();
        if(obj instanceof WorkItem){
            WorkItem workItem = (WorkItem) obj;
            Persistable object2 = workItem.getPrimaryBusinessObject().getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            activityName = activity.getName();
            currentActKey = CtBomConfig.getProperty(activityName);
            if(workItem.isComplete()) {
                taskCompleted = true;
            }
            if(object2 instanceof PromotionNotice){
                PromotionNotice promotionNotice = (PromotionNotice)object2;
                proOid = promotionNotice.getPersistInfo().getObjectIdentifier().getId() + "";
            }else if(object2 instanceof WTDocument){
                proOid= CtWTObjectUtil.getVid(object2);
            }
        }else if(obj instanceof WTPart){
            currentActKey = "maintenance_bom_node";
            partPage = true;
        }else if(obj instanceof PromotionNotice){
            proOid = oid.substring(oid.lastIndexOf(":")+1);
        }
        long timestamp = System.currentTimeMillis();
    %>
    <script type="text/javascript">
        var workItemOid = "<%=oid%>";

        //当前节点key
        var currentActKey = "<%=currentActKey%>";

        //当前的任务完成状态
        var taskCompleted = false;
        <%if(taskCompleted){%>
            taskCompleted = true;
        <%}%>

        var proOid ='<%= proOid %>';

        var activityName = "<%=activityName%>";

        var readOnlyPage = false;

        var partPage = false;
        <%if(partPage){%>
            partPage = true;
        <%}%>
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/promotion/js/ctConvertBomFn.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/promotion/js/ctConvertBom.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/promotion/js/ctConvertBomPanel.js?_dc=<%=timestamp%>"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/part/promotion/js/ctChangeImpactConfirmTable.js?_dc=<%System.currentTimeMillis();%>"></script>
</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {
                    region: 'center',
                    items: [{
                        xtype: 'tabpanel',
                        activeTab: 0,
                        items: [
                            {
                                title: '<font style="font-size:12px">业务属性收集与维护</font>',
                                xtype: 'CtConvertBomPanel'
                            }
                            ,{
                                scrollable: true,
                                title: '<font style="font-size:12px">相关变更影响确认</font>',
                                xtype: 'ctChangeImpactConfirmTable'
                            }
                        ]
                    }]
                }
            ]
        });
    });
</script>
</body>
</html>