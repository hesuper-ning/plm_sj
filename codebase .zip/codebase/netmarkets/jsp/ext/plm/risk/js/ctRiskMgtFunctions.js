//===========开始  1.RiskItemStore Store 定义==================


//修改
function updateProblem (tRecord,callbackFn,e,tField,value) {
    // tRecord['createTime']=Ext.util.Format.date(new Date(parseInt(tRecord['proposedTime'])),'Y-m-d H:i:s');
    // tRecord['updateTime']=Ext.util.Format.date(new Date(parseInt(tRecord['proposedTime'])),'Y-m-d H:i:s');
    tRecord['createTime']=null;
    tRecord['updateTime']=null;
    tRecord['version']=null;
    for(var attr in tRecord){
        // console.log(tRecord['plannedFinishDate']!=undefined)
        // if ((attr=='proposedTime'&&tRecord['proposedTime']!=undefined)
        //     ||(attr=='pqaEnsure'&&tRecord['pqaEnsure']!=undefined)||(attr=='plannedFinishDate'&&tRecord['plannedFinishDate']!=undefined)){
        //
        //     tRecord[attr]=Ext.util.Format.date(new Date(tRecord[attr]),'Y-m-d H:i:s');
        //
        // }
        if (attr=='plannedFinishDate'&&tRecord['plannedFinishDate']!=undefined&&tRecord['plannedFinishDate']!='')
           {

            tRecord[attr]=Ext.util.Format.date(new Date(tRecord[attr]),'Y-m-d');
        }

    }
   // if(tRecord['riskHappenedOrNot']!="是"){
   //     if(tField=='currentStatus'||tField=='severity2'||tField=='occurrence2'||
   //         tField=='detection2'||tField=='problemId'){
   //          if(value==undefined||value==null||value==''){
   //              e.set("businessStatus","打开Open");
   //              e.commit();
   //          }
   //     }
   // }

    // alert(JSON.stringify(tRecord));
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/risk/updateRisk/'+oid+'/'+tField,
        method:'POST',
        params:tRecord,
        // params:JSON.stringify(tRecord),
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success"){
                e.commit();
                callbackFn();
            }else{
                alert(obj.message);
            }
        },
        failure: function(response, opts) {

            alert('错误：更新风险表单字段失败，请检查网络！');
            callbackFn();
        }
    });
}
//删除
/**
 * 批量删除内容
 * @param dataArray
 * @param callback
 */
function deleteData(obj,callback) {
    console.log(oid);
    Ext.Ajax.request({
        url: '/Windchill/ptc1/risk/deleteData/'+oid,
        params:JSON.stringify(obj),
        headers: {'Content-Type':'application/json'},
        // params:obj,
        method:'POST',
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message!="success") {
                Ext.Msg.alert("数据删除失败",obj.message);
                // myMask.hide();
            }else{
                // myMask.hide();
                alert("数据删除成功");
                callback();
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'数据删除失败，请检查网络！')
        }
    });
}
/**
 * 判断是否可以删除
 * @param dataArray
 * @param callback
 */
function whetherCanDelete(obj) {
    obj.forEach((item,index,array)=>{
        if(item.owner==userName){
            return true;
        }
    })
    return true;
}



/**
 * 导出的时候获取数据源
 * @param dataArray
 * @param callback
 */
function getSearchData(record) {
    var data = {
        riskId: record.data['riskId'],
        evaluationDept:record.data['evaluationDept'],
        proposedTime:record.data['proposedTime'],
        projectPhase:record.data['projectPhase'],
        riskCategory:record.data['riskCategory'],
        riskDescription:record.data['riskDescription'],
        riskEffect:record.data['riskEffect'],
        severity:record.data['severity'],
        occurrence:record.data['occurrence'],
        detection:record.data['detection'],
        levelOfRisk:record.data['levelOfRisk'],
        responseCategories:record.data['responseCategories'],
        actionsForRisk:record.data['actionsForRisk'],
        ownerDept:record.data['ownerDept'],
        plannedFinishDate:record.data['plannedFinishDate'],
        owner:record.data['owner'],
        currentStatus:record.data['currentStatus'],
        severity2:record.data['severity2'],
        occurrence2:record.data['occurrence2'],
        detection2:record.data['detection2'],
        levelOfRisk2:record.data['levelOfRisk2'],
        businessStatus:record.data['businessStatus'],
        riskHappenedOrNot:record.data['riskHappenedOrNot'],
        pqaEnsure:record.data['pqaEnsure'],
        pqaRemark:record.data['pqaRemark'],
        branchId:record.data['branchId'],
        riskCreatPeople:record.data['riskCreatPeople'],
    };
    return data;
}

//检查风险编号是否正确
function checkRiskNumber(number) {
    var isCorrect = true;
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/checkRiskNumber',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
                isCorrect = false;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return isCorrect;
}

//检查问题编号是否正确
function checkProblemNumber(number) {
    var isCorrect = true;
    Ext.Ajax.request({
        scope:this,
        url: '/Windchill/ptc1/problemMgt/checkProblemNumber',
        method: "GET",
        params: {
            number:number
        },
        async:false,
        success: function(response, opts) {
            var obj = Ext.decode(response.responseText);
            if(!obj['success']) {
                Ext.Msg.alert("错误","填写的编号错误，请确认编号是否正确");
                isCorrect = false;
            }
        },
        failure: function(response, opts) {
            Ext.Msg.alert("错误",'请检查网络！')
        }
    });
    return isCorrect;
}

/**
 * 添加
 */
function save(data) {


    Ext.Ajax.request({
        scope: this,
        url: '/Windchill/ptc1/problemMgt/addProblem',
        params: {
            data: Ext.encode(data),
            imgs: imgs
        },
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if (obj['success']) {
                var problemNumber = obj['problemNumber'];
                var callbackFn = function () {
                };
                // 遍历每一条选中的记录
                Ext.each(ctRiskAssessGridRecords, function(record) {
                    // 修改某个属性的值，例如将 'someField' 设置为 'newValue'
                    record.set('problemId', problemNumber);
                    updateProblem(record.data,callbackFn,record,"problemId",problemNumber);
                });
                Ext.getStore('ctRiskAssessStore').reload()
            } else {
                alert(obj['error']);
            }
        },
        failure: function (response, opts) {
            alert('错误：保存信息失败，请检查网络！');
        }
    }); //~End of Ajax request

}

/*
清空表单的值
 */
function clear() {
    Ext.getCmp('PDMLinkProductName').setValue(""),
    Ext.getCmp('description').setValue(""),
        Ext.getCmp('problemTerritory').setValue(""),
        Ext.getCmp('problemGrade').setValue(""),
        Ext.getCmp('projectPhase').setValue(""),
        Ext.getCmp('optimizeStrategy').setValue(""),
        Ext.getCmp('planFinishDate').setValue(""),
        Ext.getCmp('analysis').setValue(""),
        Ext.getCmp('badProportion').setValue(""),
        Ext.getCmp('problemSource').setValue(""),
        Ext.getCmp('relatedProblemNumber').setValue(""),
        Ext.getCmp('temporaryMeasures').setValue(""),
        Ext.getCmp('creator').setValue(""),
        Ext.getCmp('softwareCharger').setValue(""),
        Ext.getCmp('hardwareCharger').setValue(""),
        Ext.getCmp('craftCharger').setValue(""),
        Ext.getCmp('fabricCharger').setValue(""),
        Ext.getCmp('testCharger').setValue(""),
        Ext.getCmp('qualityCharger').setValue(""),
        Ext.getCmp('purchaseCharger').setValue(""),
        Ext.getCmp('makeCharger').setValue(""),
        Ext.getCmp('bazaarCharger').setValue(""),
        Ext.getCmp('elseCharger').setValue(""),
    Ext.getCmp('affirmCheck').setValue(""),
    Ext.getCmp('pqaCheck').setValue(""),
        Ext.getCmp('projectNumber').setValue(""),
        Ext.getCmp('projectName').setValue(""),
        Ext.getCmp('summaryOfIssues').setValue("")
}




