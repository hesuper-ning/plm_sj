/**
 * 风险统计表单Grid
 */
Ext.define('Plm.view.ctRiskReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctRiskReport',
    border: false,
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        Ext.define('ctRiskAssessModel', {
            extend: 'Ext.data.Model',
            fields:['id' ,'riskId','evaluationDept','riskCreatPeople','proposedTime','riskCategory','riskDescription','riskEffect','severity','occurrence',
                'detection','levelOfRisk','responseCategories','actionsForRisk','ownerDept','owner','plannedFinishDate','currentStatus','severity2',
                'occurrence2' ,'detection2','levelOfRisk2','businessStatus','riskHappenedOrNot','pqaEnsure','pqaRemark','branchId','creator','whetherPass','createTime','projectPhase','projectId','projectNumber','projectName','projectStatus'],
            idProperty: 'id'
        });
        Ext.define('ctAllUserModel', {
            extend: 'Ext.data.Model',
            fields:['no' ,'riskId']
        });

        var ctRiskAssessStore = Ext.create('Ext.data.Store', {
            // pageSize: 1,
            model: 'ctRiskAssessModel',
            id: 'ctRiskAssessStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/riskReport/getDateBySearch',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });

        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var riskIdText = '风险ID';
        var evaluationDeptText = '评价部门';
        var riskCreatPeopleText = '风险识别人';
        var proposedTimeText = '提出时间';
        var projectPhaseText='项目阶段';
        var riskCategoryText='风险类型';
        var riskDescriptionText='风险描述';
        var riskEffectText='潜在风险影响、失效后果';
        var severityText='严重程度(S)';
        var occurrenceText='发生概率(O)';
        var detectionText='探测度(D)';
        // var riskRateText='风险系数RPN=S*O*D';
        var levelOfRiskText='风险优先级AP';
        var responseCategoriesText='应对措施类别';
        var actionsForRiskText='风险应对措施';
        var ownerDeptText='责任部门';
        var ownerText='责任人Owner';
        var plannedFinishDateText='预计完成日期';
        var whetherPassText='是否驳回';

        var currentStatusText='措施实施进展';
        var severity2Text='严重程度(S)';
        var occurrence2Text='发生概率(O)';
        var detection2Text='探测度(D)';
        // var riskRate2Text='风险系数';
        var levelOfRisk2Text='风险优先级AP';
        var problemIdText='问题ID';

        var riskHappenedOrNotText='风险是否发生';
        var businessStatusText='当前状态';
        var pqaEnsureText='实际完成时间';
        var pqaRemarkText='PQA备注';
        var branchIdText='流程ID';
        //可编辑项

        // }
        var click="1";
        //导入panel
        var uploadForm =  new Ext.form.Panel({
            layout:'form',
            id:'uploadForm',
            name:'uploadForm',
            width:450,
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            border:0,
            tbar:[{
                xtype: 'filefield',
                name: 'riskAssessFile',
                id:'riskAssessFile',
                msgTarget: 'side',
                fieldLabel: '上传Excel文件',
                width: 280,
                anchor: '100%',
                buttonText: '选择文件..',
                buttonOnly: false,
                buttonMargin : '5 5 5 5'
            },{
                xtype:'button',
                padding: '5 5 5 5',
                id:'technic_submit',
                //disabled: existManufacturingViewPart?false:true,
                text: '开始导入',
                handler:function() {
                    var mainForm = Ext.getCmp('uploadForm').getForm();
                    var furl = "";  //文件物理地址
                    var fname=""; //文件名称
                    furl = Ext.getCmp("riskAssessFile").getValue();
                    //alert(furl);
                    if(furl == "") {
                        alert("请先选择文件！");
                        return false;
                    }

                    mainForm.submit({
                        url:'/Windchill/ptc1/risk/importRiskAssess?proOid='+proOid+'&oid='+oid+'&activityName='+activityName,
                        waitMsg : '正在导入......',
                        waitTitle : '请等待',
                        // method : 'POST',
                        success: function(form,action) {
                            var obj = action.result;
                            if(obj.success) {
                                alert(obj.msg);
                                Ext.getStore('ctRiskAssessStore').reload();
                            } else {
                                alert(obj.msg);
                                Ext.getStore('ctRiskAssessStore').reload();
                            }
                            uploadPlanWindow.close();
                        },
                        failure: function(form,action) {
                            var obj = action.result;
                            alert(obj.msg);
                        },
                        scope : this
                    });
                }
            }]
        });
        //导入窗口
        var uploadPlanWindow = new Ext.create('Ext.Window', {
            title: '批量导入问题',
            // width: 430,
            autoHeight : true,
            autoWidth : true,
            closeAction: 'hidden',
            y: '10%',
            id:'uploadProblemWindow',
            constrain: true,
            modal:true,
            layout:'fit',
            //border : 0,
            items: uploadForm
        });

        //==========================combe start
        var problemIdCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            fieldLabel: '风险是否发生',
            editable : true,
            margin: '0 10 0 0',
            // forceSelection: true, //forceSelection 是否能够手填
            id: 'problemIdCombo',
            name: 'problemIdCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["是", "是"], ["否", "否"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var riskApCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            fieldLabel: '风险优先级AP',
            editable : true,
            margin: '0 10 0 0',
            // forceSelection: true, //forceSelection 是否能够手填
            id: 'riskApCombo',
            name: 'riskApCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["H", "H"], ["M", "M"],["L", "L"],["Error", "Error"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });

        var statusCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : true,
            fieldLabel: '当前状态',
            margin: '0 10 0 0',
            // forceSelection: true, //forceSelection 是否能够手填
            id: 'statusCombo',
            name: 'statusCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["打开Open", "打开Open"],["关闭Close", "关闭Close"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var riskCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : true,
            fieldLabel: '风险类型',
            margin: '0 10 0 0',
            // forceSelection: true, //forceSelection 是否能够手填
            id: 'riskCombo',
            name: 'riskCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["需求不确定", "需求不确定"], ["进度要求", "进度要求"], ["新设计", "新设计"],["新工艺", "新工艺"],
                    ["新物料", "新物料"], ["新应用", "新应用"], ["新过程", "新过程"],["新供应商", "新供应商"],
                    ["法规要求", "法规要求"], ["人力要求", "人力要求"], ["成本要求", "成本要求"],["售后要求", "售后要求"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var ctAllUserStore = Ext.create('Ext.data.Store', {
            model: 'ctAllUserModel',
            id: 'ctAllUserStore',
            autoSync: true,//同步更新
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/hr/getAllUser',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });
        // var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
        //     storeId: 'allUserStore_projectPlan'
        // });
        var allUserCombo_projectPlan = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            fieldLabel: '责任人',
            margin: '0 10 0 0',
            editable : true,
            allowBlank : true,
            // triggerAction: 'all',
            queryMode: 'local',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'riskOwner',
            // name: 'hiddenName',
            mode: 'remote',
            store: ctAllUserStore,
            valueField: 'no',
            displayField: 'userFullName',
        });

        var riskCreatPeople = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            fieldLabel: '风险识别人',
            margin: '0 10 0 0',
            editable : true,
            allowBlank : true,
            queryMode: 'local',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'riskCreatPeople',
            mode: 'remote',
            store: ctAllUserStore,
            valueField: 'userFullName',
            displayField: 'userFullName',
        });

        var phaseCombo = new Ext.form.field.ComboBox({
            anyMatch: true,
            editable : true,
            // forceSelection: true, //forceSelection 是否能够手填
            fieldLabel: '项目阶段',
            margin: '0 10 0 0',
            id: 'phaseCombo',
            name: 'phaseCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"],["TR4-TR4A", "TR4-TR4A"],
                    ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });

        //======start


        Ext.define('PLM.common.CtProblemNumberCombo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtProblemNumberCombo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            displayField: 'problemNumber',
            valueField: 'problemNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true
        });
        //======end
        Ext.define('PLM.common.CtProblemNumberStore',{
            extend:'Ext.data.Store',
            alias:'widget.CtProblemNumberStore',
            fields:['problemNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/problemMgt/getProblemByNumber?oid=' + " " ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });

        Ext.define('PLM.common.CtProblemNumberCombo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtProblemNumberCombo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            displayField: 'problemNumber',
            valueField: 'problemNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true
        });
        //用户下拉列表
        // var allUserStore_risk = Ext.create('PLM.common.CtAllUserStore',{
        //     storeId:'allUserStore_risk'
        // });

        // var allUserCombo_projectPlan = Ext.create('PLM.hr.CtAllUserCombo',{
        //     store:allUserStore_projectPlan
        // });

        //问题下拉列表
        var problemNumberStore = Ext.create('PLM.common.CtProblemNumberStore',{
            storeId:'problemNumberStore'
        });
        var problemNumberCombo = Ext.create('PLM.common.CtProblemNumberCombo',{
            store:problemNumberStore
        });

        //==========================combin end
        var ctRiskAssessGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: ctRiskAssessStore,
            id: 'ctRiskAssessGrid',
            title:'风险评估表单',
            // margin: '20 10 20 10',
            // forceFit: true,
            height:524,
            // autoScroll: true,
            // region: 'center',
            // height: '100%',
            listeners: {
                'beforeedit':function (editor, e, eOpts) {

                },
            },
            selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"MULTI",showHeaderCheckbox:true}),
            viewConfig: {enableTextSelection: false, forceFit: false},
            columns: [
                {xtype: 'rownumberer', text: '序号', width: 50, align: 'center'},
                {text: 'id', dataIndex: 'id', width: 120, menuDisabled: true, hidden: true, align: 'center'},
                {text: '风险提出', columns: [
                        {text: "项目编号", dataIndex: 'projectId',width: 120, menuDisabled: true,  align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: "项目名称", dataIndex: 'projectName',width: 100, menuDisabled: true,  align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        // {text: "项目状态", dataIndex: 'ProjectPhase',width: 100, menuDisabled: true,  align: 'center'},
                        {text: projectPhaseText, dataIndex: 'projectPhase', editor:null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},

                        {text: riskIdText, dataIndex: 'riskId',width: 100, menuDisabled: true,  align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: riskCreatPeopleText, dataIndex: 'riskCreatPeople',width: 120, menuDisabled: true,  align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: evaluationDeptText, dataIndex: 'evaluationDept',
                            // editor:allowEdit?deptCombo:null,
                            editor:null,
                            width: 100, menuDisabled: true
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: proposedTimeText, dataIndex: 'proposedTime', width: 120,
                            // editor:allowEdit?new Ext.form.DateField({ format: 'Y-m-d',}):null ,
                            editor:null ,
                            menuDisabled: true,align: 'center',
                            renderer: function(value,metaData,record,row,col,store){
                                if(value){
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                    value=value.substring(0,10);

                                }
                                return value;
                            }},
                        {text: riskCategoryText, dataIndex: 'riskCategory',editor: null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: riskDescriptionText, dataIndex: 'riskDescription',editor:null, width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            },
                            // renderer: function (value, meta, record) {
                            //     //自动换行
                            //     meta.style = 'white-space:normal;word-break:break-all;';
                            //     return value;
                            // }
                        },
                        {text: riskEffectText, dataIndex: 'riskEffect', width: 140,editor:null, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            },},
                        {text: severityText, dataIndex: 'severity', editor: null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: occurrenceText, dataIndex: 'occurrence', editor:  null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: detectionText, dataIndex: 'detection', editor: null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        // {text: riskRateText, dataIndex: 'riskRate', editor: allowEdit?'textfield':null,width: 100, menuDisabled: true, align: 'center'},
                        {text: levelOfRiskText, dataIndex: 'levelOfRisk', editor:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {

                                if (value != null && value != undefined && value != '') {
                                    let whetherError= value.substring(0,5);
                                    let levelOfRiskKey ;
                                    let levelOfRiskDes ;
                                    if(whetherError=="Error"){
                                        levelOfRiskKey = value.substring(0,5);
                                        levelOfRiskDes = value.substring(5);
                                    }else{
                                        levelOfRiskKey = value.substring(0,1);
                                        levelOfRiskDes = value.substring(1);
                                    }

                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+levelOfRiskDes+"'";
                                    if(levelOfRiskKey=='H'||levelOfRiskKey=='M'||levelOfRiskKey=='Error'){
                                        levelOfRiskKey= '<span style="color:#FF0000;">'+levelOfRiskKey+'</span>';
                                    }
                                    return levelOfRiskKey;
                                }
                                return value;
                            },},
                        {text: responseCategoriesText, dataIndex: 'responseCategories', editor: null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: actionsForRiskText, dataIndex: 'actionsForRisk', editor: null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: ownerText, dataIndex: 'owner', editor: null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value, meta, record) {
                                // sleep(1000);
                                let displayName = value;
                                if(value){
                                    let riskByPurchaseAsscessStore = allUserCombo_projectPlan.getStore();
                                    riskByPurchaseAsscessStore.each(function(rec){
                                        if(rec.get('no') == value){
                                            displayName =  rec.get('userFullName');
                                        }
                                    });
                                }
                                return displayName;
                            }
                        },
                        {text: ownerDeptText, dataIndex: 'ownerDept',
                            // editor: allowEdit||riskFollowAllowEdit?'textfield':null,
                            editor: null,
                            width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: plannedFinishDateText, dataIndex: 'plannedFinishDate',width: 100, editor:null,menuDisabled: true,
                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                return selfDateFormat(value);
                            } },
                        {text: whetherPassText, dataIndex: 'whetherPass', editor:null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                    ], menuDisabled: true,
                },
                {text: '风险跟进', columns: [
                        {text: currentStatusText, dataIndex: 'currentStatus', editor: null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }
                        },
                        {text: severity2Text, dataIndex: 'severity2', editor:null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: occurrence2Text, dataIndex: 'occurrence2',  editor:null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: detection2Text, dataIndex: 'detection2',  editor:null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        // {text: riskRate2Text, dataIndex: 'riskRate2',  editor:  allowEdit?numberCombo:null,tooltip:detectionD,width: 120, menuDisabled: true, align: 'center'},
                        {text: levelOfRisk2Text, dataIndex: 'levelOfRisk2', editor:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    let whetherError= value.substring(0,5);
                                    let levelOfRiskKey ;
                                    let levelOfRiskDes ;
                                    if(whetherError=="Error"){
                                        levelOfRiskKey = value.substring(0,5);
                                        levelOfRiskDes = value.substring(5);
                                    }else{
                                        levelOfRiskKey = value.substring(0,1);
                                        levelOfRiskDes = value.substring(1);
                                    }

                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+levelOfRiskDes+"'";
                                    if(levelOfRiskKey=='H'||levelOfRiskKey=='M'||levelOfRiskKey=='Error'){
                                        levelOfRiskKey= '<span style="color:#FF0000;">'+levelOfRiskKey+'</span>';
                                    }
                                    return levelOfRiskKey;
                                }
                                return value;
                            },},
                        {text: riskHappenedOrNotText, dataIndex: 'riskHappenedOrNot', editor:null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: problemIdText, dataIndex: 'problemId', editor: null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},

                    ], menuDisabled: true,
                },
                {text: '风险确认', columns: [
                        {text: businessStatusText, dataIndex: 'businessStatus', editor:null,width: 120, menuDisabled: true, align: 'center'
                            ,renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: pqaEnsureText, dataIndex: 'pqaEnsure',
                            // editor: riskPQASureAllowEdit?new Ext.form.DateField({ format: 'Y-m-d',}):null,
                            editor:null,
                            menuDisabled: true,align: 'center',
                            renderer: function (value) {

                                if(value!=null){
                                    value=value.trim();
                                }else {
                                    value='';
                                }
                                return value;

                            }},
                        {text: pqaRemarkText, dataIndex: 'pqaRemark', editor:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: branchIdText, dataIndex: 'branchId', editor: null,width: 120, menuDisabled: true, align: 'center',hidden: true
                            },
                    ], menuDisabled: true,
                },
            ],
            bbar: Ext.create('Ext.PagingToolbar', {
                store: Ext.data.StoreManager.lookup('ctRiskAssessStore'),
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空",
                items:[{
                    text: '查询全部',
                    scope: this,
                    id:'queryAll',
                    handler:function(){
                        ctRiskAssessStore.pageSize=ctRiskAssessStore.getTotalCount();
                        ctRiskAssessStore.currentPage = 1;
                        // refreshAllRequireStore();
                        refreshAllRequireStore(false,25,1);
                        Ext.getCmp("queryAll").hide();
                        Ext.getCmp("pageQuery").show();
                    }
                },{
                    text: '分页查询',
                    scope: this,
                    id:'pageQuery',
                    hidden:true,
                    handler:function(){
                        ctRiskAssessStore.pageSize=25;
                        refreshRequireStore(true,25,1);
                        // refreshRequireStore();
                        Ext.getCmp("pageQuery").hide();
                        Ext.getCmp("queryAll").show();
                    }
                }]
            }),//~End bbar
            tbar: [{
                iconCls: 'icon-excelExport',
                // xtype: 'button',
                id: "excelOutputData",
                text: 'Excel导出',
                handler : function () {
                    this.exportReport();
                },
                scope : this
            }]

        });

        ctRiskAssessGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var value = e.value; //得到修改列
                updateProblem(tRecord.data,callbackFn,tRecord,tField,value);
            });
        var riskReportForm = {
            title: '查询参数',
            xtype: 'fieldset',
            region: 'center',
            align: 'center',
            id: 'mainForm',
            width: '98%',
            hidden: false,
            hideLabel: true,
            frame: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '10 0 0 10',
                items: [{
                    margin: '0 10 0 0',
                    fieldLabel: '风险编号',
                    id: 'riskNumber',
                    width: 275,
                }, {
                    margin: '0 10 0 0',
                    fieldLabel: '项目名称',
                    labelWidth: 100,
                    id: 'projectName',
                    width: 275,
                }, {
                    xtype:riskCreatPeople,
                    id: 'riskPeople',
                    width: 275,
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '10 0 0 10',
                items: [{
                    margin: '0 10 0 0',
                    fieldLabel: '项目阶段',
                    xtype:phaseCombo,
                    width: 275,
                }, {
                    margin: '0 10 0 0',
                    xtype:riskCombo,
                    id: 'riskStatus',
                    width: 275,
                }, {
                    margin: '0 10 0 0',
                    xtype:riskApCombo,
                    id: 'riskAp',
                    width: 275,
                }]
            },{
                xtype: 'container',
                layout: 'hbox',
                defaultType: 'textfield',
                margin: '10 0 0 10',
                items: [{
                    margin: '0 10 0 0',
                    xtype: allUserCombo_projectPlan,
                    id: 'owner',
                    width: 275,
                },{
                    margin: '0 10 0 0',
                    xtype: problemIdCombo,
                    text: '风险是否发生',
                    // fieldLabel: '风险是否发生',
                    id: 'riskWhetherHappen',
                    width: 275,
                },{
                    margin: '0 10 0 0',
                    // xtype: 'textfield',
                    fieldLabel: '问题ID',
                    id: 'problemId',
                    width: 275,
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                margin: '10 0 0 10',
                items: [{
                    id: 'nowStatus',
                    xtype: statusCombo,
                    margin: '0 5 0 0',
                    width: 275,
                },{
                    text: '查询',
                    iconCls : 'icon-search',
                    name: 'phone',
                    margin: '10 100 0 10',
                    xtype: 'button',
                    width: 75,
                    handler: function () {
                        doSearch()
                    }
                }]
            }, ctRiskAssessGrid],
    };
        this.items = [ riskReportForm];

        this.callParent();
    },

    exportReport: function() {
        let data = getDate();
        data['isPageQuery']=false;
        data['limit']=25;
        data['page']=1;
        window.location.href = '/Windchill/ptc1/riskReport/exportRiskAssess?data='+Ext.encode(data);
    },
    listeners: {
        'afterrender': function () {
        },
        'beforerender': function () {
            Ext.getStore('ctAllUserStore').load({
                params: { },
                callback: function (records, operation, success) {
                    if(success){
                        console.log("=====true===success=====")
                        let data = getDate();
                        data['isPageQuery']=true;
                        data['limit']=25;
                        data['page']=1;
                        Ext.getStore('ctRiskAssessStore').load({
                            params: data,
                            callback: function (records, operation, success) {
                                if (!success) {
                                    if (typeof (operation.error) == 'string') {
                                        alert(operation.error);
                                    } else {
                                        // alert('查询超时！请重试！')
                                    }
                                }
                            }
                        });
                    }
                    if (!success) {
                        console.log("=====false===success=====")
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            // alert('查询超时！请重试！')
                        }
                    }
                }
            });
        },

    },

});

function refreshRequireStore(isPage,limit,page){
    let data = getDate();
    data['isPageQuery']=isPage;
    // data['limit']=limit;
    // data['page']=page;
    Ext.getStore('ctRiskAssessStore').load({
        params: data,
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询风险报表失败，请联系管理员！');
            }
        }
    });
}
function refreshAllRequireStore(isPage,limit,page){
    let data = getDate();
    data['isPageQuery']=isPage;
    data['limit']=limit;
    data['page']=page;
    Ext.getStore('ctRiskAssessStore').load({
        params: data,
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询风险报表失败，请联系管理员！');
            }
        }
    });
}


//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}

function getDate() {
    var data = {
        riskNumber: Ext.getCmp('riskNumber').getValue(),
        projectName: Ext.getCmp('projectName').getValue(),
        riskPeople: Ext.getCmp('riskCreatPeople').getValue(),
        projectStep: Ext.getCmp('phaseCombo').getValue(),
        riskStatus: Ext.getCmp('riskCombo').getValue(),
        riskAp: Ext.getCmp('riskApCombo').getValue(),
        owner: Ext.getCmp('riskOwner').getValue(),
        riskWhetherHappen: Ext.getCmp('problemIdCombo').getValue(),
        problemId: Ext.getCmp('problemId').getValue(),
        nowStatus: Ext.getCmp('statusCombo').getValue(),

    };
    return data;
}
function doSearch(){
    let data = getDate();
    data['isPageQuery']=false;
    data['limit']=25;
    data['page']=1;
    Ext.getStore('ctRiskAssessStore').load({
        params: data,
        callback: function (records, operation, success) {
            if (!success) {
                alert('查询风险报表失败，请联系管理员！');
            }
        }
    });

}
////////////////////Function Area//////////////////////////////





