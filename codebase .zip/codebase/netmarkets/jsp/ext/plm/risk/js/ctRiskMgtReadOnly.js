/**
 * 风险评估表单Grid---只读页面
 */
Ext.define('Plm.view.ctRiskMgt', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctRiskMgt',
    border: false,
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {
        allowEdit = false;
        riskFollowAllowEdit = false;
        riskSureAllowEdit = false;
        riskPQASureAllowEdit = false;
        Ext.define('ctRiskAssessModel', {
            extend: 'Ext.data.Model',
            fields:['id' ,'riskId','evaluationDept','riskCreatPeople','proposedTime','projectPhase','riskCategory','riskDescription','riskEffect','severity','occurrence',
                'detection','levelOfRisk','responseCategories','actionsForRisk','ownerDept','owner','plannedFinishDate','currentStatus','severity2',
                'occurrence2' ,'detection2','levelOfRisk2','businessStatus','riskHappenedOrNot','pqaEnsure','pqaRemark','branchId','creator','whetherPass','createTime'],
            idProperty: 'id'
        });
        Ext.define('ctAllUserModel', {
            extend: 'Ext.data.Model',
            fields:['no' ,'riskId']
        });
        //添加 导入 删除 隐藏
        console.log(activityName.indexOf("录入")!=-1)


        var addHidden=allowEdit&&(!riskSureAllowEdit&&!riskFollowAllowEdit&&!riskPQASureAllowEdit);
        //显示个人  隐藏
        var showMyselfHidden=(allowEdit||riskSureAllowEdit)&&!riskFollowAllowEdit&&!riskPQASureAllowEdit;

        var me = this;
        var severity="";
        var occurrence="";
        var detection="";
        var severity2="";
        var occurrence2="";
        var detection2="";

        var ctRiskAssessStore = Ext.create('Ext.data.Store', {
            // pageSize: 1,
            model: 'ctRiskAssessModel',
            id: 'ctRiskAssessStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/risk/getDataByBranchId',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });
        // ctRiskAssessStore.on('beforeload', function(store, options) {
        //     var data = {
        //         proOid:proOid,
        //         oid:oid,
        //         owner:name,
        //         isPageQuery:isPageQuery,
        //         activityName:activityName,
        //     };
        //     Ext.apply(ctRiskAssessStore.proxy.extraParams, data);
        // });
        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var riskIdText = '风险ID';
        var evaluationDeptText = '评价部门';
        var riskCreatPeopleText = '风险识别人';
        var proposedTimeText = '提出时间';
        var projectPhaseText='项目阶段';
        var riskCategoryText='风险类型';
        var riskDescriptionText='风险描述';
        var riskEffectText='潜在风险影响、失效后果';
        var severityText='严重程度(S)';
        var occurrenceText='发生概率(O)';
        var detectionText='探测度(D)';
        // var riskRateText='风险系数RPN=S*O*D';
        var levelOfRiskText='风险优先级AP';
        var responseCategoriesText='应对措施类别';
        var actionsForRiskText='风险应对措施';
        var ownerDeptText='责任部门';
        var ownerText='责任人Owner';
        var plannedFinishDateText='预计完成日期';
        var whetherPassText='是否驳回';

        var currentStatusText='措施实施进展';
        var severity2Text='严重程度(S)';
        var occurrence2Text='发生概率(O)';
        var detection2Text='探测度(D)';
        // var riskRate2Text='风险系数';
        var levelOfRisk2Text='风险优先级AP';
        var problemIdText='问题ID';

        var riskHappenedOrNotText='风险是否发生';
        var businessStatusText='当前状态';
        var pqaEnsureText='实际完成时间';
        var pqaRemarkText='PQA备注';
        var branchIdText='流程ID';
        //可编辑项
        if(allowEdit) {
            //对应要加标的选项
            // riskIdText = redStarFlag+blueFlagStart+ riskIdText +blueFlagEnd;
            // evaluationDeptText =redStarFlag+ blueFlagStart+ evaluationDeptText +blueFlagEnd;
            // proposedTimeText =redStarFlag+ blueFlagStart+ proposedTimeText +blueFlagEnd;
            projectPhaseText =redStarFlag+blueFlagStart+ projectPhaseText +blueFlagEnd;
            riskCategoryText =redStarFlag+blueFlagStart+ riskCategoryText +blueFlagEnd;
            riskDescriptionText =redStarFlag+blueFlagStart+ riskDescriptionText +blueFlagEnd;
            riskEffectText =redStarFlag+blueFlagStart+ riskEffectText +blueFlagEnd;
            severityText =redStarFlag+blueFlagStart+ severityText +blueFlagEnd;
            occurrenceText =redStarFlag+blueFlagStart+ occurrenceText +blueFlagEnd;
            detectionText =redStarFlag+blueFlagStart+ detectionText +blueFlagEnd;
            // riskRateText =redStarFlag+blueFlagStart+ riskRateText +blueFlagEnd;
            // levelOfRiskText =redStarFlag+blueFlagStart+ levelOfRiskText +blueFlagEnd;
            responseCategoriesText =redStarFlag+blueFlagStart+ responseCategoriesText +blueFlagEnd;
            actionsForRiskText =redStarFlag+blueFlagStart+ actionsForRiskText +blueFlagEnd;
        }
        if(allowEdit||riskFollowAllowEdit){
            // ownerDeptText =redStarFlag+blueFlagStart+ ownerDeptText +blueFlagEnd;
            ownerText =redStarFlag+blueFlagStart+ ownerText +blueFlagEnd;
            plannedFinishDateText =redStarFlag+blueFlagStart+ plannedFinishDateText +blueFlagEnd;
        }
        if(riskFollowAllowEdit){
            whetherPassText =blueFlagStart+ whetherPassText +blueFlagEnd;
        }
        if(riskSureAllowEdit){
            currentStatusText =redStarFlag+blueFlagStart+ currentStatusText +blueFlagEnd;
            severity2Text =redStarFlag+blueFlagStart+ severity2Text +blueFlagEnd;
            occurrence2Text =redStarFlag+blueFlagStart+ occurrence2Text +blueFlagEnd;
            detection2Text =redStarFlag+blueFlagStart+ detection2Text +blueFlagEnd;
            // riskRate2Text =redStarFlag+blueFlagStart+ riskRate2Text +blueFlagEnd;
            levelOfRisk2Text =redStarFlag+blueFlagStart+ levelOfRisk2Text +blueFlagEnd;
            riskHappenedOrNotText =redStarFlag+blueFlagStart+ riskHappenedOrNotText +blueFlagEnd;
            problemIdText =redStarFlag+blueFlagStart+ problemIdText +blueFlagEnd;
        }
        if(riskPQASureAllowEdit){
            businessStatusText =redStarFlag+blueFlagStart+ businessStatusText +blueFlagEnd;
            // pqaEnsureText =redStarFlag+blueFlagStart+ pqaEnsureText +blueFlagEnd;
            pqaRemarkText =redStarFlag+blueFlagStart+ pqaRemarkText +blueFlagEnd;
        }
        // }
        var click="1";
        //导入panel
        var uploadForm =  new Ext.form.Panel({
            layout:'form',
            id:'uploadForm',
            name:'uploadForm',
            width:450,
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            border:0,
            tbar:[{
                xtype: 'filefield',
                name: 'riskAssessFile',
                id:'riskAssessFile',
                msgTarget: 'side',
                fieldLabel: '上传Excel文件',
                width: 280,
                anchor: '100%',
                buttonText: '选择文件..',
                buttonOnly: false,
                buttonMargin : '5 5 5 5'
            },{
                xtype:'button',
                padding: '5 5 5 5',
                id:'technic_submit',
                //disabled: existManufacturingViewPart?false:true,
                text: '开始导入',
                handler:function() {
                    var mainForm = Ext.getCmp('uploadForm').getForm();
                    var furl = "";  //文件物理地址
                    var fname=""; //文件名称
                    furl = Ext.getCmp("riskAssessFile").getValue();
                    //alert(furl);
                    if(furl == "") {
                        alert("请先选择文件！");
                        return false;
                    }

                    mainForm.submit({
                        url:'/Windchill/ptc1/risk/importRiskAssess?proOid='+proOid+'&oid='+oid+'&activityName='+activityName,
                        waitMsg : '正在导入......',
                        waitTitle : '请等待',
                        // method : 'POST',
                        success: function(form,action) {
                            var obj = action.result;
                            if(obj.success) {
                                alert(obj.msg);
                                Ext.getStore('ctRiskAssessStore').reload();
                            } else {
                                alert(obj.msg);
                                Ext.getStore('ctRiskAssessStore').reload();
                            }
                            uploadPlanWindow.close();
                        },
                        failure: function(form,action) {
                            var obj = action.result;
                            alert(obj.msg);
                        },
                        scope : this
                    });
                }
            }]
        });
        //导入窗口
        var uploadPlanWindow = new Ext.create('Ext.Window', {
            title: '批量导入问题',
            // width: 430,
            autoHeight : true,
            autoWidth : true,
            closeAction: 'hidden',
            y: '10%',
            id:'uploadProblemWindow',
            constrain: true,
            modal:true,
            layout:'fit',
            //border : 0,
            items: uploadForm
        });

        //==========================combe start
        var severityS='严重度S：分值越高，说明越严重；9-10分，不安全；7-8分，丧失基本功能；5-6分，不舒服不方便；  2-4分，能感知到的影响；1分，不影响。';
        var occurrenceO='发生度O：分值越高，说明越容易发生；9-10分，不可避免；7-8分，可能重复失效；4-6分，可能偶尔失效；  2-3分，很少失效；1分，不可能失效';
        var detectionD='探测度D：分值越高，说明越不容易检验出；8-10分，不能确定；6-7分，确定能力低；4-5分，确定能力中等；   2-3分，确定度高；1分，完全确定';
        var whetherPassCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'whetherPassCombo',
            name: 'whetherPassCombo',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["驳回", "驳回"], ["通过", "通过"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo',
            name: 'numberCombo',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo2 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo2',
            name: 'numberCombo2',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo3 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo3',
            name: 'numberCombo3',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo4 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo4',
            name: 'numberCombo4',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo5 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo5',
            name: 'numberCombo5',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo6 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo6',
            name: 'numberCombo6',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var phaseCombo = new Ext.form.field.ComboBox({
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'phaseCombo',
            name: 'phaseCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"],["TR4-TR4A", "TR4-TR4A"],
                    ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var riskCombo = new Ext.form.field.ComboBox({
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'riskCombo',
            name: 'riskCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["需求不确定", "需求不确定"], ["进度要求", "进度要求"], ["新设计", "新设计"],["新工艺", "新工艺"],
                    ["新物料", "新物料"], ["新应用", "新应用"], ["新过程", "新过程"],["新供应商", "新供应商"],
                    ["法规要求", "法规要求"], ["人力要求", "人力要求"], ["成本要求", "成本要求"],["售后要求", "售后要求"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var deptCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'deptCombo',
            name: 'deptCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["产品管理", "产品管理"], ["项目管理", "项目管理"], ["硬件", "硬件"],["软件", "软件"],
                    ["结构", "结构"], ["测试", "测试"], ["产品工程", "产品工程"],["采购", "采购"],
                    ["制造", "制造"], ["PQA", "PQA"], ["质控", "质控"],["技术支持", "技术支持"],
                    ["销售", "销售"],["财务", "财务"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var problemIdCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : true,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'problemIdCombo',
            name: 'problemIdCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["是", "是"], ["否", "否"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var statusCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'statusCombo',
            name: 'statusCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["打开Open", "打开Open"],["关闭Close", "关闭Close"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var responseCategoriesCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'responseCategoriesCombo',
            name: 'responseCategoriesCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["规避Evade", "规避Evade"], ["转嫁Shift", "转嫁Shift"],["缓解Relieve", "缓解Relieve"],["接受Accept", "接受Accept"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        //用户下拉列表
        // var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
        //     storeId: 'allUserStore_projectPlan'
        // });
        var ctAllUserStore = Ext.create('Ext.data.Store', {
            model: 'ctAllUserModel',
            id: 'ctAllUserStore',
            autoSync: true,//同步更新
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/hr/getAllUser',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });
        // var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
        //     storeId: 'allUserStore_projectPlan'
        // });
        var allUserCombo_projectPlan = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : true,
            allowBlank : true,
            // triggerAction: 'all',
            queryMode: 'local',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'hiddenName',
            // name: 'hiddenName',
            mode: 'remote',
            store: ctAllUserStore,
            valueField: 'no',
            displayField: 'userFullName',

        });

        //======start


        Ext.define('PLM.common.CtProblemNumberCombo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtProblemNumberCombo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            displayField: 'problemNumber',
            valueField: 'problemNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true
        });
        //======end
        Ext.define('PLM.common.CtProblemNumberStore',{
            extend:'Ext.data.Store',
            alias:'widget.CtProblemNumberStore',
            fields:['problemNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/problemMgt/getProblemByNumber?oid=' + oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });

        Ext.define('PLM.common.CtProblemNumberCombo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtProblemNumberCombo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            displayField: 'problemNumber',
            valueField: 'problemNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true
        });
        //用户下拉列表
        // var allUserStore_risk = Ext.create('PLM.common.CtAllUserStore',{
        //     storeId:'allUserStore_risk'
        // });

        // var allUserCombo_projectPlan = Ext.create('PLM.hr.CtAllUserCombo',{
        //     store:allUserStore_projectPlan
        // });

        //问题下拉列表
        var problemNumberStore = Ext.create('PLM.common.CtProblemNumberStore',{
            storeId:'problemNumberStore'
        });
        var problemNumberCombo = Ext.create('PLM.common.CtProblemNumberCombo',{
            store:problemNumberStore
        });



        //==========================combin end
        var ctRiskAssessGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: ctRiskAssessStore,
            id: 'ctRiskAssessGrid',
            title:'风险评估表单',
            // margin: '20 10 20 10',
            // forceFit: true,
            height:524,
            // autoScroll: true,
            // region: 'center',
            // height: '100%',
            listeners: {
                'beforeedit':function (editor, e, eOpts) {
                    severity=e.record.get("severity");
                    occurrence=e.record.get("occurrence");
                    detection=e.record.get("detection");
                    severity2=e.record.get("severity2");
                    occurrence2=e.record.get("occurrence2");
                    detection2=e.record.get("detection2");
                    let riskHappenedOrNot=e.record.get("riskHappenedOrNot");
                    let businessStatus=e.record.get("businessStatus");
                    let pqaEnsure=e.record.get("pqaEnsure");
                    var data=e.record;
                    var tField = e.field; //得到修改列
                    if(userName!='wcadmin'){
                        if(!riskSureAllowEdit&&!riskFollowAllowEdit&&!riskPQASureAllowEdit&&data.get("creator")!=name){
                            return false;
                        }
                        if(riskSureAllowEdit&&data.get("owner")!=name){
                            return false;
                        }
                    }
                    //风险已发生为是，不能编辑当前状态
                    if(riskHappenedOrNot==="是"){
                        if(tField==="businessStatus"||tField==="pqaEnsure"){
                            return false;
                        }
                    }
                    //pqa确认节点，如果当前状态为‘关闭Close’ 不能编辑
                    if(riskSureAllowEdit&&businessStatus==="关闭Close"){
                        if(tField==="problemId"||tField==="riskHappenedOrNot"){
                        }else {
                            return false;

                        }
                    }
                },
            },
            selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"MULTI",showHeaderCheckbox:true}),
            viewConfig: {enableTextSelection: true, forceFit: false},
            columns: [
                {xtype: 'rownumberer', text: '序号', width: 50, align: 'center'},
                {text: 'id', dataIndex: 'id', width: 120, menuDisabled: true, hidden: true, align: 'center'},
                {text: '风险提出', columns: [
                        {text: riskIdText, dataIndex: 'riskId',width: 100, menuDisabled: true,  align: 'center'},
                        {text: riskCreatPeopleText, dataIndex: 'riskCreatPeople',width: 120, menuDisabled: true,  align: 'center'},
                        {text: evaluationDeptText, dataIndex: 'evaluationDept',
                            // editor:allowEdit?deptCombo:null,
                            editor:null,
                            width: 100, menuDisabled: true},
                        {text: proposedTimeText, dataIndex: 'proposedTime', width: 120,
                            // editor:allowEdit?new Ext.form.DateField({ format: 'Y-m-d',}):null ,
                            editor:null ,
                            menuDisabled: true,align: 'center',
                            renderer: function(value,metaData,record,row,col,store){
                                if(value){
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                    value=value.substring(0,10);

                                }
                                return value;
                            }},
                        {text: projectPhaseText, dataIndex: 'projectPhase', editor: allowEdit?phaseCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: riskCategoryText, dataIndex: 'riskCategory',editor: allowEdit?riskCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: riskDescriptionText, dataIndex: 'riskDescription',editor: allowEdit?'textfield':null, width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {

                                if (value != null && value != undefined && value != '') {

                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";

                                    return value;
                                }
                                return value;
                            },
                        },
                        {text: riskEffectText, dataIndex: 'riskEffect', width: 140,editor: allowEdit?'textfield':null, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            },},
                        {text: severityText, dataIndex: 'severity', editor:  allowEdit?numberCombo:null,tooltip:severityS,width: 120, menuDisabled: true, align: 'center'},
                        {text: occurrenceText, dataIndex: 'occurrence', editor:  allowEdit?numberCombo2:null,tooltip:occurrenceO,width: 120, menuDisabled: true, align: 'center'},
                        {text: detectionText, dataIndex: 'detection', editor:  allowEdit?numberCombo3:null,tooltip:detectionD,width: 120, menuDisabled: true, align: 'center'},
                        // {text: riskRateText, dataIndex: 'riskRate', editor: allowEdit?'textfield':null,width: 100, menuDisabled: true, align: 'center'},
                        {text: levelOfRiskText, dataIndex: 'levelOfRisk', editor:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {

                                if (value != null && value != undefined && value != '') {
                                    let whetherError= value.substring(0,5);
                                    let levelOfRiskKey ;
                                    let levelOfRiskDes ;
                                    if(whetherError=="Error"){
                                        levelOfRiskKey = value.substring(0,5);
                                        levelOfRiskDes = value.substring(5);
                                    }else{
                                        levelOfRiskKey = value.substring(0,1);
                                        levelOfRiskDes = value.substring(1);
                                    }

                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+levelOfRiskDes+"'";
                                    if(levelOfRiskKey=='H'||levelOfRiskKey=='M'||levelOfRiskKey=='Error'){
                                        levelOfRiskKey= '<span style="color:#FF0000;">'+levelOfRiskKey+'</span>';
                                    }
                                    return levelOfRiskKey;
                                }
                                return value;
                            },},

                        {text: ownerText, dataIndex: 'owner', editor: allowEdit||riskFollowAllowEdit?allUserCombo_projectPlan:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value, meta, record) {
                                // sleep(1000);
                                let displayName = value;
                                if(value){
                                    let riskByPurchaseAsscessStore = allUserCombo_projectPlan.getStore();
                                    riskByPurchaseAsscessStore.each(function(rec){
                                        if(rec.get('no') == value){
                                            displayName =  rec.get('userFullName');
                                        }
                                    });
                                }
                                return displayName;
                            }
                        },
                        {text: ownerDeptText, dataIndex: 'ownerDept',
                            // editor: allowEdit||riskFollowAllowEdit?'textfield':null,
                            editor: null,
                            width: 120, menuDisabled: true, align: 'center'},
                        {text: plannedFinishDateText, dataIndex: 'plannedFinishDate',width: 100, editor: allowEdit||riskFollowAllowEdit ?  {xtype:'datefield', minValue:new Date(),format:'Y-m-d'}: null,menuDisabled: true,
                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                return selfDateFormat(value);
                            } },
                        {text: whetherPassText, dataIndex: 'whetherPass', editor: riskFollowAllowEdit?whetherPassCombo:null,width: 120, menuDisabled: true, align: 'center'},
                    ], menuDisabled: true,
                },
                {text: '风险跟进', columns: [
                        {text: responseCategoriesText, dataIndex: 'responseCategories', editor: allowEdit?responseCategoriesCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: actionsForRiskText, dataIndex: 'actionsForRisk', editor: allowEdit?'textfield':null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: currentStatusText, dataIndex: 'currentStatus', editor: riskSureAllowEdit?'textfield':null,width: 120, menuDisabled: true, align: 'center'},
                        {text: severity2Text, dataIndex: 'severity2', editor:riskSureAllowEdit?numberCombo4:null,tooltip:severityS,width: 120, menuDisabled: true, align: 'center'},
                        {text: occurrence2Text, dataIndex: 'occurrence2',  editor:riskSureAllowEdit?numberCombo5:null,tooltip:occurrenceO,width: 120, menuDisabled: true, align: 'center'},
                        {text: detection2Text, dataIndex: 'detection2',  editor:riskSureAllowEdit?numberCombo6:null,tooltip:detectionD,width: 120, menuDisabled: true, align: 'center',},
                        // {text: riskRate2Text, dataIndex: 'riskRate2',  editor:  allowEdit?numberCombo:null,tooltip:detectionD,width: 120, menuDisabled: true, align: 'center'},
                        {text: levelOfRisk2Text, dataIndex: 'levelOfRisk2', editor:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    let whetherError= value.substring(0,5);
                                    let levelOfRiskKey ;
                                    let levelOfRiskDes ;
                                    if(whetherError=="Error"){
                                        levelOfRiskKey = value.substring(0,5);
                                        levelOfRiskDes = value.substring(5);
                                    }else{
                                        levelOfRiskKey = value.substring(0,1);
                                        levelOfRiskDes = value.substring(1);
                                    }

                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+levelOfRiskDes+"'";
                                    if(levelOfRiskKey=='H'||levelOfRiskKey=='M'||levelOfRiskKey=='Error'){
                                        levelOfRiskKey= '<span style="color:#FF0000;">'+levelOfRiskKey+'</span>';
                                    }
                                    return levelOfRiskKey;
                                }
                                return value;
                            },},
                        {text: riskHappenedOrNotText, dataIndex: 'riskHappenedOrNot', editor: riskSureAllowEdit?problemIdCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: problemIdText, dataIndex: 'problemId', editor: riskSureAllowEdit?problemNumberCombo:null,width: 120, menuDisabled: true, align: 'center',

                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                if(value) {
                                    var docLink = "<a href='" + urlPathPrefix +record.get('containerId') +"' target='_blank' >"
                                        + value + "</a>";
                                    return docLink;
                                }else {
                                    return value;
                                }
                            },

                        },

                    ], menuDisabled: true,
                },
                {text: '风险确认', columns: [
                        {text: businessStatusText, dataIndex: 'businessStatus', editor:riskPQASureAllowEdit?statusCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: pqaEnsureText, dataIndex: 'pqaEnsure',
                            // editor: riskPQASureAllowEdit?new Ext.form.DateField({ format: 'Y-m-d',}):null,
                            editor:null,
                            menuDisabled: true,align: 'center',
                            renderer: function (value) {

                                if(value!=null){
                                    value=value.trim();
                                }else {
                                    value='';
                                }
                                return value;

                            }},
                        {text: pqaRemarkText, dataIndex: 'pqaRemark', editor:riskPQASureAllowEdit?'textfield':null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: branchIdText, dataIndex: 'branchId', editor: riskPQASureAllowEdit?'textfield':null,width: 120, menuDisabled: true, align: 'center',hidden: true,},
                    ], menuDisabled: true,
                },
            ],
            bbar: Ext.create('Ext.PagingToolbar', {
                store: Ext.data.StoreManager.lookup('ctRiskAssessStore'),
                displayInfo: true,
                displayMsg: '当前显示 {0} - {1} ，共 {2}',
                emptyMsg: "查询结果为空",
                items:[{
                    text: '查询全部',
                    scope: this,
                    id:'queryAll',
                    handler:function(){
                        isPageQuery=false;
                        ctRiskAssessStore.pageSize=ctRiskAssessStore.getTotalCount();
                        ctRiskAssessStore.currentPage = 1;
                        refreshRequireStore();
                        Ext.getCmp("queryAll").hide();
                        Ext.getCmp("pageQuery").show();
                    }
                },{
                    text: '分页查询',
                    scope: this,
                    id:'pageQuery',
                    hidden:true,
                    handler:function(){
                        isPageQuery=true;
                        ctRiskAssessStore.pageSize=25;
                        refreshRequireStore();
                        Ext.getCmp("pageQuery").hide();
                        Ext.getCmp("queryAll").show();
                    }
                }]
            }),//~End bbar
            tbar: [{
                iconCls : 'icon-add',
                xtype: 'button',
                id: "addData",
                text: '添加',
                hidden:true,
                handler: function(){
                    Ext.Ajax.request({
                        scope:this,
                        url: '/Windchill/ptc1/risk/genRiskFromData',
                        method:'POST',
                        params:{
                            proOid:proOid,
                            oid:oid,
                        },
                        success: function(response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=="success") {
                                Ext.getStore('ctRiskAssessStore').reload();
                            }else{
                                alert(obj.message);
                            }
                        },
                        failure: function(response, opts) {
                            alert('错误：保存信息失败，请检查网络！');
                        }
                    });
                }
            },{
                text: '删除 ',
                iconCls : 'icon-delete',
                xtype: 'button',
                id: "removeData",
                hidden:true,
                handler: function () { }
            },{
                text: 'Excel导入',
                hidden:true,
                iconCls: 'icon-excelImport',
                xtype: 'button',
                id: "excelInputData",
                handler : function() {
                },
            },{
                iconCls: 'icon-excelExport',
                // xtype: 'button',
                id: "excelOutputData",
                text: 'Excel导出',
                handler : function () {
                    this.exportReport();
                },
                scope : this
            },{
                iconCls: 'icon-download ',
                xtype: 'button',
                id: "downTemplate",
                text: '下载模板',
                handler: function(){
                    window.location.href='/Windchill/template/riskAssessExportTemplate.xlsx','','width=200,height=100' ;
                }
            },{
                iconCls: 'icon-myself',
                xtype: 'button',
                id: "showMyself",
                text: '显示个人',
                // hidden:riskFollowAllowEdit||riskPQASureAllowEdit?true:false,
                //  hidden:(allowEdit||riskSureAllowEdit)&&!riskFollowAllowEdit&&!riskPQASureAllowEdit?true:false,
                hidden:true,

                handler: function(){

                },
            },{
                iconCls: 'icon-team',
                text: '显示全部',
                scope: this,
                // hidden:(allowEdit||riskSureAllowEdit)&&!riskFollowAllowEdit&&!riskPQASureAllowEdit?true:false,
                hidden:true,
                id:'showAll',
                handler:function(){

                }
            }]

        });

        ctRiskAssessGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var value = e.value; //得到修改列

                if((tField=="severity"&&e.value==severity)||(tField=="occurrence"&&e.value==occurrence)
                    ||(tField=="detection"&&e.value==detection)||(tField=="severity2"&&e.value==severity2)
                    ||(tField=="occurrence2"&&e.value==occurrence2)||(tField=="detection2"&&e.value==detection2)) {
                    tRecord.commit();
                    return;
                }
                var callbackFn = function () {
                    if(tField=='severity'||tField=='occurrence'||tField=='detection'
                        ||tField=='severity2'||tField=='occurrence2'||tField=='detection2'
                        ||tField=='owner'||tField=='pqaEnsure'||tField=='businessStatus'
                        ||tField=='riskHappenedOrNot'){
                        Ext.getStore('ctRiskAssessStore').reload()
                    }
                };
                updateProblem(tRecord.data,callbackFn,tRecord,tField,value);
            });

        this.items = [ ctRiskAssessGrid];

        this.callParent();
    },

    exportReport: function() {
        //如果没有勾选默认导出全部
        let selectionArr = Ext.getCmp('ctRiskAssessGrid').getSelectionModel().getSelection();

        window.location.href = '/Windchill/ptc1/risk/exportRiskAssess?proOid='+proOid+'&oid=' + oid + '';

    },
    listeners: {
        'afterrender': function () {
        },
        'beforerender': function () {

            Ext.getStore('ctAllUserStore').load({
                params: { },
                callback: function (records, operation, success) {
                    if(success){
                        Ext.getStore('ctRiskAssessStore').load({
                            params: {
                                proOid:proOid,
                                oid:oid,
                                owner:riskFollowAllowEdit||riskPQASureAllowEdit?'':name,
                                isPageQuery:false,
                                activityName:activityName,
                            },
                            callback: function (records, operation, success) {
                                if (!success) {
                                    if (typeof (operation.error) == 'string') {
                                        alert(operation.error);
                                    } else {
                                        // alert('查询超时！请重试！')
                                    }
                                }
                            }
                        });
                    }
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            // alert('查询超时！请重试！')
                        }
                    }
                }
            });
        },

    },
});

function refreshRequireStore(){
    Ext.getStore('ctRiskAssessStore').load({
        params: {
            proOid:proOid,
            oid:oid,
            owner:'',
            isPageQuery:isPageQuery,
            activityName:activityName,
        },
        callback: function(records, operation, success) {
            if(!success){
                alert('查询信息失败，请联系管理员！');
            }else {
                // if(allowExport) {
                //     Ext.getCmp("upload1").enable();
                // }else {
                //     Ext.getCmp("upload1").disable();
                // }
            }
        }
    });
}

//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}


////////////////////Function Area//////////////////////////////





