
Ext.define('PLM.view.mockRiskMgt', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.mockRiskMgt',
    border: false,
    autoScroll: true,
    autoWidth: true,
    autoHeight: true,
    collapsible: false,
    config: {
        in_objectKey: 'RiskMgtMock',
        in_objectDesc: '风险管理Demo',
    },
    id: 'MockExample',
    initComponent: function () {
        var me = this;
        var mockExampleStore = Ext.create('PLM.store.MockItemStore', {
            id: 'mockExampleStore'
        });
        var severityS='严重度S：分值越高，说明越严重；9-10分，不安全；7-8分，丧失基本功能；5-6分，不舒服不方便；  2-4分，能感知到的影响；1分，不影响。';
        var occurrenceO='发生度O：分值越高，说明越容易发生；9-10分，不可避免；7-8分，可能重复失效；4-6分，可能偶尔失效；  2-3分，很少失效；1分，不可能失效';
        var detectionD='探测度D：分值越高，说明越不容易检验出；8-10分，不能确定；6-7分，确定能力低；4-5分，确定能力中等；   2-3分，确定度高；1分，完全确定';
        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
        var numberCombo = new Ext.form.field.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            lazyRender: true,
            width: 100,
            allowBlank: false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo',
            name: 'numberCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var phaseCombo = new Ext.form.field.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            lazyRender: true,
            width: 100,
            allowBlank: false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'phaseCombo',
            name: 'phaseCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["charter", "charter"], ["TR2", "TR2"], ["PDCP", "PDCP"],["TR4", "TR4"],
                    ["TR4A", "TR4A"], ["TR5", "TR5"], ["TR6", "TR6"],["LDCP", "LDCP"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var riskCombo = new Ext.form.field.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            lazyRender: true,
            width: 100,
            allowBlank: false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'riskCombo',
            name: 'riskCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["需求不确定", "需求不确定"], ["进度要求", "进度要求"], ["新设计", "新设计"],["新工艺", "新工艺"],
                    ["新物料", "新物料"], ["新应用", "新应用"], ["新过程", "新过程"],["新供应商", "新供应商"],
                    ["法规要求", "法规要求"], ["人力要求", "人力要求"], ["成本要求", "成本要求"],["售后要求", "售后要求"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var deptCombo = new Ext.form.field.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            lazyRender: true,
            width: 100,
            allowBlank: false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'deptCombo',
            name: 'deptCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["产品管理", "产品管理"], ["项目管理", "项目管理"], ["硬件", "硬件"],["软件", "软件"],
                    ["结构", "结构"], ["测试", "测试"], ["产品工程", "产品工程"],["采购", "采购"],
                    ["制造", "制造"], ["PQA", "PQA"], ["质控", "质控"],["技术支持", "技术支持"],
                    ["销售", "销售"],["财务", "财务"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var mockExampleGrid = Ext.create('Ext.grid.Panel', {
            title: '风险管理表单',
            plugins: [cellEditing],
            store: Ext.getStore('mockExampleStore'),
            id: 'mockExampleGrid',
            // margin: '20 10 20 10',
            //forceFit: true,
            //autoWidth: true,
            // width:2500,
            height:524,
            autoScroll: true,
            region: 'center',
            //height: '100%',
            selModel: {
                mode: 'MULTI' //可以多选
            },
            //bodyStyle : 'overflow-x:scroll; overflow-y:scroll',
            viewConfig: {
                enableTextSelection: true,
                stripeRows: true,
                listeners: {
                    itemcontextmenu: function (view, rec, node, index, e) {
                        e.stopEvent();
                        var contextMenu = Ext.create('PLM.mock.ContextMenu', {
                            param_grid: mockExampleGrid,
                            param_objectKey: me.in_objectKey,
                            param_objectDesc: me.in_objectDesc
                        });
                        contextMenu.showAt(e.getXY());
                        return false;
                    }
                }
            },
            columns: [{xtype: 'rownumberer'},
                {text: '', dataIndex: 'id', menuDisabled: true, hidden: true},
                {text: '', dataIndex: 'masterId', menuDisabled: true, hidden: true},
                {text: '风险提出', columns: [
                    {text: '风险ID', dataIndex: 'data1', width: 100, editor: 'textfield', menuDisabled: true},
                    {text: '评价部门<br> Evaluation dept.', dataIndex: 'data2', width: 120, editor: deptCombo,menuDisabled: true,align: 'center'},
                    {text: '提出时间<br>Proposed time', dataIndex: 'data3', width: 120, editor:new Ext.form.DateField({minValue: new Date(), format: 'Y-m-d',}) , menuDisabled: true,align: 'center',
                        renderer: function (value) {
                            if (value != null && value != undefined && value != '') {
                                var date = new Date(value);
                                var time = Ext.Date.format(date, "Y-m-d")
                                return time;
                            }
                            return value;
                        }},
                    {text: '项目阶段<br>Project phase  ', dataIndex: 'data4', width: 120, editor: phaseCombo, menuDisabled: true,align: 'center'},
                    {text: '风险类型<br>Risk category', dataIndex: 'data5', width: 120, editor: riskCombo, menuDisabled: true,align: 'center'},
                    {text: '风险描述<br>Risk description', dataIndex: 'data6', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '潜在风险影响、失效后果<br>Risk Effect', dataIndex: 'data7', width: 140, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '严重度<br>Severity (S) ', dataIndex: 'data8', width: 120, editor: numberCombo,tooltip:severityS,  menuDisabled: true,align: 'center',},
                    {text: '发生度<br>Occurrence (O)', dataIndex: 'data9', width: 120, editor: numberCombo,tooltip:occurrenceO, menuDisabled: true,align: 'center', },
                    {text: '探测度<br>Detection (D)', dataIndex: 'data10', width: 120, editor: numberCombo,tooltip:detectionD, menuDisabled: true,align: 'center', },
                    {text: '风险优先级<br>AP', dataIndex: 'data11', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '应对措施类别<br>Response categories', dataIndex: 'data13', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '风险应对措施<br>Actions for risk', dataIndex: 'data14', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '责任部门', dataIndex: 'data15', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '责任人<br>Owner', dataIndex: 'data16', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '预计完成日期<br>Planned finish date', dataIndex: 'data17', width: 120,editor:new Ext.form.DateField({minValue: new Date(), format: 'Y-m-d',}) , menuDisabled: true,align: 'center',
                        renderer: function (value) {
                            if (value != null && value != undefined && value != '') {
                                var date = new Date(value);
                                var time = Ext.Date.format(date, "Y-m-d")
                                return time;
                            }
                            return value;
                        }},
                    ], menuDisabled: true, width: 425
                },
                {text: '风险更进', columns: [
                    {text: '措施实施进展<br>Current status', dataIndex: 'data18', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '严重度<br>Severity (S) ', dataIndex: 'data19', width: 120, editor: numberCombo,tooltip:severityS,  menuDisabled: true,align: 'center'},
                    {text: '发生度<br>Occurrence (O) ', dataIndex: 'data20', width: 120, editor: numberCombo,tooltip:occurrenceO, menuDisabled: true,align: 'center'},
                    {text: '探测度<br>Detection (D)', dataIndex: 'data21', width: 120, editor: numberCombo,tooltip:detectionD,  menuDisabled: true,align: 'center'},
                    {text: '风险优先级<br>AP', dataIndex: 'data22', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '风险是否发生<br>Risk happened or not', dataIndex: 'data23', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '问题ID', dataIndex: 'data24', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    ], menuDisabled: true, width: 425
                },
                {text: '风险确认', columns: [
                    {text: '当前状态', dataIndex: 'data25', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'},
                    {text: '实际完成时间', dataIndex: 'data26', width: 120, editor:new Ext.form.DateField({minValue: new Date(), format: 'Y-m-d',}) , menuDisabled: true,align: 'center',
                        renderer: function (value) {
                            if (value != null && value != undefined && value != '') {
                                var date = new Date(value);
                                var time = Ext.Date.format(date, "Y-m-d")
                                return time;
                            }
                            return value;
                        }},
                    {text: 'PQA备注', dataIndex: 'data27', width: 120, editor: 'textfield', menuDisabled: true,align: 'center'}
                    ], menuDisabled: true, width: 425
                },
            ],
            tbar: [{
                iconCls : 'icon-add',
                xtype: 'button',
                id: "addData",
                text: '添加',
                handler: function(){
                    alert('开发进行中....');
                }
            },{
                text: '删除 ',
                iconCls : 'icon-delete',
                xtype: 'button',
                id: "removeData",
                handler: function () {
                    alert('开发进行中....');

                }
            },{
                text: 'Excel导入',
                iconCls: 'icon-excelImport',
                xtype: 'button',
                id: "excelInputData",
                handler : function() {
                    alert('开发进行中....');
                },
            },{
                iconCls: 'icon-excelExport',
                // iconCls: 'icon-store-import',
                xtype: 'button',
                id: "excelOutputData",
                text: 'Excel导出',
                handler: function () {
                    alert('开发进行中....');
                }
            },{
                iconCls: 'icon-download ',
                xtype: 'button',
                id: "downTemplate",
                text: '下载模板',
                handler: function(){
                    alert('开发进行中....');
                }
            },{
                iconCls: 'icon-myself',
                xtype: 'button',
                id: "showMyself",
                text: '显示个人',
                handler: function () {
                    alert('开发进行中....');
                }
            }]
        });

        mockExampleGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var tValue = e.value; //得到修改列修改后值
                var itemId = tRecord.get('id');

                var callbackFn = function () {
                    tRecord.commit();
                };
                saveMockItemData(this.in_objectKey, this.in_objectDesc, itemId, tField, tValue, callbackFn);

            });

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [ mockExampleGrid]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            Ext.getStore('mockExampleStore').load({
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()//表头key
                },
                callback: function (records, operation, success) {
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            alert('查询超时！请重试！')
                        }
                    } else {
                        //无数据时自动添加一条空数据
                        if (Ext.getStore('mockExampleStore').getCount() == 0) {
                            var callbackFn = function () {
                                Ext.getStore('mockExampleStore').reload()
                            }
                            createMockItemData(Ext.getCmp('MockExample').getIn_objectKey()
                                , Ext.getCmp('MockExample').getIn_objectDesc, callbackFn);
                        }
                    }
                }
            });

            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/mock/getObject',
                params: {
                    objectKey: Ext.getCmp('MockExample').getIn_objectKey()
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    if (obj['success']) {
                        var mainPanel = Ext.getCmp('mainForm');
                        mainPanel.getForm().setValues(obj);
                    } else {
                        alert(obj['error']);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

