/**
 * 风险评估表单Grid
 */
Ext.define('Plm.view.ctRiskMgt', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctRiskMgt',
    border: false,
    collapsible: false,
    fieldDefaults: {
        msgTarget: 'side',
        labelWidth: 75
    },
    initComponent: function () {

        //上传图片窗口
        var uploadImageWindow = Ext.create('Ext.Window', {
            title: '导入图片',
            width: 550,
            height: 350,
            //autoHeight : true,
            //autoWidth : true,
            closeAction: 'hide',
            id: 'uploadImageWindow',
            autoScroll: false,
            //closable:false,
            constrain: true,
            layout: 'fit',
            modal: true,
            items: {
                xtype: 'uploadImagePanel'
            }
        });

        Ext.define('PDMLinkProductModel', {
            extend: 'Ext.data.Model',
            fields: [
                'innerName', 'displayName'
            ],
            idProperty: 'innerName'
        });


        // 产品库下拉
        var PDMLinkProductStore = Ext.create('Ext.data.Store', {
            //pageSize: 50,
            model: 'PDMLinkProductModel',
            id: 'PDMLinkProductStore',
            pruneModifiedRecords: true,
            autoSync: true,//同步更新
            proxy: {
                type: 'ajax',
                url: '/Windchill/ptc1/riskReport/getPDMLinkProduct?proOid='+proOid,
                reader: {
                    type: 'json',
                    rootProperty: 'items'
                }
            },
            listeners: {
                load: function(store) {
                    var combo = Ext.getCmp('PDMLinkProductName');
                    if (store.getCount() > 0) {
                        // 获取第一条记录的 valueField 值
                        var firstRecord = store.getAt(0);
                        var firstValue = firstRecord.get('innerName');
                        // 设置 combo 的值为第一条记录的 valueField 值
                        combo.setValue(firstValue);
                    }
                }
            },
            autoLoad: true
        });

        //用户下拉列表
        var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan'
        });
        var allUserStore_projectPlan1 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan1'
        });
        var allUserStore_projectPlan2 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan2'
        });
        var allUserStore_projectPlan3 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan3'
        });
        var allUserStore_projectPlan4 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan4'
        });
        var allUserStore_projectPlan5 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan5'
        });
        var allUserStore_projectPlan6 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan6'
        });
        var allUserStore_projectPlan7 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan7'
        });
        var allUserStore_projectPlan8 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan8'
        });
        var allUserStore_projectPlan9 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan9'
        });
        var allUserStore_projectPlan10 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan10'
        });
        var allUserStore_projectPlan11 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan11'
        });
        var allUserStore_projectPlan12 = Ext.create('PLM.hr.CtAllUserStore', {
            storeId: 'allUserStore_projectPlan12'
        });
        //问题添加表单
        var addForm = new Ext.form.Panel({
            xtype: 'form',
            margin: '10 0 0 0',
            border: false,
            height: 600,
            autoScroll: true,
            items: [
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [
                        {
                            xtype: 'combo',
                            fieldLabel: '<font color=red>*</font>所属产品库',
                            margin: '0 20 0 0',
                            queryMode: 'local',
                            enableRegEx: true,
                            displayField: 'displayName',
                            valueField: 'innerName',
                            store: PDMLinkProductStore,
                            width: 500,
                            id: 'PDMLinkProductName',
                            name: 'PDMLinkProductName',
                            labelWidth: 100,
                            listeners: {
                                change: function (combo, newValue, oldValue) {
                                    containerId = newValue;
                                }
                            }
                        },{
                            xtype: 'button',
                            id: 'upClose',
                            text: '取消',
                            handler: function () {
                                clear();
                                Ext.getCmp('requireWin2').close();
                            }
                        }
                    ]
                },
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题领域',
                        margin: '0 20 0 0',
                        valueField: 'groupName',
                        displayField: 'groupName',
                        multiSelect: true,
                        anyMatch: true,
                        editable: false,
                        store: [['软件', '软件'], ['硬件', '硬件'], ['工艺', '工艺'],
                            ['结构', '结构'], ['测试', '测试'], ['质量', '质量'],
                            ['采购', '采购'], ['制造', '制造'], ['市场', '市场'],
                            ['其他', '其他']],
                        width: 300,
                        id: 'problemTerritory',
                        name: 'problemTerritory',
                        labelWidth: 100,
                        listeners: {
                            change: function (e) {
                                var territory = Ext.getCmp("problemTerritory").getValue();
                                territory.indexOf("软件") != -1 ? Ext.getCmp("softwareCharger").show() : Ext.getCmp("softwareCharger").hide();
                                territory.indexOf("硬件") != -1 ? Ext.getCmp("hardwareCharger").show() : Ext.getCmp("hardwareCharger").hide();
                                territory.indexOf("工艺") != -1 ? Ext.getCmp("craftCharger").show() : Ext.getCmp("craftCharger").hide();
                                territory.indexOf("结构") != -1 ? Ext.getCmp("fabricCharger").show() : Ext.getCmp("fabricCharger").hide();
                                territory.indexOf("测试") != -1 ? Ext.getCmp("testCharger").show() : Ext.getCmp("testCharger").hide();
                                territory.indexOf("质量") != -1 ? Ext.getCmp("qualityCharger").show() : Ext.getCmp("qualityCharger").hide();
                                territory.indexOf("采购") != -1 ? Ext.getCmp("purchaseCharger").show() : Ext.getCmp("purchaseCharger").hide();
                                territory.indexOf("制造") != -1 ? Ext.getCmp("makeCharger").show() : Ext.getCmp("makeCharger").hide();
                                territory.indexOf("市场") != -1 ? Ext.getCmp("bazaarCharger").show() : Ext.getCmp("bazaarCharger").hide();
                                territory.indexOf("其他") != -1 ? Ext.getCmp("elseCharger").show() : Ext.getCmp("elseCharger").hide();
                            }
                        }
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题来源（领域）',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [['研发', '研发'], ['质量', '质量'], ['工艺', '工艺'], ['测试', '测试'],
                            ['客诉', '客诉'], ['售后质量', '售后质量'], ['制程异常', '制程异常'], ['用户体验', '用户体验']],
                        width: 300,
                        id: 'problemSource',
                        name: 'problemSource',
                        labelWidth: 100
                    }
                    ]
                },

                , {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '项目名称',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'projectName',
                        displayField: 'projectName',
                        anyMatch: true,
                        editable: false,
                        width: 300,
                        id: 'projectName',
                        name: 'projectName',
                        labelWidth: 100
                    }, {
                        xtype: 'combo',
                        fieldLabel: '项目编号',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'projectNumber',
                        displayField: 'projectNumber',
                        anyMatch: true,
                        editable: false,
                        width: 300,
                        id: 'projectNumber',
                        name: 'projectNumber',
                        labelWidth: 100
                    }
                    ]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>项目阶段',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"], ["TR4-TR4A", "TR4-TR4A"],
                            ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"],['量产阶段','量产阶段']],
                        width: 300,
                        id: 'projectPhase',
                        name: 'projectPhase',
                        labelWidth: 100
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题级别',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [['严重', '严重'], ['一般', '一般'], ['轻微', '轻微'],
                            ['N/A', 'N/A']],
                        width: 300,
                        id: 'problemGrade',
                        name: 'problemGrade',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [ {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题提出者',
                        margin: '0 20 0 0',
                        valueField: 'userFullName',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        store: allUserStore_projectPlan,
                        width: 300,
                        id: 'creator',
                        name: 'creator',
                        labelWidth: 100
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>问题来源（评审）',
                        margin: '0 20 0 0',
                        multiSelect: false,
                        valueField: 'groupName',
                        displayField: 'groupName',
                        anyMatch: true,
                        editable: false,
                        store: [['非评审', '非评审'], ['原理图及PCB评审', '原理图及PCB评审'], ['结构评审', '结构评审'],['软件评审', '软件评审']
                            ,['总体方案评审', '总体方案评审'],['需求规格评审', '需求规格评审'],['TR评审', 'TR评审']],
                        width: 300,
                        id: 'problemSourceTerritory',
                        name: 'problemSourceTerritory',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'datefield',
                        fieldLabel: '<font color=red>*</font>计划完成时间',
                        margin: '0 20 0 0',
                        width: 300,
                        minValue: new Date(),
                        format: 'Y-m-d',
                        id: 'planFinishDate',
                        name: 'planFinishDate',
                        labelWidth: 100
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '相关问题编号',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'relatedProblemNumber',
                        name: 'relatedProblemNumber',
                        labelWidth: 100,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('relatedProblemNumber').getValue();
                                //验证编号是否正确
                                if (value != "")
                                    var isCorrect = checkProblemNumber(value);
                                if (!isCorrect) {
                                    Ext.getCmp('relatedProblemNumber').setValue("");
                                }
                            }
                        }
                    }
                    ]
                },
                /* {
                     layout: 'hbox',
                     border: false,
                     margin: '5 5 10 30',
                     items: [{
                         xtype: 'textfield',
                         fieldLabel: '成品编号',
                         margin: '0 20 0 0',
                         width: 300,
                         id: 'endPartNumber',
                         name: 'endPartNumber',
                         labelWidth: 100,
                         listeners: {
                             blur: function (e) {
                                 var value = Ext.getCmp('endPartNumber').getValue();
                                 //验证编号是否正确
                                 var isCorrect = checkPartNumber(value);
                                 if (!isCorrect) {
                                     Ext.getCmp('endPartNumber').setValue("");
                                 } else {
                                     //产品型号获取
                                     var productNumber = getProductNumber(value);
                                     Ext.getCmp('productNumber').setValue(productNumber);
                                 }
                             }
                         }
                     }, {
                         xtype: 'displayfield',
                         fieldLabel: '产品型号',
                         margin: '0 20 0 0',
                         width: 300,
                         id: 'productNumber',
                         name: 'productNumber',
                         labelWidth: 100
                     }
                     ]
                 },*/
                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'numberfield',
                        fieldLabel: '不良比例（%）',
                        margin: '0 20 0 0',
                        width: 300,
                        minValue: 0,
                        maxValue: 100,
                        id: 'badProportion',
                        name: 'badProportion',
                        labelWidth: 100
                    }, {
                        xtype: 'textfield',
                        fieldLabel: '风险编号',
                        margin: '0 20 0 0',
                        width: 300,
                        id: 'riskNumber',
                        name: 'riskNumber',
                        labelWidth: 100,
                        listeners: {
                            blur: function (e) {
                                var value = Ext.getCmp('riskNumber').getValue();
                                //验证编号是否正确
                                if (value != "")
                                    var isCorrect = checkRiskNumber(value);
                                if (!isCorrect) {
                                    Ext.getCmp('riskNumber').setValue("");
                                }
                            }
                        }
                    },
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>PQA',
                        id: 'pqaCheck',
                        name: 'pqaCheck',
                        margin: '0 20 0 0',
                        valueField: 'userFullName',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        store: allUserStore_projectPlan11,
                        labelWidth: 100,
                        width: 300,
                    }, {
                        xtype: 'combo',
                        fieldLabel: '<font color=red>*</font>开发代表',
                        id: 'affirmCheck',
                        name: 'affirmCheck',
                        margin: '0 20 0 0',
                        valueField: 'userFullName',
                        displayField: 'userFullName',
                        queryMode: 'local',
                        anyMatch: true,
                        typeAhead: true,
                        forceSelection: true,
                        triggerAction: 'all',
                        allowBlank: true,
                        store: allUserStore_projectPlan12,
                        labelWidth: 100,
                        width: 300,
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        layout: 'hbox',
                        border: false,
                        margin: '5 5 10 30',
                        items: [{
                            xtype: 'button',
                            text: "图片上传",
                            margin: '0 20 0 0',
                            width: 260,
                            id: 'sctp',
                            name: 'sctp',
                            handler: function () {
                                if(containerId == ''){
                                    alert("请先选择所属产品库！")
                                }else {
                                    uploadImageWindow.show();
                                }
                            }
                        }]
                    }]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>问题摘要',
                        maxLength: 1200,
                        maxLengthText: "问题描述必须在500字及以内!",
                        width: 620,
                        id: 'summaryOfIssues',
                        name: 'summaryOfIssues',
                        labelWidth: 100
                    }
                    ]
                },

                {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>问题描述',
                        maxLength: 1200,
                        maxLengthText: "问题描述必须在1200字及以内!",
                        width: 620,
                        id: 'description',
                        name: 'description',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textareafield',
                        margin: '0 20 0 0',
                        fieldLabel: '<font color=red>*</font>初步原因分析',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "初步原因分析必须在1200字及以内!",
                        id: 'analysis',
                        name: 'analysis',
                        labelWidth: 100
                    }
                    ]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '<font color=red>*</font>初步对策',
                        margin: '0 20 0 0',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "初步对策必须在1200字及以内!",
                        id: 'optimizeStrategy',
                        name: 'optimizeStrategy',
                        labelWidth: 100
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'textarea',
                        fieldLabel: '临时措施',
                        margin: '0 20 0 0',
                        width: 620,
                        maxLength: 1200,
                        maxLengthText: "临时措施必须在1200字及以内!",
                        id: 'temporaryMeasures',
                        name: 'temporaryMeasures',
                        labelWidth: 100
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        xtype: 'fieldset',
                        title: '领域问题责任人',
                        // hidden:allowEdit?false:true,
                        padding: '5',
                        collapsed: true,
                        collapsible: true,
                        titleCollapse: false,
                        hideCollapseTool: false,
                        anchor: '100%',
                        defaults: {
                            padding: '2 10 2 10',
                            labelWidth: 100,
                            border: false
                        },
                        items: [
                            {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>硬件领域问题承担者',
                                    id: 'hardwareCharger',
                                    name: 'hardwareCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan1,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>软件领域问题承担者',
                                    id: 'softwareCharger',
                                    name: 'softwareCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan2,
                                    labelWidth: 130,
                                    margin: '0 0 0 30',
                                    width: 280,

                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>结构领域问题承担者',
                                    id: 'fabricCharger',
                                    name: 'fabricCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan3,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>工艺领域问题承担者',
                                    id: 'craftCharger',
                                    name: 'craftCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan4,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,

                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>测试领域问题承担者',
                                    id: 'testCharger',
                                    name: 'testCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan5,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>质量领域问题承担者',
                                    id: 'qualityCharger',
                                    name: 'qualityCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan6,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>采购领域问题承担者',
                                    id: 'purchaseCharger',
                                    name: 'purchaseCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan7,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>制造领域问题承担者',
                                    id: 'makeCharger',
                                    name: 'makeCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan8,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            }, {
                                layout: 'hbox',
                                border: false,
                                margin: '5 5 10 0',
                                items: [{
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>市场领域问题承担者',
                                    id: 'bazaarCharger',
                                    name: 'bazaarCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan9,
                                    labelWidth: 130,
                                    width: 280,
                                }, {
                                    xtype: 'combo',
                                    hidden: true,
                                    fieldLabel: '<font color=red>*</font>其他领域问题承担者',
                                    id: 'elseCharger',
                                    name: 'elseCharger',
                                    margin: '0 20 0 0',
                                    valueField: 'userFullName',
                                    displayField: 'userFullName',
                                    queryMode: 'local',
                                    anyMatch: true,
                                    typeAhead: true,
                                    forceSelection: true,
                                    triggerAction: 'all',
                                    allowBlank: true,
                                    store: allUserStore_projectPlan10,
                                    margin: '0 0 0 30',
                                    labelWidth: 130,
                                    width: 280,
                                },]
                            },]
                    }]
                }, {
                    layout: 'hbox',
                    border: false,
                    margin: '5 5 10 30',
                    items: [{
                        margin: '0 10 0 0',
                        xtype: 'button',
                        id: 'save',
                        text: '保存',
                        handler: function () {
                            var data = {
                                containerId: Ext.getCmp('PDMLinkProductName').getValue(),
                                description: Ext.getCmp('description').getValue(),
                                problemTerritory: Ext.getCmp('problemTerritory').getValue(),
                                problemGrade: Ext.getCmp('problemGrade').getValue(),
                                projectPhase: Ext.getCmp('projectPhase').getValue(),
                                optimizeStrategy: Ext.getCmp('optimizeStrategy').getValue(),
                                pqaCheck: Ext.getCmp('pqaCheck').getValue(),
                                //charger: Ext.getCmp('charger').getValue(),
                                creator: Ext.getCmp('creator').getValue(),
                                planFinishDate: Ext.getCmp('planFinishDate').getValue(),
                                analysis: Ext.getCmp('analysis').getValue(),
                                badProportion: Ext.getCmp('badProportion').getValue(),
                                problemSource: Ext.getCmp('problemSource').getValue(),
                                riskNumber: Ext.getCmp('riskNumber').getValue(),
                                relatedProblemNumber: Ext.getCmp('relatedProblemNumber').getValue(),
                                temporaryMeasures: Ext.getCmp('temporaryMeasures').getValue(),
                                /*endPartNumber: Ext.getCmp('endPartNumber').getValue(),
                                productNumber: Ext.getCmp('productNumber').getValue(),*/
                                softwareCharger: Ext.getCmp('softwareCharger').getValue(),
                                hardwareCharger: Ext.getCmp('hardwareCharger').getValue(),
                                craftCharger: Ext.getCmp('craftCharger').getValue(),
                                fabricCharger: Ext.getCmp('fabricCharger').getValue(),
                                testCharger: Ext.getCmp('testCharger').getValue(),
                                qualityCharger: Ext.getCmp('qualityCharger').getValue(),
                                purchaseCharger: Ext.getCmp('purchaseCharger').getValue(),
                                makeCharger: Ext.getCmp('makeCharger').getValue(),
                                bazaarCharger: Ext.getCmp('bazaarCharger').getValue(),
                                elseCharger: Ext.getCmp('elseCharger').getValue(),
                                affirmCheck: Ext.getCmp('affirmCheck').getValue(),
                                problemSourceTerritory: Ext.getCmp('problemSourceTerritory').getValue(),
                                problemInput: userName,

                                projectNumber:Ext.getCmp('projectNumber').getValue(),
                                projectName:Ext.getCmp('projectName').getValue(),
                                summaryOfIssues:Ext.getCmp('summaryOfIssues').getValue()

                            }

                            if(data.containerId == ""){
                                alert("弹窗中“所属产品库”为必填项，不允许为空！");
                                return;
                            }

                            if (data.summaryOfIssues == "" || data.description == "" || data.problemTerritory == null || data.problemGrade == null || data.projectPhase == null || data.optimizeStrategy == ""
                                || data.planFinishDate == "" || data.analysis == "" || data.problemSource == null|| data.problemSourceTerritory == null ||/* data.productNumber == "" || */data.pqaCheck == null ||
                                data.creator == null || data.affirmCheck == null) {
                                alert("弹窗中*号标识为必填项，不允许为空");
                                return;
                            }

                            if(data.summaryOfIssues){
                                if (data.summaryOfIssues.length > 500) {
                                    alert("“问题摘要”长度超过了 500 个字符！");
                                   return;
                                }
                            }

                            var split = data.problemTerritory.toString().split(',');
                            for (let i = 0; i < split.length; i++) {
                                if (split[i] == '软件') {
                                    var value = Ext.getCmp("softwareCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '硬件') {
                                    var value = Ext.getCmp("hardwareCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '工艺') {
                                    var value = Ext.getCmp("craftCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '结构') {
                                    var value = Ext.getCmp("fabricCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '测试') {
                                    var value = Ext.getCmp("testCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '质量') {
                                    var value = Ext.getCmp("qualityCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '采购') {
                                    var value = Ext.getCmp("purchaseCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '制造') {
                                    var value = Ext.getCmp("makeCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '市场') {
                                    var value = Ext.getCmp("bazaarCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                } else if (split[i] == '其他') {
                                    var value = Ext.getCmp("elseCharger").getValue();
                                    if (value == null) {
                                        alert("弹窗中*号标识为必填项，不允许为空");
                                        return;
                                    }
                                }
                            }

                            var t = '软件,硬件,工艺,结构,测试,质量,采购,制造,市场,其他';
                            var ts = t.split(',')
                            let newArray = [];
                            for (let i = 0; i < ts.length; i++) {
                                if (!split.includes(ts[i])) {
                                    newArray.push(ts[i]);
                                }
                                ;
                            }
                            for (let i = 0; i < newArray.length; i++) {
                                if (newArray[i] == '软件') {
                                    data.softwareCharger = '';
                                } else if (newArray[i] == '硬件') {
                                    data.hardwareCharger = '';

                                } else if (newArray[i] == '工艺') {
                                    data.craftCharger = '';

                                } else if (newArray[i] == '结构') {
                                    data.fabricCharger = '';

                                } else if (newArray[i] == '测试') {
                                    data.testCharger = '';

                                } else if (newArray[i] == '质量') {
                                    data.qualityCharger = '';

                                } else if (newArray[i] == '采购') {
                                    data.purchaseCharger = '';

                                } else if (newArray[i] == '制造') {
                                    data.makeCharger = '';

                                } else if (newArray[i] == '市场') {
                                    data.bazaarCharger = '';

                                } else if (newArray[i] == '其他') {
                                    data.elseCharger = '';
                                }
                            }

                            save(data);
                            clear();
                            Ext.getCmp('requireWin2').close();
                        }
                    }, {
                        xtype: 'button',
                        id: 'close',
                        text: '取消',
                        handler: function () {
                            clear();
                            Ext.getCmp('requireWin2').close();
                        }
                    }]
                }]
        })

        var requireWin2 = Ext.create('Ext.Window', {
            id: 'requireWin2',
            title: '添加问题',
            width: 700,
            //height: 300,
            autoHeight: true,
            closeAction: 'hide',
            closable: false, // 禁用右上角的叉号
            constrain: true,
            modal: true,
            items: [addForm],
        });





        Ext.define('ctRiskAssessModel', {
            extend: 'Ext.data.Model',
            fields:['id' ,'riskId','evaluationDept','riskCreatPeople','proposedTime','projectPhase','riskCategory','riskDescription','riskEffect','severity','occurrence',
                'detection','levelOfRisk','responseCategories','actionsForRisk','ownerDept','owner','plannedFinishDate','currentStatus','severity2',
                'occurrence2' ,'detection2','levelOfRisk2','businessStatus','riskHappenedOrNot','pqaEnsure','pqaRemark','branchId','creator','whetherPass','createTime','projectNumber','projectName','projectStatus','containerId'],
            idProperty: 'id'
        });
        Ext.define('ctAllUserModel', {
            extend: 'Ext.data.Model',
            fields:['no' ,'riskId']
        });
        //添加 导入 删除 隐藏
        console.log(activityName.indexOf("录入")!=-1)
        console.log(name)

        var addHidden=allowEdit&&(!riskSureAllowEdit&&!riskFollowAllowEdit&&!riskPQASureAllowEdit);
        //显示个人  隐藏
        var showMyselfHidden=(allowEdit||riskSureAllowEdit)&&!riskFollowAllowEdit&&!riskPQASureAllowEdit;

        var me = this;
        var severity="";
        var occurrence="";
        var detection="";
        var severity2="";
        var occurrence2="";
        var detection2="";

        var ctRiskAssessStore = Ext.create('Ext.data.Store', {
            // pageSize: 1,
            model: 'ctRiskAssessModel',
            id: 'ctRiskAssessStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/risk/getDataByBranchId',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: false
        });
        // ctRiskAssessStore.on('beforeload', function(store, options) {
        //     var data = {
        //         proOid:proOid,
        //         oid:oid,
        //         owner:name,
        //         isPageQuery:isPageQuery,
        //         activityName:activityName,
        //     };
        //     Ext.apply(ctRiskAssessStore.proxy.extraParams, data);
        // });
        var cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });


        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var riskIdText = '风险ID';
        var evaluationDeptText = '评价部门';
        var riskCreatPeopleText = '风险识别人';
        var proposedTimeText = '提出时间';
        var projectPhaseText='项目阶段';
        var riskCategoryText='风险类型';
        var riskDescriptionText='风险描述';
        var riskEffectText='潜在风险影响、失效后果';
        var severityText='严重程度(S)';
        var occurrenceText='发生概率(O)';
        var detectionText='探测度(D)';
        // var riskRateText='风险系数RPN=S*O*D';
        var levelOfRiskText='风险优先级AP';
        var responseCategoriesText='应对措施类别';
        var actionsForRiskText='风险应对措施';
        var ownerDeptText='责任部门';
        var ownerText='责任人Owner';
        var plannedFinishDateText='预计完成日期';
        var whetherPassText='是否驳回';

        var currentStatusText='措施实施进展';
        var severity2Text='严重程度(S)';
        var occurrence2Text='发生概率(O)';
        var detection2Text='探测度(D)';
        // var riskRate2Text='风险系数';
        var levelOfRisk2Text='风险优先级AP';
        var problemIdText='问题ID';

        var riskHappenedOrNotText='风险是否发生';
        var businessStatusText='当前状态';
        var pqaEnsureText='实际完成时间';
        var pqaRemarkText='PQA备注';
        var branchIdText='流程ID';
            //可编辑项
            if(allowEdit) {
                //对应要加标的选项
                // riskIdText = redStarFlag+blueFlagStart+ riskIdText +blueFlagEnd;
                // evaluationDeptText =redStarFlag+ blueFlagStart+ evaluationDeptText +blueFlagEnd;
                // proposedTimeText =redStarFlag+ blueFlagStart+ proposedTimeText +blueFlagEnd;
                projectPhaseText =redStarFlag+blueFlagStart+ projectPhaseText +blueFlagEnd;
                riskCategoryText =redStarFlag+blueFlagStart+ riskCategoryText +blueFlagEnd;
                riskDescriptionText =redStarFlag+blueFlagStart+ riskDescriptionText +blueFlagEnd;
                riskEffectText =redStarFlag+blueFlagStart+ riskEffectText +blueFlagEnd;
                severityText =redStarFlag+blueFlagStart+ severityText +blueFlagEnd;
                occurrenceText =redStarFlag+blueFlagStart+ occurrenceText +blueFlagEnd;
                detectionText =redStarFlag+blueFlagStart+ detectionText +blueFlagEnd;
                // riskRateText =redStarFlag+blueFlagStart+ riskRateText +blueFlagEnd;
                // levelOfRiskText =redStarFlag+blueFlagStart+ levelOfRiskText +blueFlagEnd;

            }
            if(allowEdit||riskFollowAllowEdit){
                // ownerDeptText =redStarFlag+blueFlagStart+ ownerDeptText +blueFlagEnd;
                ownerText =redStarFlag+blueFlagStart+ ownerText +blueFlagEnd;
                plannedFinishDateText =redStarFlag+blueFlagStart+ plannedFinishDateText +blueFlagEnd;
            }
            if(riskFollowAllowEdit){

                whetherPassText =redStarFlag+blueFlagStart+ whetherPassText +blueFlagEnd;
            }
            // if(riskSureAllowEdit||riskPQASureAllowEdit){
            //     responseCategoriesText =blueFlagStart+ responseCategoriesText +blueFlagEnd;
            //     actionsForRiskText =redStarFlag+blueFlagStart+ actionsForRiskText +blueFlagEnd;
            //     currentStatusText =redStarFlag+blueFlagStart+ currentStatusText +blueFlagEnd;
            //     severity2Text =redStarFlag+blueFlagStart+ severity2Text +blueFlagEnd;
            //     occurrence2Text =redStarFlag+blueFlagStart+ occurrence2Text +blueFlagEnd;
            //     detection2Text =redStarFlag+blueFlagStart+ detection2Text +blueFlagEnd;
            //     // riskRate2Text =redStarFlag+blueFlagStart+ riskRate2Text +blueFlagEnd;
            //     levelOfRisk2Text =redStarFlag+blueFlagStart+ levelOfRisk2Text +blueFlagEnd;
            //     riskHappenedOrNotText =redStarFlag+blueFlagStart+ riskHappenedOrNotText +blueFlagEnd;
            //     // problemIdText =redStarFlag+blueFlagStart+ problemIdText +blueFlagEnd;
            //     problemIdText =blueFlagStart+ problemIdText +blueFlagEnd;
            // }
            if(riskSureAllowEdit){
                responseCategoriesText =blueFlagStart+ responseCategoriesText +blueFlagEnd;
                actionsForRiskText =redStarFlag+blueFlagStart+ actionsForRiskText +blueFlagEnd;
                currentStatusText =redStarFlag+blueFlagStart+ currentStatusText +blueFlagEnd;
                severity2Text =redStarFlag+blueFlagStart+ severity2Text +blueFlagEnd;
                occurrence2Text =redStarFlag+blueFlagStart+ occurrence2Text +blueFlagEnd;
                detection2Text =redStarFlag+blueFlagStart+ detection2Text +blueFlagEnd;
                // riskRate2Text =redStarFlag+blueFlagStart+ riskRate2Text +blueFlagEnd;
                levelOfRisk2Text =redStarFlag+blueFlagStart+ levelOfRisk2Text +blueFlagEnd;
                riskHappenedOrNotText =redStarFlag+blueFlagStart+ riskHappenedOrNotText +blueFlagEnd;
                // problemIdText =redStarFlag+blueFlagStart+ problemIdText +blueFlagEnd;
                problemIdText =blueFlagStart+ problemIdText +blueFlagEnd;
            }
            if(riskPQASureAllowEdit){
                businessStatusText =redStarFlag+blueFlagStart+ businessStatusText +blueFlagEnd;
                // pqaEnsureText =redStarFlag+blueFlagStart+ pqaEnsureText +blueFlagEnd;
                // pqaRemarkText =redStarFlag+blueFlagStart+ pqaRemarkText +blueFlagEnd;
                pqaRemarkText =blueFlagStart+ pqaRemarkText +blueFlagEnd;
            }
        // }
        var click="1";
        //导入panel
        var uploadForm =  new Ext.form.Panel({
            layout:'form',
            id:'uploadForm',
            name:'uploadForm',
            width:450,
            //height:460, //注意一定要给高度固定值才会出滚动条
            //autoScroll: true,
            border:0,
            tbar:[{
                xtype: 'filefield',
                name: 'riskAssessFile',
                id:'riskAssessFile',
                msgTarget: 'side',
                fieldLabel: '上传Excel文件',
                width: 280,
                anchor: '100%',
                buttonText: '选择文件..',
                buttonOnly: false,
                buttonMargin : '5 5 5 5'
            },{
                xtype:'button',
                padding: '5 5 5 5',
                id:'technic_submit',
                //disabled: existManufacturingViewPart?false:true,
                text: '开始导入',
                handler:function() {
                    var mainForm = Ext.getCmp('uploadForm').getForm();
                    var furl = "";  //文件物理地址
                    var fname=""; //文件名称
                    furl = Ext.getCmp("riskAssessFile").getValue();
                    //alert(furl);
                    if(furl == "") {
                        alert("请先选择文件！");
                        return false;
                    }

                    mainForm.submit({
                        url:'/Windchill/ptc1/risk/importRiskAssess?proOid='+proOid+'&oid='+oid+'&activityName='+activityName,
                        waitMsg : '正在导入......',
                        waitTitle : '请等待',
                        // method : 'POST',
                        success: function(form,action) {
                            var obj = action.result;
                            if(obj.success) {
                                alert(obj.msg);
                                Ext.getStore('ctRiskAssessStore').reload();
                            } else {
                                alert(obj.msg);
                                Ext.getStore('ctRiskAssessStore').reload();
                            }
                            uploadPlanWindow.close();
                        },
                        failure: function(form,action) {
                            var obj = action.result;
                            alert(obj.msg);
                        },
                        scope : this
                    });
                }
            }]
        });
        //导入窗口
        var uploadPlanWindow = new Ext.create('Ext.Window', {
            title: '批量导入问题',
            // width: 430,
            autoHeight : true,
            autoWidth : true,
            closeAction: 'hidden',
            y: '10%',
            id:'uploadProblemWindow',
            constrain: true,
            modal:true,
            layout:'fit',
            //border : 0,
            items: uploadForm
        });

        //==========================combe start
        var severityS='严重度S：分值越高，说明越严重；9-10分，不安全；7-8分，丧失基本功能；5-6分，不舒服不方便；  2-4分，能感知到的影响；1分，不影响。';
        var occurrenceO='发生度O：分值越高，说明越容易发生；9-10分，不可避免；7-8分，可能重复失效；4-6分，可能偶尔失效；  2-3分，很少失效；1分，不可能失效';
        var detectionD='探测度D：分值越高，说明越不容易检验出；8-10分，不能确定；6-7分，确定能力低；4-5分，确定能力中等；   2-3分，确定度高；1分，完全确定';
        var whetherPassCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'whetherPassCombo',
            name: 'whetherPassCombo',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["驳回", "驳回"], ["通过", "通过"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo',
            name: 'numberCombo',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo2 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo2',
            name: 'numberCombo2',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo3 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo3',
            name: 'numberCombo3',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo4 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo4',
            name: 'numberCombo4',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo5 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo5',
            name: 'numberCombo5',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var numberCombo6 = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            id: 'numberCombo6',
            name: 'numberCombo6',
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["10", "10"], ["9", "9"], ["8", "8"],["7", "7"],
                    ["6", "6"], ["5", "5"], ["4", "4"],["3", "3"], ["2", "2"],["1", "1"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var phaseCombo = new Ext.form.field.ComboBox({
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'phaseCombo',
            name: 'phaseCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["charter-TR2", "charter-TR2"], ["TR2-PDCP", "TR2-PDCP"], ["PDCP-TR4", "PDCP-TR4"],["TR4-TR4A", "TR4-TR4A"],
                    ["TR4A-TR5", "TR4A-TR5"], ["TR5-TR6", "TR5-TR6"], ["TR6-LDCP", "TR6-LDCP"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var riskCombo = new Ext.form.field.ComboBox({
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'riskCombo',
            name: 'riskCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["需求不确定", "需求不确定"], ["进度要求", "进度要求"], ["新设计", "新设计"],["新工艺", "新工艺"],
                    ["新物料", "新物料"], ["新应用", "新应用"], ["新过程", "新过程"],["新供应商", "新供应商"],
                    ["法规要求", "法规要求"], ["人力要求", "人力要求"], ["成本要求", "成本要求"],["售后要求", "售后要求"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var deptCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'deptCombo',
            name: 'deptCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["产品管理", "产品管理"], ["项目管理", "项目管理"], ["硬件", "硬件"],["软件", "软件"],
                    ["结构", "结构"], ["测试", "测试"], ["产品工程", "产品工程"],["采购", "采购"],
                    ["制造", "制造"], ["PQA", "PQA"], ["质控", "质控"],["技术支持", "技术支持"],
                    ["销售", "销售"],["财务", "财务"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var problemIdCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : true,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'problemIdCombo',
            name: 'problemIdCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["是", "是"], ["否", "否"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var statusCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'statusCombo',
            name: 'statusCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["打开Open", "打开Open"],["关闭Close", "关闭Close"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        var responseCategoriesCombo = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : false,
            forceSelection: true, //forceSelection 是否能够手填
            id: 'responseCategoriesCombo',
            name: 'responseCategoriesCombo',
            mode: 'local',
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["规避Evade", "规避Evade"], ["转嫁Shift", "转嫁Shift"],["缓解Relieve", "缓解Relieve"],["接受Accept", "接受Accept"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
        });
        //用户下拉列表
        // var allUserStore_projectPlan = Ext.create('PLM.hr.CtAllUserStore', {
        //     storeId: 'allUserStore_projectPlan'
        // });
        var ctAllUserStore = Ext.create('Ext.data.Store', {
            model: 'ctAllUserModel',
            id: 'ctAllUserStore',
            autoSync: true,//同步更新
            pruneModifiedRecords: true,
            // forceSelection: true,//强制从列表中选择
            proxy: new Ext.data.HttpProxy({
                type: 'ajax',
                url: '/Windchill/ptc1/hr/getAllUser',
                method: 'GET',
                reader:{
                    type:'json',
                    totalProperty: 'totalCount',
                    rootProperty: 'data',
                    idProperty: 'id',//修改显示重复数据,叠加变更时数据库的id相同
                    messageProperty: 'message'
                }
            }),
            autoLoad: true
        });
        // var allUserStore_projectPlan = Ext.create('PLM.common.CtAllUserStore', {
        //     storeId: 'allUserStore_projectPlan'
        // });
        var allUserCombo_projectPlan = new Ext.form.field.ComboBox({
            multiSelect: false,
            anyMatch: true,
            editable : true,
            allowBlank : true,
            // triggerAction: 'all',
            queryMode: 'local',
            forceSelection: true, //forceSelection 是否能够手填
            id: 'hiddenName',
            // name: 'hiddenName',
            mode: 'remote',
            store: ctAllUserStore,
            valueField: 'no',
            displayField: 'userFullName',

        });

        //======start


        Ext.define('PLM.common.CtProblemNumberCombo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtProblemNumberCombo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            displayField: 'problemNumber',
            valueField: 'problemNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true
        });
        //======end
        Ext.define('PLM.common.CtProblemNumberStore',{
            extend:'Ext.data.Store',
            alias:'widget.CtProblemNumberStore',
            fields:['problemNumber'],
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/problemMgt/getProblemByNumber?oid=' + oid ,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    //idProperty: 'id',
                    messageProperty: 'message'
                }
            }),
            autoLoad:false
        });

        Ext.define('PLM.common.CtProblemNumberCombo',{
            extend:'Ext.form.field.ComboBox',
            alias:'widget.CtProblemNumberCombo',
            typeAhead: true,
            triggerAction: 'all',
            // queryMode: 'local',
            queryMode: 'remote',
            displayField: 'problemNumber',
            valueField: 'problemNumber',
            forceSelection:true,
            minChars: 2,
            allowBlank : true,
            editable : true,
            anyMatch: true
        });
        //用户下拉列表
        // var allUserStore_risk = Ext.create('PLM.common.CtAllUserStore',{
        //     storeId:'allUserStore_risk'
        // });

        // var allUserCombo_projectPlan = Ext.create('PLM.hr.CtAllUserCombo',{
        //     store:allUserStore_projectPlan
        // });

        //问题下拉列表
        var problemNumberStore = Ext.create('PLM.common.CtProblemNumberStore',{
            storeId:'problemNumberStore'
        });
        var problemNumberCombo = Ext.create('PLM.common.CtProblemNumberCombo',{
            store:problemNumberStore
        });



        //==========================combin end
        var ctRiskAssessGrid = Ext.create('Ext.grid.Panel', {
            plugins: [cellEditing],
            store: ctRiskAssessStore,
            id: 'ctRiskAssessGrid',
            title:'风险评估表单',
            // margin: '20 10 20 10',
            // forceFit: true,
            height:524,
            // autoScroll: true,
            // region: 'center',
            // height: '100%',
            listeners: {
                'beforeedit':function (editor, e, eOpts) {
                     severity=e.record.get("severity");
                     occurrence=e.record.get("occurrence");
                     detection=e.record.get("detection");
                     severity2=e.record.get("severity2");
                     occurrence2=e.record.get("occurrence2");
                     detection2=e.record.get("detection2");
                   let riskHappenedOrNot=e.record.get("riskHappenedOrNot");
                   let businessStatus=e.record.get("businessStatus");
                   let pqaEnsure=e.record.get("pqaEnsure");
                    var data=e.record;
                    var tField = e.field; //得到修改列
                    if(userName!='wcadmin'){
                        if(!riskSureAllowEdit&&!riskFollowAllowEdit&&!riskPQASureAllowEdit&&data.get("creator")!=name){
                            return false;
                        }
                        if(riskSureAllowEdit&&data.get("owner")!=name){
                            return false;
                        }
                    }
                    //风险已发生为是，不能编辑当前状态
                    if(riskHappenedOrNot==="是"){
                        if(tField==="businessStatus"||tField==="pqaEnsure"){
                            return false;
                        }
                    }
                    //pqa确认节点，如果当前状态为‘关闭Close’ 不能编辑
                    if(riskSureAllowEdit&&businessStatus==="关闭Close"){
                        if(tField==="problemId"||tField==="riskHappenedOrNot"){

                        }else {
                            return false;

                        }
                    }
                    //责任人填写节点，如果当前状态为‘关闭Close’ 不能编辑
                    if(riskPQASureAllowEdit&&businessStatus==="关闭Close"){
                        if(tField==="problemId"||tField==="riskHappenedOrNot"){

                        }else {
                            return false;

                        }
                    }
                },
            },
            selModel:Ext.create('Ext.selection.CheckboxModel',{mode:"MULTI",showHeaderCheckbox:true}),
            viewConfig: {enableTextSelection: true, forceFit: false},
            columns: [
                {xtype: 'rownumberer', text: '序号', width: 50, align: 'center'},
                {text: 'id', dataIndex: 'id', width: 120, menuDisabled: true, hidden: true, align: 'center'},
                {text: '风险提出', columns: [
                        {text: riskIdText, dataIndex: 'riskId',width: 100, menuDisabled: true,  align: 'center'},
                        {text: riskCreatPeopleText, dataIndex: 'riskCreatPeople',width: 120, menuDisabled: true,  align: 'center'},
                        {text: evaluationDeptText, dataIndex: 'evaluationDept',
                            // editor:allowEdit?deptCombo:null,
                            editor:null,
                            width: 100, menuDisabled: true},
                        {text: proposedTimeText, dataIndex: 'proposedTime', width: 120,
                            // editor:allowEdit?new Ext.form.DateField({ format: 'Y-m-d',}):null ,
                            editor:null ,
                            menuDisabled: true,align: 'center',
                            renderer: function(value,metaData,record,row,col,store){
                                if(value){
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                    value=value.substring(0,10);

                                }
                                return value;
                            }},
                        {text: projectPhaseText, dataIndex: 'projectPhase', editor: allowEdit?phaseCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: riskCategoryText, dataIndex: 'riskCategory',editor: allowEdit?riskCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: riskDescriptionText, dataIndex: 'riskDescription',editor: allowEdit?'textarea':null, width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            },
                            // renderer: function (value, meta, record) {
                            //     //自动换行
                            //     meta.style = 'white-space:normal;word-break:break-all;';
                            //     return value;
                            // }
                        },
                        {text: riskEffectText, dataIndex: 'riskEffect', width: 140,editor: allowEdit?'textarea':null, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            },},
                        {text: severityText, dataIndex: 'severity', editor:  allowEdit?numberCombo:null,tooltip:severityS,width: 120, menuDisabled: true, align: 'center'},
                        {text: occurrenceText, dataIndex: 'occurrence', editor:  allowEdit?numberCombo2:null,tooltip:occurrenceO,width: 120, menuDisabled: true, align: 'center'},
                        {text: detectionText, dataIndex: 'detection', editor:  allowEdit?numberCombo3:null,tooltip:detectionD,width: 120, menuDisabled: true, align: 'center'},
                        // {text: riskRateText, dataIndex: 'riskRate', editor: allowEdit?'textfield':null,width: 100, menuDisabled: true, align: 'center'},
                        {text: levelOfRiskText, dataIndex: 'levelOfRisk', editor:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {

                                if (value != null && value != undefined && value != '') {
                                    let whetherError= value.substring(0,5);
                                    let levelOfRiskKey ;
                                    let levelOfRiskDes ;
                                    if(whetherError=="Error"){
                                        levelOfRiskKey = value.substring(0,5);
                                        levelOfRiskDes = value.substring(5);
                                    }else{
                                        levelOfRiskKey = value.substring(0,1);
                                        levelOfRiskDes = value.substring(1);
                                    }

                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+levelOfRiskDes+"'";
                                    if(levelOfRiskKey=='H'||levelOfRiskKey=='M'||levelOfRiskKey=='Error'){
                                        levelOfRiskKey= '<span style="color:#FF0000;">'+levelOfRiskKey+'</span>';
                                    }
                                    return levelOfRiskKey;
                                }
                                return value;
                            },},

                        {text: ownerText, dataIndex: 'owner', editor: allowEdit||riskFollowAllowEdit?allUserCombo_projectPlan:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value, meta, record) {
                                // sleep(1000);
                                let displayName = value;
                                if(value){
                                    let riskByPurchaseAsscessStore = allUserCombo_projectPlan.getStore();
                                    riskByPurchaseAsscessStore.each(function(rec){
                                        if(rec.get('no') == value){
                                            displayName =  rec.get('userFullName');
                                        }
                                    });
                                }
                                return displayName;
                            }
                        },
                        {text: ownerDeptText, dataIndex: 'ownerDept',
                            // editor: allowEdit||riskFollowAllowEdit?'textfield':null,
                            editor: null,
                            width: 120, menuDisabled: true, align: 'center'},
                        {text: plannedFinishDateText, dataIndex: 'plannedFinishDate',width: 100, editor: allowEdit||riskFollowAllowEdit ?  {xtype:'datefield', minValue:new Date(),format:'Y-m-d'}: null,menuDisabled: true,
                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                return selfDateFormat(value);
                            } },
                        {text: whetherPassText, dataIndex: 'whetherPass', editor: riskFollowAllowEdit?whetherPassCombo:null,width: 120, menuDisabled: true, align: 'center'},
                    ], menuDisabled: true,
                },
                {text: '风险跟进', columns: [
                        {text: responseCategoriesText, dataIndex: 'responseCategories', editor: riskSureAllowEdit?responseCategoriesCombo:null,width: 120, menuDisabled: true, align: 'center',},
                        {text: actionsForRiskText, dataIndex: 'actionsForRisk', editor: riskSureAllowEdit?'textarea':null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: currentStatusText, dataIndex: 'currentStatus', editor: riskSureAllowEdit?'textfield':null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }
                        },
                        {text: severity2Text, dataIndex: 'severity2', editor:riskSureAllowEdit?numberCombo4:null,tooltip:severityS,width: 120, menuDisabled: true, align: 'center'},
                        {text: occurrence2Text, dataIndex: 'occurrence2',  editor:riskSureAllowEdit?numberCombo5:null,tooltip:occurrenceO,width: 120, menuDisabled: true, align: 'center'},
                        {text: detection2Text, dataIndex: 'detection2',  editor:riskSureAllowEdit?numberCombo6:null,tooltip:detectionD,width: 120, menuDisabled: true, align: 'center',},
                        // {text: riskRate2Text, dataIndex: 'riskRate2',  editor:  allowEdit?numberCombo:null,tooltip:detectionD,width: 120, menuDisabled: true, align: 'center'},
                        {text: levelOfRisk2Text, dataIndex: 'levelOfRisk2', editor:null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    let whetherError= value.substring(0,5);
                                    let levelOfRiskKey ;
                                    let levelOfRiskDes ;
                                    if(whetherError=="Error"){
                                        levelOfRiskKey = value.substring(0,5);
                                        levelOfRiskDes = value.substring(5);
                                    }else{
                                        levelOfRiskKey = value.substring(0,1);
                                        levelOfRiskDes = value.substring(1);
                                    }

                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+levelOfRiskDes+"'";
                                    if(levelOfRiskKey=='H'||levelOfRiskKey=='M'||levelOfRiskKey=='Error'){
                                        levelOfRiskKey= '<span style="color:#FF0000;">'+levelOfRiskKey+'</span>';
                                    }
                                    return levelOfRiskKey;
                                }
                                return value;
                            },},
                        {text: riskHappenedOrNotText, dataIndex: 'riskHappenedOrNot', editor: riskSureAllowEdit?problemIdCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        // {text: problemIdText, dataIndex: 'problemId', editor: riskSureAllowEdit?problemNumberCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: problemIdText, dataIndex: 'problemId', editor: riskSureAllowEdit?true:null,width: 120, menuDisabled: true, align: 'center',

                            renderer: function(value,metaData,record,row,col,store){
                                if(value)
                                    metaData.tdAttr = 'data-qtip="' + value +'"';
                                if(value) {
                                    var docLink = "<a href='" + urlPathPrefix +record.get('containerId') +"' target='_blank' >"
                                        + value + "</a>";
                                    return docLink;
                                }else {
                                    return value;
                                }
                            },
                        },
                        // {text: problemIdText, dataIndex: 'problemId', editor: riskSureAllowEdit||riskPQASureAllowEdit?'textfield':null,width: 120, menuDisabled: true, align: 'center'},

                    ], menuDisabled: true,
                },
                {text: '风险确认', columns: [
                        {text: businessStatusText, dataIndex: 'businessStatus', editor:riskPQASureAllowEdit?statusCombo:null,width: 120, menuDisabled: true, align: 'center'},
                        {text: pqaEnsureText, dataIndex: 'pqaEnsure',
                            // editor: riskPQASureAllowEdit?new Ext.form.DateField({ format: 'Y-m-d',}):null,
                            editor:null,
                            menuDisabled: true,align: 'center',
                            renderer: function (value) {

                                if(value!=null){
                                    value=value.trim();
                                }else {
                                    value='';
                                }
                                return value;

                            }},
                        {text: pqaRemarkText, dataIndex: 'pqaRemark', editor:riskPQASureAllowEdit?'textarea':null,width: 120, menuDisabled: true, align: 'center',
                            renderer: function (value,metaData) {
                                if (value != null && value != undefined && value != '') {
                                    //提示tip
                                    metaData.tdAttr = " data-qtip = '"+value+"'";
                                    return value;
                                }
                                return value;
                            }},
                        {text: branchIdText, dataIndex: 'branchId', editor: riskPQASureAllowEdit?'textfield':null,width: 120, menuDisabled: true, align: 'center',hidden: true,},
                    ], menuDisabled: true,
                },
            ],
            // bbar: Ext.create('Ext.PagingToolbar', {
            //     store: Ext.data.StoreManager.lookup('ctRiskAssessStore'),
            //     displayInfo: true,
            //     displayMsg: '当前显示 {0} - {1} ，共 {2}',
            //     emptyMsg: "查询结果为空",
            //     items:[{
            //         text: '查询全部',
            //         scope: this,
            //         id:'queryAll',
            //         handler:function(){
            //             isPageQuery=false;
            //             ctRiskAssessStore.pageSize=ctRiskAssessStore.getTotalCount();
            //             ctRiskAssessStore.currentPage = 1;
            //             refreshRequireStore();
            //             Ext.getCmp("queryAll").hide();
            //             Ext.getCmp("pageQuery").show();
            //         }
            //     },{
            //         text: '分页查询',
            //         scope: this,
            //         id:'pageQuery',
            //         hidden:true,
            //         handler:function(){
            //             isPageQuery=true;
            //             ctRiskAssessStore.pageSize=25;
            //             refreshRequireStore();
            //             Ext.getCmp("pageQuery").hide();
            //             Ext.getCmp("queryAll").show();
            //         }
            //     }]
            // }),//~End bbar
            tbar: [{
                iconCls : 'icon-add',
                xtype: 'button',
                id: "addData",
                text: '添加',
                hidden:addHidden?false:true,
                handler: function(){
                    Ext.Ajax.request({
                        scope:this,
                        url: '/Windchill/ptc1/risk/genRiskFromData',
                        method:'POST',
                        params:{
                            proOid:proOid,
                            oid:oid,
                        },
                        success: function(response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if(obj.message=="success") {
                                Ext.getStore('ctRiskAssessStore').reload();
                            }else{
                                alert(obj.message);
                            }
                        },
                        failure: function(response, opts) {
                            alert('错误：保存信息失败，请检查网络！');
                        }
                    });
                }
            },{
                text: '删除 ',
                iconCls : 'icon-delete',
                xtype: 'button',
                id: "removeData",
                hidden:addHidden?false:true,
                handler: function () {
                    let selectionArr = ctRiskAssessGrid.getSelectionModel().getSelection();
                    if (selectionArr==undefined||selectionArr==null||selectionArr.length==0){
                        Ext.Msg.alert("提示","请选择要删除的数据");
                        return;
                    }
                    //数据组装
                    let obj = new Array();
                    let obj2 = new Array();
                    let obj3 = new Array();
                    let obj4 = new Array();
                    let obj5 = new Array();
                    let obj6 = new Array();
                    let timeObj = new Array();
                    Ext.each(selectionArr,function(record){
                        obj.push(record.data['id']),
                        obj2.push(record.data['creator']),
                        obj3.push(record.data['currentStatus']),
                        obj4.push(record.data['riskId']),
                        obj5.push(record.data['riskHappenedOrNot']),
                        obj6.push(record.data['whetherPass']),
                        timeObj.push(record.data['createTime'])

                    });
                    var callbackFn = function () {
                        Ext.getStore('ctRiskAssessStore').reload()
                    };
                    //判断能否删除数据--自己创建得才能删除
                    let flag=false;
                    let mes="";
                    let mes2="";
                    let mes3="";
                    obj2.forEach((item,index,array)=>{
                        if(userName!="wcadmin"&&item!=name){
                            flag=true;
                        }
                        mes+=obj4[index]+"\n";
                    })

                    //判断能否删除数据--已跑到下一节点得数据无法删除
                    let nextFlag=true;
                    let riskHappenFlag=false;
                    // obj3.forEach((item,index,array)=>{
                    //     console.log("item==="+item+"");
                    //     console.log(item==undefined||item==''||item==null);
                    //     if(item==undefined||item==''||item==null){
                    //         nextFlag=false;
                    //     }
                    //     mes2+=obj4[index]+"\n";
                    // })
                    timeObj.forEach((item,index,array)=>{
                        //比较时间
                            // console.log(new Date(item).getTime()>new Date(startTime).getTime());
                            if(new Date(item).getTime()>new Date(startTime).getTime()){
                                nextFlag=false;
                            }
                            mes2+=obj4[index]+"\n";
                        })
                     obj5.forEach((item,index,array)=>{
                         console.log("item==="+item+"");
                         console.log(item==undefined||item==''||item==null);
                         console.log(obj6[index]);
                         
                         if((item==undefined||item==''||item==null) && obj6[index]== '驳回'){
                        	 riskHappenFlag=true;
                         }else{
                        	 mes3+=obj4[index]+"\n"; 
                         }
                     })    
                    if(nextFlag){
                    	if(mes3 != ""){
                    		alert("你无法删除已到下一节点的风险条目!!!\n对应风险ID：\n"+mes3);
                            return;
                    	}
                    }
                    if(flag){
                        alert("你无法删除不为你所有的数据!!!\n对应风险ID：\n"+mes);
                        return;
                    }
                    deleteData(obj,callbackFn);

                }
            },{
                text: 'Excel导入',
                hidden:addHidden?false:true,
                iconCls: 'icon-excelImport',
                xtype: 'button',
                id: "excelInputData",
                handler : function() {
                    uploadPlanWindow.show();
                },
            },{
                iconCls: 'icon-excelExport',
                // xtype: 'button',
                id: "excelOutputData",
                text: 'Excel导出',
                handler : function () {
                    this.exportReport();
                },
                scope : this
            },{
                iconCls: 'icon-download ',
                xtype: 'button',
                id: "downTemplate",
                text: '下载模板',
                handler: function(){
                    window.location.href='/Windchill/template/riskAssessExportTemplate.xlsx','','width=200,height=100' ;
                }
            },{
                iconCls: 'icon-myself',
                xtype: 'button',
                id: "showMyself",
                text: '显示个人',
               // hidden:riskFollowAllowEdit||riskPQASureAllowEdit?true:false,
               //  hidden:(allowEdit||riskSureAllowEdit)&&!riskFollowAllowEdit&&!riskPQASureAllowEdit?true:false,
                hidden:showMyselfHidden?false:true,

                handler: function(){
                    Ext.getStore('ctRiskAssessStore').load({
                        params: {
                            proOid:proOid,
                            oid:oid,
                            owner:'',
                            isPageQuery:isPageQuery,
                            activityName:activityName,
                        },
                        callback: function (records, operation, success) {
                            if (!success) {
                                if (typeof (operation.error) == 'string') {
                                    alert(operation.error);
                                } else {
                                    // alert('查询超时！请重试！')
                                }
                            }
                        }
                    });
                    Ext.getCmp("showAll").show();
                    Ext.getCmp("showMyself").hide();
                    // click="1";
                },
            },{
                iconCls: 'icon-team',
                text: '显示全部',
                scope: this,
                // hidden:(allowEdit||riskSureAllowEdit)&&!riskFollowAllowEdit&&!riskPQASureAllowEdit?true:false,
                hidden:true,
                id:'showAll',
                handler:function(){

                    Ext.getStore('ctRiskAssessStore').load({
                        params: {
                            proOid:proOid,
                            owner:name,
                            oid:oid,
                            isPageQuery:isPageQuery,
                            activityName:activityName,
                        },
                        callback: function (records, operation, success) {
                            if (!success) {
                                if (typeof (operation.error) == 'string') {
                                    alert(operation.error);
                                } else {
                                    // alert('查询超时！请重试！')
                                }
                            }
                        }
                    });
                    Ext.getCmp("showMyself").show();
                    Ext.getCmp("showAll").hide();
                }
            }
            ,{

                    text: '风险转问题',
                    id: 'add',
                    name: 'add',
                    hidden:riskToProblemButton,
                    scope: this,
                    handler: function () {
                        var editRecords = Ext.getCmp('ctRiskAssessGrid').getSelectionModel().getSelection();
                        if (editRecords.length == 0) {
                            alert("请选择要转问题的风险信息！");
                            return;
                        } else{
                            ctRiskAssessGridRecords = editRecords;
                            Ext.getCmp('projectNumber').setValue(projectNumber);
                            Ext.getCmp('projectName').setValue(projectName);
                            PDMLinkProductStore.load();
                            requireWin2.show();
                        }
                    }
                },
            ]

        });

        ctRiskAssessGrid.on('edit',
            function (editor, e) {
                var tRecord = e.record; //得到当前行所有数据
                var tField = e.field; //得到修改列
                var value = e.value; //得到修改列

                if((tField=="severity"&&e.value==severity)||(tField=="occurrence"&&e.value==occurrence)
                ||(tField=="detection"&&e.value==detection)||(tField=="severity2"&&e.value==severity2)
                ||(tField=="occurrence2"&&e.value==occurrence2)||(tField=="detection2"&&e.value==detection2)) {
                    tRecord.commit();
                    return;
                }
                var callbackFn = function () {
                    if(tField=='severity'||tField=='occurrence'||tField=='detection'
                        ||tField=='severity2'||tField=='occurrence2'||tField=='detection2'
                        ||tField=='owner'||tField=='pqaEnsure'||tField=='businessStatus'
                        ||tField=='riskHappenedOrNot'||tField == 'problemId'){
                        Ext.getStore('ctRiskAssessStore').reload()
                    }
                };
                if(tField == 'problemId'){
                    if (value != ""){
                        var isCorrect = checkProblemNumber(value);
                        if (!isCorrect) {
                            Ext.getStore('ctRiskAssessStore').reload()
                            return;
                        }
                    }
                }
                updateProblem(tRecord.data,callbackFn,tRecord,tField,value);
            });

        this.items = [ ctRiskAssessGrid];

        this.callParent();
    },

    exportReport: function() {
        //如果没有勾选默认导出全部
        let selectionArr = Ext.getCmp('ctRiskAssessGrid').getSelectionModel().getSelection();
        // if (selectionArr==undefined||selectionArr==null||selectionArr.length==0){
        //     // console.log("导出全部")
        //     // let obj = new Array();
        //     // Ext.getStore('ctRiskAssessStore').each(function(record) {
        //     //     let data =getSearchData(record);
        //     //     console.log("导出全部"+JSON.stringify(data));
        //     //     obj.push(data);
        //     // });
        //     window.location.href = '/Windchill/ptc1/risk/exportRiskAssess?proOid='+proOid+'&oid=' + oid + '';
        //     // window.location.href = '/Windchill/ptc1/risk/exportRiskAssess?data='+JSON.stringify(obj)+'&oid=' + oid + '';
        //
        // }else {
            // let obj = new Array();
            // Ext.each(selectionArr,function(record){
            //     let data =getSearchData(record);
            //     obj.push(data)
            // });
            window.location.href = '/Windchill/ptc1/risk/exportRiskAssess?proOid='+proOid+'&oid=' + oid + '';
            // window.location.href = '/Windchill/ptc1/risk/exportRiskAssess?data='+Ext.encode(obj)+'&oid=' + oid + '';
        // }

    },
    listeners: {
        'afterrender': function () {
        },
        'beforerender': function () {

           Ext.getStore('ctAllUserStore').load({
                params: { },
                callback: function (records, operation, success) {
                    if(success){
                        Ext.getStore('ctRiskAssessStore').load({
                            params: {
                                proOid:proOid,
                                oid:oid,
                                owner:riskFollowAllowEdit||riskPQASureAllowEdit?'':name,
                                isPageQuery:isPageQuery,
                                activityName:activityName,
                            },
                            callback: function (records, operation, success) {
                                if (!success) {
                                    if (typeof (operation.error) == 'string') {
                                        alert(operation.error);
                                    } else {
                                        // alert('查询超时！请重试！')
                                    }
                                }
                            }
                        });
                    }
                    if (!success) {
                        if (typeof (operation.error) == 'string') {
                            alert(operation.error);
                        } else {
                            // alert('查询超时！请重试！')
                        }
                    }
                }
            });
        },

    },

});

function sleep(numberMillis) {
    var now = new Date();
    var exitTime = now.getTime() + numberMillis;
    while (true) {
        now = new Date();
        if (now.getTime() > exitTime)
            return;
    }
}

/**
 * 加载Combobox的store
 * @param callback
 */
function loadComboboxStore() {
    Ext.Ajax.request({
        url: '/Windchill/ptc1/hr/getAllUser',
        method: 'GET',
        async: false,
        headers: {'Content-Type': 'application/json'},
        timeout: 99999999,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                var configMap = obj['data'];
                for (let comboboxId in configMap) {
                    let store = Ext.data.StoreManager.lookup(comboboxId);
                    if (store !== undefined) {
                        store.loadData(configMap[comboboxId]);
                    }
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：获取信息失败，请检查网络！');
        }
    }); // ~End of Ajax request
}
/**
 * 加载Combobox的store
 * @param callback
 */
function loadComboboxStore2() {
    Ext.Ajax.request({
        url: '/Windchill/ptc1/risk/getDataByBranchId',
        method: 'GET',
        async: false,
        headers: {'Content-Type': 'application/json'},
        timeout: 99999999,
        success: function (response, opts) {
            var obj = Ext.decode(response.responseText);
            if(obj.message=="success") {
                var configMap = obj['data'];
                for (let comboboxId in configMap) {
                    let store = Ext.data.StoreManager.lookup(comboboxId);
                    if (store !== undefined) {
                        store.loadData(configMap[comboboxId]);
                    }
                }
            } else {
                alert(obj.message);
            }
        },
        failure: function (response, opts) {
            alert('错误：获取信息失败，请检查网络！');
        }
    }); // ~End of Ajax request
}

function refreshRequireStore(){
    Ext.getStore('ctRiskAssessStore').load({
        params: {
            proOid:proOid,
            oid:oid,
            owner:'',
            isPageQuery:isPageQuery,
            activityName:activityName,
        },
        callback: function(records, operation, success) {
            if(!success){
                alert('查询信息失败，请联系管理员！');
            }else {
                // if(allowExport) {
                //     Ext.getCmp("upload1").enable();
                // }else {
                //     Ext.getCmp("upload1").disable();
                // }
            }
        }
    });
}
function refreshRequireStore2(){
    Ext.getStore('ctRiskAssessStore').reload({
        params: {
            proOid:proOid,
            oid:oid,
            owner:riskFollowAllowEdit||riskPQASureAllowEdit?'':name,
            isPageQuery:isPageQuery,
            activityName:activityName,
        },
        callback: function(records, operation, success) {
            if(!success){
                alert('查询信息失败，请联系管理员！');
            }else {
                // if(allowExport) {
                //     Ext.getCmp("upload1").enable();
                // }else {
                //     Ext.getCmp("upload1").disable();
                // }
            }
        }
    });
}

//日期 renderer,防止IE下日期显示异常
function selfDateFormat(value) {

    if(value instanceof Date){
        return Ext.Date.format(value,"Y-m-d");
    }
    return value;
}


//'id' ,'riskId','evaluationDept','proposedTime','projectPhase','riskCategory','riskDescription','riskEffect','severity','occurrence',
//'detection','levelOfRisk','responseCategories','actionsForRisk','ownerDept','owner','plannedFinishDate','currentStatus','severity2',
//'occurrence2' ,'detection2','levelOfRisk2','businessStatus','riskHappenedOrNot','pqaEnsure','pqaRemark','branchId'



////////////////////Function Area//////////////////////////////





