<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.maturity.PromotionNotice" %>
<%@ page import="wt.workflow.engine.WfProcess" %>
<%@ page import="ext.plm.util.CtWorkFlowUtil" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.org.WTUser" %>
<%@ page import="wt.session.SessionHelper" %>
<%@ page import="ext.plm.risk.config.CtRiskConstant" %>
<%@ page import="ext.plm.risk.config.CtRiskProperties" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        String proOid="";
        boolean allowEdit=false;
        boolean riskSureAllowEdit=false;
        boolean riskFollowAllowEdit=false;
        boolean riskPQASureAllowEdit=false;
        String activityName="";
        System.out.println(">>>in ctRiskMgt.jsp oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workItem =null;
        Persistable object = rf.getReference(oid).getObject();
        String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
//        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
//        owner=user.getFullName();
        if(object instanceof WTDocument){
            proOid= CtWTObjectUtil.getVid(object);
        }else if(object instanceof WorkItem){
            workItem = (WorkItem)rf.getReference(oid).getObject();
            Persistable object2 = workItem.getPrimaryBusinessObject().getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            activityName=activity.getName();

            if(object2 instanceof PromotionNotice){
                PromotionNotice promotionNotice = (PromotionNotice)object2;
                proOid = CtWTObjectUtil.getOid(promotionNotice);
            }else if(object2 instanceof WTDocument){
                proOid= CtWTObjectUtil.getVid(object2);
            }
        }

        wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
        String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/ext/plm/problem/ctProblemMgtIframe?oid=";

//        if (workItem.isComplete()){
//            allowEdit = false;
//            riskFollowAllowEdit = false;
//            riskFollowAllowEdit = false;
//            riskPQASureAllowEdit = false;
//        };
//        if (CtFormatUtil.hasContent(workItem)){
//            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
//            String activityName=activity.getName();
//            System.out.println(activityName);
//            if (!workItem.isComplete()){
//                allowEdit = true;
//            };
//        }
    %>

    <SCRIPT type="text/javascript">
        var oid ='<%= oid %>';
        var proOid ='<%= proOid %>';
        var activityName ='<%= activityName %>';
        //当前用户全名
        var userName = "<%=userName%>";
        var allowEdit = false;
        var riskSureAllowEdit = false;
        var riskFollowAllowEdit = false;
        var riskPQASureAllowEdit = false;
        //是否为分页查询
        var isPageQuery = true;
        var isShowAllRequire = false;
        console.log(riskFollowAllowEdit+activityName);
        var urlPathPrefix ="<%=urlPathPrefix%>";
    </SCRIPT>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <%--    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/common/jquery-2.0.0.min.js=<%=System.currentTimeMillis()%>"></script>--%>
    <!-- ExtJS -->
    <script type="text/javascript" src="js/ctRiskMgtReadOnly.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctRiskMgtFunctions.js?_dc=<%System.currentTimeMillis();%>"></script>

</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ctRiskMgt',
            }]
        });
    });
</script>
</body>
</html>