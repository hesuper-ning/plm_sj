<%@ page import="wt.doc.WTDocument" %>
<%@ page import="wt.fc.Persistable" %>
<%@ page import="wt.workflow.work.WorkItem" %>
<%@ page import="wt.maturity.PromotionNotice" %>
<%@ page import="wt.workflow.engine.WfProcess" %>
<%@ page import="wt.workflow.work.WfAssignedActivity" %>
<%@ page import="wt.org.WTUser" %>
<%@ page import="wt.session.SessionHelper" %>
<%@ page import="ext.plm.risk.config.CtRiskConstant" %>
<%@ page import="ext.plm.risk.config.CtRiskProperties" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="com.ptc.core.components.util.TimeZoneHelper" %>
<%@ page import="java.util.Date" %>
<%@ page import="ext.plm.risk.CtRiskLogic" %>
<%@ page import="wt.projmgmt.admin.Project2" %>
<%@ page import="ext.plm.util.*" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        String proOid="";
        boolean allowEdit=false;
        boolean riskSureAllowEdit=false;
        boolean riskFollowAllowEdit=false;
        boolean riskPQASureAllowEdit=false;
        boolean riskToProblemButton = false;
        String activityName="";
        String adminUser="";
        System.out.println(">>>in ctRiskMgt.jsp oid="+oid);
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        WorkItem workItem =null;
        Persistable object = rf.getReference(oid).getObject();
        String userName = ext.plm.util.CtUserUtil.getCurrentUserDisplayName();
        String name = ext.plm.util.CtUserUtil.getCurrentUserAccountName();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        simpleDateFormat.setTimeZone(TimeZoneHelper.getTimeZone());
//        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
//        owner=user.getFullName();


        String aaa= "";
        String startTime= "";
        String projectNumber = "";
        String projectName = "";
        WTDocument doc = null;

        if(object instanceof WTDocument){
            proOid= CtWTObjectUtil.getVid(object);
            doc = (WTDocument)object;
        }else if(object instanceof WorkItem){
            workItem = (WorkItem)rf.getReference(oid).getObject();
            Persistable object2 = workItem.getPrimaryBusinessObject().getObject();
            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
            startTime = simpleDateFormat.format(new Date(activity.getStartTime().getTime()));
            activityName=activity.getName();
            //获取工作负责人  如果是管理员就将当前用户改为工作负责人
            if (userName.equals("wcadmin")) {
                adminUser = workItem.getOwnership().getOwner().getFullName();
            }else {
                adminUser=userName;
            }
            if(object2 instanceof PromotionNotice){
                PromotionNotice promotionNotice = (PromotionNotice)object2;
                proOid = CtWTObjectUtil.getOid(promotionNotice);
            }else if(object2 instanceof WTDocument){
                proOid= CtWTObjectUtil.getVid(object2);
                doc = (WTDocument)object2;
            }
        }

        if(CtFormatUtil.hasContent(doc)){
            IBAUtil ibaUtil = new IBAUtil(doc);
            projectNumber = ibaUtil.getIBAValue("ct_ItemNumber");
            if(CtFormatUtil.hasContent(projectNumber)) {
                Project2 p2 = CtProjectUtil.getProjectByNumber(projectNumber);
                projectName = p2.getName();
            }
        }

        //编辑权限判断
        //提交&&风险录入
         allowEdit = CtRiskLogic.hasEditAccess(workItem,
                 CtRiskProperties.getProperties("risk_allowEdit_roles"));
        if(allowEdit&&(activityName.contains("开启")||activityName.contains("确认"))){
            allowEdit = false;
        }

        System.out.println("==========================getCreateTimestamp"+workItem.getCreateTimestamp());
        //责任人填写
        riskSureAllowEdit = CtRiskLogic.hasEditAccess(workItem,
                CtRiskProperties.getProperties("risk_riskSureAllowEdit_roles"));
        //PQA审核
        riskFollowAllowEdit = CtRiskLogic.hasEditAccess(workItem,
                CtRiskProperties.getProperties("risk_riskFollowAllowEdit_roles"));
        if(riskFollowAllowEdit&&!activityName.contains("审核")){
            riskFollowAllowEdit = false;
        }
        //PQA确定
        riskPQASureAllowEdit = CtRiskLogic.hasEditAccess(workItem,
                CtRiskProperties.getProperties("risk_riskPQASureAllowEdit_roles"));
        if(riskPQASureAllowEdit&&!activityName.contains("确认")){
            riskPQASureAllowEdit = false;
        }
        if (workItem.isComplete()){
            allowEdit = false;
            riskFollowAllowEdit = false;
            riskSureAllowEdit = false;
            riskPQASureAllowEdit = false;
        };

        if("三江电子-风险管理审批流程-责任人填写".equals(activityName)){
            riskToProblemButton = true;
        }

        wt.httpgw.URLFactory url = new wt.httpgw.URLFactory();
        String urlPathPrefix = url.getBaseHREF() + "app/#ptc1/ext/plm/problem/ctProblemMgtIframe?oid=";

//        if (CtFormatUtil.hasContent(workItem)){
//            WfAssignedActivity activity = (WfAssignedActivity)workItem.getSource().getObject();
//            String activityName=activity.getName();
//            System.out.println(activityName);
//            if (!workItem.isComplete()){
//                allowEdit = true;
//            };
//        }
    %>
    
    <SCRIPT type="text/javascript">
        var oid ='<%= oid %>';
        var startTime ='<%= startTime %>';
        var proOid ='<%= proOid %>';
        var activityName ='<%= activityName %>';
        //当前用户全名
        var userName = "<%=userName%>";
        var name = "<%=name%>";
        var adminUser = "<%=adminUser%>";
        var allowEdit = false;
        <%if(allowEdit){ %>
        allowEdit = true;
        <%}%>
        var riskSureAllowEdit = false;
        <%if(riskSureAllowEdit){ %>
        riskSureAllowEdit = true;
        <%}%>
        var riskFollowAllowEdit = false;
        <%if(riskFollowAllowEdit){ %>
        riskFollowAllowEdit = true;
        <%}%>
        var riskPQASureAllowEdit = false;
        <%if(riskPQASureAllowEdit){ %>
        riskPQASureAllowEdit = true;
        <%}%>
        //是否为分页查询
        var isPageQuery = false;
        var isShowAllRequire = false;
        console.log(name)
        var imgs = '';
        var userDisplayName = "<%=userName%>";
        var containerId = '';
        //问题编号
        var problemId = "";
        var projectNumber = "<%=projectNumber%>";
        var projectName = "<%=projectName%>";
        var ctRiskAssessGridRecords = '';

        var riskToProblemButton = true;
        <%if(riskToProblemButton){ %>
        riskToProblemButton = false;
        <%}%>

        var urlPathPrefix ="<%=urlPathPrefix%>";
    </SCRIPT>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-crisp/resources/theme-crisp-all.css">
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/classic/locale/locale-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/ctCommonObjects.js?_dc=<%=System.currentTimeMillis()%>"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
<%--    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/common/jquery-2.0.0.min.js=<%=System.currentTimeMillis()%>"></script>--%>
    <!-- ExtJS -->
    <script type="text/javascript" src="js/ctRiskMgt.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="js/ctRiskMgtFunctions.js?_dc=<%System.currentTimeMillis();%>"></script>
    <script type="text/javascript" src="../problem/js/uploadImagePanel.js?_dc=<%=System.currentTimeMillis()%>"></script>

</head>

<body>
<script>
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();
        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ctRiskMgt',
            }]
        });
    });
</script>
</body>
</html>