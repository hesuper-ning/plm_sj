<%@ page import="ext.plm.part.config.CtPartConstant" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        String value = request.getParameter("value");
        boolean hideFlag = false;
        if(oid != null && oid.contains("WTUser")) {
            hideFlag = true;
        }
        String attName = "Ct_AssociatedDesignViewPart";
    %>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-6.2.0/classic/theme-gray/resources/theme-gray-all.css">
    <link rel="stylesheet" type="text/css" href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" />
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-6.2.0/ext-all-debug.js"></script>
    <script type="text/javascript" src="../common/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="js/ctMultiplePartSearch.js?_dc=<%System.currentTimeMillis();%>"></script>
</head>

<body>
<script>
    var attName = '<%=attName%>';
    var hideFlag = <%=hideFlag%>;
    var selectNumbers = '<%=value%>';
    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [
                {
                    region: 'center',
                    xtype: 'MultiplePartSearchPanel'
                }
            ]
        });
    });
</script>
</body>
</html>