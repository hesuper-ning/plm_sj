<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@ page import="wt.part.WTPart" %>
<%@ page import="ext.plm.util.CtWTObjectUtil" %>
<%@ page import="ext.plm.adTool.CtAdToolLogic" %>
<%@ page import="com.alibaba.fastjson.JSONObject" %>
<%@ page import="java.net.URLDecoder" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        // 解码
        oid = URLDecoder.decode(oid, "UTF-8");
        WTPart part = (WTPart) CtWTObjectUtil.getObjectByOid(oid);
        // 获取物料信息
        Map<String, String> partInfoMap = CtAdToolLogic.getInstance().getPartInfo(part);
        partInfoMap.put("oid", oid);
        String partInfoJsonStr = JSONObject.toJSONString(partInfoMap);
        // 处理带有转义字符
        partInfoJsonStr = partInfoJsonStr.replace("\\", "\\\\");
    %>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/part/js/ctUpdatedVersion.js?_dc=<%=System.currentTimeMillis()%>"></script>
</head>
<body>
<script>
    var partInfo = Ext.JSON.decode('<%= partInfoJsonStr %>', 'UTF-8');
    console.log('partInfo', partInfo);
    var loadMask = new Ext.LoadMask(Ext.getBody(),{
        msg:'正在更新中......',
        removeMask : true
    });

    // ==============layout define area=================================//
    Ext.onReady(function() {
        Ext.QuickTips.init();

        Ext.create('Ext.container.Viewport', {
            layout: 'border',
            items: [{
                region: 'center',
                xtype: 'ctUpdatedVersionPanel'
            }]
        });
    });
</script>
</body>
</html>