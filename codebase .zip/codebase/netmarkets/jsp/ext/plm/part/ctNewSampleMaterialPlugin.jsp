<%@ page import="ext.plm.util.CtFormatUtil" %>
<%@ page import="wt.part.WTPart" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <%
        String oid = request.getParameter("oid");
        wt.fc.ReferenceFactory rf = new wt.fc.ReferenceFactory();
        Object obj = rf.getReference(oid).getObject();
        wt.part.WTPart part = (WTPart) obj;
        String containerOid = null;
        containerOid = request.getParameter("ContainerOid");
        String partName = part.getName();
        partName = CtFormatUtil.escape(partName);//转义
    %>

    <script type="text/javascript">
        var orgPartName = '<%=partName%>';
        orgPartName = unescape(orgPartName);//反转义
        var orgPartNumber = '<%= part.getNumber() %>';
        var containerOid = '<%= containerOid %>';
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/Windchill/netmarkets/javascript/ext-4.2.1/resources/ext-theme-neptune/ext-theme-neptune-all.css">
    <link href="/Windchill/netmarkets/css/plm/ctCommonStyle.css" rel="stylesheet" type="text/css" />
    <!-- ExtJS -->
    <script type="text/javascript" src="/Windchill/netmarkets/javascript/ext-4.2.1/ext-all-debug.js"></script>
    <script src="/Windchill/netmarkets/javascript/ext-4.2.1/locale/ext-lang-zh_CN.js"></script>
    <script type="text/javascript" src="/Windchill/netmarkets/jsp/ext/plm/part/js/ctNewSampleMaterial.js?_dc=<%=System.currentTimeMillis()%>"></script>


</head>
<body>
<script>
// ==============layout define area=================================//
Ext.onReady(function() {
Ext.QuickTips.init();

Ext.create('Ext.container.Viewport', {
layout: 'border',
items: [{
region: 'center',
xtype: 'ctNewSampleMaterialPanel'
}]
});
});
</script>
</body>
</html>