Ext.define('PLM.view.ctChangeImpactConfirmTable', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctChangeImpactConfirmTable',
    border: false,
    autoScroll: true,
    autoWidth: true,
    // autoHeight: true,
    collapsible: false,
    height:850,
    id: 'ctChangeImpactConfirmTable',
    initComponent: function (){

//========== 开始  partChangeGrid================
        Ext.define('ctChangeImpactConfirmTableModel', {
            extend: 'Ext.data.Model',
            fields: [
                'id','partNumber','partName','changeNo','changeState','changeDesc','changeUrl','partUrl'
            ],
            idProperty: 'id'
        });

        // create the Data Store
        this.ctChangeImpactConfirmTableStore = Ext.create('Ext.data.Store', {
            model: 'ctChangeImpactConfirmTableModel',
            id:'ctChangeImpactConfirmTableStore',
            pruneModifiedRecords: true,
            proxy: new Ext.data.HttpProxy({
                url: '/Windchill/ptc1/newEc/getChangeImpact?proOid=' + proOid,
                method:'GET',
                reader:{
                    type:'json',
                    rootProperty: 'data',
                    idProperty: 'id',
                    messageProperty: 'msg'
                }
            }),
            autoLoad:true
        });

        var ctChangeImpactConfirmTableCellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });

        var ctChangeImpactConfirmTableGrid = Ext.create('Ext.grid.Panel', {
            plugins: [ctChangeImpactConfirmTableCellEditing],
            store: Ext.getStore('ctChangeImpactConfirmTableStore'),
            id: 'ctChangeImpactConfirmTableGrid',
            margin: '20 10 20 0',
            title: '相关变更影响确认',
            autoWidth: true,
            columnLines: true,
            height:'1500',
            width:'100%',
            multiSelect : false,
            autoScroll: true,
            viewConfig: { enableTextSelection: true },
            forceFit: false,
            //selType: 'checkboxmodel',
            columns: [
                {
                    text: '待升级物料编号',
                    dataIndex: 'partNumber',
                    width: 160,
                    editAccess: false,
                    editor: 'textfield',
                    menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(value) {
                            var changeLink = record.get('partUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {
                    text: '物料描述',
                    dataIndex: 'partName',
                    width: 300,
                    editAccess: false,
                    editor: 'textfield',
                    menuDisabled: true,
                    renderer:showTip
                },
                {
                    text: '相关变更单号',
                    dataIndex: 'changeNo',
                    width: 160,
                    editAccess: false,
                    editor: 'textfield',
                    menuDisabled: true,
                    renderer: function(value,metaData,record,row,col,store){
                        if(value)
                            metaData.tdAttr = 'data-qtip="' + value +'"';
                        if(value) {
                            var changeLink = record.get('changeUrl');
                            return changeLink;
                        }else {
                            return value;
                        }
                    }
                },
                {
                    text: '变更状态',
                    dataIndex: 'changeState',
                    width: 100,
                    editAccess: false,
                    editor: 'textfield',
                    menuDisabled: true,
                    renderer:showTip
                },
                {
                    text: '变更描述',
                    dataIndex: 'changeDesc',
                    width: 500,
                    editAccess: false,
                    editor: 'textfield',
                    menuDisabled: true,
                    renderer:showTip
                }
            ],
            tbar: [
            ]//~end of tbar
        });

        ctChangeImpactConfirmTableGrid.on('beforeedit', function (editor, e) {
            var r = e.record; // 得到当前行所有数据
            var f = e.field; // 得到修改列
            var v = e.value; // 得到修改列修改后值
            return checkEditAccess(e); // 校验字段编辑权限
        });

        var ctChangeImpactConfirmTablePanel = Ext.create('Ext.panel.Panel',{
            xtype:'panel',
            //title: '',
            padding:'5',
            collapsed:false,
            collapsible:true,
            titleCollapse:true,
            hideCollapseTool:true,
            border: false,
            anchor:'100%',
            width:'99.9%',
            height:'1500px',
            items:[
                {
                    fieldLabel: '',
                    xtype: 'checkboxgroup',
                    name: 'confirmGroup',
                    id: 'confirmGroup',
                    width: 1000,
                    columns: 8,
                    items: [{
                        width:990,
                        inputValue: '当前升级流程的升级对象存在以下相关变更，请确认您在提交该升级请求时已经把以下相关变更的变更内容考虑进来。',
                        boxLabel: '当前升级流程的升级对象存在以下相关变更，请确认您在提交该升级请求时已经把以下相关变更的变更内容考虑进来。',
                        id: 'confirmCheckBox',
                        name: 'confirmCheckBox',
                        checked: true,
                        disabled: isDisabled(),//节点编辑权限
                        disabledCls: 'none',
                        listeners:{
                            'change': function(checkbox, newValue, oldValue) {
                                Ext.Ajax.request({
                                    url: '/Windchill/ptc1/changeConfirm/updateChangeConfirm',
                                    params: {
                                        promotionOid: proOid,
                                        changeConfirm: newValue?'Y':'N'
                                    },
                                    failure: function(response, opts) {
                                        alert('错误：处理超时，请检查网络！');
                                    }
                                });
                            }
                        }
                    }]
                },
                ctChangeImpactConfirmTableGrid
            ],
            listeners:{
                'afterrender':function () {
                    //加载新编码
                    Ext.Ajax.request({
                        url: '/Windchill/ptc1/changeConfirm/searchChangeConfirm?promotionOid='+proOid,
                        success:function (response, opts) {
                            var obj = Ext.decode(response.responseText);
                            if (!obj['success']) {
                                alert(obj['msg']);
                                return;
                            }
                            //设置表单值
                            var confirmCheckBox = Ext.getCmp('confirmCheckBox');
                            if ('Y' == obj.data['changeConfirm']) {
                                confirmCheckBox.setValue(true);
                            } else {
                                confirmCheckBox.setValue(false);
                            }
                        },
                        failure: function(response, opts) {
                            alert('错误：处理超时，请检查网络！');
                        }
                    });
                }
            }
        });

        this.items = [
            ctChangeImpactConfirmTablePanel
        ];

        this.callParent();
        //========== 结束  PartChangeGrid================
    }
})

//三江电子-风险管理审批流程 三江电子-风险管理审批流程-提交
// 成品/半成品物料生效、样机BOM发布流程 成品/半成品物料生效、样机BOM发布流程-提交
// 原材料物料申请流程  原材料电子物料申请流程-提交 原材料非电子物料申请流程-提交
// （成品/半成品、试产专用成品）设计BOM生效流程  设计BOM生效流程-提交
function isDisabled(){
    if(activityName){
        if('三江电子-风险管理审批流程-提交' == activityName ||
            '成品/半成品物料生效、样机BOM发布流程-提交' == activityName ||
        '原材料电子物料申请流程-提交' == activityName || '原材料非电子物料申请流程-提交' == activityName ||
        '设计BOM生效流程-提交' == activityName){
            return false;
        }
    }
    return true;
}

//region grid单元格悬浮提示
function showTip(value,metaData,record,row,col,store){
    if(value)
        metaData.tdAttr = 'data-qtip="' + value +'"';
    return value;
}//endregion
