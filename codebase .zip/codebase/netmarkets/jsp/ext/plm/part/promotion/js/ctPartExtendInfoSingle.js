Ext.define('PLM.view.ctPartExtendInfoSingle', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ctPartExtendInfoSingle',
    border: false,
    autoScroll: true,
    // autoWidth: true,
    // autoHeight: true,
    // collapsible: false,
    config: {
        in_objectKey: 'PartExtendInfoSingle',
        in_objectDesc: '物料扩展视图单页面信息',
    },
    id: 'PartExtendExample',
    initComponent: function () {
        // var whetherHasValue=Ext.getCmp("acquisitionType").getValue()==undefined
        var me = this;
        var redStarFlag = '<font color=red bold>*</font>'; //必填标志
        var blueFlagStart = '<font color=blue bold><b>';
        var blueFlagEnd = '</b></font>';
        var oldPartNumberText = '旧物料编码';
        var sapPartNumberText = 'SAP物料编码';
        var partTypeText = '物料类型';
        var partCnDescribeText='物料描述(中文)';
        var developPartDescribeText='研发物料描述';
        //基本视图
        var saleDescribeText='销售描述';
        var unitText='基本单位';
        var partGroupText='物料组';
        var productGroupText='产品组';
        var pdtTeamText='PDT团队归属';
        var partLibraryNumberText='器件库编码';
        var controllerPointsText='控制器点数';
        var priorityText='优先级';
        var otherFactoryPartStatusText='跨工厂物料状态';
        var volumeText='体积';
        var taxTypeCodeText='财务税收分类编码';
        var longTextText='备注';
        //组织架构
        var factoryText='工厂';
        var saleOrganizationText='销售组织';
        var channelsText='分销渠道';
        //销售视图
        var deliveryFactoryText='交货工厂';
        var taxTypeText='税分类';
        var subjectGroupText='科目设置组';
        var projectTypeGroupText='项目类别组';
        var loadGroupText='装载组';
        //采购视图
        var purchaseGroupText='采购组';
        var autoBuyListText='自动采购订单';
        var sourceListText='源清单';
        //质量视图
        var checkTypeText='检验类型';
        //认证视图
        var certificationTypeText='认证类型';
        //MRP1
        var stockLogoText='库存ABC标示';
        var mrpTypeText='MRP类型';
        var mrpControllerText='MRP控制者';
        var lotSizeText='批量大小';
        var miniLotText='最小批量大小';
        var assemblyScrapText='装配报废(%)';
        var roundingText='舍入值';
        //MRP2
        var acquisitionTypeText='获取类型';
        var specialTypeText='特殊获取类型';
        var goLogoText='反冲标识';
        var bulkPartText='散装物料';
        var productionLocationText='生产仓储地点';
        var outBuyStorageLocationText='外部采购仓储地点';
        var planMarginalCodeText='计划边际码';
        var selfProductionTimeText='自制生产时间(天)';
        var planDeliveryTimeText='计划交货时间(天)';
        var receiptTimeText='收货处理时间(天)';
        var safeStockText='安全库存';
        //MRP3
        var policyGroupText='策略组';
        var consumptionPatternText='消耗模式';
        var reverseConsumptionText='逆向消耗期间';
        var periodConsumptionText='向前消耗期间';
        var availabilityCheckText='可用性检查';
        //MRP4
        var independentLogoText='独立/集中标识';
        var bomScrapText='组件报废';
        var discontinueLogoText='非连续标识';
        var effectiveTimeText='生效日期';
        var subsequentPartText='后续物料';
        //工作计划
        var productionManagerText='生产管理员';
        var productionPlanListText='生产计划参数文件';
        var numberListText='序列号参数文件';
        var unitCodeText='填写单位编码';
        //会计/成本视图
        var accessTypeText='评估类';
        var priceControlText='价格控制';
        var standardPriceText='标准价格(元)';
        var priceMovingText='移动平均价(元)';
        var priceUnitText='价格单位(元)';
        var costEstimationText='成本估算';
        var partSourceText='物料来源';
        var profitCenterText='利润中心';
        var branchIdText='流程ID';
        //可编辑项
        if(allowEdit||allowEditAll) {
            //基本视图
            oldPartNumberText= blueFlagStart+ oldPartNumberText +blueFlagEnd;

            partTypeText= redStarFlag+blueFlagStart+ partTypeText +blueFlagEnd;
            partCnDescribeText= redStarFlag+blueFlagStart+ partCnDescribeText +blueFlagEnd;
            developPartDescribeText= blueFlagStart+ developPartDescribeText +blueFlagEnd;
            saleDescribeText=blueFlagStart+ saleDescribeText +blueFlagEnd;
            unitText = redStarFlag+blueFlagStart+ unitText +blueFlagEnd;
            partGroupText =redStarFlag+ blueFlagStart+ partGroupText +blueFlagEnd;
            productGroupText =redStarFlag+ blueFlagStart+ productGroupText +blueFlagEnd;
            pdtTeamText =redStarFlag+blueFlagStart+ pdtTeamText +blueFlagEnd;
            partLibraryNumberText =blueFlagStart+ partLibraryNumberText +blueFlagEnd;
            controllerPointsText =blueFlagStart+ controllerPointsText +blueFlagEnd;
            priorityText =blueFlagStart+ priorityText +blueFlagEnd;
            otherFactoryPartStatusText =blueFlagStart+ otherFactoryPartStatusText +blueFlagEnd;
            taxTypeCodeText =blueFlagStart+ taxTypeCodeText +blueFlagEnd;
            longTextText =blueFlagStart+ longTextText +blueFlagEnd;
        }
        if(allowEditAllCheck||allowEditAll){
            sapPartNumberText= redStarFlag+blueFlagStart+ sapPartNumberText +blueFlagEnd;
        }
        if(allowEditCommercialDirector||allowEditAll){
            volumeText =blueFlagStart+ volumeText +blueFlagEnd;
            subjectGroupText =blueFlagStart+ subjectGroupText +blueFlagEnd;
            projectTypeGroupText =blueFlagStart+ projectTypeGroupText +blueFlagEnd;
            loadGroupText =blueFlagStart+ loadGroupText +blueFlagEnd;

            // if(whetherBom){
            //     taxTypeText =redStarFlag+blueFlagStart+ taxTypeText +blueFlagEnd;
            //     saleOrganizationText =redStarFlag+ blueFlagStart+ saleOrganizationText +blueFlagEnd;
            //     channelsText =redStarFlag+ blueFlagStart+ channelsText +blueFlagEnd;
            // }else {
                taxTypeText =blueFlagStart+ taxTypeText +blueFlagEnd;

                saleOrganizationText = blueFlagStart+ saleOrganizationText +blueFlagEnd;
                channelsText = blueFlagStart+ channelsText +blueFlagEnd;
            // }
        }
        if(allowEditPurchaseFollow||allowEditAll) {
            //采购视图
            purchaseGroupText =blueFlagStart+ purchaseGroupText +blueFlagEnd;
            autoBuyListText =blueFlagStart+ autoBuyListText +blueFlagEnd;
            sourceListText =blueFlagStart+ sourceListText +blueFlagEnd;
        }
        if(allowEditIQCDirector||allowEditAll) {
            //质量视图
            checkTypeText =blueFlagStart+ checkTypeText +blueFlagEnd;
        }
        if(allowEditCertificationDirector||allowEditAll) {
            //认证视图
            certificationTypeText =blueFlagStart+ certificationTypeText +blueFlagEnd;
        }
        if(allowEditFollow||allowEditAll) {
            factoryText = redStarFlag+blueFlagStart+ factoryText +blueFlagEnd;
            deliveryFactoryText =blueFlagStart+ deliveryFactoryText +blueFlagEnd;
            //MRP1
            stockLogoText =blueFlagStart+ stockLogoText +blueFlagEnd;
            mrpTypeText = redStarFlag+blueFlagStart+ mrpTypeText +blueFlagEnd;
            mrpControllerText = redStarFlag+blueFlagStart+ mrpControllerText +blueFlagEnd;
            lotSizeText = redStarFlag+blueFlagStart+ lotSizeText +blueFlagEnd;
            miniLotText =blueFlagStart+ miniLotText +blueFlagEnd;
            assemblyScrapText = blueFlagStart+ assemblyScrapText +blueFlagEnd;
            roundingText =blueFlagStart+ roundingText +blueFlagEnd;
            //MRP2
            acquisitionTypeText = redStarFlag+blueFlagStart+ acquisitionTypeText +blueFlagEnd;
            specialTypeText = blueFlagStart+ specialTypeText +blueFlagEnd;
            goLogoText = blueFlagStart+ goLogoText +blueFlagEnd;
            bulkPartText = blueFlagStart+ bulkPartText +blueFlagEnd;
            productionLocationText = blueFlagStart+ productionLocationText +blueFlagEnd;
            outBuyStorageLocationText =blueFlagStart+ outBuyStorageLocationText +blueFlagEnd;
            planMarginalCodeText = redStarFlag+blueFlagStart+ planMarginalCodeText +blueFlagEnd;
            selfProductionTimeText = blueFlagStart+ selfProductionTimeText +blueFlagEnd;
            planDeliveryTimeText = blueFlagStart+ planDeliveryTimeText +blueFlagEnd;
            receiptTimeText = redStarFlag+blueFlagStart+ receiptTimeText +blueFlagEnd;
            safeStockText = blueFlagStart+ safeStockText +blueFlagEnd;
            //MRP3

            consumptionPatternText = blueFlagStart+ consumptionPatternText +blueFlagEnd;
            reverseConsumptionText = blueFlagStart+ reverseConsumptionText +blueFlagEnd;
            periodConsumptionText = blueFlagStart+ periodConsumptionText +blueFlagEnd;
            availabilityCheckText =blueFlagStart+ availabilityCheckText +blueFlagEnd;
            //MRP4
            independentLogoText =blueFlagStart+ independentLogoText +blueFlagEnd;
            bomScrapText = blueFlagStart+ bomScrapText +blueFlagEnd;
            discontinueLogoText = blueFlagStart+ discontinueLogoText +blueFlagEnd;
            effectiveTimeText = blueFlagStart+ effectiveTimeText +blueFlagEnd;
            subsequentPartText = blueFlagStart+ subsequentPartText +blueFlagEnd;
            //工作计划
            productionManagerText = blueFlagStart+ productionManagerText +blueFlagEnd;
            productionPlanListText = blueFlagStart+ productionPlanListText +blueFlagEnd;
            numberListText = blueFlagStart+ numberListText +blueFlagEnd;
            unitCodeText =blueFlagStart+ unitCodeText +blueFlagEnd;
        }
        if(allowEditPDTManager||allowEditAll){
            policyGroupText = blueFlagStart+ policyGroupText +blueFlagEnd;
        }
        if(allowEditTreasurer||allowEditAll){
            //会计/成本视图
            accessTypeText =blueFlagStart+ accessTypeText +blueFlagEnd;
            priceControlText =blueFlagStart+ priceControlText +blueFlagEnd;
            standardPriceText =blueFlagStart+ standardPriceText +blueFlagEnd;
            priceMovingText =blueFlagStart+ priceMovingText +blueFlagEnd;
            priceUnitText =blueFlagStart+ priceUnitText +blueFlagEnd;
            costEstimationText =redStarFlag+blueFlagStart+ costEstimationText +blueFlagEnd;
            partSourceText =redStarFlag+blueFlagStart+ partSourceText +blueFlagEnd;
            profitCenterText =blueFlagStart+ profitCenterText +blueFlagEnd;
            branchIdText =redStarFlag+blueFlagStart+ branchIdText +blueFlagEnd;
        }


        var factoryTextCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel:factoryText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            id: 'factory',
            name: 'factory',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["1001", "1001"], ["1003", "1003"], ["1100", "1100"], ["1200", "1200"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    if(factoryTextCombo.getValue()!=null){
                        Ext.getCmp("mrpController").setHidden(false);
                        Ext.getCmp("mrpController2").setHidden(true);
                    }

                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value,callbackFn);
                    function callbackFn() {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ctPart/getDataById',
                            method: 'GET',
                            params: {
                                id: id
                            },
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                var data = obj['data'];
                                if (obj['message']=='success') {
                                    // var mainPanel = Ext.getCmp('mainForm');
                                    Ext.getCmp("profitCenter").setValue( data['profitCenter']);
                                    if (!selectPlan){
                                    Ext.getCmp("mrpController").setValue('');
                                 }
                                    Ext.getStore('mrpControllerTextStore').load({
                                        params: {
                                            key:"factory",
                                            data:factoryTextCombo.getValue(),
                                        }
                                    });
                                } else {
                                    alert(obj['error']);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：查询信息失败，请检查网络！!');
                            }
                        });

                    }

                },

            }
        });
        var saleOrganizationTextCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel:saleOrganizationText,
            readOnly:allowEditCommercialDirector||allowEditAll?false:true,
            name: 'saleOrganization',
            id: 'saleOrganization',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["1001-国内销售组织", "1001-国内销售组织"],["1002-国外销售组织", "1002-国外销售组织"], ["1003-电商销售组织", "1003-电商销售组织"], ["1100-科技销售组织", "1100-科技销售组织"], ["1200-数据销售组织", "1200-数据销售组织"], ["1300-检测销售组织", "1300-检测销售组织"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    if(saleOrganizationTextCombo.getValue()!=null){
                        Ext.getCmp("channels").setHidden(false);
                        Ext.getCmp("channels2").setHidden(true);
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value,callbackFn);
                    function callbackFn() {
                        Ext.Ajax.request({
                            url: '/Windchill/ptc1/ctPart/getDataById',
                            method: 'GET',
                            params: {
                                id: id
                            },
                            success: function (response, opts) {
                                var obj = Ext.decode(response.responseText);
                                var data = obj['data'];
                                if (obj['message']=='success') {
                                    // var mainPanel = Ext.getCmp('mainForm');
                                    if (!selectPlan){
                                    Ext.getCmp("channels").setValue('');
                                    }
                                    Ext.getStore('channelsTextStore').load({
                                        params: {
                                            key:"2",
                                            data:saleOrganizationTextCombo.getValue(),
                                        }
                                    });
                                } else {
                                    alert(obj['error']);
                                }
                            },
                            failure: function (response, opts) {
                                alert('错误：查询信息失败，请检查网络！!');
                            }
                        });

                    }

                },

            }
        });

        var channelsTextCombo =new Ext.form.field.ComboBox({
            // forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditCommercialDirector||allowEditAll?false:true,
            fieldLabel: channelsText,
            name: 'channels',
            id: 'channels',
            width: 300,
            // mode: 'local',
            multiSelect: true,
            // anyMatch: true,
            editable : false,
            queryMode:'local',
            store:Ext.getStore('channelsTextStore'),
            valueField: 'formInfo',
            displayField: 'formInfo',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });

        var deliveryFactoryTextCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel:deliveryFactoryText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            id: 'deliveryFactory',
            name: 'deliveryFactory',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["1001", "1001"], ["1003", "1003"], ["1100", "1100"], ["1200", "1200"],]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);


                },

            }
        });
        var taxTypeTextCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel:taxTypeText,
            readOnly:allowEditCommercialDirector||allowEditAll?false:true,
            id: 'taxType',
            name: 'taxType',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [ ["0-零税率","0-零税率"], ["1-13%（物料、产品及软件销售）", "1-13%（物料、产品及软件销售）"], ["2-10%（工程服务）", "2-10%（工程服务）"],
                    ["3-6%（研发服务、技术服务、平台服务）", "3-6%（研发服务、技术服务、平台服务）"],["4-16%  （维修服务）", "4-16%  （维修服务）"], ["5-5%  （租赁服务）","5-5%  （租赁服务）"],
                    ["6-3%（各项业务）","6-3%（各项业务）"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var sourceListTextCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel:sourceListText,
            readOnly:allowEditPurchaseFollow||allowEditAll?false:true,
            name: 'sourceList',
            id: 'sourceList',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["无", "无"], ["X", "启用"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var stockLogoCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel: stockLogoText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            id: 'stockLogo',
            name: 'stockLogo',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["无","无"],["A-高价值", "A-高价值"], ["B-中价值", "B-中价值"], ["C-低价值", "C-低价值"]
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var mrpTypeCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel: mrpTypeText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            name: 'mrpType',
            id: 'mrpType',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["PD-参与MRP运算", "PD-参与MRP运算"], ["ND-不参与MRP运算", "ND-不参与MRP运算"]
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });

        var mrpControllerTextCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow||allowEditAll?false:true,
            fieldLabel: mrpControllerText,
            name: 'mrpController',
            id: 'mrpController',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            queryMode:'local',
            store:Ext.getStore("mrpControllerTextStore"),
            valueField: 'formInfo',
            displayField: 'formInfo',
            listeners: {
                    change: function (e) {
                        if(taskCompleted){
                            return;
                        }
                        let id=Ext.getCmp("id").getValue();
                        saveObjectData(id, e.id, e.value);
                    }
            }
        });

        var certificationTypeCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow||allowEditAll?false:true,
            fieldLabel: certificationTypeText,
            name: 'certificationType',
            id: 'certificationType',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            multiSelect: true,
            queryMode:'local',
            store:Ext.getStore("certificationTypeStore"),
            valueField: 'certificationType',
            displayField: 'certificationType',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });

        var lotSizeTextCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel: lotSizeText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            name: 'lotSize',
            id: 'lotSize',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["MB-月批量", "MB-月批量"], ["W2-2周批量", "W2-2周批量"], ["WB-周批量", "WB-周批量"],
                    ["TB-日合批", "TB-日合批"], ["2D-2天合批", "2D-2天合批"],["3D-3天合批", "3D-3天合批"],["4D-4天合批", "4D-4天合批"],
                    ["5D-5天合批", "5D-5天合批"],["TD-10天合批", "TD-10天合批"],["EX-逐批", "EX-逐批"],
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var specialTypeCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel: specialTypeText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            name: 'specialType',
            id: 'specialType',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["无","无"],["50-生产虚拟件(结合E-自制使用)", "50-生产虚拟件(结合E-自制使用)"], ["30-委外采购(结合F-外购使用)", "30-委外采购(结合F-外购使用)"], ["41-工厂间转储(结合F-外购使用)", "41-工厂间转储(结合F-外购使用)"]
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var acquisitionTypeCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow||allowEditAll?false:true,
            fieldLabel: acquisitionTypeText,
            name: 'acquisitionType',
            id: 'acquisitionType',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["E-自制","E-自制"],["F-外购", "F-外购"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    let partType=Ext.getCmp("partType").getValue();
                    saveObjectData(id, e.id, e.value);
                    let value=e.value;

                    if(value=="E-自制"){
                        saveObjectData(id,"priceControl", "S-标准价(成品/半成品)");
                        Ext.getCmp("priceControl").setValue("S-标准价(成品/半成品)")
                        if(partType!="Z030"&&partType!="Z031"&&partType!="Z032"){
                            saveObjectData(id,"checkType", "");
                            Ext.getCmp("checkType").setValue("")
                        }
                    }else {
                        saveObjectData(id,"priceControl", "V-移动平均价(其它物料)");
                        Ext.getCmp("priceControl").setValue("V-移动平均价(其它物料)")
                        if(partType!="Z030"&&partType!="Z031"&&partType!="Z032"){
                            saveObjectData(id,"checkType", "01-来料检验");
                            Ext.getCmp("checkType").setValue("01-来料检验")
                        }
                    }

                }
            }
        });
        var goLogoCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            labelWidth: 100,
            fieldLabel: goLogoText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            name: 'goLogo',
            id: 'goLogo',
            // margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["一直反冲", "一直反冲"], ["不反冲", "不反冲"]
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var bulkPartCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow||allowEditAll?false:true,
            fieldLabel: bulkPartText,
            name: 'bulkPart',
            id: 'bulkPart',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data:[["无", "无"], ["X-散装物料标识", "X-散装物料标识"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var productionLocationCombo = new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            fieldLabel:productionLocationText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            name: 'productionLocation',
            id: 'productionLocation',
            margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["0001物控-质检仓", "0001物控-质检仓"], ["0002物控-原材料仓", "0002物控-原材料仓"],
                    ["0003物控-半成品仓", "0003物控-半成品仓"], ["0008物控-消防成品仓", "0008物控-消防成品仓"],
                    ["1001生产-大柜线边仓", "1001生产-大柜线边仓"], ["1002生产-壁挂线边仓(1, 2线)", "1002生产-壁挂线边仓(1, 2线)"],
                    ["1003生产-大板线边仓(3线)", "1003生产-大板线边仓(3线)"], ["1003生产-大板线边仓(3线)", "1003生产-大板线边仓(3线)"],
                    ["1004生产-四楼线边仓", "1004生产-四楼线边仓"], ["1005生产-五楼线边仓", "1005生产-五楼线边仓"],
                    ["1006生产-五楼贴片线边仓", "1006生产-五楼贴片线边仓"], ["1007生产-六楼底座线边仓", "1007生产-六楼底座线边仓"],
                    ["1008生产-六楼声光线边仓", "1008生产-六楼声光线边仓"], ["1009生产-二楼贴片二车边仓", "1009生产-二楼贴片二车边仓"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }

                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                },

            }
        });
        var outBuyStorageLocationCombo =new Ext.form.field.ComboBox({
            forceSelection: true, //forceSelection 是否能够手填
            readOnly:allowEditFollow||allowEditAll?false:true,
            fieldLabel: outBuyStorageLocationText,
            name: 'outBuyStorageLocation',
            id: 'outBuyStorageLocation',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            // queryMode:'local',
            // store:Ext.getStore('outBuyStorageLocationStore'),
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["0001物控-质检仓", "0001物控-质检仓"], ["0002物控-原材料仓", "0002物控-原材料仓"],
                    ["0003物控-半成品仓", "0003物控-半成品仓"], ["0008物控-消防成品仓", "0008物控-消防成品仓"],
                    ["1001生产-大柜线边仓", "1001生产-大柜线边仓"], ["1002生产-壁挂线边仓(1, 2线)", "1002生产-壁挂线边仓(1, 2线)"],
                    ["1003生产-大板线边仓(3线)", "1003生产-大板线边仓(3线)"], ["1003生产-大板线边仓(3线)", "1003生产-大板线边仓(3线)"],
                    ["1004生产-四楼线边仓", "1004生产-四楼线边仓"], ["1005生产-五楼线边仓", "1005生产-五楼线边仓"],
                    ["1006生产-五楼贴片线边仓", "1006生产-五楼贴片线边仓"], ["1007生产-六楼底座线边仓", "1007生产-六楼底座线边仓"],
                    ["1008生产-六楼声光线边仓", "1008生产-六楼声光线边仓"], ["1009生产-二楼贴片二车边仓", "1009生产-二楼贴片二车边仓"]]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });

        var discontinueLogoCombo = new Ext.form.field.ComboBox({
            fieldLabel: discontinueLogoText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            name: 'discontinueLogo',
            id: 'discontinueLogo',
            // margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["1-单一后续替代", "1-单一后续替代"], ["3-平行后续替代", "3-平行后续替代"]
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var numberListCombo = new Ext.form.field.ComboBox({
            fieldLabel: numberListText,
            readOnly:allowEditFollow||allowEditAll?false:true,
            name: 'numberList',
            id: 'numberList',
            // margin: '5 20 0 0',
            width: 300,
            mode: 'local',
            anyMatch: true,
            editable : false,
            store: new Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'key',
                    'displayText'
                ],
                data: [["空-无", "空-无"], ["Z001-序列号管理", "Z001-序列号管理"]
                ]
            }),
            valueField: 'key',
            displayField: 'displayText',
            listeners: {
                change: function (e) {
                    if(taskCompleted){
                        return;
                    }
                    let id=Ext.getCmp("id").getValue();
                    saveObjectData(id, e.id, e.value);
                }
            }
        });
        var headPanel =  {
            xtype: 'fieldset',
            title: '基本视图',
            // hidden:allowEdit?false:true,
            padding: '5',
            collapsed:allowEdit||allowEditAll?false:true,
            collapsible: true,
            titleCollapse: false,
            hideCollapseTool: false,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: 'id',
                    id: 'id',
                    name: 'id',
                    hidden:true,
                },{
                    xtype: 'displayfield',
                    fieldLabel: oldPartNumberText,
                    id: 'oldPartNumber',
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'oldPartNumber',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },{
                    xtype: 'displayfield',
                    fieldLabel: sapPartNumberText,
                    readOnly:allowEditAllCheck||allowEditAll?false:true,
                    id: 'sapPartNumber',
                    name: 'sapPartNumber',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: partTypeText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'partType',
                    id: 'partType',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                } ]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    labelWidth: 100,
                    fieldLabel: partCnDescribeText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'partCnDescribe',
                    id: 'partCnDescribe',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }

                },{
                    xtype: 'displayfield',
                    fieldLabel: developPartDescribeText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    id: 'developPartDescribe',
                    name: 'developPartDescribe',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: saleDescribeText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'saleDescribe',
                    id: 'saleDescribe',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                } ]
            },{//第三行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    labelWidth: 100,
                    fieldLabel: unitText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'unit',
                    id: 'unit',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }

                },{
                    xtype: 'displayfield',
                    fieldLabel: partGroupText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    id: 'partGroup',
                    name: 'partGroup',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                        xtype: 'displayfield',
                        fieldLabel: productGroupText,
                        readOnly:allowEdit||allowEditAll?false:true,
                        id: 'productGroup',
                        name: 'productGroup',
                        //value:'05430',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                if(taskCompleted){
                                    return;
                                }
                                let id=Ext.getCmp("id").getValue()
                                saveObjectData(id, e.id, e.value);
                            }
                        }
                    }]
            },{//第四行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [ {
                    xtype: 'displayfield',
                    fieldLabel: pdtTeamText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'pdtTeam',
                    id: 'pdtTeam',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: partLibraryNumberText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'partLibraryNumber',
                    id: 'partLibraryNumber',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }},{
                    xtype: 'displayfield',
                    fieldLabel: controllerPointsText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'controllerPoints',
                    id: 'controllerPoints',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            },{//第五行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    labelWidth: 100,
                    fieldLabel: priorityText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'priority',
                    id: 'priority',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }

                },{
                    xtype: 'displayfield',
                    fieldLabel: otherFactoryPartStatusText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    id: 'otherFactoryPartStatus',
                    name: 'otherFactoryPartStatus',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: volumeText,
                    readOnly:allowEditCommercialDirector||allowEditAll?false:true,
                    name: 'volume',
                    id: 'volume',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            },{//第六行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    labelWidth: 100,
                    fieldLabel: taxTypeCodeText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    name: 'taxTypeCode',
                    id: 'taxTypeCode',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }

                },{
                    xtype: 'displayfield',
                    labelWidth: 100,
                    fieldLabel: longTextText,
                    readOnly:allowEdit||allowEditAll?false:true,
                    id: 'longText',
                    name: 'longText',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            }]
        };

        var groupInfoPanel =  {
            xtype: 'fieldset',
            title: '组织架构',
            // hidden:(allowEditFollow||allowEditCommercialDirector)?false:true,
            collapsed:(allowEditFollow||allowEditCommercialDirector||allowEditAll)?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [ factoryTextCombo,saleOrganizationTextCombo,{
                    xtype: 'displayfield',
                    fieldLabel: channelsText,
                    readOnly:allowEditPurchaseFollow||allowEditAll?false:true,
                    id: 'channels2',
                    name: 'channels2',
                    //value:'05430',
                    width: 300,
                },channelsTextCombo]
            }]
        };
        var saleViewPanel =  {
            xtype: 'fieldset',
            title: '销售视图',
            // hidden:(allowEditFollow||allowEditCommercialDirector)?false:true,
            collapsed:(allowEditFollow||allowEditCommercialDirector||allowEditAll)?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [deliveryFactoryTextCombo,taxTypeTextCombo, {
                    xtype: 'displayfield',
                    labelWidth: 100,
                    fieldLabel: subjectGroupText,
                    readOnly:allowEditCommercialDirector||allowEditAll?false:true,
                    name: 'subjectGroup',
                    id: 'subjectGroup',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }

                }]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: projectTypeGroupText,
                    readOnly:allowEditCommercialDirector||allowEditAll?false:true,
                    id: 'projectTypeGroup',
                    name: 'projectTypeGroup',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: loadGroupText,
                    readOnly:allowEditCommercialDirector||allowEditAll?false:true,
                    name: 'loadGroup',
                    id: 'loadGroup',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            }]
        };
        var purchaseViewPanel =  {
            xtype: 'fieldset',
            title: '采购视图',
            // hidden:allowEditPurchaseFollow?false:true,
            collapsed:allowEditPurchaseFollow||allowEditAll?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: purchaseGroupText,
                    readOnly:allowEditPurchaseFollow||allowEditAll?false:true,
                    id: 'purchaseGroup',
                    name: 'purchaseGroup',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: autoBuyListText,
                    readOnly:allowEditPurchaseFollow||allowEditAll?false:true,
                    name: 'autoBuyList',
                    id: 'autoBuyList',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, sourceListTextCombo

                ]
            }]
        };
        var qualityViewPanel =  {
            xtype: 'fieldset',
            title: '质量视图',
            // hidden:allowEditIQCDirector?false:true,
            collapsed:allowEditIQCDirector||allowEditAll?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [ {
                    xtype: 'displayfield',
                    fieldLabel: checkTypeText,
                    readOnly:allowEditPurchaseFollow||allowEditAll?false:true,
                    id: 'checkType',
                    name: 'checkType',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            }]
        };
        var certificationViewPanel =  {
            xtype: 'fieldset',
            title: '认证视图',
            collapsed:allowEditCertificationDirector||allowEditAll?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [certificationTypeCombo]
            }]
        };
        var MRP1ViewPanel =  {
            xtype: 'fieldset',
            title: 'MRP1',
            // hidden:allowEditFollow?false:true,
            collapsed:allowEditFollow||allowEditAll?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [stockLogoCombo, mrpTypeCombo,{
                    xtype: 'displayfield',
                    fieldLabel: mrpControllerText,
                    readOnly:allowEditPurchaseFollow||allowEditAll?false:true,
                    id: 'mrpController2',
                    name: 'mrpController2',
                    //value:'05430',
                    width: 300,
                },mrpControllerTextCombo]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [lotSizeTextCombo, {
                    xtype: 'numberfield',
                    fieldLabel: miniLotText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    decimalPrecision:0,
                    name: 'miniLot',
                    id: 'miniLot',
                    minValue:0,
                    maxValue:100,
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'numberfield',
                    anchor: '100%',
                    decimalPrecision: 2,
                    minValue: 0,
                    maxValue:100,
                    fieldLabel: assemblyScrapText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    name: 'assemblyScrap',
                    id: 'assemblyScrap',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            },{//第三行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: roundingText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'rounding',
                    name: 'rounding',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            }]
        };

        var MRP2ViewPanel =  {
            xtype: 'fieldset',
            title: 'MRP2',
            // hidden:allowEditFollow?false:true,
            collapsed:allowEditFollow||allowEditAll?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [ {
                    xtype:acquisitionTypeCombo,
                    fieldLabel: acquisitionTypeText,
                    // readOnly:allowEditPurchaseFollow?false:true,
                    id: 'acquisitionType',
                    name: 'acquisitionType',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },specialTypeCombo, goLogoCombo]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [bulkPartCombo,productionLocationCombo,
                //     {
                //     xtype: 'displayfield',
                //     fieldLabel: outBuyStorageLocationText,
                //     readOnly:allowEditFollow||allowEditAll?false:true,
                //     name: 'outBuyStorageLocation2',
                //     id: 'outBuyStorageLocation2',
                //     //value:'05430',
                //     width: 300,
                // }
                // ,
                    outBuyStorageLocationCombo]
            },{//第三行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: planMarginalCodeText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'planMarginalCode',
                    name: 'planMarginalCode',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }

                },{
                    xtype: 'numberfield',
                    fieldLabel: selfProductionTimeText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'selfProductionTime',
                    name: 'selfProductionTime',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },{
                    xtype: 'numberfield',
                    fieldLabel: planDeliveryTimeText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'planDeliveryTime',
                    name: 'planDeliveryTime',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            },{//第四行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: receiptTimeText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'receiptTime',
                    name: 'receiptTime',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },{
                    xtype: 'numberfield',
                    fieldLabel: safeStockText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'safeStock',
                    name: 'safeStock',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            }]
        };
        var MRP3ViewPanel =  {
            xtype: 'fieldset',
            title: 'MRP3',
            // hidden:(allowEditPDTManager||allowEditFollow)?false:true,
            collapsed:(allowEditPDTManager||allowEditFollow||allowEditAll)?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [
                    {
                        xtype: 'displayfield',
                        fieldLabel: policyGroupText,
                        readOnly:allowEditFollow||allowEditAll?false:true,
                        name: 'policyGroup',
                        id: 'policyGroup',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                if(taskCompleted){
                                    return;
                                }
                                let id=Ext.getCmp("id").getValue()
                                saveObjectData(id, e.id, e.value);
                            }
                        }
                    },
                {
                    xtype: 'displayfield',
                    fieldLabel: consumptionPatternText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    name: 'consumptionPattern',
                    id: 'consumptionPattern',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    labelWidth: 100,
                    fieldLabel: reverseConsumptionText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    name: 'reverseConsumption',
                    id: 'reverseConsumption',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }

                }]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: periodConsumptionText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'periodConsumption',
                    name: 'periodConsumption',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'displayfield',
                    fieldLabel: availabilityCheckText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    name: 'availabilityCheck',
                    id: 'availabilityCheck',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            }]
        };
        var MRP4ViewPanel =  {
            xtype: 'fieldset',
            title: 'MRP4',
            // hidden:allowEditFollow?false:true,
            collapsed:allowEditFollow||allowEditAll?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [ {
                    xtype: 'displayfield',
                    fieldLabel: independentLogoText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'independentLogo',
                    name: 'independentLogo',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },
                    {
                    xtype: 'textfield',
                    fieldLabel: bomScrapText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    name: 'bomScrap',
                    id: 'bomScrap',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },  discontinueLogoCombo,
                   ]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'datefield',
                    fieldLabel: effectiveTimeText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'effectiveTime',
                    name: 'effectiveTime',
                    format:'Y-m-d',
                    //value:'05430',
                    width: 300,
                    renderer: function (value) {
                        if (value != null && value != undefined && value != '') {
                            var date = new Date(value);
                            var time = Ext.Date.format(date, "Y-m-d")
                            return time;
                        }
                        return value;
                    },
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: subsequentPartText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    name: 'subsequentPart',
                    id: 'subsequentPart',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            }]
        };
        var workPlanViewPanel =  {
            xtype: 'fieldset',
            title: '工作计划',
            // hidden:allowEditFollow?false:true,
            collapsed:allowEditFollow||allowEditAll?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [ {
                    xtype: 'displayfield',
                    fieldLabel: productionManagerText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'productionManager',
                    name: 'productionManager',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },{
                    xtype: 'displayfield',
                    fieldLabel: productionPlanListText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'productionPlanList',
                    name: 'productionPlanList',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },
                    numberListCombo]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: unitCodeText,
                    readOnly:allowEditFollow||allowEditAll?false:true,
                    id: 'unitCode',
                    name: 'unitCode',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            }]
        };

        var costViewPanel =  {
            xtype: 'fieldset',
            title: '会计/成本视图',
            // hidden:allowEditCostAccounting?false:true,
            collapsed:allowEditTreasurer||allowEditAll?false:true,
            padding: '5',
            collapsible: true,
            titleCollapse: true,
            hideCollapseTool: true,
            anchor: '100%',
            defaults: {
                padding: '2 10 2 10',
                labelWidth: 80,
                border: false
            },
            items: [{//第一行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'displayfield',
                    fieldLabel: accessTypeText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'accessType',
                    name: 'accessType',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },  {
                    xtype: 'displayfield',
                    fieldLabel: priceControlText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'priceControl',
                    name: 'priceControl',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },
                    {
                    xtype: 'numberfield',
                    labelWidth: 100,
                    fieldLabel: standardPriceText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    name: 'standardPrice',
                    id: 'standardPrice',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }

                }]
            },{//第二行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: priceMovingText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'priceMoving',
                    name: 'priceMoving',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },{
                    xtype: 'displayfield',
                    fieldLabel: priceUnitText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'priceUnit',
                    name: 'priceUnit',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },{
                    xtype: 'textfield',
                    fieldLabel: costEstimationText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'costEstimation',
                    name: 'costEstimation',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                }]
            },{//第三行
                xtype: 'panel',
                layout: 'hbox',
                defaults: {margin: '5 20 0 0', labelWidth: 100},
                items: [{
                    xtype: 'textfield',
                    fieldLabel: partSourceText,
                    readOnly:allowEditTreasurer||allowEditAll?false:true,
                    id: 'partSource',
                    name: 'partSource',
                    //value:'05430',
                    width: 300,
                    listeners: {
                        blur: function (e) {
                            if(taskCompleted){
                                return;
                            }
                            let id=Ext.getCmp("id").getValue()
                            saveObjectData(id, e.id, e.value);
                        }
                    }
                },{
                        xtype: 'displayfield',
                        fieldLabel: profitCenterText,
                        readOnly: allowEditTreasurer||allowEditAll?false:true,
                        id: 'profitCenter',
                        name: 'profitCenter',
                        //value:'05430',
                        width: 300,
                        listeners: {
                            blur: function (e) {
                                if(taskCompleted){
                                    return;
                                }
                                let id = Ext.getCmp("id").getValue()
                                saveObjectData(id, e.id, e.value);
                            }
                        }

            },
            ]
            }]
        };

        var mockExampleForm = {
            xtype: 'form',
            id: 'mainForm',
            width: '100%',
            hideLabel: true,
            frame: false,
            // border: false,
            layout: "anchor",// 整个大的表单是anchor布局
            items: [headPanel,groupInfoPanel,saleViewPanel,purchaseViewPanel,qualityViewPanel, certificationViewPanel, MRP1ViewPanel,MRP2ViewPanel,MRP3ViewPanel,MRP4ViewPanel,workPlanViewPanel,costViewPanel]
        };


/////////////////////////Main Panel items//////////////////////////////////
        this.items = [mockExampleForm];

        this.callParent();

    },//~End of initComponent
    listeners: {
        'afterrender': function () {
            console.log(Ext.getCmp('PartExtendExample').getIn_objectKey());
            // 查询MockExample form表单数据
            Ext.Ajax.request({
                url: '/Windchill/ptc1/ctPart/getDataById',
                method: 'GET',
                params: {
                    id: id
                },
                success: function (response, opts) {
                    var obj = Ext.decode(response.responseText);
                    var data = obj['data'];

                    if (obj['message']=='success') {
                        // var mainPanel = Ext.getCmp('mainForm');
                        selectPlan=true;
                        if(data['factory']==null){
                            Ext.getCmp("mrpController").setHidden(true);
                        }else {
                            Ext.getCmp("mrpController2").setHidden(true);
                        }

                        if(data['saleOrganization']==null){
                            Ext.getCmp("channels").setHidden(true);
                        }else {
                            Ext.getCmp("channels2").setHidden(true);
                        }

                        // if(data['productionLocation']==null){
                        //     Ext.getCmp("outBuyStorageLocation").setHidden(true);
                        // }else {
                        //     Ext.getCmp("outBuyStorageLocation2").setHidden(true);
                        // }
                        console.log("======"+ data['outBuyStorageLocation']);
                        setViewFromValue(data);
                    } else {
                        alert(obj.message);
                    }
                },
                failure: function (response, opts) {
                    alert('错误：查询信息失败，请检查网络！!');
                }
            }); //~End of Ajax request
        }
    }
});

//   //'','sapPartNumber''','','',
//  '','','','','','','','','', '' ,
// '','deliveryFactory','taxType','subjectGroup','projectTypeGroup','loadGroup','purchaseGroup', 'autoBuyList','sourceList','checkType','stockLogo',
// 'mrpType','mrpController','lotSize','miniLot','assemblyScrap','rounding','acquisitionType','specialType','goLogo','bulkPart','productionLocation',
//  'outBuyStorageLocation','planMarginalCode','selfProductionTime','planDeliveryTime','receiptTime','safeStock','policyGroup','consumptionPattern',
// 'reverseConsumption','periodConsumption','availabilityCheck','independentLogo','bomScrap','discontinueLogo','effectiveTime','subsequentPart',
//   'productionManager','productionPlanList','numberList','unitCode','accessType', 'priceControl','standardPrice','priceMoving','priceUnit','costEstimation',
//  'partSource','profitCenter'

